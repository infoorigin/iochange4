"""Source Data — read-only explorer over the hub's ingested source tables.

Read-only router over the barrier_signal hub Postgres schema (connection
from ``BARRIER_SIGNAL_DB_URL``, schema from ``BARRIER_SIGNAL_DB_SCHEMA``,
pooled by ``app/hub_db.py``). Powers the Operational Insights "Source Data"
sidebar group — the UI renders the sidebar from ``/summary``, so adding a
source here is the whole change.

  /summary            — per-source row counts + freshness + filter definitions
                        (distinct values for the UI's dropdown filter chips)
  /{source}           — paginated rows; server-side filtering (exact-match
                        query params validated against a per-source whitelist,
                        combined with AND) + free-text search; limit ≤ 100

Source → hub table mapping (schema v2, inspected live 2026-08-22):
  call-notes  → call_notes   (field call transcripts + HCP / account / persona
                              metadata — the only signal source today)
  claims      → ladd         (longitudinal claims: NDC, payer, formulary, PA)
  demand-plan → demand_plan  (brand × month × metric × scenario targets)

CUTOVER. The first version read the retired ``savant_data_hub`` (v1) tables
``sales_performance`` / ``crm_activity`` / ``signal_sources``; none exist in
``savant_data_hub_v2``. The generic ``SourceDef`` machinery is unchanged —
only the definitions moved.

NEVER writes to the hub — every statement is a parameterized SELECT. PII:
``hcp_name`` → "Dr. X. Y." as ``hcp``, ``rep_persona_name`` → initials as
``rep``; ``jnj_id`` / ``rep_persona_wwid`` / ``rep_persona_email`` /
``content_hash`` are never SELECTed (pinned by ``BANNED_COLUMNS`` and its
test). ``ladd.pat_id`` is an opaque claims identifier, not a name, and stays.
Transcripts stay verbatim — the same decision the Call Notes page made.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from dataclasses import dataclass, field

from fastapi import APIRouter, HTTPException, Request

from app import hub_db
from app.routers.barrier_insights import BANNED_COLUMNS, _json_safe, _mask_person

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/source-data", tags=["source-data"])

MAX_LIMIT = 100
DEFAULT_LIMIT = 25
#: query-string keys that are paging/search controls, not column filters
RESERVED_PARAMS = {"limit", "offset", "search"}

#: honorific by OUTPUT column: an HCP reads "Dr. X. Y.", a rep "X. Y."
_HONORIFIC_FOR = {"hcp": "Dr. "}


@contextmanager
def _hub():
    """Read-only hub cursor — POOLED, shared with the other hub routers."""
    with hub_db.hub_cursor() as cur:
        yield cur


# ── source definitions (config-driven; columns are explicit whitelists) ──

@dataclass(frozen=True)
class SourceDef:
    key: str
    label: str
    description: str
    table: str
    id_col: str
    #: SELECT list — real column names only (masking happens post-fetch).
    #: ALSO THE READING ORDER: the UI derives its column order from the key
    #: order of a returned row, so this tuple is what a reader sees left to
    #: right. Identity first, then the business-meaningful fields, then the
    #: plumbing — never SELECT order for its own sake.
    columns: tuple[str, ...]
    #: person-name columns masked to initials and renamed in the response
    mask_cols: dict[str, str] = field(default_factory=dict)
    #: filterable low-cardinality columns: column → UI label
    filters: dict[str, str] = field(default_factory=dict)
    #: free-text search columns (ILIKE, OR-combined)
    search_cols: tuple[str, ...] = ()
    order_by: str = ""
    #: long-text column the UI truncates + expands (call transcripts)
    long_text_col: str | None = None
    #: the timestamp MAX()ed for "freshness" in /summary
    freshness_col: str = "ingested_at"


SOURCES: dict[str, SourceDef] = {
    "call-notes": SourceDef(
        key="call-notes", label="Call Notes",
        description="Field call transcripts with HCP, account, persona and "
                    "geography metadata — the source every signal is "
                    "evidenced from.",
        table="call_notes", id_col="note_id",
        # who/when, then the HCP block (masked name beside the id and the
        # specialty it belongs with), the account and geography, what the
        # call was about, then the words, then the org hierarchy and the
        # ingest plumbing last.
        columns=("note_id", "call_recorded_timestamp",
                 "call_recorded_persona_role", "hcp_name", "hcp_id",
                 "hcp_specialty", "account_name", "account_id", "territory",
                 "region", "district", "brand_product", "therapy_area",
                 "sub_ta", "call_type_channel", "call_duration",
                 "rep_persona_name", "summary", "transcript",
                 "selling_division", "corporate_parent_l5", "regional_idn_l4",
                 "hospital_l3", "site_of_care_l2", "outlet_name_l1",
                 "source_file", "ingested_at", "call_id", "territory_id"),
        mask_cols={"hcp_name": "hcp", "rep_persona_name": "rep"},
        filters={"region": "Region", "territory": "Territory",
                 "district": "District", "brand_product": "Brand",
                 "call_recorded_persona_role": "Persona",
                 "hcp_specialty": "Specialty", "call_type_channel": "Channel"},
        search_cols=("transcript", "summary", "account_name", "note_id"),
        order_by="note_id",
        long_text_col="transcript",
        freshness_col="ingested_at",
    ),
    "claims": SourceDef(
        key="claims", label="Claims (LADD)",
        description="Longitudinal pharmacy claims: NDC / brand, payer channel "
                    "and plan, formulary tier, prior-auth and step edits, "
                    "rejections, allowed vs paid amounts.",
        table="ladd", id_col="clm_id",
        # the claim and its outcome, then the drug, then who paid and on what
        # terms, then the money, then dispensing and prescriber, and the
        # reference/classification fields last.
        columns=("clm_id", "svc_dt", "clm_stts", "clm_typ", "brand_nm",
                 "gnrc_nm", "ndc", "plan_name", "payer_channel",
                 "formulary_tier", "pa_required", "step_edit_required",
                 "rejection_reason", "allowed_amt", "patient_pay", "plan_pay",
                 "days_supply", "qty_dispensed", "pharmacy_channel",
                 "prscr_specialty", "prscr_region", "pat_id", "mfr",
                 "mkt_class", "therapeutic_area", "is_target_brand",
                 "in_mkt_basket", "ndc_is_placeholder", "launch_dt",
                 "ingested_at"),
        filters={"clm_typ": "Claim type", "clm_stts": "Status",
                 "brand_nm": "Brand", "pharmacy_channel": "Pharmacy channel",
                 "payer_channel": "Payer channel",
                 "formulary_tier": "Formulary tier",
                 "prscr_region": "Prescriber region",
                 "rejection_reason": "Rejection reason"},
        search_cols=("clm_id", "plan_name", "prscr_specialty"),
        order_by="svc_dt DESC, clm_id",
        freshness_col="ingested_at",
    ),
    "demand-plan": SourceDef(
        key="demand-plan", label="Demand Plan",
        description="Brand demand plan: monthly targets per metric and "
                    "scenario, with the planning source.",
        table="demand_plan", id_col="period_month",
        columns=("period_month", "brand_nm", "metric", "scenario",
                 "target_value", "plan_source", "updated_at"),
        filters={"brand_nm": "Brand", "metric": "Metric",
                 "scenario": "Scenario", "plan_source": "Plan source"},
        search_cols=("metric", "scenario"),
        order_by="period_month DESC, brand_nm, metric, scenario",
        freshness_col="updated_at",
    ),
}


def _source_or_404(source: str) -> SourceDef:
    sd = SOURCES.get(source)
    if not sd:
        raise HTTPException(
            status_code=404,
            detail=f"unknown source '{source}' (valid: {', '.join(SOURCES)})")
    return sd


def build_rows_query(sd: SourceDef, filters: dict[str, str], search: str,
                     limit: int, offset: int) -> tuple[str, str, list]:
    """(rows_sql, count_sql, params) — pure, parameterized; raises 400 on a
    filter key outside the source's whitelist. Shared params list: count uses
    params minus the trailing LIMIT/OFFSET pair."""
    where, params = [], []
    for col, val in filters.items():
        if col not in sd.filters:
            raise HTTPException(
                status_code=400,
                detail=f"'{col}' is not filterable on {sd.key} "
                       f"(filterable: {', '.join(sd.filters)})")
        where.append(f"{col} = %s")
        params.append(val)
    if search:
        like = " OR ".join(f"{c}::text ILIKE %s" for c in sd.search_cols)
        where.append(f"({like})")
        params.extend([f"%{search}%"] * len(sd.search_cols))
    where_sql = f" WHERE {' AND '.join(where)}" if where else ""
    cols = ", ".join(sd.columns)
    rows_sql = (f"SELECT {cols} FROM {sd.table}{where_sql} "
                f"ORDER BY {sd.order_by} LIMIT %s OFFSET %s")
    count_sql = f"SELECT COUNT(*) AS n FROM {sd.table}{where_sql}"
    return rows_sql, count_sql, params + [limit, offset]


def row_key_order(sd: SourceDef) -> tuple[str, ...]:
    """The key order a masked row comes back in — the SELECT list with each
    masked column replaced IN PLACE by its output name.

    Masking used to ``pop`` the source column and append the masked value,
    which put the two person fields at the far RIGHT of a 29-column table:
    the HCP's name ended up nowhere near the HCP id and specialty it belongs
    with. Masking is a rename, so it should not move the field.
    """
    order = [sd.mask_cols.get(c, c) for c in sd.columns]
    # a mask column declared outside the SELECT list still gets a slot
    order += [out for src, out in sd.mask_cols.items()
              if src not in sd.columns and out not in order]
    return tuple(order)


def _mask_row(sd: SourceDef, row: dict) -> dict:
    for src_col, out_col in sd.mask_cols.items():
        raw = row.pop(src_col, None)
        # 'NA' is a data convention for "not assigned", not a person name
        row[out_col] = (None if raw in (None, "", "NA")
                        else _mask_person(str(raw), honorific=_HONORIFIC_FOR.get(out_col, "")))
    # rebuild in reading order; anything unexpected keeps its value at the end
    out = {k: row[k] for k in row_key_order(sd) if k in row}
    out.update({k: v for k, v in row.items() if k not in out})
    return _json_safe(out)


# ── endpoints ────────────────────────────────────────────────────

FILTER_VALUES_LIMIT = 50


def summary_sql(sd: SourceDef) -> str:
    """ONE statement per source: count, freshness, and every filter column's
    distinct values as correlated array subselects.

    The first cut ran one `SELECT DISTINCT` per filter column — 25 round
    trips for three sources, measured at 5.5 s against RDS from a laptop,
    and the sidebar paid it on every navigation. Same values, three trips.
    Column names come from the SourceDef whitelist, never from a request.
    """
    parts = "".join(
        f", (SELECT array_agg(v ORDER BY v) FROM (SELECT DISTINCT {col} AS v "
        f"FROM {sd.table} WHERE {col} IS NOT NULL ORDER BY 1 "
        f"LIMIT {FILTER_VALUES_LIMIT}) s) AS f_{i}"
        for i, col in enumerate(sd.filters))
    return (f"SELECT COUNT(*) AS n, MAX({sd.freshness_col}) AS fresh{parts} "
            f"FROM {sd.table}")


@router.get("/summary")
def summary():
    """Per-source counts, freshness, and filter definitions with distinct
    values — one call powers the sidebar badges AND the filter dropdowns."""
    out = []
    with _hub() as cur:
        for sd in SOURCES.values():
            cur.execute(summary_sql(sd))
            head = cur.fetchone()
            filter_defs = []
            for i, (col, label) in enumerate(sd.filters.items()):
                values = [_json_safe(v) for v in (head.get(f"f_{i}") or [])]
                if values:  # empty column → no useless dropdown
                    filter_defs.append({"key": col, "label": label,
                                        "values": values})
            out.append({
                "key": sd.key, "label": sd.label,
                "description": sd.description,
                "table": sd.table, "count": head["n"],
                "freshness": head["fresh"].isoformat() if head["fresh"] else None,
                "filters": filter_defs,
                "search_columns": list(sd.search_cols),
                "long_text_column": sd.long_text_col,
                "id_column": sd.id_col,
            })
    return {"sources": out}


@router.get("/{source}")
def rows(source: str, request: Request, limit: int = DEFAULT_LIMIT,
         offset: int = 0, search: str = ""):
    sd = _source_or_404(source)
    limit = max(1, min(int(limit), MAX_LIMIT))
    offset = max(0, int(offset))
    filters = {k: v for k, v in request.query_params.items()
               if k not in RESERVED_PARAMS and v != ""}
    rows_sql, count_sql, params = build_rows_query(
        sd, filters, search.strip(), limit, offset)
    count_params = params[:-2]  # everything except the LIMIT/OFFSET pair
    with _hub() as cur:
        cur.execute(count_sql, count_params or None)
        total = cur.fetchone()["n"]
        cur.execute(rows_sql, params)
        data = [_mask_row(sd, dict(r)) for r in cur.fetchall()]
    return {"source": sd.key, "label": sd.label, "count": total,
            "limit": limit, "offset": offset,
            "filters_applied": filters, "search": search.strip(),
            "rows": data}
