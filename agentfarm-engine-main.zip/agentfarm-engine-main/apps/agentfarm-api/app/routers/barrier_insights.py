"""Operational Insights — executive evidence explorer over the barrier_signal hub.

Read-only router over the hub Postgres schema (``BARRIER_SIGNAL_DB_URL`` /
``BARRIER_SIGNAL_DB_SCHEMA``, pooled by ``app/hub_db.py``) plus the pack's
``taxonomy.yaml`` as an optional enrichment. Powers the Studio's Operational
Insights pages:

  /summary                  — one-call executive roll-up (barriers by status /
                              severity / category / type / account, signals by
                              method / category, evidence + source totals)
  /kb                       — the knowledge base in force: barrier types grouped
                              by category, each with its mapped signal types
                              (tier 1 first) and LIVE counts from the register
  /barriers, /barriers/{id} — the register, priority-ranked, with derived
                              signal types / evidence / source / insight counts
  /barriers/{id}/trace      — the provenance drill tree: barrier ▸ signals ▸
                              evidence quotes ▸ masked call notes, plus a census
                              that keeps MENTIONS apart from DISTINCT statements
  /barriers/{id}/graph      — the same closure as a graph in the ``iof-graph/v1``
                              vocabulary the pack's projection uses
  /graph/expand             — any node's neighbourhood, both directions
  /insights, /insights/{id} — statistical insights and what they rest on
  /mapping                  — insight ↔ barrier links with shared-signal counts

CUTOVER. The first version of this router read the retired ``savant_data_hub``
(v1) schema — ``lifecycle_status``, ``signal_sources``, ``link_strength`` —
none of which exist in ``savant_data_hub_v2``, so every endpoint 500'd the
moment the hub moved. Everything below is written against v2 and nothing
else; ``hil_queue.py`` / ``playbook_templates.py`` still read v1-only tables
and are deliberately untouched.

SHAPE. Each endpoint is a thin SQL fetch (every statement a parameterized
SELECT; identifiers never come from the request) handed to a PURE assembly
function over row lists — ``kb_grouping``, ``merge_barrier_derivations``,
``assemble_trace``, ``assemble_graph`` — so the tests need no database.

PII. Person names never leave this API verbatim: ``_mask_person`` reduces an
HCP to "Dr. X. Y." and a rep to initials. ``jnj_id``, ``rep_persona_wwid``,
``rep_persona_email`` and ``content_hash`` are never SELECTed (pinned by the
column constants below and their test). Accounts, territories, regions and
transcripts stay verbatim — the same decision the Call Notes page made.
"""

from __future__ import annotations

import logging
import re
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

import yaml
from fastapi import APIRouter, HTTPException

from app import hub_db
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/barrier-insights", tags=["barrier-insights"])

TRANSCRIPT_EXCERPT = 600   # display cap for call-note transcript excerpts
EVIDENCE_PER_SIGNAL = 5    # evidence quotes surfaced per signal in a trace
SIGNALS_PER_BARRIER = 60   # trace cap (the largest barrier links 5 today)
PROP_TRIM = 260            # long text props on graph nodes are trimmed to this
EXPAND_CAP = 40            # fan-out cap for the wide neighbourhoods in /expand

#: KB category order the client reads the taxonomy in; unknown ones follow.
CATEGORY_ORDER = ("Commercial", "Patient", "Medical", "Market", "Customer",
                  "Enterprise")

#: Columns that must NEVER appear in a SELECT here (identity / plumbing).
BANNED_COLUMNS = ("jnj_id", "rep_persona_wwid", "rep_persona_email",
                  "content_hash", "content_key")

# ── graph vocabulary — MUST equal solutions/pharma/tools/graph_projection.py ──
# Pinned by tests/test_barrier_insights.py, which parses that file.

N_BARRIER, N_SIGNAL, N_EVIDENCE, N_SOURCE = "Barrier", "Signal", "Evidence", "Source"
N_ACCOUNT, N_ORG, N_HCP, N_PERSONA = "Account", "Organization", "HCP", "Persona"
N_INSIGHT, N_SIGNAL_TYPE, N_BARRIER_TYPE = "Insight", "SignalType", "BarrierType"
N_CORRELATION = "Correlation"

E_SUPPORTS = "SUPPORTS"            # Signal   -> Barrier   (stance-carrying)
E_DETECTED_FROM = "DETECTED_FROM"  # Signal   -> Source    (one per (signal, source))
E_HAS_EVIDENCE = "HAS_EVIDENCE"    # Signal   -> Evidence
E_QUOTES = "QUOTES"                # Evidence -> Source
E_EVIDENCES = "EVIDENCES"          # Signal   -> Insight
E_CONCERNS = "CONCERNS"            # Insight  -> Barrier
E_CORRELATES = "CORRELATES"        # Signal   -> Correlation
E_AT_ACCOUNT = "AT_ACCOUNT"        # Source   -> Account
E_ABOUT_HCP = "ABOUT_HCP"          # Source   -> HCP
E_REPORTED_BY = "REPORTED_BY"      # Source   -> Persona
E_PRACTICES_AT = "PRACTICES_AT"    # HCP      -> Account
E_SITE_OF = "SITE_OF"              # Account  -> Organization (proposed; not projected here)
E_SCOPED_TO = "SCOPED_TO"          # Barrier  -> Account | HCP
E_TYPED_AS = "TYPED_AS"            # Signal   -> SignalType
E_MAPS_TO = "MAPS_TO"              # SignalType -> BarrierType (KB, tiered)
E_OF_TYPE = "OF_TYPE"              # Barrier  -> BarrierType

GRAPH_LABELS: tuple[str, ...] = (
    N_BARRIER, N_SIGNAL, N_EVIDENCE, N_SOURCE, N_ACCOUNT, N_ORG, N_HCP,
    N_PERSONA, N_INSIGHT, N_SIGNAL_TYPE, N_BARRIER_TYPE, N_CORRELATION)
GRAPH_EDGE_TYPES: tuple[str, ...] = (
    E_SUPPORTS, E_DETECTED_FROM, E_HAS_EVIDENCE, E_QUOTES, E_EVIDENCES,
    E_CONCERNS, E_CORRELATES, E_AT_ACCOUNT, E_ABOUT_HCP, E_REPORTED_BY,
    E_PRACTICES_AT, E_SITE_OF, E_SCOPED_TO, E_TYPED_AS, E_MAPS_TO, E_OF_TYPE)
GRAPH_FORMAT = "iof-graph/v1"

# ── SELECT lists — explicit whitelists, one per table ────────────────────

BARRIER_SELECT = (
    # `scope_parent` is the account behind a prescriber-scope row. Without it a
    # masked `Dr. S. C.` cannot be told from another `Dr. S. C.` at a different
    # site, and 23 of 97 names in the delivered corpus appear at more than one.
    "barrier_id, barrier_type, barrier_category, scope_kind, scope_value, "
    # `parent_barrier_id` is the ROLL-UP: which account barrier generalises
    # this prescriber one. 84 of 190 rows carry it and none of them reached the
    # wire, so the UI could not show the relationship the grain change exists
    # to provide - an account claim and the prescribers beneath it.
    "scope_parent, parent_barrier_id, "
    "statement, rationale, status, review_state, review_reason, severity, "
    "confidence, priority, kb_support_tier, supporting_count, "
    "conflicting_count, evidence_strength, insufficiency_reason, brand, "
    "run_id, detected_at")
BARRIER_DETAIL_SELECT = BARRIER_SELECT + ", score_drivers, verified_claims"
#: aliased `s.` because it is always read through a JOIN on a link table
SIGNAL_SELECT = (
    "s.signal_id, s.signal_type, s.signal_category, s.scope, s.scope_kind, "
    "s.scope_value, s.scope_parent, s.observed_period, s.brand, "
    "s.account_name, s.hcp_name, "
    "s.statement, s.detection_method, s.rule_name, s.evidence_strength, "
    "s.mention_count, s.distinct_evidence_count, s.source_count, "
    "s.corroboration, s.status, s.run_id, s.detected_at")
EVIDENCE_SELECT = (
    "evidence_id, signal_id, source_table, source_ref, source_column, "
    "snippet, speaker, turn_index, matched_phrase")
#: the call note WITHOUT its transcript (graph nodes); `hcp_name` and
#: `rep_persona_name` are selected only to be masked.
NOTE_SELECT = (
    "note_id, call_id, call_recorded_timestamp, call_recorded_persona_role, "
    "rep_persona_name, hcp_name, hcp_id, hcp_specialty, account_name, "
    "account_id, territory, region, district, brand_product, therapy_area, "
    "call_type_channel, summary")
#: the trace adds a capped excerpt; the `%s` is TRANSCRIPT_EXCERPT
NOTE_TRACE_SELECT = (NOTE_SELECT + ", left(transcript, %s) AS transcript_excerpt, "
                     "length(transcript) AS transcript_length")
#: the same projection with a NAMED excerpt parameter. The closure statement
#: below binds by name — it carries one value across fourteen CTEs and
#: positional order would be a trap — while `signals.py` keeps the positional
#: form. Same SQL, so the two cannot drift in what they select.
_NOTE_TRACE_SELECT_NAMED = NOTE_TRACE_SELECT.replace("%s", "%(excerpt)s")
CORRELATION_SELECT = (
    "c.correlation_id, c.signal_type, c.scope_kind, c.scope_value, "
    "c.scope_parent, "
    "c.signal_count, c.source_count, c.period_count, c.has_conflict")
INSIGHT_SELECT = (
    "insight_id, insight_type, title, narrative, why_generated, "
    "why_no_barrier, scope_kind, scope_value, scope_parent, run_id, created_at")
SIGNAL_TYPE_META_SELECT = ("signal_type, signal_category, signal_group, "
                           "directional, polarity")
BARRIER_TYPE_META_SELECT = "barrier_type, category, definition, typical_signals"

_HONORIFIC_RE = re.compile(r"^(dr|prof|mr|mrs|ms)\.?\s+", re.I)


# ── small helpers ────────────────────────────────────────────────────────

def _mask_person(name: str | None, honorific: str = "") -> str | None:
    """Person names never leave this API verbatim — initials only.

    'Dr. A Smith' -> 'Dr. A. S.' (with honorific) · 'Diana' -> 'D.'
    Institutions / regions are not persons and stay verbatim.
    """
    if not name or not str(name).strip():
        return None
    raw = str(name).strip()
    # already-pseudonymous labels ("HCP 28") pass through unchanged
    if re.fullmatch(r"HCP[\s-]*\d+", raw, re.I):
        return raw.upper()
    bare = _HONORIFIC_RE.sub("", raw)
    parts = [p for p in re.split(r"[\s.]+", bare) if p and p[0].isalpha()]
    if not parts:
        return None
    initials = " ".join(f"{p[0].upper()}." for p in parts[:3])
    return f"{honorific}{initials}" if honorific else initials


def _json_safe(value: Any) -> Any:
    """Decimal → float, datetime/date → isoformat, recursively. jsonb columns
    arrive as dicts already and pass through."""
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def _trim(value: Any, n: int = PROP_TRIM) -> Any:
    if isinstance(value, str) and len(value) > n:
        return value[: n - 3] + "..."
    return _json_safe(value)


def _int(v: Any) -> int:
    try:
        return int(v or 0)
    except (TypeError, ValueError):
        return 0


@contextmanager
def _hub():
    """Read-only hub cursor — POOLED, shared with the other hub routers."""
    with hub_db.hub_cursor() as cur:
        yield cur


def _rows(cur) -> list[dict]:
    """Every hub read comes through here - which is why the mask lives here.

    `scope_value` BECAME A PERSON when detection moved to prescriber grain. It
    used to hold an account name on every row, so it was safe to pass through
    verbatim and this module's promise - "person names never leave this API
    verbatim" - held without anyone thinking about it. At `hcp` scope it now
    holds a prescriber's full name, on the majority of barriers, signals and
    correlations. Nothing in the SELECT lists changed; the meaning of a column
    did.

    Masking here rather than in each shaper is deliberate: there are a dozen
    queries and one reader, and a rule applied per-caller is a rule the next
    caller forgets. `scope_parent` is an ACCOUNT and stays verbatim - it is
    what keeps two same-named prescribers apart once their names are initials,
    which is the same job it does in the hub's identity key.
    """
    return [mask_scope(dict(r)) for r in cur.fetchall()]


#: Free text the ANALYSIS wrote, and which therefore may name a prescriber.
#: Call-note `transcript` and `summary` are deliberately NOT here: they are
#: the source record, served verbatim by an existing decision this must not
#: quietly reverse.
_PROSE_FIELDS = ("statement", "rationale", "narrative", "title",
                 "why_generated", "why_no_barrier", "insufficiency_reason",
                 "review_reason")

#: An honorific is the anchor. Without one there is no way to tell a surname
#: from any other capitalised word, and a redactor that guesses eats
#: "Patient Access" and "Boston Oncology". `[A-Z][a-z]+` needs two letters,
#: so already-masked text (`Dr. S. D.`) does not match and cannot be
#: double-masked.
_PROSE_NAME_RE = re.compile(
    r"\b(Dr|Prof|Mr|Mrs|Ms)\.?\s+((?:[A-Z][a-z]+)(?:\s+[A-Z][a-z]+){0,2})")


def mask_prose(text):
    """Redact prescriber names OUT OF FREE TEXT, not just out of columns.

    THE COLUMN MASK IS NOT ENOUGH, and measurement is what showed it: of 190
    barriers in the validation hub, 30 statements and 42 rationales name a
    person, and three name one IN FULL. Masking `scope_value` alone leaves
    "Patients in Dr. Skyler Davis's panel" on the wire beside a `scope_value`
    reading `Dr. S. D.` - the guarantee defeated by the sentence next to it.

    A per-row scrub keyed on the row's own name cannot fix it either: 22 of
    those rationales sit on ACCOUNT-grain barriers, where `scope_value` is an
    institution and the people named are the account's prescribers. The row
    holds no key to scrub by, so the rule has to be a pattern.
    """
    if not text or not isinstance(text, str):
        return text

    def sub(m):
        return _mask_person(m.group(2), honorific=m.group(1) + ". ") or m.group(0)

    out, n = _PROSE_NAME_RE.subn(sub, text)
    if not n:
        return text
    # Initials END in a period, so a name that ended a sentence leaves two.
    # "Dr. Taylor Brooks." -> "Dr. T. B.." reads as a defect to the domain
    # reviewer looking at it, and they are the whole audience for this text.
    # Anchored on the initial itself, NOT on "any doubled period": the loose
    # version ate one dot of an ellipsis ("A pause..." -> "A pause..").
    return re.sub(r"([A-Z]\.)\.", lambda m: m.group(1), out)


def mask_scope(row: dict) -> dict:
    """`scope_value` is a PERSON at `hcp` scope. Public so the other hub
    routers use this one rather than growing a second copy - `signals.py`
    already had its own `_rows`, which is how a fix reaches one reader and not
    the other."""
    if row.get("scope_kind") == "hcp" and row.get("scope_value"):
        row["scope_value"] = _mask_person(row["scope_value"], honorific="Dr. ")
    for field in _PROSE_FIELDS:
        if row.get(field):
            row[field] = mask_prose(row[field])
    return row


def mask_note(row: dict) -> dict:
    """A call note as the wire ``TraceSource``: person names masked, identity
    columns renamed, nothing else from the row leaks through."""
    return _json_safe({
        "note_id": row.get("note_id"),
        "call_id": row.get("call_id"),
        "date": row.get("call_recorded_timestamp"),
        "persona_role": row.get("call_recorded_persona_role"),
        "rep": _mask_person(row.get("rep_persona_name")),
        "hcp": _mask_person(row.get("hcp_name"), honorific="Dr. "),
        "hcp_id": row.get("hcp_id"),
        "hcp_specialty": row.get("hcp_specialty"),
        "account_name": row.get("account_name"),
        "account_id": row.get("account_id"),
        "territory": row.get("territory"),
        "region": row.get("region"),
        "district": row.get("district"),
        "brand": row.get("brand_product"),
        "therapy_area": row.get("therapy_area"),
        "call_type": row.get("call_type_channel"),
        "transcript_excerpt": row.get("transcript_excerpt"),
        "transcript_length": row.get("transcript_length"),
        "summary": row.get("summary"),
    })


def mask_signal(row: dict) -> dict:
    """A signal row for the wire: ``hcp_name`` becomes masked ``hcp``."""
    out = _json_safe(dict(row))
    out["hcp"] = _mask_person(out.pop("hcp_name", None), honorific="Dr. ")
    # `hcp_name` was the only person column when this was written. At
    # prescriber grain `scope_value` is one too, on most rows.
    return mask_scope(out)


# ── knowledge base ───────────────────────────────────────────────────────

def _taxonomy_path() -> Path | None:
    """The pack's taxonomy.yaml, if this process can see a checkout.

    Flat workspace layout first (``solutions/<domain>/taxonomy/``), then any
    packaged copy deeper down. The Studio API pod has no packs, so None is
    the normal answer there and the KB is served from the hub alone.
    """
    root = get_settings().agentfarm_dir
    for pattern in ("solutions/*/taxonomy/taxonomy.yaml",
                    "solutions/*/**/taxonomy/taxonomy.yaml"):
        for cand in sorted(root.glob(pattern)):
            if cand.is_file():
                return cand
    return None


def load_taxonomy() -> dict | None:
    path = _taxonomy_path()
    if not path:
        return None
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as e:  # unreadable → hub-only, never an error
        logger.warning("taxonomy.yaml at %s not readable: %s", path, e)
        return None
    return data if isinstance(data, dict) else None


def kb_grouping(barrier_types: list[dict], signal_types: list[dict],
                mapping: list[dict], barrier_counts: dict[str, int],
                signal_counts: dict[str, int],
                taxonomy: dict | None = None) -> dict:
    """Pure: hub meta rows (+ optional taxonomy enrichment) → KnowledgeBase.

    A barrier type's signal types come from ``signal_barrier_map`` — tier 1
    first, then by name — joined to ``signal_type_meta`` for polarity / group.
    Counts are LIVE (what the register holds), never the KB's own numbers.
    """
    tax_bt = (taxonomy or {}).get("barrier_types") or {}
    tax_st = (taxonomy or {}).get("signal_types") or {}
    st_meta = {r["signal_type"]: r for r in signal_types}
    by_bt: dict[str, list[dict]] = defaultdict(list)
    for m in mapping:
        by_bt[m["barrier_type"]].append(m)

    out_types: list[dict] = []
    for bt in barrier_types:
        name = bt["barrier_type"]
        tb = tax_bt.get(name) or {}
        sts = []
        for m in sorted(by_bt.get(name, []),
                        key=lambda m: (m.get("support_tier") or 99, m["signal_type"])):
            meta = st_meta.get(m["signal_type"]) or {}
            ts = tax_st.get(m["signal_type"]) or {}
            entry: dict[str, Any] = {
                "name": m["signal_type"],
                "signal_category": (meta.get("signal_category")
                                    or ts.get("signal_category") or ""),
                "signal_group": meta.get("signal_group") or ts.get("signal_group"),
                "polarity": meta.get("polarity") or ts.get("polarity"),
                "directional": meta.get("directional", ts.get("directional")),
                "support_tier": _int(m.get("support_tier")) or None,
                "cues": [str(c) for c in (ts.get("cues") or ts.get("hints") or [])],
                "signal_count": signal_counts.get(m["signal_type"], 0),
            }
            if ts.get("definition"):
                entry["definition"] = str(ts["definition"]).strip()
            sts.append(entry)
        typical = bt.get("typical_signals") or tb.get("typical_signals") or []
        out_types.append({
            "name": name,
            "category": bt.get("category") or tb.get("category") or "",
            "definition": str(bt.get("definition") or tb.get("definition") or "").strip(),
            "typical_signals": [str(t) for t in typical],
            "signal_types": sts,
            "barrier_count": barrier_counts.get(name, 0),
        })

    cats: dict[str, list[dict]] = defaultdict(list)
    for t in out_types:
        cats[t["category"]].append(t)

    def _rank(c: str):
        return (CATEGORY_ORDER.index(c) if c in CATEGORY_ORDER
                else len(CATEGORY_ORDER), c)

    categories = [{"name": c, "barrier_types": sorted(cats[c], key=lambda t: t["name"])}
                  for c in sorted(cats, key=_rank)]
    flat = [t for c in categories for t in c["barrier_types"]]
    return {
        "source": "hub+taxonomy.yaml" if taxonomy else "hub",
        "categories": categories,
        "barrier_types": flat,
        "barrier_type_count": len(flat),
        "signal_type_count": len(signal_types),
        "mapping_count": len(mapping),
    }


@router.get("/kb")
def knowledge_base():
    with _hub() as cur:
        cur.execute(f"SELECT {BARRIER_TYPE_META_SELECT} FROM barrier_type_meta "
                    "ORDER BY barrier_type")
        barrier_types = _rows(cur)
        cur.execute(f"SELECT {SIGNAL_TYPE_META_SELECT} FROM signal_type_meta "
                    "ORDER BY signal_type")
        signal_types = _rows(cur)
        cur.execute("SELECT signal_type, barrier_type, support_tier "
                    "FROM signal_barrier_map ORDER BY barrier_type, support_tier, signal_type")
        mapping = _rows(cur)
        cur.execute("SELECT barrier_type AS k, COUNT(*) AS n FROM barriers GROUP BY 1")
        barrier_counts = {r["k"]: r["n"] for r in cur.fetchall()}
        cur.execute("SELECT signal_type AS k, COUNT(*) AS n FROM signals GROUP BY 1")
        signal_counts = {r["k"]: r["n"] for r in cur.fetchall()}
    return kb_grouping(barrier_types, signal_types, mapping, barrier_counts,
                       signal_counts, taxonomy=load_taxonomy())


# ── summary ──────────────────────────────────────────────────────────────

def summary_from_rows(barrier_groups: list[dict], account_rows: list[dict],
                      signal_groups: list[dict], linked: int,
                      evidence_total: int, note_head: dict,
                      insights_total: int) -> dict:
    """Pure: GROUP BY rows → HubSummary. ``barrier_groups`` is one row per
    (barrier_type, barrier_category, status, severity) with ``n`` and
    ``fresh``; ``signal_groups`` one per (detection_method, signal_category)."""
    total = 0
    by_status: Counter = Counter()
    by_severity: Counter = Counter()
    by_category: Counter = Counter()
    by_type: dict[str, dict] = {}
    fresh = None
    for r in barrier_groups:
        n = _int(r.get("n"))
        total += n
        by_status[r.get("status") or "unknown"] += n
        by_severity[r.get("severity") or "none"] += n
        by_category[r.get("barrier_category") or "unknown"] += n
        t = by_type.setdefault(r["barrier_type"], {
            "barrier_type": r["barrier_type"],
            "category": r.get("barrier_category") or "",
            "count": 0, "high": 0, "medium": 0, "low": 0})
        t["count"] += n
        if r.get("severity") in ("high", "medium", "low"):
            t[r["severity"]] += n
        if r.get("fresh") and (fresh is None or r["fresh"] > fresh):
            fresh = r["fresh"]
    sig_total = 0
    by_method: Counter = Counter()
    sig_by_category: Counter = Counter()
    for r in signal_groups:
        n = _int(r.get("n"))
        sig_total += n
        by_method[r.get("detection_method") or "unknown"] += n
        sig_by_category[r.get("signal_category") or "unknown"] += n
    return _json_safe({
        "barriers": {
            "total": total,
            "by_status": dict(by_status),
            "by_severity": dict(by_severity),
            "by_category": dict(by_category),
            "by_type": sorted(by_type.values(),
                              key=lambda t: (-t["count"], t["barrier_type"])),
            "by_account": [{"scope_value": r["scope_value"], "count": _int(r["n"]),
                            "high": _int(r["high"])} for r in account_rows],
        },
        "signals": {
            "total": sig_total,
            "linked": _int(linked),
            "by_method": dict(by_method),
            "by_category": dict(sig_by_category),
        },
        "evidence_total": _int(evidence_total),
        "sources_total": _int(note_head.get("n")),
        "accounts_total": _int(note_head.get("accounts")),
        "hcps_total": _int(note_head.get("hcps")),
        "insights_total": _int(insights_total),
        "freshness": fresh,
    })


@router.get("/summary")
def hub_summary():
    """One-call executive roll-up — seven aggregates, no per-row work."""
    with _hub() as cur:
        cur.execute("SELECT barrier_type, barrier_category, status, severity, "
                    "COUNT(*) AS n, MAX(detected_at) AS fresh "
                    "FROM barriers GROUP BY 1, 2, 3, 4")
        barrier_groups = _rows(cur)
        # AN ACCOUNT'S BARRIERS ARE NOT ONLY ITS ACCOUNT-SCOPE ONES. Since
        # detection moved to prescriber grain most barriers sit at `hcp` scope
        # with the account in `scope_parent`, so filtering to `scope_kind =
        # 'account'` reported a fraction of the register - a site with eight
        # prescriber barriers and no account-level one appeared with none, or
        # not at all. Rolling up on COALESCE(scope_parent, scope_value) counts
        # a barrier under the account it concerns, whichever grain it was
        # judged at.
        cur.execute("SELECT COALESCE(NULLIF(scope_parent, ''), scope_value) "
                    "AS scope_value, COUNT(*) AS n, "
                    "COUNT(*) FILTER (WHERE severity = 'high') AS high "
                    "FROM barriers WHERE scope_kind IN ('account', 'hcp') "
                    "GROUP BY 1 ORDER BY n DESC, high DESC, 1 "
                    "LIMIT 12")
        account_rows = _rows(cur)
        cur.execute("SELECT detection_method, signal_category, COUNT(*) AS n "
                    "FROM signals GROUP BY 1, 2")
        signal_groups = _rows(cur)
        cur.execute("SELECT COUNT(DISTINCT signal_id) AS n FROM barrier_signals")
        linked = cur.fetchone()["n"]
        cur.execute("SELECT COUNT(*) AS n FROM signal_evidence")
        evidence_total = cur.fetchone()["n"]
        cur.execute("SELECT COUNT(*) AS n, COUNT(DISTINCT account_name) AS accounts, "
                    "COUNT(DISTINCT hcp_id) AS hcps FROM call_notes")
        note_head = dict(cur.fetchone())
        cur.execute("SELECT COUNT(*) AS n FROM insights")
        insights_total = cur.fetchone()["n"]
    return summary_from_rows(barrier_groups, account_rows, signal_groups, linked,
                             evidence_total, note_head, insights_total)


# ── barriers ─────────────────────────────────────────────────────────────

def merge_barrier_derivations(barriers: list[dict], type_rows: list[dict],
                              evidence_rows: list[dict],
                              insight_rows: list[dict]) -> list[dict]:
    """Pure: barrier rows ⊕ three GROUP BY results → HubBarrier rows.

    ``type_rows``: (barrier_id, signal_type, n) ordered by barrier then
    frequency; ``evidence_rows``: (barrier_id, evidence_count, source_count);
    ``insight_rows``: (barrier_id, n). A barrier absent from a derivation has
    zero of it — the 15 insufficient-evidence barriers link no signals at all.
    """
    types: dict[str, list[str]] = defaultdict(list)
    for r in type_rows:
        if r["signal_type"] not in types[r["barrier_id"]]:
            types[r["barrier_id"]].append(r["signal_type"])
    ev = {r["barrier_id"]: r for r in evidence_rows}
    ins = {r["barrier_id"]: _int(r["n"]) for r in insight_rows}
    out = []
    for b in barriers:
        row = _json_safe(dict(b))
        bid = row["barrier_id"]
        e = ev.get(bid) or {}
        row["signal_types"] = list(types.get(bid, []))
        row["evidence_count"] = _int(e.get("evidence_count"))
        row["source_count"] = _int(e.get("source_count"))
        row["insight_count"] = ins.get(bid, 0)
        out.append(row)
    return out


def barrier_facets(facet_rows: list[dict]) -> dict:
    """Pure: (status, severity, barrier_category, barrier_type, scope_value, n)
    GROUP BY rows over the WHOLE register → BarrierFacets. A null severity
    (insufficient barriers) is counted under 'none' so facets sum to total."""
    facets: dict[str, Counter] = {k: Counter() for k in (
        "status", "severity", "barrier_category", "barrier_type", "scope_value")}
    for r in facet_rows:
        n = _int(r.get("n"))
        for k in facets:
            v = r.get(k)
            facets[k][str(v) if v not in (None, "") else "none"] += n
    return {k: dict(sorted(c.items(), key=lambda kv: (-kv[1], kv[0])))
            for k, c in facets.items()}


_DERIVE_TYPES_SQL = (
    "SELECT bs.barrier_id, s.signal_type, COUNT(*) AS n "
    "FROM barrier_signals bs JOIN signals s ON s.signal_id = bs.signal_id{where} "
    "GROUP BY 1, 2 ORDER BY 1, n DESC, 2")
_DERIVE_EVIDENCE_SQL = (
    "SELECT bs.barrier_id, COUNT(DISTINCT e.evidence_id) AS evidence_count, "
    "COUNT(DISTINCT e.source_ref) AS source_count "
    "FROM barrier_signals bs JOIN signal_evidence e ON e.signal_id = bs.signal_id{where} "
    "GROUP BY 1")
_DERIVE_INSIGHTS_SQL = (
    "SELECT barrier_id, COUNT(*) AS n FROM insight_barriers{where} GROUP BY 1")


def _fetch_derivations(cur, barrier_id: str | None = None) -> tuple[list, list, list]:
    """The three GROUP BY derivations — whole register, or one barrier."""
    where = " WHERE bs.barrier_id = %s" if barrier_id else ""
    params = (barrier_id,) if barrier_id else None
    cur.execute(_DERIVE_TYPES_SQL.format(where=where), params)
    type_rows = _rows(cur)
    cur.execute(_DERIVE_EVIDENCE_SQL.format(where=where), params)
    evidence_rows = _rows(cur)
    cur.execute(_DERIVE_INSIGHTS_SQL.format(
        where=" WHERE barrier_id = %s" if barrier_id else ""), params)
    insight_rows = _rows(cur)
    return type_rows, evidence_rows, insight_rows


@router.get("/barriers")
def list_barriers(status: str = ""):
    """The whole register, priority-ranked; ``?status=`` is a server-side cut.
    Facets always describe the WHOLE register, filtered or not."""
    where, params = "", []
    if status.strip():
        where = " WHERE status = %s"
        params.append(status.strip())
    with _hub() as cur:
        cur.execute(f"SELECT {BARRIER_SELECT} FROM barriers{where} "
                    "ORDER BY priority DESC NULLS LAST, supporting_count DESC, barrier_id",
                    params or None)
        barriers = _rows(cur)
        type_rows, evidence_rows, insight_rows = _fetch_derivations(cur)
        # `scope_kind` is selected ONLY so the mask can read it. Without it
        # `mask_scope` cannot tell a prescriber from an institution and
        # correctly declines to guess - which sent 97 real names out in the
        # facet list while every barrier row beside them was masked. The
        # facet builder ignores the extra column, and its Counter sums on
        # collision, so two prescribers sharing initials add up rather than
        # overwrite.
        cur.execute("SELECT status, severity, barrier_category, barrier_type, "
                    "scope_value, scope_kind, COUNT(*) AS n "
                    "FROM barriers GROUP BY 1, 2, 3, 4, 5, 6")
        facet_rows = _rows(cur)
    rows = merge_barrier_derivations(barriers, type_rows, evidence_rows, insight_rows)
    return {"count": len(rows), "barriers": rows, "facets": barrier_facets(facet_rows)}


def _fetch_barrier_or_404(cur, barrier_id: str) -> dict:
    cur.execute(f"SELECT {BARRIER_DETAIL_SELECT} FROM barriers WHERE barrier_id = %s",
                (barrier_id,))
    row = cur.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"barrier '{barrier_id}' not found")
    # MASKED HERE because this is a single-row read and `_rows` never sees it.
    # The register was masked and the DETAIL was not: the list showed
    # `Dr. S. D.` while opening that same barrier printed `Dr. Skyler Davis`
    # in its header. One barrier at a time is exactly the read that gets
    # forgotten, and it is the one a person actually looks at.
    return mask_scope(dict(row))


#: INSIGHT_SELECT qualified for the `insights i` side of the barrier join
_INSIGHT_SELECT_I = ", ".join("i." + c for c in INSIGHT_SELECT.split(", "))


def _fetch_barrier_insights(cur, barrier_id: str) -> list[dict]:
    cur.execute(f"SELECT ib.relation, {_INSIGHT_SELECT_I} "
                "FROM insight_barriers ib JOIN insights i ON i.insight_id = ib.insight_id "
                "WHERE ib.barrier_id = %s ORDER BY i.insight_id", (barrier_id,))
    return _rows(cur)


def barrier_detail(barrier: dict, type_rows: list[dict], evidence_rows: list[dict],
                   insight_rows: list[dict], insights: list[dict]) -> dict:
    """Pure: one barrier row ⊕ derivations ⊕ insight rows → BarrierDetail."""
    row = merge_barrier_derivations([barrier], type_rows, evidence_rows, insight_rows)[0]
    row["score_drivers"] = row.get("score_drivers") or None
    row["verified_claims"] = row.get("verified_claims") if "verified_claims" in row else None
    row["insights"] = [{"insight_id": i["insight_id"], "title": i.get("title"),
                        "insight_type": i.get("insight_type"),
                        "relation": i.get("relation")} for i in insights]
    return row


@router.get("/barriers/{barrier_id}")
def get_barrier(barrier_id: str):
    with _hub() as cur:
        barrier = _fetch_barrier_or_404(cur, barrier_id)
        type_rows, evidence_rows, insight_rows = _fetch_derivations(cur, barrier_id)
        insights = _fetch_barrier_insights(cur, barrier_id)
    return barrier_detail(barrier, type_rows, evidence_rows, insight_rows, insights)


# ── the closure below one barrier (shared by /trace and /graph) ──────────

#: Every set below one barrier, as ONE statement.
#:
#: It WAS nine sequential statements, and /trace then added three derivation
#: GROUP BYs on top while /graph added two meta reads — twelve and eleven
#: round trips. Every dependency was a round trip made of nothing: read the
#: signal ids, send them back, read the evidence, collect its source_refs,
#: send THOSE back. Against RDS from a laptop one round trip is ~0.25s, so
#: /trace measured 2.98s and /graph 2.72s on a barrier with five signals —
#: latency, not work, and the UI pays both back to back when a reader opens
#: the Graph tab.
#:
#: The CTEs chain the SAME dependencies inside the database (`ev` reads
#: `WHERE signal_id IN (SELECT signal_id FROM sig)`, `nt` reads `ev`'s
#: source_refs) and each set comes back as its own `json_agg` column. Points
#: that are load-bearing rather than stylistic:
#:
#:  * every `json_agg` carries its ORDER BY *inside* the aggregate — the
#:    assembly relies on those orders and a bare `json_agg` would leave them
#:    to the plan;
#:  * `coalesce(..., '[]')` so an empty set is `[]` and never NULL, which is
#:    what lets every downstream branch stay exactly as it was;
#:  * the barrier rides the same statement, so the 404 costs no extra trip;
#:  * `json_agg` changes types at the boundary — timestamps arrive as the
#:    same ISO strings `_json_safe` produced, numerics as JSON numbers, jsonb
#:    as nested objects. Nothing downstream needed `datetime`/`Decimal`
#:    objects (`mask_note`, `trace_census`, `emit_*` and `_trim` all read
#:    through `_json_safe`), and `_json_safe` still passes the new shapes.
#:
#: `sig` and `ev` are referenced by several CTEs each, so PostgreSQL
#: materialises them once — the chain is evaluated once, not per reader.
CLOSURE_SQL = f"""
WITH b AS (
    SELECT {BARRIER_DETAIL_SELECT} FROM barriers WHERE barrier_id = %(bid)s
), sig AS (
    SELECT {SIGNAL_SELECT}, bs.stance, bs.support_tier
    FROM barrier_signals bs JOIN signals s ON s.signal_id = bs.signal_id
    WHERE bs.barrier_id = %(bid)s
), ev AS (
    SELECT {EVIDENCE_SELECT} FROM signal_evidence
    WHERE signal_id IN (SELECT signal_id FROM sig)
), nt AS (
    SELECT {_NOTE_TRACE_SELECT_NAMED} FROM call_notes
    WHERE note_id IN (SELECT source_ref FROM ev
                      WHERE source_table = 'call_notes' AND source_ref IS NOT NULL)
), corr AS (
    SELECT cs.signal_id, cs.stance, {CORRELATION_SELECT}
    FROM correlation_signals cs
    JOIN signal_correlations c ON c.correlation_id = cs.correlation_id
    WHERE cs.signal_id IN (SELECT signal_id FROM sig)
), stm AS (
    SELECT {SIGNAL_TYPE_META_SELECT} FROM signal_type_meta
    WHERE signal_type IN (SELECT signal_type FROM sig)
), ins AS (
    SELECT ib.relation, {_INSIGHT_SELECT_I}
    FROM insight_barriers ib JOIN insights i ON i.insight_id = ib.insight_id
    WHERE ib.barrier_id = %(bid)s
), isl AS (
    SELECT insight_id, signal_id FROM insight_signals
    WHERE insight_id IN (SELECT insight_id FROM ins)
      AND signal_id IN (SELECT signal_id FROM sig)
), dtype AS (
    SELECT %(bid)s::text AS barrier_id, signal_type, COUNT(*) AS n
    FROM sig GROUP BY signal_type
), dev AS (
    SELECT %(bid)s::text AS barrier_id,
           COUNT(DISTINCT evidence_id) AS evidence_count,
           COUNT(DISTINCT source_ref) AS source_count
    FROM ev
), dins AS (
    SELECT barrier_id, COUNT(*) AS n FROM insight_barriers
    WHERE barrier_id = %(bid)s GROUP BY barrier_id
), btm AS (
    SELECT {BARRIER_TYPE_META_SELECT} FROM barrier_type_meta
    WHERE barrier_type IN (SELECT barrier_type FROM b)
), sbm AS (
    SELECT signal_type, barrier_type, support_tier FROM signal_barrier_map
    WHERE barrier_type IN (SELECT barrier_type FROM b)
      AND signal_type IN (SELECT signal_type FROM sig)
)
SELECT
  (SELECT coalesce(json_agg(t), '[]'::json) FROM b t) AS barrier,
  (SELECT coalesce(json_agg(t ORDER BY t.support_tier ASC NULLS LAST,
                            t.mention_count DESC, t.signal_id), '[]'::json)
     FROM sig t) AS signals,
  (SELECT coalesce(json_agg(t ORDER BY t.signal_id, t.evidence_id), '[]'::json)
     FROM ev t) AS evidence,
  (SELECT coalesce(json_agg(t ORDER BY t.note_id), '[]'::json)
     FROM nt t) AS notes,
  (SELECT coalesce(json_agg(t ORDER BY t.signal_id, t.correlation_id), '[]'::json)
     FROM corr t) AS correlations,
  (SELECT coalesce(json_agg(t ORDER BY t.signal_type), '[]'::json)
     FROM stm t) AS signal_type_meta,
  (SELECT coalesce(json_agg(t ORDER BY t.insight_id), '[]'::json)
     FROM ins t) AS insights,
  (SELECT coalesce(json_agg(t ORDER BY t.insight_id, t.signal_id), '[]'::json)
     FROM isl t) AS insight_signal_links,
  (SELECT coalesce(json_agg(t ORDER BY t.n DESC, t.signal_type), '[]'::json)
     FROM dtype t) AS type_rows,
  (SELECT coalesce(json_agg(t), '[]'::json) FROM dev t) AS evidence_rows,
  (SELECT coalesce(json_agg(t), '[]'::json) FROM dins t) AS insight_rows,
  (SELECT coalesce(json_agg(t ORDER BY t.barrier_type), '[]'::json)
     FROM btm t) AS barrier_type_meta,
  (SELECT coalesce(json_agg(t ORDER BY t.support_tier, t.signal_type), '[]'::json)
     FROM sbm t) AS mapping
"""

#: what `_fetch_closure` returns, and therefore what the one statement must
#: name. Pinned by the test, so a set added to one and not the other fails.
CLOSURE_KEYS: tuple[str, ...] = (
    "barrier", "signals", "evidence", "notes", "correlations",
    "signal_type_meta", "insights", "insight_signal_links",
    "type_rows", "evidence_rows", "insight_rows",
    "barrier_type_meta", "mapping")


def _fetch_closure(cur, barrier_id: str) -> dict:
    """Every row the trace and the graph need — ONE statement, 404 included.

    The three ``*_rows`` derivations (what ``/trace`` used to fetch with
    ``_fetch_derivations``) and the two graph meta sets ride along, because
    inside one statement they are free: both endpoints are now a single
    round trip. ``_fetch_derivations`` stays for the register endpoints,
    which ask the same questions of EVERY barrier.
    """
    cur.execute(CLOSURE_SQL, {"bid": barrier_id, "excerpt": TRANSCRIPT_EXCERPT})
    row = cur.fetchone()
    # EVERY list, not the ones that look like they carry a person. These rows
    # arrive from `json_agg` inside one statement, so none of them passes
    # through `_rows`, and picking the right keys by hand is a decision that
    # goes stale the moment a SELECT list grows a column. `mask_scope` is a
    # no-op on a row without `scope_kind == 'hcp'`, so applying it everywhere
    # costs nothing and cannot miss the next one.
    out = {k: [mask_scope(dict(r)) for r in ((row[k] if row else None) or [])]
           for k in CLOSURE_KEYS}
    if not out["barrier"]:
        raise HTTPException(status_code=404, detail=f"barrier '{barrier_id}' not found")
    out["barrier"] = out["barrier"][0]
    return out


def _signal_order(s: dict):
    return (s.get("support_tier") if s.get("support_tier") is not None else 99,
            -_int(s.get("mention_count")), s["signal_id"])


def trace_census(signals: list[dict], evidence: list[dict], notes: list[dict]) -> dict:
    """Pure: mirrors ``trace_barrier()`` in the pack's graph projection.

    MENTIONS count source rows; DISTINCT statements count genuinely different
    ones — their gap (``restated``) is repetition, never corroboration, and
    reading it as corroboration is the defect the signal rebuild removed.
    """
    sig_ids = {s["signal_id"] for s in signals}
    ev = [e for e in evidence if e["signal_id"] in sig_ids]
    src_ids = {e["source_ref"] for e in ev if e.get("source_ref")}
    by_note = {n["note_id"]: n for n in notes if n["note_id"] in src_ids}
    stances = Counter((s.get("stance") or "supporting") for s in signals)
    mentions = sum(_int(s.get("mention_count")) for s in signals)
    distinct = sum(_int(s.get("distinct_evidence_count")) for s in signals)
    return {
        "signals": len(signals),
        "supporting": stances.get("supporting", 0),
        "conflicting": stances.get("conflicting", 0),
        "evidence": len(ev),
        "sources": len(src_ids),
        "accounts": len({n.get("account_name") for n in by_note.values()
                         if n.get("account_name")}),
        "hcps": len({n.get("hcp_id") for n in by_note.values() if n.get("hcp_id")}),
        "mentions": mentions,
        "distinct_statements": distinct,
        "restated": max(0, mentions - distinct),
        "by_type": dict(Counter(s["signal_type"] for s in signals)),
        "by_method": dict(Counter(s.get("detection_method") or "unknown" for s in signals)),
        "by_persona": dict(Counter(n.get("call_recorded_persona_role") or "unknown"
                                   for n in by_note.values())),
    }


def assemble_trace(barrier: dict, signals: list[dict], evidence: list[dict],
                   notes: list[dict], correlations: list[dict],
                   insights: list[dict], insight_signal_links: list[dict],
                   signal_type_meta: list[dict], *,
                   type_rows: list[dict] = (), evidence_rows: list[dict] = (),
                   insight_rows: list[dict] = (),
                   signal_cap: int = SIGNALS_PER_BARRIER,
                   evidence_cap: int = EVIDENCE_PER_SIGNAL) -> dict:
    """Pure: closure rows → BarrierTrace. The census covers EVERY linked
    signal; the signal list and the per-signal evidence are capped."""
    polarity = {m["signal_type"]: m.get("polarity") for m in signal_type_meta}
    masked_notes = {n["note_id"]: mask_note(n) for n in notes}
    ev_by_sig: dict[str, list[dict]] = defaultdict(list)
    for e in sorted(evidence, key=lambda e: (e["signal_id"], _int(e.get("evidence_id")))):
        ev_by_sig[e["signal_id"]].append(e)
    corr_by_sig: dict[str, list[dict]] = defaultdict(list)
    for c in correlations:
        corr_by_sig[c["signal_id"]].append(c)
    ins_by_sig: dict[str, list[str]] = defaultdict(list)
    for l in insight_signal_links:
        if l["insight_id"] not in ins_by_sig[l["signal_id"]]:
            ins_by_sig[l["signal_id"]].append(l["insight_id"])

    ordered = sorted(signals, key=_signal_order)
    shown = []
    for s in ordered[:signal_cap]:
        sig = mask_signal(s)
        sig["polarity"] = polarity.get(s["signal_type"])
        sig["stance"] = s.get("stance") or "supporting"
        sig["support_tier"] = _int(s.get("support_tier")) or None
        evs = []
        for e in ev_by_sig.get(s["signal_id"], [])[:evidence_cap]:
            item = _json_safe(dict(e))
            if e.get("source_table") == "call_notes":
                item["source_kind"] = "note"
                item["source"] = masked_notes.get(e.get("source_ref")) or {
                    "note_id": e.get("source_ref")}
            else:
                item["source_kind"] = "record"
                item["source"] = {"source_table": e.get("source_table"),
                                  "record_ref": e.get("source_ref")}
            evs.append(item)
        sig["evidence"] = evs
        sig["correlations"] = [
            _json_safe({k: v for k, v in c.items() if k != "signal_id"})
            for c in corr_by_sig.get(s["signal_id"], [])]
        sig["insight_ids"] = ins_by_sig.get(s["signal_id"], [])
        shown.append(sig)

    return {
        "barrier": barrier_detail(barrier, list(type_rows), list(evidence_rows),
                                  list(insight_rows), insights),
        "signals": shown,
        "signal_count_total": len(signals),
        "signals_shown": len(shown),
        "census": trace_census(signals, evidence, notes),
    }


@router.get("/barriers/{barrier_id}/trace")
def barrier_trace(barrier_id: str):
    """Full provenance drill tree: barrier ▸ signals ▸ evidence ▸ call note.
    ONE statement — the derivations ride the closure."""
    with _hub() as cur:
        c = _fetch_closure(cur, barrier_id)
    return assemble_trace(c["barrier"], c["signals"], c["evidence"], c["notes"],
                          c["correlations"], c["insights"], c["insight_signal_links"],
                          c["signal_type_meta"], type_rows=c["type_rows"],
                          evidence_rows=c["evidence_rows"], insight_rows=c["insight_rows"])


# ── graph projection (iof-graph/v1) ──────────────────────────────────────

class Graph:
    """Nodes and edges, deterministic in insertion order; a node is enriched,
    never overwritten, and an edge is one per (type, from, to)."""

    def __init__(self) -> None:
        self.nodes: dict[tuple[str, str], dict] = {}
        self.edges: list[dict] = []
        self._edge_keys: set[tuple] = set()

    def node(self, label: str, key: Any, **props) -> str:
        if key is None or key == "":
            return ""
        k = (label, str(key))
        clean = {p: _trim(v) for p, v in props.items() if v is not None}
        if k not in self.nodes:
            self.nodes[k] = {"label": label, "id": str(key), **clean}
        else:
            for p, v in clean.items():
                self.nodes[k].setdefault(p, v)
        return str(key)

    def edge(self, etype: str, src_label: str, src: Any, dst_label: str, dst: Any,
             **props) -> None:
        if src in (None, "") or dst in (None, ""):
            return
        k = (etype, src_label, str(src), dst_label, str(dst))
        if k in self._edge_keys:
            return
        self._edge_keys.add(k)
        self.edges.append({"type": etype,
                           "from": {"label": src_label, "id": str(src)},
                           "to": {"label": dst_label, "id": str(dst)},
                           **{p: _json_safe(v) for p, v in props.items() if v is not None}})

    def has(self, label: str, key: Any) -> bool:
        return (label, str(key)) in self.nodes

    def census(self) -> dict:
        return {"nodes": dict(Counter(l for l, _ in self.nodes)),
                "edges": dict(Counter(e["type"] for e in self.edges)),
                "total_nodes": len(self.nodes), "total_edges": len(self.edges)}

    def payload(self, root: dict) -> dict:
        return {"format": GRAPH_FORMAT, "root": root,
                "nodes": list(self.nodes.values()), "edges": list(self.edges),
                "census": self.census()}

    def expansion(self, node: dict) -> dict:
        return {"node": node, "nodes": list(self.nodes.values()),
                "edges": list(self.edges)}


def emit_barrier(g: Graph, b: dict, *, with_type: bool = True,
                 with_scope: bool = True) -> str:
    bid = g.node(N_BARRIER, b["barrier_id"], barrier_type=b.get("barrier_type"),
                 category=b.get("barrier_category"), statement=b.get("statement"),
                 status=b.get("status"), severity=b.get("severity"),
                 confidence=b.get("confidence"), priority=b.get("priority"),
                 supporting_count=b.get("supporting_count"),
                 conflicting_count=b.get("conflicting_count"),
                 scope_kind=b.get("scope_kind"), scope_value=b.get("scope_value"),
                 kb_support_tier=b.get("kb_support_tier"))
    if with_type and b.get("barrier_type"):
        g.node(N_BARRIER_TYPE, b["barrier_type"], category=b.get("barrier_category"))
        g.edge(E_OF_TYPE, N_BARRIER, bid, N_BARRIER_TYPE, b["barrier_type"])
    if with_scope:
        sv = b.get("scope_value")
        if b.get("scope_kind") == "account" and sv:
            g.node(N_ACCOUNT, sv, name=sv)
            g.edge(E_SCOPED_TO, N_BARRIER, bid, N_ACCOUNT, sv)
        elif b.get("scope_kind") == "hcp" and sv:
            g.node(N_HCP, sv)
            g.edge(E_SCOPED_TO, N_BARRIER, bid, N_HCP, sv)
    return bid


def emit_signal(g: Graph, s: dict, polarity: str | None = None, *,
                with_type: bool = True) -> str:
    sid = g.node(N_SIGNAL, s["signal_id"], signal_type=s.get("signal_type"),
                 signal_category=s.get("signal_category"), statement=s.get("statement"),
                 method=s.get("detection_method"), rule_name=s.get("rule_name"),
                 scope_kind=s.get("scope_kind"), scope_value=s.get("scope_value"),
                 mention_count=s.get("mention_count"),
                 distinct_evidence_count=s.get("distinct_evidence_count"),
                 source_count=s.get("source_count"), polarity=polarity,
                 status=s.get("status"))
    if with_type and s.get("signal_type"):
        g.node(N_SIGNAL_TYPE, s["signal_type"], signal_category=s.get("signal_category"))
        g.edge(E_TYPED_AS, N_SIGNAL, sid, N_SIGNAL_TYPE, s["signal_type"])
    return sid


def emit_signal_type(g: Graph, m: dict) -> str:
    return g.node(N_SIGNAL_TYPE, m["signal_type"], signal_category=m.get("signal_category"),
                  polarity=m.get("polarity"), signal_group=m.get("signal_group"))


def emit_barrier_type(g: Graph, m: dict) -> str:
    return g.node(N_BARRIER_TYPE, m["barrier_type"], category=m.get("category"),
                  definition=m.get("definition"))


def emit_note(g: Graph, n: dict) -> str:
    """A call note as a Source plus the dimension nodes it carries
    (Account by name, HCP by hcp_id, Persona by role) — names masked."""
    hcp_masked = _mask_person(n.get("hcp_name"), honorific="Dr. ")
    nid = g.node(N_SOURCE, n["note_id"], kind="call note", call_id=n.get("call_id"),
                 date=n.get("call_recorded_timestamp"),
                 persona_role=n.get("call_recorded_persona_role"),
                 territory=n.get("territory"), region=n.get("region"),
                 brand=n.get("brand_product"), account_name=n.get("account_name"),
                 hcp=hcp_masked)
    acc = g.node(N_ACCOUNT, n.get("account_name"), name=n.get("account_name"))
    hcp = g.node(N_HCP, n.get("hcp_id"), name=hcp_masked, specialty=n.get("hcp_specialty"))
    role = n.get("call_recorded_persona_role")
    per = g.node(N_PERSONA, role, description=role)
    g.edge(E_AT_ACCOUNT, N_SOURCE, nid, N_ACCOUNT, acc)
    g.edge(E_ABOUT_HCP, N_SOURCE, nid, N_HCP, hcp)
    g.edge(E_REPORTED_BY, N_SOURCE, nid, N_PERSONA, per)
    g.edge(E_PRACTICES_AT, N_HCP, hcp, N_ACCOUNT, acc)
    return nid


def emit_evidence(g: Graph, e: dict, method: str | None = None) -> str:
    """Evidence node + HAS_EVIDENCE + QUOTES, and the collapsed DETECTED_FROM
    pointer (one per (signal, source) — the Graph dedupes it)."""
    eid = g.node(N_EVIDENCE, e["evidence_id"], snippet=e.get("snippet"),
                 matched_phrase=e.get("matched_phrase"), speaker=e.get("speaker"),
                 turn_index=e.get("turn_index"), source_column=e.get("source_column"))
    ref = e.get("source_ref")
    if ref:
        g.node(N_SOURCE, ref, kind="call note")   # enriched if the note was read
    g.edge(E_HAS_EVIDENCE, N_SIGNAL, e["signal_id"], N_EVIDENCE, eid)
    g.edge(E_QUOTES, N_EVIDENCE, eid, N_SOURCE, ref, source_column=e.get("source_column"))
    g.edge(E_DETECTED_FROM, N_SIGNAL, e["signal_id"], N_SOURCE, ref, method=method)
    return eid


def emit_insight(g: Graph, i: dict) -> str:
    return g.node(N_INSIGHT, i["insight_id"], title=i.get("title"),
                  insight_type=i.get("insight_type"), scope_kind=i.get("scope_kind"),
                  scope_value=i.get("scope_value"))


def emit_correlation(g: Graph, c: dict) -> str:
    return g.node(N_CORRELATION, c["correlation_id"], signal_type=c.get("signal_type"),
                  scope_value=c.get("scope_value"), signal_count=c.get("signal_count"),
                  source_count=c.get("source_count"), has_conflict=c.get("has_conflict"))


def assemble_graph(barrier: dict, signals: list[dict], evidence: list[dict],
                   notes: list[dict], correlations: list[dict], insights: list[dict],
                   insight_signal_links: list[dict], signal_type_meta: list[dict],
                   barrier_type_meta: list[dict] = (), mapping: list[dict] = ()) -> dict:
    """Pure: the closure rows → GraphPayload rooted at the barrier.

    An insufficient-evidence barrier has no signals, so its graph is the root,
    its type and its scope — exactly what the hub says about it, no more.
    """
    g = Graph()
    bid = emit_barrier(g, barrier)
    for m in barrier_type_meta:
        emit_barrier_type(g, m)
    polarity = {m["signal_type"]: m.get("polarity") for m in signal_type_meta}
    methods: dict[str, str | None] = {}
    for s in sorted(signals, key=_signal_order):
        sid = emit_signal(g, s, polarity.get(s["signal_type"]))
        g.edge(E_SUPPORTS, N_SIGNAL, sid, N_BARRIER, bid, stance=s.get("stance"),
               support_tier=s.get("support_tier"))
        methods[sid] = s.get("detection_method")
    for m in signal_type_meta:
        emit_signal_type(g, m)
    for n in notes:
        emit_note(g, n)
    for e in evidence:
        emit_evidence(g, e, method=methods.get(e["signal_id"]))
    for c in correlations:
        cid = emit_correlation(g, c)
        g.edge(E_CORRELATES, N_SIGNAL, c["signal_id"], N_CORRELATION, cid, stance=c.get("stance"))
    for i in insights:
        iid = emit_insight(g, i)
        g.edge(E_CONCERNS, N_INSIGHT, iid, N_BARRIER, bid, relation=i.get("relation"))
    for l in insight_signal_links:
        if g.has(N_SIGNAL, l["signal_id"]) and g.has(N_INSIGHT, l["insight_id"]):
            g.edge(E_EVIDENCES, N_SIGNAL, l["signal_id"], N_INSIGHT, l["insight_id"])
    for m in mapping:
        if g.has(N_SIGNAL_TYPE, m["signal_type"]):
            g.node(N_BARRIER_TYPE, m["barrier_type"])
            g.edge(E_MAPS_TO, N_SIGNAL_TYPE, m["signal_type"], N_BARRIER_TYPE,
                   m["barrier_type"], support_tier=m.get("support_tier"))
    return g.payload({"label": N_BARRIER, "id": bid})


@router.get("/barriers/{barrier_id}/graph")
def barrier_graph(barrier_id: str):
    """ONE statement — the barrier-type meta and the KB mapping ride the
    closure, scoped to this barrier's type and its own signal types."""
    with _hub() as cur:
        c = _fetch_closure(cur, barrier_id)
    return assemble_graph(c["barrier"], c["signals"], c["evidence"], c["notes"],
                          c["correlations"], c["insights"], c["insight_signal_links"],
                          c["signal_type_meta"], c["barrier_type_meta"], c["mapping"])


# ── expand: any node's neighbourhood ─────────────────────────────────────

def validate_label(label: str) -> str:
    if label not in GRAPH_LABELS:
        raise HTTPException(status_code=400,
                            detail=f"unknown label '{label}' "
                                   f"(one of: {', '.join(GRAPH_LABELS)})")
    return label


def _not_found(label: str, node_id: str):
    return HTTPException(status_code=404, detail=f"{label} '{node_id}' not found")


def _notes_where(cur, where: str, params: tuple, limit: int | None = EXPAND_CAP) -> list[dict]:
    lim = " LIMIT %s" if limit else ""
    cur.execute(f"SELECT {NOTE_SELECT} FROM call_notes WHERE {where} ORDER BY note_id{lim}",
                params + ((limit,) if limit else ()))
    return _rows(cur)


def _signals_by_ids(cur, sig_ids: list[str]) -> list[dict]:
    if not sig_ids:
        return []
    cur.execute(f"SELECT {SIGNAL_SELECT} FROM signals s WHERE s.signal_id = ANY(%s) "
                "ORDER BY s.signal_id", (sig_ids,))
    return _rows(cur)


def _polarity_for(cur, signals: list[dict]) -> dict[str, str | None]:
    types = sorted({s["signal_type"] for s in signals if s.get("signal_type")})
    if not types:
        return {}
    cur.execute(f"SELECT {SIGNAL_TYPE_META_SELECT} FROM signal_type_meta "
                "WHERE signal_type = ANY(%s)", (types,))
    return {r["signal_type"]: r.get("polarity") for r in cur.fetchall()}


def _emit_signal_evidence(g: Graph, cur, signal: dict) -> None:
    """A signal's evidence, its sources (masked notes), correlations, insights."""
    sid = signal["signal_id"]
    cur.execute(f"SELECT {EVIDENCE_SELECT} FROM signal_evidence WHERE signal_id = %s "
                "ORDER BY evidence_id", (sid,))
    evidence = _rows(cur)
    refs = sorted({e["source_ref"] for e in evidence
                   if e.get("source_table") == "call_notes" and e.get("source_ref")})
    if refs:
        for n in _notes_where(cur, "note_id = ANY(%s)", (refs,), limit=None):
            emit_note(g, n)
    for e in evidence:
        emit_evidence(g, e, method=signal.get("detection_method"))
    cur.execute(f"SELECT cs.stance, {CORRELATION_SELECT} FROM correlation_signals cs "
                "JOIN signal_correlations c ON c.correlation_id = cs.correlation_id "
                "WHERE cs.signal_id = %s ORDER BY c.correlation_id", (sid,))
    for c in _rows(cur):
        g.edge(E_CORRELATES, N_SIGNAL, sid, N_CORRELATION, emit_correlation(g, c),
               stance=c.get("stance"))
    cur.execute(f"SELECT {INSIGHT_SELECT} FROM insights WHERE insight_id IN "
                "(SELECT insight_id FROM insight_signals WHERE signal_id = %s) "
                "ORDER BY insight_id", (sid,))
    for i in _rows(cur):
        g.edge(E_EVIDENCES, N_SIGNAL, sid, N_INSIGHT, emit_insight(g, i))


def _expand(cur, label: str, node_id: str) -> Graph:
    g = Graph()
    if label == N_ACCOUNT:
        notes = _notes_where(cur, "account_name = %s", (node_id,))
        # Both grains: the account's own barriers, and the prescriber barriers
        # whose parent is this account. Expanding a site and seeing only the
        # institutional claims hid most of what was judged there.
        cur.execute(f"SELECT {BARRIER_SELECT} FROM barriers "
                    "WHERE (scope_kind = 'account' AND scope_value = %s) "
                    "   OR (scope_kind = 'hcp' AND scope_parent = %s) "
                    "ORDER BY priority DESC NULLS LAST, barrier_id",
                    (node_id, node_id))
        barriers = _rows(cur)
        if not notes and not barriers:
            raise _not_found(label, node_id)
        g.node(N_ACCOUNT, node_id, name=node_id)
        for n in notes:
            emit_note(g, n)
        for b in barriers:
            emit_barrier(g, b, with_type=False)
    elif label == N_HCP:
        notes = _notes_where(cur, "hcp_id = %s", (node_id,))
        cur.execute(f"SELECT {BARRIER_SELECT} FROM barriers WHERE scope_kind = 'hcp' "
                    "AND scope_value = %s ORDER BY priority DESC NULLS LAST, barrier_id",
                    (node_id,))
        barriers = _rows(cur)
        if not notes and not barriers:
            raise _not_found(label, node_id)
        g.node(N_HCP, node_id)
        for n in notes:
            emit_note(g, n)
        for b in barriers:
            emit_barrier(g, b, with_type=False)
    elif label == N_PERSONA:
        notes = _notes_where(cur, "call_recorded_persona_role = %s", (node_id,))
        if not notes:
            raise _not_found(label, node_id)
        g.node(N_PERSONA, node_id, description=node_id)
        for n in notes:
            emit_note(g, n)
    elif label == N_SOURCE:
        notes = _notes_where(cur, "note_id = %s", (node_id,), limit=None)
        if not notes:
            raise _not_found(label, node_id)
        emit_note(g, notes[0])
        cur.execute(f"SELECT {EVIDENCE_SELECT} FROM signal_evidence "
                    "WHERE source_table = 'call_notes' AND source_ref = %s "
                    "ORDER BY signal_id, evidence_id", (node_id,))
        evidence = _rows(cur)
        signals = _signals_by_ids(cur, sorted({e["signal_id"] for e in evidence}))
        methods = {}
        for s in signals:
            emit_signal(g, s, with_type=False)
            methods[s["signal_id"]] = s.get("detection_method")
        for e in evidence:
            emit_evidence(g, e, method=methods.get(e["signal_id"]))
    elif label == N_SIGNAL:
        signals = _signals_by_ids(cur, [node_id])
        if not signals:
            raise _not_found(label, node_id)
        s = signals[0]
        pol = _polarity_for(cur, signals)
        emit_signal(g, s, pol.get(s["signal_type"]))
        cur.execute(f"SELECT {BARRIER_SELECT}, bs.stance, bs.support_tier FROM barrier_signals bs "
                    "JOIN barriers USING (barrier_id) WHERE bs.signal_id = %s "
                    "ORDER BY barrier_id", (node_id,))
        for b in _rows(cur):
            g.edge(E_SUPPORTS, N_SIGNAL, node_id, N_BARRIER,
                   emit_barrier(g, b, with_type=False, with_scope=False),
                   stance=b.get("stance"), support_tier=b.get("support_tier"))
        _emit_signal_evidence(g, cur, s)
    elif label == N_EVIDENCE:
        try:
            eid = int(node_id)
        except ValueError:
            raise _not_found(label, node_id)
        cur.execute(f"SELECT {EVIDENCE_SELECT} FROM signal_evidence WHERE evidence_id = %s",
                    (eid,))
        rows = _rows(cur)
        if not rows:
            raise _not_found(label, node_id)
        e = rows[0]
        signals = _signals_by_ids(cur, [e["signal_id"]])
        for s in signals:
            emit_signal(g, s, with_type=False)
        if e.get("source_table") == "call_notes" and e.get("source_ref"):
            for n in _notes_where(cur, "note_id = %s", (e["source_ref"],), limit=None):
                emit_note(g, n)
        emit_evidence(g, e, method=signals[0].get("detection_method") if signals else None)
    elif label == N_SIGNAL_TYPE:
        cur.execute(f"SELECT {SIGNAL_TYPE_META_SELECT} FROM signal_type_meta "
                    "WHERE signal_type = %s", (node_id,))
        meta = _rows(cur)
        if not meta:
            raise _not_found(label, node_id)
        emit_signal_type(g, meta[0])
        cur.execute("SELECT m.barrier_type, m.support_tier, bt.category, bt.definition "
                    "FROM signal_barrier_map m "
                    "LEFT JOIN barrier_type_meta bt ON bt.barrier_type = m.barrier_type "
                    "WHERE m.signal_type = %s ORDER BY m.support_tier, m.barrier_type",
                    (node_id,))
        for m in _rows(cur):
            g.edge(E_MAPS_TO, N_SIGNAL_TYPE, node_id, N_BARRIER_TYPE, emit_barrier_type(g, m),
                   support_tier=m.get("support_tier"))
        cur.execute(f"SELECT {SIGNAL_SELECT} FROM signals s WHERE s.signal_type = %s "
                    "ORDER BY s.mention_count DESC, s.signal_id LIMIT %s", (node_id, EXPAND_CAP))
        for s in _rows(cur):
            emit_signal(g, s, meta[0].get("polarity"))
    elif label == N_BARRIER_TYPE:
        cur.execute(f"SELECT {BARRIER_TYPE_META_SELECT} FROM barrier_type_meta "
                    "WHERE barrier_type = %s", (node_id,))
        meta = _rows(cur)
        if not meta:
            raise _not_found(label, node_id)
        emit_barrier_type(g, meta[0])
        cur.execute("SELECT m.signal_type, m.support_tier, st.signal_category, "
                    "st.signal_group, st.directional, st.polarity "
                    "FROM signal_barrier_map m "
                    "LEFT JOIN signal_type_meta st ON st.signal_type = m.signal_type "
                    "WHERE m.barrier_type = %s ORDER BY m.support_tier, m.signal_type",
                    (node_id,))
        for m in _rows(cur):
            g.edge(E_MAPS_TO, N_SIGNAL_TYPE, emit_signal_type(g, m), N_BARRIER_TYPE, node_id,
                   support_tier=m.get("support_tier"))
        cur.execute(f"SELECT {BARRIER_SELECT} FROM barriers WHERE barrier_type = %s "
                    "ORDER BY priority DESC NULLS LAST, barrier_id LIMIT %s",
                    (node_id, EXPAND_CAP))
        for b in _rows(cur):
            emit_barrier(g, b, with_scope=False)
    elif label == N_INSIGHT:
        cur.execute(f"SELECT {INSIGHT_SELECT} FROM insights WHERE insight_id = %s", (node_id,))
        rows = _rows(cur)
        if not rows:
            raise _not_found(label, node_id)
        emit_insight(g, rows[0])
        cur.execute(f"SELECT ib.relation, {BARRIER_SELECT} FROM insight_barriers ib "
                    "JOIN barriers USING (barrier_id) WHERE ib.insight_id = %s "
                    "ORDER BY barrier_id", (node_id,))
        for b in _rows(cur):
            g.edge(E_CONCERNS, N_INSIGHT, node_id, N_BARRIER,
                   emit_barrier(g, b, with_type=False, with_scope=False),
                   relation=b.get("relation"))
        cur.execute(f"SELECT {SIGNAL_SELECT} FROM insight_signals isg "
                    "JOIN signals s ON s.signal_id = isg.signal_id "
                    "WHERE isg.insight_id = %s ORDER BY s.signal_id LIMIT %s",
                    (node_id, EXPAND_CAP))
        for s in _rows(cur):
            g.edge(E_EVIDENCES, N_SIGNAL, emit_signal(g, s, with_type=False), N_INSIGHT, node_id)
    elif label == N_CORRELATION:
        cur.execute(f"SELECT {CORRELATION_SELECT} FROM signal_correlations c "
                    "WHERE c.correlation_id = %s", (node_id,))
        rows = _rows(cur)
        if not rows:
            raise _not_found(label, node_id)
        emit_correlation(g, rows[0])
        cur.execute(f"SELECT cs.stance, {SIGNAL_SELECT} FROM correlation_signals cs "
                    "JOIN signals s ON s.signal_id = cs.signal_id "
                    "WHERE cs.correlation_id = %s ORDER BY s.signal_id", (node_id,))
        for s in _rows(cur):
            g.edge(E_CORRELATES, N_SIGNAL, emit_signal(g, s, with_type=False),
                   N_CORRELATION, node_id, stance=s.get("stance"))
    elif label == N_BARRIER:
        barrier = _fetch_barrier_or_404(cur, node_id)
        bid = emit_barrier(g, barrier)
        cur.execute(f"SELECT {SIGNAL_SELECT}, bs.stance, bs.support_tier "
                    "FROM barrier_signals bs JOIN signals s ON s.signal_id = bs.signal_id "
                    "WHERE bs.barrier_id = %s ORDER BY bs.support_tier ASC NULLS LAST, "
                    "s.mention_count DESC, s.signal_id", (node_id,))
        signals = _rows(cur)
        pol = _polarity_for(cur, signals)
        for s in signals:
            g.edge(E_SUPPORTS, N_SIGNAL, emit_signal(g, s, pol.get(s["signal_type"]), with_type=False),
                   N_BARRIER, bid, stance=s.get("stance"), support_tier=s.get("support_tier"))
        for i in _fetch_barrier_insights(cur, node_id):
            g.edge(E_CONCERNS, N_INSIGHT, emit_insight(g, i), N_BARRIER, bid,
                   relation=i.get("relation"))
    else:  # Organization — a proposed entity-resolution layer the API does not project
        raise _not_found(label, node_id)
    return g


@router.get("/graph/expand")
def graph_expand(label: str = "", id: str = ""):
    """The neighbourhood of ANY node, both directions — the sideways walk out
    of one barrier's subgraph (other barriers at an account, other signals in
    a note, every barrier of a type)."""
    label = validate_label(label.strip())
    node_id = id.strip()
    if not node_id:
        raise HTTPException(status_code=400, detail="id is required")
    with _hub() as cur:
        g = _expand(cur, label, node_id)
    return g.expansion({"label": label, "id": node_id})


# ── insights ─────────────────────────────────────────────────────────────

def merge_insights(insights: list[dict], barrier_links: list[dict],
                   signal_counts: list[dict]) -> list[dict]:
    """Pure: insight rows ⊕ (insight_id, barrier_id) ⊕ (insight_id, n) → HubInsight."""
    bids: dict[str, list[str]] = defaultdict(list)
    for l in barrier_links:
        if l["barrier_id"] not in bids[l["insight_id"]]:
            bids[l["insight_id"]].append(l["barrier_id"])
    counts = {r["insight_id"]: _int(r["n"]) for r in signal_counts}
    out = []
    for i in insights:
        row = _json_safe(dict(i))
        row["barrier_ids"] = list(bids.get(i["insight_id"], []))
        row["signal_count"] = counts.get(i["insight_id"], 0)
        out.append(row)
    return out


@router.get("/insights")
def list_insights():
    with _hub() as cur:
        cur.execute(f"SELECT {INSIGHT_SELECT} FROM insights ORDER BY insight_id")
        insights = _rows(cur)
        cur.execute("SELECT insight_id, barrier_id FROM insight_barriers ORDER BY 1, 2")
        links = _rows(cur)
        cur.execute("SELECT insight_id, COUNT(*) AS n FROM insight_signals GROUP BY 1")
        counts = _rows(cur)
    rows = merge_insights(insights, links, counts)
    return {"count": len(rows), "insights": rows}


@router.get("/insights/{insight_id}")
def get_insight(insight_id: str):
    with _hub() as cur:
        cur.execute(f"SELECT {INSIGHT_SELECT} FROM insights WHERE insight_id = %s", (insight_id,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"insight '{insight_id}' not found")
        cur.execute("SELECT b.barrier_id, b.barrier_type, b.statement, b.severity, b.status, "
                    "ib.relation FROM insight_barriers ib "
                    "JOIN barriers b ON b.barrier_id = ib.barrier_id "
                    "WHERE ib.insight_id = %s ORDER BY b.barrier_id", (insight_id,))
        barriers = _rows(cur)
        cur.execute("SELECT s.signal_id, s.signal_type, s.statement, s.scope_value, "
                    "s.account_name FROM insight_signals isg "
                    "JOIN signals s ON s.signal_id = isg.signal_id "
                    "WHERE isg.insight_id = %s ORDER BY s.signal_id", (insight_id,))
        signals = _rows(cur)
    out = merge_insights([dict(row)], [{"insight_id": insight_id, "barrier_id": b["barrier_id"]}
                                       for b in barriers],
                         [{"insight_id": insight_id, "n": len(signals)}])[0]
    out["barriers"] = [_json_safe(b) for b in barriers]
    out["signals"] = [_json_safe(s) for s in signals]
    return out


# ── insight ↔ barrier mapping ────────────────────────────────────────────

@router.get("/mapping")
def insight_barrier_mapping():
    """Every insight_barriers link with the number of signals the pair
    shares. LEFT JOINs so a pair sharing none still appears with 0."""
    with _hub() as cur:
        cur.execute(
            "SELECT ib.insight_id, ib.barrier_id, ib.relation, "
            "       COUNT(bs.signal_id) AS shared_signals "
            "FROM insight_barriers ib "
            "LEFT JOIN insight_signals isg ON isg.insight_id = ib.insight_id "
            "LEFT JOIN barrier_signals bs ON bs.barrier_id = ib.barrier_id "
            "   AND bs.signal_id = isg.signal_id "
            "GROUP BY ib.insight_id, ib.barrier_id, ib.relation "
            "ORDER BY ib.insight_id, ib.barrier_id")
        links = [_json_safe(r) for r in _rows(cur)]
    return {"count": len(links), "links": links}
