# Setup — standing the solution up in an environment

Two paths:

- **[Part A — Upgrading an environment that already ran an earlier build](#part-a--upgrading-an-existing-environment)** ← start here if you have already installed and seeded once
- **[Part B — Fresh install](#part-b--fresh-install)** — a machine with nothing on it yet

Day-to-day operation is in [solutions/pharma/RUNBOOK.md](solutions/pharma/RUNBOOK.md);
the full configuration contract is in
[solutions/pharma/DEPLOYMENT.md](solutions/pharma/DEPLOYMENT.md).

> **Shell note:** examples use Windows paths (`.venv\Scripts\…`). On Linux/macOS
> use `.venv/bin/…`. A trailing `\` does NOT continue a command in CMD — put it
> on one line, or use a backtick (`` ` ``) in PowerShell.

## What this environment contains

```
agentfarm-core        the framework: engine, CLI, web API
                      + three shared agents — Jarvis, Quinn, Alex
agentfarm-skills      shared craft skills (data_query, presentation, dataviz, …)
solutions/pharma      barrier_insights — the Signal-to-Action domain pack
solutions/ainf        ainf — the commercial-intelligence domain pack
apps/agentfarm-api    studio backend      apps/agentfarm-ui    studio front end
```

Two domain packs, one framework. Nothing else ships.

---

# Part A — Upgrading an existing environment

Use this if you installed and ran a seed round on an earlier build. The
framework has since been stripped to three agents, ten legacy agents and their
workflows were removed, the AINF distribution was renamed, and pack names
changed — so a plain `git pull` leaves stale packages and agent folders behind.

### A1. Get the code

```powershell
cd C:\path\to\repo
git pull
```

### A2. Remove packages that no longer exist

Editable installs leave entry points registered even after their source is
deleted, so the framework keeps discovering ghosts until you uninstall them.
**`agentfarm-pharma` is the old name of the AINF distribution** — it must go or
you will have two AINF packs registered.

```powershell
.venv\Scripts\pip uninstall -y agentfarm-pharma agentfarm-procurement agentfarm-ai-workspace agentfarm-template
```

(Some may report "not installed" — that is fine, uninstall is idempotent.)

### A3. Reinstall the current set

```powershell
.venv\Scripts\pip install -e agentfarm-core -e agentfarm-skills
.venv\Scripts\pip install -e solutions\ainf
.venv\Scripts\pip install -e solutions\pharma\barrier_signal -e solutions\pharma\signal_ingestion -e solutions\pharma\pharma_common -e solutions\pharma\signal_brief
.venv\Scripts\pip install -e apps\agentfarm-api
```

Verify only the expected packs resolve:

```powershell
.venv\Scripts\python -c "from ioagentfarm.packs import load_registry; print([p.name for p in load_registry().packs])"
```

Expect `core`, `ainf`, `barrier_insights` (×3 — the three pharma
distributions deliberately share one pack name), `skills`, `studio-agents`.
Anything else is a leftover install: uninstall it.

### A4. Clear stale agent workspaces

`~/.iobot/agents/` is **machine-global** and accumulates. Agents from deleted
packs stay there forever, and the studio builds its skills list from those
folders — this is what makes procurement or EDI skills appear in a pharma
environment.

Keep exactly these, delete every other directory:

```
jarvis  queryngine  project_lead
pharma_data_analyst  pharma_domain_analyst  pharma_reviewer
ainf-meta-agent  sia_agent  profound_a2a  market_feedback  reporting
```

```powershell
dir %USERPROFILE%\.iobot\agents          # review first
rmdir /s /q %USERPROFILE%\.iobot\agents\analyst        # …and each other stale one
```

> If `setup-agents` later fails with a UnicodeDecodeError, an agent has created
> a `.git` or `.iof` directory inside its own workspace and the copy loop reads
> every file as text. Delete those stray directories and re-run.

### A5. Reseed agents and re-sync the registry

```powershell
.venv\Scripts\ioagentfarm setup-agents --force
curl -X POST http://localhost:8111/api/agents/sync
```

**The sync is required, not optional.** It writes the `pack` column that the
studio API uses to scope each workspace's catalog. Skip it and every workspace
shows an unscoped list.

If rows for deleted agents linger:

> Every `iof.`-prefixed statement below assumes the default engine schema. If you
> set `IOF_DB_SCHEMA`, substitute that name (or prepend
> `SET search_path TO <your_schema>, public;` and drop the `iof.` prefixes).

```sql
DELETE FROM iof.agents WHERE role NOT IN (
  'jarvis','queryngine','project_lead',
  'pharma_data_analyst','pharma_domain_analyst','pharma_reviewer',
  'ainf-meta-agent','sia_agent','profound_a2a','market_feedback','reporting');
```

### A6. Re-sync workflow definitions

```powershell
curl -X POST http://localhost:8002/api/studio/workflows/sync
```

Workflow content is DB-canonical, and the old build's definitions are still
stored. This reimports from the current packs and propagates to every tenant.

**Sync upserts — it never deletes.** So workflows and agents removed by the
cleanup are still sitting in the database, and the studio will keep listing
them. Clear them explicitly:

```sql
-- workflow definitions whose packs no longer exist
DELETE FROM iof.studio_workflow_defs WHERE code IN (
  'bug_fix','deck_build','feature_dev','forensic_analysis','pilot_build',
  'project_lead','resiliency_probe','story_loop','test_queryngine');

-- display rows for agents that no longer exist
DELETE FROM iof.studio_agent_display
 WHERE role NOT IN (SELECT role FROM iof.agents);

-- one-off test workflows, if any were created during trials
DELETE FROM iof.studio_workflow_defs WHERE source = 'studio' AND code LIKE '%_wf';
```

Check what remains — it should be your solution's workflows and nothing else:

```sql
SELECT workspace_code, code FROM iof.studio_workflow_defs ORDER BY 1, 2;
```

Run history (`runs`, `steps`, `messages`) referencing deleted workflows is
harmless — it is a record of what happened. Delete it only if you want clean
Sessions lists; see RUNBOOK §"Full platform reset".

### A7. Refresh the tenant workspaces

```powershell
psql "%IOF_DATABASE_URL%" -f scripts\seed_workspaces.sql
```

Idempotent: creates `barrier_insights` and `ainf` and updates their pack
scoping to the new names. Existing workspace ids are preserved, so run history
stays attached.

### A8. Decide about existing data

Your earlier seed round is still in the hub. Either keep it, or start clean:

```powershell
.venv\Scripts\iof-signals reset-hub --dry-run    # shows exactly what would go
.venv\Scripts\iof-signals reset-hub
.venv\Scripts\iof-signals init-db
.venv\Scripts\iof-playbook seed-templates
```

`reset-hub` also clears the **ingest ledger** — without that, re-ingesting the
same workbook reports "already in ledger" and silently loads nothing. For the
wider reset (run history, sessions, on-disk artifacts) see RUNBOOK §"Full
platform reset".

### A9. Rebuild the UI

```powershell
cd apps\agentfarm-ui
npm install
npm run dev          # or: npx vite build --mode prod
```

Vite bakes configuration at build time, so a running dev server must be
restarted to pick up any `.env` change.

### A10. Verify

```powershell
.venv\Scripts\ioagentfarm list-workflows                  # the 4 pharma workflows
curl -H "X-Workspace-Id: 3" http://localhost:8002/api/studio/agents   # 3 pharma + 3 platform
curl -H "X-Workspace-Id: 4" http://localhost:8002/api/studio/agents   # 5 AINF + 3 platform
curl http://localhost:8002/api/studio/skills                          # no procurement/EDI names
```

If a workspace returns an unscoped list, A5's `agents/sync` did not run.

---

# Part B — Fresh install

### B0. What is not in git

Every environment-specific file is excluded deliberately, so a fresh copy has
none of them:

| Missing | Created in |
|---|---|
| `.env` (repo root) — engine + CLI | B2 |
| `apps/agentfarm-api/.env` — studio API | B2 |
| `apps/agentfarm-ui/.env.local` — UI | B2 |
| `~/.iobot/config.json` — model provider | B3 |
| `~/.env` — agent subprocess config | B4 (automatic) |
| `~/.iobot/agents/…` — agent workspaces | B4 (automatic) |
| `.iof/` — state directory | B4/B5 (automatic) |

Prerequisites: Python 3.11+, Node 18+, and a PostgreSQL instance (the engine
schema and hub schema can share one database).

### B1. Install

Run everything from the **repo root** — the folder holding `agentfarm-core/`,
`solutions/`, `apps/` and `scripts/`.

```powershell
cd C:\path\to\repo

python -m venv .venv
.venv\Scripts\pip install -e agentfarm-core -e agentfarm-skills
.venv\Scripts\pip install -e solutions\ainf
.venv\Scripts\pip install -e solutions\pharma\barrier_signal -e solutions\pharma\signal_ingestion -e solutions\pharma\pharma_common -e solutions\pharma\signal_brief
.venv\Scripts\pip install -e apps\agentfarm-api

cd apps\agentfarm-ui
npm install
cd ..\..

.venv\Scripts\ioagentfarm list-workflows      # proof the entry points resolved
```

An empty workflow list means a `pip install -e` failed — fix that first.

*(At a client consuming published wheels, replace the first line with
`pip install "agentfarm-core[iobot,web,duckdb]" agentfarm-skills`; everything
else is identical.)*

### B2. The three `.env` files

**Repo root `.env`** — engine and CLI (`copy env.example .env`):

```ini
IOF_DATABASE_URL=postgresql://user:pass@host:5432/dbname
BARRIER_SIGNAL_DB_URL=postgresql://user:pass@host:5432/dbname?sslmode=require
BARRIER_SIGNAL_DB_SCHEMA=savant_data_hub
IOF_ROOT=C:\path\to\repo\.iof          # ABSOLUTE — see the warning in B4
```

**`apps\agentfarm-api\.env`** — the studio API. **Must be complete and
self-contained**: dotenv stops at the first `.env` it finds walking up from the
API directory, and this service ships as its own deployment where no repo-root
file exists.

```ini
IOF_DATABASE_URL=...                    # same as root
BARRIER_SIGNAL_DB_URL=...
BARRIER_SIGNAL_DB_SCHEMA=...
IOF_ROOT=C:\path\to\repo\.iof
IOF_AGENTFARM_DIR=C:\path\to\repo
IOF_RUN_API_URL=http://localhost:8111   # the engine
# IOF_AUTH_DEV=1                        # DEV ONLY: accepts ANY credentials
```

**`apps\agentfarm-ui\.env.local`** — the UI:

```ini
VITE_WORKSPACE_API_BASE_URL=http://localhost:8002   # studio API
VITE_RUN_API_BASE_URL=http://localhost:8111         # engine
VITE_SKIN=io                                        # io | jnj
```

⚠️ Vite bakes these at **build time**. Restart `npm run dev` after any change.
For a deployable artifact use `npx vite build --mode <mode>` — a bare
`npm run build` defaults to a `.env.production` this repo does not have, so it
silently loads no profile.

### B3. Model provider

Create `~/.iobot/config.json`:

```json
{
  "agents": { "defaults": { "model": "azure/<deployment-name>", "maxTokens": 21333 } },
  "providers": {
    "azureOpenai": {
      "apiKey": "<key>",
      "apiBase": "https://<resource>.openai.azure.com",
      "apiVersion": "<api-version>"
    }
  }
}
```

`maxTokens: 21333` is the SDK's non-streaming ceiling — higher values cause
every generation call to be rejected.

### B4. Agents

```powershell
.venv\Scripts\ioagentfarm setup-agents
```

Seeds `~/.iobot/agents/` (11 agents: 3 framework + 3 pharma + 5 AINF) and
copies your root `.env` to `~/.env`.

> ⚠️ **`IOF_ROOT` must be ABSOLUTE and must reach `~/.env`.** Agent tool
> subprocesses run with their environment stripped to `{HOME, LANG, TERM}` and
> their working directory set to the agent's own workspace, so a relative value
> resolves to a stray `.iof` inside that workspace. The symptom is misleading:
> agents answer run questions with *"that run does not exist"* — truthfully,
> about the wrong directory. Verify:
> `cd %USERPROFILE%\.iobot\agents\jarvis\workspace && iof-run-audit list-runs`

### B5. Database

```powershell
.venv\Scripts\ioagentfarm init                       # engine schema (iof.*)
.venv\Scripts\iof-signals init-db                    # hub schema + taxonomy
.venv\Scripts\iof-playbook seed-templates            # playbook template catalog
psql "%IOF_DATABASE_URL%" -f scripts\seed_workspaces.sql   # tenant workspaces
```

All idempotent. If the app user lacks CREATE rights, have a DBA apply
`scripts\setup_schema.sql` first — it contains every table including the
`studio_*` set.

> **`seed-templates` is easy to skip and fails silently later.** Playbook
> generation matches each barrier to a template by `barrier_type`; with an empty
> catalog *every* barrier is skipped as "no template" and no play is ever
> produced — the workflow succeeds, it just does nothing. Confirm with
> `SELECT template_id, barrier_type FROM playbook_templates;`
>
> Note also that the pack ships **one** template (Operational). Barrier types
> without a template will always skip — that is a content gap for the domain
> team to fill, not a failure. The Playbook → Templates page shows which types
> are covered.

### B6. Services

Run from the repo root, in separate terminals:

```powershell
.venv\Scripts\ioagentfarm serve --port 8111
.venv\Scripts\python -m uvicorn app.main:app --port 8002 --app-dir apps\agentfarm-api
cd apps\agentfarm-ui ; npm run dev
```

`--app-dir` rather than `cd` — uvicorn resolves relative paths against the
working directory, so starting it inside the API folder creates a stray
`.iof/` there.

### B7. Register agents with the studio

```powershell
curl -X POST http://localhost:8111/api/agents/sync
```

Writes the `pack` column the studio uses for per-workspace scoping. Re-run
whenever agents are installed, renamed or removed.

### B8. Load data and run

```powershell
.venv\Scripts\iof-signals bootstrap --input C:\path\to\client-data
.venv\Scripts\ioagentfarm run signal_detection            --goal "Detect signals from the latest call notes"
.venv\Scripts\ioagentfarm run barrier_detection_discovery --goal "Discover barriers from the current signals"
```

`bootstrap` is the whole ETL in one idempotent command. `--sample` uses the
bundled demo workbook; `--skip-embed` when no vector store is configured. The
LLM stages can also be started from the UI: Studio → Workflows → **Run**.

From here, work from [RUNBOOK.md](solutions/pharma/RUNBOOK.md).

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `list-workflows` empty | packs not installed | re-run the install lines, watch for errors |
| Skills from another domain appear | stale agent folders in `~/.iobot` | A4 — delete them, then `setup-agents --force` |
| Every workspace shows the same agents | `agents/sync` never ran | A5 / B7 |
| Agent says a run "does not exist" | `IOF_ROOT` not reaching subprocesses | absolute path in `.env` **and** `~/.env`, re-run `setup-agents` |
| `setup-agents` UnicodeDecodeError | stray `.git`/`.iof` inside an agent workspace | delete those directories, re-run |
| API returns 503 | `IOF_DATABASE_URL` unset for that process | it reads `apps/agentfarm-api/.env`, not the root one |
| Every login fails | API started without its env | restart it so its `.env` loads (`IOF_AUTH_DEV=1` in dev) |
| Re-ingest loads nothing | file already in the ingest ledger | `iof-signals reset-hub`, or ingest a different file |
| UI shows stale URLs or data | Vite bakes env at build time | restart `npm run dev` / rebuild |
| LLM calls rejected immediately | `maxTokens` above the non-streaming ceiling | set `21333` in `~/.iobot/config.json` |
