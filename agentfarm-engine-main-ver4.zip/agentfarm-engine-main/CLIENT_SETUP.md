# Client setup — five repositories, clean slate

Step-by-step for a client environment where the solution is split across five
independent git repositories, each with its own project root, starting from a
database that must be wiped first.

Day-to-day operation afterwards: `RUNBOOK.md` in the solution repo.

> **Windows note:** examples use CMD/PowerShell. A trailing `\` does not
> continue a command — keep each on one line. On Linux/macOS swap
> `.venv\Scripts\` for `.venv/bin/` and `%VAR%` for `$VAR`.

---

## Step 0 — Name the paths once

Every later command refers to these. Set them in the shell you will use, or
just substitute them as you go.

```cmd
set ENGINE=C:\path\to\engine-repo
set SKILLS=C:\path\to\skills-repo
set SOLUTION=C:\path\to\barrier-insights-repo
set API=C:\path\to\api-repo
set UI=C:\path\to\ui-repo
set STATE=C:\agentfarm-state\.iof
```

`STATE` is the shared state directory — run snapshots, forensics, per-run
artifacts. Put it **outside every repo** so no repo owns it and nothing
gitignores it by accident. Create it: `mkdir %STATE%`

### How the repos relate

| Repo | Contains | Runs anything? |
|---|---|---|
| engine | `agentfarm-core` — runtime, CLI, engine web API, the 3 shared agents (Jarvis, Quinn, Alex) | yes — the CLI and engine service |
| skills | `agentfarm-skills` — shared craft skills | no — installed into the engine venv |
| barrier-insights | the solution: `barrier_signal`, `signal_ingestion`, `pharma_common`, `signal_brief` | no — installed into the engine venv |
| api | studio backend | yes — the studio API service |
| ui | React studio | yes — static build / dev server |

**Two Python environments, not five.** Entry-point discovery is per-environment:
a pack installed in a different venv than the engine is invisible to it. So the
solution packs and shared skills install *into the engine's venv*. The API gets
its own venv because it is a separate service — it no longer needs the solution
packs, because it reads solution provenance from the database.

---

## Step 1 — Wipe the database

Both schemas, as a Postgres admin. **Irreversible** — deletes runs, forensics,
signals, barriers, playbooks, everything.

```sql
DROP SCHEMA IF EXISTS iof CASCADE;
DROP SCHEMA IF EXISTS savant_data_hub CASCADE;   -- use YOUR hub schema name
CREATE SCHEMA iof;
CREATE SCHEMA savant_data_hub;
```

> **Using a schema name other than `iof`?** It is configurable — set
> `IOF_DB_SCHEMA` — but it is read in four separate places, so decide now
> rather than later. Substitute your name above, then carry it through
> §5a, §5b and §6. Leave it unset to get `iof`. It must be a bare identifier
> (`[A-Za-z_][A-Za-z0-9_]*`); anything else is rejected rather than quoted.
> This is what lets two environments share one database.

Then clear the local state, since run artifacts live on disk rather than in the
database — leaving them behind orphans them against a fresh schema:

```cmd
rmdir /s /q %STATE%
mkdir %STATE%
rmdir /s /q %USERPROFILE%\.iobot\agents
```

`~/.iobot/agents` is machine-global and survives everything. Agents from
earlier installs stay there forever, and the studio builds its skill list from
those folders — this is what makes skills from other solutions appear.

---

## Step 2 — Build the engine environment

This venv is the runtime: it executes every workflow and agent, so the shared
skills and all four solution packages install into it.

```cmd
cd %ENGINE%
python -m venv .venv
.venv\Scripts\pip install -e .
.venv\Scripts\pip install -e %SKILLS% -e %SOLUTION%\pharma_common -e %SOLUTION%\barrier_signal -e %SOLUTION%\signal_ingestion -e %SOLUTION%\signal_brief
```

`-e` records the source location, so the repos stay independent and code edits
take effect without reinstalling.

Two notes on these commands, both learned by installing the wrong way and
watching it fail:

- **A plain `pip install -e .` yields a complete engine.** The runtime stack
  (`iobot`, `fastapi`/`uvicorn`, `duckdb`) is a hard dependency of
  `agentfarm-core` — deliberately, so there is no extras incantation to
  forget. Older docs showing `.[iobot,web,duckdb]` still work; those
  extras are now empty no-ops.
- **The solution packages install in ONE pip command.** They depend on each
  other by name (`barrier_signal` requires `agentfarm-pharma-common`), and
  those names do not exist on PyPI. Installed one per command, pip tries
  PyPI for the not-yet-installed sibling and fails with "No matching
  distribution found". One combined command resolves the set against itself.

Every package here also **declares `agentfarm-core` as a real dependency**
(pinned `>=0.6,<0.7`), satisfied by the engine installed just above. That
declaration is what makes the future artifact-repository model work: once
`agentfarm-core` and `agentfarm-skills` are published as wheels to an
internal index, this whole step collapses to `pip install -e .` inside the
solution repo — pip pulls the SDK transitively, and the engine/skills repos
no longer need to exist on the machine at all.

**Checkpoint — the packs must resolve:**

```cmd
.venv\Scripts\python -c "from ioagentfarm.packs import load_registry; print([p.name for p in load_registry().packs])"
```

Expect `core`, `barrier_insights` (three times — the solution's
three distributions deliberately share one pack name), `skills`, and
`studio-agents` (built into core: it exposes Studio-created agents from the
state directory; nothing separate to install). A missing name means that
install failed; fix it before continuing, because everything downstream
depends on discovery.

**Checkpoint — the CLI tools must resolve.** Agents invoke these as shell
commands, so a broken one stays silent until an agent reaches for it mid-run:

```cmd
.venv\Scripts\python -c "import subprocess,sys,pathlib; s=pathlib.Path(sys.executable).parent; [print(t,'OK' if subprocess.run([str(s/t),'--help'],capture_output=True).returncode==0 else 'FAILED') for t in ['iof-query','iof-s3','iof-consult','iof-extract','iof-signals','iof-playbook','iof-run-audit']]"
```

All seven must print `OK`. This resolves each tool **relative to the venv**, and
actually executes it, so it catches both a missing command and one that is
installed but fails to import.

> Do not substitute `ioagentfarm cli-hub check` or a `shutil.which` test here.
> Both consult the shell's `PATH`, so in an unactivated shell they report tools
> as absent that are installed and working.

---

## Step 3 — Build the API environment

```cmd
cd %API%
python -m venv .venv
.venv\Scripts\pip install -e . -e %ENGINE%
```

The API needs the framework, not the solution packs. The distribution is
`agentfarm-api` and it **declares `agentfarm-core` as a dependency** — the
combined command above satisfies it with the local engine checkout (the two
`-e` installs resolve together; `-e .` alone would send pip to PyPI for a
name that isn't there). In the artifact-repository model this step becomes
`pip install agentfarm-api` with no engine checkout on the machine.

---

## Step 4 — Build the UI

```cmd
cd %UI%
npm install
```

---

## Step 5 — Configuration

Three `.env` files. Copy each from the `env.example` beside it.

### 5a. `%ENGINE%\.env` — engine and CLI

```ini
IOF_DATABASE_URL=postgresql://user:pass@host:5432/dbname
BARRIER_SIGNAL_DB_URL=postgresql://user:pass@host:5432/dbname?sslmode=require
BARRIER_SIGNAL_DB_SCHEMA=savant_data_hub
IOF_ROOT=C:\agentfarm-state\.iof

# IOF_DB_SCHEMA=iof    # only if you chose a non-default engine schema in step 1
```

### 5b. `%API%\.env` — studio API

Must be **complete and self-contained**: dotenv stops at the first `.env` it
finds walking up from the API directory, and this service has its own repo with
no parent file to fall back on.

```ini
IOF_DATABASE_URL=postgresql://user:pass@host:5432/dbname
BARRIER_SIGNAL_DB_URL=postgresql://user:pass@host:5432/dbname?sslmode=require
BARRIER_SIGNAL_DB_SCHEMA=savant_data_hub

# IOF_DB_SCHEMA=iof    # must match the engine's value exactly

IOF_ROOT=C:\agentfarm-state\.iof
IOF_AGENTFARM_DIR=C:\path\to\engine-repo
IOF_BIN=C:\path\to\engine-repo\.venv\Scripts\ioagentfarm.exe
IOF_RUN_API_URL=http://localhost:8111

IOF_AUTH_JWT_SECRET=<a long random string>
IOF_BOOTSTRAP_ADMIN=you@client.com

# IOF_AUTH_DEV=1     # DEV ONLY: accepts ANY credentials. Never deploy.
```

`IOF_BIN` matters in a split install: the API spawns runs as subprocesses and
must call the **engine's** CLI, not look for one on PATH.

> **Workspace access is closed.** A user reaches only the workspaces they are
> a member of; `IOF_BOOTSTRAP_ADMIN` names the account(s) seeded as **platform
> admins**, who reach every workspace and can grant access from
> **Administration** in the header. Set it, or the first person to log in sees
> an empty workspace switcher and has no way to fix it. The email must match
> the account you log in with (DB user or SSO).
>
> `IOF_AUTH_JWT_SECRET` is what tokens are signed with. Leaving the
> `change-me` default means anyone who has read the source can mint a valid
> token for any user.

### 5c. `%UI%\.env.local` — studio front end

```ini
VITE_WORKSPACE_API_BASE_URL=http://localhost:8002
VITE_RUN_API_BASE_URL=http://localhost:8111
VITE_SKIN=jnj
```

Vite bakes these at **build time**. Restart `npm run dev` or rebuild after any
change. For a deployable artifact use `npx vite build --mode <mode>` — a bare
`npm run build` looks for a `.env.production` that does not exist here and
silently loads no profile.

### 5d. `~/.iobot/config.json` — model provider

```json
{
  "agents": { "defaults": { "model": "azure/<deployment-name>", "maxTokens": 21333 } },
  "providers": {
    "azureOpenai": {
      "apiKey": "<key>",
      "apiBase": "https://<resource>.openai.azure.com",
      "apiVersion": "<api-version>"
    }
  }
}
```

`maxTokens: 21333` is the SDK's non-streaming ceiling — above it every
generation call is rejected.

### The values that must agree

Scattered repos make drift easy, and these are the ones that bite:

| Value | Where |
|---|---|
| `IOF_ROOT` — identical absolute path | `%ENGINE%\.env`, `%API%\.env`, **and `%USERPROFILE%\.env`** |
| `IOF_DATABASE_URL` | engine + API |
| `BARRIER_SIGNAL_DB_URL` / `_SCHEMA` | engine + API |
| `IOF_DB_SCHEMA` *(only if customised)* | engine + API + **both SQL scripts in step 6** |

A mismatched `IOF_DB_SCHEMA` does not error — each process simply creates and
reads its own schema. The symptom is a UI that shows no runs while the CLI
reports them fine.

---

## Step 6 — Create the schema

Run from the engine venv:

```cmd
cd %ENGINE%
.venv\Scripts\ioagentfarm init                 :: engine schema (iof.*)
.venv\Scripts\iof-signals init-db              :: hub schema + taxonomy projections
.venv\Scripts\iof-playbook seed-templates      :: playbook template catalog
```

> **Do not skip `seed-templates`.** Playbook generation matches barriers to
> templates by `barrier_type`; with an empty catalog every barrier is skipped as
> "no template" and no play is produced — the workflow succeeds and does
> nothing. Verify: `SELECT template_id, barrier_type FROM playbook_templates;`

Then apply `setup_schema.sql` — **required at this point, not just for
locked-down databases**. `init` creates the engine tables only; the
`studio_*` set (which the workspace seed below writes into) otherwise
appears only when the API first starts, which is two steps away:

```cmd
psql "postgresql://user:pass@host:5432/dbname" -f %ENGINE%\scripts\setup_schema.sql
```

> **No psql on the machine?** Both SQL scripts run fine through psycopg2
> from the engine venv: strip the backslash-prefixed psql meta-command lines
> (`\if`/`\else`/`\endif`/`\set`) and replace `:"schema"` with your schema
> name, then execute the remainder as one statement batch. The scripts are
> plain DDL/DML apart from those lines.

### Tenant workspaces

Edit `%ENGINE%\scripts\seed_workspaces.sql` and **remove the `ainf` rows from
both INSERT statements** — AINF is not part of this deployment, and leaving them
creates an empty workspace in the switcher. Then:

```cmd
psql "postgresql://user:pass@host:5432/dbname" -f %ENGINE%\scripts\seed_workspaces.sql
```

> **Non-default schema?** Both SQL scripts take it as a psql variable, and
> default to `iof` when it is omitted. Pass it to *each* of them:
>
> ```cmd
> psql "<url>" -v schema=myschema -f %ENGINE%\scripts\setup_schema.sql
> psql "<url>" -v schema=myschema -f %ENGINE%\scripts\seed_workspaces.sql
> ```

---

## Step 7 — Seed the agents

```cmd
cd %ENGINE%
.venv\Scripts\ioagentfarm setup-agents
```

Creates `~/.iobot/agents/` with **six** agents — Jarvis, Quinn, Alex (shared
platform) and Nora, Maya, Vera (the solution) — and copies your engine `.env` to
`~/.env`.

> ⚠️ **`IOF_ROOT` must be absolute and must reach `~/.env`.** Agent tool
> subprocesses run with their environment stripped to `{HOME, LANG, TERM}` and
> their working directory set to the agent's own workspace, so a relative value
> resolves to a stray `.iof` inside that workspace. The symptom is misleading —
> agents answer run questions with *"that run does not exist"*, truthfully,
> about the wrong directory.

### Give Jarvis its database config

`setup-agents` seeds identities and skills; it does **not** deploy the metadata
that tells an always-on agent which databases it may query. That is a separate
command, and without it Jarvis cannot answer any question about runs, token
usage or cost:

```cmd
.venv\Scripts\ioagentfarm configure-agent jarvis %ENGINE%\metadata\jarvis
```

Add `--force` when re-running — it refuses to overwrite existing metadata, so a
second setup pass silently leaves the old file in place.

> If `%ENGINE%\metadata\jarvis\` does not exist, the engine repo was split
> without it: `metadata/` lives beside `agentfarm-core`, not inside it. Copy
> that directory in from the source monorepo — the packaged wheel does not
> carry it.

Verify:

```cmd
cd %USERPROFILE%\.iobot\agents\jarvis\workspace
%ENGINE%\.venv\Scripts\iof-run-audit.exe list-runs
%ENGINE%\.venv\Scripts\iof-query.exe --db iof --metadata-dir metadata --sql "SELECT count(*) FROM runs"
```

Both must run without error. On a fresh install the first prints
`no runs yet (instances dir not created: <your IOF_ROOT>\instances)` — check
that the path shown is your `IOF_ROOT`, because that line doubles as proof
the state directory resolves correctly. The second returns
`{"success": true, …}` (a count of zero is fine) only if `configure-agent`
deployed `databases.yml`.

Note the SQL is **unqualified**: `FROM runs`, not `FROM iof.runs`. The schema
comes from `IOF_DB_SCHEMA` through that config file, which is why a custom
schema needs no SQL edits anywhere.

> If `setup-agents` fails with a UnicodeDecodeError, an agent created a `.git`
> or `.iof` directory inside its own workspace and the copy loop reads every
> file as text. Delete those and re-run.

---

## Step 8 — Start the services

Three terminals.

```cmd
:: 1 — engine web API (runs, chat, SSE)
cd %ENGINE%
.venv\Scripts\ioagentfarm serve --port 8111

:: 2 — studio API
cd %API%
.venv\Scripts\python -m uvicorn app.main:app --port 8002 --app-dir %API%

:: 3 — UI
cd %UI%
npm run dev
```

Health: `http://localhost:8002/api/health` returns 200 and the UI loads on 5173.

Then populate the studio catalogs — **three commands, all required**. The
studio API deliberately has no solution packs installed; everything it shows
comes from the database, and these are what put it there.

**8a + 8b. Agents and workflow registry** — writes the `pack` column the studio
uses to scope each workspace's catalog, and registers the pack workflows with
the engine's run bookkeeping. One command, no server required:

```cmd
cd %ENGINE%
.venv\Scripts\ioagentfarm sync
```

> `setup-agents` (step 7) already ran the agent half. Re-run `sync` whenever a
> pack is installed, upgraded or removed. The equivalent HTTP calls against a
> running engine are `curl -X POST http://localhost:8111/api/agents/sync` and
> `.../api/workflows/sync` — the same code, so use whichever is convenient.

**8c. Studio workflow catalog** — imports the solution repo into the
tenant's studio catalog via the workspace CLI bridge:

```cmd
cd %ENGINE%
.venv\Scripts\ioagentfarm workspace attach barrier_insights --url %SOLUTION%
.venv\Scripts\ioagentfarm workspace import barrier_insights
```

Expect `4 added` on first import and all-`unchanged` on a re-run. This
requires `agentfarm.solution.yaml` at the solution repo root (it ships with
the repo; if yours predates it, copy it from the source monorepo's
`solutions/pharma/`). `--url` also takes a git URL + `--branch` for a
clone-based deployment.

> **Import brings workflows, agents and skills** — everything the manifest's
> `roots:` declares. Agents land in that workspace only and are stored in the
> database, so another machine rebuilds them without the repo. Re-run import
> after pulling repo changes.
>
> **It will never overwrite a Studio edit.** If someone edited an item in the
> Studio *and* the repo changed it too, import refuses, names the item, and
> exits non-zero with nothing applied — the whole batch, not just that item.
> Resolve it by exporting your version first (`ioagentfarm workspace export
> <code>`) or, if the repo should win, re-run with `--take-repo` — which
> snapshots the prior content under
> `<IOF_ROOT>/workspaces/<code>/.backups/<timestamp>/` before replacing it.

Skip 8a/8b and the Studio's agent list carries no pack provenance; skip 8c and
the Studio's workflow tab is empty even though CLI runs work fine. Re-run
`sync` whenever agents or workflows are added or removed; re-run 8c after
pulling solution repo changes.

> **A workspace with no scoping row is UNSCOPED** — it lists every installed
> pack's agents, not just its own. `workspace import` sets that row from the
> manifest's `solution:` (and says so), which is why the import above is what
> makes a tenant show only its own solution. An operator wanting several packs
> in one tenant edits `studio_workspace_settings.include_packs`; import never
> overwrites a row that already exists.

---

## Step 9 — Load data

```cmd
cd %ENGINE%
.venv\Scripts\iof-signals bootstrap --input C:\path\to\client-data --skip-embed
```

One idempotent command: applies schema, syncs taxonomy, ingests, and runs
rule-based detection. `--input` takes a directory or a single `.xlsx`;
`--skip-embed` when no vector store is configured. Re-running is safe — the
ingest ledger skips files already loaded.

Sheets are matched on **column headers**, not names, so a client workbook
usually loads with no mapping configuration. Check the printed summary: a table
at zero rows means that sheet's headers matched nothing.

---

## Step 10 — Run the barrier engine

```cmd
cd %ENGINE%
.venv\Scripts\ioagentfarm run signal_detection            --goal "Detect signals from the call notes"
.venv\Scripts\ioagentfarm run barrier_detection_discovery --goal "Discover barriers from the current signals"
.venv\Scripts\ioagentfarm run playbook_generation         --goal "Generate plays for uncovered barriers"
```

Each returns when its run reaches a terminal state. Detection processes roughly
120 notes per run — check `iof-signals status` and repeat until the unprocessed
backlog is zero before moving to discovery.

These can also be started from the UI: Studio → Workflows → pick one → **Run**.

**Do not kill a run at the first error.** Transient LLM failures are expected
and absorbed — the harness retries within a step, resumes stalled drivers, and
is bounded by a hard attempt cap, so a run always ends in `done` or a clean
failure. What looks like a hang is usually the recovery loop working.

---

## Step 11 — Verify

```cmd
.venv\Scripts\ioagentfarm list-workflows      :: the four solution workflows
.venv\Scripts\iof-signals status              :: sources, signals (rule + ai), barriers
```

In the UI:

- **Studio → Agents** — six agents, no foreign solutions
- **Header workspace switcher** — switching changes the agent, skill and
  workflow lists. If both workspaces show the same thing, `agents/sync`
  (step 8) did not run.
- **Operational Insights** — Source Data populated, Signals listed with
  `rule`/`ai` chips, Barriers with `status: proposed` chips
- **Playbook → Templates** — the seeded template and its coverage

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `list-workflows` empty | packs not installed, or installed into the wrong venv | re-run step 2 and the checkpoint |
| Foreign skills appear | stale agent folders in `~/.iobot/agents` | delete them, `setup-agents --force` |
| Every workspace shows the same agents | the workspace has no scoping row (`studio_workspace_settings`) | re-run `workspace import` — it sets the row from the manifest's `solution:` |
| Agent list carries no pack provenance | `sync` / `agents/sync` never ran | `ioagentfarm sync` |
| Login fails with a 500 on a fresh database | install predates the auth-table ensure | update the engine repo; the API creates `user`/`user_password` at startup |
| An ops script wrote to the wrong database | install predates the `.env`-precedence fix (the file beat the environment) | update the engine repo; the scripts now echo the resolved target |
| `workspace export` writes shared-skill directories into the repo | install predates the export restriction | update the engine repo; discard those directories, they are the SDK's |
| Agent says a run "does not exist" | `IOF_ROOT` not reaching subprocesses | absolute path in both `.env` files **and** `~/.env`, then `setup-agents` |
| API 503 | `IOF_DATABASE_URL` unset for that process | it reads `%API%\.env`, not the engine's |
| API cannot start runs | `IOF_BIN` missing or wrong | point it at the engine venv's `ioagentfarm.exe` |
| Every login fails | API started without its env | restart it so its `.env` loads (`IOF_AUTH_DEV=1` in dev) |
| Logged in but the workspace switcher is empty | membership is closed and this account has none | set `IOF_BOOTSTRAP_ADMIN` to that email and restart the API, then grant others from **Administration** |
| 403 "You do not have access to workspace" | the account is not a member of the selected workspace | add them in Administration → Workspaces, or switch to one they belong to |
| Administration link missing | that account is not a platform admin | an existing admin grants `role: admin`; the link is driven by `/api/admin/me` |
| No plays generated | template catalog empty, or no barrier of a covered type | `iof-playbook seed-templates`, then check `barrier_type` values |
| Re-ingest loads nothing | file already in the ingest ledger | ingest a different file, or `iof-signals reset-hub` |
| UI shows stale data or URLs | Vite bakes env at build time | restart `npm run dev` / rebuild |
| LLM calls rejected immediately | `maxTokens` above the non-streaming ceiling | set `21333` in `~/.iobot/config.json` |
| `setup-agents` UnicodeDecodeError | stray `.git`/`.iof` inside an agent workspace | delete those directories, re-run |
| Jarvis cannot answer run / token / cost questions | `configure-agent` never ran, so it has no `databases.yml` | step 7, then `--force` if re-running |
| UI shows no runs, CLI shows them | `IOF_DB_SCHEMA` differs between engine and API | make the two `.env` files agree, restart both |
| `iof-query` fails with `ModuleNotFoundError` | install predates the tools relocation | `pip install -e .` in the engine repo again |
| `cli-hub check` reports tools missing that work | it uses the shell `PATH`, not the venv | activate the venv, or use the step-2 checkpoint |
| Old behaviour survives a reinstall; package metadata looks duplicated | an interrupted `pip install` on Windows leaves renamed `~…` directories in `site-packages` that stay discoverable | delete `.venv\Lib\site-packages\~*`, then reinstall |
| Studio workflow tab empty, CLI runs fine | workspace import (8c) never ran, or the solution repo lacks `agentfarm.solution.yaml` | step 8c; copy the manifest in if missing |
| Solution agents missing from a workspace right after setup | a studio request landed before `agents/sync`; older builds cached that empty view for an hour | run 8a, then restart the studio API if the list stays wrong |
| `workspace import` says agents "shadow a platform-shared agent" | engine build predates the platform-tier fix to `reserved_names()` | update the engine repo; the reserved tier is core + shared skills only |
| State lands in `<engine>\.iof` despite `IOF_ROOT` in `.env` | engine build predates the explicit-config fix to `_recover_iof_root()` | update the engine repo; delete the stray `.iof` |

---

## Starting over later

```cmd
.venv\Scripts\iof-signals reset-hub              :: business data + ingest ledger
.venv\Scripts\iof-signals reset-ai-signals       :: AI signals only, re-arm notes
```

For a full platform reset — run history, sessions, on-disk artifacts, studio
catalogs — see `RUNBOOK.md` §"Full platform reset".
