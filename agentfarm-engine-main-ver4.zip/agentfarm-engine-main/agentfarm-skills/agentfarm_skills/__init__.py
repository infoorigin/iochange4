"""agentfarm-skills — the shared capability-skill pack for AgentFarm.

Framework-owned skills that any agent, in any domain, can load: data querying,
data visualization, presentation/decks, vectorfs document search, guardrails,
planning/checkpointing, and report standards.

Ships as its own distribution (decoupled from core release cadence) and plugs in
via the ``aicore.packs`` entry point. Its ``skills`` are auto-injected into
every agent workspace by ``ensure_agent_workspace`` (see engine/workspaces.py).
"""
from __future__ import annotations

from importlib.resources import files

from ioagentfarm.packs import Pack


def pack() -> Pack:
    from ioagentfarm.packs import load_skill_defaults

    return Pack(
        name="skills",
        skills=files("agentfarm_skills") / "skills",
        # The opening hand for this wheel's universally-useful skills. Only
        # skills every agent should start with — this package is shared by
        # every domain, so it must never name a domain's roles. See
        # skill_defaults.yaml.
        skill_defaults=load_skill_defaults("agentfarm_skills"),
    )
