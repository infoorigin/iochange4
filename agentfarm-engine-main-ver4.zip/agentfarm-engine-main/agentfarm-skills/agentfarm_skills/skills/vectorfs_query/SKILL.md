---
name: vectorfs_query
description: Query unstructured document collections (contracts, policies, specs) via a read-only filesystem. Navigate with standard Unix commands — no custom abstractions.
always: false
---

# VectorFS Query

## Goal

Search unstructured documents (contracts, reports, policies, specifications) stored as a read-only filesystem. You use **standard Unix commands you already know** — `ls`, `cat`, `grep`, `find`, `head`, pipes. No custom tools to learn.

## When to use

When the catalog lists a source with `type: vectorfs` — for questions about document content, contract terms, policy language, clause text, or any unstructured text.

## Tool

`vectorfs` — CLI that exposes the document collection as a filesystem you can browse with Unix commands.

## Setup

The vectorfs config is embedded in the **Current vectorfs config** section below — no need to read it from file.

`vectorfs` auto-loads `VECTORFS_STORE`, `VECTORFS_COLLECTION`, `QDRANT_URL` and other backend creds from `.env` in the workspace cwd via dotenv. **Do NOT prefix commands with env-var exports** — just run vectorfs directly.

## Commands (standard Unix — you already know these)

```bash
vectorfs "ls /"                                   # list top-level folders
vectorfs "ls /contracts"                          # list 16 vendor slugs
vectorfs "ls /contracts/<vendor>"                 # count/verify chunks for a vendor (returns opaque IDs, useful for sanity checks)
vectorfs "grep -ri '<term>' /contracts/<vendor>"  # PRIMARY TOOL — search within a vendor
vectorfs "grep -ri '<term>' /contracts"           # search across portfolio
vectorfs "cat <path>"                             # follow-up read of a path you saw in grep output
```

Paths are 2 levels: `/contracts/<vendor>/<chunk_id>`. The chunk_id is a system-internal numeric ID (like a UUID) — **never construct one yourself**, and never iterate through them sequentially (cat 0001, 0002, 0003...). You only `cat` a chunk_id that `grep` has already returned to you. For everything else, `grep -ri '<concept>' /contracts/<vendor>` is the one tool you need: it returns matching chunk paths **with their content inline**, so you rarely need a follow-up `cat`.

Pipes and redirects work: `vectorfs "grep -ri 'Net 45' /contracts | head -20"`.

## Decision tree (how to choose commands)

**Question names a vendor + a concept** (e.g., "Oracle termination notice", "Accenture payment terms"):
→ `grep -ri '<concept>' /contracts/<vendor>` — returns matching chunks with content inline. Usually 1 call is enough; the grep output shows "Term and Termination" / "Payment Terms" as heading lines so you see the source section directly.

**Question is cross-portfolio** (e.g., "which vendors have GxP clauses?"):
→ `grep -ri '21 CFR Part 11' /contracts` — returns only matching files.

**Question applies the SAME clause lookup to N vendors** (e.g., "For each top 5 vendor, show their payment terms"):
→ **Do NOT loop vendor-by-vendor.** Use ONE broad grep across the whole portfolio, then filter results in your answer:
```bash
vectorfs "grep -riE 'Net [0-9]+' /contracts"   # all payment terms at once
vectorfs "grep -riE 'termination.{0,50}notice' /contracts"   # all termination notices
vectorfs "grep -ri 'GxP' /contracts"           # all GxP clauses
```
One call returns ~20-50 matching chunks with their paths. This is 5-10x faster than N per-vendor lookups because it's a single tool call + single LLM round.

**Question needs per-vendor deep dive for N vendors** (e.g., "profile each top vendor"):
→ Fire N scoped-`grep` calls **in a SINGLE parallel tool-use turn** — not N separate turns. Multiple tool_use blocks in one assistant response execute in parallel.
```
turn 1: [vectorfs grep -ri 'termination' /contracts/oracle]
        [vectorfs grep -ri 'termination' /contracts/sap]
        [vectorfs grep -ri 'termination' /contracts/aws]
```
3 parallel calls = 1 LLM round-trip, not 3. Fastest when per-vendor detail is needed.

**Question uses vocabulary that might not match the contract wording** (e.g., user says "lock-in" but contracts say "exclusivity" or "notice period"):
→ Use multiple grep patterns in one call: `grep -riE 'exclusiv|notice period|transition assistance|non-compete' /contracts`. Synonyms are cheaper than dumping everything.

## Query patterns

| Goal | Command |
|------|---------|
| List all vendors | `vectorfs "ls /contracts"` |
| Count chunks for one vendor (sanity) | `vectorfs "ls /contracts/oracle \| wc -l"` |
| Search within one vendor | `vectorfs "grep -ri 'termination' /contracts/oracle"` |
| Compare one clause across vendors | `vectorfs "grep -ri 'payment terms' /contracts"` |
| Expand context on a grep hit | `vectorfs "cat <path-grep-returned>"` |
| Count matches | `vectorfs "grep -ri 'audit' /contracts \| wc -l"` |

## Rules

- **Tool-call budget: 8 per request.** Every queryngine request has a hard budget of **8 tool calls total** across vectorfs + iof-query combined. When you've spent 8, STOP making tool calls and compose the envelope from whatever data you have. A partial answer with honest caveats is strictly better than a perfect answer that took 30 calls. The orchestrator will inject a reminder at your 7th call.
- **Representative, not exhaustive.** For comparison or aggregation questions across multiple entities (*"top 3 vendors by X"*, *"which vendors have Y"*, *"compare Z across vendors"*), **one confident data point per entity is enough**. Do not iterate for completeness. A table with 5 rows sourced from 5 chunks beats a table with 5 rows sourced from 20 chunks and 5× latency. If the first grep per vendor returns a hit, that's your answer for that vendor — move to the next one.
- **No meta-debugging.** If a tool returns an error, malformed output, or something you don't expect, **do NOT try to diagnose the infrastructure**. Forbidden: `python -c "print('test')"`, env-var checks (`os.environ.get(...)`), connectivity probes, `grep` for `QDRANT_URL` or `VECTORFS_STORE` in home directories, reading `.env` files. Note the anomaly in a caveat (*"vectorfs returned empty output for /contracts/<vendor> on one call"*) and continue with other tools. Infra problems are the orchestrator's job, not yours.
- **Scope first, grep second** — always pass a vendor-level path to `grep -r` (e.g. `/contracts/oracle`). Don't grep the whole portfolio when a scoped grep will do. Unscoped greps produce noisy cross-vendor output that's hard to interpret.
- **Use multiple grep patterns for fuzzy concepts** — `grep -riE 'terminat|cancel|expir'` in one call beats three sequential searches. Cheaper and more explainable.
- **Cite the exact path you read** — evidence is `/contracts/oracle/0015` not "from Oracle contracts." If a chunk carries heading text (e.g., "Term and Termination"), quote the heading in `answer`/`insight` so the reader knows which clause.
- **HARD CAP: 3 vectorfs calls per concept per vendor.** After 3 calls with no definitive match (grep returns empty, or returns only tangential mentions that don't answer the question), STOP. Conclude the concept is not present in that vendor's contracts. Return `null` for that row's value in the envelope and add one line to `caveats[]` like `"AWS: no termination notice clause found in searched contracts"`. Do NOT escalate regex variations. Do NOT widen with broader synonyms. Do NOT cat sequential chunks (0001, 0002, ...) hoping for a hit. **A missing clause is a legitimate answer — not every contract has every clause** (cloud EDP, perpetual licenses, and consumption commitments typically don't carry traditional termination-notice clauses; that absence is itself information).
- **Never paraphrase from training data.** If vectorfs returned nothing for "AWS EDP termination notice," the answer is `null` — not your recollection of AWS EDP terms. This is the #1 way to corrupt an envelope.
- **Never modify, summarize, or paraphrase the retrieved text in the evidence panel** — show the actual chunk. You may summarize in the answer, but raw text appears in evidence.
