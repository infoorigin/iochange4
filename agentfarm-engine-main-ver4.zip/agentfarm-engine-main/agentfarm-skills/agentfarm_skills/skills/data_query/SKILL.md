---
name: data_query
description: "Query any structured data source (PostgreSQL, MySQL, Parquet, CSV) via iof-query, one inline --sql call per query. Read-only. One tool, backend-agnostic."
always: false
---

# Data Query

## Goal

Execute read-only queries against any structured data source listed in the data catalog. The backend (PostgreSQL, MySQL, DuckDB/Parquet/CSV) is transparent — you use the same tool and interface regardless.

## Tool

`iof-query` — unified CLI for all structured data sources.

## Default pattern — ONE tool call, SQL inline

```bash
iof-query --db <source_name> --sql "SELECT supplier, SUM(amount) FROM po_lines WHERE fiscal_year = 2025 GROUP BY supplier" --metadata-dir metadata
```

Double quotes around the SQL, single quotes for string literals inside it.
Writing the SQL to a file first is a second model round on every question and
buys nothing for a statement that fits on a line — measured on a served
deployment, the file cost about a third of the answer time. When the turn
names a per-session scratch directory, add `--scratch <that dir>` so the
tool-call budget applies to the inline query.

## When the file IS needed — double-quoted identifiers, or SQL longer than a line

```bash
# Step 1: write the SQL (write_file tool, path: <scratch dir>/query.sql)
# Step 2: execute
iof-query --db <source_name> --sql-file <scratch dir>/query.sql --metadata-dir metadata
```

Use this ONLY when the SQL must contain double-quoted identifiers such as
`"Payment Amount"` or `"End Date"` — the shell mangles nested double quotes
passed to `--sql` inline — or when the statement is too long for one line (a
long `IN` list, several CTEs). A catalog whose columns are snake_case never
needs quoting, so it never needs the file. ⚠ Do not try inline
`--sql "... \"Column Name\" ..."` as a discovery step; go straight to the file
when an identifier needs quoting. Put the file in the scratch directory the
turn names, never at the workspace root.

## Other flags

```bash
# Custom row limit (default: 200)
iof-query --db <source_name> --sql "SELECT ..." --metadata-dir metadata --limit 500
```

## Discovering sources

The catalog embedded in your system prompt (see `catalog_reader`) lists every database by name, type, and entity — with dimensions, measures, cardinality, and value ranges. Use that directly. Do NOT run `--list-databases` or `--list-entities` as a default first step.

Run a discovery command only if:
- The user asks a meta question (*"what sources are available?", "what can you query?"*)
- A query returns `database not found` or `entity not found` and you need to verify the canonical name

Otherwise skip straight to writing and executing the query.

## Output format (JSON)

```json
{
  "success": true,
  "rows": [{"col1": "val1", "col2": "val2"}, ...],
  "row_count": 42,
  "columns": ["col1", "col2"],
  "database": "source_name"
}
```

On error:
```json
{
  "success": false,
  "error": "description",
  "error_type": "TABLE_NOT_FOUND|COLUMN_NOT_FOUND|SYNTAX_ERROR|CONNECTION_ERROR|...",
  "rows": [], "row_count": 0, "columns": []
}
```

## Query rules

- **SELECT only.** The tool blocks INSERT, UPDATE, DELETE, DROP, ALTER, CREATE, TRUNCATE.
- **Use catalog column names exactly.** Read them from the catalog first — do not guess.
- **Auto-LIMIT.** The tool adds `LIMIT 200` if missing. Use `--limit` to override.
- **PostgreSQL dialect** for SQL databases: double-quoted identifiers, `TO_CHAR()`, `::type` casts.
- **DuckDB dialect** for file sources: `read_parquet()`, `read_csv()`, glob patterns, partition pruning.

## Backend-specific SQL

### PostgreSQL / MySQL (type: postgres, mysql)
```sql
SELECT supplier, SUM(amount) as total_spend
FROM po_lines
WHERE fiscal_year = 2025
GROUP BY supplier
ORDER BY total_spend DESC
```

### DuckDB — CSV files (type: duckdb)
```sql
SELECT supplier_id, name, risk_score
FROM read_csv('metadata/data/suppliers.csv')
WHERE risk_score > 7
```

## When not to query

If the user's question is purely interpretive (*"why is AWS so high"*, *"thoughts?"*, *"should we be worried"*) — do not run iof-query. The prior tool_result is in the session. Skip to composition; `result_composer` will emit an envelope with `data: null` and the reasoning in `insight`.

## Do not tidy up

The temporary `query.sql` file is fine to leave on disk — do NOT run `del`, `rm`, or cleanup commands after your query succeeds.

## Error handling

- If `success: false`, include the `error` string in the envelope's `evidence.caveats`.
- If zero rows, reflect empty result in `data`; do not infer from training data.
- Common errors: `TABLE_NOT_FOUND`, `COLUMN_NOT_FOUND`, `SYNTAX_ERROR` — check catalog for correct names.

## Output

Formatting is **not your job** — `result_composer` owns output format. Your job ends when you have the raw rows.
