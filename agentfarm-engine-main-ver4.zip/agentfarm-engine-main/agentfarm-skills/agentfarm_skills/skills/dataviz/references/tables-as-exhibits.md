# Tables as exhibits (the consultant's craft)

`choosing-a-form.md` sends you here when the form is a **table** — more than ~7 meaningful classes, or a reader who needs exact values. A table is a visualization: dense and exact. A McKinsey-grade table **argues a point** — the reader sees the "so-what" in seconds, not after scanning a grid. Treat every table as an *exhibit*, not a data dump.

The color rules are the same as the rest of the method: roles from `palette.md`, sequential for magnitude, status reserved. Only the marks differ.

## Encode magnitude in-cell — so the eye ranks without reading

Pick **one** device per table (never stack them):

- **Data bars** — a faint horizontal bar behind each number in the key column, width ∝ value. A number column becomes an instant ranking. Bar fill = `--series` at low alpha or a single ink tint; the number sits on top in `--text-primary`.
- **Heat** — a `sequential` (one-hue, light→dark) background on the **key value column only**. Light = low, dark = high. Never heat the whole grid; that destroys scanning.
- **Harvey balls** (`○ ◔ ◑ ◕ ●`) — for qualitative 0–4 ratings (risk, fit, readiness, coverage). The consulting staple for comparison matrices; one glyph reads faster than a number.
- **Status chips** — `status` palette + a **word/icon** for state cells (on-track / at-risk / critical). Never color alone — status is icon+label by rule.

## Structure the argument

- **Sort by the value that matters** (usually descending). The row order is part of the argument.
- **Emphasize the takeaway row/column** — bold it or give it a faint `--surface` accent tint; keep the rest quiet so the emphasis reads.
- **One-line "so-what" below the table** — the action-title rule applies to exhibits: state what the table *proves*, not what it *contains*.
- **Cap the density** — an exhibit, not a dump. On a slide, ≤ ~7 rows × ≤ 6 columns; summarize or split beyond that.
- **Cap by dropping rows, not the decision columns.** When a source table carries *owner / accountable*, *by-when / deadline*, *key assumption*, or *success metric* columns, keep them — they are the executive so-what that turns a data table into a decision exhibit. Drop rows to fit; never these columns. If the source lacks them, omit silently — never invent an owner, deadline, assumption, or metric (nothing on an exhibit that isn't in the source).

## Number hygiene

- **Right-align** numbers; align decimals; use tabular figures (`font-variant-numeric: tabular-nums`). Left-align text.
- Put the **unit in the header** (`Spend ($M)`), not in every cell.
- **Round to the decision** — `17.0`, not `16,984,213`.

## Line-light minimalism (this is what reads as "consultant")

- **No vertical rules, no boxed cells, no heavy borders.** One rule under the header, generous cell padding, whitespace over gridlines.
- Zebra striping only for genuinely wide tables where the eye loses its row.
- The restraint is the point: gridlines everywhere read as "spreadsheet"; whitespace + one header rule reads as "exhibit."

## Delivery-agnostic

Author the exhibit as a real HTML `<table>` (data bars as positioned spans, Harvey balls as glyphs, chips as styled spans). It exports unchanged: dom-to-pptx maps a `<table>` to a **native editable PowerPoint table**, and Playwright prints it crisply to PDF. Same category, same color, on every slide.
