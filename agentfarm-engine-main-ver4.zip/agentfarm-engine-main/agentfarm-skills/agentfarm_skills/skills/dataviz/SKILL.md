---
name: dataviz
description: >-
  Use this skill whenever you are about to create ANY chart, graph, plot, dashboard, or
  data visualization, in ANY output medium — an HTML or React artifact, inline SVG,
  plotting code in any library (matplotlib, plotly, d3, Recharts, …), an image/PNG you
  will render and upload, or a chart shared into Slack. Read it BEFORE writing the first
  line of chart code, choosing chart colors, building a stat tile / meter / KPI row, or
  laying out a dashboard. Produces visualizations that read as one system — elegant,
  accessible, consistent in light and dark — using a brand-neutral placeholder palette
  you swap for your own. Teaches a design-system-agnostic method: a form heuristic, a
  color formula with a runnable validator, mark specs, and interaction rules. A validated
  default palette is documented in `references/palette.md` — swap that file's values for
  your brand's. Triggers on: "chart", "graph", "plot", "data viz",
  "visualization", "dashboard", "analytics", "visualize data", "categorical colors",
  "sequential / diverging palette", "stat tile", "sparkline", "heatmap", "legend",
  "axis", "tooltip", "chart colors", "color by series".
license: >-
  Local copy of the bundled Claude Code `dataviz` skill, extracted into this repo for
  team use. The reference files and validator scripts are copied verbatim; this SKILL.md
  is a faithful reconstruction of the injected skill body. Not an official Anthropic
  open-source release — the upstream skill is not published in github.com/anthropics/skills.
---

# Data visualization

A design-system-agnostic method for building charts that read as **one coherent
system** — elegant, accessible, consistent in light and dark. The method is a fixed
pipeline; only the palette instance changes per brand.

## The method, in order

Work these steps in sequence. Do not pick colors before you have picked a form.

1. **Choose the form first** — decide what the reader must *do* with the data, then
   pick the form. Often the right form is **not a chart** (a stat tile, KPI row, hero
   figure, meter, or table). See `references/choosing-a-form.md` for the
   is-it-even-a-chart table, the job→type table, and the series-count ladder. When the
   form is a **table**, design it as an *exhibit* (data bars, Harvey balls, heat,
   line-light) per `references/tables-as-exhibits.md`.

2. **Assign color by job, not by taste.** Every chart color does exactly one of four
   jobs — **categorical** (identity), **ordinal/sequential** (magnitude/position),
   **diverging** (polarity), or **status** (state). A categorical palette is legal only
   if it passes **six checks** (fixed hue anchors, lightness band, chroma floor, CVD
   separation, contrast vs surface, documented-palette-only). See
   `references/color-formula.md`.

3. **Validate the palette — never eyeball it.** Run the validator on every categorical
   palette, once per mode:

   ```bash
   # Node
   node .claude/skills/dataviz/scripts/validate_palette.js \
     "#2a78d6,#1baf7a,#eda100,#008300,#4a3aa7,#e34948,#e87ba4,#eb6834" --mode light

   # or Python (no Node required)
   python .claude/skills/dataviz/scripts/validate_palette.py \
     "#2a78d6,#1baf7a,#eda100,#008300,#4a3aa7,#e34948,#e87ba4,#eb6834" --mode light
   ```

   - Run again with `--mode dark --surface "#1a1a19"`.
   - Add `--pairs all` for scatter / bubble / choropleth / small-multiples (any two
     marks can be neighbors; the default adjacent check would hide a collapse).
   - Pass `--ordinal` for an ordered one-hue ramp (switches to ramp checks).
   - Exit 0 = no hard FAIL; exit 1 on any FAIL. WARN bands (CVD 8–12 floor, sub-3:1
     contrast) are legal **only** with a secondary encoding (direct labels / texture /
     the table view).

4. **Draw the marks and chrome to spec** — bar/line/area/scatter geometry, gridlines,
   axes, baselines, direct labels, and the texture accessibility channel. See
   `references/marks-and-anatomy.md` and `references/components.md` (stat tiles, meters,
   KPI rows, sparklines, hero figures).

5. **Wire interaction** — hover, tooltips, legend behavior, filter composition,
   emphasis/highlight. See `references/interaction.md`.

6. **Check against the anti-patterns** before shipping. See
   `references/anti-patterns.md`.

## Palette: swap this one file for your brand

`references/palette.md` is the **reference instance** — a validated default palette
(8 categorical slots, sequential ramp, diverging pair, fixed status scale, surfaces,
chrome/ink, typography). The rest of the skill is system-agnostic: **to target your
brand, substitute the hex values in `palette.md` and re-run the validator.** Nothing
else changes.

In HTML charts, define only the roles you use as CSS custom properties in a local
`<style>` block, swap light/dark in a `prefers-color-scheme` media query, and write the
chart body against roles (`--series-1`) rather than raw hex.

## Hard rules (the ones most often broken)

- **Sequential is the safe default.** Reach for categorical only when the series
  themselves are the subject; if the story is "this one went up," that's **emphasis**
  (one accent hue, the rest gray), not categorical.
- **Never solve "too many series" by generating more hues.** 8 slots is the ceiling.
  Past it: fold the tail into "Other," facet into small multiples, or use composite
  encoding (hue × shape).
- **Status never follows the theme** — fixed scale, reserved meaning, always
  icon + label (warning/serious sit sub-3:1 on light by design; the pairing is the
  mitigation).
- **Never color nominal bars by their value** — that re-encodes what bar length already
  shows and spends the identity channel.

## Files

| File | What it covers |
|---|---|
| `references/choosing-a-form.md` | Is-it-a-chart? · job→type · series-count ladder |
| `references/color-formula.md` | The four jobs · the six checks · snap-to-passing · themes |
| `references/palette.md` | Reference instance — swap for your brand |
| `references/marks-and-anatomy.md` | Mark geometry, axes, gridlines, texture channel |
| `references/components.md` | Stat tiles, meters, KPI rows, sparklines, hero figures |
| `references/tables-as-exhibits.md` | Tables as McKinsey exhibits — data bars, Harvey balls, heat, line-light |
| `references/interaction.md` | Hover, tooltips, legend, filters, emphasis |
| `references/anti-patterns.md` | What not to do — pre-ship checklist |
| `scripts/validate_palette.js` | Palette validator (Node); also loadable as a page module |
| `scripts/validate_palette.py` | Palette validator (Python; no Node required) |
