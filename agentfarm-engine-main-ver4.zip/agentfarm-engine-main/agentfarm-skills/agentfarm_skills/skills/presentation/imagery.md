# Imagery layer — abstract SVG backdrops (reference)

**OPTIONAL and REMOVABLE.** Imagery is *never* what makes a deck premium — the
"Graphite & Signal" system (type scale, ink + one accent, composition, the block
language) does that, and a deck with **zero backdrops must already look board-ready**
(R14). A backdrop is only a tasteful garnish for *chapter-tone* slides: subtle
theme-colored geometry behind title/divider slides — **not** stock photos and
**never** behind data.

Because it's a garnish, it must be **trivially removable**: a backdrop is one
`<svg class="slide-bg">` line, and deleting it must leave a premium slide behind.
Never let a slide *depend* on its backdrop. Some users don't want imagery at all —
that's a supported, first-class choice, not a downgrade. Loaded on demand by the
`presentation` skill (Step 2 / Step 4); ignore it entirely for a plain deck.

## The one rule that keeps it McKinsey (SCOPE)

Backdrops appear on **exactly three kinds of slide, and nowhere else**:

| Slide | Backdrop? | Context flag |
|---|---|---|
| **L1 Title / Hero** | ✅ yes | `--context cover` |
| **L3 Section divider** | ✅ yes | `--context divider` |
| The one **"wow" slide** (R12) | ✅ optional | `divider` or `cover` |
| L4 KPI grid, L5 bullet+visual, L6 table, L7/L8/L10/L11, charts | ❌ **never** | — |

Why: imagery sets the tone between chapters; **exhibits stay clean**. A motif behind
a data table reads as clip-art and fights readability. If in doubt, leave it off —
a restrained deck beats a busy one. **At most ~1 backdrop per 3–4 slides.**

## How to add one (2 steps)

**1. Generate the SVG** (pure-Python, no deps; prints to stdout):

```bash
python skills/presentation/scripts/gen_backdrop.py \
  --motif corner --accent "#3A4DE0" --context cover
```

- `--accent` = the deck's `--accent-primary` (same hex as the theme). Keeps the
  backdrop in-palette automatically.
- `--motif` = `mesh` | `grid` | `topo` | `diagonal` (see table below).
- `--context` = `cover` (light slide bg, dark text) or `divider` (`.section-slide`
  accent bg, white text). This picks contrast-safe tints for you.
- `--seed N` = change placement between two same-motif slides so they don't look identical.

**2. Paste the output as the FIRST child of the slide**, before `.slide-content`:

```html
<section class="slide section-slide" id="slide-03">
  <svg class="slide-bg" ...>…generated…</svg>   <!-- FIRST child = painted behind -->
  <div class="slide-content">
    <h1 class="reveal">Part I — The Portfolio Today</h1>
    <p class="subtitle reveal">Where the $100M sits today</p>
  </div>
  <span class="slide-number">3</span>
</section>
```

The `.slide-bg` / `.slide-scrim` classes in `viewport-base.css` handle full-bleed
positioning and keep the backdrop **behind** the content (`z-index:0` vs content's
`z-index:1`). Do not add a backdrop to the `.reveal` set — it should always be visible.

## Motif → use

| Motif | Feel | Best for |
|---|---|---|
| `corner` | concentric accent arcs anchored to a corner (one deliberate mark) | **title/cover** — the recommended cover treatment (visible on white; clears centered/left text) |
| `mesh` | soft overlapping color blobs (gradient wash) | calm **dividers**; a whisper-only wash (near-invisible on a light cover — use `corner` there instead) |
| `grid` | faint square grid + accent ticks | structured/Swiss dividers, data-heavy decks |
| `topo` | concentric contour rings | the **"wow"** slide, strategy/roadmap dividers |
| `diagonal` | dynamic chevron band + depth gradient | energetic section dividers, closing/CTA |

**Light covers:** prefer `corner` over `mesh`. On a white background the `mesh` wash is
tuned so faint it barely registers; `corner` gives the cover a single visible-but-restrained
geometric anchor. (`mesh` still earns its keep on the accent `divider` field.)

Rotate motifs like layouts — don't use the same one on every divider. A common set:
`corner` cover → `grid` divider I → `topo` divider II / wow → `diagonal` closing.

## Contrast & restraint (non-negotiable)

- The script already tunes opacity per context (whisper-faint on light `cover`;
  low-opacity white on the accent `divider`), so text stays readable **without** a scrim.
- Only reach for `<div class="slide-scrim"></div>` (also a first child) if a busy
  `topo`/`diagonal` divider ever dims the heading — rare.
- Never raise the motif opacities to "make it pop". If it competes with the words,
  it's wrong. The words are the point; the backdrop is atmosphere.

## Duotone photography — real images, enterprise-blended (the ppt-master steal)

When a real photo is warranted (a title or divider that wants atmosphere a geometric
motif can't give), use one — but **blend it into the deck palette** as a navy DUOTONE so
it reads editorial/on-brand (the Bloomberg/McKinsey look), never stock-y. Same scope as
abstract backdrops: title / dividers / one "wow" slide, behind a scrim, **never behind data**.

**Critical:** the duotone is baked into the PIXELS by `scripts/photo.py` (Pillow). A CSS
filter would NOT survive dom-to-pptx (it maps the DOM to shapes, ignoring CSS filters), so
the PPTX would show the raw photo. Baking guarantees browser == PPTX.

**Fetch + blend (no API key — Openverse, CC-licensed):**
```bash
python skills/presentation/scripts/photo.py fetch \
  --query "modern data center" --out {{output_dir}}/assets --accent "#1B365D"
# → assets/<slug>_duo.png  + attribution.json + CREDITS.md
```
- Default licenses are **enterprise-safe** (`cc0,pdm,by` — no ShareAlike/NonCommercial/NoDerivatives).
  **Attribution is written for you** — put a small credit line on the slide or appendix (required for CC BY / Unsplash / Pexels).
- Other sources: `--source pexels` (needs `PEXELS_API_KEY`) / `--source unsplash` (needs `UNSPLASH_ACCESS_KEY`).
- Best-effort: no network / no results / no key → it prints why and exits 0; fall back to `gen_backdrop.py` or a visual device.

**User-provided image (you already have the file):**
```bash
python skills/presentation/scripts/photo.py duotone --in /path/to/photo.jpg \
  --out {{output_dir}}/assets/hero_duo.png --accent "#1B365D"
```

**Place it** as a full-bleed backdrop (same slot as the SVG), with a scrim for contrast:
```html
<section class="slide section-slide" id="slide-NN">
  <img class="slide-bg" src="assets/hero_duo.png" alt="">
  <div class="slide-scrim"></div>
  <div class="slide-content"><h1 class="reveal">Part II — The Renewal Window</h1></div>
</section>
```

**Blend onto an EXISTING deck (Mode B):** to drop a (user-provided) image as a blended
full-bleed background onto a slide of an existing `.pptx`, use `pptx_tool.py add-image`
(bakes the duotone + adds a scrim + sends it behind the content). See `editing.md`.

## Export

Nothing to configure. Inline `<svg>` (abstract) scrapes to a **native, editable PPTX
vector**; a duotone `<img>` exports as a **native picture**; both print cleanly to PDF.
The abstract backdrop needs no downloads/attribution; a duotone photo carries its
`attribution.json` — surface the credit line.

## Self-review add-on (fold into SKILL.md Step 8 · 6.b)

- [ ] Backdrops appear ONLY on title / section-divider / the one "wow" slide — none behind data.
- [ ] Each `<svg class="slide-bg">` is the FIRST child of its slide and is NOT in the `.reveal` set.
- [ ] `--accent` passed to the generator matches the deck's `--accent-primary`.
- [ ] Motifs rotate (not the same motif on every divider); ≤ ~1 backdrop per 3–4 slides.
- [ ] Every heading over a backdrop is comfortably readable (scrim added only if needed).
