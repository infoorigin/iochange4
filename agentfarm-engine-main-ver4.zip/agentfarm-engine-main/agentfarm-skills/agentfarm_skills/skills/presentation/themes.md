# Presentation Themes — one SYSTEM, per-client configurable brand

## The model: fixed system, swappable brand

The deck's **design system is constant** — the type scale, composition, the block
language (kicker / action-title / rule / seam / block-grid / chip-list / section
divider), the exhibit style. What is **configurable per client** is the **brand**:
a small set of `:root` tokens (one accent + the neutral surfaces + fonts). Swap the
tokens → the same premium system wears a different client's brand. Never fork the
structure per client; only the tokens change.

Premium is structural, so **any** valid brand token set still looks board-ready —
imagery is never required (see `imagery.md`, R14).

## Brand resolution (precedence — highest wins)

When building a deck, resolve the brand in this order:

1. **User / goal states brand colors** ("use our brand red #C8102E", "dark deck") →
   use them.
2. **Client brand config file** — `{{metadata_dir}}/brand.yaml` if present (a client
   deployment bundles this in its pack; read it and map to `:root`). Schema below.
3. **Workflow `vars:`** — a workflow may set `brand_accent`, `brand_paper`, etc.
4. **Default** — the **Graphite & Signal** token set below.

### `brand.yaml` schema (client deployments drop this in their pack `metadata/`)

```yaml
# metadata/brand.yaml — a client's brand. Every field optional; unset → system default.
name: "Acme Corp"
accent: "#C8102E"          # THE signal accent (the one required brand color)
accent_secondary: "#9E0C24" # darker accent for on-tint text; else derive ~20% darker
paper: "#F6F6F3"           # page background; keep warm off-white unless brand demands
ink: "#15171E"             # primary text; keep near-black on light paper
mode: "light"              # light | dark  (dark → Executive Ink surfaces)
font_display: "Plus Jakarta Sans"
font_body: "Inter"
logo_wordmark: "ACME"      # optional — small wordmark for the title kicker line
```

Map it to the full token set: `accent`→`--accent-primary`,
`accent_secondary`→`--accent-secondary`, `--accent-muted` = accent at ~10% tint,
`--kicker-on-ink` = accent ~55% lighter, `paper`→`--bg-primary`, `ink`→`--text-primary`,
and derive `--bg-secondary`/`--card-bg`/`--border-color`/`--text-secondary`/`--text-muted`
from the neutrals. Fill any unset field from the default below.

## Default token set — "Graphite & Signal"

Used when no brand is configured. Complete set (all tokens are required — the block
language references `--text-muted`, `--ink-panel`, `--kicker-on-ink`, `--pos`/`--neg`):

```css
:root {
  --bg-primary:#F6F6F3;      /* warm off-white paper — never stark #fff */
  --bg-secondary:#EEEFEA;
  --card-bg:#FFFFFF;
  --ink-panel:#15171E;       /* full-bleed section-divider panel */
  --text-primary:#15171E;
  --text-secondary:#565C6B;
  --text-muted:#9AA0AD;
  --accent-primary:#3A4DE0;  /* the default brand accent */
  --accent-secondary:#2233B8;
  --accent-muted:#ECEEFC;
  --kicker-on-ink:#B9C0FF;
  --border-color:#E4E5E1;
  --pos:#12805C; --neg:#C0392B;
  --font-display:'Plus Jakarta Sans', sans-serif;
  --font-body:'Inter', sans-serif;
}
```
Google Fonts: `Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700`

## Ready-made client brand presets (examples — copy + tweak per client)

Each is just the tokens that differ from the default; everything else inherits.

```css
/* Crimson (e.g. a red-brand client) */  --accent-primary:#C8102E; --accent-secondary:#9E0C24; --accent-muted:#FBE9EC; --kicker-on-ink:#FF9AA8;
/* Forest  (sustainability / health)  */ --accent-primary:#1F7A54; --accent-secondary:#155C3F; --accent-muted:#E5F1EB; --kicker-on-ink:#8FD9B6;
/* Slate Navy (finance / gov)         */ --accent-primary:#1B365D; --accent-secondary:#122543; --accent-muted:#E8EDF4; --kicker-on-ink:#9DB4D6;
/* Amber (industrial / logistics)     */ --accent-primary:#B26A00; --accent-secondary:#8A5200; --accent-muted:#FBF0DE; --kicker-on-ink:#F2C879;
```

### Executive Ink (dark mode — `mode: dark`)

```css
:root {
  --bg-primary:#101218; --bg-secondary:#171A22; --card-bg:#1B1F29; --ink-panel:#0A0B0F;
  --text-primary:#F2F3F5; --text-secondary:#AEB4C0; --text-muted:#727884;
  --accent-primary:#7B8CFF; --accent-secondary:#AAB5FF; --accent-muted:rgba(123,140,255,0.14);
  --kicker-on-ink:#AAB5FF; --border-color:rgba(255,255,255,0.10);
  --pos:#3DD68C; --neg:#F0616B;
  --font-display:'Plus Jakarta Sans', sans-serif; --font-body:'Inter', sans-serif;
}
```
(For a dark client, keep the client's `accent`; only swap the surfaces to the above.)

## Contrast rules (enforce for any brand)
- `--accent-primary` must clear **4.5:1** against `--bg-primary` AND against white (chips/section text sit on the accent).
- `--accent-secondary` (on-tint / total-row text) must clear 4.5:1 on `--accent-muted` and on paper.
- Light paper → ink text; dark mode → light text. Prefer warm off-white paper over stark `#fff`.
- If a client's accent fails contrast on white chips, darken `--accent-primary` a step for the chip/section use — don't ship an illegible brand.
