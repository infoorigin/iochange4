---
name: presentation
description: Build AND edit enterprise-grade slide decks. Mode A — convert a markdown report into a visually stunning HTML deck (→ PPTX/PDF), enforcing layout variety, density caps, and consulting-firm aesthetic. Mode B — edit an existing .pptx in place (update numbers/dates/tables, add designed slides, drop/reorder) via scripts/pptx_tool.py, see editing.md. Shared skill — available to every agent.
---

# Presentation Skill (markdown → deck)

Convert any structured markdown document (intelligence report, strategy plan, compliance review, ad-hoc writeup) into a self-contained HTML presentation that looks like it came out of McKinsey / BCG / Bain / Deloitte.

**Shared skill.** Every workflow agent (analyst, domain_consultant, reviewer, jarvis, queryngine, etc.) inherits this via `_common/skills/`.

## Two modes — author (A) or edit (B)

- **Mode A — author a new deck from markdown** (the default; Steps 1–10 below). HTML is the
  canonical artifact → native PPTX/PDF.
- **Mode B — edit an EXISTING `.pptx`** the user gives you (update numbers/dates/vendor
  names, fix a table cell, drop/reorder slides, or add new designed slides). There's no
  HTML source, so you edit the OOXML in place with `scripts/pptx_tool.py`. **Full playbook:
  `editing.md`.** The design system still lives here in the same skill: surgical edits
  preserve the host deck's design (don't re-skin it); *new* slides get the full Mode-A
  craft (layouts, `dataviz`, `imagery.md`) themed to the host, then merged with `append-deck`.

Pick the mode from the request (see triggers below), then follow that mode's steps.

## When to use — OPT-IN ONLY

**This skill is NEVER auto-triggered.** It runs only when the user explicitly asks for a presentation. Workflow agents must NOT invoke it as part of their normal step execution — the MD deliverable is the step's output; a deck is a separate, on-request artifact.

Trigger ONLY when the user explicitly says something like:
- "turn this into a deck" / "make a PPT" / "make a PowerPoint"
- "export as slides" / "generate slides" / "slide deck"
- "build a presentation from <file>"
- "board-ready deck" / "exec presentation" / "present this"
- Any direct imperative referencing slides, a deck, or a presentation
- **Mode B (edit):** "update this deck" / "change slide 3" / "fix the numbers in this pptx" /
  "add a slide to <file.pptx>" / "reorder / drop a slide" — any request to modify a `.pptx`
  the user supplies. Go to `editing.md`.

Do NOT trigger on:
- Completion of a workflow step (even if the MD deliverable is ready)
- Goal text containing words like "executive" or "board" without an explicit slide/deck ask
- Agents reasoning that "this would make a nice deck" — it's the user's call, not the agent's

If the user's request is ambiguous (e.g., "can you summarize this for leadership?"), produce a summary, NOT a deck. Only the words *deck / slides / presentation / PPT / PowerPoint* unlock this skill.

## Input contract

Primary input: a **markdown document path** (or raw markdown string). That document drives the entire deck.

```
# Point at the MD file the step just assembled
cat {{output_dir}}/intelligence_report.md   # or any other .md
```

Secondary input (optional):
- `theme`: one of `swiss` (default), `executive_dark`, `modern`, `minimal`, or a custom brand color like `#1B365D`. See `themes.md`.
- `title`: override the deck title (default: derive from first `#` heading in the MD)
- `subtitle`: secondary line under the title (default: derive from the goal or first paragraph)

## Step 1 — Plan mode: write the slide plan to disk FIRST

**CRITICAL:** Never generate the entire HTML deck in one shot. The provider's streaming API fails on single large outputs (>10 min or >~30 KB). The pattern that works — proven for MD reports, same shape here — is **plan → shell → per-slide files → assemble**.

Read the MD file. Think through the slide plan. Then **write the plan as the first file on disk**, before any HTML:

```
write_file {{output_dir}}/_slide_plan.md
```

Format of `_slide_plan.md`:

```markdown
# Slide Plan — <deck title>
Source: <path to input MD>
Theme: <swiss | executive_dark | modern | minimal | custom #hex>
Total slides: <N>
Story arc: Hook (1-2) → Context (3-4) → Findings (5-8) → Insight (9-10) → Action (11-12) → Proof (13-14)

| # | Layout | Action Title (assertion, not noun) | Source MD section | Focal element | Density (bullets/rows/cards) |
|---|--------|-----------------------------------|-------------------|---------------|------------------------------|
| 1 | L1 Title | "BD IT Vendor Portfolio — FY26 Planning Intelligence" | (cover) | big title | - |
| 2 | L2 Agenda | "Five findings, five recommendations, one 18-month plan" | (derived) | numbered list | 5 items |
| 3 | L3 Divider | "Part I — The Portfolio Today" | (derived) | section title | 1 tagline |
| 4 | L4 KPI grid | "$100.45M across 16 vendors with 40% top-3 concentration" | ## Executive Summary | 4 KPI cards | 4 cards |
| 5 | L5 Bullet+visual | "AWS alone is 17% — 40% above top-quartile ceiling" | ## Top Vendors | bar chart | 5 bullets + 1 chart |
| ... | ... | ... | ... | ... | ... |
```

### Heading → slide boundary rules
- Every MD `##` section maps to at least one slide — maybe more if content exceeds the layout's density cap
- `###` subsections under a `##` become child slides when the parent exceeds density, otherwise subheadings within the same slide
- A section whose content fits ≤ the density cap of its chosen layout stays a single slide; otherwise split into `<section>a`, `<section>b`, etc.

**Do NOT produce a 1:1 section-to-slide mapping if that means cramming.** Density > fidelity.

### Plan validation checklist (before moving to Step 2)
- [ ] Every title in the plan is an **assertion** (R1) — a complete sentence stating a finding, not a noun phrase
- [ ] No two consecutive rows use the same layout (rotation rule)
- [ ] Each layout respects its density cap
- [ ] Total slides fits the story arc (Hook → Context → Findings → Insight → Action → Proof)
- [ ] One "wow" slide exists (quadrant L10, quote L12, waterfall L14, or striking divider L3)

## Step 2: Pick the right layout per section — THE LAYOUT TAXONOMY

This is the core of producing a stunning deck. Map each parsed section to the best layout from the taxonomy below. **Never use the same layout twice in a row.** Rotate aggressively.

### L1 — Title / Hero (opening slide only)
Big title, subtitle, date, footer. Use `.title-slide` class.
- Trigger: always slide 1
- Density cap: 1 title + 1 subtitle + 1 meta line
- Optional: an abstract SVG backdrop (`--motif corner --context cover`) — see `imagery.md`

### L2 — Agenda / TOC
Numbered list of chapters with one-liner each. Use a 2-column split.
- Trigger: always slide 2 for decks > 5 slides
- Density cap: 5-7 numbered items, each with a 6-10 word descriptor

### L3 — Section divider
Full-bleed colored block with just the section name (accent bg, white text).
- Trigger: between the major parts of a long deck (before "Analysis", before "Strategy", before "Review")
- Density cap: 1 heading + optional 1 tagline
- Optional: an abstract SVG backdrop (`--context divider`) — the prime home for imagery. See `imagery.md`

### L4 — Executive KPI grid
3-4 large metric cards in a row, each with a big number and short context. Use `.card-grid` + `.metric-card`.
- Trigger: executive summaries, "key findings at a glance", top-line numbers
- Density cap: 3-4 cards max, each with (label, big_number, delta or one-liner)
- Example: `$100.45M · 16 vendors · 40% top-3 concentration · 4 GxP systems`

### L5 — Bullet + visual (60/40 or 50/50 split)
Bullets on the left, a chart/table/illustrative block on the right. Use `.two-column`.
- Trigger: narrative findings that benefit from a side visual (a table, a chart, a ranked list)
- Density cap: left side 4-6 bullets; right side 1 table ≤ 7 rows OR 1 chart OR 1 callout card
- This is your workhorse — use liberally for findings, recommendations, diagnosis

### L6 — Data table (an *exhibit*, per `dataviz`)
A table that argues a point — not a spreadsheet. Uses `.data-table`; design it with the **`dataviz`** table rules: encode magnitude in-cell (data bars / Harvey balls / heat on the key column), sort by what matters, right-align tabular numbers with the unit in the header, emphasize the takeaway row, line-light (no vertical rules).
- Trigger: comparison data (vendor ranking, contract list, KPI-by-segment)
- Density cap: ≤ 7 rows × ≤ 6 columns. Split into follow-up slide if more.
- Always include a one-line "so what" below the table (the exhibit's assertion)
- Cap by dropping **rows**, never the owner / by-when / assumption / success-metric columns when the source has them (see R2b)

### L7 — Two-column compare (vs)
Two parallel blocks with a center divider. "Before / After", "Option A / Option B", "Baseline / Target".
- Trigger: any comparison of two choices or states
- Density cap: each column = 1 subheading + 3-5 bullets
- Center divider can be a small `vs` chip

### L8 — Three-column (scenarios)
Three parallel panels. Conservative / Expected / Optimistic. Wave 1 / Wave 2 / Wave 3.
- Trigger: three-scenario financials, three-phase roadmaps, triads
- Density cap: each column = 1 heading + 3 bullets + 1 KPI number

### L9 — Timeline / roadmap
Horizontal connected milestones along a timeline axis.
- Trigger: phased plans, transformation roadmaps, renewal pipeline by quarter
- Density cap: ≤ 6 milestones. Each: date/quarter label + 1-line action
- Use alternating above/below placement for readability
- Carry the per-milestone success metric and/or review cadence when the source defines it (see R2b)

### L10 — 2×2 quadrant (priority matrix)
Four-quadrant grid with an axis title on each side. Populate with labeled items.
- Trigger: BCG matrix, priority-vs-effort, risk-vs-reward, impact-vs-urgency classifications
- Density cap: ≤ 3 items per quadrant. Each item = short label + tiny number
- Label the axes clearly (e.g., Impact ↑ / Urgency →)
- Annotate each item with its owner when the source names one (see R2b)

### L11 — Card grid (findings)
3-6 cards in a responsive grid. Each card = icon/category + heading + 2-3 bullets.
- Trigger: risk inventory (RO-XX), signal list (SIG-XX), recommendations (R-XX) list
- Density cap: ≤ 6 cards per slide. Split by severity (CRITICAL / HIGH / MEDIUM) if more.
- Tag chips for severity using the `.tag` + `.severity-critical/high/medium` classes

### L12 — Quote / callout
Big pulled quote, author attribution, minimal chrome.
- Trigger: stakeholder voice, analyst benchmark citation, principle statement
- Density cap: ≤ 30 words quote + attribution
- Use once per deck max, for emphasis

### L13 — Process flow
Horizontal connected boxes with arrows between.
- Trigger: workflows, approval chains, methodologies
- Density cap: ≤ 5 boxes, each with 2-3 word label

### L14 — Savings waterfall
Stepped bars: gross → addressable → achievable → net. Custom SVG or styled divs.
- Trigger: business case, savings decomposition
- Density cap: 4-5 steps, each with dollar value
- **Segment heights must be proportional to value** on a shared baseline — compute each bar's height from its number, don't eyeball it (per `dataviz`)
- Add a one-line **sourced assumptions footnote** naming the 1–3 drivers behind the case when the source provides them (see R2b) — never invent them

### L15 — Appendix / sources
Dense small-text layout. Citations, methodology, data lineage.
- Trigger: last slide(s); evidence trail
- Density cap: 10-15 items, condensed typography

### L16 — Closing / CTA
Simple centered block with next steps, owners, deadlines.
- Trigger: last slide before appendix
- Density cap: 3-5 next-step bullets with owner (role) and timeline

## Layout selection rules (enforced)

1. **Rotate.** No two consecutive slides may use the same layout. If the natural choice is a repeat, either (a) split into two halves and use adjacent-but-different layouts, or (b) insert a divider (L3) or quote (L12) between them.
2. **Density cap is hard.** If content exceeds a layout's cap, split across multiple slides. Never overflow.
3. **Prefer showing over telling.** Numbers get KPI cards (L4) or tables (L6). Decisions get two-column compare (L7). Phased content gets timelines (L9) or three-column (L8).
4. **Variety ≠ novelty.** Lean on L4 / L5 / L6 / L7 / L8 / L11 as the core 80%. L12 / L13 / L14 are spices — one or two per deck.
5. **Imagery is chapter-tone only.** Abstract SVG backdrops go on L1 (title), L3 (dividers), and at most the one "wow" slide — **never** behind data (L4/L5/L6/tables/charts). Optional; ≤ ~1 per 3–4 slides. Full rules + generator: `imagery.md`.

## Step 2.5: Visual craft rules — the difference between OK and stunning

Layout variety alone doesn't make a deck beautiful. These are the craft rules that separate a template output from something a senior consultant would present. Every slide must pass these checks.

### R1 — Action titles, not topic titles (McKinsey rule)

The slide title is a **complete assertion**, not a noun phrase. It states the finding; the body is the proof.

- ❌ "Vendor Spend Analysis"
- ✅ "AWS at 17% of IT spend is 40% above the top-quartile concentration ceiling"
- ❌ "Recommendations"
- ✅ "Five renegotiations worth $3.5M are ready to execute this fiscal year"
- ❌ "Contract Renewal Pipeline"
- ✅ "$19.6M in 7-vendor contracts expire in 2026 — Q2 is the critical window"

If you cannot write an action title for a slide, the slide has no finding and should be cut.

### R2 — One focal point per slide

Every slide has a single visual anchor — a number, a chart, a table, a quote. Everything else supports it hierarchically. Readers should know instantly where to look first.

- In L4 (KPI grid): the biggest number is the focal point; labels are secondary
- In L5 (bullet + visual): the visual is focal; bullets support it
- In L6 (data table): one cell or row is the "so what" — use `--accent-primary` color or bold
- In L7 (compare): the "winning" side may be subtly emphasized with accent background

Never present two things of equal visual weight on one slide — pick the hero.

### R2b — Exhibit column fidelity: keep the "so-what" columns

When you compress a source table into an exhibit (L6, L10, L11, L14, L9) you may drop **rows** to hit the density cap — but you must **keep the columns that carry the executive so-what**. Four column types turn a data table into a *decision* exhibit; do not strip them for visual tidiness:

- **Owner / accountable role** — who is on the hook
- **By-when / deadline** — the timing commitment
- **Key assumption or basis** — what a number depends on (esp. behind a scenario or projection)
- **Success metric** — how the outcome will be measured

Rules (each of the four is independent — none is tied to any particular layout):
- **If a source table has one of these columns, it MUST appear somewhere in the deck** — on whatever slide or exhibit carries that data. The *form* follows the layout you happen to use: a table column, an in-card line, an annotation on a quadrant/card item, a footnote on a waterfall/scenario panel, a KPI card, or a line on the closing slide. Pick the vehicle the deck actually has; do not silently discard the data because the "obvious" layout for it isn't in this deck.
- **Do not condition a column on a specific layout.** A success metric belongs in the deck whether or not there's a roadmap; an assumption belongs whether or not there's a waterfall; an owner belongs whether or not there's a quadrant. If the natural home layout is absent, the column rides the nearest exhibit that shows the related number, or a one-line footnote — it does **not** get dropped.
- **If the source does NOT provide it, omit it silently** — do **not** invent an owner, assumption, deadline, or metric. Fabricated accountability is worse than an absent column. (Same grounding contract as every figure: nothing on a slide that isn't in the source.)

**Coverage check before finalizing:** scan every source table for the four column types. For each one that is present in the source, confirm it appears at least once somewhere in the deck — on any slide, in any form. This check is layout-agnostic by design: it asks "is the decision data on a slide?", never "is it on the roadmap/waterfall/quadrant?"

Density-capping a table by dropping these columns is the most common way a strong analysis renders as a weak deck: the numbers survive but the *decision* — who, by when, on what basis, measured how — is lost.

### R3 — Typography scale (projection-ready)

Use these clamp() ranges. They scale across laptop → projector → 4K display without recompute:

| Element | Clamp range | Weight |
|---|---|---|
| Slide action title | `clamp(1.75rem, 3.2vw, 2.75rem)` | 700-800 |
| Section divider title (L3) | `clamp(3rem, 6vw, 5rem)` | 800 |
| KPI big number (L4) | `clamp(2.5rem, 5vw, 4rem)` | 800, `font-feature: tabular-nums` |
| H2 subheading | `clamp(1.25rem, 2vw, 1.5rem)` | 600 |
| Body / bullets | `clamp(0.95rem, 1.4vw, 1.1rem)` | 400-500 |
| Caption / footer / attribution | `clamp(0.75rem, 1vw, 0.9rem)` | 500, `--text-secondary` |

Body copy on a slide should almost never exceed 1.1rem at native size. If it does, you're cramming.

### R4 — Whitespace is a first-class design element

- Leave at least **64-96px (4-6 × base unit)** of padding inside every slide edge
- Between grouped content and header: at least **40-56px**
- Between cards in a grid: at least **16-24px** gap
- Never let any element touch another without intentional spacing

Density is about bullet count, whitespace is about the blank space *around* the content — both matter independently.

### R5 — Restrained color palette

- **Use the accent color sparingly** — rule of thumb: accent appears on ≤ 20% of any given slide. If the whole slide is colored, nothing stands out.
- **Primary text on primary background**; accent only for headings, callouts, focal numbers, chart emphasis
- **Semantic colors** (success/warning/danger) only for severity chips and status tags — never as body text color
- **No gradients on body text, no rainbow charts.** One chart = one accent + grayscale variants

### R6 — Charts & tables: use the `dataviz` skill

Every chart AND every data table in the deck follows the **`dataviz`** skill — **load it before building any L5 / L6 / L14 visual.** It owns:
- **Chart-type selection** (the form heuristic — bar for ranking, line for trend, KPI tile for a headline number, never a pie > 3 slices, never dual-axis).
- **Color by job** — deck **theme colors lead** (from `themes.md` / the corporate template), Okabe-Ito as the accessible fallback; categorical hues in fixed order, same category same color on every slide.
- **Tables as exhibits** — in-cell **data bars**, **Harvey balls** (`○◔◑◕●`) for qualitative ratings, **heat** on the one key value column, right-aligned tabular numbers, line-light minimalism (no vertical rules), emphasis on the takeaway row. A McKinsey-grade table argues a point; it is not a spreadsheet.

Author charts as inline **SVG** and tables as clean HTML so they export unchanged to pptx / pdf / html. Deck-specific additions on top of `dataviz`:
- Chart/table **title = a short assertion** of what it shows (same rule as slide titles).
- **Source / methodology** in small caps below ("Source: spend_data.spend_cube, FY26 Q1").
- One theme accent for the highlighted series/row; muted grayscale for the rest.

### R7 — Iconography

- Icons are monochrome and use the accent color, nothing else
- Lucide icons only (already common across our apps). Embed as inline SVG, 16-24px
- Use icons **only** when they add orientation (e.g., risk/severity chips, arrows on a process flow). Never decorative.

### R8 — Consistent footer on every content slide

Every non-title, non-divider slide shows a thin footer:

```
[DECK TITLE]                                          [N / TOTAL]
```

- Left: deck title in `--text-secondary`, caption size
- Right: current slide number / total — same style, tabular-nums
- Height: `~28px`
- Separator: 1px hairline in `--border-color`

This gives projection presence without visual weight.

### R9 — Motion: subtle, not performative

- Reveal animations: 200-300ms ease-out, 50-80ms stagger between siblings
- Entry direction: fade-in + 8px translate-y. Never from far off-screen. Never rotations.
- Slide transitions: instant change on navigation (keyboard/scroll). Do NOT animate slide-to-slide — the content reveal IS the animation.
- Progress bar at top: thin (2-3px), accent color, smooth width transition on nav

### R10 — Story arc (build an argument, don't dump sections)

A deck is not a dump of the MD sections. It's a **narrative**:

1. **Hook** (L1 title, L4 KPI grid) — what's the state of the world in 30 seconds
2. **Context** (L3 divider, L5 bullet+visual) — how we got here
3. **Findings** (L6 tables, L11 card grids) — what we observed, with evidence
4. **Insight** (L10 quadrant, L7 compare) — the "so what" — synthesis
5. **Action** (L8 3-column scenarios, L9 timeline, L16 CTA) — what we recommend
6. **Proof** (L14 waterfall, L15 appendix) — the math and sources backing the above

When translating MD → slides, check that the deck builds this arc. If your deck is "Section 1 → 4 slides, Section 2 → 4 slides, …" with no arc, restructure.

### R11 — Empty-state discipline

If you don't have content for a layout slot, DO NOT fill it with filler. Leave it empty and resize the rest, or drop the slot. Never add "TBD" / "more content coming" / lorem-ipsum.

### R12 — One "wow" moment per deck

Every deck needs one slide that's visually memorable — a quadrant (L10), a striking quote (L12), a big waterfall (L14), or a full-bleed section divider (L3) with a striking phrase. This is what people remember; give the deck at least one.

### R13 — Every content slide earns a visual; no bare bullet slides

A heading + a bullet list is the boring-deck failure state. Every content slide carries
**one** focal visual — a KPI card (L4), a chart or exhibit table (`dataviz`), or a **visual
device** from `visual_devices.md` (hero stat, progress ring, comparison bars, callout,
pull-quote, icon grid, feature list, chapter card). One focal device per slide (R2) — don't
stack them; rotate them like layouts. Genuine data still goes through `dataviz`; devices are
for emphasis and variety. Imagery backdrops (`imagery.md`: abstract SVG or duotone photo)
dress the title/dividers/"wow" slide only — never behind data.

### R14 — Premium is STRUCTURAL. Visual appeal is non-negotiable; imagery is optional

The deck's canonical look is the **"Graphite & Signal"** system (`themes.md` default,
`viewport-base.css` block language). Premium comes from the **type scale, ink + one
brand accent, composition, and the block language** — never from imagery. The **design
system is fixed; the brand is configurable per client** — resolve the brand tokens per
`themes.md` (user request > `metadata/brand.yaml` > workflow vars > default), then keep
the structure identical. Two hard rules:

1. **Visual appeal is non-negotiable and comes from structure.** Every content slide is
   built on the same spine — **kicker → action-title (an assertion) → accent rule → one
   focal block → optional seam takeaway → footer** (`html-template.md` composition rules).
   Fill the canvas; no dead lower-half. Use the **block language** as the default vocabulary
   (`.kicker`, `.rule`, `.seam`, `.block-grid`/`.block`, `.chip-list`, `.two-col` + exhibit)
   and a **full-bleed ink `.section-slide`** before each major part. A deck with **zero
   images must already look board-ready.**
2. **Imagery is optional and removable.** A backdrop is a garnish on title/section slides
   only; deleting the one `<svg class="slide-bg">` line must leave a premium slide behind.
   Never make a slide *depend* on a backdrop, and never put one behind data. Some users
   don't want imagery — the default look must not need it.

## Step 3: Pick the theme

Check the user's request:

| Signal | Theme |
|---|---|
| None given | **Swiss Consulting** (default) |
| "executive" / "premium" / "board" | **Executive Dark** |
| "modern" / "tech" / "data" | **Modern Corporate** |
| "minimal" / "regulatory" | **Minimal Light** |
| Hex color provided (e.g., `#1B365D`) | Build custom `:root` with that color as `--accent-primary` |
| Brand name provided (BD = `#CC092F`, etc.) | Use provided brand color scheme |

See `themes.md` for full `:root` blocks and contrast rules.

## Step 4 — Write the HTML SHELL (one small write_file)

Generate the shell file that contains everything EXCEPT the slide `<section>` bodies. This is a single `write_file` call, ~6-10 KB — well under any stall threshold.

```
write_file {{output_dir}}/_deck_shell.html
```

Contents (exactly in this order):
1. `<!DOCTYPE html>`, `<html>`, `<head>` with theme font `<link>`
2. `<style>` block containing:
   - The full theme `:root { ... }` (from `themes.md`)
   - The ENTIRE `viewport-base.css` inlined
   - Theme-specific overrides (title-slide, section-slide, metric-card, tag, severity classes — see `html-template.md`)
3. `<body>` opening tag
4. `<!-- SLIDES_GO_HERE -->` **marker comment** (exact string; the assembly step replaces this)
5. The `<script>` block with the `SlidePresentation` JS class (from `html-template.md`)
6. `</body></html>`

Rules for the shell:
- Inline `viewport-base.css` IN FULL — do not reference it as `<link>`
- Theme `:root` variables at the very top of `<style>`
- Every slide must render at `height: 100vh; overflow: hidden` — **non-negotiable**
- Google Fonts loaded via `<link>` in `<head>` per theme
- The `SlidePresentation` JS class handles keyboard nav, touch/swipe, wheel scroll, progress bar, nav dots, IntersectionObserver animations

## Step 5 — Write each slide to its OWN file (one write_file per slide)

One file per planned slide. Each file contains **only** one `<section>...</section>` block — NOT a full HTML document. File size: ~1-3 KB per slide. Well under stall threshold.

Canonical filename: `_slide_NN_<short_slug>.html` where `NN` is zero-padded 2-digit order.

```
write_file {{output_dir}}/_slide_01_title.html
write_file {{output_dir}}/_slide_02_agenda.html
write_file {{output_dir}}/_slide_03_divider_part_i.html
write_file {{output_dir}}/_slide_04_kpi_grid.html
write_file {{output_dir}}/_slide_05_aws_concentration.html
write_file {{output_dir}}/_slide_06_renewal_pipeline.html
...
```

Each slide file:
- Starts with `<section class="slide ..." id="slide-NN">` (NN matches the filename)
- Contains `<div class="slide-content">...</div>` with all content
- Includes `<span class="slide-number">NN</span>`
- Every content element has `class="reveal"` for the animation
- Ends with `</section>`

**Efficiency rule:** write **3-4 independent slide files in ONE parallel tool-use turn** (multiple `write_file` tool_use blocks in a single assistant response). 12 slides = 3-4 turns, not 12. Each stream is small, the round-trips are few.

## Step 6 — Assemble the final deck

Concatenate the shell with all slide fragments. The glob `_slide_*.html` expands in lexical order because of the `_slide_NN_` naming:

```
exec: sed "/<!-- SLIDES_GO_HERE -->/{s/<!-- SLIDES_GO_HERE -->//;r /dev/stdin
}" {{output_dir}}/_deck_shell.html < <(cat {{output_dir}}/_slide_*.html) > {{output_dir}}/presentation.html
```

If `sed` substitution feels fragile on your shell, use the simpler split-and-cat:

```
# Python helper (one-shot inline; does NOT violate "no helper scripts" rule because it's <5 lines and inline)
python -c "
import pathlib, re
out = pathlib.Path(r'{{output_dir}}')
shell = (out / '_deck_shell.html').read_text(encoding='utf-8')
slides = '\n'.join(p.read_text(encoding='utf-8') for p in sorted(out.glob('_slide_*.html')))
(out / 'presentation.html').write_text(shell.replace('<!-- SLIDES_GO_HERE -->', slides), encoding='utf-8')
"
```

Expected result: one file `presentation.html` containing the shell with all slides spliced at the marker location.

## Step 7 — Preview + publish

Tell the user:
> "Deck ready — `{{output_dir}}/presentation.html`, N slides. Open in a browser; use arrow keys / scroll to navigate."

Optional: for a workflow run, publish it as an artifact so it syncs to S3:
```
aicore run-output --run-id <run_id> --publish presentation.html --role <your_role>
```

## Step 8: Self-review (MUST pass before declaring done)

Read the HTML back and verify two separate checklists:

### 6.a Structural checks

- [ ] Title slide is slide 1, agenda is slide 2 (for decks > 5 slides)
- [ ] Sequential `id="slide-N"` with no gaps or duplicates
- [ ] No two consecutive slides share the same layout
- [ ] Every slide respects its density cap (count bullets, cards, rows)
- [ ] `:root` variables match the requested theme/brand
- [ ] `viewport-base.css` is fully inlined
- [ ] `SlidePresentation` JS class is included
- [ ] Font `<link>` matches the theme's `--font-display` / `--font-body`
- [ ] Every `class="reveal"` element present
- [ ] No unsourced claim: numbers and quotes in the deck trace to something in the source MD

### 6.b Visual craft checks (per Step 2.5 rules)

- [ ] **R1** — Every content slide title is an assertion (complete sentence), not a noun phrase
- [ ] **R2** — Every slide has one visual focal point; no two elements of equal weight
- [ ] **R3** — All font sizes use the clamp() ranges from R3 (check for any hardcoded px values)
- [ ] **R4** — Every slide has ≥64px padding from the edge; grids have ≥16px inter-card gap
- [ ] **R5** — Accent color appears on ≤20% of any slide's surface
- [ ] **R6** — Any chart has a 1-line assertion title, a source line, direct labels (no legend boxes for ≤3 series), no gridlines or 3D
- [ ] **R7** — Icons (if used) are monochrome in accent color, ≤24px
- [ ] **R8** — Every non-title, non-divider slide has the consistent footer (`[DECK TITLE] ... [N / TOTAL]`)
- [ ] **R9** — Reveal animations are 200-300ms with 50-80ms stagger; no slide-to-slide transition animations
- [ ] **R10** — The deck builds a narrative arc (Hook → Context → Findings → Insight → Action → Proof), not a section dump
- [ ] **R11** — No empty filler ("TBD", "lorem ipsum", placeholder boxes)
- [ ] **R12** — At least one visually memorable "wow" slide exists (quadrant / full-bleed divider / big quote / waterfall)
- [ ] **Imagery** (if used) — backdrops only on title / divider / "wow" slides, none behind data; each `<svg class="slide-bg">` is the slide's first child and not in `.reveal`; motifs rotate. Full list: `imagery.md`

### 6.c Visual QA — render the slides and LOOK at them (mandatory)

The checks above read the HTML *source*. They are blind to how it actually renders —
overflow, overlapping elements, text unreadable over a backdrop, uneven gaps. Those
only show up in a picture of the slide. Before declaring done, run the **visual QA loop**:

```bash
node skills/presentation/slides_export.js --input {{output_dir}}/presentation.html --shots {{output_dir}}/_qa
```

Then read every `_qa/slide_NN.png`, list issues per slide, fix at the `_slide_NN` source,
re-render, and repeat until a full pass is clean. Full loop + inspection checklist:
**`visual_qa.md`**. (Vision-capable agents inspect directly; a non-vision model still
renders the PNGs and surfaces them for a human/vision reviewer.)

If ANY check fails (structural, visual, or visual-QA), fix before declaring done. A deck that would embarrass the user in front of the board is not ready — and you only know it's clean by looking at it.

## Step 9: Iterative refinement

When the user says "fix slide 3", "split slide 5", "change the accent to #1B365D":

1. Edit the specific **per-slide file** only: `_slide_NN_*.html`. Do NOT re-read the assembled `presentation.html` — that's a derived artifact.
2. If the change is theme-wide (accent color, font): edit `_deck_shell.html` and re-assemble (Step 6).
3. If splitting a slide: create a new `_slide_NN_*.html` with the correct NN; rename subsequent files so NN remains sequential. Because the glob `_slide_*.html` sorts lexically, you can also use the letter-suffix pattern (`_slide_05a_*`, `_slide_05b_*`) without renumbering the rest.
4. Re-run Step 6 (assemble).
5. Re-run Step 8 (self-review checks) on the assembled file.

## Step 10 (optional): Export to PPTX / PDF — the HTML is delivery-agnostic

The assembled HTML is the canonical deck. The **same file** renders to PDF and native editable PPTX; nothing about the layout/design/theming changes per format.

**One-time dependencies** (skip if already present in the environment):

```bash
npm install playwright dom-to-pptx pptxgenjs
npx playwright install chromium
```

**Export** (each `<section class="slide">` → one page/slide):

```bash
node skills/presentation/slides_export.js --input {{output_dir}}/presentation.html --output {{output_dir}}/presentation.pptx
node skills/presentation/slides_export.js --input {{output_dir}}/presentation.html --output {{output_dir}}/presentation.pdf
```

- **PPTX** goes through **dom-to-pptx** (v2.x) — a coordinate scraper that maps the DOM to **native, editable** PowerPoint shapes; inline **SVG charts stay vectors**, tables stay tables. (Screenshot-via-pptxgenjs is the automatic fallback if the browser stack is missing — non-editable.)
- **PDF** is Playwright's print at 1920×1080, one slide per page.

**Verify (required):** re-open the pptx and confirm it isn't empty — a broken export reports success but yields 0 slides:

```bash
python -c "from pptx import Presentation; p=Presentation('{{output_dir}}/presentation.pptx'); print('slides:', len(p.slides)); assert len(p.slides)>0"
```

## Reference files (same folder)

- `themes.md` — CSS theme variables, brand color derivation rules, contrast requirements
- `viewport-base.css` — baseline CSS; must be inlined into every generated deck
- `html-template.md` — full HTML skeleton, JS class, slide-type classes, tag styles
- `visual_devices.md` — **R13** the anti-boring vocabulary: hero stats, progress rings, comparison bars, callouts, pull-quotes, icon grids, feature lists, chapter cards (CSS in `viewport-base.css`)
- `imagery.md` — backdrops for title/divider/"wow" slides: abstract SVG (`scripts/gen_backdrop.py`) **or** duotone photo (`scripts/photo.py`)
- `visual_qa.md` — the mandatory render-and-look QA loop (Step 8 · 6.c) + per-slide inspection checklist
- `editing.md` — **Mode B**: edit an existing `.pptx` in place (surgical edits vs. designed additions) + `scripts/pptx_tool.py`
- `slides_export.js` — Node.js HTML → PPTX/PDF exporter, plus `--shots <dir>` (one PNG per slide, for visual QA)
- `scripts/pptx_tool.py` — inspect/replace-text/set-cell/delete/reorder/**add-image**/append-deck/unpack/repack for existing decks (Mode B)
- `scripts/photo.py` — duotone imagery: `fetch` (Openverse/Pexels/Unsplash, enterprise-safe licenses) + `duotone` (blend a local image)

## Rules summary

- **MD is the truth.** Every claim in the deck must be traceable to the input markdown. No invented numbers.
- **Layout rotates.** No two adjacent slides share a layout. L3 (divider) and L12 (quote) are palette cleansers.
- **Density is a cap, not a target.** Shorter slides win. If in doubt, split.
- **Theme is deploy-time.** Brand color via `--accent-primary`; rest of the palette derives from that + the chosen base theme.
- **Self-review is mandatory.** A deck that fails the Step 6 checklist is unfinished.
