#!/usr/bin/env python3
"""pptx_tool.py — inspect and edit an EXISTING .pptx (no HTML source needed).

For the lifecycle case the HTML-authoring `presentation` skill can't serve: a user
hands you a finished deck (last quarter's board deck) and wants it *updated* — new
numbers, dates, a renamed vendor, a dropped slide. That content lives only as OOXML
inside the .pptx, so we edit it in place.

Built on python-pptx (robust, already a dependency) for the common 80%, with raw
unpack/repack (zip) as the OOXML escape hatch for anything python-pptx can't reach.
Pure stdlib + python-pptx + lxml. All slide/row/col indices are **1-based** (what
inspect prints and what a human says).

Subcommands:
  inspect  FILE [--slide N] [--json]           structure: per-slide shapes you can target
  replace-text FILE --find S --replace S [--slide N] [--mode run|paragraph] [-o OUT]
  set-text FILE --slide N --shape M --text S [-o OUT]        set one shape's text
  set-cell FILE --slide N --shape M --row R --col C --text S [-o OUT]   table cell
  delete-slide FILE --slide N [-o OUT]
  reorder  FILE --order 1,3,2,... [-o OUT]
  add-image FILE --slide N --image IMG [--full-bleed] [--duotone] [--scrim] [-o OUT]
      Put a (user-provided) image on an existing slide — e.g. a full-bleed background
      blended into the deck palette (navy duotone) with a scrim so text stays legible.
  append-deck FILE --from OTHER.pptx [-o OUT]    append OTHER's slides (design-system bridge)
  unpack   FILE DIR                              explode the .pptx (OOXML escape hatch)
  repack   DIR FILE                              re-zip a dir into a .pptx
  render   FILE DIR                              PNG per slide for visual QA (needs LibreOffice)

Edits write in place unless -o/--output is given. inspect first, ALWAYS.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import shutil
import subprocess
import sys
import zipfile

# Reconfigure in place (do NOT replace sys.stdout with a new TextIOWrapper — that
# closes the buffer when this module is imported by a sibling, e.g. photo.py).
try:
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
except Exception:  # pragma: no cover
    pass

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE


# ---------------------------------------------------------------- shape helpers
def _shape_kind(shape) -> str:
    if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
        return "group"
    if getattr(shape, "has_table", False) and shape.has_table:
        return "table"
    if getattr(shape, "has_chart", False) and shape.has_chart:
        return "chart"
    if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
        return "picture"
    if shape.has_text_frame:
        return "text"
    return "other"


def _shape_text(shape) -> str:
    if shape.has_text_frame:
        return shape.text_frame.text
    return ""


def _iter_text_frames(shapes, loc):
    """Yield (label, text_frame) for every editable text frame under `shapes`,
    recursing into groups and table cells. `loc` is a human path prefix."""
    for i, shape in enumerate(shapes, start=1):
        here = f"{loc}/shape{i}"
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from _iter_text_frames(shape.shapes, here)
        elif getattr(shape, "has_table", False) and shape.has_table:
            for r, row in enumerate(shape.table.rows, start=1):
                for c, cell in enumerate(row.cells, start=1):
                    yield (f"{here}/cell[{r},{c}]", cell.text_frame)
        elif shape.has_text_frame:
            yield (here, shape.text_frame)


def _top_shape(slide, shape_idx: int):
    shapes = list(slide.shapes)
    if not (1 <= shape_idx <= len(shapes)):
        raise SystemExit(f"shape {shape_idx} out of range (slide has {len(shapes)} shapes)")
    return shapes[shape_idx - 1]


def _slide_at(prs, n: int):
    slides = list(prs.slides)
    if not (1 <= n <= len(slides)):
        raise SystemExit(f"slide {n} out of range (deck has {len(slides)} slides)")
    return slides[n - 1]


# -------------------------------------------------------- run-aware text replace
def _replace_in_text_frame(tf, find: str, replace: str, mode: str):
    """Returns (n_replaced, n_split_run_misses). mode 'run' preserves per-run
    formatting (may miss text split across runs); 'paragraph' joins runs first
    (thorough, collapses a matched paragraph to one run — lossy formatting)."""
    replaced = 0
    split_misses = 0
    for para in tf.paragraphs:
        runs = para.runs
        joined = "".join(r.text for r in runs)
        if find not in joined:
            continue
        total = joined.count(find)
        # run-level first (formatting-safe)
        run_hits = 0
        for r in runs:
            if find in r.text:
                run_hits += r.text.count(find)
                r.text = r.text.replace(find, replace)
        if run_hits >= total:
            replaced += run_hits
            continue
        # remaining hits are split across runs
        if mode == "paragraph" and runs:
            new_text = joined.replace(find, replace)
            runs[0].text = new_text
            for extra in runs[1:]:
                extra._r.getparent().remove(extra._r)
            replaced += total
        else:
            replaced += run_hits
            split_misses += (total - run_hits)
    return replaced, split_misses


# -------------------------------------------------------------------- commands
def cmd_inspect(a):
    prs = Presentation(a.file)
    slides = list(prs.slides)
    out = []
    for si, slide in enumerate(slides, start=1):
        if a.slide and si != a.slide:
            continue
        shapes = []
        for shi, shape in enumerate(slide.shapes, start=1):
            kind = _shape_kind(shape)
            entry = {"shape": shi, "kind": kind, "name": shape.name}
            if kind == "table":
                t = shape.table
                entry["rows"] = len(t.rows)
                entry["cols"] = len(t.columns)
                entry["cells"] = [[c.text for c in row.cells] for row in t.rows]
            else:
                txt = _shape_text(shape)
                if txt:
                    entry["text"] = txt
            shapes.append(entry)
        notes = ""
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text
        out.append({"slide": si, "shapes": shapes, **({"notes": notes} if notes else {})})
    if a.json:
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        for sl in out:
            print(f"── Slide {sl['slide']} " + "─" * 40)
            for sh in sl["shapes"]:
                head = f"  [{sh['shape']}] {sh['kind']:<7} {sh['name']}"
                if sh["kind"] == "table":
                    print(head + f"  ({sh['rows']}×{sh['cols']})")
                    for r, row in enumerate(sh["cells"], 1):
                        print(f"        row{r}: " + " | ".join(row))
                elif "text" in sh:
                    preview = sh["text"].replace("\n", " ⏎ ")
                    print(head + f"  “{preview[:80]}”")
                else:
                    print(head)
            if sl.get("notes"):
                print(f"  notes: “{sl['notes'][:80]}”")
    return 0


def _save(prs, a):
    out = a.output or a.file
    prs.save(out)
    return out


def cmd_replace_text(a):
    prs = Presentation(a.file)
    total, misses = 0, []
    for si, slide in enumerate(prs.slides, start=1):
        if a.slide and si != a.slide:
            continue
        frames = list(_iter_text_frames(slide.shapes, f"slide{si}"))
        if slide.has_notes_slide:
            frames.append((f"slide{si}/notes", slide.notes_slide.notes_text_frame))
        for label, tf in frames:
            n, m = _replace_in_text_frame(tf, a.find, a.replace, a.mode)
            total += n
            if m:
                misses.append((label, m))
    out = _save(prs, a)
    print(f"replaced {total} occurrence(s) of {a.find!r} → {a.replace!r}  →  {out}")
    if misses:
        print(f"⚠ {sum(m for _, m in misses)} split-run occurrence(s) NOT replaced "
              f"(text spans multiple runs). Re-run with --mode paragraph, or use set-text:")
        for label, m in misses:
            print(f"    {label}: {m} miss(es)")
    return 0


def cmd_set_text(a):
    prs = Presentation(a.file)
    shape = _top_shape(_slide_at(prs, a.slide), a.shape)
    if not shape.has_text_frame:
        raise SystemExit(f"shape {a.shape} on slide {a.slide} has no text frame (kind={_shape_kind(shape)})")
    shape.text_frame.text = a.text
    out = _save(prs, a)
    print(f"set slide {a.slide} shape {a.shape} text  →  {out}")
    return 0


def cmd_set_cell(a):
    prs = Presentation(a.file)
    shape = _top_shape(_slide_at(prs, a.slide), a.shape)
    if not (getattr(shape, "has_table", False) and shape.has_table):
        raise SystemExit(f"shape {a.shape} on slide {a.slide} is not a table (kind={_shape_kind(shape)})")
    t = shape.table
    if not (1 <= a.row <= len(t.rows) and 1 <= a.col <= len(t.columns)):
        raise SystemExit(f"cell [{a.row},{a.col}] out of range ({len(t.rows)}×{len(t.columns)})")
    t.cell(a.row - 1, a.col - 1).text = a.text
    out = _save(prs, a)
    print(f"set slide {a.slide} table[{a.row},{a.col}] = {a.text!r}  →  {out}")
    return 0


def cmd_delete_slide(a):
    prs = Presentation(a.file)
    sld_lst = prs.slides._sldIdLst
    ids = list(sld_lst)
    if not (1 <= a.slide <= len(ids)):
        raise SystemExit(f"slide {a.slide} out of range (deck has {len(ids)} slides)")
    sld_id = ids[a.slide - 1]
    # Drop the presentation→slide relationship FIRST so the slide part becomes
    # unreferenced (python-pptx only serializes reachable parts). Removing just the
    # sldId entry leaves an orphaned slideN.xml → "Duplicate name" warnings on save.
    prs.part.drop_rel(sld_id.rId)
    sld_lst.remove(sld_id)
    out = _save(prs, a)
    print(f"deleted slide {a.slide}; {len(list(sld_lst))} slide(s) remain  →  {out}")
    return 0


def cmd_reorder(a):
    prs = Presentation(a.file)
    sld_lst = prs.slides._sldIdLst
    ids = list(sld_lst)
    order = [int(x) for x in a.order.split(",")]
    if sorted(order) != list(range(1, len(ids) + 1)):
        raise SystemExit(f"--order must be a permutation of 1..{len(ids)} (got {order})")
    for el in ids:
        sld_lst.remove(el)
    for pos in order:
        sld_lst.append(ids[pos - 1])
    out = _save(prs, a)
    print(f"reordered to {order}  →  {out}")
    return 0


def _cover_crop(in_path, out_path, tw, th):
    """Resize+crop to exactly tw×th (cover, centered) so a full-bleed image fills the
    slide without stretching. Pillow only; caller falls back to stretch if unavailable."""
    from PIL import Image
    img = Image.open(in_path).convert("RGB")
    iw, ih = img.size
    scale = max(tw / iw, th / ih)
    img = img.resize((max(1, int(iw * scale + 0.5)), max(1, int(ih * scale + 0.5))))
    nw, nh = img.size
    left, top = (nw - tw) // 2, (nh - th) // 2
    img.crop((left, top, left + tw, th + top)).save(out_path, "PNG")
    return out_path


def _add_scrim(slide, prs, alpha_pct=38):
    """A semi-transparent black rectangle over the image so text on top stays legible
    (the 'blend' that keeps a photo from fighting the words)."""
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.dml.color import RGBColor
    from pptx.oxml.ns import qn
    rect = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    rect.line.fill.background()
    rect.shadow.inherit = False
    rect.fill.solid()
    rect.fill.fore_color.rgb = RGBColor(0x0F, 0x1E, 0x30)  # near-navy black
    srgb = rect.fill._xPr.find(qn("a:solidFill")).find(qn("a:srgbClr"))
    srgb.append(srgb.makeelement(qn("a:alpha"), {"val": str(int(alpha_pct * 1000))}))
    return rect


def cmd_add_image(a):
    from pptx.util import Inches
    prs = Presentation(a.file)
    slide = _slide_at(prs, a.slide)
    img, tmp = a.image, []
    # 'blend' the photo into the deck palette: bake a navy duotone (sibling photo.py).
    if a.duotone:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import photo
        duo = a.image + ".__duo.png"
        photo._bake_duotone(a.image, duo, a.accent, a.shadow, a.highlight)
        img, _ = duo, tmp.append(duo)

    if a.full_bleed:
        try:
            tw = 1920
            th = int(round(1920 * int(prs.slide_height) / int(prs.slide_width)))
            cov = a.image + ".__cover.png"
            _cover_crop(img, cov, tw, th); tmp.append(cov); img = cov
        except Exception:
            pass  # Pillow missing → stretch to fill
        pic = slide.shapes.add_picture(img, 0, 0, prs.slide_width, prs.slide_height)
        spTree = slide.shapes._spTree
        spTree.remove(pic._element); spTree.insert(2, pic._element)   # send behind all content
        if a.scrim:
            rect = _add_scrim(slide, prs, a.scrim_alpha)
            spTree.remove(rect._element); spTree.insert(3, rect._element)  # above image, below content
    else:
        w = Inches(a.width) if a.width else None
        h = Inches(a.height) if a.height else None
        slide.shapes.add_picture(img, Inches(a.left), Inches(a.top), w, h)

    out = _save(prs, a)
    for t in tmp:
        try: os.remove(t)
        except Exception: pass
    Presentation(out)  # re-verify opens
    how = "full-bleed behind content" + (" + scrim" if a.full_bleed and a.scrim else "") if a.full_bleed \
          else f"at {a.left}\",{a.top}\""
    print(f"added image to slide {a.slide} ({how}{', duotone-blended' if a.duotone else ''})  →  {out}")
    return 0


_NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
_NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _remap_images(src_slide, new_slide):
    """After a slide's shapes are deep-copied into new_slide, their <a:blip r:embed>
    still point at the SOURCE slide's relationships. Re-embed each image blob into the
    new slide's part (in document order) and rewrite embed ids so pictures survive the
    cross-deck copy. SVG/vector shapes and native tables carry no blip and copy as-is."""
    src_blips = list(src_slide.shapes._spTree.iter(f"{{{_NS_A}}}blip"))
    new_blips = list(new_slide.shapes._spTree.iter(f"{{{_NS_A}}}blip"))
    for src_blip, new_blip in zip(src_blips, new_blips):
        rid = src_blip.get(f"{{{_NS_R}}}embed")
        if not rid:
            continue
        try:
            blob = src_slide.part.related_part(rid).blob
            _, new_rid = new_slide.part.get_or_add_image_part(io.BytesIO(blob))
            new_blip.set(f"{{{_NS_R}}}embed", new_rid)
        except Exception:
            pass  # linked/exotic image — leave as-is; visual QA will surface it


def cmd_append_deck(a):
    import copy
    dst = Presentation(a.file)
    src = Presentation(a.src)
    # A blank layout to hang absolutely-positioned copied shapes on.
    blank = dst.slide_layouts[6] if len(dst.slide_layouts) > 6 else dst.slide_layouts[-1]
    added = 0
    for slide in src.slides:
        new_slide = dst.slides.add_slide(blank)
        for shape in list(slide.shapes):
            new_slide.shapes._spTree.append(copy.deepcopy(shape._element))
        _remap_images(slide, new_slide)
        added += 1
    out = _save(dst, a)
    Presentation(out)  # re-verify it opens
    print(f"appended {added} slide(s) from {a.src} → {out} "
          f"({len(list(Presentation(out).slides))} total; verified opens)")
    return 0


def cmd_unpack(a):
    os.makedirs(a.dir, exist_ok=True)
    with zipfile.ZipFile(a.file) as z:
        z.extractall(a.dir)
    print(f"unpacked {a.file} → {a.dir}/  (edit the XML, then: pptx_tool.py repack {a.dir} <out.pptx>)")
    return 0


def cmd_repack(a):
    # Zip the directory back into a .pptx. [Content_Types].xml must be present.
    if not os.path.exists(os.path.join(a.dir, "[Content_Types].xml")):
        raise SystemExit(f"{a.dir} is not an unpacked pptx ( [Content_Types].xml missing )")
    if os.path.exists(a.file):
        os.remove(a.file)
    with zipfile.ZipFile(a.file, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(a.dir):
            for fn in files:
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, a.dir).replace(os.sep, "/")
                z.write(full, arc)
    # sanity: it must re-open as a presentation
    Presentation(a.file)
    print(f"repacked {a.dir}/ → {a.file}  (verified: opens as a presentation)")
    return 0


def cmd_render(a):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise SystemExit("render needs LibreOffice (soffice) on PATH — not found. "
                         "Skip render-QA, or export via a machine that has it.")
    os.makedirs(a.dir, exist_ok=True)
    subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", a.dir, a.file], check=True)
    pdf = os.path.join(a.dir, os.path.splitext(os.path.basename(a.file))[0] + ".pdf")
    pdftoppm = shutil.which("pdftoppm")
    if pdftoppm:
        subprocess.run([pdftoppm, "-png", "-r", "96", pdf, os.path.join(a.dir, "slide")], check=True)
        print(f"rendered PNGs → {a.dir}/slide-*.png")
    else:
        print(f"rendered PDF → {pdf}  (install poppler/pdftoppm for per-slide PNGs)")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description="Inspect and edit an existing .pptx.")
    sub = p.add_subparsers(dest="cmd", required=True)

    q = sub.add_parser("inspect"); q.add_argument("file"); q.add_argument("--slide", type=int)
    q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_inspect)

    q = sub.add_parser("replace-text"); q.add_argument("file")
    q.add_argument("--find", required=True); q.add_argument("--replace", required=True)
    q.add_argument("--slide", type=int); q.add_argument("--mode", choices=["run", "paragraph"], default="run")
    q.add_argument("-o", "--output"); q.set_defaults(fn=cmd_replace_text)

    q = sub.add_parser("set-text"); q.add_argument("file")
    q.add_argument("--slide", type=int, required=True); q.add_argument("--shape", type=int, required=True)
    q.add_argument("--text", required=True); q.add_argument("-o", "--output"); q.set_defaults(fn=cmd_set_text)

    q = sub.add_parser("set-cell"); q.add_argument("file")
    q.add_argument("--slide", type=int, required=True); q.add_argument("--shape", type=int, required=True)
    q.add_argument("--row", type=int, required=True); q.add_argument("--col", type=int, required=True)
    q.add_argument("--text", required=True); q.add_argument("-o", "--output"); q.set_defaults(fn=cmd_set_cell)

    q = sub.add_parser("delete-slide"); q.add_argument("file")
    q.add_argument("--slide", type=int, required=True); q.add_argument("-o", "--output"); q.set_defaults(fn=cmd_delete_slide)

    q = sub.add_parser("reorder"); q.add_argument("file")
    q.add_argument("--order", required=True); q.add_argument("-o", "--output"); q.set_defaults(fn=cmd_reorder)

    q = sub.add_parser("add-image"); q.add_argument("file")
    q.add_argument("--slide", type=int, required=True); q.add_argument("--image", required=True)
    q.add_argument("--full-bleed", action="store_true", help="cover the whole slide, behind existing content")
    q.add_argument("--duotone", action="store_true", help="blend into the deck palette (navy duotone)")
    q.add_argument("--scrim", action="store_true", help="dark overlay so text on top stays legible")
    q.add_argument("--scrim-alpha", type=int, default=38); q.add_argument("--accent", default="#1B365D")
    q.add_argument("--shadow"); q.add_argument("--highlight")
    q.add_argument("--left", type=float, default=0); q.add_argument("--top", type=float, default=0)
    q.add_argument("--width", type=float); q.add_argument("--height", type=float)
    q.add_argument("-o", "--output"); q.set_defaults(fn=cmd_add_image)

    q = sub.add_parser("append-deck"); q.add_argument("file")
    q.add_argument("--from", dest="src", required=True, help="deck whose slides to append")
    q.add_argument("-o", "--output"); q.set_defaults(fn=cmd_append_deck)

    q = sub.add_parser("unpack"); q.add_argument("file"); q.add_argument("dir"); q.set_defaults(fn=cmd_unpack)
    q = sub.add_parser("repack"); q.add_argument("dir"); q.add_argument("file"); q.set_defaults(fn=cmd_repack)
    q = sub.add_parser("render"); q.add_argument("file"); q.add_argument("dir"); q.set_defaults(fn=cmd_render)

    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
