#!/usr/bin/env python3
"""photo.py — enterprise duotone imagery for slide backdrops.

Steals ppt-master's "use a real photo" idea but keeps it board-professional: any
image is baked into a navy DUOTONE (two-tone recolor) so it always reads on-brand
and editorial (the Bloomberg/McKinsey treatment) instead of stock-y — and, crucially,
the tone is baked into the PIXELS. A CSS filter would NOT survive dom-to-pptx (the
scraper maps the DOM to shapes and doesn't apply CSS filters/blend-modes), so the
PPTX would show the raw photo. Baking guarantees the export matches the browser.

Use only on title / section-divider / one "wow" slide, behind a scrim, NEVER behind
data — same scope rules as the abstract backdrops (see imagery.md). Output is a
full-bleed `<img class="slide-bg">`, identical slot to gen_backdrop.py's SVG.

Subcommands:
  duotone --in PHOTO --out OUT.png [--accent "#1B365D"] [--shadow HEX] [--highlight HEX]
      Bake a navy duotone into an existing local image. Pure-local, no network.

  fetch --query "data center" --out DIR [--accent "#1B365D"] [--source openverse]
        [--n 1] [--no-duotone] [--license commercial]
      Search a provider, download the top result(s), bake the duotone, and write
      attribution (assets/attribution.json + CREDITS.md). Best-effort — prints a
      clear message and exits 0 if nothing is found / no network / no API key, so a
      deck build never hard-fails over decoration.

Sources: openverse (CC, NO API KEY, auto-attribution — the safe enterprise default);
         pexels   (needs PEXELS_API_KEY);  unsplash (needs UNSPLASH_ACCESS_KEY).

Requires Pillow (pip install pillow). Network via urllib (stdlib).
"""
from __future__ import annotations

import argparse
import io
import json
import os
import sys
import urllib.parse
import urllib.request

# Reconfigure in place (safe when imported by a sibling, e.g. pptx_tool.py add-image).
try:
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
except Exception:  # pragma: no cover
    pass

_UA = {"User-Agent": "agentfarm-deck/1.0 (+presentation skill)"}


# ----------------------------------------------------------------- color helper
def _hex_to_rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _scale(rgb, f):
    return tuple(max(0, min(255, int(round(c * f)))) for c in rgb)


def _slug(s, n=40):
    keep = "".join(c if c.isalnum() else "-" for c in s.lower())
    while "--" in keep:
        keep = keep.replace("--", "-")
    return keep.strip("-")[:n] or "image"


# --------------------------------------------------------------------- duotone
def _bake_duotone(in_path, out_path, accent, shadow=None, highlight=None):
    from PIL import Image, ImageOps
    acc = _hex_to_rgb(accent)
    shadow_rgb = _hex_to_rgb(shadow) if shadow else _scale(acc, 0.55)   # deep navy
    highlight_rgb = _hex_to_rgb(highlight) if highlight else (233, 238, 244)  # light tint
    gray = Image.open(in_path).convert("L")
    duo = ImageOps.colorize(gray, black=shadow_rgb, white=highlight_rgb).convert("RGB")
    duo.save(out_path, "PNG")
    return out_path


def cmd_duotone(a):
    out = _bake_duotone(a.infile, a.out, a.accent, a.shadow, a.highlight)
    print(f"duotone baked → {out}  (shadow≈{a.shadow or 'accent×0.55'}, highlight≈{a.highlight or '#e9eef4'})")
    print(f'  use as:  <img class="slide-bg" src="{os.path.basename(out)}" alt="">   (add a .slide-scrim div for text contrast)')
    return 0


# ----------------------------------------------------------------- providers
# Enterprise-safe default: CC0 + Public Domain Mark + CC BY only. These allow
# commercial use AND modification (we bake a duotone = a derivative) with NO
# ShareAlike (would force the deck under the same license), NO NonCommercial, NO
# NoDerivatives. BY still requires a credit line — written to attribution.json.
_SAFE_LICENSES = "cc0,pdm,by"
_LICENSE_TYPES = {"commercial", "modification", "commercial,modification", "all"}


def _openverse(query, n, license_spec):
    # A bare license_type keyword (e.g. "commercial") → license_type param; anything
    # else is treated as specific license codes (e.g. "cc0,pdm,by") → license param.
    key = "license_type" if license_spec in _LICENSE_TYPES else "license"
    params = urllib.parse.urlencode(
        {"q": query, key: license_spec, "page_size": n, "mature": "false"})
    req = urllib.request.Request("https://api.openverse.org/v1/images/?" + params, headers=_UA)
    data = json.load(urllib.request.urlopen(req, timeout=15))
    out = []
    for r in data.get("results", []):
        out.append({
            "url": r.get("url") or r.get("thumbnail"),
            "title": r.get("title") or "untitled",
            "creator": r.get("creator") or "unknown",
            "license": f"{(r.get('license') or '').upper()} {r.get('license_version') or ''}".strip(),
            "license_url": r.get("license_url") or "",
            "source": r.get("foreign_landing_url") or r.get("url") or "",
        })
    return out


def _pexels(query, n, _lt):
    key = os.environ.get("PEXELS_API_KEY")
    if not key:
        return None  # signal "source unavailable"
    params = urllib.parse.urlencode({"query": query, "per_page": n})
    req = urllib.request.Request("https://api.pexels.com/v1/search?" + params,
                                 headers={**_UA, "Authorization": key})
    data = json.load(urllib.request.urlopen(req, timeout=15))
    return [{
        "url": p["src"]["large2x"], "title": p.get("alt") or "Pexels photo",
        "creator": p.get("photographer", "unknown"),
        "license": "Pexels License", "license_url": "https://www.pexels.com/license/",
        "source": p.get("url", ""),
    } for p in data.get("photos", [])]


def _unsplash(query, n, _lt):
    key = os.environ.get("UNSPLASH_ACCESS_KEY")
    if not key:
        return None
    params = urllib.parse.urlencode({"query": query, "per_page": n})
    req = urllib.request.Request("https://api.unsplash.com/search/photos?" + params,
                                 headers={**_UA, "Authorization": f"Client-ID {key}"})
    data = json.load(urllib.request.urlopen(req, timeout=15))
    return [{
        "url": p["urls"]["regular"], "title": p.get("description") or "Unsplash photo",
        "creator": (p.get("user") or {}).get("name", "unknown"),
        "license": "Unsplash License", "license_url": "https://unsplash.com/license",
        "source": (p.get("links") or {}).get("html", ""),
    } for p in data.get("results", [])]


_SOURCES = {"openverse": _openverse, "pexels": _pexels, "unsplash": _unsplash}


def cmd_fetch(a):
    fn = _SOURCES[a.source]
    try:
        results = fn(a.query, a.n, a.license)
    except Exception as exc:
        print(f"⚠ {a.source} search failed ({type(exc).__name__}): {str(exc)[:80]}. "
              f"Skipping imagery — use gen_backdrop.py or a visual device instead.")
        return 0
    if results is None:
        env = "PEXELS_API_KEY" if a.source == "pexels" else "UNSPLASH_ACCESS_KEY"
        print(f"⚠ {a.source} needs {env} (not set). Use --source openverse (no key), "
              f"gen_backdrop.py, or a visual device.")
        return 0
    if not results:
        print(f"⚠ no results for {a.query!r} on {a.source}. Use gen_backdrop.py or a visual device.")
        return 0

    os.makedirs(a.out, exist_ok=True)
    manifest = []
    for i, r in enumerate(results[:a.n], start=1):
        try:
            raw = urllib.request.urlopen(urllib.request.Request(r["url"], headers=_UA), timeout=20).read()
        except Exception as exc:
            print(f"  ⚠ download failed for result {i}: {str(exc)[:60]}")
            continue
        base = f"{_slug(a.query)}-{i}"
        raw_path = os.path.join(a.out, base + "_src")
        with open(raw_path, "wb") as fh:
            fh.write(raw)
        if a.no_duotone:
            final = os.path.join(a.out, base + ".png")
            from PIL import Image
            Image.open(raw_path).convert("RGB").save(final, "PNG")
        else:
            final = _bake_duotone(raw_path, os.path.join(a.out, base + "_duo.png"), a.accent, a.shadow, a.highlight)
        os.remove(raw_path)
        entry = {"file": os.path.basename(final), **{k: r[k] for k in ("title", "creator", "license", "license_url", "source")}}
        manifest.append(entry)
        print(f"  ✓ {os.path.basename(final)}  — “{r['title'][:40]}” by {r['creator']} ({r['license']})")

    if manifest:
        with open(os.path.join(a.out, "attribution.json"), "w", encoding="utf-8") as fh:
            json.dump(manifest, fh, ensure_ascii=False, indent=2)
        with open(os.path.join(a.out, "CREDITS.md"), "a", encoding="utf-8") as fh:
            for m in manifest:
                fh.write(f"- {m['file']}: “{m['title']}” by {m['creator']}, {m['license']} — {m['source']}\n")
        print(f"attribution → {a.out}/attribution.json + CREDITS.md  "
              f"(put a small credits line on the slide or appendix — required for CC/Unsplash/Pexels)")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description="Enterprise duotone imagery for slide backdrops.")
    sub = p.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("duotone")
    d.add_argument("--in", dest="infile", required=True); d.add_argument("--out", required=True)
    d.add_argument("--accent", default="#1B365D"); d.add_argument("--shadow"); d.add_argument("--highlight")
    d.set_defaults(fn=cmd_duotone)

    f = sub.add_parser("fetch")
    f.add_argument("--query", required=True); f.add_argument("--out", required=True)
    f.add_argument("--source", choices=sorted(_SOURCES), default="openverse")
    f.add_argument("--accent", default="#1B365D"); f.add_argument("--shadow"); f.add_argument("--highlight")
    f.add_argument("--n", type=int, default=1); f.add_argument("--no-duotone", action="store_true")
    f.add_argument("--license", default=_SAFE_LICENSES,
                   help="openverse licenses. Default cc0,pdm,by = enterprise-safe (no ShareAlike/NC/ND). "
                        "Pass specific codes (cc0,pdm,by,by-sa,…) or a type (commercial|modification).")
    f.set_defaults(fn=cmd_fetch)

    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
