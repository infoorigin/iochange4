#!/usr/bin/env python3
"""gen_backdrop.py — deterministic abstract SVG backdrops for slide decks.

Prints ONE self-contained inline <svg class="slide-bg"> to stdout. Paste it as
the FIRST child of a title / section-divider / "wow" slide (see imagery.md for
the scope rules — imagery NEVER goes behind data, tables, or KPI grids).

Why a script and not hand-authored SVG: the motif math (seeded placement,
theme-derived tints, contrast-safe opacities) lives in ONE place so every deck
looks consistent and the LLM never re-derives it. Pure stdlib, no dependencies
(same contract as validate_palette.py). Output is deterministic for a given
(motif, accent, context, seed) — no Math.random, no clock — so re-runs are
reproducible and PPTX export is stable.

Inline SVG scrapes to NATIVE PPTX vectors (dom-to-pptx), so no export change is
needed and the backdrop stays editable in PowerPoint.

Usage:
  gen_backdrop.py --motif mesh   --accent "#1B365D" --context cover
  gen_backdrop.py --motif grid   --accent "#1B365D" --context divider
  gen_backdrop.py --motif topo   --accent "#0052cc" --context divider --seed 7
  gen_backdrop.py --motif diagonal --accent "#0d9488" --context divider

Motifs:  mesh | grid | topo | diagonal
Context: cover   — sits on a LIGHT slide bg (dark text). Very faint accent tint.
         divider — sits on the ACCENT field (.section-slide, white text).
                   Adds depth gradient + faint WHITE motif.
Exit code 0 always (a backdrop is decorative; never fail the deck over it).
"""
from __future__ import annotations

import argparse
import io
import sys

# Force UTF-8 stdout so Windows consoles don't choke on the SVG.
try:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", newline="\n")
except Exception:  # pragma: no cover - already wrapped / non-standard stream
    pass

W, H = 1920, 1080


# ---------------------------------------------------------------- color helpers
def _hex_to_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) != 6:
        raise ValueError(f"bad hex color: {h!r}")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _rgb_to_hex(r: int, g: int, b: int) -> str:
    clamp = lambda v: max(0, min(255, int(round(v))))
    return f"#{clamp(r):02x}{clamp(g):02x}{clamp(b):02x}"


def _scale(hex_color: str, factor: float) -> str:
    """factor<1 darkens, >1 lightens toward white."""
    r, g, b = _hex_to_rgb(hex_color)
    if factor <= 1:
        return _rgb_to_hex(r * factor, g * factor, b * factor)
    t = factor - 1.0
    return _rgb_to_hex(r + (255 - r) * t, g + (255 - g) * t, b + (255 - b) * t)


# ------------------------------------------------------------- deterministic RNG
class _LCG:
    """Tiny seeded PRNG so placement is reproducible (no clock / os.urandom)."""

    def __init__(self, seed: int) -> None:
        self.s = (seed * 2654435761 + 1) & 0xFFFFFFFF

    def next(self) -> float:
        self.s = (1103515245 * self.s + 12345) & 0x7FFFFFFF
        return self.s / 0x7FFFFFFF

    def between(self, lo: float, hi: float) -> float:
        return lo + (hi - lo) * self.next()


# ------------------------------------------------------------------------ motifs
def _mesh(accent: str, ctx: str, rng: _LCG) -> str:
    """Soft overlapping radial blobs — the 'soft gradient' cover look."""
    if ctx == "divider":
        c1, c2, c3 = _scale(accent, 0.72), accent, _scale(accent, 1.25)
        base_op = (0.55, 0.40, 0.28)
    else:  # cover on light bg — keep it a whisper
        c1 = c2 = c3 = accent
        base_op = (0.07, 0.05, 0.04)
    blobs = [
        (rng.between(0, 640), rng.between(0, 480), rng.between(560, 780), c1, base_op[0]),
        (rng.between(1280, 1920), rng.between(0, 400), rng.between(520, 760), c2, base_op[1]),
        (rng.between(900, 1600), rng.between(680, 1080), rng.between(600, 820), c3, base_op[2]),
    ]
    defs, circles = [], []
    for i, (cx, cy, r, col, op) in enumerate(blobs):
        defs.append(
            f'<radialGradient id="mb{i}"><stop offset="0%" stop-color="{col}" '
            f'stop-opacity="{op:.3f}"/><stop offset="100%" stop-color="{col}" '
            f'stop-opacity="0"/></radialGradient>'
        )
        circles.append(f'<circle cx="{cx:.0f}" cy="{cy:.0f}" r="{r:.0f}" fill="url(#mb{i})"/>')
    return f"<defs>{''.join(defs)}</defs>{''.join(circles)}"


def _grid(accent: str, ctx: str, rng: _LCG) -> str:
    """Faint square grid + a few accent tick squares (Swiss / structured look)."""
    stroke = "#ffffff" if ctx == "divider" else accent
    op = 0.10 if ctx == "divider" else 0.06
    tick = "#ffffff" if ctx == "divider" else accent
    tick_op = 0.22 if ctx == "divider" else 0.14
    step = 120
    lines = []
    x = step
    while x < W:
        lines.append(f'<line x1="{x}" y1="0" x2="{x}" y2="{H}"/>')
        x += step
    y = step
    while y < H:
        lines.append(f'<line x1="0" y1="{y}" x2="{W}" y2="{y}"/>')
        y += step
    ticks = []
    for _ in range(7):
        gx = int(rng.between(1, W // step - 1)) * step
        gy = int(rng.between(1, H // step - 1)) * step
        ticks.append(
            f'<rect x="{gx - 5}" y="{gy - 5}" width="10" height="10" '
            f'fill="{tick}" fill-opacity="{tick_op}"/>'
        )
    return (
        f'<g stroke="{stroke}" stroke-opacity="{op}" stroke-width="1.5">{"".join(lines)}</g>'
        f'{"".join(ticks)}'
    )


def _topo(accent: str, ctx: str, rng: _LCG) -> str:
    """Concentric contour rings — topographic 'wow' texture."""
    stroke = "#ffffff" if ctx == "divider" else accent
    op = 0.14 if ctx == "divider" else 0.07
    cx, cy = rng.between(1150, 1550), rng.between(300, 780)
    rings = []
    r = 90
    while r < 1500:
        rings.append(
            f'<circle cx="{cx:.0f}" cy="{cy:.0f}" r="{r:.0f}" fill="none" '
            f'stroke="{stroke}" stroke-opacity="{op:.3f}" stroke-width="2"/>'
        )
        r += int(rng.between(58, 96))
    return "".join(rings)


def _diagonal(accent: str, ctx: str, rng: _LCG) -> str:
    """Large diagonal chevron field — dynamic section-divider band."""
    if ctx == "divider":
        band, band_op, line, line_op = "#ffffff", 0.06, "#ffffff", 0.10
        depth = _scale(accent, 0.72)
        depth_g = (
            f'<defs><linearGradient id="dg" x1="0" y1="0" x2="1" y2="1">'
            f'<stop offset="0%" stop-color="{depth}" stop-opacity="0.45"/>'
            f'<stop offset="100%" stop-color="{accent}" stop-opacity="0"/>'
            f"</linearGradient></defs>"
            f'<rect x="0" y="0" width="{W}" height="{H}" fill="url(#dg)"/>'
        )
    else:
        band, band_op, line, line_op, depth_g = accent, 0.05, accent, 0.07, ""
    bands = [
        f'<polygon points="0,{H} 520,{H} 1180,0 660,0" fill="{band}" fill-opacity="{band_op}"/>',
    ]
    lines = []
    for _ in range(5):
        off = rng.between(-200, W)
        lines.append(
            f'<line x1="{off:.0f}" y1="{H}" x2="{off + 700:.0f}" y2="0" '
            f'stroke="{line}" stroke-opacity="{line_op}" stroke-width="2.5"/>'
        )
    return f'{depth_g}{"".join(bands)}{"".join(lines)}'


def _corner(accent: str, ctx: str, rng: _LCG) -> str:
    """A single deliberate mark: concentric arcs anchored to the bottom-right
    corner. Reads as intentional design (not a texture), stays clear of centered/
    left-aligned title text, and is VISIBLE on a light cover (unlike the mesh wash).
    Rhymes with `topo` so covers + dividers feel like one system."""
    if ctx == "divider":
        col = "#ffffff"
        ops = [0.14, 0.20, 0.12, 0.09]      # white arcs on the accent field
    else:  # cover on light bg — visible but restrained accent
        col = accent
        ops = [0.10, 0.16, 0.11, 0.08]
    cx, cy = W, H                            # centered on the bottom-right corner
    radii = [360, 540, 720, 900]            # only the in-slide quarter shows (overflow:hidden)
    widths = [2.5, 6, 2.5, 2.5]             # one hero stroke among hairlines
    rings = [
        f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{col}" '
        f'stroke-opacity="{op:.3f}" stroke-width="{w}"/>'
        for r, op, w in zip(radii, ops, widths)
    ]
    return "".join(rings)


_MOTIFS = {"mesh": _mesh, "grid": _grid, "topo": _topo, "diagonal": _diagonal, "corner": _corner}


def build(motif: str, accent: str, context: str, seed: int) -> str:
    inner = _MOTIFS[motif](accent, context, _LCG(seed))
    return (
        f'<svg class="slide-bg" viewBox="0 0 {W} {H}" '
        f'preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" '
        f'aria-hidden="true" focusable="false">{inner}</svg>'
    )


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Generate an abstract SVG slide backdrop.")
    p.add_argument("--motif", choices=sorted(_MOTIFS), default="mesh")
    p.add_argument("--accent", default="#1B365D", help="deck accent hex (theme --accent-primary)")
    p.add_argument("--context", choices=["cover", "divider"], default="cover")
    p.add_argument("--seed", type=int, default=1, help="reproducible placement seed")
    args = p.parse_args(argv)
    try:
        sys.stdout.write(build(args.motif, args.accent, args.context, args.seed) + "\n")
    except Exception as exc:  # decorative — never break the deck build
        sys.stderr.write(f"gen_backdrop: {exc}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
