# Visual devices — the anti-boring vocabulary (reference)

A deck of white slides with bullet lists and one accent color reads as *boring* even
when the content is strong. These are **enterprise-professional graphical components**
that carry the everyday content slides — the foreground counterpart to the imagery
backdrops (`imagery.md`). No photos, no dependencies, always on-brand (they use the
theme CSS variables). The CSS primitives live in `viewport-base.css`; copy the HTML
snippets below.

**The rule that makes this matter (SKILL.md R13):** every content slide earns **one**
visual device — a stat, a chart (`dataviz`), an exhibit table, a device below. A slide
that's just a heading + bullets is a failure state. But **one focal device per slide**
(R2) — don't stack three. Rotate devices like layouts; don't repeat one slide-to-slide.

All devices are static (fixed px, internal flex only, no transform) so they scrape to
native PPTX cleanly — same contract as the rest of the deck.

---

## Hero stat — one giant number IS the slide
For a single headline figure that deserves the whole canvas (L4-adjacent). Focal by design.
```html
<div class="hero-stat reveal">
  <div class="hero-num">$100.45M</div>
  <div class="hero-caption">FY26 IT vendor spend across 16 suppliers</div>
  <div class="hero-sub">40% concentrated in the top three — AWS, Microsoft, and Dell.</div>
</div>
```

## Progress ring — a % as a donut (SVG; no CSS needed)
Circumference C = 2·π·r. For r=90 → C≈565.49. Filled arc = C·(pct/100); rotate −90° to start at 12 o'clock.
```html
<div class="ring-wrap reveal">
  <svg width="220" height="220" viewBox="0 0 220 220">
    <circle cx="110" cy="110" r="90" fill="none" stroke="var(--bg-secondary,#eef2f7)" stroke-width="22"/>
    <!-- 68%: dasharray = 565.49*0.68 ≈ 384.5 , then the remainder -->
    <circle cx="110" cy="110" r="90" fill="none" stroke="var(--accent-primary)" stroke-width="22"
            stroke-dasharray="384.5 565.49" stroke-linecap="butt"
            transform="rotate(-90 110 110)"/>
    <text x="110" y="122" text-anchor="middle" font-size="56" font-weight="800"
          fill="var(--text-primary)">68%</text>
  </svg>
  <div><div class="ic-title">Contracts on standard terms</div>
       <div class="ic-body">Up from 41% at the start of FY25.</div></div>
</div>
```

## Sparkline — a trend inline next to a KPI (SVG)
Points are `x,y` in the viewBox; y is inverted (0 = top). Keep it label-light — it's a shape, not a chart.
```html
<div class="ring-wrap reveal">
  <div><div class="metric-value">$17.1M</div><div class="metric-label">AWS spend</div></div>
  <svg width="360" height="90" viewBox="0 0 360 90" fill="none">
    <polyline points="0,70 60,64 120,66 180,48 240,40 300,26 360,12"
              stroke="var(--accent-primary)" stroke-width="3"/>
  </svg>
</div>
```

## Comparison bars — quick magnitude ranking (CSS; set width:% = value)

**This `.bar-row` component is THE way to do a labeled horizontal-bar breakdown.**
It is collision-safe by construction: a flex row of `label | track | value`, each in
its own fixed-width lane, so the label and the value can NEVER overlap no matter how
long the bar or the text. Bar widths are `% of the MAX value` (the biggest bar = 100%).
Sort descending; the takeaway bar can take a deeper fill. Right-aligned tabular values.
The value lane fits `"$5.5M · 55%"`; keep values short.

```html
<div class="reveal" style="margin-top:44px">
  <div class="bar-row"><span class="bar-label">AWS</span>
    <div class="bar-track"><div class="bar-fill" style="width:100%"></div></div><span class="bar-value">$17.1M · 44%</span></div>
  <div class="bar-row"><span class="bar-label">Microsoft</span>
    <div class="bar-track"><div class="bar-fill" style="width:73%"></div></div><span class="bar-value">$12.4M · 32%</span></div>
  <div class="bar-row"><span class="bar-label">Dell</span>
    <div class="bar-track"><div class="bar-fill" style="width:44%"></div></div><span class="bar-value">$7.6M · 20%</span></div>
</div>
```

> ⛔ **ANTI-PATTERN — do NOT hand-roll a horizontal bar chart in SVG with absolutely
> positioned text.** A `<text x="316" …>` label placed just past the bar end, plus a
> `<text x="490" text-anchor="end">` value on the same baseline, **collide on the widest
> bar** (the label runs right into the value — e.g. "Platform S**$5.5M**"). SVG has no
> flow layout to keep them apart. For any *labeled* magnitude/breakdown bar list, use the
> `.bar-row` component above. Reserve hand-authored SVG for charts that genuinely need it
> (multi-series bars, lines, rings) — and there, put category labels on the axis BELOW the
> bars or in a legend, never as free text overlapping the plotted marks.

## Callout / aside — a boxed key insight
Pull the one "so what" out of the flow so the eye lands on it.
```html
<div class="callout reveal">
  <div class="callout-label">Why it matters</div>
  <p>Three renewals worth $19.6M land in Q2 — the single largest negotiating window this fiscal year.</p>
</div>
```

## Pull-quote — an editorial voice moment (use once)
Stakeholder voice, an analyst benchmark, a principle. ≤ 30 words.
```html
<div class="pull-quote reveal">
  <p>“We are paying enterprise rates for commodity capacity.”</p>
  <cite>— VP, Infrastructure &amp; Platforms</cite>
</div>
```

## Icon grid — icon + label rows (Lucide inline SVG, monochrome accent)
For a set of themes/capabilities/risks. Icons orient, never decorate (R7). 2–4 cells.
```html
<div class="icon-grid reveal">
  <div class="icon-cell">
    <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M12 2 2 7l10 5 10-5-10-5Z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/></svg>
    <div><div class="ic-title">Consolidation</div><div class="ic-body">16 vendors → a target of 11 by FY27.</div></div>
  </div>
  <div class="icon-cell">
    <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
    <div><div class="ic-title">Renewal timing</div><div class="ic-body">Q2 is the critical window for 7 contracts.</div></div>
  </div>
</div>
```
Lucide path data: https://lucide.dev — copy the inner `<path>` of any icon; keep `viewBox="0 0 24 24"`.

## Feature list — numbered items with accent badges
For sequenced recommendations / steps where a bare `<ul>` is too plain.
```html
<div class="feature-list reveal">
  <div class="feature-item"><div class="feature-num">1</div>
    <div><div class="ft-title">Renegotiate AWS</div><div class="ft-body">Target a 12% reduction at the Q2 renewal.</div></div></div>
  <div class="feature-item"><div class="feature-num">2</div>
    <div><div class="ft-title">Consolidate the mid-tail</div><div class="ft-body">Fold 5 sub-$1M vendors into two frameworks.</div></div></div>
</div>
```

## Chapter card — a RICHER section divider (replaces a bare L3)
Big faint part number + a one-line thesis. Pairs with an `imagery.md` backdrop.
```html
<section class="slide section-slide" id="slide-NN">
  <!-- optional: <svg class="slide-bg" …> from gen_backdrop.py, or a duotone <img class="slide-bg"> -->
  <div class="slide-content chapter-card">
    <div class="chapter-num">02</div>
    <h1 class="reveal">The Renewal Window</h1>
    <p class="chapter-thesis reveal">$19.6M in contracts expire in 2026 — Q2 decides most of the leverage.</p>
  </div>
</section>
```

## KPI delta — direction on a metric card
Add a green/red delta line to an existing `.metric-card`.
```html
<div class="metric-card">
  <div class="metric-value">17%</div><div class="metric-label">AWS share of IT spend</div>
  <div class="metric-delta up">▲ 4 pts vs FY25</div>
</div>
```

---

## Picking a device (form follows the point)
| The point is… | Device |
|---|---|
| one headline number | hero stat |
| a proportion / completion | progress ring |
| a KPI + its trend | sparkline |
| ranking a few items | comparison bars |
| the single "so what" | callout |
| a human/authority voice | pull-quote |
| a set of themes/capabilities | icon grid |
| sequenced recommendations | feature list |
| a chapter break | chapter card (+ backdrop) |
| magnitude across many rows | a `dataviz` chart or exhibit table (not a device) |

Devices are for emphasis and variety; genuine data still goes through `dataviz`
(charts) and the exhibit-table rules (L6). One focal device per slide.
