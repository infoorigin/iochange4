# Visual QA loop — render the slides and LOOK at them (reference)

The Step 8 text self-review reads the HTML source. That catches structure (slide
ids, density counts, missing `.reveal`) but it is **blind to how the deck actually
renders** — overflow, overlapping elements, text unreadable over a backdrop, uneven
gaps, a chart that's illegible at size. Those only show up when you *look at a picture
of the slide*. This loop makes that mandatory.

> A text review would never have caught that our first title backdrop was invisible
> on white — rendering it and looking did. That's the whole point of this step.

**Applies to vision-capable agents** (e.g. Claude). The render step is universal and
always worth doing (it produces a human-reviewable artifact); the *inspection* needs a
model that can see images. A non-vision authoring model should still render the PNGs
and surface them for a human/vision reviewer.

## The loop

**1. Render one PNG per slide** (reuses the deck exporter — no new dependency):

```bash
node skills/presentation/slides_export.js \
  --input {{output_dir}}/presentation.html --shots {{output_dir}}/_qa
# → {{output_dir}}/_qa/slide_01.png, slide_02.png, …
```

**2. Look at every slide.** Read each `_qa/slide_NN.png` and inspect against the
checklist below. For a large deck (≳15 slides) or a workflow run, fan out **one
subagent per slide** (each reads its PNG, returns a `{slide, issues[]}` list) so the
inspection parallelizes; otherwise the authoring agent reads them all itself.

**3. List every issue** — per slide, even minor ones. Be specific:
`slide_04: KPI card 3 value overflows the card's right edge`.

**4. Fix at the source.** Edit the specific `_slide_NN_*.html` file (or `_deck_shell.html`
for a theme-wide fix), then re-assemble (SKILL.md Step 6). Never edit `presentation.html`
directly — it's derived.

**5. Re-render and re-inspect the slides you changed.** Repeat 1–5 until a full pass
shows **zero new issues**. Don't stop at "fixed the big ones" — the second pass routinely
surfaces a gap the first one hid.

## Inspection checklist (what to look for in each PNG)

**Overflow / clipping**
- [ ] No text or element runs off the 1920×1080 edge or is cut by `overflow:hidden`
- [ ] No slide is visibly overfull (content crammed to the margins) — split it (density cap)

**Overlap / collision**
- [ ] No two elements sit on top of each other (text over a shape, card over a chart)
- [ ] **Bar-chart labels never touch their values** — on the widest bar, the segment name and the number are clearly separated (the classic hand-rolled-SVG collision, e.g. "Platform S$5.5M"). If a labeled bar list collides, it wasn't built with the `.bar-row` component — rebuild it with `.bar-row` (see `visual_devices.md`).
- [ ] Chart axis / tick labels aren't wrapping ("$5.5M" split onto two lines) — add `white-space:nowrap`
- [ ] A backdrop (`.slide-bg`) sits BEHIND the text, not over it — heading fully legible

**Contrast / legibility**
- [ ] Every heading and body line is comfortably readable against its background/backdrop
- [ ] Chart labels, axis text, table cells are legible at slide size (not tiny/greyed out)
- [ ] Accent color is used for emphasis, not smeared across the whole slide (R5)

**Alignment / rhythm**
- [ ] Cards/columns are the same height and evenly gapped; grids line up on a shared edge
- [ ] Consistent left margin across content slides (headings start at the same x)
- [ ] Whitespace looks intentional — no lonely element floating in a sea of empty slide

**Emptiness / filler**
- [ ] No sparse slide that's mostly blank (merge or add the missing visual — R11)
- [ ] No placeholder / lorem / "TBD" text visible

**Premium system (Graphite & Signal, R14) — the FLOOR, not the ceiling**
- [ ] Every content slide opens with a **kicker + action-title (an assertion) + accent rule** — not a bare topic label
- [ ] Every content slide has **one focal block** (block-grid / chart+exhibit / chip-list / device) — no heading-over-empty-space
- [ ] **Content fills the canvas** — no dead lower-half; a thin slide gets a seam takeaway or a promoted hero-stat, not whitespace
- [ ] At least one **full-bleed ink `.section-slide`** divider is present in a multi-part deck
- [ ] Title slide is the **editorial masthead** (kicker + big title + `.title-rule` + subtitle) and looks premium **with no backdrop**
- [ ] Paper is warm off-white (`#F6F6F3`), not stark `#fff`; the ONE accent is used for emphasis, not smeared
- [ ] No text-wrap orphans (a lone word on its own line in a title/subtitle)

**The AI tells (fix on sight)**
- [ ] No centered body paragraphs, no low-contrast grey-on-grey, no identical layout twice running

**Imagery (OPTIONAL — see `imagery.md`)**
- [ ] The deck looks board-ready **even with every backdrop removed** (imagery is never load-bearing)
- [ ] Backdrops only on title / dividers / the one "wow" slide, never behind data
- [ ] The backdrop reads as intentional and quiet, not a texture fighting the words

## Done bar

The deck is not done until a full render pass shows every slide clean against this
checklist. A deck that would embarrass the user in front of the board is not ready —
and you can only know that by looking at it.
