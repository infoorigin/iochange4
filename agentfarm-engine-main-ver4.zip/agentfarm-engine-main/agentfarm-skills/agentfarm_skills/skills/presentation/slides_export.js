#!/usr/bin/env node
/**
 * slides_export.js — render a canonical HTML slide deck to PDF or native PPTX.
 *
 * HTML is the single source of layout/design; this exports it delivery-agnostic:
 *   - PDF:  Playwright prints each .slide as one 1920x1080 page.
 *   - PPTX: dom-to-pptx (v2.x) "coordinate scraper" maps the DOM to NATIVE,
 *           editable PowerPoint shapes (text, tables, and SVG kept as vectors).
 *           Falls back to a Playwright screenshot deck (pptxgenjs) if the
 *           dom-to-pptx CLI is unavailable.
 *
 * Usage:
 *   node slides_export.js --input deck.html --output deck.pdf
 *   node slides_export.js --input deck.html --output deck.pptx [--selector .slide]
 *   node slides_export.js --input deck.html --shots qa_shots/   # one PNG per slide (visual QA)
 *
 * Dependencies:
 *   npm install playwright dom-to-pptx pptxgenjs
 *   npx playwright install chromium
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');

// Resolve a runtime dep from the CWD tree or ~/.iobot/node_modules — NOT just
// the script's own location. In a workflow step this script lives in the agent's
// filtered workspace (no node_modules), but the deps are installed under
// ~/.iobot/node_modules and/or the run's cwd tree. This mirrors how the PPTX
// path's `npx` resolves, so PDF (Playwright) works in the same contexts.
// Cross-platform (Linux pods + Windows local): collect every plausible
// node_modules location so deps resolve regardless of cwd, install style, or OS.
function depPaths() {
  const seen = new Set();
  const out = [];
  const add = (p) => { if (p && !seen.has(p)) { seen.add(p); out.push(p); } };
  // 1. ~/.iobot/node_modules — local agent install location
  add(path.join(os.homedir(), '.iobot', 'node_modules'));
  // 2. walk up from cwd AND from this script's dir (path.dirname handles / and \)
  for (const start of [process.cwd(), __dirname]) {
    let d = start;
    while (true) {
      add(path.join(d, 'node_modules'));
      const parent = path.dirname(d);
      if (parent === d) break;   // filesystem root on any OS
      d = parent;
    }
  }
  // 3. global installs: NODE_PATH (path.delimiter is ':' on POSIX, ';' on Windows)
  //    + Node's built-in global module search paths (covers `npm i -g`)
  (process.env.NODE_PATH || '').split(path.delimiter).forEach(add);
  try { require('module').globalPaths.forEach(add); } catch (e) {}
  return out;
}
function requireDep(name) { return require(require.resolve(name, { paths: depPaths() })); }

// Resolve dom-to-pptx's CLI script path so we can run it with `node <cli>` from
// anywhere (robust in a workflow step where cwd has no node_modules but the deps
// live under ~/.iobot). Falls back to `npx` if the package can't be resolved.
function resolveDomToPptxCli() {
  try {
    const pkgJson = require.resolve('dom-to-pptx/package.json', { paths: depPaths() });
    const bin = require(pkgJson).bin;
    const rel = typeof bin === 'string' ? bin : (bin['dom-to-pptx'] || Object.values(bin)[0]);
    return rel ? path.join(path.dirname(pkgJson), rel) : null;
  } catch (e) { return null; }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Launch a headless Chromium page via whatever driver is installed: Playwright
// (typical local dev) OR Puppeteer (the deploy pod — see Dockerfile: system
// chromium + PUPPETEER_EXECUTABLE_PATH). Both expose goto/evaluate/pdf/screenshot;
// we normalize the couple of differences (context vs page, waitUntil value,
// and the pod's no-sandbox requirement).
async function launchBrowserPage() {
  const driver = (process.env.SLIDES_EXPORT_DRIVER || '').toLowerCase();  // '', 'playwright', 'puppeteer'
  async function viaPlaywright() {
    const { chromium } = requireDep('playwright');
    const browser = await chromium.launch({ headless: true });
    const page = await (await browser.newContext({ viewport: { width: 1920, height: 1080 } })).newPage();
    return { browser, page, waitUntil: 'networkidle' };
  }
  async function viaPuppeteer() {
    const puppeteer = requireDep('puppeteer');
    const opts = { headless: 'new', args: ['--no-sandbox', '--disable-setuid-sandbox'] };
    if (process.env.PUPPETEER_EXECUTABLE_PATH) opts.executablePath = process.env.PUPPETEER_EXECUTABLE_PATH;
    const browser = await puppeteer.launch(opts);
    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });
    return { browser, page, waitUntil: 'networkidle0' };
  }
  if (driver === 'puppeteer') return viaPuppeteer();
  if (driver === 'playwright') return viaPlaywright();
  try { return await viaPlaywright(); } catch (e) { return await viaPuppeteer(); }  // default: playwright→puppeteer
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.input) {
    console.error('Usage: node slides_export.js --input <html> --output <file> [--format pptx|pdf] [--selector .slide]');
    console.error('       node slides_export.js --input <html> --shots <dir>   # one PNG per slide (visual QA)');
    process.exit(1);
  }
  const inputPath = path.resolve(args.input);
  if (!fs.existsSync(inputPath)) {
    console.error(`Input file not found: ${inputPath}`);
    process.exit(1);
  }
  const selector = args.selector || '.slide';

  // Visual-QA mode: render each slide to a PNG so it can be *looked at* (overflow,
  // overlap, contrast, uneven gaps — things a text read of the HTML can't catch).
  // Reuses the same browser launcher + reveal-flatten as the screenshot exporter.
  if (args.shots) {
    const shotsDir = path.resolve(args.shots);
    fs.mkdirSync(shotsDir, { recursive: true });
    console.log(`Rendering slide PNGs: ${inputPath} -> ${shotsDir}/`);
    const { browser, page, waitUntil } = await launchBrowserPage();
    try {
      await page.goto(`file://${inputPath.replace(/\\/g, '/')}`, { waitUntil, timeout: 30000 });
      try { await page.evaluate(() => document.fonts && document.fonts.ready); } catch (e) {}
      const slideCount = await flattenReveals(page, selector);
      console.log(`Found ${slideCount} slides`);
      const files = await screenshotSlides(page, shotsDir, slideCount, selector);
      console.log(`✓ Wrote ${files.length} slide PNGs to ${shotsDir}/`);
    } finally {
      await browser.close();
    }
    return;
  }

  const format = args.format || (args.output && args.output.endsWith('.pdf') ? 'pdf' : 'pptx');
  const outputPath = path.resolve(args.output || `output.${format}`);

  console.log(`Converting: ${inputPath} -> ${outputPath} (${format})`);

  if (format === 'pptx') {
    // Primary: dom-to-pptx CLI (self-contained headless browser, native editable shapes).
    if (runDomToPptxCli(inputPath, outputPath, selector)) return;
    console.log('  dom-to-pptx CLI unavailable — falling back to screenshot PPTX (non-editable).');
  }

  // PDF, or the PPTX screenshot fallback: drive a headless browser ourselves
  // (Playwright locally, Puppeteer on the pod — whichever is installed).
  const { browser, page, waitUntil } = await launchBrowserPage();
  try {
    await page.goto(`file://${inputPath.replace(/\\/g, '/')}`, { waitUntil, timeout: 30000 });
    try { await page.evaluate(() => document.fonts && document.fonts.ready); } catch (e) {}
    const slideCount = await flattenReveals(page, selector);
    console.log(`Found ${slideCount} slides`);
    if (format === 'pdf') await exportPdf(page, outputPath);
    else await screenshotPptx(page, outputPath, slideCount, selector);
    console.log(`✓ Exported: ${outputPath} (${slideCount} slides)`);
  } finally {
    await browser.close();
  }
}

// Strip nav chrome and force every .reveal element visible (no scroll observer runs
// headlessly). Shared by the PDF, screenshot-PPTX, and visual-QA paths. Returns count.
async function flattenReveals(page, selector) {
  return page.evaluate((sel) => {
    document.querySelectorAll('.progress-bar, .nav-dots').forEach(el => el.remove());
    document.querySelectorAll('.reveal').forEach(el => {
      el.classList.add('visible');
      el.style.opacity = '1'; el.style.transform = 'none'; el.style.transition = 'none';
    });
    return document.querySelectorAll(sel).length;
  }, selector);
}

// One PNG per slide (slide_01.png, slide_02.png, …) for visual inspection.
async function screenshotSlides(page, dir, slideCount, selector) {
  const written = [];
  for (let i = 0; i < slideCount; i++) {
    await page.evaluate(({ idx, sel }) => {
      document.querySelectorAll(sel).forEach((s, j) => {
        if (j === idx) {
          Object.assign(s.style, { display: 'block', position: 'fixed', top: '0', left: '0',
            width: '1920px', height: '1080px', zIndex: '9999' });
        } else { s.style.display = 'none'; }
      });
    }, { idx: i, sel: selector });
    await sleep(200);
    const file = path.join(dir, `slide_${String(i + 1).padStart(2, '0')}.png`);
    await page.screenshot({ path: file, clip: { x: 0, y: 0, width: 1920, height: 1080 } });
    written.push(file);
    console.log(`  Rendered slide ${i + 1}/${slideCount} -> ${path.basename(file)}`);
  }
  return written;
}

function runDomToPptxCli(inputPath, outputPath, selector) {
  // dom-to-pptx scrapes COMPUTED styles headlessly and does NOT run the deck's
  // scroll-in JS — so `.reveal` elements (opacity:0 by default until a scroll
  // observer adds `.visible`) are invisible at scrape time and get DROPPED
  // (tables, exhibits, most content). Bake a flattened copy that forces every
  // reveal/animated element visible, then export that.
  let exportPath = inputPath;
  let tmp = null;
  try {
    let html = fs.readFileSync(inputPath, 'utf-8');
    const forceVisible = '<style id="__pptx_flatten">' +
      '.reveal,.reveal.visible{opacity:1 !important;transform:none !important;transition:none !important;}' +
      '.progress-bar,.nav-dots{display:none !important;}' +
      '</style>';
    html = html.includes('</head>')
      ? html.replace('</head>', forceVisible + '</head>')
      : forceVisible + html;
    tmp = path.join(path.dirname(outputPath), '.__flattened_export.html');
    fs.writeFileSync(tmp, html, 'utf-8');
    exportPath = tmp;
  } catch (e) {
    exportPath = inputPath;  // fall back to the original on any error
  }
  // Prefer running the resolved CLI with the Node binary (works on Linux + Windows,
  // no shell); fall back to `npx` (shell only on Windows for npx.cmd) if unresolved.
  const cli = resolveDomToPptxCli();
  const args = ['export', exportPath, '--selector', selector, '--output', outputPath];
  const r = cli
    ? spawnSync(process.execPath, [cli, ...args], { stdio: 'inherit' })
    : spawnSync('npx', ['dom-to-pptx', ...args], { stdio: 'inherit', shell: process.platform === 'win32' });
  if (tmp) { try { fs.unlinkSync(tmp); } catch (e) {} }
  if (r.status === 0 && fs.existsSync(outputPath) && fs.statSync(outputPath).size > 0) {
    console.log(`✓ Exported native editable PPTX: ${outputPath}`);
    return true;
  }
  return false;
}

async function exportPdf(page, outputPath) {
  // Flow all slides vertically, one 1920x1080 page each, no scroll-snap.
  await page.evaluate(() => {
    const pres = document.querySelector('.presentation');
    if (pres) { pres.style.overflow = 'visible'; pres.style.height = 'auto'; pres.style.scrollSnapType = 'none'; }
    document.body.style.overflow = 'visible';
    document.documentElement.style.overflow = 'visible';
    document.querySelectorAll('.slide').forEach(s => {
      s.style.height = '1080px'; s.style.width = '1920px'; s.style.overflow = 'hidden';
      s.style.pageBreakAfter = 'always'; s.style.breakAfter = 'page';
      s.style.position = 'relative'; s.style.scrollSnapAlign = 'none';
    });
  });
  await page.pdf({
    path: outputPath, width: '1920px', height: '1080px',
    printBackground: true, preferCSSPageSize: false,
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
  });
}

async function screenshotPptx(page, outputPath, slideCount, selector) {
  const PptxGenJS = requireDep('pptxgenjs');
  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_WIDE';
  for (let i = 0; i < slideCount; i++) {
    await page.evaluate(({ idx, sel }) => {
      document.querySelectorAll(sel).forEach((s, j) => {
        if (j === idx) {
          Object.assign(s.style, { display: 'flex', position: 'fixed', top: '0', left: '0',
            width: '100vw', height: '100vh', zIndex: '9999' });
        } else { s.style.display = 'none'; }
      });
    }, { idx: i, sel: selector });
    await sleep(250);
    const shot = await page.screenshot({ type: 'png', clip: { x: 0, y: 0, width: 1920, height: 1080 } });
    pptx.addSlide().addImage({ data: `image/png;base64,${shot.toString('base64')}`, x: 0, y: 0, w: '100%', h: '100%' });
    console.log(`  Captured slide ${i + 1}/${slideCount}`);
  }
  fs.writeFileSync(outputPath, await pptx.write({ outputType: 'nodebuffer' }));
}

function parseArgs(args) {
  const r = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--input' && args[i + 1]) r.input = args[++i];
    else if (args[i] === '--output' && args[i + 1]) r.output = args[++i];
    else if (args[i] === '--format' && args[i + 1]) r.format = args[++i];
    else if (args[i] === '--selector' && args[i + 1]) r.selector = args[++i];
    else if (args[i] === '--shots' && args[i + 1]) r.shots = args[++i];
  }
  return r;
}

main().catch(err => { console.error('Export failed:', err.message); process.exit(1); });
