# HTML Template Reference — "Graphite & Signal" premium system

Every generated presentation follows this skeleton. All CSS/JS are inlined — one self-contained file.

**Static-layout contract (do not break — it's what makes the PPTX render correctly).** The deck is exported to PPTX by `dom-to-pptx`, a coordinate scraper that maps computed positions to shapes and does NOT run scroll/animation JS. So: slides are **fixed 1920×1080, top-anchored block flow** (never flex-center content), type is **fixed px** (never `clamp()`/`vw`), and `.reveal` is **opacity-only** (no `transform`). `viewport-base.css` enforces this — inline it verbatim. Only `.title-slide`/`.section-slide` may center vertically (trivial content); they are left-anchored, not centre-aligned.

**Premium is STRUCTURAL, not decorative.** The look comes from the type scale, the ink+one-accent palette, disciplined composition, and the **block language** — NOT from imagery. A deck with zero backdrops must still look premium (imagery is an optional, removable garnish — see `imagery.md`). Every content slide is built the same way:

> **kicker → action-title → accent rule → one focal block → optional seam takeaway → footer**

## Theme tokens (`:root`) — the ONE global accent + neutrals

```css
:root {
  /* Swap these to rebrand. The design system is fixed; the BRAND is configurable
     per client — resolve tokens per themes.md (user > metadata/brand.yaml > vars >
     default), then keep the structure identical. These are the default tokens. */
  --bg-primary:#F6F6F3;      /* warm off-white paper (never stark #fff) */
  --bg-secondary:#EEEFEA;
  --card-bg:#FFFFFF;
  --ink-panel:#15171E;       /* full-bleed section-divider panel */
  --text-primary:#15171E;    /* near-black display ink */
  --text-secondary:#565C6B;
  --text-muted:#9AA0AD;
  --accent-primary:#3A4DE0;  /* THE signal accent */
  --accent-secondary:#2233B8;/* darker accent for on-tint text */
  --accent-muted:#ECEEFC;    /* accent wash for seam bands / block hover */
  --kicker-on-ink:#B9C0FF;   /* kicker color on the ink section panel */
  --border-color:#E4E5E1;    /* hairline */
  --pos:#12805C; --neg:#C0392B;
  --font-display:'Plus Jakarta Sans', sans-serif;
  --font-body:'Inter', sans-serif;
}
```

## Full document structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>{{presentation_title}}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    /* 1. :root theme tokens (above) */
    /* 2. viewport-base.css — inline the ENTIRE file here (it carries the system) */
    body { font-family: var(--font-body); }
    .slide h1, .slide h2, .slide h3, .action-title { font-family: var(--font-display); color: var(--text-primary); }
  </style>
</head>
<body>
  <div class="progress-bar" id="progressBar"></div>
  <div class="nav-dots" id="navDots"></div>
  <div class="presentation" id="presentation">

    <!-- TITLE — editorial masthead, left-anchored, NO imagery needed -->
    <section class="slide title-slide" id="slide-1">
      <div class="kicker reveal">{{eyebrow}}</div>
      <h1 class="reveal">{{main_title}}</h1>
      <div class="title-rule reveal"></div>
      <p class="subtitle reveal">{{subtitle}}</p>
      <p class="t-meta reveal">{{date}} &nbsp;·&nbsp; {{org_or_confidential}}</p>
    </section>

    <!-- KPI BLOCK-GRID — the premium summary slide -->
    <section class="slide" id="slide-2">
      <div class="slide-content">
        <div class="kicker reveal">{{kicker}}</div>
        <h2 class="action-title reveal">{{action_title_assertion}}</h2>
        <div class="rule reveal"></div>
        <div class="block-grid reveal">
          <div class="block"><div class="b-value">{{v1}}</div><div class="b-label">{{l1}}</div><div class="b-delta">▲ {{d1}}</div><div class="b-sub">{{s1}}</div></div>
          <div class="block"><div class="b-value">{{v2}}</div><div class="b-label">{{l2}}</div><div class="b-delta">▲ {{d2}}</div><div class="b-sub">{{s2}}</div></div>
          <div class="block"><div class="b-value">{{v3}}</div><div class="b-label">{{l3}}</div><div class="b-delta">▲ {{d3}}</div><div class="b-sub">{{s3}}</div></div>
          <div class="block"><div class="b-value">{{v4}}</div><div class="b-label">{{l4}}</div><div class="b-delta">▲ {{d4}}</div><div class="b-sub">{{s4}}</div></div>
        </div>
        <div class="seam reveal" style="margin-top:48px;">
          <div class="seam-label">Why it matters</div>
          <p>{{so_what_takeaway}}</p>
        </div>
      </div>
      <div class="footer"><span>{{running_footer}}</span><span>02</span></div>
    </section>

    <!-- SECTION DIVIDER — full-bleed ink panel, giant ghosted chapter number -->
    <section class="slide section-slide" id="slide-3">
      <div class="kicker on-ink reveal">{{section_eyebrow}}</div>
      <div class="s-num reveal">01</div>
      <h2 class="s-title reveal">{{section_title}}</h2>
      <p class="s-thesis reveal">{{section_thesis}}</p>
    </section>

    <!-- CHART + EXHIBIT — two-column focal visual -->
    <section class="slide" id="slide-4">
      <div class="slide-content">
        <div class="kicker reveal">{{kicker}}</div>
        <h2 class="action-title reveal">{{action_title_assertion}}</h2>
        <div class="rule reveal"></div>
        <div class="two-col reveal" style="margin-top:44px;">
          <div>
            <div class="col-head">{{chart_caption}}</div>
            <svg viewBox="0 0 620 340" style="width:100%;"><!-- dataviz SVG: sequential-shaded bars → ink "now" bar, direct label --></svg>
          </div>
          <div>
            <div class="col-head">{{table_caption}}</div>
            <table><thead><tr><th>{{c1}}</th><th class="tab-num">{{c2}}</th></tr></thead>
              <tbody>
                <tr><td>{{r1a}}</td><td class="tab-num">{{r1b}}</td></tr>
                <tr class="total"><td>{{rTa}}</td><td class="tab-num">{{rTb}}</td></tr>
              </tbody></table>
          </div>
        </div>
      </div>
      <div class="footer"><span>{{running_footer}}</span><span>04</span></div>
    </section>

    <!-- ORDERED POINTS — numbered chips + a seam takeaway -->
    <section class="slide" id="slide-5">
      <div class="slide-content">
        <div class="kicker reveal">{{kicker}}</div>
        <h2 class="action-title reveal">{{action_title_assertion}}</h2>
        <div class="rule reveal"></div>
        <div class="chip-list reveal" style="margin-top:36px;">
          <div class="chip-row"><div class="chip">1</div><div><div class="cr-title">{{point1_title}}</div><div class="cr-body">{{point1_body}}</div></div></div>
          <div class="chip-row"><div class="chip">2</div><div><div class="cr-title">{{point2_title}}</div><div class="cr-body">{{point2_body}}</div></div></div>
          <div class="chip-row"><div class="chip">3</div><div><div class="cr-title">{{point3_title}}</div><div class="cr-body">{{point3_body}}</div></div></div>
        </div>
        <div class="seam reveal" style="margin-top:40px;"><div class="seam-label">The takeaway</div><p>{{takeaway}}</p></div>
      </div>
      <div class="footer"><span>{{running_footer}}</span><span>05</span></div>
    </section>

  </div>
  <script>
    /* Standard reveal + nav controller — see viewport-base.css for the static contract.
       IntersectionObserver adds .visible; keyboard/wheel/touch navigate; nav dots + progress. */
    class SlidePresentation{constructor(){this.slides=document.querySelectorAll('.slide');this.i=0;this.n=this.slides.length;
      this.bar=document.getElementById('progressBar');this.dots=document.getElementById('navDots');this.lock=false;
      for(let k=0;k<this.n;k++){const d=document.createElement('button');d.className='nav-dot'+(k===0?' active':'');d.onclick=()=>this.go(k);this.dots.appendChild(d);}
      const ro=new IntersectionObserver(e=>e.forEach(x=>{if(x.isIntersecting)x.target.classList.add('visible');}),{threshold:0.1});
      document.querySelectorAll('.reveal').forEach(el=>ro.observe(el));
      const so=new IntersectionObserver(e=>e.forEach(x=>{if(x.isIntersecting){this.i=[...this.slides].indexOf(x.target);this.upd();}}),{threshold:0.5});
      this.slides.forEach(s=>so.observe(s));
      addEventListener('keydown',e=>{if(['ArrowDown','ArrowRight',' ','PageDown'].includes(e.key)){e.preventDefault();this.go(this.i+1);}else if(['ArrowUp','ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();this.go(this.i-1);}});
      addEventListener('wheel',e=>{if(this.lock)return;this.lock=true;this.go(this.i+(e.deltaY>0?1:-1));setTimeout(()=>this.lock=false,800);},{passive:true});this.upd();}
      go(k){if(k>=0&&k<this.n)this.slides[k].scrollIntoView({behavior:'smooth'});}
      upd(){this.bar.style.width=((this.i+1)/this.n*100)+'%';this.dots.querySelectorAll('.nav-dot').forEach((d,k)=>d.classList.toggle('active',k===this.i));}}
    addEventListener('DOMContentLoaded',()=>new SlidePresentation());
  </script>
</body>
</html>
```

## Slide-type reference

| Type | Class / blocks | Use for |
|------|----------------|---------|
| Title | `.title-slide` (kicker + h1 + `.title-rule` + subtitle + meta) | Opening — editorial masthead, no imagery needed |
| Section divider | `.section-slide` (kicker `.on-ink` + `.s-num` + `.s-title` + `.s-thesis`) | Full-bleed ink panel between major sections |
| KPI blocks | `.block-grid` + `.block` (value/label/delta/sub) | 3-4 headline metrics |
| Ordered points | `.chip-list` + `.chip-row` (numbered chips) | Milestones, steps, ranked reasons |
| Chart + exhibit | `.two-col` + dataviz SVG + `.table` (`tr.total`) | Data slide — one chart beside one table |
| Callout / seam | `.seam` (label + p) or `.callout` | The "so what" takeaway band |
| Icon tiles / features | `.icon-grid` / `.feature-list` | Capabilities, pillars |
| Hero stat / pull-quote | `.hero-stat` / `.pull-quote` | One number or one line is the whole slide |

## Composition rules (NON-NEGOTIABLE — this is where premium lives)

1. **Every content slide opens with a kicker + action-title + accent rule.** The action title is a full-sentence *assertion* (a claim), never a topic label ("Q2 Results" → "ARR grew 127% to $18.2M").
2. **Every content slide earns exactly one focal block** — a block-grid, chart+exhibit, chip-list, icon-grid, hero-stat, or pull-quote. Never a bare bullet slide.
3. **Fill the canvas.** Content spans the vertical space (kicker/title top, focal block middle, optional seam near the bottom, footer at the very bottom). No dead lower half. If a slide is thin, add the seam takeaway or promote a number to a hero-stat — don't leave whitespace.
4. **Rotate layouts** — never the same focal block on two consecutive content slides.
5. **Use a section divider before each major part** (2-5 in a 12-slide deck) — the full-bleed ink panel is the deck's rhythm.
6. **Imagery is optional and removable.** Backdrops only on title/section slides, never behind data; the slide must look premium with the backdrop deleted.

## Content density limits

- Title: kicker + 1 title + 1 subtitle + meta line. Nothing else.
- KPI blocks: 3-4 blocks (never >4).
- Chip-list / feature-list: 3-5 rows.
- Table: max 6 data rows (+ optional total).
- Two-col chart+exhibit: one chart, one table.
- If content exceeds a limit → split across slides. NEVER cram.
