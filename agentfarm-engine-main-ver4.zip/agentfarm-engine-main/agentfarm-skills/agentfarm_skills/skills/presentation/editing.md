# Editing an existing .pptx (reference) — Mode B of the presentation skill

The authoring flow (Mode A) turns markdown → a new HTML deck → PPTX. **Mode B is the
other lifecycle case:** the user hands you a finished `.pptx` (last quarter's board
deck, a client template) and wants it *changed*. That content lives only as OOXML
inside the file — there's no HTML source — so you edit it in place with
`scripts/pptx_tool.py` (python-pptx under the hood).

This lives **inside** the `presentation` skill on purpose: editing a deck is deck
craft, so the whole design system — layout taxonomy, R1–R12, `dataviz`, `imagery.md`,
`visual_qa.md` — is in the same context. But the design system applies **differently**
depending on the edit. Getting that distinction right is the whole point.

## The fork: surgical edit vs. designed addition

**1. Surgical edits — MATCH the deck you were given; do NOT re-skin it.**
Updating a number, a date, a vendor name; fixing a table cell; dropping or reordering a
slide. Here the user wants *their* deck, changed in one spot and otherwise byte-identical.
**Do NOT apply our themes, layouts, or backdrops** — re-skinning someone's board deck to
our Swiss/navy system is vandalism, not an upgrade. The tool is deliberately
design-agnostic for this reason. The design system's *layout/theme machinery does not
apply here* — and that's correct, not a loss.

**2. Designed additions / rebuilds — the FULL design system applies.**
Adding new analysis slides, or rebuilding a weak slide from scratch. A *new* slide should
be authored with the complete presentation craft — layout taxonomy, R1 action titles,
`dataviz` charts/exhibit tables, `imagery.md` backdrops, `visual_qa.md` — **themed to
match the host deck** (pull its accent color / fonts via `inspect`, don't impose ours).
Author the new slide(s) via the Mode-A pipeline (HTML → export a small deck), then bring
them in with `append-deck` (see below).

**Craft rules that apply to EVERY edit (even surgical):**
- **R1 action titles** — if you touch a title, it stays a complete assertion, not a noun phrase.
- **`visual_qa.md`** — always render the *edited* deck and look at it (`pptx_tool.py render`,
  or re-export) before declaring done. An edit that reflowed text and caused overflow is invisible until you look.
- **No AI-tells** — don't introduce an accent line under a title, centered body text, etc.

## Workflow

```
1. inspect   → know exactly what's there and the shape/slide indices to target
2. plan      → decide surgical vs. designed-addition per change
3. edit      → pptx_tool.py subcommands (surgical) and/or author+append (designed)
4. visual QA → render the edited deck, look at every changed slide (visual_qa.md)
5. verify    → it re-opens and slide count is right
```

**Always `inspect` first** — never edit blind.

## Tool: `scripts/pptx_tool.py` (all indices 1-based; `--help` per subcommand)

```bash
py=scripts/pptx_tool.py
python $py inspect  deck.pptx [--slide N] [--json]     # structure + shape indices to target
python $py replace-text deck.pptx --find "Q1 FY26" --replace "Q2 FY26" [--slide N] [--mode run|paragraph] [-o out.pptx]
python $py set-text deck.pptx --slide 2 --shape 1 --text "New title"      # one shape
python $py set-cell deck.pptx --slide 3 --shape 2 --row 2 --col 2 --text "$18.9M"   # table cell
python $py delete-slide deck.pptx --slide 4
python $py reorder  deck.pptx --order 1,3,2,4
python $py add-image deck.pptx --slide 2 --image photo.jpg --full-bleed --duotone --scrim   # blend an image in
python $py unpack   deck.pptx _unpacked/     # OOXML escape hatch (edit raw XML)…
python $py repack   _unpacked/ deck.pptx     # …then re-zip
python $py render   deck.pptx _qa/           # PNG per slide for visual QA (needs LibreOffice)
```

- **`replace-text`** traverses shapes, table cells, grouped shapes, and notes. Default
  `--mode run` preserves per-run formatting; if a match is split across runs it's reported
  (not silently rewritten) — re-run that one with `--mode paragraph` or `set-text`.
- Edits write in place unless `-o/--output` is given. Work on a **copy** of the user's
  original until the visual QA passes.
- **`add-image`** puts a (user-provided) image on a slide. `--full-bleed` covers the slide
  and sends it **behind** existing content; `--duotone` blends it into the deck palette
  (navy); `--scrim` darkens it so text on top stays legible. This is the "here's an image,
  blend it onto this slide" case. Details/treatment: `imagery.md` §Duotone photography.

## Designed additions — the bridge that keeps the design system

To add board-grade new slides to an existing deck **without losing our design system**:

1. Author the new slides via **Mode A** (this skill) as their own small HTML deck,
   themed to the host (use `inspect` to read the host's accent/fonts). Apply the full
   craft: layouts, `dataviz`, `imagery.md`, self-review, `visual_qa.md`.
2. Export that mini-deck to PPTX (`slides_export.js`).
3. **`append-deck host.pptx --from new_slides.pptx`** — copies the authored slides
   (shapes + their images) onto the host and re-verifies it opens.

> Caveat: `append-deck` copies slide shapes and picture parts and remaps their
> relationships. Native PPT *chart objects* (rare in our HTML-authored decks — we emit
> charts as SVG vectors, which copy fine) are not deep-copied; if a source slide has a
> native chart, rebuild it or use `unpack`/`repack`. Always run visual QA after a merge.

## Escape hatch

For any OOXML operation the subcommands don't cover (slide-master tweaks, duplicating a
slide, surgical XML): `unpack` → edit the XML under `_unpacked/ppt/…` → `repack`. `repack`
re-verifies the result opens as a presentation before returning.
