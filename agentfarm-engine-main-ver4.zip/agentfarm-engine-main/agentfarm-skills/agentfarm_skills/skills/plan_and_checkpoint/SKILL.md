---
name: plan_and_checkpoint
description: Crash-resilient planning pattern. Write a plan manifest at step start; file existence is the checkpoint. Survives any restart — Fix 6, crash-recovery, pod migration, manual retry.
---

# Plan & Checkpoint

Every long-running step (>10 expected tool calls) must start by writing
a plan file. The plan is your **durable contract** — any future agent
instance (new session, new pod, different attempt) can read it and
continue your work without re-reading everything you already wrote.

## Phase 0 — Check for existing plan (FIRST action on step start)

```
read_file {{output_dir}}/_<step>_plan.md
```

Replace `<step>` with your step key (`analyze`, `strategize`, `review`).

**If the file EXISTS → this is a RESTART.** A prior attempt wrote this
plan and was interrupted. Your remaining work is the difference between
what the plan lists and what files exist on disk. The continuation prompt
(or a single `glob`) shows you what's on disk. Resume from the first
file in the plan that doesn't exist on disk yet. DO NOT re-read files
that already exist — their content was in the prior session or is
retrievable from disk if you specifically need it for consistency.

**If the file does NOT exist → this is a FRESH START.** Write your plan
as Phase 1 below.

## Phase 1 — Write the plan (replaces the old "outline" phase)

```
write_file {{output_dir}}/_<step>_plan.md
```

The plan is a **manifest of intended files**, organized by phase. Use
exact file names — not descriptions — so the restart logic can match
plan items against files on disk unambiguously.

### Format

```markdown
# <step> plan — <brand> <goal summary>

## Phase 1 — Read inputs
- intelligence_report.md (read)
- playbook.yaml (read)

## Phase 2 — Compose
- _<step>_section_01_executive_summary.md
- _<step>_section_02_diagnosis.md
- _<step>_section_03_scenarios.md
- ...

## Phase 3 — Assemble + finalize
- <deliverable>.md (assemble via exec cat)
- OUTPUT.md (protocol header)
```

Each line is a file the step intends to produce or consume. No checkboxes,
no status markers. **File existence on disk IS the checkpoint.** This
eliminates all per-item update overhead — zero extra tool calls during
normal execution.

### Why file names, not descriptions

On restart, the recovery logic matches plan items against the file listing:

```
Plan says:  _strategize_section_05_recommendations.md
Disk has:   _strategize_section_01..04_*.md, strategy_plan.md — but NOT 05
            → resume at section 05
```

If the plan said "Write the recommendations section" instead of the file
name, the match would require interpretation. File names are exact.

## During execution — zero checkpoint overhead

Work normally. Write your section files, run queries, assemble the
deliverable. **Do NOT edit the plan file to track progress.** Every
`write_file` you do IS a checkpoint because the file now exists on disk
and survives any crash.

The ONLY time you should edit the plan is if your **approach changes**
(e.g., you planned 7 sections but data says 5 is enough). Update the
plan once to reflect the new intent, then continue. This is rare — maybe
0-1 times per step.

## On restart — the recovery pattern

Whether you're resuming from a Fix 6 continuation, an Alex crash-recovery,
a pod migration, or a manual retry, the pattern is the same:

1. **Read your plan** (1 tool call) — see what you intended to do
2. **Check what exists** — the continuation prompt includes a file listing,
   OR do one `glob {{output_dir}}/_<step>_*` call
3. **Compute the gap** — planned files minus existing files = remaining work
4. **Resume from the first missing file** — don't re-read completed files
5. **When everything in the plan exists on disk, write OUTPUT.md**

### What NOT to do on restart

- ❌ Re-read every file "to verify" — trust file existence. If you need
  specific content from a prior section for consistency, read ONLY that
  one section, not all of them.
- ❌ Re-write the plan — it's already correct (unless your approach changed)
- ❌ glob/list_dir/grep to "re-discover" the project — the file listing
  in the continuation prompt already shows everything
- ❌ Start the step from scratch — the plan + files tell you exactly where
  you stopped

## Why this survives every crash mode

| Crash | Plan file survives? | Recovery |
|---|---|---|
| MiniMax stream stall | Yes (on disk) | Fix 6 reads plan, shows file listing |
| MiniMax connection error | Yes | Same as above |
| Agent premature termination | Yes | Same |
| Alex crash-recovery (new session) | Yes (on disk) | Phase 0 reads plan from disk |
| Pod crash (K8s) | Yes (S3-synced) | S3 pull restores plan + section files |
| Manual step-retry | Yes (on disk) | Phase 0 reads plan |
| Python/iobot crash | Yes (on disk) | Phase 0 reads plan |
