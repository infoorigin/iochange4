---
name: vector_search
description: "When a question is about the content of documents that were indexed locally with `iof-vectors` (a folder of notes, contracts, policies, reports, CSV exports): search the index, cite the document and chunk behind every passage you use, and say when the index does not cover it."
---

# Vector search over a local index

`iof-vectors` is a local, serverless index: one SQLite file holding the
chunks of a set of documents and a vector for each chunk. You search it
with a question and get back the chunks whose vectors are nearest, each
with a score, the document it came from and its position (chunk ordinal).
The mechanism is the CLI, run through exec; the judgement - when to search,
what a score means, what you may claim from a hit - is yours, and this
file is how you exercise it.

## When to search

Search when the answer should come from the documents rather than from
you: what a contract says, what a policy requires, which report mentioned
a figure, whether a topic appears anywhere in the corpus. Do not search
for things the documents cannot contain (arithmetic on numbers you already
have, general knowledge, the current date).

Before the first search, look at what the index holds:

```
iof-vectors --store <path> status --json
```

If `documents` is 0, there is nothing to search. Say so; do not answer the
question from memory as if you had read the documents.

## Running a search

```
iof-vectors --store <path> search "<question in plain words>" --top 5 --json
```

Phrase the query as the passage you expect to find, not as a command
("net 45 payment terms" rather than "find the payment terms"). Run more
than one query when the question has more than one part; one broad query
returns one neighbourhood, not the whole answer.

Each hit carries `score`, `doc_id`, `title`, `path`, `ordinal`, `text` and
`snippet`. Read the `text`, not only the snippet, before you rely on it.

## Reading a score

The score is cosine similarity in [-1, 1]. It ranks the chunks; it does
not certify that the best one answers the question. Two rules:

* **A low top score means "not in the index".** When the best hit scores
  well under the others you have seen for this index, or the text of the
  best hit does not address the question, say "not in the index" and stop.
  Do not read an answer into a weakly related chunk.
* **Which embedder built the index decides what "close" means.** The
  `embedder` field of the result says which. `openai` (any OpenAI-
  compatible endpoint) is semantic: paraphrases score close. `hash` is
  LEXICAL - it scores shared words, not shared meaning - so a paraphrase
  can miss entirely. With a `hash` index, try the vocabulary the documents
  are likely to use, and treat a miss as "not found with these words", not
  as proof of absence.

## Citing what you use

Every passage you quote or paraphrase names its source: the document
(`title` and `path`) and the chunk (`ordinal`), for example
`payment_terms.md, chunk 2`. Quote the text as it stands in the hit.
Never compose a passage that the search did not return, never merge two
chunks into one quotation, and never attribute to a document a statement
that appears only in your reasoning.

When two hits disagree, report both with their sources rather than
choosing silently.

## When the tool refuses

`search` refuses when the query embedder is not the one that built the
index (the message names both models). Do not work around it by changing
the query; the vectors are not comparable. Report the refusal, and if you
are asked to fix it, `iof-vectors --store <path> reindex` re-embeds the
whole index with the current embedder - a deliberate, whole-index change,
so name it before you run it.

## Indexing

If the task includes building the index, `iof-vectors --store <path>
index <folder-or-glob>` indexes text, markdown and CSV (one row per line);
binaries are skipped and reported. Re-running it on unchanged files
changes nothing, so it is safe to run again after adding files. Set the
store path deliberately (inside the step's metadata directory when there
is one) and reuse the same path for every search.
