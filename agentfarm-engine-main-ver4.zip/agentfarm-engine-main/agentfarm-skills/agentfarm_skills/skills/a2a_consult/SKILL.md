---
name: a2a_consult
description: >-
  Consulting EXTERNAL A2A agents with `iof-consult`: read the workspace's
  registered agent catalog (metadata/external_agents.yaml and, if present,
  metadata/catalog_dynamic.yaml), route each question to the best-fit agent
  by description/tags/examples, dispatch in parallel, and combine the
  results. Use when a question is outside your own data and an external
  agent in the catalog covers it.
---

# Consulting external A2A agents

You can delegate questions to external agents over the A2A protocol. The
mechanism is the `iof-consult` CLI (via exec); the judgement — which agent,
which question, what to do with the answers — is yours, and this file is how
you exercise it.

## Step 1 — Load the catalog

```
read_file metadata/external_agents.yaml
```

Also read `metadata/catalog_dynamic.yaml` if it exists (dynamically
discovered agents — same shape). Merge the two lists by agent `name`; the
static registry wins a name conflict.

Each entry:

```yaml
agents:
  - name: partner-insights
    description: "Partner market-insights agent"
    a2a_url: "https://partner.example.com/a2a/insights"
    tags: [market-share, partner]
    examples: ["Which regions grew share last quarter?"]
    headers:                       # optional — auth for this endpoint
      Authorization: "Bearer ${PARTNER_A2A_TOKEN}"
```

**If neither file exists or both are empty**: no external agents are
configured in this workspace. Say exactly that and answer from your own
capabilities — never invent an agent or a URL.

## Step 2 — Route

Match each question against every agent's `description`, `tags[]` and
`examples[]`. Assign each question to its single best-fit agent; an agent
with no assigned questions is not dispatched. Before dispatching, explain
your routing in one short plain-markdown passage — which agent gets which
question and why.

If no agent covers a question, keep that question for yourself (or say it
cannot be answered) — do not send it to a nearly-fitting agent just to send
it somewhere.

## Step 3 — Dispatch (parallel)

Write `metadata/tmp/<session_hash>/dispatch.json`, one entry per selected
agent. `url` and `headers` come from the catalog entry **verbatim** —
`${VAR}` references included; `iof-consult` expands them at send time from
the workspace environment:

```json
[
  {
    "id": "<agent name>",
    "url": "<entry.a2a_url>",
    "nlq": "<the question(s) for this agent>",
    "context_id": "<session_hash>:<agent name>",
    "headers": { "<copied from entry.headers, if present>": "..." }
  }
]
```

Execute, passing `timeout: 360` to the exec tool (60s buffer over
iof-consult's own timeout):

```
exec iof-consult --batch metadata/tmp/<hash>/dispatch.json --output metadata/tmp/<hash>/results.json --timeout 300
```

Each agent's reply also lands immediately in
`metadata/tmp/<hash>/<id>_result.json` as it completes.

## Step 4 — Combine

Read `results.json` — shape `{"results": [{"id", "ok", "envelope"|"error"}]}`.
For each result log one line: `[<id>] ✓ …` or `[<id>] ✗ <error>`. Then:

- Use only `ok: true` envelopes. A failed agent is **excluded and named** in
  your answer's caveats — never padded with an invented result, never turned
  into an error row.
- Attribute every externally-sourced figure to the agent it came from.
- If ALL dispatches failed, say so and answer with what you have yourself.

## Anti-patterns

- Hardcoding an agent name or URL → forbidden; the catalog is the only
  source. An agent not in the catalog does not exist for you.
- Writing a resolved token into `dispatch.json`, a log line, or your answer
  → forbidden; headers are copied with their `${VAR}` references intact.
- Dispatching a question to an agent whose description does not cover it.
- Shell command substitution (`$(...)`, `` `...` ``) inside exec commands.
- Retrying a failed agent more than once — one retry, then exclude it.
