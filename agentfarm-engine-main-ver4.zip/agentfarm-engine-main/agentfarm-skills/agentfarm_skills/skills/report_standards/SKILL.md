---
name: report_standards
description: Consulting-grade deliverable formatting — executive structure, language conventions, data presentation standards
---

# Report Standards

Universal formatting conventions for every deliverable. These are the principles — your domain skills define the specific report structure for each engagement type.

## Core Principles

1. **Answer first (Pyramid Principle).** Lead every section with the conclusion. Then prove it. Never build up to a finding — state it, then support it.
2. **Quantify everything.** "Significant savings" is not acceptable. "$2.3M annual reduction (18% of addressable spend)" is.
3. **Ranges, not points.** Three scenarios: conservative, expected, optimistic. Single-point estimates signal false precision.
4. **So-what on every number.** A number without an implication is just data. "Vendor concentration: 42% with top 3" is data. "Vendor concentration: 42% with top 3, exceeding the 30% risk threshold — diversification required" is insight.

## Executive Summary — SCR Framing

Every Executive Summary uses Situation-Complication-Resolution:

- **SITUATION** — Neutral context everyone agrees with. No controversy.
- **COMPLICATION** — The problem or tension that demands action. The "why now."
- **RESOLUTION** — The recommended course of action, stated clearly.

Followed by: Key Findings (3-5 bullets with numbers), Recommendations Summary, Expected Impact, Immediate Next Steps.

The Executive Summary must be self-contained — a reader who reads nothing else must understand the full picture.

## Report Structure

Adapt structure to the deliverable type. Standard building blocks:

| Block | When to include | Purpose |
|-------|----------------|---------|
| Cover + Confidentiality | Always | Client, date, classification, version |
| Executive Summary (SCR) | Always | Self-contained overview for leadership |
| Scope and Methodology | Full assessments | What was analyzed, how, data sources |
| Current State Assessment | Diagnostic reports | Evidence-backed baseline |
| Findings / Analysis | Always | The "what" — data, patterns, insights |
| Recommendations | Strategy deliverables | The "so what" — specific actions |
| Roadmap | Transformation plans | Phased implementation with gates |
| Financial Impact | When quantifiable | Savings waterfall, ROI, NPV |
| Risks and Dependencies | Strategy deliverables | What could go wrong, mitigations |
| Next Steps | Always | Concrete actions for the next 30 days |

**For targeted deliverables** (single vendor negotiation brief, specific audit response): skip irrelevant blocks. A negotiation brief doesn't need a roadmap. An audit response doesn't need an ROI model.

## Recommendation Format

Every recommendation follows:

```
**R-[N]: [Action-oriented title]**
- **Owner:** [Role/function responsible]
- **Timeline:** [Specific — Q3 2026, not "short-term"]
- **Investment:** [$ amount or effort estimate]
- **Expected Impact:** [$ range, three scenarios]
- **Dependencies:** [What must happen first]
- **Success Metric:** [Measurable KPI + target + date]
```

## Language Conventions

- Never use first person ("I", "we", "our") — use "this assessment", "the analysis"
- Action-oriented section titles: "SaaS Redundancy Drives $6M in Waste" not "SaaS Analysis"
- Severity labels: CRITICAL / HIGH / MEDIUM / LOW — use consistently
- Time references: specific (Q3 2026, March 2027) not vague (short-term, near future)
- Benchmark framing: "Your score X.X | Peer median X.X | Top quartile X.X"
- Hedging hierarchy: "will" (certain) > "expected to" (high confidence) > "likely" (moderate) > "may" (uncertain)

## Data Presentation

- Present data as **tables**, not described in prose
- Financial data: savings waterfall format (gross → adjustments → net)
- Comparisons: always include benchmark (peer median, top quartile, industry standard)
- Trends: show direction and magnitude, not just current state
- Risk: severity × likelihood matrix or register format

## Confidentiality Banner

Every report opens with:

```
> **CONFIDENTIAL** — Prepared for [Client] leadership. Not for distribution 
> outside the authorized recipient list without written approval.
```

## Compliance Checklist

Before finalizing any deliverable:

- [ ] Confidentiality banner present
- [ ] Executive Summary is self-contained with SCR framing
- [ ] Every section title is action-oriented
- [ ] Pyramid Principle followed (conclusion first)
- [ ] All financial estimates use three scenarios
- [ ] All benchmarks show your score vs peer median vs top quartile
- [ ] No first-person pronouns
- [ ] Every number has a "so what" implication
- [ ] Time references are specific
