# AI Core Harness shared skills

The shared craft skills. These are the capabilities any agent in any domain can
be given: querying data, searching documents, building charts and decks, report
formatting, planning, and the security guardrails applied to every agent. They
are versioned and released separately from the engine.

Published to your package index as **`ai-core-harness-skills`**.

## Install

```bash
pip install ai-core-harness-skills
```

It is normally installed with the engine in one command. See
[`../aicore_docusaurus/02-getting-started/02-set-up-your-machine.md`](../aicore_docusaurus/02-getting-started/02-set-up-your-machine.md).

## What ships

| Skill | What it gives an agent |
|---|---|
| `data_query` | read-only querying of PostgreSQL, MySQL, Parquet and CSV through `iof-query` |
| `vectorfs_query` | read-only navigation of document collections through `vectorfs` |
| `guardrails` | security rules applied to all agents: no package installs, no credential access, prompt-injection resistance |
| `dataviz` | the method for any chart, dashboard or stat tile, including a colour-accessibility validator |
| `presentation` | build a slide deck from a markdown report, or edit an existing `.pptx` in place |
| `report_standards` | executive structure and data-presentation conventions for deliverables |
| `plan_and_checkpoint` | write a plan manifest at step start so a long step survives a restart |
| `a2a_consult` | ask another agent a question over the A2A protocol, through `iof-consult` |

`data_query`, `guardrails` and `vectorfs_query` are the opening hand: a new
agent workspace starts with them. The rest are held only when you assign them
in the Studio or a workflow step names them — `a2a_consult` in particular is
never carried by default, because reaching another agent is a capability you
grant deliberately.

## Operating notes

- **Do not edit these in a tenant.** They arrive in a wheel and are replaced on
  upgrade. A local copy would be a fork the next release cannot reach. Extend
  them with your own workspace skills instead.
- **After upgrading, run `aicore sync`.** That is what refreshes the skill
  catalogue the Studio reads.
- **A workflow step's `skills:` list is a whitelist.** Any skill it does not
  name is dropped for that step, including `guardrails`.
- **`plan_and_checkpoint` is what makes a long step restartable.** The manifest
  it writes is the file the retry path reads to work out what is already done;
  without it a restarted step re-does everything, however far it had got.

## Next

- [`../aicore_docusaurus/03-building-solutions/01-agents-and-skills.md`](../aicore_docusaurus/03-building-solutions/01-agents-and-skills.md)
  for how skills are assigned and how to write your own.
