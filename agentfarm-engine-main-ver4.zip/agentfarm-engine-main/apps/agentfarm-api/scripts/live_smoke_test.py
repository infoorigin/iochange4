"""Live E2E smoke test for the UI path: Studio API -> engine -> agent -> artifact.

This is the only test that exercises what a user actually does in the Studio:
POST a session, watch messages stream back, and end with a real artifact on
disk. Unit tests mock the handover; this one does not.

Usage:
    python scripts/live_smoke_test.py
    IOF_SMOKE_WORKFLOW=signal_brief python scripts/live_smoke_test.py

Prerequisites — BOTH servers must already be running:
    ioagentfarm serve --port 8111                       # the engine
    uvicorn app.main:app --port 8000                    # this API

The script deliberately does NOT spawn them. It used to spawn uvicorn, which
is half the reason it rotted: run creation is a HANDOVER (POST /sessions
forwards to the engine at IOF_RUN_API_URL), so a lone API process cannot
execute anything, and a smoke test that starts the wrong half of the system
reports a green that means nothing.

Set IOF_IOBOT_EXTRA_ALLOWED_DIRS on the ENGINE process to exercise the
filesystem-sandbox patch — that is the configuration the pod and the Studio
run path use, and the one where a broken patch actually shows up.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import httpx

# ── Config ───────────────────────────────────────────────────────
# Everything is derived or env-driven. The previous version hardcoded absolute
# paths into a repo layout that no longer exists (the monorepo split moved the
# engine to agentfarm-core/ and domains to solutions/), so it could not run at
# all. Nothing here may name a machine-specific path again.

REPO_ROOT = Path(__file__).resolve().parents[3]

API_URL = os.environ.get("IOF_SMOKE_API_URL", "http://127.0.0.1:8000")
ENGINE_URL = os.environ.get("IOF_RUN_API_URL", "http://127.0.0.1:8111")

# A single-step workflow whose whole purpose is to exercise agent spawn, the
# subprocess patch shim, write_file, the fail-closed artifact gate and protocol
# parsing. Override for a heavier pack workflow.
WORKFLOW = os.environ.get("IOF_SMOKE_WORKFLOW", "hub_scribe_note")
GOAL = os.environ.get(
    "IOF_SMOKE_GOAL",
    "Write a short note recording that this smoke test ran end to end. "
    "Invent no figures.",
)
PROJECT_DIR = os.environ.get(
    "IOF_SMOKE_PROJECT_DIR", str(REPO_ROOT / ".iof" / "tmp" / "live_smoke")
)

RUN_TIMEOUT_S = float(os.environ.get("IOF_SMOKE_TIMEOUT_S", "900"))
STREAM_BUDGET_S = float(os.environ.get("IOF_SMOKE_STREAM_S", "60"))


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def reachable(url: str, path: str) -> bool:
    try:
        return httpx.get(f"{url}{path}", timeout=3.0).status_code < 500
    except httpx.HTTPError:
        return False


def preflight() -> bool:
    """Both halves must be up. A missing engine used to surface as a confusing
    500 from the handover; say which process is missing instead."""
    ok = True
    if not reachable(API_URL, "/api/health"):
        log(f"MISSING: Studio API at {API_URL}")
        log("  start it:  uvicorn app.main:app --port 8000   (from apps/agentfarm-api)")
        ok = False
    if not reachable(ENGINE_URL, "/health"):
        log(f"MISSING: engine at {ENGINE_URL}")
        log("  start it:  ioagentfarm serve --port 8111")
        ok = False
    return ok


def _who(evt: dict) -> str:
    """Label a streamed message. These fields are present but EMPTY on system
    rows, so `or`-chaining on presence alone prints '?' for every one of them."""
    for key in ("agent_name", "agent", "role", "step_key", "source"):
        val = evt.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    return "system"


def stream_messages(client: httpx.Client, run_id: str) -> int:
    """Follow the SSE stream for a bounded window. Streaming is the feature
    under test; it is not the completion signal — status polling is."""
    seen = 0
    url = f"/api/workflows/{WORKFLOW}/sessions/{run_id}/messages/stream"
    deadline = time.time() + STREAM_BUDGET_S
    try:
        with client.stream("GET", url, timeout=STREAM_BUDGET_S + 10) as resp:
            if resp.status_code != 200:
                log(f"  SSE unavailable ({resp.status_code}) — continuing on polling")
                return 0
            for line in resp.iter_lines():
                if time.time() > deadline:
                    break
                if not line or not line.startswith("data:"):
                    continue
                try:
                    evt = json.loads(line[5:].strip())
                except json.JSONDecodeError:
                    continue
                text = (evt.get("content") or "").strip().replace("\n", " ")
                if text:
                    seen += 1
                    log(f"  [{_who(evt)}] {text[:110]}")
    except httpx.HTTPError as e:
        log(f"  SSE ended early ({type(e).__name__}) — continuing on polling")
    return seen


def wait_for_terminal(run_id: str) -> dict:
    deadline = time.time() + RUN_TIMEOUT_S
    last = {}
    while time.time() < deadline:
        try:
            last = httpx.get(
                f"{ENGINE_URL}/api/run/{run_id}/status", timeout=10.0
            ).json()
        except (httpx.HTTPError, ValueError):
            time.sleep(3)
            continue
        if last.get("status") in ("done", "failed"):
            return last
        time.sleep(5)
    return {**last, "status": last.get("status", "timeout")}


def main() -> int:
    os.makedirs(PROJECT_DIR, exist_ok=True)

    log(f"workflow : {WORKFLOW}")
    log(f"api      : {API_URL}")
    log(f"engine   : {ENGINE_URL}")
    log(f"project  : {PROJECT_DIR}")
    if not preflight():
        return 2

    client = httpx.Client(base_url=API_URL, timeout=60.0)

    log("POST /sessions (the Studio's run action; handed over to the engine)")
    resp = client.post(
        f"/api/workflows/{WORKFLOW}/sessions",
        json={"goal": GOAL, "project_dir": PROJECT_DIR},
    )
    if resp.status_code != 200:
        log(f"FAIL: session start returned {resp.status_code}: {resp.text[:400]}")
        return 1

    started = resp.json()
    run_id = started["run_id"]
    log(f"run_id   : {run_id}  (steps={started.get('total_steps', '?')})")

    log("--- streaming ---")
    streamed = stream_messages(client, run_id)
    log(f"--- {streamed} message(s) streamed ---")

    final = wait_for_terminal(run_id)
    steps = final.get("steps", {})
    log(f"status   : {final.get('status')}  steps={steps}")

    failures = []
    if final.get("status") != "done":
        failures.append(f"run status is {final.get('status')!r}, expected 'done'")
    if steps.get("failed"):
        failures.append(f"{steps['failed']} step(s) failed")
    if steps.get("done", 0) < steps.get("total", 0):
        failures.append(f"only {steps.get('done')}/{steps.get('total')} steps done")
    # Streaming is a first-class feature of this path: a run that completes
    # while the UI showed nothing is a defect the status check cannot see.
    if streamed == 0:
        failures.append("no messages streamed — the UI would have shown an empty run")

    if failures:
        log("FAIL:")
        for f in failures:
            log(f"  - {f}")
        log(f"  forensics: ioagentfarm forensics show {run_id}")
        return 1

    log("PASS - Studio API -> engine -> agent -> artifact, end to end")
    return 0


if __name__ == "__main__":
    sys.exit(main())
