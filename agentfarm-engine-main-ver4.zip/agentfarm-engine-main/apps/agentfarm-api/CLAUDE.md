# CLAUDE.md — ioagentfarm-api

## What is this project?

FastAPI backend for the ioagentfarm Teams-like chat UI. It reads from ioagentfarm's shared database, drives workflow execution via CLI subprocess calls, and streams agent output in real-time via SSE.

This is a **read-heavy UI layer** — it reads run/step/message state from the shared DB and streams it to the frontend. The only writes happen indirectly via `ioagentfarm` CLI subprocess calls.

## Tech stack

- **Python 3.11+** / **FastAPI** / **Uvicorn** (ASGI)
- **Pydantic** for request/response models
- **SQLite** (default) or **PostgreSQL** (production, `iof` schema)
- **sse-starlette** for Server-Sent Events
- **PyYAML** for parsing STORED workflow definitions (files are import-only, read once by the sync endpoint)
- **python-dotenv** for env var loading
- **pytest + httpx** for testing

## Quick reference

```bash
# Install
python -m venv .venv
.venv\Scripts\pip install -e .

# Run dev server
uvicorn app.main:app --reload --port 8000

# Run tests
pytest tests/ -v

# Run live smoke test (needs running ioagentfarm + database)
python scripts/live_smoke_test.py
```

## Project layout

```
app/
  main.py          — App setup, CORS, router registration
  config.py        — Settings from env vars (cached via lru_cache)
  database.py      — DB abstraction (SQLite + PostgreSQL, context manager)
  agents.py        — Static agent registry (role -> name/color/avatar)
  persona_sections.py — sectioned persona model: parse_soul/compose_soul (SOUL.md is a composed artifact; parse(compose(x)) == x, legacy files land losslessly in sections)
  schemas.py       — Pydantic request/response models
  routers/
    workspaces.py  — Workspace CRUD + run/workflow aggregation
    workflows.py   — Workflow catalog (engine DB only — studio_workflow_defs)
    sessions.py    — Session lifecycle + background pipeline execution
    messages.py    — Message polling + SSE streaming
tests/
  conftest.py      — Fixtures: in-memory SQLite, seeded data, patched client
  test_*.py        — Unit/integration tests per module
scripts/
  live_smoke_test.py — E2E test (spawns uvicorn, monitors SSE)
```

## Key architecture patterns

- **Shared database**: Both this API and ioagentfarm CLI connect to the same DB. They must point to the same `IOF_DATABASE_URL`.
- **Run creation is a HANDOVER, never a local spawn**: `POST /sessions` forwards to the engine web API (`POST {engine}/api/run`, same rails as the message/chat proxy in `run_proxy.py`). The engine executes runs where the solution packs and model config live; this API's host never runs workflows — in the split deployment its pod has neither.
- **Engine routing is PER WORKSPACE and ENV-ONLY** (`app/engine_routing.py`, 2026-08-09): every engine-bound call resolves `engine_for(active workspace)` — `IOF_ENGINE_URLS` (JSON map, malformed = startup failure) → `IOF_ENGINE_URL_TEMPLATE` (`{workspace}` substituted) → `IOF_RUN_API_URL` → the historical localhost default. NEVER store an engine URL in the database — a URL in data travels with database copies across environments; env config stays with the deployment it describes. `IOF_DEPLOYMENT` (both-set-only) makes the engine 409 a cross-deployment request. Observed health lives in `studio_engine_health` (last-seen-healthy per workspace, written by `mark_engine_seen` on every successful rail call/probe); `GET /api/studio/workspace-runtime` derives the three UI lifecycle states from it — `preparing` (never seen healthy — a new workspace's normal state, presented warmly), `connected`, `unreachable` (was healthy, is not now — the only incident-toned state). Members never receive an engine URL; `GET /api/admin/engine-topology` (platform admin) shows host:port only. The UI's `VITE_RUN_API_BASE_URL` is retired — the browser never addresses an engine.
- **Background threading**: Session execution runs in a daemon thread after `POST /sessions` returns immediately.
- **The Studio READS base content from the ENGINE (One Truth s4.3, 2026-08-15)**: agents, skills and workflows list/detail resolve from the engine's pack-resolved catalog (`GET /api/catalog/*` via `app/engine_catalog.py`; merge in `app/agent_catalog.py` + `app/workflow_catalog.py`), each item stamped (`pack version @ sha`) and marked `source: engine`. Tenant tables (`studio_agent_defs`, `studio_skills`, `studio_workflow_defs`) ADD only — a row is shown when the engine has no item of that name and is marked `unpromoted: true`; a row for a name the engine ships is NOT shown (pack wins). `used_by`/carriage still comes from `studio_skills.roles_json`. Engine unreachable = 502 on every catalog read, never `[]`. `POST /api/studio/workflows/sync` is kept as a proxy that reports "nothing to sync". SAVE is a **DRAFT** (One Truth P2, 2026-08-15): all six create/edit endpoints delegate to `app/draft_save.py`, which writes one `content_drafts` row per `(workspace, kind, name, author)` via `app/drafts.py` — a thin wrapper over `ioagentfarm.engine.drafts` on this API's `get_db()` + `q()`; it must NEVER import `engine.draft_files` (disk) or touch `iof_root` (this pod has no filesystem). The author is `Identity.email` from `Depends(require_member)` — any client-supplied author is discarded, because the engine has no auth and this API is the only place identity is real. A draft resolves only in its author's own Try-it session (`draft: true` → engine `draft_author`) or draft-flagged run; every other reader keeps seeing the pack. `app/routers/content_drafts.py` is the draft surface (`/api/studio/content-drafts`): list/detail, per-file diff (three-way when stale), rebase, discard, patch download, and promote-instructions — the desktop command `aicore drafts apply <id>`, because the platform never commits or pushes to git (organisational policy); a draft is auto-marked promoted when the running base's bytes equal the draft's. Studio create/edit no longer writes `studio_agent_defs`/`studio_skills`/`studio_workflow_defs` (those rows remain read-only for one transitional release; `aicore drafts migrate` converts them) and no longer regenerates the `.iof/workflows/<code>/` override.
- **Sectioned personas**: agent detail returns `persona_sections` (who/purpose/how/tone/boundaries/additional) parsed tolerantly from SOUL.md; PUT accepts `persona_sections` + `persona_name` and composes SOUL.md deterministically (stable headings, round-trip safe). Raw `soul` PUT stays as the Advanced path. Unclassifiable legacy content is preserved verbatim in "Additional instructions" — never lost.
- **SSE polling**: Async loop polls DB on configurable interval, emits only new events.
- **Parameter abstraction**: `q()` function in `database.py` rewrites `?` placeholders to `%s` for PostgreSQL.
- **PostgreSQL schema**: Tables live in `iof` schema, set via `search_path` automatically.

## Database schema

The PostgreSQL schema setup script is at `C:\sb\dev\agentfarm\io-agentfarm\scripts\setup_schema.sql`. All tables live in the `iof` schema:

- **workspaces** — top-level grouping (code, name, description)
- **workflows** — engine run-metadata registry with `steps_json` and `roles_json` (lazily created on first run; enriches catalog reads)
- **studio_workflow_defs** — API-owned DB-canonical workflow catalog (code, yaml, files_json, source `pack-sync`|`studio`, shadows_pack, synced_at, updated_at); ensured idempotently at startup
- **runs** — workflow executions (workspace_id, workflow_name, goal, project_dir, status)
- **steps** — pipeline steps per run (step_key, role, status, seq, deps_json, meta_json, output_text). Unique on `(run_id, step_key)`
- **stories** — story tracking for story_loop workflow (story_id, title, details, status). Unique on `(run_id, story_id)`
- **tasks** — ad-hoc spawn tracking (task_id, role, title, body, status, output_text)
- **messages** — append-only log for real-time agent output (run_id, step_key, role, agent_name, content, msg_type). Indexed on `(run_id, step_key)` and `(run_id, id)`
- **user_context** — per-user active run context (user_id, active_run_id)

Key indexes: `steps(run_id, status, seq)`, `stories(run_id, status)`, `tasks(status)`, `tasks(run_id, status)`, `messages(run_id, step_key)`, `messages(run_id, id)`.

## Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `IOF_DATABASE_URL` | *(required — no fallback)* | Engine DB URL (system of record; resolved at request time, API returns 503 when unset) |
| `IOF_ROOT` | `.iof` | State directory |
| `IOF_BIN` | `ioagentfarm` | Path to CLI binary |
| `IOF_AGENTFARM_DIR` | `../io-agentfarm` | Source dir for YAML workflow discovery |
| `IOF_UI_CORS` | `*` | CORS origins (comma-separated) |
| `IOF_UI_SSE_POLL` | `0.5` | SSE poll interval (seconds) |

## API route structure

All routes prefixed with `/api`. Sessions are nested under workflows:
- `/api/health`, `/api/agents` — meta
- `/api/workspaces/{id}` — workspace CRUD
- `/api/workflows/{code}` — workflow discovery
- `/api/workflows/{wf}/sessions/{id}` — session lifecycle
- `/api/workflows/{wf}/sessions/{id}/messages/stream` — SSE

## Testing conventions

- In-memory SQLite with full schema (see `conftest.py`)
- Seeded test data: 1 workspace, 1 workflow, 2 runs, 5 steps, 5 messages
- All `get_db` calls patched to test connection
- `q()` patched to return SQL unchanged (SQLite mode)
- `app.workflow_defs.discover_workflow_sources()` / `pack_workflow_dirs()` patched to RAISE — proof that no list/detail read touches disk (sync tests re-patch locally)
- Subprocess calls (`ioagentfarm` CLI) mocked via `unittest.mock`
- Class-based test organization
- Assertions on HTTP status codes and JSON payload structure

## Code conventions

- Type hints throughout (Python 3.11+)
- Routers use plural resource names (`/workspaces`, `/workflows`, `/sessions`)
- Status values: `running`, `done`, `failed`, `pending` for runs and steps
- Timestamps as ISO format strings
- Cursor-based pagination via `after_id` parameter
- HTTPException with 404/400/500 for errors
- Standard Python logging, one logger per module
