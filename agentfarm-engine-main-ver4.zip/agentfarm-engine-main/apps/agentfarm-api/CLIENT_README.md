# AI Core Harness Studio API

The backend for the Studio. It serves the agent, skill and workflow catalogues,
run history and operational insights to the Studio front end, and handles login.
Everything it reads and writes goes through the database. It never executes a
run and holds no solution content on disk.

## Install and run

From this directory:

```bash
python -m venv .venv
.venv/Scripts/pip install -e .
cp env.example .env                       # then fill it in
.venv/Scripts/uvicorn app.main:app --port 8002
curl http://localhost:8002/api/health
```

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `IOF_DATABASE_URL` | *required* | the engine database. Must be the same one the engine uses. Requests return 503 while it is unset |
| `IOF_RUN_API_URL` | `http://localhost:8111` | the engine web API. Starting a run and chatting to an agent are forwarded there |
| `IOF_UI_CORS` | `*` | comma-separated origins allowed to call this API |
| `IOF_AUTH_JWT_SECRET` | `change-me` | signs the session tokens. Set it |
| `CLIENT_ID` / `CLIENT_SECRET` / `TENANT_ID` / `REDIRECT_URI` | *(none)* | Microsoft Entra single sign-on |

On PostgreSQL the tables live in the `iof` schema; the app sets `search_path`
itself.

## Operating notes

- **This pod has no solution content.** Agents, skills and workflows reach it
  only through the database. If the Studio shows an empty catalogue, run
  `aicore sync` on the engine.
- **Starting a run is a handover.** If `IOF_RUN_API_URL` does not point at a
  reachable engine, run creation fails even though the Studio is otherwise
  healthy.
- **Requests are workspace-scoped by the `X-Workspace-Id` header.** An absent or
  unrecognised value resolves to the `default` workspace rather than failing, so
  check the header first when a tenant looks empty.
- **Never set `IOF_AUTH_DEV=1` in a deployment.** It accepts any credentials at
  login. It exists for local development only.

## Next

- [`../../docs/aicore/`](../../docs/aicore/) for the workspace, agent and
  workflow model behind the catalogues this API serves.
- The Studio front end is a separate deployment with its own CLIENT_README, in
  the sibling directory.
