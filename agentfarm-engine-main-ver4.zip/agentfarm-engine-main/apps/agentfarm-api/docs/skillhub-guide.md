# SkillHub — Agent Skills Registry

End-to-end guide for the SkillHub module: a portable, self-contained registry for managing AI agent skill documents.

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [SKILL.md Format](#skillmd-format)
4. [API Reference](#api-reference)
5. [Security](#security)
6. [Search & Discovery](#search--discovery)
7. [Community Features](#community-features)
8. [Integration Guide](#integration-guide)
9. [Database Schema](#database-schema)
10. [Configuration](#configuration)
11. [Testing](#testing)

---

## Overview

SkillHub is a registry for **agent skills** — markdown-based instruction documents (SKILL.md) that teach AI agents how to perform specific tasks. Inspired by [ClawHub](https://clawhub.ai/), it provides:

- Upload skills as single SKILL.md files or multi-file ZIP bundles
- Semver versioning with custom tags (stable, beta, etc.)
- Semantic search powered by local embeddings (fastembed + numpy)
- Built-in security scanning (8 rules, no external dependencies)
- Community features: stars, comments, reporting with auto-moderation
- Rename with redirect aliases, merge duplicates
- Content integrity verification via SHA-256 hashing
- Append-only audit trail for all mutations

**Key design principle:** SkillHub is a **portable, self-contained Python package** (`skillhub/`) with zero imports from the host project. It integrates into any FastAPI application via dependency injection.

---

## Architecture

```
                                    ┌─────────────────────┐
    Human / Agent                   │     S3 Bucket        │
         │                          │  skills/{slug}/      │
         │  Upload SKILL.md         │    {version}/        │
         │  or ZIP bundle           │      SKILL.md        │
         ▼                          │      scripts/        │
┌─────────────────┐    store files  │      config/         │
│   SkillHub API  │───────────────►│      ...             │
│  /api/skills/*  │                 └─────────────────────┘
│                 │
│  ┌───────────┐  │    read/write   ┌─────────────────────┐
│  │ Validator │  │◄───────────────►│     Database         │
│  │ Scanner   │  │                 │  skills              │
│  └───────────┘  │                 │  skill_versions      │
│                 │                 │  skill_files          │
│  ┌───────────┐  │                 │  skill_version_tags  │
│  │ Search    │  │                 │  skill_stars          │
│  │ Index     │  │                 │  skill_comments      │
│  │(in-memory)│  │                 │  skill_reports       │
│  └───────────┘  │                 │  skill_redirects     │
└─────────────────┘                 │  skill_audit_log     │
                                    └─────────────────────┘
```

### Data Flow

**Publish:**
```
Upload (SKILL.md or ZIP)
  → Validate file size (50MB max)
  → Detect format (ZIP or bare file)
  → If ZIP: extract, validate each file (no binaries, allowed extensions only)
  → Parse SKILL.md (yaml.safe_load frontmatter + markdown body)
  → Validate frontmatter (name, version, tags, roles)
  → Run security scanner (8 rules → risk_score 0.0-1.0)
  → Generate embedding (fastembed → 384-dim vector)
  → Upload files to S3 (one S3 object per file)
  → Insert into DB (skills + skill_versions + skill_files + audit_log)
  → Update search index (in-memory)
  → Return SkillDetail response
```

**Search:**
```
Query string
  → Embed query (same model)
  → Cosine similarity against in-memory index
  → Hybrid scoring: vector (70%) + lexical (20%) + popularity (10%)
  → Fetch matching skill records from DB
  → Apply post-filters (tags, role, status, workspace)
  → Return ranked list
```

**Download:**
```
GET /api/skills/{slug}/download
  → Resolve slug (follow redirects if renamed)
  → Look up version (latest, specific, or by tag)
  → If bundle (file_count > 1): reconstruct ZIP from S3 files
  → If single file: stream SKILL.md directly
  → Increment download count + audit log
```

---

## SKILL.md Format

Every skill must contain a `SKILL.md` file with YAML frontmatter:

```markdown
---
name: Code Review Bot
description: Teaches agents to perform thorough, constructive code reviews
version: 1.0.0
tags:
  - code-review
  - quality
  - best-practices
target_roles:
  - reviewer
  - developer
requires:
  tools:
    - git
    - diff
  env_vars: []
  network: false
config:
  max_files_per_review: 20
  severity_levels:
    - critical
    - warning
    - suggestion
---

# Code Review Bot

## Overview
When reviewing code, follow these structured steps...

## Step 1: Understand the Context
Read the PR description and linked issues before looking at code.

## Step 2: Check for Common Issues
- Security vulnerabilities (injection, XSS, auth bypass)
- Performance problems (N+1 queries, missing indexes)
- Error handling gaps
...
```

### Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `name` | string | Human-readable name (max 200 chars) |
| `version` | string | Semver: `major.minor.patch` |

### Optional Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `description` | string | `""` | Short description |
| `tags` | list[string] | `[]` | Lowercase, hyphenated tags |
| `target_roles` | list[string] | `[]` | Agent roles this skill applies to |
| `requires.tools` | list[string] | `[]` | CLI tools the skill needs |
| `requires.env_vars` | list[string] | `[]` | Environment variables needed |
| `requires.network` | bool | `false` | Whether network access is needed |
| `config` | dict | `{}` | Arbitrary configuration |

### Multi-File Bundles

Skills can include supporting files (scripts, configs, templates) by uploading a ZIP archive:

```
my-skill.zip
├── SKILL.md              (required, must be at root)
├── scripts/
│   ├── setup.sh
│   └── run.py
├── config/
│   └── settings.yaml
└── templates/
    └── report.md
```

**Constraints:**
- Total archive size: 50MB max
- Per-file size: 10MB max
- Text files only — binaries are rejected (ELF, PE, Mach-O, images, nested ZIPs, etc.)
- Allowed extensions: `.md`, `.py`, `.sh`, `.yaml`, `.yml`, `.json`, `.toml`, `.txt`, `.cfg`, `.ini`, `.sql`, `.html`, `.css`, `.js`, `.ts`, `.go`, `.java`, `.rs`, `.c`, `.h`, `.cpp`, `.rb`, `.r`, and more
- OS junk automatically stripped (`__MACOSX/`, `.DS_Store`, `Thumbs.db`)
- Path traversal rejected (`..` in file paths)

---

## API Reference

Base path: `/api/skills`

### Create a Skill

```bash
# Single SKILL.md
curl -X POST /api/skills?owner_id=user_1 \
  -F "file=@SKILL.md;type=text/markdown"

# ZIP bundle
curl -X POST /api/skills?owner_id=user_1 \
  -F "file=@my-skill.zip;type=application/zip"
```

**Response (201):**
```json
{
  "skill_id": "sk_a1b2c3d4e5f6",
  "slug": "code-review-bot",
  "name": "Code Review Bot",
  "description": "Teaches agents to perform thorough code reviews",
  "version": "1.0.0",
  "tags": ["code-review", "quality"],
  "target_roles": ["reviewer"],
  "status": "active",
  "scan_status": "clean",
  "content_hash": "sha256:abcdef...",
  "file_count": 3,
  "files": [
    {"file_path": "SKILL.md", "file_size": 2048, "content_hash": "sha256:...", "s3_key": "skills/code-review-bot/1.0.0/SKILL.md"},
    {"file_path": "scripts/setup.sh", "file_size": 128, "content_hash": "sha256:...", "s3_key": "..."},
    {"file_path": "config/settings.yaml", "file_size": 64, "content_hash": "sha256:...", "s3_key": "..."}
  ]
}
```

### List & Search Skills

List and search are split into two endpoints:

- `GET /api/skills` — plain list with metadata filters and **cursor pagination**
- `GET /api/skills/search` — **semantic search** (embedding-ranked), offset pagination

Both return the same envelope:

```json
{ "items": [ ... ], "next_cursor": "Mg" }
```

`next_cursor` is `null` when there are no more pages.

```bash
# List, ordered by recency (id DESC), with metadata filters
curl "/api/skills?tags=security,quality&role=developer&limit=20"

# Cursor pagination — pass next_cursor from the previous response
curl "/api/skills?limit=20&cursor=Mg"

# Semantic search
curl "/api/skills/search?q=code+review+best+practices"

# Search with the same metadata filters layered on top
curl "/api/skills/search?q=testing&tags=pytest&role=developer&limit=10"
```

Filters (`tags`, `role`, `status`, `workspace_id`) work on both endpoints. Search supports `limit`/`offset`; list supports `limit`/`cursor`.

### Publish New Version

```bash
curl -X POST /api/skills/code-review-bot/versions?changelog=Added+security+rules&owner_id=user_1 \
  -F "file=@SKILL-v2.md;type=text/markdown"
```

Version must be strictly greater than the current latest (semver comparison). Content deduplication prevents publishing identical content.

### Version Tags

```bash
# Tag version 1.0.0 as "stable"
curl -X PUT /api/skills/code-review-bot/tags/stable \
  -H "Content-Type: application/json" \
  -d '{"version": "1.0.0"}'

# Download by tag
curl /api/skills/code-review-bot/download?tag=stable

# Remove tag
curl -X DELETE /api/skills/code-review-bot/tags/stable
```

The `latest` tag is auto-managed and cannot be modified or deleted.

### Download

```bash
# Download latest version (returns SKILL.md or ZIP depending on bundle)
curl -O /api/skills/code-review-bot/download

# Download specific version
curl -O /api/skills/code-review-bot/download?version=1.0.0

# Download by tag
curl -O /api/skills/code-review-bot/download?tag=stable

# Download individual file from bundle
curl /api/skills/code-review-bot/files/1.0.0/scripts/setup.sh

# List files in a version
curl /api/skills/code-review-bot/versions/1.0.0/files
```

Response headers include `X-Content-Hash` for client-side integrity verification.

### Verify Integrity

```bash
curl /api/skills/code-review-bot/verify
# → {"valid": true, "expected": "sha256:abc...", "actual": "sha256:abc...", "version": "1.0.0"}
```

Re-downloads from S3 and recomputes the hash to detect corruption or tampering.

### Rename

```bash
curl -X POST /api/skills/code-review-bot/rename \
  -H "Content-Type: application/json" \
  -d '{"new_slug": "code-review-v2", "owner_id": "user_1"}'
```

Creates a redirect: `GET /api/skills/code-review-bot` returns 301 to `/api/skills/code-review-v2`. Existing redirects are chained.

### Soft-delete & Undelete

```bash
# Soft-delete (status -> 'removed'; pulled from search index)
curl -X DELETE /api/skills/code-review-bot

# Restore (status -> 'active'; re-indexed for search)
curl -X POST /api/skills/code-review-bot/undelete \
  -H "Content-Type: application/json" \
  -d '{"owner_id": "user_1"}'
```

Undelete is owner-gated when `owner_id` is supplied and the skill has a recorded owner. Only `removed` skills can be undeleted; calling it on an active skill returns `400`.

### Find & Merge Duplicates

```bash
# Find duplicates (embedding similarity > 0.85 + name similarity > 0.8)
curl /api/skills/code-review-bot/duplicates
# → [{"skill_id": "sk_...", "slug": "code-reviews", "similarity": 0.92, "match_type": "embedding"}]

# Merge (requires owner of both skills)
curl -X POST /api/skills/code-reviews/merge \
  -H "Content-Type: application/json" \
  -d '{"target_slug": "code-review-bot", "owner_id": "user_1"}'
```

Merge re-assigns versions, stars, comments, and tags from source to target. Creates a redirect from source slug. Soft-deletes the source.

---

## Security

### Built-in Scanner

Every upload is automatically scanned. The scanner runs pure Python regex pattern matching (no external dependencies).

| Rule | Severity | Detects |
|------|----------|---------|
| `EXEC_CALL` | high | `eval()`, `exec()`, `compile()`, `__import__()` |
| `SHELL_CMD` | high | `subprocess`, `os.system`, `os.popen`, backticks, `$(...)` |
| `FILE_WRITE` | medium | `open('w')`, `shutil.rmtree`, `os.remove` |
| `NETWORK_UNDECLARED` | medium | `requests.`/`urllib.`/`socket.` when `requires.network` is false |
| `ENV_ACCESS` | medium | `os.environ`/`os.getenv` for undeclared vars |
| `OBFUSCATED` | high | Base64 blocks > 200 chars, hex sequences > 100 chars |
| `CREDENTIAL_PATTERN` | high | `sk-*`, `ghp_*`, `AKIA*`, password assignments |
| `EXCESSIVE_SIZE` | low | Body > 50KB |

**Scoring:** high=0.4, medium=0.2, low=0.05 per finding. Capped at 1.0.

Skills with `risk_score >= 0.7` are automatically flagged (`scan_status = "flagged"`). They remain published but are visible for admin review.

```bash
# View scan results
curl /api/skills/code-review-bot/scan
# → {"version": "1.0.0", "scan_status": "clean", "scan_result": {"risk_score": 0.0, "findings": []}}

# Re-scan (after rule updates)
curl -X POST /api/skills/code-review-bot/rescan
```

### Multi-File Bundle Security

For ZIP uploads, all files in the bundle are scanned (not just SKILL.md). Additionally:

- **No-binary enforcement:** Files are checked for magic bytes (ELF, PE, Mach-O, PNG, JPEG, ZIP, gzip, etc.) and null bytes
- **Extension allow-list:** Only text-based file extensions are permitted
- **Path traversal prevention:** Paths containing `..` or starting with `/` are rejected
- **Nested archive rejection:** ZIP files within the archive are blocked
- **OS junk removal:** `__MACOSX/`, `.DS_Store`, `Thumbs.db` are silently skipped

### Other Security Measures

- **YAML safe_load only** — prevents deserialization attacks
- **File size validation before parsing** — prevents memory exhaustion
- **SHA-256 content hashing** — integrity verification per file and per bundle
- **Content deduplication** — rejects identical content across versions
- **Status state machine** — enforced transitions (active/hidden/deprecated/removed)
- **Audit trail** — every mutation logged to `skill_audit_log` (append-only)

---

## Search & Discovery

### How It Works

SkillHub uses **fastembed** (ONNX-based, local, no API key) with the `BAAI/bge-small-en-v1.5` model (384 dimensions) for embeddings.

**At publish time:**
1. Build embedding text from: name + description + tags + SKILL.md body + supplementary file snippets
2. Generate 384-dim vector via fastembed
3. Store vector as JSON in `skill_versions.embedding` column
4. Add to in-memory numpy index

**At search time:**
1. Embed query with the same model
2. Compute cosine similarity via numpy dot product (sub-millisecond for <10K skills)
3. Apply hybrid scoring:
   - **Vector score** (70%) — semantic similarity
   - **Lexical score** (20%) — exact/prefix matches on slug and name
   - **Popularity score** (10%) — `log1p(download_count)` normalized
4. Fetch full records from DB for top-K results
5. Apply post-filters (tags, role, status, workspace)

**On startup:**
- Stored embeddings are loaded from DB into numpy — no re-embedding needed

### Duplicate Detection

`GET /{slug}/duplicates` uses two signals:
1. **Embedding similarity > 0.85** — catches semantically similar skills with different names
2. **Name similarity > 0.8** (via `difflib.SequenceMatcher`) — catches typos and variations

---

## Community Features

### Stars

```bash
curl -X POST /api/skills/code-review-bot/star \
  -H "Content-Type: application/json" -d '{"user_id": "agent_1"}'
# → {"message": "Starred", "starred": true}

curl -X DELETE "/api/skills/code-review-bot/star?user_id=agent_1"
# → {"message": "Unstarred", "starred": false}
```

Idempotent — starring twice is a no-op. Star count is denormalized on the `skills` table for fast listing.

### Comments

```bash
# Add
curl -X POST /api/skills/code-review-bot/comments \
  -H "Content-Type: application/json" -d '{"user_id": "agent_1", "content": "Works great!"}'

# List
curl /api/skills/code-review-bot/comments

# Delete (own only)
curl -X DELETE "/api/skills/code-review-bot/comments/42?user_id=agent_1"
```

### Community Reporting

```bash
curl -X POST /api/skills/code-review-bot/report \
  -H "Content-Type: application/json" \
  -d '{"reporter_id": "user_3", "reason": "malicious", "detail": "Contains obfuscated code"}'
```

**Reasons:** `inappropriate`, `malicious`, `duplicate`, `spam`, `other`

**Auto-moderation:** When 3 unique users report a skill, it is automatically hidden (`status = "hidden"`). One report per user per skill (duplicate reports return 409).

---

## Integration Guide

### Minimal Setup (Any FastAPI Project)

```python
from fastapi import FastAPI
from skillhub import create_skillhub_router

app = FastAPI()

# 1. Implement DBProvider (2 methods)
class MyDBProvider:
    def get_connection(self):
        # Return context manager yielding connection with
        # .execute(), .fetchone(), .fetchall(), .commit()
        ...

    def placeholder(self):
        return "?"  # SQLite
        # return "%s"  # PostgreSQL

# 2. Create and mount the router
router = create_skillhub_router(
    db=MyDBProvider(),
    s3_client_factory=lambda: boto3.client("s3"),
    s3_bucket="my-skills-bucket",
)
app.include_router(router)
```

### Create Tables

```python
from skillhub.database import ensure_tables

ensure_tables(my_db_provider)  # Creates all 9 tables if they don't exist
```

### Custom Configuration

```python
from skillhub import SkillHubConfig

config = SkillHubConfig(
    max_file_size=52_428_800,        # 50MB (default)
    max_per_file_size=10_485_760,    # 10MB per file in bundle (default)
    s3_prefix="skills",              # S3 key prefix (default)
    embedding_model="BAAI/bge-small-en-v1.5",  # (default)
    report_auto_hide_threshold=3,    # auto-hide after N reports (default)
    scan_flag_threshold=0.7,         # flag skills above this score (default)
    api_prefix="/api/skills",        # route prefix (default)
)

router = create_skillhub_router(db=..., s3_client_factory=..., s3_bucket=..., config=config)
```

### PostgreSQL Note

For PostgreSQL with psycopg2, the `DBProvider.get_connection()` must yield an object with `.execute()`. Since psycopg2 connections don't have `.execute()`, wrap with a cursor:

```python
class CursorWrapper:
    def __init__(self, con):
        self._con = con
        self._cursor = con.cursor()

    def execute(self, sql, params=()):
        self._cursor.execute(sql, params)
        return self._cursor

    def commit(self):
        self._con.commit()
```

---

## Database Schema

### 9 Tables

| Table | Purpose |
|-------|---------|
| `skills` | Skill registry — one row per logical skill |
| `skill_versions` | Immutable version snapshots with embeddings |
| `skill_files` | Individual files within a bundle |
| `skill_audit_log` | Append-only mutation trail |
| `skill_version_tags` | Named pointers to versions (stable, beta, latest) |
| `skill_stars` | User stars (unique per user per skill) |
| `skill_comments` | User comments |
| `skill_reports` | Community reports with reasons |
| `skill_redirects` | Slug rename aliases |

### Key Columns

**skills:**
`skill_id` (unique), `slug` (unique), `name`, `description`, `tags` (JSON), `target_roles` (JSON), `requires` (JSON), `owner_id`, `workspace_id`, `status`, `latest_version`, `download_count`, `star_count`, `report_count`, `scan_status`

**skill_versions:**
`skill_id`, `version` (unique per skill), `content_hash` (SHA-256), `s3_key`, `file_size`, `file_count`, `bundle_size`, `frontmatter` (JSON), `embedding` (JSON array), `scan_result` (JSON)

**skill_files:**
`skill_id`, `version`, `file_path` (unique per version), `file_size`, `content_hash`, `s3_key`

---

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_file_size` | `52_428_800` (50MB) | Maximum upload size |
| `max_per_file_size` | `10_485_760` (10MB) | Max individual file in bundle |
| `s3_prefix` | `"skills"` | S3 key prefix |
| `embedding_model` | `"BAAI/bge-small-en-v1.5"` | fastembed model |
| `report_auto_hide_threshold` | `3` | Reports to trigger auto-hide |
| `scan_flag_threshold` | `0.7` | Risk score to flag as suspicious |
| `api_prefix` | `"/api/skills"` | API route prefix |

---

## Testing

SkillHub ships with 178 self-contained tests that run independently of the host project:

```bash
# Run all SkillHub tests
pytest skillhub/tests/ -v

# Run by category
pytest skillhub/tests/test_validator.py -v    # 87 tests — parsing, validation, scanner, archive
pytest skillhub/tests/test_search.py -v       # 18 tests — embeddings, search, duplicates
pytest skillhub/tests/test_router.py -v       # 73 tests — all endpoints
```

Tests use in-memory SQLite, mocked S3, and mocked fastembed (no model download needed in CI).
