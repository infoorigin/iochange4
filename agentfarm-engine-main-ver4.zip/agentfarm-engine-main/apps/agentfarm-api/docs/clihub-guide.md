# CLI Hub — Agent CLI Tools Registry

End-to-end guide for the CLI Hub module: a portable, self-contained registry for managing agent-native CLI tool registrations.

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [CLI Tool Registration Format](#cli-tool-registration-format)
4. [API Reference](#api-reference)
5. [Security](#security)
6. [Search & Discovery](#search--discovery)
7. [Agent Discovery](#agent-discovery)
8. [Community Features](#community-features)
9. [Integration Guide](#integration-guide)
10. [Database Schema](#database-schema)
11. [Configuration](#configuration)
12. [Testing](#testing)

---

## Overview

CLI Hub is a registry for **agent-native CLI tools** — pip-installable Python CLI packages (typically Click-based) that wrap GUI software so AI agents can control them deterministically via text commands with JSON output. Inspired by [CLI-Anything](https://github.com/HKUDS/CLI-Anything).

Unlike SkillHub (which stores files in S3), CLI Hub is **metadata-only** — CLI tool packages live in git repos and are installed via pip. The hub tracks how to find, install, and use them.

Key features:
- Register CLI tools with install commands, entry points, categories, and requirements
- Semver versioning with custom tags
- Semantic search powered by local embeddings
- CLI-specific security scanning (shell injection, unsafe URLs, unknown registries)
- Community features: stars, comments, reporting with auto-moderation
- Agent discovery endpoints: `catalog.txt` (plain text) and `install-info` (JSON)
- Rename with redirect aliases, merge duplicates
- Audit trail for all mutations

**Key design principle:** CLI Hub is a **portable, self-contained Python package** (`clihub/`) with zero imports from the host project. No S3 dependency.

---

## Architecture

```
                                      ┌──────────────────────┐
    Human / Agent                     │   Git Repositories    │
         │                            │                       │
         │  Register CLI metadata     │  github.com/org/repo  │
         │  (JSON body)               │    └── tool/          │
         ▼                            │        ├── setup.py   │
┌──────────────────┐                  │        ├── cli.py     │
│   CLI Hub API    │   pip install    │        └── SKILL.md   │
│  /api/cli-tools  │─ ─ ─ ─ ─ ─ ─ ─ ►│                       │
│                  │   (by agents)    └──────────────────────┘
│  ┌────────────┐  │
│  │ Validator  │  │    read/write   ┌──────────────────────┐
│  │ Scanner    │  │◄───────────────►│      Database         │
│  └────────────┘  │                 │  cli_tools            │
│                  │                 │  cli_versions          │
│  ┌────────────┐  │                 │  cli_version_tags     │
│  │ Search     │  │                 │  cli_stars            │
│  │ Index      │  │                 │  cli_comments         │
│  │ (in-memory)│  │                 │  cli_reports          │
│  └────────────┘  │                 │  cli_redirects        │
└──────────────────┘                 │  cli_audit_log        │
                                     └──────────────────────┘
```

### Data Flow

**Register:**
```
JSON body (name, version, install_cmd, entry_point, ...)
  → Validate all fields (name, version, entry_point format, install_cmd safety)
  → Validate URLs (homepage, skill_md_url — HTTPS only, no IPs)
  → Run security scanner (8 rules → risk_score 0.0-1.0)
  → Generate embedding (fastembed → 384-dim vector)
  → Insert into DB (cli_tools + cli_versions + audit_log)
  → Update search index (in-memory)
  → Return CLIToolDetail response
```

**Agent Installs a Tool:**
```
Agent queries: GET /api/cli-tools/catalog.txt
  → Finds matching tool (e.g., "gimp" for image editing)
  → GET /api/cli-tools/gimp/install-info
  → Runs: pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness
  → Uses: cli-anything-gimp --json layer add "Background"
```

---

## CLI Tool Registration Format

CLI tools are registered via JSON body (not file upload):

```json
{
  "name": "gimp",
  "display_name": "GIMP",
  "description": "Image editing CLI for AI agents — layers, filters, exports with JSON output",
  "version": "1.0.0",
  "category": "creative",
  "entry_point": "cli-anything-gimp",
  "install_cmd": "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
  "homepage": "https://www.gimp.org",
  "requires": "GIMP 2.10+",
  "skill_md_url": "gimp/agent-harness/cli_anything/gimp/skills/SKILL.md",
  "tags": ["image", "editing", "creative"],
  "contributor": "CLI-Anything-Team",
  "contributor_url": "https://github.com/HKUDS/CLI-Anything",
  "owner_id": "user_1"
}
```

### Required Fields

| Field | Type | Validation |
|-------|------|------------|
| `name` | string | Max 200 chars, safe characters only |
| `version` | string | Semver: `major.minor.patch` |
| `entry_point` | string | Lowercase alphanumeric + hyphens, max 100 chars |
| `install_cmd` | string | Must start with `pip install`, no shell metacharacters |

### Optional Fields

| Field | Type | Description |
|-------|------|-------------|
| `display_name` | string | Human-readable name (e.g., "GIMP" vs "gimp") |
| `description` | string | What the CLI does |
| `category` | string | Classification (ai, creative, 3d, devtools, etc.) |
| `homepage` | string | Official software URL (HTTPS validated) |
| `requires` | string | Runtime dependencies description |
| `skill_md_url` | string | Path/URL to the tool's SKILL.md |
| `tags` | list[string] | Searchable tags |
| `contributor` | string | Who built it |
| `contributor_url` | string | Contributor's profile URL |
| `owner_id` | string | Owner for access control |
| `workspace_id` | string | Optional workspace scoping |

---

## API Reference

Base path: `/api/cli-tools`

### Register a CLI Tool

```bash
curl -X POST /api/cli-tools \
  -H "Content-Type: application/json" \
  -d '{
    "name": "gimp",
    "display_name": "GIMP",
    "description": "Image editing CLI for AI agents",
    "version": "1.0.0",
    "category": "creative",
    "entry_point": "cli-anything-gimp",
    "install_cmd": "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
    "homepage": "https://www.gimp.org",
    "requires": "GIMP 2.10+",
    "tags": ["image", "editing"],
    "contributor": "CLI-Anything-Team",
    "owner_id": "user_1"
  }'
```

**Response (201):**
```json
{
  "cli_id": "cli_a1b2c3d4e5f6",
  "slug": "gimp",
  "name": "gimp",
  "display_name": "GIMP",
  "description": "Image editing CLI for AI agents",
  "category": "creative",
  "entry_point": "cli-anything-gimp",
  "install_cmd": "pip install git+https://...",
  "latest_version": "1.0.0",
  "install_count": 0,
  "star_count": 0,
  "scan_status": "clean",
  "tags": ["image", "editing"],
  "homepage": "https://www.gimp.org",
  "requires": "GIMP 2.10+"
}
```

### Search CLI Tools

```bash
# Semantic search
curl "/api/cli-tools?q=image+editing"

# Filter by category
curl "/api/cli-tools?category=ai"

# Filter by tags
curl "/api/cli-tools?tags=llm,inference"

# Combine
curl "/api/cli-tools?q=3d+modeling&category=3d&limit=10"
```

### Get Tool Detail

```bash
curl /api/cli-tools/gimp
```

Returns full metadata including `homepage`, `requires`, `skill_md_url`, `contributor_url`.

### Update Metadata

```bash
curl -X PATCH /api/cli-tools/gimp \
  -H "Content-Type: application/json" \
  -d '{"description": "Updated description", "tags": ["image", "editing", "photo"]}'
```

Updatable fields: `status`, `tags`, `description`, `category`, `homepage`, `requires`.

### Publish New Version

```bash
curl -X POST /api/cli-tools/gimp/versions \
  -H "Content-Type: application/json" \
  -d '{
    "version": "2.0.0",
    "install_cmd": "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
    "entry_point": "cli-anything-gimp",
    "requires": "GIMP 2.10+",
    "changelog": "Added batch processing support",
    "owner_id": "user_1"
  }'
```

Version must be strictly greater than current latest.

### Version Tags

```bash
# Tag version 1.0.0 as "stable"
curl -X PUT /api/cli-tools/gimp/tags/stable \
  -H "Content-Type: application/json" -d '{"version": "1.0.0"}'

# Get install info for a tagged version
curl /api/cli-tools/gimp/install-info?tag=stable

# Remove tag
curl -X DELETE /api/cli-tools/gimp/tags/stable
```

### Soft-Delete

```bash
curl -X DELETE /api/cli-tools/gimp
# → {"message": "CLI tool removed", "slug": "gimp"}
```

Status changes to `removed`. Data persists in DB for audit purposes.

### Rename with Redirects

```bash
curl -X POST /api/cli-tools/gimp/rename \
  -H "Content-Type: application/json" \
  -d '{"new_slug": "gimp-cli", "owner_id": "user_1"}'
```

Old slug returns 301 redirect. Existing redirects are chained.

### Find & Merge Duplicates

```bash
# Find duplicates
curl /api/cli-tools/gimp/duplicates
# → [{"cli_id": "cli_...", "slug": "gimp-editor", "similarity": 0.91, "match_type": "embedding"}]

# Merge (owner of both required)
curl -X POST /api/cli-tools/gimp-editor/merge \
  -H "Content-Type: application/json" \
  -d '{"target_slug": "gimp", "owner_id": "user_1"}'
```

---

## Security

### CLI-Specific Security Scanner

Every registration and version publish is automatically scanned.

| Rule | Severity | Detects |
|------|----------|---------|
| `SHELL_INJECTION` | high | Shell metacharacters in install_cmd: `;`, `&&`, `\|\|`, `\|`, backticks, `$()` |
| `UNSAFE_INSTALL_URL` | high | Non-HTTPS URLs, IP address hosts, localhost/127.x |
| `SUSPICIOUS_SUBDIRECTORY` | medium | Path traversal (`..`) in pip `#subdirectory=` specifier |
| `UNKNOWN_REGISTRY` | medium | Install from non-PyPI, non-GitHub, non-GitLab, non-Bitbucket |
| `EXCESSIVE_PERMISSIONS` | medium | `--user` or `--system` flags in install_cmd |
| `ENTRY_POINT_MISMATCH` | low | Entry point doesn't follow naming conventions |
| `MISSING_HOMEPAGE` | low | No homepage URL provided |
| `MISSING_SKILL_MD` | low | No skill_md_url provided |

**Scoring:** high=0.4, medium=0.2, low=0.05 per finding. Capped at 1.0. Tools with `risk_score >= 0.7` are flagged.

```bash
# View scan results
curl /api/cli-tools/gimp/scan

# Re-scan
curl -X POST /api/cli-tools/gimp/rescan
```

### Input Validation

| Field | Validation |
|-------|------------|
| `install_cmd` | Must start with `pip install`, no shell metacharacters |
| `entry_point` | `^[a-z][a-z0-9-]*$`, max 100 chars |
| `homepage` | Valid URL, HTTPS preferred, no IP addresses, no localhost |
| `skill_md_url` | Valid URL if provided |
| `version` | Strict semver `major.minor.patch` |
| `slug` | `^[a-z0-9][a-z0-9-]*[a-z0-9]$`, 2-100 chars |

### Trusted Hosts

The `UNKNOWN_REGISTRY` rule warns (but doesn't block) when install URLs point to hosts outside: `github.com`, `gitlab.com`, `bitbucket.org`, `pypi.org`.

---

## Search & Discovery

### Semantic Search

Same engine as SkillHub — fastembed (BAAI/bge-small-en-v1.5, 384 dims) + numpy.

**Embedding text built from:** name + display_name + description + category + tags + requires

**Hybrid scoring:**
- Vector similarity: 70%
- Lexical match (slug/name exact/prefix): 20%
- Popularity (log install_count): 10%

### Category Filtering

Common categories: `ai`, `creative`, `3d`, `devtools`, `data`, `system`, `media`, `generation`

```bash
curl "/api/cli-tools?category=ai"
```

---

## Agent Discovery

CLI Hub provides two lightweight endpoints specifically designed for AI agents:

### Plain Text Catalog

```bash
curl /api/cli-tools/catalog.txt
```

Response:
```
# CLI Hub — Agent-Native CLI Tools Catalog

## GIMP
Image editing CLI for AI agents
Install: pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness
Command: cli-anything-gimp
Category: creative

## Ollama
Local LLM inference and model management
Install: pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=ollama/agent-harness
Command: cli-anything-ollama
Category: ai
```

Agents can fetch this single URL to discover all available tools.

### Install Info (Lightweight JSON)

```bash
curl /api/cli-tools/gimp/install-info
```

Response:
```json
{
  "install_cmd": "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
  "entry_point": "cli-anything-gimp",
  "requires": "GIMP 2.10+",
  "version": "1.0.0"
}
```

This is the minimum an agent needs to install and use a tool. Increments the `install_count`.

### Agent Workflow

```
1. Agent needs image editing capability
2. Fetches: GET /api/cli-tools/catalog.txt
3. Finds "GIMP" matches the need
4. Fetches: GET /api/cli-tools/gimp/install-info
5. Runs: pip install git+https://...
6. Uses: cli-anything-gimp --json layer add "Background"
7. Parses JSON output for structured results
```

---

## Community Features

### Stars

```bash
curl -X POST /api/cli-tools/gimp/star -H "Content-Type: application/json" -d '{"user_id": "agent_1"}'
curl -X DELETE "/api/cli-tools/gimp/star?user_id=agent_1"
```

### Comments

```bash
curl -X POST /api/cli-tools/gimp/comments \
  -H "Content-Type: application/json" -d '{"user_id": "agent_1", "content": "Works great with Claude Code!"}'

curl /api/cli-tools/gimp/comments
curl -X DELETE "/api/cli-tools/gimp/comments/42?user_id=agent_1"
```

### Reporting

```bash
curl -X POST /api/cli-tools/gimp/report \
  -H "Content-Type: application/json" \
  -d '{"reporter_id": "user_3", "reason": "malicious", "detail": "Install URL is suspicious"}'
```

Reasons: `inappropriate`, `malicious`, `duplicate`, `spam`, `other`. Auto-hides at 3 unique reporters.

---

## Integration Guide

### Minimal Setup

```python
from fastapi import FastAPI
from clihub import create_clihub_router

app = FastAPI()

class MyDBProvider:
    def get_connection(self):
        ...  # context manager yielding connection
    def placeholder(self):
        return "?"  # or "%s" for PostgreSQL

router = create_clihub_router(db=MyDBProvider())
app.include_router(router)
```

No S3 needed — CLI Hub is metadata-only.

### Create Tables

```python
from clihub.database import ensure_tables
ensure_tables(my_db_provider)
```

### Custom Configuration

```python
from clihub import CLIHubConfig

config = CLIHubConfig(
    embedding_model="BAAI/bge-small-en-v1.5",
    report_auto_hide_threshold=3,
    scan_flag_threshold=0.7,
    api_prefix="/api/cli-tools",
)
router = create_clihub_router(db=my_db, config=config)
```

---

## Database Schema

### 8 Tables

| Table | Purpose |
|-------|---------|
| `cli_tools` | Tool registry — one row per logical CLI tool |
| `cli_versions` | Version snapshots with install commands and embeddings |
| `cli_audit_log` | Append-only mutation trail |
| `cli_version_tags` | Named pointers to versions |
| `cli_stars` | User stars |
| `cli_comments` | User comments |
| `cli_reports` | Community reports |
| `cli_redirects` | Slug rename aliases |

### Key Columns

**cli_tools:**
`cli_id` (unique), `slug` (unique), `name`, `display_name`, `description`, `category`, `entry_point`, `install_cmd`, `homepage`, `requires`, `skill_md_url`, `tags` (JSON), `owner_id`, `contributor`, `contributor_url`, `status`, `latest_version`, `install_count`, `star_count`, `report_count`, `scan_status`

**cli_versions:**
`cli_id`, `version` (unique per tool), `install_cmd`, `entry_point`, `requires`, `skill_md_url`, `changelog`, `embedding` (JSON), `scan_result` (JSON)

---

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `embedding_model` | `"BAAI/bge-small-en-v1.5"` | fastembed model |
| `report_auto_hide_threshold` | `3` | Reports to trigger auto-hide |
| `scan_flag_threshold` | `0.7` | Risk score to flag |
| `api_prefix` | `"/api/cli-tools"` | Route prefix |

---

## Testing

CLI Hub ships with 104 self-contained tests:

```bash
# Run all CLI Hub tests
pytest clihub/tests/ -v

# By category
pytest clihub/tests/test_validator.py -v    # 47 tests — validation, scanner
pytest clihub/tests/test_search.py -v       # 12 tests — embeddings, search
pytest clihub/tests/test_router.py -v       # 45 tests — all endpoints
```

Tests use in-memory SQLite and mocked fastembed. No external services needed.

---

## Comparison: SkillHub vs CLI Hub

| Aspect | SkillHub | CLI Hub |
|--------|----------|---------|
| **What it manages** | SKILL.md instruction documents | CLI tool registrations |
| **Storage** | S3 (files + ZIP bundles) | Database only (metadata) |
| **Upload format** | Multipart file upload | JSON body |
| **Install by agents** | Download SKILL.md | `pip install git+<url>` |
| **DI requirements** | DB + S3 client + S3 bucket | DB only |
| **Security focus** | Content scanning (exec, shell, creds) | URL/command scanning (injection, unsafe hosts) |
| **Unique features** | Multi-file bundles, hash verification | catalog.txt, install-info endpoint |
| **Tables** | 9 | 8 |
| **Tests** | 178 | 104 |
| **Shared** | Same DBProvider protocol, same search engine, same community features |
