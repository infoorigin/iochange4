"""CLI Hub routes — CRUD + catalog."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse, PlainTextResponse

from clihub.config import CLIHubConfig
from clihub.errors import ConflictError, NotFoundError, ValidationError
from clihub.schemas import CLIToolCreate, CLIToolUpdate
from clihub.service import CLIService


def register_routes(router: APIRouter, service: CLIService, config: CLIHubConfig) -> None:

    @router.get("/catalog.txt")
    def catalog_txt():
        rows = service.get_catalog()
        lines = ["# CLI Hub — Agent-Native CLI Tools Catalog", ""]
        for r in rows:
            lines.append(f"## {r.get('display_name') or r['name']}")
            if r.get("description"):
                lines.append(r["description"])
            lines.append(f"Install: {r.get('install_cmd', '')}")
            lines.append(f"Command: {r.get('entry_point', '')}")
            if r.get("category"):
                lines.append(f"Category: {r['category']}")
            lines.append("")
        return PlainTextResponse("\n".join(lines))

    @router.post("", status_code=201)
    def create_cli_tool(body: CLIToolCreate):
        try:
            return service.create_tool(body.model_dump())
        except (ValidationError, ValueError) as e:
            raise HTTPException(400, str(e))
        except ConflictError as e:
            raise HTTPException(409, str(e))

    @router.get("")
    def list_cli_tools(
        q_param: str | None = Query(None, alias="q"),
        category: str | None = Query(None),
        tags: str | None = Query(None),
        status: str = Query("active"),
        workspace_id: str | None = Query(None),
        limit: int = Query(50, ge=1, le=200),
        offset: int = Query(0, ge=0),
    ):
        return service.list_tools(q_param, category, tags, status, workspace_id, limit, offset)

    @router.get("/{slug}")
    def get_cli_tool(slug: str):
        try:
            result = service.get_tool(slug)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        if "_redirect" in result:
            return JSONResponse(status_code=301,
                                headers={"Location": f"{config.api_prefix}/{result['_redirect']}"},
                                content={"redirect": result["_redirect"]})
        return result

    @router.patch("/{slug}")
    def update_cli_tool(slug: str, body: CLIToolUpdate):
        try:
            return service.update_tool(slug, body.model_dump(exclude_none=True))
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except (ValidationError, ValueError) as e:
            raise HTTPException(400, str(e))

    @router.delete("/{slug}")
    def delete_cli_tool(slug: str):
        try:
            return service.delete_tool(slug)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))
