"""CLI Hub router assembly."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from clihub.config import CLIHubConfig
from clihub.search import CLISearchIndex
from clihub.service import CLIService

__all__ = ["build_router"]


def build_router(db: Any, config: CLIHubConfig, search_index: CLISearchIndex) -> APIRouter:
    service = CLIService(db, config, search_index)
    router = APIRouter(prefix=config.api_prefix, tags=["cli-tools"])

    from clihub.routers.tools import register_routes as tools_routes
    from clihub.routers.versions import register_routes as versions_routes
    from clihub.routers.community import register_routes as community_routes
    from clihub.routers.admin import register_routes as admin_routes

    tools_routes(router, service, config)
    versions_routes(router, service)
    community_routes(router, service)
    admin_routes(router, service)

    return router
