"""CLI Hub routes — versions, tags, install-info."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from clihub.errors import ConflictError, NotFoundError, ValidationError
from clihub.schemas import VersionPublish, VersionTagSet
from clihub.service import CLIService


def register_routes(router: APIRouter, service: CLIService) -> None:

    @router.get("/{slug}/versions")
    def list_versions(slug: str):
        try:
            return service.list_versions(slug)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.get("/{slug}/versions/{version}")
    def get_version(slug: str, version: str):
        try:
            return service.get_version(slug, version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.post("/{slug}/versions", status_code=201)
    def publish_version(slug: str, body: VersionPublish):
        try:
            return service.publish_version(slug, body.model_dump())
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except (ValidationError, ValueError) as e:
            raise HTTPException(400, str(e))
        except ConflictError as e:
            raise HTTPException(409, str(e))

    @router.get("/{slug}/install-info")
    def install_info(slug: str, tag: str | None = Query(None)):
        try:
            return service.get_install_info(slug, tag)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.put("/{slug}/tags/{tag}")
    def set_version_tag(slug: str, tag: str, body: VersionTagSet):
        """Point a named tag at a specific version."""
        if not tag.strip() or len(tag) > 100:
            raise HTTPException(400, "Tag must be 1-100 characters")
        try:
            return service.set_tag(slug, tag, body.version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))

    @router.delete("/{slug}/tags/{tag}")
    def delete_version_tag(slug: str, tag: str):
        try:
            return service.delete_tag(slug, tag)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))
