"""CLI Hub database abstraction — protocol-based dependency injection.

Uses the same DBProvider protocol as SkillHub.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, ContextManager, Protocol, runtime_checkable


@runtime_checkable
class DBProvider(Protocol):
    """Minimal contract a host project must satisfy."""

    def get_connection(self) -> ContextManager[Any]: ...
    def placeholder(self) -> str: ...


def q(sql: str, provider: DBProvider) -> str:
    """Rewrite ``?`` placeholders to the backend's style."""
    ph = provider.placeholder()
    if ph == "?":
        return sql
    return sql.replace("?", ph)


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS cli_tools (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cli_id          TEXT NOT NULL UNIQUE,
    name            TEXT NOT NULL,
    slug            TEXT NOT NULL UNIQUE,
    display_name    TEXT NOT NULL DEFAULT '',
    description     TEXT NOT NULL DEFAULT '',
    category        TEXT NOT NULL DEFAULT '',
    entry_point     TEXT NOT NULL DEFAULT '',
    install_cmd     TEXT NOT NULL DEFAULT '',
    homepage        TEXT NOT NULL DEFAULT '',
    requires        TEXT NOT NULL DEFAULT '',
    skill_md_url    TEXT NOT NULL DEFAULT '',
    tags            TEXT NOT NULL DEFAULT '[]',
    owner_id        TEXT NOT NULL DEFAULT '',
    contributor     TEXT NOT NULL DEFAULT '',
    contributor_url TEXT NOT NULL DEFAULT '',
    workspace_id    TEXT,
    status          TEXT NOT NULL DEFAULT 'active',
    latest_version  TEXT NOT NULL DEFAULT '',
    install_count   INTEGER NOT NULL DEFAULT 0,
    star_count      INTEGER NOT NULL DEFAULT 0,
    report_count    INTEGER NOT NULL DEFAULT 0,
    scan_status     TEXT NOT NULL DEFAULT 'pending',
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cli_versions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cli_id          TEXT NOT NULL,
    version         TEXT NOT NULL,
    install_cmd     TEXT NOT NULL DEFAULT '',
    entry_point     TEXT NOT NULL DEFAULT '',
    requires        TEXT NOT NULL DEFAULT '',
    skill_md_url    TEXT NOT NULL DEFAULT '',
    changelog       TEXT NOT NULL DEFAULT '',
    published_by    TEXT NOT NULL DEFAULT '',
    embedding       TEXT NOT NULL DEFAULT '[]',
    scan_result     TEXT NOT NULL DEFAULT '{}',
    created_at      TEXT NOT NULL,
    UNIQUE(cli_id, version)
);

CREATE TABLE IF NOT EXISTS cli_audit_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cli_id          TEXT NOT NULL,
    action          TEXT NOT NULL,
    actor_id        TEXT NOT NULL DEFAULT '',
    detail          TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cli_version_tags (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cli_id          TEXT NOT NULL,
    tag             TEXT NOT NULL,
    version         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    UNIQUE(cli_id, tag)
);

CREATE TABLE IF NOT EXISTS cli_stars (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cli_id          TEXT NOT NULL,
    user_id         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    UNIQUE(cli_id, user_id)
);

CREATE TABLE IF NOT EXISTS cli_comments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cli_id          TEXT NOT NULL,
    user_id         TEXT NOT NULL,
    content         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cli_reports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cli_id          TEXT NOT NULL,
    reporter_id     TEXT NOT NULL,
    reason          TEXT NOT NULL,
    detail          TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL,
    UNIQUE(cli_id, reporter_id)
);

CREATE TABLE IF NOT EXISTS cli_redirects (
    old_slug        TEXT PRIMARY KEY,
    new_slug        TEXT NOT NULL,
    created_at      TEXT NOT NULL
);
"""


def ensure_tables(provider: DBProvider) -> None:
    """Create all CLI Hub tables if they don't exist."""
    with provider.get_connection() as con:
        for stmt in SCHEMA_SQL.split(";"):
            stmt = stmt.strip()
            if stmt:
                con.execute(q(stmt, provider))
        con.commit()
