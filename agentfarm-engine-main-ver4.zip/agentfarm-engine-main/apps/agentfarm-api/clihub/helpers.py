"""CLI Hub shared helpers — pure utility functions."""

from __future__ import annotations

import json
import time
from typing import Any


def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def row_to_dict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    if isinstance(row, dict):
        return row
    try:
        return dict(row)
    except (TypeError, ValueError):
        return {k: row[k] for k in row.keys()}


def parse_json_field(val: Any, default: Any = None) -> Any:
    if val is None:
        return default if default is not None else []
    if isinstance(val, (list, dict)):
        return val
    try:
        return json.loads(val)
    except (json.JSONDecodeError, TypeError):
        return default if default is not None else []
