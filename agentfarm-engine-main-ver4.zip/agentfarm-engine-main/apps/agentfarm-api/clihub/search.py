"""CLI Hub in-memory vector search engine — fastembed + numpy."""

from __future__ import annotations

import json
import logging
import math
import threading
from difflib import SequenceMatcher
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)


class CLISearchIndex:
    """In-memory vector index for semantic CLI tool search."""

    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5") -> None:
        self._model_name = model_name
        self._model: Any = None
        self._lock = threading.Lock()
        self._embeddings: np.ndarray | None = None
        self._cli_ids: list[str] = []
        self._cli_meta: dict[str, dict[str, Any]] = {}

    def _get_model(self) -> Any:
        if self._model is None:
            from fastembed import TextEmbedding
            self._model = TextEmbedding(model_name=self._model_name)
        return self._model

    def _embed(self, texts: list[str]) -> np.ndarray:
        model = self._get_model()
        embeddings = list(model.embed(texts))
        arr = np.array(embeddings, dtype=np.float32)
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)
        return arr / norms

    def build_from_db(self, db_provider: Any) -> None:
        """Load stored embeddings from the database on startup."""
        from clihub.database import q as db_q

        with self._lock:
            self._cli_ids = []
            self._cli_meta = {}
            vectors: list[list[float]] = []

            with db_provider.get_connection() as con:
                sql = db_q(
                    "SELECT t.cli_id, t.name, t.slug, t.install_count, v.embedding "
                    "FROM cli_tools t "
                    "JOIN cli_versions v ON t.cli_id = v.cli_id "
                    "  AND t.latest_version = v.version "
                    "WHERE t.status IN ('active', 'deprecated')",
                    db_provider,
                )
                rows = con.execute(sql).fetchall()

            for row in rows:
                cli_id = row["cli_id"]
                emb_json = row["embedding"]
                if not emb_json or emb_json == "[]":
                    continue
                try:
                    vec = json.loads(emb_json)
                    if not vec or not isinstance(vec, list):
                        continue
                except (json.JSONDecodeError, TypeError):
                    continue

                self._cli_ids.append(cli_id)
                vectors.append(vec)
                self._cli_meta[cli_id] = {
                    "name": row["name"],
                    "slug": row["slug"],
                    "installs": row["install_count"],
                }

            if vectors:
                self._embeddings = np.array(vectors, dtype=np.float32)
                norms = np.linalg.norm(self._embeddings, axis=1, keepdims=True)
                norms = np.where(norms == 0, 1, norms)
                self._embeddings = self._embeddings / norms
                logger.info("Loaded %d CLI embeddings into search index", len(vectors))
            else:
                self._embeddings = None

    def add(self, cli_id: str, text: str, meta: dict[str, Any] | None = None) -> list[float]:
        vec = self._embed([text])[0]
        with self._lock:
            self._remove_unlocked(cli_id)
            self._cli_ids.append(cli_id)
            if self._embeddings is not None:
                self._embeddings = np.vstack([self._embeddings, vec.reshape(1, -1)])
            else:
                self._embeddings = vec.reshape(1, -1)
            if meta:
                self._cli_meta[cli_id] = meta
        return vec.tolist()

    def remove(self, cli_id: str) -> None:
        with self._lock:
            self._remove_unlocked(cli_id)

    def _remove_unlocked(self, cli_id: str) -> None:
        if cli_id not in self._cli_ids:
            return
        idx = self._cli_ids.index(cli_id)
        self._cli_ids.pop(idx)
        self._cli_meta.pop(cli_id, None)
        if self._embeddings is not None and len(self._embeddings) > 0:
            self._embeddings = np.delete(self._embeddings, idx, axis=0)
            if len(self._embeddings) == 0:
                self._embeddings = None

    def search(self, query: str, top_k: int = 10) -> list[tuple[str, float]]:
        if self._embeddings is None or len(self._cli_ids) == 0:
            return []

        query_vec = self._embed([query])[0]

        with self._lock:
            if self._embeddings is None:
                return []
            similarities = self._embeddings @ query_vec
            results: list[tuple[str, float]] = []
            max_installs = 1.0
            for cid in self._cli_ids:
                meta = self._cli_meta.get(cid, {})
                inst = meta.get("installs", 0)
                if inst > 0:
                    max_installs = max(max_installs, math.log1p(inst))

            query_lower = query.lower().strip()
            for i, cli_id in enumerate(self._cli_ids):
                vector_score = float(similarities[i])
                meta = self._cli_meta.get(cli_id, {})
                name = meta.get("name", "").lower()
                slug = meta.get("slug", "").lower()
                installs = meta.get("installs", 0)

                lexical = 0.0
                if query_lower == slug:
                    lexical = 1.0
                elif slug.startswith(query_lower):
                    lexical = 0.8
                elif query_lower == name:
                    lexical = 1.0
                elif name.startswith(query_lower):
                    lexical = 0.6
                elif query_lower in slug or query_lower in name:
                    lexical = 0.3

                popularity = math.log1p(installs) / max_installs if installs > 0 else 0.0
                final_score = vector_score * 0.7 + lexical * 0.2 + popularity * 0.1
                results.append((cli_id, final_score))

        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]

    def find_duplicates(self, cli_id: str, threshold: float = 0.85) -> list[tuple[str, float]]:
        if self._embeddings is None or cli_id not in self._cli_ids:
            return []
        with self._lock:
            idx = self._cli_ids.index(cli_id)
            query_vec = self._embeddings[idx]
            similarities = self._embeddings @ query_vec
            results = []
            for i, cid in enumerate(self._cli_ids):
                if cid == cli_id:
                    continue
                sim = float(similarities[i])
                if sim >= threshold:
                    results.append((cid, sim))
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def get_meta(self, cli_id: str) -> dict[str, Any]:
        """Thread-safe access to CLI tool metadata."""
        with self._lock:
            return self._cli_meta.get(cli_id, {}).copy()

    def update_meta(self, cli_id: str, **updates: Any) -> None:
        """Thread-safe update of CLI tool metadata."""
        with self._lock:
            if cli_id in self._cli_meta:
                self._cli_meta[cli_id].update(updates)

    @property
    def size(self) -> int:
        return len(self._cli_ids)


def build_embedding_text(
    name: str,
    display_name: str,
    description: str,
    category: str,
    tags: list[str],
    requires: str = "",
    max_chars: int = 2000,
) -> str:
    """Build the text to embed for a CLI tool."""
    parts = [name, display_name, description, category]
    if tags:
        parts.append(" ".join(tags))
    if requires:
        parts.append(requires)
    text = "\n\n".join(p for p in parts if p)
    return text[:max_chars]


def name_similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()
