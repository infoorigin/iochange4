"""Self-contained test fixtures for CLI Hub."""

from __future__ import annotations

import sqlite3
import time
from contextlib import contextmanager
from typing import Any, Generator
from unittest.mock import MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from clihub.config import CLIHubConfig
from clihub.database import SCHEMA_SQL
from clihub.routers import build_router
from clihub.search import CLISearchIndex


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


class TestDBProvider:
    def __init__(self, con: sqlite3.Connection) -> None:
        self._con = con

    @contextmanager
    def get_connection(self) -> Generator[Any, None, None]:
        yield self._con

    def placeholder(self) -> str:
        return "?"


@pytest.fixture()
def test_db():
    con = sqlite3.connect(":memory:", check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA_SQL)
    yield con
    con.close()


@pytest.fixture()
def seeded_db(test_db):
    now = _now()

    # CLI tool 1: gimp
    test_db.execute(
        "INSERT INTO cli_tools(cli_id, name, slug, display_name, description, category, "
        "entry_point, install_cmd, homepage, requires, skill_md_url, tags, owner_id, "
        "contributor, contributor_url, status, latest_version, scan_status, created_at, updated_at) "
        "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', '1.1.0', 'clean', ?, ?)",
        ("cli_aaa111", "gimp", "gimp", "GIMP", "Image editing CLI for agents",
         "creative", "cli-anything-gimp",
         "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
         "https://www.gimp.org", "GIMP 2.10+",
         "gimp/agent-harness/skills/SKILL.md",
         '["image","editing","creative"]', "user_1",
         "CLI-Anything-Team", "https://github.com/HKUDS/CLI-Anything",
         now, now),
    )

    test_db.execute(
        "INSERT INTO cli_versions(cli_id, version, install_cmd, entry_point, requires, "
        "skill_md_url, published_by, embedding, scan_result, created_at) "
        "VALUES(?, '1.0.0', ?, 'cli-anything-gimp', 'GIMP 2.10+', '', 'user_1', '[]', '{}', ?)",
        ("cli_aaa111",
         "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
         now),
    )
    test_db.execute(
        "INSERT INTO cli_versions(cli_id, version, install_cmd, entry_point, requires, "
        "skill_md_url, published_by, embedding, scan_result, created_at) "
        "VALUES(?, '1.1.0', ?, 'cli-anything-gimp', 'GIMP 2.10+', '', 'user_1', '[]', "
        "'{\"risk_score\":0.0,\"findings\":[]}', ?)",
        ("cli_aaa111",
         "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
         now),
    )

    test_db.execute(
        "INSERT INTO cli_version_tags(cli_id, tag, version, created_at) VALUES(?, 'latest', '1.1.0', ?)",
        ("cli_aaa111", now),
    )

    # CLI tool 2: ollama
    test_db.execute(
        "INSERT INTO cli_tools(cli_id, name, slug, display_name, description, category, "
        "entry_point, install_cmd, homepage, requires, tags, owner_id, contributor, "
        "status, latest_version, scan_status, created_at, updated_at) "
        "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', '1.0.0', 'clean', ?, ?)",
        ("cli_bbb222", "ollama", "ollama", "Ollama", "Local LLM inference CLI",
         "ai", "cli-anything-ollama",
         "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=ollama/agent-harness",
         "https://ollama.com", "Ollama running at localhost:11434",
         '["ai","llm"]', "user_2", "CLI-Anything-Team",
         now, now),
    )

    test_db.execute(
        "INSERT INTO cli_versions(cli_id, version, install_cmd, entry_point, requires, "
        "published_by, embedding, scan_result, created_at) "
        "VALUES(?, '1.0.0', ?, 'cli-anything-ollama', 'Ollama running', 'user_2', '[]', '{}', ?)",
        ("cli_bbb222",
         "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=ollama/agent-harness",
         now),
    )

    test_db.execute(
        "INSERT INTO cli_version_tags(cli_id, tag, version, created_at) VALUES(?, 'latest', '1.0.0', ?)",
        ("cli_bbb222", now),
    )

    # Star on tool 1
    test_db.execute("INSERT INTO cli_stars(cli_id, user_id, created_at) VALUES('cli_aaa111', 'user_2', ?)", (now,))
    test_db.execute("UPDATE cli_tools SET star_count = 1 WHERE cli_id = 'cli_aaa111'")

    # Comment on tool 1
    test_db.execute(
        "INSERT INTO cli_comments(cli_id, user_id, content, created_at, updated_at) "
        "VALUES('cli_aaa111', 'user_2', 'Great tool!', ?, ?)", (now, now),
    )

    test_db.commit()
    yield test_db


@pytest.fixture()
def mock_search_index():
    index = MagicMock(spec=CLISearchIndex)
    index.add.return_value = [0.1] * 384
    index.search.return_value = []
    index.find_duplicates.return_value = []
    index.remove.return_value = None
    index._cli_meta = {}
    index.size = 0
    return index


@pytest.fixture()
def client(seeded_db, mock_search_index):
    db_provider = TestDBProvider(seeded_db)
    config = CLIHubConfig()
    router = build_router(db=db_provider, config=config, search_index=mock_search_index)
    app = FastAPI()
    app.include_router(router)
    yield TestClient(app)


VALID_CLI_TOOL = {
    "name": "blender",
    "display_name": "Blender",
    "description": "3D modeling and rendering CLI for agents",
    "version": "1.0.0",
    "category": "3d",
    "entry_point": "cli-anything-blender",
    "install_cmd": "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=blender/agent-harness",
    "homepage": "https://www.blender.org",
    "requires": "Blender 3.0+",
    "skill_md_url": "blender/agent-harness/skills/SKILL.md",
    "tags": ["3d", "modeling"],
    "contributor": "CLI-Anything-Team",
    "contributor_url": "https://github.com/HKUDS/CLI-Anything",
    "owner_id": "user_1",
}
