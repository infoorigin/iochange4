"""CLI Hub validation and security scanning — pure functions, no I/O."""

from __future__ import annotations

import re
import secrets
from urllib.parse import urlparse

from clihub.schemas import ScanResult, SecurityFinding


# ── Validation regexes ──────────────────────────────────────────

_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$")
_ENTRY_POINT_RE = re.compile(r"^[a-z][a-z0-9-]*$")
_SAFE_NAME_RE = re.compile(r"^[\w\s\-.,!?()]+$", re.UNICODE)
_SHELL_META_RE = re.compile(r"[;&|`$]|\$\(|&&|\|\|")
_IP_HOST_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
_USER_ID_RE = re.compile(r"^[a-zA-Z0-9._@\-]+$")

# Maximum lengths for text fields
MAX_USER_ID_LENGTH = 255
MAX_COMMENT_LENGTH = 10_000
MAX_CHANGELOG_LENGTH = 5_000


def validate_user_id(user_id: str) -> None:
    """Validate a user/owner ID. Raises ValueError if invalid."""
    if not user_id:
        return
    if len(user_id) > MAX_USER_ID_LENGTH:
        raise ValueError(f"User ID must be {MAX_USER_ID_LENGTH} characters or fewer")
    if not _USER_ID_RE.match(user_id):
        raise ValueError("User ID contains invalid characters")


def validate_comment_content(content: str) -> None:
    """Validate comment content. Raises ValueError if invalid."""
    stripped = content.strip()
    if not stripped:
        raise ValueError("Comment cannot be empty")
    if len(stripped) > MAX_COMMENT_LENGTH:
        raise ValueError(f"Comment must be {MAX_COMMENT_LENGTH:,} characters or fewer")


def escape_like_pattern(value: str) -> str:
    """Escape SQL LIKE wildcards for safe pattern matching."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

# Known trusted registries for pip installs
_TRUSTED_HOSTS = {"github.com", "gitlab.com", "bitbucket.org", "pypi.org"}


# ── Slug / ID generators ───────────────────────────────────────


def generate_slug(name: str) -> str:
    """Convert a CLI tool name to a URL-safe slug."""
    slug = name.lower().strip()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    slug = slug.strip("-")
    return slug or "unnamed"


def generate_cli_id() -> str:
    """Generate a unique CLI tool identifier."""
    return f"cli_{secrets.token_hex(6)}"


# ── Validation functions ────────────────────────────────────────


def validate_name(name: str) -> list[str]:
    """Validate tool name. Returns error messages."""
    errors: list[str] = []
    if not name or not name.strip():
        errors.append("'name' is required")
    elif len(name) > 200:
        errors.append("'name' must be 200 characters or fewer")
    elif not _SAFE_NAME_RE.match(name):
        errors.append("'name' contains invalid characters")
    return errors


def validate_version(version: str) -> list[str]:
    """Validate semver version string."""
    if not version:
        return ["'version' is required"]
    if not _SEMVER_RE.match(version):
        return [f"'version' must be semver (major.minor.patch), got '{version}'"]
    return []


def validate_slug(slug: str) -> list[str]:
    """Validate a slug string."""
    errors: list[str] = []
    if len(slug) < 2:
        errors.append("Slug must be at least 2 characters")
    if len(slug) > 100:
        errors.append("Slug must be 100 characters or fewer")
    if not _SLUG_RE.match(slug):
        errors.append("Slug must be lowercase alphanumeric with hyphens")
    return errors


def validate_entry_point(ep: str) -> list[str]:
    """Validate CLI entry point format."""
    errors: list[str] = []
    if not ep:
        errors.append("'entry_point' is required")
    elif len(ep) > 100:
        errors.append("'entry_point' must be 100 characters or fewer")
    elif not _ENTRY_POINT_RE.match(ep):
        errors.append("'entry_point' must be lowercase alphanumeric with hyphens")
    return errors


def validate_install_cmd(cmd: str) -> list[str]:
    """Validate pip install command format."""
    errors: list[str] = []
    if not cmd:
        errors.append("'install_cmd' is required")
        return errors

    if not cmd.strip().startswith("pip install"):
        errors.append("'install_cmd' must start with 'pip install'")

    if _SHELL_META_RE.search(cmd):
        errors.append("'install_cmd' contains shell metacharacters")

    return errors


def validate_url(url: str) -> list[str]:
    """Validate a URL for safety."""
    if not url:
        return []  # optional field
    errors: list[str] = []
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("https", "http", ""):
            errors.append(f"URL scheme '{parsed.scheme}' not allowed")
        if parsed.hostname and _IP_HOST_RE.match(parsed.hostname):
            errors.append("IP addresses not allowed in URLs")
        if parsed.hostname and parsed.hostname in ("localhost", "127.0.0.1", "0.0.0.0"):
            errors.append("localhost URLs not allowed")
    except Exception:
        errors.append(f"Invalid URL: '{url}'")
    return errors


def validate_cli_tool(name: str, version: str, entry_point: str, install_cmd: str) -> list[str]:
    """Validate all required fields for a CLI tool. Returns combined errors."""
    errors: list[str] = []
    errors.extend(validate_name(name))
    errors.extend(validate_version(version))
    errors.extend(validate_entry_point(entry_point))
    errors.extend(validate_install_cmd(install_cmd))
    return errors


def validate_version_progression(new_version: str, current_latest: str) -> None:
    """Raise ValueError if new_version is not strictly greater than current_latest."""
    if not current_latest:
        return

    def _parse(v: str) -> tuple[int, ...]:
        return tuple(int(x) for x in v.split("."))

    try:
        new = _parse(new_version)
        cur = _parse(current_latest)
    except (ValueError, AttributeError):
        raise ValueError(f"Cannot compare versions: '{new_version}' vs '{current_latest}'")

    if new <= cur:
        raise ValueError(
            f"New version '{new_version}' must be greater than current '{current_latest}'"
        )


def validate_status_transition(current: str, target: str) -> None:
    """Raise ValueError if the status transition is not allowed."""
    allowed: dict[str, set[str]] = {
        "active": {"hidden", "deprecated", "removed"},
        "hidden": {"active", "deprecated", "removed"},
        "deprecated": {"active", "removed"},
        "removed": {"active"},
    }
    valid = allowed.get(current, set())
    if target not in valid:
        raise ValueError(
            f"Cannot transition from '{current}' to '{target}'. "
            f"Allowed: {sorted(valid)}"
        )


# ── Security Scanner ───────────────────────────────────────────

_SEVERITY_WEIGHT = {"high": 0.4, "medium": 0.2, "low": 0.05}


def scan_cli_tool(
    install_cmd: str,
    entry_point: str = "",
    requires: str = "",
    homepage: str = "",
    skill_md_url: str = "",
) -> ScanResult:
    """Run the built-in security scanner on CLI tool metadata.

    Returns a ScanResult with risk_score (0.0-1.0) and findings.
    """
    findings: list[SecurityFinding] = []

    # SHELL_INJECTION — shell metacharacters in install_cmd
    if _SHELL_META_RE.search(install_cmd):
        for match in _SHELL_META_RE.finditer(install_cmd):
            findings.append(SecurityFinding(
                rule="SHELL_INJECTION",
                severity="high",
                message="Shell metacharacter in install command",
                snippet=match.group(0),
            ))

    # UNSAFE_INSTALL_URL — non-https, IP addresses, localhost
    if "git+" in install_cmd or "http" in install_cmd:
        # Extract URL from install_cmd
        parts = install_cmd.split()
        for part in parts:
            if "://" in part or part.startswith("git+"):
                url_str = part.replace("git+", "")
                try:
                    parsed = urlparse(url_str)
                    if parsed.scheme == "http":
                        findings.append(SecurityFinding(
                            rule="UNSAFE_INSTALL_URL",
                            severity="high",
                            message="Non-HTTPS URL in install command",
                            snippet=part[:100],
                        ))
                    if parsed.hostname and _IP_HOST_RE.match(parsed.hostname):
                        findings.append(SecurityFinding(
                            rule="UNSAFE_INSTALL_URL",
                            severity="high",
                            message="IP address in install URL",
                            snippet=parsed.hostname,
                        ))
                    if parsed.hostname in ("localhost", "127.0.0.1", "0.0.0.0"):
                        findings.append(SecurityFinding(
                            rule="UNSAFE_INSTALL_URL",
                            severity="high",
                            message="Localhost in install URL",
                            snippet=parsed.hostname,
                        ))
                except Exception:
                    pass

    # SUSPICIOUS_SUBDIRECTORY — path traversal in pip subdirectory
    if "#subdirectory=" in install_cmd:
        subdir = install_cmd.split("#subdirectory=")[-1].split("&")[0]
        if ".." in subdir:
            findings.append(SecurityFinding(
                rule="SUSPICIOUS_SUBDIRECTORY",
                severity="medium",
                message="Path traversal in pip subdirectory specifier",
                snippet=subdir[:100],
            ))

    # UNKNOWN_REGISTRY — install from untrusted source
    if "git+" in install_cmd:
        parts = install_cmd.split()
        for part in parts:
            if "git+" in part:
                url_str = part.replace("git+", "").split("#")[0].split("@")[0]
                try:
                    parsed = urlparse(url_str)
                    if parsed.hostname and parsed.hostname not in _TRUSTED_HOSTS:
                        findings.append(SecurityFinding(
                            rule="UNKNOWN_REGISTRY",
                            severity="medium",
                            message=f"Install from untrusted host: {parsed.hostname}",
                            snippet=parsed.hostname,
                        ))
                except Exception:
                    pass

    # EXCESSIVE_PERMISSIONS
    if "--user" in install_cmd or "--system" in install_cmd:
        findings.append(SecurityFinding(
            rule="EXCESSIVE_PERMISSIONS",
            severity="medium",
            message="Explicit permission scope flag in install command",
            snippet="--user" if "--user" in install_cmd else "--system",
        ))

    # ENTRY_POINT_MISMATCH
    if entry_point and not _ENTRY_POINT_RE.match(entry_point):
        findings.append(SecurityFinding(
            rule="ENTRY_POINT_MISMATCH",
            severity="low",
            message="Entry point doesn't follow naming conventions",
            snippet=entry_point[:50],
        ))

    # MISSING_HOMEPAGE
    if not homepage:
        findings.append(SecurityFinding(
            rule="MISSING_HOMEPAGE",
            severity="low",
            message="No homepage URL provided",
        ))

    # MISSING_SKILL_MD
    if not skill_md_url:
        findings.append(SecurityFinding(
            rule="MISSING_SKILL_MD",
            severity="low",
            message="No SKILL.md URL provided",
        ))

    risk_score = min(sum(_SEVERITY_WEIGHT.get(f.severity, 0.0) for f in findings), 1.0)
    return ScanResult(risk_score=risk_score, findings=findings)
