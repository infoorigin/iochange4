"""CLI Hub service layer — all DB operations and business logic.

No FastAPI imports. Raises domain exceptions (errors.py).
"""

from __future__ import annotations

import json
import logging
from typing import Any

from clihub.config import CLIHubConfig
from clihub.database import DBProvider, q
from clihub.errors import ConflictError, ForbiddenError, NotFoundError, ValidationError
from clihub.helpers import now, parse_json_field, row_to_dict
from clihub.search import CLISearchIndex, build_embedding_text, name_similarity
from clihub.validator import (
    escape_like_pattern,
    generate_cli_id,
    generate_slug,
    scan_cli_tool,
    validate_cli_tool,
    validate_comment_content,
    validate_install_cmd,
    validate_slug,
    validate_status_transition,
    validate_url,
    validate_user_id,
    validate_version,
    validate_version_progression,
)

logger = logging.getLogger(__name__)


class CLIService:
    """Encapsulates all CLI Hub business logic and DB operations."""

    def __init__(self, db: DBProvider, config: CLIHubConfig, search_index: CLISearchIndex) -> None:
        self.db = db
        self.config = config
        self.search_index = search_index

    # ── Internal helpers ─────────────────────────────────────────

    def _resolve_slug(self, slug: str, con: Any) -> str:
        """Resolve a slug, following redirects if necessary."""
        row = con.execute(q("SELECT slug FROM cli_tools WHERE slug = ?", self.db), (slug,)).fetchone()
        if row:
            return slug
        redirect = con.execute(q("SELECT new_slug FROM cli_redirects WHERE old_slug = ?", self.db), (slug,)).fetchone()
        if redirect:
            return row_to_dict(redirect)["new_slug"]
        return slug

    def _get_or_404(self, slug: str, con: Any) -> dict[str, Any]:
        """Fetch a CLI tool by slug or raise NotFoundError."""
        resolved = self._resolve_slug(slug, con)
        row = con.execute(q("SELECT * FROM cli_tools WHERE slug = ?", self.db), (resolved,)).fetchone()
        if not row:
            logger.warning("CLI tool '%s' not found", slug)
            raise NotFoundError(f"CLI tool '{slug}' not found")
        return row_to_dict(row)

    def _audit(self, con: Any, cli_id: str, action: str, actor_id: str = "", detail: str = "") -> None:
        """Write an entry to the audit log."""
        con.execute(
            q("INSERT INTO cli_audit_log(cli_id, action, actor_id, detail, created_at) VALUES(?, ?, ?, ?, ?)", self.db),
            (cli_id, action, actor_id, detail, now()),
        )

    def _to_summary(self, row: dict[str, Any]) -> dict[str, Any]:
        """Convert a full tool row to a summary dict for list responses."""
        return {
            "cli_id": row["cli_id"], "slug": row["slug"], "name": row["name"],
            "display_name": row.get("display_name", ""),
            "description": row.get("description", ""),
            "category": row.get("category", ""),
            "entry_point": row.get("entry_point", ""),
            "install_cmd": row.get("install_cmd", ""),
            "status": row.get("status", "active"),
            "latest_version": row.get("latest_version", ""),
            "install_count": row.get("install_count", 0),
            "star_count": row.get("star_count", 0),
            "report_count": row.get("report_count", 0),
            "scan_status": row.get("scan_status", "pending"),
            "tags": parse_json_field(row.get("tags"), []),
            "contributor": row.get("contributor", ""),
            "owner_id": row.get("owner_id", ""),
            "workspace_id": row.get("workspace_id"),
            "created_at": row.get("created_at", ""),
            "updated_at": row.get("updated_at", ""),
        }

    # ── CRUD ─────────────────────────────────────────────────────

    def create_tool(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create a new CLI tool entry. Raises ValidationError or ConflictError."""
        validate_user_id(data.get("owner_id", ""))
        errors = validate_cli_tool(data["name"], data["version"], data["entry_point"], data["install_cmd"])
        url_errors = validate_url(data.get("homepage", ""))
        if url_errors:
            errors.extend(url_errors)
        if errors:
            raise ValidationError("; ".join(errors))

        cli_id = generate_cli_id()
        slug = generate_slug(data["name"])
        ts = now()

        scan_result = scan_cli_tool(data["install_cmd"], data["entry_point"],
                                     data.get("requires", ""), data.get("homepage", ""), data.get("skill_md_url", ""))
        scan_status = "flagged" if scan_result.risk_score >= self.config.scan_flag_threshold else "clean"

        tags = data.get("tags", [])
        emb_text = build_embedding_text(data["name"], data.get("display_name", ""),
                                         data.get("description", ""), data.get("category", ""),
                                         tags, data.get("requires", ""))
        try:
            embedding = self.search_index.add(cli_id, emb_text, meta={"name": data["name"], "slug": slug, "installs": 0})
        except Exception:
            logger.warning("Failed to generate embedding for CLI %s", slug)
            embedding = []

        with self.db.get_connection() as con:
            if con.execute(q("SELECT id FROM cli_tools WHERE slug = ?", self.db), (slug,)).fetchone():
                raise ConflictError(f"Slug '{slug}' already exists")

            con.execute(
                q("INSERT INTO cli_tools(cli_id, name, slug, display_name, description, category, "
                  "entry_point, install_cmd, homepage, requires, skill_md_url, tags, owner_id, "
                  "contributor, contributor_url, workspace_id, status, latest_version, "
                  "scan_status, created_at, updated_at) "
                  "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)", self.db),
                (cli_id, data["name"], slug, data.get("display_name", ""), data.get("description", ""),
                 data.get("category", ""), data["entry_point"], data["install_cmd"],
                 data.get("homepage", ""), data.get("requires", ""), data.get("skill_md_url", ""),
                 json.dumps(tags), data.get("owner_id", ""), data.get("contributor", ""),
                 data.get("contributor_url", ""), data.get("workspace_id"),
                 data["version"], scan_status, ts, ts),
            )
            con.execute(
                q("INSERT INTO cli_versions(cli_id, version, install_cmd, entry_point, requires, "
                  "skill_md_url, changelog, published_by, embedding, scan_result, created_at) "
                  "VALUES(?, ?, ?, ?, ?, ?, '', ?, ?, ?, ?)", self.db),
                (cli_id, data["version"], data["install_cmd"], data["entry_point"],
                 data.get("requires", ""), data.get("skill_md_url", ""),
                 data.get("owner_id", ""), json.dumps(embedding), json.dumps(scan_result.model_dump()), ts),
            )
            con.execute(q("INSERT INTO cli_version_tags(cli_id, tag, version, created_at) VALUES(?, 'latest', ?, ?)", self.db),
                        (cli_id, data["version"], ts))
            self._audit(con, cli_id, "created", data.get("owner_id", ""),
                        json.dumps({"version": data["version"], "slug": slug}))
            con.commit()

        result = {
            "cli_id": cli_id, "slug": slug, "name": data["name"],
            "display_name": data.get("display_name", ""), "description": data.get("description", ""),
            "category": data.get("category", ""), "entry_point": data["entry_point"],
            "install_cmd": data["install_cmd"], "latest_version": data["version"],
            "install_count": 0, "star_count": 0, "report_count": 0, "scan_status": scan_status,
            "tags": tags, "contributor": data.get("contributor", ""),
            "owner_id": data.get("owner_id", ""), "workspace_id": data.get("workspace_id"),
            "created_at": ts, "updated_at": ts,
            "homepage": data.get("homepage", ""), "requires": data.get("requires", ""),
            "skill_md_url": data.get("skill_md_url", ""), "contributor_url": data.get("contributor_url", ""),
        }
        logger.info("Created CLI tool '%s' (cli_id=%s, slug=%s)", data["name"], cli_id, slug)
        return result

    def list_tools(self, query: str | None, category: str | None, tags: str | None,
                   status: str, workspace_id: str | None, limit: int, offset: int) -> list[dict[str, Any]]:
        """List CLI tools with optional filtering. Returns a list of tool summaries."""
        if query:
            results = self.search_index.search(query, top_k=limit + offset)
            if results:
                cli_ids = [cid for cid, _ in results[offset:offset + limit]]
                if not cli_ids:
                    return []
                with self.db.get_connection() as con:
                    ph = ",".join("?" for _ in cli_ids)
                    rows = con.execute(q(f"SELECT * FROM cli_tools WHERE cli_id IN ({ph}) AND status = ?", self.db),
                                       (*cli_ids, status)).fetchall()
                row_map = {row_to_dict(r)["cli_id"]: row_to_dict(r) for r in rows}
                ordered = []
                for cid in cli_ids:
                    if cid in row_map:
                        row = row_map[cid]
                        if category and row.get("category") != category:
                            continue
                        if tags and not any(t in parse_json_field(row.get("tags"), []) for t in tags.split(",")):
                            continue
                        if workspace_id and row.get("workspace_id") != workspace_id:
                            continue
                        ordered.append(self._to_summary(row))
                return ordered

        with self.db.get_connection() as con:
            clauses, params = ["status = ?"], [status]
            if category:
                clauses.append("category = ?")
                params.append(category)
            if tags:
                for t in tags.split(","):
                    escaped = escape_like_pattern(t.strip())
                    clauses.append("tags LIKE ? ESCAPE '\\'")
                    params.append(f'%"{escaped}"%')
            if workspace_id:
                clauses.append("workspace_id = ?")
                params.append(workspace_id)
            params.extend([limit, offset])
            rows = con.execute(
                q(f"SELECT * FROM cli_tools WHERE {' AND '.join(clauses)} ORDER BY updated_at DESC LIMIT ? OFFSET ?", self.db),
                tuple(params),
            ).fetchall()
        return [self._to_summary(row_to_dict(r)) for r in rows]

    def get_tool(self, slug: str) -> dict[str, Any]:
        """Get a single CLI tool by slug. Raises NotFoundError if missing."""
        with self.db.get_connection() as con:
            resolved = self._resolve_slug(slug, con)
            if resolved != slug:
                return {"_redirect": resolved}
            tool = self._get_or_404(slug, con)
        result = self._to_summary(tool)
        result["homepage"] = tool.get("homepage", "")
        result["requires"] = tool.get("requires", "")
        result["skill_md_url"] = tool.get("skill_md_url", "")
        result["contributor_url"] = tool.get("contributor_url", "")
        return result

    def update_tool(self, slug: str, updates: dict[str, Any]) -> dict[str, Any]:
        """Update fields on an existing CLI tool. Raises ValidationError or NotFoundError."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            sets: list[str] = []
            params: list[Any] = []
            if "status" in updates:
                validate_status_transition(tool["status"], updates["status"])
                sets.append("status = ?")
                params.append(updates["status"])
            if "tags" in updates:
                sets.append("tags = ?")
                params.append(json.dumps(updates["tags"]))
            if "description" in updates:
                sets.append("description = ?")
                params.append(updates["description"])
            if "category" in updates:
                sets.append("category = ?")
                params.append(updates["category"])
            if "homepage" in updates:
                sets.append("homepage = ?")
                params.append(updates["homepage"])
            if "requires" in updates:
                sets.append("requires = ?")
                params.append(updates["requires"])
            if not sets:
                raise ValidationError("No fields to update")
            sets.append("updated_at = ?")
            params.append(now())
            params.append(tool["cli_id"])
            con.execute(q(f"UPDATE cli_tools SET {', '.join(sets)} WHERE cli_id = ?", self.db), tuple(params))
            self._audit(con, tool["cli_id"], "updated", "", json.dumps(updates))
            con.commit()
        return {"message": "CLI tool updated", "slug": tool["slug"]}

    def delete_tool(self, slug: str) -> dict[str, Any]:
        """Soft-delete a CLI tool by setting status to removed. Raises NotFoundError or ValidationError."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            if tool["status"] == "removed":
                raise ValidationError("CLI tool is already removed")
            con.execute(q("UPDATE cli_tools SET status = 'removed', updated_at = ? WHERE cli_id = ?", self.db), (now(), tool["cli_id"]))
            self._audit(con, tool["cli_id"], "deleted", "")
            con.commit()
        self.search_index.remove(tool["cli_id"])
        logger.info("Deleted CLI tool '%s' (cli_id=%s)", slug, tool["cli_id"])
        return {"message": "CLI tool removed", "slug": tool["slug"]}

    # ── Versions ─────────────────────────────────────────────────

    def publish_version(self, slug: str, data: dict[str, Any]) -> dict[str, Any]:
        """Publish a new version for a CLI tool. Raises ValidationError or NotFoundError."""
        validate_user_id(data.get("owner_id", ""))
        errors = validate_version(data["version"])
        errors.extend(validate_install_cmd(data["install_cmd"]))
        if errors:
            raise ValidationError("; ".join(errors))

        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            validate_version_progression(data["version"], tool["latest_version"])
            ts = now()

            scan_result = scan_cli_tool(data["install_cmd"], data.get("entry_point") or tool["entry_point"],
                                         data.get("requires", ""), tool.get("homepage", ""), data.get("skill_md_url", ""))
            scan_status = "flagged" if scan_result.risk_score >= self.config.scan_flag_threshold else "clean"

            emb_text = build_embedding_text(tool["name"], tool.get("display_name", ""),
                                             tool.get("description", ""), tool.get("category", ""),
                                             parse_json_field(tool.get("tags"), []), data.get("requires", ""))
            try:
                embedding = self.search_index.add(tool["cli_id"], emb_text,
                    meta={"name": tool["name"], "slug": tool["slug"], "installs": tool.get("install_count", 0)})
            except Exception:
                embedding = []

            entry_point = data.get("entry_point") or tool["entry_point"]
            con.execute(
                q("INSERT INTO cli_versions(cli_id, version, install_cmd, entry_point, requires, "
                  "skill_md_url, changelog, published_by, embedding, scan_result, created_at) "
                  "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", self.db),
                (tool["cli_id"], data["version"], data["install_cmd"], entry_point,
                 data.get("requires", ""), data.get("skill_md_url", ""), data.get("changelog", ""),
                 data.get("owner_id", ""), json.dumps(embedding), json.dumps(scan_result.model_dump()), ts),
            )
            con.execute(q("UPDATE cli_tools SET latest_version = ?, install_cmd = ?, scan_status = ?, updated_at = ? WHERE cli_id = ?", self.db),
                        (data["version"], data["install_cmd"], scan_status, ts, tool["cli_id"]))
            if data.get("entry_point"):
                con.execute(q("UPDATE cli_tools SET entry_point = ? WHERE cli_id = ?", self.db), (entry_point, tool["cli_id"]))
            con.execute(q("UPDATE cli_version_tags SET version = ?, created_at = ? WHERE cli_id = ? AND tag = 'latest'", self.db),
                        (data["version"], ts, tool["cli_id"]))
            self._audit(con, tool["cli_id"], "version_published", data.get("owner_id", ""),
                        json.dumps({"version": data["version"], "previous": tool["latest_version"]}))
            con.commit()

        logger.info("Published version %s for '%s' (cli_id=%s)", data["version"], slug, tool["cli_id"])
        return {
            "cli_id": tool["cli_id"], "version": data["version"], "install_cmd": data["install_cmd"],
            "entry_point": entry_point, "requires": data.get("requires", ""),
            "skill_md_url": data.get("skill_md_url", ""), "changelog": data.get("changelog", ""),
            "published_by": data.get("owner_id", ""), "scan_result": scan_result.model_dump(), "created_at": ts,
        }

    def list_versions(self, slug: str) -> list[dict[str, Any]]:
        """List all versions of a CLI tool. Raises NotFoundError if tool missing."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            versions = con.execute(q("SELECT * FROM cli_versions WHERE cli_id = ? ORDER BY created_at DESC", self.db),
                                   (tool["cli_id"],)).fetchall()
            tag_rows = con.execute(q("SELECT tag, version FROM cli_version_tags WHERE cli_id = ?", self.db),
                                   (tool["cli_id"],)).fetchall()
        vtags: dict[str, list[str]] = {}
        for tr in tag_rows:
            tr_dict = row_to_dict(tr)
            vtags.setdefault(tr_dict["version"], []).append(tr_dict["tag"])
        result = []
        for r in versions:
            v = row_to_dict(r)
            result.append({
                "version": v["version"], "install_cmd": v.get("install_cmd", ""),
                "entry_point": v.get("entry_point", ""), "requires": v.get("requires", ""),
                "changelog": v.get("changelog", ""), "published_by": v.get("published_by", ""),
                "scan_result": parse_json_field(v.get("scan_result"), {}),
                "tags": vtags.get(v["version"], []), "created_at": v.get("created_at", ""),
            })
        return result

    def get_version(self, slug: str, version: str) -> dict[str, Any]:
        """Get a specific version of a CLI tool. Raises NotFoundError if missing."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            row = con.execute(q("SELECT * FROM cli_versions WHERE cli_id = ? AND version = ?", self.db),
                              (tool["cli_id"], version)).fetchone()
            if not row:
                logger.warning("Version '%s' not found for tool '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
            tag_rows = con.execute(q("SELECT tag FROM cli_version_tags WHERE cli_id = ? AND version = ?", self.db),
                                   (tool["cli_id"], version)).fetchall()
        v = row_to_dict(row)
        return {
            "cli_id": v["cli_id"], "version": v["version"], "install_cmd": v.get("install_cmd", ""),
            "entry_point": v.get("entry_point", ""), "requires": v.get("requires", ""),
            "skill_md_url": v.get("skill_md_url", ""), "changelog": v.get("changelog", ""),
            "published_by": v.get("published_by", ""), "scan_result": parse_json_field(v.get("scan_result"), {}),
            "tags": [row_to_dict(t)["tag"] for t in tag_rows], "created_at": v.get("created_at", ""),
        }

    def get_install_info(self, slug: str, tag: str | None) -> dict[str, Any]:
        """Get install info for a tool, optionally by tag. Raises NotFoundError if tool missing."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            version = tool["latest_version"]
            if tag:
                tag_row = con.execute(q("SELECT version FROM cli_version_tags WHERE cli_id = ? AND tag = ?", self.db),
                                      (tool["cli_id"], tag)).fetchone()
                if tag_row:
                    version = row_to_dict(tag_row)["version"]
            ver = con.execute(q("SELECT install_cmd, entry_point, requires FROM cli_versions WHERE cli_id = ? AND version = ?", self.db),
                              (tool["cli_id"], version)).fetchone()
            con.execute(q("UPDATE cli_tools SET install_count = install_count + 1 WHERE cli_id = ?", self.db), (tool["cli_id"],))
            con.commit()
        if not ver:
            return {"install_cmd": tool["install_cmd"], "entry_point": tool["entry_point"],
                    "requires": tool.get("requires", ""), "version": version}
        v = row_to_dict(ver)
        return {"install_cmd": v["install_cmd"], "entry_point": v["entry_point"],
                "requires": v["requires"], "version": version}

    def get_catalog(self) -> list[dict[str, Any]]:
        """Return a lightweight catalog of all active tools."""
        with self.db.get_connection() as con:
            rows = con.execute(
                q("SELECT name, display_name, description, install_cmd, entry_point, category "
                  "FROM cli_tools WHERE status = 'active' ORDER BY name", self.db)
            ).fetchall()
        return [row_to_dict(r) for r in rows]

    # ── Tags ─────────────────────────────────────────────────────

    def set_tag(self, slug: str, tag: str, version: str) -> dict[str, Any]:
        """Assign a version tag. Raises ValidationError for 'latest' or NotFoundError."""
        if tag == "latest":
            raise ValidationError("'latest' tag is auto-managed")
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            if not con.execute(q("SELECT id FROM cli_versions WHERE cli_id = ? AND version = ?", self.db),
                               (tool["cli_id"], version)).fetchone():
                logger.warning("Version '%s' not found for tag assignment on '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
            ts = now()
            cur = con.execute(q("UPDATE cli_version_tags SET version = ?, created_at = ? WHERE cli_id = ? AND tag = ?", self.db),
                              (version, ts, tool["cli_id"], tag))
            if cur.rowcount == 0:
                con.execute(q("INSERT INTO cli_version_tags(cli_id, tag, version, created_at) VALUES(?, ?, ?, ?)", self.db),
                            (tool["cli_id"], tag, version, ts))
            con.commit()
        return {"message": f"Tag '{tag}' now points to version {version}"}

    def delete_tag(self, slug: str, tag: str) -> dict[str, Any]:
        """Remove a version tag. Raises ValidationError for 'latest' or NotFoundError."""
        if tag == "latest":
            raise ValidationError("Cannot remove 'latest' tag")
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            cur = con.execute(q("DELETE FROM cli_version_tags WHERE cli_id = ? AND tag = ?", self.db), (tool["cli_id"], tag))
            if cur.rowcount == 0:
                logger.warning("Tag '%s' not found on tool '%s'", tag, slug)
                raise NotFoundError(f"Tag '{tag}' not found")
            con.commit()
        return {"message": f"Tag '{tag}' removed"}

    # ── Community ────────────────────────────────────────────────

    def star(self, slug: str, user_id: str) -> dict[str, Any]:
        """Star a CLI tool for a user. Raises NotFoundError if tool missing."""
        validate_user_id(user_id)
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            if con.execute(q("SELECT id FROM cli_stars WHERE cli_id = ? AND user_id = ?", self.db), (tool["cli_id"], user_id)).fetchone():
                return {"message": "Already starred", "starred": True}
            con.execute(q("INSERT INTO cli_stars(cli_id, user_id, created_at) VALUES(?, ?, ?)", self.db), (tool["cli_id"], user_id, now()))
            con.execute(q("UPDATE cli_tools SET star_count = star_count + 1 WHERE cli_id = ?", self.db), (tool["cli_id"],))
            con.commit()
        return {"message": "Starred", "starred": True}

    def unstar(self, slug: str, user_id: str) -> dict[str, Any]:
        """Remove a star from a CLI tool. Raises NotFoundError if tool missing."""
        validate_user_id(user_id)
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            cur = con.execute(q("DELETE FROM cli_stars WHERE cli_id = ? AND user_id = ?", self.db), (tool["cli_id"], user_id))
            if cur.rowcount > 0:
                con.execute(q("UPDATE cli_tools SET star_count = CASE WHEN star_count > 0 THEN star_count - 1 ELSE 0 END WHERE cli_id = ?", self.db), (tool["cli_id"],))
                con.commit()
                return {"message": "Unstarred", "starred": False}
        return {"message": "Was not starred", "starred": False}

    def list_comments(self, slug: str) -> list[dict[str, Any]]:
        """List all comments on a CLI tool. Raises NotFoundError if tool missing."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            rows = con.execute(q("SELECT * FROM cli_comments WHERE cli_id = ? ORDER BY created_at ASC", self.db), (tool["cli_id"],)).fetchall()
        result = []
        for row in rows:
            r = row_to_dict(row)
            result.append({
                "id": r["id"], "cli_id": tool["cli_id"], "user_id": r["user_id"],
                "content": r["content"], "created_at": r.get("created_at", ""),
                "updated_at": r.get("updated_at", ""),
            })
        return result

    def add_comment(self, slug: str, user_id: str, content: str) -> dict[str, Any]:
        """Add a comment to a CLI tool. Raises ValidationError if empty or NotFoundError."""
        validate_user_id(user_id)
        validate_comment_content(content)
        ts = now()
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            con.execute(q("INSERT INTO cli_comments(cli_id, user_id, content, created_at, updated_at) VALUES(?, ?, ?, ?, ?)", self.db),
                        (tool["cli_id"], user_id, content.strip(), ts, ts))
            con.commit()
        return {"message": "Comment added"}

    def delete_comment(self, slug: str, comment_id: int, user_id: str) -> dict[str, Any]:
        """Delete a comment. Raises NotFoundError or ForbiddenError."""
        validate_user_id(user_id)
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            comment = con.execute(q("SELECT * FROM cli_comments WHERE id = ? AND cli_id = ?", self.db), (comment_id, tool["cli_id"])).fetchone()
            if not comment:
                logger.warning("Comment %d not found on tool '%s'", comment_id, slug)
                raise NotFoundError("Comment not found")
            if row_to_dict(comment)["user_id"] != user_id:
                logger.warning("User '%s' forbidden from deleting comment %d on '%s'", user_id, comment_id, slug)
                raise ForbiddenError("Can only delete your own comments")
            con.execute(q("DELETE FROM cli_comments WHERE id = ?", self.db), (comment_id,))
            con.commit()
        return {"message": "Comment deleted"}

    def report(self, slug: str, reporter_id: str, reason: str, detail: str = "") -> dict[str, Any]:
        """Report a CLI tool for abuse. Raises NotFoundError or ConflictError."""
        validate_user_id(reporter_id)
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            if con.execute(q("SELECT id FROM cli_reports WHERE cli_id = ? AND reporter_id = ?", self.db), (tool["cli_id"], reporter_id)).fetchone():
                raise ConflictError("You have already reported this CLI tool")
            ts = now()
            con.execute(q("INSERT INTO cli_reports(cli_id, reporter_id, reason, detail, created_at) VALUES(?, ?, ?, ?, ?)", self.db),
                        (tool["cli_id"], reporter_id, reason, detail, ts))
            con.execute(q("UPDATE cli_tools SET report_count = report_count + 1 WHERE cli_id = ?", self.db), (tool["cli_id"],))
            cnt = row_to_dict(con.execute(q("SELECT COUNT(DISTINCT reporter_id) as cnt FROM cli_reports WHERE cli_id = ?", self.db),
                                           (tool["cli_id"],)).fetchone()).get("cnt", 0)
            if cnt >= self.config.report_auto_hide_threshold and tool["status"] == "active":
                con.execute(q("UPDATE cli_tools SET status = 'hidden', updated_at = ? WHERE cli_id = ?", self.db), (ts, tool["cli_id"]))
                self._audit(con, tool["cli_id"], "auto_hidden_by_reports", "", json.dumps({"report_count": cnt}))
            self._audit(con, tool["cli_id"], "reported", reporter_id, json.dumps({"reason": reason}))
            con.commit()
        logger.info("Report submitted for '%s' by '%s' (reason=%s)", slug, reporter_id, reason)
        return {"message": "Report submitted"}

    # ── Admin ────────────────────────────────────────────────────

    def rename(self, slug: str, new_slug: str, owner_id: str = "") -> dict[str, Any]:
        """Rename a CLI tool's slug. Raises ValidationError, ForbiddenError, or ConflictError."""
        validate_user_id(owner_id)
        slug_errors = validate_slug(new_slug)
        if slug_errors:
            raise ValidationError("; ".join(slug_errors))
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            if owner_id and tool["owner_id"] != owner_id:
                logger.warning("User '%s' forbidden from renaming tool '%s'", owner_id, slug)
                raise ForbiddenError("Only the owner can rename")
            if con.execute(q("SELECT id FROM cli_tools WHERE slug = ?", self.db), (new_slug,)).fetchone():
                raise ConflictError(f"Slug '{new_slug}' already exists")
            ts = now()
            old_slug = tool["slug"]
            con.execute(q("UPDATE cli_tools SET slug = ?, updated_at = ? WHERE cli_id = ?", self.db), (new_slug, ts, tool["cli_id"]))
            con.execute(q("INSERT INTO cli_redirects(old_slug, new_slug, created_at) VALUES(?, ?, ?)", self.db), (old_slug, new_slug, ts))
            con.execute(q("UPDATE cli_redirects SET new_slug = ? WHERE new_slug = ?", self.db), (new_slug, old_slug))
            self._audit(con, tool["cli_id"], "renamed", owner_id, json.dumps({"old_slug": old_slug, "new_slug": new_slug}))
            con.commit()
            self.search_index.update_meta(tool["cli_id"], slug=new_slug)
        logger.info("Renamed CLI tool '%s' to '%s' (cli_id=%s)", old_slug, new_slug, tool["cli_id"])
        return {"message": f"Renamed '{old_slug}' → '{new_slug}'", "slug": new_slug}

    def find_duplicates(self, slug: str, threshold: float = 0.85) -> list[dict[str, Any]]:
        """Find potential duplicate CLI tools by embedding and name similarity. Raises NotFoundError."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            emb_dupes = self.search_index.find_duplicates(tool["cli_id"], threshold=threshold)
            all_tools = con.execute(q("SELECT cli_id, slug, name FROM cli_tools WHERE status = 'active' AND cli_id != ?", self.db),
                                    (tool["cli_id"],)).fetchall()
        candidates: list[dict[str, Any]] = []
        seen: set[str] = set()
        for cid, sim in emb_dupes:
            meta = self.search_index.get_meta(cid)
            candidates.append({"cli_id": cid, "slug": meta.get("slug", ""), "name": meta.get("name", ""),
                               "similarity": round(sim, 3), "match_type": "embedding"})
            seen.add(cid)
        for row in all_tools:
            r = row_to_dict(row)
            if r["cli_id"] in seen:
                continue
            sim = name_similarity(tool["name"], r["name"])
            if sim >= 0.8:
                candidates.append({"cli_id": r["cli_id"], "slug": r["slug"], "name": r["name"],
                                   "similarity": round(sim, 3), "match_type": "name"})
        candidates.sort(key=lambda c: c["similarity"], reverse=True)
        return candidates

    def merge(self, slug: str, target_slug: str, owner_id: str = "") -> dict[str, Any]:
        """Merge one CLI tool into another, combining versions and stars. Raises ValidationError or ForbiddenError."""
        validate_user_id(owner_id)
        with self.db.get_connection() as con:
            source = self._get_or_404(slug, con)
            target = self._get_or_404(target_slug, con)
            if source["cli_id"] == target["cli_id"]:
                raise ValidationError("Cannot merge into itself")
            if owner_id:
                if source["owner_id"] != owner_id or target["owner_id"] != owner_id:
                    logger.warning("User '%s' forbidden from merging '%s' into '%s'", owner_id, slug, target_slug)
                    raise ForbiddenError("Must own both to merge")
            ts = now()
            target_ver_rows = con.execute(
                q("SELECT version FROM cli_versions WHERE cli_id = ?", self.db), (target["cli_id"],)).fetchall()
            target_vers: set[str] = set()
            for tv in target_ver_rows:
                target_vers.add(row_to_dict(tv)["version"])
            source_ver_rows = con.execute(
                q("SELECT id, version FROM cli_versions WHERE cli_id = ?", self.db), (source["cli_id"],)).fetchall()
            for sv_row in source_ver_rows:
                sv = row_to_dict(sv_row)
                if sv["version"] not in target_vers:
                    con.execute(q("UPDATE cli_versions SET cli_id = ? WHERE id = ?", self.db), (target["cli_id"], sv["id"]))
            existing_star_rows = con.execute(
                q("SELECT user_id FROM cli_stars WHERE cli_id = ?", self.db), (target["cli_id"],)).fetchall()
            existing_users: set[str] = set()
            for eu_row in existing_star_rows:
                existing_users.add(row_to_dict(eu_row)["user_id"])
            source_star_rows = con.execute(
                q("SELECT user_id, created_at FROM cli_stars WHERE cli_id = ?", self.db), (source["cli_id"],)).fetchall()
            for s_row in source_star_rows:
                s = row_to_dict(s_row)
                if s["user_id"] not in existing_users:
                    con.execute(q("INSERT INTO cli_stars(cli_id, user_id, created_at) VALUES(?, ?, ?)", self.db),
                                (target["cli_id"], s["user_id"], s["created_at"]))
            con.execute(q("DELETE FROM cli_stars WHERE cli_id = ?", self.db), (source["cli_id"],))
            con.execute(q("UPDATE cli_comments SET cli_id = ? WHERE cli_id = ?", self.db), (target["cli_id"], source["cli_id"]))
            source_tag_rows = con.execute(
                q("SELECT tag, version FROM cli_version_tags WHERE cli_id = ?", self.db), (source["cli_id"],)).fetchall()
            for t_row in source_tag_rows:
                t = row_to_dict(t_row)
                if t["tag"] == "latest":
                    continue
                if not con.execute(q("SELECT id FROM cli_version_tags WHERE cli_id = ? AND tag = ?", self.db), (target["cli_id"], t["tag"])).fetchone():
                    con.execute(q("INSERT INTO cli_version_tags(cli_id, tag, version, created_at) VALUES(?, ?, ?, ?)", self.db),
                                (target["cli_id"], t["tag"], t["version"], ts))
            con.execute(q("DELETE FROM cli_version_tags WHERE cli_id = ?", self.db), (source["cli_id"],))
            all_ver_rows = con.execute(
                q("SELECT version FROM cli_versions WHERE cli_id = ?", self.db), (target["cli_id"],)).fetchall()
            all_vers: list[str] = []
            for av_row in all_ver_rows:
                all_vers.append(row_to_dict(av_row)["version"])
            if all_vers:
                all_vers.sort(key=lambda v: tuple(int(x) for x in v.split(".")), reverse=True)
                con.execute(q("UPDATE cli_tools SET latest_version = ?, updated_at = ? WHERE cli_id = ?", self.db), (all_vers[0], ts, target["cli_id"]))
                con.execute(q("UPDATE cli_version_tags SET version = ? WHERE cli_id = ? AND tag = 'latest'", self.db), (all_vers[0], target["cli_id"]))
            star_cnt = row_to_dict(con.execute(q("SELECT COUNT(*) as cnt FROM cli_stars WHERE cli_id = ?", self.db), (target["cli_id"],)).fetchone()).get("cnt", 0)
            con.execute(q("UPDATE cli_tools SET star_count = ? WHERE cli_id = ?", self.db), (star_cnt, target["cli_id"]))
            con.execute(q("INSERT INTO cli_redirects(old_slug, new_slug, created_at) VALUES(?, ?, ?)", self.db), (source["slug"], target["slug"], ts))
            con.execute(q("UPDATE cli_redirects SET new_slug = ? WHERE new_slug = ?", self.db), (target["slug"], source["slug"]))
            con.execute(q("UPDATE cli_tools SET status = 'removed', updated_at = ? WHERE cli_id = ?", self.db), (ts, source["cli_id"]))
            self._audit(con, source["cli_id"], "merged_into", owner_id, json.dumps({"target": target["slug"]}))
            self._audit(con, target["cli_id"], "merged_from", owner_id, json.dumps({"source": source["slug"]}))
            con.commit()
        self.search_index.remove(source["cli_id"])
        logger.info("Merged CLI tool '%s' into '%s'", source["slug"], target["slug"])
        return {"message": f"Merged '{source['slug']}' into '{target['slug']}'", "target_slug": target["slug"]}

    def get_scan(self, slug: str, version: str | None) -> dict[str, Any]:
        """Get scan results for a tool version. Raises NotFoundError if missing."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            if not version:
                version = tool["latest_version"]
            row = con.execute(q("SELECT scan_result FROM cli_versions WHERE cli_id = ? AND version = ?", self.db),
                              (tool["cli_id"], version)).fetchone()
            if not row:
                logger.warning("Version '%s' not found for scan on '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
        return {"version": version, "scan_status": tool.get("scan_status", "pending"),
                "scan_result": parse_json_field(row_to_dict(row).get("scan_result"), {})}

    def rescan(self, slug: str, version: str | None) -> dict[str, Any]:
        """Re-run security scan on a tool version. Raises NotFoundError if missing."""
        with self.db.get_connection() as con:
            tool = self._get_or_404(slug, con)
            if not version:
                version = tool["latest_version"]
            ver_row = con.execute(q("SELECT install_cmd, entry_point, requires, skill_md_url FROM cli_versions WHERE cli_id = ? AND version = ?", self.db),
                                  (tool["cli_id"], version)).fetchone()
            if not ver_row:
                logger.warning("Version '%s' not found for rescan on '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
            vr = row_to_dict(ver_row)
            result = scan_cli_tool(vr["install_cmd"], vr.get("entry_point", ""),
                                    vr.get("requires", ""), tool.get("homepage", ""), vr.get("skill_md_url", ""))
            scan_status = "flagged" if result.risk_score >= self.config.scan_flag_threshold else "clean"
            ts = now()
            con.execute(q("UPDATE cli_versions SET scan_result = ? WHERE cli_id = ? AND version = ?", self.db),
                        (json.dumps(result.model_dump()), tool["cli_id"], version))
            if version == tool["latest_version"]:
                con.execute(q("UPDATE cli_tools SET scan_status = ?, updated_at = ? WHERE cli_id = ?", self.db), (scan_status, ts, tool["cli_id"]))
            self._audit(con, tool["cli_id"], "rescanned", "", json.dumps({"version": version, "risk_score": result.risk_score}))
            con.commit()
        return {"version": version, "scan_status": scan_status, "scan_result": result.model_dump()}
