# Building the studio API pod

This repo builds into the **studio API pod**: agents/skills/workflows
authoring, operational insights (signals, barriers, HIL queue), and auth.
It deliberately installs **no solution packs for catalog purposes** — solution
content reaches it through the database (`agents/sync`, `workflows/sync`,
`workspace push`, all run on the engine pod). The one exception is noted
below.

## What goes into the image

| Piece | Where it comes from |
|---|---|
| `agentfarm-api` (this repo, distribution name `agentfarm-api`) | `pip install .` |
| `agentfarm-core` | Artifactory, transitively — declared in this repo's `pyproject.toml`. Brings the `ioagentfarm` CLI into this pod's own environment. |
| `agentfarm-barrier-signal` | Artifactory, explicit — **only** for the `iof-playbook` CLI (see HIL note) |

## Dockerfile

```dockerfile
FROM python:3.12-slim

ARG PIP_INDEX_URL
ENV PIP_INDEX_URL=${PIP_INDEX_URL}

WORKDIR /app
COPY . /app

# agentfarm-core arrives transitively (declared dependency).
# agentfarm-barrier-signal is ONLY for the HIL queue's iof-playbook CLI —
# the catalog never needs solution packs here. Requires that wheel to be
# published to the index; omit the second name until it is, accepting that
# HIL playbook approve/reject returns 500 (see below).
RUN pip install --no-cache-dir . agentfarm-barrier-signal

ENV IOF_ROOT=/data/.iof
EXPOSE 8002
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8002"]
```

No entrypoint script is needed — the API creates its `studio_*` tables
idempotently at startup (respecting `IOF_DB_SCHEMA`) and has no per-pod
agent seeding.

## Runtime environment (ConfigMap/Secret)

The `.env`-file mechanism is for local dev; in K8s these are plain env vars.
The API's env must be **complete** — it never falls back to another service's
configuration.

| Var | Value | Notes |
|---|---|---|
| `IOF_DATABASE_URL` | postgres URL | same DB as the engine pod |
| `IOF_DB_SCHEMA` | your engine schema name | **identical to the engine pod** |
| `BARRIER_SIGNAL_DB_URL` / `_SCHEMA` | hub DB | operational-insights routers read these |
| `IOF_ROOT` | `/data/.iof` | pod-local; NOT shared with the engine pod — shared truth is Postgres |
| `IOF_RUN_API_URL` | `http://<engine-service>:8111` | run creation / chat proxy to the engine pod |
| `IOF_AUTH_JWT_SECRET` | from Secret | **required** — tokens are signed with it; the `change-me` default lets anyone mint a valid token |
| `IOF_BOOTSTRAP_ADMIN` | admin email(s), comma-separated | seeded as platform admins at startup. Membership is CLOSED, so without this nobody can grant anyone access |
| `IOF_AUTHZ_ENFORCE` | omit (defaults on) | `0` keeps token verification but stops enforcing membership — a rollback lever, not a deploy mode |
| `IOF_UI_CORS` | UI origin(s) | |
| `IOF_BIN` | **omit** | the CLI is in this pod's own environment (core is a declared dependency); the resolver finds it beside the interpreter. Set only if the API is ever launched by an interpreter without agentfarm-core. |
| `IOF_AUTH_DEV` | **never set in a pod** | dev-only bypass that accepts any credentials |

## The HIL exception

`app/routers/hil_queue.py` shells **`iof-playbook`** — a *solution* console
script and the only playbook decision write path. It is a validating DB
client, so it runs fine in this pod against the shared hub DB, but it must
be installed: that is the sole reason `agentfarm-barrier-signal` appears in
the Dockerfile. Without it, playbook approve/reject returns a clear 500
naming the missing binary; everything else works.

## Health / smoke

- `GET :8002/api/health` → 200
- After the engine pod's catalog syncs have run: `GET :8002/api/studio/agents`
  with header `X-Workspace-Id: barrier_insights` → 6 agents
  (Jarvis/Quinn/Alex + Ava/Maya/Vera); `GET :8002/api/studio/workflows` → 4.
- If workspaces all show identical unscoped lists, `agents/sync` has not run
  on the engine pod.
