"""The auth tables (``user`` / ``user_password``), ensured idempotently.

WHY THIS EXISTS. Every other table this API owns is self-provisioning —
``studio_workflow_defs`` via ``workflow_defs.ensure_defs``,
``studio_workspace_members`` via ``workspace_members.ensure_table``, the whole
platform set via ``ioagentfarm.workspace_sync.ensure_platform_schema``. The two
auth tables were the exception: they existed ONLY in
``scripts/setup_schema.sql``, which is PostgreSQL DDL applied by hand.

On the backend the README calls the default (``sqlite``, and on any Postgres
deployment where that script had not been run yet) the result was not a
degraded login — it was a 500:

    POST /api/auth/login -> 500
    sqlite3.OperationalError: no such table: user

A brand-new installation could therefore not log in at all, and the error told
the operator nothing about which of the twelve setup steps had been missed.
Ensuring the tables here makes the same request answer ``401 Invalid email or
password`` — the truth ("no such account") instead of a stack trace.

Ensuring is NOT seeding: there is still no account until one is created
(``scripts/seed_user.py``, ``POST /api/admin/users``, or SSO first-login).
"""

from __future__ import annotations

import logging

from app.database import placeholder

logger = logging.getLogger(__name__)

#: ``user`` is a reserved word in both backends — always quoted.
_USER_DDL_PG = (
    'CREATE TABLE IF NOT EXISTS "user" ('
    "  id            SERIAL PRIMARY KEY,"
    "  sso_id        TEXT NOT NULL DEFAULT '',"
    "  first_name    TEXT NOT NULL DEFAULT '',"
    "  last_name     TEXT NOT NULL DEFAULT '',"
    "  email         TEXT NOT NULL UNIQUE,"
    "  is_active     INTEGER NOT NULL DEFAULT 1,"
    "  created_date  TEXT"
    ")"
)

_USER_DDL_SQLITE = (
    'CREATE TABLE IF NOT EXISTS "user" ('
    "  id            INTEGER PRIMARY KEY AUTOINCREMENT,"
    "  sso_id        TEXT NOT NULL DEFAULT '',"
    "  first_name    TEXT NOT NULL DEFAULT '',"
    "  last_name     TEXT NOT NULL DEFAULT '',"
    "  email         TEXT NOT NULL UNIQUE,"
    "  is_active     INTEGER NOT NULL DEFAULT 1,"
    "  created_date  TEXT"
    ")"
)

_PASSWORD_DDL = (
    "CREATE TABLE IF NOT EXISTS user_password ("
    '  user_id   INTEGER PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,'
    "  password  TEXT NOT NULL"
    ")"
)

_ensured = False


def ensure_user_tables(con) -> None:
    """Create the auth tables if absent. Idempotent, once per process."""
    global _ensured
    if _ensured:
        return
    cur = con.cursor()
    is_pg = placeholder() == "%s"
    cur.execute(_USER_DDL_PG if is_pg else _USER_DDL_SQLITE)
    cur.execute(_PASSWORD_DDL)
    try:
        con.commit()
    except Exception:      # pragma: no cover - autocommit connections
        pass
    _ensured = True


def reset_cache() -> None:
    """Forget the once-per-process flag (tests repoint the database)."""
    global _ensured
    _ensured = False
