"""Studio workflow definition store — the engine DB is the SINGLE source of
truth for what workflows exist and what they contain.

Table (engine DB, studio-owned by name — same convention as
``studio_skill_scripts``): ``studio_workflow_defs``

    code         TEXT PRIMARY KEY   -- workflow code/slug
    yaml         TEXT               -- the full workflow.yaml definition
    files_json   TEXT               -- {"steps/x.md": "...", "roles/y.md": "..."}
    source       TEXT               -- 'pack-sync' (imported) | 'studio' (authored)
    shadows_pack INTEGER            -- 1 when a studio def hides a pack workflow
    synced_at    TEXT               -- last written by POST /workflows/sync
    updated_at   TEXT               -- last written by anything

Principles (do not regress):
  * Every workflow LIST/DETAIL read in the API resolves from this table
    (joined with the engine's own ``iof.workflows`` run-metadata registry).
    Local YAML files are NEVER a display source — pack files are an *import
    format*, read exactly once by ``sync_from_disk()`` (the sync endpoint).
  * An empty table means an empty catalog plus a hint to run sync — never a
    silent fallback to disk (fail-honest, like the 503 engine-DB contract).
  * Studio create/edit writes the DB record FIRST; the engine-format override
    directory under ``<IOF_ROOT>/workflows/<code>/`` is a derived artifact
    regenerated from the record (the engine still executes from files).
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone

import yaml

#: Friendly empty-catalog hint, surfaced as the X-Workflow-Defs-Hint response
#: header on empty lists and inside 404 details (ASCII only: HTTP headers
#: must be latin-1 encodable).
EMPTY_HINT = (
    "the engine's installed packs provide no workflows for this workspace "
    "and it holds no definition of its own - install the solution pack on "
    "the engine (the Studio reads what the engine runs; sync imports nothing)"
)

#: Fallback DDL (already workspace-keyed) for the rare case the engine
#: package is not importable — the real ensure delegates to the SINGLE
#: shared implementation in ioagentfarm.workspace_sync.ensure_platform_schema
#: (which also migrates legacy single-tenant tables in place).
_TABLE_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workflow_defs ("
    "  workspace_code TEXT NOT NULL DEFAULT 'default',"
    "  code           TEXT NOT NULL,"
    "  yaml           TEXT NOT NULL,"
    "  files_json     TEXT NOT NULL DEFAULT '{}',"
    "  source         TEXT NOT NULL DEFAULT 'pack-sync',"
    "  shadows_pack   INTEGER NOT NULL DEFAULT 0,"
    "  synced_at      TEXT,"
    "  updated_at     TEXT NOT NULL,"
    "  imported_sha   TEXT NOT NULL DEFAULT '',"
    "  imported_hash  TEXT NOT NULL DEFAULT '',"
    "  origin         TEXT NOT NULL DEFAULT '',"
    "  content_hash   TEXT NOT NULL DEFAULT '',"
    "  version        INTEGER NOT NULL DEFAULT 1,"
    "  solution       TEXT NOT NULL DEFAULT '',"
    "  PRIMARY KEY (workspace_code, code)"
    ")"
)

_COLUMNS = "code, yaml, files_json, source, shadows_pack, synced_at, updated_at"

#: Read-side columns (adds the materialize-on-use sync key + the owning
#: solution within the workspace family; writes keep _COLUMNS so the INSERT
#: column list stays in lockstep with its VALUES — `solution` is written by
#: the ENGINE's pack sync / repo import, never by this API).
_READ_COLUMNS = _COLUMNS + ", content_hash, version, solution"

_ensured_urls: set[str] = set()

from ioagentfarm.engine.workspaces import PLATFORM_TIER

# The internal shared-tier key (the retired literal, kept for existing
# rows). NOT a workspace: requests can never resolve to it.
DEFAULT_WS = PLATFORM_TIER


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _commit(con) -> None:
    """Commit when the backend needs it (sqlite); harmless no-op elsewhere."""
    try:
        con.commit()
    except Exception:
        pass


def ensure_defs(con) -> None:
    """Idempotent ensure + legacy migration — run at startup and lazily.

    Delegates to the engine's shared implementation (tenant columns +
    composite PK + in-place migration of single-tenant tables); the local
    DDL is only a last-resort fallback when the engine import fails.
    """
    try:
        from ioagentfarm.workspace_sync import ensure_platform_schema
        from app.database import placeholder
        ensure_platform_schema(con, placeholder() == "%s")
        return
    except ImportError:
        pass
    cur = con.cursor()
    cur.execute(_TABLE_DDL)
    _commit(con)


def ensure_defs_once(con) -> None:
    """``ensure_defs`` once per (engine DB URL, schema) in this process.

    THE READ PATHS MUST USE THIS. ``ensure_defs`` is 16 statements against
    the engine DB, and it was being re-run on the way into every studio
    read — ~4s per call over a WAN, twice per `/api/studio/agents` request,
    to re-create tables that already existed. The DDL is idempotent and the
    migrations inside it are one-time, which is exactly why ``main.py``
    already runs it once at startup; the lazy call is the fallback for a
    database that was not up then, not a per-request obligation.

    Shared memo in ``app.database`` so this and ``drafts._ensured`` cannot
    key it differently.
    """
    from app.database import ensure_once
    ensure_once("platform_schema", con, ensure_defs)


#: Back-compat alias — the private name predates the read/write split.
_ensure_once = ensure_defs_once


# ── CRUD (workspace-scoped: the composite key IS the tenant boundary) ──

def list_defs(workspace_code: str) -> list[dict]:
    """The workspace's stored workflow definitions, ordered by code."""
    from app.database import get_db, q
    with get_db() as con:
        _ensure_once(con)
        cur = con.cursor()
        cur.execute(q(f"SELECT {_READ_COLUMNS} FROM studio_workflow_defs "
                      "WHERE workspace_code=? ORDER BY code"),
                    (workspace_code,))
        return [dict(r) for r in cur.fetchall()]


def get_def(code: str, workspace_code: str) -> dict | None:
    """One stored definition by (workspace, code) (None when absent)."""
    from app.database import get_db, q
    with get_db() as con:
        _ensure_once(con)
        cur = con.cursor()
        cur.execute(q(f"SELECT {_READ_COLUMNS} FROM studio_workflow_defs "
                      "WHERE workspace_code=? AND code=?"),
                    (workspace_code, code))
        row = cur.fetchone()
        return dict(row) if row else None


def _upsert_row(code: str, yaml_text: str, files_json: str, source: str,
                shadows_pack: int, synced_at: str | None, updated_at: str,
                workspace_code: str) -> None:
    # Materialize-on-use sync key: every save recomputes content_hash and
    # bumps version (hash equality makes no-op saves free at pull time).
    from app.database import get_db, q
    try:
        from ioagentfarm.engine.hydration import workflow_content_hash
    except ImportError:                     # engine absent: same canonicalization
        import hashlib

        def workflow_content_hash(y: str, fs: dict[str, str]) -> str:
            h = hashlib.sha256()
            h.update(y.encode("utf-8"))
            for rel in sorted(fs):
                h.update(b"\x00")
                h.update(rel.encode("utf-8"))
                h.update(b"\x01")
                h.update(fs[rel].encode("utf-8"))
            return h.hexdigest()
    try:
        files = json.loads(files_json or "{}")
    except json.JSONDecodeError:
        files = {}
    chash = workflow_content_hash(yaml_text, files if isinstance(files, dict) else {})
    with get_db() as con:
        ensure_defs_once(con)
        cur = con.cursor()
        cur.execute(
            q("INSERT INTO studio_workflow_defs "
              f"(workspace_code, {_COLUMNS}, content_hash, version) "
              "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1) "
              "ON CONFLICT (workspace_code, code) DO UPDATE SET "
              "yaml=excluded.yaml, files_json=excluded.files_json, "
              "source=excluded.source, shadows_pack=excluded.shadows_pack, "
              "synced_at=excluded.synced_at, updated_at=excluded.updated_at, "
              "content_hash=excluded.content_hash, "
              "version=studio_workflow_defs.version + 1"),
            (workspace_code, code, yaml_text, files_json, source, shadows_pack,
             synced_at, updated_at, chash),
        )
        _commit(con)


def upsert_def(code: str, yaml_text: str, files: dict[str, str], *,
               source: str, shadows_pack: bool = False,
               synced_at: str | None = None,
               workspace_code: str) -> None:
    """Insert or replace a definition. ``source`` is 'pack-sync' or 'studio'."""
    _upsert_row(code, yaml_text, json.dumps(files or {}), source,
                1 if shadows_pack else 0, synced_at, _now(),
                workspace_code=workspace_code)


def restore_def(row: dict, workspace_code: str) -> None:
    """Put a previously-read row back verbatim (dry-run rollback path)."""
    _upsert_row(row["code"], row["yaml"], row["files_json"] or "{}",
                row["source"], int(row["shadows_pack"] or 0),
                row["synced_at"], row["updated_at"],
                workspace_code=workspace_code)


def delete_def(code: str, workspace_code: str) -> bool:
    """Remove a definition. Returns True when a row was deleted."""
    from app.database import get_db, q
    with get_db() as con:
        _ensure_once(con)
        cur = con.cursor()
        cur.execute(q("DELETE FROM studio_workflow_defs "
                      "WHERE workspace_code=? AND code=?"),
                    (workspace_code, code))
        deleted = cur.rowcount > 0
        _commit(con)
        return deleted


def def_files(row: dict) -> dict[str, str]:
    """The stored prompt/role files of a definition row."""
    try:
        files = json.loads(row.get("files_json") or "{}")
        return files if isinstance(files, dict) else {}
    except json.JSONDecodeError:
        return {}


# ── YAML parsing (of STORED text — no file reads) ────────────────

def parse_yaml_tolerant(yaml_text: str) -> dict:
    """Parsed workflow data, or {} when the stored YAML is malformed."""
    try:
        data = yaml.safe_load(yaml_text)
        return data if isinstance(data, dict) else {}
    except yaml.YAMLError:
        return {}


def extract_roles(data: dict) -> list[str]:
    """Unique role names from a parsed workflow definition."""
    role_names: list[str] = []
    for r in data.get("roles", []):
        if isinstance(r, dict):
            role_names.append(r.get("name", ""))
        elif isinstance(r, str):
            role_names.append(r)
    return list(dict.fromkeys(n for n in role_names if n))


def extract_role_specs(data: dict) -> list[dict]:
    """The per-role JOB SPEC a definition declares, not just the role names.

    ``skills:`` is the most consequential line a workflow role can carry and
    the Studio rendered none of it. It is the EXACT set for that job: it may
    name a capability no agent holds, and every capability it omits is simply
    not loaded — including the always-on ones. So ``None`` (this role does not
    narrow anything) and ``[]`` (this role is narrowed to nothing) must stay
    distinguishable all the way to the screen; collapsing them to a list would
    make "everything the agent has" look identical to "nothing at all".
    """
    specs: list[dict] = []
    for r in data.get("roles", []) or []:
        if isinstance(r, str):
            specs.append({"name": r, "prompt": "", "skills": None, "model": ""})
            continue
        if not isinstance(r, dict) or not r.get("name"):
            continue
        skills = r.get("skills")
        specs.append({
            "name": r["name"],
            "prompt": r.get("prompt") or "",
            "skills": list(skills) if isinstance(skills, list) else None,
            "model": r.get("model") or "",
        })
    return specs


def parse_studio_workflow(yaml_text: str, fallback_name: str) -> dict:
    """Studio-shaped view of a stored definition (rich step graph).

    Raises yaml.YAMLError on malformed text — callers that must stay listable
    catch and degrade.
    """
    data = yaml.safe_load(yaml_text) or {}
    steps = []
    for s in data.get("steps", []):
        steps.append({
            "key": s.get("key"),
            "title": s.get("title", ""),
            "role": s.get("role") or ("system" if s.get("type") == "exec" else ""),
            "type": s.get("type", "normal"),
            "deps": s.get("deps", []) or [],
            "command": s.get("command", ""),
            # The path of the step's instruction file, so a reader can be
            # shown WHAT the step tells the agent. The parsed graph carried
            # only the title, which is the one line of a step that says the
            # least.
            "prompt": s.get("prompt", "") or "",
            "requires_artifacts": s.get("requires_artifacts", []) or [],
            "per_item_steps": [
                {"key_suffix": t.get("key_suffix"), "role": t.get("role"),
                 "title": t.get("title", ""), "deps": t.get("deps", []) or []}
                for t in (s.get("per_item_steps") or [])
            ],
        })
    # `team:` is the declared roster. It is OPTIONAL in the engine's contract
    # (only `roles:` and `steps:` are load-bearing), and the catalog rendered
    # its absence as "no agents" — which is never true of a workflow that
    # runs. Fall back to the roles the steps actually name, in step order, so
    # every screen that asks "who is on this?" gets an honest answer.
    team = [t.get("role") for t in data.get("team", []) or []
            if isinstance(t, dict) and t.get("role")]
    if not team:
        team = list(dict.fromkeys(
            s["role"] for s in steps if s["role"] and s["type"] != "exec"))
    return {
        "name": data.get("name", fallback_name),
        "description": (data.get("description") or "").strip(),
        "team": team,
        "roles": extract_role_specs(data),
        "vars": data.get("vars", {}) or {},
        "steps": steps,
    }


# ── Disk discovery lives in the ENGINE ───────────────────────────
#
# `pack_workflow_dirs`, `override_workflow_dirs`, `discover_workflow_sources`,
# `read_workflow_dir`, `workflow_pack_map` and `sync_from_disk` were all here,
# and all of them read a filesystem this process does not own. Two things were
# wrong with that, one visible and one not:
#
#   * the API pod has no packs installed, so there is nothing to import;
#   * `_PACK_GLOBS` globbed `IOF_AGENTFARM_DIR/solutions/*/*/*/workflows/…` —
#     a REPO LAYOUT. It matched only on a developer's checkout of this
#     monorepo. Anywhere else, sync reported success and imported nothing.
#
# They now live in `ioagentfarm.engine.catalog_sync`, reached over HTTP
# (`POST /api/workflows/defs/sync`) or as `ioagentfarm sync` with no server,
# and resolved from the PACK REGISTRY rather than a path shape. The API's
# `POST /api/studio/workflows/sync` is a thin proxy so the Studio's call is
# unchanged.
#
# Nothing in this module touches a file any more. That is the property worth
# keeping: every read AND every write here is a row.
