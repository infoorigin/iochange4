"""Request-scoped tenant context — the middleware side of app/tenancy.py.

A contextvar carries the active workspace code for the duration of each
request so deep call sites (the studio visibility filter, the workflow
catalog) stay signature-stable instead of threading a header through every
function. Set once per request by the middleware registered in main.py.

FAIL-CLOSED: there is no default. ``active_code()`` raises when nothing set
it — which means either the middleware exempted this path from tenancy (the
handler should not be doing workspace-scoped work), or the call site is
running OUTSIDE a request (startup warmup, background thread) and must be
given an explicit code instead of borrowing an ambient one.
"""
from __future__ import annotations

from contextvars import ContextVar

_active_code: ContextVar[str | None] = ContextVar("active_workspace_code",
                                                  default=None)


def set_active_code(code: str | None) -> None:
    _active_code.set((code or "").strip() or None)


def active_code() -> str:
    code = _active_code.get()
    if not code:
        raise RuntimeError(
            "no active workspace in this context: the request path is "
            "exempt from tenancy resolution, or this code is running "
            "outside a request. Workspace-scoped work needs an explicit "
            "workspace code here — there is no fallback workspace.")
    return code


def maybe_active_code() -> str | None:
    """The active code, or ``None`` — for reporting/diagnostic paths only."""
    return _active_code.get()
