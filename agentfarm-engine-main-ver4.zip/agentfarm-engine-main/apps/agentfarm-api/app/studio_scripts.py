"""Studio script catalog — DB-catalogued commands a skill can be bound to.

A *skill script* is a CLI command (``iof-query``, ``vectorfs``, …) that a
Studio-authored skill teaches an agent to run via exec. The catalog lives in
the ENGINE database (the single system of record — ``IOF_DATABASE_URL``
resolved at request time via ``app.database``), in its own clearly-named
table ``studio_skill_scripts`` (studio-owned by name, so it can never be
mistaken for an engine-owned table), created idempotently on first use
following the store's migration pattern. NO engine code is touched: this is
an API-side table in the shared engine DB. Assumption (documented per design
review): the API's DB user has CREATE TABLE rights in the engine schema —
true for this deployment; on a locked-down RDS the DDL moves to
scripts/setup_schema.sql instead.

Fail-closed: creation validates every field; unknown scripts can never be
bound to a skill (the router checks membership here before composing the
skill package).
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.authz import require_member
from app.database import get_db, placeholder, q

# Same guard as the rest of /api/studio. This router is mounted separately, so
# a dependency on studio.router does NOT cover it — and POST here writes the
# script catalog that skills are allowed to bind to.
router = APIRouter(prefix="/api/studio/skill-scripts", tags=["studio"],
                   dependencies=[Depends(require_member)])

SCRIPT_NAME_RE = re.compile(r"^[a-z][a-z0-9_-]{1,40}$")

_TABLE_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_skill_scripts ("
    "  name        TEXT PRIMARY KEY,"
    "  title       TEXT NOT NULL,"
    "  description TEXT NOT NULL,"
    "  command     TEXT NOT NULL,"
    "  usage_md    TEXT NOT NULL,"
    "  owner       TEXT NOT NULL DEFAULT 'studio',"
    "  created_at  TEXT NOT NULL"
    ")"
)

#: Built-in rows — the engine CLI tools agents already invoke via exec today
#: (see tools.yaml / vectorfs_query + data_query skills). Seeded IF ABSENT so
#: a deployment can edit/extend them without re-seeding fights.
_SEED_ROWS = [
    {
        "name": "iof-query",
        "title": "Data query — SQL over the governed data catalog",
        "description": "Runs read-only SQL against the deployment's governed "
                       "data catalog (DuckDB). Grounds every figure the agent "
                       "states in a real query result.",
        "command": 'iof-query --sql "<SQL>"',
        "usage_md": "Run read-only SELECT statements against the catalog "
                    "entities. Always cite the entity and the query you ran. "
                    "If a column or table is not found, read the error's "
                    "catalog_schema hint and correct the query — never invent "
                    "values.",
        "owner": "core",
    },
    {
        "name": "vectorfs",
        "title": "Document search — vector filesystem reads",
        "description": "Read-only filesystem over the vector document store "
                       "(contracts, notes, reports). ls / cat / grep style "
                       "navigation for evidence retrieval.",
        "command": "vectorfs <ls|cat|grep> <path-or-pattern>",
        "usage_md": "Use ls to discover collections, grep to locate passages, "
                    "cat to quote evidence verbatim. Quote sources by path. "
                    "Never paraphrase a document you did not open.",
        "owner": "core",
    },
    {
        "name": "run-output",
        "title": "Run deliverables — read and publish run artifacts",
        "description": "Reads, greps and publishes deliverable files produced "
                       "by workflow runs (the engine's run-output surface).",
        "command": "ioagentfarm run-output <read|grep|publish> <file>",
        "usage_md": "Use to inspect prior step deliverables in the current "
                    "run before writing your own, and to publish your final "
                    "artifact.",
        "owner": "core",
    },
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ensure_catalog(con) -> None:
    """Idempotent ensure + seed. Cheap enough to run per request."""
    cur = con.cursor()
    cur.execute(_TABLE_DDL)
    insert = (
        "INSERT INTO studio_skill_scripts (name, title, description, command, usage_md, owner, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT (name) DO NOTHING"
        if placeholder() == "%s"
        else
        "INSERT OR IGNORE INTO studio_skill_scripts (name, title, description, command, usage_md, owner, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)"
    )
    for row in _SEED_ROWS:
        cur.execute(q(insert), (row["name"], row["title"], row["description"],
                               row["command"], row["usage_md"], row["owner"], _now()))
    if placeholder() != "%s":
        con.commit()


def get_script(name: str) -> dict | None:
    """Catalog row by name (None when absent). Used by the skills builder."""
    with get_db() as con:
        ensure_catalog(con)
        cur = con.cursor()
        cur.execute(q("SELECT * FROM studio_skill_scripts WHERE name = ?"), (name,))
        row = cur.fetchone()
        return dict(row) if row else None


class ScriptCreate(BaseModel):
    name: str
    title: str
    description: str
    command: str
    usage_md: str = ""


@router.get("")
def list_scripts():
    with get_db() as con:
        ensure_catalog(con)
        cur = con.cursor()
        cur.execute("SELECT * FROM studio_skill_scripts ORDER BY name")
        return [dict(r) for r in cur.fetchall()]


@router.post("", status_code=201)
def create_script(req: ScriptCreate):
    if not SCRIPT_NAME_RE.match(req.name):
        raise HTTPException(status_code=400,
                            detail="script name must match ^[a-z][a-z0-9_-]{1,40}$")
    for field in ("title", "description", "command"):
        if not getattr(req, field).strip():
            raise HTTPException(status_code=400, detail=f"{field} must not be empty")
    usage = req.usage_md.strip() or req.description.strip()
    with get_db() as con:
        ensure_catalog(con)
        cur = con.cursor()
        cur.execute(q("SELECT name FROM studio_skill_scripts WHERE name = ?"), (req.name,))
        if cur.fetchone():
            raise HTTPException(status_code=409,
                                detail=f"script '{req.name}' already exists")
        cur.execute(
            q("INSERT INTO studio_skill_scripts (name, title, description, command, "
              "usage_md, owner, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"),
            (req.name, req.title.strip(), req.description.strip(),
             req.command.strip(), usage, "studio", _now()),
        )
        if placeholder() != "%s":
            con.commit()
    return get_script(req.name)
