"""Pydantic models for request/response serialization."""

from __future__ import annotations

from pydantic import BaseModel
from typing import Optional


# ── Requests ──────────────────────────────────────────────────────

class SessionCreate(BaseModel):
    workflow: str
    goal: str
    project_dir: str = ""


class AuthLoginRequest(BaseModel):
    email: str
    password: str


class AuthTokenResponse(BaseModel):
    accessToken: str
    tokenType: str = "Bearer"


# ── Responses ─────────────────────────────────────────────────────

class AgentInfo(BaseModel):
    role: str
    name: str
    title: str
    color: str
    avatar: str


class WorkflowSummary(BaseModel):
    name: str
    description: str
    steps: list[str]
    roles: list[str]
    team: list[AgentInfo]


class StepDetail(BaseModel):
    key: str
    title: str
    role: str
    deps: list[str]
    agent: AgentInfo


class WorkflowDetail(WorkflowSummary):
    step_details: list[StepDetail]


class TeamMember(AgentInfo):
    status: str  # active | idle | done | failed
    current_step: Optional[str] = None


class SessionSummary(BaseModel):
    id: str
    workflow_name: str
    goal: str
    project_dir: str
    status: str
    created_at: str
    updated_at: str


class SessionDetail(SessionSummary):
    steps: list[dict]
    team: list[TeamMember]


class MessageOut(BaseModel):
    id: int
    run_id: str
    step_key: str
    role: str
    agent: AgentInfo
    content: str
    msg_type: str
    created_at: str


class MessagePage(BaseModel):
    messages: list[MessageOut]
    last_id: int


class SessionStartResponse(BaseModel):
    run_id: str
    status: str
    message: str
