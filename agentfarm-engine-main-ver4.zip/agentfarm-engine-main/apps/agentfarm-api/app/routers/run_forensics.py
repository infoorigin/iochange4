"""Run explainability — the forensic substrate, served to the Studio.

The engine has recorded a full forensic timeline per run since the
instrumentation phases (``forensic_events`` in the shared DB, indexed on
run_id / (run_id, step_key, attempt) / severity / event_type), and the CLI
composes it into a one-document postmortem (``aicore forensics explain``).
Until this router, NOTHING in the API read that table — the most
differentiating diagnostic data in the platform was CLI-only.

Three endpoints, all DB-composed (no engine, no filesystem):

  GET /api/studio/runs                      — the workspace's runs, listable
  GET /api/studio/runs/{run_id}/timeline    — the forensic event timeline
  GET /api/studio/runs/{run_id}/explain     — verdict + step table + rollup

plus one proxy for the filesystem-bound remainder (usage.jsonl totals,
structural session-failure parsing, swarm artifacts), forwarded to the
engine on the same rail as agent memory:

  GET /api/studio/runs/{run_id}/explain/artifacts

The DB layer covers ~85% of the CLI's explain; what it cannot derive is
``null`` with ``sources.engine=false`` — explicitly absent, never silently
zero. Verdict phrasing is ported from ``cli_forensics._build_explain``
(agentfarm-core), NOT imported: the API pod must not import CLI modules.

Workspace scoping is fail-closed and follows the run's OWN row: a run in
another workspace is 403 (listing never shows it), and a run with no
workspace attribution is 409 — the explicit-workspace invariant.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from app.authz import require_member
# Deliberately NOT `from app.database import get_db, q`: the test harness
# patches `app.database.get_db` per test, and a from-import would freeze the
# first test's patched closure into this module for the rest of the session.
# Calling through the module keeps every access on the live attribute.
from app import database
from app.workspace_context import active_code


def get_db():
    return database.get_db()


def q(sql: str) -> str:
    return database.q(sql)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio", tags=["run-forensics"],
                   dependencies=[Depends(require_member)])

_SEVERITY_ORDER = ("info", "warn", "error", "fatal")


def _rows(cur) -> list[dict]:
    return [dict(r) for r in cur.fetchall()]


def _events_for(con, run_id: str, *, step_key: Optional[str] = None,
                severity_min: Optional[str] = None,
                limit: Optional[int] = None) -> list[dict]:
    """The run's forensic events, ascending. Empty when the table is absent
    (an older schema) — the DB view degrades, it never 500s on history."""
    sql = ("SELECT ts, event_type, severity, step_key, attempt, message, "
           "payload_json FROM forensic_events WHERE run_id=?")
    params: list[Any] = [run_id]
    if step_key:
        sql += " AND step_key=?"
        params.append(step_key)
    if severity_min and severity_min in _SEVERITY_ORDER:
        allowed = _SEVERITY_ORDER[_SEVERITY_ORDER.index(severity_min):]
        sql += f" AND severity IN ({','.join('?' * len(allowed))})"
        params.extend(allowed)
    sql += " ORDER BY ts ASC"
    if limit:
        sql += " LIMIT ?"
        params.append(limit)
    try:
        cur = con.cursor()
        cur.execute(q(sql), tuple(params))
        return _rows(cur)
    except Exception:
        logger.debug("forensic_events unavailable for %s", run_id,
                     exc_info=True)
        return []


def _payload(event: dict) -> dict:
    try:
        return json.loads(event.get("payload_json") or "{}") or {}
    except Exception:
        return {}


def _run_scoped(con, run_id: str) -> dict:
    """The run row, after the fail-closed workspace check."""
    cur = con.cursor()
    cur.execute(q("SELECT * FROM runs WHERE id=?"), (run_id,))
    row = cur.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"run '{run_id}' not found")
    run = dict(row)
    ws_id = run.get("workspace_id")
    if not ws_id:
        raise HTTPException(
            status_code=409,
            detail=f"run '{run_id}' is not attributed to a workspace")
    cur.execute(q("SELECT code FROM workspaces WHERE id=?"), (ws_id,))
    ws_row = cur.fetchone()
    code = dict(ws_row)["code"] if ws_row else None
    if code != active_code():
        raise HTTPException(
            status_code=403,
            detail=f"run '{run_id}' belongs to another workspace")
    return run


# ── list ────────────────────────────────────────────────────────────

@router.get("/runs")
def list_runs(limit: int = Query(50, ge=1, le=500),
              status: Optional[str] = None,
              workflow: Optional[str] = None) -> dict:
    ws = active_code()
    with get_db() as con:
        cur = con.cursor()
        sql = ("SELECT r.id AS run_id, r.workflow_name, r.kind, r.status, "
               "r.goal, r.created_at, r.updated_at, "
               "(SELECT COUNT(*) FROM steps s WHERE s.run_id = r.id) "
               "AS steps_total, "
               "(SELECT COUNT(*) FROM steps s WHERE s.run_id = r.id "
               " AND s.status='done') AS steps_done, "
               "(SELECT COUNT(*) FROM steps s WHERE s.run_id = r.id "
               " AND s.status='failed') AS steps_failed "
               "FROM runs r JOIN workspaces w ON w.id = r.workspace_id "
               "WHERE w.code=?")
        params: list[Any] = [ws]
        if status:
            sql += " AND r.status=?"
            params.append(status)
        if workflow:
            sql += " AND r.workflow_name=?"
            params.append(workflow)
        sql += " ORDER BY r.created_at DESC LIMIT ?"
        params.append(limit)
        cur.execute(q(sql), tuple(params))
        runs = _rows(cur)

        # Severity flags in ONE query, not one per run. Absent table -> {}.
        flagged: set[str] = set()
        if runs:
            ids = [r["run_id"] for r in runs]
            try:
                cur.execute(
                    q("SELECT DISTINCT run_id FROM forensic_events "
                      f"WHERE run_id IN ({','.join('?' * len(ids))}) "
                      "AND severity IN ('error','fatal')"),
                    tuple(ids))
                flagged = {dict(r)["run_id"] for r in cur.fetchall()}
            except Exception:
                pass

    out = []
    for r in runs:
        out.append({
            "run_id": r["run_id"],
            "workflow": r["workflow_name"],
            "kind": r.get("kind") or "workflow",
            "status": r["status"],
            "goal": r["goal"],
            "created_at": r["created_at"],
            "updated_at": r["updated_at"],
            "steps_total": int(r["steps_total"] or 0),
            "steps_done": int(r["steps_done"] or 0),
            "has_failures": bool(int(r["steps_failed"] or 0))
            or r["run_id"] in flagged,
        })
    return {"runs": out}


# ── timeline ────────────────────────────────────────────────────────

@router.get("/runs/{run_id}/timeline")
def run_timeline(run_id: str,
                 severity_min: Optional[str] = Query(
                     None, pattern="^(info|warn|error|fatal)$"),
                 step_key: Optional[str] = None,
                 limit: int = Query(500, ge=1, le=5000)) -> dict:
    with get_db() as con:
        _run_scoped(con, run_id)
        events = _events_for(con, run_id, step_key=step_key,
                             severity_min=severity_min, limit=limit)
    return {"events": [{
        "at": e.get("ts"),
        "event_type": e.get("event_type"),
        "severity": e.get("severity"),
        "step_key": e.get("step_key"),
        "attempt": e.get("attempt"),
        "payload": _payload(e) or (
            {"message": e.get("message")} if e.get("message") else {}),
    } for e in events]}


# ── explain (DB-composed) ───────────────────────────────────────────

def _compose_steps(step_rows: list[dict],
                   events: list[dict]) -> tuple[list[dict], Optional[dict]]:
    """The per-step table from rows + events; also the first failed step.

    Derivations mirror cli_forensics._build_explain (agentfarm-core), with
    the blob-derived fields re-derived from the events the orchestrator
    emits per attempt: duration from step.subprocess_exited, tool activity
    from step.tool_usage, stall retries from step.auto_retry_after_stall,
    the artifact gate from step.artifact_missing.
    """
    by_step: dict[str, dict[str, Any]] = {}
    for e in events:
        key = e.get("step_key")
        if not key:
            continue
        agg = by_step.setdefault(key, {
            "duration": 0.0, "tool_calls": 0, "wrote_output": False,
            "stalls": 0, "artifact_missing": None, "failure": None})
        etype = e.get("event_type")
        payload = _payload(e)
        if etype == "step.subprocess_exited":
            try:
                agg["duration"] += float(payload.get("duration_s") or 0)
            except (TypeError, ValueError):
                pass
        elif etype == "step.tool_usage":
            by_name = payload.get("by_name") or {}
            try:
                agg["tool_calls"] += sum(int(v) for v in by_name.values())
            except (TypeError, ValueError):
                pass
            agg["wrote_output"] = agg["wrote_output"] or bool(
                payload.get("wrote_output"))
        elif etype == "step.auto_retry_after_stall":
            agg["stalls"] += 1
        elif etype == "step.artifact_missing":
            agg["artifact_missing"] = payload.get("missing") or ["?"]
        if e.get("severity") in ("error", "fatal"):
            agg["failure"] = {"event_type": etype,
                              "message": e.get("message")}

    steps_out: list[dict] = []
    first_failed: Optional[dict] = None
    for row in step_rows:
        key = row["step_key"]
        agg = by_step.get(key, {})
        status = row.get("status") or "unknown"
        missing = agg.get("artifact_missing")
        if missing is not None:
            gate = "passed" if status == "done" else f"failed:{missing[0]}"
        else:
            # No artifact_missing event = no gate ever fired. A step with no
            # declared gate must read as NOTHING, not as a stringly 'n/a' the
            # UI styles as a failure - the walkthrough's converged run showed
            # a destructive 'missing: n/a' pill on a gateless workflow.
            gate = None
        failure = agg.get("failure")
        reason = (failure or {}).get("event_type") if status != "done" else None
        entry = {
            "key": key,
            "role": row.get("role") or "",
            "status": status,
            "attempts": int(row.get("attempt") or 0),
            "max_attempts": int(row.get("max_attempts") or 0),
            "duration_s": round(float(agg.get("duration") or 0.0), 1),
            "tool_calls": int(agg.get("tool_calls") or 0),
            "wrote_output": bool(agg.get("wrote_output")),
            "artifact_gate": gate,
            "failure_reason": reason,
            "stall_retries": int(agg.get("stalls") or 0),
        }
        steps_out.append(entry)
        if first_failed is None and status == "failed":
            first_failed = {**entry,
                            "_message": (failure or {}).get("message")}
    return steps_out, first_failed


@router.get("/runs/{run_id}/explain")
def run_explain(run_id: str) -> dict:
    with get_db() as con:
        run = _run_scoped(con, run_id)
        cur = con.cursor()
        cur.execute(q("SELECT * FROM steps WHERE run_id=? ORDER BY seq"),
                    (run_id,))
        step_rows = _rows(cur)
        events = _events_for(con, run_id)

    sev = {"warn": 0, "error": 0, "fatal": 0}
    last_error = None
    for e in events:
        s = e.get("severity")
        if s in sev:
            sev[s] += 1
        if s in ("error", "fatal"):
            last_error = e.get("message")

    steps_out, first_failed = _compose_steps(step_rows, events)
    total_stalls = sum(s["stall_retries"] for s in steps_out)
    done_steps = [s for s in steps_out if s["status"] == "done"]
    run_status = run.get("status") or "unknown"

    # Verdict phrasing ported from cli_forensics._build_explain (the CLI's
    # postmortem composer) — kept in its voice so the Studio and the CLI
    # give one answer to "what happened".
    gave_up = next((e for e in events
                    if e.get("event_type") in ("run.driver_gave_up",
                                               "supervisor.gave_up")), None)
    detail: list[str] = []
    if run_status == "done" and first_failed is None:
        status = "degraded" if (total_stalls or sev["error"] or sev["fatal"]) \
            else "converged"
        headline = (f"Run converged: {len(done_steps)}/{len(steps_out)} "
                    f"step(s) done")
        if total_stalls:
            headline += (f" after {total_stalls} auto-retr"
                         + ("y" if total_stalls == 1 else "ies"))
        headline += "."
        if sev["error"] or sev["fatal"]:
            detail.append(
                f"{sev['error'] + sev['fatal']} error-severity event(s) were "
                "absorbed on the way — the timeline has each one.")
    elif first_failed is not None:
        status = "failed"
        reason = (first_failed.get("_message")
                  or first_failed.get("failure_reason")
                  or ("required artifact never produced"
                      if str(first_failed["artifact_gate"] or "").startswith(
                          "failed:")
                      else "see the step's forensic timeline"))
        headline = (f"Run {run_status} at step "
                    f"'{first_failed['key']}': {reason}")
        if (first_failed["artifact_gate"] or "").startswith("failed:"):
            detail.append(
                "The fail-closed artifact gate refused the step: "
                f"{first_failed['artifact_gate'][len('failed:'):]} was "
                "missing or empty.")
    elif gave_up is not None:
        status = "failed"
        never_started = [s["key"] for s in steps_out
                         if s["status"] == "pending"]
        headline = ("Run did not converge: "
                    + (gave_up.get("message") or "the driver gave up")
                    + (f"; step(s) never started: "
                       f"{', '.join(never_started)}" if never_started else "")
                    + ". No step ran, so there is no step-level failure to "
                      "read - suspect the model endpoint or credentials.")
    else:
        status = "running" if run_status == "running" else run_status
        headline = f"Run status: {run_status}."

    return {
        "run": {"run_id": run_id,
                "workflow": run.get("workflow_name") or "",
                "kind": run.get("kind") or "workflow",
                "status": run_status,
                "goal": run.get("goal") or "",
                "created_at": run.get("created_at")},
        "verdict": {"status": status, "headline": headline, "detail": detail},
        "steps": steps_out,
        "severity_rollup": {**sev, "last_error": last_error},
        "usage": None,
        "sources": {"db": True, "engine": False},
    }


# ── the filesystem-bound remainder, proxied to the engine ───────────

@router.get("/runs/{run_id}/explain/artifacts")
def run_explain_artifacts(run_id: str) -> dict:
    """Usage totals, structural failure parsing and swarm artifacts.

    These live under the engine host's ``<IOF_ROOT>/instances/<run>/`` and
    CANNOT be derived from the database — same story as agent memory, same
    rail (the ``_engine_memory`` proxy pattern in studio.py).
    """
    with get_db() as con:
        _run_scoped(con, run_id)
    from app.engine_routing import engine_json
    return engine_json(
        "GET", f"/api/runs/{run_id}/explain/artifacts",
        purpose="run artifacts live on the engine host, not here")
