"""HIL Playbook Review Queue — the studio surface for the hub's hil_queue.

Generated playbooks enter the hub as ``status='hitl_pending'`` plus a
``hil_queue`` row (written by the barrier_signal pack's fail-closed
``iof-playbook catalog`` tool). This router makes that queue a first-class
studio surface:

  /queue                      — pending + recently-decided queue entries with
                                playbook/barrier context for the review list
  /playbooks/{id}             — full playbook (body_md, slots) + barrier
                                context for the review reading pane
  /playbooks/{id}/decision    — approve/reject. SHELLS OUT to the pack CLI
                                ``iof-playbook review`` and returns its verdict
                                verbatim. The CLI is the ONLY legitimate write
                                path for decisions (fail-closed tool ownership:
                                reject requires notes, approve chains
                                hitl_pending -> approved -> operational,
                                double-decide is blocked). This API NEVER
                                writes playbook/hil rows with SQL.

Reads are plain SELECTs over the hub (same conventions as
``barrier_insights.py``). The hub schema is read from
``BARRIER_SIGNAL_DB_SCHEMA`` at REQUEST TIME (not import time) so this
surface keeps working across the savant_data_hub -> savant_data_hub_v2
cutover without a redeploy. None of the surfaced tables carry HCP/author
person-name fields; ``decider``/``reviewed_by`` are deliberate audit fields
(the reviewer's recorded identity, mirrored verbatim by ``iof-playbook
list``), not PII to mask.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app import hub_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/hil", tags=["hil-queue"])

DEFAULT_HUB_SCHEMA = "savant_data_hub"
DECIDED_LIMIT = 15            # recently-decided entries surfaced in the queue
STATEMENT_EXCERPT = 300       # barrier statement cap in the queue list

_SCHEMA_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,62}$")
_PLAYBOOK_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")


def _hub_schema() -> str:
    """Hub schema resolved at REQUEST time — see app/hub_db.py."""
    return hub_db.hub_schema()


@contextmanager
def _hub():
    """Read-only hub cursor — POOLED, shared with the other hub routers.

    Was a private copy that opened and closed a connection per request; see
    app/hub_db.py for why five identical copies became one.
    """
    with hub_db.hub_cursor() as cur:
        yield cur


def _rows(cur) -> list[dict]:
    return [dict(r) for r in cur.fetchall()]


# ── the pack CLI (the ONLY decision write path) ──────────────────

def _playbook_bin() -> str:
    """Resolve the ``iof-playbook`` CLI to a concrete executable path.

    Resolution order (mirrors the ``_iof_bin``/IOF_BIN pattern in studio.py):
      1. ``IOF_PLAYBOOK_BIN`` env override (absolute path, or name on PATH)
      2. the running interpreter's own scripts dir (repo .venv/Scripts when
         the API is started from it — where the barrier_signal pack installs)
      3. plain PATH lookup.
    Fails loudly with a clear 500 instead of an opaque FileNotFoundError.
    """
    override = (os.getenv("IOF_PLAYBOOK_BIN") or "").strip()
    if override:
        p = Path(override)
        if p.is_file():
            return str(p)
        found = shutil.which(override)
        if found:
            return found
    exe_dir = Path(sys.executable).resolve().parent
    for name in ("iof-playbook.exe", "iof-playbook"):
        cand = exe_dir / name
        if cand.is_file():
            return str(cand)
    found = shutil.which("iof-playbook")
    if found:
        return found
    raise HTTPException(
        status_code=500,
        detail="iof-playbook CLI not found: install the barrier_signal pack "
               "into the API's venv or set IOF_PLAYBOOK_BIN to the full path "
               "of the executable (e.g. <repo>/.venv/Scripts/iof-playbook.exe)")


def _cli_env() -> dict[str, str]:
    """Subprocess env for the CLI — pin hub URL + schema to what THIS request
    resolved, so the CLI decides in the same hub/schema the studio displays
    (real env vars win over the tool's own ~/.barrier_signal/.env lookup)."""
    env = os.environ.copy()
    url = os.getenv("BARRIER_SIGNAL_DB_URL", "").strip()
    if url:
        env["BARRIER_SIGNAL_DB_URL"] = url
    env["BARRIER_SIGNAL_DB_SCHEMA"] = _hub_schema()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    return env


# ── queue ────────────────────────────────────────────────────────

@router.get("/queue")
def review_queue():
    """Pending + recently-decided queue entries with barrier context."""
    base_select = (
        "SELECT q.queue_id, q.playbook_id, q.status AS queue_status, "
        "       q.requested_at, q.decided_at, q.decision, q.decider, q.notes, "
        "       p.title, p.template_id, p.status AS playbook_status, "
        "       p.created_at, p.reviewed_by, "
        "       b.barrier_id, b.barrier_type, b.title AS barrier_title, "
        "       left(b.statement, %s) AS barrier_statement, "
        "       b.geography_scope, b.severity, b.signal_count "
        "FROM hil_queue q "
        "JOIN playbooks p ON p.playbook_id = q.playbook_id "
        "LEFT JOIN barriers b ON b.barrier_id = p.barrier_id ")
    with _hub() as cur:
        cur.execute(base_select + "WHERE q.status = 'pending' "
                    "ORDER BY q.queue_id", (STATEMENT_EXCERPT,))
        pending = _rows(cur)
        cur.execute(base_select + "WHERE q.status = 'decided' "
                    "ORDER BY q.decided_at DESC NULLS LAST, q.queue_id DESC "
                    "LIMIT %s", (STATEMENT_EXCERPT, DECIDED_LIMIT))
        decided = _rows(cur)
    return {
        "schema": _hub_schema(),
        "pending_count": len(pending),
        "pending": pending,
        "decided": decided,
    }


# ── playbook library (all playbooks, not just the review queue) ──

@router.get("/playbooks")
def list_playbooks():
    """Every playbook in the hub with template + barrier context (the W6
    Playbooks library + the catalog picker's Playbooks tab).

    Read-only SELECT over the hub — the queue endpoint above only surfaces
    rows with a hil_queue entry; this lists the full catalog regardless of
    review state. Newest first. LEFT JOINs so a playbook without a template or
    barrier still lists."""
    with _hub() as cur:
        cur.execute(
            "SELECT p.playbook_id, p.template_id, t.name AS template_name, "
            "       p.barrier_id, p.title, p.status, p.reviewed_by, "
            "       p.generated_by_run, p.created_at, "
            "       b.barrier_type, b.geography_scope, b.severity, "
            "       b.signal_count, "
            "       q.status AS queue_status "
            "FROM playbooks p "
            "LEFT JOIN playbook_templates t ON t.template_id = p.template_id "
            "LEFT JOIN barriers b ON b.barrier_id = p.barrier_id "
            "LEFT JOIN LATERAL ("
            "    SELECT status FROM hil_queue hq "
            "    WHERE hq.playbook_id = p.playbook_id "
            "    ORDER BY hq.queue_id DESC LIMIT 1"
            ") q ON true "
            "ORDER BY p.created_at DESC NULLS LAST, p.playbook_id DESC")
        playbooks = _rows(cur)
    return {"schema": _hub_schema(), "count": len(playbooks),
            "playbooks": playbooks}


def counts() -> dict:
    """``{playbooks, hil_pending}`` — the sidebar's two hub numbers.

    Two `count(*)`s on ONE hub connection, in place of the two full catalog
    endpoints the sidebar used to call for their `.length`. `_hub()` opens a
    fresh connection per call (no pool on this side yet), so halving the
    calls halves the connects, which is most of what they cost.

    Not a route: the sidebar asks `/api/studio/counts` once, and this is the
    hub half of that answer. Keeping it beside the queries it mirrors is what
    stops the badge and the page drifting apart.
    """
    with _hub() as cur:
        cur.execute("SELECT count(*) AS n FROM playbooks")
        playbooks = _rows(cur)[0]["n"]
        cur.execute("SELECT count(*) AS n FROM hil_queue WHERE status = 'pending'")
        pending = _rows(cur)[0]["n"]
    return {"playbooks": int(playbooks), "hil_pending": int(pending)}


# ── playbook detail (the review reading pane) ────────────────────

@router.get("/playbooks/{playbook_id}")
def playbook_detail(playbook_id: str):
    """Full playbook body + slots + barrier context + queue state."""
    with _hub() as cur:
        cur.execute(
            "SELECT p.playbook_id, p.template_id, t.name AS template_name, "
            "       p.barrier_id, p.title, p.body_md, p.slots_filled, "
            "       p.status, p.review_notes, p.reviewed_by, p.reviewed_at, "
            "       p.generated_by_run, p.created_at, p.updated_at "
            "FROM playbooks p "
            "LEFT JOIN playbook_templates t ON t.template_id = p.template_id "
            "WHERE p.playbook_id = %s", (playbook_id,))
        playbook = cur.fetchone()
        if not playbook:
            raise HTTPException(status_code=404,
                                detail=f"playbook '{playbook_id}' not found")
        playbook = dict(playbook)

        barrier = None
        if playbook.get("barrier_id"):
            cur.execute(
                "SELECT barrier_id, barrier_type, title, statement, brand, "
                "       geography_scope, signal_count, priority_score, "
                "       severity, confidence, lifecycle_status "
                "FROM barriers WHERE barrier_id = %s",
                (playbook["barrier_id"],))
            row = cur.fetchone()
            if row:
                barrier = dict(row)
                cur.execute(
                    "SELECT COUNT(*) AS n FROM barrier_signals "
                    "WHERE barrier_id = %s AND link_strength = 'core'",
                    (playbook["barrier_id"],))
                barrier["core_signal_count"] = (cur.fetchone() or {"n": 0})["n"]

        cur.execute(
            "SELECT queue_id, status, requested_at, decided_at, decision, "
            "       decider, notes "
            "FROM hil_queue WHERE playbook_id = %s "
            "ORDER BY queue_id DESC LIMIT 1", (playbook_id,))
        queue = cur.fetchone()
        queue = dict(queue) if queue else None

    return {"schema": _hub_schema(), "playbook": playbook,
            "barrier": barrier, "queue": queue}


# ── decision — shells the pack CLI, returns its verdict verbatim ─

class DecisionRequest(BaseModel):
    decision: Literal["approve", "reject"]
    decider: str
    notes: str | None = None


@router.post("/playbooks/{playbook_id}/decision")
def decide_playbook(playbook_id: str, req: DecisionRequest):
    """Approve/reject via ``iof-playbook review`` — the CLI owns the rules.

    The tool's fail-closed governance is passed through, not duplicated:
    reject-without-notes, unknown playbook, and double-decide all come back
    as 400s carrying the tool's own message verbatim.
    """
    if not _PLAYBOOK_ID_RE.match(playbook_id):
        raise HTTPException(status_code=400, detail="bad playbook id")
    decider = req.decider.strip()
    if not decider:
        raise HTTPException(status_code=400, detail="decider is required")

    cmd = [_playbook_bin(), "review", "--playbook-id", playbook_id,
           f"--{req.decision}", "--by", decider]
    notes = (req.notes or "").strip()
    if notes:
        cmd += ["--notes", notes]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8",
            errors="replace", env=_cli_env(), timeout=90)
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="iof-playbook review timed out")

    verdict = ((result.stdout or "") + (result.stderr or "")).strip()
    logger.info("iof-playbook review %s --%s by %s -> rc=%s: %s",
                playbook_id, req.decision, decider, result.returncode,
                verdict[:200])
    if result.returncode != 0:
        # the tool's rejection (missing notes, double-decide, unknown id) IS
        # the API error — verbatim, so the reviewer sees the governance rule
        raise HTTPException(
            status_code=400,
            detail=verdict or f"iof-playbook review failed "
                              f"(exit {result.returncode})")

    # decision landed — report the post-decision state from the hub
    with _hub() as cur:
        cur.execute("SELECT status, reviewed_by, reviewed_at, review_notes "
                    "FROM playbooks WHERE playbook_id = %s", (playbook_id,))
        p = cur.fetchone()
        cur.execute("SELECT status, decision, decider, decided_at "
                    "FROM hil_queue WHERE playbook_id = %s "
                    "ORDER BY queue_id DESC LIMIT 1", (playbook_id,))
        q = cur.fetchone()
    return {
        "ok": True,
        "playbook_id": playbook_id,
        "decision": req.decision,
        "verdict": verdict,
        "status": (p or {}).get("status"),
        "queue": dict(q) if q else None,
    }
