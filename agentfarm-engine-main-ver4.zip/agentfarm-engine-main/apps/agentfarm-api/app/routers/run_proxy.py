"""Run follow-up proxy — keeps the UI single-origin.

The conversation composer POSTs ``/api/run/{run_id}/message`` on the UI's
RUN_API_BASE_URL. Locally that is this API (8002), but the session-aware
follow-up endpoint lives on the ENGINE web API (``ioagentfarm serve``,
default 8111). Without this proxy every send 404s and the message silently
never reaches the run (root cause of the "composer fails" report,
2026-07-27: POST http://localhost:8002/api/run/<id>/message -> 404 while
the same body on 8111 -> 200 with a real reply).

Deliberately a thin passthrough: no auth logic, no body reshaping — the
engine endpoint owns session semantics. The engine base URL is resolved PER
WORKSPACE by ``app.engine_routing`` (IOF_ENGINE_URLS map, then
IOF_ENGINE_URL_TEMPLATE, then the single-engine IOF_RUN_API_URL, default
http://localhost:8111) so each tenant's messages reach that tenant's engine;
deployments whose ingress routes RUN_API_BASE_URL straight to the engine
simply never hit this route.
"""

from __future__ import annotations

import logging
import re

from fastapi import Depends, APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse

from app.engine_routing import (active_engine_base, rail_headers,
                                mark_engine_seen)
from app.workspace_context import maybe_active_code
from app.authz import require_member

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/run", tags=["run-proxy"],
    # GUARDED ON THE ROUTER. This router carried no authentication of
    # any kind: a validator reached it with no bearer token and got
    # 200. A per-route guard is one somebody has to remember on every
    # new route; a router-level one cannot be forgotten.
    dependencies=[Depends(require_member)],
)

_RUN_ID_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,80}$")

#: LLM-backed replies are slow; match the UI's 300s request budget.
_TIMEOUT_S = 300.0


def _engine_base() -> str:
    """The engine serving the request's tenant (workspace-routed)."""
    return active_engine_base()


@router.post("/{run_id}/message")
async def proxy_run_message(run_id: str, request: Request):
    """Forward a follow-up message to the engine's session-aware endpoint."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=400, detail="invalid run id")

    try:
        import httpx
    except ImportError:  # pragma: no cover - httpx ships with the venv
        raise HTTPException(status_code=503, detail="httpx not installed on the API host")

    body = await request.body()
    url = f"{_engine_base()}/api/run/{run_id}/message"
    headers = {"Content-Type": request.headers.get("content-type",
                                                   "application/json")}
    headers.update(rail_headers())
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT_S) as client:
            upstream = await client.post(url, content=body, headers=headers)
    except httpx.HTTPError as exc:
        logger.warning("run-message proxy to %s failed: %s", url, exc)
        raise HTTPException(
            status_code=502,
            detail="engine API for this workspace unreachable (set "
                   "IOF_ENGINE_URLS / IOF_ENGINE_URL_TEMPLATE / "
                   "IOF_RUN_API_URL)",
        )
    mark_engine_seen(maybe_active_code() or "")

    media_type = upstream.headers.get("content-type", "application/json")
    return JSONResponse(
        status_code=upstream.status_code,
        content=upstream.json() if "json" in media_type else {"detail": upstream.text},
    )


# ── starting and watching a run ──────────────────────────────────────────
#
# THE UI COULD NOT START A RUN. This proxy carried exactly one route -
# `/{run_id}/message` - so the Studio could list runs, read their timelines
# and message one that was already going, and had no way to begin one. The
# engine has offered `POST /api/run` throughout; nothing forwarded to it, so
# "re-run signal detection from the UI" was not a wiring fault, it was an
# absent route. A swarm could be launched (`/api/studio/swarms/{name}/run`)
# and a workflow could not, which is how the gap stayed invisible.
#
# Same passthrough discipline as the message route: no body reshaping, no
# opinion about goals or drivers. The engine owns what a run IS; this owns
# only that the browser talks to one origin.


@router.post("")
@router.post("/")
async def proxy_run_create(request: Request):
    """Start a run on the workspace's engine."""
    return await _forward(request, "/api/run", method="POST")


@router.post("/{run_id}/resume")
async def proxy_run_resume(run_id: str, request: Request):
    """Reap and re-spawn the driver of an interrupted run."""
    _check_run_id(run_id)
    return await _forward(request, f"/api/run/{run_id}/resume", method="POST")


@router.post("/{run_id}/cancel")
async def proxy_run_cancel(run_id: str, request: Request):
    _check_run_id(run_id)
    return await _forward(request, f"/api/run/{run_id}/cancel", method="POST")


@router.get("/{run_id}/status")
async def proxy_run_status(run_id: str, request: Request):
    _check_run_id(run_id)
    return await _forward(request, f"/api/run/{run_id}/status", method="GET")


@router.get("/{run_id}/stream")
async def proxy_run_stream(run_id: str, request: Request):
    """The run's live output, streamed.

    STREAMED, not buffered. `JSONResponse` on the other routes reads the whole
    upstream body before answering, which for SSE means the browser sees
    nothing until the run ENDS - the "streaming does not work" report, and a
    30-minute pipeline looks like a hang. This holds the upstream connection
    open and forwards each chunk as it arrives, and sets the two headers a
    proxy in front of it needs: `Cache-Control: no-cache` and
    `X-Accel-Buffering: no`, without which nginx buffers the stream back into
    exactly the behaviour this route exists to avoid.
    """
    _check_run_id(run_id)
    import httpx

    url = f"{_engine_base()}/api/run/{run_id}/stream"
    headers = rail_headers()

    async def body():
        try:
            async with httpx.AsyncClient(timeout=None) as client:
                async with client.stream("GET", url, headers=headers) as upstream:
                    if upstream.status_code >= 400:
                        text = (await upstream.aread()).decode("utf-8", "replace")
                        yield f"event: error\ndata: {text[:400]}\n\n".encode()
                        return
                    async for chunk in upstream.aiter_raw():
                        yield chunk
        except httpx.HTTPError as exc:
            logger.warning("run-stream proxy to %s failed: %s", url, exc)
            yield b"event: error\ndata: engine unreachable\n\n"

    mark_engine_seen(maybe_active_code() or "")
    return StreamingResponse(body(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    })


def _check_run_id(run_id: str) -> None:
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=400, detail="invalid run id")


async def _forward(request: Request, path: str, method: str = "POST"):
    """One passthrough for every non-streaming route above."""
    import httpx

    url = f"{_engine_base()}{path}"
    headers = {"Content-Type": request.headers.get("content-type",
                                                   "application/json")}
    headers.update(rail_headers())
    body = await request.body() if method == "POST" else None
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT_S) as client:
            upstream = await client.request(method, url, content=body,
                                            headers=headers)
    except httpx.HTTPError as exc:
        logger.warning("run proxy %s %s failed: %s", method, url, exc)
        raise HTTPException(
            status_code=502,
            detail="engine API for this workspace unreachable (set "
                   "IOF_ENGINE_URLS / IOF_ENGINE_URL_TEMPLATE / "
                   "IOF_RUN_API_URL)",
        )
    mark_engine_seen(maybe_active_code() or "")
    media_type = upstream.headers.get("content-type", "application/json")
    return JSONResponse(
        status_code=upstream.status_code,
        content=upstream.json() if "json" in media_type else {"detail": upstream.text},
    )
