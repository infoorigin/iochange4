"""``/api/studio/content-drafts`` — the draft lifecycle surface.

OWNS: listing, reading, diffing, rebasing, discarding and promoting-by-
instruction the ``content_drafts`` rows of the request's workspace. The
authorisation rule lives HERE and nowhere lower: any member may see WHO
holds a draft (metadata), but a draft's CONTENT — and every mutation — is
its author's alone unless the caller is a platform admin. Promotion is a
person's act on a developer desktop (One Truth s3.5): this surface hands
out the command and the repo, it never touches git.

MUST NOT import: ``app.draft_save`` (saving is the six studio endpoints'
seam, not this one's), ``ioagentfarm.engine.draft_files`` (disk), and
nothing here may resolve ``get_settings().iof_root`` — the diff's "current
base" side comes from ``app.drafts.current_base``, i.e. the engine rail.

Namespaced ``content-drafts`` because ``/api/studio/learning/drafts`` (the
learning steward console) and ``POST /api/studio/agents/draft`` (the
describe-then-refine drafter) already mean other things by "draft".
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Response

from app import drafts as app_drafts
from app import workspace_members
from app.authz import Identity, require_member
from ioagentfarm.engine import drafts as engine_drafts

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/content-drafts",
                   tags=["content-drafts"],
                   dependencies=[Depends(require_member)])


def _ws() -> str:
    from app.workspace_context import active_code
    return active_code()


def _is_admin(identity: Identity) -> bool:
    try:
        return workspace_members.is_platform_admin(identity.email)
    except Exception:
        return False


def _load(draft_id: int) -> dict:
    d = app_drafts.get(draft_id)
    # A draft of ANOTHER workspace answers 404, not 403: the id space is
    # global, and confirming existence across a tenant boundary is a leak.
    if d is None or d.get("workspace_code") != _ws():
        raise HTTPException(status_code=404,
                            detail=f"no content draft with id {draft_id}")
    return d


def _own_or_admin(draft: dict, identity: Identity) -> None:
    if draft["author"] == (identity.email or "").strip().lower():
        return
    if _is_admin(identity):
        return
    # 403, not 404: the drafts[] metadata already tells members the draft
    # exists — pretending otherwise here would just be confusing.
    raise HTTPException(
        status_code=403,
        detail="this draft belongs to another author — only its author "
               "(or a platform admin) may read its content or change it")


@router.get("")
def list_content_drafts(kind: str | None = None, name: str | None = None,
                        mine: bool = False,
                        identity: Identity = Depends(require_member)):
    """Open drafts of this workspace — metadata only; content via ``/{id}``."""
    if kind is not None and kind not in app_drafts.KINDS:
        raise HTTPException(status_code=400,
                            detail=f"kind must be one of {list(app_drafts.KINDS)}")
    author = identity.email if mine else None
    out = []
    for d in app_drafts.list_drafts(_ws(), author=author, kind=kind, name=name):
        m = app_drafts.meta(d)
        m.update({"kind": d["kind"], "name": d["name"],
                  "base_stamp": d.get("base_stamp") or "",
                  "mine": d["author"] == identity.email})
        out.append(m)
    return out


@router.get("/{draft_id}")
def get_content_draft(draft_id: int,
                      identity: Identity = Depends(require_member)):
    d = _load(draft_id)
    _own_or_admin(d, identity)
    return app_drafts.view(d, _ws())


@router.get("/{draft_id}/diff")
def diff_content_draft(draft_id: int,
                       identity: Identity = Depends(require_member)):
    """Per-file unified diffs draft ↔ CURRENT base; when the base moved since
    the pin, also old-base ↔ new-base plus the conflicting paths — the
    three-way view a rebase decision needs."""
    d = _load(draft_id)
    _own_or_admin(d, identity)
    base, stamp = app_drafts.current_base(d["kind"], d["name"], _ws())
    st = engine_drafts.staleness(d, stamp, base)
    files = d.get("files") or {}
    touched = engine_drafts.touched_paths(files)
    before = {p: base[p] for p in touched if p in base}
    after = {p: files[p] for p in touched if files[p] is not None}
    out = {
        "id": d["id"], "kind": d["kind"], "name": d["name"],
        "base_stamp": d.get("base_stamp") or "", "current_stamp": stamp,
        "stale": st["stale"], "promoted": st["promoted"],
        "conflicts": st["conflicts"],
        "files": engine_drafts.diff_files(before, after),
        "skills": engine_drafts.carried_skills(files),
    }
    if st["stale"]:
        pinned = d.get("base_files") or {}
        out["base_changes"] = engine_drafts.diff_files(
            {p: pinned[p] for p in touched if p in pinned},
            {p: base[p] for p in touched if p in base})
    return out


@router.post("/{draft_id}/rebase")
def rebase_content_draft(draft_id: int,
                         identity: Identity = Depends(require_member)):
    """Re-pin the draft to the CURRENT base — the author's explicit act after
    looking at the three-way diff; nothing rebases on their behalf."""
    d = _load(draft_id)
    _own_or_admin(d, identity)
    base, stamp = app_drafts.current_base(d["kind"], d["name"], _ws())
    touched = engine_drafts.touched_paths(d.get("files") or {})
    pin = {p: base[p] for p in touched if p in base}
    updated = app_drafts.rebase(d["id"], base_files=pin, base_stamp=stamp)
    if updated is None:  # pragma: no cover - the row was just read
        raise HTTPException(status_code=500, detail="rebase did not persist")
    return app_drafts.view(updated, _ws())


@router.delete("/{draft_id}")
def discard_content_draft(draft_id: int,
                          identity: Identity = Depends(require_member)):
    """Discard — a tombstone, not a DELETE, so the audit trail keeps it."""
    d = _load(draft_id)
    _own_or_admin(d, identity)
    app_drafts.set_status(d["id"], "discarded")
    return {"discarded": d["id"], "kind": d["kind"], "name": d["name"]}


@router.get("/{draft_id}/patch")
def content_draft_patch(draft_id: int,
                        identity: Identity = Depends(require_member)):
    """The draft as one ``text/x-patch`` unified-diff bundle — current base →
    draft, per touched path — for the developer who applies it by hand
    rather than via ``aicore drafts apply``."""
    d = _load(draft_id)
    _own_or_admin(d, identity)
    base, _stamp = app_drafts.current_base(d["kind"], d["name"], _ws())
    files = d.get("files") or {}
    chunks = []
    for path in engine_drafts.touched_paths(files):
        diff = engine_drafts.unified_diff(path, base.get(path), files[path])
        if diff:
            chunks.append(diff if diff.endswith("\n") else diff + "\n")
    text = "".join(chunks) or f"# draft {d['id']} matches the current base\n"
    return Response(
        content=text, media_type="text/x-patch",
        headers={"Content-Disposition":
                 f'attachment; filename="draft-{d["id"]}-{d["name"]}.patch"'})


@router.get("/{draft_id}/promote-instructions")
def promote_instructions(draft_id: int,
                         identity: Identity = Depends(require_member)):
    """What a developer runs on their desktop. The platform never commits or
    pushes (org policy: the engine has no git access) — it hands over the
    command, the attached repo and the branch, and steps back."""
    d = _load(draft_id)
    _own_or_admin(d, identity)
    repo, branch = None, None
    try:
        from app.database import get_db, q
        with get_db() as con:
            cur = con.cursor()
            cur.execute(q("SELECT repo_url, branch FROM studio_workspace_repos "
                          "WHERE workspace_code=?"), (_ws(),))
            row = cur.fetchone()
            if row:
                row = dict(row)
                repo = row.get("repo_url") or None
                branch = row.get("branch") or None
    except Exception:
        logger.debug("studio_workspace_repos unavailable", exc_info=True)
    return {
        "id": d["id"], "kind": d["kind"], "name": d["name"],
        "command": f"aicore drafts apply {d['id']}",
        "repo": repo, "branch": branch,
        "note": "Run this in a checkout of the workspace repo; review the "
                "diff, commit and open the PR yourself — the platform never "
                "touches git.",
    }
