"""Workflow catalog — read from the ENGINE, which runs the packs.

Definitions come from the engine's pack-resolved catalog
(``GET /api/catalog/workflows``, via ``app.workflow_catalog``), each stamped
with the distribution / version / commit that is running; the tenant's own
``studio_workflow_defs`` rows ADD only what no installed pack provides
(``unpromoted``). Run-metadata from the engine's ``iof.workflows`` registry
(id, display name, description) enriches an item when the engine has
registered the workflow.

Local YAML files are NEVER read here (this pod has none), and neither is a
database mirror of the packs. An unreachable engine is a 502 — never an
empty catalog.
"""

from __future__ import annotations

import json
import logging

from fastapi import Depends, APIRouter, HTTPException, Response

from app import workflow_defs
from app.agents import get_agent
from app.database import get_db, q
from app.workflow_defs import DEFAULT_WS
from app.authz import require_member

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/workflows", tags=["workflows"],
    # GUARDED ON THE ROUTER. This router carried no authentication of
    # any kind: a validator reached it with no bearer token and got
    # 200. A per-route guard is one somebody has to remember on every
    # new route; a router-level one cannot be forgotten.
    dependencies=[Depends(require_member)],
)


# ── iof.workflows run-metadata (engine-owned registry) ───────────

def _list_db_workflows(workspace_code: str) -> dict[str, dict]:
    """Run-metadata rows from iof.workflows (registered lazily by the engine).

    ``workflows.code`` is unique PER WORKSPACE (2026-08), so the enrichment
    map prefers the active workspace's row and falls back to the platform
    tier (the shared second tier of catalog reads — not a workspace).
    A pre-migration engine DB (no workspace_code column) degrades through
    the except to {} — display names then derive from the code, which is
    the same fresh-install behavior as ever.
    """
    ws = workspace_code
    try:
        with get_db() as con:
            cursor = con.cursor()
            cursor.execute(
                q("SELECT id, workspace_code, code, name, description, "
                  "steps_json, roles_json, created_at, updated_at "
                  "FROM workflows WHERE workspace_code IN (?, ?) "
                  "ORDER BY code ASC"),
                (ws, DEFAULT_WS),
            )
            out: dict[str, dict] = {}
            for r in cursor.fetchall():
                row = dict(r)
                prior = out.get(row["code"])
                # the active workspace's row wins over default's
                if prior is None or row["workspace_code"] == ws:
                    out[row["code"]] = row
            return out
    except Exception:
        # Table (or the workspace_code column) may not exist yet
        return {}


def _get_db_workflow(code: str, workspace_code: str) -> dict | None:
    """One iof.workflows row by code — the workspace first, then the
    platform tier."""
    ws = workspace_code
    try:
        with get_db() as con:
            cursor = con.cursor()
            cursor.execute(
                q("SELECT id, workspace_code, code, name, description, "
                  "steps_json, roles_json, created_at, updated_at "
                  "FROM workflows WHERE code=? AND workspace_code IN (?, ?)"),
                (code, ws, DEFAULT_WS),
            )
            rows = [dict(r) for r in cursor.fetchall()]
            for row in rows:
                if row["workspace_code"] == ws:
                    return row
            return rows[0] if rows else None
    except Exception:
        return None


# ── DB-only workflow map (shared with the workspaces router) ─────

def build_workflow_map(workspace_code: str | None = None) -> dict[str, dict]:
    """code -> workflow summary, read ONLY from the engine DB.

    Base set = the TENANT's studio_workflow_defs rows (composite key
    workspace_code+code — the workspace id IS the tenant id and the DB
    decides what each workspace shows). None -> the request's active
    workspace from the tenant middleware. iof.workflows contributes id /
    display name / description where the engine has registered the
    workflow. No disk access on this path.
    """
    if workspace_code is None:
        from app.workspace_context import active_code
        workspace_code = active_code()
    from app import workflow_catalog
    defs = workflow_catalog.list_workflows(workspace_code)
    db_meta = _list_db_workflows(workspace_code)
    result_map: dict[str, dict] = {}
    for row in defs:
        code = row["name"]
        data = workflow_defs.parse_yaml_tolerant(row["yaml"])
        steps = [s.get("key", "") for s in data.get("steps", [])]
        roles = workflow_defs.extract_roles(data)
        meta = db_meta.get(code)
        if meta and not steps:
            # malformed stored YAML — fall back to the engine's registered shape
            steps = json.loads(meta.get("steps_json") or "[]")
            roles = roles or json.loads(meta.get("roles_json") or "[]")
        # TODO: fix ensure_workflow to always include project_lead in team_json.
        # Alex orchestrates every workflow but isn't listed in roles.
        if "project_lead" not in roles:
            roles = ["project_lead"] + roles
        entry: dict = {
            "code": code,
            "name": (meta or {}).get("name") or code.replace("_", " ").title(),
            "description": (meta or {}).get("description")
                           or (data.get("description") or code),
            "steps": steps,
            "roles": roles,
            "team": [get_agent(r) for r in roles],
            "source": row["source"],
            # which solution of the workspace family owns this workflow
            # ('' = family-level / unattributed) — the engine's attribution.
            "solution": row.get("solution") or "",
            # PROVENANCE (One Truth s4.3): what the engine runs, stamped.
            "stamp": row.get("stamp"),
            "unpromoted": bool(row.get("unpromoted")),
        }
        if meta:
            entry["id"] = meta["id"]
        result_map[code] = entry
    return result_map


# ── Endpoints ────────────────────────────────────────────────────

@router.get("")
def list_workflows(response: Response):
    """List available workflows with team info — from the ENGINE catalog."""
    result = list(build_workflow_map().values())
    response.headers["X-Catalog-Source"] = "engine"
    if not result:
        response.headers["X-Workflow-Defs-Hint"] = workflow_defs.EMPTY_HINT
    return result


@router.get("/{code}")
def get_workflow(code: str):
    """Workflow detail with step graph and team roster — from the ENGINE
    catalog (a tenant row only when no installed pack provides the name)."""
    from app import workflow_catalog
    from app.workspace_context import active_code
    row = workflow_catalog.get_workflow(code, active_code())
    if not row:
        raise HTTPException(
            status_code=404,
            detail=f"Workflow '{code}' is not in the engine catalog for this "
                   f"workspace, and the workspace holds no definition of its "
                   f"own. {workflow_defs.EMPTY_HINT}")

    data = workflow_defs.parse_yaml_tolerant(row["yaml"])
    roles = workflow_defs.extract_roles(data)
    # TODO: fix ensure_workflow to always include project_lead in team_json
    if "project_lead" not in roles:
        roles = ["project_lead"] + roles

    step_details = []
    for s in data.get("steps", []):
        key = s.get("key", "")
        role = s.get("role", "")
        step_details.append({
            "key": key,
            "title": s.get("title", key),
            "role": role,
            "deps": s.get("deps", []) or [],
            "agent": get_agent(role),
        })

    meta = _get_db_workflow(code, active_code())
    out: dict = {
        "code": code,
        "name": (meta or {}).get("name") or code.replace("_", " ").title(),
        "description": (meta or {}).get("description")
                       or (data.get("description") or code),
        "steps": [s["key"] for s in step_details],
        "roles": roles,
        "step_details": step_details,
        "team": [get_agent(r) for r in roles],
        "source": row["source"],
        "solution": row.get("solution") or "",
        "stamp": row.get("stamp"),
        "unpromoted": bool(row.get("unpromoted")),
    }
    if meta:
        out["id"] = meta["id"]
    return out
