"""Admin module — users, workspaces and memberships.

The management surface for closed membership. Every route is behind
``require_platform_admin``: hiding the link in the UI is cosmetic, this is the
actual boundary.

Scope note: user *creation* here is for LOCAL (password) accounts. SSO users
provision themselves on first login via ``auth.py::_upsert_user_from_sso`` —
what an admin does for those is grant membership, not create the account.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

import bcrypt
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app import workspace_members
from app.auth_token import Identity
from app.authz import require_platform_admin
from app.database import get_db, placeholder, q
from app.user_tables import ensure_user_tables

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin", tags=["admin"],
                   dependencies=[Depends(require_platform_admin)])

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_ALLOWED_ROLES = {"member", "admin"}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def _commit(con) -> None:
    if placeholder() != "%s":
        con.commit()


# ── Models ────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    email: str
    password: str
    first_name: str = ""
    last_name: str = ""


class UserPatch(BaseModel):
    is_active: bool | None = None
    first_name: str | None = None
    last_name: str | None = None


class PasswordReset(BaseModel):
    password: str


class MembershipChange(BaseModel):
    workspace_code: str
    user_email: str
    role: str = "member"


# ── Users ─────────────────────────────────────────────────────────

@router.get("/users")
def list_users():
    """Every account, with its workspace memberships.

    `sso_id` distinguishes a directory account from a local one — an admin
    needs to know which users they can reset a password for.
    """
    with get_db() as con:
        ensure_user_tables(con)
        cur = con.cursor()
        cur.execute('SELECT id, sso_id, first_name, last_name, email, is_active,'
                    ' created_date FROM "user" ORDER BY lower(email)')
        users = [dict(r) for r in cur.fetchall()]

    for u in users:
        email = (u.get("email") or "").lower()
        u["is_local"] = not (u.get("sso_id") or "")
        u["memberships"] = workspace_members.workspaces_for(email)
        u["is_admin"] = workspace_members.is_platform_admin(email)
    return users


@router.post("/users", status_code=201)
def create_user(req: UserCreate):
    """Create a LOCAL (password) account. Bcrypt only — never plaintext."""
    email = req.email.strip().lower()
    if not _EMAIL_RE.match(email):
        raise HTTPException(status_code=400, detail="valid email required")
    if len(req.password or "") < 8:
        raise HTTPException(status_code=400,
                            detail="password must be at least 8 characters")

    hashed = bcrypt.hashpw(req.password.encode(), bcrypt.gensalt()).decode()
    with get_db() as con:
        ensure_user_tables(con)
        cur = con.cursor()
        cur.execute(q('SELECT id FROM "user" WHERE lower(email)=lower(?)'), (email,))
        if cur.fetchone():
            raise HTTPException(status_code=409, detail=f"user '{email}' exists")
        cur.execute(
            q('INSERT INTO "user"(sso_id, first_name, last_name, email, is_active,'
              " created_date) VALUES ('', ?, ?, ?, 1, ?)"),
            (req.first_name, req.last_name, email, _now()))
        _commit(con)
        cur.execute(q('SELECT id FROM "user" WHERE lower(email)=lower(?)'), (email,))
        row = cur.fetchone()
        uid = row["id"] if hasattr(row, "keys") else row[0]
        cur.execute(q("INSERT INTO user_password(user_id, password) VALUES (?, ?)"),
                    (uid, hashed))
        _commit(con)
    logger.info("admin created local user %s", email)
    return {"id": uid, "email": email, "is_active": True, "is_local": True}


@router.patch("/users/{email}")
def patch_user(email: str, req: UserPatch):
    """Activate/deactivate or rename. Deactivation is the revoke path — an
    inactive user is refused at login (`auth.py`), which is why there is no
    delete: removing the row would orphan their run history."""
    email = email.strip().lower()
    sets, params = [], []
    if req.is_active is not None:
        sets.append("is_active=?")
        params.append(1 if req.is_active else 0)
    if req.first_name is not None:
        sets.append("first_name=?")
        params.append(req.first_name)
    if req.last_name is not None:
        sets.append("last_name=?")
        params.append(req.last_name)
    if not sets:
        raise HTTPException(status_code=400, detail="nothing to update")

    with get_db() as con:
        cur = con.cursor()
        params.append(email)
        cur.execute(q(f'UPDATE "user" SET {", ".join(sets)} WHERE lower(email)=lower(?)'),
                    tuple(params))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail=f"user '{email}' not found")
        _commit(con)
    return {"email": email, "updated": True}


@router.post("/users/{email}/password")
def reset_password(email: str, req: PasswordReset):
    """Set a local account's password. No-op-safe for SSO users: they have no
    user_password row and authenticate through the directory."""
    email = email.strip().lower()
    if len(req.password or "") < 8:
        raise HTTPException(status_code=400,
                            detail="password must be at least 8 characters")
    hashed = bcrypt.hashpw(req.password.encode(), bcrypt.gensalt()).decode()
    with get_db() as con:
        cur = con.cursor()
        cur.execute(q('SELECT id FROM "user" WHERE lower(email)=lower(?)'), (email,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"user '{email}' not found")
        uid = row["id"] if hasattr(row, "keys") else row[0]
        upsert = (
            "INSERT INTO user_password(user_id, password) VALUES (?, ?) "
            "ON CONFLICT (user_id) DO UPDATE SET password = EXCLUDED.password"
            if placeholder() == "%s" else
            "INSERT OR REPLACE INTO user_password(user_id, password) VALUES (?, ?)"
        )
        cur.execute(q(upsert), (uid, hashed))
        _commit(con)
    logger.info("admin reset password for %s", email)
    return {"email": email, "password_set": True}


# ── Workspaces + memberships ──────────────────────────────────────

@router.get("/workspaces")
def list_all_workspaces():
    """Every workspace with its members — the admin's unfiltered view."""
    with get_db() as con:
        cur = con.cursor()
        cur.execute("SELECT id, code, name, description FROM workspaces"
                    " ORDER BY code")
        rows = [dict(r) for r in cur.fetchall()]
    for ws in rows:
        ws["members"] = workspace_members.list_members(ws["code"])
        ws["member_count"] = len(ws["members"])
    return rows


@router.post("/memberships", status_code=201)
def grant_membership(req: MembershipChange):
    if req.role not in _ALLOWED_ROLES:
        raise HTTPException(status_code=400,
                            detail=f"role must be one of {sorted(_ALLOWED_ROLES)}")
    if not _EMAIL_RE.match(req.user_email.strip().lower()):
        raise HTTPException(status_code=400, detail="valid email required")
    result = workspace_members.add_member(req.workspace_code, req.user_email, req.role)
    logger.info("admin granted %s -> %s (%s)",
                req.user_email, req.workspace_code, req.role)
    return result


@router.delete("/memberships")
def revoke_membership(workspace_code: str, user_email: str,
                      identity: Identity = Depends(require_platform_admin)):
    """Revoke a membership.

    Guard: an admin cannot remove their OWN admin grant — the lockout that
    leaves a deployment with no one able to administer it.
    """
    email = user_email.strip().lower()
    if email == identity.email and workspace_members.is_platform_admin(email):
        remaining = [m for m in _all_admin_rows() if m != (workspace_code, email)]
        if not remaining:
            raise HTTPException(
                status_code=400,
                detail="refusing to remove the last platform admin (yourself)")
    if not workspace_members.remove_member(workspace_code, email):
        raise HTTPException(status_code=404, detail="membership not found")
    return {"revoked": {"workspace_code": workspace_code, "user_email": email}}


def _all_admin_rows() -> list[tuple[str, str]]:
    with get_db() as con:
        workspace_members.ensure_table(con)
        cur = con.cursor()
        cur.execute(q("SELECT workspace_code, user_email FROM"
                      " studio_workspace_members WHERE role=?"),
                    (workspace_members.ADMIN_ROLE,))
        return [(r["workspace_code"], r["user_email"]) if hasattr(r, "keys")
                else (r[0], r[1]) for r in cur.fetchall()]


@router.get("/me")
def whoami(identity: Identity = Depends(require_platform_admin)):
    """Lets the UI decide whether to show the Admin entry at all."""
    return {"email": identity.email, "is_admin": True, "is_dev": identity.is_dev}
