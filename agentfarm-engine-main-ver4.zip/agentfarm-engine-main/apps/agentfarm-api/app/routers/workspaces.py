"""Workspace management — list, detail, workspace-scoped workflows and sessions.

Workspaces are the top-level grouping (team/group/dept):
  Workspace → Workflow(s) → Run(s)/Session(s).
"""

from __future__ import annotations

import json
import logging
import base64
import re
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Header, Response
from pydantic import BaseModel

from app.auth_token import Identity
from app.authz import (can_access, require_identity, require_member,
                       require_platform_admin)
from app.config import get_settings
from app.database import get_db, q
from app.routers.workflows import build_workflow_map
from app import workflow_defs, tenancy, workspace_members, workspace_settings

#: The members table has no CHECK constraint, so the API is the only place a
#: role is validated. 'admin' is platform-wide — see app/authz.py.
_ALLOWED_ROLES = {"member", "admin"}

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/workspaces", tags=["workspaces"])

#: One source with the engine: a code the Studio creates must satisfy the
#: same rule `aicore new-workspace` applies to it one command later.
from ioagentfarm.engine.workspaces import (  # noqa: E402
    WORKSPACE_CODE_RE as _CODE_RE, workspace_code_problem as _code_problem)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class WorkspaceCreate(BaseModel):
    code: str
    name: str = ""
    description: str = ""


class WorkspaceUpdate(BaseModel):
    name: str | None = None
    description: str | None = None


class MemberAdd(BaseModel):
    user_email: str
    role: str = "member"


# THE DISCLOSURE. `GET /active` returned 200 with the full `members[]` array -
# emails, roles, timestamps - for whatever workspace the caller named, with NO
# bearer token. Guarded per-route rather than on the router because listing
# workspaces is part of the login flow, before a member is known.
@router.get("/active")
def get_active_workspace(x_workspace_id: str | None = Header(None),
                         authorization: str | None = Header(None)):
    """The tenant workspace this request addresses (X-Workspace-Id header).

    Fail-closed — missing/unknown/retired refuses; see app/tenancy.py.

    THE ROSTER IS THE PART THAT NEEDED GUARDING, not the route. This returned
    the full `members[]` array - every email address, role and timestamp -
    for whatever workspace the caller named, with NO bearer token. A
    validator read it anonymously.

    Guarding the whole route was the first fix and it was wrong: resolution
    happens during login, before membership is established, and the
    query-param fallback serves headerless SSE streams. So the ROUTE still
    resolves and the ROSTER is now omitted for a caller who is not a member -
    a non-member learns the workspace exists, which they must, and nothing
    about who is in it.
    """
    ws = tenancy.resolve_workspace(x_workspace_id)
    ws["members"] = []
    try:
        identity = require_identity(authorization)
        if can_access(identity, ws["code"]):
            ws["members"] = workspace_members.list_members(ws["code"])
    except Exception:  # noqa: BLE001 - no credential is not an error here
        pass
    return ws


@router.post("", status_code=201)
def create_workspace(req: WorkspaceCreate,
                     identity: Identity = Depends(require_identity)):
    """Create a tenant workspace (the iof.workspaces registry row).

    TWO THINGS USED TO BE WRONG HERE, and they compounded.

    1. No dependency at all: an ANONYMOUS caller could create tenants — in the
       same module whose comment above ``get_members`` records fixing exactly
       that on the membership routes. Creation now needs a verified caller.
    2. The creator got no membership row. Under closed membership ("no row, no
       access") the sequence was: ``POST /api/workspaces`` -> ``201`` with the
       full row -> ``GET /api/workspaces`` -> ``[]``. A user created a
       workspace in the product and it was invisible to them, with nothing in
       either response hinting that a membership had to be granted by someone
       else. Seeding the creator makes the object they just made reachable.
    """
    code = req.code.strip().lower()
    problem = _code_problem(code, new=True)
    if problem:
        raise HTTPException(status_code=400,
                            detail=f"workspace code: {problem}")
    with get_db() as con:
        cur = con.cursor()
        cur.execute(q("SELECT id FROM workspaces WHERE code=?"), (code,))
        if cur.fetchone():
            raise HTTPException(status_code=409,
                                detail=f"workspace '{code}' already exists")
        now = _now()
        cur.execute(
            q("INSERT INTO workspaces (code, name, description, created_at, "
              "updated_at) VALUES (?, ?, ?, ?, ?)"),
            (code, req.name.strip() or code.replace("_", " ").title(),
             req.description.strip(), now, now),
        )
        try:
            con.commit()
        except Exception:
            pass
        from app.authz import ensure_workspace_seed_member
        ensure_workspace_seed_member(con, code, identity.email)
        cur.execute(q("SELECT id, code, name, description, created_at, "
                      "updated_at FROM workspaces WHERE code=?"), (code,))
        row = dict(cur.fetchone())
    tenancy.invalidate_cache()
    # Scope it to nothing. Without a settings row a workspace is UNSCOPED, so
    # a brand-new empty one opened showing every installed pack's agents —
    # another solution's content, in a workspace that had none of its own.
    # Import claims this empty row later; a curated one is never touched.
    workspace_settings.seed_empty_scope(code)
    row["members"] = workspace_members.list_members(code)
    # A brand-new workspace looks empty: say so, and say what fills the lists.
    # Otherwise the Studio shows empty tabs and reads as broken rather than new.
    row["next_step"] = (
        "This workspace is empty. It lists the agents, skills and workflows of "
        "whichever solutions are installed for it; anything you build here "
        "starts as your own draft.")
    return row


@router.delete("/{code}")
def delete_workspace(code: str, force: bool = False,
                     _admin: Identity = Depends(require_platform_admin)):
    """Remove a workspace and every row keyed to it. Platform admins only.

    There was no delete path anywhere — not here, not in the admin module, not
    in the CLI. A workspace created by mistake was permanent unless someone
    hand-wrote DELETEs across seven tables. Refuses a workspace holding runs
    unless ``?force=true``; see ``workspace_sync.delete_workspace``.
    """
    from ioagentfarm.workspace_sync import (
        RunHistoryRefused, delete_workspace_rows, remove_workspace_state,
        workspace_state_dir,
    )
    # Dialect via q(), NOT database.placeholder(): q() is the module-level
    # symbol the whole router already uses and the one the tests repoint at
    # their sqlite fixture. placeholder() re-reads IOF_DATABASE_URL from the
    # environment, which is a different database from the one get_db() yields
    # whenever a caller has substituted the connection.
    is_pg = q("?") == "%s"
    try:
        with get_db() as con:
            report = delete_workspace_rows(con, is_pg, code, force=force)
    except RunHistoryRefused as exc:
        # Same refusal, said in this front end's vocabulary. The core message
        # is written for the CLI ("re-run with --force (API: ?force=true)")
        # and was being shown verbatim in a browser dialog to a user who has
        # no terminal and did not type a command.
        raise HTTPException(
            status_code=409,
            detail=(f"This workspace has {exc.run_count} run"
                    f"{'s' if exc.run_count != 1 else ''} in its history. "
                    "Deleting it will delete them too. Files already written "
                    "to disk by those runs are kept."))
    except ValueError as exc:
        # 409: the request is well-formed, the state refuses it.
        status = 404 if "does not exist" in str(exc) else 409
        raise HTTPException(status_code=status, detail=str(exc))
    report["state_dir"] = str(workspace_state_dir(code))
    report["state_dir_removed"] = remove_workspace_state(code)
    tenancy.invalidate_cache()
    return report


@router.put("/{code}")
def update_workspace(code: str, req: WorkspaceUpdate,
                     identity: Identity = Depends(require_identity)):
    """Update workspace display name/description (code is immutable).

    Was unauthenticated: any anonymous caller could rename any tenant.
    """
    with get_db() as con:
        cur = con.cursor()
        cur.execute(q("SELECT id, name, description FROM workspaces "
                      "WHERE code=?"), (code,))
        row = cur.fetchone()
        # Existence before access: a code is operator-chosen, not a secret, and
        # answering 403 for a workspace that does not exist sends the caller
        # hunting for a permission problem that isn't there.
        if not row:
            raise HTTPException(status_code=404,
                                detail=f"workspace '{code}' not found")
        if get_settings().authz_enforce and not can_access(identity.email, code):
            raise HTTPException(
                status_code=403,
                detail=f"You do not have access to workspace '{code}'")
        current = dict(row)
        name = current["name"] if req.name is None else req.name.strip()
        description = (current["description"] if req.description is None
                       else req.description.strip())
        cur.execute(
            q("UPDATE workspaces SET name=?, description=?, updated_at=? "
              "WHERE code=?"),
            (name, description, _now(), code),
        )
        try:
            con.commit()
        except Exception:
            pass
    tenancy.invalidate_cache()
    return {"code": code, "name": name, "description": description}


# Membership changes are ADMIN-ONLY. These three were completely
# unauthenticated: any caller could POST themselves as role='admin' to any
# workspace — which, under the platform-admin rule, is total access.

@router.get("/{code}/members")
def get_members(code: str, _admin: Identity = Depends(require_platform_admin)):
    _get_workspace_or_404(code=code)
    return workspace_members.list_members(code)


@router.post("/{code}/members", status_code=201)
def post_member(code: str, req: MemberAdd,
                _admin: Identity = Depends(require_platform_admin)):
    _get_workspace_or_404(code=code)
    if "@" not in req.user_email:
        raise HTTPException(status_code=400, detail="user_email must be an email")
    if req.role not in _ALLOWED_ROLES:
        raise HTTPException(
            status_code=400,
            detail=f"role must be one of {sorted(_ALLOWED_ROLES)}")
    return workspace_members.add_member(code, req.user_email, req.role)


@router.delete("/{code}/members/{user_email}")
def delete_member(code: str, user_email: str,
                  _admin: Identity = Depends(require_platform_admin)):
    _get_workspace_or_404(code=code)
    if not workspace_members.remove_member(code, user_email):
        raise HTTPException(status_code=404, detail="member not found")
    return {"removed": user_email.strip().lower()}


@router.get("/{code}/repo")
def get_repo_state(code: str):
    """Read-only git-bridge state for the workspace settings page.

    The UI NEVER gets sync controls — push/pull are operator CLI actions
    (``ioagentfarm workspace push|export``). This endpoint only reports
    what the CLI last did. Returns ``{"attached": false}`` before Phase 2's
    table exists or when no repo has been attached.
    """
    _get_workspace_or_404(code=code)
    try:
        with get_db() as con:
            cur = con.cursor()
            cur.execute(q(
                "SELECT workspace_code, repo_url, branch, credential_ref, "
                "last_sha, last_imported_at, last_exported_at "
                "FROM studio_workspace_repos WHERE workspace_code=?"), (code,))
            row = cur.fetchone()
            if not row:
                return {"attached": False}
            d = dict(row)
            d["attached"] = True
            # credential_ref is an env-var NAME, never a secret value — safe.
            return d
    except Exception:
        return {"attached": False}


def _get_workspace_or_404(workspace_id: int | None = None, code: str | None = None) -> dict | list[dict]:
    """Fetch a workspace by id or code or raise 404. If both are None, return all workspaces."""
    with get_db() as con:
        cursor = con.cursor()
        
        if workspace_id is None and code is None:
            cursor.execute(
                "SELECT id, code, name, description, "
                "created_at, updated_at FROM workspaces ORDER BY name ASC"
            )
            return [dict(r) for r in cursor.fetchall()]
            
        elif workspace_id is not None:
            cursor.execute(
                q("SELECT id, code, name, description, "
                  "created_at, updated_at FROM workspaces WHERE id=?"),
                (workspace_id,),
            )
            row = cursor.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail=f"Workspace id={workspace_id} not found")
            return dict(row)
        else:
            cursor.execute(
                q("SELECT id, code, name, description, "
                  "created_at, updated_at FROM workspaces WHERE code=?"),
                (code,),
            )
            row = cursor.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail=f"Workspace code='{code}' not found")
            return dict(row)

@router.get("")
def get_workspace(workspace_id: int | None = None, code: str | None = None,
                  authorization: str | None = Header(None)):
    """Workspace detail, or the caller's workspaces when unfiltered.

    The LIST form is user-driven: a caller sees the workspaces they are a
    member of; a platform admin sees all. This is what makes the header
    switcher tenant-correct — the UI needs no logic of its own, it renders
    whatever this returns.

    The DETAIL forms (?workspace_id / ?code) are left unfiltered on purpose:
    they are 404-or-row lookups used to resolve a code the caller already
    holds, and `require_member` is what gates actually *using* a workspace.

    NO TOKEN IS A 401, NOT AN EMPTY LIST. It used to be the latter, on the
    reasoning that a missing token must never leak the tenant roster — which is
    right, and `[]` is not the only way to achieve it. The cost was paid by
    every caller: `[]` is also the honest answer for an authenticated user with
    no memberships, so the two states were indistinguishable, and a reader
    whose token had silently failed to be set read "you have no workspaces" and
    went looking for a broken import. Observed doing exactly that, twice, in
    one walkthrough. 401 leaks nothing the auth endpoint does not already
    reveal and separates the two questions.
    """
    ws_or_list = _get_workspace_or_404(workspace_id=workspace_id, code=code)

    if isinstance(ws_or_list, list):
        # Retired codes are not workspaces — a leftover 'default' row is the
        # platform tier's key, and offering it in the switcher would recreate
        # the exact ambiguity its retirement removed.
        from ioagentfarm.engine.workspaces import RETIRED_WORKSPACE_CODES
        workspaces = [w for w in ws_or_list
                      if w["code"] not in RETIRED_WORKSPACE_CODES]
        # Filter to the caller. An unverifiable caller is refused outright;
        # a verified one with no memberships still gets [], which is true.
        member_codes: set[str] = set()
        if get_settings().authz_enforce:
            from app.auth_token import identity_from_header
            from app.authz import visible_workspace_codes
            email = identity_from_header(authorization).email
            allowed = visible_workspace_codes(email)
            if allowed is not None:
                allowed_set = set(allowed)
                workspaces = [w for w in workspaces if w["code"] in allowed_set]
            # is_member marks the caller's OWN workspaces (an actual
            # membership row), distinct from platform-admin visibility of
            # everything. The UI prefers these at first login — the
            # walkthrough's fresh login landed in the first workspace
            # alphabetically, which was another tenant's.
            try:
                with get_db() as con:
                    cur2 = con.cursor()
                    cur2.execute(q("SELECT workspace_code FROM "
                                   "studio_workspace_members WHERE "
                                   "user_email = ?"), (email,))
                    member_codes = {r["workspace_code"]
                                    for r in cur2.fetchall()}
            except Exception:
                member_codes = set()
        for ws in workspaces:
            ws["is_member"] = ws["code"] in member_codes
            with get_db() as con:
                cursor = con.cursor()
                cursor.execute(
                    q("SELECT COUNT(*) AS cnt FROM runs WHERE workspace_id=?"),
                    (ws["id"],),
                )
                ws["run_count"] = int(cursor.fetchone()["cnt"])
                cursor.execute(
                    q("SELECT COUNT(DISTINCT workflow_name) AS cnt FROM runs WHERE workspace_id=?"),
                    (ws["id"],),
                )
                ws["workflow_count"] = int(cursor.fetchone()["cnt"])
        return workspaces

    # query-param detail keeps its historical 1-element-list shape (the UI's
    # list normalizer depends on it); the path-param form returns the dict.
    return [_workspace_detail(ws_or_list)]


@router.get("/{workspace_id}")
def get_workspace_by_path(workspace_id: int):
    """Workspace detail (dict) by numeric id — the path-param form."""
    ws = _get_workspace_or_404(workspace_id=workspace_id)
    return _workspace_detail(ws)


def _workspace_detail(ws: dict) -> dict:
    """Enrich a workspace row with its workflows + recent runs."""
    workspace_id = ws["id"]

    with get_db() as con:
        cursor = con.cursor()

        # Workflows used in this workspace (derived from runs)
        cursor.execute(
            q("SELECT DISTINCT workflow_name, workflow_id FROM runs "
              "WHERE workspace_id=? ORDER BY workflow_name ASC"),
            (workspace_id,),
        )
        wf_rows = cursor.fetchall()

        workflows = []
        for wr in wf_rows:
            wf_code = wr["workflow_name"]
            wf_id = wr["workflow_id"]
            wf_info = {"code": wf_code, "name": wf_code.replace("_", " ").title()}

            if wf_id:
                cursor.execute(
                    q("SELECT code, name, description FROM workflows WHERE id=?"),
                    (wf_id,),
                )
                wf_row = cursor.fetchone()
                if wf_row:
                    wf_info["name"] = wf_row["name"] or wf_code.replace("_", " ").title()
                    wf_info["description"] = wf_row["description"] or ""

            # Run counts for this workflow in this workspace
            cursor.execute(
                q("SELECT COUNT(*) AS total, "
                  "SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) AS running, "
                  "SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) AS done, "
                  "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed "
                  "FROM runs WHERE workspace_id=? AND workflow_name=?"),
                (workspace_id, wf_code),
            )
            counts = dict(cursor.fetchone())
            wf_info["runs"] = {
                "total": int(counts["total"] or 0),
                "running": int(counts["running"] or 0),
                "done": int(counts["done"] or 0),
                "failed": int(counts["failed"] or 0),
            }
            workflows.append(wf_info)

        # Recent runs across all workflows
        cursor.execute(
            q("SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, "
              "project_dir, status, created_at, updated_at "
              "FROM runs WHERE workspace_id=? ORDER BY created_at DESC LIMIT 20"),
            (workspace_id,),
        )
        recent_runs = [dict(r) for r in cursor.fetchall()]

    ws["workflows"] = workflows
    ws["recent_runs"] = recent_runs
    return ws


@router.get("/{workspace_id}/workflows")
def list_workspace_workflows(response: Response, workspace_id: int | None = None,
                             code: str | None = None):
    """All available workflows, enriched with run counts for this workspace.

    Same DB-only catalog as GET /api/workflows (studio_workflow_defs joined
    with iof.workflows run-metadata — no file discovery), plus per-workflow
    run stats scoped to this workspace.
    """
    ws = _get_workspace_or_404(workspace_id=workspace_id)
    if isinstance(ws, list):
        raise HTTPException(status_code=400, detail="Must provide workspace_id to list workspace-scoped workflows")

    workspace_id = ws["id"]

    # tenant scoping by the PATH workspace (more precise than the header)
    result_map = build_workflow_map(ws["code"])
    if not result_map:
        response.headers["X-Workflow-Defs-Hint"] = workflow_defs.EMPTY_HINT

    # Enrich each workflow with run counts scoped to this workspace
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT workflow_name, "
              "COUNT(*) AS total, "
              "SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) AS running, "
              "SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) AS done, "
              "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed "
              "FROM runs WHERE workspace_id=? GROUP BY workflow_name"),
            (workspace_id,),
        )
        run_counts = {r["workflow_name"]: dict(r) for r in cursor.fetchall()}

    for wf_code, wf in result_map.items():
        counts = run_counts.get(wf_code, {})
        wf["runs"] = {
            "total": int(counts.get("total") or 0),
            "running": int(counts.get("running") or 0),
            "done": int(counts.get("done") or 0),
            "failed": int(counts.get("failed") or 0),
        }

    workflows = list(result_map.values())
    if code:
        workflows = [wf for wf in workflows if wf.get("code") == code]
    return workflows


@router.get("/{workspace_id}/sessions")
def list_workspace_sessions(workspace_id: int, limit: int = 200, status: str | None = None):
    """All runs/sessions for a workspace, across all workflows."""
    _get_workspace_or_404(workspace_id)

    with get_db() as con:
        cursor = con.cursor()
        sql = ("SELECT id, workspace_id, workflow_name, workflow_id, goal, "
               "project_dir, status, created_at, updated_at "
               "FROM runs WHERE workspace_id=?")
        params: list = [workspace_id]
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        cursor.execute(q(sql), tuple(params))
        return [dict(r) for r in cursor.fetchall()]


@router.get("/{workspace_id}/sessions/user")
def list_workspace_user_sessions(
    workspace_id: int, 
    limit: int = 200, 
    status: str | None = None,
    authorization: str | None = Header(None)
):
    """All runs/sessions for a workspace, across all workflows, filtered by user."""
    _get_workspace_or_404(workspace_id)
    
    # VERIFIED identity. This block used to base64-decode the payload without
    # ever touching the signature or exp, so a forged or expired token worked
    # exactly like a real one.
    from app.auth_token import identity_from_header

    user_email = identity_from_header(authorization).email

    with get_db() as con:
        cursor = con.cursor()
        # Note: Adjust 'user_email' below if needed for your DB schema
        sql = ("SELECT id, workspace_id, workflow_name, workflow_id, goal, "
               "project_dir, status, created_at, updated_at "
               "FROM runs WHERE workspace_id=? AND user_id=?")
        params: list = [workspace_id, user_email]
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        cursor.execute(q(sql), tuple(params))
        return [dict(r) for r in cursor.fetchall()]
