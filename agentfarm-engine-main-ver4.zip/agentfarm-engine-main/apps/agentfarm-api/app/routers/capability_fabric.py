"""Capability fabric — tools, MCP tiers and swarms, proxied to the engine.

All three are engine truth this pod cannot see: tool PRESENCE is a PATH/exec
question against installed packs (this pod installs none), the effective MCP
view merges files under the engine's state dir, and swarms resolve from
installed packs plus the ``<IOF_ROOT>/swarms/`` override tree. Same rail as
agent memory, learning and the A2A console: forward, and answer 502 naming
the knob when the engine is absent.

Secrets discipline inherited from the engine endpoints: MCP summaries carry
command/url only (refs unexpanded, no env dict), so this layer cannot leak
what it never receives.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends

from app.authz import require_member
from app.engine_routing import engine_json

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio", tags=["capability-fabric"],
                   dependencies=[Depends(require_member)])


def _engine(method: str, path: str, *, json_body: dict | None = None) -> dict:
    return engine_json(
        method, path, json_body=json_body,
        purpose="tool presence, MCP tiers and swarms live on the engine "
                "host, not here")


@router.get("/tools")
def list_tools() -> dict:
    """Every declared CLI tool with live presence and its taught-by skills."""
    return _engine("GET", "/api/tools")


@router.get("/mcp/effective")
def mcp_effective() -> dict:
    """The merged cross-tier MCP view with provenance and resolvability."""
    return _engine("GET", "/api/mcp/effective")


@router.get("/swarms")
def list_swarms() -> dict:
    return _engine("GET", "/api/swarms")


@router.get("/swarms/{name}")
def swarm_detail(name: str) -> dict:
    return _engine("GET", f"/api/swarms/{name}")


@router.put("/swarms/{name}")
def swarm_save(name: str, req: dict) -> dict:
    """Save to the engine's override tree; lint comes back as advisory."""
    return _engine("PUT", f"/api/swarms/{name}", json_body=req)


@router.post("/swarms/{name}/run")
def swarm_run(name: str, req: dict) -> dict:
    """Spawn a swarm run through the engine's run-swarm machinery."""
    return _engine("POST", f"/api/swarms/{name}/run", json_body=req)
