"""Durable conversations with an always-on agent.

WHAT WAS MISSING. The engine already answers a turn — `POST /api/chat/<role>`
runs an in-process AgentLoop and returns `{content, envelope, id, error}` — and
it already logs its own progress to `messages`, tagged with whatever `user_id`
the caller supplies. What nothing kept was the THREAD: which turns belong
together, in what order, under whose name. The Studio's only chat until now was
`POST /api/studio/agents/{role}/chat`: one blocking turn, nothing persisted,
which is right for the builder's Test panel and not a conversation.

THE ENGINE IS UNCHANGED, deliberately. The obvious way to build this is the one
a sibling product took: fire the engine call without awaiting it, then poll
`messages` for a `stream_end` sentinel row to learn it finished. That needs the
engine to write a new `msg_type` — and BOTH of this API's SSE mappers
(`messages.py`, `agentfarm_sessions.py`) funnel any msg_type they do not
recognise into a `message` event, so a sentinel carrying empty content would
render as a blank chat bubble in the existing Sessions UI. A new row type is
not a backward-compatible change to a table three readers already interpret.

So completion here is the HTTP response itself. The engine's reply already
carries the answer, the parsed envelope and the error; awaiting it is both
simpler than a sentinel and impossible to get wrong when the agent dies mid-turn
(the request fails, rather than a sentinel never arriving and a poll loop
spinning forever, which is the failure mode of the design not taken).

SESSION CONTINUITY IS THE ENGINE'S, NOT OURS. Each conversation maps to one
engine `session_key`, so the agent keeps its own memory of the thread and we do
not re-send history as prompt text. Prepending recent turns to the content — the
other product's approach — competes with that memory and double-counts context.
We store turns to RENDER them; the engine stores them to REASON over them.
"""
from __future__ import annotations

import json
import logging
import re
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel
from sse_starlette.sse import EventSourceResponse

from app.auth_token import Identity
from app.authz import require_member

logger = logging.getLogger(__name__)

#: Router-level guard, matching `studio.py` rather than the routers that merely
#: share its path prefix. `/api/studio/learning` and `/api/studio/hil` are
#: separate router objects and inherit nothing from the studio router's
#: dependency — the guard travels with the ROUTER, not the URL. Declaring it
#: here is what makes a route added later impossible to leave unguarded.
router = APIRouter(prefix="/api/studio/conversations", tags=["conversations"],
                   dependencies=[Depends(require_member)])

#: Same shape the Studio uses for an agent role everywhere else.
ROLE_RE = re.compile(r"^[a-z][a-z0-9_-]{1,39}[a-z0-9]$")
_TITLE_CHARS = 60
_MAX_CONTENT = 32_000


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _ws() -> str:
    from app.workspace_context import active_code
    return active_code()


def _ensure(con) -> None:
    from app import workflow_defs
    workflow_defs.ensure_defs_once(con)


def _title_from(text: str) -> str:
    """First line, trimmed — a placeholder until the thread has a better name.

    Deliberately not the agent's answer: the question is what the author will
    recognise the thread by.
    """
    line = (text or "").strip().splitlines()[0] if (text or "").strip() else ""
    return line[:_TITLE_CHARS].strip()


# ── schemas ──────────────────────────────────────────────────────

class ConversationCreate(BaseModel):
    role: str
    title: str = ""


class ConversationRename(BaseModel):
    title: str


class MessageSend(BaseModel):
    content: str


# ── reads ────────────────────────────────────────────────────────

def _row_to_conversation(r: dict) -> dict:
    return {
        "id": r["id"], "role": r["role"], "title": r["title"],
        "created_at": r["created_at"], "updated_at": r["updated_at"],
    }


def _get_owned(con, conv_id: str, identity: Identity) -> dict:
    """The caller's conversation, or 404.

    Ownership is checked in the QUERY, not after it: a conversation that
    belongs to another member must be indistinguishable from one that does not
    exist, or the endpoint becomes an existence oracle for other people's
    threads.
    """
    from app.database import q
    cur = con.cursor()
    cur.execute(q("SELECT workspace_code, id, role, author, title, created_at,"
                  " updated_at FROM studio_conversations"
                  " WHERE workspace_code=? AND id=? AND author=?"),
                (_ws(), conv_id, identity.email))
    row = cur.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return dict(row)


@router.get("")
def list_conversations(limit: int = Query(default=50, ge=1, le=200),
                       offset: int = Query(default=0, ge=0),
                       identity: Identity = Depends(require_member)) -> dict:
    """The caller's conversations in this workspace, newest activity first."""
    from app.database import get_db, q
    with get_db() as con:
        _ensure(con)
        cur = con.cursor()
        cur.execute(q("SELECT id, role, title, created_at, updated_at"
                      " FROM studio_conversations"
                      " WHERE workspace_code=? AND author=?"
                      " ORDER BY updated_at DESC, id DESC"
                      " LIMIT ? OFFSET ?"),
                    (_ws(), identity.email, limit, offset))
        items = [_row_to_conversation(dict(r)) for r in cur.fetchall()]
        cur.execute(q("SELECT COUNT(*) AS n FROM studio_conversations"
                      " WHERE workspace_code=? AND author=?"),
                    (_ws(), identity.email))
        total = int(dict(cur.fetchone())["n"])
    return {"conversations": items, "total": total,
            "limit": limit, "offset": offset}


@router.post("")
def create_conversation(body: ConversationCreate,
                        identity: Identity = Depends(require_member)) -> dict:
    """Open a thread with one agent. The author is the verified caller."""
    role = (body.role or "").strip()
    if not ROLE_RE.match(role):
        raise HTTPException(status_code=400,
                            detail=f"'{role}' is not a valid agent role")
    from app.database import get_db, q
    conv_id = uuid.uuid4().hex
    now = _now()
    with get_db() as con:
        _ensure(con)
        con.cursor().execute(
            q("INSERT INTO studio_conversations (workspace_code, id, role,"
              " author, title, created_at, updated_at)"
              " VALUES (?, ?, ?, ?, ?, ?, ?)"),
            (_ws(), conv_id, role, identity.email,
             (body.title or "").strip()[:_TITLE_CHARS], now, now))
        _commit(con)
    return {"id": conv_id, "role": role, "title": (body.title or "").strip(),
            "created_at": now, "updated_at": now}


@router.get("/{conv_id}")
def get_conversation(conv_id: str,
                     identity: Identity = Depends(require_member)) -> dict:
    """One conversation and every turn in it, in `seq` order."""
    from app.database import get_db, q
    with get_db() as con:
        _ensure(con)
        rec = _get_owned(con, conv_id, identity)
        cur = con.cursor()
        cur.execute(q("SELECT seq, id, role, content, envelope_json, run_id,"
                      " error, thoughts, created_at"
                      " FROM studio_conversation_messages"
                      " WHERE workspace_code=? AND conversation_id=?"
                      " ORDER BY seq ASC"),
                    (_ws(), conv_id))
        messages = [_message_out(dict(r)) for r in cur.fetchall()]
    out = _row_to_conversation(rec)
    out["messages"] = messages
    return out


def _message_out(r: dict) -> dict:
    """A stored turn as the UI reads it.

    A malformed `envelope_json` degrades to None rather than failing the whole
    read: the envelope is a rendering enrichment, and one bad row must not make
    a conversation unreadable.
    """
    env = None
    raw = r.get("envelope_json") or ""
    if raw:
        try:
            env = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            logger.warning("conversation message %s has unparsable envelope",
                           r.get("id"))
    return {"seq": r["seq"], "id": r["id"], "role": r["role"],
            "content": r["content"], "envelope": env,
            "run_id": r.get("run_id") or None,
            "error": r.get("error") or None,
            "thoughts": r.get("thoughts") or None,
            "created_at": r["created_at"]}


@router.patch("/{conv_id}")
def rename_conversation(conv_id: str, body: ConversationRename,
                        identity: Identity = Depends(require_member)) -> dict:
    """Name a thread.

    The automatic name is the first question truncated to 60 characters, which
    is a placeholder: it is the right thing to show before anyone has said
    what the thread is FOR, and the wrong thing to be stuck with afterwards.

    An empty name is refused rather than stored. `_touch` fills a blank title
    from the next question, so accepting "" would not clear the name — it
    would arm a silent rename on the following turn, which is a different
    thing from what the caller asked for.
    """
    title = (body.title or "").strip()[:_TITLE_CHARS]
    if not title:
        raise HTTPException(status_code=400, detail="A conversation needs a name")
    from app.database import get_db, q
    with get_db() as con:
        _ensure(con)
        rec = _get_owned(con, conv_id, identity)
        # `updated_at` is NOT bumped. It orders the rail by when the thread was
        # last WORKED on, and renaming is housekeeping — moving a months-old
        # thread to the top of "Today" because its name was tidied would be a
        # lie about what happened.
        con.cursor().execute(
            q("UPDATE studio_conversations SET title=?"
              " WHERE workspace_code=? AND id=?"), (title, _ws(), conv_id))
        _commit(con)
    rec["title"] = title
    return _row_to_conversation(rec)


@router.delete("/{conv_id}")
def delete_conversation(conv_id: str,
                        identity: Identity = Depends(require_member)) -> dict:
    """Forget a thread. The engine's own session is left alone — it ages out on
    its own terms, and reaching into it from here would couple this table's
    lifecycle to the runtime's."""
    from app.database import get_db, q
    with get_db() as con:
        _ensure(con)
        _get_owned(con, conv_id, identity)
        cur = con.cursor()
        cur.execute(q("DELETE FROM studio_conversation_messages"
                      " WHERE workspace_code=? AND conversation_id=?"),
                    (_ws(), conv_id))
        cur.execute(q("DELETE FROM studio_conversations"
                      " WHERE workspace_code=? AND id=?"), (_ws(), conv_id))
        _commit(con)
    return {"deleted": conv_id}


def _commit(con) -> None:
    """Commit when the backend needs it (sqlite); a no-op on the pooled
    autocommit Postgres connection."""
    try:
        con.commit()
    except Exception:      # noqa: BLE001 - autocommit connections have none
        pass


# ── the turn ─────────────────────────────────────────────────────

def _session_key(conv_id: str, role: str) -> str:
    """The engine session this thread maps to.

    One key per (conversation, agent) so the agent's own memory IS the thread's
    history. Namespaced `studio:` so it cannot collide with the run-scoped and
    A2A session keys the engine also holds.
    """
    return f"studio:conv:{conv_id}:{role}"


def _next_seq(con, conv_id: str) -> int:
    from app.database import q
    cur = con.cursor()
    cur.execute(q("SELECT COALESCE(MAX(seq), 0) AS s"
                  " FROM studio_conversation_messages"
                  " WHERE workspace_code=? AND conversation_id=?"),
                (_ws(), conv_id))
    return int(dict(cur.fetchone())["s"]) + 1


def _insert_message(con, conv_id: str, seq: int, role: str, content: str,
                    envelope: dict | None = None, run_id: str = "",
                    error: str = "", thoughts: str = "") -> dict:
    from app.database import q
    msg_id = uuid.uuid4().hex
    now = _now()
    con.cursor().execute(
        q("INSERT INTO studio_conversation_messages (workspace_code,"
          " conversation_id, seq, id, role, content, envelope_json, run_id,"
          " error, thoughts, created_at)"
          " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"),
        (_ws(), conv_id, seq, msg_id, role, content,
         json.dumps(envelope) if envelope is not None else "",
         run_id or "", error or "", thoughts or "", now))
    return {"seq": seq, "id": msg_id, "role": role, "content": content,
            "envelope": envelope, "run_id": run_id or None,
            "error": error or None, "thoughts": thoughts or None,
            "created_at": now}


@router.post("/{conv_id}/messages")
def send_message(conv_id: str, body: MessageSend,
                 identity: Identity = Depends(require_member)) -> dict:
    """Ask the agent, store both turns, return them.

    Blocking by design in this first cut: the engine runs the agent loop
    non-streaming anyway (`IOF_DISABLE_STREAMING` is deliberate — streaming-on
    measured worse), so there is no token stream to surrender by waiting. What
    a client gains from a stream is PROGRESS, and that arrives separately from
    the engine's own `thought` rows; it is not a reason to make the answer
    itself asynchronous.
    """
    content = (body.content or "").strip()
    if not content:
        raise HTTPException(status_code=400, detail="content is required")
    if len(content) > _MAX_CONTENT:
        raise HTTPException(
            status_code=413,
            detail=f"content exceeds {_MAX_CONTENT} characters")

    from app.database import get_db
    ws = _ws()

    with get_db() as con:
        _ensure(con)
        rec = _get_owned(con, conv_id, identity)
        seq = _next_seq(con, conv_id)
        user_msg = _insert_message(con, conv_id, seq, "user", content)
        _commit(con)

    role = rec["role"]
    reply, envelope, run_id, err = _ask_engine(
        role=role, content=content, ws=ws,
        session_key=_session_key(conv_id, role), author=identity.email)

    with get_db() as con:
        assistant = _insert_message(con, conv_id, seq + 1, "assistant",
                                    reply, envelope, run_id, err)
        _touch(con, conv_id, title_seed=content)
        _commit(con)

    return {"conversation_id": conv_id, "messages": [user_msg, assistant]}


def _touch(con, conv_id: str, title_seed: str = "") -> None:
    """Bump `updated_at`, and name an untitled thread from its first question."""
    from app.database import q
    cur = con.cursor()
    cur.execute(q("UPDATE studio_conversations SET updated_at=?"
                  " WHERE workspace_code=? AND id=?"),
                (_now(), _ws(), conv_id))
    if title_seed:
        cur.execute(q("UPDATE studio_conversations SET title=?"
                      " WHERE workspace_code=? AND id=? AND title=''"),
                    (_title_from(title_seed), _ws(), conv_id))


def _ask_engine(*, role: str, content: str, ws: str, session_key: str,
                author: str) -> tuple[str, dict | None, str, str]:
    """One turn against the engine's always-on agent surface.

    Goes through `engine_routing.engine_json` rather than a bare httpx call so
    it inherits the tenant's engine URL, the kept HTTP client, and the
    `X-IOF-Deployment` handshake that stops a dev API answering from a prod
    engine.

    `user_id` is the correlation key the engine stamps on the `thought` rows it
    writes while working — the hook a progress stream reads later. It is set
    here even though nothing consumes it yet, because the turn is the only
    place that knows it.
    """
    from app.engine_routing import engine_json

    body = {
        "content": content,
        "agent": role,
        "sender_id": "studio",
        "user_id": f"studio:conv:{session_key}",
        "session_key": session_key,
        "workspace": ws,
        # A PERSON is reading this, in a client that renders the envelope. It
        # is what lets the engine give any agent whose own always-on skill
        # promises the v1 envelope the full treatment — parsed, window-measured,
        # rows checked, composed in two passes — instead of the three role names
        # that were hardcoded there. Every other caller of /api/chat is
        # unaffected, which is why the widening is scoped by this flag rather
        # than applied to the endpoint.
        "conversation": True,
        # NO `format` KEY, and that is the fix for a bug this code caused.
        #
        # `format: "json"` makes the engine append `_JSON_FORMAT_SUFFIX` — a
        # prompt instruction demanding `{answer, rows, queries, sources,
        # confidence, caveats}`. That is a DIFFERENT and poorer schema than
        # the v1 envelope `result_composer` mandates (it has no `data.type`,
        # no `insight`, no `viz_hint`), and being appended last it wins. The
        # symptom was an agent that "ignored its own always:true skill"; the
        # cause was this API telling it to.
        #
        # It bought nothing either: the engine extracts the envelope for
        # `queryngine`/`aria` REGARDLESS of `format`, because those roles
        # always emit v1. The flag exists for roles that have no composer —
        # and for those, prose the UI renders as markdown is a better answer
        # than a schema they were badgered into.
    }
    try:
        # 600s, not 300. The 300s ceiling predates two-phase composition,
        # which spends TWO generations per turn; a demand-attainment turn
        # measured 297.75s of engine time and the answer was produced and
        # then lost at this wire, recorded as "engine unreachable". 600
        # matches IOF_REQUEST_TIMEOUT_S's convention for slow model rounds.
        data = engine_json("POST", f"/api/chat/{role}", purpose=(
            "agent conversations run on the engine host, not here"),
            timeout=600.0, json_body=body, workspace_code=ws)
    except HTTPException as exc:
        # A failed turn is RECORDED, not lost: the user's question is already
        # stored, and a thread that silently drops its answer is worse than one
        # that shows what went wrong.
        detail = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
        return "", None, "", detail[:500]

    reply = (data.get("content") or "").strip()
    envelope = data.get("envelope") if isinstance(data.get("envelope"), dict) else None
    run_id = str(data.get("id") or "")
    err = str(data.get("error") or "")
    if not reply and not err:
        err = "the agent returned an empty reply"
    return reply, envelope, run_id, err


# ── progress: the agent's own reasoning, while it works ──────────
#
# The engine writes a `thought` row to `messages` for each step it takes,
# tagged with the `user_id` the caller supplied — the correlation key
# `_ask_engine` already sends. Nothing else is needed to watch a turn happen:
# no message bus, no fan-out, no second process. Reading those rows IS the
# stream.
#
# WHY THE SSE ENDPOINT RUNS THE TURN. The reference implementation spawns a
# background task on the request that starts the turn, then uses Redis pub/sub
# to get its events to whichever process later serves the SSE, plus a TTL'd
# replay list for the race where the turn finishes before the client connects.
# This API is synchronous and has no task machinery, and Redis between a task
# and a handler in the same process buys only cross-replica delivery — at the
# price of a pod dependency.
#
# Running the turn inside the stream removes that race instead of compensating
# for it, and makes the durable message table the replay buffer the TTL list
# was emulating: a client that reconnects finds the answer already stored.

#: How often the thought log is re-read. Below ~0.5s the reads cost more than
#: the latency they save; the agent emits a step every few seconds at best.
_POLL_S = 0.7

#: How far the poll backs off while the agent is producing nothing, and how
#: long it stays fast after a row arrives.
#:
#: A turn is minutes long and MOSTLY SILENT - the agent spends most of it
#: inside one model call or one query. Polling every 0.7s through that spends
#: a pooled connection and a remote round trip per stream per 0.7s to learn
#: nothing, and every open stream pays it: a reader who closed their tab
#: keeps paying until the turn ends, because the turn is deliberately not
#: cancelled with the reader. Measured: restarting the API - which is only a
#: way of dropping those loops - took first feedback on screen from 54-59s to
#: 23s with nothing else changed.
#:
#: Fast while rows are flowing, so live narration stays live; slow while
#: nothing is happening, which is when nobody is waiting on a row anyway.
_POLL_IDLE_S = 2.5
_POLL_FAST_FOR_S = 6.0
#: Silence after which a keep-alive goes out, so a proxy does not close an
#: idle stream while the agent is thinking.
_PING_S = 15.0


class StreamStart(BaseModel):
    content: str


@router.post("/{conv_id}/messages/stream")
def start_streamed_turn(conv_id: str, body: StreamStart,
                        identity: Identity = Depends(require_member)) -> dict:
    """Store the question and hand back the key to stream its answer.

    The question is persisted HERE, before the agent is asked, so a client that
    never manages to open the stream has still not lost what the user typed.

    The key is the user message's own id. There is no separate stream state to
    expire and no TTL to tune — reconnecting is just asking about that message
    again, and the answer either exists yet or does not.
    """
    content = (body.content or "").strip()
    if not content:
        raise HTTPException(status_code=400, detail="content is required")
    if len(content) > _MAX_CONTENT:
        raise HTTPException(status_code=413,
                            detail=f"content exceeds {_MAX_CONTENT} characters")
    from app.database import get_db
    with get_db() as con:
        _ensure(con)
        _get_owned(con, conv_id, identity)
        seq = _next_seq(con, conv_id)
        msg = _insert_message(con, conv_id, seq, "user", content)
        _commit(con)
    return {"conversation_id": conv_id, "stream_key": msg["id"],
            "seq": seq, "message": msg}


def _load_question(con, conv_id: str, msg_id: str) -> dict:
    from app.database import q
    cur = con.cursor()
    cur.execute(q("SELECT seq, id, role, content FROM"
                  " studio_conversation_messages WHERE workspace_code=?"
                  " AND conversation_id=? AND id=?"),
                (_ws(), conv_id, msg_id))
    row = cur.fetchone()
    if row is None or dict(row)["role"] != "user":
        raise HTTPException(status_code=404, detail="No such question")
    return dict(row)


def _answer_for(con, conv_id: str, seq: int) -> dict | None:
    """The assistant turn answering `seq`, when it has already been stored."""
    from app.database import q
    cur = con.cursor()
    cur.execute(q("SELECT seq, id, role, content, envelope_json, run_id, error,"
                  " thoughts, created_at FROM studio_conversation_messages"
                  " WHERE workspace_code=? AND conversation_id=? AND seq=?"
                  " AND role='assistant'"),
                (_ws(), conv_id, seq + 1))
    row = cur.fetchone()
    return _message_out(dict(row)) if row is not None else None


def _narration_since(user_id: str, last_id: int) -> list[dict]:
    """The narration rows a stream has not sent yet.

    A module-level function rather than an inline block because it runs in a
    worker thread: it must own its connection for the whole call and hand
    back plain dicts, not a cursor the event loop would then have to touch.

    `get_db` and `q` are imported HERE because this module imports them
    inside functions, not at module scope - the first version of this
    reader referenced them as globals, raised NameError on every poll, and
    the narration simply stopped arriving. Nothing surfaced it: the
    exception died in the worker thread and the stream kept pinging.
    """
    from app.database import get_db, q
    with get_db() as con:
        cur = con.cursor()
        cur.execute(
            q("SELECT id, content, msg_type FROM messages"
              " WHERE user_id=? AND id>?"
              " AND msg_type IN ('thought','preview')"
              " ORDER BY id ASC LIMIT 50"), (user_id, last_id))
        return [dict(r) for r in cur.fetchall()]


@router.get("/{conv_id}/messages/stream/{stream_key}")
async def stream_turn(conv_id: str, stream_key: str, request: Request,
                      identity: Identity = Depends(require_member)):
    """Run the turn, narrating the agent's reasoning as it happens.

    Events: ``start``, ``thought`` (a step the agent took), ``preview`` (the
    answer, early), ``ping`` (liveness), ``done`` (the stored assistant turn).

    A `thought` is PROGRESS, never the answer. The answer comes from the
    engine's HTTP response, which already carries the parsed envelope — so a
    thought row that is dropped, duplicated or arrives late cannot corrupt what
    gets stored.

    A `preview` is the exception that proves it: under two-phase composition
    the engine has the numbers one whole LLM round before it has the read, and
    writes them as `msg_type='preview'`. It is rendered EARLY and then replaced
    by `done`, so the same rule still holds — nothing durable is built from it,
    and a dropped preview costs a few seconds of anticipation, never an answer.

    Adding a msg_type is safe HERE and would not have been in general: the two
    other readers of `messages` select `WHERE run_id=?`, and a chat turn writes
    no run_id, so a preview row cannot surface as a stray bubble in the
    Sessions UI. Check that again before inventing a third type.
    """
    import asyncio
    import json as _json

    from app.database import get_db, q

    ws = _ws()
    with get_db() as con:
        _ensure(con)
        rec = _get_owned(con, conv_id, identity)
        question = _load_question(con, conv_id, stream_key)
        # ALREADY ANSWERED — a reconnect, or a client that opened the stream
        # after the turn finished. This is the race the reference design needs
        # a TTL'd Redis list for; here the answer is simply in the table
        # already, so it replays itself and the turn is not run twice.
        settled = _answer_for(con, conv_id, question["seq"])

    role = rec["role"]
    session_key = _session_key(conv_id, role)
    user_id = f"studio:conv:{session_key}"

    async def events():
        if settled is not None:
            yield {"event": "done", "data": _json.dumps(settled)}
            return

        # The high water mark is read BEFORE the agent starts. Without it an
        # earlier turn's thoughts — same agent, same correlation key — would
        # replay into this one's stream.
        with get_db() as con:
            cur = con.cursor()
            cur.execute(q("SELECT COALESCE(MAX(id), 0) AS m FROM messages"
                          " WHERE user_id=?"), (user_id,))
            last_id = int(dict(cur.fetchone())["m"])

        # The engine call is synchronous (httpx, psycopg2 underneath), so it
        # goes to a worker thread rather than blocking the event loop and with
        # it every other SSE stream this process is serving.
        turn = asyncio.create_task(asyncio.to_thread(
            _ask_engine, role=role, content=question["content"], ws=ws,
            session_key=session_key, author=identity.email))

        yield {"event": "start", "data": _json.dumps(
            {"conversation_id": conv_id, "seq": question["seq"],
             "role": role})}

        # Kept, not just forwarded. The reasoning is the only record of HOW an
        # answer was reached — which query it settled on, what it rejected —
        # and it was on screen for the minutes the user waited and then thrown
        # away the instant the answer arrived.
        narration: list[str] = []
        quiet = 0.0
        try:
            since_row = 1e9                # nothing has arrived yet
            while not turn.done():
                # Fast while the agent is producing, slow while it is not.
                interval = (_POLL_S if since_row < _POLL_FAST_FOR_S
                            else _POLL_IDLE_S)
                await asyncio.sleep(interval)
                quiet += interval
                since_row += interval
                # A disconnected client does NOT cancel the turn. The agent is
                # already working and its answer is worth storing either way —
                # the alternative is a question in the thread that can never be
                # answered because the reader closed a tab. The loop stops
                # narrating; the turn still lands.
                if await request.is_disconnected():
                    break
                # OFF THE EVENT LOOP. `get_db()` and psycopg2 are synchronous,
                # so reading here blocked the loop for a remote round trip -
                # roughly 0.25s to RDS - and every other stream this process
                # serves waited behind it. One slow read is then not one
                # stream's problem but everyone's.
                rows = await asyncio.to_thread(_narration_since, user_id,
                                               last_id)
                if rows:
                    since_row = 0.0
                for r in rows:
                    last_id = max(last_id, int(r["id"]))
                    text = r.get("content") or ""
                    # NOT stripped. A client concatenates these chunks to
                    # rebuild the paragraph the agent is writing, and the
                    # boundaries are exactly where the spaces live — stripping
                    # here would reintroduce "The useris asking" one layer
                    # further out. Emptiness is still tested on the stripped
                    # form, so a whitespace-only chunk is not an event.
                    if not text.strip():
                        continue
                    quiet = 0.0
                    if r.get("msg_type") == "preview":
                        # Deliberately NOT appended to `narration`: that becomes
                        # the durable `thoughts` field, and the answer is not a
                        # record of how the answer was reached.
                        yield {"event": "preview",
                               "data": _json.dumps({"text": text})}
                        continue
                    narration.append(text)
                    yield {"event": "thought",
                           "data": _json.dumps({"text": text})}
                if quiet >= _PING_S:
                    quiet = 0.0
                    yield {"event": "ping", "data": "{}"}

            reply, envelope, run_id, err = await turn
        except asyncio.CancelledError:
            raise
        except Exception as exc:            # noqa: BLE001 — recorded, not raised
            logger.exception("conversation turn failed")
            reply, envelope, run_id, err = "", None, "", str(exc)[:500]

        with get_db() as con:
            # Re-checked under the write: two streams opened on one question
            # must not both answer it.
            already = _answer_for(con, conv_id, question["seq"])
            if already is not None:
                stored = already
            else:
                stored = _insert_message(con, conv_id, question["seq"] + 1,
                                         "assistant", reply, envelope,
                                         run_id, err, "".join(narration))
                _touch(con, conv_id, title_seed=question["content"])
                _commit(con)

        yield {"event": "done", "data": _json.dumps(stored)}

    return EventSourceResponse(events())
