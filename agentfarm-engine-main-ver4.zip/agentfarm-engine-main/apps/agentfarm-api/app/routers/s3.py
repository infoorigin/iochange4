"""S3 file operations — list, upload, download, delete, move, presigned URLs.

Local-run fallback (2026-07-27): run artifacts for LOCAL executions never
reach S3 (and historically the UI/engine prefixes even disagreed), so the
artifact panel listed (0) despite `.iof/instances/<run>/project/` holding
real deliverables. `list` and `download` now transparently serve the local
filesystem for run-shaped prefixes/keys — S3 results win on key collisions,
local files fill the gaps. Read-only; path-traversal guarded.
"""

from __future__ import annotations

import io
import logging
import mimetypes
import os
import re
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError
from fastapi import Depends, APIRouter, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, StreamingResponse

from app.config import get_settings
from app.authz import require_member

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/s3", tags=["s3"],
    # GUARDED ON THE ROUTER. This router carried no authentication of
    # any kind: a validator reached it with no bearer token and got
    # 200. A per-route guard is one somebody has to remember on every
    # new route; a router-level one cannot be forgotten.
    dependencies=[Depends(require_member)],
)

#: Run-artifact key shapes the UI uses:
#:   <s3-prefix>/<run_id>/instances/project[/rel]  -> <IOF_ROOT>/instances/<run_id>/project
#:   <s3-prefix>/<run_id>/state/steps[/rel]        -> <IOF_ROOT>/runs/<run_id>/steps
_RUNS_KEY_RE = re.compile(
    r"(?:^|/)runs/(run_[A-Za-z0-9_]+)/(instances/project|state/steps)(?:/(.*))?$"
)
_LOCAL_LIST_CAP = 500


def _local_base_dir(run_id: str, kind: str) -> Path:
    root = get_settings().iof_root
    if kind == "instances/project":
        return Path(root) / "instances" / run_id / "project"
    return Path(root) / "runs" / run_id / "steps"


def _parse_runs_key(key_or_prefix: str) -> tuple[Path, str, str] | None:
    """(base_dir, rel_path, normalized_prefix_root) for run-shaped keys."""
    m = _RUNS_KEY_RE.search(key_or_prefix.replace("\\", "/"))
    if not m:
        return None
    run_id, kind, rel = m.group(1), m.group(2), m.group(3) or ""
    prefix_root = key_or_prefix.replace("\\", "/")
    if rel:
        prefix_root = prefix_root[: -(len(rel) + 1)]
    return _local_base_dir(run_id, kind), rel, prefix_root.rstrip("/")


def _list_local_files(prefix: str) -> list[dict]:
    parsed = _parse_runs_key(prefix)
    if not parsed:
        return []
    base, _rel, prefix_root = parsed
    if not base.is_dir():
        return []
    files: list[dict] = []
    for path in sorted(base.rglob("*")):
        if len(files) >= _LOCAL_LIST_CAP:
            logger.warning("local artifact listing capped at %d for %s", _LOCAL_LIST_CAP, prefix)
            break
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        rel = path.relative_to(base).as_posix()
        stat = path.stat()
        files.append({
            "key": f"{prefix_root}/{rel}",
            "size": stat.st_size,
            "last_modified": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
        })
    return files


def _resolve_local_file(key: str) -> Path | None:
    """Local file for a run-shaped key, or None. Rejects traversal."""
    parsed = _parse_runs_key(key)
    if not parsed:
        return None
    base, rel, _ = parsed
    if not rel:
        return None
    candidate = (base / rel).resolve()
    try:
        base_resolved = base.resolve()
    except OSError:
        return None
    if base_resolved not in candidate.parents and candidate != base_resolved:
        return None
    return candidate if candidate.is_file() else None


def _get_s3_client():
    """Build an S3 client using explicit credentials if available, else default profile/IAM."""
    settings = get_settings()
    if settings.aws_access_key_id and settings.aws_secret_access_key:
        return boto3.client(
            "s3",
            region_name=settings.aws_region,
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
        )
    return boto3.client("s3", region_name=settings.aws_region)


def _resolve_bucket(bucket: str | None) -> str:
    """Use the provided bucket or fall back to the configured default."""
    if bucket:
        return bucket
    settings = get_settings()
    if not settings.s3_bucket:
        raise HTTPException(status_code=400, detail="No bucket specified and IOF_S3_BUCKET is not configured")
    return settings.s3_bucket


@router.get("/list")
def list_files(
    prefix: str = "",
    bucket: Optional[str] = None,
    max_keys: int = 1000,
):
    """List files under a prefix — S3 merged with the local-run fallback."""
    # Prepend configured prefix if no explicit prefix given
    settings = get_settings()
    full_prefix = prefix
    if not full_prefix and settings.s3_prefix:
        full_prefix = settings.s3_prefix

    files: list[dict] = []
    resolved_bucket = ""
    try:
        resolved_bucket = _resolve_bucket(bucket)
        s3 = _get_s3_client()
        paginator = s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(
            Bucket=resolved_bucket,
            Prefix=full_prefix,
            PaginationConfig={"MaxItems": max_keys},
        )
        for page in pages:
            for obj in page.get("Contents", []):
                files.append({
                    "key": obj["Key"],
                    "size": obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                })
    except (ClientError, BotoCoreError, HTTPException) as e:
        # Run-shaped prefixes can still be served locally; anything else
        # keeps the original hard failure.
        if not _RUNS_KEY_RE.search(full_prefix.replace("\\", "/")):
            if isinstance(e, HTTPException):
                raise
            raise HTTPException(status_code=500, detail=f"S3 list failed: {e}")
        logger.debug("S3 unavailable for %s; serving local fallback (%s)", full_prefix, e)

    # Merge local run artifacts (S3 wins on identical keys).
    seen = {f["key"] for f in files}
    files.extend(f for f in _list_local_files(full_prefix) if f["key"] not in seen)

    return {
        "bucket": resolved_bucket or "local",
        "prefix": full_prefix,
        "count": len(files),
        "files": files,
    }


@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    key: str = Query(..., description="S3 object key (path)"),
    bucket: Optional[str] = None,
):
    """Upload a file to S3."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        contents = await file.read()
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=contents,
            ContentType=file.content_type or "application/octet-stream",
        )
        return {"bucket": bucket, "key": key, "size": len(contents), "message": "Uploaded successfully"}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 upload failed: {e}")


@router.delete("/delete")
def delete_file(
    key: str = Query(..., description="S3 object key to delete"),
    bucket: Optional[str] = None,
):
    """Delete a file from S3."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        s3.delete_object(Bucket=bucket, Key=key)
        return {"bucket": bucket, "key": key, "message": "Deleted successfully"}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 delete failed: {e}")


@router.delete("/delete-by-prefix")
def delete_by_prefix(
    prefix: str = Query(..., description="S3 prefix — all objects under this path will be deleted"),
    bucket: Optional[str] = None,
):
    """Delete all files under a given S3 path."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        paginator = s3.get_paginator("list_objects_v2")
        deleted = 0
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            objects = [{"Key": obj["Key"]} for obj in page.get("Contents", [])]
            if objects:
                s3.delete_objects(Bucket=bucket, Delete={"Objects": objects})
                deleted += len(objects)
        return {"bucket": bucket, "prefix": prefix, "deleted_count": deleted, "message": "Deleted successfully"}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 delete-by-prefix failed: {e}")


@router.get("/generate-url")
def generate_presigned_url(
    key: str = Query(..., description="S3 object key"),
    expiration: int = Query(3600, description="URL expiration in seconds"),
    bucket: Optional[str] = None,
):
    """Generate a presigned URL for an S3 object."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": key},
            ExpiresIn=expiration,
        )
        return {"bucket": bucket, "key": key, "expiration": expiration, "url": url}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 presigned URL failed: {e}")


@router.post("/move")
def move_file(
    source_key: str = Query(..., description="Source S3 object key"),
    destination_key: str = Query(..., description="Destination S3 object key"),
    bucket: Optional[str] = None,
):
    """Move (copy + delete) a file within S3."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        s3.copy_object(
            Bucket=bucket,
            CopySource={"Bucket": bucket, "Key": source_key},
            Key=destination_key,
        )
        s3.delete_object(Bucket=bucket, Key=source_key)
        return {
            "bucket": bucket,
            "source_key": source_key,
            "destination_key": destination_key,
            "message": "Moved successfully",
        }
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 move failed: {e}")


@router.get("/download")
def download_file(
    key: str = Query(..., description="S3 object key to download"),
    bucket: Optional[str] = None,
):
    """Download a file — local run artifacts first, then S3."""
    local = _resolve_local_file(key)
    if local is not None:
        media_type = mimetypes.guess_type(local.name)[0] or "application/octet-stream"
        return FileResponse(
            local,
            media_type=media_type,
            filename=local.name,
        )

    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        filename = key.rsplit("/", 1)[-1] if "/" in key else key
        content_type = response.get("ContentType", "application/octet-stream")

        return StreamingResponse(
            response["Body"],
            media_type=content_type,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except s3.exceptions.NoSuchKey:
        raise HTTPException(status_code=404, detail=f"Object '{key}' not found")
    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code == "NoSuchKey":
            raise HTTPException(status_code=404, detail=f"Object '{key}' not found")
        raise HTTPException(status_code=500, detail=f"S3 download failed: {e}")

def _iterate_s3_objects_stream(s3_client, bucket: str, prefix: str) -> Iterator[tuple[str, bytes]]:
    paginator = s3_client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            try:
                resp = s3_client.get_object(Bucket=bucket, Key=key)
                # read in chunks to avoid very large memory spikes
                body = resp["Body"].read()
                yield key, body
            except ClientError:
                logger.exception("Skipping object due to read error: %s", key)
                continue


# @router.get("/download-prefix-zip")
# def download_prefix_as_zip(
#     prefix: str = Query(..., description="S3 prefix — all objects under this path will be zipped"),
#     bucket: Optional[str] = None,
# ):
#     """Download all files under a given S3 prefix as a single ZIP file."""
#     bucket = _resolve_bucket(bucket)
#     s3 = _get_s3_client()

#     settings = get_settings()
#     full_prefix = prefix
#     if not full_prefix and settings.s3_prefix:
#         full_prefix = settings.s3_prefix

#     try:
#         # In-memory buffer for the zip
#         zip_buffer = io.BytesIO()

#         with zipfile.ZipFile(zip_buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
#             file_count = 0
#             for key, contents in _iterate_s3_objects_stream(s3, bucket, full_prefix):
#                 # Make archive name relative to the prefix if possible
#                 if full_prefix and key.startswith(full_prefix):
#                     arcname = key[len(full_prefix):].lstrip("/")
#                 else:
#                     arcname = key.rsplit("/", 1)[-1]
#                 if not arcname:
#                     arcname = key.replace("/", "_")
#                 zf.writestr(arcname, contents)
#                 file_count += 1

#         if file_count == 0:
#             raise HTTPException(status_code=404, detail=f"No objects found under prefix '{full_prefix}'")

#         zip_buffer.seek(0)
#         zip_name = f"{(full_prefix or 'archive').rstrip('/')}-{int(time.time())}.zip"

#         return StreamingResponse(
#             zip_buffer,
#             media_type="application/zip",
#             headers={"Content-Disposition": f'attachment; filename="{zip_name}"'},
#         )
#     except ClientError as e:
#         raise HTTPException(status_code=500, detail=f"S3 zip-download failed: {e}")
#     except Exception as e:
#         logger.exception("Error creating ZIP for prefix %s: %s", full_prefix, e)
#         raise HTTPException(status_code=500, detail=f"Failed to create ZIP: {e}")

@router.get("/list-level")
def list_files_at_level(
    prefix: str = "",
    bucket: Optional[str] = None,
    max_keys: int = 1000,
):
    """List S3 files and folders only at the specified prefix level."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    # Prepend configured prefix if no explicit prefix given
    settings = get_settings()
    full_prefix = prefix
    if not full_prefix and settings.s3_prefix:
        full_prefix = settings.s3_prefix

    # S3 requires the prefix to end with a slash to act like a directory list,
    # otherwise a prefix of "folder" will match "folder1.txt" and "folder2/".
    if full_prefix and not full_prefix.endswith('/'):
        full_prefix += '/'

    try:
        paginator = s3.get_paginator("list_objects_v2")
        # The Delimiter="/" is what stops the recursive listing and groups subdirectories
        pages = paginator.paginate(
            Bucket=bucket,
            Prefix=full_prefix,
            Delimiter="/",
            PaginationConfig={"MaxItems": max_keys},
        )
        
        folders = []
        files = []
        
        for page in pages:
            # 1. Process "Folders" (CommonPrefixes)
            for prefix_obj in page.get("CommonPrefixes", []):
                folder_path = prefix_obj["Prefix"]
                # Extract just the folder name without the trailing slash
                folder_name = folder_path.rstrip('/').split('/')[-1]
                
                folders.append({
                    "name": folder_name,
                    "path": folder_path,
                    "type": "folder"
                })

            # 2. Process "Files" (Contents)
            for obj in page.get("Contents", []):
                # S3 sometimes returns the folder itself as a 0-byte object. We skip it.
                if obj["Key"] == full_prefix:
                    continue
                    
                file_name = obj["Key"].split('/')[-1]
                
                files.append({
                    "name": file_name,
                    "key": obj["Key"],
                    "size": obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                    "type": "file"
                })

        return {
            "bucket": bucket,
            "current_prefix": full_prefix,
            "count": len(folders) + len(files),
            "folders": folders,
            "files": files
        }
        
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 list failed: {e}")

@router.post("/upload-files")
async def upload_and_extract_zip(
    file: UploadFile = File(...),
    prefix: str = Form("ioagentfarm/input_data/ui_catalog/"),
    bucket: Optional[str] = Form(None)
):
    """
    Accepts any file. 
    - If ZIP: extracts it in memory and uploads contents to a new folder.
    - If Normal File: uploads it directly to the specified prefix.
    """
    bucket_name = _resolve_bucket(bucket)
    s3 = _get_s3_client()
    
    # Ensure prefix ends with a slash
    if prefix and not prefix.endswith('/'):
        prefix += '/'

    is_zip = file.filename.lower().endswith('.zip')

    try:
        if is_zip:
            # ==========================================
            # ZIP FILE HANDLING
            # ==========================================
            folder_name = os.path.splitext(file.filename)[0]
            base_s3_path = f"{prefix}{folder_name}/"
            
            file_bytes = await file.read()
            zip_buffer = io.BytesIO(file_bytes)
            uploaded_files = []
            
            with zipfile.ZipFile(zip_buffer, "r") as zip_ref:
                for file_info in zip_ref.infolist():
                    # Skip directories
                    if file_info.is_dir():
                        continue
                        
                    with zip_ref.open(file_info) as extracted_file:
                        s3_key = f"{base_s3_path}{file_info.filename}"
                        
                        # Read into BytesIO so boto3 has a .seek() method
                        file_data = extracted_file.read()
                        upload_buffer = io.BytesIO(file_data)
                        
                        s3.upload_fileobj(upload_buffer, bucket_name, s3_key)
                        uploaded_files.append(s3_key)

            return {
                "message": f"Successfully extracted and uploaded {len(uploaded_files)} files.",
                "folder_path": base_s3_path,
                "extracted_files_count": len(uploaded_files),
                "type": "folder"
            }

        else:
            # ==========================================
            # NORMAL FILE HANDLING
            # ==========================================
            s3_key = f"{prefix}{file.filename}"
            
            file_bytes = await file.read()
            upload_buffer = io.BytesIO(file_bytes)
            
            # Pass along the content type if available
            extra_args = {}
            if file.content_type:
                extra_args["ContentType"] = file.content_type
                
            s3.upload_fileobj(upload_buffer, bucket_name, s3_key, ExtraArgs=extra_args)
            
            return {
                "message": f"Successfully uploaded {file.filename}.",
                "folder_path": s3_key, # Return the direct path for normal files
                "extracted_files_count": 1,
                "type": "file"
            }

    except zipfile.BadZipFile:
        raise HTTPException(status_code=400, detail="The provided file is not a valid ZIP archive.")
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 Upload failed: {e}")
    except Exception as e:
        logger.exception("Upload/Extraction failed")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")