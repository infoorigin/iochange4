"""Studio — GenAgents-inspired agent & workflow authoring + run telemetry.

Concepts translated from Genspark's GenAgents/GenTeam: no-code agent creation
with role/persona assignment, agents as first-class chat participants, and a
workflow studio over the engine's YAML contract.

THE RULE (2026-08). The API pod and the engine pod are separate Kubernetes
pods and are never co-located. This process has no agent home, no pack
installation and no engine state directory. What the Studio SHOWS as base
content — agents, skills, workflows — it READS FROM THE ENGINE's pack-resolved
catalog (``app/engine_catalog.py`` -> ``GET /api/catalog/*``; One Truth model,
``docs/one-truth-content-model.md`` s4.3), stamped with the distribution /
version / commit that is running; the tenant tables ADD only what no installed
pack provides (``unpromoted``). What it SAVES is a DRAFT (One Truth s3.5):
every save endpoint delegates to ``app/draft_save.py``, which writes one
``content_drafts`` row per (item, author) — base-pinned, resolved only in
that author's own Try-it sessions, promoted by a developer on their desktop
(``aicore drafts apply``). The tenant content tables are never written by a
Save any more; they remain a transitional READ tier (add-only) and the
migration reader. Anything that genuinely needs the packs or the engine's
disk is FORWARDED to the engine (``_engine_json``), never done here. An
unreachable engine is a 502 on every catalog read — never an empty list.

WHAT STILL TOUCHES A FILESYSTEM IN THIS MODULE, and why it is named rather
than hidden. Each is the SAME defect as the agent-home scan was, on a surface
this change did not cover:

  * ``_materialize_override`` writes ``<IOF_ROOT>/workflows/<code>``, and
    ``_dry_run`` shells out to the ``ioagentfarm`` CLI. Both are the workflow
    CREATE/SAVE path. On a split deployment ``_iof_bin()`` already raises a
    clear 500, so the failure is honest rather than silent — but the fix is an
    engine-side validate-and-materialise endpoint, not code here.
  * ``run_usage`` / ``run_sessions`` / ``run_session_messages`` read
    ``<IOF_ROOT>/instances/<run_id>/`` (usage.jsonl, forensic session
    snapshots). Those are ENGINE artifacts; on this pod the endpoints answer
    ``available: false`` and an empty list, which is wrong-but-quiet.
  * ``_role_pack_map``'s registry fallback imports ``ioagentfarm.packs``. It
    runs only while ``agents.pack`` is entirely blank (before the first sync),
    is exception-guarded, and answers empty on a pod — a deliberate bridge,
    not a source.
  * ``chat_with_agent`` shells out to ``ioagentfarm agent-chat``, which talks
    to the engine web API over HTTP. The subprocess is the awkward part, not
    the boundary.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

import yaml
from fastapi import APIRouter, Depends, HTTPException, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app import drafts as app_drafts
from app import draft_save
from app import persona_sections as personas
from app import skill_defs
from app import studio_display
from app import workflow_defs
from app.agents import get_agent
from app.authz import Identity, require_member
from app.config import get_settings
from ioagentfarm.engine import drafts as engine_drafts

logger = logging.getLogger(__name__)

# Every route is behind require_member — declared on the ROUTER, the same way
# admin.py declares its guard, so a new endpoint cannot be added unguarded.
# This surface creates, rewrites and deletes agents, skills and workflows and
# clears agent memory; until 2026-08 all of it answered with no token at all.
# require_member rather than require_identity because the objects are
# workspace-scoped — a valid token for another tenant is not authorisation
# here — and because it is the tier that honours the IOF_AUTHZ_ENFORCE
# rollback lever; require_identity ignores it, so the lever would go dead.
router = APIRouter(prefix="/api/studio", tags=["studio"],
                   dependencies=[Depends(require_member)])

# Must END on a letter or number too. The old pattern accepted a trailing
# underscore, which is exactly what the UI's silent normalisation produced
# from `Freight-Analyst!` — an id nobody typed and nobody noticed. Only
# checked when an agent is CREATED, so no existing role is invalidated.
ROLE_RE = re.compile(r"^[a-z][a-z0-9_]{1,39}[a-z0-9]$")
SKILL_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{2,40}$")
RUN_ID_RE = re.compile(r"^run_[0-9_]+$")


def slug_role(base: str) -> str:
    """A display name -> a valid internal id, or '' when nothing survives.

    ONE normaliser. There were three that disagreed — this module's draft
    path stripped trailing underscores, the agent-builder's did not (so
    `Freight-Analyst!` became `freight_analyst_`), and the workflow page had
    a third. Divergent normalisers are why an id nobody typed could be
    accepted: each end believed the other had checked it.
    """
    out = re.sub(r"[^a-z0-9]+", "_", (base or "").lower()).strip("_")[:41]
    if not out:
        return ""
    # Prefix whenever the base is not already a valid id — that covers a
    # leading digit AND a name too short to stand alone ("X" -> agent_x),
    # which is what the browser-side mirror does.
    if not ROLE_RE.match(out):
        out = f"agent_{out}"[:41]
    # Trim again AFTER the length slice: truncating can re-expose a trailing
    # "_", the exact shape ROLE_RE rejects.
    out = out.rstrip("_")
    return out if ROLE_RE.match(out) else ""


def _def_workspace(role: str) -> str:
    """Which workspace owns *role*'s definition row.

    The DB replacement for ``_agents_home(role)``, and the same rule: a
    PLATFORM-SHARED role is framework-owned and identical in every workspace,
    so the studio edits the one canonical definition (the platform tier)
    rather than forking it per tenant. Everything else belongs to the active
    tenant — resolved fail-closed; there is no fallback workspace.

    The function it replaced answered with a DIRECTORY, under
    ``Path.home()/".iobot"/"agents"`` — a path the engine has not written
    since the runtime state directory became ``~/.iobot``, on a pod that has no
    agent home at all.
    """
    from ioagentfarm.engine.workspaces import PLATFORM_TIER

    from app.workspace_context import active_code

    if role in get_settings().platform_shared_roles:
        return PLATFORM_TIER
    return active_code()


# ── Pack provenance + solution visibility filter ─────────────────
#
# The studio curates by SOLUTION: agents (and the skills only they carry)
# from excluded packs never appear, and included packs' agents appear even
# without a DB-registry row. The role→pack map comes from the engine's
# `aicore.packs` registry; the import is guarded so the API still works
# (registry+marker behavior only) if the engine or a pack fails to import.

#: How long a SUCCESSFUL role->pack read is reused. It was an hour, which made
#: adding an agent to an existing solution look broken: the new agent lands in
#: the catalog, `sync` attributes it to the right pack, and the Studio keeps
#: serving the map it read at startup — so the agent shows as "Platform" and a
#: workspace-scoped list drops it entirely, for up to an hour, with no error.
#:
#: The read is `SELECT role, pack FROM agents WHERE pack <> ''` — cheap. A
#: minute is plenty to spare the per-request cost, and it bounds the window in
#: which a freshly synced agent is invisible to something a person will wait
#: through rather than file a bug about. The engine's own `sync` runs in a
#: DIFFERENT PROCESS and cannot reach into this cache, so a short TTL is the
#: only thing that covers the CLI path; :func:`invalidate_pack_map` covers the
#: in-process one.
_PACK_MAP_TTL = 60
_pack_map_cache: dict = {"map": None, "at": 0.0}


def invalidate_pack_map() -> None:
    """Drop the role->pack cache. Called after an in-process agent sync so the
    new agent is attributed immediately rather than after the TTL."""
    _pack_map_cache["map"] = None
    _pack_map_cache["at"] = 0.0


def _role_pack_map_from_db() -> dict[str, str]:
    """role -> pack from ``iof.agents.pack``, written by POST /api/agents/sync.

    The preferred source: the sync runs in the ENGINE, where the solution
    packs are installed, so this API needs no packs of its own to answer
    "which solution does this agent belong to?" — which is what lets the
    studio API deploy independently of the solutions it serves.

    Returns {} when the column is absent (older schema) or every row is blank
    (sync has not run yet), so the caller falls back to the local registry.
    """
    from app.database import get_db, q
    try:
        with get_db() as con:
            cur = con.cursor()
            cur.execute(q("SELECT role, pack FROM agents WHERE pack <> ''"))
            # psycopg2 is configured with a dict row factory here, sqlite yields
            # tuples — handle both rather than assuming one.
            out: dict[str, str] = {}
            for row in cur.fetchall():
                if hasattr(row, "keys"):
                    out[row["role"]] = row["pack"]
                else:
                    out[row[0]] = row[1]
            return out
    except Exception as exc:
        logger.debug("agents.pack unavailable (%s); using pack registry", exc)
        return {}


def _role_pack_map() -> dict[str, str]:
    """role -> pack name for every pack-bundled agent ("core" = built-in).

    DB first (works with no solution packs installed), local pack registry as
    the fallback for a fresh deployment whose sync has not run yet.
    """
    now = time.time()
    if _pack_map_cache["map"] is not None \
            and now - _pack_map_cache["at"] < _PACK_MAP_TTL:
        return _pack_map_cache["map"]

    from_db = _role_pack_map_from_db()
    if from_db:
        _pack_map_cache["map"] = from_db
        _pack_map_cache["at"] = now
        return from_db

    mapping: dict[str, str] = {}
    try:
        from ioagentfarm.packs import load_registry
        for pack in load_registry().packs:
            root = pack.agents
            if root is None:
                continue
            pname = pack.name
            try:
                for entry in root.iterdir():
                    if entry.name.startswith("_"):
                        continue   # inject.yaml content dirs, not agents
                    try:
                        if (entry / "workspace" / "SOUL.md").is_file():
                            # first source wins — same order the engine resolves
                            mapping.setdefault(entry.name, pname)
                    except OSError:
                        continue
            except OSError:
                continue
    except Exception as e:
        logger.warning("pack registry unavailable for studio filtering "
                       "(falling back to registry+marker curation): %s", e)
    # Deliberately NOT cached. This fallback only bridges the window before
    # the engine's POST /api/agents/sync first writes agents.pack — and in a
    # split deployment (API venv has no solution packs) it is packs-blind.
    # Caching it for the full TTL froze that blind view for an hour: every
    # solution agent vanished from workspace catalogs until restart. Rebuild
    # it per call (cheap: local dir stats) so the map converges on the DB
    # within one request of sync completing.
    return mapping


#: pack name -> the label the UI shows on agent rows. Keys are workspace
#: FAMILY codes (Pack.name — one per team, shared by every distribution of a
#: workspace repo: pharma_common, barrier_signal and signal_brief all say
#: "barrier_insights"), NOT per-solution codes. Per-solution attribution
#: exists only for WORKFLOWS (studio_workflow_defs.solution); agents are
#: family-level by design, so a family label is the most specific true thing
#: an agent row can say. Missing keys fall back to title-cased code.
_PACK_SOLUTION_LABELS = {
    "core": "Platform",
    "skills": "Platform",
    "studio": "Studio-built",
    "ainf": "AINF",
    "barrier_insights": "Barrier Insights",
    "ai_workspace": "AI Workspace",
    "procurement": "Procurement",
}


def _solution_label(role: str, custom: bool, pack_map: dict[str, str]) -> str:
    if custom:
        return "Studio-built"
    pack = pack_map.get(role, "")
    return _PACK_SOLUTION_LABELS.get(pack, pack.replace("_", " ").title() or "Platform")


def _role_visible(role: str, rec, registry: dict,
                  pack_map: dict[str, str]) -> bool:
    """Tenant-scoped visibility — what this workspace shows.

    THE DEPLOYMENT DECIDES, NOT THE DB. One engine serves one workspace and
    resolves only that workspace's installed packs, so the engine's catalog is
    already the scope. Anything the engine served is shown; ``include_packs``
    is honoured when set but is no longer required to see your own agents.

    Default workspace (and any workspace WITHOUT a studio_workspace_settings
    row): the historical formula, byte-identical —
        (DB registry ∪ .studio-created ∪ env include-packs) − env exclude-packs.

    A workspace WITH a settings row:
        the platform-shared tier (settings.platform_shared_roles — Jarvis,
        Quinn, Alex) ∪ everything the engine served ∪ agents of the row's
        include_packs, − the row's exclude_packs.
    Studio-created agents stay in the default workspace's catalog only.
    Shared content appears in EVERY workspace by locked design decision.

    The shared tier is an explicit role list, NOT "every core-pack agent":
    core also bundles the generic workflow roles (analyst, developer,
    reviewer, strategist, …) which belong to core's own workflows, not to
    every tenant's catalog.
    """
    from app.workspace_context import active_code
    from app import workspace_settings
    pack = pack_map.get(role)

    # active_code() is fail-closed now, so this is always a real tenant;
    # packs_for returns None for a tenant with no scoping row (unscoped).
    code = active_code()
    scoped = workspace_settings.packs_for(code)
    if scoped is not None:
        if pack and pack in scoped["exclude"]:
            return False
        if pack == "core":
            # Shared platform tier — an explicit role list. Do NOT curate this
            # by "has a row in iof.agents": that table is now COMPLETE by
            # design (POST /api/agents/sync writes every installed agent so
            # pack provenance resolves), so membership there says nothing
            # about whether an agent is platform-shared.
            return role in get_settings().platform_shared_roles
        if pack and pack in scoped["include"]:
            return True
        if scoped["include"]:
            # A NON-EMPTY include list is the operator having said, in so many
            # words, which solutions this workspace is. A pack not on it is out
            # of scope — engine-served or not — and the widening below does not
            # get to overrule that.
            #
            # The widening's premise is that the engine's catalog IS the scope,
            # because one engine serves one workspace and resolves only that
            # workspace's installed packs. That holds for a per-workspace pod
            # and fails wherever one venv carries several solution packs, which
            # is every developer machine and this deployment: the engine
            # answers /api/catalog/agents?workspace=barrier_insights with all
            # 22 agents from nine packs, ignoring the parameter. So
            # `barrier_insights` — include_packs='barrier_insights' — listed
            # `ainf-meta-agent` (Pharma Intel) and four other AINF agents.
            #
            # Only a tenant's OWN Studio-built agent still passes here: it has
            # no pack to be in scope BY, and it belongs to whoever built it.
            return bool(rec["custom"]) and bool(rec["owned_here"])
        # THE ENGINE THAT ANSWERED IS THIS WORKSPACE'S ENGINE, so a pack agent
        # it served is in scope by construction — for an EMPTY include row,
        # which is a workspace nothing has ever scoped. One engine serves one
        # workspace and resolves only that workspace's installed packs, which
        # makes its catalog the scope — re-deciding it from an include list
        # nobody filled in asks a question the deployment has already
        # answered, and answers it "nothing".
        #
        # This is not a widening for its own sake; without it the Studio shows
        # a solution team NONE of their own agents. `include_packs` had exactly
        # one writer, `_scope_workspace_to_solution`, reachable only from
        # `push_workspace` — and `aicore workspace push` became a no-op under
        # the One Truth content model. `seed_empty_scope` still writes the
        # EMPTY row on create, so every workspace made since then is scoped to
        # "no solution packs" permanently, with nothing able to fill it.
        # Observed on a two-engine stack: the engine served 8 agents for
        # `barrier_insights` and the Studio listed 5, silently dropping
        # pharma_data_analyst, pharma_domain_analyst and pharma_reviewer.
        #
        # `exclude_packs` still wins (checked above): an operator hiding a pack
        # is an explicit choice, and nothing here overrides it.
        if rec["source"] == "engine" and pack:
            return True
        # A Studio-built agent whose DEFINITION ROW belongs to this tenant
        # belongs to this tenant. This used to ask whether its directory sat
        # under the tenant's own agent home — same question, asked of the
        # thing that actually travels between pods.
        if rec["custom"]:
            return rec["owned_here"]
        return False

    s = get_settings()
    if pack and pack in s.studio_exclude_packs:
        return False
    if rec["custom"]:
        return True
    if pack and pack in s.studio_include_packs:
        return True
    if not registry:
        return True   # empty registry = curation off (all remaining workspaces list)
    return role in registry


def _visible_agents() -> dict:
    """``role -> AgentRecord`` for everything this workspace shows.

    THE READ THAT WAS A DIRECTORY SCAN. It asked ``~/.iobot/agents`` — a
    filesystem the API pod does not have and a path the engine stopped writing
    at the ``~/.iobot`` rename — and because materialize-on-use is pull-based
    and PER ITEM, a tenant rebuilt from the database showed nothing at all: the
    rows were present the whole time and a list never asks for a named role.
    """
    from app import agent_catalog
    from app.agents import _load_all
    from app.workspace_context import active_code
    try:
        registry = _load_all() or {}
    except Exception:
        registry = {}
    pack_map = _role_pack_map()
    index = agent_catalog.agent_index(active_code(),
                                      get_settings().platform_shared_roles)
    return {role: rec for role, rec in index.items()
            if _role_visible(role, rec, registry, pack_map)}


def _visible_roles() -> list[str]:
    return sorted(_visible_agents())


# ── Skill categories (user-intuitive browsing groups) ────────────

#: stable key -> UI label. A skill's category comes from its `category:`
#: frontmatter when present, else this server-side default map, else the
#: fallback. Vocabulary is deliberately small — "what does this skill DO".
SKILL_CATEGORIES = {
    "data-analysis": "Data & Analysis",
    "domain-knowledge": "Domain Knowledge",
    "reasoning-method": "Reasoning & Method",
    "output-reporting": "Output & Reporting",
    "system": "System",
}
DEFAULT_SKILL_CATEGORY = "domain-knowledge"

_SKILL_CATEGORY_MAP = {
    # Data & Analysis — querying, aggregating, preparing data
    "data_query": "data-analysis",
    "vectorfs_query": "data-analysis",
    "api_query": "data-analysis",
    "data_preparation": "data-analysis",
    "signal_clustering": "data-analysis",
    "signal_snapshot": "data-analysis",
    "priority_scoring": "data-analysis",
    # Domain Knowledge — what the business domain means
    "administrative_barriers": "domain-knowledge",
    "clinical_barriers": "domain-knowledge",
    "competitive_barriers": "domain-knowledge",
    "market_barriers": "domain-knowledge",
    "operational_barriers": "domain-knowledge",
    "patient_access_barriers": "domain-knowledge",
    "patient_identification_barriers": "domain-knowledge",
    "product_barriers": "domain-knowledge",
    "barrier_taxonomy": "domain-knowledge",
    "signal_taxonomy": "domain-knowledge",
    "cloud_finops": "domain-knowledge",
    "account_playbook": "domain-knowledge",
    "transformation_planning": "domain-knowledge",
    "transformation_roadmap": "domain-knowledge",
    # Reasoning & Method — how to think and verify
    "grounded_analysis": "reasoning-method",
    "guardrails": "reasoning-method",
    "plan_and_checkpoint": "reasoning-method",
    "discovery_review": "reasoning-method",
    "pharma_federation": "reasoning-method",
    "generate_workflow_test_cases": "reasoning-method",
    # Output & Reporting — composing deliverables
    "presentation": "output-reporting",
    "dataviz": "output-reporting",
    "report_standards": "output-reporting",
    "result_composer": "output-reporting",
    "synthesis": "output-reporting",
    "insight_generation": "output-reporting",
    "signal_brief": "output-reporting",
    # System — platform plumbing (tucked away last in the UI)
    "output_protocol": "system",
    "catalog_reader": "system",
    "orchestrate": "system",
    "run_context": "system",
    "run_diagnostics": "system",
    "run_forensics": "system",
    "status_reports": "system",
    "messaging": "system",
    "dynamic_tasks": "system",
    "ask_subagent": "system",
    "ai_assistant": "system",
}


def _skill_category(name: str, meta: dict) -> str:
    cat = str(meta.get("category") or "").strip().lower()
    if cat in SKILL_CATEGORIES:
        return cat
    return _SKILL_CATEGORY_MAP.get(name, DEFAULT_SKILL_CATEGORY)


# ── Persisting a studio save ─────────────────────────────────────
#
# There is no file mirror any more. It copied the agent's workspace into
# <IOF_ROOT>/studio/agents so `ioagentfarm.studio_pack` could offer it as a
# template source — which requires the writer and the engine to share a disk,
# and they do not: separate pods, separate state directories. The DB row is
# the supply. `ensure_agent_workspace` already handles a role with no template
# at all (hydrate, then return when SOUL.md is present), which is exactly the
# studio-created case, so nothing needed the copy except the assumption that
# the two processes were the same machine.

def _save_agent(role: str, files: dict[str, str], skills: list[str]) -> None:
    """Write one agent's definition and its skill assignment. DB only.

    NO SAVE ENDPOINT CALLS THIS ANY MORE — a Studio Save is a draft
    (``app/draft_save.py``). It stays for the transitional add-only read
    tier and for ``aicore drafts migrate``'s reader; scheduled for removal
    one release after the migration ships.

    The agent row holds IDENTITY FILES ONLY, so carriage has to be recorded
    alongside it or the first run deletes it: hydration rmtrees the workspace
    and replays the DB, and a skill with no row is simply not in the replay.
    Two records, one per tier, both written BEFORE the snapshot so the
    snapshot carries the marker as it stands AFTER this save:

    * ``sync_carried_skill_names`` — reconciles ``studio_skills.roles_json``,
      additions and removals, for every tier (a pack skill gets an
      assignment-only row; its content stays in the wheel).
    * the ``.skills-assigned.json`` marker, composed here rather than derived
      by ``record_skill_assignment`` — that function reads a directory, and
      there is no directory. It rides in ``files`` because it is one of
      ``agent_defs._IDENTITY_FILES``; without it a pod rebuilding from the
      database re-derives the agent from the removed ``roles:`` rule and hands
      back skills the user deleted.
    """
    from app import agent_catalog

    code = _def_workspace(role)
    pack_names = _pack_skill_names()
    files = dict(files)
    # The marker names the skills whose CONTENT is not in this agent's row —
    # the pack tier, replayed from the wheel. That is the same set that gets an
    # assignment-only ``studio_skills`` row, which is why one call computes it.
    files[agent_catalog.SKILL_ASSIGNMENT_MARKER] = \
        agent_catalog.skill_assignment_marker(
            role, sorted(n for n in skills if n in pack_names))
    skill_defs.sync_carried_skill_names(role, sorted(set(skills)),
                                        pack_names, code)
    try:
        from app import agent_defs
        agent_defs.upsert_agent_files(role, files, workspace_code=code)
    except Exception as e:                       # never block the save
        logger.warning("agent def snapshot failed for %s: %s", role, e)


def _active_workspace() -> str:
    from app.workspace_context import active_code
    return active_code()


# ── SKILL.md frontmatter parsing ─────────────────────────────────

def _skill_meta_text(raw: str, name: str) -> dict:
    """Parsed SKILL.md TEXT: frontmatter (name/description/always/roles/tool)
    + body + a one-line summary. Tolerant of text without frontmatter.

    Text, never a directory — every tier now arrives as a row: a tenant skill
    from ``studio_skills.files_json``, a pack skill from ``pack_skills``."""
    meta: dict = {}
    body = raw
    if raw.startswith("---"):
        parts = raw.split("---", 2)
        if len(parts) >= 3:
            try:
                meta = yaml.safe_load(parts[1]) or {}
                if not isinstance(meta, dict):
                    meta = {}
            except yaml.YAMLError:
                meta = {}
            body = parts[2]
    summary = ""
    for line in body.splitlines():
        line = line.strip()
        if line:
            summary = line.lstrip("# ").strip()
            break
    return {
        "name": meta.get("name", name),
        "description": str(meta.get("description") or "").strip() or summary,
        "always": bool(meta.get("always", False)),
        "roles": meta.get("roles"),   # None | "all" | [role, ...] — assignment
        "tool": meta.get("tool"),
        "category": _skill_category(name, meta),
        "summary": summary[:180],
        "body": body,
        "raw": raw,
        "fm": meta,   # full frontmatter — update preserves unknown keys
    }


def _skill_used_by(name: str) -> list[str]:
    """Studio-visible roles that carry this skill.

    ONE source for every tier: ``studio_skills.roles_json``. A pack skill's
    assignment-only row answers this exactly as a tenant skill's content row
    does — carriage is a tenant fact, so it is never taken from the global
    catalog, where it would be meaningless.

    The fallback this replaced walked every visible agent's ``skills/``
    directory, which is why an untouched pack agent's carriage still comes
    from ``agents.skills_json``: see ``agent_catalog.agent_index``.
    """
    agents = _visible_agents()
    row = skill_defs.get_def(name, _active_workspace())
    if row is not None:
        return skill_defs.carriers(row["roles"], sorted(agents))
    return sorted(r for r, rec in agents.items() if name in rec["skills"])


#: Static skill -> CLI-tool attributions for pack skills that predate the
#: `tool:` frontmatter key Studio-authored skills carry.
# The skill->tool hints live in the ENGINE's tool_teaching module — the one
# seam the tools console shares, so the per-agent "via <skill>" view and the
# console's taught_by column cannot disagree (they did, live in the
# walkthrough). Fallback copy only for isolated API tests without the engine.
try:
    from ioagentfarm.engine.tool_teaching import SKILL_TOOL_HINTS as _SKILL_TOOL_MAP
except Exception:
    _SKILL_TOOL_MAP = {
        "data_query": "iof-query",
        "catalog_reader": "iof-query",
        "vectorfs_query": "vectorfs",
    }


def _iof_bin() -> str:
    """The resolved ioagentfarm CLI path — clear 500 when missing.

    Settings resolves the binary from IOF_BIN / the server venv's scripts
    dir / PATH; if none of those hit, fail loudly instead of letting
    subprocess raise FileNotFoundError ([WinError 2]) as an opaque 500.
    """
    bin_path = get_settings().ioagentfarm_bin
    if not bin_path or not Path(bin_path).is_file():
        raise HTTPException(
            status_code=500,
            detail="ioagentfarm CLI not found: install the engine into the API's "
                   "venv or set IOF_BIN to the full path of the executable "
                   "(e.g. <repo>/.venv/Scripts/ioagentfarm.exe)")
    return bin_path


def _engine_base() -> str:
    """The engine serving the request's tenant (workspace-routed)."""
    from app.engine_routing import active_engine_base
    return active_engine_base()


def _engine_json(method: str, path: str, **kw) -> dict:
    """Call the tenant's ENGINE web API and return its JSON, or a clear 502.

    The rail for everything that needs the packs or the engine's state
    directory. Same shape as ``run_proxy`` and the session handover: this
    process is not where solutions are installed, and asking it to read them
    is the defect, not a missing feature.
    """
    from app.engine_routing import engine_json
    return engine_json(
        method, path, timeout=120.0,
        purpose="this operation reads the installed solution packs, "
                "which live there", **kw)


def _engine_env(workspace_code: str) -> dict[str, str]:
    """Subprocess env for engine CLI calls — the tenant travels with it.

    The Studio always knows which workspace a request acts on; the engine
    now REFUSES to invent one, so omitting IOF_WORKSPACE here would turn
    every subprocess call into a WorkspaceNotSelected error.
    """
    settings = get_settings()
    env = os.environ.copy()
    env["IOF_ROOT"] = str(settings.iof_root)
    env["IOF_WORKSPACE"] = workspace_code
    if settings.database_url:
        env["IOF_DATABASE_URL"] = settings.database_url
    env.setdefault("PYTHONIOENCODING", "utf-8")
    return env


def _soul_name(soul: str, fallback: str) -> str:
    """Agent display name from SOUL.md.

    Handles the workspace conventions:
      "# SOUL — Maya, Pharma Domain Analyst"        -> "Maya"
      "# SOUL" + "You are **Jarvis**, the ..."      -> "Jarvis"
      "You are the **ANALYST** — the investigator"  -> "Analyst"
    """
    head = soul[:2000]
    m = re.search(r"^#+\s*SOUL\s*[—–-]+\s*([^,\n]+)", head, re.M)
    if m:
        return m.group(1).strip()[:40]
    m = re.search(r"[Yy]ou are (?:the\s+)?\*\*([^*]+)\*\*", head)
    if m:
        name = m.group(1).strip().split(",")[0].split("—")[0].strip()
        return (name.title() if name.isupper() else name)[:40]
    m = re.search(r"[Yy]ou are (?:the\s+)?([A-Z][\w-]+)", head)
    if m:
        return m.group(1)[:40]
    for line in head.splitlines():
        line = line.strip()
        if line:
            hm = re.match(r"^#+\s*(.+)$", line)
            text = (hm.group(1) if hm else line).strip()
            if text.upper() != "SOUL":
                return text[:60]
    return fallback


def apply_display_name(soul: str, name: str) -> str:
    """Make SOUL.md's heading say *name*, because that heading IS the name.

    The Agent name typed on the create form was being discarded: it was used
    for a line of AGENTS.md prose and nothing else, while the agent's name is
    READ BACK from SOUL.md by ``_soul_name``, whose first rule is the
    ``# SOUL — X`` heading. The drafted persona always carries that heading,
    fixed at draft time — so typing "Freight Analyst", drafting, then
    renaming saved an agent called "Analyse Freight Carrier". The POST body
    had the right name; the heading won, silently.

    Rewrites the existing heading rather than re-composing the document, so a
    hand-written persona keeps its exact wording. Empty *name* is a no-op:
    the user did not ask for one.
    """
    display = (name or "").strip()
    if not display:
        return soul
    lines = soul.splitlines()
    for i, line in enumerate(lines):
        if not line.strip():
            continue
        if re.match(r"^#+\s", line):
            lines[i] = f"# SOUL — {display}"
            return "\n".join(lines).rstrip() + "\n"
        break
    return f"# SOUL — {display}\n\n{soul.lstrip()}"


def _workspace_summary(role: str, rec: dict,
                       display: dict | None = None) -> dict:
    """One agent's list/detail summary, from its merged catalog record.

    Same JSON as when this read a directory, field for field — the front end
    parses it directly (``studio.service.ts``), so a DB-only API that returned
    a different shape would break the Studio silently."""
    soul = rec.get("soul", "")
    skills = list(rec.get("skills", []))
    meta = get_agent(role)
    # NAME PRECEDENCE: a tenant-authored definition derives its name from the
    # SOUL it wrote (edits win); an untouched pack agent uses the catalog's
    # own name column, which the engine's sync computed with the canonical
    # extractor. Deriving pack names from the soul text re-parsed a STALE
    # "You are **Jarvis**" prose line and showed the retired name for `cora`
    # while the catalog row already said 'Core Assistant' — found live in
    # the first browser walkthrough.
    if rec.get("has_def"):
        name = _soul_name(soul, meta.get("name", role))
    else:
        name = rec.get("name") or _soul_name(soul, meta.get("name", role))
    return {
        "role": role,
        "name": name,
        "avatar": meta.get("avatar"),
        "color": meta.get("color"),
        "skills": skills,
        "skill_count": len(skills),
        # Agent memory is RUNTIME STATE on the engine host: deliberately
        # excluded from studio_agent_defs (hydration preserves memory/ and
        # never sources it), so this pod cannot know. Reported True because
        # every seeded workspace has a MEMORY.md — the honest answer to
        # "is there a memory to look at?" from here. The UI does not read it.
        "has_memory": True,
        "custom": rec.get("custom", False),
        # NOT "draft". `.studio-created` is PROVENANCE — it says where the
        # agent was authored — and it is written once and never removed, so
        # every Studio agent was badged "Draft" for ever, with no publish
        # action anywhere in the product and no draft state in the API. It
        # ran perfectly well: saving IS publishing here, and the builder's
        # own header already says so ("Save changes; no separate publish
        # state"). A permanent badge that contradicts the behaviour teaches
        # users to distrust the badge. `custom` still carries the provenance
        # for anyone who wants to show it.
        "state": "published",
        "solution": _solution_label(role, rec.get("custom", False),
                                    _role_pack_map()),
        # display metadata (presentation layer — never touches SOUL.md)
        "role_label": (display or {}).get("role_label", ""),
        "summary": (display or {}).get("summary", ""),
        # PROVENANCE (One Truth s4.3). A base agent is what the ENGINE runs,
        # stamped `pack version @ sha`; an unpromoted one exists only as a
        # tenant row no installed pack provides.
        "source": rec.get("source") or ("studio" if rec.get("unpromoted") else "engine"),
        "stamp": rec.get("stamp"),
        "unpromoted": bool(rec.get("unpromoted")),
    }


def _display_map() -> dict[str, dict]:
    """Stored display rows; the DB being down must never break listing."""
    try:
        return studio_display.all_display()
    except Exception as e:
        logger.warning("studio_agent_display unavailable: %s", e)
        return {}


# ── Drafts on the read side (One Truth s3.5) ─────────────────────
#
# A Studio Save is a DRAFT now — per author, base-pinned, resolved only in
# the author's own Try-it sessions. The read side therefore answers two new
# questions on every item: "do I have a draft on this?" (content included,
# staleness against the CURRENT base) and "who else does?" (metadata only —
# another author's content never leaves app/drafts' authorisation seam).

def _attach_drafts(item: dict, kind: str, name: str, identity: Identity,
                   grouped: dict[str, list[dict]] | None = None,
                   *, full: bool = False) -> dict:
    """Fill ``item['draft']`` (the caller's) + ``item['drafts']`` (everyone's,
    metadata). ``full=True`` (detail) computes real staleness — one engine
    call, cached by stamp; lists use the cheap pinned-stamp comparison so N
    rows cost zero extra calls."""
    # `grouped` is EVERY open draft of this kind in the workspace, already
    # fetched in one query — so a name missing from it means "no drafts",
    # not "not looked up yet". Asking `grouped.get(name)` and treating the
    # resulting None as "unfetched" sent every draft-less row back to the
    # database one at a time: 12 of the 13 queries this function's own
    # docstring promises to avoid, and ~15s of a 30s agents list. The
    # batched path is the common path precisely because most items have no
    # draft, which is why the miss went unnoticed.
    if grouped is None:
        rows = [d for d in app_drafts.list_drafts(_active_workspace(),
                                                  kind=kind, name=name)]
    else:
        rows = grouped.get(name) or []
    stamp = item.get("stamp")
    item["drafts"] = [app_drafts.meta(d, stamp) for d in rows]
    mine = next((d for d in rows if d["author"] == identity.email), None)
    if mine is None:
        item["draft"] = None
    elif full:
        item["draft"] = app_drafts.view(mine, _active_workspace())
    else:
        m = app_drafts.meta(mine, stamp)
        m["base_stamp"] = mine.get("base_stamp") or ""
        item["draft"] = m
    return item


def _draft_only_agent_rec(role: str, draft: dict) -> dict:
    """A catalog-record shape for a NEW-ITEM agent draft — visible only to
    its author, which is why this is built per caller instead of living in
    ``agent_index``."""
    files = engine_drafts.overlay({}, draft.get("files"))
    skills = engine_drafts.carried_skills(draft.get("files")) or []
    return {
        "role": role, "pack": "", "name": role, "avatar": "", "color": "",
        "soul": files.get("SOUL.md", ""), "tools": files.get("TOOLS.md", ""),
        "skills": sorted(skills), "custom": True, "owned_here": True,
        # has_def drives name-from-SOUL precedence in _workspace_summary —
        # a draft's name lives in the SOUL its author wrote.
        "has_def": True, "files": files, "stamp": None,
        "has_card": "a2a-card.yaml" in files, "unpromoted": True,
        "source": "draft",
    }


def _agent_record_or_draft(role: str, identity: Identity) -> dict:
    """``_agent_record`` extended by the caller's OWN new-item draft.

    Another member asking for a name that exists only as someone else's
    draft still gets the 404 — a new item is invisible until promoted."""
    try:
        return _agent_record(role)
    except HTTPException as exc:
        if exc.status_code != 404:
            raise
    d = app_drafts.find(_active_workspace(), "agent", role, identity.email)
    if d is None:
        raise HTTPException(status_code=404, detail=f"Agent '{role}' not found")
    return _draft_only_agent_rec(role, d)


# ── Agents ───────────────────────────────────────────────────────

@router.get("/agents")
def list_agents(response: Response,
                identity: Identity = Depends(require_member)):
    """Gallery roster = the agent CATALOG curated by SOLUTION visibility:
    (DB registry `iof.agents` ∪ `.studio-created` ∪ STUDIO_INCLUDE_PACKS)
    − STUDIO_EXCLUDE_PACKS. The DB registry stays the per-role curation
    surface; the pack filter adds whole-solution include/exclude on top
    (e.g. show the AINF agents, hide procurement) with zero DB writes.
    An EMPTY registry disables per-role curation (pack filter still applies).

    The formula is unchanged. What changed is where the roster comes from: the
    union of ``agents`` and ``studio_agent_defs``, not a scan of an agent home
    this process does not have."""
    display = _display_map()
    visible = _visible_agents()
    grouped = app_drafts.for_kind(_active_workspace(), "agent")
    out = [_attach_drafts(_workspace_summary(role, rec, display.get(role)),
                          "agent", role, identity, grouped)
           for role, rec in sorted(visible.items())]
    # The caller's NEW-ITEM drafts: agents no tier lists yet, visible to
    # their author alone until promoted (One Truth s3.5).
    for name in sorted(grouped):
        if name in visible:
            continue
        mine = app_drafts.caller_draft(grouped, name, identity.email)
        if mine is None:
            continue
        out.append(_attach_drafts(
            _workspace_summary(name, _draft_only_agent_rec(name, mine),
                               display.get(name)),
            "agent", name, identity, grouped))
    response.headers["X-Catalog-Source"] = "engine"
    return out


# ── sidebar badge counts ─────────────────────────────────────────

def _skill_catalog_names(ws: str, agents: dict) -> set[str]:
    """The names :func:`_skill_catalog` would return — WITHOUT the bodies.

    Same two tiers and the same visibility rule, deliberately kept next to
    the real thing: a badge that counts a different set from the page it
    links to is worse than no badge.
    """
    from app import agent_catalog

    used = {s for rec in agents.values() for s in rec["skills"]}
    names = {n for n in agent_catalog.pack_skills(ws) if n in used}
    for name, row in skill_defs.list_defs(ws).items():
        if name not in names and not row.get("assignment_only"):
            names.add(name)
    return names


@router.get("/counts")
def studio_counts(identity: Identity = Depends(require_member)):
    """The sidebar's badge numbers, without the catalogs behind them.

    The sidebar wanted five integers and fetched five FULL catalogs to get
    them — every SKILL.md body and every workflow's YAML, parsed into
    summaries, serialised, and then reduced to `.length` in the browser. On
    this deployment that was ~17KB and ~18KB of JSON per page for two of the
    five numbers.

    A count needs neither. This resolves names only: the skill catalog
    without bodies, the workflow catalog without per-workflow detail calls.
    Both derive from the same helpers the list endpoints use
    (`_skill_catalog_names`, `workflow_catalog.list_workflow_names`), which
    is what keeps a badge from counting a different set than its page shows.

    Best-effort per number: the hub is a different database and may be
    unconfigured, so a hub failure omits its keys rather than failing the
    whole sidebar. `loadError` in the UI is about the CATALOG.
    """
    from app import workflow_catalog

    ws = _ws()
    agents = _visible_agents()
    # ONE query for all three kinds — the sidebar counts three, and
    # `for_kind` three times is three round trips over one table.
    drafts = app_drafts.for_all_kinds(ws)
    grouped_a = drafts.get("agent", {})
    grouped_s = drafts.get("skill", {})
    grouped_w = drafts.get("workflow", {})

    def _with_new_item_drafts(names: set[str], grouped: dict) -> int:
        """A list endpoint also shows the CALLER's own not-yet-promoted new
        items, so the badge has to count them too."""
        extra = sum(1 for n in grouped
                    if n not in names
                    and app_drafts.caller_draft(grouped, n, identity.email))
        return len(names) + extra

    out = {
        "agents": _with_new_item_drafts(set(agents), grouped_a),
        "skills": _with_new_item_drafts(_skill_catalog_names(ws, agents),
                                        grouped_s),
        "workflows": _with_new_item_drafts(
            set(workflow_catalog.list_workflow_names(ws)), grouped_w),
    }
    try:
        from app.routers import hil_queue
        out.update(hil_queue.counts())
    except Exception as e:      # noqa: BLE001 — a different DB; never fatal here
        logger.info("hub counts unavailable: %s", e)
    return out


def _agent_record(role: str) -> dict:
    """One agent's merged record, or 404 — the DB replacement for "does
    ``<home>/<role>/workspace/SOUL.md`` exist?"."""
    from app import agent_catalog
    from app.workspace_context import active_code

    rec = agent_catalog.agent_index(
        active_code(), get_settings().platform_shared_roles).get(role)
    if rec is None:
        raise HTTPException(status_code=404, detail=f"Agent '{role}' not found")
    if not rec.get("unpromoted"):
        # Base tier: the list carries no bodies; the pack TEMPLATE's files
        # come from the engine (cached by stamp).
        files = agent_catalog.pack_agent_files(role, active_code(),
                                               rec.get("stamp"))
        rec["files"] = files
        rec["soul"] = files.get("SOUL.md", "")
        rec["tools"] = files.get("TOOLS.md", "")
    if not rec.get("soul"):
        raise HTTPException(status_code=404, detail=f"Agent '{role}' not found")
    return rec


@router.get("/agents/{role}")
def get_agent_detail(role: str, identity: Identity = Depends(require_member)):
    rec = _agent_record_or_draft(role, identity)
    try:
        display = studio_display.get_display(role)
    except Exception:
        display = None
    detail = _workspace_summary(role, rec, display)
    detail["details"] = (display or {}).get("details", "")
    detail["soul"] = rec["soul"]
    # sectioned persona view — the builder edits sections; SOUL.md stays the
    # runtime artifact (composed deterministically on save)
    detail["persona_sections"] = personas.parse_soul(
        detail["soul"], fallback_name=detail["name"])
    detail["tools"] = rec.get("tools", "")
    # per-skill frontmatter (always/description/tool) + the derived CLI-tool
    # surface — tools are taught by skills, never assigned directly, so this
    # is a read-only computed view ("via <skill>" attribution in the UI).
    catalog = _skill_catalog()
    skill_details, cli_tools = [], []
    for s in detail["skills"]:
        entry = catalog.get(s)
        m = entry["meta"] if entry else _skill_meta_text("", s)
        skill_details.append({
            "name": s, "description": m["description"][:200],
            "always": m["always"], "roles": m["roles"], "tool": m["tool"],
        })
        tool = m["tool"] or _SKILL_TOOL_MAP.get(s)
        if tool:
            cli_tools.append({"tool": tool, "via": s})
    detail["skill_details"] = skill_details
    detail["cli_tools"] = cli_tools
    # The inbound A2A card, verbatim. It already rides files_json (it is an
    # identity file) — this just stops hiding it from the builder, which is
    # what left the exposure switch with no product surface.
    from app import agent_catalog as _ac
    raw_card = (rec.get("files") or {}).get("a2a-card.yaml")
    detail["a2a_card"] = _ac._decode(raw_card) if raw_card else None
    # Base stays base; the caller's own edit rides `draft` (full view, real
    # staleness) and everyone's existence rides `drafts` (metadata only).
    return _attach_drafts(detail, "agent", role, identity, full=True)


class AgentCreate(BaseModel):
    role: str
    name: str = ""
    persona: str = ""          # becomes SOUL.md
    skills: list[str] = []     # copied from the skill inventory


class AgentUpdate(BaseModel):
    soul: str | None = None       # raw markdown (Advanced mode) — kept working
    tools: str | None = None      # TOOLS.md — "edit ANY feature" surface
    add_skills: list[str] = []
    remove_skills: list[str] = []
    # sectioned persona editing: sections win over `soul` when both are sent.
    # SOUL.md is COMPOSED deterministically from these (stable headings, so
    # parse(compose(x)) == x round-trips).
    persona_sections: dict[str, str] | None = None
    persona_name: str | None = None   # display name for the composed title
    # The inbound A2A card (raw YAML). A string sets/replaces the file, the
    # empty string REMOVES it (withdrawing the agent from the A2A surface at
    # the next serve start), absent leaves it untouched.
    a2a_card: str | None = None


def _skill_instructions(body: str, name: str) -> str:
    """The editable instructions part of a skill body: the markdown minus the
    generated title heading and any trailing '## Tool:' binding section."""
    text = body.split("\n## Tool:", 1)[0]
    lines = text.strip().splitlines()
    if lines and re.match(r"^#\s+", lines[0]):
        heading = lines[0].lstrip("# ").strip().lower()
        if heading in (name.replace("_", " ").lower(), name.lower()):
            lines = lines[1:]
    return "\n".join(lines).strip()


def _pack_skill_names() -> set[str]:
    """Every skill name the installed packs ship — from the ENGINE catalog."""
    from app import agent_catalog
    return set(agent_catalog.pack_skills(_active_workspace()))


def _sdk_skill_names() -> set[str]:
    """Shared-tier skill names a tenant may not take ownership of.

    The agentfarm-skills wheel (and the core pack): they arrive in wheels and
    change on upgrade, so a tenant-owned copy freezes a fork that no SDK
    upgrade reaches again.

    From the ENGINE catalog: a skill whose ``pack`` is the engine's own or
    the shared-skills wheel (``engine_catalog.SDK_PACKS``). It used to import
    the pack registry HERE — which answers empty on a pod with no packs, i.e.
    exactly where the Studio would then offer an Edit button on every SDK
    skill and let a tenant fork the lot.
    """
    from app import agent_catalog
    rows = agent_catalog.pack_skills(_active_workspace())
    return {n for n, r in rows.items() if r["shared"]}


def _skill_editable(name: str, origin: str,
                    sdk: "set[str] | None" = None) -> bool:
    """Whether the Studio may edit this skill package.

    ``sdk`` lets a caller that is already looping over the inventory pass the
    shared-tier set in. Resolving it costs an ENGINE ROUND TRIP, and this is
    called once per skill - which is how a list endpoint spent ~26s of its
    ~35s asking the same question 23 times and getting the same answer.

    False for the shared SDK tier only. A DOMAIN pack's skill stays editable:
    the catalog deliberately lets a tenant shadow one (DB wins on a name
    collision), and that is a supported choice. Forking a wheel's skill is
    not — it is the thing the shared tier exists to prevent.
    """
    return name not in (_sdk_skill_names() if sdk is None else sdk)


def _skill_catalog() -> dict[str, dict]:
    """Every skill the Studio can show: ``{name: {meta, used_by, origin,
    stamp, unpromoted}}``.

    TWO TIERS, joined here, and the ENGINE tier wins:

    * the ENGINE catalog (``GET /api/catalog/skills``) — what the installed
      packs ship, each with its stamp; bodies fetched per skill and cached by
      stamp. This tier used to be a database mirror (``pack_skills``) written
      by a sync that had to have run; before that it was read off a
      filesystem this pod does not have.
    * ``studio_skills`` — this WORKSPACE's own: assignment for every tier
      (``roles_json`` IS carriage, pack skills included), and CONTENT only
      for a name the engine has no skill of (ADD-ONLY, marked
      ``unpromoted``). A tenant content row for a name the engine also
      ships is NOT shown — pack wins; its ``roles_json`` still counts.

    Visibility is inherited from the agents, unchanged: a skill no visible
    agent carries is not in the catalog, which is what keeps an excluded
    pack's skills out of an excluded pack's tenant.
    """
    agents = _visible_agents()
    visible = sorted(agents)
    used_index: dict[str, list[str]] = {}
    for role in visible:
        for s in agents[role]["skills"]:
            used_index.setdefault(s, []).append(role)

    from app import agent_catalog
    ws = _active_workspace()
    out: dict[str, dict] = {}
    # Bodies for the WHOLE inventory in one fan-out. Fetching them one at a
    # time here is what made this endpoint take 66s on a 43-skill workspace
    # - and the page renders nothing until it returns, so it read as an
    # empty catalog rather than a slow one.
    wanted = {name: row for name, row in agent_catalog.pack_skills(ws).items()
              if name in used_index}
    bodies = agent_catalog.pack_skill_md_many(wanted, ws)
    for name, row in wanted.items():
        md = bodies.get(name, "")
        out[name] = {"meta": _skill_meta_text(md, name),
                     "used_by": used_index[name], "origin": "pack",
                     "pack": row.get("pack", ""), "stamp": row.get("stamp"),
                     "unpromoted": False}
    for name, row in skill_defs.list_defs(ws).items():
        entry = out.get(name)
        if entry is not None or row.get("assignment_only"):
            if entry is None:
                continue           # assigned but its pack is not installed here
            # PACK WINS the content; the row still records who holds it.
            entry["used_by"] = skill_defs.carriers(row["roles"], visible)
            continue
        out[name] = {
            "meta": _skill_meta_text(row["files"].get("SKILL.md", ""), name),
            "used_by": skill_defs.carriers(row["roles"], visible),
            "origin": row.get("origin") or "studio",
            "pack": "", "stamp": None, "unpromoted": True,
        }
    return out


def _skill_summaries() -> list[dict]:
    """The catalog rows of :func:`list_skills`, minus the per-caller draft
    decoration — extracted so :func:`draft_agent` can rank suggestions over
    the same inventory without a Response or an identity in hand."""
    out = []
    # ONCE for the whole inventory - see `_skill_editable`. Per row this was
    # an engine call each, and it dominated the endpoint.
    sdk = _sdk_skill_names()
    for name, entry in sorted(_skill_catalog().items()):
        m = entry["meta"]
        out.append({
            "name": name,
            "summary": m["summary"][:140],
            "description": m["description"][:300],
            "always": m["always"],
            "roles": m["roles"],          # None | "all" | [...] — assignment
            "tool": m["tool"],
            "category": m["category"],
            "used_by": entry["used_by"],
            "source": (entry["used_by"] or [""])[0],
            # Provenance, and whether the Studio may edit it. The Edit button
            # used to be unconditional, inviting a tenant fork of SDK content
            # that the shared tier exists to prevent — and the payload carried
            # nothing the UI could have used to tell the difference ("source"
            # is used_by[0], an agent role, not provenance).
            "origin": entry["origin"],
            "editable": _skill_editable(name, entry["origin"], sdk),
            # PROVENANCE (One Truth s4.3): base = the ENGINE's installed
            # pack, stamped; unpromoted = a tenant row no pack provides.
            # (`source` above is the historical used_by[0] the UI reads.)
            "catalog_source": "studio" if entry["unpromoted"] else "engine",
            "stamp": entry.get("stamp"),
            "unpromoted": entry["unpromoted"],
        })
    return out


def _draft_only_skill_summary(name: str, draft: dict, ws: str,
                              pack_row: dict | None = None) -> dict:
    """A list row for a skill the CATALOG did not yield.

    Usually that means it exists only as the caller's draft. It can also mean
    the draft has been PROMOTED and no agent carries it yet: the pack tier is
    filtered by carriage (a skill no visible agent holds is not in the
    catalog), so a promoted-but-uncarried skill falls out of it and landed
    here — reported as an unpromoted draft while `aicore drafts list` and the
    engine both read it as promoted. The badge contradicted the state.

    PROVENANCE IS NOT VISIBILITY. `unpromoted` answers "does any installed
    pack provide this item?", so it is computed against the UNFILTERED engine
    catalog (``pack_row``), never against the carriage-filtered view.
    """
    files = engine_drafts.overlay({}, draft.get("files"))
    m = _skill_meta_text(files.get("SKILL.md", ""), name)
    used_by = draft_save.author_skill_carriers(ws, draft["author"], name)
    promoted = pack_row is not None
    return {
        "name": name, "summary": m["summary"][:140],
        "description": m["description"][:300], "always": m["always"],
        "roles": m["roles"], "tool": m["tool"], "category": m["category"],
        "used_by": used_by, "source": (used_by or [""])[0],
        "origin": "pack" if promoted else "draft",
        "editable": _skill_editable(name, "") if promoted else True,
        "catalog_source": "engine" if promoted else "draft",
        "stamp": (pack_row or {}).get("stamp") if promoted else None,
        "unpromoted": not promoted,
    }


@router.get("/skills")
def list_skills(response: Response,
                identity: Identity = Depends(require_member)):
    """Inventory with parsed frontmatter — powers the Skill Studio and the
    recommendation-ranked skills panel. `roles` is the assignment record (who
    holds it), NOT an eligibility list — any skill may be added to any agent."""
    ws = _active_workspace()
    grouped = app_drafts.for_kind(ws, "skill")
    out = [_attach_drafts(row, "skill", row["name"], identity, grouped)
           for row in _skill_summaries()]
    listed = {row["name"] for row in out}
    # The caller's NEW-ITEM skill drafts — theirs alone until promoted.
    # `pack_all` is the UNFILTERED engine catalog, fetched only if there is
    # an unlisted draft to classify: a name the engine now ships is PROMOTED
    # even when the carriage filter kept it out of the catalog above.
    pack_all: dict | None = None
    for name in sorted(grouped):
        if name in listed:
            continue
        mine = app_drafts.caller_draft(grouped, name, identity.email)
        if mine is None:
            continue
        if pack_all is None:
            from app import agent_catalog
            pack_all = agent_catalog.pack_skills(ws)
        out.append(_attach_drafts(
            _draft_only_skill_summary(name, mine, ws, pack_all.get(name)),
            "skill", name, identity, grouped))
    response.headers["X-Catalog-Source"] = "engine"
    return out


@router.get("/skills/{name}")
def get_skill_detail(name: str,
                     identity: Identity = Depends(require_member)):
    """Full SKILL.md package view: frontmatter properties + body + used-by."""
    entry = _skill_catalog().get(name)
    if not entry:
        # A name only the caller's own draft knows resolves FROM the draft;
        # for anyone else it does not exist yet (One Truth s3.5).
        d = app_drafts.find(_active_workspace(), "skill", name, identity.email)
        if d is None:
            raise HTTPException(status_code=404,
                                detail=f"Skill '{name}' not found")
        files = engine_drafts.overlay({}, d.get("files"))
        m = _skill_meta_text(files.get("SKILL.md", ""), name)
        detail = {
            "name": name, "description": m["description"],
            "always": m["always"], "roles": m["roles"], "tool": m["tool"],
            "category": m["category"], "summary": m["summary"],
            "body": m["body"], "instructions": _skill_instructions(m["body"], name),
            "raw": m["raw"],
            "used_by": draft_save.author_skill_carriers(
                _active_workspace(), identity.email, name),
            "origin": "draft", "editable": True, "catalog_source": "draft",
            "stamp": None, "unpromoted": True,
        }
        return _attach_drafts(detail, "skill", name, identity, full=True)
    m = entry["meta"]
    detail = {
        "name": name,
        "description": m["description"],
        "always": m["always"],
        "roles": m["roles"],
        "tool": m["tool"],
        "category": m["category"],
        "summary": m["summary"],
        "body": m["body"],
        "instructions": _skill_instructions(m["body"], name),
        "raw": m["raw"],
        "used_by": entry["used_by"],
        "origin": entry["origin"],
        "editable": _skill_editable(name, entry["origin"]),
        "catalog_source": "studio" if entry["unpromoted"] else "engine",
        "stamp": entry.get("stamp"),
        "unpromoted": entry["unpromoted"],
    }
    return _attach_drafts(detail, "skill", name, identity, full=True)


class SkillCreate(BaseModel):
    name: str
    description: str
    instructions: str
    always: bool = False
    category: str | None = None            # browsing group (SKILL_CATEGORIES key)
    roles: list[str] | str | None = None   # assignment; None -> the install targets
    script: str | None = None              # DB-catalogued command binding
    script_usage: str = ""                 # author's extra usage guidance
    install_to: list[str] = []             # target agent roles (workspaces)


def _compose_skill_md(req: "SkillCreate", extra_fm: dict | None = None) -> str:
    """SKILL.md package text: frontmatter + instructions + tool binding.

    `roles:` is written exactly as chosen. It is the skill's ASSIGNMENT — who
    holds it — and it seeds the baseline of an agent workspace materialized for
    the first time. It is no longer an eligibility gate: nothing refuses this
    skill to an agent outside the list, and a workflow step may name it
    regardless. `extra_fm` carries frontmatter keys this form does not own
    (e.g. iobot `metadata:` requirements) so an update never drops them."""
    fm: dict = {
        "name": req.name,
        "description": req.description.strip(),
        "always": bool(req.always),
        "studio_created": True,
    }
    if req.category:
        fm["category"] = req.category
    if req.roles is not None:
        fm["roles"] = req.roles
    if req.script:
        fm["tool"] = req.script
    for k, v in (extra_fm or {}).items():
        fm.setdefault(k, v)

    title = req.name.replace("_", " ").title()
    parts = [
        "---",
        yaml.safe_dump(fm, sort_keys=False, allow_unicode=True).strip(),
        "---",
        "",
        f"# {title}",
        "",
        req.instructions.strip(),
    ]
    if req.script:
        row = _get_catalog_script(req.script)
        parts += [
            "",
            f"## Tool: {row['title']}",
            "",
            "Run this command via exec:",
            "",
            "```",
            row["command"],
            "```",
            "",
            (row.get("usage_md") or "").strip(),
        ]
        if req.script_usage.strip():
            parts += ["", req.script_usage.strip()]
    return "\n".join(parts).rstrip() + "\n"


def _get_catalog_script(name: str) -> dict:
    from app.studio_scripts import get_script
    row = get_script(name)
    if not row:
        raise HTTPException(
            status_code=400,
            detail=f"script '{name}' is not in the catalog — register it first "
                   f"(POST /api/studio/skill-scripts)")
    return row


def _validate_skill_payload(req: SkillCreate, *, creating: bool,
                            extra_agents: frozenset | set = frozenset()) -> None:
    if not SKILL_NAME_RE.match(req.name):
        raise HTTPException(status_code=400,
                            detail="skill name must match ^[a-z][a-z0-9_]{2,40}$")
    if not req.description.strip():
        raise HTTPException(status_code=400, detail="description must not be empty")
    if not req.instructions.strip():
        raise HTTPException(status_code=400, detail="instructions must not be empty")
    if isinstance(req.roles, str) and req.roles != "all":
        raise HTTPException(status_code=400,
                            detail="roles must be a list of role ids or the literal 'all'")
    if req.category is not None and req.category not in SKILL_CATEGORIES:
        raise HTTPException(
            status_code=400,
            detail=f"category must be one of {sorted(SKILL_CATEGORIES)}")
    # A skill with NO carrier is allowed. It used to be a 400 — "install_to
    # must name at least one agent, a skill package lives inside agent
    # workspaces" — which was true while a skill existed only as path-keyed
    # entries inside some agent's blob. Since `studio_skills` a skill has its
    # own row and needs no carrier to exist, and refusing one contradicted
    # both the open-skills model and this page's own hint: a workflow step
    # declares what the JOB needs and may name a skill no agent holds.
    # Creating it is precisely how you author that skill.
    # `roles` is the ASSIGNMENT RECORD — who holds this skill — not a list of
    # who is ALLOWED to. Skills are open, so installing into an agent outside
    # the list is not a contradiction to refuse (it used to be a 400: "agents
    # [...] are not in this skill's allowed roles"); it is simply a new
    # assignment, and the record must learn it. Anything else would leave the
    # skill on the agent's disk while the row said it was not there, and the
    # first hydration would delete it.
    #
    # None -> scoped to exactly the install targets (create only — an UPDATE
    # with roles=None means "keep it only-where-installed", and must not
    # silently rewrite that to an empty list).
    if req.roles is None and creating:
        req.roles = sorted(req.install_to)
    if isinstance(req.roles, list):
        req.roles = sorted(set(req.roles) | set(req.install_to))
    known_agents = set(_visible_agents()) | extra_agents
    for role in req.install_to:
        if role not in known_agents:
            raise HTTPException(status_code=400, detail=f"unknown agent '{role}'")
    if req.script:
        _get_catalog_script(req.script)  # 400 when not catalogued (fail-closed)


def _write_skill(name: str, text: str, roles) -> None:
    """One DB row. That is the whole write.

    NO SAVE ENDPOINT CALLS THIS ANY MORE — a Studio Save is a draft
    (``app/draft_save.py``). Kept for the transitional read tier and the
    migration reader; removal is scheduled one release after
    ``aicore drafts migrate`` ships.

    The row is the authority; hydration's composite sync key propagates the
    edit to every carrier at its next run/task/chat seam. What used to follow
    this was a copy of ``SKILL.md`` into each carrier's workspace directory —
    "so the skill is usable immediately on this host". There is no such host:
    the API pod has no agent home, so those writes landed nowhere the engine
    would ever look, while reading the same directories back is what made a
    rebuilt tenant show nothing.

    The carriers still have to be recorded, and are: ``install_to`` is folded
    into ``roles`` by ``_validate_skill_payload``, and ``roles_json`` IS the
    assignment for every tier.
    """
    skill_defs.upsert_skill_def(name, {"SKILL.md": text}, roles,
                                _active_workspace())


def _caller_draft_agent_names(identity: Identity) -> set[str]:
    """Agents that exist only as the caller's own drafts — legal install
    targets for the caller (carriage lands in those drafts, nowhere else)."""
    return {d["name"] for d in app_drafts.list_drafts(
        _active_workspace(), author=identity.email, kind="agent")}


@router.post("/skills", status_code=201)
def create_skill(req: SkillCreate,
                 identity: Identity = Depends(require_member)):
    """Author a SKILL.md package — as the caller's DRAFT. ``install_to``
    carriage is recorded as agent drafts too (carriage is content, so a
    skill add on a pack agent is draft-only until promoted)."""
    _validate_skill_payload(req, creating=True,
                            extra_agents=_caller_draft_agent_names(identity))
    ws = _active_workspace()
    from app import agent_catalog
    if req.name in agent_catalog.all_skill_names(ws) \
            or app_drafts.find(ws, "skill", req.name, identity.email):
        raise HTTPException(status_code=409, detail=f"skill '{req.name}' already exists")
    text = _compose_skill_md(req)
    draft_save.save_skill(ws, identity, req.name, text)
    draft_save.assign_skill_to_agents(ws, identity, req.name, req.install_to)
    detail = get_skill_detail(req.name, identity)
    detail["saved_as"] = "draft"
    return detail


@router.put("/skills/{name}")
def update_skill(name: str, req: SkillCreate,
                 identity: Identity = Depends(require_member)):
    """Update a skill package — as the caller's DRAFT (base pinned from the
    engine for a pack skill; a legacy tenant row seeds a new-item draft and
    is never written again). Frontmatter keys the form does not own
    (iobot `metadata:`, `license`, …) are carried through."""
    if req.name != name:
        raise HTTPException(status_code=400, detail="name in body must match the URL")
    ws = _active_workspace()
    from app import agent_catalog
    # Fail-closed, not merely hidden in the UI: even a DRAFT of a wheel's
    # skill invites a tenant fork frozen at today's version that no SDK
    # upgrade reaches again. Hiding the button is the UX; this is the rule.
    # BEFORE the existence check, deliberately: the SDK tier is defined by the
    # NAME (`engine_catalog.SDK_PACKS`), and the wheel's skills need not appear
    # in this workspace's catalog — checking existence first turned the
    # contractual 409 into a 404 that reads like "no such skill".
    if not _skill_editable(name, ""):
        raise HTTPException(
            status_code=409,
            detail=f"'{name}' ships with the SDK and updates when the SDK is "
                   f"upgraded — it cannot be edited here. Create a skill with "
                   f"a different name if you need your own version.")
    own_draft = app_drafts.find(ws, "skill", name, identity.email)
    if name not in agent_catalog.all_skill_names(ws) and own_draft is None:
        raise HTTPException(status_code=404, detail=f"Skill '{name}' not found")
    _validate_skill_payload(req, creating=False,
                            extra_agents=_caller_draft_agent_names(identity))
    entry = _skill_catalog().get(name)
    known = {"name", "description", "always", "roles", "tool", "category",
             "studio_created"}
    extra_fm = {}
    if entry:
        extra_fm = {k: v for k, v in (entry["meta"].get("fm") or {}).items()
                    if k not in known}
    elif own_draft is not None:
        prior = _skill_meta_text(
            engine_drafts.overlay({}, own_draft["files"]).get("SKILL.md", ""),
            name)
        extra_fm = {k: v for k, v in (prior.get("fm") or {}).items()
                    if k not in known}
    text = _compose_skill_md(req, extra_fm)
    draft_save.save_skill(ws, identity, name, text)
    draft_save.assign_skill_to_agents(ws, identity, name, req.install_to)
    detail = get_skill_detail(name, identity)
    detail["saved_as"] = "draft"
    return detail


@router.post("/agents", status_code=201)
def create_agent(req: AgentCreate,
                 identity: Identity = Depends(require_member)):
    if not ROLE_RE.match(req.role):
        # Plain language, not a regex: this is shown to a business user who
        # typed a name, not to whoever wrote the pattern. `Freight-Analyst!`
        # was being normalised client-side to `freight_analyst_` and accepted
        # silently — a trailing underscore is never something anyone meant.
        raise HTTPException(
            status_code=400,
            detail="Internal id must be 3-41 characters, start with a letter, "
                   "end with a letter or number, and contain only lowercase "
                   f"letters, numbers and underscores (got '{req.role}').")
    from app import agent_catalog
    from app.workspace_context import active_code

    existing = agent_catalog.agent_index(
        active_code(), get_settings().platform_shared_roles)
    if req.role in existing:
        raise HTTPException(status_code=409, detail=f"Agent '{req.role}' already exists")
    if app_drafts.find(active_code(), "agent", req.role, identity.email):
        raise HTTPException(
            status_code=409,
            detail=f"You already have a draft named '{req.role}' — open it "
                   f"in the builder to keep editing, or discard it first.")

    name = req.name or req.role.replace("_", " ").title()
    soul = req.persona.strip() or f"# {name}\n\nYou are {name}, a specialist agent.\n"
    # The name is read back FROM the persona's heading, so it has to be
    # written INTO it — otherwise a drafted persona's own heading wins and
    # the name the user typed is lost. See apply_display_name.
    soul = apply_display_name(soul, req.name)

    # The agent's IDENTITY FILES, as a row rather than a directory. `memory/`
    # is deliberately absent: it is runtime state the engine creates and
    # hydration preserves, and storing it here would let one host's
    # accumulated learnings overwrite another's. AGENTS.md is generated per
    # host by the engine; it is written here only because it always was, and
    # `_generate_agents_md` rewrites it on the way into a run anyway.
    known = set(agent_catalog.all_skill_names(active_code()))
    wanted = sorted((set(req.skills) & known) | {"output_protocol"})
    files = {
        "SOUL.md": soul,
        "AGENTS.md": f"# Working agreements\n\nYou are the {name} agent.\n",
        "TOOLS.md": "# Tools\n\nYour capabilities are taught by your skills.\n",
        "USER.md": "# User\n",
        "HEARTBEAT.md": "# Heartbeat\n",
        ".studio-created": "created via studio\n",
    }
    # A brand-new item is a DRAFT visible only to its author until promoted —
    # no studio_agent_defs row, no studio_skills row (One Truth s3.5). The
    # engine serves it only inside this author's draft sessions.
    draft_save.save_agent(active_code(), identity, req.role, None,
                          files, wanted)
    detail = get_agent_detail(req.role, identity)
    detail["saved_as"] = "draft"
    return detail


@router.put("/agents/{role}")
def update_agent(role: str, req: AgentUpdate,
                 identity: Identity = Depends(require_member)):
    from app import agent_catalog
    from app.workspace_context import active_code

    # The author edits against what THEY currently see: base ⊕ their own
    # draft. A second save therefore composes on the first instead of
    # silently reverting it — the draft row is replaced wholesale by
    # draft_save with the base re-pinned to today's stamp.
    state = draft_save.agent_state(active_code(), identity.email, role)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Agent '{role}' not found")
    files = {k: agent_catalog._decode(v) for k, v in state["files"].items()}
    current_soul = files.get("SOUL.md", "")

    if req.persona_sections is not None:
        unknown = [k for k in req.persona_sections
                   if k not in personas.SECTION_ORDER]
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=f"unknown persona sections {unknown} — valid sections: "
                       f"{personas.SECTION_ORDER}")
        if not any((v or "").strip() for v in req.persona_sections.values()):
            raise HTTPException(status_code=400,
                                detail="persona must not be empty — fill in at "
                                       "least one section")
        parsed = personas.parse_soul(current_soul,
                                     fallback_name=get_agent(role)["name"])
        name = (req.persona_name or "").strip() or parsed["name"]
        files["SOUL.md"] = personas.compose_soul(name, req.persona_sections)
    elif req.soul is not None:
        if not req.soul.strip():
            raise HTTPException(status_code=400, detail="soul must not be empty")
        # Same rule as create: persona_name, when sent, owns the heading. The
        # edit screen rewrites it client-side; doing it here too means the API
        # cannot be talked into saving a name it was not given.
        files["SOUL.md"] = apply_display_name(req.soul, req.persona_name or "")
    if req.tools is not None:
        files["TOOLS.md"] = req.tools
    if req.a2a_card is not None:
        if not req.a2a_card.strip():
            files.pop("a2a-card.yaml", None)
        else:
            import yaml as _yaml
            try:
                parsed = _yaml.safe_load(req.a2a_card)
            except Exception as exc:
                raise HTTPException(status_code=400,
                                    detail=f"a2a_card is not valid YAML: {exc}")
            if not isinstance(parsed, dict):
                raise HTTPException(status_code=400,
                                    detail="a2a_card must be a YAML mapping")
            files["a2a-card.yaml"] = req.a2a_card

    # A skill the caller only holds as their own DRAFT is addable too — it
    # exists for them, and refusing it would make a drafted skill unusable
    # until promoted, which defeats the Try-it loop.
    known = set(agent_catalog.all_skill_names(active_code())) | {
        d["name"] for d in app_drafts.list_drafts(
            active_code(), author=identity.email, kind="skill")}
    skills = set(state["skills"])
    for skill in req.add_skills:
        if skill not in known:
            raise HTTPException(status_code=400, detail=f"unknown skill '{skill}'")
        skills.add(skill)
    for skill in req.remove_skills:
        if skill == "output_protocol":
            raise HTTPException(status_code=400, detail="output_protocol is mandatory")
        skills.discard(skill)
    # The Save IS a draft (One Truth s3.5): no tenant row is written — a
    # pack agent's edit would otherwise be silently inert (the engine no
    # longer resolves that tier for pack names).
    draft_save.save_agent(active_code(), identity, role, state, files,
                          sorted(skills))
    detail = get_agent_detail(role, identity)
    detail["saved_as"] = "draft"
    return detail


class AgentDisplayUpdate(BaseModel):
    """Presentation-layer fields — persisted in studio_agent_display, never
    composed into SOUL.md. None keeps the stored value; '' clears it."""
    role_label: str | None = None
    summary: str | None = None
    details: str | None = None


@router.put("/agents/{role}/display")
def update_agent_display(role: str, req: AgentDisplayUpdate):
    _agent_record(role)          # 404 for a role this workspace does not show
    return studio_display.upsert_display(
        role, req.role_label, req.summary, req.details)


# ── Describe-then-refine drafting (deterministic, inventory-grounded) ──
#
# The endpoints keep the approved spec's request/response shapes
# (docs/AGENT_BUILDER_UX.md §3.4) so an LLM-backed drafter is a drop-in
# upgrade; today's implementation is rule-based (honest 2-hour-scope cut):
# a structured persona template + keyword-ranked skill suggestions with
# plain-language rationale over the LIVE inventory (real skill names only).

_STOPWORDS = frozenset(
    "a an and are as at be by for from has have how in is it its of on or "
    "our that the their they this to was we what when which who will with "
    "you your should must can could need needs agent skills skill data".split())


def _keywords(text: str) -> list[str]:
    words = re.findall(r"[a-z][a-z0-9_]{2,}", text.lower())
    seen: dict[str, None] = {}
    for w in words:
        if w not in _STOPWORDS:
            seen.setdefault(w, None)
    return list(seen)


class DraftRequest(BaseModel):
    description: str
    role: str = ""
    name: str = ""


def _draft_soul(name: str, description: str) -> str:
    desc = description.strip().rstrip(".")
    return f"""# SOUL — {name}

You are **{name}**. {desc}.

## Mission

{description.strip()}

## How you work

- Ground every statement in data you actually queried or documents you actually read — never invent figures.
- Lead with the answer, then the evidence. Keep replies short and structured.
- When information is not available, say exactly what is missing instead of guessing.

## Boundaries

- Stay within your mission; redirect unrelated requests back to the user.
- Never reveal credentials, secrets, or internal file paths.

## Output discipline

When you complete a task step, follow the output protocol exactly: finish with
`STATUS: done` and a one-paragraph `OUTPUT:` summary.
"""


@router.post("/agents/draft")
def draft_agent(req: DraftRequest):
    """Describe-then-refine backend: description in → editable draft out.

    Returns a proposed role id, display name, persona draft, and skill
    suggestions ranked by fit with a "why suggested" rationale. Nothing is
    created — the caller reviews/edits and then POSTs /agents (human-gated)."""
    description = req.description.strip()
    if not description:
        raise HTTPException(status_code=400, detail="description must not be empty")

    kws = _keywords(description)
    role = req.role.strip()
    if not role:
        # `or` chain, because slug_role returns '' when nothing usable
        # survives normalisation (e.g. a name of only punctuation).
        role = (slug_role(req.name.strip()) or slug_role(" ".join(kws[:3]))
                or "specialist_agent")
    name = req.name.strip() or role.replace("_", " ").title()

    suggestions = []
    for s in _skill_summaries():
        if s["name"] == "output_protocol":
            continue
        hay_name = s["name"].replace("_", " ")
        hay = f"{hay_name} {s['description']} {s['summary']}".lower()
        matched = [k for k in kws if k in hay]
        name_hits = [k for k in kws if k in hay_name]
        score = len(matched) + 2 * len(name_hits)
        if score > 0:
            shown = sorted(set(matched), key=matched.index)[:3]
            suggestions.append({
                "skill": s["name"],
                "score": score,
                "rationale": "Matches your description: " + ", ".join(f'"{m}"' for m in shown),
                "always": s["always"],
                "roles": s["roles"],
                "description": s["description"][:200],
                "locked": False,
                "include": score >= 3,
            })
    suggestions.sort(key=lambda x: -x["score"])
    suggestions = suggestions[:8]
    suggestions.insert(0, {
        "skill": "output_protocol", "score": 99,
        "rationale": "Always included — how the agent reports completed work "
                     "back to the platform.",
        "always": True, "roles": "all", "description":
            "Platform requirement: every task ends with a structured status report.",
        "locked": True, "include": True,
    })
    return {
        "role": role,
        "name": name,
        "soul": _draft_soul(name, description),
        "suggestions": suggestions,
    }


class AssistRequest(BaseModel):
    mode: str  # "tighten" | "guardrails"


@router.post("/agents/{role}/assist")
def assist_soul(role: str, req: AssistRequest):
    """Persona assist: returns a PROPOSED revision for accept/reject diffing.

    Nothing is applied server-side — the apply path stays the human-gated
    PUT /agents/{role} (the Dust contract: no silent writes)."""
    current = _agent_record(role)["soul"]
    proposed = current

    if req.mode == "tighten":
        lines = [ln.rstrip() for ln in proposed.splitlines()]
        text = "\n".join(lines)
        text = re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"
        if not text.lstrip().startswith("#"):
            display = _soul_name(current, role.replace("_", " ").title())
            text = f"# SOUL — {display}\n\n{text}"
        if "output" not in text.lower() or "STATUS" not in text:
            text += ("\n## Output discipline\n\nWhen you complete a task step, "
                     "follow the output protocol exactly: finish with "
                     "`STATUS: done` and a one-paragraph `OUTPUT:` summary.\n")
        proposed = text
    elif req.mode == "guardrails":
        if not re.search(r"^##.*\b(guardrail|boundar)", proposed, re.I | re.M):
            proposed = proposed.rstrip() + """

## Boundaries & guardrails

- Only state facts you can trace to data you queried or documents you read; say "not available" otherwise.
- Stay within your mission; redirect unrelated requests back to the user.
- Never reveal credentials, secrets, or internal file paths.
- If a request conflicts with these rules, decline and explain why.
"""
    else:
        raise HTTPException(status_code=400, detail="mode must be 'tighten' or 'guardrails'")

    fallback = get_agent(role)["name"]
    return {"role": role, "mode": req.mode,
            "proposed_soul": proposed, "unchanged": proposed == current,
            # sectioned view of the proposal so the builder can show
            # per-section accept/reject diffs
            "proposed_sections": personas.parse_soul(proposed, fallback),
            "current_sections": personas.parse_soul(current, fallback)}


# ── Agent memory — the ENGINE's, proxied ─────────────────────────
#
# Memory is the one thing that is deliberately NOT in the database: it is
# accumulated per host, hydration preserves `memory/` and never sources it,
# and `studio_agent_defs` excludes it precisely so one pod's learnings cannot
# overwrite another's. So these two endpoints cannot be migrated — they can
# only be moved to the process that owns the file. They forward to the engine
# web API, the same rail `POST /sessions` and `run_proxy` already use.
#
# Reading the API pod's own filesystem was never right and on a split
# deployment was never anything: the path resolved under a home directory the
# engine does not write, so a clear reported success and cleared nothing.

def _engine_memory(role: str, method: str) -> dict:
    _agent_record(role)          # 404 for a role this workspace does not show
    from app.engine_routing import engine_json
    return engine_json(
        method, f"/api/agents/{role}/memory",
        purpose="agent memory lives on the engine host, not here")


@router.get("/agents/{role}/memory")
def get_agent_memory(role: str):
    return _engine_memory(role, "GET")


@router.delete("/agents/{role}/memory")
def clear_agent_memory(role: str):
    """Guarded reset of accumulated memory (explicit user action in the UI)."""
    return _engine_memory(role, "DELETE")


class ChatRequest(BaseModel):
    message: str
    # Try-it against the CALLER's draft. The author is NEVER taken from the
    # body — the engine has no auth, so the API stamps the verified identity
    # on (draft_save._author); a client-sent author field is ignored.
    draft: bool = False


def _post_engine_json(url: str, payload: dict, headers: dict[str, str],
                      timeout: float) -> tuple[int, dict]:
    """One JSON POST to the engine: ``(status, body)``.

    A transport error is a body with an ``error`` key and status 0, an HTTP
    error is its status and whatever the engine said, and a timeout is the
    one thing raised - the caller answers 504 for it rather than waiting
    twice. Everything above this reads status and body; nothing above it
    opens a socket, which is what makes the chat path testable without one.
    """
    import urllib.error
    import urllib.request

    def _loads(raw: bytes) -> dict:
        text = raw.decode("utf-8", errors="replace")
        try:
            parsed = json.loads(text)
        except ValueError:
            return {"error": text[:200]}
        return parsed if isinstance(parsed, dict) else {"error": "non-object response"}

    request = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", **headers}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as r:
            return r.status, _loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            body = _loads(e.read())
        except Exception:  # noqa: BLE001
            body = {}
        return e.code, body or {"error": f"HTTP {e.code} {e.reason}"}
    except TimeoutError:
        raise
    except urllib.error.URLError as e:
        if isinstance(e.reason, TimeoutError):
            raise TimeoutError(str(e.reason)) from e
        return 0, {"error": str(e.reason)}
    except (OSError, ValueError) as e:
        return 0, {"error": str(e)}


def _adhoc_chat_fallback(role: str, req: "ChatRequest",
                         draft_author: str | None = None) -> dict:
    """Engine ad-hoc chat (POST /api/chat/{name} on the gateway) for agents
    with no completed step — the in-process AgentLoop path. AgentPool.get()
    runs ensure_iobot_agent, so hydration covers a fresh host.

    ``draft_author`` routes the turn to the engine's DRAFT pool: the agent
    home resolved is base ⊕ that author's drafts, and nobody else's session
    is touched."""
    import json as _json
    import urllib.error
    import urllib.request

    from app.engine_routing import rail_headers, mark_engine_seen

    ws_code = _active_workspace()
    payload = {"content": req.message, "agent": role,
               "sender_id": "studio",
               "user_id": f"studio:{draft_author}" if draft_author
               else "ui:studio",
               "workspace": ws_code}
    if draft_author:
        payload["draft_author"] = draft_author
    body = _json.dumps(payload).encode("utf-8")
    # The tenant's routed engine first; the legacy local port loop stays as
    # the single-host fallback (stale-registry second instance included).
    from app.engine_routing import engine_for
    candidates = [engine_for(ws_code)]
    for port_env, default in (("GATEWAY_PORT", "8111"),
                              ("IOF_STUDIO_GATEWAY_PORT", "8112")):
        port = os.environ.get(port_env, default)
        base = f"http://127.0.0.1:{port}"
        if base not in candidates:
            candidates.append(base)
    # EVERY CANDIDATE'S ERROR, ATTRIBUTED TO IT. `last_err` kept only the
    # final attempt, and the final attempt is the legacy fallback port where
    # nothing is listening - so a routed engine answering 409 "this engine
    # serves workspace 'x'" was reported to the caller as "No connection
    # could be made because the target machine actively refused it". The
    # diagnosis that reaches a person then points at the wrong machine and
    # the wrong problem.
    errors: list[str] = []
    for base in candidates:
        try:
            r = urllib.request.urlopen(
                urllib.request.Request(
                    f"{base}/api/chat/studio", data=body,
                    headers={"Content-Type": "application/json",
                             **rail_headers()}),
                timeout=180)
            data = _json.loads(r.read().decode("utf-8", errors="replace"))
            reply = (data.get("content") or "").strip()
            if data.get("error"):
                errors.append(f"{base}: {data['error']}")
                continue
            if reply:
                if base == candidates[0]:
                    mark_engine_seen(ws_code)
                return {"role": role, "run_id": None, "step_key": None,
                        "reply": reply, "via": "adhoc",
                        # what answered: stamp + draft items (engine-computed)
                        "provenance": data.get("provenance")}
            errors.append(f"{base}: empty reply")
        except urllib.error.HTTPError as e:
            # The STATUS LINE says almost nothing ("HTTP Error 409:
            # Conflict"); the engine's own message is in the body, and it is
            # the one that names the workspace mismatch.
            try:
                detail = e.read().decode("utf-8", errors="replace")[:200]
            except Exception:  # noqa: BLE001
                detail = ""
            errors.append(f"{base}: HTTP {e.code} {detail or e.reason}")
            continue
        except (urllib.error.URLError, OSError, ValueError, TimeoutError) as e:
            errors.append(f"{base}: {e}")
            continue
    tried = "; ".join(errors)[:600] if errors else "no engine reachable"
    raise HTTPException(
        status_code=502,
        detail=f"ad-hoc chat failed for '{role}'; tried {tried}")


@router.post("/agents/{role}/chat")
def chat_with_agent(role: str, req: ChatRequest,
                    identity: Identity = Depends(require_member)):
    """Talk to an agent via its latest completed step (engine agent-chat path).

    Agents with no completed step fall back to the engine's ad-hoc chat
    (in-process AgentLoop) — that path runs ensure_iobot_agent, whose
    materialize-on-use hook hydrates the workspace from ``studio_agent_defs``
    on a host that has never seen the agent's files.

    ``draft: true`` is Try-it: ALWAYS the ad-hoc path, with the verified
    caller as ``draft_author`` — the run/step reuse path answers from the
    shared home, which never resolves a draft."""
    from app.database import get_db, q as _q
    if req.draft:
        _agent_record_or_draft(role, identity)   # 404 unless base or own draft
        return _adhoc_chat_fallback(role, req, draft_author=identity.email)
    # The hydration call that used to be here is gone. It materialised the
    # agent into THIS process's agent home so the engine would find it — which
    # only ever worked because the two shared a disk. Both paths below reach
    # the engine over HTTP, and both run `ensure_iobot_agent` there, whose
    # materialize-on-use hook hydrates from `studio_agent_defs` on the host
    # that is actually going to run the agent.
    _agent_record(role)           # 404 for a role this workspace does not show
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            _q("SELECT s.run_id, s.step_key FROM steps s "
               "WHERE s.role=? AND s.status='done' "
               "ORDER BY s.updated_at DESC LIMIT 1"),
            (role,),
        )
        row = cursor.fetchone()
    if not row:
        return _adhoc_chat_fallback(role, req)

    ws_code = _active_workspace()

    # THE RUN-CONTEXT TURN IS ONE HTTP CALL, MADE HERE. This path used to
    # shell out to `ioagentfarm agent-chat`, a process that opens the
    # database, stamps every installed pack for its mode banner, and then
    # makes the same POST this function can make itself. Measured
    # 2026-09-05 against a closed port, so no model turn included: 3.3-3.5s
    # of start-up on EVERY chat turn. Worse than the wait: the API pod of
    # the split deployment has no engine install, so `_iof_bin()` had
    # nothing to run there, and the run's context was lost on every turn -
    # silently, through the fallback below. Before that, the child resolved
    # its engine from the ambient IOF_RUN_API_URL over the `--port` it was
    # given, so one BFF variable sent every workspace's chat to one engine.
    #
    # The rail (`run_proxy.py`) already reaches this exact endpoint over
    # HTTP, workspace-routed and authenticated. This is that call, in
    # process: one routing rule (`engine_for`), one header builder
    # (`rail_headers`), no environment handed to a child, and a remote
    # engine is reached the same way as a local one - the localhost-only
    # gate that used to sit here existed only because the CLI could not
    # follow the routing.
    from app.engine_routing import engine_for, mark_engine_seen, rail_headers
    engine_base = engine_for(ws_code)
    payload = {"content": req.message, "role": role, "sender_id": "ui:studio"}

    def _chat_via(base: str) -> tuple[int, dict]:
        # The engine's session-aware /api/run/{id}/message: the step's own
        # session, so the reply carries the run's context.
        return _post_engine_json(
            f"{base.rstrip('/')}/api/run/{row['run_id']}/message",
            payload, rail_headers(), timeout=180)

    try:
        status, data = _chat_via(engine_base)
        # Stale-registry fallback: a long-lived engine web API that predates
        # the studio pack cannot resolve Studio-created roles ("Agent
        # workspace template not found"). A second engine instance started
        # AFTER the pack install (IOF_STUDIO_GATEWAY_PORT, default 8112)
        # resolves them; same DB, same workspaces — the documented
        # horizontally-scaled deployment shape. Existing roles keep using
        # the routed engine; the fallback fires ONLY on this exact failure,
        # and reaches the second instance on the SAME host as the routed one.
        if "workspace template not found" in json.dumps(data).lower():
            from urllib.parse import urlsplit
            routed = urlsplit(engine_base)
            studio_port = os.environ.get("IOF_STUDIO_GATEWAY_PORT", "8112")
            status, data = _chat_via(
                f"{routed.scheme or 'http'}://{routed.hostname or '127.0.0.1'}:{studio_port}")
    except TimeoutError:
        raise HTTPException(status_code=504, detail="agent-chat timed out")
    reply = (data.get("content") or "").strip()
    if status >= 400 or data.get("error") or not reply:
        # A STALE RUN MADE THE AGENT UNCHATTABLE. This path exists to continue
        # the session of the agent's newest completed STEP, which is the right
        # thing when that run is recent - the reply carries its context. But
        # the row is only ever "newest done step for this role", with no
        # bound on age, and the engine then tries to resume a session whose
        # artifacts may be weeks old and long gone. Observed live: the Studio
        # test panel answered 502 for `pharma_domain_analyst` while resuming
        # a run from seventeen days earlier, and the engine's ad-hoc chat -
        # one HTTP call away, already used as the fallback for an agent with
        # NO completed step - answered correctly as Maya in five seconds.
        #
        # So failure here falls through to that path rather than out to the
        # caller. The lost context is the point of the degradation and is
        # worth saying out loud in the log; a dead test panel is not.
        why = data.get("error") or data.get("detail") or ("empty reply" if not reply else "")
        logger.warning(
            "run-context chat via run %s failed for %s (HTTP %s): %s - falling "
            "back to the engine's ad-hoc chat, without that run's context",
            row["run_id"], role, status, str(why)[:200].replace("\n", " "))
        return _adhoc_chat_fallback(role, req)
    mark_engine_seen(ws_code)
    return {"role": role, "run_id": row["run_id"], "step_key": row["step_key"],
            "reply": reply, "via": "run", "provenance": data.get("provenance")}


# ── Workflows — the engine DB is the single source of truth ─────
#
# List/detail reads resolve from `studio_workflow_defs` ONLY (see
# app/workflow_defs.py). Disk is touched in exactly two places:
#   * POST /workflows/sync — the one-time import of pack files into the DB
#   * _materialize_override() — REGENERATING the engine-format override dir
#     FROM the DB record after a create/edit (the engine executes from
#     files; the file tree is a derived artifact, never a display source).

def _ws() -> str:
    """The request's tenant workspace code (middleware-resolved; the DB
    decides what each workspace shows — no client-side filtering)."""
    from app.workspace_context import active_code
    return active_code()


def _override_dir(name: str, workspace_code: str) -> Path:
    """Derived engine-format tree for a stored workflow definition.

    A tenant's tree is <IOF_ROOT>/workspaces/<code>/workflows/<name>, which
    the engine's WorkflowLoader resolves when given the workspace code
    (mirrors hydration.workflow_override_dir). The platform tier's tree is
    the unscoped <IOF_ROOT>/workflows/<name> override layer — internal, and
    never reachable from a request (active_code() cannot return it)."""
    from ioagentfarm.engine.workspaces import PLATFORM_TIER

    root = get_settings().iof_root
    if workspace_code == PLATFORM_TIER:
        return root / "workflows" / name
    return root / "workspaces" / workspace_code / "workflows" / name


class WorkflowSave(BaseModel):
    yaml: str
    files: dict[str, str] = {}    # e.g. {"steps/analyze.md": "..."}


def _validate_rel_paths(files: dict[str, str]) -> None:
    for rel in files:
        rel_path = Path(rel)
        if rel_path.is_absolute() or ".." in rel_path.parts:
            raise HTTPException(status_code=400, detail=f"illegal path: {rel}")


def _materialize_override(name: str, workspace_code: str) -> None:
    """Regenerate the derived override tree FROM the stored DB record.

    Called after every DB write — the engine still executes from files, so
    the override tree is rebuilt as a derived artifact of the record."""
    row = workflow_defs.get_def(name, workspace_code)
    if not row:
        return
    target = _override_dir(name, workspace_code)
    shutil.rmtree(target, ignore_errors=True)
    target.mkdir(parents=True, exist_ok=True)
    (target / "workflow.yaml").write_text(row["yaml"], encoding="utf-8")
    files = workflow_defs.def_files(row)
    for rel, content in files.items():
        rel_path = Path(rel)
        if rel_path.is_absolute() or ".." in rel_path.parts:
            continue  # validated at write time; belt-and-braces on replay
        dest = target / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")
    # Anchor the tree with a materialize-on-use stamp so this host's next
    # run-creation pull is a no-op (other hosts pull the row themselves).
    try:
        from ioagentfarm.engine import hydration as _hyd
        _hyd._write_stamp(target, "workflow", row.get("version"),
                          _hyd.workflow_content_hash(row["yaml"], files))
    except Exception:
        logger.debug("stamp write skipped for %s", name, exc_info=True)


@router.post("/workflows/sync")
def studio_sync_workflows():
    """Import the installed pack workflows into the DB store — ON THE ENGINE.

    A THIN PROXY, not an implementation. Reading pack workflow files is the
    same defect as the agent home one layer over: it needs the packs, and the
    API pod has none. Worse, the reader it used globbed
    ``IOF_AGENTFARM_DIR/solutions/*/*/*/workflows/*/workflow.yaml`` — a REPO
    LAYOUT, so it only ever found anything on a developer's checkout and
    silently synced nothing from an installed wheel.

    The engine owns this now (``POST /api/workflows/defs/sync``, and
    ``ioagentfarm sync`` without a running server). The route stays because
    the Studio calls it; the second implementation is gone.

    Tenant-aware: a workspace with a scoping row imports only its
    DB-declared packs (``studio_workspace_settings``); one without a row
    imports the full installed catalog. Curate afterwards with
    DELETE /api/studio/workflows/defs/{code}."""
    ws = _ws()
    from app import workspace_settings
    packs = workspace_settings.packs_for(ws)
    # No scoping row -> import nothing, same as before for every real
    # tenant (the full-catalog import belongs to the engine's own
    # `ioagentfarm sync`, which targets the platform tier).
    include: list[str] = packs["include"] if packs else []
    body = _engine_json("POST", "/api/workflows/defs/sync",
                        json={"workspace_code": ws, "include_packs": include})
    # One Truth s4.5: the Studio LISTS the engine catalog directly now, so
    # whatever the engine imported into `studio_workflow_defs` is not what
    # the list reads. The route stays (the UI calls it) and says so.
    body = dict(body) if isinstance(body, dict) else {"result": body}
    body["message"] = ("nothing to sync — the Studio reads the workflow "
                       "catalog from the engine (GET /api/catalog/workflows)")
    return body


@router.delete("/workflows/defs/{code}")
def studio_delete_workflow_def(code: str):
    """Prune a workflow definition from the catalog (deployment curation).

    Also removes the derived override directory so the DB and the engine's
    file layer cannot disagree. Pack files are untouched — a pruned pack
    workflow can be re-imported any time by running sync again."""
    ws = _ws()
    row = workflow_defs.get_def(code, ws)
    if not row:
        raise HTTPException(
            status_code=404,
            detail=f"Workflow definition '{code}' is not in the engine DB")
    workflow_defs.delete_def(code, ws)
    removed_dir = False
    if (_override_dir(code, ws) / "workflow.yaml").exists():
        shutil.rmtree(_override_dir(code, ws), ignore_errors=True)
        removed_dir = True
    return {"deleted": code, "source": row["source"],
            "removed_override_dir": removed_dir}


def _draft_workflow_item(name: str, draft: dict) -> dict:
    """A catalog-item shape for a workflow that exists only as the caller's
    draft — same keys ``workflow_catalog`` items carry."""
    files = engine_drafts.overlay({}, draft.get("files"))
    return {
        "name": name,
        "yaml": files.get("workflow.yaml", ""),
        "files": {k: v for k, v in files.items() if k != "workflow.yaml"},
        "source": "draft", "source_path": f"db:content_drafts/{draft['id']}",
        "solution": "", "pack": "", "stamp": None, "unpromoted": True,
        "synced_at": None, "updated_at": draft.get("updated_at"),
    }


def _workflow_summary(item: dict) -> dict:
    try:
        parsed = workflow_defs.parse_studio_workflow(item["yaml"], item["name"])
    except Exception as e:  # malformed stored def must still be listable
        parsed = {"name": item["name"], "description": f"(parse error: {e})",
                  "team": [], "roles": [], "vars": {}, "steps": []}
    parsed.update({
        "editable": item["unpromoted"],
        "shadows_pack": False,
        "source": item["source"],
        "step_count": len(parsed["steps"]),
        "stamp": item["stamp"],
        "unpromoted": item["unpromoted"],
        "solution": item.get("solution") or "",
    })
    return parsed


@router.get("/workflows")
def studio_list_workflows(response: Response,
                          identity: Identity = Depends(require_member)):
    """Workflow catalog — the ENGINE's installed packs, plus the tenant's
    own unpromoted definitions (add-only) and the caller's own new-item
    drafts. 502 when the engine is down."""
    from app import workflow_catalog
    ws = _ws()
    grouped = app_drafts.for_kind(ws, "workflow")
    out = []
    for item in workflow_catalog.list_workflows(ws):
        out.append(_attach_drafts(_workflow_summary(item), "workflow",
                                  item["name"], identity, grouped))
    listed = {w["name"] for w in out}
    for name in sorted(grouped):
        if name in listed:
            continue
        mine = app_drafts.caller_draft(grouped, name, identity.email)
        if mine is None:
            continue
        out.append(_attach_drafts(
            _workflow_summary(_draft_workflow_item(name, mine)),
            "workflow", name, identity, grouped))
    response.headers["X-Catalog-Source"] = "engine"
    return out


@router.get("/workflows/{name}")
def studio_get_workflow(name: str,
                        identity: Identity = Depends(require_member)):
    """Workflow detail — the engine's pack files, the tenant's own
    unpromoted definition, or (for its author alone) a new-item draft."""
    from app import workflow_catalog
    item = workflow_catalog.get_workflow(name, _ws())
    if not item:
        mine = app_drafts.find(_ws(), "workflow", name, identity.email)
        if mine is None:
            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{name}' is not in the engine catalog for this "
                       f"workspace, and the workspace holds no definition of "
                       f"its own. {workflow_defs.EMPTY_HINT}")
        item = _draft_workflow_item(name, mine)
    try:
        parsed = workflow_defs.parse_studio_workflow(item["yaml"], name)
    except Exception as e:
        parsed = {"name": name, "description": f"(parse error: {e})",
                  "team": [], "roles": [], "vars": {}, "steps": []}
    parsed.update({
        "yaml": item["yaml"],
        "files": item["files"],
        "editable": item["unpromoted"],
        "shadows_pack": False,
        "source": item["source"],
        "source_path": item["source_path"],
        "synced_at": item.get("synced_at"),
        "updated_at": item.get("updated_at"),
        "stamp": item["stamp"],
        "unpromoted": item["unpromoted"],
        "solution": item.get("solution") or "",
    })
    return _attach_drafts(parsed, "workflow", name, identity, full=True)


#: Box-drawing and ANSI noise Rich emits around a traceback frame.
_RICH_NOISE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]|[─-╿]")
#: The line that actually says what is wrong.
_EXC_LINE = re.compile(
    r"^\s*(?:[\w.]+\.)?(\w*(?:Error|Exception)):\s*(?P<msg>.+?)\s*$")


def dry_run_reason(output: str) -> str:
    """The one sentence a person needs, out of a ~40-line Python traceback.

    A bad workflow YAML surfaced in the Studio as the raw stderr of
    ``ioagentfarm run --dry-run``: Rich box-drawing, every frame, and absolute
    source paths from the API host — with the only useful line
    (``ValueError: step 'x' references role 'no_such_agent'``) at the very
    bottom, and the top of the blob cut mid-word by a tail slice. It read as a
    crash in the product rather than a mistake in the user's file.

    Takes the LAST exception line, because that is the innermost raise — the
    one describing the actual problem, not the wrapper. Falls back to the last
    meaningful line, then to the trimmed tail, so an error shape we have not
    seen still says something rather than nothing.
    """
    clean = [_RICH_NOISE.sub("", ln).strip()
             for ln in (output or "").splitlines()]
    clean = [ln for ln in clean if ln]
    for ln in reversed(clean):
        m = _EXC_LINE.match(ln)
        if m and m.group("msg"):
            return m.group("msg")
    for ln in reversed(clean):
        # skip pure traceback scaffolding
        if ln.startswith(("File \"", "Traceback", "during handling", "The above")):
            continue
        return ln[:400]
    return "the engine rejected this workflow but gave no reason"


def _dry_run(name: str, workspace: str) -> tuple[bool, str]:
    """Engine-validate a workflow, in its own tenant tree.

    `--workspace` makes the engine resolve the override tree the studio just
    materialized (`<IOF_ROOT>/workspaces/<code>/workflows/`). Always passed:
    the engine refuses to invent a workspace, and validating in an
    unspecified tree would validate content the tenant cannot see.
    """
    cmd = [_iof_bin(), "run", name, "--goal", "studio validation", "--dry-run",
           "--workspace", workspace]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            env=_engine_env(workspace), timeout=90,
        )
    except subprocess.TimeoutExpired:
        return False, "dry-run timed out"
    ok = result.returncode == 0 and "Traceback" not in (result.stderr or "")
    return ok, (result.stdout or "") + (result.stderr or "")


def _workflow_save_response(name: str, identity: Identity,
                            validation: dict | None) -> dict:
    detail = studio_get_workflow(name, identity)
    detail["saved_as"] = "draft"
    # None = the engine does not expose draft validation yet — saved anyway,
    # honestly labelled, so an older engine never blocks the only edit path.
    detail["validated"] = None if validation is None \
        else bool(validation.get("valid", True))
    detail["findings"] = (validation or {}).get("findings") or []
    if validation is None:
        detail["validation_message"] = (
            "this engine does not validate drafts yet "
            "(POST /api/catalog/drafts/validate is absent) — the draft was "
            "saved unvalidated")
    return detail


@router.post("/workflows", status_code=201)
def studio_create_workflow(req: WorkflowSave,
                           identity: Identity = Depends(require_member)):
    """Author a workflow — as the caller's DRAFT (One Truth s3.5). Nothing
    is materialised on this pod: validation runs on the ENGINE, where the
    packs and the loader are."""
    try:
        data = yaml.safe_load(req.yaml)
        name = data["name"]
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"invalid YAML: {e}")
    if not ROLE_RE.match(name.replace("-", "_")):
        raise HTTPException(status_code=400, detail="workflow name must be a slug")
    _validate_rel_paths(req.files)
    ws = _ws()
    from app import engine_catalog
    if engine_catalog.workflow_detail(name, ws) is not None:
        raise HTTPException(
            status_code=409,
            detail=f"workflow '{name}' ships with an installed pack — open "
                   f"it in the studio to draft an edit instead")
    prior = workflow_defs.get_def(name, ws)
    if prior and prior["source"] == "studio":
        raise HTTPException(
            status_code=409,
            detail=f"workflow '{name}' already exists — open it in the studio "
                   f"to edit it, or delete its definition first "
                   f"(DELETE /api/studio/workflows/defs/{name})")
    if app_drafts.find(ws, "workflow", name, identity.email):
        raise HTTPException(
            status_code=409,
            detail=f"You already have a draft named '{name}' — open it in "
                   f"the studio to keep editing, or discard it first.")
    _, validation = draft_save.save_workflow(ws, identity, name, req.yaml,
                                             req.files)
    return _workflow_save_response(name, identity, validation)


@router.put("/workflows/{name}")
def studio_save_workflow(name: str, req: WorkflowSave,
                         identity: Identity = Depends(require_member)):
    """Save a workflow edit — as the caller's DRAFT. A pack workflow pins
    the engine's files as the base; a legacy Studio row seeds a new-item
    draft and the row is never written again."""
    _validate_rel_paths(req.files)
    try:
        data = yaml.safe_load(req.yaml)
        yaml_name = data["name"]
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"invalid YAML: {e}")
    if yaml_name != name:
        raise HTTPException(
            status_code=400,
            detail=f"the definition's `name:` is '{yaml_name}' but you are "
                   f"editing '{name}' — the name cannot change on save")
    ws = _ws()
    from app import engine_catalog
    known = engine_catalog.workflow_detail(name, ws) is not None \
        or workflow_defs.get_def(name, ws) is not None \
        or app_drafts.find(ws, "workflow", name, identity.email) is not None
    if not known:
        raise HTTPException(
            status_code=404,
            detail=f"Workflow '{name}' is not in the engine catalog. "
                   f"Create it first, or {workflow_defs.EMPTY_HINT}")
    _, validation = draft_save.save_workflow(ws, identity, name, req.yaml,
                                             req.files)
    return _workflow_save_response(name, identity, validation)


@router.post("/workflows/{name}/validate")
def studio_validate_workflow(name: str):
    ok, output = _dry_run(name, _ws())
    return {"name": name, "valid": ok, "dry_run": output[-3000:]}


# ── Run telemetry ────────────────────────────────────────────────

@router.get("/runs/{run_id}/usage")
def run_usage(run_id: str):
    """Per-session token usage from the engine's native AgentHook capture."""
    if not RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=400, detail="bad run id")
    path = get_settings().iof_root / "instances" / run_id / "usage.jsonl"
    if not path.exists():
        return {"run_id": run_id, "available": False, "sessions": [],
                "totals": {"calls": 0, "input": 0, "output": 0, "total": 0}}
    sessions: dict[str, dict] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        key = str(rec.get("session", "?"))
        # compress iof:<run>:<step>:u:<uid> to the step portion
        m = re.match(r"^iof:[^:]+:(.+?):u:", key)
        label = m.group(1) if m else key
        s = sessions.setdefault(label, {"session": label, "calls": 0,
                                        "input": 0, "output": 0,
                                        "cache_read": 0, "cache_write": 0})
        s["calls"] += 1
        s["input"] += int(rec.get("in", 0) or 0)
        s["output"] += int(rec.get("out", 0) or 0)
        s["cache_read"] += int(rec.get("cr", 0) or 0)
        s["cache_write"] += int(rec.get("cw", 0) or 0)
    rows = sorted(sessions.values(), key=lambda s: -(s["input"] + s["output"]))
    for r in rows:
        r["total"] = r["input"] + r["output"]
    totals = {
        "calls": sum(r["calls"] for r in rows),
        "input": sum(r["input"] for r in rows),
        "output": sum(r["output"] for r in rows),
    }
    totals["total"] = totals["input"] + totals["output"]
    return {"run_id": run_id, "available": True, "sessions": rows, "totals": totals}


# ── Run agent sessions (per-step iobot session mapping) ────────
#
# Engine runs don't have vantive-style chat sessions: each agent step's LLM
# dialog lives in the forensic session snapshot at
#   <IOF_ROOT>/instances/<run_id>/forensics/attempts/<step>.<n>/session-snapshot.jsonl
# (dir name = step_key with ":" and "/" sanitized to "_", one dir per attempt —
# mirrors cli_orchestration.py). These endpoints map a run to those per-step
# sessions so the UI conversation view can render real agent dialog.

def _attempts_root(run_id: str) -> Path:
    return get_settings().iof_root / "instances" / run_id / "forensics" / "attempts"


def _sanitize_step(step_key: str) -> str:
    """Same sanitization the engine applies to forensic attempt dir names."""
    return step_key.replace(":", "_").replace("/", "_")


def _latest_snapshot(attempts: Path, step_key: str) -> tuple[Path | None, int]:
    """Latest attempt's session-snapshot.jsonl for a step (None if absent)."""
    prefix = _sanitize_step(step_key) + "."
    best: Path | None = None
    best_n = 0
    if not attempts.is_dir():
        return None, 0
    for d in attempts.iterdir():
        if not (d.is_dir() and d.name.startswith(prefix)):
            continue
        suffix = d.name[len(prefix):]
        if not suffix.isdigit():
            continue
        snap = d / "session-snapshot.jsonl"
        if snap.is_file() and snap.stat().st_size > 0 and int(suffix) >= best_n:
            best, best_n = snap, int(suffix)
    return best, best_n


def _parse_session_snapshot(snap: Path, max_text: int = 6000,
                            max_tool: int = 700) -> list[dict]:
    """Parse a iobot session JSONL into UI-ready messages.

    Records: metadata line (skipped), user/assistant (text content),
    tool results ({role: tool, name, content}). Tool args are collapsed —
    assistant messages carry only the invoked tool *names*; tool results
    are truncated to a preview.
    """
    messages: list[dict] = []
    for line in snap.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        role = rec.get("role")
        if rec.get("_type") == "metadata" or role not in ("user", "assistant", "tool"):
            continue
        content = rec.get("content")
        if isinstance(content, list):  # anthropic-style block list
            content = "\n".join(
                str(b.get("text", "")) for b in content
                if isinstance(b, dict) and b.get("type") in (None, "text"))
        text = (content or "").strip()
        limit = max_tool if role == "tool" else max_text
        msg: dict = {
            "role": role,
            "text": text[:limit],
            "truncated": len(text) > limit,
            "timestamp": rec.get("timestamp"),
        }
        if role == "assistant":
            msg["tool_calls"] = [
                fn for fn in (
                    ((tc or {}).get("function") or {}).get("name")
                    for tc in (rec.get("tool_calls") or [])
                ) if fn
            ]
        elif role == "tool":
            msg["tool"] = rec.get("name", "")
        messages.append(msg)
    return messages


def _run_step_rows(run_id: str) -> list[dict]:
    """Step rows (step_key, role, status) from the shared engine DB."""
    from app.database import get_db, q as _q
    try:
        with get_db() as con:
            cur = con.cursor()
            cur.execute(
                _q("SELECT step_key, role, status FROM steps "
                   "WHERE run_id=? ORDER BY seq"),
                (run_id,),
            )
            return [dict(r) for r in cur.fetchall()]
    except Exception as e:  # DB down — fall back to disk scan
        logger.warning("run_sessions: step query failed for %s: %s", run_id, e)
        return []


@router.get("/runs/{run_id}/sessions")
def run_sessions(run_id: str):
    """Per-step agent sessions of a run: step_key, role, calls, messages."""
    if not RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=400, detail="bad run id")
    attempts = _attempts_root(run_id)
    steps = _run_step_rows(run_id)
    if not steps and attempts.is_dir():
        # disk-only fallback: reconstruct step keys from attempt dir names
        seen: dict[str, None] = {}
        for d in sorted(attempts.iterdir()):
            if d.is_dir() and "." in d.name and (d / "session-snapshot.jsonl").is_file():
                seen.setdefault(d.name.rsplit(".", 1)[0], None)
        steps = [{"step_key": k, "role": "", "status": ""} for k in seen]

    sessions = []
    for s in steps:
        snap, attempt = _latest_snapshot(attempts, s["step_key"])
        if not snap:
            continue  # exec/system steps and never-spawned steps have no session
        msgs = _parse_session_snapshot(snap)
        sessions.append({
            "step_key": s["step_key"],
            "role": s.get("role", ""),
            "status": s.get("status", ""),
            "attempt": attempt,
            "calls": sum(1 for m in msgs if m["role"] == "assistant"),
            "message_count": len(msgs),
        })
    return {"run_id": run_id, "available": bool(sessions), "sessions": sessions}


@router.get("/runs/{run_id}/sessions/{step_key:path}/messages")
def run_session_messages(run_id: str, step_key: str, attempt: int = 0):
    """Parsed messages of one step's agent session (latest attempt default)."""
    if not RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=400, detail="bad run id")
    attempts = _attempts_root(run_id)
    if attempt > 0:
        snap = attempts / f"{_sanitize_step(step_key)}.{attempt}" / "session-snapshot.jsonl"
        if not (snap.is_file() and snap.stat().st_size > 0):
            snap = None
        used_attempt = attempt
    else:
        snap, used_attempt = _latest_snapshot(attempts, step_key)
    if not snap:
        raise HTTPException(
            status_code=404,
            detail=f"No session snapshot for step '{step_key}' in {run_id}")
    role = next((s.get("role", "") for s in _run_step_rows(run_id)
                 if s["step_key"] == step_key), "")
    messages = _parse_session_snapshot(snap)
    return {
        "run_id": run_id,
        "step_key": step_key,
        "role": role,
        "attempt": used_attempt,
        "count": len(messages),
        "messages": messages,
    }


# ── streamed chat: Maya's thinking, while she thinks ─────────────────────
#
# THE TEST PANEL WAS DEAD SILENT FOR THE WHOLE TURN. `chat_with_agent` is a
# blocking POST: the browser learns nothing until the agent has finished, so
# a 40-second turn is 40 seconds of nothing, and the reader cannot tell a
# working agent from a hung one. That is the single worst thing about the
# surface, and it was never a missing engine capability - the engine has
# offered `POST /api/chat/{ns}/stream` all along, emitting `status` events
# while the agent works and `delta` events carrying text as it arrives.
# Nothing in the Studio called it.
#
# This is a passthrough, deliberately: the engine owns what a turn IS and
# what its frames mean. The BFF owns only that the browser talks to one
# origin, and that the stream is not buffered on the way through.


@router.post("/agents/{role}/chat/stream")
async def chat_with_agent_streamed(role: str, req: ChatRequest,
                                   identity: Identity = Depends(require_member)):
    """The same turn as ``/chat``, streamed as Server-Sent Events.

    Frames are the engine's, forwarded verbatim: ``status`` while the agent
    works, ``delta`` as text arrives, one final ``message`` whose payload is
    exactly what the non-streaming route returns - so a caller that already
    handles ``/chat`` needs only to read the last frame.
    """
    import json as _json

    import httpx

    from app.engine_routing import engine_for, mark_engine_seen, rail_headers

    if req.draft:
        _agent_record_or_draft(role, identity)
        author = identity.email if identity else None
    else:
        _agent_record(role)
        author = None

    ws_code = _active_workspace()
    payload = {"content": req.message, "agent": role, "sender_id": "studio",
               "user_id": f"studio:{author}" if author else "ui:studio",
               "workspace": ws_code}
    if author:
        payload["draft_author"] = author

    url = f"{engine_for(ws_code)}/api/chat/{role}/stream"
    headers = {"Content-Type": "application/json"}
    headers.update(rail_headers())

    async def body():
        try:
            # No read timeout: a turn legitimately takes minutes, and the
            # whole point of this route is that the reader sees it working.
            async with httpx.AsyncClient(timeout=None) as client:
                async with client.stream("POST", url, headers=headers,
                                         content=_json.dumps(payload)) as up:
                    if up.status_code >= 400:
                        text = (await up.aread()).decode("utf-8", "replace")
                        yield _sse("error", {"detail": text[:400]})
                        return
                    async for chunk in up.aiter_raw():
                        yield chunk
        except httpx.HTTPError as exc:
            logger.warning("chat stream proxy to %s failed: %s", url, exc)
            yield _sse("error", {"detail": f"engine unreachable: {exc}"})

    mark_engine_seen(ws_code)
    return StreamingResponse(body(), media_type="text/event-stream", headers={
        # Without these a proxy in front of this route re-buffers the stream
        # into exactly the silence it exists to remove.
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    })


def _sse(event: str, data: dict) -> bytes:
    import json as _json
    return f"event: {event}\ndata: {_json.dumps(data)}\n\n".encode("utf-8")
