"""Playbook Templates — read-only catalog of the REUSABLE plays.

Read-only router over the barrier_signal hub Postgres schema (connection from
``BARRIER_SIGNAL_DB_URL``, schema from ``BARRIER_SIGNAL_DB_SCHEMA`` — both
resolved at REQUEST time, matching source_data.py/signals.py). Powers the
Operational Insights "Playbook Templates" page.

Why this exists: the Playbooks library shows *generated* plays and the review
queue shows the ones awaiting approval — but the template itself is the
reusable asset the archetype model is built on ("one play, many barriers").
Without a catalog view a business user cannot answer *what plays do we have*,
*which barrier types are covered*, or *what is actually in this play*.

  /                 — catalog: one row per template + usage counts
  /coverage         — the question the catalog really answers: which barrier
                      types have a play and which do NOT (the gap is the
                      actionable part)
  /{template_id}    — detail incl. the full body_md and its slots

NEVER writes to the hub — every statement here is a SELECT.
"""

from __future__ import annotations

import json
import logging
import os
import re
from contextlib import contextmanager

from fastapi import APIRouter, HTTPException
from app import hub_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/playbook-templates",
                   tags=["playbook-templates"])

DEFAULT_HUB_SCHEMA = "savant_data_hub"

#: template_id shape — validated before it reaches a query (defence in depth;
#: the query is parameterized regardless)
_TEMPLATE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


def _hub_schema() -> str:
    return (os.getenv("BARRIER_SIGNAL_DB_SCHEMA") or DEFAULT_HUB_SCHEMA).strip()


@contextmanager
def _hub():
    """Read-only hub cursor — POOLED, shared with the other hub routers.

    Was a private copy that opened and closed a connection per request; see
    app/hub_db.py for why five identical copies became one.
    """
    with hub_db.hub_cursor() as cur:
        yield cur


def _template_id_or_400(template_id: str) -> str:
    if not _TEMPLATE_ID_RE.match(template_id):
        raise HTTPException(status_code=400,
                            detail="template_id must look like TPL-OS-VACANCY")
    return template_id


def _slots(raw) -> list:
    """`slots` is JSONB (psycopg2 hands back a list/dict) but tolerate TEXT."""
    if raw in (None, ""):
        return []
    if isinstance(raw, (list, dict)):
        return raw if isinstance(raw, list) else [raw]
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError):
        return []
    return parsed if isinstance(parsed, list) else [parsed]


def _iso(row: dict) -> dict:
    for k, v in list(row.items()):
        if hasattr(v, "isoformat"):
            row[k] = v.isoformat()
    return row


# ── endpoints (static paths before /{template_id}) ───────────────────

@router.get("")
def catalog():
    """One row per template + how many plays each has produced.

    Usage is counted from ``playbooks`` (plays derived from the template) and
    split generated/reused via ``playbook_barriers.link_reason`` — the
    archetype model's whole point is that one template covers many barriers,
    so the reuse count is the number that shows it working.
    """
    with _hub() as cur:
        cur.execute(
            "SELECT t.template_id, t.name, t.barrier_type, t.trigger_type, "
            "       t.version, t.slots, t.updated_at, "
            "       LENGTH(COALESCE(t.body_md, '')) AS body_chars, "
            "       (SELECT COUNT(*) FROM playbooks p "
            "          WHERE p.template_id = t.template_id) AS play_count, "
            "       (SELECT COUNT(*) FROM playbook_barriers pb "
            "          JOIN playbooks p2 ON p2.playbook_id = pb.playbook_id "
            "         WHERE p2.template_id = t.template_id "
            "           AND pb.link_reason = 'generated') AS generated_links, "
            "       (SELECT COUNT(*) FROM playbook_barriers pb "
            "          JOIN playbooks p3 ON p3.playbook_id = pb.playbook_id "
            "         WHERE p3.template_id = t.template_id "
            "           AND pb.link_reason = 'reused') AS reused_links "
            "  FROM playbook_templates t "
            " ORDER BY t.barrier_type, t.template_id")
        rows = []
        for r in cur.fetchall():
            row = _iso(dict(r))
            slots = _slots(row.pop("slots", None))
            row["slot_count"] = len(slots)
            row["barriers_covered"] = (row["generated_links"]
                                       + row["reused_links"])
            rows.append(row)
    return {
        "count": len(rows),
        "templates": rows,
        "description": ("Reusable plays. A template is authored once per "
                        "archetype (barrier type + trigger) and linked to "
                        "every barrier that matches it — generating a new "
                        "play only when no template fits."),
    }


@router.get("/coverage")
def coverage():
    """Which barrier types have a play — and which do not.

    The universe is the taxonomy (``barrier_type_meta``), which is the single
    authority for valid types. Every type is reported with the barriers
    discovered against it so far, so an uncovered type carrying real barriers
    reads as the actionable gap it is.
    """
    with _hub() as cur:
        cur.execute("SELECT barrier_type, definition FROM barrier_type_meta "
                    "ORDER BY barrier_type")
        taxonomy = [dict(r) for r in cur.fetchall()]
        cur.execute("SELECT barrier_type, COUNT(*) AS n FROM barriers "
                    "GROUP BY barrier_type")
        barrier_counts = {r["barrier_type"]: r["n"] for r in cur.fetchall()}
        cur.execute("SELECT barrier_type, COUNT(*) AS n, "
                    "       STRING_AGG(template_id, ', ' ORDER BY template_id) AS ids "
                    "  FROM playbook_templates GROUP BY barrier_type")
        tpl = {r["barrier_type"]: r for r in cur.fetchall()}

    out = []
    for t in taxonomy:
        bt = t["barrier_type"]
        hit = tpl.get(bt)
        out.append({
            "barrier_type": bt,
            "definition": t.get("definition"),
            "template_count": hit["n"] if hit else 0,
            "template_ids": (hit["ids"].split(", ") if hit and hit["ids"] else []),
            "barrier_count": barrier_counts.get(bt, 0),
            "covered": bool(hit),
        })
    # types with real barriers but no play — the part worth acting on
    gaps = [r for r in out if r["barrier_count"] > 0 and not r["covered"]]
    return {
        "types": out,
        "covered_count": sum(1 for r in out if r["covered"]),
        "type_count": len(out),
        "gap_count": len(gaps),
        "gaps": [r["barrier_type"] for r in gaps],
    }


@router.get("/{template_id}")
def detail(template_id: str):
    """Full template incl. the play body (markdown) and its slots."""
    tid = _template_id_or_400(template_id)
    with _hub() as cur:
        cur.execute(
            "SELECT template_id, name, barrier_type, trigger_type, body_md, "
            "       slots, version, created_at, updated_at "
            "  FROM playbook_templates WHERE template_id = %s", (tid,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404,
                                detail=f"unknown template '{template_id}'")
        out = _iso(dict(row))
        out["slots"] = _slots(out.get("slots"))
        cur.execute(
            "SELECT p.playbook_id, p.barrier_id, p.title, p.status "
            "  FROM playbooks p WHERE p.template_id = %s "
            " ORDER BY p.playbook_id LIMIT 50", (tid,))
        out["plays"] = [dict(r) for r in cur.fetchall()]
    return out
