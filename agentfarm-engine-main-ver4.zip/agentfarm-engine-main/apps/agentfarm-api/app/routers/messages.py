"""Message streaming — poll and SSE endpoints for real-time chat UI.

Nested under ``/api/workflows/{workflow}/sessions/{run_id}/messages``.

SSE Event Contract (for frontend developers)
=============================================

Every SSE event has ``event:`` and ``data:`` (JSON). Event types:

1. **step_update** — step status changed
   ```json
   {"step_key": "spec", "status": "running",
    "agent": {"role": "analyst", "name": "Dana", "title": "Analyst",
              "color": "#7B68EE", "avatar": "DA"}}
   ```

2. **agent_start** — agent began speaking (light up icon)
   ```json
   {"step_key": "spec",
    "metadata": {},
    "agent": {"role": "analyst", "name": "Dana", "title": "Analyst",
              "color": "#7B68EE", "avatar": "DA"}}
   ```
   ``metadata`` is present on every msg-derived event (start/message/end);
   writers may attach payload to any of them.

3. **message** — one line of agent output (append to chat)
   ```json
   {"id": 42, "step_key": "spec", "content": "Analyzing the codebase...",
    "source": "step_output", "timestamp": "2026-03-11T18:16:10",
    "metadata": {},
    "agent": {"role": "analyst", "name": "Dana", "title": "Analyst",
              "color": "#7B68EE", "avatar": "DA"}}
   ```
   ``metadata`` is always present (parsed JSON dict, ``{}`` when empty);
   it carries writer-supplied context (token counts, tool args, etc.).

   For agent chat messages (role ``analyst`` / ``strategist``,
   source=``agent``, msg_type ``output|message|executive_summary``) the
   writer populates ``metadata.split`` to drive the chat-bubble
   progressive-disclosure UI:

   ```json
   "metadata": {
     "split": {
       "summary": "headline / diagnosis (20–60 words)",
       "detail":  "evidence / reasoning (100–200 words)",
       "footer":  "impact + handoff or 'How to drive this' affordance"
     }
   }
   ```

   ``content`` still carries the full cleaned narrative for fallback
   rendering. UI prefers ``metadata.split`` when present.

4. **agent_end** — agent finished speaking (dim icon)
   ```json
   {"step_key": "spec",
    "metadata": {"scorecard": [...], "grade": "A", ...},
    "agent": {"role": "analyst", "name": "Dana", "title": "Analyst",
              "color": "#7B68EE", "avatar": "DA"}}
   ```
   ``metadata`` may carry final-frame payloads (e.g. reviewer scorecard,
   grade, badge). Empty dict when the writer didn't attach anything.

5. **session_end** — run completed
   ```json
   {"run_id": "run_2026...", "status": "done"}
   ```

Message sources (``source`` column):
  - ``step_start``    — agent began a step (maps to agent_start SSE event)
  - ``step_output``   — agent output line (maps to message SSE event)
  - ``agent``         — direct agent message (maps to message SSE event)
  - ``user``          — user-submitted message (maps to message SSE event)
  - ``system``        — system notification (maps to message SSE event)
  - ``task_spawned``  — task was spawned (maps to message SSE event)

Frontend lifecycle per step:
  step_update(running) → agent_start → message* → agent_end → step_update(done)
"""

from __future__ import annotations

import asyncio
import json
import logging

from fastapi import Depends, APIRouter, HTTPException, Request
from sse_starlette.sse import EventSourceResponse

from app.agents import get_agent
from app.config import get_settings
from app.database import get_db, q
from app.authz import require_member

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/workflows/{workflow}/sessions/{run_id}/messages",
    tags=["messages"],
    # GUARDED ON THE ROUTER. This router carried no authentication of
    # any kind: a validator reached it with no bearer token and got
    # 200. A per-route guard is one somebody has to remember on every
    # new route; a router-level one cannot be forgotten.
    dependencies=[Depends(require_member)],
)


def _validate_run(run_id: str, workflow: str) -> None:
    """Raise 404 if run doesn't exist or doesn't belong to the workflow."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT workflow_name FROM runs WHERE id=?"), (run_id,),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"Session '{run_id}' not found")
        if row["workflow_name"] != workflow:
            raise HTTPException(
                status_code=404,
                detail=f"Session '{run_id}' belongs to workflow '{row['workflow_name']}', not '{workflow}'",
            )


def _build_agent(role: str, agent_name: str = "") -> dict:
    """Build agent display object, preferring DB agent_name over registry."""
    agent = get_agent(role)
    if agent_name:
        agent["name"] = agent_name
        agent["avatar"] = agent_name[:2].upper()
    return agent


@router.get("")
def get_messages(
    workflow: str,
    run_id: str,
    after_id: int = 0,
    step_key: str | None = None,
    limit: int = 200,
):
    """Poll messages for a session.

    The client tracks ``last_id`` and passes it as ``after_id`` on the
    next call to receive only new messages.
    """
    _validate_run(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        sql = ("SELECT id, run_id, step_key, role, agent_name, content, msg_type, "
               "source, task_id, user_id, metadata, created_at "
               "FROM messages WHERE run_id=? AND id>?")
        params: list = [run_id, after_id]
        if step_key:
            sql += " AND step_key=?"
            params.append(step_key)
        sql += " ORDER BY id ASC LIMIT ?"
        params.append(limit)
        cursor.execute(q(sql), tuple(params))
        messages = []
        last = after_id
        for r in cursor.fetchall():
            m = dict(r)
            last = m["id"]
            m["agent"] = _build_agent(m["role"], m.get("agent_name", ""))
            meta = m.get("metadata")
            if isinstance(meta, str):
                try:
                    meta = json.loads(meta)
                except (json.JSONDecodeError, TypeError):
                    meta = {}
            m["metadata"] = meta or {}
            messages.append(m)

        return {
            "messages": messages,
            "last_id": last,
        }


@router.get("/stream")
async def stream_messages(
    workflow: str, run_id: str, request: Request, after_id: int = 0,
):
    """SSE endpoint for real-time message streaming.

    Events emitted (see module docstring for full JSON contract):

    - ``step_update``  — step status changed (pending -> running -> done/failed)
    - ``agent_start``  — agent began speaking (icon lights up)
    - ``message``      — output line from an agent (append to chat)
    - ``agent_end``    — agent finished speaking (icon dims)
    - ``session_end``  — the run completed (done or failed)

    The frontend connects once and receives a continuous stream until the
    session ends or the client disconnects.

    Pass ``after_id`` (the last message id the client has seen) to resume
    a stream without replaying old messages — useful for browser reconnects.
    """
    _validate_run(run_id, workflow)
    settings = get_settings()

    async def event_generator():
        # Emit stream contract as first event so the UI knows what to expect
        yield {
            "event": "stream_start",
            "data": json.dumps({
                "run_id": run_id,
                "workflow": workflow,
                "after_id": after_id,
                "event_types": {
                    "stream_start": "First event — describes the contract and lists all steps/agents",
                    "step_update": "Step status changed (pending → running → done/failed)",
                    "agent_start": "Agent began speaking — light up avatar (source: step_start)",
                    "message": "Output line — append to chat (source: step_output, agent, user, system, task_spawned)",
                    "agent_end": "Agent finished speaking — dim avatar",
                    "session_end": "Run completed (done or failed) — last event",
                },
                "lifecycle": [
                    "step_update(running)",
                    "agent_start",
                    "message (repeated)",
                    "agent_end",
                    "step_update(done)",
                ],
            }),
        }

        last_msg_id = after_id
        last_step_states: dict[str, str] = {}
        idle_ticks_after_end = 0

        while True:
            if await request.is_disconnected():
                break

            events: list[dict] = []

            with get_db() as con:
                cursor = con.cursor()

                # ── New messages ──────────────────────────────
                cursor.execute(
                    q("SELECT id, run_id, step_key, role, agent_name, content, msg_type, "
                      "source, task_id, user_id, metadata, created_at FROM messages "
                      "WHERE run_id=? AND id>? ORDER BY id ASC LIMIT ?"),
                    (run_id, last_msg_id, 100),
                )
                new_messages = [dict(r) for r in cursor.fetchall()]

                # ── Step status ───────────────────────────────
                cursor.execute(
                    q("SELECT step_key, role, status FROM steps "
                      "WHERE run_id=? ORDER BY seq ASC"),
                    (run_id,),
                )
                current_steps = {
                    r["step_key"]: dict(r) for r in cursor.fetchall()
                }

                # ── Run status ────────────────────────────────
                cursor.execute(
                    q("SELECT status FROM runs WHERE id=?"), (run_id,),
                )
                run_row = cursor.fetchone()
                run_status = run_row["status"] if run_row else "unknown"

            # Emit step status transitions
            for key, step in current_steps.items():
                old = last_step_states.get(key)
                new = step["status"]
                if old == new:
                    continue
                last_step_states[key] = new

                events.append({
                    "event": "step_update",
                    "data": json.dumps({
                        "step_key": key,
                        "status": new,
                        "agent": _build_agent(step["role"]),
                    }),
                })

            # Emit messages — map source/msg_type to SSE events
            for msg in new_messages:
                last_msg_id = msg["id"]
                agent = _build_agent(msg["role"], msg.get("agent_name", ""))
                source = msg.get("source") or ""
                msg_type = msg.get("msg_type") or ""

                meta = msg.get("metadata")
                if isinstance(meta, str):
                    try:
                        meta = json.loads(meta)
                    except (json.JSONDecodeError, TypeError):
                        meta = {}
                meta = meta or {}

                # Determine SSE event type from source (preferred) or msg_type (legacy)
                is_start = source == "step_start" or (not source and msg_type == "start")
                is_end = msg_type == "end"

                if is_start:
                    events.append({
                        "event": "agent_start",
                        "data": json.dumps({
                            "step_key": msg["step_key"],
                            "agent": agent,
                            "metadata": meta,
                        }),
                    })
                elif is_end:
                    events.append({
                        "event": "agent_end",
                        "data": json.dumps({
                            "step_key": msg["step_key"],
                            "agent": agent,
                            "metadata": meta,
                        }),
                    })
                else:
                    payload = {
                        "id": msg["id"],
                        "step_key": msg["step_key"],
                        "content": msg["content"],
                        "source": source or msg_type,
                        "timestamp": msg["created_at"],
                        "agent": agent,
                        "metadata": meta,
                    }
                    if msg.get("task_id"):
                        payload["task_id"] = msg["task_id"]
                    if msg.get("user_id"):
                        payload["user_id"] = msg["user_id"]
                    events.append({
                        "event": "message",
                        "data": json.dumps(payload),
                    })

            # Emit session end (once)
            if run_status in ("done", "failed") and idle_ticks_after_end == 0:
                events.append({
                    "event": "session_end",
                    "data": json.dumps({"run_id": run_id, "status": run_status}),
                })

            # Yield events
            for evt in events:
                yield evt

            # Stop after run completes and messages drain
            if run_status in ("done", "failed") and not new_messages:
                idle_ticks_after_end += 1
                if idle_ticks_after_end > 4:  # ~2 seconds of quiet after completion
                    break

            await asyncio.sleep(settings.sse_poll_interval)

    return EventSourceResponse(event_generator())
