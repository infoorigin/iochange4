"""A2A console — the exposure view and the external-agent registry, proxied.

Both directions are filesystem-bound on the ENGINE host: the inbound
exposure answer unions on-disk agent homes, and the outbound registry is a
workspace YAML file carrying auth-header *references*. This pod has neither,
so every call forwards over the same rail agent memory and the learning
console use.

The one discipline this layer inherits and must never weaken: ``${VAR}``
credential references stay UNEXPANDED in every response. The engine resolves
them only inside its validate probe and scrubs resolved values from anything
it returns — nothing here may log, echo or persist a resolved secret.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends

from app.authz import Identity, require_member
from app.engine_routing import engine_json

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/a2a", tags=["a2a"],
                   dependencies=[Depends(require_member)])


def _engine(method: str, path: str, *, json_body: dict | None = None) -> dict:
    return engine_json(
        method, path, json_body=json_body,
        purpose="the A2A registry lives on the engine host, not here")


@router.get("/exposed")
def exposed(identity: Identity = Depends(require_member)) -> dict:
    """Which agents this workspace's engine publishes on the A2A surface."""
    return _engine("GET", "/api/a2a/exposed")


@router.get("/external")
def external_list(identity: Identity = Depends(require_member)) -> dict:
    return _engine("GET", "/api/a2a/external")


@router.post("/external")
def external_upsert(req: dict,
                    identity: Identity = Depends(require_member)) -> dict:
    return _engine("POST", "/api/a2a/external", json_body=req)


@router.delete("/external/{name}")
def external_remove(name: str,
                    identity: Identity = Depends(require_member)) -> dict:
    return _engine("DELETE", f"/api/a2a/external/{name}")


@router.post("/external/{name}/validate")
def external_validate(name: str,
                      identity: Identity = Depends(require_member)) -> dict:
    return _engine("POST", f"/api/a2a/external/{name}/validate")
