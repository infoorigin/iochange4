from fastapi import Depends, APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app.docs_service import HtmlToDocxService
from fastapi import UploadFile, File
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import requests
from app.authz import require_member
from app.url_guard import UrlRefused, check_fetchable


# Initialize the router
router = APIRouter(
    prefix="/documents",
    tags=["Documents"],
    # GUARDED ON THE ROUTER, not per route. This router had NO authentication
    # of any kind, and one of its routes fetched an arbitrary URL server-side
    # and returned the body - an unauthenticated SSRF into the pod's own
    # network. A per-route guard is a guard somebody has to remember; a
    # router-level one cannot be forgotten by the next route added here.
    dependencies=[Depends(require_member)],
)

# Define the expected request payload
class HtmlDocumentRequest(BaseModel):
    html_content: str

# Instantiate the service
docx_service = HtmlToDocxService()

@router.post("/generate-docx")
async def generate_docx(request: HtmlDocumentRequest):
    """
    Accepts HTML content and returns a formatted .docx file.
    """
    try:
        # Generate the document buffer
        docx_buffer = docx_service.generate_docx_from_html(request.html_content)
        
        # Define headers to prompt a file download in the client
        headers = {
            'Content-Disposition': 'attachment; filename="Formatted_Document.docx"'
        }
        
        # Return the buffer as a streaming response
        return StreamingResponse(
            docx_buffer, 
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document", 
            headers=headers
        )
        
    except Exception as e:
        # Catch and return any parsing errors
        raise HTTPException(
            status_code=500, 
            detail=f"Failed to generate document: {str(e)}"
        )


@router.post("/convert-docx")
async def convert_docx(file: UploadFile = File(...)):
    """Accepts a DOCX file upload and returns HTML representation."""
    try:
        contents = await file.read()
        html = docx_service.convert_docx_to_html(contents)
        return JSONResponse(content={"html": html})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to convert DOCX to HTML: {str(e)}")


class UrlRequest(BaseModel):
    url: str


@router.post("/convert-docx-from-url")
async def convert_docx_from_url(payload: UrlRequest):
    """Fetch a DOCX from a URL (e.g., S3 presigned) server-side and convert to HTML."""
    try:
        resp = requests.get(check_fetchable(payload.url), timeout=10)
        if resp.status_code != 200:
            raise HTTPException(status_code=502, detail=f"Failed to fetch file: {resp.status_code}")
        html = docx_service.convert_docx_to_html(resp.content)
        return JSONResponse(content={"html": html})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch/convert DOCX: {str(e)}")


@router.post("/fetch-url-content")
async def fetch_url_content(payload: UrlRequest):
    """Fetch raw content from a URL server-side to bypass CORS.

    Membership is required by the router; the egress guard below is the other
    half. A Studio member is entitled to import a document from the internet,
    not to read this pod's own network through us.
    """
    try:
        target = check_fetchable(payload.url)
    except UrlRefused as refused:
        raise HTTPException(status_code=400, detail=str(refused))
    try:
        resp = requests.get(target, timeout=10, allow_redirects=False)
        if resp.status_code != 200:
            raise HTTPException(status_code=502, detail=f"Failed to fetch url: {resp.status_code}")
        # Return the text content since our .doc is HTML
        return JSONResponse(content={"content": resp.text})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch URL: {str(e)}")