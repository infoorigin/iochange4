"""Session (run) management — create, list, inspect, team roster.

All endpoints are nested under ``/api/workflows/{workflow}/sessions``.
"""

from __future__ import annotations

import logging
import time
import base64
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Header

from app.agents import get_agent
from app.authz import require_member
from app.database import get_db, q

logger = logging.getLogger(__name__)

# Router-level guard (the admin.py pattern): POST here starts a real run on the
# engine, and the read endpoints expose another tenant's goals, steps and team.
# Declared on the router so a new endpoint cannot be added unguarded.
router = APIRouter(prefix="/api/workflows/{workflow}/sessions", tags=["sessions"],
                   dependencies=[Depends(require_member)])


# ── Helpers ───────────────────────────────────────────────────────

def _run_workspace_code(run: dict) -> str | None:
    """The workspace a RUN belongs to, from its own row — or ``None``.

    Deliberately not the caller's current workspace: a roster describes that
    run, and a platform admin reading another tenant's session must see that
    tenant's team, not their own.

    ``None`` means the run is not attributed to a workspace (a null
    ``workspace_id``, a dangling id, or the registry being unreachable).
    Callers fall back to a roster derived from the run's own steps — never
    to another workspace's definition, which is what the old ``"default"``
    answer silently showed.
    """
    ws_id = run.get("workspace_id")
    if not ws_id:
        return None
    try:
        with get_db() as con:
            cur = con.cursor()
            cur.execute(q("SELECT code FROM workspaces WHERE id=?"), (ws_id,))
            row = cur.fetchone()
            return (dict(row)["code"] if row else None) or None
    except Exception:
        return None


def _get_workflow_team(workflow_name: str,
                       workspace_code: str) -> list[dict]:
    """The workflow's declared team, as THIS WORKSPACE resolves the workflow.

    Same rule as the catalog the Studio lists (``app.workflow_catalog``):
    the ENGINE's installed pack first, a ``studio_workflow_defs`` row only
    when no installed pack provides the name (add-only, unpromoted). It used
    to read ``workflows.team_json`` and call that "source of truth", which it
    cannot be: that table has no ``workspace_code``, and ``ensure_workflow``
    rewrites the single global row at every run creation from the workflow
    as resolved FOR THAT TENANT.

    Returns ``[]`` when neither tier defines the workflow — the caller then
    derives the roster from the run's own steps, which is tenant-correct by
    construction. An unreachable engine also yields ``[]`` HERE (a session
    view must not fail because the catalog is down; the run's steps still
    say who worked) — the catalog endpoints themselves stay fail-loud.
    """
    from fastapi import HTTPException

    from app import workflow_catalog

    try:
        team = workflow_catalog.workflow_team(workflow_name, workspace_code)
    except HTTPException as exc:
        if exc.status_code in (502, 503):
            logger.warning("engine catalog unreachable; roster falls back to "
                           "the run's own steps: %s", exc.detail)
            return []
        raise
    return team or []


def _dedupe_avatars(team: list[dict]) -> list[dict]:
    """Guarantee unique avatar initials across one roster.

    Initials derive from friendly names ('Nora' -> NO) and are almost always
    distinct; on a collision the later member gets first-letter + the next
    distinguishing letter of its name, falling back to role letters.
    """
    seen: set[str] = set()
    for member in team:
        avatar = (member.get("avatar") or "??")[:2].upper()
        if avatar in seen:
            name = str(member.get("name") or member.get("role") or "??")
            letters = [c for c in name.upper() if c.isalpha()]
            for alt_second in letters[1:] + [c for c in str(member.get("role", "")).upper() if c.isalpha()]:
                candidate = (letters[0] if letters else "?") + alt_second
                if candidate not in seen:
                    avatar = candidate
                    break
        member["avatar"] = avatar
        seen.add(avatar)
    return team


def _build_team_roster(steps: list[dict], workflow_name: str = "",
                       workspace_code: str | None = None) -> list[dict]:
    """Build the team roster from the workspace's workflow definition,
    enriched with step status.

    The definition supplies membership; the run's steps supply live status
    (active/idle/done/failed). When the workspace has no definition — or the
    run is not attributed to a workspace at all (``workspace_code=None``) —
    the roster is derived from the run's own steps alone; no other
    workspace's definition is ever consulted.
    """
    # Compute status from steps
    role_status: dict[str, dict[str, Any]] = {}
    for s in steps:
        role = s["role"]
        if role not in role_status:
            role_status[role] = {"status": "idle", "current_step": None}

        if s["status"] == "running":
            role_status[role] = {"status": "active", "current_step": s["step_key"]}
        elif s["status"] == "failed":
            role_status[role] = {"status": "failed", "current_step": s["step_key"]}
        elif s["status"] == "done" and role_status[role]["status"] == "idle":
            role_status[role]["status"] = "done"

    # Membership comes from this workspace's own workflow definition. An
    # unattributed run reads no definition at all — steps-only fallback.
    team_members = (_get_workflow_team(workflow_name, workspace_code)
                    if workflow_name and workspace_code else [])

    if team_members:
        # Alex orchestrates every run and is not in any workflow's `team:`
        # block, so he is added here rather than authored into each definition.
        if not any(m.get("role") == "project_lead" for m in team_members):
            team_members = [{"role": "project_lead"}] + team_members
        team = []
        seen_roles = set()
        for member in team_members:
            role = member.get("role", "")
            if not role or role in seen_roles:
                continue
            seen_roles.add(role)
            agent = get_agent(role)
            info = role_status.get(role, {"status": "idle", "current_step": None})
            agent["status"] = info["status"]
            agent["current_step"] = info["current_step"]
            team.append(agent)
        return _dedupe_avatars(team)

    # Fallback: no definition for this workspace — derive from the run's own
    # steps. Tenant-correct by construction, which is why it is the fallback
    # and the global `workflows` row is not.
    team = []
    for role, info in role_status.items():
        agent = get_agent(role)
        agent["status"] = info["status"]
        agent["current_step"] = info["current_step"]
        team.append(agent)

    # Alex orchestrates every run (see above).
    if not any(t.get("role") == "project_lead" for t in team):
        pl = get_agent("project_lead")
        pl["status"] = "active"
        pl["current_step"] = None
        team.insert(0, pl)

    return _dedupe_avatars(team)


def _get_run_or_404(run_id: str, workflow: str) -> dict:
    """Fetch a run and validate it belongs to the given workflow."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, status, "
              "created_at, updated_at FROM runs WHERE id=?"),
            (run_id,),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"Session '{run_id}' not found")
        run = dict(row)
        if run["workflow_name"] != workflow:
            raise HTTPException(
                status_code=404,
                detail=f"Session '{run_id}' belongs to workflow '{run['workflow_name']}', not '{workflow}'",
            )
        return run


# NOTE (2026-07-25): the hand-rolled _execute_pipeline driver loop is GONE.
# It bypassed the engine orchestrator (canned project_lead approvals, no
# retries, no hard cap, stranded runs on failure). `run --json` spawns the
# engine's own Alex-driven background execution — one orchestration semantic
# for CLI and UI alike.


# ── Endpoints ─────────────────────────────────────────────────────

@router.post("")
def start_session(workflow: str, req: dict,
                  identity=Depends(require_member)):
    """Start a new workflow session.

    1. Calls ``ioagentfarm start-run`` to create the run + materialize steps.
    2. Launches a background thread to drive execution via next-step / run-step.

    ``draft: true`` runs the workflow against the CALLER's content drafts
    (One Truth s3.5). The author is the VERIFIED identity, never a body
    field — the engine has no auth, so a client-sent ``draft_author`` would
    let one member run under another's drafts; it is discarded here.
    """
    goal = req.get("goal", "")
    project_dir = req.get("project_dir", "")
    variables = req.get("vars", {}) or {}

    if not goal:
        raise HTTPException(status_code=400, detail="goal is required")

    # HANDOVER, not local execution. This API deliberately never runs
    # workflows on its own host: in the split deployment its pod has no
    # solution packs and no model-provider config, so a locally spawned run
    # dies on its first LLM call (observed as an Azure 401 with the run
    # inheriting THIS process's environment). Run creation goes to the
    # TENANT'S engine web API — routed per workspace by app.engine_routing,
    # the same rail the message/chat proxy (run_proxy.py) uses — and
    # executes where the solution is installed.
    try:
        import httpx
    except ImportError:  # pragma: no cover - httpx ships with the venv
        raise HTTPException(status_code=503, detail="httpx not installed on the API host")

    payload: dict[str, Any] = {
        "workflow": workflow,
        "goal": goal,
        "user_id": req.get("user_id", "ui:studio"),
        "variables": variables,
    }
    if req.get("draft"):
        payload["draft_author"] = identity.email
    if project_dir:
        payload["project_dir"] = project_dir
    # The tenant ALWAYS reaches the engine: body override first, else the
    # workspace the request itself was resolved to (X-Workspace-Id). The old
    # form forwarded only the body field — a caller that sent the header but
    # no body field had its run created in whatever the engine invented.
    from app.workspace_context import active_code
    from app.engine_routing import (rail_headers, engine_for,
                                    mark_engine_seen)
    ws_code = (req.get("workspace") or "").strip() or active_code()
    payload["workspace"] = ws_code
    base = engine_for(ws_code)

    try:
        resp = httpx.post(f"{base}/api/run", json=payload, timeout=120.0,
                          headers=rail_headers())
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Timeout creating run on the engine")
    except httpx.HTTPError:
        raise HTTPException(
            status_code=502,
            detail=f"engine API for workspace '{ws_code}' unreachable "
                   "(set IOF_ENGINE_URLS / IOF_ENGINE_URL_TEMPLATE / "
                   "IOF_RUN_API_URL; is `ioagentfarm serve` running?)",
        )
    mark_engine_seen(ws_code)

    if resp.status_code != 200:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise HTTPException(
            status_code=resp.status_code if resp.status_code >= 400 else 500,
            detail=f"engine refused the run: {str(detail)[:800]}",
        )

    data = resp.json()
    run_id = data.get("run_id", "")
    if not run_id:
        raise HTTPException(status_code=500, detail="No run_id in engine response")

    return {
        "run_id": run_id,
        "workflow": workflow,
        "status": "running",
        "message": f"Session started. Workflow '{workflow}' is executing (engine-orchestrated).",
        "total_steps": data.get("total_steps", 0),
        "first_step_key": data.get("first_step_key"),
    }


@router.get("")
def list_sessions(workflow: str, limit: int = 20, status: str | None = None):
    """List sessions for a workflow (most recent first)."""
    with get_db() as con:
        cursor = con.cursor()
        sql = ("SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, status, "
               "created_at, updated_at FROM runs WHERE workflow_name=?")
        params: list = [workflow]
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        cursor.execute(q(sql), tuple(params))
        return [dict(r) for r in cursor.fetchall()]


@router.get("/user")
def list_user_sessions(
    workflow: str,
    workspace_id: int | None = None,
    limit: int = 20,
    status: str | None = None,
    authorization: str | None = Header(None)
):
    """List sessions for a specific workflow and user, using user email from token."""
    # VERIFIED identity — the twin of the block in routers/workspaces.py. Both
    # previously trusted an unverified payload (no signature, no exp check).
    from app.auth_token import identity_from_header

    user_email = identity_from_header(authorization).email

    with get_db() as con:
        cursor = con.cursor()
        # runs.user_id holds the creator's email (written from the verified
        # identity at run creation — see start_session).
        sql = ("SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, status, "
               "created_at, updated_at FROM runs WHERE workflow_name=? AND user_id=?")
        params: list = [workflow, user_email]
        if workspace_id is not None:
            sql += " AND workspace_id=?"
            params.append(workspace_id)
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        cursor.execute(q(sql), tuple(params))
        return [dict(r) for r in cursor.fetchall()]


@router.get("/{run_id}")
def get_session(workflow: str, run_id: str):
    """Session detail — run info, step progress, and team roster."""
    run = _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT step_key, role, status, attempt, max_attempts, "
              "COALESCE(output_text,'') AS output_text, created_at, updated_at "
              "FROM steps WHERE run_id=? ORDER BY seq ASC"),
            (run_id,),
        )
        steps = []
        for r in cursor.fetchall():
            s = dict(r)
            s["agent"] = get_agent(s["role"])
            steps.append(s)

    run["steps"] = steps
    run["team"] = _build_team_roster(steps, workflow, _run_workspace_code(run))
    return run


@router.get("/{run_id}/status")
def get_session_status(workflow: str, run_id: str):
    """Lightweight status check for a session."""
    run = _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT status FROM steps WHERE run_id=?"), (run_id,),
        )
        steps = [dict(r) for r in cursor.fetchall()]

    total = len(steps)
    done = sum(1 for s in steps if s["status"] == "done")
    running = sum(1 for s in steps if s["status"] == "running")
    failed = sum(1 for s in steps if s["status"] == "failed")
    pending = sum(1 for s in steps if s["status"] == "pending")

    return {
        "run_id": run_id,
        "status": run["status"],
        "steps_total": total,
        "steps_done": done,
        "steps_running": running,
        "steps_failed": failed,
        "steps_pending": pending,
    }


@router.get("/{run_id}/steps")
def get_session_steps(workflow: str, run_id: str):
    """Step progress for a session."""
    _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT step_key, role, status, attempt, max_attempts, deps_json, "
              "meta_json, COALESCE(output_text,'') AS output_text, "
              "created_at, updated_at "
              "FROM steps WHERE run_id=? ORDER BY seq ASC"),
            (run_id,),
        )
        steps = []
        for r in cursor.fetchall():
            s = dict(r)
            s["agent"] = get_agent(s["role"])
            steps.append(s)
        return steps


@router.get("/{run_id}/team")
def get_session_team(workflow: str, run_id: str):
    """Team roster with current active/idle/done status."""
    run = _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT step_key, role, status FROM steps "
              "WHERE run_id=? ORDER BY seq ASC"),
            (run_id,),
        )
        steps = [dict(r) for r in cursor.fetchall()]
    return _build_team_roster(steps, workflow, _run_workspace_code(run))
