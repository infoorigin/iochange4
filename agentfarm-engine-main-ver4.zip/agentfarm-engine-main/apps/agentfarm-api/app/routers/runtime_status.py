"""Workspace runtime state — what the UI says about the engine, warmly.

A workspace's engine is deployed per tenant, and there is a real window where
the workspace exists but its runtime does not yet. The UI must be able to say
*"being prepared"* for that state — a normal onboarding moment — and reserve
incident language for an engine that WAS healthy and stopped answering. The
difference is observed history (``studio_engine_health``), not configuration.

Members get the state and nothing else: the engine URL never appears in a
member-facing response — topology is deployment configuration, and leaking it
turns a browser into a map of internal hosts. Platform admins get a separate
read-only topology view with the resolved HOST (never the full URL) per
workspace.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends

from app.authz import Identity, require_member, require_platform_admin
from app.engine_routing import (last_engine_seen, mark_engine_seen,
                                masked_host, probe_engine, resolve_engine)
from app.workspace_context import active_code

logger = logging.getLogger(__name__)

router = APIRouter(tags=["runtime"])


def _runtime_state(code: str, *, timeout: float = 3.0) -> dict:
    resolved = resolve_engine(code)
    last_seen = last_engine_seen(code)
    if probe_engine(resolved.url, timeout=timeout):
        mark_engine_seen(code)
        state = "connected"
        last_seen = last_engine_seen(code)
    elif last_seen is None:
        # Never observed healthy: the runtime is still being prepared —
        # onboarding, not an incident.
        state = "preparing"
    else:
        state = "unreachable"
    return {"state": state, "resolved_via": resolved.via,
            "last_seen_at": last_seen}


@router.get("/api/studio/workspace-runtime")
def workspace_runtime(identity: Identity = Depends(require_member)) -> dict:
    """The active workspace's runtime lifecycle state. No URLs, ever."""
    return _runtime_state(active_code())


@router.get("/api/admin/engine-topology")
def engine_topology(
        identity: Identity = Depends(require_platform_admin)) -> dict:
    """Read-only resolved topology — every workspace, host-masked.

    Answers "which engine would serve each workspace, and is it up?" without
    exposing full URLs (scheme, path and credentials are stripped). The
    topology itself is env-only and cannot be edited here by design.
    """
    from app.database import get_db, q

    from ioagentfarm.engine.workspaces import PLATFORM_TIER

    with get_db() as con:
        cur = con.cursor()
        cur.execute(q("SELECT code FROM workspaces ORDER BY code"))
        codes = [r["code"] for r in cur.fetchall()
                 if r["code"] != PLATFORM_TIER]
    items = []
    for code in codes:
        resolved = resolve_engine(code)
        entry = _runtime_state(code, timeout=2.0)
        items.append({"workspace": code,
                      "engine_host": masked_host(resolved.url),
                      "resolved_via": resolved.via,
                      "state": entry["state"],
                      "last_seen_at": entry["last_seen_at"]})
    return {"items": items, "topology_source": "environment"}
