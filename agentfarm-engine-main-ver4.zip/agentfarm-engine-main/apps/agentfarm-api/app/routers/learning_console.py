"""Learning governance console — the steward workflow, proxied to the engine.

Drafts, the audit trail and the approved-skill inbox are filesystem/JSONL
under the ENGINE's ``IOF_ROOT`` (``engine/learning/governance.py``); this pod
has none of it, so every read and decision forwards over the same rail agent
memory uses. Nothing of the governance semantics lives here — the security
scan, the fail-closed dangerous-approve refusal and the draft file moves all
run engine-side.

What this layer OWNS is identity and tenancy:

* The approver on every decision is the AUTHENTICATED caller — a client-sent
  ``approver`` field is discarded, because an enterprise audit trail must not
  be able to say whatever the browser typed.
* Members see their workspace's drafts (plus, for platform admins only, the
  legacy unscoped ones — an unscoped draft belongs to nobody provably, so no
  single tenant's steward may claim it).
* A decision on another workspace's draft is refused here, before the engine
  ever sees it.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException

from app import workspace_context, workspace_members
from app.authz import Identity, require_member

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/learning", tags=["learning"])


def _engine(method: str, path: str, *, params: dict | None = None,
            json_body: dict | None = None) -> dict:
    from app.engine_routing import engine_json
    return engine_json(
        method, path, params=params, json_body=json_body,
        purpose="learning drafts live on the engine host, not here")


def _is_admin(identity: Identity) -> bool:
    try:
        return workspace_members.is_platform_admin(identity.email)
    except Exception:
        return False


def _summary(raw: dict) -> str:
    text = (raw.get("thoughts") or "").strip()
    if not text:
        text = (raw.get("skill_md") or "").strip()
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith(("#", "---")):
            return line[:200]
    return ""


def _to_console_shape(raw: dict, *, with_body: bool = False) -> dict:
    """Engine DraftRecord -> the console contract shape.

    Two impedances, surfaced honestly rather than papered over:
    ``submitted_at`` is not recorded by the engine draft store (null here),
    and the evidence bundle carries a completion RATE but no completions
    count (null likewise).
    """
    scan = raw.get("security_scan") or {}
    ev = raw.get("evidence") or {}
    out = {
        "ident": raw.get("ident"),
        "skill_name": raw.get("skill_name"),
        "skill_type": raw.get("skill_type"),
        "action": raw.get("action"),
        "scope": {"role": raw.get("scope_role"),
                  "workflow": raw.get("scope_workflow")},
        "workspace_code": raw.get("workspace_code"),
        "submitted_at": None,
        "security": {"verdict": scan.get("verdict"),
                     "findings": scan.get("findings") or []},
        "evidence": {"applications": ev.get("applications") or 0,
                     "completions": None,
                     "completion_rate": ev.get("completion_rate")},
        "summary": _summary(raw),
    }
    if with_body:
        out["skill_md"] = raw.get("skill_md") or ""
        out["thoughts"] = raw.get("thoughts") or ""
    return out


def _visible(raw: dict, workspace: str, admin: bool) -> bool:
    ws = raw.get("workspace_code")
    return ws == workspace or (ws is None and admin)


def _fetch_visible_draft(ident: str, identity: Identity) -> dict:
    raw = _engine("GET", f"/api/learning/drafts/{ident}")
    workspace = workspace_context.active_code()
    if not _visible(raw, workspace, _is_admin(identity)):
        # Same status as "does not exist": revealing that another tenant HAS
        # a draft with this ident is itself a leak.
        raise HTTPException(status_code=404,
                            detail=f"no pending draft addressed by '{ident}'")
    return raw


@router.get("/pending")
def pending(include_unscoped: bool = False,
            identity: Identity = Depends(require_member)) -> dict:
    workspace = workspace_context.active_code()
    admin = _is_admin(identity)
    body = _engine("GET", "/api/learning/pending", params={
        "workspace": workspace,
        "include_unscoped": bool(include_unscoped and admin),
    })
    return {"drafts": [_to_console_shape(d) for d in body.get("drafts", [])]}


@router.get("/drafts/{ident}")
def draft_detail(ident: str,
                 identity: Identity = Depends(require_member)) -> dict:
    raw = _fetch_visible_draft(ident, identity)
    return _to_console_shape(raw, with_body=True)


@router.post("/drafts/{ident}/decision")
def decide(ident: str, req: dict,
           identity: Identity = Depends(require_member)) -> dict:
    decision = (req.get("decision") or "").strip().lower()
    if decision not in ("approve", "reject"):
        raise HTTPException(status_code=400,
                            detail="decision must be 'approve' or 'reject'")
    _fetch_visible_draft(ident, identity)   # tenancy gate before any action
    try:
        body = _engine("POST", f"/api/learning/drafts/{ident}/decision",
                       json_body={
                           "decision": decision,
                           "note": (req.get("note") or "").strip(),
                           # The authenticated caller, never the client's
                           # claim — the body's approver field is discarded.
                           "approver": identity.email,
                       })
    except HTTPException as exc:
        if exc.status_code == 409:
            return {"ok": False, "outcome": "refused",
                    "refused_reason": str(exc.detail)}
        raise
    return {"ok": True, "outcome": body.get("outcome", decision),
            "refused_reason": None}


@router.get("/audit")
def audit(limit: int = 100,
          identity: Identity = Depends(require_member)) -> dict:
    workspace = workspace_context.active_code()
    admin = _is_admin(identity)
    body = _engine("GET", "/api/learning/audit", params={"limit": limit})
    entries = []
    for e in body.get("entries", []):
        ws = e.get("workspace")
        # Members see their workspace's decisions; legacy entries with no
        # stamp are admin-only, same rule as unscoped drafts.
        if ws == workspace or (ws is None and admin):
            entries.append({"at": e.get("at"), "event": e.get("event"),
                            "skill": e.get("skill_name"),
                            "by": e.get("approver"),
                            "detail": e.get("reason") or e.get("note") or ""})
    return {"entries": entries}
