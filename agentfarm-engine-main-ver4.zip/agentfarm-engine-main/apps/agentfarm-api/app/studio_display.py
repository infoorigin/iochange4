"""Studio agent display metadata — the business-friendly presentation layer.

Backs the builder's Role input, the "What this agent does" summary, and the
"Additional details" text. This is DISPLAY ONLY: rows are read/written by the
studio API and merged into agent responses; the engine and iobot never read
this table, and nothing here ever touches SOUL.md (the runtime persona stays
exactly what the persona editor composes).

Storage follows the ``studio_skill_scripts`` pattern: an API-owned,
clearly-named table in the shared engine DB (``IOF_DATABASE_URL`` resolved at
request time), created idempotently on first use. Seed rows carry authored
plain-language copy for the shipped agents (INSERT ... ON CONFLICT DO NOTHING
— a deployment can edit them without re-seeding fights).
"""
from __future__ import annotations

import time
from datetime import datetime, timezone

from app.database import get_db, placeholder, q

_TABLE_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_agent_display ("
    "  role       TEXT PRIMARY KEY,"
    "  role_label TEXT NOT NULL DEFAULT '',"
    "  summary    TEXT NOT NULL DEFAULT '',"
    "  details    TEXT NOT NULL DEFAULT '',"
    "  updated_at TEXT NOT NULL"
    ")"
)

#: Authored friendly copy — role label + a summary that fits the Build tab,
#: with longer context in details. Written FOR business users; sourced from
#: each agent's SOUL.md first paragraph but never copied verbatim jargon.
_SEED_ROWS: list[dict] = [
    {
        "role": "cora",
        "role_label": "AI assistant",
        "summary": "Your first point of contact — answers questions directly, "
                   "checks on running work, and hands bigger jobs to the right agent.",
        "details": "The Core Assistant is the front door to the agent team. It can "
                   "answer from its own knowledge, look up live data, report on "
                   "workflow runs, and dispatch specialist agents when real work "
                   "is needed.",
    },
    {
        "role": "project_lead",
        "role_label": "Team orchestrator",
        "summary": "Plans and runs multi-step work: decides what happens next, "
                   "delegates each step to the right specialist, and recovers when "
                   "something fails.",
        "details": "Alex drives whole workflows rather than single tasks — "
                   "sequencing steps, watching for failures, retrying or re-routing "
                   "work, and signing off when everything is done.",
    },
    {
        "role": "pharma_data_analyst",
        "role_label": "Pharma data analyst",
        "summary": "Prepares the ground for barrier discovery: turns large volumes "
                   "of field notes, sales and access records into small, citable "
                   "summaries the rest of the team works from.",
        "details": "Nora is the first stage of the discovery pipeline. She never "
                   "interprets — she prepares exact, checkable artifacts so the "
                   "domain analyst and reviewer can ground every claim in real data.",
    },
    {
        "role": "pharma_domain_analyst",
        "role_label": "Pharma domain analyst",
        "summary": "The discovery specialist: reads the prepared evidence, "
                   "identifies business signals, and infers the barriers behind "
                   "them — every claim traceable to its source.",
        "details": "Maya thinks in the enterprise signal/barrier framework: a "
                   "signal is WHAT was detected, a barrier is WHY. She writes her "
                   "discoveries so a skeptic can check every link, quote and figure.",
    },
    {
        "role": "pharma_reviewer",
        "role_label": "Discovery reviewer",
        "summary": "The quality gate: independently re-checks every figure, quote "
                   "and link in a discovery before it moves forward. Nothing "
                   "unverifiable gets through.",
        "details": "Vera re-derives claims rather than re-reading them — counting "
                   "cited signals herself, finding quotes verbatim in sources, and "
                   "recomputing rates. Interpretation is judged downstream; her "
                   "question is whether the evidence would survive an audit.",
    },
    {
        "role": "ainf-meta-agent",
        "role_label": "Commercial intelligence orchestrator",
        "summary": "Answers broad commercial questions by splitting them across "
                   "the specialist data agents, then combining their findings into "
                   "one grounded answer.",
        "details": "Pharma Intel never queries data itself — it decomposes a "
                   "question, dispatches the pieces to the performance, market and "
                   "feedback specialists in parallel, and synthesizes their "
                   "verified results.",
    },
    {
        "role": "sia_agent",
        "role_label": "Commercial performance specialist",
        "summary": "Answers questions about sales performance — actuals vs goals, "
                   "growth, KPIs and NPS — directly from the commercial "
                   "performance data.",
        "details": "RxPulse translates focused analytics questions into precise "
                   "queries over the commercial performance data and returns "
                   "insight cards with verified figures.",
    },
    {
        "role": "profound_a2a",
        "role_label": "Market intelligence specialist",
        "summary": "Covers market share trends, competitive positioning, share of "
                   "voice and detailing reach from the market data.",
        "details": "MarketScope is scoped to the market share and competitive "
                   "positioning data — every answer is backed by a query it "
                   "actually ran.",
    },
    {
        "role": "market_feedback",
        "role_label": "Physician feedback specialist",
        "summary": "Mines physician interviews for attitudes, prescribing intent, "
                   "adoption barriers and competitive stance.",
        "details": "FeedbackLens turns qualitative questions about physician "
                   "sentiment into precise queries over the interview data and "
                   "reports what physicians actually said.",
    },
    {
        "role": "reporting",
        "role_label": "Insight synthesizer",
        "summary": "Joins the findings from the performance and market specialists "
                   "into a single storyline — where the signals agree, and where "
                   "they conflict.",
        "details": "Synthesis is a pure reasoning agent: it runs no queries of its "
                   "own, always works last, and authors the combined narrative "
                   "from data the specialists already verified.",
    },
    {
        "role": "field_ops_analyst",
        "role_label": "Field operations analyst",
        "summary": "Monitors field operations signals and produces short, "
                   "data-grounded snapshots for the operations team.",
        "details": "",
    },
    {
        "role": "register_curator",
        "role_label": "Signal register curator",
        "summary": "Keeps the barrier register tidy: folds newly arrived, "
                   "already-covered signals into their barriers as supporting "
                   "evidence and queues anything ambiguous for human review.",
        "details": "Mira never promotes a barrier's lifecycle status — that "
                   "decision always belongs to the human review gate.",
    },
    {
        "role": "studio_builder_agent",
        "role_label": "Acceptance test agent",
        "summary": "A studio-built agent used to verify the builder end-to-end.",
        "details": "",
    },
    {
        "role": "studio_test_agent",
        "role_label": "E2E test agent",
        "summary": "A studio-created agent used by automated tests.",
        "details": "",
    },
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


#: The DDL + seed is ~16 round trips; over a remote RDS link that is 1-3s.
#: The agents list is on the studio's hot path (every sidebar render), so the
#: provisioning runs ONCE per process and later calls go straight to the SELECT.
#: Reset via `reset_seed_cache()` (tests) — the statements stay idempotent, so
#: a second process provisioning concurrently is harmless.
_seeded = False


def reset_seed_cache() -> None:
    global _seeded
    _seeded = False
    _invalidate()


def ensure_table(con) -> None:
    """Idempotent ensure + seed — provisioning runs once per process."""
    global _seeded
    if _seeded:
        return
    cur = con.cursor()
    cur.execute(_TABLE_DDL)
    insert = (
        "INSERT INTO studio_agent_display (role, role_label, summary, details, updated_at) "
        "VALUES (?, ?, ?, ?, ?) ON CONFLICT (role) DO NOTHING"
        if placeholder() == "%s"
        else
        "INSERT OR IGNORE INTO studio_agent_display (role, role_label, summary, details, updated_at) "
        "VALUES (?, ?, ?, ?, ?)"
    )
    # SELF-HEAL: carry display rows keyed to a retired slug onto the canonical
    # role (jarvis -> cora), so a deployment seeded before the rename shows the
    # current identity without an operator touching the table. UPDATE only when
    # the canonical row is absent; then drop the retired row either way so the
    # seed below cannot resurrect stale copy.
    try:
        from ioagentfarm.engine.workspaces import _ROLE_ALIASES
        for old_slug, new_slug in _ROLE_ALIASES.items():
            cur.execute(q("SELECT 1 FROM studio_agent_display WHERE role = ?"),
                        (new_slug,))
            if cur.fetchone() is None:
                cur.execute(q("UPDATE studio_agent_display SET role = ? "
                              "WHERE role = ?"), (new_slug, old_slug))
            else:
                cur.execute(q("DELETE FROM studio_agent_display WHERE role = ?"),
                            (old_slug,))
    except Exception:
        pass  # engine package absent (isolated API tests) — seed as-is

    for row in _SEED_ROWS:
        cur.execute(q(insert), (row["role"], row["role_label"], row["summary"],
                               row["details"], _now()))
    if placeholder() != "%s":
        con.commit()
    _seeded = True


#: The agents list is the studio's hot path (every sidebar render refetches it)
#: and the engine DB is typically a remote RDS, so the display rows — which
#: change only when someone edits an agent in the builder — are cached for a
#: short window and invalidated on write. Without this, listing agents pays an
#: extra WAN round trip per request and the sidebar counts arrive late.
_CACHE_TTL = 60.0
_cache: dict = {"rows": None, "at": 0.0}


def _invalidate() -> None:
    _cache["rows"] = None
    _cache["at"] = 0.0


def all_display(*, fresh: bool = False) -> dict[str, dict]:
    """role -> {role_label, summary, details} for every stored row."""
    now = time.monotonic()
    if not fresh and _cache["rows"] is not None and now - _cache["at"] < _CACHE_TTL:
        return _cache["rows"]
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        cur.execute("SELECT role, role_label, summary, details FROM studio_agent_display")
        rows = {r["role"]: dict(r) for r in (dict(row) for row in cur.fetchall())}
    _cache["rows"] = rows
    _cache["at"] = now
    return rows


def get_display(role: str) -> dict | None:
    """One agent's display row. Served from the list cache when warm — the
    builder's detail fetch is the same hot path as the gallery."""
    cached = _cache["rows"]
    if cached is not None and time.monotonic() - _cache["at"] < _CACHE_TTL:
        return dict(cached[role]) if role in cached else None
    return all_display().get(role)


def upsert_display(role: str, role_label: str | None, summary: str | None,
                   details: str | None) -> dict:
    """Partial upsert — None keeps the stored value; '' clears it."""
    current = get_display(role) or {"role_label": "", "summary": "", "details": ""}
    merged = {
        "role_label": current["role_label"] if role_label is None else role_label.strip(),
        "summary": current["summary"] if summary is None else summary.strip(),
        "details": current["details"] if details is None else details.strip(),
    }
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        upsert = (
            "INSERT INTO studio_agent_display (role, role_label, summary, details, updated_at) "
            "VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT (role) DO UPDATE SET role_label = EXCLUDED.role_label, "
            "summary = EXCLUDED.summary, details = EXCLUDED.details, "
            "updated_at = EXCLUDED.updated_at"
            if placeholder() == "%s"
            else
            "INSERT OR REPLACE INTO studio_agent_display "
            "(role, role_label, summary, details, updated_at) VALUES (?, ?, ?, ?, ?)"
        )
        cur.execute(q(upsert), (role, merged["role_label"], merged["summary"],
                                merged["details"], _now()))
        if placeholder() != "%s":
            con.commit()
    _invalidate()   # the builder must read back what it just saved
    return {"role": role, **merged}
