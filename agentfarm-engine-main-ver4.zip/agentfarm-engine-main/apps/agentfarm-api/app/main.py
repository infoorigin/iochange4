"""FastAPI backend for ioagentfarm Teams-like chat UI.

Reads from ioagentfarm's database (SQLite or PostgreSQL).
Starts workflow sessions via ioagentfarm CLI subprocess.
Streams agent output in real-time via SSE.

    uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routers import workspaces, workflows, sessions, messages, s3, auth, agentfarm_sessions, documents, auth_info_qa, studio, barrier_insights, hil_queue, source_data, signals, playbook_templates, run_proxy, admin, run_forensics, learning_console, a2a_console, capability_fabric, runtime_status, content_drafts, conversations
from app.routers.product_catalog import brand_router, play_router, mission_router
from app.studio_scripts import router as studio_scripts_router
from app.skillhub_adapter import get_skills_router
from app.clihub_adapter import get_cli_router

def _docs_urls() -> dict:
    """The Studio API's own name and whether it publishes its route list.

    The same two decisions the engine exposes, for the same reasons. The
    title was `ioagentfarm UI` - the import package name, and a description
    naming a chat UI this has not been for some time. `IOF_API_TITLE`
    renames it for an organisation serving the Studio under its own product
    name; `IOF_API_DOCS=off` withdraws `/docs`, `/redoc` and
    `/openapi.json`.

    Unlike the engine, every route here is already behind `require_member`,
    so withdrawing the browser is a preference rather than a control.
    """
    import os
    off = (os.environ.get("IOF_API_DOCS") or "").strip().lower() in (
        "off", "0", "false", "no")
    return {
        "title": os.environ.get("IOF_API_TITLE") or "AI Core Harness Studio",
        "description": "Backend API for the AI Core Harness Studio.",
        "docs_url": None if off else "/docs",
        "redoc_url": None if off else "/redoc",
        "openapi_url": None if off else "/openapi.json",
    }


app = FastAPI(version="0.1.0", **_docs_urls())

settings = get_settings()

# Engine topology is ENV-ONLY and validated at import: a malformed
# IOF_ENGINE_URLS map must kill the process here, loudly, not surface as
# intermittent per-request 500s on some workspaces and not others.
from app.engine_routing import validate_topology  # noqa: E402

validate_topology()



#: Paths that legitimately precede workspace selection. Everything else is
#: workspace-scoped and REQUIRES a resolvable X-Workspace-Id: the login flow
#: runs before any workspace exists; the workspace list is what the UI's
#: switcher reads to OFFER a selection; admin routes operate across
#: workspaces (and carry their own platform-admin guard); health and the
#: docs endpoints are infrastructural.
_TENANCY_EXEMPT_PREFIXES = (
    "/auth/", "/api/auth", "/api/health", "/api/agents",
    "/api/workspaces", "/api/admin",
    "/docs", "/openapi.json", "/redoc",
)


@app.middleware("http")
async def _request_scope(request, call_next):
    """Open the per-request memo (see app/request_scope.py) around everything.

    Registered BEFORE the tenancy middleware so Starlette makes it the inner
    one: it must still be open while a handler runs, and it must close on the
    way out even when tenancy refuses the request.
    """
    from app import request_scope

    token = request_scope.begin(request.method)
    try:
        return await call_next(request)
    finally:
        request_scope.end(token)


@app.middleware("http")
async def _actor_context(request, call_next):
    """Resolve the VERIFIED end user once per request, for engine attribution.

    Registered after ``_request_scope`` and before ``_tenant_context``, so it
    sits between them: the memo is open around it, and the tenant is resolved
    outside it. Neither ordering constraint is subtle — this only needs to be
    set before any handler runs.

    NON-FATAL BY CONSTRUCTION (``maybe_identity``, not ``identity_from_header``).
    This is attribution, not authorization: ``require_member`` is the guard, and
    a middleware that could refuse a request the real guard would have allowed
    is a second, weaker copy of it. An exempt path, an absent token or an
    unverifiable one all leave the actor empty and the request proceeds.

    The reset is in a ``finally`` because a contextvar left set outlives the
    request on a reused worker — which would stamp one user's identity onto the
    next request's engine calls.
    """
    from app import actor_context
    from app.auth_token import maybe_identity

    identity = None
    try:
        identity = maybe_identity(request.headers.get("Authorization"))
    except Exception:  # noqa: BLE001 — never fail a request over attribution
        pass
    token = actor_context.set_actor(identity.email if identity else "")
    try:
        return await call_next(request)
    finally:
        actor_context.reset(token)


@app.middleware("http")
async def _tenant_context(request, call_next):
    """Resolve X-Workspace-Id ONCE per request into the tenant contextvar.

    Deep call sites (studio visibility filter, workflow catalog) read
    app.workspace_context.active_code() instead of threading the header.

    FAIL-CLOSED: a workspace-scoped request that does not name a valid
    workspace is refused here (400 missing / 403 unknown-or-retired / 503
    registry unreachable) — the response the old fail-open-to-'default'
    branch existed to avoid, and exactly the one that makes "which
    workspace answered this?" always answerable. Exempt paths get NO
    ambient workspace: a handler on one that does workspace-scoped work
    hits active_code()'s RuntimeError instead of another tenant's data.
    """
    from fastapi import HTTPException
    from fastapi.responses import JSONResponse

    from app import tenancy, workspace_context

    # CORS preflights are ANONYMOUS BY SPEC: the browser sends OPTIONS with
    # no custom headers precisely to ask whether X-Workspace-Id may be sent.
    # This middleware is outermost (registered after CORSMiddleware), so
    # refusing the preflight here made every /api/studio/* call fail from a
    # split-origin browser with a bare "Network Error" — found live in the
    # first real UI walkthrough; TestClient never preflights, so no API test
    # could see it. The actual request that follows still enforces tenancy.
    if request.method == "OPTIONS":
        workspace_context.set_active_code(None)
        return await call_next(request)

    path = request.url.path
    if any(path.startswith(p) for p in _TENANCY_EXEMPT_PREFIXES):
        workspace_context.set_active_code(None)
        return await call_next(request)
    try:
        named = (request.headers.get("X-Workspace-Id") or "").strip()
        if not named:
            # EventSource cannot set request headers, so SSE streams name
            # their workspace via ?workspace_id= instead. Read ONLY when the
            # header is absent — the header always wins, so the
            # explicit-workspace contract holds unchanged: every request
            # still names its workspace; streams just use the one channel a
            # browser EventSource actually has.
            named = (request.query_params.get("workspace_id") or "").strip()
        ws = tenancy.resolve_workspace(named)
    except HTTPException as e:
        return JSONResponse(status_code=e.status_code,
                            content={"detail": e.detail})
    workspace_context.set_active_code(ws["code"])
    return await call_next(request)


@app.exception_handler(Exception)
async def _errors_reach_the_browser(request, exc: Exception):
    """An unhandled error reaches the browser AS AN ERROR, not as "CORS".

    Starlette's ServerErrorMiddleware is the OUTERMOST layer - outside
    CORSMiddleware - so the 500 it produces carries no
    `Access-Control-Allow-Origin`, and a split-origin browser reports a CORS
    failure. The real fault is invisible and the reported symptom points at
    the one part of the stack that is working. Reported from a client
    production environment as "the perf changes are throwing CORS errors",
    where CORS was configured correctly the whole time.

    SO THE HEADER IS SET HERE, EXPLICITLY, and that is not belt-and-braces.
    Two other shapes were tried and MEASURED failing:

    * a plain `@app.exception_handler(Exception)` without the header - 500,
      no ACAO, which is the symptom this exists to remove;
    * a `@app.middleware("http")` catcher registered inside CORSMiddleware -
      also no ACAO, because with NESTED BaseHTTPMiddleware the downstream
      exception surfaces while the response body is streamed back, AFTER
      `call_next` has returned, so a try/except around it never sees it. It
      works in a single-middleware app, which is exactly how such a fix gets
      believed without being checked.

    `allow_origins` is `*` here, so `*` is the honest echo. If this ever
    becomes a real allowlist, reflect the request Origin instead.
    """
    # IMPORTED HERE, like every other name this module uses. `main.py`
    # imports FastAPI's response classes inside functions, and a handler that
    # reached for them as globals raised NameError INSIDE the error path -
    # producing an empty 500 with no header, which is indistinguishable from
    # the bug this handler exists to fix. The same shape is on record in this
    # repo: the threaded narration reader referenced `get_db`/`q` as globals
    # and failed silently on every poll.
    import logging

    from fastapi.responses import JSONResponse

    logging.getLogger(__name__).exception(
        "Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        headers={"Access-Control-Allow-Origin": "*"},
        content={"detail": f"API error: {type(exc).__name__}: {exc}. "
                           "The API pod log carries the traceback."})


# CORS is registered LAST so Starlette makes it OUTERMOST: it answers
# preflights before tenancy runs, and it wraps CORS headers onto the tenancy
# middleware's own 400/403/503 responses - which otherwise reach a
# split-origin browser without Access-Control-Allow-Origin and render as a
# bare 'Network Error', hiding the actionable refusal copy.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(workspaces.router)
# Admin module — every route is behind require_platform_admin (declared
# on the router itself, so a new endpoint cannot be added unguarded).
app.include_router(admin.router)
app.include_router(studio.router)
app.include_router(studio_scripts_router)
app.include_router(barrier_insights.router)
app.include_router(hil_queue.router)
app.include_router(learning_console.router)
app.include_router(content_drafts.router)
app.include_router(conversations.router)
app.include_router(a2a_console.router)
app.include_router(capability_fabric.router)
app.include_router(source_data.router)
app.include_router(signals.router)
app.include_router(playbook_templates.router)
app.include_router(workflows.router)
app.include_router(sessions.router)
app.include_router(messages.router)
app.include_router(run_forensics.router)
app.include_router(documents.router)  # Include the documents router
app.include_router(s3.router, prefix="/api")
app.include_router(run_proxy.router)
app.include_router(runtime_status.router)
app.include_router(auth.router)
app.include_router(auth_info_qa.router)
app.include_router(agentfarm_sessions.router)
app.include_router(brand_router)
app.include_router(play_router)
app.include_router(mission_router)
app.include_router(get_skills_router())
app.include_router(get_cli_router())


@app.on_event("startup")
def _announce_auth_posture() -> None:
    """Say what this pod's authentication posture is, at startup, once.

    `IOF_AUTH_DEV` authenticates ANY credentials and mints a token carrying
    whatever email the caller typed. A validator searched 13,247 lines of
    startup and request log for it and found ZERO occurrences: the
    documentation says "never set this in a deployed environment" and the
    software did nothing whatever to notice. The engine refuses a
    non-loopback bind with auth off; this service cannot do that - uvicorn
    owns the bind and the app never sees it - so the least it can do is say
    so where an operator will read it.
    """
    try:
        from app.env_source import warn_if_unsafe
        warn_if_unsafe()
    except Exception:  # noqa: BLE001 - a warning must not stop startup
        pass


@app.on_event("startup")
def _ensure_studio_tables() -> None:
    """Best-effort idempotent ensure of the studio-owned engine-DB tables.

    The DB may be unreachable at boot (request-time URL resolution is the
    contract) — reads/writes lazily re-ensure per DB URL, so failure here is
    logged and non-fatal."""
    import logging
    log = logging.getLogger(__name__)
    try:
        from app.database import get_db
        from app.user_tables import ensure_user_tables
        from app.workflow_defs import ensure_defs_once
        with get_db() as con:
            # ensure_defs_once, not ensure_defs: this fills the shared memo,
            # so the first request does not re-run the same 16 statements.
            ensure_defs_once(con)
            # The auth tables shipped only in the PostgreSQL setup script, so a
            # fresh install answered its FIRST login with a 500 ("no such table:
            # user") rather than a 401. See app/user_tables.py.
            ensure_user_tables(con)
    except Exception as e:
        log.warning("studio_workflow_defs ensure deferred to first request: %s", e)


    # Pre-warm the studio's hot path off the request thread. Both of these are
    # process-lifetime caches whose COLD cost is seconds (importing the pack
    # registry; provisioning + seeding studio_agent_display over a remote DB),
    # and the agents list is fetched on every studio sidebar render — paying
    # that on a user's first click is what made the sidebar counts arrive late.
    import threading

    def _warm() -> None:
        try:
            from app.routers.studio import _role_pack_map
            _role_pack_map()
        except Exception as e:
            log.warning("pack map warmup deferred to first request: %s", e)
        try:
            from app import studio_display
            studio_display.all_display(fresh=True)
        except Exception as e:
            log.warning("agent display warmup deferred to first request: %s", e)
        # Tenant demo seed: workspace rows + per-workspace pack scoping + each
        # scoped tenant's workflow catalog — DB-driven and idempotent, so a
        # fresh environment reproduces the demo with no manual SQL. Runs off
        # the boot path: the catalog seed is dozens of WAN round trips.
        try:
            from app import workspace_settings, tenancy
            from app.database import get_db
            with get_db() as con:
                workspace_settings.ensure_table(con)
                workspace_settings.ensure_demo_workspaces(con)
            seeded = workspace_settings.seed_scoped_catalogs()
            tenancy.invalidate_cache()
            # Report per-workspace, and say what an error MEANS. The previous
            # message was "deferred to first request", which is not true —
            # nothing retries this — and it hid a hard AttributeError for as
            # long as it took someone to notice a tenant listing no workflows.
            failed = {k: v for k, v in seeded.items()
                      if isinstance(v, dict) and v.get("error")}
            if failed:
                log.warning(
                    "workspace scoping seed INCOMPLETE — these workspaces "
                    "will list no workflows until it succeeds or "
                    "`ioagentfarm sync` is run on the engine: %s", failed)
            else:
                log.info("workspace scoping seed complete (%d workspace(s))",
                         len(seeded))
        except Exception as e:
            log.warning("workspace scoping seed FAILED — scoped workspaces "
                        "will list no workflows until `ioagentfarm sync` runs "
                        "on the engine: %s", e)
        # Membership bootstrap. Closed membership means "no row, no access", so
        # a deployment with no admin has no one who can grant anyone access —
        # seed IOF_BOOTSTRAP_ADMIN before that bites. Separate try block: a
        # failure here must not be masked by the scoping seed's.
        try:
            from app import authz
            from app.config import get_settings as _gs
            from app.database import get_db as _get_db
            from app import workspace_settings as _wss
            with _get_db() as con:
                authz.ensure_bootstrap_admins(con)
                # The per-workspace member rows belong to the DEMO seed: a
                # platform admin (the `default` admin row above) already
                # reaches every workspace, and a fresh environment must not
                # gain rows for tenants it never created.
                if _wss.demo_seed_enabled():
                    for ws in [w["code"] for w in _wss._DEMO_WORKSPACES]:
                        for email in _gs().bootstrap_admins:
                            authz.ensure_workspace_seed_member(con, ws, email)
            log.info("membership bootstrap complete (enforce=%s)",
                     _gs().authz_enforce)
        except Exception as e:
            log.warning("membership bootstrap deferred to first request: %s", e)

    threading.Thread(target=_warm, name="studio-warmup", daemon=True).start()


@app.get("/api/health")
def health():
    """Health check, and this pod's authentication posture.

    An operator auditing a deployment should not need shell access to answer
    "is the dev bypass on here?". The posture carries no secret - two
    booleans and the path of the file that supplied them.
    """
    body = {"status": "ok"}
    try:
        from app.env_source import posture
        body["auth"] = posture()
    except Exception:  # noqa: BLE001 - health must answer regardless
        pass
    return body


@app.get("/api/agents")
def list_agents():
    """Agent registry — names, titles, colors, avatars from the DB."""
    from app.agents import _load_all
    return list(_load_all().values())
