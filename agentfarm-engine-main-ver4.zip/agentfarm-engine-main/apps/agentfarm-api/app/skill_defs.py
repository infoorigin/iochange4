"""Studio skill definitions — a skill's own DB row.

Before ``studio_skills`` a skill existed only as path-keyed entries inside
every carrying agent's ``files_json``: stored once per carrier, so one edit
wrote N files and re-snapshotted N whole workspaces, and a repo-imported
standalone skill had nowhere durable to live at all.

``roles_json`` IS the assignment — there is deliberately no agent<->skill
mapping table. ``_validate_skill_payload`` folds ``install_to`` into ``roles``
(installing a skill into an agent IS assigning it), so the row and the disk
cannot disagree; a mapping table would be a second answer to a question
already answered, free to drift from the first.

Assignment is not ELIGIBILITY. It records what an agent holds — its baseline —
and nothing consults it to refuse a skill to an agent: any skill in a workspace
may be assigned to any agent in it, and a workflow step resolves what the job
needs from the whole catalog (``engine.workspaces._resolve_skill``).

PACK SKILLS ARE NOT STORED HERE. They arrive in wheels and change on upgrade;
ingesting them would freeze a copy that goes stale the next time the SDK is
bumped. The Studio inventory is a union of this table and the pack sources.

Table DDL lives in the single shared implementation
(``ioagentfarm.workspace_sync.ensure_platform_schema``), reached through
``workflow_defs.ensure_defs`` — the same convention as the agent store.
Failures are logged, never raised: a save must not fail because the def
snapshot did.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

from ioagentfarm.engine.workspaces import PLATFORM_TIER

# The internal shared-tier key (the retired literal, kept for existing
# rows). NOT a workspace: requests can never resolve to it.
DEFAULT_WS = PLATFORM_TIER


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _rows(cur) -> list[dict]:
    return [r if isinstance(r, dict) else dict(r) for r in cur.fetchall()]


def list_defs(workspace_code: str) -> dict[str, dict]:
    """``{name: {files, roles, content_hash, version, origin}}``. Never raises.

    Resolved ONCE per read-only request: `_skill_catalog` and
    `agent_catalog.skill_carriage` both read this table while serving one
    page. See app/request_scope for why this is a request memo and not the
    time-based catalog cache that was tried and reverted.
    """
    from app import request_scope
    return request_scope.memo(f"skill_defs:{workspace_code}",
                              lambda: _list_defs_uncached(workspace_code))


def _list_defs_uncached(workspace_code: str) -> dict[str, dict]:
    try:
        from app.database import get_db, q
        from app import workflow_defs
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)
            cur = con.cursor()
            cur.execute(q("SELECT name, files_json, roles_json, content_hash,"
                          " version, origin FROM studio_skills "
                          "WHERE workspace_code = ?"), (workspace_code,))
            out: dict[str, dict] = {}
            for r in _rows(cur):
                try:
                    files = json.loads(r.get("files_json") or "{}")
                    roles = json.loads(r.get("roles_json") or "null")
                except json.JSONDecodeError:
                    continue
                if not isinstance(files, dict):
                    continue
                origin = r.get("origin") or ""
                # An ASSIGNMENT-ONLY row (pack skill): no content by design —
                # the wheel is the content. It must survive the content check
                # below, which exists to drop rows whose payload is unusable,
                # not rows that legitimately have none.
                if "SKILL.md" not in files and not (origin == "pack"
                                                    and not files):
                    continue
                out[r["name"]] = {
                    "files": files, "roles": roles,
                    "content_hash": r.get("content_hash") or "",
                    "version": r.get("version") or 1,
                    "origin": origin,
                    "assignment_only": origin == "pack" and not files,
                }
            return out
    except Exception as e:
        # No disk fallback exists any more (and on the pod there never was
        # one to fall back to). An empty catalog is the honest answer.
        logger.warning("skill def list failed: %s", e)
        return {}


def get_def(name: str, workspace_code: str) -> dict | None:
    return list_defs(workspace_code).get(name)


def _is_pack_row(name: str, workspace_code: str) -> bool:
    """True when *name* already has an assignment-only pack row here."""
    row = list_defs(workspace_code).get(name)
    return bool(row and row.get("assignment_only"))


def is_shared_skill(name: str) -> bool:
    """True for the tier a tenant may NOT take ownership of.

    ``pack_skills.shared`` — computed by the engine from ``reserved_names()``
    (core + the shared-skills wheel) and published on every sync — with the
    registry itself as the fallback for a host whose catalog has never been
    synced.

    This is what the content guard keys on, and it must be the SHARED tier and
    not "has a pack row". Every pack skill gets an assignment-only row now,
    including a DOMAIN pack's; shadowing one of those with a tenant copy is a
    supported choice (the Studio marks them editable). Forking a wheel's skill
    is the thing the tier exists to prevent.
    """
    try:
        from app.database import get_db, q
        with get_db() as con:
            cur = con.cursor()
            cur.execute(q("SELECT name, shared FROM pack_skills"))
            rows = _rows(cur)
        if rows:
            return any(r["name"] == name and r.get("shared") for r in rows)
    except Exception:
        logger.debug("pack_skills unreadable; falling back to reserved_names",
                     exc_info=True)
    try:
        from ioagentfarm.workspace_sync import reserved_names
        return name in reserved_names()[1]
    except Exception:
        return False


def upsert_pack_assignment(name: str, roles, workspace_code: str) -> None:
    """Record which agents hold a SHARED (wheel-owned) skill.

    The row is ``origin='pack'`` with ``files_json='{}'`` — assignment, never
    content. It exists so "this agent holds `presentation`" is durable and
    cluster-visible: pack skills are deliberately absent from the import and
    export paths (``reserved_names()``), so before this the only record was the
    directory on one host's disk, and a pod rebuilding from the database lost
    it silently.

    ONE record for the relation, for every tier. The alternative — a per-agent
    file listing shared-skill names — would answer "which agents have this
    skill?" only by opening and parsing every agent, which is the N-agent walk
    ``studio_skills`` was created to remove.
    """
    try:
        from app.database import get_db, placeholder, q
        from app import workflow_defs
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)      # table may not exist yet
            cur = con.cursor()
            cur.execute(
                q("INSERT INTO studio_skills (workspace_code, name, files_json,"
                  " roles_json, content_hash, version, updated_at, origin) "
                  "VALUES (?, ?, '{}', ?, '', 1, ?, 'pack') "
                  "ON CONFLICT (workspace_code, name) DO UPDATE SET "
                  "roles_json = excluded.roles_json, "
                  "version = studio_skills.version + 1, "
                  "updated_at = excluded.updated_at"),
                (workspace_code, name, json.dumps(roles), _now()))
            if placeholder() != "%s":
                con.commit()
    except Exception as e:
        logger.warning("pack assignment write failed for %s: %s", name, e)


def is_assignment_only(name: str, workspace_code: str) -> bool:
    """True when *name*'s row is a pack assignment (content lives in the wheel).
    The Studio needs this to take ``used_by`` from the row while still reading
    the skill's DESCRIPTION and body from the pack source."""
    return _is_pack_row(name, workspace_code)


def upsert_skill_def(name: str, files: dict[str, str],
                     roles: list[str] | str | None,
                     workspace_code: str,
                     origin: str = "studio") -> None:
    """Write the skill's content and assignment as ONE row.

    This is the whole point of the table: what used to be N file writes plus N
    full agent re-snapshots is a single statement, and hydration's composite
    sync key makes every carrier pick the change up on its next run.

    REFUSES to put content on a pack row. A shared skill has an assignment-only
    row (``origin='pack'``, ``files_json='{}'``) and its content comes from the
    wheel on every pull. Writing content here would freeze a tenant fork at
    today's version that no SDK upgrade reaches again — the exact defect
    ``reserved_names()`` keeps off the import and export paths. Enforced by the
    writer rather than left to convention, because a content-less row LOOKS
    like an oversight: the failure mode is somebody helpfully filling it in.
    """
    if files and origin != "pack" and _is_pack_row(name, workspace_code) \
            and is_shared_skill(name):
        logger.warning(
            "refusing to write content to the pack-assignment row for %r: "
            "shared skills are owned by the wheel and a tenant copy would "
            "freeze a fork no SDK upgrade reaches", name)
        return
    try:
        from ioagentfarm.workspace_sync import content_hash
        from app.database import get_db, placeholder, q
        from app import workflow_defs
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)
            cur = con.cursor()
            cur.execute(
                q("INSERT INTO studio_skills (workspace_code, name, files_json,"
                  " roles_json, content_hash, version, updated_at, origin) "
                  "VALUES (?, ?, ?, ?, ?, 1, ?, ?) "
                  "ON CONFLICT (workspace_code, name) DO UPDATE SET "
                  "files_json = excluded.files_json, "
                  "roles_json = excluded.roles_json, "
                  "content_hash = excluded.content_hash, "
                  "version = studio_skills.version + 1, "
                  "updated_at = excluded.updated_at"),
                (workspace_code, name, json.dumps(files), json.dumps(roles),
                 content_hash("", files), _now(), origin))
            if placeholder() != "%s":
                con.commit()
        logger.debug("skill def upserted: %s (%d file(s))", name, len(files))
    except Exception as e:
        logger.warning("skill def snapshot failed for %s (save still applied "
                       "on disk): %s", name, e)


def delete_skill_def(name: str, workspace_code: str) -> None:
    try:
        from app.database import get_db, placeholder, q
        from app import workflow_defs
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)
            cur = con.cursor()
            cur.execute(q("DELETE FROM studio_skills "
                          "WHERE workspace_code = ? AND name = ?"),
                        (workspace_code, name))
            if placeholder() != "%s":
                con.commit()
    except Exception as e:
        logger.warning("skill def delete failed for %s: %s", name, e)


def set_skill_roles(name: str, roles: list[str] | str | None,
                    workspace_code: str) -> None:
    """Rewrite one skill's assignment, leaving its CONTENT untouched.

    Carriage changes (an agent gains or loses a skill) must not restate
    ``files_json``: the row is the authority for content, and the caller here
    holds only one carrier's on-disk copy — writing that back would let a
    stale workspace overwrite an edit made through the skill builder.
    """
    try:
        from app.database import get_db, placeholder, q
        from app import workflow_defs
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)
            cur = con.cursor()
            cur.execute(
                q("UPDATE studio_skills SET roles_json = ?, "
                  "version = version + 1, updated_at = ? "
                  "WHERE workspace_code = ? AND name = ?"),
                (json.dumps(roles), _now(), workspace_code, name))
            if placeholder() != "%s":
                con.commit()
    except Exception as e:
        logger.warning("skill roles update failed for %s: %s", name, e)


def read_workspace_skills(ws) -> dict[str, dict[str, str]]:
    """``{skill_name: {rel_posix: content}}`` for one agent workspace's
    ``skills/`` tree. Binary-safe via the shared file codec."""
    from ioagentfarm.engine.filecodec import encode_file

    out: dict[str, dict[str, str]] = {}
    root = ws / "skills"
    if not root.is_dir():
        return out
    for d in sorted(root.iterdir()):
        if not d.is_dir() or not (d / "SKILL.md").is_file():
            continue
        files: dict[str, str] = {}
        for p in sorted(d.rglob("*")):
            if not p.is_file() or "__pycache__" in p.parts:
                continue
            v = encode_file(p)
            if v is not None:
                files[p.relative_to(d).as_posix()] = v
        if "SKILL.md" in files:
            out[d.name] = files
    return out


def sync_carried_skills(role: str, ws, workspace_code: str) -> None:
    """Record which skills an agent workspace CARRIES, as ``studio_skills`` rows.

    Without this a Studio-created agent lost skills on its first run, silently.
    ``studio_agent_defs`` stores identity files only (skills moved to their own
    table), so an agent's chosen skills lived nowhere but that host's disk —
    and ``hydrate_agent`` rebuilds a workspace by rmtree-ing it and replaying
    the DB payload. Any skill with no row was therefore deleted by the first
    run, including ``output_protocol``, which the Studio marks mandatory and
    which every step needs to emit ``STATUS:``/``OUTPUT:``.

    Carriage is reconciled, not merely added: a skill this role no longer has
    on disk loses the role, so ``remove_skills`` survives hydration too.

    ONE record for every tier, and pack/SDK skills are included — as
    ASSIGNMENT-ONLY rows (``origin='pack'``, no content; see
    :func:`upsert_pack_assignment`). Their content still comes from the wheel
    on every pull, so nothing freezes a fork, but "this agent holds
    `presentation`" is now durable and answerable with one SELECT instead of
    opening every agent workspace.

    **Existing rows keep their content.** Only the assignment is touched; see
    :func:`set_skill_roles`.

    Best-effort by contract, like every other writer in this module.
    """
    try:
        try:
            from ioagentfarm.workspace_sync import reserved_names
            _, shared = reserved_names()
        except Exception:            # registry unavailable — guard structure only
            shared = set()
        disk = read_workspace_skills(ws)
        _reconcile(role, disk, shared, workspace_code)
    except Exception as e:
        logger.warning("carried-skill sync failed for %s (save still applied "
                       "on disk): %s", role, e)


def sync_carried_skill_names(role: str, names: list[str],
                             pack_names: set[str],
                             workspace_code: str) -> None:
    """Record carriage from a LIST OF NAMES rather than a directory.

    The writer the Studio uses. Same reconciliation as
    :func:`sync_carried_skills` — additions and removals, one record for every
    tier — but it takes what the user chose instead of listing an agent
    workspace, because the API pod has none to list.

    A skill in *pack_names* gets an ASSIGNMENT-ONLY row: its content is the
    wheel's, resolved at materialisation by
    ``engine.workspaces.shared_skill_files``. Everything else must already
    have a content row (the Studio only offers skills that are in the
    catalog), so carriage is all there is to write.
    """
    try:
        _reconcile(role, {n: None for n in names}, set(pack_names),
                   workspace_code)
    except Exception as e:
        logger.warning("carried-skill sync failed for %s: %s", role, e)


def _reconcile(role: str, carried: dict, pack_names: set[str],
               workspace_code: str) -> None:
    """Make ``studio_skills.roles_json`` agree with *carried* for one role.

    ``carried`` maps name -> files (a directory snapshot) or name -> None (the
    Studio's name-only form). Existing rows keep their CONTENT either way:
    only the assignment is touched, so a carrier's stale copy can never
    overwrite an edit made in the skill builder.
    """
    existing = list_defs(workspace_code)

    for name, files in carried.items():
        row = existing.get(name)
        if row is None:
            if name in pack_names or files is None:
                # A pack skill, or a name-only assignment for a skill whose
                # row has not been created yet — either way the row we can
                # honestly write is the assignment, never invented content.
                upsert_pack_assignment(name, [role], workspace_code)
            else:
                upsert_skill_def(name, files, [role], workspace_code)
            continue
        roles = row.get("roles")
        if roles == "all":
            continue                 # already covers every role
        current = roles if isinstance(roles, list) else []
        if role not in current:
            set_skill_roles(name, sorted({*current, role}), workspace_code)

    # Reconcile removals: a row still assigned here but no longer carried.
    # Pack rows included — a removal has to be durable for every tier, or the
    # next pod rebuild hands the skill back.
    for name, row in existing.items():
        if name in carried:
            continue
        roles = row.get("roles")
        if isinstance(roles, list) and role in roles:
            set_skill_roles(name, sorted(set(roles) - {role}), workspace_code)


def carriers(roles: list[str] | str | None, known_roles: list[str]) -> list[str]:
    """Roles a ``roles_json`` value assigns to. ``None`` -> [] (unassigned:
    the skill exists in the catalog and is held by no agent — which is a
    starting state, not a refusal; anything may still be assigned it)."""
    if roles == "all":
        return sorted(known_roles)
    if isinstance(roles, list):
        return sorted(r for r in roles if r in known_roles)
    return []
