"""Engine routing — which engine serves which workspace. ENV-ONLY by design.

Every workspace can run its own engine (``ioagentfarm serve``), and this API
must reach the right one for the request's tenant. The topology lives in the
DEPLOYMENT ENVIRONMENT, never in the database: a database row naming an engine
URL survives restores and copies between environments, so a prod URL pasted
into a dev database — or a dev database restored from a prod snapshot — would
silently cross environments. Env vars are scoped to the pod that carries them
and die with it. Do not add a DB-backed override tier here.

Resolution order for ``engine_for(code)`` (most specific wins):

1. ``IOF_ENGINE_URLS``  — JSON map ``{"workspace_code": "http://host:8111"}``.
   Malformed JSON is refused LOUDLY at startup (``validate_topology()`` in
   main.py), never silently per request.
2. ``IOF_ENGINE_URL_TEMPLATE`` — e.g. ``http://engine-{workspace}.agents.svc:8111``;
   ``{workspace}`` is substituted with the workspace code.
3. ``IOF_RUN_API_URL`` — the single-engine deployment everyone runs today.
4. Nothing configured — ``http://127.0.0.1:8111`` (a literal address, not
   ``localhost``: see ``_DEFAULT_ENGINE``), so
   a local dev stack keeps working with zero configuration.

The optional identity handshake: when ``IOF_DEPLOYMENT`` is set on BOTH sides,
every rail request carries ``X-IOF-Deployment`` and the engine refuses a
mismatch with 409 — so a dev API misconfigured with a prod engine URL fails
loudly instead of running dev traffic against prod. One side unset = no check
(back-compat).

``mark_engine_seen`` / ``last_engine_seen`` record OBSERVED health per
workspace (a self-provisioned table, same pattern as app/user_tables.py) —
the difference between "being prepared" (never seen healthy: a brand-new
workspace whose engine is still being deployed) and "temporarily unreachable"
(was healthy, is not now). That distinction is presentation-critical: only the
second is an incident.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlsplit

from fastapi import HTTPException

logger = logging.getLogger(__name__)

#: 127.0.0.1, NOT localhost. `localhost` resolves to ::1 before 127.0.0.1, and
#: the local engine is started `--host 127.0.0.1` (the bind the Studio docs
#: prescribe, because the engine API has no authentication). The v6 attempt is
#: not refused — it hangs for ~2.2s before falling back, measured, on EVERY
#: catalog call whose connection had gone idle. A literal address cannot be
#: ambiguous about which family it means. Anything that really needs a name
#: sets IOF_RUN_API_URL / IOF_ENGINE_URLS / IOF_ENGINE_URL_TEMPLATE.
_DEFAULT_ENGINE = "http://127.0.0.1:8111"

#: parsed-map cache keyed on the RAW env value, so a monkeypatched env in
#: tests (or a hot-reloaded process) re-parses naturally.
_map_cache: tuple[str, dict[str, str]] | None = None


class EngineTopologyError(RuntimeError):
    """IOF_ENGINE_URLS is set but not a usable JSON object."""


def _engine_map() -> dict[str, str]:
    """The IOF_ENGINE_URLS map, parsed once per distinct env value.

    Raises :class:`EngineTopologyError` on malformed content — callers at
    startup let it propagate (loud), request-time callers never see it
    because startup already validated.
    """
    global _map_cache
    raw = os.getenv("IOF_ENGINE_URLS", "").strip()
    if not raw:
        return {}
    if _map_cache is not None and _map_cache[0] == raw:
        return _map_cache[1]
    try:
        parsed = json.loads(raw)
    except ValueError as exc:
        raise EngineTopologyError(
            f"IOF_ENGINE_URLS is not valid JSON: {exc}") from exc
    if not isinstance(parsed, dict) or not all(
            isinstance(k, str) and isinstance(v, str) and v.strip()
            for k, v in parsed.items()):
        raise EngineTopologyError(
            "IOF_ENGINE_URLS must be a JSON object mapping workspace codes "
            "to engine URLs, e.g. "
            '{"pharma_comm": "http://engine-pharma:8111"}')
    cleaned = {k: v.strip().rstrip("/") for k, v in parsed.items()}
    _map_cache = (raw, cleaned)
    return cleaned


def validate_topology() -> None:
    """Called at app startup: a malformed map kills the process LOUDLY.

    A per-request parse error would surface as intermittent 500s on some
    workspaces and not others — the exact silent-misroute shape this module
    exists to prevent.
    """
    _engine_map()
    template = os.getenv("IOF_ENGINE_URL_TEMPLATE", "").strip()
    if template and "{workspace}" not in template:
        raise EngineTopologyError(
            "IOF_ENGINE_URL_TEMPLATE must contain '{workspace}' "
            f"(got: {template!r})")


@dataclass(frozen=True)
class ResolvedEngine:
    url: str
    via: str  # "map" | "template" | "fallback" | "none"


def resolve_engine(workspace_code: str) -> ResolvedEngine:
    mapped = _engine_map().get(workspace_code)
    if mapped:
        return ResolvedEngine(mapped, "map")
    template = os.getenv("IOF_ENGINE_URL_TEMPLATE", "").strip()
    if template:
        return ResolvedEngine(
            template.replace("{workspace}", workspace_code).rstrip("/"),
            "template")
    fallback = os.getenv("IOF_RUN_API_URL", "").strip()
    if fallback:
        return ResolvedEngine(fallback.rstrip("/"), "fallback")
    return ResolvedEngine(_DEFAULT_ENGINE, "none")


def engine_for(workspace_code: str) -> str:
    """The engine base URL serving ``workspace_code`` (no trailing slash)."""
    return resolve_engine(workspace_code).url


def _active_workspace() -> str:
    from app.workspace_context import active_code
    return active_code()


def active_engine_base() -> str:
    """Engine base for the request's tenant (middleware-resolved)."""
    return engine_for(_active_workspace())


# ── the rail's HTTP client: made once, kept ──────────────────────────────────
#
# `engine_json` used to open a fresh `httpx.Client` per call, so every catalog
# read paid a full connect. Two costs, both measured on the local stack:
#
#  * ~0.2s of client construction and TCP setup per call; and
#  * ~2.2s when the engine base is a NAME rather than a literal address.
#    `localhost` resolves to ::1 before 127.0.0.1, `ioagentfarm serve --host
#    127.0.0.1` listens on IPv4 only, and the v6 attempt is not refused — it
#    hangs until it gives up. The zero-config default IS `http://localhost:8111`
#    (see the resolution order above), and a dual-stack cluster can present the
#    same shape for a service DNS name, so this is not only a laptop problem.
#
# A kept client makes that a once-per-process cost instead of a per-call one:
# `/api/studio/workflows` makes one list call plus one detail call per
# workflow, and eight of those were 19s of a 22s request.
#
# The cache re-makes itself whenever `httpx.Client` is not the object it was
# built from. That is what keeps the tests that monkeypatch `httpx.Client`
# honest — a cached real client would quietly ignore the patch, and the patch
# coming back off has to be noticed too.
_rail_client_obj: Any = None
_rail_client_factory: Any = None
_rail_client_lock = threading.Lock()


def _rail_client(httpx):
    global _rail_client_obj, _rail_client_factory
    with _rail_client_lock:
        if _rail_client_obj is None or _rail_client_factory is not httpx.Client:
            stale, _rail_client_obj = _rail_client_obj, httpx.Client()
            _rail_client_factory = httpx.Client
            if stale is not None:
                try:
                    stale.close()
                except Exception:      # a test double need not be closeable
                    pass
        return _rail_client_obj


def reset_rail_client() -> None:
    """Drop the kept client (tests, and a forced reconnect)."""
    global _rail_client_obj, _rail_client_factory
    with _rail_client_lock:
        stale, _rail_client_obj = _rail_client_obj, None
        _rail_client_factory = None
    if stale is not None:
        try:
            stale.close()
        except Exception:
            pass


def rail_headers() -> dict[str, str]:
    """Everything an outbound engine call carries. THE one builder.

    Three things, and they are three because they answer three different
    questions the engine asks:

    ``X-IOF-Deployment`` — *which environment am I?* An identity check, not a
        credential: it makes a dev API pointed at a prod engine URL fail loudly
        on its first call. Both sides unset means no check.

    The credential — *am I a known workload?* An OAuth 2.0 client-credentials
        bearer (Entra ID / Okta) or a shared key, resolved by
        ``ioagentfarm.security.rail`` from the same ``IOF_ENGINE_CRED_*``
        variables the CLI reads. Empty against an engine running
        ``IOF_ENGINE_AUTH=off``, which is every local stack today, so nothing
        changes until an engine starts asking.

    ``X-IOF-Actor`` — *who is this FOR?* The end user this API already
        verified. Without it the engine attributes every run to the API pod.
        The engine honours it only from an authenticated caller, so it is an
        assertion by a known service rather than a claim by an anonymous one.

    ONE builder rather than three, because the failure mode of several is a
    call site that carries two of them: an engine call missing the credential
    is a 401 you find immediately, but one missing only the ACTOR is a silent
    hole in the audit trail that nothing surfaces.
    """
    headers: dict[str, str] = {}

    ident = os.getenv("IOF_DEPLOYMENT", "").strip()
    if ident:
        headers["X-IOF-Deployment"] = ident

    try:
        from ioagentfarm.security.rail import engine_auth_headers
        headers.update(engine_auth_headers())
    except Exception:  # noqa: BLE001
        # Never fail an engine call while BUILDING its headers. An acquisition
        # failure already degrades to no-header inside engine_auth_headers();
        # this catches the import itself failing on an older core, so an API
        # pod ahead of its engine keeps working instead of 500ing every route.
        logger.exception("could not build the engine rail credential headers")

    try:
        from app.actor_context import current_actor
        actor = current_actor()
        if actor:
            headers["X-IOF-Actor"] = actor
    except Exception:  # noqa: BLE001 — attribution is never worth a failure
        logger.debug("no actor context for this call", exc_info=True)

    return headers


#: The name the rail builder had when it carried only the deployment header.
#: Kept as an ALIAS rather than deleted, and pointing at the FULL builder on
#: purpose: any call site still using the old name — here, in a test, or in a
#: deployment's own patch — keeps sending the credential. The alternative
#: (leaving it as the old identity-only function) is a call site that silently
#: goes anonymous and 401s only once an engine turns auth on.
deployment_headers = rail_headers


# ── observed engine health (self-provisioned, additive) ──────────────────────

def _ensure_health_table(con) -> None:
    # Idempotent per call, NOT memoized per process: the DB behind get_db can
    # change under us (tests use a fresh in-memory DB per case; request-time
    # URL resolution is the deployment contract).
    con.cursor().execute(
        "CREATE TABLE IF NOT EXISTS studio_engine_health ("
        "  workspace_code TEXT PRIMARY KEY,"
        "  last_seen_at   TEXT NOT NULL"
        ")")
    con.commit()


#: Lazily created single worker that files health notes off the hot path.
_seen_pool: "ThreadPoolExecutor | None" = None
#: Most recent queued write; one worker + FIFO makes it the barrier.
_last_write: Any = None
#: workspace_code -> the newest timestamp queued but NOT yet written. See
#: `_submit_engine_seen` for why a second note for a workspace already in
#: here replaces the value instead of queueing another job.
_seen_pending: dict[str, str] = {}
_seen_lock = threading.Lock()


def reset_seen_throttle() -> None:
    """Forget any queued health write (tests, and a forced re-record)."""
    global _last_write
    with _seen_lock:
        _last_write = None
        _seen_pending.clear()


def mark_engine_seen(workspace_code: str) -> None:
    """Record that this workspace's engine answered — observed state.

    Best-effort, and OFF THE HOT PATH — see :func:`_submit_engine_seen`.
    Health bookkeeping must never fail the rail call whose success it is
    recording, and it must not dominate it either: it used to cost ~626ms
    against ~116ms for the HTTP request it annotates.
    """
    if not workspace_code:
        return
    _submit_engine_seen(workspace_code, datetime.now(timezone.utc).isoformat())


def _submit_engine_seen(workspace_code: str, now: str) -> None:
    """Hand the write to a background worker — the rail call never waits.

    Each record is a connection, a CREATE TABLE IF NOT EXISTS, an UPDATE and
    a COMMIT: ~626ms measured, against ~116ms for the HTTP request it was
    annotating. An inventory making 25 engine calls therefore spent fifteen
    seconds filing the same note twenty-five times, on the request's clock.

    A caller is reporting that the engine ANSWERED; nothing about the answer
    depends on the note being filed first, so this is pure overhead to move
    off the path. Dispatching alone recovered the whole cost - a throttle
    was tried first and measured IDENTICAL, so it was removed rather than
    kept as a second mechanism with its own cross-database state to get
    wrong.

    One worker, so concurrent rail calls cannot pile writes onto SQLite at
    once and the notes are filed in order - which is what lets
    :func:`flush_engine_seen` use the newest write as a barrier.

    COALESCED, and that is not the throttle this docstring says was tried and
    removed. A throttle DROPS notes on a timer and has to hold cross-database
    state to decide; this drops nothing and holds nothing. The column is
    `last_seen_at` - state, not an event log - so several notes for one
    workspace that have not been written YET have exactly one meaning
    between them, the newest. Filing them separately writes the same row
    three times over.

    Off the hot path is not free either, which is what moved this: a studio
    list makes one rail call per item, so `/api/studio/skills` queued seven
    notes, each a CREATE TABLE IF NOT EXISTS + UPDATE + COMMIT, and the
    worker held a pool connection for ~0.5s per note while the request
    thread wanted one. A/B measured on the live stack: skills 6.4s -> 3.9s,
    workflows 4.7s -> 2.8s.
    """
    global _seen_pool
    with _seen_lock:
        if _seen_pool is None:
            _seen_pool = ThreadPoolExecutor(
                max_workers=1, thread_name_prefix="engine-health")
        pool = _seen_pool
        queued = workspace_code in _seen_pending
        _seen_pending[workspace_code] = now      # newest wins
        if queued:
            # A job for this workspace has not run yet; it will pick the
            # timestamp up from _seen_pending. Nothing is lost by not
            # queueing a second one.
            return
    global _last_write
    try:
        fut = pool.submit(_write_pending_engine_seen, workspace_code)
    except RuntimeError:
        # Interpreter shutting down, or the pool was closed under us.
        # Bookkeeping is never worth an exception on the caller's path.
        with _seen_lock:
            _seen_pending.pop(workspace_code, None)
        logger.debug("engine-health write not scheduled for %s", workspace_code)
        return
    with _seen_lock:
        _last_write = fut


def _write_pending_engine_seen(workspace_code: str) -> None:
    """Write whatever note is outstanding for *workspace_code*.

    Claiming (popping) BEFORE the write is what re-opens the workspace to
    queueing: a note arriving while this one is being written gets its own
    job rather than being folded into a write already in flight.
    """
    with _seen_lock:
        now = _seen_pending.pop(workspace_code, None)
    if now is None:
        return
    _write_engine_seen(workspace_code, now)


def flush_engine_seen(timeout: float = 5.0) -> None:
    """Wait for queued health writes to land.

    ONE worker and FIFO submission, so waiting on the most recent write
    waits for every earlier one too. The pool is left alive - this is a
    barrier, not a shutdown, and it is called on the read path.
    """
    with _seen_lock:
        fut = _last_write
    if fut is not None:
        try:
            fut.result(timeout=timeout)
        except Exception:  # noqa: BLE001 - bookkeeping, never the caller's fate
            logger.debug("engine-health write did not complete", exc_info=True)


def shutdown_engine_seen(timeout: float = 5.0) -> None:
    """Stop the health writer and WAIT for it, then drop the pool.

    :func:`flush_engine_seen` is deliberately a barrier that leaves the pool
    alive, because it is called on the read path. This is the other thing -
    the one a teardown needs - and the distinction is what the crash was made
    of.

    THE CRASH. The writer runs on a ThreadPoolExecutor so a note never sits on
    a request, which means it can still be inside `_ensure_health_table` when
    whoever owns the connection decides it is finished. In the API suite that
    owner is the `test_db` fixture, holding one in-memory SQLite connection
    opened `check_same_thread=False`; teardown called `con.close()` while the
    worker was mid-statement, and closing a sqlite3 connection out from under
    a thread using it is a use-after-free in the C layer, not a Python error.
    It surfaced as `Windows fatal exception: access violation` and killed the
    whole pytest process, so a shard reported no summary at all and the suite
    total silently lost ~123 tests.

    Load is what made it look like flakiness: the wider the machine is
    stretched the likelier the worker is still running at teardown, so it fired
    when two gate runs overlapped and never when one ran alone. Every session
    hit the same thing and re-derived the same dead end.

    Idempotent, and the pool is dropped rather than merely shut down: a later
    `mark_engine_seen` builds a fresh one, so a process that tears down many
    times (every test) keeps working.
    """
    global _seen_pool, _last_write
    with _seen_lock:
        pool, fut = _seen_pool, _last_write
        _seen_pool = None
        _last_write = None
        _seen_pending.clear()
    if fut is not None:
        try:
            fut.result(timeout=timeout)
        except Exception:  # noqa: BLE001 - bookkeeping, never the caller's fate
            logger.debug("engine-health write did not finish", exc_info=True)
    if pool is not None:
        # `wait=True` is the entire point: returning before the worker has
        # stopped is what left it running into the connection's close.
        pool.shutdown(wait=True)


def _write_engine_seen(workspace_code: str, now: str) -> None:
    """The health UPSERT itself, split out so the throttle above it is
    testable by counting writes rather than by timing them."""
    try:
        from app.database import get_db, q
        with get_db() as con:
            _ensure_health_table(con)
            cur = con.cursor()
            cur.execute(q("UPDATE studio_engine_health SET last_seen_at=? "
                          "WHERE workspace_code=?"), (now, workspace_code))
            if getattr(cur, "rowcount", 0) == 0:
                cur.execute(q("INSERT INTO studio_engine_health "
                              "(workspace_code, last_seen_at) VALUES (?, ?)"),
                            (workspace_code, now))
            con.commit()
    except Exception:  # noqa: BLE001 — bookkeeping, never the request's fate
        logger.debug("mark_engine_seen(%s) failed", workspace_code,
                     exc_info=True)


def last_engine_seen(workspace_code: str) -> str | None:
    # Health writes are dispatched to a worker so no rail call waits on
    # them; the READ waits instead, which is where consistency is actually
    # wanted and where the cost is paid once rather than per engine call.
    flush_engine_seen()
    try:
        from app.database import get_db, q
        with get_db() as con:
            _ensure_health_table(con)
            cur = con.cursor()
            cur.execute(q("SELECT last_seen_at FROM studio_engine_health "
                          "WHERE workspace_code=?"), (workspace_code,))
            row = cur.fetchone()
            return row["last_seen_at"] if row else None
    except Exception:  # noqa: BLE001
        logger.debug("last_engine_seen(%s) failed", workspace_code,
                     exc_info=True)
        return None


def probe_engine(base_url: str, timeout: float = 3.0) -> bool:
    """One live liveness probe against the engine's ``/health``."""
    try:
        import httpx
        with httpx.Client(timeout=timeout) as client:
            r = client.get(f"{base_url}/health",
                           headers=rail_headers())
        return r.status_code == 200
    except Exception:  # noqa: BLE001 — any failure is simply "not reachable"
        return False


def masked_host(base_url: str) -> str:
    """Hostname[:port] only — what the admin topology view shows.

    Full URLs stay out of every response body; scheme, path and any userinfo
    are dropped here rather than trusted to the caller.
    """
    parts = urlsplit(base_url)
    host = parts.hostname or ""
    return f"{host}:{parts.port}" if parts.port else host


# ── the shared rail helper ───────────────────────────────────────────────────

def engine_json(method: str, path: str, *, purpose: str,
                timeout: float = 30.0, params: dict | None = None,
                json_body: dict | None = None,
                workspace_code: str | None = None, **kw) -> dict:
    """Call the tenant's engine and return its JSON — the ONE rail.

    ``purpose`` finishes the 502 detail ("— <purpose>") so each console keeps
    its specific "lives on the engine host, not here" explanation. Engine
    error statuses pass through; success records observed health for the
    workspace's runtime-state answer.
    """
    try:
        import httpx
    except ImportError:  # pragma: no cover - httpx ships with the venv
        raise HTTPException(status_code=503,
                            detail="httpx not installed on the API host")
    if "json" in kw:  # callers that speak httpx's own kwarg name
        json_body = kw.pop("json")
    code = workspace_code if workspace_code is not None else _active_workspace()
    base = engine_for(code)
    url = f"{base}{path}"
    # ONE retry, and only on a failure to CONNECT. This is the cost of keeping
    # the client: a pooled connection outlives the request that opened it, so
    # the peer can close it in between — an engine pod restarting, an idle
    # timeout, a load balancer recycling. The next call then reaches for a
    # socket that is already gone.
    #
    # Observed exactly that way: the engine was restarted, the very next turn
    # came back "engine unreachable" while the engine was demonstrably serving,
    # and the call after it succeeded. A per-call client could never fail this
    # way, so the retry is what pays for the connection reuse.
    #
    # ConnectError/ConnectTimeout ONLY. They mean no request was delivered, so
    # replaying is free. A `RemoteProtocolError` is NOT retried: the server may
    # have received the request and died answering it, and these calls are not
    # all idempotent — replaying a chat turn would spend a second LLM call and
    # could double-write. A lost response is the caller's to handle.
    for attempt in (1, 2):
        try:
            client = _rail_client(httpx)
            r = client.request(method, url, params=params, json=json_body,
                               headers=rail_headers(), timeout=timeout,
                               **kw)
            break
        except (httpx.ConnectError, httpx.ConnectTimeout) as exc:
            if attempt == 1:
                logger.info("engine call %s %s could not connect (%s) — "
                            "dropping the kept client and retrying once",
                            method, url, type(exc).__name__)
                reset_rail_client()
                continue
            logger.warning("engine call %s %s failed: %s", method, url, exc)
            raise HTTPException(
                status_code=502,
                detail=f"engine API for workspace '{code}' unreachable "
                       f"(set IOF_ENGINE_URLS / IOF_ENGINE_URL_TEMPLATE / "
                       f"IOF_RUN_API_URL) — {purpose}")
        except httpx.HTTPError as exc:
            logger.warning("engine call %s %s failed: %s", method, url, exc)
            raise HTTPException(
                status_code=502,
                detail=f"engine API for workspace '{code}' unreachable "
                       f"(set IOF_ENGINE_URLS / IOF_ENGINE_URL_TEMPLATE / "
                       f"IOF_RUN_API_URL) — {purpose}")
    mark_engine_seen(code)
    if r.status_code >= 400:
        detail = r.text[:400]
        try:
            detail = r.json().get("detail", detail)
        except ValueError:
            pass
        raise HTTPException(status_code=r.status_code, detail=detail)
    try:
        return r.json()
    except ValueError:
        raise HTTPException(status_code=502,
                            detail="engine returned a non-JSON response")
