"""Token verification — the trust boundary for every authenticated request.

Before this module existed, the two endpoints that read a JWT
(``routers/workspaces.py`` and ``routers/sessions.py``) base64-decoded the
payload and used it: the third segment was never touched and ``exp`` was never
compared, so a **forged or expired** token authenticated exactly like a real
one. Membership enforcement on top of that would have been decoration.

Why symmetric verification is sufficient
----------------------------------------
Every token this platform accepts is minted by this platform. DB login and
Microsoft Entra SSO both end at ``auth.py::_create_access_token`` — MSAL
validates the Entra ``id_token`` at the callback, and we then issue **our own**
HS256 token (the classic BFF/token-exchange shape). So there is one format and
one secret; no JWKS fetch, no key rotation. ``auth_info_qa.py`` is a second
minter sharing that secret, so its tokens verify here too.

ENTRA PASS-THROUGH SEAM (not built — deliberate)
------------------------------------------------
If a deployment ever has the SPA hold an Entra access token directly, this is
the one place that changes: dispatch on the ``iss`` claim and verify RS256
against cached JWKS. That branch MUST pin ``aud`` (and ``tid`` for a
multi-tenant app) — without the audience check, a token minted for any other
app in the same directory would be accepted here. Authorization above this
module is unaffected: it consumes an ``Identity``, not a token.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
from dataclasses import dataclass, field

from fastapi import HTTPException

from app.config import get_settings

#: Only the algorithm we mint with. A token's own header is attacker-controlled,
#: so it is checked against this rather than trusted — the ``alg: none`` /
#: algorithm-confusion hole.
_ALLOWED_ALG = "HS256"

#: Small leeway for clock skew between the minting and verifying hosts.
_EXP_LEEWAY_S = 60


@dataclass(frozen=True)
class Identity:
    """A verified caller. Never constructed from unverified input."""

    email: str
    user_id: str = ""
    role: str = "user"
    claims: dict = field(default_factory=dict)
    #: True when synthesised by the IOF_AUTH_DEV bypass rather than verified.
    is_dev: bool = False


class TokenError(Exception):
    """Verification failed. The message is for logs, never for the client —
    callers surface a generic 401 so a probe cannot distinguish 'bad
    signature' from 'expired' from 'malformed'."""


def _b64url_decode(seg: str) -> bytes:
    return base64.urlsafe_b64decode(seg + "=" * ((4 - len(seg) % 4) % 4))


def _dev_bypass_enabled() -> bool:
    # Read at call time (not through cached Settings) to match auth.py's
    # bypass, which is deliberately outside the Settings cache.
    return os.getenv("IOF_AUTH_DEV", "") == "1"


def verify_token(token: str, secret: str | None = None) -> Identity:
    """Verify *token* and return the caller's :class:`Identity`.

    Mirrors ``auth.py::_jwt_encode_hs256`` exactly. Raises :class:`TokenError`
    on any failure — malformed, wrong algorithm, bad signature, or expired.
    """
    secret = secret if secret is not None else get_settings().auth_jwt_secret

    parts = (token or "").split(".")
    if len(parts) != 3:
        raise TokenError("malformed token (expected 3 segments)")
    header_b64, payload_b64, sig_b64 = parts

    try:
        header = json.loads(_b64url_decode(header_b64))
    except Exception as exc:
        raise TokenError(f"undecodable header: {exc}") from exc
    if header.get("alg") != _ALLOWED_ALG:
        raise TokenError(f"unexpected alg {header.get('alg')!r}")

    expected = hmac.new(
        secret.encode("utf-8"),
        f"{header_b64}.{payload_b64}".encode("ascii"),
        hashlib.sha256,
    ).digest()
    try:
        presented = _b64url_decode(sig_b64)
    except Exception as exc:
        raise TokenError(f"undecodable signature: {exc}") from exc
    # Constant-time: a plain == here leaks signature bytes through timing.
    if not hmac.compare_digest(expected, presented):
        raise TokenError("signature mismatch")

    try:
        claims = json.loads(_b64url_decode(payload_b64))
    except Exception as exc:
        raise TokenError(f"undecodable payload: {exc}") from exc

    exp = claims.get("exp")
    if exp is None:
        raise TokenError("token has no exp")
    try:
        if float(exp) + _EXP_LEEWAY_S < time.time():
            raise TokenError("token expired")
    except (TypeError, ValueError) as exc:
        raise TokenError(f"unreadable exp: {exc}") from exc

    # The claims _create_access_token actually mints; 'email' is accepted as a
    # forward-compatible alias (an Entra branch would supply it).
    email = (claims.get("unique_name") or claims.get("userName")
             or claims.get("email") or "").strip()
    if not email:
        raise TokenError("token carries no identity claim")

    role = str((claims.get("customClaims") or {}).get("role") or "user")
    return Identity(email=email.lower(), user_id=str(claims.get("userId") or ""),
                    role=role, claims=claims)


def maybe_identity(authorization: str | None) -> Identity | None:
    """The verified caller, or ``None`` — never raises.

    The non-raising sibling of :func:`identity_from_header`, for the ATTRIBUTION
    path: ``app/actor_context.py``'s middleware runs on every request including
    the exempt ones (login, health, docs), where an absent or unverifiable token
    is normal rather than an error. Raising there would put a second, weaker
    copy of the guard in front of the real one — able to refuse requests
    ``require_member`` would have allowed.

    The dev bypass is deliberately NOT honoured here. Under ``IOF_AUTH_DEV`` the
    real dependency synthesises ``dev@local`` so a local stack works; stamping
    that onto engine-side audit records would write a fictitious human into the
    trail. No identity is the honest answer.
    """
    header = (authorization or "").strip()
    if header[:7].lower() != "bearer ":
        return None
    presented = header[7:].strip()
    if not presented:
        return None
    try:
        return verify_token(presented)
    except TokenError:
        return None


def identity_from_header(authorization: str | None) -> Identity:
    """Verified caller from an ``Authorization: Bearer`` header, or 401.

    With ``IOF_AUTH_DEV=1`` an absent/invalid header yields a synthetic dev
    identity — the same local-development affordance the login endpoint has.
    A *valid* token is still honoured in dev so real users can be exercised.
    """
    token = ""
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()

    if token:
        try:
            return verify_token(token)
        except TokenError:
            if _dev_bypass_enabled():
                return Identity(email="dev@local", user_id="dev", is_dev=True)
            # Deliberately generic: do not tell a prober WHY it failed.
            raise HTTPException(status_code=401, detail="Invalid or expired token")

    if _dev_bypass_enabled():
        return Identity(email="dev@local", user_id="dev", is_dev=True)
    raise HTTPException(status_code=401, detail="Missing bearer token")
