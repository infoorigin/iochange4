"""Where the Studio API's configuration comes from — named, not guessed.

THE DEFECT. `app/config.py` opened with a bare ``load_dotenv()``. That walks
UP from the working directory until it finds a `.env`, so the API's
configuration came from whatever file happened to sit above wherever it was
started. A validator started an API deliberately WITHOUT ``IOF_AUTH_DEV`` and
`POST /api/auth/login` minted a token for password `"anything"` — because an
ambient `.env` supplied the bypass.

This is the exact hazard `CLAUDE.md` documents at length and records as fixed
for the CLI: *"`find_dotenv` walks UP, and on Windows project and temp
directories sit under the home directory, so it was reachable from almost
anywhere"*. The CLI was fixed; the API kept it, for its AUTHENTICATION
POSTURE. Silence and "it had no effect" looked identical.

WHAT THIS DOES. It loads the same values, and it RECORDS which file supplied
them, so `aicore current`'s "set by" idea exists here too. The real
environment still outranks a file — a pod's own variables win, as they must.

WHAT IT REFUSES. A file above the working directory is no longer searched by
default: the API reads a `.env` NEXT TO the application, or one named
explicitly by ``IOF_API_ENV_FILE``. An operator who wants the old behaviour
sets ``IOF_API_ENV_WALK_UP=1`` and gets a warning naming the file it found —
because a configuration source you cannot name is one you cannot audit.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

#: Set by :func:`load`, read by the health surface so a deployment can be
#: audited without shell access to the pod.
SOURCE: Optional[str] = None

#: Files that were found and deliberately NOT loaded, so silence is
#: distinguishable from "there was nothing there".
IGNORED: list[str] = []


def _candidates() -> list[Path]:
    """In order of precedence. The first that exists wins."""
    explicit = (os.environ.get("IOF_API_ENV_FILE") or "").strip()
    out: list[Path] = []
    if explicit:
        out.append(Path(explicit))
    here = Path(__file__).resolve().parent          # app/
    out.append(here.parent / ".env")                # apps/agentfarm-api/.env
    out.append(Path.cwd() / ".env")                 # where it was started
    return out


def load() -> Optional[str]:
    """Load one env file and return its path, or None. Never raises."""
    global SOURCE
    try:
        from dotenv import load_dotenv, find_dotenv
    except Exception:  # noqa: BLE001 - dotenv absent is not fatal
        return None

    for path in _candidates():
        try:
            if path.is_file():
                load_dotenv(path, override=False)
                SOURCE = str(path)
                logger.info("Studio API configuration: %s", SOURCE)
                return SOURCE
        except Exception:  # noqa: BLE001
            continue

    # The old behaviour, now opt-in and loud.
    if (os.environ.get("IOF_API_ENV_WALK_UP") or "").strip() in ("1", "true", "yes"):
        try:
            found = find_dotenv(usecwd=True)
        except Exception:  # noqa: BLE001
            found = ""
        if found:
            load_dotenv(found, override=False)
            SOURCE = found
            logger.warning(
                "Studio API configuration read from %s, found by walking UP "
                "from the working directory (IOF_API_ENV_WALK_UP=1). This is "
                "how an ambient file silently supplied IOF_AUTH_DEV once. "
                "Name the file with IOF_API_ENV_FILE instead.", found)
            return SOURCE
    else:
        try:
            found = find_dotenv(usecwd=True)
            if found and not any(Path(found) == c for c in _candidates()):
                IGNORED.append(found)
                logger.info(
                    "Studio API: %s exists above the working directory and "
                    "was NOT loaded. Set IOF_API_ENV_FILE to use it, or "
                    "IOF_API_ENV_WALK_UP=1 for the old behaviour.", found)
        except Exception:  # noqa: BLE001
            pass

    logger.info("Studio API configuration: environment only (no .env loaded)")
    return None


def posture() -> dict:
    """What an operator needs to audit this pod, without shell access.

    `IOF_AUTH_DEV` authenticates ANY credentials and mints a token carrying
    whatever email was typed. A validator found 13,247 lines of startup and
    request log containing zero occurrences of it — the doc says "never set
    this in a deployed environment" and the software did nothing to notice.
    """
    dev = (os.environ.get("IOF_AUTH_DEV") or "").strip().lower() in (
        "1", "true", "yes")
    enforce = (os.environ.get("IOF_AUTHZ_ENFORCE") or "1").strip().lower() \
        not in ("0", "false", "no")
    return {
        "env_file": SOURCE,
        "env_files_ignored": list(IGNORED),
        "auth_dev_bypass": dev,
        "membership_enforced": enforce,
    }


def warn_if_unsafe() -> None:
    """Say it at startup, once, where an operator will see it."""
    state = posture()
    if state["auth_dev_bypass"]:
        logger.warning(
            "IOF_AUTH_DEV IS ON: any credentials authenticate, and the token "
            "carries whatever email the caller types. This must never be set "
            "in a deployed environment.%s",
            f" It came from {SOURCE}." if SOURCE else "")
    if not state["membership_enforced"]:
        logger.warning(
            "IOF_AUTHZ_ENFORCE is off: identity is verified but workspace "
            "membership is NOT enforced.%s",
            f" It came from {SOURCE}." if SOURCE else "")
