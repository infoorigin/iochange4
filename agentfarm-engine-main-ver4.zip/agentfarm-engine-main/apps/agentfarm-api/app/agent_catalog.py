"""What the Studio knows about agents and skills — read from the ENGINE.

THE RULE THIS EXISTS TO ENFORCE. The API pod and the engine pod are separate
Kubernetes pods and are never co-located. The API therefore has no agent home,
no pack installation and no engine state directory. Under the One Truth
content model (``docs/one-truth-content-model.md`` s4.3) the BASE tier — what
the installed packs ship — is read FROM THE ENGINE's pack-resolved catalog
(``app/engine_catalog.py`` -> ``GET /api/catalog/agents|skills``), so the
Studio shows what the environment is actually running, stamped
(``pharma 0.3.0 @ 5eee3fd``). The ``agents`` / ``pack_skills`` content
tables are no longer read: a database mirror of the wheels is a second home
for content, and a second home is the defect the model removes.

WHERE EACH ANSWER COMES FROM. Two tiers, and the ENGINE tier wins:

  ============  ===============================  ==========================
  question      base tier (engine catalog)       tenant tier (per workspace)
  ============  ===============================  ==========================
  agent files   GET /api/catalog/agents/{role}   ``studio_agent_defs.files_json``
                                                 ONLY when the engine has no
                                                 agent of that role (add-only)
  agent skills  catalog ``skills`` + carriage    ``studio_skills.roles_json`` +
                rows                             ``.skills-assigned.json``
  skill body    GET /api/catalog/skills/{name}   ``studio_skills.files_json``
                                                 ONLY when the engine has no
                                                 skill of that name (add-only)
  who holds it  — never; see below               ``studio_skills.roles_json``
  ============  ===============================  ==========================

THE TRANSITIONAL ADD-ONLY RULE. A tenant row is shown only when the engine
catalog has no item of that name — it ADDS, never shadows — and such an item
is marked ``unpromoted: True`` (a Studio-authored / imported agent no pack
provides yet). Until drafts land, that is the whole tenant content tier.

CARRIAGE IS NEVER TAKEN FROM THE ENGINE TIER. ``used_by`` on a catalog item
would be meaningless (a wheel does not know which tenant's agents hold its
skill), so assignment comes from ``studio_skills.roles_json`` for every tier
— pack skills included, via their assignment-only rows. The catalog's own
per-agent ``skills`` list is the BASELINE a pack agent carries; carriage rows
are unioned onto it.

AN UNREACHABLE ENGINE IS A 502, NEVER AN EMPTY LIST — ``engine_catalog``
raises, and nothing here catches it into ``{}``.
"""

from __future__ import annotations

import json
import logging

logger = logging.getLogger(__name__)

from ioagentfarm.engine.workspaces import PLATFORM_TIER

# The internal shared-tier key (the retired literal, kept for existing
# rows). NOT a workspace: requests can never resolve to it.
DEFAULT_WS = PLATFORM_TIER

#: Written by :func:`ioagentfarm.engine.workspaces.record_skill_assignment`
#: into the agent workspace, and carried in ``studio_agent_defs.files_json``.
#: NAMES only — the shared skills this agent holds, whose content stays in the
#: wheel.
SKILL_ASSIGNMENT_MARKER = ".skills-assigned.json"


def _decode(value: str) -> str:
    """One stored file back to text ('' for a binary payload).

    ``studio_agent_defs`` is binary-safe (``engine.filecodec``); everything
    this module reads — SOUL.md, TOOLS.md, the assignment marker — is text, so
    a binary value means "not something to display", not an error.
    """
    try:
        from ioagentfarm.engine.filecodec import decode_file
        out = decode_file(value)
        return out if isinstance(out, str) else ""
    except Exception:
        return value if isinstance(value, str) else ""


def _rows(cur) -> list[dict]:
    return [r if isinstance(r, dict) else dict(r) for r in cur.fetchall()]


def _select(cur, q, columns: str, table: str, tail: str = "", args=()) -> list[dict]:
    """SELECT that degrades to fewer columns on an older schema.

    ``agents.soul``/``tools_md``/``skills_json`` are migration-added and
    ``pack_skills`` is new, so a database that has not been through
    ``ioagentfarm init``/``sync`` yet must still serve a list rather than 500.
    """
    try:
        cur.execute(q(f"SELECT {columns} FROM {table} {tail}"), args)
        return _rows(cur)
    except Exception:
        logger.debug("%s unavailable with columns %r", table, columns,
                     exc_info=True)
        return []


# ── the base tier: what the engine's installed packs contain ──────────

def pack_agents(workspace_code: str) -> dict[str, dict]:
    """``role -> {role, name, pack, stamp, skills, has_card}`` from the
    ENGINE catalog. Raises the rail's 502 when the engine is unreachable —
    an empty roster must never mask that.

    Resolved ONCE per read-only request: several call sites want the roster
    while serving one page, and each ask is an engine round trip returning
    identical bytes. The memo dies with the request — see app/request_scope.
    """
    from app import engine_catalog, request_scope
    return request_scope.memo(
        f"pack_agents:{workspace_code}",
        lambda: engine_catalog.agents(workspace_code))


def pack_agent_files(role: str, workspace_code: str,
                     stamp: str | None = None) -> dict[str, str]:
    """``{rel: text}`` of a pack agent's template (SOUL.md, TOOLS.md,
    a2a-card.yaml, skills/...) from the engine; ``{}`` when no installed pack
    provides the role."""
    from app import engine_catalog
    d = engine_catalog.agent_files(role, workspace_code, stamp)
    files = (d or {}).get("files") or {}
    return {k: v for k, v in files.items() if isinstance(v, str)}


def pack_skills(workspace_code: str) -> dict[str, dict]:
    """``name -> {name, pack, source, stamp, shared, also}`` — the engine's
    skill catalog (no bodies; see :func:`pack_skill_md`).

    Resolved ONCE per read-only request. `/api/studio/skills` asked twice —
    `_skill_catalog` wants the inventory and `_sdk_skill_names` wants the
    shared tier out of the same answer — so this was two engine round trips
    for one page. Neither caller is wrong to ask; the duplication is between
    them, which is where the memo belongs.
    """
    from app import engine_catalog, request_scope
    return request_scope.memo(
        f"pack_skills:{workspace_code}",
        lambda: engine_catalog.skills(workspace_code))


def pack_skill_md(name: str, workspace_code: str,
                  stamp: str | None = None) -> str:
    """One pack skill's SKILL.md text from the engine (cached by stamp)."""
    from app import engine_catalog
    return engine_catalog.skill_md(name, workspace_code, stamp)


def pack_skill_md_many(rows: dict[str, dict],
                       workspace_code: str) -> dict[str, str]:
    """SKILL.md text for many pack skills at once. Use this for an INVENTORY
    - one call per skill in sequence took 66s on a 43-skill workspace."""
    from app import engine_catalog
    return engine_catalog.skill_md_many(rows, workspace_code)


# ── the tenant tier: what this workspace owns ────────────────────────

def agent_defs(workspace_codes: list[str]) -> dict[str, dict[str, dict]]:
    """``{workspace_code: {role: {rel: text}}}`` from ``studio_agent_defs``.

    Both the tenant's own code and ``default`` are read in one query: a scoped
    workspace shows its own agents PLUS the platform-shared ones, whose single
    canonical definition lives on ``default`` (the same rule
    ``_sync_studio_template`` writes by and ``ensure_agent_workspace``
    enforces engine-side).
    """
    from app.database import get_db, q
    from app import workflow_defs

    out: dict[str, dict[str, dict]] = {c: {} for c in workspace_codes}
    if not workspace_codes:
        return out
    try:
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)
            cur = con.cursor()
            marks = ",".join("?" * len(workspace_codes))
            cur.execute(q("SELECT workspace_code, role, files_json "
                          "FROM studio_agent_defs "
                          f"WHERE workspace_code IN ({marks})"),
                        tuple(workspace_codes))
            for r in _rows(cur):
                try:
                    files = json.loads(r.get("files_json") or "{}")
                except json.JSONDecodeError:
                    continue
                if not isinstance(files, dict) or "SOUL.md" not in files:
                    continue        # a workspace without a SOUL is not an agent
                out.setdefault(r["workspace_code"], {})[r["role"]] = files
    except Exception as e:
        logger.warning("studio_agent_defs unavailable: %s", e)
    return out


def assigned_skills(files: dict) -> list[str]:
    """The shared-skill names recorded in an agent's assignment marker."""
    raw = files.get(SKILL_ASSIGNMENT_MARKER)
    if not raw:
        return []
    try:
        rec = json.loads(_decode(raw))
    except (json.JSONDecodeError, TypeError):
        return []
    names = rec.get("skills") if isinstance(rec, dict) else None
    return sorted(str(n) for n in names) if isinstance(names, list) else []


def skill_assignment_marker(role: str, names: list[str]) -> str:
    """The marker file's text, written by the Studio instead of the engine.

    Same shape ``engine.workspaces.record_skill_assignment`` writes, because
    the same reader parses it and the file rides in the agent's DB row. The
    Studio composes it directly now: that function derives the record by
    LISTING A DIRECTORY, and there is no directory here.
    """
    return json.dumps({
        "role": role,
        "note": "shared-skill assignment for this agent; see "
                "engine/workspaces.py SKILL_ASSIGNMENT_MARKER",
        "skills": sorted(names),
    }, indent=2) + "\n"


# ── the merged view ──────────────────────────────────────────────────

class AgentRecord(dict):
    """One agent as the Studio sees it, from both tiers.

    A dict so it stays trivially serialisable and testable; the named
    properties are for readability at the call sites.
    """

    @property
    def role(self) -> str:
        return self["role"]

    @property
    def custom(self) -> bool:
        """Authored in the Studio — the ``.studio-created`` provenance marker,
        which is now a key in the agent's row rather than a file on a disk."""
        return self["custom"]

    @property
    def owned_here(self) -> bool:
        """This workspace holds the agent's definition row (not inherited from
        ``default``). The DB equivalent of "its directory is under the tenant's
        own agent home", which is how a Studio agent used to be attributed."""
        return self["owned_here"]


def agent_index(workspace_code: str, platform_shared_roles: list[str]) -> dict[str, AgentRecord]:
    """Every agent this workspace could show, before the visibility filter.

    Union of the ENGINE tier (installed packs) and the tenant tier (rows) —
    pack wins a role; a row is shown only when the engine has no agent of
    that role and is then marked ``unpromoted``. Base records carry no
    SOUL/TOOLS text (the list endpoint has none); ``_agent_record`` fetches
    the template files for the detail view.
    """
    catalog = pack_agents(workspace_code)
    codes = [workspace_code] if workspace_code == DEFAULT_WS \
        else [workspace_code, DEFAULT_WS]
    defs = agent_defs(codes)
    carriage, universal = skill_carriage(workspace_code)

    roles = set(catalog) | {r for d in defs.values() for r in d}

    # RETIRED SLUGS: a row for a retired agent slug whose canonical role is
    # also present is HIDDEN — it is the same agent under its old name, left
    # behind by an adopted tree or a pre-rename sync (agent prune is opt-in
    # by design). Listing both showed two 'Jarvis' entries in the walkthrough.
    # The engine's alias table is the single seam for this mapping.
    try:
        from ioagentfarm.engine.workspaces import canonical_role
        roles = {r for r in roles
                 if canonical_role(r) == r or canonical_role(r) not in roles}
    except Exception:
        pass  # engine package absent (isolated API tests) — list as-is

    out: dict[str, AgentRecord] = {}
    for role in sorted(roles):
        cat = catalog.get(role)
        db_skills = sorted(carriage.get(role, set()) | universal)
        if cat is not None:
            # PACK WINS. The tenant row (if any) is not consulted for identity;
            # carriage rows still add to the pack's baseline (assignment is a
            # tenant fact). A Studio-side edit of a pack agent's files is
            # therefore not shown — it will not survive a re-seed either.
            out[role] = AgentRecord({
                "role": role,
                "pack": cat.get("pack", ""),
                "name": cat.get("name", role),
                "avatar": "",
                "color": "",
                "soul": "",
                "tools": "",
                "skills": sorted(set(db_skills) | set(cat.get("skills", []))),
                "custom": False,
                "owned_here": False,
                "has_def": False,
                "files": {},
                "stamp": cat.get("stamp", ""),
                "has_card": bool(cat.get("has_card")),
                "unpromoted": False,
                "source": "engine",
            })
            continue

        # ADD-ONLY: no installed pack provides this role, so the tenant row is
        # the only definition — a Studio-authored / imported agent, unpromoted.
        owner = None
        if role in platform_shared_roles:
            if role in defs.get(DEFAULT_WS, {}):
                owner = DEFAULT_WS
        else:
            for c in codes:
                if role in defs.get(c, {}):
                    owner = c
                    break
        files = defs.get(owner, {}).get(role, {}) if owner else {}
        if not files:
            continue
        # The tenant owns this agent's definition, so the DB is the whole
        # truth about it — carriage rows plus the shared-skill marker. No
        # catalog baseline exists to union in.
        skills = sorted(set(db_skills) | set(assigned_skills(files)))
        out[role] = AgentRecord({
            "role": role,
            "pack": "",
            "name": role,
            "avatar": "",
            "color": "",
            "soul": _decode(files.get("SOUL.md", "")),
            "tools": _decode(files.get("TOOLS.md", "")),
            "skills": skills,
            "custom": ".studio-created" in files,
            "owned_here": owner == workspace_code,
            "has_def": True,
            "files": files,
            "stamp": None,
            "has_card": "a2a-card.yaml" in files,
            "unpromoted": True,
            "source": "studio",
        })
    return out


def skill_carriage(workspace_code: str) -> tuple[dict[str, set[str]], set[str]]:
    """``(role -> {skill names}, {skills assigned to every role})``.

    The reverse of ``used_by``, from the same single source: assignment lives
    in ``studio_skills.roles_json`` for every tier, so this answers both
    directions with one read instead of opening every agent workspace. The
    literal ``"all"`` is returned separately because it names no role — it has
    to be resolved against whichever agents this workspace actually has.
    """
    from app import skill_defs
    per_role: dict[str, set[str]] = {}
    universal: set[str] = set()
    for name, row in skill_defs.list_defs(workspace_code).items():
        roles = row.get("roles")
        if roles == "all":
            universal.add(name)
            continue
        for role in (roles or []):
            if isinstance(role, str):
                per_role.setdefault(role, set()).add(name)
    return per_role, universal


def all_skill_names(workspace_code: str) -> set[str]:
    """Every skill name that resolves in this workspace (both tiers)."""
    from app import skill_defs
    return set(pack_skills(workspace_code)) | set(skill_defs.list_defs(workspace_code))
