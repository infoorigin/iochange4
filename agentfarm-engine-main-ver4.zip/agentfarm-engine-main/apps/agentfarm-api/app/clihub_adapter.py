"""Thin adapter wiring CLI Hub into the agentfarm API."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator

from fastapi import APIRouter

from clihub import CLIHubConfig, create_clihub_router
from clihub.database import DBProvider


class _CursorWrapper:
    """Wraps a psycopg2 connection for cursor-based execute + commit."""

    def __init__(self, con: Any) -> None:
        self._con = con
        self._cursor = con.cursor()

    def execute(self, sql: str, params: tuple = ()) -> Any:
        self._cursor.execute(sql, params)
        return self._cursor

    def commit(self) -> None:
        self._con.commit()


class AgentFarmDBProvider:
    @contextmanager
    def get_connection(self) -> Generator[Any, None, None]:
        from app.database import get_db, _parse_url, engine_db_url

        # Engine DB only — resolved at request time (see app/database.py).
        backend, _ = _parse_url(engine_db_url())

        with get_db() as con:
            if backend == "postgres":
                yield _CursorWrapper(con)
            else:
                yield con

    def placeholder(self) -> str:
        from app.database import placeholder
        return placeholder()


def get_cli_router() -> APIRouter:
    return create_clihub_router(db=AgentFarmDBProvider())
