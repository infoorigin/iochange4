"""Configuration — reads from environment variables shared with ioagentfarm."""

from __future__ import annotations

import json
import os
import shutil
import sys
from functools import lru_cache
from pathlib import Path

# NAMED, NOT GUESSED. A bare `load_dotenv()` walks UP from the working
# directory, so the API's configuration - including its AUTHENTICATION
# POSTURE - came from whatever file happened to sit above wherever it was
# started. A validator started an API deliberately without IOF_AUTH_DEV and
# still got the bypass, from an ambient file. See app/env_source.py; this is
# the same hazard CLAUDE.md records as fixed for the CLI and not for here.
from app.env_source import load as _load_env
_load_env()


def _resolve_ioagentfarm_bin() -> str:
    """Resolve the ``ioagentfarm`` CLI to a concrete executable path.

    Resolution order:
      1. ``IOF_BIN`` env override (absolute path, or a name resolved on PATH)
      2. the running interpreter's own scripts dir (``.venv/Scripts`` on
         Windows, ``.venv/bin`` elsewhere) — the repo venv when the API is
         started from it. This is the fix for the bare-name subprocess call
         failing with ``FileNotFoundError [WinError 2]`` when the venv's
         scripts dir is not on the server process PATH.
      3. plain PATH lookup.

    Returns "" when nothing is found — callers must surface a clear error
    instead of letting subprocess raise WinError 2.
    """
    override = (os.getenv("IOF_BIN") or "").strip()
    if override:
        p = Path(override)
        if p.is_file():
            return str(p)
        found = shutil.which(override)
        if found:
            return found
        # explicit override that doesn't resolve: fall through to auto-detect
    exe_dir = Path(sys.executable).resolve().parent
    for name in ("ioagentfarm.exe", "ioagentfarm"):
        cand = exe_dir / name
        if cand.is_file():
            return str(cand)
    return shutil.which("ioagentfarm") or ""


def _parse_scopes(raw: str) -> list[str]:
    value = (raw or "").strip()
    if not value:
        return []

    if value.startswith("[") and value.endswith("]"):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return [str(scope).strip() for scope in parsed if str(scope).strip()]
            return []
        except json.JSONDecodeError:
            inner = value[1:-1].strip()
            if not inner:
                return []
            value = inner

    return [
        token.strip().strip('"').strip("'")
        for token in value.replace(",", " ").split()
        if token.strip().strip('"').strip("'")
    ]


class Settings:
    """App settings loaded from environment variables.

    Shared with ioagentfarm:
        IOF_ROOT          — state directory (default: .iof)
        IOF_DATABASE_URL  — database connection string

    UI-specific:
        IOF_AGENTFARM_DIR — path to io-agentfarm source (for workflow YAMLs)
        IOF_BIN           — ioagentfarm CLI binary
        IOF_UI_CORS       — comma-separated CORS origins (default: *)
        IOF_UI_SSE_POLL   — SSE poll interval in seconds (default: 0.5)
    """

    def __init__(self) -> None:
        self.iof_root = Path(os.getenv("IOF_ROOT", ".iof")).resolve()

        # Path to ioagentfarm source root (for reading workflow YAMLs)
        default_agentfarm = str(Path(__file__).resolve().parent.parent.parent / "io-agentfarm")
        self.agentfarm_dir = Path(os.getenv("IOF_AGENTFARM_DIR", default_agentfarm))

        # Concrete executable path ("" when unresolvable — callers raise a
        # clear error rather than crashing with FileNotFoundError/WinError 2).
        self.ioagentfarm_bin = _resolve_ioagentfarm_bin()

        cors = os.getenv("IOF_UI_CORS", "*")
        self.cors_origins = [o.strip() for o in cors.split(",")]

        # Studio pack visibility filter (solution curation without touching
        # any pack on disk). Pack names are `Pack.name` values from the
        # engine's `aicore.packs` registry ("core" for the built-in pack).
        #   STUDIO_INCLUDE_PACKS — packs whose agents are studio-visible even
        #     without a DB-registry row (default "ainf" = the AINF solution).
        #   STUDIO_EXCLUDE_PACKS — packs hidden from the studio entirely,
        #     agents AND the skills only their agents carry (default
        #     "procurement" for this deployment).
        self.studio_include_packs = [
            p.strip() for p in os.getenv("STUDIO_INCLUDE_PACKS", "ainf").split(",")
            if p.strip()]
        self.studio_exclude_packs = [
            p.strip() for p in os.getenv("STUDIO_EXCLUDE_PACKS", "procurement").split(",")
            if p.strip()]

        # The platform-shared agent tier: the always-on assistants every
        # workspace sees regardless of its solution scoping — Jarvis (gateway),
        # Quinn (query engine), Alex (orchestrator).
        #
        # This is an EXPLICIT list because it cannot be inferred from the core
        # pack: core also bundles the generic workflow roles (analyst,
        # developer, reviewer, strategist, …) that belong to core's own
        # workflows, not to every tenant's catalog. It was previously inferred
        # from "which roles have a row in iof.agents", which worked only while
        # that table was hand-curated; POST /api/agents/sync now fills it with
        # every installed agent (needed for pack provenance), so curation and
        # completeness had to stop being the same signal.
        # THE DEFAULT MUST MATCH THE ENGINE'S (engine/workspaces.py
        # `_platform_shared_roles`) — core cannot import this module, so the
        # env var IS the contract and the two defaults are the fallback when
        # nobody sets it. They diverged once: the assistant's rename to `cora`
        # updated the engine and not this line, so on any deployment that left
        # the variable unset the studio treated `jarvis` as platform-shared and
        # `cora` as an ordinary tenant agent — exactly the split the engine's
        # docstring warns about. Change both together, or neither.
        self.platform_shared_roles = [
            r.strip() for r in os.getenv(
                "PLATFORM_SHARED_ROLES",
                "cora,queryngine,project_lead,cora_build,meta_agent,play_operator").split(",")
            if r.strip()]

        self.sse_poll_interval = float(os.getenv("IOF_UI_SSE_POLL", "0.5"))

        # Skills module
        self.skills_s3_prefix = os.getenv("IOF_SKILLS_S3_PREFIX", "skills")
        self.skills_embedding_model = os.getenv("IOF_SKILLS_EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5")

        # S3
        self.s3_bucket = os.getenv("IOF_S3_BUCKET", "")
        self.s3_prefix = os.getenv("IOF_S3_PREFIX", "")
        self.aws_region = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
        self.aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID", "")
        self.aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY", "")

        # Auth
        self.auth_jwt_secret = os.getenv("IOF_AUTH_JWT_SECRET", "change-me")
        self.auth_jwt_validity_hours = int(os.getenv("IOF_AUTH_JWT_HOURS", "12"))
        self.auth_frontend_url = os.getenv("IOF_AUTH_FRONTEND_URL", "http://localhost:5173")
        self.info_qa_auth_frontend_url = os.getenv("IOF_INFO_QA_AUTH_FRONTEND_URL", "http://localhost:5173")

        # Authorization (workspace membership)
        #: Emails seeded as platform admins at startup — they reach every
        #: workspace. The bootstrap that keeps a closed-membership deployment
        #: from locking everyone out on first upgrade.
        self.bootstrap_admins = [
            e.strip().lower()
            for e in os.getenv("IOF_BOOTSTRAP_ADMIN", "").split(",")
            if e.strip()
        ]
        #: Temporary rollback lever. When 0/false, identity is still verified
        #: and logged but membership is NOT enforced — the pre-Phase-4
        #: behaviour. Exists so a seeding mistake cannot block a live demo; it
        #: is NOT a mode to deploy in.
        self.authz_enforce = os.getenv(
            "IOF_AUTHZ_ENFORCE", "1").strip().lower() not in ("0", "false", "off")


        # SSO (Microsoft Entra)
        self.auth_sso_client_id = os.getenv("CLIENT_ID", "")
        self.auth_sso_client_secret = os.getenv("CLIENT_SECRET", "")
        self.auth_sso_tenant_id = os.getenv("TENANT_ID", "")
        self.auth_sso_scopes = _parse_scopes(os.getenv("SCOPES", "openid,profile,email"))
        self.auth_sso_redirect_uri = os.getenv("REDIRECT_URI", "")
        self.info_qa_sso_redirect_uri = os.getenv("INFO_QA_REDIRECT_URI", "")
        self.auth_sso_authorize_url = f"https://login.microsoftonline.com/{self.auth_sso_tenant_id}"

    @property
    def database_url(self) -> str:
        """Engine DB URL — resolved from the environment at ACCESS time.

        Deliberately NOT captured in ``__init__``: ``get_settings()`` is
        ``lru_cache``d for the process lifetime, and freezing the engine DB
        URL at first request is exactly how a long-running API kept listing
        historical sessions from a stale legacy store after the engine
        metadata was rebuilt. Request-time resolution matches the hub
        pattern (``barrier_insights._hub_schema()`` / ``hil_queue``).

        No sqlite fallback: the engine DB is the single system of record —
        ``app.database.get_db()`` fails closed (503) when this is empty.
        """
        return (os.getenv("IOF_DATABASE_URL") or "").strip()


@lru_cache
def get_settings() -> Settings:
    return Settings()
