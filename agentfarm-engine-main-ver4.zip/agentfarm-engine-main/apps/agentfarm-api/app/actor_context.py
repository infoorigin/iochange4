"""The verified end user, for the duration of one request.

WHY THIS EXISTS. The API calls the engine as ITSELF — a service principal
holding a client-credentials token, or a shared key. That is correct: the
engine must know that the caller is a known workload. But it means the engine
learns only "the API called", so every run it creates is attributed to the
API, and the audit trail answers "who started this?" with the name of a pod.

``X-IOF-Actor`` carries the end user the API has already verified. The engine
trusts it ONLY from an authenticated caller (see
``ioagentfarm/web/auth.py::resolve_actor``) — the standard trusted-subsystem
shape, whose whole security rests on the header being unreachable from
outside, which is precisely what the engine's new guard establishes.

WHY A CONTEXTVAR AND NOT A PARAMETER. ``engine_json`` is the one rail, called
from a dozen routers, several of them from helper functions three levels below
the handler. Threading an identity through all of them is the change nobody
finishes, and a rail where SOME calls carry the actor is worse than one where
none do: the audit trail then has holes that look like anonymous activity.
This is the same argument, and the same mechanism, as
``app/workspace_context.py`` — the tenant travels the same way for the same
reason.

FAIL-OPEN, DELIBERATELY. An unresolvable identity leaves the actor empty and
the request proceeds. This is attribution, not authorization: the caller has
already been through ``require_member`` on any route that needs it, and a
middleware that could 401 a request the real guard would have allowed is a
second, weaker copy of the guard.
"""

from __future__ import annotations

from contextvars import ContextVar

#: Empty string means "no verified end user" — an unauthenticated or exempt
#: path, or a token that did not verify. Never ``None``, so callers cannot
#: accidentally send the string "None" as a header value.
_actor: ContextVar[str] = ContextVar("iof_actor_email", default="")


def set_actor(email: str | None) -> object:
    """Record the verified end user; returns the token for :func:`reset`."""
    return _actor.set((email or "").strip().lower())


def reset(token: object) -> None:
    """Restore the previous value. Called in a ``finally`` so a failing
    request cannot leak its actor into whatever the worker handles next."""
    try:
        _actor.reset(token)  # type: ignore[arg-type]
    except (ValueError, TypeError):
        # Reset from a different context than the set. Not recoverable and not
        # worth an exception on a teardown path; the default is empty anyway.
        pass


def current_actor() -> str:
    """The verified end user for this request, or ``""``."""
    return _actor.get()
