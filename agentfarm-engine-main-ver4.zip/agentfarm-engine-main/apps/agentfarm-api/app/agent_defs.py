"""Studio agent definitions — the DB copy of studio-authored agent content.

Materialize-on-use, writer half (design: docs/PLATFORM_HARDENING_BACKLOG.md).
Every studio save that touches an agent workspace (agent create/update, skill
create/update on its carriers) snapshots the workspace's CONTENT FILES into
``studio_agent_defs`` with a per-item sync key (version, content_hash). The
engine's hydration hooks (``ioagentfarm.engine.hydration``) rebuild the
workspace from this row on any host where the key differs — which is what
makes studio agent edits survive pod restarts and reach remote engines.

Included: SOUL.md, AGENTS.md, TOOLS.md, USER.md, HEARTBEAT.md, a2a-card.yaml,
``.studio-created`` (visibility marker), ``.skills-assigned.json`` (the
shared-skill assignment record — NAMES only; see ``_IDENTITY_FILES``).
Excluded: ``skills/**`` (own table since 2026-07-30 — see ``skill_defs``;
storing them here meant one copy per carrier and a full re-snapshot of every
carrying workspace on a single skill edit), ``memory/`` and ``sessions/``
(runtime state — DB-backed learning owns memory), ``metadata/`` (host-specific
deploys), stamps/locks/binaries.

Table DDL lives in the single shared implementation
(``ioagentfarm.workspace_sync.ensure_platform_schema``), reached through
``workflow_defs.ensure_defs`` — the same convention as the workflow store.
Failures here are logged, never raised: a save must not fail because the
def snapshot did (the file write already succeeded; the next save retries).
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

#: ``.skills-assigned.json`` is the agent's SHARED-SKILL ASSIGNMENT RECORD
#: (``engine.workspaces.SKILL_ASSIGNMENT_MARKER``) — names only, never content.
#: It is here because pack/SDK skills deliberately have no ``studio_skills``
#: row (a tenant copy would freeze a fork no SDK upgrade reaches), so without
#: it "this agent holds `presentation`" existed on one host's disk and nowhere
#: else: a pod with an empty state directory and a restored database rebuilt
#: the agent without it, silently. Storing the NAMES cannot freeze a fork —
#: the content still comes from the wheel at materialization.
#:
#: ``skills.yaml`` is the AUTHORED counterpart — a solution repo declaring, by
#: name, the skills an agent carries (``engine.workspaces.DECLARED_SKILLS_FILE``).
#: It is here for the same reason and one more: this tuple is what a Studio save
#: snapshots FROM the live workspace, so a name missing from it is silently
#: dropped from the row the next time anyone touches the agent in the product.
#: ``USER.md`` and ``HEARTBEAT.md`` are DELIBERATELY ABSENT. The agent runtime
#: scaffolds both into a workspace the first time an agent runs, so they are
#: per-host runtime state like ``memory/`` and ``sessions/`` -- not content any
#: author wrote. Capturing them meant `push` stored them and `pull` then wrote
#: them into the repository, so a converged push followed by a pull left two
#: untracked files behind and made the documented "pull converges" false on the
#: first pull. One of them also carries the runtime's own wording about
#: heartbeat cron, which is not this product's to publish into a customer repo.
_IDENTITY_FILES = ("SOUL.md", "AGENTS.md", "TOOLS.md", "a2a-card.yaml",
                   ".studio-created", ".skills-assigned.json",
                   "skills.yaml")
_SKIP_SUFFIXES = (".pyc", ".pyo", ".exe", ".dll", ".so")
_SKIP_NAMES = (".materialized",)

from ioagentfarm.engine.workspaces import PLATFORM_TIER

# The internal shared-tier key (the retired literal, kept for existing
# rows). NOT a workspace: requests can never resolve to it.
DEFAULT_WS = PLATFORM_TIER


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def snapshot_workspace_files(ws: Path) -> dict[str, str]:
    """{rel_posix_path: text} content snapshot of one agent workspace.

    Identity files ONLY. ``skills/**`` moved to ``studio_skills`` (2026-07-30):
    capturing them here is what stored a shared skill once per carrier and made
    one skill edit re-snapshot every carrying workspace.
    """
    from ioagentfarm.engine.filecodec import encode_file

    files: dict[str, str] = {}
    for fname in _IDENTITY_FILES:
        p = ws / fname
        if p.is_file():
            v = encode_file(p)
            if v is not None:
                files[fname] = v
    return files


def _legacy_skill_keys(cur, role: str, workspace_code: str) -> dict[str, str]:
    """Pre-migration ``skills/**`` entries already in this agent's row.

    They are carried forward verbatim on every save so the "copy, never
    delete" rule holds even through a rewrite — the migration left them as a
    recovery snapshot, and a save must not be what finally erases them.
    Nothing reads them: hydration resolves skills from ``studio_skills`` and
    only falls back to these on a schema that predates that table.
    """
    from app.database import q
    try:
        cur.execute(q("SELECT files_json FROM studio_agent_defs "
                      "WHERE workspace_code = ? AND role = ?"),
                    (workspace_code, role))
        row = cur.fetchone()
        if not row:
            return {}
        raw = row["files_json"] if isinstance(row, dict) else row[0]
        return {k: v for k, v in (json.loads(raw or "{}")).items()
                if k.startswith("skills/")}
    except Exception:
        return {}


def upsert_agent_def(role: str, ws: Path,
                     workspace_code: str) -> None:
    """Snapshot a workspace DIRECTORY into its DB row.

    The engine-side path (a host that has the files). The Studio API uses
    :func:`upsert_agent_files` instead — it has no directory to snapshot.
    """
    upsert_agent_files(role, snapshot_workspace_files(ws),
                       workspace_code=workspace_code)


def upsert_agent_files(role: str, files: dict[str, str],
                       workspace_code: str) -> None:
    """Write an agent's identity files straight to its row, bumping the sync key.

    The writer the Studio uses. It used to compose the row by reading the
    workspace back off disk — which needs the API pod and the engine pod to
    share a filesystem, and they never do. Same row, same sync key, same
    hydration contract; the only difference is that the content arrives as
    values rather than as a directory listing.

    Best-effort by contract: logs and returns on any failure.
    """
    try:
        from ioagentfarm.engine.hydration import files_hash
        from app.database import get_db, placeholder, q
        from app import workflow_defs

        files = {k: v for k, v in (files or {}).items() if v is not None}
        if "SOUL.md" not in files:
            return          # not a complete agent workspace — nothing to store
        chash = files_hash(files)
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)   # shared platform schema (incl. agent defs)
            cur = con.cursor()
            legacy = _legacy_skill_keys(cur, role, workspace_code)
            if legacy:
                files = {**legacy, **files}
                chash = files_hash(files)
            cur.execute(
                q("INSERT INTO studio_agent_defs "
                  "(workspace_code, role, files_json, content_hash, version,"
                  " updated_at) VALUES (?, ?, ?, ?, 1, ?) "
                  "ON CONFLICT (workspace_code, role) DO UPDATE SET "
                  "files_json = excluded.files_json, "
                  "content_hash = excluded.content_hash, "
                  "version = studio_agent_defs.version + 1, "
                  "updated_at = excluded.updated_at"),
                (workspace_code, role, json.dumps(files), chash, _now()))
            if placeholder() != "%s":
                con.commit()
        logger.debug("agent def upserted for %s (%d files)", role, len(files))
    except Exception as e:
        logger.warning("agent def snapshot failed for %s (save still "
                       "applied on disk): %s", role, e)


def delete_agent_def(role: str, workspace_code: str) -> None:
    """Remove an agent's def row (agent deletion flows). Best-effort."""
    try:
        from app.database import get_db, placeholder, q
        from app import workflow_defs
        with get_db() as con:
            workflow_defs.ensure_defs_once(con)
            cur = con.cursor()
            cur.execute(q("DELETE FROM studio_agent_defs "
                          "WHERE workspace_code = ? AND role = ?"),
                        (workspace_code, role))
            if placeholder() != "%s":
                con.commit()
    except Exception as e:
        logger.warning("agent def delete failed for %s: %s", role, e)
