"""One answer per question, per request — and no longer than that.

WHY. A studio read asks the same pure question several times because the
answer is needed in several places: serving `/api/studio/skills` resolves
the engine's skill catalog TWICE (`_skill_catalog` and `_sdk_skill_names`
both want it) and `studio_skills` TWICE (`_skill_catalog` and
`skill_carriage`). Each is an engine round trip or a DB round trip returning
the identical bytes, and no caller is wrong to ask — the duplication is
between them, so the fix belongs between them too.

WHY NOT A CACHE. A 2s memo on `_skill_catalog()` was tried and REVERTED: it
served a stale catalog after a change and failed three
`test_studio_reads_the_engine_catalog` tests. That memo outlived the request
that made it, which is the whole difference. This one is created when a
request starts and dropped when it ends, so nothing it holds can survive
into a later request and no change can be missed — the next request asks
again, always.

READ-ONLY REQUESTS ONLY, and that is the second safety rail. A request that
WRITES may legitimately read the same thing before and after its own write
and must see its effect; a memo would hand it the pre-write answer. Rather
than audit every handler for that shape, the scope is simply never installed
for a method that can write. Outside a request (CLI, tests, background
threads) there is no scope either, and `memo` degrades to calling through.
"""
from __future__ import annotations

import contextvars
from typing import Any, Callable, TypeVar

#: Methods that cannot change state, so re-asking within one of them is
#: guaranteed to be re-asking the same question.
READ_ONLY_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})

_scope: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "studio_request_scope", default=None)

T = TypeVar("T")


def begin(method: str) -> contextvars.Token:
    """Open a scope for this request. Returns the token to pass to :func:`end`."""
    fresh: dict | None = {} if method.upper() in READ_ONLY_METHODS else None
    return _scope.set(fresh)


def end(token: contextvars.Token) -> None:
    _scope.reset(token)


def memo(key: str, produce: Callable[[], T]) -> T:
    """``produce()`` once per *key* per read-only request.

    With no scope (a write, or no request at all) this is a plain call —
    which is why wrapping a function with it can never change behaviour
    outside a read.
    """
    store = _scope.get()
    if store is None:
        return produce()
    if key in store:
        return store[key]
    value = produce()
    store[key] = value
    return value


def active() -> bool:
    """Whether a read-only scope is open (tests, and assertions)."""
    return _scope.get() is not None


def snapshot() -> dict[str, Any]:
    """What the current scope holds — for tests that count resolutions."""
    return dict(_scope.get() or {})
