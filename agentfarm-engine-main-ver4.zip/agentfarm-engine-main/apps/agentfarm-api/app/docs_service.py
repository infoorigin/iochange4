import io
import re
import base64
import requests
from bs4 import BeautifulSoup, NavigableString, Tag
from docx import Document
from docx.shared import RGBColor, Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_COLOR_INDEX

class HtmlToDocxService:
    def __init__(self):
        self.highlight_mapping = {
            'yellow': WD_COLOR_INDEX.YELLOW,
            'green': WD_COLOR_INDEX.BRIGHT_GREEN,
            'cyan': WD_COLOR_INDEX.TURQUOISE,
            'magenta': WD_COLOR_INDEX.PINK,
            'blue': WD_COLOR_INDEX.BLUE,
            'red': WD_COLOR_INDEX.RED,
            'darkblue': WD_COLOR_INDEX.DARK_BLUE,
            'teal': WD_COLOR_INDEX.TEAL,
            'purple': WD_COLOR_INDEX.VIOLET,
            'darkred': WD_COLOR_INDEX.DARK_RED,
            'darkyellow': WD_COLOR_INDEX.DARK_YELLOW,
            'gray': WD_COLOR_INDEX.GRAY_50,
            'lightgray': WD_COLOR_INDEX.GRAY_25,
            'black': WD_COLOR_INDEX.BLACK
        }

    def generate_docx_from_html(self, html_content: str) -> io.BytesIO:
        soup = BeautifulSoup(html_content, 'html.parser')
        doc = Document()
        
        body = soup.find('body')
        if not body:
            body = soup

        self._process_blocks(body, doc)

        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        return buffer

    def _get_image_stream(self, src: str) -> io.BytesIO:
        """Helper to fetch an image stream from a Base64 string or an HTTP URL."""
        if not src:
            return None
            
        try:
            # Handle Base64 embedded images
            if src.startswith('data:image'):
                base64_data = src.split(',')[1]
                image_data = base64.b64decode(base64_data)
                stream = io.BytesIO(image_data)
                stream.seek(0) # CRITICAL: Reset pointer for docx reader
                return stream
                
            # Handle standard URL images
            elif src.startswith('http://') or src.startswith('https://'):
                response = requests.get(src, timeout=5)
                if response.status_code == 200:
                    stream = io.BytesIO(response.content)
                    stream.seek(0) # CRITICAL: Reset pointer for docx reader
                    return stream
        except Exception as e:
            print(f"Failed to process image {src[:30]}... Error: {e}")
            
        return None

    def _parse_inline_styles(self, style_str: str) -> dict:
        styles = {}
        if not style_str:
            return styles
        for declaration in style_str.split(';'):
            if ':' in declaration:
                prop, val = declaration.split(':', 1)
                styles[prop.strip().lower()] = val.strip().lower()
        return styles

    def _apply_paragraph_styles(self, paragraph, styles: dict):
        if 'text-align' in styles:
            align = styles['text-align']
            if align == 'center': paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            elif align == 'right': paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            elif align == 'justify': paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    def _hex_to_rgb(self, hex_color: str):
        hex_color = hex_color.lstrip('#')
        if len(hex_color) == 6:
            try:
                return RGBColor(int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16))
            except ValueError:
                return None
        return None

    def _process_blocks(self, parent_element, doc, list_level=0, list_type=None):
        for element in parent_element.children:
            if isinstance(element, NavigableString):
                text = str(element).strip()
                if text and text != '\n':
                    doc.add_paragraph(text)
                continue

            tag = element.name
            if not tag:
                continue

            styles = self._parse_inline_styles(element.get('style', ''))

            if tag in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                level = int(tag[1])
                p = doc.add_heading(level=level)
                self._apply_paragraph_styles(p, styles)
                self._process_inline_elements(element, p, inherited_styles=styles)

            elif tag in ['p', 'div', 'span']:
                p = doc.add_paragraph()
                self._apply_paragraph_styles(p, styles)
                self._process_inline_elements(element, p, inherited_styles=styles)

            elif tag == 'ul':
                self._process_blocks(element, doc, list_level + 1, 'ul')
            elif tag == 'ol':
                self._process_blocks(element, doc, list_level + 1, 'ol')
            elif tag == 'li':
                style_name = 'List Bullet' if list_type == 'ul' else 'List Number'
                if list_level > 1:
                    style_name += f' {min(list_level, 3)}' 
                
                p = doc.add_paragraph(style=style_name)
                self._apply_paragraph_styles(p, styles)
                self._process_inline_elements(element, p, inherited_styles=styles)

            elif tag == 'table':
                self._process_table(element, doc)
                
            elif tag == 'br':
                doc.add_paragraph()
                
            # Handle root-level images
            elif tag == 'img':
                p = doc.add_paragraph()
                self._insert_image(element, p)

    def _insert_image(self, img_element, docx_paragraph):
        """Extracts and safely injects an image into a document run."""
        src = img_element.get('src', '')
        image_stream = self._get_image_stream(src)
        
        if image_stream:
            run = docx_paragraph.add_run()
            try:
                # Use explicit width if provided, otherwise default to 6 inches
                width_val = img_element.get('width')
                if width_val and width_val.isdigit():
                    # converting raw html pixels to docx points safely
                    run.add_picture(image_stream, width=Pt(int(width_val) * 0.75))
                else:
                    run.add_picture(image_stream, width=Inches(6.0))
            except Exception as e:
                print(f"Error adding picture to document run: {e}")

    def _process_inline_elements(self, parent_element, docx_paragraph, inherited_styles=None, parent_format=None):
        if inherited_styles is None: inherited_styles = {}
        if parent_format is None:
            parent_format = {
                'bold': False, 'italic': False, 'underline': False, 
                'color': None, 'size': None, 'highlight': None, 'uppercase': False
            }

        current_format = parent_format.copy()
        element_styles = self._parse_inline_styles(parent_element.get('style', '')) if isinstance(parent_element, Tag) else {}
        merged_styles = {**inherited_styles, **element_styles}

        if merged_styles.get('text-transform') == 'uppercase':
            current_format['uppercase'] = True
        if 'underline' in merged_styles.get('text-decoration', ''):
            current_format['underline'] = True
        if 'color' in merged_styles:
            color_val = merged_styles['color']
            if color_val.startswith('#'):
                current_format['color'] = self._hex_to_rgb(color_val)
        if 'font-size' in merged_styles:
            size_match = re.search(r'(\d+)px', merged_styles['font-size'])
            if size_match:
                current_format['size'] = Pt(int(size_match.group(1)) * 0.75)
        if 'background-color' in merged_styles:
            bg_color = merged_styles['background-color']
            for name, docx_color in self.highlight_mapping.items():
                if name in bg_color:
                    current_format['highlight'] = docx_color
                    break

        for child in parent_element.children:
            if isinstance(child, NavigableString):
                text = str(child).replace('\xa0', ' ').replace('\n', ' ')
                if not text.strip() and len(text) > 0 and text[0] == ' ':
                    text = ' '
                elif not text.strip():
                    continue
                    
                if current_format['uppercase']:
                    text = text.upper()

                run = docx_paragraph.add_run(text)
                if current_format['bold']: run.bold = True
                if current_format['italic']: run.italic = True
                if current_format['underline']: run.underline = True
                if current_format['color']: run.font.color.rgb = current_format['color']
                if current_format['size']: run.font.size = current_format['size']
                if current_format['highlight']: run.font.highlight_color = current_format['highlight']

            elif isinstance(child, Tag):
                tag = child.name
                child_format = current_format.copy()

                if tag in ['b', 'strong']: child_format['bold'] = True
                elif tag in ['i', 'em']: child_format['italic'] = True
                elif tag in ['u']: child_format['underline'] = True
                elif tag == 'mark': child_format['highlight'] = WD_COLOR_INDEX.YELLOW
                elif tag == 'a':
                    child_format['color'] = RGBColor(5, 99, 193)
                    child_format['underline'] = True
                elif tag == 'br':
                    docx_paragraph.add_run('\n')
                    continue
                
                elif tag == 'img':
                    self._insert_image(child, docx_paragraph)
                    continue

                self._process_inline_elements(child, docx_paragraph, merged_styles, child_format)

    def _process_table(self, table_element, doc):
        rows = table_element.find_all('tr')
        if not rows: return

        max_cols = max(len(row.find_all(['td', 'th'])) for row in rows)
        if max_cols == 0: return

        table = doc.add_table(rows=len(rows), cols=max_cols)
        table.style = 'Table Grid'

        for i, row in enumerate(rows):
            cells = row.find_all(['td', 'th'])
            for j, cell in enumerate(cells):
                if j < max_cols:
                    doc_cell = table.cell(i, j)
                    doc_cell.text = '' 
                    p = doc_cell.paragraphs[0]
                    
                    styles = self._parse_inline_styles(cell.get('style', ''))
                    if cell.name == 'th' or styles.get('text-align') == 'center':
                        p.alignment = WD_ALIGN_PARAGRAPH.CENTER

                    format_state = {'bold': cell.name == 'th', 'italic': False, 'underline': False, 
                                    'color': None, 'size': None, 'highlight': None, 'uppercase': False}
                    
                    self._process_inline_elements(cell, p, inherited_styles=styles, parent_format=format_state)


    def convert_docx_to_html(self, docx_bytes: bytes) -> str:
        """Convert a DOCX byte stream to HTML, preserving formatting, colors, images, alignment, etc."""
        try:
            doc = Document(io.BytesIO(docx_bytes))
            
            # Extract all images from document first
            self.image_map = self._extract_all_images(doc)
            
            html_parts = ['<!DOCTYPE html>', '<html>', '<head>', '<meta charset="UTF-8">', '</head>', '<body>']
            
            for element in doc.element.body:
                if element.tag.endswith('}p'):
                    html_parts.append(self._paragraph_to_html(doc, element, docx_bytes))
                elif element.tag.endswith('}tbl'):
                    html_parts.append(self._table_to_html(doc, element, docx_bytes))
            
            html_parts.extend(['</body>', '</html>'])
            return '\n'.join(html_parts)
        except Exception as e:
            print(f"Failed to convert DOCX to HTML: {e}")
            import traceback
            traceback.print_exc()
            raise

    def _paragraph_to_html(self, doc: Document, para_element, docx_bytes: bytes) -> str:
        """Convert a paragraph element with all formatting."""
        
        # Get paragraph alignment
        pPr = para_element.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}pPr')
        alignment = 'left'
        if pPr is not None:
            jc = pPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}jc')
            if jc is not None:
                align_val = jc.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                if align_val == 'center': alignment = 'center'
                elif align_val == 'right': alignment = 'right'
                elif align_val == 'both': alignment = 'justify'
        
        # Get heading level
        heading_level = None
        if pPr is not None:
            pStyle = pPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}pStyle')
            if pStyle is not None:
                style_id = pStyle.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                if style_id and style_id.startswith('Heading'):
                    heading_level = int(style_id.replace('Heading', ''))
        
        # Build inline style
        style_attr = f'text-align: {alignment};' if alignment != 'left' else ''
        
        # Determine tag
        if heading_level:
            tag = f'h{heading_level}'
            html_tag_start = f'<{tag} style="{style_attr}">' if style_attr else f'<{tag}>'
            html_tag_end = f'</{tag}>'
        else:
            html_tag_start = f'<p style="{style_attr}">' if style_attr else '<p>'
            html_tag_end = '</p>'
        
        # Process runs (text content with formatting)
        runs_html = self._process_runs_to_html(doc, para_element, docx_bytes)
        
        return f'{html_tag_start}{runs_html}{html_tag_end}'

    def _process_runs_to_html(self, doc: Document, para_element, docx_bytes: bytes) -> str:
        """Convert runs within a paragraph, preserving text formatting."""
        html_parts = []
        
        for run_element in para_element.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}r'):
            # Get run properties
            rPr = run_element.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}rPr')
            bold = False
            italic = False
            underline = False
            color = None
            font_size = None
            highlight = None
            
            if rPr is not None:
                bold = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}b') is not None
                italic = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}i') is not None
                underline = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}u') is not None
                
                color_elem = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}color')
                if color_elem is not None:
                    color_val = color_elem.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                    if color_val:
                        color = f'#{color_val}'
                
                sz_elem = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}sz')
                if sz_elem is not None:
                    sz_val = sz_elem.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                    if sz_val:
                        font_size = f'{int(sz_val) // 2}px'
                
                highlight_elem = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}highlight')
                if highlight_elem is not None:
                    highlight_val = highlight_elem.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                    if highlight_val:
                        highlight = highlight_val
            
            # Get text content
            text_elem = run_element.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t')
            text = text_elem.text if text_elem is not None and text_elem.text else ''
            
            # Check for images in run
            image_html = self._find_image_in_run(run_element)
            if image_html:
                html_parts.append(image_html)
            
            # Build inline styles
            style_parts = []
            if color:
                style_parts.append(f'color: {color}')
            if font_size:
                style_parts.append(f'font-size: {font_size}')
            if highlight:
                style_parts.append(f'background-color: {self._word_highlight_to_css(highlight)}')
            
            style_attr = '; '.join(style_parts)
            
            # Build HTML
            if text:
                if bold:
                    text = f'<b>{text}</b>'
                if italic:
                    text = f'<i>{text}</i>'
                if underline:
                    text = f'<u>{text}</u>'
                
                if style_attr:
                    text = f'<span style="{style_attr}">{text}</span>'
                
                html_parts.append(text)
        
        return ''.join(html_parts)

    def _table_to_html(self, doc: Document, table_element, docx_bytes: bytes) -> str:
        """Convert a table element to HTML."""
        table_html = ['<table style="border-collapse: collapse; border: 1px solid black;">']
        
        for row_element in table_element.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tr'):
            table_html.append('<tr>')
            for cell_element in row_element.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tc'):
                cell_html = '<td style="border: 1px solid black; padding: 5px;">'
                for para_elem in cell_element.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'):
                    cell_html += self._process_runs_to_html(doc, para_elem, docx_bytes)
                cell_html += '</td>'
                table_html.append(cell_html)
            table_html.append('</tr>')
        
        table_html.append('</table>')
        return '\n'.join(table_html)

    def _map_word_color_to_css(self, word_color: str) -> str:
        """Map Word highlight colors to CSS."""
        color_map = {
            'yellow': '#FFFF00',
            'green': '#00B050',
            'cyan': '#00B0F0',
                'magenta': '#FF00FF',
                'blue': '#0070C0',
                'red': '#FF0000',
                'darkBlue': '#002070',
                'teal': '#00B4C7',
                'purple': '#7030A0',
                'darkRed': '#C00000',
                'darkYellow': '#808000',
                'gray': '#808080',
                'lightGray': '#C0C0C0',
                'black': '#000000'
            }
        return color_map.get(word_color, '#FFFFFF')
    
    def _extract_all_images(self, doc: Document) -> dict:
        """Extract all images from the document and store them as base64."""
        image_map = {}
        
        try:
            # Get all image parts from the document
            for rel in doc.part.rels.values():
                if 'image' in rel.reltype:
                    try:
                        image_part = rel.target_part
                        image_data = image_part.blob
                        image_type = self._detect_image_type(image_data, rel.reltype)
                        image_base64 = base64.b64encode(image_data).decode('utf-8')
                        data_url = f'data:image/{image_type};base64,{image_base64}'
                        
                        # Map by relationship ID
                        image_map[rel.rId] = data_url
                        print(f"Extracted image: {rel.rId} (type: {image_type}, size: {len(image_data)} bytes)")
                    except Exception as e:
                        print(f"Error extracting image {rel.rId}: {e}")
            
            print(f"Total images extracted: {len(image_map)}")
        except Exception as e:
            print(f"Error extracting all images: {e}")
        
        return image_map

    def _find_image_in_run(self, run_element) -> str:
        """Find and extract image from a run element."""
        try:
            # Look for blip element (inline shapes)
            blip = run_element.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}blip')
            if blip is not None:
                # Get embed ID from blip
                embed_id = None
                
                # Try various namespace combinations
                for attr_key, attr_value in blip.attrib.items():
                    if 'embed' in attr_key.lower():
                        embed_id = attr_value
                        print(f"Found embed ID in blip: {embed_id} from key {attr_key}")
                        break
                
                if embed_id and hasattr(self, 'image_map') and embed_id in self.image_map:
                    data_url = self.image_map[embed_id]
                    return f'<img src="{data_url}" style="max-width: 100%;" />'
            
            # Look for alternate picture formats
            pict = run_element.find('.//{urn:schemas-microsoft-com:vml}imagedata')
            if pict is not None:
                src = pict.get('src')
                if src and hasattr(self, 'image_map'):
                    for rid, data_url in self.image_map.items():
                        if rid in src or src in data_url:
                            return f'<img src="{data_url}" style="max-width: 100%;" />'
        
        except Exception as e:
            print(f"Error finding image in run: {e}")
        
        return None
    
    def _detect_image_type(self, image_data: bytes, filename: str = '') -> str:
        """Detect image type from magic bytes or filename."""
        # Check magic bytes first
        if image_data.startswith(b'\x89PNG'):
            return 'png'
        elif image_data.startswith(b'\xff\xd8\xff'):
            return 'jpeg'
        elif image_data.startswith(b'GIF8'):
            return 'gif'
        elif image_data.startswith(b'BM'):
            return 'bmp'
        elif image_data.startswith(b'RIFF') and b'WEBP' in image_data[:20]:
            return 'webp'
        
        # Fallback to file extension
        filename_lower = filename.lower()
        if 'jpg' in filename_lower or 'jpeg' in filename_lower:
            return 'jpeg'
        elif 'png' in filename_lower:
            return 'png'
        elif 'gif' in filename_lower:
            return 'gif'
        elif 'webp' in filename_lower:
            return 'webp'
        elif 'bmp' in filename_lower:
            return 'bmp'
        
        return 'png'  # Default fallback

    def _word_highlight_to_css(self, word_color: str) -> str:
        """Map Word highlight colors to CSS."""
        color_map = {
            'yellow': '#FFFF00',
            'green': '#00B050',
            'cyan': '#00B0F0',
            'magenta': '#FF00FF',
            'blue': '#0070C0',
            'red': '#FF0000',
            'darkBlue': '#002070',
            'teal': '#00B4C7',
            'purple': '#7030A0',
            'darkRed': '#C00000',
            'darkYellow': '#808000',
            'gray': '#808080',
            'lightGray': '#C0C0C0',
            'black': '#000000'
        }
        return color_map.get(word_color, '#FFFFFF')