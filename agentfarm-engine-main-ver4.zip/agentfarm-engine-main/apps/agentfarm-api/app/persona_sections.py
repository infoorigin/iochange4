"""Sectioned persona model — SOUL.md becomes a composed artifact.

The builder edits a persona as plain-language SECTIONS; the runtime artifact
stays a single SOUL.md file (iobot loads it natively — the file is the
contract). Two directions:

  * ``parse_soul(text)``   — tolerant reader. Recognizes the canonical
    composed format (marker + stable headings) exactly, and legacy hand-
    written SOULs by heading keywords. Anything it cannot classify lands
    INTACT in "Additional instructions" — content is never lost.
  * ``compose_soul(name, sections)`` — deterministic writer with stable
    heading markers, so ``parse(compose(x)) == x`` round-trips.

Canonical section model (plain-language labels live in the UI):
  who        — name + one-line identity ("Who am I")
  purpose    — Purpose & responsibilities
  how        — How I work (instructions / approach)
  tone       — Tone & style
  boundaries — Boundaries (things it must not do)
  additional — Additional instructions (catch-all; unclassified content)
"""

from __future__ import annotations

import re

SECTION_ORDER = ["who", "purpose", "how", "tone", "boundaries", "additional"]

#: Stable structural headings written by compose (and recognized exactly by
#: parse). Changing any of these breaks round-tripping of existing files —
#: treat them as a file-format contract.
SECTION_HEADINGS = {
    "who": "## Who I am",
    "purpose": "## Purpose & responsibilities",
    "how": "## How I work",
    "tone": "## Tone & style",
    "boundaries": "## Boundaries",
    "additional": "## Additional instructions",
}

#: Marker line identifying a composed (v1) file.
MARKER = "<!-- persona:v1 — edited as sections in Studio; headings are structural -->"

#: Legacy heading classifier — first match wins, checked in this order so
#: the more specific patterns ("how you work") beat the generic ones.
#: Vocabulary is drawn from an audit of the real installed SOULs (2026-07-27,
#: Barrier Insights workspace: pharma trio + jarvis + project_lead) — headings
#: like "What you are", "Non-negotiables", "Personality", "Values", "Decision
#: model" previously fell through to Additional. "Working style" must keep
#: matching `how` BEFORE tone's `style` (order-dependent).
_LEGACY_RULES: list[tuple[str, re.Pattern]] = [
    ("who", re.compile(
        r"^(who\b|identity|what (you|i) are\b|about\b|personality|values|principles)",
        re.I)),
    ("how", re.compile(
        r"^how\b|approach|method|process|working style|operating|discipline"
        r"|decision|workflow|practice", re.I)),
    ("tone", re.compile(r"tone|style|voice|communicat", re.I)),
    ("boundaries", re.compile(
        r"boundar|guardrail|safety|constraint|limits|non.?negotiable"
        r"|\bnever\b|hard rules", re.I)),
    ("purpose", re.compile(
        r"purpose|mission|responsibilit|objective|goal|what (you|i) do\b"
        r"|\bjob\b|deliverables", re.I)),
]

_H1_SOUL = re.compile(r"^#\s*SOUL\s*(?:[—–-]+\s*(?P<name>.+))?$")


def _classify(heading: str) -> str | None:
    for key, rx in _LEGACY_RULES:
        if rx.search(heading):
            return key
    return None


def compose_soul(name: str, sections: dict[str, str]) -> str:
    """Deterministic SOUL.md from sections. Empty sections are omitted."""
    display = (name or "Agent").strip()
    out = [f"# SOUL — {display}", MARKER, ""]
    for key in SECTION_ORDER:
        body = (sections.get(key) or "").strip()
        if not body:
            continue
        out += [SECTION_HEADINGS[key], "", body, ""]
    return "\n".join(out).rstrip() + "\n"


def _parse_v1(text: str) -> dict:
    lines = text.splitlines()
    name = "Agent"
    if lines:
        m = _H1_SOUL.match(lines[0].strip())
        if m and m.group("name"):
            name = m.group("name").strip()
    heading_to_key = {v: k for k, v in SECTION_HEADINGS.items()}
    sections = {k: "" for k in SECTION_ORDER}
    current: str | None = None
    buf: list[str] = []

    def flush():
        # append (not overwrite): a canonical heading appearing twice —
        # e.g. carried inside legacy content — must merge, never clobber
        if current is None:
            return
        body = "\n".join(buf).strip()
        if not body:
            return
        prev = sections[current]
        sections[current] = f"{prev}\n\n{body}" if prev else body

    for line in lines[1:]:
        if line.strip() == MARKER.strip():
            continue
        key = heading_to_key.get(line.strip())
        if key is not None:
            flush()
            current, buf = key, []
        elif current is not None:
            buf.append(line)
        # content before the first canonical heading in a v1 file is only
        # ever blank lines — anything else would have been composed into a
        # section; ignore stray whitespace.
    flush()
    return {"format": "v1", "name": name, "sections": sections}


def _parse_legacy(text: str, fallback_name: str) -> dict:
    """Heading-keyword mapping with a lossless catch-all.

    Preamble (before the first ``## ``) is the identity — it becomes "who"
    (minus a bare ``# SOUL`` title line, whose display name we lift). Every
    H2 block maps by keyword; unmatched blocks keep their original heading
    line and land verbatim in "additional".
    """
    lines = text.splitlines()
    sections: dict[str, list[str]] = {k: [] for k in SECTION_ORDER}
    name = fallback_name

    # split off preamble
    first_h2 = next((i for i, ln in enumerate(lines) if ln.startswith("## ")),
                    len(lines))
    preamble = lines[:first_h2]

    kept_preamble: list[str] = []
    for ln in preamble:
        m = _H1_SOUL.match(ln.strip())
        if m:
            if m.group("name"):
                name = m.group("name").strip()
            continue                       # title line absorbed into the name
        if ln.startswith("# "):            # non-SOUL H1 title (e.g. "# Maya")
            if not kept_preamble:
                name = ln[2:].strip() or name
                continue
        kept_preamble.append(ln)
    who_text = "\n".join(kept_preamble).strip()
    if who_text:
        sections["who"].append(who_text)

    # H2 blocks
    i = first_h2
    while i < len(lines):
        heading_line = lines[i]
        heading = heading_line[3:].strip()
        j = i + 1
        while j < len(lines) and not lines[j].startswith("## "):
            j += 1
        body = "\n".join(lines[i + 1:j]).strip()
        key = _classify(heading)
        # retained headings are demoted to H3 so a composed file can never
        # contain a structural (H2) heading inside section content
        label = f"### {heading}"
        if key is None:
            # catch-all keeps the original heading (demoted) — nothing is lost
            sections["additional"].append(f"{label}\n\n{body}".strip())
        elif sections[key]:
            # second block for the same bucket: keep its heading as a label
            sections[key].append(f"{label}\n\n{body}".strip())
        else:
            sections[key].append(body)
        i = j

    return {
        "format": "legacy",
        "name": name,
        "sections": {k: "\n\n".join(v).strip() for k, v in sections.items()},
    }


def parse_soul(text: str, fallback_name: str = "Agent") -> dict:
    """Sections view of any SOUL.md — composed files exactly, legacy files
    tolerantly, unclassifiable content preserved in ``additional``."""
    if "persona:v1" in text:
        return _parse_v1(text)
    return _parse_legacy(text or "", fallback_name)
