"""Per-workspace catalog scoping — which solution packs a tenant sees.

Pulls the process-wide STUDIO_INCLUDE_PACKS/STUDIO_EXCLUDE_PACKS curation
forward into per-workspace state (the platform plan's Phase 3 item, landed
early for the client demo): each tenant workspace can carry its own
include/exclude pack lists, keyed by ``workspace_code`` per the tenancy
keying rule. A workspace WITHOUT a row falls back to the env-driven
defaults — the ``default`` workspace keeps byte-identical behavior.

Platform-shared content (registry-curated core agents like Jarvis and Alex,
plus the agentfarm-skills wheel) is NOT governed by these lists — shared
content stays global in every workspace by locked design decision.
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timezone

from app.database import get_db, placeholder, q

_TABLE_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workspace_settings ("
    "  workspace_code TEXT PRIMARY KEY,"
    "  include_packs  TEXT NOT NULL DEFAULT '',"
    "  exclude_packs  TEXT NOT NULL DEFAULT '',"
    "  updated_at     TEXT NOT NULL"
    ")"
)

#: Demo tenants (idempotent INSERT-or-ignore; deployments edit rows freely).
#: One pack name per SOLUTION, matching each workspace code:
#:   barrier_insights — the Signal-to-Action solution (its three distributions
#:                      all report Pack(name="barrier_insights"))
#:   ainf             — the AINF commercial-intelligence solution
#:
#: KEEP IN SYNC with ``scripts/seed_workspaces.sql`` — the same seed as SQL, for
#: locked-down databases where this app's user lacks CREATE/INSERT rights and a
#: DBA applies the tenant layout up front. If you change these rows, change that
#: file too; nothing detects the drift automatically.
_SEED_ROWS = [
    {"workspace_code": "barrier_insights",
     "include_packs": "barrier_insights",
     "exclude_packs": "procurement"},
    {"workspace_code": "ainf",
     "include_packs": "ainf",
     "exclude_packs": "procurement"},
]

_seeded = False
_CACHE_TTL = 60.0
_cache: dict = {"rows": None, "at": 0.0}

#: THE DEMO SEED IS OPT-IN (2026-08-27). `_SEED_ROWS` and `_DEMO_WORKSPACES`
#: are the reference deployment's two tenants. Seeding them unconditionally
#: meant that a BRAND-NEW environment - a different client, its own solution,
#: an empty platform schema - woke up with `ainf` and `barrier_insights` in
#: its workspace picker and its bootstrap admin made a member of both. Found
#: by walking env_setup/ on a scratch schema: the Studio listed three
#: workspaces where one had been created. Set STUDIO_SEED_DEMO_WORKSPACES=1
#: on the reference deployment; everywhere else the platform seeds nothing
#: it was not told about.
_DEMO_SEED_ENV = "STUDIO_SEED_DEMO_WORKSPACES"


def demo_seed_enabled() -> bool:
    return os.getenv(_DEMO_SEED_ENV, "").strip().lower() in ("1", "true", "yes", "on")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def reset_cache() -> None:
    global _seeded
    _seeded = False
    _cache["rows"] = None
    _cache["at"] = 0.0


def ensure_table(con) -> None:
    global _seeded
    if _seeded:
        return
    cur = con.cursor()
    cur.execute(_TABLE_DDL)
    insert = (
        "INSERT INTO studio_workspace_settings "
        "(workspace_code, include_packs, exclude_packs, updated_at) "
        "VALUES (?, ?, ?, ?) ON CONFLICT (workspace_code) DO NOTHING"
        if placeholder() == "%s" else
        "INSERT OR IGNORE INTO studio_workspace_settings "
        "(workspace_code, include_packs, exclude_packs, updated_at) "
        "VALUES (?, ?, ?, ?)"
    )
    for row in (_SEED_ROWS if demo_seed_enabled() else []):
        cur.execute(q(insert), (row["workspace_code"], row["include_packs"],
                                row["exclude_packs"], _now()))
    if placeholder() != "%s":
        con.commit()
    _seeded = True


def _all_rows() -> dict[str, dict]:
    now = time.monotonic()
    if _cache["rows"] is not None and now - _cache["at"] < _CACHE_TTL:
        return _cache["rows"]
    rows: dict[str, dict] = {}
    try:
        with get_db() as con:
            ensure_table(con)
            cur = con.cursor()
            cur.execute("SELECT workspace_code, include_packs, exclude_packs "
                        "FROM studio_workspace_settings")
            for r in cur.fetchall():
                d = dict(r)
                rows[d["workspace_code"]] = d
    except Exception:
        return rows or {}
    _cache["rows"] = rows
    _cache["at"] = now
    return rows


#: Demo tenant registry rows (engine `workspaces` table) — created
#: idempotently so a fresh environment gets the same demo with no manual SQL.
_DEMO_WORKSPACES = [
    {"code": "barrier_insights", "name": "Barrier Insights",
     "description": "Pharma Signal-to-Action solution workspace"},
    {"code": "ainf", "name": "AINF",
     "description": "AINF commercial-intelligence workspace"},
]


def ensure_demo_workspaces(con) -> None:
    """Idempotent seed of the demo tenant rows in iof.workspaces - ONLY when
    STUDIO_SEED_DEMO_WORKSPACES is set (see `demo_seed_enabled`)."""
    if not demo_seed_enabled():
        return
    cur = con.cursor()
    for ws in _DEMO_WORKSPACES:
        cur.execute(q("SELECT id FROM workspaces WHERE code=?"), (ws["code"],))
        if cur.fetchone():
            continue
        cur.execute(
            q("INSERT INTO workspaces (code, name, description, created_at,"
              " updated_at) VALUES (?, ?, ?, ?, ?)"),
            (ws["code"], ws["name"], ws["description"], _now(), _now()))
    if placeholder() != "%s":
        con.commit()


def seed_scoped_catalogs() -> dict:
    """Seed each scoped tenant's workflow catalog from its DB-declared packs.

    ON THE ENGINE. This called ``workflow_defs.sync_from_disk`` until that
    reader moved out — reading pack files is exactly what this pod cannot do —
    and the call site then raised ``AttributeError`` on every startup, logged
    as a warning and swallowed. Nothing else seeds a SCOPED tenant (the
    propagation inside a default sync only refreshes rows that already exist),
    so every scoped workspace listed zero workflows while its `include_packs`
    sat correct in this very table. The symptom was silent in both directions:
    a warning nobody reads, and an empty list that looks like curation.

    Convergent and idempotent, so it is safe on every startup — studio-authored
    rows are never clobbered by a pack re-import. Best-effort by contract: the
    engine may not be up yet, and ``ioagentfarm sync`` does the same work with
    no server at all.
    """
    results: dict[str, object] = {}
    for code, row in _all_rows().items():
        include = [p.strip() for p in (row["include_packs"] or "").split(",")
                   if p.strip()]
        try:
            from app.routers.studio import _engine_json
            # `workspace_code=` is REQUIRED here, not decoration. Without it
            # the engine is chosen from the request-time active workspace,
            # and this loop runs at STARTUP where there is no request: every
            # workspace failed with WorkspaceNotSelected and the seed never
            # ran anywhere. It is also wrong whenever it could resolve - one
            # engine per workspace means each code has its OWN engine, so a
            # single ambient code would sync every tenant against one of
            # them. The body already carried the code; only the routing
            # missed it.
            results[code] = _engine_json(
                "POST", "/api/workflows/defs/sync", workspace_code=code,
                json={"workspace_code": code, "include_packs": include})
        except Exception as exc:
            results[code] = {"error": str(exc)}
    return results


def seed_empty_scope(workspace_code: str) -> bool:
    """Give a brand-new workspace an EMPTY scoping row. True if written.

    An absent row means UNSCOPED, and unscoped means the Studio lists every
    installed pack's agents — so a workspace created in the product and never
    imported into opened on another solution's content (observed: Agents 12 ·
    Skills 38, with Pharma Intel, Maya, Vera and MarketScope in a workspace
    that had nothing in it). The scoping row was only ever written by
    ``workspace push``, which a Studio-only workspace never runs.

    An empty row is not "hide everything": the shared platform tier
    (Jarvis/Quinn/Alex) and the workspace's own Studio-built agents are not
    governed by these lists. It means "no SOLUTION packs yet", which is the
    truth about a workspace nobody has imported into.

    Never overwrites: ``workspace push`` claims the empty row afterwards
    (``workspace_sync._scope_workspace_to_solution``), and a curated row is
    a deliberate choice. ``default`` is skipped — it is unscoped by design.
    Best-effort: creation must not fail because the scope row did.
    """
    from ioagentfarm.engine.workspaces import PLATFORM_TIER
    if workspace_code == PLATFORM_TIER:  # the platform tier is unscoped by design
        return False
    try:
        with get_db() as con:
            ensure_table(con)
            cur = con.cursor()
            cur.execute(q("SELECT workspace_code FROM studio_workspace_settings"
                          " WHERE workspace_code=?"), (workspace_code,))
            if cur.fetchone() is not None:
                return False
            cur.execute(
                q("INSERT INTO studio_workspace_settings (workspace_code,"
                  " include_packs, exclude_packs, updated_at)"
                  " VALUES (?, '', '', ?)"), (workspace_code, _now()))
            if placeholder() != "%s":
                con.commit()
        reset_cache()
        return True
    except Exception:
        return False


def packs_for(workspace_code: str) -> dict | None:
    """{'include': [...], 'exclude': [...]} for a scoped workspace, or None
    when the workspace has no settings row (env defaults apply)."""
    row = _all_rows().get(workspace_code)
    if not row:
        return None
    return {
        "include": [p.strip() for p in (row["include_packs"] or "").split(",")
                    if p.strip()],
        "exclude": [p.strip() for p in (row["exclude_packs"] or "").split(",")
                    if p.strip()],
    }
