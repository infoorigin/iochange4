"""Content-draft data access for the Studio API pod.

OWNS: the plumbing between the API's request-scoped database
(``app.database.get_db`` + ``placeholder``) and the ONE draft implementation
in :mod:`ioagentfarm.engine.drafts` — its ``(con, is_pg)`` functions — plus
the read-side composition every Studio surface shares: the caller's draft
VIEW (staleness computed against the CURRENT engine base, with the derived
``promoted`` state persisted so the Studio stops nagging), and the
metadata-only listing other workspace members may see (WHO holds a draft is
a workspace fact; another author's CONTENT is not).

MUST NOT import: ``ioagentfarm.engine.draft_files`` (it touches disk, and
this pod has none — ``tests/test_studio_without_a_filesystem.py`` is the
guard), anything under ``app.routers``, and nothing here may resolve
``get_settings().iof_root``. Base bytes come only from ``app.engine_catalog``
— the engine rail — never from a filesystem or a content table.
"""

from __future__ import annotations

import logging

from ioagentfarm.engine import drafts as engine_drafts

logger = logging.getLogger(__name__)

#: Re-exported so callers spell the reserved carriage key one way.
SKILLS_KEY = engine_drafts.SKILLS_KEY

KINDS = engine_drafts.KINDS


def _is_pg() -> bool:
    # Derived from q(), not placeholder(): q is the seam the test harness
    # patches alongside get_db, so dialect and connection can never disagree
    # — placeholder() reads IOF_DATABASE_URL, which on a dev box may name
    # Postgres while the patched connection is sqlite.
    from app.database import q
    return q("?") == "%s"


def split_stamp(stamp: str | None) -> tuple[str, str, str]:
    """``"pack version @ sha"`` -> its three columns ('' where absent).

    The rendered stamp is what the catalog serves; the split copy exists so
    SQL can filter on it — parsing failure degrades to empty columns rather
    than refusing the save, because the stamp is provenance, not a key.
    """
    raw = (stamp or "").strip()
    if not raw:
        return "", "", ""
    left, _, sha = raw.partition(" @ ")
    pack, _, version = left.strip().rpartition(" ")
    if not pack:                       # a one-word stamp: call it the pack
        pack, version = version, ""
    return pack.strip(), version.strip(), sha.strip()


def _ensured(con) -> None:
    # Idempotent ensure so a read does not 500 on a database that predates
    # the table — but ONCE per (DB URL, schema) per process, through the
    # same memo `workflow_defs.ensure_defs_once` uses. Per CALL it was 3
    # statements, and a list render calls in here once per row: 13 rows on
    # /api/studio/agents cost 9.6s of pure round trip re-creating one table.
    from app.database import ensure_once
    ensure_once("content_drafts",
                con, lambda c: engine_drafts.ensure_table(c, is_pg=_is_pg()))


# ── raw verbs over the API's own connection ──────────────────────────

def upsert(workspace_code: str, kind: str, name: str, author: str,
           files: dict, base_files: dict | None, base_stamp: str,
           note: str = "") -> dict:
    from app.database import get_db
    pack, version, sha = split_stamp(base_stamp)
    with get_db() as con:
        _ensured(con)
        return engine_drafts.upsert_draft(
            con, is_pg=_is_pg(), workspace_code=workspace_code, kind=kind,
            name=name, author=author, files=files,
            base_files=base_files or {}, base_stamp=base_stamp or "",
            base_pack=pack, base_version=version, base_git_sha=sha, note=note)


def get(draft_id: int) -> dict | None:
    from app.database import get_db
    with get_db() as con:
        _ensured(con)
        return engine_drafts.get_draft(con, draft_id, is_pg=_is_pg())


def find(workspace_code: str, kind: str, name: str, author: str) -> dict | None:
    from app.database import get_db
    with get_db() as con:
        _ensured(con)
        return engine_drafts.find_draft(con, workspace_code, kind, name,
                                        author, is_pg=_is_pg())


def list_drafts(workspace_code: str, *, author: str | None = None,
                kind: str | None = None, name: str | None = None) -> list[dict]:
    from app.database import get_db
    with get_db() as con:
        _ensured(con)
        return engine_drafts.list_drafts(con, workspace_code, is_pg=_is_pg(),
                                         author=author, kind=kind, name=name)


def set_status(draft_id: int, status: str, **kw) -> dict | None:
    from app.database import get_db
    with get_db() as con:
        _ensured(con)
        return engine_drafts.set_status(con, draft_id, status,
                                        is_pg=_is_pg(), **kw)


def rebase(draft_id: int, *, base_files: dict, base_stamp: str) -> dict | None:
    from app.database import get_db
    pack, version, sha = split_stamp(base_stamp)
    with get_db() as con:
        _ensured(con)
        return engine_drafts.rebase_draft(
            con, draft_id, is_pg=_is_pg(), base_files=base_files,
            base_stamp=base_stamp, base_pack=pack, base_version=version,
            base_git_sha=sha)


# ── the current base, from the ONE rail ──────────────────────────────

def current_base(kind: str, name: str,
                 workspace_code: str) -> tuple[dict, str]:
    """``({rel: text}, stamp)`` of the item as the engine runs it now.

    ``({}, '')`` when no installed pack provides the name — the new-item
    case, in which a draft can never be stale (there is no base to move).
    Raises the rail's 502 when the engine is down: staleness computed
    against a guessed base would show a false 'promoted'/'stale'.
    """
    from app import engine_catalog
    if kind == "agent":
        d = engine_catalog.agent_files(name, workspace_code)
        if d is None:
            return {}, ""
        files = {k: v for k, v in (d.get("files") or {}).items()
                 if isinstance(v, str)}
        return files, d.get("stamp") or ""
    if kind == "skill":
        d = engine_catalog.skill_files(name, workspace_code)
        if d is None:
            return {}, ""
        files = {k: v for k, v in (d.get("files") or {}).items()
                 if isinstance(v, str)}
        return files, d.get("stamp") or ""
    if kind == "workflow":
        d = engine_catalog.workflow_detail(name, workspace_code)
        if d is None:
            return {}, ""
        files = {k: v for k, v in (d.get("files") or {}).items()
                 if isinstance(v, str)}
        if d.get("yaml"):
            files.setdefault("workflow.yaml", d["yaml"])
        return files, d.get("stamp") or ""
    raise ValueError(f"unknown draft kind {kind!r}")


# ── the shared read shapes ───────────────────────────────────────────

def view(draft: dict, workspace_code: str) -> dict:
    """The caller-facing shape of ONE draft, staleness included.

    ``promoted`` is DERIVED (current base bytes == draft bytes) and then
    persisted, so a draft whose change has landed stops being offered for
    rebase — detected here rather than declared anywhere, which is what
    keeps a draft from claiming promotion while the pod still runs the old
    bytes.
    """
    base, stamp = current_base(draft["kind"], draft["name"], workspace_code)
    st = engine_drafts.staleness(draft, stamp, base)
    if st["promoted"] and draft.get("status") in ("draft", "applied"):
        updated = set_status(draft["id"], "promoted", promoted_ref=stamp or "")
        if updated is not None:
            draft = updated
    return {
        "id": draft["id"],
        "kind": draft["kind"],
        "name": draft["name"],
        "author": draft["author"],
        "status": draft["status"],
        "note": draft.get("note") or "",
        "base_stamp": draft.get("base_stamp") or "",
        "stale": st["stale"],
        "promoted": st["promoted"],
        "conflicts": st["conflicts"],
        "files": draft.get("files") or {},
        "updated_at": draft.get("updated_at"),
        "created_at": draft.get("created_at"),
    }


def meta(draft: dict, current_stamp: str | None = None) -> dict:
    """The metadata OTHER members may see — never another author's content.

    ``stale`` here is the cheap form (pinned stamp vs the list's current
    stamp) so a list of N items costs no extra engine calls; the full
    three-way answer lives in :func:`view`.
    """
    return {
        "id": draft["id"],
        "author": draft["author"],
        "status": draft["status"],
        "stale": bool(current_stamp)
        and (draft.get("base_stamp") or "") != current_stamp,
        "updated_at": draft.get("updated_at"),
    }


def for_kind(workspace_code: str, kind: str) -> dict[str, list[dict]]:
    """Every open draft of one kind, grouped by item name — ONE query for a
    whole list render instead of one per row."""
    grouped: dict[str, list[dict]] = {}
    for d in list_drafts(workspace_code, kind=kind):
        grouped.setdefault(d["name"], []).append(d)
    return grouped


def for_all_kinds(workspace_code: str) -> dict[str, dict[str, list[dict]]]:
    """``{kind: {name: [draft, ...]}}`` — every open draft, in ONE query.

    `for_kind` is the right shape for a page that renders one kind. The
    sidebar counts three, and calling it three times is three round trips for
    a table that was going to be read whole anyway.
    """
    grouped: dict[str, dict[str, list[dict]]] = {}
    for d in list_drafts(workspace_code):
        grouped.setdefault(d["kind"], {}).setdefault(d["name"], []).append(d)
    return grouped


def caller_draft(grouped: dict[str, list[dict]], name: str,
                 author: str) -> dict | None:
    author = (author or "").strip().lower()
    for d in grouped.get(name, []):
        if d["author"] == author:
            return d
    return None
