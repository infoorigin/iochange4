"""Refuse a server-side fetch that points back inside the network.

WHY. `POST /documents/fetch-url-content` took any URL, fetched it with
`requests.get`, and returned the whole body — behind no authentication at
all. A validator proved it with no Authorization header::

    POST /documents/fetch-url-content   X-Workspace-Id: 1
    {"url": "http://127.0.0.1:8410/health"}
    -> 200 {"content": "{\\"ok\\":true}"}

The only gate was a workspace id, and `1` is guessable. In a pod that is the
cloud metadata endpoint and every internal service the pod can route to —
including the engine itself, whose own default posture on loopback is
authentication off.

Membership is now required on the router, which closes the anonymous half.
This module closes the other half: an authenticated Studio user is not
entitled to read the pod's own network either. The feature exists to bypass
CORS for a document the user is importing, so the public internet is the
whole of its legitimate range.

WHAT IS REFUSED, and it is deliberately a DENY of the private ranges rather
than an allow-list of hosts: a Studio genuinely fetches arbitrary customer
document URLs, so an allow-list would have to be empty or useless. Every
address a name resolves to is checked, not just the first, and the check runs
against the RESOLVED address so a hostname pointing at 169.254.169.254 does
not slip through.

WHAT THIS CANNOT DO. It does not defeat DNS rebinding: the name is resolved
here and again by the HTTP client, and a record with a one-second TTL can
differ between the two. Closing that needs the connection pinned to the
address that was checked. Stated rather than papered over.
"""
from __future__ import annotations

import ipaddress
import socket
from typing import Iterable
from urllib.parse import urlparse

#: Only these reach the network. `file:`, `gopher:`, `ftp:` and the rest are
#: how a fetcher becomes a file reader.
ALLOWED_SCHEMES = ("http", "https")

#: Cloud instance-metadata addresses, which are the first thing anyone tries.
#: They are inside the link-local range below, but named so a refusal message
#: can say WHY rather than leave the reader guessing.
METADATA_HOSTS = frozenset({
    "169.254.169.254",          # AWS, Azure, GCP, DigitalOcean, Oracle
    "metadata.google.internal",
    "metadata.goog",
    "100.100.100.200",          # Alibaba
})


class UrlRefused(ValueError):
    """The URL is not one this service will fetch."""


def _addresses_for(host: str) -> Iterable[ipaddress._BaseAddress]:
    """Every address the host resolves to. A literal resolves to itself."""
    try:
        return [ipaddress.ip_address(host)]
    except ValueError:
        pass
    infos = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
    out = []
    for family, _type, _proto, _canon, sockaddr in infos:
        try:
            out.append(ipaddress.ip_address(sockaddr[0]))
        except ValueError:
            continue
    return out


def check_fetchable(url: str) -> str:
    """Return the URL if it may be fetched; raise :class:`UrlRefused` if not."""
    raw = (url or "").strip()
    if not raw:
        raise UrlRefused("no URL was given")

    parsed = urlparse(raw)
    if parsed.scheme.lower() not in ALLOWED_SCHEMES:
        raise UrlRefused(
            f"scheme {parsed.scheme or '(none)'!r} is not fetchable; only "
            f"{' and '.join(ALLOWED_SCHEMES)} are")

    host = (parsed.hostname or "").strip().rstrip(".")
    if not host:
        raise UrlRefused("the URL names no host")
    if host.lower() in METADATA_HOSTS:
        raise UrlRefused(
            "that address is a cloud instance-metadata endpoint, which this "
            "service will not fetch")

    try:
        addresses = list(_addresses_for(host))
    except Exception as exc:  # noqa: BLE001 - an unresolvable name is refused
        raise UrlRefused(f"the host could not be resolved: {exc}") from exc
    if not addresses:
        raise UrlRefused("the host resolved to no address")

    # EVERY address, not the first: a name with one public and one private
    # record would otherwise pass on the public one and connect to either.
    for address in addresses:
        if (address.is_private or address.is_loopback or address.is_reserved
                or address.is_link_local or address.is_multicast
                or address.is_unspecified):
            raise UrlRefused(
                "that host resolves to an address inside this network, which "
                "this service will not fetch. Only public URLs can be "
                "imported.")
    return raw
