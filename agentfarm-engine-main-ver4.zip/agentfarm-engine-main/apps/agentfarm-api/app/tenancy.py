"""Tenant workspace resolution — ONE place where a request becomes a tenant.

THE TENANCY KEYING RULE (platform-wide, do not mix):
  * ``iof.workspaces`` is the tenant registry. Engine-owned tables
    (``runs``, ``messages``) carry the numeric ``workspace_id`` FK.
  * API-owned ``studio_*`` tables carry the stable human ``workspace_code``
    (requests address tenants by code; codes survive DB rebuilds).
  * The API resolves code<->id EXACTLY ONCE per request via this module —
    no endpoint mixes the two keys in one table, no endpoint re-derives the
    mapping itself.

THE EXPLICIT-WORKSPACE CONTRACT (user directive, 2026-08-09 — replaces the
"universal fallback" this module used to implement):
  * The API NEVER invents a tenant. A request that does not name a valid
    workspace is refused: missing/empty/``'0'`` X-Workspace-Id -> 400;
    unknown or retired id/code -> 403; registry unreachable -> 503.
    Silent fallback to ``default`` is how it became impossible to say
    which workspace served which answer — and how a request carrying a
    deleted or foreign workspace id was answered from another tenant's
    data with a 200.
  * ``default`` is retired as a workspace. The literal survives only as
    the PLATFORM TIER — the internal shared-tier key for catalog rows —
    imported as ``PLATFORM_TIER``, never resolvable from a request.
  * Paths that legitimately precede workspace selection (health, auth,
    workspace list/create, admin) are exempted BY THE MIDDLEWARE in
    main.py, not here.

The browser sends ``X-Workspace-Id`` (numeric id as a string) on every
request via the axios interceptor; this module resolves it exactly once per
request (middleware in main.py -> app.workspace_context contextvar).
The engine applies the same contract in ``cli._workspace_code`` /
``web.app._run_workspace_code``.
"""
from __future__ import annotations

import logging
import time

from fastapi import Header, HTTPException

from ioagentfarm.engine.workspaces import (PLATFORM_TIER,
                                           RETIRED_WORKSPACE_CODES)

from app.database import get_db, q

logger = logging.getLogger(__name__)

#: id -> code map, cached briefly: the header rides EVERY request and the
#: engine DB is typically remote RDS. Invalidate on workspace create/update.
_CACHE_TTL = 60.0
_cache: dict = {"map": None, "at": 0.0}


def invalidate_cache() -> None:
    _cache["map"] = None
    _cache["at"] = 0.0


def _workspace_map() -> dict[int, dict]:
    """id -> row for every registered workspace. RAISES on a DB failure —
    the caller turns that into a 503, never a silently-chosen tenant."""
    now = time.monotonic()
    if _cache["map"] is not None and now - _cache["at"] < _CACHE_TTL:
        return _cache["map"]
    rows: dict[int, dict] = {}
    with get_db() as con:
        cur = con.cursor()
        cur.execute("SELECT id, code, name, description FROM workspaces")
        for r in cur.fetchall():
            d = dict(r)
            rows[int(d["id"])] = d
    _cache["map"] = rows
    _cache["at"] = now
    return rows


def resolve_workspace(x_workspace_id: str | None) -> dict:
    """Header value -> ``{"id": int, "code": str, "name": str}``. Fail-closed:

    * missing/empty/``'0'`` -> 400 (the header is required)
    * unknown id or code, or a retired code -> 403
    * workspace registry unreachable -> 503
    """
    raw = (x_workspace_id or "").strip()
    if not raw or raw == "0":
        raise HTTPException(
            status_code=400,
            detail="X-Workspace-Id header is required: name the workspace "
                   "this request acts on (numeric id or code; a stream that "
                   "cannot set headers may use the workspace_id query "
                   "parameter instead). There is no fallback workspace.")
    try:
        wmap = _workspace_map()
    except Exception:
        logger.warning("workspace registry unreachable during tenancy "
                       "resolution", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail="workspace registry unavailable; cannot resolve "
                   "X-Workspace-Id")
    try:
        ws = wmap.get(int(raw))
    except ValueError:
        # a CODE instead of a numeric id — honor it if it exists
        ws = next((w for w in wmap.values() if w["code"] == raw), None)
    if ws is not None and ws["code"] in RETIRED_WORKSPACE_CODES:
        raise HTTPException(
            status_code=403,
            detail="the 'default' workspace is retired and cannot be "
                   "addressed. Create a named workspace and adopt its data: "
                   "aicore workspace rename default <code>")
    if ws is None:
        raise HTTPException(
            status_code=403,
            detail=f"unknown workspace {raw!r}: not a registered workspace "
                   "id or code")
    return {"id": int(ws["id"]), "code": ws["code"],
            "name": ws.get("name") or ws["code"],
            "description": ws.get("description") or ""}


def active_workspace(x_workspace_id: str | None = Header(None)) -> dict:
    """FastAPI dependency form of :func:`resolve_workspace`."""
    return resolve_workspace(x_workspace_id)


def active_code(x_workspace_id: str | None = Header(None)) -> str:
    """FastAPI dependency: just the tenant code (the studio_* table key)."""
    return resolve_workspace(x_workspace_id)["code"]
