"""Save → draft: the translation the six Studio save endpoints delegate to.

OWNS: turning "what the builder sent" into one author's base-pinned DRAFT
(One Truth s3.5): building the overlay from the request against the pinned
base, deciding which of the three shapes an item is in — a PACK item (base =
the engine catalog's files + stamp), a LEGACY tenant row (seeds a NEW-ITEM
draft from the row; the row is never written again), or a NEW item (empty
base) — and the carriage rule: an agent's skill set travels in the overlay
under :data:`app.drafts.SKILLS_KEY`, so a skill add/remove on a pack agent
is draft-only until promoted, exactly like a SOUL.md edit.

MUST NOT import: ``app.routers`` (this is what the routers call, never the
reverse), ``ioagentfarm.engine.draft_files`` (disk — this pod has none), and
nothing here may resolve ``get_settings().iof_root``. Request parsing and
HTTP-shape validation stay in the endpoint; only the draft translation lives
here.
"""

from __future__ import annotations

import logging

from fastapi import HTTPException

from app import drafts as app_drafts
from ioagentfarm.engine import drafts as engine_drafts

logger = logging.getLogger(__name__)

#: The identity files an agent overlay may carry. Restricting the diff to
#: these keeps a pack agent's overlay to what the builder can actually edit —
#: without it, a stray key in the engine's file tree (a skills/ path, a
#: memory file) would ride into every draft and make every one look stale.
AGENT_OVERLAY_PATHS = ("SOUL.md", "TOOLS.md", "AGENTS.md", "USER.md",
                       "HEARTBEAT.md", "a2a-card.yaml", ".studio-created")


def _author(identity) -> str:
    """The ONLY source of a draft's author: the verified token's email.

    A client-supplied ``draft_author``/``user_id`` is never consulted — the
    engine has no auth, so this API is the one place identity is real, and a
    draft attributed to whatever the browser typed would let one member edit
    under another's name.
    """
    email = (getattr(identity, "email", "") or "").strip().lower()
    if not email:
        raise HTTPException(status_code=401, detail="no verified caller identity")
    return email


# ── agents ───────────────────────────────────────────────────────────

def agent_state(workspace_code: str, author: str, role: str) -> dict | None:
    """The effective editing state of one agent FOR one author.

    ``files``/``skills`` are what the author currently sees (base ⊕ their own
    draft) so a second save composes on the first instead of silently
    reverting it; ``base_files``/``base_stamp`` are the pin for the next
    save; ``baseline_skills`` is the carriage the non-draft tiers give the
    agent — the reference for "does this save deviate". ``None`` when the
    role exists in no tier at all.
    """
    from app import agent_catalog, engine_catalog
    from app.config import get_settings

    draft = app_drafts.find(workspace_code, "agent", role, author)
    idx = agent_catalog.agent_index(workspace_code,
                                    get_settings().platform_shared_roles)
    rec = idx.get(role)
    if rec is None and draft is None:
        return None

    if rec is not None and not rec.get("unpromoted"):
        d = engine_catalog.agent_files(role, workspace_code, rec.get("stamp"))
        base = {k: v for k, v in ((d or {}).get("files") or {}).items()
                if isinstance(v, str)}
        stamp = (d or {}).get("stamp") or rec.get("stamp") or ""
        baseline = sorted(rec.get("skills") or [])
        shape = "pack"
    elif rec is not None:
        # LEGACY tenant row: shown add-only today, never written again. Its
        # files seed the draft (base stays empty — there is no pack to pin).
        base, stamp = {}, ""
        baseline = sorted(rec.get("skills") or [])
        shape = "legacy"
    else:
        base, stamp = {}, ""
        baseline = engine_drafts.carried_skills(draft["files"]) or []
        shape = "draft"

    if shape == "legacy":
        seed = {k: agent_catalog._decode(v)
                for k, v in (rec.get("files") or {}).items()}
        effective = engine_drafts.overlay(seed, (draft or {}).get("files"))
    else:
        effective = engine_drafts.overlay(base, (draft or {}).get("files"))
    skills = baseline
    if draft is not None:
        carried = engine_drafts.carried_skills(draft["files"])
        if carried is not None:
            skills = carried
    return {"role": role, "shape": shape, "base_files": base,
            "base_stamp": stamp, "baseline_skills": baseline,
            "files": effective, "skills": list(skills), "draft": draft,
            "rec": rec}


def save_agent(workspace_code: str, identity, role: str, state: dict | None,
               files: dict, skills: list[str], note: str = "") -> dict:
    """Persist one agent edit as the author's draft; returns the row.

    ``state=None`` means a brand-new agent (POST): the whole file set is the
    overlay and the base pins empty. A pack agent's overlay carries only the
    identity files that DIFFER from the base plus, when the requested set
    deviates from the baseline, the carriage — nothing else, so 'what did
    this author change?' stays answerable from the row alone.
    """
    author = _author(identity)
    if role == "project_lead":
        # The workflow DRIVER runs on the shared agent home (web/spawn.py) and
        # never resolves a draft, so accepting one here would record an edit
        # that no session can ever exercise — refuse at save, loudly.
        raise HTTPException(
            status_code=409,
            detail="'project_lead' is the workflow driver and runs on the "
                   "shared agent home — a draft on it would never be "
                   "resolved. Edit it in the solution repo instead.")
    skills = sorted({s for s in skills if s})
    if state is not None and state["shape"] == "pack":
        base = state["base_files"]
        overlay: dict = {}
        for p in AGENT_OVERLAY_PATHS:
            in_new, in_base = p in files, p in base
            if in_new and (not in_base or files[p] != base[p]):
                overlay[p] = files[p]
            elif in_base and not in_new:
                overlay[p] = None          # the author removed it (a2a card)
        if skills != sorted(state["baseline_skills"]):
            overlay[app_drafts.SKILLS_KEY] = skills
        pin = {p: base[p] for p in overlay
               if p != app_drafts.SKILLS_KEY and p in base}
        return app_drafts.upsert(workspace_code, "agent", role, author,
                                 overlay, pin, state["base_stamp"], note=note)
    # New item (or a legacy row seeding one): the draft IS the whole agent.
    overlay = {p: v for p, v in files.items() if isinstance(v, str)}
    overlay[app_drafts.SKILLS_KEY] = skills
    return app_drafts.upsert(workspace_code, "agent", role, author,
                             overlay, {}, "", note=note)


def assign_skill_to_agents(workspace_code: str, identity, skill_name: str,
                           roles: list[str]) -> list[str]:
    """Record ``install_to`` carriage as AGENT drafts (carriage is content).

    Returns the roles actually drafted; unknown roles are skipped with a
    warning rather than failing the skill save — the skill draft itself is
    already durable, and half-failing the request would leave the author
    guessing which part landed.
    """
    author = _author(identity)
    drafted: list[str] = []
    for role in roles or []:
        if role == "project_lead":
            continue
        state = agent_state(workspace_code, author, role)
        if state is None:
            logger.warning("install_to names unknown agent %r — skipped", role)
            continue
        if skill_name in state["skills"]:
            continue
        save_agent(workspace_code, identity, role, state, state["files"],
                   [*state["skills"], skill_name])
        drafted.append(role)
    return drafted


def author_skill_carriers(workspace_code: str, author: str,
                          skill_name: str) -> list[str]:
    """Roles whose drafts (this author's) carry *skill_name* — the caller's
    ``used_by`` for a draft-only skill, which no ``studio_skills`` row can
    answer any more because no Save writes one."""
    out = []
    for d in app_drafts.list_drafts(workspace_code, author=author,
                                    kind="agent"):
        carried = engine_drafts.carried_skills(d.get("files"))
        if carried and skill_name in carried:
            out.append(d["name"])
    return sorted(out)


# ── skills ───────────────────────────────────────────────────────────

def save_skill(workspace_code: str, identity, name: str, text: str,
               note: str = "") -> dict:
    """One skill edit as the author's draft. Overlay = SKILL.md.

    A pack skill pins the engine's files; a legacy tenant content row seeds a
    new-item draft carrying the row's whole file set (so nothing of it is
    lost when the row stops being read); everything else is a new item.
    SDK-tier refusal happens in the endpoint BEFORE this — the 409 is a
    policy, not a translation.
    """
    from app import skill_defs
    author = _author(identity)
    base, stamp = app_drafts.current_base("skill", name, workspace_code)
    if base:
        return app_drafts.upsert(workspace_code, "skill", name, author,
                                 {"SKILL.md": text},
                                 {k: v for k, v in base.items()
                                  if k == "SKILL.md"},
                                 stamp, note=note)
    row = skill_defs.get_def(name, workspace_code)
    seed = dict(row["files"]) if row and not row.get("assignment_only") else {}
    seed["SKILL.md"] = text
    return app_drafts.upsert(workspace_code, "skill", name, author,
                             seed, {}, "", note=note)


# ── workflows ────────────────────────────────────────────────────────

def validate_workflow_draft(workspace_code: str, name: str,
                            files: dict) -> dict | None:
    """Ask the ENGINE to lint the draft (base ⊕ overlay happens there, where
    the packs are). ``None`` when the engine does not expose the endpoint
    yet (its 404) — the caller saves anyway and says so, because refusing
    every save until the engine upgrades would block the only edit path.

    Routed through ``engine_catalog``'s binding of the rail deliberately:
    it is the same physical rail every catalog read uses, and the one the
    test fixtures fake.
    """
    from app import engine_catalog
    try:
        return engine_catalog.engine_json(
            "POST", "/api/catalog/drafts/validate",
            purpose="draft validation runs on the engine, where the packs are",
            timeout=60.0,
            json_body={"kind": "workflow", "name": name, "files": files,
                       "workspace": workspace_code},
            workspace_code=workspace_code)
    except HTTPException as exc:
        if exc.status_code == 404:
            return None
        raise


def save_workflow(workspace_code: str, identity, name: str, yaml_text: str,
                  files: dict, note: str = "") -> tuple[dict, dict | None]:
    """One workflow edit as the author's draft; returns ``(row, validation)``.

    ``validation`` is the engine's answer or ``None`` (endpoint absent).
    Findings with severity ``error`` are refused fail-closed — the same
    contract the old dry-run enforced — BEFORE anything is written, so a
    refused save leaves no half-draft behind.
    """
    from app import workflow_defs
    author = _author(identity)
    prior = app_drafts.find(workspace_code, "workflow", name, author)
    base, stamp = app_drafts.current_base("workflow", name, workspace_code)

    overlay: dict = dict((prior or {}).get("files") or {})
    overlay.update({k: v for k, v in files.items() if isinstance(v, str)})
    overlay["workflow.yaml"] = yaml_text
    if base:
        # Pack item: keep only what deviates, so promotion detection and the
        # diff describe the author's change rather than restating the pack.
        overlay = {p: v for p, v in overlay.items() if base.get(p) != v}
        pin = {p: base[p] for p in overlay if p in base}
    else:
        row = workflow_defs.get_def(name, workspace_code)
        if row is not None and row.get("source") == "studio":
            seed = workflow_defs.def_files(row)
            merged = dict(seed)
            merged.update(overlay)
            merged.setdefault("workflow.yaml", row["yaml"])
            overlay, pin, stamp = merged, {}, ""
        else:
            pin, stamp = {}, ""

    validation = validate_workflow_draft(workspace_code, name, overlay)
    if validation is not None:
        errors = [f for f in (validation.get("findings") or [])
                  if str(f.get("severity", "error")).lower() == "error"]
        if errors or validation.get("valid") is False:
            first = errors[0] if errors else {"message": "invalid workflow"}
            raise HTTPException(
                status_code=400,
                detail=f"draft validation failed: "
                       f"{first.get('message') or first}")
    row = app_drafts.upsert(workspace_code, "workflow", name, author,
                            overlay, pin, stamp, note=note)
    return row, validation
