"""Lightweight DB layer — the ENGINE database (single system of record).

All engine-type data this API serves (runs/sessions, steps, messages,
workspaces, workflows, agents, users, skill-hub / cli-hub tables) resolves
through this ONE connection. The URL comes from ``IOF_DATABASE_URL``
resolved at REQUEST time — the same cutover-safe pattern as
``barrier_insights._hub_schema()`` / ``hil_queue`` — so a DB repoint or a
schema rebuild takes effect on the next request, and a long-running API
process can never keep serving sessions out of a stale legacy store.

Fail-closed: a missing ``IOF_DATABASE_URL`` raises 503 instead of silently
falling back to a local sqlite file (the legacy behaviour — it let the
home page list historical sessions from an abandoned local store instead
of the engine DB).

The ONLY other database connection in this API is the business-data hub
(``BARRIER_SIGNAL_DB_URL`` — ``barrier_insights.py`` / ``hil_queue.py``).
Engine data must never be read from it, and business data never from here.

All access is read-heavy; writes only happen when starting a session
(via ioagentfarm CLI subprocess, not direct INSERT).
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
import threading
from contextlib import contextmanager
from typing import Any, Generator

#: Default PostgreSQL schema for engine-owned tables. Unset env → this value,
#: so a deployment that never sets IOF_DB_SCHEMA behaves exactly as before.
DEFAULT_ENGINE_SCHEMA = "iof"

#: A bare SQL identifier. The schema name comes from the environment and is
#: interpolated into `SET search_path`, which takes no bind parameter — so it
#: is validated rather than escaped.
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def engine_schema() -> str:
    """PostgreSQL schema holding the engine tables.

    Resolved per request (like ``engine_db_url()``), so repointing the API at
    another schema needs no restart. Must match the engine's own
    ``IOF_DB_SCHEMA`` — the two processes share these tables.
    """
    raw = (os.getenv("IOF_DB_SCHEMA") or DEFAULT_ENGINE_SCHEMA).strip()
    if not _IDENT_RE.match(raw):
        raise ValueError(
            f"IOF_DB_SCHEMA={raw!r} is not a valid SQL identifier "
            "(letters, digits and underscore only, not starting with a digit)"
        )
    return raw

from fastapi import HTTPException


def engine_db_url() -> str:
    """The engine DB URL, resolved from the environment at request time.

    No fallback: the engine DB is the system of record, and a silent
    sqlite fallback is exactly the legacy-store path this module bans.
    """
    url = (os.getenv("IOF_DATABASE_URL") or "").strip()
    if not url:
        raise HTTPException(
            status_code=503,
            detail="IOF_DATABASE_URL is not configured (engine DB unavailable); "
                   "refusing to fall back to a local store",
        )
    return url


def _parse_url(url: str) -> tuple[str, str]:
    """Returns (backend, connection_string)."""
    if url.startswith("postgresql://") or url.startswith("postgres://"):
        return "postgres", url
    path = ""
    if url.startswith("sqlite:///"):
        path = url[len("sqlite:///"):]
    elif url.startswith("sqlite://"):
        path = url[len("sqlite://"):]
    else:
        path = url
    return "sqlite", path



#: (url, schema) -> pool. KEYED BY BOTH, deliberately: each is resolved at
#: REQUEST time so a repoint takes effect without a restart, and a single
#: module-level pool would have quietly kept serving the old database — the
#: exact property this module's docstring promises, broken by the fix for
#: something else.
#:
#: WHY POOL AT ALL. `get_db()` opened a fresh connection per use and closed
#: it, and there are 111 call sites: serving ONE `/api/studio/agents` request
#: opened 24 connections. Measured against RDS from a laptop, a connect costs
#: 1.8s versus 0.27s for a query, so 24 connects were 43s of a 71s request —
#: 61% of it spent on TCP, TLS and auth. Beside the database a connect is
#: sub-millisecond, which is why this was invisible in production and why the
#: code treats a connection as free.
_POOLS: dict[tuple[str, str], Any] = {}
_POOL_LOCK = threading.Lock()


def _statement_timeout_option() -> str:
    """`-c statement_timeout=...`, or "" when disabled.

    THE LAST RESORT UNDER THE KEEPALIVES. Keepalives detect a peer that
    stopped answering; they do nothing about a query the server is genuinely
    still running. Either way the pool slot is held, and this pool is small
    (maxconn 10 by default) and now holds connections across worker threads
    for the length of a turn - so one query that never returns costs a tenth
    of the pod's database capacity permanently.

    Generous by default: this is a runaway guard, not a latency budget. Set
    `IOF_API_PG_STATEMENT_TIMEOUT_MS=0` to disable it entirely.
    """
    default = 60000
    raw = os.getenv("IOF_API_PG_STATEMENT_TIMEOUT_MS", str(default)).strip()
    try:
        value = int(raw)
    except ValueError:
        # A TYPO MUST NOT DISABLE A GUARD. Returning "" here would switch the
        # runaway protection off because someone wrote `60_000` or `60s`, and
        # nothing would say so - the failure it protects against is exactly
        # the one nobody notices until the pool is empty.
        logging.getLogger(__name__).warning(
            "IOF_API_PG_STATEMENT_TIMEOUT_MS=%r is not an integer - using the "
            "default %dms. Set it to 0 to disable the timeout deliberately.",
            raw, default)
        value = default
    return f" -c statement_timeout={value}" if value > 0 else ""


#: When a connection last completed a checkout cleanly, keyed by id(con).
#: See `_checkout` for why this exists rather than probing every time.
_LAST_OK: dict = {}


def _checkout(pool):
    """A LIVE connection from *pool*, discarding any that is not.

    Ported from `engine/db.py`, which added it because a managed-Postgres
    connection dropped while idle in the pool does not announce itself: it
    surfaces mid-operation as "server closed the connection unexpectedly", or
    simply blocks. `con.closed` catches what psycopg2 already knows about at
    no cost; the round-trip probe catches the rest.

    THE PROBE IS WINDOWED, deliberately. It costs two round trips - measured
    at 780 ms against RDS in the engine - and paying that on every checkout
    would undo the pooling work this module exists to do (a studio page load
    borrows six connections). Within the window a peer that died is not yet
    detectable by anything cheaper anyway: the keepalives above have not
    begun probing, and every cause of a dead pooled connection - RDS idle
    timeout, failover, NAT reaping - takes minutes.
    """
    import time as _time

    retries = max(1, int(os.getenv("IOF_API_PG_CHECKOUT_RETRIES", "3")))
    probe_after = float(os.getenv("IOF_API_PG_PROBE_AFTER_S", "20"))
    last_err = None
    for _ in range(retries):
        con = pool.getconn()
        if con.closed:                     # local flag, no round trip
            _LAST_OK.pop(id(con), None)
            pool.putconn(con, close=True)
            continue
        seen = _LAST_OK.get(id(con), 0.0)
        if _time.monotonic() - seen < probe_after:
            return con
        try:
            # The probe must not leave a transaction behind. With autocommit
            # off, psycopg2 wraps `SELECT 1` in an implicit BEGIN, and the
            # `con.autocommit = True` that `get_db` applies next is refused
            # inside it - "set_session cannot be used inside a transaction" -
            # so the FIRST checkout of every pooled connection failed and the
            # Studio API 500ed on every request that touched the engine DB.
            # Found live on a fresh local stack the day after the probe landed;
            # the suite runs on SQLite and never took this path. The engine's
            # pool (engine/db.py) avoids it by rolling back and staying in
            # explicit transactions; this pool hands out autocommit
            # connections, so the flip happens here, before the probe.
            if not con.autocommit:
                con.rollback()
                con.autocommit = True
            with con.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        except Exception as exc:           # noqa: BLE001 - any dead socket
            last_err = exc
            _LAST_OK.pop(id(con), None)
            try:
                pool.putconn(con, close=True)
            except Exception:              # noqa: BLE001
                pass
            continue
        _LAST_OK[id(con)] = _time.monotonic()
        return con
    if last_err is not None:
        raise last_err
    raise RuntimeError("no live database connection could be taken from the pool")


def _pool_for(connstr: str, schema: str):
    """The pool for *connstr* at *schema*, created once.

    KEYED BY SCHEMA TOO, because the schema is baked into the connections it
    holds (see ``options`` below) — one pool per URL would hand out
    connections pointing at whichever schema happened to create it, which is
    the request-time-repoint contract broken one level down.
    """
    import psycopg2.extras
    import psycopg2.pool

    key = (connstr, schema)
    pool = _POOLS.get(key)
    if pool is None:
        with _POOL_LOCK:
            pool = _POOLS.get(key)          # re-check: another thread may have won
            if pool is None:
                pool = psycopg2.pool.ThreadedConnectionPool(
                    # OPENED UP FRONT, and that is the point. psycopg2 opens
                    # `minconn` connections inside the pool constructor, and
                    # the constructor runs on whichever request first touches
                    # the DB — at startup here, because main.py ensures the
                    # schema. Left at 1, the pool grew one connection at a
                    # time under load, and psycopg2 holds its own lock across
                    # a connect: six concurrent studio calls (what a single
                    # page load IS) serialized five 1.8s RDS connects behind
                    # each other, so requests that measured 4-6s alone
                    # measured 15-21s together. A profile shows the cost
                    # plainly as `psycopg2._psycopg._connect` INSIDE a
                    # request. Sized for one page load; raise it for a pod
                    # serving more.
                    minconn=int(os.getenv("IOF_API_DB_POOL_MIN", "6")),
                    # Above the server's own ceiling is worse than useless: the
                    # pool would hand out connections the database refuses.
                    maxconn=int(os.getenv("IOF_API_DB_POOL_MAX", "10")),
                    dsn=connstr,
                    # search_path travels in the CONNECT handshake instead of a
                    # `SET` per checkout. The `SET` was one round trip every
                    # time a connection was borrowed — 0.25s each against RDS
                    # from a laptop, and a studio request borrows six — for a
                    # value that never varies within a pool, since the schema
                    # is now part of the pool's key.
                    options=(f"-c search_path={schema},public"
                             + _statement_timeout_option()),
                    # A DEAD PEER MUST BECOME DETECTABLE. Managed Postgres
                    # (RDS), NAT and failover all drop an idle connection
                    # server-side without telling the client, and a socket in
                    # that state does not raise - it BLOCKS. A connection
                    # blocked in recv() never returns to the pool, so the slot
                    # is gone for the life of the process and `maxconn` is
                    # reached one leak at a time. The engine pool has carried
                    # these since the RDS idle-drop fix; this pool never got
                    # them, and it is the one a browser talks to.
                    keepalives=1,
                    keepalives_idle=int(os.getenv("IOF_PG_KEEPALIVE_IDLE", "30")),
                    keepalives_interval=int(os.getenv("IOF_PG_KEEPALIVE_INTERVAL", "10")),
                    keepalives_count=int(os.getenv("IOF_PG_KEEPALIVE_COUNT", "5")),
                    connect_timeout=int(os.getenv("IOF_PG_CONNECT_TIMEOUT", "10")),
                    cursor_factory=psycopg2.extras.RealDictCursor,
                )
                _POOLS[key] = pool
    return pool


@contextmanager
def get_db() -> Generator[Any, None, None]:
    """Yield a connection to the engine DB with dict-like row access."""
    backend, connstr = _parse_url(engine_db_url())

    if backend == "postgres":
        # The schema is resolved per request and carried in the POOL KEY, so a
        # repoint still takes effect on the next request — it lands on a
        # different pool whose connections were opened with the new
        # search_path, rather than on a `SET` this function had to re-issue
        # every single checkout.
        pool = _pool_for(connstr, engine_schema())
        con = _checkout(pool)
        con.autocommit = True
        try:
            yield con
        except BaseException:
            # A connection that raised may be mid-transaction or dead. Putting
            # it back would hand the fault to the next caller, so it is closed
            # instead — the pool opens a replacement on demand.
            _LAST_OK.pop(id(con), None)
            pool.putconn(con, close=True)
            raise
        else:
            import time as _time
            _LAST_OK[id(con)] = _time.monotonic()
            pool.putconn(con)
    else:
        con = sqlite3.connect(connstr)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL;")
        try:
            yield con
        finally:
            con.close()


def placeholder() -> str:
    """Parameter placeholder for the current backend."""
    backend, _ = _parse_url(engine_db_url())
    return "%s" if backend == "postgres" else "?"


def q(sql: str) -> str:
    """Rewrite ``?`` placeholders to the backend's style."""
    ph = placeholder()
    if ph == "?":
        return sql
    return sql.replace("?", ph)


# ── run-this-DDL-once (schema ensures) ───────────────────────────────
#
# WHY. Every studio read used to re-run its schema ensure on the way in:
# `workflow_defs.ensure_defs` is 16 statements and `drafts.ensure_table` is
# 3, and a statement against RDS from a laptop costs one round trip (0.25s
# measured). Serving ONE `/api/studio/agents` that way spent ~18s of a ~30s
# request re-creating tables that already existed. The DDL is idempotent, so
# every run after the first is pure latency.
#
# Keyed by (URL, schema) — NOT a bare flag — because both are resolved at
# REQUEST time and this module's contract is that a repoint takes effect on
# the next request. A memo that ignored them would report "already ensured"
# about a database it had never opened, which is the same shape as the
# `.skills-assigned.json` bug in the engine (a memo over a scoped write that
# left the scope out of its key).
#
# The memo is only written AFTER the ensure returns: a failed ensure (a DB
# that is not up yet at import time) must be retried, not remembered.
_ENSURED: set[tuple[str, str, str]] = set()
_ENSURED_LOCK = threading.Lock()


def _ensure_key(tag: str) -> tuple[str, str, str]:
    return ((os.getenv("IOF_DATABASE_URL") or "").strip(),
            (os.getenv("IOF_DB_SCHEMA") or DEFAULT_ENGINE_SCHEMA).strip(),
            tag)


def ensure_once(tag: str, con, run) -> None:
    """Call ``run(con)`` once per (engine DB URL, schema, *tag*) per process.

    Two threads may both run it on a cold start; that is harmless — the DDL
    is idempotent, and the alternative (holding a lock across a multi-second
    DDL batch) serialises every request behind it.
    """
    key = _ensure_key(tag)
    if key in _ENSURED:
        return
    run(con)
    with _ENSURED_LOCK:
        _ENSURED.add(key)


def reset_ensure_memo() -> None:
    """Forget every recorded ensure — for tests that rebuild a schema behind
    a URL this process has already served."""
    with _ENSURED_LOCK:
        _ENSURED.clear()
