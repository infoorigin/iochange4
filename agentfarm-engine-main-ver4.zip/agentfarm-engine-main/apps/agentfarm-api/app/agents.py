"""Agent registry — DB-backed with smart cache.

Cache all agents from the DB ``agents`` table. TTL of 1 hour for cached entries.
On cache miss (unknown role), immediately query DB before falling back to
auto-generated display info. No static registry — DB is the source of truth.

Display enrichment (2026-07-27): raw ``agents`` rows are often degenerate for
pack agents (name == role, avatar == role[:2], grey) because the engine's
sync can't always parse the SOUL. ``get_agent()`` therefore ENRICHES the row
on the way out — friendly name from SOUL.md, role label from
``studio_agent_display``, initials derived from the friendly name, and a
distinct deterministic palette color per role. Enrichment happens on the
returned copy only; ``_db_registry`` itself stays byte-identical to the DB
because it doubles as the studio's curation source.
"""

from __future__ import annotations

import logging
import re
import time
import zlib

logger = logging.getLogger(__name__)

_db_registry: dict[str, dict] = {}
_cache_loaded_at: float = 0
_CACHE_TTL = 3600  # 1 hour

#: role -> fully-enriched display dict (cleared alongside the registry cache)
_enriched: dict[str, dict] = {}

#: Distinct, deterministic avatar colors — dark enough for white initials
#: (AA at avatar text size) and not the brand primary of either skin.
_PALETTE = [
    "#0f766e",  # teal
    "#7c3aed",  # violet
    "#b45309",  # amber-brown
    "#be185d",  # pink
    "#1d4ed8",  # blue
    "#4d7c0f",  # olive
    "#c2410c",  # burnt orange
    "#6d28d9",  # purple
    "#0e7490",  # cyan
    "#a21caf",  # magenta
]
_GREY_FALLBACKS = {None, "", "#888888", "#888"}

#: Roles confirmed ABSENT from the registry. Without this, every lookup of a
#: role that has no `agents` row (studio-created agents, pack agents a
#: deployment never registered) re-queries the DB on every call — and the
#: studio's agents list does one lookup per agent, per request. Kept separate
#: from `_db_registry` on purpose: that dict is also the studio's curation
#: source, so seeding derived rows into it would silently widen curation.
_known_missing: set[str] = set()


#: ``soul`` is migration-added, so the read degrades to the columns that have
#: always existed rather than 500ing on a database that predates it.
_AGENT_COLUMNS = "role, name, title, avatar, color, soul"
_AGENT_COLUMNS_LEGACY = "role, name, title, avatar, color"


def _agent_row(r: dict) -> dict:
    return {
        "role": r["role"],
        "name": r["name"],
        "title": r["title"],
        "avatar": r["avatar"],
        "color": r["color"],
        "soul": r.get("soul") or "",
    }


def _load_all() -> dict[str, dict]:
    """Bulk-load all agents from DB (called once per TTL window)."""
    global _db_registry, _cache_loaded_at

    try:
        from app.database import get_db
        with get_db() as con:
            cursor = con.cursor()
            try:
                cursor.execute(f"SELECT {_AGENT_COLUMNS} FROM agents")
            except Exception:
                cursor = con.cursor()
                cursor.execute(f"SELECT {_AGENT_COLUMNS_LEGACY} FROM agents")
            registry = {}
            for row in cursor.fetchall():
                r = dict(row)
                registry[r["role"]] = _agent_row(r)
            _db_registry = registry
            _cache_loaded_at = time.time()
            return _db_registry
    except Exception:
        logger.debug("agents table not available, using existing cache")
        return _db_registry


def _lookup_single(role: str) -> dict | None:
    """Query DB for a single agent by role (cache miss path)."""
    try:
        from app.database import get_db, q
        with get_db() as con:
            cursor = con.cursor()
            try:
                cursor.execute(
                    q(f"SELECT {_AGENT_COLUMNS} FROM agents WHERE role=?"),
                    (role,))
            except Exception:
                cursor = con.cursor()
                cursor.execute(
                    q(f"SELECT {_AGENT_COLUMNS_LEGACY} FROM agents WHERE role=?"),
                    (role,))
            row = cursor.fetchone()
            if row:
                agent = _agent_row(dict(row))
                _db_registry[role] = agent  # warm cache for next call
                return agent
    except Exception:
        logger.debug("Single agent lookup failed for role=%s", role)
    return None


def reload_agents() -> None:
    """Force immediate cache refresh on next call."""
    global _cache_loaded_at
    _cache_loaded_at = 0
    _known_missing.clear()
    _enriched.clear()


def _soul_display_name(role: str) -> str | None:
    """Friendly agent name from the agent's SOUL, tolerant of the repo's
    conventions (mirrors the studio's ``_soul_name`` patterns).

    From ``agents.soul``, published by the engine's catalog sync. It used to
    open ``<agent home>/<role>/workspace/SOUL.md`` — on a pod that has no
    agent home, and at a path (``~/.iobot``) the engine stopped writing when
    the runtime state directory became ``~/.iobot``, so on a machine running
    both it read a stale file and on a pod it read nothing.
    """
    head = (_db_registry.get(role) or {}).get("soul") or ""
    if not head:
        return None
    head = head[:2000]
    m = re.search(r"^#+\s*SOUL\s*[—–-]+\s*([^,\n]+)", head, re.M)
    if m:
        return m.group(1).strip()[:40]
    m = re.search(r"[Yy]ou are (?:the\s+)?\*\*([^*]+)\*\*", head)
    if m:
        name = m.group(1).strip().split(",")[0].split("—")[0].strip()
        return (name.title() if name.isupper() else name)[:40]
    m = re.search(r"[Yy]ou are (?:the\s+)?([A-Z][\w-]+)", head)
    if m:
        return m.group(1)[:40]
    return None


def _role_label(role: str) -> str | None:
    """Business-friendly role label from studio_agent_display, if present."""
    try:
        from app import studio_display
        row = studio_display.get_display(role)
        if row and row.get("role_label"):
            return str(row["role_label"])[:60]
    except Exception:
        logger.debug("role_label lookup failed for %s", role)
    return None


def _initials(name: str) -> str:
    """Two-letter shortcut from a display name: 'Nora' -> 'NO',
    'Pharma Intel' -> 'PI'."""
    words = [w for w in re.split(r"[\s_\-]+", name.strip()) if w]
    if len(words) >= 2:
        return (words[0][0] + words[1][0]).upper()
    if words:
        return words[0][:2].upper()
    return "??"


def _palette_color(role: str) -> str:
    return _PALETTE[zlib.crc32(role.encode("utf-8")) % len(_PALETTE)]


def _enrich(role: str, row: dict | None) -> dict:
    """Resolve the friendly display record for a role (see module docstring)."""
    db_name = (row or {}).get("name")
    db_title = (row or {}).get("title")
    db_avatar = (row or {}).get("avatar")
    db_color = (row or {}).get("color")

    # Name: DB value unless it is the verbatim role slug; then SOUL; then Title Case.
    name = db_name if db_name and db_name != role else None
    if not name:
        name = _soul_display_name(role) or role.replace("_", " ").title()

    # Title / role label: studio display copy wins; degenerate DB titles drop.
    title = _role_label(role) or (db_title if db_title and db_title != role else None) \
        or role.replace("_", " ").title()

    # Avatar: keep an authored one; regenerate the degenerate role[:2] form.
    avatar = db_avatar
    if not avatar or avatar == role[:2].upper():
        avatar = _initials(name)

    color = db_color if db_color not in _GREY_FALLBACKS else _palette_color(role)

    return {"role": role, "name": name, "title": title, "avatar": avatar, "color": color}


def get_agent(role: str) -> dict:
    """Get display info for a role.

    Fast path: serve from cache (TTL 1 hour).
    Cache miss: query DB for this specific role.
    Final fallback: auto-generate from role name.
    """
    # Refresh full cache if TTL expired
    now = time.time()
    if not _db_registry or (now - _cache_loaded_at) > _CACHE_TTL:
        _load_all()
        _known_missing.clear()   # re-check absentees once per TTL window
        _enriched.clear()

    if role in _enriched:
        return _enriched[role].copy()

    # DB row (cache hit, else single lookup once per TTL window)
    row = _db_registry.get(role)
    if row is None and role not in _known_missing:
        row = _lookup_single(role)
        if row is None:
            _known_missing.add(role)

    agent = _enrich(role, row)
    _enriched[role] = agent
    return agent.copy()


# Backwards compatibility alias
AGENT_REGISTRY = {}
