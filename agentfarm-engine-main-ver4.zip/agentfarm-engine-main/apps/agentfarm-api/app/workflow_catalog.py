"""The workflow catalog the Studio LISTS — the engine's packs, add-only rows.

One Truth (``docs/one-truth-content-model.md`` s4.3): the base list and
detail come from the ENGINE (``GET /api/catalog/workflows[/name]``, via
``app.engine_catalog``), each item stamped with the distribution / version /
commit that is running. ``studio_workflow_defs`` rows ADD only: a row is
shown when the engine has no workflow of that name — a Studio-authored
definition no pack provides yet — and is marked ``unpromoted``. A row whose
name the engine also ships is NOT shown (pack wins); the ``.materialized`` /
``shadows_pack`` override idea is gone from the read path.

An unreachable engine is the rail's 502 — never an empty catalog.
"""
from __future__ import annotations

import logging

from app import engine_catalog, workflow_defs

logger = logging.getLogger(__name__)


def _scoped_packs(workspace_code: str):
    """The workspace's pack scoping row, or ``None`` when unscoped."""
    from app import workspace_settings
    return workspace_settings.packs_for(workspace_code)


def _pack_in_scope(pack: str, scoped) -> bool:
    """The agents catalog's `include_packs` rule, applied to a workflow.

    Found the same way the agents leak was (2026-08-17): by LOOKING at the
    page. `ainf2` - include_packs='ainf2', one agent, no workflows - listed
    ELEVEN workflows from pharma_intel_sol, pharma_comm_sol, agentfarm-pharma
    and v2check, naming agents its own catalog does not show. The engine's
    list is every installed pack's workflows (the `workspace` parameter does
    not filter by pack), and the include row was honoured one catalog over
    and ignored here.

    Same semantics as `studio._role_visible`, minus the platform tier: there
    is no platform-shared WORKFLOW list, and the agents section already
    records why - core's generic workflow roles "belong to core's own
    workflows, not to every tenant's catalog". So under a strict include
    list, core's workflows are out unless named.

    Tenant-AUTHORED rows never pass through here: `_tenant_rows` content has
    no pack and belongs to whoever wrote it, the same reason a Studio-built
    agent passes `_role_visible` without a pack to be in scope by.
    """
    if scoped is None:
        return True                     # no scoping row - unscoped workspace
    if pack and pack in scoped["exclude"]:
        return False
    if scoped["include"]:
        return bool(pack) and pack in scoped["include"]
    return True                         # empty include - the documented widening


def _tenant_rows(workspace_code: str, engine_names: set[str]) -> list[dict]:
    """The workspace's own definitions the engine has NO workflow for.

    Only Studio-AUTHORED rows (``source='studio'``) add: a ``pack-sync`` row
    is a mirror of pack content, and the engine's answer supersedes it — a
    mirror of a workflow the pack no longer ships would otherwise claim a
    workflow nothing can run.
    """
    try:
        rows = workflow_defs.list_defs(workspace_code)
    except Exception as e:  # noqa: BLE001 — the tenant table is additive
        logger.warning("studio_workflow_defs unavailable: %s", e)
        return []
    return [r for r in rows
            if r["code"] not in engine_names and r.get("source") == "studio"]


def _from_engine(name: str, meta: dict, detail: dict) -> dict:
    files = {k: v for k, v in (detail.get("files") or {}).items()
             if isinstance(v, str) and k != "workflow.yaml"}
    return {
        "name": name,
        "yaml": detail.get("yaml") or files.get("workflow.yaml", ""),
        "files": files,
        "source": engine_catalog.SOURCE,
        "source_path": f"engine:{meta.get('pack') or detail.get('pack') or ''}/{name}",
        "solution": meta.get("solution") or detail.get("solution") or "",
        "pack": meta.get("pack") or detail.get("pack") or "",
        "stamp": meta.get("stamp") or detail.get("stamp") or "",
        "unpromoted": False,
        "synced_at": None,
        "updated_at": None,
    }


def _from_row(row: dict) -> dict:
    return {
        "name": row["code"],
        "yaml": row["yaml"],
        "files": workflow_defs.def_files(row),
        "source": "studio",
        "source_path": f"db:studio_workflow_defs/{row['code']}",
        "solution": row.get("solution") or "",
        "pack": "",
        "stamp": None,
        "unpromoted": True,
        "synced_at": row.get("synced_at"),
        "updated_at": row.get("updated_at"),
    }


def list_workflows(workspace_code: str) -> list[dict]:
    """Every workflow this workspace shows, engine first, ordered by name.

    Each item: ``{name, yaml, files, source, source_path, solution, pack,
    stamp, unpromoted, synced_at, updated_at}``. Engine bodies come from the
    per-workflow detail (cached by stamp).
    """
    all_listed = engine_catalog.workflows(workspace_code)
    # Scope BEFORE the detail fan-out: an out-of-scope workflow must not show,
    # so its detail call would be paid for a row that is then thrown away.
    scoped = _scoped_packs(workspace_code)
    listed = {n: m for n, m in all_listed.items()
              if _pack_in_scope(m.get("pack") or "", scoped)}
    # One detail call per workflow is inherent — the list carries no YAML and
    # a summary needs it — but they must not be SERIAL. Eleven in sequence
    # were most of this endpoint's wall clock, and it is on the path of every
    # agent page too ("used in N workflows"). Same fan-out the skill
    # inventory already uses.
    details = engine_catalog.workflow_detail_many(listed, workspace_code)
    out: list[dict] = []
    for name, meta in listed.items():
        detail = details.get(name)
        if detail is None:
            continue         # listed a moment ago, gone now — a pack changed
        out.append(_from_engine(name, meta, detail))
    # The FULL engine name set, not the scoped one: a studio row shadowed by
    # an out-of-scope pack workflow must not reappear as "unpromoted" just
    # because the pack copy is hidden. `list_workflow_names` does the same,
    # and the count test only holds while both do.
    for row in _tenant_rows(workspace_code, set(all_listed)):
        out.append(_from_row(row))
    out.sort(key=lambda w: w["name"])
    return out


def list_workflow_names(workspace_code: str) -> list[str]:
    """Just the names — no YAML, no per-workflow detail call.

    The sidebar wants a NUMBER, and `list_workflows` pays one engine detail
    call per workflow to build summaries nobody is going to render. Same two
    sources and the same add-only rule as `list_workflows`, which is what
    `test_the_count_and_the_list_agree` pins: the moment these two disagree
    the badge is lying about the page it links to.
    """
    listed = engine_catalog.workflows(workspace_code)
    scoped = _scoped_packs(workspace_code)
    names = {n for n, m in listed.items()
             if _pack_in_scope(m.get("pack") or "", scoped)}
    # `_tenant_rows` is still handed EVERY engine name: a studio row shadowed
    # by an out-of-scope pack workflow must not reappear as "unpromoted" just
    # because the pack copy is hidden here.
    names.update(r["code"] for r in _tenant_rows(workspace_code, set(listed)))
    return sorted(names)


def get_workflow(name: str, workspace_code: str) -> dict | None:
    """One workflow — the engine's, else the tenant's own unpromoted row,
    else ``None``."""
    detail = engine_catalog.workflow_detail(name, workspace_code)
    if detail is not None:
        return _from_engine(name, {}, detail)
    row = workflow_defs.get_def(name, workspace_code)
    if row and row.get("source") == "studio":
        return _from_row(row)
    return None


def workflow_team(name: str, workspace_code: str) -> list[dict] | None:
    """The ``team:`` roster of the workflow as this workspace resolves it —
    ``[{role}]`` — or ``None`` when neither tier defines it (the caller
    falls back to the run's own steps). Same rule as the catalog: engine
    first, a tenant row only when the engine has no such workflow.
    """
    item = get_workflow(name, workspace_code)
    if item is None:
        return None
    data = workflow_defs.parse_yaml_tolerant(item["yaml"] or "")
    return [{"role": m.get("role")} for m in (data.get("team") or [])
            if isinstance(m, dict) and m.get("role")]
