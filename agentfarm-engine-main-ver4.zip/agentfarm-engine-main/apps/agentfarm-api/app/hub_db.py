"""The business-data hub connection — pooled, and in ONE place.

Deliberately not in ``app/database.py``: that module is the ENGINE database
and its contract is that engine data is never read from the hub and hub data
never from it. Two databases, two modules; what they share is the pooling
technique, not a connection.

WHY THIS MODULE EXISTS AT ALL. `_hub()` was copied into five routers
(`hil_queue`, `barrier_insights`, `playbook_templates`, `signals`,
`source_data`) — four of them byte-identical — and every copy opened a FRESH
connection per request and closed it. Against RDS from a laptop a connect is
~1.8s and a query ~0.25s, so a hub read was about 90% connect. The sidebar's
two hub badges cost two connects; `/api/studio/counts` collapsed them to one
and the connect was still most of what remained.

Five copies is also how a fix reaches one caller and not the other four,
which is the shape this repo has been bitten by before. They now delegate
here, so pooling — and anything after it — lands everywhere at once.
"""
from __future__ import annotations

import os
import re
import threading
from contextlib import contextmanager
from typing import Any

from fastapi import HTTPException

DEFAULT_HUB_SCHEMA = "savant_data_hub_v2"

#: The schema name is interpolated into `SET search_path` / the connect
#: options, neither of which takes a bind parameter — so it is validated,
#: never escaped.
_SCHEMA_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

#: (url, schema) -> pool. The schema is in the key because it rides the
#: CONNECT options below, so connections are not interchangeable across
#: schemas — the same reason the engine pool is keyed that way.
_POOLS: dict[tuple[str, str], Any] = {}
_POOL_LOCK = threading.Lock()


def hub_schema() -> str:
    """Hub schema resolved at REQUEST time (cutover-safe, never cached)."""
    schema = (os.getenv("BARRIER_SIGNAL_DB_SCHEMA") or DEFAULT_HUB_SCHEMA).strip()
    if not _SCHEMA_RE.match(schema):
        raise HTTPException(
            status_code=500,
            detail=f"BARRIER_SIGNAL_DB_SCHEMA is not a valid identifier: {schema!r}")
    return schema


def _hub_url() -> str:
    url = os.getenv("BARRIER_SIGNAL_DB_URL", "").strip()
    if not url or not url.startswith(("postgresql://", "postgres://")):
        raise HTTPException(
            status_code=503,
            detail="BARRIER_SIGNAL_DB_URL is not configured (hub unavailable)")
    return url


def _pool_for(url: str, schema: str):
    import psycopg2.extras
    import psycopg2.pool

    key = (url, schema)
    pool = _POOLS.get(key)
    if pool is None:
        with _POOL_LOCK:
            pool = _POOLS.get(key)      # re-check: another thread may have won
            if pool is None:
                try:
                    pool = psycopg2.pool.ThreadedConnectionPool(
                        # Opened in the constructor, so the cost lands on
                        # whoever creates the pool rather than on each later
                        # caller one connect at a time — psycopg2 holds its
                        # own lock across a connect, so growing under load
                        # serialises requests behind it.
                        # SIX, because that is what ONE PAGE ASKS FOR. The
                        # engine pool learned this and the hub pool did not:
                        # an Operational Insights page load fans out to
                        # summary + barriers + kb + signals/summary +
                        # source-data/summary + the sidebar counts, and at
                        # minconn=2 the other four each waited for a fresh
                        # connect taken under psycopg2's own lock. Measured
                        # against RDS: eight concurrent hub calls returned in
                        # 20.5s each - all finishing at the same instant,
                        # which is the signature of serialisation - while any
                        # one of them alone took 2.5s. Opened in the
                        # CONSTRUCTOR, so the cost lands once on whoever
                        # creates the pool instead of on each later caller.
                        minconn=int(os.getenv("IOF_HUB_DB_POOL_MIN", "6")),
                        maxconn=int(os.getenv("IOF_HUB_DB_POOL_MAX", "10")),
                        dsn=url,
                        # KEEPALIVES, so the drop is prevented rather than
                        # only survived. Same names the engine pool uses, so
                        # one deployment setting tunes both.
                        keepalives=1,
                        keepalives_idle=int(os.getenv("IOF_PG_KEEPALIVE_IDLE", "30")),
                        keepalives_interval=int(os.getenv("IOF_PG_KEEPALIVE_INTERVAL", "10")),
                        keepalives_count=int(os.getenv("IOF_PG_KEEPALIVE_COUNT", "5")),
                        connect_timeout=int(os.getenv("IOF_PG_CONNECT_TIMEOUT", "10")),
                        # search_path in the handshake, not a `SET` per
                        # checkout: one fewer round trip every borrow, and
                        # the schema is already part of the pool's key.
                        options=f"-c search_path={schema}",
                        cursor_factory=psycopg2.extras.RealDictCursor,
                    )
                except Exception as e:
                    raise HTTPException(status_code=502,
                                        detail=f"hub connection failed: {e}")
                _POOLS[key] = pool
    return pool


#: When a hub connection last completed a checkout cleanly, keyed by id(con).
_LAST_OK: dict = {}


def _checkout(pool):
    """A LIVE connection from *pool*, discarding any that is not.

    THE THIRD THING THE ENGINE POOL LEARNED AND THIS ONE DID NOT. RDS drops a
    connection that has been idle, and it does not announce it: the socket
    surfaces mid-query as "server closed the connection unexpectedly". The
    engine pool has validated on checkout since its own idle-drop fix; the hub
    pool handed the dead connection straight to a request, which 500ed. That
    is what made the Operational Insights walk intermittent — a barrier trace
    would simply fail every so often, and the UI showed a page with no
    breadcrumb rather than an error.

    WINDOWED, for the same reason as the engine's: the probe costs a round
    trip (~0.25s to RDS), and paying it on every checkout would undo the
    pooling. Inside the window a peer that died is not detectable by anything
    cheaper anyway - the keepalives have not begun probing, and every cause of
    a dead pooled connection (idle timeout, failover, NAT reaping) takes
    minutes.
    """
    import time as _time

    retries = max(1, int(os.getenv("IOF_HUB_PG_CHECKOUT_RETRIES", "3")))
    probe_after = float(os.getenv("IOF_HUB_PG_PROBE_AFTER_S", "20"))
    last_err = None
    for _ in range(retries):
        con = pool.getconn()
        if getattr(con, "closed", 0):          # local flag, no round trip
            _LAST_OK.pop(id(con), None)
            pool.putconn(con, close=True)
            continue
        if _time.monotonic() - _LAST_OK.get(id(con), 0.0) < probe_after:
            return con
        try:
            # autocommit BEFORE the probe: with it off, psycopg2 opens an
            # implicit transaction for `SELECT 1` and the `con.autocommit =
            # True` below is then refused ("set_session cannot be used inside
            # a transaction"). That exact bug shipped in the engine pool and
            # broke every request on a fresh stack.
            con.autocommit = True
            with con.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        except Exception as exc:               # noqa: BLE001 - any dead socket
            last_err = exc
            _LAST_OK.pop(id(con), None)
            try:
                pool.putconn(con, close=True)
            except Exception:                  # noqa: BLE001
                pass
            continue
        _LAST_OK[id(con)] = _time.monotonic()
        return con
    if last_err is not None:
        raise last_err
    raise HTTPException(status_code=502,
                        detail="no live hub connection could be taken from the pool")


@contextmanager
def hub_cursor():
    """Read-only hub cursor. Same signature the five copies had, so a caller
    changes only where it imports from."""
    # Imported HERE, not referenced as a global: this module imports psycopg2
    # inside `_pool_for`, and the discrimination below runs in an ERROR path —
    # a name that is not bound would raise NameError inside the handler and
    # replace a real fault with a confusing one. That has happened in this
    # codebase before (the API's own 500 handler referenced `logging` and
    # `JSONResponse` as globals and failed silently).
    import psycopg2

    schema = hub_schema()
    pool = _pool_for(_hub_url(), schema)
    con = _checkout(pool)
    try:
        con.autocommit = True
        yield con.cursor()
    except HTTPException:
        # The CALLER refused the request (a 404 for an unknown barrier, a 400
        # for a bad label) after its queries ran fine — the connection is
        # healthy, and closing it made the NEXT caller pay a ~1.8s reconnect
        # for every not-found. Return it to the pool.
        pool.putconn(con)
        raise
    except Exception as exc:
        # DISCRIMINATE: a dead socket must go, a rejected STATEMENT must not.
        # This closed the connection for any error at all, including
        # `UndefinedTable` — which the Playbook pages raise on every visit,
        # because their tables live only in the retired v1 hub. Each visit
        # therefore destroyed a pooled connection, so the pool was permanently
        # cold and every later page paid the reconnect under psycopg2's lock.
        # With autocommit on there is no transaction left to abort, so a
        # connection that merely ran a bad statement is perfectly reusable.
        if isinstance(exc, (psycopg2.OperationalError, psycopg2.InterfaceError)) \
                or getattr(con, "closed", 0):
            pool.putconn(con, close=True)
        else:
            pool.putconn(con)
        raise
    except BaseException:
        # Not an Exception (a cancellation, a KeyboardInterrupt): the query
        # may be mid-flight and the connection's state is unknown.
        pool.putconn(con, close=True)
        raise
    else:
        import time as _time
        _LAST_OK[id(con)] = _time.monotonic()
        pool.putconn(con)


def reset_pools() -> None:
    """Drop every hub pool (tests, and a forced reconnect after a repoint)."""
    with _POOL_LOCK:
        pools, _POOLS_local = list(_POOLS.values()), None
        _POOLS.clear()
    for p in pools:
        try:
            p.closeall()
        except Exception:
            pass
