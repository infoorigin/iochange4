"""The Studio asks the ENGINE what content exists — never a content table.

One Truth (``docs/one-truth-content-model.md`` s4.3): the API pod has no
filesystem and no packs, and the installed pack on the ENGINE is the only
source of agents, skills and workflows. So every base-tier read here goes
over the one engine rail (``engine_routing.engine_json``) to the engine's
pack-resolved catalog (``ioagentfarm/web/catalog.py``):

    GET /api/catalog/agents            [{role, name, pack, stamp, skills, has_card}]
    GET /api/catalog/agents/{role}     {role, pack, files{rel: text}, stamp}
    GET /api/catalog/skills            [{name, source, pack, stamp}]
    GET /api/catalog/skills/{name}     {name, source, pack, files, stamp, also}
    GET /api/catalog/workflows         [{name, solution, pack, steps, stamp}]
    GET /api/catalog/workflows/{name}  {name, solution, pack, yaml, files, stamp}

Two properties, both load-bearing:

* **An unreachable engine is a 502, never an empty list.** ``engine_json``
  raises the 502 (detail names the workspace and ends with the purpose line
  below); nothing here catches it into ``[]``. A Studio showing "no agents"
  is exactly the silent failure the model exists to remove.
* **Item CONTENT is cached by its stamp.** The list endpoints carry no
  bodies, so a skill's description or an agent's SOUL costs one detail call
  each. A stamp names the distribution, version and commit the item came
  from; identical stamp = identical bytes for an installed wheel, so the
  cache key is ``(workspace, kind, name, stamp)`` and an SDK upgrade
  invalidates naturally. A ``+local`` stamp (a dirty checkout, s3.4: "a
  checkout is never cached") is never cached.

The tenant tables (``studio_agent_defs``, ``studio_skills``,
``studio_workflow_defs``) are NOT read here; ``agent_catalog`` /
``workflow_catalog`` merge them under the transitional ADD-ONLY rule.
"""
from __future__ import annotations

import logging
import threading

from fastapi import HTTPException

from app.engine_routing import engine_json

logger = logging.getLogger(__name__)

#: Finishes the 502 detail: "engine API for workspace 'x' unreachable (...) —
#: <this>". The sentence the UI shows when the engine is down.
PURPOSE = "engine unreachable — the Studio shows what the engine runs"

#: The provenance marker every base item carries.
SOURCE = "engine"

#: Bound the content cache; cleared wholesale rather than evicted — it is a
#: cache of small text files keyed by version, and a rebuild is one detail
#: call per item.
_CACHE_MAX = 4096
_content_cache: dict[tuple, dict] = {}
_lock = threading.Lock()


def reset() -> None:
    """Drop the stamp-keyed content cache (tests; a forced refresh)."""
    with _lock:
        _content_cache.clear()


def _cacheable(stamp: str | None) -> bool:
    return bool(stamp) and "+local" not in str(stamp)


def _get(path: str, workspace_code: str, params: dict | None = None,
         timeout: float = 30.0) -> dict:
    """One catalog GET. ``?workspace=`` travels so the engine can refuse a
    request naming a workspace it does not serve (409) instead of answering
    for the wrong tenant."""
    p = {"workspace": workspace_code}
    if params:
        p.update(params)
    return engine_json("GET", path, purpose=PURPOSE, timeout=timeout,
                       params=p, workspace_code=workspace_code)


def _cached_detail(kind: str, name: str, stamp: str | None,
                   workspace_code: str, fetch) -> dict:
    key = (workspace_code, kind, name, stamp)
    if _cacheable(stamp):
        with _lock:
            hit = _content_cache.get(key)
        if hit is not None:
            return hit
    body = fetch()
    if _cacheable(stamp) and body.get("stamp") == stamp:
        with _lock:
            if len(_content_cache) >= _CACHE_MAX:
                _content_cache.clear()
            _content_cache[key] = body
    return body


# ── agents ────────────────────────────────────────────────────────────

def agents(workspace_code: str) -> dict[str, dict]:
    """``role -> {role, name, pack, stamp, skills, has_card}`` from the engine."""
    body = _get("/api/catalog/agents", workspace_code)
    out: dict[str, dict] = {}
    for a in body.get("agents") or []:
        role = a.get("role")
        if not role:
            continue
        out[role] = {
            "role": role,
            "name": a.get("name") or role,
            "pack": a.get("pack") or "",
            "stamp": a.get("stamp") or "",
            "skills": [s for s in (a.get("skills") or []) if isinstance(s, str)],
            "has_card": bool(a.get("has_card")),
        }
    return out


def agent_files(role: str, workspace_code: str,
                stamp: str | None = None) -> dict | None:
    """``{role, pack, files, stamp}`` for a pack agent — ``None`` when no
    installed pack provides the role (the engine's 404)."""
    def fetch():
        return _get(f"/api/catalog/agents/{role}", workspace_code)
    try:
        return _cached_detail("agent", role, stamp, workspace_code, fetch)
    except HTTPException as exc:
        if exc.status_code == 404:
            return None
        raise


# ── skills ────────────────────────────────────────────────────────────

#: Distributions whose skills a tenant may not fork (the SDK tier): the
#: engine's own pack and the shared-skills wheel. Everything else is a
#: domain pack.
SDK_PACKS = frozenset({"ioagentfarm-core", "core", "skills", "agentfarm-skills"})


def skills(workspace_code: str) -> dict[str, dict]:
    """``name -> {name, pack, source, stamp, shared, also}`` from the engine.

    The engine lists EVERY occurrence (a pack-level source first, then each
    agent-local copy); the first wins the name here — the same order the
    engine's own detail endpoint resolves — and the rest ride ``also``.
    """
    body = _get("/api/catalog/skills", workspace_code)
    out: dict[str, dict] = {}
    for s in body.get("skills") or []:
        name = s.get("name")
        if not name:
            continue
        entry = {"source": s.get("source") or "pack", "pack": s.get("pack") or "",
                 "stamp": s.get("stamp") or ""}
        if name in out:
            out[name]["also"].append(entry)
            continue
        out[name] = {"name": name, **entry,
                     "shared": entry["pack"] in SDK_PACKS, "also": []}
    return out


def skill_files(name: str, workspace_code: str, stamp: str | None = None,
                role: str | None = None) -> dict | None:
    """``{name, source, pack, files, stamp, also}`` — ``None`` on the
    engine's 404 (no installed pack provides the skill)."""
    def fetch():
        return _get(f"/api/catalog/skills/{name}", workspace_code,
                    params={"role": role} if role else None)
    key = f"{name}@{role}" if role else name
    try:
        return _cached_detail("skill", key, stamp, workspace_code, fetch)
    except HTTPException as exc:
        if exc.status_code == 404:
            return None
        raise


def skill_md(name: str, workspace_code: str, stamp: str | None = None) -> str:
    """The SKILL.md text of a pack skill ('' when absent)."""
    d = skill_files(name, workspace_code, stamp)
    if not d:
        return ""
    return (d.get("files") or {}).get("SKILL.md") or ""


#: How many catalog detail calls may be in flight at once. The engine serves
#: these from already-resolved pack content, so the limit is about not
#: opening an unreasonable number of sockets, not about protecting it.
_FANOUT = 8


def skill_md_many(rows: dict[str, dict], workspace_code: str) -> dict[str, str]:
    """SKILL.md text for many skills at once — ``{name: text}``.

    The list endpoint carries no bodies, so the inventory needs one detail
    call PER skill, and doing them in sequence made the Skills page take
    **66 seconds** on a 43-skill workspace. Measured, not estimated: ~1s a
    call, and the page shows nothing at all until the last one lands, which
    reads as an empty catalog rather than a slow one.

    The stamp cache does not rescue this in two common cases. A COLD cache
    pays the full serial cost once per deployment; and a checkout installed
    editable stamps its items ``+local``, which is deliberately never cached
    (the bytes can change under us) - so on a developer machine EVERY
    request paid it. Here that was 21 of 30 skills.

    Concurrency is the fix that helps both, and it is safe: each call builds
    its own httpx client, and the shared cache is already lock-guarded.
    Cached entries are resolved inline and never dispatched.
    """
    from concurrent.futures import ThreadPoolExecutor

    out: dict[str, str] = {}
    pending: list[tuple[str, str | None]] = []
    for name, row in rows.items():
        stamp = row.get("stamp")
        if _cacheable(stamp):
            with _lock:
                hit = _content_cache.get((workspace_code, "skill", name, stamp))
            if hit is not None:
                out[name] = (hit.get("files") or {}).get("SKILL.md") or ""
                continue
        pending.append((name, stamp))
    if not pending:
        return out

    def one(item: tuple[str, str | None]) -> tuple[str, str]:
        name, stamp = item
        try:
            return name, skill_md(name, workspace_code, stamp)
        except HTTPException:
            # One unreadable skill must not empty the whole inventory. The
            # 502-not-empty-list rule is about the ENGINE being unreachable,
            # which the list call above has already proven it is not.
            logger.warning("skill body unavailable for %r in workspace %r",
                           name, workspace_code)
            return name, ""

    with ThreadPoolExecutor(max_workers=_FANOUT) as pool:
        for name, md in pool.map(one, pending):
            out[name] = md
    return out


# ── workflows ─────────────────────────────────────────────────────────

def workflows(workspace_code: str) -> dict[str, dict]:
    """``name -> {name, solution, pack, steps, stamp}`` from the engine."""
    body = _get("/api/catalog/workflows", workspace_code)
    out: dict[str, dict] = {}
    for w in body.get("workflows") or []:
        name = w.get("name")
        if not name:
            continue
        out[name] = {"name": name, "solution": w.get("solution") or "",
                     "pack": w.get("pack") or "", "steps": w.get("steps"),
                     "stamp": w.get("stamp") or ""}
    return out


def workflow_detail(name: str, workspace_code: str,
                    stamp: str | None = None) -> dict | None:
    """``{name, solution, pack, yaml, files, stamp}`` — ``None`` on 404."""
    def fetch():
        return _get(f"/api/catalog/workflows/{name}", workspace_code)
    try:
        return _cached_detail("workflow", name, stamp, workspace_code, fetch)
    except HTTPException as exc:
        if exc.status_code == 404:
            return None
        raise


def workflow_detail_many(rows: dict[str, dict],
                         workspace_code: str) -> dict[str, dict]:
    """Detail for many workflows at once — ``{name: detail}``, 404s omitted.

    Same shape and same reason as :func:`skill_md_many`. The list endpoint
    carries no YAML, and a workflow summary needs it (`team:`, the step
    chain, the description), so the catalog costs one detail call PER
    workflow — eleven of them, in sequence, on every render of the Workflows
    page AND on every open of an agent, which shows "used in N workflows".

    Cached entries resolve inline and are never dispatched, so a warm stamp
    cache still costs nothing; a ``+local`` stamp is deliberately never
    cached, which is exactly the case that made the serial version hurt most
    on a developer checkout.
    """
    from concurrent.futures import ThreadPoolExecutor

    out: dict[str, dict] = {}
    pending: list[tuple[str, str | None]] = []
    for name, meta in rows.items():
        stamp = meta.get("stamp")
        if _cacheable(stamp):
            with _lock:
                hit = _content_cache.get((workspace_code, "workflow", name, stamp))
            if hit is not None:
                out[name] = hit
                continue
        pending.append((name, stamp))
    if not pending:
        return out

    def one(item: tuple[str, str | None]):
        name, stamp = item
        try:
            return name, workflow_detail(name, workspace_code, stamp)
        except HTTPException:
            # One unreadable workflow must not empty the catalog — the list
            # call already proved the engine is reachable.
            logger.warning("workflow detail unavailable for %r in workspace %r",
                           name, workspace_code)
            return name, None

    with ThreadPoolExecutor(max_workers=_FANOUT) as pool:
        for name, detail in pool.map(one, pending):
            if detail is not None:
                out[name] = detail
    return out
