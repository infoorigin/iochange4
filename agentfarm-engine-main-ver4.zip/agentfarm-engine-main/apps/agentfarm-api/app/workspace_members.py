"""Workspace membership — who may see/switch to a tenant workspace.

API-owned table in the shared engine DB (``studio_`` prefix per the
``studio_skill_scripts`` convention). Keyed by ``workspace_code`` per the
tenancy keying rule (see ``app/tenancy.py``).

Enforcement model (Phase 4 of the platform plan): membership is CLOSED —
access requires either a platform-admin row anywhere or a row for this
workspace. There is no "zero members means open" case; that earlier
behaviour, and the caveat that membership was advisory until JWT signatures
were verified everywhere, are both gone. Signatures ARE verified
(``app/auth_token.py``: ``alg`` pinned, ``hmac.compare_digest``, ``exp``
checked), and ``app/authz.py`` is the single decision point.

Enforcement is reachable ONLY from a router that declares a guard. The
studio and session routers went unguarded until 2026-08 — a closed model
decides nothing where nobody asks it. ``IOF_AUTHZ_ENFORCE=0`` is the
rollback lever: identity still verified, decision logged, access allowed.
"""
from __future__ import annotations

from datetime import datetime, timezone

from app.database import get_db, placeholder, q

_TABLE_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workspace_members ("
    "  workspace_code TEXT NOT NULL,"
    "  user_email     TEXT NOT NULL,"
    "  role           TEXT NOT NULL DEFAULT 'member',"
    "  added_at       TEXT NOT NULL,"
    "  PRIMARY KEY (workspace_code, user_email)"
    ")"
)

_ensured = False


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


#: "Which workspaces does this user belong to?" is now a hot path (every
#: workspace-list call and every membership check), but the PK is
#: (workspace_code, user_email) — leading column wrong for that query.
_EMAIL_INDEX_DDL = (
    "CREATE INDEX IF NOT EXISTS ix_ws_members_user_email "
    "ON studio_workspace_members (user_email)"
)


def ensure_table(con) -> None:
    global _ensured
    if _ensured:
        return
    cur = con.cursor()
    cur.execute(_TABLE_DDL)
    try:
        cur.execute(_EMAIL_INDEX_DDL)
    except Exception:      # pragma: no cover - index is an optimisation
        pass
    try:
        con.commit()
    except Exception:
        pass
    _ensured = True


def reset_cache() -> None:
    global _ensured
    _ensured = False


def list_members(workspace_code: str) -> list[dict]:
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        cur.execute(q("SELECT workspace_code, user_email, role, added_at "
                      "FROM studio_workspace_members WHERE workspace_code=? "
                      "ORDER BY user_email"), (workspace_code,))
        return [dict(r) for r in cur.fetchall()]


def add_member(workspace_code: str, user_email: str, role: str = "member") -> dict:
    email = user_email.strip().lower()
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        upsert = (
            "INSERT INTO studio_workspace_members "
            "(workspace_code, user_email, role, added_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT (workspace_code, user_email) DO UPDATE SET role = EXCLUDED.role"
            if placeholder() == "%s" else
            "INSERT OR REPLACE INTO studio_workspace_members "
            "(workspace_code, user_email, role, added_at) VALUES (?, ?, ?, ?)"
        )
        cur.execute(q(upsert), (workspace_code, email, role, _now()))
        try:
            con.commit()
        except Exception:
            pass
    return {"workspace_code": workspace_code, "user_email": email, "role": role}


def remove_member(workspace_code: str, user_email: str) -> bool:
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        cur.execute(q("DELETE FROM studio_workspace_members "
                      "WHERE workspace_code=? AND user_email=?"),
                    (workspace_code, user_email.strip().lower()))
        deleted = cur.rowcount > 0
        try:
            con.commit()
        except Exception:
            pass
        return deleted


#: The platform-wide role. A user holding it on ANY workspace row reaches
#: every workspace — it is a platform grant expressed through the members
#: table, not a per-workspace capability.
ADMIN_ROLE = "admin"


def is_platform_admin(user_email: str | None) -> bool:
    """True when *user_email* holds the admin role anywhere."""
    email = (user_email or "").strip().lower()
    if not email:
        return False
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        cur.execute(q("SELECT 1 FROM studio_workspace_members "
                      "WHERE user_email=? AND role=? LIMIT 1"),
                    (email, ADMIN_ROLE))
        return cur.fetchone() is not None


def is_member(workspace_code: str, user_email: str | None) -> bool:
    """True when *user_email* has a row for *workspace_code*. No 'open' case."""
    email = (user_email or "").strip().lower()
    if not email or not workspace_code:
        return False
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        cur.execute(q("SELECT 1 FROM studio_workspace_members "
                      "WHERE workspace_code=? AND user_email=? LIMIT 1"),
                    (workspace_code, email))
        return cur.fetchone() is not None


def workspaces_for(user_email: str | None) -> list[str]:
    """Workspace codes *user_email* belongs to (does NOT expand admin)."""
    email = (user_email or "").strip().lower()
    if not email:
        return []
    with get_db() as con:
        ensure_table(con)
        cur = con.cursor()
        cur.execute(q("SELECT workspace_code FROM studio_workspace_members "
                      "WHERE user_email=? ORDER BY workspace_code"), (email,))
        return [r["workspace_code"] if hasattr(r, "keys") else r[0]
                for r in cur.fetchall()]


def is_member_or_open(workspace_code: str, user_email: str | None) -> bool:
    """DEPRECATED — open-by-default is exactly what closed membership removes.

    Kept only so an unnoticed caller fails loudly in review rather than
    silently granting access; it now delegates to the closed check. Had zero
    callers when membership enforcement landed.
    """
    return is_member(workspace_code, user_email)
