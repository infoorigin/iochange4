"""Authorization — who may reach which workspace.

The model, deliberately simple and CLOSED:

    is_platform_admin(email)  := an 'admin' row anywhere in studio_workspace_members
    can_access(email, ws)     := is_platform_admin(email) OR a row for (ws, email)

No row, no access. The previous ``is_member_or_open`` treated a workspace with
zero members as public, which is the property this replaces — but it also means
an upgrade could lock everyone out, so :func:`ensure_bootstrap_admins` seeds the
configured admin accounts at startup.

This module holds the app's first FastAPI dependencies. They follow the shape
already sketched in ``app/tenancy.py`` (plain functions taking ``Header(None)``,
delegating to pure helpers that unit-test without FastAPI).

TRUST BOUNDARY: everything here consumes a VERIFIED ``Identity`` from
``app.auth_token``. Authorization over self-asserted identity is decoration.
"""

from __future__ import annotations

import logging

from fastapi import Header, HTTPException

from app import workspace_members
from app.auth_token import Identity, identity_from_header
from app.config import get_settings

logger = logging.getLogger(__name__)


def can_access(user_email: str | None, workspace_code: str) -> bool:
    """Closed membership + the platform-wide admin grant."""
    if workspace_members.is_platform_admin(user_email):
        return True
    return workspace_members.is_member(workspace_code, user_email)


def visible_workspace_codes(user_email: str | None) -> list[str] | None:
    """Codes the caller may see, or ``None`` meaning 'all' (admin).

    ``None`` rather than a materialised list so the caller can skip filtering
    entirely for admins instead of enumerating every workspace.
    """
    if workspace_members.is_platform_admin(user_email):
        return None
    return workspace_members.workspaces_for(user_email)


# ── FastAPI dependencies ──────────────────────────────────────────

def require_identity(authorization: str | None = Header(None)) -> Identity:
    """A verified caller. 401 otherwise (or a dev identity under IOF_AUTH_DEV)."""
    return identity_from_header(authorization)


def require_member(
    authorization: str | None = Header(None),
    x_workspace_id: str | None = Header(None),
) -> Identity:
    """Verified AND allowed to reach the workspace the request selected.

    The workspace comes from ``X-Workspace-Id`` resolved exactly as the tenant
    middleware does, so authorization and scoping can never disagree about
    which tenant a request is for. When the header is absent, the middleware's
    own resolution is reused — for an SSE request the workspace arrived via
    the ``workspace_id`` query parameter, a channel this Header dependency
    cannot see; re-resolving from the (absent) header here would refuse every
    stream the middleware just admitted. An unknown or malformed value still
    errors in ``resolve_workspace`` — there is no fallback workspace.
    """
    from app import tenancy, workspace_context

    identity = identity_from_header(authorization)
    named = (x_workspace_id or "").strip()
    if not named:
        ambient = workspace_context.maybe_active_code()
        if ambient:
            code = ambient
        else:
            code = tenancy.resolve_workspace(named)["code"]  # raises the 400
    else:
        code = tenancy.resolve_workspace(named)["code"]

    if not get_settings().authz_enforce:
        # Rollback lever: identity is still verified, the decision is logged,
        # but access is not blocked. Never a deploy mode.
        if not can_access(identity.email, code):
            logger.warning(
                "authz(disabled): %s would be DENIED workspace %r",
                identity.email, code)
        return identity

    if not can_access(identity.email, code):
        logger.info("authz: denied %s -> workspace %r", identity.email, code)
        raise HTTPException(
            status_code=403,
            detail=f"You do not have access to workspace '{code}'")
    return identity


def require_platform_admin(authorization: str | None = Header(None)) -> Identity:
    """Verified AND holding the admin role. Guards membership + the admin module."""
    identity = identity_from_header(authorization)
    if not get_settings().authz_enforce:
        if not workspace_members.is_platform_admin(identity.email):
            logger.warning("authz(disabled): %s would be DENIED admin",
                           identity.email)
        return identity
    if not workspace_members.is_platform_admin(identity.email):
        logger.info("authz: denied admin to %s", identity.email)
        raise HTTPException(status_code=403, detail="Administrator access required")
    return identity


# ── Bootstrap ─────────────────────────────────────────────────────

def ensure_bootstrap_admins(con) -> None:
    """Seed ``IOF_BOOTSTRAP_ADMIN`` emails as platform admins, idempotently.

    Mirrors ``workspace_settings.ensure_demo_workspaces``. Without this, a
    deployment that switches to closed membership has no one who can grant
    membership to anyone — the classic bootstrap deadlock.

    The rows are attached to the ``default`` workspace purely as a home for
    the grant; by the admin rule they confer access to every workspace.
    """
    settings = get_settings()
    if not settings.bootstrap_admins:
        logger.info(
            "no IOF_BOOTSTRAP_ADMIN configured — closed membership will admit "
            "only explicitly added members")
        return
    workspace_members.ensure_table(con)
    cur = con.cursor()
    from app.database import placeholder, q
    # A membership row on the PLATFORM TIER = platform admin. The tier is
    # not a workspace — nothing resolves to it — it is simply the durable
    # place a global grant lives.
    from ioagentfarm.engine.workspaces import PLATFORM_TIER
    for email in settings.bootstrap_admins:
        cur.execute(q("SELECT role FROM studio_workspace_members "
                      "WHERE workspace_code=? AND user_email=?"),
                    (PLATFORM_TIER, email))
        row = cur.fetchone()
        if row is not None:
            continue
        cur.execute(
            q("INSERT INTO studio_workspace_members "
              "(workspace_code, user_email, role, added_at) VALUES (?, ?, ?, ?)"),
            (PLATFORM_TIER, email, workspace_members.ADMIN_ROLE,
             workspace_members._now()))
        logger.info("seeded bootstrap admin %s", email)
    if placeholder() != "%s":
        con.commit()


def ensure_workspace_seed_member(con, workspace_code: str, email: str) -> None:
    """Give *workspace_code* a starting member so it is never a dead tenant."""
    if not email:
        return
    workspace_members.ensure_table(con)
    from app.database import placeholder, q
    cur = con.cursor()
    cur.execute(q("SELECT 1 FROM studio_workspace_members "
                  "WHERE workspace_code=? AND user_email=?"),
                (workspace_code, email.strip().lower()))
    if cur.fetchone() is not None:
        return
    cur.execute(
        q("INSERT INTO studio_workspace_members "
          "(workspace_code, user_email, role, added_at) VALUES (?, ?, ?, ?)"),
        (workspace_code, email.strip().lower(), "member", workspace_members._now()))
    if placeholder() != "%s":
        con.commit()
