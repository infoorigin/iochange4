# ioagentfarm-api

FastAPI backend for the ioagentfarm Teams-like chat UI. Reads from ioagentfarm's database, drives workflow execution via CLI subprocess calls, streams agent output in real-time via SSE, and hosts portable registries for agent skills and CLI tools.

## Architecture

```
React UI
    │
    ▼
ioagentfarm-api (this project)
    │  FastAPI — REST + SSE
    │
    ├── Workflow mode (reads runs, steps, messages)
    │     Drives pipeline via ioagentfarm CLI subprocess
    │
    ├── Session mode (reads agentfarm_sessions, session_events, messages)
    │     Read/query layer for interactive sessions (lifecycle in ioagentfarm)
    │
    ├── Product catalog (reads product_brands, product_plays, product_missions)
    │
    ├──► ioagentfarm CLI (subprocess)
    │       start-run, next-step, run-step, step-complete
    │
    ├──► Shared Database (SQLite or PostgreSQL)
    │       iof schema — all tables shared with ioagentfarm
    │
    ├──► SkillHub Module (/api/skills)
    │       Agent skill registry — SKILL.md files + ZIP bundles in S3
    │
    └──► CLI Hub Module (/api/cli-tools)
            Agent CLI tool registry — metadata for pip-installable CLIs
```

The core API is a **read-heavy UI layer**. The SkillHub and CLI Hub modules are **independent, portable packages** that can be copied to any FastAPI project.

## Quick start

```bash
# Setup
python -m venv .venv
.venv\Scripts\pip install -e .

# Configure (copy and edit)
cp env.example .env

# Run
uvicorn app.main:app --reload --port 8000
```

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `IOF_DATABASE_URL` | *(required — no fallback)* | Engine DB URL (must match ioagentfarm's; resolved at request time, 503 when unset) |
| `IOF_ROOT` | `.iof` | State directory (shared with ioagentfarm) |
| `IOF_BIN` | `ioagentfarm` | Path to ioagentfarm CLI binary |
| `IOF_AGENTFARM_DIR` | `../io-agentfarm` | Path to the engine repo (pack workflow *sync import* only — never a display source) |
| `IOF_UI_CORS` | `*` | Comma-separated CORS origins |
| `IOF_UI_SSE_POLL` | `0.5` | SSE poll interval in seconds |
| `IOF_S3_BUCKET` | _(none)_ | S3 bucket name for file operations and SkillHub storage |
| `IOF_S3_PREFIX` | _(none)_ | Default S3 key prefix |
| `IOF_SKILLS_S3_PREFIX` | `skills` | S3 prefix for SkillHub files |
| `IOF_SKILLS_EMBEDDING_MODEL` | `BAAI/bge-small-en-v1.5` | Embedding model for skill/CLI search |
| `IOF_AUTH_JWT_SECRET` | `change-me` | Secret used to sign JWTs |
| `IOF_AUTH_JWT_HOURS` | `12` | JWT validity in hours |
| `IOF_AUTH_FRONTEND_URL` | `http://localhost:5173` | Frontend URL used in SSO callback redirect |
| `CLIENT_ID` | _(none)_ | Microsoft Entra app client ID |
| `CLIENT_SECRET` | _(none)_ | Microsoft Entra app client secret |
| `TENANT_ID` | _(none)_ | Microsoft Entra tenant ID |
| `SCOPES` | `openid,profile,email` | Comma-separated SSO scopes |
| `REDIRECT_URI` | _(none)_ | Redirect URI for auth code callback |
| `AWS_ACCESS_KEY_ID` | _(none)_ | AWS access key (if not set, uses default profile/IAM role) |
| `AWS_SECRET_ACCESS_KEY` | _(none)_ | AWS secret key |
| `AWS_DEFAULT_REGION` | `us-east-1` | AWS region |

Both this project and ioagentfarm **must point to the same database** for real-time streaming to work. PostgreSQL tables live in the `iof` schema — the app sets `search_path` automatically.

## API endpoints

### Health

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/agents` | Agent registry (names, colors, avatars) |

### Workspaces

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/workspaces` | List workspaces with run/workflow counts |
| GET | `/api/workspaces/{id}` | Workspace detail with workflows and recent runs |
| GET | `/api/workspaces/{id}/workflows` | Workflows used in a workspace |
| GET | `/api/workspaces/{id}/sessions` | All sessions for a workspace |

### Workflows

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/workflows` | List workflows (engine DB only — `studio_workflow_defs` + `iof.workflows` metadata) |
| POST | `/api/studio/workflows/sync` | One-time import of installed pack workflows + `.iof` overrides into the DB store |
| DELETE | `/api/studio/workflows/defs/{code}` | Prune a workflow definition (deployment curation) |
| GET | `/api/workflows/{code}` | Workflow detail with step graph and team roster |

### Sessions (runs)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/workflows/{wf}/sessions` | Start a new session (`{goal, project_dir}`) |
| GET | `/api/workflows/{wf}/sessions` | List sessions for a workflow |
| GET | `/api/workflows/{wf}/sessions/{id}` | Session detail (steps + team roster) |
| GET | `/api/workflows/{wf}/sessions/{id}/status` | Lightweight run status polling |
| GET | `/api/workflows/{wf}/sessions/{id}/steps` | Step progress |
| GET | `/api/workflows/{wf}/sessions/{id}/team` | Team roster with active/idle status |

### Messages (real-time streaming)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/workflows/{wf}/sessions/{id}/messages` | Poll messages (`?after_id=N`) |
| GET | `/api/workflows/{wf}/sessions/{id}/messages/stream` | SSE stream (real-time) |

### Agentfarm Sessions (interactive session mode)

Read APIs for the interactive session mode (agentfarm_sessions, agentfarm_session_events tables). Session lifecycle (create, intel, dialogue, submit, challenge, complete) is handled by the session engine in ioagentfarm.

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/agentfarm_sessions` | List sessions (`?brand=&mission=&user_name=&conference_day=`) |
| GET | `/api/agentfarm_sessions/{session_id}` | Full session detail (scores, composition, signals) |
| GET | `/api/agentfarm_sessions/{session_id}/events` | Execution trace (`?from_seq=N` for polling) |
| GET | `/api/agentfarm_sessions/{session_id}/messages` | Conversation log (`?after_id=N` for polling) |
| GET | `/api/agentfarm_sessions/{session_id}/messages/stream` | SSE stream (real-time) |
| GET | `/api/agentfarm_sessions/leaderboard/grand` | Best score per user across all brands |
| GET | `/api/agentfarm_sessions/leaderboard/brand/{brand_slug}` | Per-brand leaderboard |
| GET | `/api/agentfarm_sessions/leaderboard/mission/{mission_name}` | Per-mission leaderboard |
| GET | `/api/agentfarm_sessions/stats` | Aggregate stats for conference dashboard |

### Product Catalog (brands, plays, missions)

Read from `product_brands`, `product_plays`, `product_missions` tables. Synced from YAML via `ioagentfarm sync-savants`.

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/product_brands` | List all brands |
| GET | `/api/product_brands/{brand_slug}` | Brand detail with config |
| GET | `/api/product_brands/{brand_slug}/plays` | Plays with signal/barrier mappings |
| GET | `/api/product_brands/{brand_slug}/missions` | Missions with entity scope and scoring |
| GET | `/api/product_plays/{play_id}` | Single play detail |
| GET | `/api/product_missions/{brand_slug}/{mission_name}` | Single mission detail |

### S3 file operations

| Method | Path | Description |
|--------|------|-------------|
| GET | `/s3/list` | List S3 files (`?prefix=...&max_keys=1000`) |
| POST | `/s3/upload` | Upload file (multipart, `?key=...`) |
| DELETE | `/s3/delete` | Delete a file (`?key=...`) |
| DELETE | `/s3/delete-by-prefix` | Delete all files under a prefix |
| GET | `/s3/generate-url` | Generate a presigned URL |
| POST | `/s3/move` | Move file within S3 |
| GET | `/s3/download` | Download file from S3 |

### SkillHub — Agent Skills Registry (`/api/skills`)

Portable module for managing agent skill documents (SKILL.md with YAML frontmatter). Supports single files and multi-file ZIP bundles stored in S3.

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/skills` | Create skill (multipart: SKILL.md or ZIP bundle) |
| GET | `/api/skills` | Plain list with filters; cursor pagination (`?cursor=`) |
| GET | `/api/skills/search` | Semantic search (`?q=` required); offset pagination |
| GET | `/api/skills/{slug}` | Skill detail (301-redirects renamed slugs) |
| PATCH | `/api/skills/{slug}` | Update metadata (status, tags, description, target_roles) |
| DELETE | `/api/skills/{slug}` | Soft-delete |
| POST | `/api/skills/{slug}/undelete` | Restore a soft-deleted skill |
| GET | `/api/skills/{slug}/versions` | List versions with tags |
| GET | `/api/skills/{slug}/versions/{ver}` | Version detail |
| POST | `/api/skills/{slug}/versions` | Publish new version |
| GET | `/api/skills/{slug}/versions/{ver}/files` | List files in bundle |
| GET | `/api/skills/{slug}/files/{ver}/{path}` | Download individual file |
| GET | `/api/skills/{slug}/download` | Download skill (SKILL.md or ZIP) |
| GET | `/api/skills/{slug}/verify` | Hash integrity check |
| PUT | `/api/skills/{slug}/tags/{tag}` | Set version tag (stable, beta, etc.) |
| DELETE | `/api/skills/{slug}/tags/{tag}` | Remove version tag |
| POST | `/api/skills/{slug}/star?user_id=` | Star a skill |
| DELETE | `/api/skills/{slug}/star?user_id=` | Unstar |
| GET | `/api/skills/{slug}/comments` | List comments |
| POST | `/api/skills/{slug}/comments` | Add comment |
| DELETE | `/api/skills/{slug}/comments/{id}` | Delete own comment |
| POST | `/api/skills/{slug}/report` | Report (auto-hides at 3 reports) |
| POST | `/api/skills/{slug}/rename` | Rename with redirect alias |
| GET | `/api/skills/{slug}/duplicates` | Find duplicates (embedding + name) |
| POST | `/api/skills/{slug}/merge` | Merge into target skill |
| GET | `/api/skills/{slug}/scan` | Security scan result |
| POST | `/api/skills/{slug}/rescan` | Re-run security scanner |

List and search both return `{"items": [...], "next_cursor": str | null}`. Cursor on `/api/skills` is opaque (decode rejected with 400). Filters (`tags`, `role`, `status`, `workspace_id`) work on both endpoints.

**Security features:** YAML safe_load only, SHA-256 integrity hashing, no-binary enforcement, 50MB archive limit, built-in scanner (8 rules: exec calls, shell commands, obfuscated content, credentials, undeclared network access), content deduplication, audit trail.

### CLI Hub — Agent CLI Tools Registry (`/api/cli-tools`)

Portable module for managing agent-native CLI tool registrations (inspired by CLI-Anything). Metadata-only registry — CLI tools are pip-installed from git repos, not uploaded.

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/cli-tools` | Register CLI tool (JSON body) |
| GET | `/api/cli-tools` | List/search (`?q=`, `?category=`) |
| GET | `/api/cli-tools/{slug}` | Tool detail (follows redirects) |
| PATCH | `/api/cli-tools/{slug}` | Update metadata |
| DELETE | `/api/cli-tools/{slug}` | Soft-delete |
| GET | `/api/cli-tools/{slug}/versions` | List versions |
| GET | `/api/cli-tools/{slug}/versions/{ver}` | Version detail |
| POST | `/api/cli-tools/{slug}/versions` | Publish new version |
| GET | `/api/cli-tools/{slug}/install-info` | Lightweight: install_cmd + entry_point |
| GET | `/api/cli-tools/catalog.txt` | Plain text catalog for agent discovery |
| PUT | `/api/cli-tools/{slug}/tags/{tag}` | Set version tag |
| DELETE | `/api/cli-tools/{slug}/tags/{tag}` | Remove version tag |
| POST | `/api/cli-tools/{slug}/star` | Star |
| DELETE | `/api/cli-tools/{slug}/star` | Unstar |
| GET | `/api/cli-tools/{slug}/comments` | List comments |
| POST | `/api/cli-tools/{slug}/comments` | Add comment |
| DELETE | `/api/cli-tools/{slug}/comments/{id}` | Delete own comment |
| POST | `/api/cli-tools/{slug}/report` | Report (auto-hides at 3) |
| POST | `/api/cli-tools/{slug}/rename` | Rename with redirect |
| GET | `/api/cli-tools/{slug}/duplicates` | Find duplicates |
| POST | `/api/cli-tools/{slug}/merge` | Merge into target |
| GET | `/api/cli-tools/{slug}/scan` | Security scan result |
| POST | `/api/cli-tools/{slug}/rescan` | Re-run scanner |

**Security features:** Install command validation (pip only, no shell metacharacters), URL safety checks (HTTPS only, no IP addresses, no localhost), path traversal detection, unknown registry warnings, audit trail.

**Agent discovery example:**
```bash
# Plain text catalog
curl https://your-host/api/cli-tools/catalog.txt

# Quick install info
curl https://your-host/api/cli-tools/gimp/install-info
# → {"install_cmd": "pip install git+...", "entry_point": "cli-anything-gimp", ...}
```

### Auth

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/login` | Email/password login (validated from `user` + `user_password` tables) |
| GET | `/api/auth/sso/login` | Redirect to Microsoft Entra authorize URL |
| GET | `/api/auth/sso/callback` | Exchange auth code via MSAL and redirect with JWT |

## SSE event contracts

### Workflow mode (`/api/workflows/{wf}/sessions/{id}/messages/stream`)

| Event | Description | Payload |
|-------|-------------|---------|
| `stream_start` | First event — contract description | `{run_id, workflow, event_types, lifecycle}` |
| `step_update` | Step status changed | `{step_key, status, agent}` |
| `agent_start` | Agent began speaking | `{step_key, agent}` |
| `message` | Agent output line | `{id, step_key, content, timestamp, agent}` |
| `agent_end` | Agent finished speaking | `{step_key, agent}` |
| `session_end` | Run completed | `{run_id, status}` |

**Frontend lifecycle per step:**
```
step_update(running) → agent_start → message* → agent_end → step_update(done)
```

### Session mode (`/api/agentfarm_sessions/{session_id}/messages/stream`)

| Event | Description | Payload |
|-------|-------------|---------|
| `stream_start` | First event — contract and resume positions | `{session_id, after_id, from_seq, event_types}` |
| `phase_change` | Session phase transition | `{seq, phase, event_type, content}` |
| `agent_start` | Agent began speaking | `{role, agent}` |
| `message` | Output line | `{id, role, content, source, timestamp, agent}` |
| `agent_end` | Agent finished speaking | `{role, agent, content}` |
| `event` | Execution trace event | `{seq, phase, event_type, agent, content, artifact_path, metadata}` |
| `session_end` | Session completed or failed | `{session_id, status}` |

**Resume params:** `?after_id=N&from_seq=N` to avoid replaying old data on reconnect.

## Project structure

```
app/
  main.py              — FastAPI app, CORS, router registration
  config.py            — Settings from environment (dotenv auto-loaded)
  database.py          — DB layer (SQLite + PostgreSQL, shared with ioagentfarm)
  agents.py            — Agent registry (role -> name, color, avatar)
  schemas.py           — Pydantic request/response models
  skillhub_adapter.py  — Thin wiring for SkillHub module
  clihub_adapter.py    — Thin wiring for CLI Hub module
  routers/
    workspaces.py          — Workspace CRUD + aggregation
    workflows.py           — Workflow catalog (engine DB only; files are import-only via sync)
    sessions.py            — Workflow session lifecycle + background pipeline execution
    messages.py            — Workflow message polling + SSE streaming
    agentfarm_sessions.py  — Interactive session listing, detail, events, messages, SSE, leaderboard, stats
    product_catalog.py     — Product catalog (brands, plays, missions)
    s3.py                  — S3 file operations
    auth.py                — Auth (JWT login + Microsoft Entra SSO)

skillhub/                — Portable agent skills registry (zero host imports)
  __init__.py            — Public API: create_skillhub_router()
  config.py              — SkillHubConfig dataclass
  database.py            — DBProvider protocol + 9-table schema
  schemas.py             — Pydantic models
  validator.py           — Parsing, validation, security scanner
  search.py              — In-memory vector search (fastembed + numpy)
  service.py             — Business logic (DB ops + S3 + scanning)
  helpers.py             — Cursor encoding, row helpers
  routers/               — Thin route handlers split by concern
    skills.py              — CRUD + list + search
    versions.py            — Versions, files, download, verify, tags
    community.py           — Stars, comments, reports
    admin.py               — Rename, merge, undelete, duplicates, scan
  tests/                 — Self-contained test suite (188 tests)

clihub/                  — Portable agent CLI tools registry (zero host imports)
  __init__.py            — Public API: create_clihub_router()
  config.py              — CLIHubConfig dataclass
  database.py            — DBProvider protocol + 8-table schema
  schemas.py             — Pydantic models
  validator.py           — CLI-specific validation + security scanner
  search.py              — In-memory vector search (fastembed + numpy)
  router.py              — All API endpoints (~27)
  tests/                 — Self-contained test suite (104 tests)

tests/                   — Host project tests (86 tests)
scripts/
  live_smoke_test.py     — End-to-end smoke test
```

## Portable modules

Both `skillhub/` and `clihub/` are **self-contained packages** with zero imports from the host project. To use in another FastAPI project:

```python
# SkillHub (needs S3)
from skillhub import create_skillhub_router
router = create_skillhub_router(db=my_db_provider, s3_client_factory=my_s3, s3_bucket="my-bucket")
app.include_router(router)

# CLI Hub (metadata only, no S3)
from clihub import create_clihub_router
router = create_clihub_router(db=my_db_provider)
app.include_router(router)
```

The `DBProvider` protocol requires just 2 methods:
- `get_connection()` — context manager yielding a DB connection with `.execute()`, `.fetchone()`, `.fetchall()`, `.commit()`
- `placeholder()` — returns `"?"` for SQLite or `"%s"` for PostgreSQL

## Database

The API reads from the same database as ioagentfarm. Supported backends:

- **SQLite** — `sqlite:///path/to/state.db` (explicit only — there is no silent local fallback)
- **PostgreSQL** — `postgresql://user:pass@host:5432/dbname` (tables in `iof` schema)

SkillHub adds 9 tables (`skills`, `skill_versions`, `skill_files`, `skill_audit_log`, `skill_version_tags`, `skill_stars`, `skill_comments`, `skill_reports`, `skill_redirects`).

CLI Hub adds 8 tables (`cli_tools`, `cli_versions`, `cli_audit_log`, `cli_version_tags`, `cli_stars`, `cli_comments`, `cli_reports`, `cli_redirects`).

## Development

```bash
# Install
.venv\Scripts\pip install -e .
.venv\Scripts\pip install pytest httpx

# Run all tests
pytest skillhub/tests/ clihub/tests/ tests/ -v

# Run module tests independently
pytest skillhub/tests/ -v    # 188 tests
pytest clihub/tests/ -v      # 104 tests
pytest tests/ -v             # host tests

# Run smoke test (requires running ioagentfarm + database)
python scripts/live_smoke_test.py
```

## Running against the io-procurement-insight-engine (studio deployment)

This copy lives at `apps/agentfarm-api` inside the engine monorepo and runs
against the engine's live state. Point it at the engine's `.iof`, database,
repo root (for pack workflow discovery), and venv CLI:

```powershell
cd apps\agentfarm-api
python -m venv .venv
.venv\Scripts\pip install -e .

$engine = "C:\sb\products\procurement-insights\io-procurement-insight-engine"
$env:IOF_ROOT          = "$engine\.iof"
$env:IOF_DATABASE_URL  = "<IOF_DATABASE_URL from the engine's .env>"
$env:IOF_AGENTFARM_DIR = $engine                       # pack workflow discovery (agentfarm-core + solutions/*)
$env:IOF_BIN           = "$engine\.venv\Scripts\ioagentfarm.exe"
$env:IOF_UI_CORS       = "http://localhost:5173"
$env:IOF_AUTH_DEV      = "1"                           # dev-only: any email/password logs in

.venv\Scripts\uvicorn app.main:app --port 8002
```

Notes:
- `POST /api/workflows/{wf}/sessions` now shells `ioagentfarm run --json`
  (engine-orchestrated, Alex-driven, resilient) — the old in-API pipeline
  driver thread was removed.
- New **studio** surface: `/api/studio/agents` (list/create/edit/chat),
  `/api/studio/skills`, `/api/studio/workflows` (list/edit/create with
  dry-run validation into `.iof/workflows/`), `/api/studio/runs/{id}/usage`
  (token usage from `instances/<run>/usage.jsonl`).
- `IOF_AUTH_DEV=1` bypasses SSO for local dev / Playwright. Never set in prod.
