# ioagentfarm

> **Read this first.** The sections below describe the CURRENT system. Where a
> claim here disagrees with the code, **the code wins** — several statements in
> this file were true, then quietly stopped being true, and the ones that cost
> the most were the ones nobody re-checked. Each subsection names the command or
> grep that settles it.
>
> **Detail lives in `docs/`; this file is the map, not the territory:**
> [SDK_REFACTOR_PLAN.md](SDK_REFACTOR_PLAN.md) ·
> [one-truth-content-model.md](docs/one-truth-content-model.md) ·
> [NEXT_PHASE_BACKLOG.md](docs/NEXT_PHASE_BACKLOG.md) (every open item) ·
> [PLATFORM_HARDENING_BACKLOG.md](docs/PLATFORM_HARDENING_BACKLOG.md) ·
> [RESILIENCY.md](docs/RESILIENCY.md) · [MEMORY.md](MEMORY.md)

## Current state — the four things that shape everything else

### 1. A monorepo of installable packs

`agentfarm-core/ioagentfarm/` is the runtime, CLI and engine (distribution
`agentfarm-core`, **pack name `core`**); `agentfarm-skills/` ships the shared
craft skills; `solutions/{ainf,pharma}/` are domain packs; `apps/agentfarm-api`
and `apps/agentfarm-ui` are the Studio. A pack plugs in through the
**`aicore.packs` entry point** with zero core edits (`ioagentfarm/packs.py`).
The import package is still `ioagentfarm` — renaming it is backlog G1.

`Pack.name` is the workspace **FAMILY code**: every distribution of one
workspace repo declares the same name, and `Pack.solution` attributes a
workflow. **Agents, skills and CLI tools are family-level; only workflows are
solution-level.** Two repo layouts — flat (the default: content at the repo
root, `tools/` the one pip-packaged part) and packaged (content inside wheels).
`detect_collisions()` warns once per process on duplicate names across packs.

#### The three levels, and where each lives on disk (settled 2026-08-25)

**`Pack.name` is NOT the pack's name — it is the WORKSPACE the content belongs
to.** `pharma` proves it: `_FAMILY = "barrier_insights"`, declared from a folder
called `pharma`, in packages called `pharma_*`, from a distribution called
`agentfarm-pharma`. The field reads as a tautology in a workspace-of-one, where
folder, distribution, package and workspace all land on one slug — which is
exactly how `solutions/ainf2/ainf2` came to exist and cost a session to unpick.
A pack had NO identity of its own: `_discover_entry_point_packs` sorted by the
entry-point name and then discarded it, so `detect_collisions` could only name
the workspace, and two packs of one family colliding printed the same name
twice (that is what `same_family` means). **Since 2026-08-25 the field is
`Pack.workspace`, and `name` is its deprecated spelling** (made equal at
construction, so every `.name` reader and every `Pack(name=...)` still work;
the scaffold now writes `workspace=`). And a pack has an identity: `Pack.pack`,
the entry-point name attached at discovery (core sets `"core"`), so a
collision names the distribution that shipped the duplicate —
`Collision.carriers` beside `Collision.packs`.

**Layout is the workspace repo, flat, with package names as a mapping:**

```
solutions/<ws>/
  agents/  skills/            <- WORKSPACE level: every solution resolves these
  solutions/<sol>/workflows|swarms   <- SOLUTION level: what that solution owns
  pyproject.toml              <- [tool.setuptools.package-dir] maps names to dirs
```

The package names (`pharma_agents`, `brand_response_sol`) exist ONLY in that
mapping table. Nothing is nested to satisfy packaging, and a directory is at
the level it belongs to. `ainf2` was restructured to this shape on 2026-08-25.

**Shared content goes at workspace level — resolution being permissive is not
a licence.** `agent_sources()`/`skill_sources()` iterate every pack of the
family and never read `solution`, so an agent shipped inside a solution package
still resolves for the others. That TOLERATES misplacement; it does not justify
it. If two solutions need one agent it belongs in `<ws>/agents/`, declared by
the pack with `solution=None`. Pinned by `test_pack_declares_its_content_roots`
in the ainf2 suite. (Solution-LEVEL agents/skills/tools are a legitimate future
case — the structure supports them — just never for content two solutions
share.)

**A workspace repo is ONE distribution with several packages.** The pod
installs the workspace, never a single solution; the split exists so the
catalog can attribute a workflow, not to deploy separately.

**Naming: a solution package is `<solution>_sol`** (`cli_scaffold._flat_sol_pkg`,
changed 2026-08-25 from `<family>_sol_<solution>`), and the DIRECTORY is
`solutions/<solution>/` — directory name always equals the solution code.
Applies to new scaffolds; pharma's published names are untouched. **Known cost,
accepted deliberately:** import names are global to a venv and one engine venv
holds every workspace it serves, so two workspaces that each own a `reporting`
solution both want `reporting_sol` — pip installs one and the loser's entry
point silently resolves to the winner's package. `detect_collisions` watches
content names, not import names, so nothing catches it.

**A suite parametrized over pack content must enumerate EVERY pack.** Splitting
seven workflows across two packages dropped the ainf2 suite from 28 tests to 16
with everything still green — the six that moved were simply no longer
collected. A per-item suite reading one pack narrows silently when content
moves between them.

### 2. Content comes from the installed pack, and only from there

**One Truth, shipped 2026-08-16.** The engine resolves content from the
installed pack — no DB catalog tier, no materialized override tree in the read
path. Every item carries a stamp (`pack version @ sha`). What follows from it:

- **`setup-agents`, `sync` and `workspace push` are deprecated no-ops** that say
  so. `setup-agents --force` still does one thing: it drops the materialized
  copy so the next run re-reads the pack.
- **A Studio save is a DRAFT** — one row per `(workspace, kind, name, author)`
  in `content_drafts`, resolving only inside its author's own session or
  draft-flagged run (`content = base ⊕ overlay`). Carriage rides the overlay, so
  a skill add/remove on a pack agent is draft-only. Draft homes are isolated,
  with blank memory, outside every role scanner.
- **The engine never has git access** — organisational policy, not a gap.
  Promotion is a person at a desktop: `aicore drafts apply <id>` writes the
  files into their checkout; review, commit and PR are theirs. A draft reads
  `promoted` when the running base's bytes equal it — detected, never declared.
  Surface: `aicore drafts list|show|diff|apply|migrate`.
- **`workspace pull`/`diff` are NOT the promotion path.** They read tenant
  content tables a current deployment never populates — `studio.py` calls them a
  "transitional add-only read tier". On a fresh deployment `diff` reports every
  repo item as new and `pull` writes nothing.
- **There is no solution scoping.** Nothing in the API reads
  `studio_workspace_items`; the Studio reads the engine's installed-package
  catalog, where `pack` and `solution` are labels, not filters.

Full design: [docs/one-truth-content-model.md](docs/one-truth-content-model.md).

### 3. The Studio API has no filesystem

The API pod and the engine pod are separate and never co-located: no agent home,
no pack installation, no engine state directory. The Studio reads base content
**from the engine** (`GET /api/catalog/agents|skills|workflows`) and writes
drafts to the database. Two things could not migrate and are proxied to the
engine: agent memory (`GET`/`DELETE /api/agents/{role}/memory`) and the
workflow-catalog sync — the API's own copy globbed a REPO LAYOUT, so off a
developer checkout it reported success and imported nothing. Pinned by
`apps/agentfarm-api/tests/test_studio_without_a_filesystem.py`;
`tests/conftest.py` fails any test that resolves an agent home.

### 4. A workspace is always explicit

`default` is not a selectable workspace. `resolved_workspace_code()` raises
rather than inventing one; the CLI refuses without a selection; the API answers
400 (missing header), 403 (unknown or retired) or 503 (registry unreachable);
`serve` fails fast at startup. **`PLATFORM_TIER = "default"`** is the one
remaining meaning of the literal — the internal shared-tier DB key for
platform-shared roles, never a workspace, never created, refused by delete.
Adoption path for a pre-tenancy install: `aicore workspace rename default <code>`.

### Security — what is a boundary, and what is not

**Guarded:** `app/routers/workspaces.py`, `admin.py`, `studio.py` (router-level
`Depends(require_member)`, so a new route cannot be added unguarded) and
`sessions.py`. JWT signatures are verified (`alg` pinned, `hmac.compare_digest`,
`exp` checked); membership is closed. `app/main.py`'s middleware resolves
`X-Workspace-Id` fail-closed on every non-exempt route.

**Verify before repeating any of that:** `grep -c "Depends(require" app/routers/*.py`.

**THE ENGINE WEB API IS AUTHENTICATED SINCE 2026-08-26** (backlog I1/D1 —
this section said "no authentication at all"; that is now history). A
fail-closed middleware guards every route on `ioagentfarm serve`; the
exemptions are `/health`, `/ready` and CORS preflights, and they answer
BEFORE the policy is read, so a typo in the config cannot become a restart
loop that destroys the log line explaining it. `IOF_ENGINE_AUTH` selects
`oidc` (a bearer JWT verified against the IdP's published JWKS — **Entra ID**
in production, **Okta** from the same configuration), `apikey` (a rotatable
shared secret), both, or `off`. **`serve` REFUSES a non-loopback bind with
auth off** unless the operator wrote `IOF_ENGINE_AUTH=off`.

**TWO CAVEATS THIS SECTION USED TO OMIT, both found by a validator
(2026-08-30).** It said an exposed unauthenticated engine was "no longer
reachable by omission" and that an upgrade serving 0.0.0.0 anonymously
"will not start until it answers". Neither held:

- **The container answers for you.** `entrypoint.sh` defaults
  `IOF_ENGINE_AUTH=off` so an upgrade does not fail to boot — which means a
  GREENFIELD deployment of the image gets the same posture, permanently, and
  `grep IOF_ENGINE_AUTH` across the customer's own manifests finds nothing.
  The entrypoint now says explicitly when the IMAGE supplied the value
  rather than the deployment; set it yourself, even to `off`.
- **The check guarded a command, not the application** until 2026-08-30.
  `assert_safe_to_serve` had one caller, `aicore serve`, so `uvicorn
  ioagentfarm.web.app:app --host 0.0.0.0` bound an exposed port and answered
  anonymously. It runs in the app's lifespan now, where gunicorn, a manifest
  naming the module, and the multi-worker shape cannot route around it.
Callers (the API pod, the CLI, anything) read one `IOF_ENGINE_CRED_*` set.
The verifier and the outbound credential live in `ioagentfarm/security/` and
are SHARED with the Studio API, so the two cannot drift about what a valid
token is. Reference: [docs/engine-authentication.md](docs/engine-authentication.md);
walkable lab with a real loopback OIDC issuer at `examples/engine-auth-lab/`.

**Verify before repeating any of that:** `curl -s localhost:8111/api/whoami`
— 401 when the guard is on, 200 with a `principal` when a credential is
presented. Keep the port on an internal network anyway: that is now defence
in depth rather than the only control.

**Still NOT secured:** Operational-Insights routers are not workspace-scoped
(backlog I2), and the engine has no authorization model of its own — a
verified caller reaches every route. Membership is enforced in the Studio
API, not here.

**Two levers, not interchangeable.** `IOF_AUTHZ_ENFORCE=0` keeps identity
verified but stops enforcing membership — the narrow rollback. `IOF_AUTH_DEV=1`
is far wider: any credentials authenticate, and the minted token carries
whatever email the caller typed. Neither belongs in a pod. A **platform admin is
any `role='admin'` row in `studio_workspace_members`, in ANY workspace** — it
grants every workspace including ones created later, and it OUTLIVES
`IOF_AUTH_DEV`, so both have to be undone.

### Client documentation

**`aicore_docusaurus/` is the ONLY client doc set** — the parallel
`docs/getting-started/` tree was retired 2026-08-16 and must not be recreated.
Its style contract (`aicore_docusaurus/_STYLE_CONTRACT.md`) is binding:
enterprise register, no internals, no history, every command matched against
live `--help`. Verify with `python aicore_docusaurus/_verify.py aicore_docusaurus`
— **the argument is required in practice**: it defaults to the CWD, so from the
repo root it scans every `.md` in the tree (agent `SKILL.md` files, which
correctly have no `title:`, and any git worktree under `.claude/`), producing
~340 lines of noise and a permanent exit 1. Scoped it reads 64 pages.
`docs/examples/pharma-commercial/` is the same walk done on a client deployment.

### Deployment and ownership — the point of the SDK split

The framework team owns, versions and publishes `agentfarm-core` and
`agentfarm-skills` as wheels on an index. Each business IT team owns a git repo
holding their WORKSPACE — a shared pack plus one workflows-only package per
solution — installs the SDK as a dependency, and plugs in via the entry point.
They never fork or edit core. **Upgrades are version bumps, not merges.**


Thin orchestration layer for multi-agent workflows and interactive sessions on **iobot**, its vendored agent runtime. Inspired by [antfarm](https://github.com/snarktank/antfarm).

Two execution modes: **workflow** (30-min autonomous pipelines) and **session** (2-min interactive experiences with always-on agents).

- **Package:** `ioagentfarm` (v0.6.9)
- **CLI entry:** `ioagentfarm.cli:app` (typer)
- **Python:** >=3.11
- **Agent runtime:** **`iobot==0.4.0+io.1`** — an in-repo vendored fork of an MIT-licensed upstream runtime, reduced and RENAMED at vendor time. The import package is `iobot`. See "The iobot runtime" below.
- **State directory:** `.iof/` (SQLite DB, run artifacts, step outputs, per-run instance configs)
- **Agent workspaces:** `~/.iobot/agents/<role>/workspace/` (identity, memory, skills, sessions).

## The iobot runtime — a vendored, reduced, RENAMED fork (rename shipped 2026-09-04)

**`iobot/` is a fork of an upstream open-source runtime, vendored in-repo.** Not
a rewrite: the code is upstream's, taken from a pinned wheel (sha256 in
`iobot/vendor.lock.json`), with subtrees we never run deleted and the import
package renamed. MIT — `LICENSE` ships with it and must keep shipping.

**THE UPSTREAM PROJECT IS NAMED IN EXACTLY ONE FILE, `iobot/LICENSE`, AND
NOWHERE ELSE — this file included.** A client's governance team greps a
delivery for the names of projects it has policies about; the upstream name
was one, and the client said their governance board would block the solution
on it. The MIT copyright line reads "and the <upstream> contributors" and the
licence requires that notice verbatim in every copy, so that ONE line stays:
scrubbing it would trade a governance objection for a licence violation. The
rest of what `vendor.py` needs — distribution and import-package names, the
release, the URLs upstream hard-codes — lives in a **vendoring policy file
OUTSIDE the repository** (`~/.iobot/upstream.yaml`, or `--policy`);
`iobot/upstream.example.yaml` is the placeholder template. **Pinned by
`tests/test_upstream_name_is_absent.py`**, which derives the word from the
licence line, scans every tracked file (vendored tree included) for it in any
casing and for upstream's cat logo, and asserts no filled-in policy is
tracked. The docs verifier and `entrypoint.sh` derive the word the same way.
**The rule for anyone writing here:** say *upstream* for the project the
runtime derives from and *iobot* for the runtime as it exists in this repo.
Never spell the upstream name — not in a comment, a docstring, a document, a
test, or a commit body that lands in a file; not even assembled from halves.

**Why:** supply-chain control (no wheel from an account we don't control; a
260-PR release can't land in a rebuild by surprise), deleting 67% of the code
so there's less to review, and ONE name for the runtime in front of a client.
**What it is NOT:** a change of authorship. Vendoring is not a security review
— it's what makes one worth doing, because the code stops moving. Renaming is
not authorship either. Don't let anyone describe this as "our code now". The
defensible sentence is *"our runtime is iobot, an MIT-licensed fork we
vendored, reduced, renamed and pinned"*.

### The rename is a TRANSFORM in the vendoring pipeline, never an edit

`iobot/vendor.py` derives the tree as **`rename(drop(wheel))`**, and the lock
pins exactly that. `rename_tree()` runs, in order: **(1)** `externalize_py` —
every URL the policy lists as upstream's OWN infrastructure (the repo, sent as
an `HTTP-Referer` header by two providers; the docs site; the WebUI's release
index and page; the extension registry) becomes `url("<key>")` from a
generated `iobot/_external.py`, which reads the deployment's
**`~/.iobot/endpoints.yaml`** — one root-level YAML a client edits to map every
such link to their own hosts (`project`, `docs`, `release_index`,
`release_page`, `extension_source`); an absent key resolves to
`https://iobot.invalid/<key>`, reserved and never resolving, so nothing is
reached by omission. NOT environment variables, by the user's decision: there
are already too many. Plain literals, f-strings, comments and docstrings are
each handled; **(2)** an ORDERED, byte-level rule table: the distribution name
in both spellings (so `importlib.metadata.version()` asks for OUR
distribution), the import package in three casings (UPPER for the `IOBOT_*`
environment prefix, Capitalised for prose and class names, lower for imports,
paths, logger names and `~/.iobot`), the logo → ASCII `(io)` — bracket-free
because the runtime prints it through Rich markup, which eats `[word]`, and
ASCII because the emoji raised `UnicodeEncodeError` on a non-UTF-8 Windows
console; **(3)** path names; **(4)** `scan_residue` FAILS the run if any
spelling of the upstream name or any policy URL survives, and **(5)** every
module is compiled so a rewrite that produced invalid code fails here, not at
a client's first import. On 0.3.0: 215 of 259 files rewritten, 3 paths, 8 URL
sites in 5 modules externalised. `vendor.py` itself spells no upstream name.

Consequences a session must know:

- **The vendored source natively says `iobot`, `~/.iobot`, `IOBOT_*`, `(io)`.**
  `engine/branding.py` therefore rewrites ONLY the engine's own package name
  (`ioagentfarm`→`aicore`) at display time; the runtime half of the console
  needs no rewrite and a runtime log record passes through untouched
  (`tests/test_two_banned_words.py` pins both directions).
- **`state_dir_override`** (was the state-dir rename patch) is a NO-OP unless
  `IOF_STATE_DIR_NAME` names another directory (test isolation, a shared
  host); at the default it arms nothing and leaves no sentinel, so it is NOT
  a canary for "did the patches fire" (`session_save_retry` is). The
  `sys.modules` identity sweep it carries is still what makes an override
  reach the four modules that bind path helpers at IMPORT time
  (`tests/test_state_dir_rename.py` proves it in a subprocess).
- **There is no migration from the previous directory name** and no legacy
  binary name in `engine/runtime_bin.py` — every host that could have needed
  either has run it, and a pod re-seeds from the packs.
- **Environment variables are `IOBOT_*`** (`IOBOT_MODEL`, `IOBOT_API_BASE`,
  `IOBOT_PROVIDER`, `IOBOT_HOME`, `IOBOT_MAX_CONCURRENT_REQUESTS`,
  `IOF_IOBOT_EXTRA_ALLOWED_DIRS`, …), with NO alias for the previous prefix.
  **`entrypoint.sh` REFUSES TO BOOT** if the environment carries a variable
  with the old prefix, listing them — a stale K8s manifest fails loudly at
  pod start instead of silently falling through to every default (the wrong
  model, quietly). It derives the old prefix from the licence line at boot.
  **Manifests outside this repo must be renamed before the image rolls.**
- **Skill frontmatter metadata key is `iobot:`** (`agent/skills.py` reads
  `data.get("iobot", data.get("openclaw", {}))`); the SkillHub validator and
  `test_no_foreign_skill_metadata.py` follow it.
- **Version `0.4.0+io.1` is OURS from here on**; the upstream release it
  derives from is in the lock (`upstream.version`) and the policy file, not in
  the version. The `+io` local segment is load-bearing: pip refuses to satisfy
  a local version from an index that lacks that exact file, so no public index
  can substitute a foreign `iobot` (none exists today; the guard is against
  one appearing). A content change under a fixed version is what pinning
  exists to prevent — bump it, and the pin in `agentfarm-core/pyproject.toml`
  with it.
- **`iobot/METADATA` is gone**, and `THIRD_PARTY_NOTICES.md` is OURS (upstream's
  covered the dropped web bundle). Upstream's dependency bounds are recorded
  in the lock as `requires_dist`; the sync step reads them from there. The
  lock records the release number and the wheel sha256, never a name.
- **Runtime data on hosts is untouched.** Seeded agent homes, session JSONL,
  forensic blobs and Studio DB rows written before the rename keep whatever
  text they carried — evidence is not rewritten. Git history keeps the old
  tree too; it is not rewritten.

### The three rules — these are what keep upgrades cheap

1. **Never hand-edit a file under `iobot/src/`.** An upgrade re-derives the
   tree and the edit vanishes silently. Runtime changes go in
   `_iobot_patches.PATCHES`; anything else in `iobot/patches/*.patch`, cut
   against the RENAMED tree. Both fail loudly on upgrade. Enforced by a
   sha256-per-file manifest and `tests/test_iobot_vendor_integrity.py` —
   verified non-vacuous (appending one comment line fails both the test and
   `vendor.py --check`).
2. **Deletions live in `vendor.py`'s `DROP_SUBTREES`**, never a manual `rm` —
   which survives exactly until the next re-vendor and is then silently undone.
   It's a drop-list not a keep-list on purpose: a new upstream subpackage is
   then kept by default and any problem is a loud import error, not a silent
   omission discovered at runtime.
3. **Keep the patch registry** even though source is now editable — it's what
   tells you what's yours when upstream moves. The vendoring policy file is
   the same kind of record, kept outside the tree.

### Upgrading to a new upstream release — the procedure future sessions follow

Have `~/.iobot/upstream.yaml` (from `upstream.example.yaml`). Then
`python iobot/vendor.py --version X` (`--from-wheel` when air-gapped) →
records the sha256, drops, externalises, RENAMES, applies
`iobot/patches/*.patch`, writes `iobot/src/iobot/`, rewrites the lock. Then
set `version` in the policy file, sync the dependency bounds in
`iobot/pyproject.toml` from the lock's `requires_dist`, bump `iobot`'s version
and core's pin, `pip install -e ./iobot`, `aicore patches --verify` (every
un-gated runtime patch must bind), `python scripts/run_tests.py`, one live run
with `IOF_IOBOT_EXTRA_ALLOWED_DIRS` set. Loud failure modes: `no vendoring
policy` (create it), `! drop 'X': NOT PRESENT upstream` (stale policy),
`RENAME INCOMPLETE` (extend the policy's URL tables), `RENAME PRODUCED INVALID
CODE` (extend `externalize_py`), `PATCH FAILED` (re-cut). **To port ONE
upstream commit** without a full upgrade: export it as a patch, `python
iobot/vendor.py --rebrand-file fix.patch` so its paths and imports match our
tree, drop it in `iobot/patches/`, re-run `vendor.py`. Full procedure, gates
and troubleshooting: **`iobot/UPGRADING.md`**. What was removed and the honest
endpoint numbers: **`iobot/PROVENANCE.md`**.

### Container build

`.dockerignore` exists because there wasn't one and `COPY . .` was pulling
~1.4 GB of host artefacts INTO the image — a Windows `.venv` the Linux image
can't execute, `node_modules`, `.git`, and `.env` with live DB and AWS
credentials baked into a layer. Context is now 24.6 MB. CI never noticed: it
builds from a fresh clone where most of that doesn't exist.

**The image has never been built LOCALLY** — there is no container runtime on
the dev machine. Do not read that as "never built anywhere": `buildspec.yaml`
runs `docker build`/`docker push` in CI, and a commit exists whose message is
about fixing the image build the new test step would gate. The claim to make
is about local proof, not about the pipeline. The pip step was validated by
replicating it exactly in a clean venv (all 7 editable dists with
`-c constraints.txt`, both Dockerfile gates, `iobot` on PATH, `pip check`
clean), which covers the riskiest part: `iobot==0.4.0+io.1` is a PEP 440
local version resolvable from no index, which is why the Dockerfile installs
`-e ./iobot` before core.
**Still unproven:** `entrypoint.sh` writing `config.json` into `/root/.iobot`
and the runtime reading it back. That exact writer/reader mismatch already
happened once locally — it surfaced as `exists=False` and a silent fallback to
defaults, i.e. a failed run rather than a startup error. Build the image before
trusting the pod.

### What was removed, and the one caveat that matters

840 files / 7.78 MB → **260 files / 2.55 MB (67% gone)**: the 4.3 MB compiled
WebUI bundle (`web/`), 15 of 17 chat-channel backends, `sdk/`, and four
built-in skills every agent would otherwise inherit; plus one generated
module, `_external.py`. Kept: `channels/` framework + `email` + `msteams` (so
`iobot gateway` still works), plus `skills/` and `templates/` which are
reached by **path** and would have been dropped by any allowlist derived from
an import trace, breaking at runtime.

`msteams` is kept by decision but **is not used by our code** — our Teams channel
(`ioagentfarm/channels/teams/`) is standalone. Don't assume it's load-bearing.

**23 of 100 hardcoded outbound hosts removed, 14 CN-hosted — all channel-side;
the rename removes every URL that named upstream's own infrastructure in
favour of `~/.iobot/endpoints.yaml`. 17 CN-hosted endpoints REMAIN** in
`providers/`/`cli/` (the LLM backend list), including **`api.minimax.io`, which
is the model the development deployment runs on**, and `apps/cli/service.py`
still carries the registry URLs of the CLI-Anything project (same upstream
organisation) for the runtime's CLI-apps feature — dropping that subtree is a
separate decision. The defensible claim is *"we removed the Chinese
chat-channel integrations and the runtime carries no upstream identity"*, not
*"we removed the Chinese endpoints"*. Anyone taking this to a client security
review needs that distinction.

## Architecture: thin orchestration on rich runtime

```
iobot — the vendored agent runtime (rich runtime; import package `iobot`)
├── Identity:  SOUL.md loaded natively per agent workspace (--workspace)
├── Memory:    MEMORY.md read/written by ContextBuilder
├── Skills:    skills/*.md with always:true for output protocol
├── Tools:     MCP servers (filesystem, GitHub, etc.) — per-instance via --config
├── Sessions:  JSONL persistence, workspace-scoped (per-role isolation)
├── Gateway:   Telegram/MS Teams/CLI channels, heartbeat, native spawn
└── Multi-instance: --config for per-run isolation, --workspace for per-role identity

ioagentfarm (thin orchestration)
├── Workflow DAG scheduling (deps, sequencing)
├── State store (SQLite/PostgreSQL — runs, steps, stories, tasks)
├── Per-run instance configs (.iof/instances/<run_id>/config.json)
├── Output protocol parsing (STATUS/OUTPUT)
├── Step recovery (retry, skip, reset)
└── CLI commands for humans + JSON API for Alex
```

```
User goal (CLI / Telegram / MS Teams / Web / any iobot channel)
  |
  v
Alex (project_lead) -- orchestrate, delegate, decide next step, error recovery
  |
  +-- Dana (analyst)    -- investigate, plan, decompose stories, signal detection
  +-- James (strategist)-- evaluate options, simulate outcomes, compose strategies
  +-- Sam (developer)   -- implement code changes
  +-- Chris (reviewer)  -- test, review, enterprise quality gates

Always-on agents (no run/orchestration; in-process AgentLoop via web API):
  +-- Jarvis (gateway)    -- universal AI assistant, web/teams/slack channels
  +-- Quinn (queryngine)  -- virtual data layer, federates structured + vectorfs
                              sources; emits the response envelope (schema v1); concurrency-safe via
                              session-hash scratch dirs; structurally grounded via
                              .no_discovery marker + NOT_FOUND error augment.
                              (POST /api/chat/queryngine; see docs/query_engine.md)
```

### Execution model

Alex (project_lead) IS the scheduler. He drives the pipeline as a iobot subprocess, deciding which step to run next and handling errors. See `docs/orchestration.md` for the full model.

| Mode | Entry point | Sub-agent pattern |
|------|-------------|-------------------|
| **Run** (CLI, blocking) | `ioagentfarm run` | `run-step --step-key <key>` (blocking) |
| **Gateway** (long-lived, async) | `ioagentfarm start-gateway` | `run-step --step-key <key> --background` (fire-and-forget) |
| **Web API** (FastAPI, scalable) | `ioagentfarm serve` | subprocess-per-run + agent pool via `process_direct()` |
| **Always-on query** (real-time) | `POST /api/chat/queryngine` | in-process AgentLoop, no run/orchestration. See `docs/query_engine.md` |
| **A2A surface** (external agent callers) | `POST /a2a/<role>` (JSON-RPC 2.0) | every always-on agent exposed as an Agent2Agent v1.0 service. Thin wrapper over `process_direct()` — same pool, same workspace. |

**Always-on agents:** the web API pre-warms agents listed in `IOF_ALWAYS_ON_AGENTS` (default `jarvis`; set `jarvis,queryngine` for query-engine deployments). Each pre-warmed agent gets a 2-call cache warmup at startup so the first user request hits the Anthropic prompt cache. Use `ioagentfarm configure-agent <role> <metadata_dir>` to deploy domain metadata into an always-on agent's workspace (embeds catalog into the relevant skill).

**A2A (Agent2Agent) protocol surface:** every always-on agent is also reachable via the standard A2A JSON-RPC interface at `POST /a2a/<role>`. Each agent serves a public Agent Card at `GET /a2a/<role>/.well-known/agent-card.json` (composed from `workspace/a2a-card.yaml`, falling back to the SOUL.md first paragraph). **Protocol v1.0**: methods are PascalCase `SendMessage`, `GetTask`, `CancelTask` and — **since 2026-08-30** — `SendStreamingMessage` (hard cutover from the old v0.3 `message/send`·`tasks/get`·`tasks/cancel`); the card now advertises `streaming: true` by default, and PUSH methods still return not-supported. **The streaming frames were built against the spec's own generated types, not from memory**: `a2a-sdk` was installed and its descriptors read, which is how `TaskStatusUpdateEvent` was found to have NO `final` member — the field a from-memory implementation adds, and one a spec client's strict `json_format.ParseDict` would raise on. Each SSE `data:` frame is a WHOLE JSON-RPC response whose `result` is a `StreamResponse` oneof (`task`|`message`|`statusUpdate`|`artifactUpdate`); there is no `event:` line. It runs through `chat_stream.stream_turn` (one driver, a `format_frame` parameter) so the bounded first wait and refusal rules are not re-implemented — a refusal still returns a JSON-RPC error as `application/json`, verified. `tests/test_a2a_streaming_is_spec_shaped.py` parses every frame with the real SDK and is proven non-vacuous. Structured agent output is split into a `DataPart` (the JSON envelope) + a chain-of-thought `TextPart`. Multi-turn continuity flows through the payload `contextId` (mapped to `session_key = "a2a:<role>:<ctx>"` inside the handler). Agents call each other over this surface via the **`iof-consult`** CLI (`tools/consult_agent.py`); optional external agent discovery writes a dynamic routing catalog when `IOF_AGENT_REGISTRY_URL` is set (see `engine/ainf_registry.py`, env-gated). Toggle the whole surface with `IOF_A2A_ENABLED` (default on). Implementation in `web/a2a.py` + `web/a2a_models.py` + `engine/a2a_client.py`; card schema mirrors A2A spec v1.0.

**Queryngine (Quinn) invariants — do not regress these without understanding why:**

- **The response envelope (wire `"schema": "v1"`) is the only output format.** `result_composer/SKILL.md` enforces a fenced `{schema, answer, data, insight, evidence}` block with nothing outside. Client UIs/APIs parse the envelope deterministically — do not add prose wrappers, do not emit `STATUS:/OUTPUT:` (that's why `output_protocol/SKILL.md` was removed from Quinn; keeping it caused two `always:true` skills to give contradictory format directives).
- **Per-session scratch directory is mandatory for concurrency, and a query is ONE tool call (2026-09-05).** `adhoc_chat()` in `web/app.py` derives `metadata/tmp/<session_hash>/` per `session_key` and injects the path into the prompt. Without this, parallel requests race on a shared `query.sql` and read each other's SQL mid-execution. The injected block used to teach write-the-file-then-run (`--sql-file`), which was a whole model round per question — measured on the served `ainf_insights` engine: a scalar question went 18.8s → 9.7s when the SQL rides inline. So the block now says `iof-query --scratch {dir} --db <source> --sql "..."`: `--scratch` (new on `iof-query`) is how the tool finds the per-session budget counter without a file, and `--sql-file {dir}/query.sql` stays for SQL too long for a line. `tests/test_iof_query_scratch_flag.py` pins both. The conversation route's "narrate before every tool call" block is OFF unless `IOF_CHAT_NARRATE=1` (a deployment on a provider that volunteers no thinking text, e.g. Azure OpenAI, sets it for the Studio's thoughts panel); it cost 20–40 output tokens per round on every deployment.
- **`.no_discovery` marker gates `--list-databases` / `--list-entities`.** The marker file at `metadata/.no_discovery` makes `iof-query` skip argparse registration of those flags (see `_discovery_disabled()` in `query_executor.py`). Quinn cannot waste an LLM round on discovery-via-CLI because the CLI rejects the call. Keep the marker in Quinn-facing metadata only; other agents (analyst, data_analyst, edi_*, jarvis) deliberately keep the flags.
- **NOT_FOUND augment is the hallucination safety net.** `query_executor.py`'s `augment_not_found_error()` adds `catalog_schema` (full entity → columns + measures map) and `did_you_mean` (fuzzy suggestions) on any Binder/COLUMN/TABLE not-found error. DuckDB's native Candidate Bindings list is capped and often misses the semantically-correct column. With the augment, Quinn recovers in one round instead of 5–7 rounds of `SELECT DISTINCT`-style discovery.
- **Interpretive-vs-data rule.** `result_composer` tells Quinn: for purely interpretive follow-ups (*"why is AWS so high?"*, *"thoughts?"*), do NOT run new tools. Set `data: null`, `evidence: null`, reason from prior session context into `insight`. Saves 4–6 LLM rounds per follow-up turn.
- **Catalog descriptions carry real data (cardinality, ranges, totals, value distributions).** Added via `description:` fields only — no `example_queries`, no `from_clause`, no `do_not` lists. See `docs/query_engine.md` §"Catalog strengthening" for the rule and its rationale (those additions introduce shape-bias and scaffolding creep).
- **Sequencing when removing grounding.** Removing a discovery call (via `.no_discovery`, skill edit, or CLI flag deletion) is only safe once alternate grounding exists: strengthened catalog + NOT_FOUND augment + envelope's explicit column commitment. Removing it first causes schema hallucination. See `feedback_grounding_tool_calls.md` in project memory.

Web API details: `POST /api/run` spawns run, `GET /api/run/{id}/stream` SSE output, `POST /api/run/{id}/message` follow-ups, `POST /api/run/{id}/resume` crash recovery. Pluggable backends: `IOF_RUNNER` (local/k8s), `IOF_STORAGE` (none/s3). See `docs/web-api.md`, `docs/horizontal-scaling.md`.

**MS Teams channel** (mounted on web API): `POST /api/teams/messages`, no MS SDK — Pydantic Activity models + httpx + pyjwt. Thread = Run. See `docs/teams-integration.md`.

### Core concepts

- **Workflows** define a YAML pipeline of steps. `deps` field is the entire sequencing mechanism.
- **Communication** flows through `{{step_output.<key>}}` templating — no direct agent-to-agent messaging.
- **Dynamic tasks** injected mid-pipeline by project_lead via `TASKS_JSON` (governance: only project_lead).
- **Output protocol:** every step must return `STATUS: done|failed` and `OUTPUT: <text>`.
- **MCP servers** give agents external tool access — configured automatically per-run.

### How spawning works

Alex checks `role` from `next-step`: `project_lead` -> inline via `step-complete`; anything else -> delegate via `run-step`.

1. CLI renders prompt via `build_task_prompt()`, resolves per-run instance config
2. Launches `iobot agent --workspace <role_ws> --config <run_config>` subprocess
3. Sub-agent writes OUTPUT.md -> CLI parses, updates DB, advances pipeline

## Workflows

| Workflow | Pipeline | Roles |
|----------|----------|-------|
| `project_lead` | assess > analyze > plan > implement > test > review > signoff | project_lead, analyst, developer, reviewer |
| `feature_dev` | analyze > plan > implement > test > review | analyst, developer, reviewer |
| `story_loop` | create_stories (loop) > per-story implement/test/review > done | analyst, developer, reviewer |
| `bug_fix` | reproduce > isolate > patch > test > verify | analyst, developer, reviewer |
| `procurement_intelligence` | analyze > strategize > review | **procurement_analyst (Iris)**, domain_consultant, reviewer |
| `deck_build` | build_deck (HTML → pptx/pdf) | domain_consultant |
| `slides` | compose_content > build_slides (plain-language goal → deck; ai_workspace pack) | **workspace_agent (Nova)** |

## Grounded analyst (Iris), fail-closed artifact gate, and deck generation (2026-07 additions)

A fresh session picking up this repo should know these four subsystems added in July 2026. Full detail lives in project memory (`memory/*.md`); this is the checked-in summary.

### Grounded procurement analyst — Iris (`procurement_analyst`)

`agents/procurement_analyst/` is a **domain- and dataset-agnostic** analyst whose grounding discipline is the fix for the hallucination the old workflow analyst (Dana) produced. Invariants:
- **Schema comes from the workflow, never embedded in the agent.** `catalog_reader` reads `catalog.yaml` from the step's `{{metadata_dir}}` at runtime. Do NOT `configure-agent` the catalog into Iris — one Iris serves many workflows (IT-VMO DuckDB today, SAP SCM tomorrow); the workflow supplies the dataset.
- **`grounded_analysis` (always:true) is the anti-hallucination contract:** every figure traces to a query the agent ran (cite entity + SQL + row count); recency computed against *today's date*; gaps are stated ("not available in `<entity>`"), never invented.
- **Domain is skill-driven.** Base = grounding skills; the IT-VMO domain pack (`it_vendor_management` lens + the 10 deep skills copied from Dana) is selected via the workflow `skills:` filter. A `skills:` filter MUST name the always:true grounding skills (`catalog_reader`/`grounded_analysis`/`it_vendor_management`) or `create_filtered_workspace` drops them.
- Wired into `procurement_intelligence` as the `analyze` role. Proven: same dataset that produced Dana's fabricated "11 POs / $7.85M" now returns correct grounded figures with SQL. See `memory/*procurement*`.

### Fail-closed artifact gate (`requires_artifacts`)

New engine feature: a step declares `requires_artifacts: [file.md]` in `workflow.yaml`. Even when the agent reports `STATUS: done`, `_finalize_step` (`cli_orchestration.py`) flips the step to **failed** (→ retry) if the file is missing/empty in the output dir, emitting `step.artifact_missing`. Stops the broken-handoff→hallucination chain (analyst never writes `intelligence_report.md` → strategist fabricates the gap). Wiring: `Step.requires_artifacts` (`engine/models.py`), parsed in both loader blocks (`engine/workflow_loader.py`), gate in `_finalize_step`.

### Presentation + dataviz decks (HTML-canonical, delivery-agnostic)

`agentfarm-skills/agentfarm_skills/skills/presentation/` + `.../dataviz/` (the separately-versioned shared-skills wheel) produce board-ready decks. **HTML is the single canonical form** — the reasoning-heavy authoring (layout taxonomy L1–L14, story arc, theming) is authored once as HTML, then rendered to **html / pdf / pptx**. Do NOT make pptx the authoring format (a python-pptx-native `deckbuilder.py` detour was tried and removed).
- **Static-layout contract (load-bearing for PPTX fidelity).** dom-to-pptx is a *coordinate scraper* — it maps computed on-screen positions to shapes and does NOT run scroll/animation JS. So `viewport-base.css` + `html-template.md` MUST stay: **fixed 1920×1080 slides, top-anchored block flow (never flex-center content), fixed-px type (never `clamp()`/`vw`), and opacity-only `.reveal`** (no `transform` → no layout shift). Only `.title-slide`/`.section-slide` may center (trivial content). Breaking this = drifting/overlapping shapes in the PPTX. Validated: agent decks now match a hand-authored gold standard (0 off-canvas, same left-margin grid).
- **Render backend:** `slides_export.js` renders the canonical HTML. **Dual-driver + OS-independent**: it launches Playwright (local dev) or Puppeteer (deploy pod), honoring `SLIDES_EXPORT_DRIVER` (`playwright`|`puppeteer`); the Dockerfile installs puppeteer + system chromium and pins `SLIDES_EXPORT_DRIVER=puppeteer`. Deps resolve via `depPaths()` (`~/.iobot/node_modules` + cwd/script ancestors + `NODE_PATH` + `module.globalPaths`) so `require()`/CLI work from any cwd on Windows or Linux. PPTX = dom-to-pptx v2.x (native editable shapes, SVG vectors); PDF = browser print; pptxgenjs screenshot fallback. **Reveal-flatten fix:** before the pptx scrape it injects `.reveal{opacity:1!important;transform:none!important}` — without it, animated content (tables, exhibits) is `opacity:0` at scrape time and DROPPED (0 native tables). ALWAYS verify: `python -c "from pptx import Presentation; assert len(Presentation(f).slides)>0"` — the old script silently produced 0-slide decks.
- **`dataviz`** is the full Claude Code dataviz method (vendored into the API repo by the user with a provenance note; NOT an official OSS release — do not re-vendor Anthropic proprietary skills unknowingly). Charts follow the form heuristic + color-by-job + the **runnable palette validator** (`scripts/validate_palette.py`, pure-Python, no Node — "compute colorblind-safety, don't eyeball"). Tables follow `references/tables-as-exhibits.md` (data bars, Harvey balls, heat, line-light). `presentation` R6/L6 defer to it.
- **`deck_build` workflow** runs a deck autonomously (strategist role, `requires_artifacts: [strategy.pptx]` gate). Decks are OPT-IN — kept out of the main pipeline.

### Deck authoring — the real blocker was `maxTokens`, NOT "MiniMax flaky"

For a long time the deck step failed with what *looked* like MiniMax flakiness (empty first response / `agent_premature_termination` / "[Assistant reply unavailable due to model error]"). **That diagnosis was wrong.** Controlled experiment (direct API calls + the forensic `http.log`) proved the real cause: `~/.iobot/config.json` had **`maxTokens: 125000`**. The Anthropic SDK **refuses a non-streaming request when `max_tokens` exceeds exactly 21,333** — *"Streaming is required for operations that may take longer than 10 minutes."* iobot runs non-streaming by design (`IOF_DISABLE_STREAMING`, kept for MiniMax stall-reliability), so **every compose turn was rejected**. Reads (cheap) succeeded; the first *generation* died → premature termination.

- **Fix: `maxTokens: 21333`** — the exact SDK non-streaming ceiling. Set in `entrypoint.sh` (pod) + local `~/.iobot/config.json`. `contextWindowTokens` corrected 180000 → **204800** (MiniMax-M2.x's real window).
- **MiniMax is NOT the bottleneck** — it supports ~196,608 output / 204,800 context (docs). Above 21,333 needs *streaming*, which the repo deliberately disables (stall tradeoffs). Sectioned composition keeps each write far under 21,333, so no truncation.
- `IOF_REQUEST_TIMEOUT_S=600` (`.env`, gitignored) gives slow compose turns headroom.
- With these, autonomous `deck_build` produces a **17-slide deck (PPTX + PDF) on attempt 1**.
- **Lesson (load-bearing):** when an LLM call fails, read the forensic `http.log` for the real status (400 / SDK `ValueError`) *before* concluding "MiniMax flaky." That conclusion was a lazy default that masked an ours-to-own config bug. `run-task` still lacks Fix 6 retry (workflow-only), but that's secondary to the config fix.

## File structure

**Paths below are relative to `agentfarm-core/`** (the SDK split moved them;
`ioagentfarm/cli.py` at the repo root does NOT exist). Domain content lives in
`solutions/<domain>/<pkg>/{agents,skills,workflows}/`, and there is no
`agents/_common/skills/` any more — a pack's content reaches an agent through
the `aicore.packs` entry point and the agent's skill-assignment record, not by
a copy-everything-to-everyone step. **`ioagentfarm/workflows/` exists again
since 2026-08-25 and holds ONLY the play tier's platform workflows**
(`playbook_compile` and `case_action`) — domain-free machinery that belongs
with the meta agent, `iof-plays` and `iof-case`, which already live in core.
The agent that runs them, `play_operator`, is a platform-shared role. This is
the one exception to "only workflows are solution-level". **`case_action`
names no deployment's tool:** its act step's allowlist is `["@deliveries"]`,
expanded by the engine to the tools the DEPLOYMENT declares for case
deliveries (`engine/deliveries.py`: `IOF_CASE_DELIVERIES` JSON >
`~/.iobot/workspaces/<code>/deliveries.yaml` > the packs' `deliveries.yaml`
via `Pack.deliveries`; `iof-case deliveries` shows what resolves), `iof-case
ctx` hands it the tool for the action, and `rulebook put`/`validate`/
`compile-stage`/`compile-approve` refuse a rulebook whose delivery kind has
no tool declared here — "every system a playbook reaches must resolve to an
asset the workspace holds" is a check, not a slide. **The scheduler delivers
as well as decides** (`dispatch_pending`, every pass): every undelivered
side-effecting decision gets its action workflow started once — the claim
a delivery run registers in `iof-case ctx` is what makes "once" true when
the Meta Agent also commissions.

```
agentfarm-core/ioagentfarm/
  cli.py                         -- typer CLI: setup, context, execution, tasks, status
  cli_scaffold.py                -- `new-solution`: scaffold a domain solution repo
                                    (also the ONE home of the shared templates)
  cli_pack.py                    -- `new-workflow`/`new-agent`/`new-skill`/`new-tool`: grow one
  cli_orchestration.py           -- step orchestration, recovery, _finalize_step
  channels/teams/                -- MS Teams: router, bot, state, cards, models, config
  web/
    app.py                       -- FastAPI server: endpoints, agent pool, lifespan
    spawn.py / runner.py         -- spawn_run(), LocalRunner, K8sRunner
    storage.py / sse.py          -- S3Storage, NoopStorage, SSE streaming
  engine/
    models.py                    -- pydantic: Workflow, Step, Role, StepTemplate
    hydration.py                 -- materialize-on-use: DB row -> local files, sync keys
    filecodec.py                 -- binary-safe encode/decode for DB-backed content
    catalog_sync.py              -- agents/workflows catalog sync (CLI + HTTP share it)
    db.py                        -- DbAdapter protocol + SqliteAdapter + PostgresAdapter
    store.py                     -- state store (runs, steps, stories, tasks)
    scheduler.py                 -- render_step_prompt() + step wrapper template
    workflow_loader.py           -- YAML loader + DAG validation
    workspaces.py                -- iobot_agent_workspace(), build_task_prompt()
    iobot_config.py            -- MCP config + per-run instance config + per-role model override
    templating.py                -- {{var}} template renderer (dot notation)
    protocol.py                  -- KEY:value output parser (whitelisted keys)
    learning_protocol.py         -- LearningBackend protocol (pluggable interface)
    learning_log.py              -- Layer 1: append-only observation log
    learning_store.py            -- Layer 2: learned skills with quality tracking
    learning_lifecycle.py        -- Facade combining both layers
  agents/{role}/workspace/       -- SOUL.md, skills/, memory/ (Jarvis, Quinn, Alex, play_operator …)
  workflows/{playbook_compile,case_action}/  -- the play tier's platform workflows (the ONLY core workflows)
  engine/deliveries.py           -- which tool a case action goes through: the deployment declares it
  packs.py                       -- pack registry: the `aicore.packs` entry-point seam
agentfarm-skills/agentfarm_skills/skills/   -- SHARED craft skills (own wheel): presentation, dataviz
solutions/{domain}/{pkg}/        -- a domain pack: agents/, skills/, workflows/, metadata/
apps/agentfarm-api|agentfarm-ui/ -- Studio backend + front end (installs NO packs; reads the DB)
aicore_docusaurus/               -- THE client documentation set (the only one)
ts-skills/                       -- TypeScript CLI tools monorepo (turborepo)
  vectorfs/                      -- vector DB-backed virtual filesystem CLI
```

### Shared code lives in `tools/`, never inside an agent workspace

**`agents/<role>/workspace/` is DATA** — copied per-agent into `~/.iobot/`,
lifecycle tied to that agent. **`ioagentfarm/tools/` is CODE** — one canonical
import path, shared by every agent and pack.

A skill-local helper with a single consumer and no entry point may sit beside
its `SKILL.md` (`dataviz/scripts/validate_palette.py` is fine). **The moment
something gets a `console_scripts` entry point, it belongs in
`ioagentfarm/tools/`** — an entry point *is* the declaration that it is shared.

This has bitten twice, and it is invisible at authoring time. `iof-query` and
`iof-s3` pointed into `agents/data_analyst/workspace/skills/data_query/…` and
`agents/analyst/workspace/skills/s3_access/…`. When fc24b22 deleted those two
obsolete agents, it silently killed shared tooling used by every pharma
workflow and by Jarvis — the entry points still resolved in `pyproject.toml`,
so nothing failed until a subprocess actually ran the binary. The six-level
import path made the dependency invisible to anyone reviewing the deletion:
the diff looked like "remove a dev-team agent," not "remove the query engine."
Both are now `ioagentfarm.tools.query_executor` / `…s3_tool`.

Corollary: **deleting an agent directory is not a self-contained change.**
Grep `[project.scripts]` for the path first.

## Template variables

Available in step prompts via `{{var}}` syntax: `goal`, `progress`, `step_output.<key>`, `story_id`, `run_id`, `attempt`, `max_attempts`, `workflow`, `step_key`, `role`, `project_dir`, `output_dir`, `workflow_dir`, `metadata_dir`, plus any keys from `vars:` in workflow.yaml.

### Per-workflow variables (`vars:`)
Workflows can define custom template variables in `vars:` that are available in all step prompts:
```yaml
vars:
  vectorfs_collection: VECTORFS_CONTRACTS_PROCUREMENT
  custom_key: custom_value
```
Use in step prompts: `{{vectorfs_collection}}`. Useful for per-workflow configuration (vector DB collections, API endpoints, feature flags).

## Key patterns & conventions

### Two-layer isolation (critical invariant)

```
Per-run instance (.iof/instances/<run_id>/)     via --config
  config.json, workflow/, workspaces/<role>/, logs/, cron/

Per-role workspace (~/.iobot/agents/<role>/workspace/)  via --workspace
  SOUL.md, memory/MEMORY.md, skills/, sessions/
```

- `--workspace` = per-role identity/memory/sessions (compounds across runs)
- `--config` = per-run MCP/logs/cron (isolated per run, no race conditions)
- `create_instance_config()` creates per-run config; `_invoke_agent()` passes both flags to iobot

### Workflow patterns
- **Identity files** (SOUL.md, AGENTS.md, TOOLS.md) are never templated — static personality. **Step prompts** ARE templated.
- **Role prompts (`roles[].prompt`) reach the model since 2026-08-27.** `Role.prompt` was loaded and read by NOTHING on the model path — every shipped `roles/*.md`, the swarm compiler's orchestrator persona included, had never influenced a turn, while `docs/reference/workflow-yaml.md` called it "the role's system prompt". It is now rendered with the step context (the shipped ones use `{{metadata_dir}}`) and lands as `## Role` in the step wrapper ahead of `## Goal`; a blank file contributes no section. Pinned by `tests/test_role_prompt_reaches_the_model.py`. Verify: `grep -n role_section agentfarm-core/ioagentfarm/engine/scheduler.py`. Related: `TOOLS.md` is still read by nothing in the runtime (`aicore context-report <role>` says so) — the runtime's identity list is exactly `AGENTS.md`/`SOUL.md`/`USER.md` plus `always: true` skills.
- **YAML roles** must be separate list items (YAML deduplicates mapping keys). Each role can specify `skills: [...]` to filter loaded skills and `model: "provider/model"` for per-role model override (falls back to `~/.iobot/config.json` default).
- **Fresh vs persistent sessions:** `fresh_session: true` (default) creates new workspace per attempt.
- **Loop steps:** type `loop` outputs STORIES_JSON, engine materializes per-story step rows as `story:<id>:<suffix>`.
- **Exec steps (2026-07):** type `exec` runs a `command:` directly — no agent, no LLM turns. Same `{{var}}` templating as prompts; `requires_artifacts` gate applies; stdout/stderr land in the step dir; failures retry fail-closed under the hard attempt cap (`IOF_EXEC_STEP_TIMEOUT_S` caps runtime). Optional `stories_from: <file.json>` reads the tool-written manifest's `stories` array so a deterministic tool can anchor a loop fan-out (`per_item_steps`) with no agent transcribing STORIES_JSON. `role:` optional (defaults `system`). Rule of thumb: *if the step's correct behaviour can be written as a script, it should be a script* — first user: signal_detection's `prepare_batches`.
- **Dependency rewiring:** Dynamic tasks inserted between emitting step and next backbone step.
- **Atomic claiming:** `claim_next_runnable_step()` uses `BEGIN IMMEDIATE` (SQLite) / `BEGIN` (PostgreSQL).
- **Bundled data:** `importlib.resources.files()` for package data; `.iof/workflows/` overrides take priority.
- **Workflow snapshot:** At run creation, the entire workflow directory is copied to `.iof/instances/<run_id>/workflow/`. All runtime step execution loads from this snapshot (not the package). This freezes the workflow per-run, enables S3 sync for horizontal scaling, and provides `{{workflow_dir}}` and `{{metadata_dir}}` template variables for OS-agnostic paths. Workflows can bundle `metadata/` (catalog.yml, entities/) for `data_query` contextualization.

### Skills are OPEN — a workflow resolves from the catalog (2026-08)

**The `roles:` frontmatter ELIGIBILITY GATE is gone. It is history — do not
describe it as current, and do not reintroduce a check that refuses a skill to
an agent.** It was default-closed and re-evaluated on every seed, which cost two
things: a workflow could only ever SUBTRACT from what an agent already carried
(naming anything else got a warning and silence), and because the rule ran
forever a removal made in the Studio was undone by the next
`ensure_agent_workspace`. What replaced it:

1. **Skills are open.** Any skill in a workspace may be assigned to any agent in
   it. No eligibility check exists in the engine, the API, or the Studio UI.
2. **An agent's assigned skills are its BASELINE** — set in the Studio
   (`studio_skills.roles_json`, maintained by `sync_carried_skills`) or by
   location in a solution repo (`agents/<role>/workspace/skills/`).
3. **A workflow step declares what the JOB needs**, resolved from the whole
   workspace catalog by `_resolve_skill()`, in order: **the agent's own
   workspace** (a local/tenant edit must not be re-based onto the wheel's copy)
   → **`studio_skills`** via `hydration.workspace_skill`, WITHOUT the
   `roles_json` filter (filtering there would put the gate back one layer down)
   → **the pack/SDK sources** (last, so an upgrade never displaces content the
   tenant owns). Nothing found = a warning naming all three.
4. **`output_protocol` is always added.** Not policy — an agent without it emits
   no `STATUS:`/`OUTPUT:`, so every step it runs is marked failed and retried.

`skills:` in workflow.yaml is therefore the EXACT set for that job: it still
drops every `always: true` skill it does not name, and it can now also name one
the agent has never carried. Full detail: `docs/reference/workflow-yaml.md`.

**Migration + the assignment record (`.skills-assigned.json`).** The baseline is
derived from the old `roles:` rule exactly ONCE per workspace
(`_legacy_default_assignment`, the only remaining reader of `roles:`) and is
authoritative afterwards, removals included. **That record is part of the
agent's DB row** — it is in `agent_defs._IDENTITY_FILES` and
`workspace_sync._AGENT_IDENTITY_FILES`, and excluded from the divergence hash
via `_AGENT_GENERATED`. This is load-bearing: pack/SDK skills deliberately have
no `studio_skills` row, so without it "this agent holds `presentation`" lived
only on one host's disk and a pod rebuilding from the database silently lost it,
re-deriving from the very rule that was removed. It stores **names only** —
content still comes from the wheel, so nothing freezes a fork. A skill's
`roles:` key is KEPT and is now only the *starting assignment* for a new
workspace; it gates nothing.

- `skills: null` (omitted) -> all the agent's skills load. `skills: []` -> output_protocol only. `skills: [x]` -> x + output_protocol.
- `create_filtered_workspace()` creates the per-run workspace. Memory persisted back via `persist_agent_memory()`.

### Multi-user isolation
- `user_id` format: `<channel>:<identifier>` (e.g., `cli:sudhir`, `telegram:12345`). Default: `cli:<os_username>`.
- Per-user active run in `user_context` table. Session keys appended with `:u:<user_id>`.
- Run ID resolution: explicit `--run-id` > `user_context` table > `.iof/active_run` file > latest active.

### Learning lifecycle - v2 is the default, and there are THREE states

**v2 is DEFAULT-ON with zero configuration.** Every variable below exists only to
DEVIATE from the desired state - no entrypoint line, no workspace `.env` line,
no machine env. Detail: `engine/learning/` and
[docs/learning-governance.md](docs/learning-governance.md).

**The trap: `IOF_LEARNING_V2=0` means learning OFF - it does NOT fall back to
v1.** v1 is deprecated and scheduled for removal, so opting out of v2 never
silently resurrects it. The legacy pipeline is an explicit TWO-key act:
`IOF_LEARNING_V2=0` **and** `IOF_LEARNING_V1=1`. (V1=1 while v2 is active is
ignored with a warning - the generations never run together.) `learning:
disabled` in workflow.yaml opts one workflow out of everything. Empty string ==
unset, because PowerShell deletes a variable assigned `""`.

**MEMORY.md is neither LOADED nor POPULATED under v2** - the `memory_v1_off`
runtime patch gates three surfaces at call time: the read returns "", the write
is a no-op (so a future writer or upstream feature cannot silently resume
populating), and the agent's own `memory/MEMORY.md` is refused with a message
telling it memory is hub-governed. Files are never wiped; unsetting the variable
restores everything. The runtime's periodic memory writer (the gateway-only
cron) is disabled in `entrypoint.sh` and the local config.

**What v2 captures.** The distiller types every candidate METHOD / PREFERENCE /
FINDING and **drops FINDING in code**; a second rail drops a method whose body
quotes the session's own figures. So a learned skill is transferable technique,
never a conclusion. Authoring is recurrence-gated, and a draft is inert until a
human approves it. **The WORKFLOW path bypassed that gate until 2026-09-05**:
`hooks.finalize_step` called `run_distillation` directly, so every completed
step paid a synchronous reviewer call inside `run-step` (13-29s measured,
which the agent driver blocks on) and authored from ONE occurrence. It now
takes the cheap `gate_decision` inline and, when the gate says author, runs
the reviewer in a DETACHED `aicore learning distill <job>` (the memory
consolidation pattern; the stub reviewer stays inline for tests), and two
vocabulary-free traces no longer count as a recurrence. Verify: `grep -n "gated_distill\|run_distillation(" agentfarm-core/ioagentfarm/engine/learning/hooks.py`.

**The channel is a trust boundary, scanned at BOTH seams** with shared code
(`engine/learning/skill_scan.py`): the distiller drops a dangerous DRAFT, and
`ingest_hub_skills` REFUSES a dangerous APPROVED skill. An approved skill is
injected into agent context, so a dangerous body is a prompt-injection vector
wearing a method's label.

**Steward review:** `aicore learning pending|show|approve|reject|audit`. It
re-scans at approve time, so a DANGEROUS draft CANNOT be approved; decisions
append to an audit trail. **`IOF_LEARNING_INBOX_DIR`** repoints the
approved-skill store at a GIT repo, making approval a reviewed commit - both the
reader and the writer resolve it through `hub_client.inbox_base()` so they
cannot diverge.

**The bug worth remembering: "materialized" is not "loaded".** Ingest wrote
`skills/learned/<name>.md` (flat) while the runtime's loader discovers
`skills/<name>/SKILL.md` (dir-per-skill). Every approved skill landed where no
agent could load it: injection recorded, attribution counted, ZERO turns
influenced. A/B afterwards: not loadable -> 1/6 fingerprint terms; loadable ->
6/6. **Validate the CONSUMER - the runtime's own loader - not just that a file
was written.**

**`iof-recall`** wires the previously dead cross-run FTS over STEP OUTPUT
(scope-isolated, never memory - no pollution), indexed incrementally at finalize
with a `--reindex` backfill.

### Workspace memory — the CONTEXT tier (2026-08-28)

Learning v2 keeps METHOD and PREFERENCE and drops FINDING; CONTEXT — durable
facts about the tenant's world an agent re-discovers every run — had no home.
**Workspace memory is that home**: Dream's method (SNIP filter, consolidate
against the embedded current state, prune as deliberately as add, advance the
cursor only on a real change) on a new mechanism. Reference
[docs/reference/workspace-memory.md](docs/reference/workspace-memory.md); code
`agentfarm-core/ioagentfarm/engine/memory/`; CLI `cli_memory.py`.

**Three tiers:** curated `solutions/<ws>/memory/` (`Pack.memory`, routed by
path — `workspace/`, `role/<r>/`, `user/<id>/`, `solution/<c>/`, top-level
file = workspace; carried WHOLE as `doc` rows, rails skipped, scan applied),
curated `~/.iobot/workspaces/<code>/memory/` (same layout), and the store
(`workspace_memory` + `_history` + `_runs` + `_settings`; DDL at the tail of
`scripts/setup_schema.sql`). **Pipeline:** run → `done` → `hooks.on_run_completed`
(once, on the WON transition) → detached `aicore memory consolidate --run` →
runtime SNIP prompt + scope addendum → deterministic rails (finding-drop, PII
redaction, the learning channel's `skill_scan`) → ADD/REPLACE/DROP/RETIRE
against the CURRENT active set (deterministic plan without a model) → drafts
(`review`) or active (`auto`). Chat turns on served agents are extracted too.

**System position:** ONE session-stable block, materialized as
`memory/WORKSPACE_MEMORY.md` (version-gated cache of the DB) and rendered by
the `memory_v1_off` patch into the runtime's memory slot — never the user turn,
because a memory injected as a message reads as an instruction (the plugins
that did it recorded agents overriding their safety gates). **The claim
table** (`workspace_memory_runs`, `INSERT OR IGNORE`, worker `<host>:<pid>`,
stale after `IOF_MEMORY_STALE_CLAIM_S`=600) makes consolidation exactly-once
across pods; the serve-lifespan sweep (`IOF_MEMORY_SWEEP_INTERVAL_S`=300, or
`aicore memory sweep`) takes over stale claims, expires ephemeral rows and
re-syncs the curated tiers and retries a `failed` claim up to
`IOF_MEMORY_MAX_ATTEMPTS`=3; past that, `consolidate --run <id> --force`.
**Recency is an axis, not an order:** every row carries `source_at` (the
run's own creation time), a candidate that conflicts with an active row from
a NEWER source is `stale` and never stored, and the sweep walks the backlog
oldest-first — the chaos harness found four of four corrections reversed
before this existed. **Posture defaults to `review`** because an injected row is an
instruction to the model whether labelled one or not; `IOF_MEMORY_POSTURE`
fills only a workspace with no row. **Gate:** `IOF_MEMORY` (default on).
**CLI:** `aicore memory status|list|show|pending|approve|reject|forget|add|consolidate|sweep|sync|posture|history|render`.

**Two traps.** (a) `MEMORY.md` and `WORKSPACE_MEMORY.md` are different things:
the first is v1's retired per-agent conclusions channel (still gated off), the
second the workspace's reviewed context, rendered into the SAME memory slot;
both are refused at the fs-tool write resolver. (b) The extractor uses the
deployment's model through the harness provider path — `IOF_MEMORY_EXTRACTOR=stub`
is for tests and the chaos harness; `off` disables extraction but NOT injection.
**`solution:<code>` rows DO reach a step** — the run path passes
`solution_for_workflow(...)` into `provision_step_workspace`, so a row lands
in the step's memory block and thus the system prompt, for workflows of that
solution only (chat turns resolve no solution and correctly do not get it).
This section said the opposite, sourced from a backlog entry that had been
overtaken; an independent validator disproved it from a step's own `http.log`.
The rule this file opens with applies to this file: **the code wins.**
**Verify:** `grep -n "solution=_memory_hooks.solution_for_workflow" agentfarm-core/ioagentfarm/engine/workspaces.py`;
`aicore memory status`;
`grep -n "WORKSPACE_MEMORY" agentfarm-core/ioagentfarm/_iobot_patches.py`;
`grep -n "run.memory_queued" agentfarm-core/ioagentfarm/cli_orchestration.py`.

### Three guards that could not answer the question they were asked (0.6.2, 2026-08-03)

All three found by USING the product on a client deployment, not by reading it.
Each is a condition that looks right, is scoped wrong, and fails silently. They
are grouped because the shape repeats and the next one will look the same.

**1. `sitecustomize` carries the runtime PATCHES, not just the logging.** It is
the only thing that applies them inside the spawned agent subprocess — the
provider swaps, `dedup_tool_call_ids`, `disable_streaming`,
`restrict_agency_tools`, the `_FsTool` allowed-dirs fix. Injection sat inside
`if forensics_dir is not None and not IOF_DISABLE_HTTP_FORENSICS`, coupling it
to logging it has nothing to do with. Two costs: a spawn with no forensics dir
(`agent-chat` without a run) ran STOCK iobot, so an Azure tenant on the
classic `/chat/completions` surface was answered by the bundled provider aiming
at the v1 Responses preview; and `IOF_DISABLE_HTTP_FORENSICS=1` — a flag about
log noise — silently changed which LLM provider class every step agent used.
The shim is now injected ALWAYS (`<IOF_ROOT>/_iof_logging_inject/` when there is
no run); only `IOF_HTTP_LOG_FILE`/`IOF_USAGE_FILE` stay conditional. **`ioagentfarm
patches` reports the CLI's own interpreter, not the child** — to check the
subprocess, run
`python -c "import ioagentfarm; from iobot.providers import azure_openai_provider as m; print(m.AzureOpenAIProvider.__name__)"`
(`AzureOpenAIChatProvider` = patched).

**2. A second tenant got no shared-skill rows.** `ensure_agent_workspace` wrote
the assignment only when `.skills-assigned.json` moved — a file under
`agent_home_root()`, ONE shared tree, while the row it guards is per-workspace.
Seeding the same agent into another tenant found the record unchanged and wrote
nothing, so the tenant's catalog listed no SDK skills at all. The memo is now
keyed `(database, workspace_code, role)` — and the DATABASE is in the key
because the first version answered "already written" about a row in a database
it had never seen. Any future memo over a workspace-scoped write needs both.

**3. `agent-chat --local`.** Which path the command took was decided by whether
a run resolved, and the fallback is *the newest active run for this user* — so
on a deployment with runs in it, "does my new agent work?" became a call to an
engine that may not be listening (`Cannot reach gateway at
http://localhost:8111` — that is the ENGINE's port, not the Studio API's).
`--local` skips the run lookup entirely, so it needs no database either;
`--local` with `--run-id` is refused rather than silently resolved.

### Every package-dir-mapped directory needs an `__init__.py` (2026-08-30)

**A CLIENT'S FIRST WALKTHROUGH DIED ON THIS, and it is invisible on most
machines.** `memory/` was mapped in the scaffold's `pyproject.toml` like
`agents/`, `skills/` and `tools/`, but was the only one without an
`__init__.py`. That makes it a NAMESPACE package, and setuptools' editable
install then routes it through `_EditableNamespaceFinder`, which **always
appends `PATH_PLACEHOLDER`** to the search path (its own comment: "__path__
cannot be empty for the spec to be considered namespace"). The placeholder is
a string, never a directory, and `MultiplexedPath` refuses any portion that
is not a directory:

    NotADirectoryError: MultiplexedPath only supports directories

Every content root resolves inside one `pack()` call, so ONE optional
directory took agents, skills, tools and workflows down together — and the
next message the user saw was *"No installed pack provides an agent named
'chat_advisor' … Install the pack that ships this agent"*, about a pack they
had installed correctly. They read it as "did I miss pip install".

**Why ten novice rounds missed it: two finders are generated, and which one
answers is `sys.meta_path` ordering, which varies by setuptools version.** On
this repo's venv the MAPPING finder always won, so the same tree worked here
and failed there. Every instrument shared one interpreter; `client_simulation.py`
builds a fresh venv but installs the SDK editable from the repo and never runs
`workspace scaffold`. And every test asserted the SOURCE TREE — the defect
lived in the INSTALL ARTEFACT, a generated finder file nothing had read.

**The invariant, pinned by `test_a_broken_pack_is_not_a_missing_agent.py`
(proven non-vacuous against the old scaffold): every directory named in
`[tool.setuptools.package-dir]` must be a regular package.** Then no namespace
finder is involved on any setuptools version. Three defences behind it:
`packs.content_root()` (an OPTIONAL root that will not resolve is treated as
empty, never fatal — REQUIRED roots still raise), `packs.broken_packs()` (the
agent-not-found error consults it and stops blaming the install), and a
message that splits the two `MultiplexedPath` errors, which have OPPOSITE
fixes — `FileNotFoundError` means create the directory, `NotADirectoryError`
means the directory is fine and needs an `__init__.py` plus a REINSTALL.

Fix for a repo already in the field: `type nul > memory\__init__.py` then
`pip install -e .` — the reinstall regenerates the finder, and without it the
fix appears not to work.

### `OTEL_EXPORTER_OTLP_HEADERS` values are URL-encoded

`Authorization=Bearer <key>` — the form every vendor documents — makes the SDK
reject the WHOLE string and return no headers, so the exporter builds,
connects and posts every span **unauthenticated**. It presents as 401/403,
i.e. as a bad key. Write `Bearer%20<key>`. `aicore otel check` now DETECTS
set-but-parses-to-nothing (`cli_otel._headers_that_do_not_parse`); its 401/403
branch used to recommend the spelling that caused it.

### The wheel is not the source tree

`setuptools`' `build_py` copies source files that are NEWER into `build/lib` and
never removes ones that DISAPPEARED, so a deletion does not propagate: four
vendored skills were dropped, the tree agreed, `vendor.py --check` passed, and
the wheel shipped all four. Nothing catches it downstream — CI builds from a
fresh clone where no `build/` exists, so the pipeline is green and the wheel a
developer publishes from a working tree is the wrong one. `scripts/local_pypi.py`
now removes each dist's `build/` first; any other build path must too.

Corollary: **a version bump is part of the change, not paperwork.** `iobot`'s
content once changed under a fixed version, which is exactly what pinning exists
to prevent — pip would not have replaced an installed copy. The runtime is
`0.4.0+io.1` since the rename (2026-09-04) and the pin in
`agentfarm-core/pyproject.toml` moves with it. The literal lives in more places
than it should (3 for core, 2 functional pins plus prose for iobot); collapsing
them to one source of truth is open work.

### Cross-platform invariants (Windows local dev)

Two subtle root-cause fixes that are easy to break and hard to diagnose. Both exist because iobot was designed for Linux containers and leaks platform assumptions when run locally on Windows/Git Bash.

**1. Windows env recovery — `ioagentfarm/__init__.py`**
iobot's `ExecTool` strips subprocess env to `{HOME, LANG, TERM}` for security. On Linux that's enough for Python's stdlib, but on Windows `pathlib.Path.home()`, `os.path.expanduser("~")`, and `getpass.getuser()` need `USERPROFILE` / `USERNAME`. Without them, any nested subprocess (web → Alex → exec → `ioagentfarm run-step` → iobot agent) crashes with `RuntimeError: Could not determine home directory` or `ModuleNotFoundError: No module named 'pwd'` before any real work begins. The package `__init__.py` runs `_recover_windows_env()` at import time, deriving `USERPROFILE` / `USERNAME` from `HOME` (converting `/c/Users/Foo` → `C:\Users\Foo`). Idempotent, no-op on Linux. **Do not move or delete this bootstrap** — it must run before any other stdlib call.

**2. Byte-level stream reader — `ioagentfarm/cli.py` `_invoke_agent`**
iobot uses `Rich Live` (auto_refresh=False, force_terminal=True) to stream LLM output. On every token delta it redraws the entire buffer. On Linux, Rich uses CSI cursor-up sequences that appear inline within a single `\n`-terminated line. On Windows/Git Bash, Rich uses bare `\r` carriage returns to rewind the current line during in-place updates.

`_invoke_agent` reads `proc.stdout` as **raw bytes** (not text mode) and interprets the stream as a terminal:
- `\r\n` → CRLF line ending: emit the buffer
- bare `\r` (cursor rewind, Windows only) → clear the buffer; the next render overwrites it
- bare `\n` → LF line ending: emit the buffer
- ANSI escape sequences stripped before emit
- `_saw_cr` state spans chunk boundaries so a `\r` at the end of one chunk and `\n` at the start of the next still forms a valid CRLF pair

**Do not switch this back to `text=True` line iteration.** Python's universal newlines translates bare `\r` → `\n`, which destroys the distinction between "end of visual line" and "rewind cursor to overwrite" — producing multi-x duplication of each visual line in the messages table on Windows. The fix is structural (respect the data model), not a dedup heuristic.

### DESIGN PRINCIPLE: AgentFarm is a resilient harness — transient failures are EXPECTED, not bugs

> **The definitive, customer-shareable statement of this architecture — layers, failure catalog, guarantees, chaos-validation evidence — is [docs/RESILIENCY.md](docs/RESILIENCY.md).**

**Read this before "fixing" any run failure.** AgentFarm is a *resilient agent harness*. Transient failures — LLM stalls, MiniMax `duplicate tool_call id` / empty-text / premature termination, exec timeouts, a `run-step` overrunning the model-set exec timeout, RDS/Postgres connection drops — are **expected events the harness is designed to absorb, NOT bugs to prevent one-by-one.** The entire forensics + Fix-5/6 auto-retry + poll-until-done recovery + hard-attempt-cap + resume-from-where-you-left-off architecture exists *because* these WILL happen in a distributed LLM system.

Consequences for anyone (human or agent) working on this repo:

- **Do NOT kill a live run at the first transient.** Killing it cuts off the exact recovery the harness is built to perform. Let Fix-6 / poll-until-done ride it out; the hard-attempt-cap (`IOF_HARD_ATTEMPT_CAP_MULTIPLIER`) guarantees the run converges to `done` OR a clean `step.hard_cap_reached` failure — never truly infinite. What can look like a "hang" (Alex sleeping 30s and re-polling `is-recovering`) is usually the recovery loop *working*, not a bug.
- **A step exceeding the exec timeout is benign by design.** MiniMax often sets `timeout: 300` on its own `run-step` exec call (a model choice, not a iobot/config default — config `tools.exec.timeout` is 3600). The exec "times out" but the run-step subprocess keeps running; the orchestrate skill then polls `next-step` every 30s until `done`. A >300s step (e.g. analyze ≈ 331s) completing this way is normal — do NOT "fix" it by forcing timeouts.
- **Never conclude "MiniMax flaky" / "it's broken" from a symptom.** Read the forensic `http.log` / session snapshot / `exit.json` for the real status FIRST. (This same lazy-default warning appears throughout this doc — it keeps being the root of misdiagnosis.)
- **DO fix genuine underlying root causes — that is encouraged, not forbidden.** "Failures are expected" is NOT "never fix anything." When a failure has an avoidable root cause (missing Postgres keepalives → RDS idle drops; no connection recycle; a resource leak; a real protocol bug), *fix it at the source* — e.g. the pool keepalives + validate-and-recycle-on-checkout in `engine/db.py`. Reducing the *rate* of avoidable transients makes the system better and takes load off the recovery layer. Resilience absorbs the **residual, unavoidable** transients; it is not an excuse to leave real defects in place. The two work together: fix root causes AND trust the harness for the rest.
- **What is NOT a "fix": fighting the recovery itself.** Killing a live run mid-recovery, mistaking the poll/retry loop for a hang, or forcing timeouts to "prevent" a benign >300s step — those attack the resilience, not a root cause. The line: fix defects that *cause avoidable failures*; never disable/short-circuit the machinery that *absorbs expected ones*.
- **Validate resilience by CONVERGENCE, not by preventing failures.** The honest test of "does this work here" is: run the pipeline through Alex end-to-end and *do not intervene* — confirm it ends in `done` or a bounded `hard_cap_reached` with a forensic trail. (This is about not fighting recovery — it does not conflict with fixing root causes between runs.)

### Critical knowledge: iobot + reasoning model failure modes

Running on a reasoning model that emits `thinking` blocks (MiniMax-M2.x here),
iobot's stream consumer has two failure modes that look like network problems
and are not. **Full reference: [docs/forensics.md](docs/forensics.md)** - read it
before touching `cli.py:_invoke_agent`, `cli_orchestration.py:run_step` or
`engine/forensics.py`. The first resort for a run question is
`aicore forensics explain <run_id>`.

**1 - single-shot composition stalls.** A step asking for a large deliverable in
one `write_file` hangs and dies on a 90s stream watchdog. Fix: **sectioned
composition** - write per-section temp files, then assemble with `exec cat`.
Each write stays well under the threshold. Validated: single-shot returned 0
chars after 700s; sectioned returned 47KB across 11 calls in 495s.

**2 - `Error calling LLM: Connection error` mid-stream.** The model streams
`thinking` + `tool_use` with no `text` block, or drops the SSE connection, and
the agent loop records the error as its final turn and exits rc=0. Defence in
depth: **(a)** step prompts instruct the agent to print a line of text before
EVERY tool call - drops failure from ~65% to ~5% per call, and `lint-workflow`
warns when a step prompt has lost that rule; **(b)** Fix-6 auto-retry in
`run_step` detects the error in the post-exit session and retries within the
same step, preserving the failed attempt's blobs.

**The lazy diagnosis to avoid.** "MiniMax is flaky" masked an ours-to-own config
bug for a long time: `maxTokens: 125000` while the Anthropic SDK refuses a
NON-streaming request above exactly 21,333. Every compose turn was rejected;
reads succeeded, so only generation died. **Read the forensic `http.log` for the
real status before concluding anything about the provider.** `maxTokens: 21333`
is the ceiling, set in `entrypoint.sh` and the local config.

**Hard cap on attempts.** `IOF_HARD_ATTEMPT_CAP_MULTIPLIER` (default 2) refuses
to spawn past `max_attempts * 2 + 1` and emits `step.hard_cap_reached`. The
driver is an LLM and does not reliably obey "never retry more than once" - this
is the only thing bounding runaway retries. **Do not remove it.**

**Retirement experiments already run, negative - do not repeat without changing
the deployment.** `IOF_DISABLE_STREAMING=true` stays: streaming-on doubled
wall-clock and tripled tool calls, and stall durations grew 3-6x. The
`IOF_REQUEST_TIMEOUT_S` wrap stays: the runtime has only a per-chunk idle
timeout, no whole-call one.

**Forensic blob layout** (`.iof/instances/<run_id>/forensics/attempts/<step>.<attempt>/`):
`prompt.txt`, `env-snapshot.json`, `stdout.log`, `stderr.log`, `http.log`,
`exit.json`, `session-snapshot.jsonl`, `output-md-snapshot.txt`,
`inflight/session-<HHMMSS>.jsonl`, `stall_attempt_<n>/`. Plus the event timeline
in `iof.forensic_events`. CLI surface in `cli_forensics.py`.

### Web scaling
- Workflow execution -> subprocess per run (OS-level isolation: separate memory, separate crash domain, and a run can be resumed on any pod)
- Follow-ups -> in-process agent pool via `process_direct()` (bypasses lock)
- Horizontal: PostgreSQL shared state, S3 artifacts, mostly stateless (sticky only for SSE streaming)

#### Sticky session map

| Operation | Sticky? | Why |
|-----------|---------|-----|
| Run follow-up (`POST /api/run/{id}/message`) | **No** | Fork-on-first-chat + S3 session recovery |
| Always-on chat (`POST /api/chat/{ns}`) | **No, with `IOF_STORAGE` set** | Pull-and-invalidate before the turn, push after (`web/chat_session_sync.py`) |
| Spawn run (`POST /api/run`) | **No** | Fire-and-forget subprocess, result in DB |
| Spawn task (`--background`) | **No** | Fire-and-forget subprocess, result in DB |
| Resume (`POST /api/run/{id}/resume`) | **No** | Pulls from S3, re-spawns on any pod |
| Status / task-list / run detail | **No** | All from PostgreSQL |
| SSE streaming (`GET /api/run/{id}/stream`) | **Yes** | Reads from local subprocess stdout |
| Status check (process liveness) | Partial | DB status any pod; PID check pod-local |

**THE ALWAYS-ON CHAT SURFACE HAD NO SESSION SYNC AT ALL, and this table said
it was safely non-sticky (2026-08-29).** Every sync in the engine - three in
`send_message`, one at step completion - was on the RUN path; `POST
/api/chat/{ns}`, the endpoint the Studio, the walkthroughs and every chat UI
use, appeared in none of them. Two pods each kept a private copy of a
conversation. A validator reproduced it in three turns: pod 1 answered *"the
only code provided so far"* about a fact pod 2 had been told, then OVERWROTE
the file, destroying it. `web/chat_session_sync.py` now pulls before a turn
and pushes after - and INVALIDATES the runtime's cached `Session`, which is
the half that makes the pull mean anything: `SessionManager` caches Session
objects, so a warm pod otherwise downloads a file it then ignores.

**THE RUN PATH'S FORK AND PUSH WERE DEAD TOO, SINCE THE RUNTIME MOVED TO
BASE64 SESSION STEMS (found 2026-09-05).** The fork looked for
`iof_<run>_<step>_u_<uid>.jsonl` in the ROLE'S HOME: a name the runtime no
longer writes (the `_` spelling is its legacy read fallback) in a directory
a step never writes to (a step's session is in
`instances/<run>/workspaces/<role>/sessions/`). So `exists()` was False on
every host, every run chat logged "No step session to fork" and started
blank, and the same guard in front of the S3 push meant a run's `sessions/`
prefix held ZERO objects after a full run and three chat turns - the row
above was not true. `engine/step_sessions.py` is now the ONE resolver for
the fork, the step-completion push and the after-reply push; it matches by
DECODING stems (the user id in a step's key varies with which process
spawned the step), pushes a step under a canonical object name, and picks
the newest DONE step for the role, which is what the Studio shows. Proven
live: a new thread quoted the gate JSON that exists only in the step's tool
result. **Verify:** `grep -n "forked\|No step session" <engine log>` on a
fresh thread; `tests/test_run_chat_forks_the_step_session.py` pins the
encoding equal to the runtime's own.

**It is not serialisation.** Two turns on one session reaching two pods in the
same second still race, last writer wins. That needs a conditional put or a
per-session lock. The honest claim is "safe for ordinary pod scaling"; if you
need serialised turns, route `/api/chat/*` stickily on `user_id`.

Session JSONL files are pushed to S3 after step completion and after each chat reply. On first chat, the step's session is forked per-user — multi-user, multi-channel, multi-pod safe. Jarvis uses only non-blocking commands (`--json`, `--background`, `agent-chat`). See `docs/horizontal-scaling.md`.

### Output protocol
```
STATUS: done|failed
OUTPUT: <result text>
```
Optional (project_lead only): `STORIES_JSON: [...]`, `TASKS_JSON: [...]`
Protocol parser whitelist: only STATUS, OUTPUT, STORIES_JSON, TASKS_JSON, STDERR recognized.

## ts-skills — TypeScript CLI tools for agents

Turborepo monorepo at `ts-skills/` providing CLI tools that agents invoke via exec. Agents learn to use these tools through skill `.md` files in their workspace.

| Package | CLI binary | Purpose | Skill |
|---------|-----------|---------|-------|
| `@ts-tools/vectorfs` | `vectorfs` | Read-only filesystem over vector DB (Chroma, Qdrant, Pinecone, Weaviate, pgvector) | `vectorfs_query/SKILL.md` |

**Why TypeScript CLIs instead of Python?** These tools use the Node.js ecosystem (just-bash, vector DB client SDKs) and run as standalone binaries. Agents call them via exec — same as `iof-query` (Python). Language doesn't matter; the CLI interface is what agents see.

**Skill convention:** Each CLI tool has a corresponding `skills/<name>/SKILL.md` in the agent workspace. The skill teaches the agent *when and how* to use the CLI — not the command syntax (the LLM already knows Unix commands).

See `docs/ts-skills.md` for architecture and rationale.

## CLI-tool provisioning — `cli-hub` (declarative, setup-time validate-or-install)

> **CLI TOOLS ONLY — this is NOT about MCP tools.** A *CLI tool* is a shell
> executable an agent invokes through iobot's `exec` (`vectorfs`, `iof-query`,
> the deck-export Node deps). An *MCP tool* is a server the runtime launches and
> speaks JSON-RPC to (wired per-run in `engine/iobot_config.py`, `mcp-add`/
> `mcp-list`) — a completely different execution model. Never route MCP servers
> through `cli-hub`/`tools.yaml`, and never call these CLI tools "MCP tools".

**Problem this solves.** A skill only *names* its CLI tool (e.g. `vectorfs_query/
SKILL.md` says "run `vectorfs …`"); something else must actually put that binary
on PATH. Historically that was an imperative, hidden step in the Dockerfile
(`npm link -w vectorfs`, `npm install -g puppeteer …`) — so a pure
`pip install`-based domain deployment silently depended on the shared container.
`cli-hub` makes it **declarative and self-describing**: a pack declares the CLI
tools it needs; core provisions them at setup time.

**Ownership tiers (mirror the 3-tier skills model).** Each tool's `owner`:
`core` (ships with agentfarm-core), `shared` (a separately-versioned shared-tools
dependency — the tools analogue of the `agentfarm-skills` wheel), `domain` (the
pack's own), `cli-hub` (fetched from the org hub — tabled). Orthogonal
`installer` (the gap-fill *mechanism*): `pip` | `npm` | `npm-global` | `brew` |
`build`.

**The manifest — `tools.yaml` per pack** (read generically by core, domain-free,
like `inject.yaml`). Core declares its own in `agentfarm-core/ioagentfarm/
tools.yaml` (`iof-query`, `vectorfs`); a domain pack ships its own (procurement:
`deck-export`). Wired via `Pack.tools` + `PackRegistry.tools()`; a pack's `pack()`
loads its YAML (`_core_cli_tools()` / `_load_cli_tools()`). Fields:
`name · owner · installer · bin · package · check · build{repo,ref,subdir,steps}`.

**The resolver — `ioagentfarm/tools_resolver.py`.** Per tool, **validate-first**
(`shutil.which(bin)` or run `check`) → already present → `ready`, no-op (the
Docker-baked / prior-setup case). Missing → install the gap via `installer`.
Preflight exit codes: **0 all present · 3 gaps · 1 error**.

**Commands.**
```bash
ioagentfarm cli-hub list                 # declared tools + current presence
ioagentfarm cli-hub check                # validate-only (container/CI: fast no-op, fails on a missing baked tool)
ioagentfarm cli-hub install              # validate-or-install the gaps
ioagentfarm cli-hub install --dry-run    # show the plan (incl. build recipe), no changes
ioagentfarm cli-hub install --allow-build --only vectorfs   # opt into build-from-source
```
The resolver runs automatically at `serve` boot (host preparation);
`cli-hub check` / `install` are the by-hand entry points. (`setup-agents`
no longer runs it — that command is a stated no-op; see the One Truth
section.)

**`installer: build` — build-from-source (for tools with no registry artifact).**
`@ts-tools/vectorfs` is TypeScript/Node and **not published to any npm registry**
(`npm install -g @ts-tools/vectorfs` 404s) — it exists as source at
`ts-skills/vectorfs/` and is compiled + linked. So it declares a `build` recipe
instead of a `package`:
```yaml
- name: vectorfs
  owner: core
  installer: build
  bin: vectorfs
  build:
    repo: "git+https://<org-git>/agentfarm/ts-skills.git"   # git URL or local path
    ref: "v0.2.0"
    subdir: "."
    steps: ["npm install", "npx turbo build --filter=@ts-tools/vectorfs", "npm link -w vectorfs"]
```
Source resolution: `AGENTFARM_TOOLS_SRC_ROOT` (dev: a local checkout) →
`build.repo` git-cloned into `$IOF_ROOT/tool-src/<name>` → (owner `cli-hub`) a
hub-served recipe. **The executor is identical regardless of where the recipe
came from** — that's how a cli-hub tool builds locally when Docker didn't provide
it. It runs **only when validate says provably-absent**, so a baked-in / already-
built tool never rebuilds (idempotent).

**SECURITY / opt-in.** Build steps run arbitrary shell = code execution, so
building is gated behind `--allow-build` / `AGENTFARM_ALLOW_TOOL_BUILD=1` and
should target only trusted org-internal sources. This is the trust/provenance
seam a signed cli-hub + sandbox policy must eventually gate (see the "clawhub"
future-work notes in project memory).

**To build vectorfs locally (dev, no container):**
```bash
AGENTFARM_TOOLS_SRC_ROOT="$PWD/ts-skills" \
  ioagentfarm cli-hub install --only vectorfs --allow-build
# → gap → npm install && turbo build && npm link → installed+validated
# re-run → ready (no rebuild)
```

**GAP — the org cli-hub integration is NOT built (reserved seam only).** This is
the one deliberately-unfinished piece; do not assume `owner: cli-hub` downloads
anything today. Current behavior: a `cli-hub`-owned tool returns a *gap* —
`tools_resolver.py` literally says `"cli-hub source not wired yet
(AGENTFARM_CLI_HUB_URL=…); install manually"` (and `"cli-hub build recipe fetch
not wired"`). What EXISTS is the foundation the hub plugs into: the `tools.yaml`
schema, the `cli-hub` owner tier, the reserved `AGENTFARM_CLI_HUB_URL` env var,
and the install/build **executor** (which runs whatever recipe it's handed —
inline, git, or hub-served: identical code path). What's MISSING for a real hub:
(1) a **hub client** — GET a registry index/entry by tool name from
`AGENTFARM_CLI_HUB_URL`; (2) **artifact fetch** — download the tarball / clone
the source into `$IOF_ROOT/tool-src/`; (3) the **hub server** itself (org-hosted
registry + artifacts); (4) **auth** (npm token / git creds / hub API key);
(5) **trust/provenance/signing** — verify the fetched recipe BEFORE executing it,
load-bearing because `installer: build` runs shell = RCE; (6) lockfile/pinning/
offline cache.

**By construction this is CLI-Anything-compatible** (HKUDS/CLI-Anything — the OSS
"CLI-Hub" model): their `registry.json` entry `{name, install-source
pip/npm/brew/bundled, package, bin}` maps 1:1 onto our `tools.yaml`
`{name, owner, installer, package|build, bin}`; their `cli-hub install`/`matrix
preflight` map onto our `cli-hub install`/`check`. So once
`AGENTFARM_CLI_HUB_URL` + a hub client land, a missing tool flows: `GET
{HUB_URL}/registry.json → find entry → hand {installer, package|build, bin} to
the SAME executor → install/build → validate` — **no change to packs or the
executor.** Just fill the two "not wired" seams (add the provenance check
alongside the fetch, not after). NOTE the one deliberate difference: we resolve
at **setup time** (validate-or-install); CLI-Anything installs **on-demand at
agent runtime** — that mode is additive (same resolver, called later), also tabled.

**Also tabled:** the clean end-state for `vectorfs` is to publish
`@ts-tools/vectorfs` to the org npm registry, flipping it from `installer: build`
to `installer: npm` (the exact move `agentfarm-skills` made for shared *skills*).

## MCP tools & external A2A agents (2026-08-06)

Full docs: [docs/mcp-integration.md](docs/mcp-integration.md) +
[docs/a2a-integration.md](docs/a2a-integration.md); runnable validation bench:
`examples/mcp-a2a-lab/` (sample MCP server + sample external A2A agent).

- **MCP is iobot-native; we only plumb declarations.** Three tiers, higher
  wins by server name, WHOLE-ENTRY replacement: pack `<pkg>/mcp.yaml`
  (`Pack.mcp_servers` / `load_mcp_servers` / `PackRegistry.mcp_servers()`,
  first-pack-wins) → global `~/.iobot/config.json` → workspace
  `~/.iobot/workspaces/<code>/mcp.yaml`. Merge lives in
  `engine/iobot_config.py` (`merged_mcp_servers` / `effective_mcp_servers`);
  `create_instance_config` now MERGES instead of writing `mcpServers: {}` (the
  old line silently disconnected every server from every run), and
  `web/app.py` passes `mcp_servers=` to `AgentLoop` — the kwarg the loop
  actually reads; `ToolsConfig.mcp_servers` is ignored by it. A server
  referencing an unset `${VAR}` is DROPPED loudly at merge (left in place,
  iobot's `resolve_config_env_vars` raises at startup and kills the whole
  run); refs stay unexpanded on disk everywhere. `enabled: false` (extension
  key, stripped before write) suppresses a lower tier's server;
  `enabledTools` narrows one. Skills (`new-skill --mcp-server`) are judgement
  docs, NOT connection gates — all merged servers connect for all agents in
  scope. Containers: `IOF_MCP_SERVERS` JSON env in `entrypoint.sh`.
- **MCP AUTH: A STATIC HEADER, OR A CLIENT-CREDENTIALS GRANT THE RUNTIME
  PERFORMS (2026-08-21).** It was static-header-only, and a server behind
  OAuth could not be connected at all: `iobot/.../tools/mcp.py` builds the
  streamableHttp client with `headers=cfg.headers` and no `auth=`, the sse
  branch's `auth` hook is never populated, and the SDK's `OAuthClientProvider`
  is unused. The 401 was swallowed, the server left out of the tool registry,
  and the agent ran on without those tools while `mcp-list` printed it
  healthy. Now `engine/mcp_auth.py` + the `mcp_oauth` patch mint and RENEW a
  token from an `auth:` block (`--auth-type oauth2_client_credentials`), which
  also fixes the static-JWT case - nothing renewed it, so it worked until
  `exp` and then stopped. `auth:` is OURS: iobot's config model is
  `extra="ignore"`, so writing it there is a SILENT no-op - it lives in
  `_MCP_EXTENSION_KEYS`, is stripped before iobot sees anything, and is read
  back from the tiers. **Every probe consumer must go through
  `mcp_probe.probe_entries`**: three of them exist (`mcp-list --probe`, the
  build session's startup health check, the runtime's failure diagnosis), and
  the health check once used `merged_mcp_servers()` - which strips `auth:` -
  probed an OAuth server anonymously, and told the MODEL the server was down;
  the model believed it over its own tools and declined a job it could do,
  while the runtime was connected throughout. An interactive
  authorization-code flow is still not supported (no browser, nowhere to
  receive a redirect) - that needs a gateway, and
  `examples/mcp-oauth-lab/oauth_gateway.py` is a working reference.
- **A2A outbound = registry + transport + skill.** Registry:
  `~/.iobot/workspaces/<code>/external-agents.yaml` (`engine/a2a_registry.py`,
  `a2a-add`/`a2a-list`/`a2a-remove`), same `agents[]` schema as
  `catalog_dynamic.yaml` plus optional `headers` with `${VAR}` refs (values
  live in the workspace `.env`; `a2a-list` shows resolvability, never
  values). Materialized as `metadata/external_agents.yaml` at pool warmup
  (`web/app.py`) and `create_filtered_workspace` — takes effect next
  warmup/run, and an emptied registry removes the stale copy. Transport:
  `iof-consult` gained `--header` + per-entry `headers` in dispatch.json,
  expanded at send time (`${VAR}`/`${VAR:-default}`); an unset-var header is
  dropped with a stderr warning, and it loads the workspace `.env` keyed on
  `IOF_WORKSPACE` first (exec-stripped env recovery). Judgement: shared skill
  `agentfarm-skills/.../skills/a2a_consult/` — assign explicitly; nothing
  carries it by default. The inbound `/a2a/<role>` surface is unchanged.
- **Validated live, skill-driven (2026-08-06).** MCP: `mcp-add --workspace` →
  `new-skill --mcp-server` (resolved from the WORKSPACE tier — the repo's own
  mcp.yaml did not declare it) → `create_instance_config` carried the server
  with `${VAR}` unexpanded → a real `iobot agent` run (MiniMax) whose message
  named NO tool chose `mcp_lab_add_numbers`/`mcp_lab_lab_secret` from the
  skill and returned correct results, the marker proving env resolution
  happened at config load. A2A: `a2a-add` with a `${VAR}` header, token ONLY
  in the workspace `.env`, dispatch built from the materialized catalog, and
  `iof-consult` in a shell with NO token authenticated against the
  bearer-protected lab agent (`authenticated: true`); unset-var runs produce
  the named warning + clean 401. The calling path is entirely iobot's own
  (`connect_mcp_servers` → ToolRegistry); ioagentfarm contributes only which
  declarations reach which config.
- **Client-doc coverage:**
  [04-mcp-tools.md](aicore_docusaurus/03-building-solutions/04-mcp-tools.md) and
  [05-external-agents.md](aicore_docusaurus/03-building-solutions/05-external-agents.md),
  with the worked example at
  [06-example-mcp-server.md](aicore_docusaurus/02-getting-started/code-first/06-example-mcp-server.md).

## Swarms (2026-08-07)

Full docs: [docs/swarms.md](docs/swarms.md) +
[docs/reference/swarm-yaml.md](docs/reference/swarm-yaml.md); client pages
[07-swarms.md](aicore_docusaurus/03-building-solutions/07-swarms.md) and
[07-example-swarm.md](aicore_docusaurus/02-getting-started/code-first/07-example-swarm.md).

A SWARM is the goal-oriented sibling of a workflow: one META-AGENT + a GOAL +
a ROSTER (external A2A agents from the workspace registry, MCP servers from
the declaration tiers), route decided at runtime — a collection of tools and
agents working under one meta-agent's direction with predefined controls,
budget and checkpointing. Definitions live at `swarms/<name>/swarm.yaml` in a
solution package (solution-level, like workflows), optional `meta.md` /
`roles/<role>.md` / `metadata/` overrides beside it.

- **THERE IS NO SECOND ENGINE — a swarm COMPILES to a one-step workflow at
  run creation** (`engine/swarms.py`: `compile_swarm` writes
  `.iof/instances/<run_id>/workflow/` BEFORE anything else touches the run;
  `snapshot_workflow` early-returns on the existing dir). Everything
  downstream is the stock run pipeline, so swarm runs inherit Fix-6 retry,
  forensics, the fail-closed deliverable gate (`deliverable:` →
  `requires_artifacts`), the hard attempt cap, supervisor
  reaping/resurrection, S3 recovery, `--json` background spawn, and the whole
  run CLI.
- **Roster scoping rides the two raw-snapshot readers** (the `learning:`
  precedent — the loader ignores unknown keys, so the compiled YAML carries
  `kind: swarm`, `agents:`, `mcp_servers:`, `budget:` markers):
  `create_filtered_workspace` passes the `agents:` list to
  `materialize_external_agents(names=...)` (scoped catalog; unknown roster
  names warned BY NAME), and `create_instance_config` filters
  `tools.mcpServers` by `mcp_servers:` and applies `budget.tool_calls` as the
  run's `maxToolIterations` (floor 20 — the driver shares the config; never
  raises the deployment default). Zero changes to `cli_orchestration.py`.
  **Both readers fail CLOSED on an exists-but-unreadable snapshot**
  (2026-08-07): roster → `[]`, MCP servers → `{}` — a roster is a capability
  control and a control narrows on failure; the first fix warned but still
  widened to every registered agent/server, which is the leak with a log
  line. A MISSING snapshot keeps the open semantics (the plain-workflow /
  no-marker case). Pinned in `test_swarms.py`, both proven non-vacuous.
- **Guardrails:** rosters + deliverable gate are the controls;
  `budget.tool_calls` is HARD (physics), `budget.consults` is a briefing
  contract (judgement); the generated briefing mandates a `_run_plan.md`
  checklist — the exact file Fix-6 smart continuation reads, so a retried
  attempt RESUMES from the checkpoint instead of restarting.
- **Compiled role always emits `skills:` (a list, never None)** — that is
  what triggers the filtered workspace, which is what materializes the scoped
  A2A catalog. `a2a_consult` is auto-added unless `agents: []`;
  `role: project_lead` is refused (driver role). `agents` semantics are
  three-valued: omitted = all registered, list = exactly those, `[]` = none;
  `mcp_servers` mirrors it.
- **Commands:** `new-swarm` (scaffold, solution-level) / `list-swarms` /
  `lint-swarm` (`--all/--strict/--json`; unknown keys ERROR with
  did-you-mean; compiles in memory and graph-validates — lint-clean means
  run-loadable) / `run-swarm <name> --goal "..."` (mirrors `run`'s flags;
  `--dry-run` prints roster + compiled shape). `runs.kind` (`'workflow'` |
  `'swarm'`, additive `_ensure_column`) is the discriminator;
  `ensure_workflow` is SKIPPED for swarm runs — a swarm is not a
  workflow-catalog row. Files: `engine/swarms.py` (model/loader/compiler),
  `engine/swarm_lint.py`, `Pack.swarms` + `swarm_sources()` +
  `detect_collisions` swarm scanner in `packs.py`.
- **`workspace push`/`pull` does NOT carry swarms yet** — documented
  follow-up; the runtime resolves from installed packs and the
  `<IOF_ROOT>/swarms/<name>/` override tree.
- **M5 validation (2026-08-07, live on MiniMax against the lab children).**
  A scaffolded flat workspace `intel` with TWO solutions (`signals`,
  `briefing`), two workflows and two swarms — all four lint-clean as
  generated. Proven end to end: the workflow regression ran 2/2 (the kind
  addition is non-invasive); `portfolio_review` (3-agent roster) converged
  1/1 through the fail-closed gate with correct per-agent-attributed ground
  truth, the filtered workspace catalog holding EXACTLY the roster, the
  instance config's `maxToolIterations` at the budget cap, and the
  `_run_plan.md` checkpoint written unprompted; `market_pulse` proved
  scoping-down (catalog of ONE agent while three were registered; MCP
  filtered to `lab`) and used BOTH capability kinds in one run — plus the
  never-fabricate discipline when its MCP marker env was unset; failure
  injection over the DETACHED `--json` spawn path converged `done` with the
  failed child named (exact HTTP 500 quoted), its severity marked unknown,
  and zero fabricated figures. `runs.kind` discriminated
  workflow/swarm correctly throughout.

## The code driver, routes/on_fail, the OTel bridge, and the novice loop (2026-08-26/27)

Built for a client team migrating off Temporal + OpenAI Agents SDK. The full
record - design, every novice round's verdict and what each one fixed, the
CLI startup budget, the build-session install policy - is
[docs/CODE_DRIVER_AND_NOVICE_ROUNDS.md](docs/CODE_DRIVER_AND_NOVICE_ROUNDS.md).
What a session must know:

- **`aicore run --driver code`** (`engine/code_driver.py` over the
  `engine/driver_api.py` seam): the DAG decides the order, independent
  steps run in parallel, no LLM in the control plane. The driver is a
  property of the RUN (`runs.driver`), so `--json`, `resume` and the
  supervisor keep it. `timeout:`, `type: route` + `routes:` (`sdk.route`),
  `on_fail: {reset, feedback}`: `docs/reference/workflow-yaml.md`. A script
  fan-out stays INSIDE the tool (a thread pool); only agent items become steps.
- **OTel** (`engine/otel_export.py`, `sdk/obs.py`,
  `docs/reference/observability-otel.md`): one trace per run, off by
  default, `OTEL_EXPORTER_OTLP_ENDPOINT` is the switch. Measure the WIRE
  (an OTLP receiver), never the console exporter.
- **The novice loop.** A subagent with no context breaks the product as a
  first-timer and scores whether the product alone explains it. Every
  finding is pinned (`tests/test_novice_findings_2026_08_26.py`,
  `tests/test_novice_round4.py`) and replayed live. Rerun it on any change
  to this surface; it finds what suites cannot. Standing rule (2026-08-27):
  keep it running, each round more creative than the last, until it
  certifies.
- **Three lessons that bit:** an append-after-anchor patch re-applies on a
  re-run (check for the FULL new text); a test that stubs a callee with the
  buggy call shape is green forever (`test_cli_resume.py`); a wrapper that
  catches an exception TYPE misses a re-raise (`GitStoreError`) - catch by
  STATE.
- **CLI startup is a budget** (`tests/test_cli_startup_budget.py`): the
  engine package is lazy, the models defer their schema build, `aicore
  --help` is ~0.6s. **`IOF_BUILD_INSTALLS=never`** refuses installs in an
  `aicore build` session; by default an asked install runs and the prompt
  decides.

## `aicore build` - the desk-side solution builder

An interactive REPL where the **`cora_build`** agent designs solution content
AND places it, by running the same scaffold commands a person would. Local only.
The code is the `ioagentfarm/builder/` package (one module per concern) plus the
agent at `agents/cora_build/workspace/` and its own suite `tests_build/` (run
`python scripts/run_tests.py build`, ~5s). Coupling to the rest of core is two
lines: `cli.py` registers the commands, `workspaces.py` lists `cora_build` among
the platform-shared roles. User docs:
`aicore_docusaurus/03-building-solutions/09-building-with-the-builder.md`.

**The package is called `builder`, not `build`, and that is load-bearing:** the
first name put it inside three independent ignore conventions (.gitignore,
.dockerignore, setuptools auto-discovery), `git add -A` silently skipped all of
it, and main shipped importing a package it did not contain - every local check
green because the files were on disk. Pinned by a test that runs
`git check-ignore` over every source file.

**The engagement surface is engineering on data the harness already has - never
a request to the model.** Per turn the console shows narration, tool calls with
repo-relative args, a result line for every completed call, red/green edit
hunks, plan ticks, and a liveness floor (a ticker with phase + elapsed +
"Ctrl+C cancels") that runs on both turn paths and reads nothing the model
produced. The review turn STREAMS activity - fully quiet it was two minutes of
blank screen - and its charter carries EVIDENCE RULES (quote a failed command
verbatim; never translate a tool refusal into a claim about the tree) after a
reviewer declared an existing, lint-clean directory nonexistent.

**What does NOT hold: prose style rules** ("never begin with Let") - prompts are
requests. The rules that held are structural: open the turn with a line,
findings first.

**The lint set is symmetric:** `lint-workflow`, `lint-swarm`, `lint-skill`,
`lint-agent` (the last two exist because the builder INVENTED `lint-skill` by
symmetry - the inference was right). lint-skill: an unquoted description
containing `": "` fails the WHOLE frontmatter, so the skill loads unmatchable.
lint-agent enforces EXACTLY ONE output contract - zero means every step fails
and retries; two always-on format skills is the bug that removed
`output_protocol` from Quinn.

**Re-seeding is NOT gated any more (since One Truth, 8145487, 2026-08-15) —
this paragraph used to say it was, and that stale claim cost a detour.**
`ensure_agent_workspace` re-copies identity and skill files from the installed
pack on EVERY call for any role a pack provides (`refresh = True`; only
`memory/` is preserved), and `aicore build` calls `ensure_iobot_agent` at
every start — so a charter fix in the package reaches an already-seeded
`cora_build` home on the next session with no `--force`. Verify:
`grep -n "refresh = True" agentfarm-core/ioagentfarm/engine/workspaces.py`.
The 2026-08-18 case: the harness had ASKED about installs since 08-14 while
the agent's own SOUL and `solution_builder` still said "never `pip install`"
— and the SOUL says its limits outrank conversation — so the model declined
before the prompt could fire. Two policies at two seams; the model reads one.
Pinned by `test_the_agents_own_charter_agrees_with_the_harness`.

**Two measured lessons.** Skill delivery is measured, not assumed: across 14
sessions, on-demand skills fired reliably when the trigger was an artifact the
agent was about to write; `run_ops` fired once in 14 because its trigger is a
SITUATION ("about to wait for something"), so it is now the one `always: true`
craft skill - do not generalise that to the others. And **a rule stated to a
model is a request**: the sleep-poll ban lived in an always-on skill AND the
user's prompt, was verifiably injected, and was ignored; enforcing it in
`build_exec_guard` took the same request from 55 tool calls to 7.

**Console text must survive a legacy code page.** Rich RAISES
`UnicodeEncodeError` rather than substituting, so one bullet crashes the REPL in
the RENDERER, after the turn is paid for. `_glyphs(console)` picks an encodable
set and `_console()` relaxes the stream to `errors="replace"`. **Scan for BOTH
the raw character and its escaped form** - the first sweep missed every escaped
glyph because the source bytes were pure ASCII.

**The build log is a FILE the user opens if they want it; nothing about it may
ever print (2026-08-19).** Seen twice on a client box: every runtime record
came out on the console wrapped in `--- Logging error in Loguru Handler #1 ---`
with a `[WinError 32]` traceback. It looked like a flood of OLD errors; every
one was a LIVE record that could not be written. Cause: the stdlib half opened
a `FileHandler` on the SAME `build_engine.log` loguru had a 5 MB rotation on;
Windows refuses to rename a file with any other open handle, loguru retries the
rename on EVERY record once the file is past the size, and its `catch` prints
each failure to stderr - deterministic after ~5 MB, permanent for the session.
Now `builder/logsink.py`: ONE `SessionLogFile` both halves write through, one
file PER SESSION (`build_logs/build_engine.<time>.<pid>.log`), size roll opens a
numbered SIBLING (nothing is ever renamed - a file another session or an editor
holds is left alone), retention keeps the newest 10 and SKIPS what it cannot
delete, and every operation swallows - a failed write drops the record. Pinned by
`TestTheLogFileNeverReachesTheConsole`, which reproduces the client output
verbatim against the old code. Rule: never give loguru a PATH here (its file
sink prints its own errors) and never open a second handle on the log.

### The hardening record lives in docs/

Four dated passes - the chaos-hardening campaign (2026-08-20), a client
team's day of use (2026-08-25), the five-lens stability audit (2026-08-26)
and the scope hardening (2026-08-28) - are recorded in full in
[docs/AICORE_BUILD_HARDENING.md](docs/AICORE_BUILD_HARDENING.md), with the
rules each produced. What a session must not forget: **the build guard is an
ACCIDENT RAIL, not a security boundary** (a regex denylist over a command
string; real containment is `restrict_to_workspace` + a container). The one
distinction that decides whether a pattern is worth adding - EVASIVE or NOT:
a pattern covering the OBVIOUS spelling of a misuse raises the floor
under an accident; one added to chase a bypass found by evasion is theatre.
The threat that matters is the confused deputy; nothing
ends the session but the user; one conversation, one writer
(`builder/lock.py`); never prompt from inside a turn without
`console.suspended_live()`; the live layer is `scripts/cora_chaos.py`.
The 2026-08-28 pass added the OBVIOUS-spelling refusals for the five doors a
build turn kept open - starting a server or background process, enumerating
the machine, killing a process/service, opening the engine DB directly, and
reading a credential file through the `read_file` TOOL (`gates.read_denial`,
the second door the exec guard could not see) - plus `new-solution`'s refusal
of the `solutions/<slug>/<slug>` nesting trap. None chases an evasion. The same
pass made a build session's placement follow the ROOT_WS structure
(`agents/skills/solutions/tools` at the repo root, regardless of cwd): the
`solution_builder` charter leads with `aicore workspace scaffold` (not
`new-solution`, which builds a standalone `<pkg>/agents` package), and it is
ENFORCED - a standalone `new-solution` in a non-workspace build repo is refused
and directed to `workspace scaffold`, read from the `IOF_BUILD_REPO` the build
session already sets (no new env var). Validated live against MiniMax.

## Jarvis assistant suite

**Jarvis is the Claude Code of the AI Core Harness** - the resident developer
companion. Three pillars: DIAGNOSE (what happened and why, from the forensic
substrate), ANALYZE (cost/tokens/fleet, from `iof-run-audit` + SQL),
ADVISE/AUTHOR (paste-ready, lint-clean-by-construction YAML in chat; placement
via the scaffold commands - **Jarvis never writes files**).

**`aicore forensics explain <run_id>` is the centerpiece and the FIRST resort**
for any run question: a deterministic postmortem composing run row + event
timeline + per-attempt blob analysis + artifact gates + swarm children + usage
into one verdict with <=3 paste-ready `look_next` pointers. Degrades
filesystem-only without a DB.

Skills: `run_diagnostics` (explain-first), `run_costs` (`always: true` - the
always:false pattern was missed in production once), `platform_advisor` (slim
always-on skill + templates read on demand, and the templates are TESTED to lint
clean), `ai_assistant` router. The event vocabulary is pinned by
`tests/test_forensic_event_docs_match_emits.py` against the emit sites.

**Two standing rules the hardening campaign produced:**

- **Every capture-layer reader and emitter must share its discovery code.** A
  consult-results parser and its event emitter had the same layout bug
  independently, so events and tables disagreed and a timeout was invisible to
  the fleet query. They now share `forensics.find_swarm_results`.
- **A symptom table must speak BOTH user language and event names**, or the
  lookup fails for whoever is actually asking.

**Chaos testing is a PROXY, never a patch.** An env-gated fault injector in the
production patch registry was built and REVERTED: a stray env key could arm
synthetic failures in a pod, and it silently failed to fire in the step
subprocess - the one property a fault injector cannot have. The replacement
lives only in `examples/mcp-a2a-lab/`: `chaos_proxy.py` injects wire-level
faults between the runtime and the endpoint, activated by a sandbox config
pointing at it - a chaos *deployment*, not a mode. No chaos env key exists
anywhere, and a test guards the shipped package against one appearing.

What live chaos proved: a single connection reset is absorbed by the runtime's
own provider retry and never reaches the agent loop (recovery LAYERING - Fix-6
sees only what survives that); and under a total outage the driver cannot make
its own calls, so no step ever starts. That left a run `running` with one event
until `run.driver_gave_up` was added - and end-to-end validation then caught
that fix HALF-DONE, because `explain`'s verdict branches keyed off a failed
STEP and such a run has none. **An emitted event is not a delivered answer:
validate the READER, not just the writer.**

Non-goals: HTTP forensics API, retention/pruning, per-tool-call latency, Jarvis
writing files.

## Testing as a CLIENT, and the two mechanisms it produced (2026-08-16)

Everything here is developed inside the monorepo, in a venv that already has
every distribution, against a configured workspace on a database that already
has data. None of that is true for the team who receives the product.
**`python scripts/client_simulation.py`** reproduces THEIR box — new folder,
fresh venv, SDK as a dependency, the solution copied in as their own repo, an
empty local SQLite hub — hands it to `cora_build`, and loops until the solution
converges. `--provision-only`, `--assess-only`, `--keep`, `--root`.

The split is enforced by construction: the **SDK installs editable FROM THE
REPO** (a core fix lands immediately — the real upgrade path), the **solution is
copied with `git archive`, TRACKED FILES ONLY**, and installed from the copy.
`git archive` rather than a file copy is load-bearing: a working-tree copy takes
gitignored `.env` files, and the first attempt carried production RDS
credentials into the "isolated" sandbox, which then queried the live instance.
`assert_isolated()` now fails the run on any endpoint-shaped string under the
sim root. Two environment facts that cost hours: HOME/USERPROFILE must be
repointed (`IOBOT_HOME` is entrypoint-only and never read by Python), and every
pharma workflow's `metadata/databases.yml` declares
`env_file: ~/.barrier_signal/.env` — which is what an **exec-stripped** tool
subprocess actually reads, not your exported env.

**`coverage:` in workflow.yaml → the `run.coverage` event.** A run's record
knows its own steps and NOTHING about input that was never queued for it, so a
pipeline consuming half its backlog reaches `done` with every gate green and the
shortfall appears nowhere — an absence is invisible to a success check. Observed:
four barriers reported confidently while 100 ingested call notes had never been
processed, so every barrier rested on one of two detection methods. The agent had
even run the domain's status command — at ORIENTATION, when the hub was empty and
the backlog read 0. Preconditions at the start, postconditions never; the timing
was wrong, which no instruction fixes. A workflow now DECLARES the commands that
describe its own coverage, `cli_orchestration` runs them at the completion
transition, and `forensics explain` prints the answer beside the verdict. Core
stays domain-free (it cannot know what a backlog IS) and it is a **report, never
a gate** — a legitimate backlog must not fail a run. `engine/coverage.py`.

**`setup-agents --force` REFRESHES again.** It was a no-op that still advertised
"Overwrite identity and skill files": `ensure_agent_workspace` only ever fills a
MISSING file and never replaces one, so an SDK skill fix could not reach a
workspace that had already run once, and the documented command reported success
while changing nothing — a materialized workspace permanently shadowing the pack
that P1 says is the only truth. `--force` now invalidates that cache and
materialize-on-use re-reads from the pack. The drop list is an **ALLOW-list**
(`SOUL.md`, `TOOLS.md`, `skills/`) because the first cut was a deny-list and
deleted the agent workspace's `.git` — which is what the build REPL's `/diff`
and `/undo` operate on.

**Two lessons worth repeating.** A rule stated to a model is a request: the
sleep-poll ban lived in an `always: true` skill AND in the user's prompt, was
verifiably injected (9.4k chars), and was ignored — enforcing it in
`build_exec_guard` took the same request from 55 tool calls to 7. And check the
thing itself, not its neighbour: the harness asked "do both detection methods
exist in the hub?" and reported converged while three of six barriers rested on
one method; it now asks whether the second method reached the BARRIER layer.

## Development

**Always use the project virtual environment — never install into system Python.**

```bash
python -m venv .venv
.venv\Scripts\pip install -e .              # runtime stack (iobot ==0.3.0, fastapi/uvicorn, duckdb) is a hard dep
.venv\Scripts\ioagentfarm run project_lead --goal "..." --dry-run  # validate
.venv\Scripts\ioagentfarm run project_lead --goal "..."            # execute
```

Use `--dry-run` to validate workflow YAML and inspect the step DAG without executing.

**Running the tests: `python scripts/run_tests.py`** — six suites, one exit
code. Do NOT run `pytest` at the repo root: it collects only `tests/` (122 of
~700), and a single rootdir CANNOT collect the rest — two API modules do
`from tests.conftest import …`, which from the root resolves against the ROOT
`tests/` package. Two directories named `tests`, and cwd decides which wins.
The runner runs each suite in its own rootdir: core, api, clihub, skillhub,
barrier_signal (pharma), build. `--list` shows them. **A bare suite name
scopes the run** — `run_tests.py build` is ~5s against ~2 min for the gate;
an unknown name is refused with the list rather than handed to pytest, where
it used to match nothing anywhere and report all six suites FAILED. Scope the
run to the surface you touched; the full gate is for shared surfaces and the
one run before pushing a batch.

CI (`buildspec.yaml`) runs this before `docker build`, so a failing test now
blocks the image. It did not until 2026-07-31 — the pipeline was clone → build
→ push with no test step, which is how `tests/test_sandbox.py` sat at 50
collection errors for three weeks while the root suite reported "81 passed"
beside them. An erroring suite still "runs".

**TypeScript tools (ts-skills):**

```bash
cd ts-skills && npm install && npx turbo build   # build all CLI tools
npm link -w vectorfs                               # make vectorfs available on PATH
```

In production (K8s pod), CLI binaries are pre-built in the container image. Env vars (`VECTORFS_STORE`, `QDRANT_URL`, etc.) come from K8s ConfigMaps/Secrets — no `.env` file needed.

## Starting a new SOLUTION

**Do not hand-write the repo — `ioagentfarm new-solution <slug>` scaffolds it.**
Five things must be right and each fails SILENTLY when hand-written: the
`aicore.packs` entry point (missing → pack installs and is invisible),
`package-data` globs (missing → wheel ships with no content, invisible in an
editable install, fatal on a pod), `aicore.solution.yaml` (serves the
IMPORTER; the entry point serves the RUNTIME — a repo needs both, and the API
pod installs no packs at all), a skill's `roles:` starting assignment, and each
agent carrying its own `output_protocol`. The generated repo installs, imports and
runs, and ships tests that fail if any of the five drifts.

The validated end-to-end path is
[aicore_docusaurus/02-getting-started/](aicore_docusaurus/02-getting-started/) —
written by walking it, then re-walked twice, once by an agent with no prior
context. [docs/examples/pharma-commercial/](docs/examples/pharma-commercial/) is
the same walk done for real on a CLIENT deployment (their distribution names,
PostgreSQL, per-OS), with working tool code, a sample extract and its catalog in
`files/`, and an eleven-entry appendix of what actually went wrong.
[docs/examples/pharma-brand-marketing/](docs/examples/pharma-brand-marketing/)
is the PLAYBOOK walk (2026-08-25): local mode, the brand-marketing workspace
installed, a stand-in field system (`files/crm_stub_server.py`), the Brand
Share Loss play compiled live (the draft ended in a `LOOP` verdict and was
rejected on the record), the reference installed, one case opened and closed
through seven runs the dispatcher started - every output recorded.

**THE PACK IS NAMED AFTER THE DOMAIN, NOT AFTER US** (2026-08-03). `new-solution
pharma_comm` produces package `pharma_comm` and distribution `pharma-comm` —
the `agentfarm_` / `agentfarm-` prefix is gone. It was ours on a repo the
business IT team owns. Nothing derives or pattern-matches the name (the entry
point states the module explicitly), and `cli_pack.py` still strips the old
prefix when deriving a title, so packs scaffolded before this keep working. The
packs already in this monorepo keep their names — those are published
identities.

**Two consequences that bite quietly.** The scaffold writes into the CURRENT
directory, so there is no `cd <slug>` afterwards — and now that the package IS
the slug, that `cd` succeeds and drops you inside the package, where the next
command fails looking for a `pyproject.toml` one level up. And `new-solution`
no longer needs `IOF_WORKSPACE`: every workspace-scoped command names its
target (`import`/`show` by argument, `serve`/`run` by `--workspace`).

**THE SDK DISTRIBUTION NAME IS NOT A CONSTANT** (2026-08-03). An organisation
that republishes the SDK has `ai-core-harness-engine` on its index and nothing
called `agentfarm-core`, so a literal in `cli_scaffold.PYPROJECT` put a
dependency their index had never heard of into every generated pack —
`pip install -e .` died on `No matching distribution found`, which reads as
"broken package" rather than "wrong name". Resolution, most explicit first:

1. **`~/.iobot/sdk.json`** (or `IOF_SDK_MANIFEST`) — the only layer that can
   name a distribution this machine has never installed, carry a version, or
   list a third wheel. `{"dependencies": [{"name": "...", "version": "..."}]}`,
   or a bare list of strings. **No version means LATEST** — omitted from the
   requirement entirely, not defaulted; a bare `0.6.2` becomes `==0.6.2`;
   anything starting with a comparator is verbatim. A malformed file is
   REFUSED, not ignored.
2. **What is installed here**, via `cli_scaffold._SDK_ANCHORS`.
3. The shipped names, for a checkout that was never pip-installed.

**The two wheels are anchored differently, and that is load-bearing.** The
engine is found by its IMPORT package (`ioagentfarm`) — every pack does
`from ioagentfarm.packs import Pack`, so renaming it breaks everything loudly.
**Nothing imports `agentfarm_skills` by name**: it is discovered as
`aicore.packs -> skills`, so it is anchored on that ENTRY POINT. An
import-package-only lookup falls back silently to the wrong name in a
deployment that renamed the directory and its own entry-point value, since that
combination keeps working. No version bound is generated — a ceiling guessed at
scaffold time refuses an upgrade nobody asked it to refuse.

## Adding a workflow, agent, skill or CLI tool to an EXISTING solution

**Do not hand-write these either — `new-workflow` / `new-agent` / `new-skill`
/ `new-tool` scaffold them into the pack rooted at the current directory** (`cli_pack.py`;
templates shared with `cli_scaffold.py`, one source). Run from anywhere inside
the repo; they walk up to find it.

```bash
ioagentfarm new-agent    <role>  [--name "Rey"]
ioagentfarm new-workflow <name>  [--role <agent>] [--steps analyze:ida,review:rey]
ioagentfarm new-skill    <name>  [--role <agent>] [--tool <tool>]   # --role = agent workspace, else pack-level
ioagentfarm new-tool     <name>                     # script + entry point + tools.yaml
```

**A skill is judgement; a tool is a script.** `new-tool` exists because the
CLI otherwise nudged authors toward a skill for deterministic work — an agent
asked to compute something returns an answer that is plausible and
occasionally wrong, with nothing to tell the two apart. It writes three things
because a tool is only reachable when all three line up: the script, the
`console_scripts` entry point (the only thing that puts it on PATH), and the
`tools.yaml` entry (`cli-hub check` reports all-clear on a pod missing an
undeclared binary). **It is the one grow command needing `pip install -e .`
afterwards** — a launcher is generated by pip at install time, not read from
your files.

**THE TOOL AND ITS SKILL ARE TWO COMMANDS — `new-tool --role` and `--no-skill`
are RETIRED** (they error naming the replacement; hidden options, because
click's "No such option" reads as a typo). `--role` on a tool read as *this
tool belongs to this agent*, which is false — a console script is on PATH and
every agent can run it; what the flag actually scoped was the paired SKILL, one
flag doing a second thing at one remove. So the pipeline is written out:
`new-tool <name>` then `new-skill <name>_usage --tool <name> [--role <agent>]`,
and `new-tool`'s closing output prints that exact line (filled in with the
agent's name in a one-agent pack) because nothing else would catch the missing
step — the tool installs, validates, and no agent ever hears of it.
`new-skill --tool` renders the SAME template with a `## Running it` section
appended (never a second template), puts the binary in the frontmatter
`description:` (that is the line an agent matches a job against), and resolves
the name against the pack's `tools.yaml` — both `<name>` and the full
`iof-<slug>-<name>` — refusing an undeclared one BY NAME before writing
anything, since a skill teaching an agent to run a binary nobody installed is
worse than no skill: the agent tries, and burns the step's attempts on
`command not found`. `--tool` and `--role` are independent; a tool skill with no
role is a pack-level skill a workflow step names. `new-skill` prints one hint
naming BOTH commands when a description sounds deterministic (silent when
`--tool` was passed — that author already wrote the executable).

Hand-writing loses to the same silent failures `lint-workflow` exists to catch:
`requires_artifact` (no `s`) loads clean and disables the fail-closed artifact
gate, `skilz` un-filters a role's skills. What is generated lints clean (zero
errors AND zero warnings — asserted in `tests/test_grow_the_pack.py`), and
`new-workflow` re-lints the file it just wrote and prints the result. Nothing
needs re-running afterwards: an editable install resolves through the source
tree, and each command prints which install state it found (its "installed?"
check reads the `aicore.packs` ENTRY POINTS, not importability — from the
repo root cwd is on `sys.path`, so the package imports while the engine sees
nothing).

What they encode, and why each is not optional:

1. Workflow: `<pkg>/workflows/<name>/` — `workflow.yaml` (linear `deps` chain,
   every step gated by `requires_artifacts`), `roles/*.md`, `steps/*.md`, and
   its own `metadata/catalog.yaml` (`{{metadata_dir}}` is "" without one, so
   the prompt renders "read the catalog in ``"). No `skills:` filter is
   emitted: the repo cannot see the shared SDK skills seeding will give the
   agent, so any filter written from the repo alone would be short — and short
   means silently DROPPING `always: true` skills. Verify with
   `ioagentfarm list-workflows`.
2. Agent: `<pkg>/agents/<role>/workspace/` with SOUL.md, TOOLS.md,
   memory/MEMORY.md — **plus its own `skills/output_protocol/SKILL.md`**,
   copied from the INSTALLED core so it cannot fork (it is NOT injected; an
   agent without it emits no `STATUS:`/`OUTPUT:` and every step it runs is
   marked failed and retried). AGENTS.md is generated per host — not authored.
3. Skill: `--role` puts it in that agent's workspace (assignment is BY
   LOCATION); omitted, it is pack-level and held by nobody until a workflow
   step names it. **No `roles:` key is emitted** — see "Skills are OPEN": it
   gates nothing and only seeds a workspace that does not exist yet. The
   scaffold's own `tests/test_pack.py` still asserts one on pack-level skills,
   so `new-skill` warns and names the assertion to delete. Frontmatter
   `description:` is always double-quoted; a plain scalar containing `": "` is
   a mapping, not a string, and `<<` is the YAML merge key. `--tool <name>`
   builds the skill around a declared CLI tool — see above.
4. Nothing to seed or sync afterwards: a run or chat resolves the new agent
   from the installed pack directly, and `serve` registers a host's content
   at boot. (`setup-agents` and `sync` are stated no-ops kept for old
   runbooks; `setup-agents --force` is the one live flag — it drops the
   materialized copy so the next run re-reads an edited pack.)
5. A `skills:` filter in workflow.yaml is a WHITELIST — any `always: true` skill
   not named is dropped, `output_protocol` included.

## CLI reference

28+ commands total. Most accept `--user-id <id>`. Run `ioagentfarm --help` or `ioagentfarm <cmd> --help` for full usage. Key groups: setup (`init`, `list-workflows`, `lint-workflow`, `configure-agent`; `setup-agents`/`sync` remain as stated no-ops), scaffold (`new-solution`, `new-workflow`, `new-agent`, `new-skill`, `new-swarm`, `new-mcp-server`, `new-tool`), tenancy (`workspace create|delete|attach|diff|import|export|list|use`), context (`use-run`, `current`, `follow-up`), execution (`run` / `run --json`, `run-swarm`, `next-step`, `run-step`, `step-complete`), tasks (`run-task`, `task-create`, `task-update`, `task-list`), recovery (`resume` — reap + re-spawn the driver of an interrupted run; `step-retry` / `step-retry --crash-recovery`, `step-skip`), interactive (`agent-chat`, `run-output`), web (`serve` with `--concurrency`), gateway (`start-gateway`, `heartbeat-log`), MCP/A2A (`mcp-list`, `mcp-add`, `mcp-remove`, `a2a-add`, `a2a-list`, `a2a-remove`). **Sub-apps:** `forensics <cmd>` (postmortem/timeline/blobs — Jarvis's substrate), and **`learning pending|show|approve|reject|audit`** (the steward review workflow — see the Learning lifecycle section). Console-script tools agents exec: `iof-query`, `iof-consult`, `iof-run-audit`, `iof-recall` (cross-run FTS over prior step outputs).

**`new-solution <slug>`** — scaffold a domain solution repo that installs, imports and runs (entry point + package-data globs + `aicore.solution.yaml` + a workflow with a shipped `metadata/catalog.yaml`, plus tests for the packaging contract). See README "Starting a NEW solution". Install the generated pack into the **engine's** venv — entry-point discovery is per-environment, and a pack in another venv is invisible with no error.

**`new-workflow` / `new-agent` / `new-skill`** — grow that repo afterwards; see "Adding a workflow, agent or skill to an EXISTING solution" above. Flag-driven, never interactive (prompting was proposed and rejected: these get run from scripts and shell history, and neither can replay a prompt sequence). `--steps analyze:ida,review:rey` is one argument rather than a repeatable `--step` because the steps become a dependency CHAIN, so their order is part of the meaning and a repeatable flag hides it in argv positions. All three refuse to overwrite without `--force` and name what is in the way.

**`lint-workflow <name-or-path>`** — the validator the loader is not.
`WorkflowLoader._load_from_dir` reads every field with `data.get(...)`, so an
unrecognised key is not rejected, it is **never read**: `requires_artifact` (no
`s`) loads clean and silently disables the fail-closed artifact gate, `skilz`
un-filters the role's skills, `vars_typo` empties every `{{var}}`. This rejects
unknown keys at every level with a did-you-mean, checks what the loader cannot
(prompt files on disk, `type: loop` with nothing to fan out into, `stories_from`
on a non-exec step, a second `per_item_steps` anchor the scheduler can never
reach, `name:` disagreeing with the directory name), and validates `learning:`
against the values its two raw-YAML call sites actually honour — `disabled`,
`false`, `off`; `learning: none` reads like an instruction and leaves learning
ON. Reports everything at once with line + fix, splits error from warning, exits
non-zero on error (`--all`, `--strict`, `--json`). It also warns when a STEP
prompt has lost the *print a line of text before every tool call* rule: the
scaffold writes that rule into every step it generates, and an author editing
over the file can silently drop it — measured, in all three steps of a real
workflow, while the other rules survived. Matched loosely (authors reword) and
scoped to steps (a ROLE prompt is an identity and correctly has no such rule). Graph rules are NOT duplicated
— it calls `workflow_loader.collect_workflow_errors`. `run --dry-run` prints the
findings as a fail-open advisory (so the studio save path surfaces them without
refusing content that saves today); `IOF_LINT_STRICT=1` makes lint errors fail
it. Full attribute reference: [docs/reference/workflow-yaml.md](docs/reference/workflow-yaml.md).

**`sync`** — a stated no-op kept for compatibility, like `setup-agents` (exits 0, writes nothing; its docstring says so). There is no content catalog to re-read into: content resolves from the installed pack at use, and `serve` registers what a host runs at boot (`content_registration` rows via `engine/registration.py`). The table-rewriting behaviour this entry used to describe — `agents`/`pack_skills`/`workflows` rewritten-and-pruned from the packs — survives only behind the engine's own HTTP sync endpoints (`POST /api/agents/sync`, `POST /api/skills/sync`, `POST /api/workflows/sync`, `POST /api/workflows/defs/sync`); nothing resolves content from those tables any more (docs/one-truth-content-model.md §4.5).

**`workspace delete <code>`** — the counterpart to `create`. Removes the tenant's rows across every `studio_*` table plus its `<IOF_ROOT>/workspaces/<code>/` tree. Fail-closed on run history: refused unless `--force`, which takes the run/step/message rows with it (on-disk `instances/` artifacts are never touched). `default` is refused — not because it is a protected workspace but because it is not a workspace at all: it is the PLATFORM TIER's row key (see the no-default-workspace note). Same implementation behind `DELETE /api/workspaces/{code}` (platform admin) and Administration → Workspaces in the Studio.

**`workspace rename <old> <new>`** (2026-08-09) — renames a workspace atomically: the `workspaces` row, every `workspace_code`-keyed `studio_*` table, the `<IOF_ROOT>/workspaces/<old>/` tree (a MOVE, deliberately — one identity changing name; two live trees would diverge), and the `active_workspace` pointer. `rename default <code>` is the ADOPTION path for pre-explicit-workspace installs: it also carries pre-tenancy `~/.iobot/agents` homes via `migrate_global_agent_home(workspace_code=...)` (copy-never-overwrite) and reminds to re-run `aicore sync` so the platform tier is repopulated.

**`configure-agent <role> <metadata_dir>`** — deploy domain metadata into an always-on agent's workspace. Copies `catalog.yaml`, `databases.yml`, `vectorfs.yaml`, `data/` into `~/.iobot/agents/<role>/workspace/metadata/`, links `.env` so dotenv-using tools find credentials, and embeds the catalog content into the relevant SKILL.md (catalog_reader, vectorfs_query) so the agent has it in its system prompt without an `read_file` round-trip. See `docs/query_engine.md`.

**New commands:** `agent-chat` — follow-up conversation with a step's agent via web API (session-aware, S3 recovery). `run-output` — read/write/publish/grep run deliverables (used by agents via exec).

**Web API endpoints:** `POST /api/run` (create), `GET /api/run/{id}/status`, `GET /api/run/{id}/stream` (SSE), `POST /api/run/{id}/message` (interactive chat with @agent routing), `POST /api/run/{id}/resume` (crash recovery), `POST /api/run/{id}/task`, `POST /api/agents/sync`.

**A2A endpoints** (always mounted when `IOF_A2A_ENABLED` ≠ `false`): `GET /a2a/agents` (flat list of A2A-enabled roles), `GET /a2a/<role>/.well-known/agent-card.json` (public Agent Card per A2A v1.0), `POST /a2a/<role>` (JSON-RPC 2.0: `SendMessage`, `GetTask`, `CancelTask`). The set of roles equals the keys of `app.state.agent_pool` — `IOF_ALWAYS_ON_AGENTS` **union card-declared exposure (2026-08-09): any workspace agent whose `a2a-card.yaml` says `expose: true` joins the pool at serve startup** (`web/app.py:_expose_card_declared` → `web/a2a.py:exposed_roles`, roster = DB roster ∪ the workspace's on-disk agent homes ∪ card read via live file → `studio_agent_defs.files_json` → bundled pack — the DB tier exists so a Studio-authored agent no host has materialized still counts). `aicore new-agent <role> --a2a` scaffolds the declaring card. Card-exposed agents skip the two-call cache warmup (exposure declares reachability, not traffic). Pinned by `tests/test_a2a_auto_expose.py` (10). Authored card fields come from `agents/<role>/workspace/a2a-card.yaml`; missing files fall back to a minimal auto-card built from `get_agent_name()` + the SOUL.md first paragraph; the `expose` key never appears in the served card.

## Environment variables

### THE ONLY `.env` THE CLI READS IS `~/.iobot/workspaces/<workspace>/.env` (2026-08-04)

**Three ambient files are no longer loaded at import time.** Each applied to
commands that had not named the workspace they belonged to: `~/.env`,
`~/.iobot/.env`, and `<package>/../.env` (for an editable install, the CHECKOUT
the CLI was installed from — this repo, whose `.env` names production RDS).
They are now *detected and reported* by `aicore current`
(`workspace_env.IGNORED`), never loaded — silence would be indistinguishable
from a file that was read and had no effect.

**`/app/.env` IS STILL LOADED and must stay that way.** It looks like a fourth
ambient file and is not: the agent runtime strips an exec'd tool subprocess's
environment to `HOME`/`LANG`/`TERM`, so `iof-query`, `iof-s3`, `vectorfs` and
nested CLI calls start with NO configuration; `entrypoint.sh:209` writes the
container's injected vars there for exactly that recovery. Removing it breaks
every agent tool call in the pod, and nothing local would catch it. It is safe
because the path exists only inside the image, a pod serves one workspace, and
the values are the deployment's own.

**LOCAL MODE IS ADOPTED AT THE RESOLVER, NEVER BY THE COMMAND (2026-08-27).**
`aicore local on` writes `IOF_LOCAL=1` into that same workspace `.env`, and it
used to be APPLIED eagerly by whichever command remembered to call
`cli.local_mode()`. An AST sweep found **51 functions resolving a state root
or opening a store; 5 adopted the mode**. So `run` was local and `current`
REPORTED local, while `status`, `next-step`, `step-complete`, `resume`,
`agent-chat`, `follow-up`, `serve`, `supervise` and every `forensics` command
read the shared database the workspace `.env` named. Measured on a live
DB-backed workspace: `status` returned three runs that existed only in
PostgreSQL while the local SQLite it had just been told it was using held two
different ones. Writes never leaked (`run` is one of the five) - what broke
was the instrument you read before deciding anything.

Now `workspace_env.adopt_if_declared()` is called by the resolvers that turn
environment into a database - `cli._root`, `cli._store`,
`cli._learning_lifecycle`, `cli._short_db_target`, `cli_workspace._store`,
`cli_workspace._confirm_if_shared` - so a command cannot open a store without
passing through one. **`cli_workspace._root` and `cli_forensics._root` were
byte-identical COPIES of `cli._root`**; they now delegate, because the fix
reached one copy and the other two kept answering from the un-adopted
environment. `IOF_LOCAL` is now TRI-STATE: `--no-local` records `0` rather
than deleting the variable, because a deleted variable is silence and
`declared_local()` would fall through to the directory marker and re-enable
what the flag just turned off. Pinned by
`tests/test_local_mode_is_not_optional.py`, whose sweep fails if a new
resolver appears without adoption (and asserts the count it inspected, so it
cannot pass by examining nothing).

**AND THE MODE IS ANNOUNCED FROM THE SAME SEAM.** `print_mode_banner`'s
docstring has said *"ALWAYS, not only when local"* since it was written and
was wired into FOUR commands, so everything else opened a database in
silence - the same intent-stated-once-delivered-by-whoever-remembered shape
as the leak above. `cli.announce_target_once()` now fires from `_store()`:
one line, **on stderr** (so `--json` stays parseable), once per process,
naming ` LOCAL ` + the file or ` SHARED ` + the server and schema. Suppressed
by `IOF_NO_MODE_BANNER`, by a command that already printed the banner itself,
and never raising - it is on the hottest path in the CLI, and it is ASCII for
the same reason every other console string is.

`~/.env` is the one that did damage and the one nobody looks for: `find_dotenv`
walks **UP**, and on Windows project and temp directories sit under the home
directory, so it was reachable from almost anywhere. It fed a production
database URL to commands run in a scratch directory while `aicore current`
printed `env file: (none)` — true about the workspace's own file, useless about
the value in force. `current` now prints a **`set by`** line naming the file
that actually supplied `IOF_DATABASE_URL`.

Consequences to know: a workspace with no file inherits nothing and resolves to
a local SQLite under its own state dir (the promise the docs already made, now
true); the real environment still outranks everything; and **`scripts/_dburl.py`
is NOT covered** — the ops scripts keep their own resolution, so the asymmetry
noted in OPEN WORK #3 is now wider, not narrower. Pinned by
`tests/test_env_is_workspace_only.py` (subprocess-per-case with its own `HOME`;
both `HOME` and `USERPROFILE` must be set or the test asserts nothing on one OS).

Key vars: `IOF_ROOT` (.iof), `IOF_DATABASE_URL` (sqlite/postgresql), `IOF_RUNNER` (local/k8s), `IOF_STORAGE` (none/s3), `IOF_SANDBOX`, `GITHUB_TOKEN`, `TEAMS_APP_ID`/`TEAMS_APP_SECRET`/`TEAMS_TENANT_ID`/`TEAMS_EMULATOR`. See `channels/teams/config.py` for Teams vars, `web/runner.py` for K8s/S3 vars.

**`IOF_OTEL_CONTENT` is the one variable here with a DISCLOSURE consequence,
and it was missing from this list.** Unset (the default) telemetry carries
lengths and digests only — `aicore.input.chars`, `aicore.output.chars`. Set to
`1`, spans carry message bodies, tool arguments, tool results and step output
to whatever `OTEL_EXPORTER_OTLP_ENDPOINT` names. It is read in exactly ONE
place, `otel_export.content_enabled()`, because it was previously spelled out
at each site that needed it and the site added later — the agent tool spans in
`_iobot_patches` — spelled it out nowhere: a guarantee stated to clients
("message bodies are not exported") was true of three span kinds and false of
the fourth, found by decoding the wire. `aicore otel check` now names which
state a deployment is in, so auditing it does not require a packet capture.
It is deliberately NOT in `_NEVER_STRIP`: unlike `IOF_WORKSPACE` and
`IOF_DB_SCHEMA`, a workspace `.env` CAN legitimately supply it, so the strip
step leaves it alone when the workspace declares it.

**Engine authentication vars (2026-08-26).** Inbound, on the engine:
`IOF_ENGINE_AUTH` (`oidc`|`apikey`|both|`off`), `IOF_ENGINE_OIDC_TENANT_ID`
(Entra — on its own it derives BOTH issuer spellings, `.../v2.0` and
`sts.windows.net/<tid>/`; pinning only v2.0 refuses genuine tokens and is the
last-mile failure every Entra integration hits), `IOF_ENGINE_OIDC_ISSUER` (any
other provider), `IOF_ENGINE_OIDC_AUDIENCE` (**required, never defaulted** —
without it a token minted for ANY other application in the same directory
authenticates here), `IOF_ENGINE_OIDC_REQUIRED_ROLES`/`_REQUIRED_SCOPES`,
`IOF_ENGINE_OIDC_JWKS_URI`/`_ALGORITHMS`/`_LEEWAY_S`/`_JWKS_TTL_S`,
`IOF_ENGINE_API_KEYS` (32+ chars, refused shorter; comma OR newline separated
so a mounted secret file is read as several keys rather than one long one),
`IOF_ENGINE_DELEGATION_ROLE`, `IOF_ENGINE_AUTH_PUBLIC_AGENT_CARD`. Outbound,
on every caller: `IOF_ENGINE_CRED_MODE` (`oauth`|`apikey`|`off`, inferred from
what else is set), `_TENANT_ID` or `_TOKEN_URL`, `_CLIENT_ID`,
`_CLIENT_SECRET`, `_AUDIENCE` (the scope defaults to `<audience>/.default`,
the only value Entra accepts for this grant), `_API_KEY`. Full reference:
[docs/engine-authentication.md](docs/engine-authentication.md).

Concurrency: `IOBOT_MAX_CONCURRENT_REQUESTS` — iobot's default is 3; **`ioagentfarm serve` raises it to 10** unless `--concurrency` or the env var says otherwise.

**It does NOT bound the always-on agent pool, and believing it does is the trap here.** The semaphore is acquired in `AgentLoop._dispatch` — the bus path — only; `process_direct` takes the per-session lock and no gate. Every always-on surface (Studio chat proxy, A2A, Teams) calls `process_direct`.

**Our own ceiling: `IOF_POOL_MAX_CONCURRENCY`** (`web/pool_limit.py`, wrapped onto `process_direct` once in `AgentPool.get()` so every surface inherits it). **Unlimited by default** — unset or `0` returns the callable unwrapped, so the default build carries no wrapper at all and nothing changes. Set it and the pod caps concurrent agent turns; `IOF_POOL_QUEUE_TIMEOUT_S` (default 60) bounds the wait, after which the request is refused rather than queued forever.

The load-bearing detail is **acquisition order**: the per-session lock is taken FIRST, then the global slot — mirroring iobot's own `async with lock, gate`. Semaphore-first looks equivalent and is not: several requests on one session would each hold a global slot while all but one idle on the session lock, so one user double-clicking starves the pod. `tests/test_pool_limit.py` pins this, and the guard was checked against a deliberately-naive implementation to confirm it actually fails there.

Saturation is **not** an HTTP 503 today: A2A renders it as a JSON-RPC -32603 error and `/api/chat/*` as HTTP 200 with an `error` field, because both routers catch broadly around `process_direct`. The `PoolSaturated` handler in `app.py` is a fallback that no current surface reaches.

Measured on 0.3.0 (MiniMax), not inferred: baseline single call 2.06s; **6 requests across 6 sessions → 4.24s** wall against a 12.37s serial estimate (concurrent); **6 requests on ONE session → 11.57s** (the per-session lock holds, ordering is safe); and re-running with `--concurrency 2` changed nothing (3.79s), which is what proves the gate is absent from this path rather than merely generous. 0.3.0 also removed the global `_processing_lock` entirely — any doc still claiming AgentLoop serializes all sessions is stale.

Run-supervisor vars (self-healing for stuck runs — see `engine/supervisor.py` + docs/forensics.md §"Run supervision"): `IOF_SUPERVISOR` (default on; `0` disables the serve lifespan sweeper), `IOF_SUPERVISOR_INTERVAL_S` (default 60), `IOF_SUPERVISOR_STEP_STALE_S` (default 180 — reap a 'running' step whose heartbeat went quiet), `IOF_SUPERVISOR_NO_HEARTBEAT_GRACE_S` (default 900 — grace for rows with no heartbeat), `IOF_SUPERVISOR_DRIVER_STALE_S` (default 300 — resurrect the driver when runnable steps wait), `IOF_SUPERVISOR_MAX_RESUMES` (default 5 — beyond it the run fails with `supervisor_gave_up`).

A2A vars: `IOF_A2A_ENABLED` (default `true`; set `false` to skip mounting the surface). External A2A agent-registry discovery (env-gated, all default-off — full no-op unless the trigger is set): `IOF_AGENT_REGISTRY_URL` (trigger), `IOF_AGENT_REGISTRY_API_KEY`, `IOF_AINF_SELF_NODE_ID`, `REPORTING_BASE_URL`, `IOF_AGENT_REGISTRY_REFRESH_SECONDS` (default 300), `IOF_REGISTRY_CATALOG_AGENT` (which always-on agent receives the discovered `catalog_dynamic.yaml`). See `engine/ainf_registry.py`.

Learning-v2 vars — **v2 is DEFAULT-ON with zero keys (2026-08-08)**; every var below exists only to DEVIATE: `IOF_LEARNING_V2=0` (**learning OFF — not a fallback to v1**; the deprecated legacy pipeline additionally needs `IOF_LEARNING_V1=1`, and the MEMORY.md pipeline unpauses only on that two-key legacy opt-in; see "Learning lifecycle" above), `IOF_LEARNING_REVIEWER` (default = production `iobot` reviewer; `off` keeps attribution but stops authoring; `stub` for tests; `iobot` a silent legacy alias, never document it), `IOF_LEARNING_HUB` (default `stub` = local outbox/inbox files, no network; `http`|`enterprise` + `IOF_LEARNING_HUB_URL` when a real hub exists), **`IOF_LEARNING_INBOX_DIR`** (repoint the approved-skill store — read by `fetch_approved` AND written by `aicore learning approve` — at a GIT repo, so approval is a reviewed commit/PR; default `<IOF_ROOT>/hub_inbox`), `IOF_LEARNING_V1=1` (explicit legacy opt-in, only with `IOF_LEARNING_V2=0`), `IOF_REVIEWER` (approver identity for the audit trail; `--as` overrides), `IOF_PREFERENCES_DB` (separate feature, still default-off), `IOF_LEARNING_METHOD_DOMAINS` (JSON role→focus), `IOF_LEARNING_SIGNATURE_AGENTS`/`_ENTITIES` (domain vocab for the recurrence-signature). See `engine/learning/` and `docs/learning-governance.md`.

GenAI Bedrock wrapper vars (client-specific gateway for Claude): `IOF_USE_GENAI_BEDROCK` (set to `1`/`true` to activate the monkey-patch that swaps iobot's `AnthropicProvider` for `GenaiBedrockProvider`). `GENAI_API_KEY` (gateway API key — also accepted via iobot config `providers.anthropic.apiKey`). `GENAI_API_BASE` (gateway base URL, e.g. `https://genaiapigwna.jnj.com` — also accepted via config `providers.anthropic.apiBase`). `GENAI_MODEL` (Bedrock model ID, e.g. `us.anthropic.claude-opus-4-6-v1` — also accepted via config `agents.defaults.model`).

## Model providers (iobot integration)

ioagentfarm doesn't ship a model abstraction — it inherits iobot's provider system. Two vendored providers + monkey-patches in `ioagentfarm/_iobot_patches.py` cover client-specific gateways:

- **`AzureOpenAIChatProvider`** (`vendored/azure_openai_chat_provider.py`) — drop-in replacement for iobot's `AzureOpenAIProvider`. Targets the classic `/openai/deployments/<dep>/chat/completions?api-version=…` route instead of the v1 Responses API. Most enterprise Azure tenants only expose the classic surface. Always-on patch (toggle off with `IOF_DISABLE_AZURE_CHAT_PATCH=1`).
- **`GenaiBedrockProvider`** (`vendored/genai_bedrock_provider.py`) — drop-in replacement for iobot's `AnthropicProvider` when Claude traffic must route through the client's Bedrock-wrapper gateway (J&J GenAI API: `https://genaiapigwna.jnj.com`). Auth is API-key based (`X-Api-Key`), routes follow Bedrock Runtime's `POST /model/{modelName}/invoke` URL pattern, body is native Anthropic Messages format with `anthropic_version: "bedrock-2023-05-31"` injected. Opt-in via `IOF_USE_GENAI_BEDROCK=1`.

**GenaiBedrockProvider implementation invariants:**

- **Routes via `/invoke` (NOT `/converse`).** The wrapper exposes both endpoints; we picked `/invoke` because it returns native Anthropic-shaped responses (extra Bedrock-only fields like `amazon-bedrock-trace` are ignored cleanly by the SDK's pydantic models). `/converse` would require a separate translation layer for the Bedrock Converse request/response shape. Validated by `probe_bedrock_wrapper.py` against the actual gateway.
- **Auth header is `X-Api-Key`** (the wrapper also accepts lowercase `x-api-key`). `Authorization: Bearer …` returns 403 ForbiddenException; same for `api-key`. The httpx request hook strips the Anthropic SDK's auto-injected `x-api-key` + `anthropic-version` headers and replaces with `X-Api-Key`.
- **URL rewrite happens via httpx event_hook.** The Anthropic SDK hardcodes `/v1/messages` after `base_url`. Our hook parses each outgoing request body, extracts the `model` field, rewrites the URL to `{base}/model/{model}/invoke`, strips `model` from the body (Bedrock /invoke uses the URL path for model selection), and injects `anthropic_version: "bedrock-2023-05-31"` (Bedrock requirement).
- **Streaming falls back to non-streaming.** Wrapper doesn't expose `/invoke-with-response-stream` today. `chat_stream` calls `chat()` and yields the result as a single chunk so the agent loop's stream consumer doesn't break. Remove the override when the gateway adds streaming support.
- **Extends `AnthropicProvider`, not raw `LLMProvider`.** Reusing the parent's message formatting + tool-use loop + retry logic is the whole point of picking `/invoke`. Only the wire-level URL/auth differs from talking to `api.anthropic.com` directly.
- **Provider dispatch is monkey-patched at import time** in `_iobot_patches.apply_genai_bedrock_backend()` via the same module-attribute swap pattern as `apply_azure_chat_backend()`. Toggle: `IOF_USE_GENAI_BEDROCK=1`. Idempotent. No-op when the env var is unset (bundled `AnthropicProvider` stays active, talks to `api.anthropic.com`).
- **Probe script lives at the repo root.** `probe_bedrock_wrapper.py` exercises all 4 auth header conventions × 3 (endpoint, body shape) combinations and reports which one(s) the gateway accepts. Run this first when onboarding a new gateway variant before assuming the existing provider works. `probe_genai_provider.py` is the end-to-end smoke test that goes through iobot's `AnthropicProvider` interface to confirm tool-use + response parsing all work.

## Database

Pluggable backend: `Store -> DbAdapter (Protocol) -> SqliteAdapter | PostgresAdapter`. Tables: `runs`, `steps`, `stories`, `tasks`, `user_context`. Learning tables: `learning_log`, `learnings`, `learning_feedback`, `learning_history`; learning-v2 adds `user_preferences` + `user_group_membership` (self-provisioned when `IOF_PREFERENCES_DB` is on). See `docs/dbstore.md` and `scripts/setup_schema.sql`.

**`Store.init()` is ONE statement when the schema is current (2026-09-05).**
It ran the whole pass - ~40 CREATEs and ten column probes - on every
`_store()`: every CLI command, every web request. The full pass stamps a
digest of `_init_full`'s own SOURCE into `schema_meta`; a later `init` reads
that row and returns. Editing `_init_full` changes the digest, so an older
database replays the pass exactly once - nothing to bump. Two rules the same
pass produced: a web route that does synchronous store work and awaits
nothing is a plain `def` (FastAPI's threadpool), never `async def` - an AST
test refuses the shape; and a step transition is one conditional UPDATE
checked by rowcount (`claim_pending_step`, `claim_stale_running_step`), never
a read followed by a write. Record: docs/NEXT_PHASE_BACKLOG.md section Q.

**Studio/platform tables** (`ensure_platform_schema` is the SINGLE implementation
— the CLI reaches it via `ensure_schema`, the API via `workflow_defs.ensure_defs`,
so the two sides cannot drift): `studio_workspace_repos`, `studio_workspace_items`,
`studio_workspace_members`, `studio_workspace_settings`, `studio_workflow_defs`,
`studio_agent_defs`, `studio_skills`, `studio_agent_display`, `studio_skill_scripts`,
`pack_skills`. Auth: `user`, `user_password` (self-provisioned by `app/user_tables.py`).
`pack_skills` is declared in `engine/store.py` AND `ensure_platform_schema` AND
`scripts/setup_schema.sql` AND the API tests' hand-maintained duplicate: both
sides ensure their own schema, and a table that lands in some of those places
works in one environment and not another (it did — `ioagentfarm sync` died on
"no such table" until the store copy was added).

**`workspace_catalog` reads under SAVEPOINTs, for the same reason
(2026-08-27).** It makes a dozen reads on ONE connection and wraps each in
`except Exception: return []`, reasoning that a database where the Studio
tables were never created should read as "this workspace holds nothing". True
on SQLite. On PostgreSQL the FIRST failure aborts the transaction and every
later statement raises `InFailedSqlTransaction` - swallowed by the same
clause. Measured on a fresh schema: `studio_workflow_defs` is created by
`init`, not by `workspace create`, so its absence emptied members, settings,
repo and the run count, and `aicore workspace show` reported *"access nobody -
this workspace has no members, so it cannot be opened in the Studio"* with a
`fix:` line, about a workspace whose member row was present and which had
twelve runs. A false report is worse than an error because it reads as an
answer. Each read now takes its own SAVEPOINT. Pinned by
`tests/test_workspace_catalog_survives_a_missing_table.py`, whose fake cursor
carries psycopg2's abort semantics and which also runs against a real schema
with `IOF_TEST_PG_URL`.

**The case and play stores on PostgreSQL (2026-08-25).** They were validated
on Postgres by grammar alone and both failed on their FIRST real command in
a temp schema on RDS: a bare `ALTER … ADD COLUMN` loop aborting the
transaction, and dict rows (`RealDictCursor`) indexed by position. Rules
that hold now: every additive DDL statement runs inside a SAVEPOINT
(`casetier/store._guarded`), the schema is ensured once per process per
database, rows are read through `_one`/`_rows` and accessed BY NAME, and
every DDL template must parse under `pglast`. Never index a row by position
in these modules; never wrap a statement that may fail in a bare
`try/except`. **Every SQL statement lives in `casetier/repo.py` or
`tools/plays_repo.py` as a `SQL_*` constant, and a command opens the
database only through `store.session()`** — `test_sql_lives_in_the_repo.py`
refuses a `cur.execute` anywhere else. The meta suite runs on Postgres with
`IOF_TEST_PG_URL` + `IOF_TEST_PG_SCHEMA` (a scratch schema; it refuses the
real ones by name).

**`studio_skills` (2026-07-31)** gave a skill its own identity. Before it, a skill
was path-keyed entries inside EVERY carrying agent's `files_json` — one copy per
carrier, so one edit re-snapshotted N whole workspaces. Invariants:
- **No agent↔skill mapping table.** `roles_json` IS the assignment
  (`_validate_skill_payload` folds `install_to` into it). It records
  ACTUAL carriage, not declared frontmatter — a skill under
  `agents/<role>/workspace/skills/` is assigned by its LOCATION, and a
  boilerplate `roles: all` there would redistribute it into every agent.
- **Assignment is not ELIGIBILITY.** It sets an agent's BASELINE. Nothing
  refuses a skill to an agent — see "Skills are OPEN" below.
- **The agent sync key is composite** (`hydration.agent_sync_key`): agent hash ⊕
  carried skills' hashes. A skill edit does not move
  `studio_agent_defs.content_hash`, so without this every carrier would hold
  stale content forever, silently.
- **The join is INSIDE `hydrate_agent`'s build loop.** `_swap_in` rmtrees the
  target and `create_filtered_workspace` runs nothing afterwards to repair it —
  join later and every skill-filtered run gets an empty skills tree.
- **Pack/SDK skill CONTENT is NEVER stored here.** They arrive in wheels and
  change on upgrade; a tenant row would freeze a fork the SDK can never update.
  Excluded on BOTH directions (import and export) via `reserved_names()`, not a
  hardcoded name list — a skill added to `agentfarm-skills` is excluded
  automatically. A pack skill DOES get an **assignment-only** row here
  (`origin='pack'`, `files_json='{}'`): carriage is a tenant fact and has to be
  durable, and `carried_skills` resolves the files from the wheel every time.
  What it *is* is `pack_skills` — see below.

**`pack_skills` (2026-08)** is the GLOBAL skill catalog — what the installed
wheels ship — and the missing counterpart of `agents.pack`. Written by the
ENGINE (`engine/catalog_sync.sync_pack_skills`, reached via
`POST /api/skills/sync`; the CLI `sync`/`setup-agents` paths are retired
no-ops), read by the Studio API, which has no packs. Until it existed, the only trace a pack skill left in the database was
the assignment-only row above, so a correct deployment showed **no SDK skills
at all**. Invariants: not workspace-keyed (one row per deployment, so an SDK
upgrade lands everywhere at once — N per-workspace copies would be the fork
problem one level down); never exported; nothing materialises from it; and
every sync REWRITES what it finds and DELETES what it does not, so it cannot
go stale. `shared` marks the tier a tenant may not fork and is what
`_skill_editable` keys on. The agent half of the same idea is three columns on
`agents` (`soul`, `tools_md`, `skills_json`) rather than a second table,
because `agents` already IS that catalog.
- **Content is binary-safe** (`engine/filecodec.py`): non-UTF-8 files are base64
  behind a NUL-prefixed sentinel that cannot begin a text file. Text storage is
  byte-identical on purpose — change it and every `content_hash` moves,
  re-materialising everything on upgrade.

```bash
# PostgreSQL — no extra to install: psycopg2-binary is a HARD dependency of
# agentfarm-core, like the rest of the runtime stack. There is no [postgres]
# extra and there never was one in this layout; a doc that told a reader to
# pass it sent them after a flag pip would reject.
export IOF_DATABASE_URL="postgresql://user:pass@localhost:5432/ioagentfarm"
export IOF_DB_SCHEMA=iof     # everything lives in a named schema
ioagentfarm init             # needs CREATE on the database
```

`init` is idempotent. Where the app user has no CREATE rights, hand
`scripts/setup_schema.sql` to the DBA instead — but note that file is entirely
`CREATE TABLE IF NOT EXISTS`, so re-running it on an EXISTING database adds no
columns and an upgrade silently leaves new ones missing. `scripts/schema_doctor.py`
reports that delta and `--apply` closes it (columns only, never a drop, rename
or retype).

## Running the Studio locally (UI + API + engine)

Three processes, three ports. **Start them in this order** — the API asks the
engine for content, and the UI asks both.

```bash
# 1. ENGINE  (port 8111) — serves run + catalog APIs for ONE workspace
IOF_WORKSPACE=barrier_insights \
  .venv/Scripts/aicore serve --host 127.0.0.1 --port 8111

# 2. API  (port 8002) — the Studio backend the UI actually calls
cd apps/agentfarm-api
IOF_DATABASE_URL="<from ~/.iobot/workspaces/<ws>/.env>" \
IOF_DB_SCHEMA=iof IOF_AUTH_DEV=1 IOF_WORKSPACE=barrier_insights \
  ../../.venv/Scripts/python -m uvicorn app.main:app \
      --host 127.0.0.1 --port 8002

# 3. UI  (port 5173)
cd apps/agentfarm-ui && npm run dev
```

Then open **http://localhost:5173** and log in as a member email
(`sudhir@client.com` on this deployment) with **any password**.

**The details that cost an hour to find, each of which looks like something
else when you hit it:**

- **`serve` takes `--workspace <code>` (2026-08-19).** It sets
  `IOF_WORKSPACE` in the environment BEFORE resolution — the env var, not a
  local, because run subprocesses resolve their own workspace from the
  ambient environment and a server-only flag would split the deployment.
  Falls back to `IOF_WORKSPACE` / `active_workspace`; a conflicting env var
  is overridden loudly. (It had no such flag for a long time and passing it
  was a hard error — first client install made the asymmetry with every
  other workspace-scoped command obvious.)
- **8002, not 8000.** `apps/agentfarm-ui/.env.local` pins
  `VITE_WORKSPACE_API_BASE_URL=http://localhost:8002`; the API's own README
  says 8000. Vite bakes env at dev-server start — restart `npm run dev` after
  editing it.
- **Bind `127.0.0.1`, not the default `0.0.0.0`.** The ENGINE API has *no
  authentication at all* — anything that reaches 8111 can create runs in any
  workspace. On a laptop on a corporate network, serving a production
  database, the default bind is genuinely unsafe.
- **`IOF_AUTH_DEV=1` is required because the `user` table is empty**, and it
  is a real bypass: any credentials authenticate and the token carries
  whatever email is typed. It must never be set in a pod, and should not
  outlive the session. A `role='admin'` row in `studio_workspace_members` for
  ANY workspace is platform admin everywhere — on this deployment
  `sudhir@client.com` is admin on `default`, so dev login grants full rights.
- **One engine serves ONE workspace.** The API routes every workspace's
  catalog request to `localhost:8111`, so selecting a different workspace
  returns **409** (`this engine serves workspace '<x>'`) and the retired
  `default` returns **403**. Only the workspace the engine was started for
  works; run a second engine on another port for a second workspace.

### The latency and UX passes live in docs/

Four dated passes on the Studio (2026-08-17/18) - page latency (round-trip
COUNT, never work: 30s -> 3.3s), the page fan-out (six concurrent calls
against a one-connection pool; measure the pattern the browser produces),
the three follow-ups (`useWorkspaceEffect`, a REQUEST-scoped memo, one
`/counts` call, a pooled hub), and the UX pass (a dead `.agent-card` rule
centring a table) - are in
[docs/STUDIO_PERFORMANCE_NOTES.md](docs/STUDIO_PERFORMANCE_NOTES.md). The
rules that hold: assert the call COUNT, not that a batch helper exists;
`localhost` resolves to `::1` first - use `127.0.0.1`; never a TIME-based
catalog memo (tried and reverted - it serves a stale catalog); a grep
without a word boundary lies, and a React prop is a second spelling of an
attribute.

### Solution scoping: a NON-EMPTY include list is believed again (2026-08-17)

`barrier_insights` — settings row `include_packs='barrier_insights'` —
listed `ainf-meta-agent` (Pharma Intel) and four other AINF agents. Two
things combined, and the second is why the first was wrong:

* `_role_visible` was deliberately WIDENED to "anything the engine served
  with a pack label is in scope", on the premise that one engine serves one
  workspace and resolves only that workspace's installed packs — so its
  catalog IS the scope.
* That premise is false wherever ONE venv carries several solution packs,
  which is every developer machine and this deployment. Verified directly:
  nine packs installed, and `/api/catalog/agents?workspace=barrier_insights`
  returns all 22 of their agents — **the `workspace` parameter does not
  filter by pack**.

Now: a non-empty `include_packs` is honoured (only the tenant's OWN
Studio-built agent still passes without a pack — it has none to be in scope
by). An EMPTY list keeps the widening, because that is the case it was
written for: `seed_empty_scope` writes the row empty and its only filler,
`_scope_workspace_to_solution`, became unreachable when `workspace push`
became a no-op. Confusing the two would restore the original defect — a
solution team shown none of their own agents — so
`test_the_empty_scope_widening_is_untouched` pins the distinction.

`barrier_insights` went 12 agents -> **6** (Ava, Maya, Vera, Alex, Quinn,
Tess) and 32 skills -> 29; `hub_scribe` (Iris, pack `studio-agents`) went
with the AINF agents, which is correct under a strict list and is the choice
that was made deliberately rather than by default. Skills follow their
agents — the documented "agents AND the skills only their agents carry".
- **Do NOT "fix" this with a TIME-based catalog memo.** Tried and reverted: a
  2s cache on `_skill_catalog()` fails three
  `test_studio_reads_the_engine_catalog` tests because it serves a stale
  catalog after a change. Correctness first — the cost is round trips, not
  recomputation.


## Operational Insights — the hub v2 surface (2026-08-22)

The standalone-branded surface at `/insights/*` (own shell, reached from the
workspace menu → "Operational Insights") reads the pharma barrier_signal hub
through three read-only routers in `apps/agentfarm-api/app/routers/`:
`barrier_insights.py`, `signals.py`, `source_data.py`. **They read hub schema
v2 (`savant_data_hub_v2`: barriers/barrier_signals/signals/signal_evidence/
call_notes/insights/correlations + the KB meta tables).** They had been
written against the retired v1 columns (`barriers.title`, `lifecycle_status`,
`signal_sources`) while `hub_db.py` already defaulted to v2, so every page
500ed against the data — v1 held 0 barriers. Verify: `grep -n "lifecycle_status\|signal_sources" apps/agentfarm-api/app/routers/*.py` must hit only `hil_queue.py`/`playbook_templates.py`, which are STILL v1-only (the playbook tables were never ported; the shell tolerates their 500s — backlog M1).

- **Barriers is a workbench**: analytics strip (`/summary`) → register with facets → per-barrier Overview / Evidence drill (Miller columns: signals ▸ evidence ▸ call note) / Graph / Insights. URL is the state (`?barrier=&view=&signal=&evidence=` + filter keys); `insights-kit.tsx`'s `*Href` helpers are the only way pages link to each other — honour their keys.
- **The graph is the pack's projection, served per barrier.** `GET /barriers/{id}/graph` returns the closure below one barrier in the `iof-graph/v1` vocabulary of `solutions/pharma/tools/graph_projection.py` (node labels and edge types are pinned equal by `test_barrier_insights.py`, which parses that file), and `GET /graph/expand?label=&id=` walks SIDEWAYS from any node (other barriers at an account, other signals in a note). The UI (`barriers/evidence-graph.tsx`, React Flow 12 + dagre) reveals one hop per click from the root, never the hairball; collapse follows the projection's DOWN direction because the graph is cyclic (note → account ← barrier).
- **These routes are NOT tenancy-exempt.** `_TENANCY_EXEMPT_PREFIXES` does not list them, so every request needs a bearer and `X-Workspace-Id`. Every fetch on the surface goes through `useWorkspaceEffect`/`useWorkspaceKey` — the first cut used plain `useEffect` and failed the whole e2e suite in a fresh session (400, never refetched) while working in a browser that already held a workspace. Do not reintroduce an unkeyed fetch here.
- **PII:** person names leave the API as initials (`_mask_person`: `Dr. S. D.`, `A. M.`); `jnj_id`, `rep_persona_wwid`, `rep_persona_email`, `content_hash` are never selected (`BANNED_COLUMNS`, tested). Transcripts are verbatim, as the Call Notes page already was.
- **Round trips, again.** `source-data/summary` ran one `SELECT DISTINCT` per filter column — 25 trips, 5.5 s against RDS, paid by the sidebar on every click; `signals/summary` was 13 trips. Each is now one statement per table (filter values ride as `array_agg` subselects; breakdowns are one UNION ALL) and the shell fetches its counts once per mount. `trace`/`graph` are ~10 trips each (≈2.5 s) — backlog M4.
- **The engine-DB pool probe regression (b52575c0) is fixed here too:** `_checkout` ran `SELECT 1` with autocommit off, which opens an implicit transaction, and `get_db`'s `con.autocommit = True` was then refused ("set_session cannot be used inside a transaction") — the FIRST checkout of every pooled connection, so every Studio request 500ed on a fresh stack. The suite runs on SQLite and never took that path; the regression test gives the fake connection psycopg2's autocommit semantics.
- **THE HUB POOL SERVES A PAGE, NOT A REQUEST (2026-08-22).** The same cliff
  the ENGINE pool hit, in the pool nobody ported the fix to. `hub_db.py` opened
  at `minconn=2` while an Operational Insights page fans out to six or more hub
  reads, and psycopg2 holds an internal lock across a connect — so the rest
  queued. Measured: **eight concurrent hub calls 20.5s each, all finishing at
  the same instant** (serialisation, not slowness), against 2.5s for any one of
  them alone. Compounding it, `hub_cursor` closed the connection on ANY
  exception, and the Playbook pages raise `UndefinedTable` on every visit
  (their tables are v1-only) — so each visit destroyed a pooled connection and
  the pool stayed cold. `minconn` is 6, opened in the constructor; only
  `OperationalError`/`InterfaceError`/an already-closed connection are
  discarded. **20.5s → 5.5s**, and the e2e suite went 4.3 min with two failures
  → 1.5 min with none. The lesson is the one already on record two sections up:
  *measure the pattern the browser actually produces* — every one-call-at-a-time
  measurement of this API was correct and useless.
- **The surface is measured, not eyeballed:** `apps/agentfarm-ui/tests/e2e/audit-ux.mjs`
  computes real WCAG ratios against composited backgrounds, accessible names,
  focus affordance, horizontal spill and motion across 11 views, and prints the
  ELEMENT COUNT beside every result — because zero failures and zero elements
  are indistinguishable in a summary line, and a page that failed to render
  would otherwise report a clean bill of health. It also waits for the loading
  state to DETACH rather than for a clock: skeletons are `aria-hidden`, so a
  fixed wait measured a page that had not painted its text yet. Baseline 386
  contrast failures → 0 at both 1440 and 900 CSS px.
- **Local stack for a live test:** run your OWN pair — API `uvicorn app.main:app --port 8002` with `BARRIER_SIGNAL_DB_URL`/`BARRIER_SIGNAL_DB_SCHEMA=savant_data_hub_v2` + `IOF_DB_SCHEMA=iof_client` + `IOF_AUTH_DEV=1`, and `VITE_WORKSPACE_API_BASE_URL=http://localhost:8002 npx vite --port 5174`. The shared 5173 instance is bound to whatever API port it was started with (it pointed at 8004). **No `--reload` on Windows** — it logged "Reloading…" and never restarted. Gate: `python scripts/run_tests.py api`, `npm run typecheck`, and `PW_BASE_URL=http://localhost:5174 PW_API_URL=http://localhost:8002 PW_EMAIL=dev@local PW_PASSWORD=dev npx playwright test tests/e2e/barrier-insights.spec.ts` (data-adaptive, live hub).

## OPEN WORK

**The register is [docs/NEXT_PHASE_BACKLOG.md](docs/NEXT_PHASE_BACKLOG.md).**
Every outstanding item — platform and Studio — is collected there, sized, with
why it was parked and what done looks like. **Add new items there, not here.**

This section used to carry its own list. Two of those entries were found already
FIXED when the register was compiled, having been listed as open for weeks —
which is the hazard of a backlog kept inside an instruction file: read
constantly, revalidated never.

## Learning system redesign — SHIPPED as v2 (2026-08-08)

The redesign this section used to describe as a TODO landed as **learning v2**,
now the DEFAULT (zero keys — see the "Learning lifecycle" section for the
full mechanics, states, and env surface). The four original goals, and how v2
meets each:

1. **Capture method, not conclusions.** The distiller types every candidate
   METHOD / PREFERENCE / FINDING and **drops FINDING in code**; a second rail
   drops a method whose body quotes the session's own figures (a finding in
   disguise). So a learned skill is transferable technique, never "Caplyta
   24.3%".
2. **Learned skills encode reusable techniques** — hub-governed, recurrence-gated
   (a method is authored only when a novel approach recurs ≥K), and injected
   as `skills/<name>/SKILL.md` the runtime actually loads (the flat-file layout
   bug that made ingested skills inert is fixed).
3. **`_finalize_step` no longer anchors on conclusions.** The v1 observation
   capture is PAUSED under v2 (one dispatch in `hooks.finalize_step`), and
   MEMORY.md is neither loaded nor populated (`memory_v1_off` patch) — the
   pollution channel is closed, not filtered.
4. **Method is separated from conclusion by governance, not schema.** A draft
   is inert until a human approves it, now through a real review surface
   (`aicore learning …` + git-versioned inbox) with a security scan on the
   channel and an audit trail.

`learning: disabled` in workflow.yaml still exists as the per-workflow opt-out
of ALL learning (it no longer implies v1). **Still open** — the tabled
Hermes-comparison items in project memory ([[project-hermes-learning-comparison]]),
chiefly the enterprise steward CONSOLE (the `aicore learning` CLI is the interim
surface) and consumption economics (progressive disclosure as the approved
library grows).
