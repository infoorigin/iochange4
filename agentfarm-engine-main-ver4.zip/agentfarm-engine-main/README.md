﻿# ioagentfarm

Deterministic multi-agent workflow runner inspired by [antfarm](https://github.com/snarktank/antfarm), built on **iobot**, its vendored agent runtime (see `iobot/PROVENANCE.md`).

## Philosophy

**The engine never changes. You configure everything with files.**

Define a team of AI agents with distinct roles and personalities, point them at a goal, and let the deterministic pipeline handle the rest. Add a new workflow or agent team by creating markdown and YAML files — zero Python required.

## Architecture

```
User goal (CLI / Telegram / WhatsApp / MS Teams / Web / any iobot channel)
              |
    +---------v----------+
    |   Alex             |  <-- Project Lead (master orchestrator)
    |   assess + plan    |      always: true skill loaded every turn
    |   + signoff        |      decides inline vs spawn per step
    +---------+----------+
              |
  +-----------+-----------+
  |           |           |
+--v---+  +---v----+  +---v------+
| Dana |  |  Sam   |  | Chris    |
|Analyst| |Developer| |Reviewer  |
+------+  +--------+  +----------+
```

Alex orchestrates via `ioagentfarm` CLI commands as tools:
- **`next-step`** → what's next? which role?
- **`run-step`** → delegate to a sub-agent (sync or `--background` for async)
- **`step-complete`** → record inline step output, advance pipeline
- **`run-task`** → run ad-hoc agent tasks (sync or `--background`)
- **`task-list/update`** → track concurrent task results

## Install

```bash
python -m venv .venv
source .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -e .
ioagentfarm init
ioagentfarm list-workflows
```

For real LLM execution (not just echo testing):
```bash
pip install -e ".[iobot]"
# Configure ~/.iobot/config.json with your API key + model

# Seed agent workspaces with identity, skills, and memory (one-time)
ioagentfarm setup-agents --project-dir ./myproject
```

For the web API server:
```bash
pip install -e ".[web,iobot]"     # FastAPI + uvicorn + iobot
ioagentfarm serve --port 8000       # start the web API
```

For PostgreSQL support:
```bash
pip install -e .                    # psycopg2-binary is already a hard dep
cp env.example .env                 # edit with your PG connection details
ioagentfarm init                    # creates iof schema + tables automatically
```

For MS Teams, horizontal scaling, or sandbox isolation, see the relevant sections below.

## Quick start

```bash
# 1. Run the smoke test to verify your setup (3 steps: spec → build → check)
ioagentfarm run smoke_test --goal "Create a Python script that prints the current date"
ioagentfarm status --json

# 2. Full orchestrated run with a project directory (artifacts written here)
ioagentfarm run project_lead --goal "Build a CLI that lists files" --project-dir ./myproject

# 3. Follow-up on an existing project
ioagentfarm follow-up --goal "Add colorized output and --verbose flag"

# 4. Run a single agent task directly
ioagentfarm run-task --role developer --goal "Add input validation to the CLI parser"
```

## Starting a NEW solution — `ioagentfarm new-solution`

A domain team owns a repo containing **only their pack** — agents, skills,
workflows — and installs `agentfarm-core` + `agentfarm-skills` as the SDK. That
repo has five non-obvious things to get right, and every one of them fails
*quietly*: the `aicore.packs` entry point (missing → the pack installs and is
invisible), the package-data globs (missing → the wheel ships no workflows),
`aicore.solution.yaml` (not the same file as the entry point → empty Studio),
a skill's `roles:` starting assignment, and each agent carrying its own
`output_protocol`. `new-solution` writes a repo that has all five and runs
as-is.

```bash
ioagentfarm new-solution logistics --dir ../logistics-solution \
    --title "Logistics Intelligence" --code logistics
```

`--code` is the **workspace code** the Studio catalog is keyed by; it defaults
to the slug. The generated repo is git-initialised with one commit.

**Install it into the ENGINE's virtualenv.** Entry-point discovery is
per-environment: a pack installed in a different venv than the engine is
invisible to it — no error, just an empty catalog. (`pip install -e .` inside a
venv of the solution repo's own is the *target* state; it works once
`agentfarm-core` and `agentfarm-skills` are published to an index you can
reach, and fails with `No matching distribution found for agentfarm-core` until
then.)

```bash
cd ../logistics-solution
<engine>/.venv/Scripts/pip install -e ".[dev]"      # POSIX: .venv/bin/pip
<engine>/.venv/Scripts/pytest                       # the packaging contract
<engine>/.venv/Scripts/python -c "from ioagentfarm.packs import load_registry; print(sorted({p.name for p in load_registry().packs}))"
<engine>/.venv/Scripts/ioagentfarm setup-agents
<engine>/.venv/Scripts/ioagentfarm list-workflows   # expect logistics_report
```

Then give it a tenant workspace and load the catalog. `create` first — `attach`
refuses a workspace that does not exist:

```bash
ioagentfarm workspace create logistics --name "Logistics Intelligence"
ioagentfarm workspace attach logistics --url .      # local path or a git URL
ioagentfarm workspace diff   logistics              # preview; writes nothing
ioagentfarm workspace push logistics              # -> 3 added
```

Import brings **workflows, agents and skills**, and scopes the workspace to
this solution's pack so the Studio lists only its agents. It is fail-safe: an
item edited in the Studio is refused by name rather than overwritten, and the
batch applies whole or not at all. Go the other way with `workspace pull`
(writes files, never commits); remove the tenant with `workspace delete`.

```bash
ioagentfarm run logistics_report --goal "..." --dry-run   # validates, no tokens
ioagentfarm run logistics_report --goal "..."             # needs a model provider
```

### Growing it — `new-workflow`, `new-agent`, `new-skill`, `new-tool`

`new-solution` gives you ONE of each. Adding the second by hand runs straight
into the failures `lint-workflow` exists to catch — `requires_artifact` (no
`s`) loads clean and silently disables the fail-closed artifact gate, `skilz`
silently un-filters a role's skills — plus one of its own: an agent without its
own `output_protocol` emits no `STATUS:`/`OUTPUT:`, so every step it runs is
marked failed and retried to the cap. Run these from anywhere inside the repo:

```bash
ioagentfarm new-agent    carrier_reviewer --name "Rey"
ioagentfarm new-workflow carrier_review --steps "analyze:logistics_analyst,review:carrier_reviewer"
ioagentfarm new-skill    exception_triage --role carrier_reviewer  # omit --role for pack-level
ioagentfarm new-tool     window_math                               # script + entry point + tools.yaml
ioagentfarm new-skill    window_usage --tool window_math --role carrier_reviewer
```

A tool and its skill are **two commands**, deliberately. A console script is on
PATH — every agent can run it — so `new-tool --role` was scoping the paired
*skill* at one remove and reading as ownership it never had. `new-tool` writes
the executable and makes it reachable; `new-skill --tool <name>` writes the
skill that says when to run it, validated against the pack's `tools.yaml` so a
typo cannot produce a skill teaching an agent to run a binary that does not
exist; `--role` assigns that skill, and is optional (a pack-level tool skill is
one a workflow step names).

They share `new-solution`'s templates (one source, no second skeleton to
drift), `new-workflow` lints what it wrote, and nothing needs re-running — an
editable install reads the new files immediately. The exception is
`new-tool`: a console script is generated by pip at install time, not read
from your files, so that one needs `pip install -e .` again. The walkthrough is
[aicore_docusaurus/03-building-solutions/](aicore_docusaurus/03-building-solutions/01-agents-and-skills.md).

Business users can also create a workspace from **Administration →
Workspaces** in the Studio; the repo is still attached and imported by an
operator from the CLI, which is the only place git and the platform meet.

## Execution model

Three modes, unified by `run-step`:

**Mode 1: Synchronous** — `ioagentfarm run` invokes Alex via iobot subprocess. Alex delegates sub-agent steps via `run-step --step-key <key>` (blocking), loops through steps, reports final result.

**Mode 2: Background (JSON)** — `ioagentfarm run --json` creates the run, spawns Alex as a detached background process, and returns JSON immediately. Designed for agents (Jarvis/Teams) and integrations that need non-blocking execution.

**Mode 3: Async (gateway)** — `ioagentfarm start-gateway` launches Alex as a long-lived iobot gateway agent. Users interact via Telegram/WhatsApp/MS Teams/CLI/Web. Alex delegates via `run-step --background` (fire-and-forget) and picks up results on heartbeat ticks:
1. Check completed tasks → notify users → mark notified
2. Advance workflow → `next-step` → `run-step --background`
3. Handle new requests → `run-task --background` → ack user

Both modes use the **same code path**. The only difference is `--background`.

**Mode 4: Web API (horizontally scalable)** — `ioagentfarm serve` starts a FastAPI server. Workflow runs spawn as independent OS processes. Follow-up messages go to an in-process agent pool — per-session serial, cross-session concurrent, and currently *unbounded* (`IOBOT_MAX_CONCURRENT_REQUESTS` gates iobot's bus path, not `process_direct`). Stateless pods. Key endpoints:

| Endpoint | Purpose |
|----------|---------|
| `POST /api/run` | Create and start a workflow run |
| `GET /api/run/{id}/status` | Run + step status (auto-resolves stale runs) |
| `GET /api/run/{id}/stream` | SSE real-time output streaming |
| `POST /api/run/{id}/message` | Interactive chat with @agent routing |
| `POST /api/run/{id}/resume` | Resume a crashed/stale run from S3 state |
| `POST /api/run/{id}/task` | Spawn ad-hoc agent task within a run |
| `POST /api/agents/sync` | Publish the installed packs' AGENT catalog to the DB (name, pack, persona, skills) |
| `POST /api/skills/sync` | Publish the installed packs' SKILL catalog to the DB (`pack_skills`) |
| `POST /api/workflows/defs/sync` | Import pack workflows into `studio_workflow_defs` |
| `GET`/`DELETE /api/agents/{role}/memory` | This host's accumulated MEMORY.md (never DB-backed) |
| `POST /api/chat/queryngine` | Always-on NL-to-SQL + vectorfs federation → v1 JSON envelope |
| `GET /a2a/agents` | List always-on agents reachable via the A2A protocol |
| `GET /a2a/{role}/.well-known/agent-card.json` | Public A2A Agent Card (v0.3) |
| `POST /a2a/{role}` | A2A JSON-RPC endpoint (`message/send`, `tasks/get`, `tasks/cancel`) |

See `docs/web-api.md`, `docs/orchestration.md`, `docs/horizontal-scaling.md`.

### Always-on query engine (Quinn)

Alongside the orchestration modes above, the web API mounts an always-on query agent — **Quinn (queryngine)** — at `POST /api/chat/queryngine`. Quinn federates across structured sources (DuckDB / PostgreSQL / Parquet / CSV via `iof-query`) and unstructured sources (vector stores via `vectorfs`), returning an evidence-backed JSON envelope that UIs render without string-parsing prose.

```bash
curl -X POST http://localhost:8000/api/chat/queryngine \
  -H 'Content-Type: application/json' \
  -d '{"content": "Top 5 IT vendors by total spend. Respond with v1 envelope, all fields.",
       "agent": "queryngine",
       "sender_id": "my_user"}'
```

Response `content` is a single fenced JSON block matching the v1 schema: `{schema, answer, data, insight, evidence}`. See `docs/query_engine.md` for the full contract, latency targets, concurrency model (per-session scratch directories, `.no_discovery` marker), and the roadmap for production-grade items (SQL validation, semantic cache, governance).

### A2A — Agent2Agent protocol surface

Every always-on agent is also reachable through the standard A2A v0.3 JSON-RPC interface, so external agentic systems can discover and call them without speaking the bespoke `/api/chat/*` shape. Discovery, agent cards, and JSON-RPC dispatch all live under `/a2a/`:

```bash
# Discovery — flat list of A2A-enabled roles
curl http://localhost:8000/a2a/agents

# Per-agent public card (A2A spec v0.3 shape)
curl http://localhost:8000/a2a/jarvis/.well-known/agent-card.json

# Synchronous message/send (turn 1)
curl -X POST http://localhost:8000/a2a/jarvis \
  -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":"1","method":"message/send",
       "params":{"message":{"role":"user","messageId":"m1",
                            "parts":[{"kind":"text","text":"What can you do?"}]}}}'

# Follow-up — reuse the contextId from the previous response for multi-turn
curl -X POST http://localhost:8000/a2a/jarvis \
  -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":"2","method":"message/send",
       "params":{"message":{"role":"user","messageId":"m2","contextId":"ctx-...",
                            "parts":[{"kind":"text","text":"Tell me more"}]}}}'
```

v1 implements `message/send`, `tasks/get`, `tasks/cancel`. Streaming (`message/stream`, `tasks/resubscribe`) and push notifications return JSON-RPC `-32601` with capabilities advertising `streaming: false`. Agent Cards are authored in `ioagentfarm/agents/<role>/workspace/a2a-card.yaml`; missing files auto-generate a minimal card from the SOUL.md first paragraph. Toggle the whole surface with `IOF_A2A_ENABLED` (default on).

Session-mode POD consults can optionally route over the same A2A surface — set `IOF_A2A_CONSULT_BASE_URL=http://...` and `_consult_pod` will POST to `<base>/a2a/<pod_role>` instead of calling `process_direct()` in-process. This enables horizontal scaling of POD agents into separate pods/services without engine code changes; unset means today's exact in-process behavior.

## Session mode — Savant Strategy Lab

An interactive 3-agent experience for pharma commercial use cases: the **analyst** diagnoses a competitive barrier, the **strategist** composes a multi-prong counter-play via active-advisor dialogue, the **reviewer** scores it. Runs as a session, not a workflow — state machine in `ioagentfarm/session_engine/`, API at `/api/sessions/*`.

```bash
IOF_SESSION_BRANDS=tremfya ioagentfarm serve
```

Endpoints (full contract in `docs/agentfarm-sessions.md`):

```
POST /api/sessions/session                       -- create session (brand, mission)
POST /api/sessions/session/{id}/intel            -- trigger analyst signal detection + diagnosis
POST /api/sessions/session/{id}/intel/refine     -- analyst Q&A or re-analysis (auto-detected from intent)
POST /api/sessions/session/{id}/dialogue         -- strategist turn (initial play + mix-and-match edits)
POST /api/sessions/session/{id}/submit           -- lock play + reviewer scores
POST /api/sessions/session/{id}/challenge        -- user challenges a dimension; reviewer defends
POST /api/sessions/session/{id}/chat/{role}      -- post-submission Q&A with any agent
```

Each agent-response endpoint returns the chat text PLUS a structured `response_split` / `intel_brief_split` field — `{summary, detail, footer}` — for UI progressive disclosure. The strategist's `/dialogue` response also carries `coaching` (a `Coaching` block with `score_read` + ≤2 actionable `moves`). See "Session-mode invariants" in CLAUDE.md.

**Three-layer prompt composition** keeps domain knowledge at the right scope:

- **Engine prompt** (generic) — output shape, word caps, jargon ban, structural constraints
- **Goal-category playbook** (`goals/<cat>/<role>.md`) — role-level domain knowledge: diagnostic heuristics, voice, steelman ritual. Compounds across all missions in that category.
- **Brand skill** (`products/<brand>/skills/<role>.md`) — brand facts only (name, competitor landscape, role).

**Phase 4b principles** (see `CLAUDE.md` → Session-mode invariants):

- Mission YAML barrier entries are taxonomy only (`display_name` + one-line `definition`). No per-mission pattern→answer maps.
- Narrative = **≤110-word exec summary** (3 short paragraphs, blank-line separated). No title line, no "if you do nothing else" anchor. All structured detail (per-prong levers, impact ranges, kill criteria, measurement rubric) lives in `STRATEGY_JSON` / `REVIEW_JSON` — the UI renders those as cards.
- Compound-barrier scoring: datasets declare `hidden_barriers: [{barrier, weight, role}]`; the analyst earns weighted credit + compound bonus for naming a secondary in their rationale.
- Plain-English rule in every prose field (narrative and JSON): banned `SOV`, `CTR`, `NRx`, consultant-flex; substitute "share of attention", "click rate", "new prescriptions per week".
- **Chat-content stripping at persist time** — `_msg()` removes embedded `STRATEGY_JSON`, `COACHING_JSON`, `REVIEW_JSON`, `CHALLENGE_VERDICT_JSON`, `HYPOTHETICAL_STRATEGY_JSON` blocks from the persisted `messages.content` (structured state lives on the session). UI no longer sees JSON inside chat bubbles.
- **`messages.metadata` carries the split + structured updates** — JSON-encoded TEXT column. Always contains `metadata.split` for chat-style messages. Strategist outputs also carry `metadata.strategy` / `metadata.coaching` / `metadata.prior_impact_mn` ONLY on turns that re-emitted them (Q&A turns get just `split` — UI can use presence of these keys as the "should I repaint the canvas?" signal).
- **Prong-merge across turns** — when the strategist re-emits partial STRATEGY_JSON, the parser preserves untouched prongs from the prior session.strategy. To intentionally drop a prong, strategist must emit it with `status: "dropped"` explicitly (omission ≠ drop).
- **`step_key=chat-{role}`** on post-submission `/chat/{role}` messages so the UI per-role tabs filter cleanly via `?step_key=` without mixing in workflow messages (briefing / dialogue / reviewing use empty step_key).

UI rendering contract for the session feed (message types, component mapping, STRATEGY_JSON canvas spec, scorecard layout): `docs/ui-message-rendering.md`.

## Built-in workflows

| Workflow | Pipeline | Roles |
|----------|----------|-------|
| `project_lead` | assess → analyze → plan → implement → test → review → signoff | Alex, Dana, Sam, Chris |
| `feature_dev` | analyze → plan → implement → test → review | Dana, Sam, Chris |
| `story_loop` | create_stories (loop) → per-story implement/test/review → done | Dana, Sam, Chris |
| `bug_fix` | reproduce → isolate → patch → test → verify | Dana, Sam, Chris |
| `smoke_test` | spec → build → check | Dana, Sam, Chris |
| `data_analysis` | analyze_data → validate_results | Ria, Chris |
| `pharma_commercial_intelligence` | analyze → strategize → review | Dana, James, Chris |
| `edi_integrationWorkflow_analyst` | detect_context → generate specs → assess → validate → map → finalize | Dana, Chris |
| `procurement_intelligence` | analyze → strategize → review | **Iris (procurement_analyst)**, domain_consultant, Chris |
| `deck_build` | build_deck (HTML → editable PPTX + PDF) | domain_consultant |

## Built-in agents

5 consolidated roles, each with targeted skills:

| Name | Role | Skills | Key trait |
|------|------|--------|-----------|
| **Alex** | `project_lead` | orchestrate, dynamic_tasks, ask_subagent, status_reports, messaging | Systems thinker. Orchestrates, plans, signs off. Never writes code. |
| **Dana** | `analyst` | decompose_stories, edi_mapping | Evidence-first investigator + planner. Reads code, decomposes goals, generates EDI mappings. |
| **Sam** | `developer` | (output_protocol only) | Pragmatic craftsman. Minimal diffs, no gold-plating, raises blockers early. |
| **Chris** | `reviewer` | test_and_validate, enterprise_quality_gates | Testing + review + enterprise quality gates. Bugs over style, binary verdicts. |
| **Ria** | `data_analyst` | data_query | Precise data investigator. Translates questions into SQL via metadata, executes queries, reports results. |
| **Quinn** | `queryngine` | catalog_reader, data_query, vectorfs_query, result_composer | Always-on virtual data layer. Federates structured + vectorfs sources; emits v1 JSON envelope; concurrency-safe via session-hash scratch dirs. Not part of workflow orchestration — served from the web API pool for real-time NL queries. See `docs/query_engine.md`. |
| **Iris** | `procurement_analyst` | catalog_reader, grounded_analysis, it_vendor_management, data_query, vectorfs_query (+ IT-VMO domain pack) | Domain- & dataset-agnostic procurement analyst. Grounding-first: every figure traces to a query it ran (SQL + row count cited), recency computed vs today, gaps flagged not invented. Schema comes from the workflow's `{{metadata_dir}}`, never embedded — one Iris serves any procurement domain (IT vendors, SCM/SAP, …) via a swapped catalog + domain skill. The `analyze` role in `procurement_intelligence`. |

All workflow agents also have `output_protocol` (always loaded) — the STATUS/OUTPUT format and learning protocol. **Quinn deliberately does NOT load `output_protocol`** — the v1 envelope owned by `result_composer` is her output format, and two `always:true` format-directive skills would conflict.

### Board-ready decks — presentation + dataviz skills

Two shared `_common` skills let any agent turn a markdown deliverable into a board-ready deck. **HTML is the canonical, delivery-agnostic form:** the deck is authored once as HTML (layout taxonomy, story arc, theming) and rendered to **HTML / PDF / native editable PPTX** from that one source.

- **`presentation`** — the reasoning-heavy authoring skill (plan → per-slide HTML → assemble → export). `slides_export.js` renders the HTML: **PDF** via Playwright, **PPTX** via the `dom-to-pptx` v2.x CLI (native editable shapes, SVG kept as vectors). Charts/tables defer to `dataviz`.
- **`dataviz`** — the full data-viz method: form heuristic, color-by-job, a **runnable Python palette validator** (`scripts/validate_palette.py` — computes colorblind-safety, no Node), and `references/tables-as-exhibits.md` (McKinsey exhibit tables — data bars, Harvey balls, heat).
- **`deck_build` workflow** — build a deck autonomously (strategist role, fail-closed `requires_artifacts: [strategy.pptx]` gate).

**One-time deps** for export (must be in the deploy pod image):
```bash
npm install playwright dom-to-pptx pptxgenjs
npx playwright install chromium
```
Always verify a PPTX export isn't empty: `python -c "from pptx import Presentation; assert len(Presentation('deck.pptx').slides)>0"`.

> **Note on `dataviz` provenance:** it is a local copy of the bundled Claude Code `dataviz` skill (not an official Anthropic OSS release), vendored for team use with a provenance note in its `SKILL.md`. Don't re-vendor Anthropic proprietary skills without that awareness.

### TypeScript CLI tools (ts-skills)

Agents can also use CLI tools built in TypeScript, invoked via exec. The `ts-skills/` monorepo (turborepo) provides these tools:

| Package | CLI | Purpose | Agent skill |
|---------|-----|---------|-------------|
| `@ts-tools/vectorfs` | `vectorfs` | Read-only filesystem over vector DB — agents use `ls`, `cat`, `grep`, `find` instead of RAG | `vectorfs_query/SKILL.md` |

**Why a filesystem instead of RAG?** LLMs have seen billions of examples of `grep -ri 'auth' /docs` in training data. A custom `search(query, topK)` API is novel — the model must learn it from the system prompt. The filesystem interface has near-zero error rate because the model already knows it. See `docs/ts-skills.md` for the full rationale.

```bash
# Build and link (dev) — or let `cli-hub` do it declaratively (below)
cd ts-skills && npm install && npx turbo build
npm link -w vectorfs    # makes 'vectorfs' available on PATH

# Production (K8s pod)
# Pre-built in container image, env vars from ConfigMaps/Secrets
```

### CLI-tool provisioning — `cli-hub`

> **CLI tools only — not MCP tools.** A CLI tool is a shell executable an agent
> runs via `exec` (`vectorfs`, `iof-query`, deck deps). MCP tools are launched
> JSON-RPC servers with a different execution model (`mcp-add`/`mcp-list`). Don't
> conflate them; `cli-hub`/`tools.yaml` are for CLI tools exclusively.

A skill only *names* its CLI tool; something must put that binary on PATH.
`cli-hub` makes that **declarative**: each pack lists its CLI tools in a
`tools.yaml`, and core validates-or-installs them at setup time (validate-first,
so it's a no-op where the container already baked the tool in).

Each tool has an `owner` (`core` / `shared` / `domain` / `cli-hub` — mirrors the
3-tier skills model) and an `installer` (`pip` / `npm` / `npm-global` / `brew` /
`build`). Core declares its own (`agentfarm-core/ioagentfarm/tools.yaml`:
`iof-query`, `vectorfs`); domain packs declare theirs.

```bash
ioagentfarm cli-hub list                 # declared CLI tools + presence
ioagentfarm cli-hub check                # validate-only (container/CI). exit 0 ok / 3 gaps / 1 error
ioagentfarm cli-hub install              # validate-or-install the gaps (also run by setup-agents)
ioagentfarm cli-hub install --dry-run    # show the plan, no changes
```

**Build-from-source** (`installer: build`) — for tools with no registry
artifact. `@ts-tools/vectorfs` isn't published to npm, so it declares a build
recipe (`{repo, ref, subdir, steps}`) and is compiled + linked on demand.
Building runs shell steps, so it's **opt-in**:

```bash
# Build vectorfs locally from source (dev, no container):
AGENTFARM_TOOLS_SRC_ROOT="$PWD/ts-skills" \
  ioagentfarm cli-hub install --only vectorfs --allow-build
# gap → npm install && turbo build && npm link → installed;  re-run → ready (no rebuild)
```

Tabled: the `cli-hub` remote source (`AGENTFARM_CLI_HUB_URL`) and on-demand
runtime install. See the CLI-tool provisioning section in `CLAUDE.md` for the
full model.

### Connecting MCP tools

The agent runtime ships a complete MCP client (stdio / SSE / streamable-HTTP);
each connected server's tools register live into every agent in scope as
`mcp_<server>_<tool>`. The platform adds only the declaration layer — three
tiers, higher tier wins by server name: a pack's `mcp.yaml` (shipped defaults),
the global `~/.iobot/config.json` (operator), and the workspace's
`~/.iobot/workspaces/<code>/mcp.yaml` (tenant, highest).

```bash
ioagentfarm mcp-add fetch --command npx --args "-y,@modelcontextprotocol/server-fetch"
ioagentfarm mcp-add search --url https://mcp.example.com/mcp \
    --header "Authorization=Bearer ${MCP_SEARCH_TOKEN}"     # ${VAR} stays unexpanded on disk
ioagentfarm mcp-list                                        # merged view + provenance per server
ioagentfarm new-skill search_usage --mcp-server search      # the judgement doc (not a gate)
```

Secrets are referenced (`${VAR}`), never stored; a server referencing an unset
variable is dropped from generated configs with a logged warning rather than
aborting the run. Containers declare servers via the `IOF_MCP_SERVERS` JSON
env var. Full model: [docs/mcp-integration.md](docs/mcp-integration.md);
runnable validation: [examples/mcp-a2a-lab/](examples/mcp-a2a-lab/README.md).

### Federating with external A2A agents

External A2A v1.0 agents are workspace-level shared content: register them once
per workspace and any agent carrying the shared `a2a_consult` skill can route
questions to them. `iof-consult` is the transport (parallel JSON-RPC fan-out,
per-endpoint auth headers with `${VAR}` references resolved at dispatch time
from the workspace `.env`); the skill is the judgement — route by each entry's
description/tags/examples, combine results, name failed agents instead of
inventing data.

```bash
ioagentfarm a2a-add partner-insights https://partner.example.com/a2a/insights \
    --description "Partner market-insights agent" --tag market-share \
    --header "Authorization=Bearer ${PARTNER_A2A_TOKEN}"
ioagentfarm a2a-list        # entries + whether each ${VAR} resolves (values never printed)
```

Registered agents materialize into agent workspaces as
`metadata/external_agents.yaml` at pool warmup and run creation — the same
`agents[]` shape the env-gated dynamic registry writes, so the skill reads
both identically. Full model: [docs/a2a-integration.md](docs/a2a-integration.md);
runnable validation: [examples/mcp-a2a-lab/](examples/mcp-a2a-lab/README.md).

### Goal-oriented swarms

A solution is a collection of **workflows** (deterministic DAGs) and
**swarms** — the goal-oriented counterpart: one meta-agent, a goal, and a
roster of capabilities (external A2A agents + MCP servers), with the route
decided at runtime under predefined controls, a hard tool-call budget, and a
checkpoint file that lets a retried attempt resume instead of restart. A
swarm compiles into a one-step run at creation, so it inherits the entire
run resilience stack — retries, forensics, the fail-closed deliverable gate,
the attempt cap, supervisor recovery — with no second engine.

```bash
ioagentfarm new-swarm portfolio_review --role intel_orchestrator --agents rx-sales,market-voice
ioagentfarm run-swarm portfolio_review --goal "Assess ORALIA risk for 2026-Q3"
```

Full model: [docs/swarms.md](docs/swarms.md); schema:
[docs/reference/swarm-yaml.md](docs/reference/swarm-yaml.md).

### Agent setup

`setup-agents` seeds iobot workspaces at `~/.iobot/agents/<role>/workspace/` from bundled templates:

```bash
# Seed all 4 agent workspaces (one-time, idempotent — skips existing files)
ioagentfarm setup-agents --project-dir ./myproject

# Seed specific roles only
ioagentfarm setup-agents --roles "analyst,developer"

# Force-update identity and skill files (preserves memory/MEMORY.md)
ioagentfarm setup-agents --force
```

Use `--force` after upgrading ioagentfarm to pick up updated SOUL.md, skills, and other identity files. Memory is never overwritten — agent learnings always persist.

Each workspace gets:
```
~/.iobot/agents/<role>/workspace/
├── SOUL.md              ← who the agent is (personality, constraints)
├── AGENTS.md            ← how the agent interacts with others
├── TOOLS.md             ← what tools the agent can use
├── USER.md              ← user interaction style
├── HEARTBEAT.md         ← heartbeat tick behavior
├── memory/MEMORY.md     ← accumulated learnings (persists across runs)
└── skills/              ← capability files (filtered per workflow)
    ├── output_protocol.md
    ├── decompose_stories.md   (analyst)
    ├── edi_mapping.md         (analyst)
    ├── test_and_validate.md   (reviewer)
    └── ...
```

Skills are seeded once and filtered at runtime — each workflow YAML declares which skills to load per role (see [Per-workflow skill filtering](#per-workflow-skill-filtering)).

## Per-workflow role configuration

Each role in a workflow YAML supports optional `skills` and `model` fields:

```yaml
roles:
  - name: analyst
    prompt: roles/analyst.md
    skills: [decompose_stories]              # skill filter (optional)
    model: anthropic/MiniMax-M2.5            # model override (optional)
  - name: developer
    prompt: roles/developer.md
    model: anthropic/MiniMax-M2.7            # different model per role
  - name: reviewer
    prompt: roles/reviewer.md
    skills: [test_and_validate]
    # no model → falls back to ~/.iobot/config.json default
```

### Skill filtering

| `skills:` value | What loads |
|---|---|
| omitted or `null` | **All** skills from the agent workspace (default) |
| `[]` | Only `output_protocol` (bare minimum) |
| `[edi_mapping]` | `edi_mapping` + `output_protocol` |

### Per-role model override

| `model:` value | What happens |
|---|---|
| omitted or `null` | Uses the default model from `~/.iobot/config.json` |
| `anthropic/MiniMax-M2.5` | Creates a per-role config with this model for that agent's step execution |

At runtime, `run-step` creates a role-specific config (e.g., `config_analyst.json`) with the model override. If the role model matches the default, no extra file is created. The same agent can use different models in different workflows.

**Current assignments:**

| Workflow | Analyst | Reviewer | Data Analyst |
|----------|---------|----------|--------------|
| `project_lead` / `feature_dev` / `story_loop` | `decompose_stories` | `test_and_validate` | — |
| `bug_fix` | (output_protocol only) | `test_and_validate` | — |
| `data_analysis` | — | (output_protocol only) | `data_query` |
| `edi_integrationWorkflow_analyst` | `edi_mapping` | `enterprise_quality_gates` | — |

At runtime, `run-step` creates a **filtered workspace** at `.iof/instances/<run_id>/workspaces/<role>/` with only the specified skills, identity files, and memory. Both skill `.md` files and skill subdirectories (e.g. `skills/cli/`) are copied. After step completion, memory updates are persisted back to the real workspace.

**Adding a new skill:** Create the `.md` file (and optional subdirectory) in the agent's workspace, add it to `skills:` in the workflow YAML, run `ioagentfarm setup-agents`. No Python changes needed.

## Communication & templating

Agents **never talk directly** to each other. Communication flows through step output templating and a shared progress file.

Step prompts support `{{var}}` syntax:

| Variable | Description |
|----------|-------------|
| `{{goal}}` | The user's original goal |
| `{{progress}}` | Current pipeline status (markdown) |
| `{{step_output.<key>}}` | Output from a prior step (e.g. `{{step_output.analyze}}`) |
| `{{story_id}}` | Current story ID (in story_loop) |
| `{{run_id}}` | Current run identifier |
| `{{attempt}}` / `{{max_attempts}}` | Retry tracking |
| `{{role}}` | Current agent role |

## Agent learning

Agents learn from experience using **iobot's native memory system**:

```
Run 1: Dana hallucinates a signal (no source record)
  → Chris catches it → step fails → retry succeeds
  → Alex logs to Dana's memory: "Verify claims against actual record counts"

Run 2: iobot loads MEMORY.md natively → Dana double-checks → no hallucination

Run 10+: Dana has accumulated domain knowledge → she's a domain specialist
```

Every agent's workspace has `memory/MEMORY.md` (long-term learnings) which iobot's ContextBuilder auto-includes in every prompt via `--workspace`. Agents write learnings after each task. Alex captures cross-agent patterns at signoff. No retraining — the LLM reads accumulated memory and naturally adjusts.

| Learning type | Example |
|------|---------|
| **Failure patterns** | "Single-source signals should not be elevated to patterns. Minimum 3 sources." |
| **Success patterns** | "Cross-role triangulation (OS + FRM data) produces highest confidence signals." |
| **Domain knowledge** | "Commercial payers say 'prior auth', Medicare says 'coverage determination'." |

## Project context & follow-ups

Follow-ups let you continue working on the same project across multiple runs (like `git checkout`):

```bash
ioagentfarm run project_lead --goal "Create helloworld CLI" --project-dir ./myproject
ioagentfarm follow-up --goal "Add colorized output and --verbose flag"
# → inherits project_dir, injects prior run summary, defaults to feature_dev workflow

ioagentfarm use-run <run_id>                 # switch active project context
ioagentfarm follow-up --goal "Fix the bug"   # follows up on that project
```

## Multi-user support

Every run and task is tagged with a `user_id` (format: `<channel>:<identifier>`). CLI defaults to `cli:<os_username>`.

```bash
# Scoped operations
ioagentfarm run project_lead --goal "Feature A" --user-id "telegram:111" --json
ioagentfarm status --user-id "telegram:111"    # user's runs only
ioagentfarm status --all                        # all users' runs

# Ad-hoc concurrent tasks (gateway mode)
ioagentfarm run-task --role reviewer --goal "Re-test auth" --user-id "telegram:111" --background
ioagentfarm task-list --status done             # Alex checks on heartbeat tick
ioagentfarm task-update --task-id <id> --status notified
```

In gateway mode, iobot's channel provides the user identity. Alex passes `--user-id` to all CLI commands automatically.

## Gateway mode

```bash
ioagentfarm setup-agents --project-dir ./myproject

# Telegram channel (uses iobot's native Telegram integration)
ioagentfarm start-gateway --project-dir ./myproject --channel telegram

# For an HTTP surface, use the web API instead of a gateway channel
ioagentfarm serve --port 8111
```

Users interact with Alex via Telegram, WhatsApp, Web, or any iobot channel. Alex uses ioagentfarm CLI commands as tools to manage workflows, spawn sub-agents, and track tasks.

### MS Teams channel

The Teams channel integrates with Microsoft Teams via the Bot Framework connector protocol — no Microsoft SDK dependency, just HTTP + JSON. Install with `pip install -e ".[web,iobot,teams]"`.

**UX model: Thread = Run.** A new @mention creates a workflow run in a new Teams thread. Replies in the thread are follow-ups on that run. Jarvis routes all requests — users just talk naturally.

```
User @AgentFarm: Analyze the Q3 shipping data for late ASNs
  └── Thread:
      ├── Bot: Workflow started (edi_business_ops, 3 steps)
      ├── Bot: analyze_data (Dana) — done
      ├── Bot: validate_results (Chris) — done
      ├── Bot: [Result card with summary]
      └── User: Drill into pattern #2       ← follow-up in same thread
```

#### Local testing with Agents Playground

No Azure registration needed. The [Microsoft 365 Agents Playground](https://learn.microsoft.com/en-us/microsoft-365/agents-sdk/test-with-toolkit-project) is a browser-based chat tool that sends Activity JSON directly to your local endpoint.

```bash
# 1. Install the Agents Playground
npm install -g @microsoft/m365agentsplayground

# 2. Start ioagentfarm in emulator mode
TEAMS_EMULATOR=true ioagentfarm serve --port 8111

# 3. Connect the playground to your local server
agentsplayground -e "http://localhost:8111/api/teams/messages" -c "emulator"
```

This opens a browser chat window. Type a message — it POSTs an Activity to your endpoint, Jarvis processes it, and the reply appears in the chat. The full agent pipeline runs (Jarvis routing, workflow execution, message persistence) exactly as it would in production.

You can also test with plain `curl`:

```bash
curl -X POST http://localhost:8111/api/teams/messages \
  -H "Content-Type: application/json" \
  -d '{
    "type": "message",
    "text": "What workflows are available?",
    "from": {"id": "user1", "name": "Sudhir", "aadObjectId": "test-123"},
    "recipient": {"id": "bot1", "name": "AgentFarm"},
    "conversation": {"id": "conv-1", "conversationType": "personal"},
    "serviceUrl": "http://localhost:8111",
    "channelId": "emulator"
  }'
# Returns 200 immediately — check /api/teams/health for status
```

#### Production deployment (real Teams)

1. **Azure Bot registration** — Create an Azure Bot resource in Azure Portal. Note the App ID and create a Client Secret. Set the messaging endpoint to `https://your-domain/api/teams/messages`.

2. **Teams app manifest** — Create a `manifest.json` with your bot ID, package as `.zip` with icon files, upload to Teams Admin Center > Manage apps.

3. **Configure and start:**
   ```bash
   export TEAMS_APP_ID=<app-id-from-azure>
   export TEAMS_APP_SECRET=<client-secret>
   export TEAMS_TENANT_ID=<your-tenant-id>
   ioagentfarm serve --port 8111
   ```

4. **Verify** — @mention the bot in a Teams channel. Jarvis should respond. Check `GET /api/teams/health` for status.

JWT tokens from Microsoft are validated against the JWKS endpoint (`https://login.botframework.com/v1/.well-known/keys`), with tenant restriction when `TEAMS_TENANT_ID` is set.

See `docs/teams-integration.md` for the full architecture, UX design, manifest example, and deployment guide.

### Web channel (removed)

`start-gateway --channel web` used to start an in-tree HTTP/WebSocket adapter (`ioagentfarm.channels.web`). It was **removed** in the iobot 0.3.0 upgrade; the command now exits with a pointer to `ioagentfarm serve`.

It had been deprecated on the grounds that iobot's `AgentLoop` held a global `_processing_lock` that serialized every session on a pod. **That is no longer true** — 0.3.0 removed the global lock in favour of per-session locks (`loop.py`, *"per-session serial, cross-session concurrent"*) plus a `IOBOT_MAX_CONCURRENT_REQUESTS` semaphore. It was removed anyway, because the lock was never the real reason to prefer `serve`: a chat channel has nowhere to put run-scoped SSE, workspace tenancy, auth, or the A2A surface. Those are properties of a run-oriented API, not a transport.

## Extensibility

**The entire framework is role and workflow agnostic. You add files, not code.**

```
Engine (never changes)          You configure (just files)
─────────────────────           ──────────────────────────
scheduler.py                    workflow.yaml  ← pipeline shape + deps
store.py                        steps/*.md     ← what each agent is told
workspaces.py                   SOUL.md        ← who the agent is
orchestrate.md skill            roles/*.md     ← role personality per workflow
                                skills/*.md    ← per-workflow capabilities
```

### Example: add a `research` workflow

```
ioagentfarm/
  agents/
    data_analyst/workspace/     ← NEW — Maya's identity
      SOUL.md, AGENTS.md, TOOLS.md, USER.md, HEARTBEAT.md, memory/MEMORY.md
    strategist/workspace/       ← NEW — Raj's identity
      ...
  workflows/
    research/                   ← NEW
      workflow.yaml
      roles/project_lead.md, data_analyst.md, strategist.md
      steps/brief.md, gather.md, analyze.md, synthesize.md, report.md
```

**workflow.yaml:**
```yaml
name: research
description: Research workflow — brief → gather → analyze → synthesize → report

roles:
  - name: project_lead
    prompt: roles/project_lead.md
  - name: data_analyst
    prompt: roles/data_analyst.md
  - name: strategist
    prompt: roles/strategist.md

steps:
  - key: brief
    role: project_lead
    prompt: steps/brief.md
  - key: gather
    role: data_analyst
    deps: [brief]
    prompt: steps/gather.md
    fresh_session: false
  - key: analyze
    role: data_analyst
    deps: [gather]
    prompt: steps/analyze.md
    fresh_session: false
  - key: synthesize
    role: strategist
    deps: [analyze]
    prompt: steps/synthesize.md
  - key: report
    role: project_lead
    deps: [synthesize]
    prompt: steps/report.md
```

**SOUL.md** — just markdown:
```markdown
# Maya — Data Analyst

You are Maya, a precise and methodical data analyst.
- Source credible data (primary over secondary)
- Flag uncertainty and data quality issues honestly
- Never fabricate statistics — acknowledge gaps explicitly
```

**Step prompt** — plain markdown with `{{var}}` templating:
```markdown
## Research brief
{{step_output.brief}}

## Your task
Gather quantitative data, statistics, and citations for the above brief.
```

**No Python changes. No engine changes. Just files.**

### Domain examples

| Workflow | Agents | Use case |
|----------|--------|----------|
| `research` | data_analyst, strategist | Market research, competitive analysis |
| `content` | researcher, writer, editor | Blog posts, documentation |
| `sales` | prospector, qualifier, closer | Lead research and outreach |
| `legal` | paralegal, counsel | Contract review, compliance checks |
| `devops` | infra_analyst, sre | Incident investigation and response |

### Edit workflows locally

```bash
ioagentfarm workflow-install project_lead   # copies to .iof/workflows/project_lead/
# edit workflow.yaml or any step prompt
ioagentfarm workflow-uninstall project_lead # reverts to bundled
```

## Database backend

SQLite by default. PostgreSQL optional:

```bash
export IOF_DATABASE_URL="postgresql://user:pass@localhost:5432/ioagentfarm"
ioagentfarm init
```

Custom backends implement the `DbAdapter` protocol (9 methods, no inheritance required). See `docs/dbstore.md`.

**Tables:** `runs` (workflow tracking), `steps` (step state & outputs), `stories` (story_loop), `tasks` (ad-hoc spawn tracking), `user_context` (per-user active run), `messages` (unified conversation thread), `teams_thread_map` (Teams thread-to-run mapping), `teams_conversation_refs` (proactive messaging refs).

**Task lifecycle:** `pending → running → done/failed → notified`

## Step recovery

```bash
ioagentfarm step-retry --step-key <key>                  # reset failed step, bump max_attempts
ioagentfarm step-skip --step-key <key>                   # mark done with SKIPPED, unblocks downstream
ioagentfarm step-retry --step-key <key> --crash-recovery  # reset stuck/crashed step to pending (no feedback)
```

## Workspace & sandboxing

`IOBOT_WORKSPACE` points to the **project directory** (via `--project-dir`) — agents read input files and write code/artifacts there. OUTPUT.txt is written to the step output directory (`.iof/runs/<run_id>/steps/<step_key>/`) via an explicit absolute path in the task prompt.

**Two-layer isolation:**
- **`--workspace`** (per-role): Identity loading — SOUL.md, MEMORY.md, skills. At `~/.iobot/agents/<role>/workspace/`.
- **`--config`** (per-run): MCP servers, logs, cron. At `.iof/instances/<run_id>/config.json`.

**Soft sandbox:** Set `IOF_SANDBOX=true` to enable iobot's `tools.restrictToWorkspace` — confines iobot's own tools to the project directory. Off by default.

**Hard sandbox (OpenShell):** Set `IOF_RUNNER=sandbox` for real OS-level isolation via NVIDIA OpenShell. See [Sandbox isolation](#sandbox-isolation) below.

## Sandbox isolation

Agents can be isolated inside NVIDIA OpenShell sandboxes — one sandbox per workflow, with L7 network policies, credential filtering, and filesystem restrictions.

### Quick setup

```bash
# 1. Install OpenShell (requires Docker)
curl -LsSf https://raw.githubusercontent.com/NVIDIA/OpenShell/main/install.sh | sh

# 2. Enable sandbox mode
echo "IOF_RUNNER=sandbox" >> .env

# 3. Start server — pre-warmed sandboxes created at startup
ioagentfarm serve --port 8111
```

No Docker? Set `IOF_RUNNER=sandbox` anyway — the system auto-detects and falls back to a stub client that exercises the full sandbox flow locally without isolation.

### How it works

Each workflow gets its own OpenShell sandbox with a declarative YAML policy controlling network access, filesystem, and process restrictions:

```
Orchestrator (host)
  └── openshell exec iof-dev -- iobot agent ...
      └── Inside sandbox:
          ├── Landlock: /sandbox + /tmp only
          ├── seccomp: no privilege escalation
          ├── Network L7 proxy:
          │   ├── api.github.com: GET repos, POST pulls — only via gh/git
          │   ├── inference.local: POST only (credentials injected by gateway)
          │   ├── 169.254.169.254: BLOCKED (metadata)
          │   └── *: BLOCKED (deny-all)
          └── Agent subprocesses run here
```

### Configure per workflow

Add a `sandbox:` block to your workflow YAML:

```yaml
name: feature_dev
# ... roles, steps ...

sandbox:
  policy: developer        # policy file from engine/sandbox_policies/
  prewarm: true            # create sandbox at server startup (zero latency)
  idle_timeout: 0          # 0 = never destroy (always-on)
  pool: dev                # share sandbox with other workflows using same pool
```

| Field | Default | Description |
|---|---|---|
| `policy` | `default` | Policy YAML name — resolves to `engine/sandbox_policies/<name>.yaml` |
| `prewarm` | `false` | Create sandbox at server startup? |
| `idle_timeout` | `300` | Seconds before idle sandbox is destroyed (0 = never) |
| `pool` | (none) | Share sandbox with workflows using the same pool name |

### Built-in policies

| Policy | Network access | Used by |
|---|---|---|
| `minimal` | Inference + DB only | pilot_build |
| `default` | + PyPI | custom workflows |
| `edi` | + S3 (no DELETE) + PyPI | edi_mapping, edi_business_ops, edi_tech_support |
| `developer` | + GitHub (no DELETE) + PyPI + npm | feature_dev, bug_fix, project_lead, story_loop |
| `data_pipeline` | + S3 (no DELETE) + PyPI | data_pipeline_provisioning |

All policies include: deny-all catch-all, gateway block, cloud metadata block, filesystem deny.

### Create a custom policy

Copy an existing policy and edit:

```bash
cp ioagentfarm/engine/sandbox_policies/default.yaml \
   ioagentfarm/engine/sandbox_policies/my_policy.yaml
# Edit network_policies to add/remove endpoints
ioagentfarm policy-validate my_policy    # validate before use
```

Then reference in your workflow YAML: `sandbox: { policy: my_policy }`.

### Sandbox CLI commands

```bash
ioagentfarm sandbox-list          # show all workflow sandbox configs
ioagentfarm sandbox-status        # show active sandboxes (IOF_RUNNER=sandbox only)
ioagentfarm policy-validate       # validate all policy files
ioagentfarm policy-validate dev   # validate one policy
```

### Security features

- **Credential filtering** — only whitelisted env vars pass into sandboxes (GITHUB_TOKEN, AWS_* stripped)
- **Anti-spoof token** — cryptographic nonce prevents IOF_SANDBOX_ID forgery
- **Session isolation** — iobot sessions scoped by sandbox name (no cross-workflow leakage)
- **Health checks** — dead sandboxes auto-detected and recovered every 5 minutes
- **Audit logging** — structured JSON for all sandbox operations
- **Max sandbox limit** — `IOF_MAX_SANDBOXES` (default 20) prevents resource exhaustion

See `docs/sandbox-strategy.md` for the full design rationale and security review.

## Configuration

### Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `IOF_ROOT` | `.iof` | Root state directory |
| `IOF_DATABASE_URL` | `sqlite:///{IOF_ROOT}/state.db` | Database connection URL |
| `IOF_SANDBOX` | (unset) | Set to `true` to restrict agent tools to project directory (soft sandbox) |
| `IOF_RUNNER` | `local` | `local` (no sandbox), `sandbox` (OpenShell), `k8s` (K8s Jobs) |
| `IOF_SANDBOX_STUB` | (unset) | `true` = stub client for testing without Docker |
| `IOF_MAX_SANDBOXES` | `20` | Maximum concurrent sandboxes |
| `IOF_STEP_TIMEOUT` | `600` | Subprocess timeout in seconds (note: the local agent invoker uses an unbounded `proc.wait()`; the per-LLM-call cap below is the effective timeout) |
| `IOF_REQUEST_TIMEOUT_S` | `180` (set to `600` in `.env`) | Per-LLM-call timeout — caps a single stuck `chat()` coroutine. Raised for slow MiniMax compose turns (deck authoring, large sections). |
| `IOF_A2A_ENABLED` | `true` | Mount the A2A protocol surface (`/a2a/*`) at startup. Set `false` to disable. |
| `IOF_A2A_CONSULT_BASE_URL` | (unset) | When set, session-engine POD consults route over A2A to `<base>/a2a/<pod_role>` instead of in-process `process_direct`. Unset = today's exact in-process behavior. |
| `IOF_USE_GENAI_BEDROCK` | (unset) | Set to `1`/`true` to route Claude traffic through the client's Bedrock-wrapper gateway (J&J GenAI API). Monkey-patches iobot's `AnthropicProvider` with `GenaiBedrockProvider`. Unset = use bundled provider against `api.anthropic.com`. |
| `GENAI_API_KEY` | (unset) | GenAI gateway API key. Sent as `X-Api-Key` header. Alternative: set `providers.anthropic.apiKey` in iobot config. |
| `GENAI_API_BASE` | (unset) | GenAI gateway base URL, e.g. `https://genaiapigwna.jnj.com` (no `/v1` suffix). Alternative: `providers.anthropic.apiBase`. |
| `GENAI_MODEL` | `us.anthropic.claude-sonnet-4-20250514-v1` | Default Bedrock model ID. Per-agent overrides via iobot config's `agents.<role>.model`. |
| `TEAMS_APP_ID` | (unset) | Azure Bot registration App ID (enables Teams channel) |
| `TEAMS_APP_SECRET` | (unset) | Azure Bot registration secret |
| `TEAMS_TENANT_ID` | (unset) | Azure AD tenant for single-tenant validation |
| `TEAMS_EMULATOR` | (unset) | Set `true` for local Agents Playground testing (no Azure) |
| `VECTORFS_STORE` | `chroma` | Vector DB provider for vectorfs: `chroma`, `qdrant`, `pinecone`, `weaviate`, `pgvector` |
| `VECTORFS_COLLECTION` | `vectorfs` | Collection/index name in the vector DB |
| `QDRANT_URL` | `http://localhost:6333` | Qdrant endpoint (when `VECTORFS_STORE=qdrant`) |
| `REDIS_URL` | (unset) | Redis URL for vectorfs content cache (optional) |

### LLM provider (pod deployment via `entrypoint.sh`)

Container deployments (`docker run` / K8s) use `entrypoint.sh` which generates `~/.iobot/config.json` from these env vars at startup. The same image targets Anthropic, an Anthropic-compatible endpoint (e.g. MiniMax), or Azure OpenAI — switching is a config-only change, no rebuild.

| Variable | Required | Default | Purpose |
|----------|----------|---------|---------|
| `LLM_API_KEY` | yes | — | API key for the chosen provider. Wired into the matching `providers.<name>` block. |
| `IOBOT_PROVIDER` | yes | `anthropic` | One of: `anthropic`, `azure_openai`, `openai`, `minimax`, `openrouter`, `deepseek`, `groq`, `gemini`, `moonshot`, `dashscope`, etc. Only the matching provider gets `apiKey` + `apiBase` populated. |
| `IOBOT_API_BASE` | yes | `https://api.minimax.io/anthropic` | Endpoint for the active provider. For Azure: `https://<resource>.openai.azure.com`. For Anthropic direct: `https://api.anthropic.com`. For MiniMax via Anthropic-compat: keep the default. |
| `IOBOT_MODEL` | yes | `anthropic/MiniMax-M2.7` | `<provider>/<model_or_deployment>`. For Azure OpenAI: `azure_openai/<deployment-name>` (Azure deployment name, NOT the underlying model ID). |
| `IOBOT_HOME` | no | `/root/.iobot` | Where `config.json` is written. |
| `GATEWAY_PORT` | no | `8111` | Gateway listen port. |

**Example — Azure OpenAI:**
```
LLM_API_KEY      = <azure-key>
IOBOT_PROVIDER = azure_openai
IOBOT_API_BASE = https://my-resource.openai.azure.com
IOBOT_MODEL    = azure_openai/my-gpt4-deployment
```

**Example — Anthropic direct:**
```
LLM_API_KEY      = sk-ant-...
IOBOT_PROVIDER = anthropic
IOBOT_API_BASE = https://api.anthropic.com
IOBOT_MODEL    = anthropic/claude-sonnet-4-5
```

**Note:** Savant session mode uses the global `agents.defaults.model` from `~/.iobot/config.json` (resolved from `IOBOT_MODEL`) for every agent in the session. Per-agent model overrides are not currently honored in session mode — switching the model is one config setting.

### Custom Bedrock-wrapper gateway (J&J GenAI API)

When the deployment must route Claude traffic through the client's own Bedrock-wrapper gateway instead of `api.anthropic.com`, ioagentfarm ships a vendored provider (`GenaiBedrockProvider`) that's swapped in via monkey-patch at import time.

**Why:** the J&J GenAI gateway sits in front of AWS Bedrock and exposes Claude models behind an API-key gate. Routes follow Bedrock Runtime's URL pattern (`POST /model/{modelName}/invoke`), auth is `X-Api-Key` (not AWS SigV4), and the request body is native Anthropic Messages format with `anthropic_version: "bedrock-2023-05-31"` injected. The provider rewrites the Anthropic SDK's outgoing requests via an httpx event hook — message formatting, tool-call extraction, retry logic, and response parsing all inherit unchanged.

**Activation (env vars):**

```bash
IOF_USE_GENAI_BEDROCK=1                        # enable the monkey-patch
GENAI_API_KEY=<your-gateway-key>               # sent as X-Api-Key header
GENAI_API_BASE=https://genaiapigwna.jnj.com    # NO trailing /v1
GENAI_MODEL=us.anthropic.claude-opus-4-6-v1    # Bedrock model ID
```

**Or via `~/.iobot/config.json`:**

```json
{
  "agents": {
    "defaults": {
      "model": "us.anthropic.claude-opus-4-6-v1",
      "maxTokens": 8192,
      "contextWindowTokens": 200000,
      "provider": "anthropic"
    }
  },
  "providers": {
    "anthropic": {
      "apiKey": "<gateway-key-or-leave-empty-for-env>",
      "apiBase": "https://genaiapigwna.jnj.com"
    }
  }
}
```

Either configuration works. Env-var values are the fallback when config fields are empty — useful for keeping secrets out of source-controlled configs.

**Verification:**

```bash
# 1. Wire-level probe (which auth header + endpoint variant the gateway accepts)
python probe_bedrock_wrapper.py

# 2. End-to-end smoke test (through iobot's AnthropicProvider stack)
python probe_genai_provider.py
```

Streaming is not currently supported by the gateway — `chat_stream` falls back to a single-shot `chat()` so the agent loop keeps working. See `ioagentfarm/vendored/genai_bedrock_provider.py` for the full implementation + CLAUDE.md "Model providers" for the invariants.

### iobot runtime settings

These are set automatically by ioagentfarm when invoking agents — you don't need to set them manually:

| Setting | Set by | Purpose |
|---------|--------|---------|
| `IOBOT_WORKSPACE` | `_invoke_agent()` | Points to `--project-dir` so agents can read/write project files. Falls back to agent's iobot workspace if no project dir. |
| `IOBOT_TOOLS__RESTRICT_TO_WORKSPACE` | `_invoke_agent()` | Set to `true` when `IOF_SANDBOX=true`. Confines all iobot tools (shell, file read/write/edit, list) to `IOBOT_WORKSPACE`. |
| `tools.restrictToWorkspace` | `create_instance_config()` | Written to per-run instance config when `IOF_SANDBOX=true`. Same effect as the env var, but persisted in the config file. |

### Per-run instance config

Each run gets an isolated iobot config at `.iof/instances/<run_id>/config.json`:

```json
{
  "tools": {
    "mcpServers": {},
    "restrictToWorkspace": false
  }
}
```

- **No MCP servers by default** — iobot provides native tools (read_file, write_file, list_directory, exec). The `mcpServers` dict is an extension point for future MCP servers.
- **`restrictToWorkspace`** is `false` by default; set `IOF_SANDBOX=true` to enable
- Provider/model settings are copied from `~/.iobot/config.json`

## File structure

```
ioagentfarm/
  agents/
    project_lead/workspace/  -- SOUL.md, AGENTS.md, TOOLS.md, skills/
    analyst/workspace/       -- Dana's identity + skills (decompose_stories, edi_mapping)
    developer/workspace/     -- Sam's identity
    reviewer/workspace/      -- Chris's identity + skills (test_and_validate, enterprise_quality_gates)
    data_analyst/workspace/  -- Ria's identity + skills (data_query with iof-query CLI)
  channels/
    teams/                   -- MS Teams channel (no SDK dependency, pure HTTP)
      router.py              -- FastAPI router: POST /api/teams/messages
      bot.py                 -- Activity handling, agent routing, proactive messaging
      models.py              -- Lightweight Activity Pydantic models
      cards.py               -- Adaptive Card builders (progress, result, welcome)
      state.py               -- Thread↔run mapping, conversation references (DB)
      config.py              -- TeamsConfig from env vars
  workflows/
    project_lead/            -- workflow.yaml, roles/*.md, steps/*.md
    feature_dev/
    story_loop/
    bug_fix/
    smoke_test/              -- e2e test workflow (spec → build → check)
    data_analysis/           -- analyze_data → validate_results (Ria + Chris)
    edi_integrationWorkflow_analyst/
  engine/
    db.py                    -- DbAdapter protocol + SQLite + PostgreSQL adapters
    store.py                 -- state (runs, steps, stories, tasks, user_context)
    scheduler.py             -- step sequencing and prompt rendering
    iobot_runner.py        -- runs steps via `iobot agent`
    iobot_config.py        -- MCP server + per-run instance config
    protocol.py              -- KEY: value output parser
    templating.py            -- {{var}} renderer (dot notation)
    progress.py              -- progress markdown builder
    workflow_loader.py       -- YAML loader (bundled + installed overrides)
    workspaces.py            -- agent workspace management + filtered workspaces
  cli.py                     -- typer CLI (setup, execution, tasks, status)
  cli_orchestration.py       -- step orchestration + recovery commands

ts-skills/                   -- TypeScript CLI tools monorepo (turborepo)
  vectorfs/                  -- vector DB-backed virtual filesystem CLI
    src/stores/              -- VectorStore interface + 5 adapters (chroma, qdrant, pinecone, weaviate, pgvector)
    src/vectorfs.ts          -- IFileSystem impl (just-bash compatible)
    src/explore-skill.ts     -- semantic + grep + follow refs in one call
    src/cli.ts               -- CLI entry point
    src/cache/               -- ContentCache interface + memory/redis adapters
```

## CLI reference

```bash
# Setup & management
ioagentfarm init
ioagentfarm list-workflows
ioagentfarm workflow-install <name> [--force]
ioagentfarm workflow-uninstall <name>
ioagentfarm setup-agents [--project-dir] [--roles "..."] [--force]

# MCP servers
ioagentfarm mcp-list
ioagentfarm mcp-add --name <name> --command <cmd>
ioagentfarm mcp-remove --name <name>

# Project context
ioagentfarm use-run <run_id|latest> [--user-id]
ioagentfarm current [--user-id]
ioagentfarm follow-up --goal "..." [--workflow] [--from <run_id>] [--user-id]

# Execution
ioagentfarm run <workflow> --goal "..." [--project-dir] [--dry-run] [--user-id]
ioagentfarm run <workflow> --goal "..." --json [--user-id]   # background spawn, JSON output (agents/Teams)
ioagentfarm status [--run-id] [--json] [--stories] [--team] [--step <key>] [--user-id] [--all]

# Gateway (async)
ioagentfarm start-gateway [--project-dir] [--channel telegram|cli]

# Step orchestration (JSON API for LLM agents)
ioagentfarm next-step [--role] [--run-id] [--user-id]
ioagentfarm run-step --step-key <key> [--background] [--extra-context "..."] [--user-id]
ioagentfarm step-complete --step-key <key> --output-file <path> [--user-id]

# Tasks
ioagentfarm run-task --role <role> --goal "..." [--background] [--user-id]
ioagentfarm task-create --role <role> --title "..." --body "..." [--user-id]
ioagentfarm task-update --task-id <id> --status running|done|failed|notified
ioagentfarm task-list [--status] [--run-id] [--user-id] [--all]

# Step recovery
ioagentfarm step-retry --step-key <key> [--run-id]
ioagentfarm step-retry --step-key <key> [--run-id] --crash-recovery  # reset stuck/crashed steps
ioagentfarm step-skip --step-key <key> [--run-id]
```

All run-scoped commands use 3-level resolution: `--run-id` → per-user active run → latest active run.

## E2E smoke test

The `smoke_test` workflow is a lightweight 3-step pipeline designed for two purposes: **validating your installation** and **learning how ioagentfarm works**.

```
spec (analyst) → build (developer) → check (reviewer)
```

It asks the analyst to write a spec, the developer to implement a tiny Python utility, and the reviewer to run it and verify acceptance criteria — exercising the full agent pipeline end-to-end.

### Run it

```bash
# Dry-run first — validates YAML, shows the step DAG, no LLM calls
ioagentfarm run smoke_test --goal "Create a Python script that prints the current date" --dry-run

# Real run — Alex drives all 3 steps via iobot
ioagentfarm run smoke_test --goal "Create a Python script that prints the current date"

# With a project directory containing input files (validates agents can read project files)
mkdir /tmp/smoke_test_project
echo "Build a Python script called greet.py that prints Hello, <name>!" > /tmp/smoke_test_project/REQUIREMENTS.txt
ioagentfarm run smoke_test --goal "Build the project per REQUIREMENTS.txt" --project-dir /tmp/smoke_test_project

# Check results
ioagentfarm status --json
```

### Inspect outputs

Deliverable artifacts (code, CSV, reports) are written to the **project directory** (`--project-dir`, defaults to cwd). Protocol outputs (STATUS/OUTPUT) are stored internally:

```bash
# Deliverable artifacts — in your project directory
ls ./myproject/                        # code, reports, data files created by agents

# Protocol outputs — internal orchestration state
ls .iof/runs/<run_id>/steps/spec/      # OUTPUT.txt (parsed by orchestrator)
ls .iof/runs/<run_id>/steps/build/
ls .iof/runs/<run_id>/steps/check/
```

### What it demonstrates

| Concept | Where to see it |
|---------|----------------|
| Step dependencies (`deps`) | `build` depends on `spec`, `check` depends on `build` |
| Cross-step templating | `{{step_output.spec}}` feeds analyst output into developer prompt |
| Per-workflow skill filtering | analyst gets `decompose_stories`, reviewer gets `test_and_validate` |
| Output protocol | Every step returns `STATUS: done\|failed` + `OUTPUT: ...` |
| Input file access | `--project-dir` sets `IOBOT_WORKSPACE` so agents can read project files |
| Workspace management | `IOBOT_WORKSPACE` points to project dir, OUTPUT.txt to step output dir |
| Retry support | `max_attempts: 3` on build step allows automatic retry on failure |

### Use as a template

Copy the smoke_test workflow to create your own:

```bash
ioagentfarm workflow-install smoke_test    # copies to .iof/workflows/smoke_test/
# Edit workflow.yaml, roles/*.md, steps/*.md
# Then run your modified version
```

## Output protocol

Every agent step must return:

```
STATUS: done|failed
OUTPUT: <result text>
```

Optional (project_lead only):
```
STORIES_JSON: [{"id":"s1","title":"...","details":"..."}]
TASKS_JSON: [{"key":"impl_auth","role":"developer","title":"...","deps":["plan"],"prompt":"..."}]
```

## Vendor intelligence (ARIA / BD Contracts Insight)

ARIA uses two external APIs for live vendor financial and news data — **Financial Modeling Prep (FMP)** for stock data, credit ratings, and Altman Z-score, and **NewsData.io** for recent news. Both are called from `io-procurement-insight-api`, not this engine.

### DB-driven vendor configuration

The vendor list, FMP tickers, and NewsData query terms are stored in the `procurement.vendor_intelligence` table — not hardcoded. ARIA's SOUL.md (`ioagentfarm/agents/aria/workspace/SOUL.md`) already references these columns directly.

| Column | Purpose |
|--------|---------|
| `fmp_ticker` | Stock ticker for FMP calls (e.g. `ACN` for Accenture). NULL = private company, no FMP data. |
| `newsdata_query_term` | Custom NewsData search override. NULL = default query `"{vendor}" procurement contract earnings`. |

### Adding a new vendor

No code changes required — just insert a row:

```sql
-- Add to the vendor_intelligence table (procurement schema)
INSERT INTO procurement.vendor_intelligence
    (id, vendor, intel_date, financial_health, sanctions_status, country_risk, source_data)
VALUES
    (gen_random_uuid(), 'New Vendor', CURRENT_DATE, 'unknown', 'clear', 'low', '{}');

-- Set ticker (public companies only) and optional custom news query
UPDATE procurement.vendor_intelligence
SET
    fmp_ticker           = 'TICK',          -- leave NULL for private companies
    newsdata_query_term  = 'New Vendor procurement'   -- optional override
WHERE vendor = 'New Vendor';
```

The `SCHEDULER_INTEL_HOURS` cron in the API project picks up the new vendor automatically on the next cycle. The rotation quota (`INTEL_NEWS_VENDORS_PER_DAY`) applies across all tracked vendors.

### ARIA SOUL.md reference

ARIA's SOUL.md documents how to use the intel APIs via CLI tools — `iof-api --endpoint fmp --path "/ratios/{ticker}"` and `iof-api --endpoint newsdata --path "/news"`. Always check the `vendor_intelligence` table (with `valid_until` freshness check) before calling external APIs. See `ioagentfarm/agents/aria/workspace/SOUL.md` lines 23–39 for the full usage guidance.
