"""`aicore login` — authenticate once; stop passing a token by hand.

WHY THIS EXISTS. The Studio API is the one surface in this product that needs
a bearer token, and the only way to get one used to be a `curl` against
`/api/auth/login` piped into `export TOK=…`. That instruction produced three
misleading signals in a row on a single real walk-through:

  1. the password contained ``!``, so an interactive bash expanded it as a
     history reference and the request was never sent;
  2. ``$TOK`` was therefore empty, and nothing said so;
  3. ``GET /api/workspaces`` answered ``200 []`` for the empty token — which
     reads as *"you have no workspaces"*, not *"you are not authenticated"*.

Two of those are fixed elsewhere (the API answers 401 now, and the guide no
longer asks anyone to hand-quote a password). This module removes the cause of
all three: nothing is typed twice, the password never reaches a shell word, and
the token lives in a file instead of a variable that a new terminal does not
have.

WHAT IT IS NOT. A secret manager. This is a local developer convenience with
the same threat model as ``~/.aws/credentials`` or ``~/.netrc``: a short-lived
token, at rest, readable by the account that wrote it. A deployment must use
``IOF_API_TOKEN`` (below) and mint tokens from its own secret store.

WHERE THE TOKEN LIVES, and why not the two obvious places:

  * NOT ``$IOF_ROOT`` — that directory is a *derived* one. Teardown deletes it,
    horizontal scaling pushes parts of it to S3, and a reader who set it to a
    path inside a checkout would be one ``git add`` away from committing a
    credential.
  * NOT the repository, for the same last reason.

So: the per-user config directory the OS already protects —
``%LOCALAPPDATA%\\agentfarm\\credentials.json`` on Windows,
``$XDG_CONFIG_HOME/agentfarm/credentials.json`` (default ``~/.config``)
elsewhere. ``IOF_CREDENTIALS_FILE`` overrides it outright, which is also how
the tests stay out of the developer's real home.

Permissions are tightened as far as each platform allows and no further, which
is worth stating precisely rather than implying: on POSIX the file is created
``0600``. On Windows ``os.chmod`` only toggles the read-only attribute and
cannot express an ACL, so the file inherits the user-profile ACL of
``%LOCALAPPDATA%`` — per-user by default, and NOT protection against another
process running as you.

PRECEDENCE. ``IOF_API_TOKEN`` in the environment always wins over the stored
file, so CI, a container and a pod need no ``login`` step at all and never
write a credential to disk. ``logout`` cannot remove it — the message says so,
because "I logged out and I am still authenticated" is otherwise a puzzle.

Tokens are keyed by API URL. One machine routinely talks to a local API and a
shared one, and a single slot would silently send the wrong deployment's token
to the other.
"""

from __future__ import annotations

import urllib.error  # cheap; urllib.request (http.client) is imported where used

import base64
import json
import os
import stat
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import typer
from rich.console import Console

console = Console()
#: `token` writes the token to stdout so it can be substituted into a header.
#: Everything explanatory therefore has to leave by the other stream, or the
#: explanation ends up inside the header.
err_console = Console(stderr=True)

#: The Studio API a bare command talks to. Deliberately the same default the
#: getting-started guide starts uvicorn on.
DEFAULT_API_URL = "http://127.0.0.1:8002"

#: Read at call time, never cached: a test (and a reader with two deployments)
#: changes it between commands in one process.
ENV_TOKEN = "IOF_API_TOKEN"
ENV_API_URL = "IOF_API_URL"
ENV_CREDENTIALS_FILE = "IOF_CREDENTIALS_FILE"

_SCHEMA_VERSION = 1


# ── the store ─────────────────────────────────────────────────────────

def credentials_path() -> Path:
    """Where the token file is, for this user, on this platform."""
    override = (os.getenv(ENV_CREDENTIALS_FILE) or "").strip()
    if override:
        return Path(override).expanduser()
    if os.name == "nt":
        base = os.getenv("LOCALAPPDATA") or os.getenv("APPDATA")
        root = Path(base) if base else Path.home() / "AppData" / "Local"
    else:
        base = os.getenv("XDG_CONFIG_HOME")
        root = Path(base) if base else Path.home() / ".config"
    return root / "agentfarm" / "credentials.json"


def normalize_api_url(url: str | None) -> str:
    """``--api-url`` > ``IOF_API_URL`` > the local default, trailing / removed.

    Normalising matters more than it looks: ``…:8002`` and ``…:8002/`` are the
    same server and would otherwise be two entries, so a reader who typed the
    slash once would `login` and then find `token` reporting nothing stored.
    """
    raw = (url or "").strip() or (os.getenv(ENV_API_URL) or "").strip() \
        or DEFAULT_API_URL
    return raw.rstrip("/")


def _read_store() -> dict:
    path = credentials_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"version": _SCHEMA_VERSION, "endpoints": {}}
    if not isinstance(data, dict) or not isinstance(data.get("endpoints"), dict):
        # A corrupt or hand-edited file is not worth an error the reader has to
        # diagnose — the whole content is one re-runnable `login`.
        return {"version": _SCHEMA_VERSION, "endpoints": {}}
    return data


def _write_store(data: dict) -> Path:
    path = credentials_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    # Create with 0600 rather than write-then-chmod: between those two calls
    # the file exists world-readable, which is the whole window that matters.
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
    finally:
        try:
            os.chmod(str(path), stat.S_IRUSR | stat.S_IWUSR)
        except OSError:      # pragma: no cover - platform-dependent, advisory
            pass
    return path


def save_token(api_url: str, token: str, email: str) -> Path:
    data = _read_store()
    data.setdefault("endpoints", {})[api_url] = {
        "email": email,
        "token": token,
        "expires_at": token_expiry(token),
        "saved_at": int(time.time()),
    }
    return _write_store(data)


def forget_token(api_url: str | None) -> list[str]:
    """Drop one endpoint's token, or every one when *api_url* is None."""
    data = _read_store()
    endpoints = data.get("endpoints") or {}
    dropped = sorted(endpoints) if api_url is None else \
        ([api_url] if api_url in endpoints else [])
    for key in dropped:
        endpoints.pop(key, None)
    data["endpoints"] = endpoints
    _write_store(data)
    return dropped


# ── reading a token back ──────────────────────────────────────────────

class TokenUnavailable(Exception):
    """No usable token, with a message that says which of the two it is.

    "Expired" and "never logged in" need different next steps, and collapsing
    them into "unauthorized" is exactly the unhelpful answer this whole module
    was written to stop producing.
    """


def token_claims(token: str) -> dict:
    """The JWT payload, decoded and NOT verified.

    Display only — expiry and the email to print back. Verification is the
    API's job and needs the signing secret, which a CLI on a developer laptop
    does not have and must not be given. Nothing here decides access.
    """
    parts = (token or "").split(".")
    if len(parts) != 3:
        return {}
    seg = parts[1]
    try:
        raw = base64.urlsafe_b64decode(seg + "=" * ((4 - len(seg) % 4) % 4))
        claims = json.loads(raw)
    except Exception:
        return {}
    return claims if isinstance(claims, dict) else {}


def token_expiry(token: str) -> int | None:
    exp = token_claims(token).get("exp")
    try:
        return int(exp)
    except (TypeError, ValueError):
        return None


def token_email(token: str) -> str:
    claims = token_claims(token)
    return str(claims.get("unique_name") or claims.get("userName")
               or claims.get("email") or "")


def _fmt_ts(ts: int | None) -> str:
    if not ts:
        return "unknown"
    return datetime.fromtimestamp(ts, timezone.utc).astimezone() \
        .strftime("%Y-%m-%d %H:%M %Z")


def _fmt_delta(seconds: float) -> str:
    seconds = abs(int(seconds))
    if seconds < 90:
        return f"{seconds}s"
    if seconds < 5400:
        return f"{seconds // 60}m"
    return f"{seconds // 3600}h {(seconds % 3600) // 60}m"


def resolve_token(api_url: str) -> tuple[str, str]:
    """``(token, source)`` for *api_url*, or raise :class:`TokenUnavailable`.

    ``source`` is what the reader needs when the answer surprises them: an
    inherited ``IOF_API_TOKEN`` explains "I logged in as A and the API says I
    am B" in one line.
    """
    env = (os.getenv(ENV_TOKEN) or "").strip()
    if env:
        return env, f"${ENV_TOKEN}"

    entry = (_read_store().get("endpoints") or {}).get(api_url)
    if not entry or not entry.get("token"):
        raise TokenUnavailable(
            f"not logged in to {api_url} — run "
            f"`aicore login --api-url {api_url}`"
            f"\n(or set ${ENV_TOKEN} if you already hold a token)")

    exp = entry.get("expires_at")
    if exp and float(exp) < time.time():
        raise TokenUnavailable(
            f"your token for {api_url} EXPIRED {_fmt_delta(time.time() - exp)} "
            f"ago (at {_fmt_ts(int(exp))}) — tokens last 12 hours. "
            "Run `aicore login` again.")
    return str(entry["token"]), str(credentials_path())


# ── HTTP ──────────────────────────────────────────────────────────────

def _post_json(url: str, payload: dict, timeout: float = 30.0) -> tuple[int, dict, str]:
    body = json.dumps(payload).encode("utf-8")
    import urllib.request, urllib.error  # noqa: E401 - only these two calls need it
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode("utf-8", "replace")
            return resp.status, _maybe_json(text), text
    except urllib.error.HTTPError as exc:
        text = exc.read().decode("utf-8", "replace")
        return exc.code, _maybe_json(text), text


def _get(url: str, token: str, timeout: float = 30.0) -> tuple[int, str]:
    import urllib.request, urllib.error  # noqa: E401 - only these two calls need it
    req = urllib.request.Request(
        url, method="GET",
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")


def _maybe_json(text: str) -> dict:
    try:
        out = json.loads(text)
    except json.JSONDecodeError:
        return {}
    return out if isinstance(out, dict) else {}


def read_password(supplied: str) -> str:
    """The password, without ever putting it through a shell word.

    Three sources, in order, and the middle one is not optional on Windows:

    * ``--password`` when given. Documented as the form NOT to prefer: an
      interactive bash expands ``!`` inside double quotes, so the very first
      real password anyone tried (``Local!2026``) died as
      ``bash: !2026: event not found`` before the process started.
    * **stdin, when it is not a terminal** — ``printf '%s\\n' "$PW" | ioagentfarm
      login``. Needed because ``getpass`` on Windows reads the CONSOLE through
      ``msvcrt``, not stdin: a piped password there does not arrive, and the
      command hangs forever waiting for a keystroke instead of failing. Every
      scripted use and every test goes through this branch.
    * a hidden prompt otherwise.
    """
    if supplied:
        return supplied
    if not sys.stdin.isatty():
        return sys.stdin.readline().rstrip("\r\n")
    return typer.prompt("password", hide_input=True)


def _unreachable(api_url: str, exc: Exception) -> typer.Exit:
    console.print(f"[red]could not reach the Studio API at {api_url}[/red]")
    console.print(f"[dim]{exc}[/dim]")
    console.print("[dim]start it with: python -m uvicorn app.main:app "
                  "--port 8002 --host 127.0.0.1   (from apps/agentfarm-api)"
                  "[/dim]")
    return typer.Exit(code=1)


# ── commands ──────────────────────────────────────────────────────────

def register(app: typer.Typer) -> None:
    """Attach login/logout/whoami/token to the root CLI."""

    @app.command("login")
    def login(
        email: str = typer.Option(
            "", "--email", "-e",
            help="account email (defaults to $IOF_BOOTSTRAP_ADMIN, then a prompt)"),
        password: str = typer.Option(
            "", "--password",
            help="read from stdin (when piped) or PROMPTED when omitted, "
                 "which are the forms to prefer — a password on the command "
                 "line reaches your shell's history and its expansion rules"),
        api_url: str = typer.Option("", "--api-url",
                                    help=f"Studio API base URL "
                                         f"(default ${ENV_API_URL} or "
                                         f"{DEFAULT_API_URL})"),
    ):
        """Authenticate against the Studio API and store the token for reuse.

        The token is written to the per-user credentials file (see
        ``ioagentfarm whoami``), NOT to the shell — so a second terminal, an
        hour later, is already logged in.

        Nothing here echoes the password or the token, including on failure.
        Pipe the password when scripting: ``printf '%s\\n' "$PW" | ioagentfarm
        login``.
        """
        url = normalize_api_url(api_url)
        who = email.strip() or (os.getenv("IOF_BOOTSTRAP_ADMIN") or "").strip()
        if not who:
            who = typer.prompt("email").strip()
        secret = read_password(password)
        if not secret:
            console.print("[red]a password is required[/red]")
            raise typer.Exit(code=1)

        try:
            status, data, text = _post_json(f"{url}/api/auth/login",
                                            {"email": who, "password": secret})
        except (urllib.error.URLError, OSError) as exc:
            raise _unreachable(url, exc)

        if status == 401:
            # The API refuses to distinguish an unknown account from a wrong
            # password, deliberately. Repeating its answer rather than guessing
            # keeps the CLI from inventing a distinction the server won't make.
            console.print(f"[red]invalid email or password for {who}[/red]")
            console.print("[dim]the API answers the same way for an unknown "
                          "account and a wrong password, on purpose[/dim]")
            raise typer.Exit(code=1)
        if status == 403:
            console.print(f"[red]{who} exists but is inactive - an "
                          "administrator has to re-activate it[/red]")
            raise typer.Exit(code=1)
        token = str(data.get("accessToken") or "")
        if status != 200 or not token:
            console.print(f"[red]login failed (HTTP {status})[/red]")
            console.print(f"[dim]{text[:400]}[/dim]")
            raise typer.Exit(code=1)

        path = save_token(url, token, token_email(token) or who)
        exp = token_expiry(token)
        console.print(f"[green]logged in as {token_email(token) or who}[/green] "
                      f"-> {url}")
        console.print(f"[dim]token valid until {_fmt_ts(exp)}"
                      + (f" ({_fmt_delta(exp - time.time())} from now)"
                         if exp else "") + f"; stored in {path}[/dim]")
        if (os.getenv(ENV_TOKEN) or "").strip():
            # Saving a token that will not be used is worth one line — the
            # alternative is a reader who logs in as A and is answered as B.
            console.print(f"[yellow]note: ${ENV_TOKEN} is set in this "
                          "environment and takes precedence over the stored "
                          "token[/yellow]")

    @app.command("logout")
    def logout(
        api_url: str = typer.Option("", "--api-url"),
        all_endpoints: bool = typer.Option(False, "--all",
                                           help="forget every stored token"),
    ):
        """Discard the stored token (this machine only — nothing is revoked)."""
        target = None if all_endpoints else normalize_api_url(api_url)
        dropped = forget_token(target)
        if dropped:
            for url in dropped:
                console.print(f"[green]logged out of {url}[/green]")
        else:
            console.print(f"[dim]no stored token for "
                          f"{'any API' if target is None else target}[/dim]")
        if (os.getenv(ENV_TOKEN) or "").strip():
            console.print(f"[yellow]${ENV_TOKEN} is still set in this "
                          f"environment and still authenticates you - "
                          f"`unset {ENV_TOKEN}` to stop that[/yellow]")
        console.print("[dim]the token itself stays valid until it expires; "
                      "there is no server-side revocation[/dim]")

    @app.command("whoami")
    def whoami(
        api_url: str = typer.Option("", "--api-url"),
        offline: bool = typer.Option(
            False, "--offline",
            help="report the stored token without asking the API about it"),
    ):
        """Who the stored token says you are, and whether the API agrees.

        It asks by default. A token can be locally valid and still refused —
        the server was restarted with a different signing secret is the common
        one — and a command that only reads the file cannot tell you that.
        """
        url = normalize_api_url(api_url)
        try:
            token, source = resolve_token(url)
        except TokenUnavailable as exc:
            console.print(f"[yellow]{exc}[/yellow]")
            raise typer.Exit(code=1)

        exp = token_expiry(token)
        console.print(f"[bold]{token_email(token) or '(no email claim)'}[/bold] "
                      f"@ {url}")
        console.print(f"  token from  {source}")
        console.print(f"  expires     {_fmt_ts(exp)}"
                      + (f"  (in {_fmt_delta(exp - time.time())})"
                         if exp and exp > time.time() else ""))
        if offline:
            return

        try:
            status, body = _get(f"{url}/api/workspaces", token)
        except (urllib.error.URLError, OSError) as exc:
            console.print(f"[yellow]  API          unreachable at {url} "
                          f"({exc})[/yellow]")
            return
        if status == 200:
            try:
                codes = [w.get("code") for w in json.loads(body)]
            except (json.JSONDecodeError, AttributeError, TypeError):
                codes = []
            console.print(f"[green]  API          accepts it[/green] - "
                          f"{len(codes)} workspace(s) visible: {codes}")
        elif status == 401:
            console.print("[red]  API          REJECTED it (401)[/red]")
            console.print("[dim]  the stored token is not one this server will "
                          "accept - usually a different IOF_AUTH_JWT_SECRET. "
                          "Run `aicore login` again.[/dim]")
            raise typer.Exit(code=1)
        else:
            console.print(f"[yellow]  API          answered HTTP {status}"
                          f"[/yellow]")
            console.print(f"[dim]  {body[:300]}[/dim]")

    @app.command("token")
    def token_cmd(
        api_url: str = typer.Option("", "--api-url"),
        header: bool = typer.Option(
            False, "--header",
            help="print `Authorization: Bearer <token>` instead of the token"),
    ):
        """Print the stored token so your own `curl` can use it.

        Explicit on purpose. The alternative — a CLI that silently injects a
        credential into commands the reader wrote themselves — hides the one
        thing a walkthrough is trying to teach:

            curl -s http://127.0.0.1:8002/api/workspaces \\
              -H "$(ioagentfarm token --header)"

        stdout carries the token and nothing else, so it substitutes cleanly.
        Every explanatory line this command prints goes to stderr.
        """
        url = normalize_api_url(api_url)
        try:
            tok, _ = resolve_token(url)
        except TokenUnavailable as exc:
            # stderr: stdout is being captured into a header by the caller, and
            # an error message there becomes a malformed request instead of a
            # visible failure.
            err_console.print(f"[red]{exc}[/red]")
            raise typer.Exit(code=1)
        print(f"Authorization: Bearer {tok}" if header else tok)
