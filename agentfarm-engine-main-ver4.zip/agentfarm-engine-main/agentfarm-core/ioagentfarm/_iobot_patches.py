"""Monkey-patches that adjust iobot internals from ioagentfarm.

Each function here is idempotent and guarded with try/except so that a
iobot version that has refactored the touched surface fails loud at
import time rather than silently misbehaving at runtime.

See also
--------
- ``ioagentfarm/__init__.py`` — invokes these at package import time for
  the in-process path (web API / sessions / always-on agents).
- ``ioagentfarm/cli.py:_invoke_agent`` — writes a ``sitecustomize.py``
  that imports this module so the same patches apply inside iobot
  subprocesses spawned for workflow runs.
"""

from __future__ import annotations

import functools
import logging
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional


def _otel_content_enabled() -> bool:
    """Whether this deployment has opted into exporting message bodies.

    ONE reader for the whole runtime. The gate existed in
    ``engine/otel_export.py`` for the run goal and the step input, and the
    tool spans in this module reimplemented nothing at all - which is how a
    documented guarantee ("message bodies are not exported") came to be true
    of three span kinds and false of the fourth. A switch spelled out at each
    site is a switch that will be forgotten at one of them.
    """
    from ioagentfarm.engine.otel_export import content_enabled
    return content_enabled()


#: Patch-runtime diagnostics. Distinct from ``_note`` below: that is registry
#: chatter a reader can ignore, this is for a patch reporting a real condition
#: at run time (an MCP server abandoned, say) that must reach the log.
logger = logging.getLogger(__name__)


def _note(*args, **kwargs) -> None:
    """Patch-registry chatter — SILENT unless asked for.

    Every one of these lines is true and occasionally invaluable: they say
    which monkey-patches went into a vendored runtime, which is the first
    question when the runtime misbehaves. They were also printed on EVERY
    invocation, so `ioagentfarm --version` opened with five paragraphs about
    MiniMax tool_use ids and a reader on page one of the guide met a wall of
    text that reads like something went wrong.

    Diagnostics that fire unconditionally stop being read, which costs the
    thing they were for. `ioagentfarm patches` prints the same inventory on
    demand, with live ACTIVE/inactive state, so nothing is lost by default.

    Set IOF_PATCH_BANNER=1 to restore the running commentary. FAILURES do not
    come through here — a patch that could not bind is always loud.
    """
    import sys as _s
    if (os.getenv("IOF_PATCH_BANNER") or "").strip().lower() in ("1", "true", "yes"):
        kwargs.setdefault("file", _s.stderr)
        kwargs.setdefault("flush", True)
        print(*args, **kwargs)



@dataclass
class Patch:
    """A single iobot monkey-patch, with its maintenance metadata.

    The ``PATCHES`` registry below is the SINGLE SOURCE OF TRUTH for what we
    patch and why — ``apply_all()`` iterates it, and ``patch_inventory()``
    exposes it (for docs, the re-validation recipe, and a future
    ``ioagentfarm patches`` CLI). To retire a patch (e.g. an iobot upgrade
    fixes the bug upstream, or a config change makes it moot), set
    ``deprecated=True`` + ``deprecated_reason`` instead of deleting it:
    ``apply_all()`` then skips it, but the descriptor and the apply-fn stay for
    history and one-flag re-enable. This keeps the inventory from drifting out
    of the code the way a doc-only list does.
    """
    name: str
    summary: str                       # one line: what it does
    reason: str                        # the upstream bug / gateway need it addresses
    target: str                        # iobot symbol(s) it patches
    sentinel: str                      # idempotency sentinel attr set on success
    apply: Callable[[], None]          # the idempotent, self-guarded apply fn
    toggle_env: Optional[str] = None   # env var that gates it (None = always applied)
    added: str = ""                    # yyyy-mm added
    iobot: str = "0.3.0"             # iobot version validated against
    deprecated: bool = False
    deprecated_reason: str = ""


DEFAULT_STATE_DIR = ".iobot"


def _rebind_across_modules(original: Any, replacement: Any) -> int:
    """Rebind every already-imported module attribute that IS ``original``.

    Replacing ``module.func`` is not enough on its own. Several iobot modules
    bind these names at IMPORT time::

        session/manager.py:20        from iobot.config.paths import get_legacy_sessions_dir
        agent/tools/message.py:14    from iobot.config.paths import get_workspace_path
        channels/msteams/runtime.py  from iobot.config.paths import get_workspace_path
        cli/commands.py:77           from iobot.config.paths import get_workspace_path, is_default_workspace

    Whichever of those was imported before this patch runs keeps a reference to
    the ORIGINAL function, so it would carry on writing to the default
    ``~/.iobot`` while everything else used the override. A split-brain state
    directory is worse than no override at all: memory and sessions silently
    divide across two trees, and it only shows up at runtime.

    Sweeping ``sys.modules`` for identity matches fixes both orderings — modules
    imported before this patch and after it — without caring which iobot
    module happens to import what.
    """
    import sys

    count = 0
    for mod in list(sys.modules.values()):
        if mod is None or not getattr(mod, "__name__", "").startswith("iobot"):
            continue
        for attr, value in list(vars(mod).items()):
            if value is original:
                setattr(mod, attr, replacement)
                count += 1
    return count


def apply_state_dir_override() -> None:
    """Relocate the runtime's on-disk state directory when ``IOF_STATE_DIR_NAME`` says so.

    The runtime's own default is ``~/.iobot`` (config.json, workspace, sessions,
    logs, cron) — the vendored source says so natively, so with the variable
    unset this patch does NOTHING and leaves no sentinel. It exists for the
    cases that need the state directory somewhere else: a test that must not
    touch the developer's real ``~/.iobot``, or an operator relocating state on
    a shared host. Instance configs set via ``set_config_path()`` are left
    alone — only the DEFAULT is redirected, so per-run configs keep working.

    Why a runtime patch and not ``iobot/patches/*.patch``
    -----------------------------------------------------
    A ``.patch`` against vendored source is EDIT-divergence: it needs re-cutting
    every time upstream touches those lines. Doing it here keeps the vendored
    tree byte-identical to what ``vendor.py`` derives, so ``vendor.py --check``
    still passes untouched. It also earns rule 3: this shows up in
    ``ioagentfarm patches`` with live bind state, and fails visibly if upstream
    restructures the modules underneath it.

    What is repointed (verified against 0.3.0, all reachable at runtime)
    -------------------------------------------------------------------
    ``config.loader.get_config_path``  -> ``~/<name>/config.json``. This is the
        root: ``paths.get_data_dir()`` returns ``get_config_path().parent``, so
        media/, cron/, logs/, webui/ and pairing.json all follow for free.
    ``config.paths.get_workspace_path`` / ``is_default_workspace`` /
        ``get_cli_history_path`` / ``get_legacy_sessions_dir``
    ``config.schema.AgentDefaults.workspace`` — the pydantic default that gets
        written into a generated config.json.
    ``utils.helpers._TOOL_RESULTS_DIR`` — read at call time, so reassigning the
        module global is sufficient.

    Several modules bind these helpers at IMPORT time, so the swap sweeps
    ``sys.modules`` for identity matches (``_rebind_across_modules``) — a
    module-attribute swap alone would leave a split-brain state directory.

    Deliberately NOT repointed
    --------------------------
    ``gateway/service.py`` launchd log paths and the ``ai.iobot.`` service
    label: macOS-only, reached only by ``iobot gateway service install``,
    which we never run. Renaming a reverse-DNS service identifier could orphan
    an already-installed service for no gain.
    ``apps/cli/service.py`` ``_ARTIFACT_IGNORE_DIRS``: a scan-ignore list, not a
    state path.

    Toggle: ``IOF_STATE_DIR_NAME`` — any directory name under ``$HOME``;
    unset or ``.iobot`` means no override. Idempotent via sentinel.
    """
    name = (os.environ.get("IOF_STATE_DIR_NAME") or DEFAULT_STATE_DIR).strip()
    if not name or name == DEFAULT_STATE_DIR:
        return  # no override: the runtime's own default IS ~/.iobot

    try:
        from pathlib import Path

        from iobot.config import loader as _loader
        from iobot.config import paths as _paths
        from iobot.config import schema as _schema
        from iobot.utils import helpers as _helpers
    except Exception:
        return

    if getattr(_loader, "_iof_state_dir_patch", False):
        return

    home = Path.home()
    old_default_cfg = home / DEFAULT_STATE_DIR / "config.json"
    new_default_cfg = home / name / "config.json"
    rebinds = 0

    # --- 1. the config path: the root everything else derives from ---------
    _orig_get_config_path = _loader.get_config_path

    def _get_config_path() -> Any:
        # Call through so `set_config_path()` (per-run instance configs, used by
        # every workflow step) keeps winning; swap ONLY the default.
        current = _orig_get_config_path()
        return new_default_cfg if current == old_default_cfg else current

    _loader.get_config_path = _get_config_path  # type: ignore[assignment]
    rebinds += _rebind_across_modules(_orig_get_config_path, _get_config_path)

    # --- 2. workspace / history / legacy sessions --------------------------
    # Reimplemented rather than wrapped: the originals call ensure_dir(), so
    # calling through to compute a default would CREATE ~/.iobot as a side
    # effect — the very directory we are trying to stop using.
    _ensure_dir = _helpers.ensure_dir
    _orig_get_workspace_path = _paths.get_workspace_path
    _orig_is_default_workspace = _paths.is_default_workspace
    _orig_get_cli_history_path = _paths.get_cli_history_path
    _orig_get_legacy_sessions_dir = _paths.get_legacy_sessions_dir

    def _get_workspace_path(workspace: Any = None) -> Any:
        path = Path(workspace).expanduser() if workspace else home / name / "workspace"
        return _ensure_dir(path)

    def _is_default_workspace(workspace: Any) -> bool:
        default = home / name / "workspace"
        current = Path(workspace).expanduser() if workspace is not None else default
        return current.resolve(strict=False) == default.resolve(strict=False)

    def _get_cli_history_path() -> Any:
        return home / name / "history" / "cli_history"

    def _get_legacy_sessions_dir() -> Any:
        return home / name / "sessions"

    for orig, repl, attr in (
        (_orig_get_workspace_path, _get_workspace_path, "get_workspace_path"),
        (_orig_is_default_workspace, _is_default_workspace, "is_default_workspace"),
        (_orig_get_cli_history_path, _get_cli_history_path, "get_cli_history_path"),
        (_orig_get_legacy_sessions_dir, _get_legacy_sessions_dir,
         "get_legacy_sessions_dir"),
    ):
        setattr(_paths, attr, repl)
        rebinds += _rebind_across_modules(orig, repl)

    # --- 3. the pydantic default written into a generated config.json ------
    try:
        field = _schema.AgentDefaults.model_fields["workspace"]
        if isinstance(field.default, str) and DEFAULT_STATE_DIR in field.default:
            field.default = field.default.replace(DEFAULT_STATE_DIR, name)
            _schema.AgentDefaults.model_rebuild(force=True)
    except Exception:
        pass

    # --- 4. tool-results dir (module global, read at call time) ------------
    try:
        if DEFAULT_STATE_DIR in getattr(_helpers, "_TOOL_RESULTS_DIR", ""):
            _helpers._TOOL_RESULTS_DIR = _helpers._TOOL_RESULTS_DIR.replace(
                DEFAULT_STATE_DIR, name
            )
    except Exception:
        pass

    # Two sentinels, on purpose: the module attr is the idempotency guard (cheap
    # and survives the function being rebound again), the function attr is what
    # `ioagentfarm patches` reads to show live bind state.
    _get_config_path._iof_state_dir_patch = True  # type: ignore[attr-defined]
    _loader._iof_state_dir_patch = True  # type: ignore[attr-defined]
    import sys as _sys
    _note(
        f"[aicore patches] apply_state_dir_override: ACTIVATED — runtime state "
        f"directory is ~/{name} (config.json, workspace, sessions, logs, cron); "
        f"{rebinds} early-bound reference(s) rebound.",
        file=_sys.stderr, flush=True,
    )


# ----------------------------------------------------------------------
# Patch: replace iobot's Azure OpenAI provider with a chat-completions
# variant for tenants that don't have the v1 Responses API enabled.
# ----------------------------------------------------------------------


def apply_azure_chat_backend() -> None:
    """Swap iobot's ``AzureOpenAIProvider`` for ``AzureOpenAIChatProvider``.

    The bundled provider targets ``{endpoint}/openai/v1/responses`` (Azure's
    v1 Responses API preview). Most enterprise Azure tenants only support
    the classic ``/openai/deployments/<dep>/chat/completions?api-version=...``
    surface, where the v1 path returns ``404 Resource not found``.

    Strategy: iobot dispatches to ``AzureOpenAIProvider`` via a *lazy*
    import inside ``iobot.iobot._make_provider`` and
    ``iobot.cli.commands._make_provider``::

        from iobot.providers.azure_openai_provider import AzureOpenAIProvider

    Because the import is performed each call, replacing the module
    attribute on ``iobot.providers.azure_openai_provider`` causes both
    dispatch sites to instantiate our class instead — without touching
    either dispatch function.

    Toggle: set ``IOF_DISABLE_AZURE_CHAT_PATCH=1`` to keep the original
    Responses-API behavior (only useful on tenants that have the v1
    preview enabled).

    Idempotency: the swap is a no-op when the module attribute already
    points at our class.
    """
    if os.environ.get("IOF_DISABLE_AZURE_CHAT_PATCH", "").lower() in ("1", "true", "yes"):
        return

    try:
        from iobot.providers import azure_openai_provider as az_mod
    except ImportError:
        # iobot not installed — skip silently.
        return

    from ioagentfarm.vendored.azure_openai_chat_provider import AzureOpenAIChatProvider

    # Idempotency: already patched.
    if getattr(az_mod.AzureOpenAIProvider, "_iof_azure_chat_patch", False):
        return

    AzureOpenAIChatProvider._iof_azure_chat_patch = True  # type: ignore[attr-defined]
    az_mod.AzureOpenAIProvider = AzureOpenAIChatProvider  # type: ignore[attr-defined,assignment]


def apply_genai_bedrock_backend() -> None:
    """Swap iobot's ``AnthropicProvider`` for ``GenaiBedrockProvider``
    when the client's Bedrock-wrapper gateway is the target.

    Strategy: same lazy-import trick as ``apply_azure_chat_backend`` —
    iobot dispatches to ``AnthropicProvider`` via::

        from iobot.providers.anthropic_provider import AnthropicProvider

    inside ``_make_provider``. Replacing the module attribute causes
    the dispatcher to instantiate our class instead, which rewrites
    requests to the wrapper's ``/model/{model}/invoke`` URL with the
    ``X-Api-Key`` auth header.

    Trigger: set ``IOF_USE_GENAI_BEDROCK=1`` to enable. Otherwise the
    bundled ``AnthropicProvider`` keeps targeting ``api.anthropic.com``
    (or whatever ``api_base`` the iobot config supplies).

    Required env vars when enabled (read inside the provider's
    ``__init__``):
      - ``GENAI_API_KEY`` — wrapper API key
      - ``GENAI_API_BASE`` — e.g. ``https://genaiapigwna.jnj.com``
      - ``GENAI_MODEL``    — e.g. ``us.anthropic.claude-opus-4-6-v1``
        (optional; falls back to a sane default if unset)

    Idempotency: the swap is a no-op when the module attribute
    already points at our class.
    """
    env_val = os.environ.get("IOF_USE_GENAI_BEDROCK", "")
    if env_val.lower() not in ("1", "true", "yes"):
        # Log at INFO so operators can see WHY the patch didn't fire
        # — most common cause of "Connection error" with no detail is
        # the env var being unset / misspelled. Print to stderr too
        # since logger may not be configured at patch time.
        import sys
        msg = (
            f"[aicore patches] apply_genai_bedrock_backend: "
            f"SKIPPED (IOF_USE_GENAI_BEDROCK={env_val!r}, expected 1/true/yes). "
            f"Bundled AnthropicProvider stays active — requests go to "
            f"the api_base in your iobot config (default api.anthropic.com)."
        )
        _note(msg, file=sys.stderr, flush=True)
        return

    try:
        from iobot.providers import anthropic_provider as anth_mod
    except ImportError:
        return

    from ioagentfarm.vendored.genai_bedrock_provider import GenaiBedrockProvider

    if getattr(anth_mod.AnthropicProvider, "_iof_genai_bedrock_patch", False):
        return

    GenaiBedrockProvider._iof_genai_bedrock_patch = True  # type: ignore[attr-defined]
    anth_mod.AnthropicProvider = GenaiBedrockProvider  # type: ignore[attr-defined,assignment]

    # Confirm activation in the server log so operators can verify the
    # monkey-patch actually fired (no diagnostic logs from the provider
    # → patch didn't run → wrong provider → wrong URL → "Connection
    # error" with no detail). Print to stderr because the standard
    # logging stack may not be configured at import time.
    import sys
    _note(
        "[aicore patches] apply_genai_bedrock_backend: ACTIVATED "
        "— iobot.providers.anthropic_provider.AnthropicProvider now "
        "resolves to GenaiBedrockProvider. Claude traffic will route "
        "through the GenAI gateway.",
        file=sys.stderr, flush=True,
    )


def apply_close_provider_clients() -> None:
    """Close each provider's HTTP client at interpreter exit.

    No LLM provider in the runtime closes the client it creates - not
    AnthropicProvider, not the two Azure providers, not openai_compat, not the
    vendored Azure-chat or Bedrock swaps. The client keeps a connection pool
    with keep-alive sockets, and nothing tears it down; that is left to
    interpreter shutdown.

    A step agent therefore stops writing to stdout and then lingers. Measured
    across the seven detection steps of run_20260820_072935_532816, the gap
    between stdout EOF and process exit was 62, 57, 56, 74, 5, 141 and 68
    seconds - about 463s a run. It does not track workload (the correlations
    with candidates, calls, stdout volume and session size are all weak and
    NEGATIVE), but it does track how recently the provider last spoke:
    `corr(idle-since-last-HTTP, lag) = -0.47`. The step whose last call was 162s
    earlier reaped in 5s; the one whose last call was 80s earlier took 141s.
    Connections the server has already dropped cost nothing to close; live ones
    do.

    Generic on purpose. Patching AnthropicProvider alone would fix a MiniMax
    deployment and leave an Azure or Bedrock gateway with the same lag, and the
    next provider added would arrive without it again.

    THE TEARDOWN IS BOUNDED, and that is the load-bearing part: a shutdown hook
    that hangs is strictly worse than the lag it removes. Every close runs under
    a timeout, every failure is swallowed, and the whole hook is skipped when it
    cannot get a loop. Worst case is the behaviour we have today.

    Toggle: IOF_CLOSE_PROVIDER_CLIENTS=0 disables it.
    """
    if os.environ.get("IOF_CLOSE_PROVIDER_CLIENTS", "").strip() == "0":
        return
    try:
        from iobot.providers.base import LLMProvider
    except Exception:
        return
    if getattr(LLMProvider, "_iof_client_close_patch", False):
        return

    import atexit
    import weakref

    # WeakSet: holding providers alive to close them would be its own leak, and
    # a provider already collected has had its client closed by the GC anyway.
    tracked: "weakref.WeakSet" = weakref.WeakSet()
    budget = float(os.environ.get("IOF_CLOSE_PROVIDER_TIMEOUT_S", "5"))

    _orig_init = LLMProvider.__init__

    def _init(self, *a, **kw):
        _orig_init(self, *a, **kw)
        try:
            tracked.add(self)
        except Exception:
            pass

    def _close_all() -> None:
        import asyncio

        import inspect

        # (closer, is_async) - decided by INSPECTION, not by name. AsyncAnthropic
        # exposes `close` as a COROUTINE and no `aclose`, so picking by attribute
        # name calls it without awaiting: "coroutine was never awaited", the
        # client stays open, and the hook reports success having done nothing.
        clients = []
        for prov in list(tracked):
            for attr in ("_client", "client", "_http_client"):
                c = getattr(prov, attr, None)
                if c is None:
                    continue
                fn = getattr(c, "aclose", None) or getattr(c, "close", None)
                if fn is None:
                    continue
                clients.append((fn, inspect.iscoroutinefunction(fn)))
                break
        if not clients:
            return

        async def _run() -> None:
            for fn, is_async in clients:
                try:
                    if is_async:
                        await asyncio.wait_for(fn(), timeout=budget)
                    else:
                        fn()
                except Exception:
                    pass

        try:
            # A running loop at interpreter exit means someone else owns
            # shutdown; adding a second one would be worse than doing nothing.
            asyncio.get_running_loop()
            return
        except RuntimeError:
            pass
        try:
            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(asyncio.wait_for(_run(), timeout=budget * 2))
            finally:
                loop.close()
        except Exception:
            pass

    try:
        LLMProvider.__init__ = _init  # type: ignore[method-assign]
        atexit.register(_close_all)
        LLMProvider._iof_client_close_patch = True  # type: ignore[attr-defined]
    except Exception:
        pass


def apply_request_timeout() -> None:
    """Bound the total duration of one LLM call, on BOTH the streaming and the
    non-streaming path.

    This used to live inside ``apply_disable_streaming`` as its "Patch 2", which
    coupled it to a flag it has nothing to do with: the function returns early
    when ``IOF_DISABLE_STREAMING`` is unset, so the only bound on total call
    duration existed exactly in the configuration that needs it LEAST. With
    streaming on there was no whole-call bound at all - only the runtime's
    per-chunk stall watchdog, which cannot fire while chunks keep arriving.

    Measured, not theorised (run_20260820_030328_787466, story:G02): a response
    body opened at 23:34:12 and closed at 23:50:10 without ever completing -
    **958 seconds** against a configured 180. Fix 6 recovered it via the stall
    path roughly 13 minutes after a timeout would have.

    This is the second time this exact shape has cost us. `sitecustomize`
    carried the runtime patches inside an `if forensics_dir is not None` guard,
    so disabling HTTP logging silently changed which provider class every agent
    used. A guard that answers a different question than the one being asked
    fails silently and in the direction nobody checks.

    Both entry points return ``LLMResponse``, so both take the same wrapper and
    produce the same error shape - the one Fix 6 already knows how to retry.

    Toggle: ``IOF_REQUEST_TIMEOUT_S`` seconds (default 180). ``0`` disables the
    bound entirely, which is the escape hatch for a deployment that genuinely
    wants unbounded calls.
    """
    ts = int(os.environ.get("IOF_REQUEST_TIMEOUT_S", "180"))
    if ts <= 0:
        return

    try:
        import asyncio
        from iobot.providers.base import LLMProvider, LLMResponse
    except Exception:
        return

    if getattr(LLMProvider, "_iof_timeout_patch", False):
        return

    def _bound(orig: Any, label: str) -> Any:
        async def _call(self: Any, *a: Any, **kw: Any) -> Any:
            try:
                return await asyncio.wait_for(orig(self, *a, **kw), timeout=ts)
            except asyncio.TimeoutError:
                # The SAME text Fix 6 already matches on. A new wording here
                # would be a timeout the recovery layer cannot see.
                return LLMResponse(
                    content=f"Error calling LLM: request timed out after {ts}s",
                    finish_reason="error")
        _call.__name__ = f"_iof_timeout_{label}"
        return _call

    # EVERY class that DEFINES chat/chat_stream, not just the base.
    #
    # AnthropicProvider defines its own `chat` AND `chat_stream`, so assigning to
    # LLMProvider.chat was shadowed and the bound never applied to the provider
    # actually in use. Measured with the chaos proxy: a request held open for 90s
    # under a 15s timeout rode the full 90s and came back as the runtime's own
    # "Connection error", never ours. That is the same shape as the hook bug in
    # apply_disable_streaming, in the patch written to fix its consequence.
    #
    # A concrete provider may not be imported yet when this runs, so the known
    # ones are imported explicitly; the subclass walk then catches anything else
    # already loaded (FallbackProvider, the vendored Azure/Bedrack swaps).
    def _targets():
        seen, out = set(), [LLMProvider]
        for mod, cls in (("iobot.providers.anthropic_provider", "AnthropicProvider"),
                         ("iobot.providers.base", "FallbackProvider")):
            try:
                out.append(getattr(__import__(mod, fromlist=[cls]), cls))
            except Exception:
                pass
        def walk(k):
            for s in k.__subclasses__():
                if s not in seen:
                    seen.add(s); out.append(s); walk(s)
        try:
            walk(LLMProvider)
        except Exception:
            pass
        return out

    for _cls in _targets():
        try:
            # __dict__, never getattr: getattr walks the MRO, so a subclass would
            # find the base's sentinel and skip itself - the very shadowing this
            # loop exists to defeat.
            # .get on the class's OWN dict: absent or explicitly False both
            # mean "patch it". `in __dict__` would treat a deliberate
            # `_iof_timeout_patch = False` - the way a caller unwinds this - as
            # already-patched and silently do nothing.
            if _cls.__dict__.get("_iof_timeout_patch"):
                continue
            for _name in ("chat", "chat_stream"):
                # Only where the class DEFINES it. An inherited method already
                # resolves to a wrapped base, and wrapping it again here would
                # apply the timeout twice on one call.
                if _name in _cls.__dict__:
                    setattr(_cls, _name, _bound(_cls.__dict__[_name], _name))
                elif _cls is LLMProvider and hasattr(_cls, _name):
                    setattr(_cls, _name, _bound(getattr(_cls, _name), _name))
            _cls._iof_timeout_patch = True  # type: ignore[attr-defined]
        except Exception:
            pass


def apply_disable_streaming() -> None:
    """Disable streaming for in-process AgentLoop (web API / process_direct path).

    The CLI path handles this via sitecustomize.py injected into each subprocess.
    The web API uses process_direct() in-process and never passes through the
    subprocess env, so that mechanism doesn't apply here.

    Mirrors cli.py Patch 2 exactly:
      - AgentHook.wants_streaming → False  (runner calls chat, not chat_stream)
      - AnthropicProvider.chat forced to stream=False at Anthropic SDK level

    The whole-call timeout is NOT part of this any more - it is
    apply_request_timeout, which applies whether or not streaming is disabled.

    Toggle: IOF_DISABLE_STREAMING=true|1|yes in environment.
    Idempotent: guards against double-patching with sentinel attributes.
    """
    if os.environ.get("IOF_DISABLE_STREAMING", "").lower() not in ("1", "true", "yes"):
        return

    ts = int(os.environ.get("IOF_REQUEST_TIMEOUT_S", "180"))

    # Patch 1: tell the runner to use chat() not chat_stream().
    #
    # EVERY class that DEFINES wants_streaming, not just the base. AgentHook is
    # the base, but the runner builds an AgentProgressHook, which overrides it
    # with `return self._on_stream is not None` - so patching only the base was
    # shadowed for every agent constructed with a stream callback, which is
    # every CLI step agent. The sentinel was set and `aicore patches` reported
    # ARMED while the runtime streamed regardless. A patch on a base class is
    # only a patch on the classes that do not override it.
    for _mod, _cls in (("iobot.agent.hook", "AgentHook"),
                       ("iobot.agent.hook", "CompositeHook"),
                       ("iobot.agent.progress_hook", "AgentProgressHook")):
        try:
            _m = __import__(_mod, fromlist=[_cls])
            _k = getattr(_m, _cls, None)
            # __dict__, NOT getattr: getattr walks the MRO, so a subclass
            # would find the base's sentinel and skip itself - the very
            # inheritance shadowing this loop exists to defeat.
            # .get, not `in`: an explicit False means "not patched", and it is
            # how a caller unwinds. getattr is wrong here for the other reason -
            # it walks the MRO, so a subclass would find the base's sentinel and
            # skip itself, which is the shadowing this loop exists to defeat.
            if _k is None or _k.__dict__.get("_iof_no_stream_patch"):
                continue
            # Only meaningful where the class defines its own; inherited ones
            # already resolve to a patched base.
            if "wants_streaming" in _k.__dict__ or _cls == "AgentHook":
                _k.wants_streaming = lambda self: False  # type: ignore[assignment]
                _k._iof_no_stream_patch = True  # type: ignore[attr-defined]
        except Exception:
            pass

    # Patch 2: the whole-call timeout. It lives in its own patch now and applies
    # regardless of this toggle - see apply_request_timeout for why. Called here
    # so that disabling streaming still guarantees it; the call is idempotent.
    apply_request_timeout()

    # Patch 3: force stream=False in AnthropicProvider.chat() at SDK level
    try:
        from iobot.providers.anthropic_provider import AnthropicProvider
        if not getattr(AnthropicProvider, "_iof_no_stream_ap_patch", False):
            _orig_ap_chat = AnthropicProvider.chat

            async def _ap_chat_no_stream(self: Any, *a: Any, **kw: Any) -> Any:
                orig_create = self._client.messages.create

                async def _create_no_stream(**ckw: Any) -> Any:
                    ckw["stream"] = False
                    return await orig_create(**ckw)

                self._client.messages.create = _create_no_stream
                try:
                    return await _orig_ap_chat(self, *a, **kw)
                finally:
                    self._client.messages.create = orig_create

            AnthropicProvider.chat = _ap_chat_no_stream  # type: ignore[method-assign]
            AnthropicProvider._iof_no_stream_ap_patch = True  # type: ignore[attr-defined]
    except Exception:
        pass

    import sys
    _note(
        "[aicore patches] apply_disable_streaming: ACTIVATED "
        "— AgentHook.wants_streaming=False, AnthropicProvider.chat stream=False. "
        "MiniMax streaming disabled for in-process path. "
        f"(whole-call timeout is apply_request_timeout, {ts}s, applied independently)",
        file=sys.stderr, flush=True,
    )


def apply_session_save_retry() -> None:
    """Retry SessionManager.save through a transient Windows file lock.

    ``os.replace(tmp, session.jsonl)`` intermittently raises PermissionError
    WinError 5 on Windows when an AV scanner / indexer briefly holds the
    freshly-written destination. Observed live 2026-08-14: the run driver
    (project_lead) crashed 12 seconds into run_20260814_204415_690744 while
    checkpointing its own session — and a CLI-detached run has no supervisor,
    so one sub-second lock killed the whole run. A session save is pure
    persistence: retrying through a momentary lock is always correct, and a
    real ACL problem still raises after the retries (~3s worst case).
    """
    from iobot.session import manager as _mgr

    if getattr(_mgr.SessionManager, "_iof_save_retry_patch", False):
        return
    _orig_save = _mgr.SessionManager.save

    def save(self, session, **kwargs):
        import time as _time
        delay = 0.1
        for attempt in range(6):
            try:
                return _orig_save(self, session, **kwargs)
            except PermissionError:
                if attempt == 5:
                    raise
                _time.sleep(delay)
                delay = min(delay * 2, 1.6)

    _mgr.SessionManager.save = save
    _mgr.SessionManager._iof_save_retry_patch = True


#: MCP server names that failed their handshake in THIS process. Read and
#: written only by `apply_mcp_connect_timeout`'s wrapper; cleared by
#: `reset_mcp_handshake_memo()` (tests, and a caller that changed the
#: declarations at runtime).
_MCP_HANDSHAKE_FAILED: set = set()


def reset_mcp_handshake_memo() -> None:
    _MCP_HANDSHAKE_FAILED.clear()


def apply_mcp_connect_timeout() -> None:
    """Bound MCP connection, per server, and continue without one that hangs.

    THE FAILURE THIS ENDS. An MCP server that starts but never completes its
    handshake blocks the agent forever. Upstream bounds the HTTP transports
    (``httpx.Timeout(30.0, connect=10.0)``) and bounds each TOOL CALL once a
    session exists (``cfg.tool_timeout``), but the STDIO handshake itself has
    no timeout at all: the child process starts, the pipes open, and
    ``ClientSession.initialize()`` waits for a reply that never comes.

    Observed 2026-08-16 with ``command: python`` and empty ``args`` — which
    starts the interactive interpreter, a process that reads stdin forever and
    never speaks MCP. The agent initialised its git store, attempted to
    connect, and sat for FORTY MINUTES.

    What made it expensive is that every diagnostic reads healthy. No error, no
    traceback, no non-zero exit. The HTTP forensics log is empty because no LLM
    call is ever attempted, no session JSONL is written because no turn ever
    completes, and the only output is the liveness ticker — which is working
    correctly and therefore looks like progress. The failure is
    indistinguishable from "the model is thinking", so the first suspicion
    falls on the provider, which is innocent: the endpoint answered the full
    18k-token prompt in 3.8s while the agent hung.

    A missing capability is a DEGRADED run, not a dead one, so a server that
    cannot be reached is named and skipped rather than allowed to take the run
    with it. Each server is bounded independently and they still connect
    concurrently, so one slow server cannot mask another's failure and a
    healthy server does not pay for a sick one.

    ``IOF_MCP_CONNECT_TIMEOUT_S`` overrides the ceiling; ``0`` restores the
    unbounded upstream behaviour.
    """
    from iobot.agent.tools import mcp as _mcp

    if getattr(_mcp.connect_mcp_servers, "_iof_mcp_timeout_patch", False):
        return
    _orig_connect = _mcp.connect_mcp_servers

    async def connect_mcp_servers(mcp_servers, registry):
        import asyncio as _aio

        try:
            budget = float(os.getenv("IOF_MCP_CONNECT_TIMEOUT_S", "60") or 60)
        except ValueError:
            budget = 60.0
        if budget <= 0 or not mcp_servers:
            return await _orig_connect(mcp_servers, registry)

        async def _one(name, cfg):
            # ONCE PER PROCESS. The runtime reconnects every server that is
            # not yet in its stack on EVERY turn, and a server that failed
            # its handshake is never in the stack - so a build session
            # paid the full budget again on each turn, and printed the
            # same error each time (seen: 60s x every turn of a session
            # whose `market_data` declaration started a bare interpreter).
            # A name that failed is skipped for the rest of this process;
            # a new session (a new process) tries again.
            if name in _MCP_HANDSHAKE_FAILED:
                logger.warning(
                    "MCP server '%s' is skipped for the rest of this session "
                    "- it failed its handshake earlier. Fix the declaration "
                    "(`aicore mcp-list`) and start a new session to retry.",
                    name)
                return {}
            try:
                return await _aio.wait_for(
                    _orig_connect({name: cfg}, registry), timeout=budget)
            except _aio.TimeoutError:
                _MCP_HANDSHAKE_FAILED.add(name)
                # NAME it. "an MCP server timed out" sends the reader looking
                # through every declaration; the whole cost of this failure was
                # not knowing which one, or that it was MCP at all.
                logger.error(
                    "MCP server '%s' did not complete its handshake within %.0fs "
                    "- continuing WITHOUT it. Its tools are unavailable for this "
                    "run. Check the declaration with `aicore mcp-list`: a command "
                    "that starts an interactive interpreter (e.g. `python` with no "
                    "args) never speaks MCP and will always do this.",
                    name, budget)
            except Exception as exc:                          # noqa: BLE001
                _MCP_HANDSHAKE_FAILED.add(name)
                logger.error("MCP server '%s' failed to connect (%s) - continuing "
                             "without it.", name, exc)
            return {}

        results = await _aio.gather(
            *(_one(n, c) for n, c in dict(mcp_servers).items()),
            return_exceptions=True)
        out: dict = {}
        for res in results:
            if isinstance(res, dict):
                out.update(res)
        return out

    connect_mcp_servers._iof_mcp_timeout_patch = True
    _mcp.connect_mcp_servers = connect_mcp_servers


def apply_write_file_keeps_newlines() -> None:
    """`write_file` writes the model's bytes, not the platform's.

    The vendored tool is `fp.write_text(content, encoding="utf-8")` -
    `newline=None`, so on Windows every LF the model authored becomes
    CRLF, and content that already carried CRLF (a captured command
    output) becomes `\r\r\n`. Its two siblings both preserve:
    `apply_patch` passes `newline=""`, `edit_file` writes bytes. Measured
    cost: a `steps/*.sh` or Dockerfile helper authored on the Windows dev
    box arrives on the Linux pod as `bad interpreter: /bin/sh^M`, and the
    success string reports the pre-translation length so neither the
    model nor a test of the result can see it happened.

    The wrapper lets the original do ALL of its work - validation, path
    resolution, error shapes - and then, on success only, rewrites the
    file with the exact authored bytes and re-records the write state so
    the staleness tracker matches the final mtime.
    """
    try:
        from iobot.agent.tools import filesystem as _fs
    except ImportError:
        return
    cls = getattr(_fs, "WriteFileTool", None)
    if cls is None or getattr(cls, "_iof_keeps_newlines", False):
        return
    _orig = cls.execute

    async def execute(self, path=None, content=None, **kwargs):
        result = await _orig(self, path=path, content=content, **kwargs)
        try:
            if (isinstance(result, str)
                    and result.startswith("Successfully wrote")
                    and isinstance(content, str) and "\n" in content
                    and path):
                fp = self._resolve_write(path)
                fp.write_bytes(content.encode("utf-8"))
                self._file_states.record_write(fp)
        except Exception:                  # noqa: BLE001 - fidelity is a
            logger.debug("write_file newline fix failed", exc_info=True)
        return result

    cls.execute = execute
    cls._iof_keeps_newlines = True


def apply_read_file_line_cap_honesty() -> None:
    """A line too long to page gets an ERROR, not an invitation to loop.

    When a single line exceeds the 128K view, the vendored trim loop keeps
    ZERO lines and the footer reads `(Showing lines 1-0 of 1. Use offset=1
    to continue.)` - no content, and an instruction to repeat the exact
    same call. A model that obeys loops until the call budget kills the
    turn. Any minified vendor file or one-line JSON catalog triggers it.
    """
    try:
        from iobot.agent.tools import filesystem as _fs
        from iobot.agent.tools.base import ToolResult
    except ImportError:
        return
    cls = getattr(_fs, "ReadFileTool", None)
    if cls is None or getattr(cls, "_iof_line_cap_honesty", False):
        return
    _orig = cls.execute
    _rx = re.compile(r"\(Showing lines (\d+)-(\d+) of \d+\. "
                     r"Use offset=(\d+) to continue\.\)")

    async def execute(self, path=None, **kwargs):
        result = await _orig(self, path=path, **kwargs)
        if isinstance(result, str):
            m = _rx.search(result)
            if m and int(m.group(2)) < int(m.group(1)):
                return ToolResult.error(
                    f"Error: line {m.group(1)} of {path} is longer than "
                    "the 128000-character view, so this file cannot be "
                    "paged by line. Do NOT retry the same read. Take a "
                    "slice through exec instead (e.g. `python -c "
                    '"print(open(r\'\'\'FILE\'\'\').read()[:4000])"`), or '
                    "work from its name and skip the content.")
        return result

    cls.execute = execute
    cls._iof_line_cap_honesty = True


def apply_apply_patch_tolerance() -> None:
    """Let `apply_patch` find `old_text` the way `edit_file` already can.

    THE FAILURE. A build session on a client box hit `Error applying
    patch: old_text not found in <file>` three times on files it had READ
    moments before, and fell back to `write_file` (a whole-file overwrite)
    each time. `apply_patch` locates `old_text` with a bare `str.find`
    after CRLF normalisation - nothing else. `edit_file` has a four-step
    ladder for the same job (exact -> per-line trimmed -> trimmed with
    quotes normalised -> quotes normalised) plus a best-match diagnostic
    when all four miss. `read_file` shows the model every line behind a
    `N| ` prefix it has to strip exactly; one greedy strip that eats a
    continuation line's indent, or one em dash re-typed as a hyphen, and
    the strict tool misses while the tolerant one would have found it. And
    the runtime's tool contract tells the model to PREFER the strict one.

    THE FIX, without touching vendored source: before the original runs,
    every `replace` edit whose `old_text` is not an exact substring of the
    target is resolved through `filesystem._find_matches`, and when that
    yields exactly one span the edit's `old_text` is rewritten to the text
    actually in the file. The original then finds it exactly and does all
    of its own work - CRLF preservation, multi-edit ordering, backups,
    file-state recording. Edits on one file are simulated in order so a
    later edit resolves against the earlier one's result, as the original
    applies them. When nothing matches, the original's error is returned
    with `edit_file`'s best-match diff appended, so the model can correct
    `old_text` in one round instead of overwriting the file.

    Ambiguity is left to the original: two or more candidate spans are not
    rewritten, and it reports "appears multiple times" as before.
    """
    try:
        from iobot.agent.tools import apply_patch as _ap
        from iobot.agent.tools import filesystem as _fs
    except ImportError:
        return
    cls = getattr(_ap, "ApplyPatchTool", None)
    if cls is None or getattr(cls, "_iof_apply_patch_tolerance", False):
        return
    _orig = cls.execute

    #: One-character dashes a model re-types as a hyphen when it copies a
    #: line back: the scaffold templates carry em dashes, the ladder in
    #: edit_file normalises QUOTES only. Same-length replacements, so a
    #: span found in the normalised text slices the real text exactly.
    _DASHES = str.maketrans({"—": "-", "–": "-", "‒": "-",
                             "−": "-", "‐": "-", "‑": "-"})

    def _dash_matches(fs, content, old_text):
        nc, no = content.translate(_DASHES), old_text.translate(_DASHES)
        if nc == content and no == old_text:
            return []
        spans = fs._find_matches(nc, no)
        return [fs._MatchSpan(start=m.start, end=m.end,
                              text=content[m.start:m.end], line=m.line)
                for m in spans]

    def _resolve(self, edits):
        """(edits with old_text rewritten where it helps, diagnostics)."""
        out, diags = [], []
        pending: dict = {}                     # resolved path -> simulated text
        for edit in edits:
            if not isinstance(edit, dict) or edit.get("action") != "replace":
                out.append(edit)
                continue
            old_text = edit.get("old_text")
            new_text = edit.get("new_text")
            raw_path = edit.get("path")
            if not (isinstance(old_text, str) and old_text
                    and isinstance(raw_path, str)):
                out.append(edit)
                continue
            try:
                source = self._resolve_write(_ap._validate_patch_path(raw_path))
                if source in pending:
                    content = pending[source]
                else:
                    content = source.read_bytes().decode("utf-8")
            except Exception:                  # noqa: BLE001 - the original reports it
                out.append(edit)
                continue
            norm_content = content.replace("\r\n", "\n")
            norm_old = old_text.replace("\r\n", "\n")
            resolved = norm_old
            if norm_content.find(norm_old) < 0:
                try:
                    found = _fs._find_matches(norm_content, norm_old)
                    if not found:
                        found = _dash_matches(_fs, norm_content, norm_old)
                except Exception:              # noqa: BLE001
                    found = []
                if len(found) == 1:
                    resolved = found[0].text
                    edit = dict(edit, old_text=resolved)
                elif not found:
                    try:
                        diags.append(str(_fs.EditFileTool._not_found_msg(
                            norm_old, norm_content, raw_path)))
                    except Exception:          # noqa: BLE001
                        pass
            out.append(edit)
            pos = norm_content.find(resolved)
            if pos >= 0 and isinstance(new_text, str):
                pending[source] = (norm_content[:pos]
                                   + new_text.replace("\r\n", "\n")
                                   + norm_content[pos + len(resolved):])
        return out, diags

    async def execute(self, edits=None, dry_run=False, **kwargs):
        diags: list = []
        if isinstance(edits, list) and edits:
            try:
                edits, diags = _resolve(self, edits)
            except Exception:                  # noqa: BLE001 - never worse than before
                logger.debug("[aicore patches] apply_patch pre-resolve failed",
                             exc_info=True)
        result = await _orig(self, edits=edits, dry_run=dry_run, **kwargs)
        if diags and "old_text not found" in str(result):
            # The original's one-line error, plus what edit_file would have
            # said: the closest window in the file as a unified diff.
            extra = "\n".join(d.replace("Error: old_text not found in", "Closest match for", 1)
                              for d in diags)
            try:
                from iobot.agent.tools.base import ToolResult
                return ToolResult.error(f"{result}\n{extra}")
            except Exception:                  # noqa: BLE001
                return f"{result}\n{extra}"
        return result

    cls.execute = execute
    cls._iof_apply_patch_tolerance = True
    _ap.ApplyPatchTool._iof_apply_patch_tolerance_patch = True


def apply_dedup_tool_call_ids() -> None:
    """Make tool_use IDs unique ON THE WIRE — fixes MiniMax's duplicate-id bug.

    MiniMax-M2.7 sometimes assigns the SAME id to two ``tool_use`` blocks in a
    single (parallel) assistant turn — e.g. two blocks both
    ``call_function_<x>_2`` (and the matching ``tool_result`` blocks inherit the
    same duplicate). The Anthropic-compatible API then rejects EVERY subsequent
    request in that session with a 400 ``invalid params, duplicate tool_call id``
    — unrecoverable, and it kills the step. Seen on deck_build's parallel file
    reads / slide writes; the ``presentation`` skill deliberately batches tool
    calls in parallel for efficiency, which is what exposes it.

    ROOT CAUSE + WHY THE OBVIOUS FIX DOESN'T WORK (proven by replaying the exact
    failing payload against api.minimax.io — 400 baseline, 200 after this fix):
    the duplicate id is baked into iobot's STORED conversation history and
    replayed on every following turn. A ``_parse_response`` rename (the first
    attempt at this patch) touches only the freshly-parsed ``ToolCallRequest``
    list; iobot stores tool calls in OpenAI-shape dicts (``tool_calls:[{id,
    function}]`` + ``tool_call_id`` on tool turns) and rebuilds the outgoing
    ``tool_use`` / ``tool_result`` blocks from THOSE, so the rename never reached
    the wire and the 400 persisted.

    Correct layer: wrap ``AnthropicProvider._convert_messages`` — the single seam
    (used by both ``chat`` and ``chat_stream`` via ``_build_kwargs``) that emits
    the final Anthropic ``messages`` array. After it builds the blocks, walk each
    message and rename duplicate ids per-message: a ``tool_use``'s ``id`` and a
    ``tool_result``'s ``tool_use_id``, second-and-later occurrence of an id →
    ``<id>_dup<n>``. Because the assistant ``tool_use`` blocks and their following
    ``tool_result`` blocks are built from the SAME stored order, the identical
    per-message counting renames both sides to the SAME new id — the pair stays
    matched with no cross-message bookkeeping. (The observed collision is always
    WITHIN one parallel turn; each MiniMax turn carries a distinct id prefix, so
    per-message scope is sufficient and preserves tool_use↔tool_result pairing.)

    Deterministic — no reliance on retry luck. Safe no-op for well-behaved
    providers (real Anthropic never duplicates, so the rename branch never fires).
    Idempotent via sentinel. Also covers GenaiBedrockProvider, which subclasses
    AnthropicProvider and inherits ``_convert_messages``.
    """
    try:
        from iobot.providers.anthropic_provider import AnthropicProvider
    except Exception:
        return
    if getattr(AnthropicProvider, "_iof_dedup_toolids_patch", False):
        return
    _orig_convert = AnthropicProvider._convert_messages  # instance method

    def _dedup_wire_ids(anthropic_msgs: Any) -> Any:
        for m in anthropic_msgs or []:
            content = m.get("content") if isinstance(m, dict) else None
            if not isinstance(content, list):
                continue
            seen: dict = {}
            for block in content:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                key = "id" if btype == "tool_use" else (
                    "tool_use_id" if btype == "tool_result" else None
                )
                if not key:
                    continue
                tid = block.get(key)
                if not tid:
                    continue
                n = seen.get(tid, 0)
                if n:
                    block[key] = f"{tid}_dup{n}"
                seen[tid] = n + 1
        return anthropic_msgs

    def _convert_messages_deduped(self: Any, messages: Any) -> Any:
        system, anthropic_msgs = _orig_convert(self, messages)
        return system, _dedup_wire_ids(anthropic_msgs)

    AnthropicProvider._convert_messages = _convert_messages_deduped  # type: ignore[method-assign]
    AnthropicProvider._iof_dedup_toolids_patch = True  # type: ignore[attr-defined]
    import sys
    _note(
        "[aicore patches] apply_dedup_tool_call_ids: ACTIVATED "
        "— duplicate MiniMax tool_use/tool_result IDs are renamed unique on the "
        "wire in _convert_messages (prevents 'duplicate tool_call id' 400s).",
        file=sys.stderr, flush=True,
    )


# ----------------------------------------------------------------------
# Patch: capture per-call token usage via iobot's NATIVE AgentHook API.
# ----------------------------------------------------------------------


def _iof_append_usage(path: str, iteration: Any, session_key: Any, usage: dict) -> None:
    """Append one JSONL usage record to ``path``. Module-level so it's unit-testable.

    Maps iobot's usage keys (anthropic_provider._parse_response) to a compact
    record::

        prompt_tokens      -> in  (total input incl. cache: new + read + write)
        completion_tokens  -> out (output)
        cache_read_input_tokens / cached_tokens   -> cr (cache read)
        cache_creation_input_tokens               -> cw (cache write)

    New (uncached) input for a call is ``in - cr - cw``. All writes are best-effort.
    """
    try:
        import json as _json
        import time as _time
        rec = {
            "t": _time.time(),
            "iter": iteration,
            "session": session_key,
            "in": int(usage.get("prompt_tokens", 0) or 0),
            "out": int(usage.get("completion_tokens", 0) or 0),
            "cr": int(usage.get("cache_read_input_tokens",
                                usage.get("cached_tokens", 0)) or 0),
            "cw": int(usage.get("cache_creation_input_tokens", 0) or 0),
            "raw": dict(usage),
        }
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(_json.dumps(rec) + "\n")
    except Exception:
        pass



def apply_gitstore_race_tolerance() -> str:
    """Three fan-out items start on one role workspace within the same
    second; each runtime process initialises the memory git store, and the
    losers raise FileExistsError on `.git` - logged as a full ERROR
    traceback into the step's stderr.log, the blob explain points a person
    at, while the step succeeds (novice finding). The store exists; the
    second init has nothing to do."""
    from iobot.utils import gitstore as _gs
    orig = _gs.GitStore.init
    if getattr(orig, "_iof_gitstore_race", False):
        return "already applied"

    def _init(self, *a, **k):
        try:
            return orig(self, *a, **k)
        except Exception as e:  # noqa: BLE001
            # dulwich raises FileExistsError; GitStore re-raises it as its
            # own GitStoreError. The race's signature is not the type but
            # the state: the store EXISTS after the failure - the other
            # process won, and this one has nothing to do.
            ws = getattr(self, "_workspace", None)
            if ws is not None and (Path(ws) / ".git").exists():
                return None
            raise
    _init._iof_gitstore_race = True
    _gs.GitStore.init = _init
    return "applied"


def otel_span_identity(loop: Any = None) -> tuple:
    """(model, gen_ai.system, agent) for an LLM span - env first, then the loop.

    A module-level seam so it can be tested without building an AgentLoop.
    `IOF_OTEL_MODEL`/`IOF_OTEL_AGENT` are set by `cli._invoke_agent` for a
    SUBPROCESS agent, where one process serves one step; `serve` holds a pool
    of loops in ONE process and sets neither, which is why every always-on
    span used to read model "unknown". Never raises: a missing attribute
    yields "" and the span simply carries less.
    """
    model = os.environ.get("IOF_OTEL_MODEL") or ""
    agent = os.environ.get("IOF_OTEL_AGENT") or ""
    if not model:
        try:
            model = str(getattr(loop, "model", "") or "")
        except Exception:
            model = ""
    if not agent:
        try:
            ws = getattr(loop, "workspace", None)
            agent = ws.parent.name if ws is not None else ""   # .../<role>/workspace
        except Exception:
            agent = ""
    system = model.split("/", 1)[0] if "/" in model else (model or "unknown")
    return model, system, agent


def apply_otel_llm_spans() -> None:
    """Emit one OTel span per LLM call (and per tool the agent runs) in the
    agent child, parented to the step span whose ``TRACEPARENT`` the
    ``run-step`` process put in our environment.

    Same seam as ``apply_usage_capture`` - the public ``AgentHook`` API,
    appended to ``AgentLoop._extra_hooks`` - so nothing inside the provider is
    wrapped. ``before_iteration`` starts the LLM span; it ends at the first of
    ``before_execute_tools`` (the model answered with tool calls, which run
    next and are not the model's time) or ``after_iteration`` (it answered with
    text). ``context.usage`` is read at the end - the runtime sets it from the
    response before either fires. Tool executions get their own spans between
    ``before_execute_tool`` and ``after_execute_tool`` / ``on_execute_tool_error``.

    Conventions: OTel GenAI (``gen_ai.*``) primary, OpenInference aliases
    beside them - see engine/otel_export.py. Model and agent name arrive as
    ``IOF_OTEL_MODEL`` / ``IOF_OTEL_AGENT`` from the parent; the runtime does
    not put the model on the hook context.

    A safe no-op unless export is on AND a ``TRACEPARENT`` is present: with
    no parent there is no trace to join, and an orphan span per LLM call
    would be noise in the client's backend.
    """
    if not (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or os.environ.get("IOF_OTEL_EXPORTER")):
        return
    try:
        from iobot.agent.loop import AgentLoop
        from iobot.agent.hook import AgentHook
        from ioagentfarm.engine import otel_export as _ex
        if not (_ex.available() and _ex.enabled()):
            return
        from opentelemetry import trace as _otrace
        from opentelemetry.trace import Status, StatusCode
        from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
    except Exception:
        return
    if getattr(AgentLoop, "_iof_otel_hook_patch", False):
        return

    # A subprocess agent (a workflow step) has the step span's TRACEPARENT in
    # its environment. An in-process agent (serve: chat, A2A, Teams) has none -
    # its parent is the CURRENT span, the `aicore.chat` turn wrap_chat opened
    # in the same task. Neither means no trace to join: emit nothing rather
    # than orphan a span per LLM call into the client's backend.
    _tp = os.environ.get("TRACEPARENT")
    _parent = TraceContextTextMapPropagator().extract({"traceparent": _tp}) if _tp else None

    def _parent_ctx():
        if _parent is not None:
            return _parent, True
        cur = _otrace.get_current_span()
        return None, bool(cur is not None and cur.get_span_context().is_valid)
    class _IofOtelHook(AgentHook):
        """One span per LLM call and per agent tool call.

        IDENTITY IS RESOLVED PER LOOP, NOT ONCE FROM THE ENVIRONMENT. The
        module-level `IOF_OTEL_MODEL`/`IOF_OTEL_AGENT` are set by
        `cli._invoke_agent` for a SUBPROCESS agent, where one process serves
        one step, so reading them once was right there and wrong everywhere
        else: `serve` holds a pool of loops in ONE process and sets neither,
        so every always-on span - Studio chat, A2A, Teams - was named
        `gen_ai.chat llm` with `gen_ai.system="unknown"` and no
        `gen_ai.request.model` at all. Cost and latency dashboards group by
        that attribute, so the interactive surfaces were the ones that fell
        out. The loop knows: `AgentLoop.model` is a live property (it follows
        a runtime preset switch mid-session) and `AgentLoop.workspace` is
        `.../agents/<role>/workspace`. Env still wins when set, so the
        subprocess path keeps the exact value its instance config named.
        """

        def __init__(self, loop: Any = None) -> None:
            super().__init__()
            self._llm: dict = {}      # iteration -> span
            self._tools: dict = {}    # id(tool_call) -> span
            self._tokens: dict = {}   # id(tool_call) -> context-attach token
            self._loop = loop

        def _identity(self) -> tuple:
            return otel_span_identity(self._loop)

        def _tracer(self):
            return _ex.tracer()

        async def before_iteration(self, context: Any) -> None:
            t = self._tracer()
            if t is None:
                return
            it = getattr(context, "iteration", 0)
            _mdl, _sys, _agt = self._identity()
            attrs = {"gen_ai.operation.name": "chat", "gen_ai.system": _sys,
                     "gen_ai.request.model": _mdl, "aicore.iteration": it,
                     "openinference.span.kind": "LLM"}
            if _agt:
                attrs["gen_ai.agent.name"] = _agt
            ctx, ok = _parent_ctx()
            if not ok:
                return
            self._llm[it] = t.start_span(f"gen_ai.chat {_mdl or 'llm'}", context=ctx,
                                         attributes={k: v for k, v in attrs.items() if v != ""})

        def _end_llm(self, context: Any) -> None:
            it = getattr(context, "iteration", 0)
            span = self._llm.pop(it, None)
            if span is None:
                return
            try:
                u = getattr(context, "usage", None) or {}
                pin = int(u.get("prompt_tokens", 0) or 0)
                pout = int(u.get("completion_tokens", 0) or 0)
                cr = int(u.get("cache_read_input_tokens", u.get("cached_tokens", 0)) or 0)
                cw = int(u.get("cache_creation_input_tokens", 0) or 0)
                span.set_attributes({
                    "gen_ai.usage.input_tokens": pin, "gen_ai.usage.output_tokens": pout,
                    "llm.token_count.prompt": pin, "llm.token_count.completion": pout,
                    "llm.token_count.total": pin + pout,
                    "aicore.usage.cache_read_tokens": cr, "aicore.usage.cache_write_tokens": cw,
                })
                sr = getattr(context, "stop_reason", None)
                if sr:
                    span.set_attribute("gen_ai.response.finish_reasons", [str(sr)])
                calls = getattr(context, "tool_calls", None) or []
                if calls:
                    span.set_attribute("aicore.llm.tool_calls",
                                       [str(getattr(c, "name", c))[:80] for c in calls][:20])
                err = getattr(context, "error", None)
                if err:
                    span.set_status(Status(StatusCode.ERROR, str(err)[:200]))
                tok = _ex.instrument("tokens")
                if tok is not None:
                    _m, _s, _ = self._identity()
                    base = {"gen_ai.request.model": _m, "gen_ai.system": _s}
                    tok.record(pin, {**base, "gen_ai.token.type": "input"})
                    tok.record(pout, {**base, "gen_ai.token.type": "output"})
            except Exception:
                pass
            finally:
                try:
                    span.end()
                except Exception:
                    pass

        async def before_execute_tools(self, context: Any) -> None:
            self._end_llm(context)

        async def after_iteration(self, context: Any) -> None:
            self._end_llm(context)

        async def before_execute_tool(self, context: Any, tool_call: Any, tool: Any,
                                      params: Any) -> None:
            t = self._tracer()
            if t is None:
                return
            name = str(getattr(tool_call, "name", None) or getattr(tool, "name", "tool"))
            # TOOL ARGUMENTS ARE CONTENT, AND THIS WAS THE ONE PLACE THAT
            # FORGOT IT. The run goal and the step input are both gated on
            # IOF_OTEL_CONTENT; these two attributes were not, so with the
            # flag UNSET a validator measured 16 of 16 tool spans carrying
            # document text and command output on the wire to a third-party
            # observability vendor - while the walkthrough stated flatly that
            # "message bodies are not exported". For an always-on agent the
            # customer's own words routinely become a tool argument.
            #
            # The LENGTH is always exported: it is the number that makes a
            # trace useful without disclosing anything.
            try:
                pstr = json.dumps(params, default=str)[:500] if params is not None else ""
            except Exception:
                pstr = str(params)[:500]
            ctx, ok = _parent_ctx()
            if not ok:
                return
            attrs = {"openinference.span.kind": "TOOL", "tool.name": name,
                     "aicore.input.chars": len(pstr),
                     "aicore.iteration": getattr(context, "iteration", 0)}
            if _otel_content_enabled():
                attrs["input.value"] = pstr
            span = t.start_span(
                f"aicore.agent_tool {name}", context=ctx, attributes=attrs)
            self._tools[id(tool_call)] = span
            # MAKE IT THE CURRENT SPAN FOR THE DURATION OF THE CALL. The hook
            # pair brackets `await tool.execute(...)` in one coroutine, and
            # asyncio hands each task its own copy of the context, so this is
            # scoped to this execution even when several tools run at once.
            # It is what lets an MCP call made INSIDE the tool carry this
            # span as its parent (see the `mcp_trace_context` patch): without
            # it the current span is the step, and a remote server's work
            # hangs beside the tool call rather than under it.
            try:
                self._tokens[id(tool_call)] = _otrace.context_api.attach(
                    _otrace.set_span_in_context(span))
            except Exception:
                pass

        def _end_tool(self, tool_call: Any, result: Any = None, error: Any = None) -> None:
            tok = self._tokens.pop(id(tool_call), None)
            if tok is not None:
                try:
                    _otrace.context_api.detach(tok)
                except Exception:
                    pass
            span = self._tools.pop(id(tool_call), None)
            if span is None:
                return
            try:
                if error is not None:
                    span.set_status(Status(StatusCode.ERROR, str(error)[:200]))
                elif result is not None:
                    rstr = str(result)
                    # Same rule at the other end: a tool RESULT is content
                    # too - a file's text, a query's rows, a command's output.
                    span.set_attribute("aicore.output.chars", len(rstr))
                    if _otel_content_enabled():
                        span.set_attribute("output.value", rstr[:500])
            except Exception:
                pass
            finally:
                try:
                    span.end()
                except Exception:
                    pass

        async def after_execute_tool(self, context: Any, tool_call: Any, tool: Any,
                                     params: Any, result: Any) -> None:
            self._end_tool(tool_call, result=result)

        async def on_execute_tool_error(self, context: Any, tool_call: Any, tool: Any,
                                       params: Any, error: Any = None, *a: Any, **k: Any) -> None:
            self._end_tool(tool_call, error=error or "tool error")

        async def on_finally(self, context: Any) -> None:
            # the agent child is short-lived: push what is buffered before exit
            for sp in list(self._llm.values()) + list(self._tools.values()):
                try:
                    sp.end()
                except Exception:
                    pass
            self._llm.clear(); self._tools.clear()
            try:
                _ex.flush()
            except Exception:
                pass

    _orig_init = AgentLoop.__init__

    def _init_with_otel_hook(self: Any, *a: Any, **k: Any) -> None:
        _orig_init(self, *a, **k)
        try:
            hooks = getattr(self, "_extra_hooks", None)
            if isinstance(hooks, list) and not any(
                    type(h).__name__ == "_IofOtelHook" for h in hooks):
                hooks.append(_IofOtelHook(self))
        except Exception:
            pass

    AgentLoop.__init__ = _init_with_otel_hook  # type: ignore[method-assign]
    AgentLoop._iof_otel_hook_patch = True  # type: ignore[attr-defined]


def apply_usage_capture() -> None:
    """Record exact per-LLM-call token usage the *native* way — via an AgentHook.

    iobot already parses each response's full usage into ``context.usage``
    (``runner.py`` sets it per iteration from the LLM result — for BOTH streaming
    and non-streaming) and exposes it through the public ``AgentHook`` API. So we
    do NOT wrap any provider internals (an earlier ``_parse_response`` wrap was
    fragile — that method is a ``@staticmethod``, so wrapping it as an instance
    method crashed). Instead we register a lightweight hook whose
    ``after_iteration`` appends one JSONL line per call to ``IOF_USAGE_FILE``.

    Injection seam: patch ``AgentLoop.__init__`` to append the hook to
    ``self._extra_hooks`` — the same public list ``process``/``process_direct``
    read (``run_hooks = [*self._extra_hooks, ...]``). The one-shot ``iobot
    agent`` CLI (how workflow steps + the orchestrator run) builds the loop via
    ``from_config`` and passes NO hooks, and iobot's own ``TokenUsageHook`` is
    only wired into the gateway/serve runtime — hence this.

    Robust (public hook API + a constructor append, not an internal-method wrap),
    idempotent via sentinel, and a safe no-op whenever ``IOF_USAGE_FILE`` is
    unset (so it's harmless in the in-process web path too).
    """
    try:
        from iobot.agent.loop import AgentLoop
        from iobot.agent.hook import AgentHook
    except Exception:
        return
    if getattr(AgentLoop, "_iof_usage_hook_patch", False):
        return

    class _IofUsageHook(AgentHook):
        """Append per-call usage to IOF_USAGE_FILE. No-op if the env is unset."""

        async def after_iteration(self, context: Any) -> None:
            path = os.environ.get("IOF_USAGE_FILE")
            if not path:
                return
            u = getattr(context, "usage", None)
            if not u:
                return
            _iof_append_usage(
                path,
                getattr(context, "iteration", None),
                getattr(context, "session_key", None),
                u,
            )

    _orig_init = AgentLoop.__init__

    def _init_with_usage_hook(self: Any, *a: Any, **k: Any) -> None:
        _orig_init(self, *a, **k)
        try:
            hooks = getattr(self, "_extra_hooks", None)
            if isinstance(hooks, list) and not any(
                type(h).__name__ == "_IofUsageHook" for h in hooks
            ):
                hooks.append(_IofUsageHook())
        except Exception:
            pass

    AgentLoop.__init__ = _init_with_usage_hook  # type: ignore[method-assign]
    AgentLoop._iof_usage_hook_patch = True  # type: ignore[attr-defined]
    import sys
    _note(
        "[aicore patches] apply_usage_capture: ACTIVATED "
        "— AgentLoop._extra_hooks gains a native usage hook; per-call tokens "
        "append to IOF_USAGE_FILE when set (no provider-internal wrapping).",
        file=sys.stderr, flush=True,
    )


AGENCY_TOOLS = ("spawn", "create_goal", "update_goal")


def apply_restrict_agency_tools() -> None:
    """Unregister iobot 0.3.0's "agency" tools from every AgentLoop we build.

    0.3.0 registers 16 tools by default, three of which let an agent
    restructure its own work: ``spawn`` (run an inline or background subagent)
    and ``create_goal`` / ``update_goal`` (record a sustained objective on the
    session).

    These are NOT new in 0.3.0 — verified against an installed 0.2.2, which
    ships ``spawn.py`` (tool ``spawn``) and ``long_task.py`` (tools
    ``long_task`` + ``complete_goal``). 0.3.0 renamed the goal pair; it did not
    introduce the capability. So this is a long-standing exposure that the
    upgrade made visible, not a regression it caused.

    Why they are wrong for a STEP agent specifically:

    - A step is a contract: one session, a rendered prompt, a
      ``requires_artifacts`` gate, forensic blobs, a token record, a hard
      attempt cap. Work done by a spawned subagent sits outside ALL of it —
      its tokens are not in the step's usage record, its dialog is not in the
      step's session snapshot, and its lifetime is not bounded by the step's
      timeout. The step would report ``STATUS: done`` for work the harness
      never saw.
    - Delegation is the ORCHESTRATOR's job here, expressed as a DAG in
      workflow.yaml and executed by ``run-step``. An agent spawning its own
      helpers is a second, invisible scheduler competing with the first.
    - Goals are session-scoped, and step sessions are ``fresh_session: true``
      per attempt — a recorded goal is discarded moments later. The cost is
      not just the wasted tool schema in every prompt; it is that a model
      offered a "record the objective" affordance sometimes takes it INSTEAD
      of doing the work.

    This is not a claim that iobot's agency model is bad — it is aimed at
    interactive sessions, where it is the right idea. It just cannot coexist
    with a deterministic step in the same process.

    Scope: this wraps ``AgentLoop.__init__``, so it covers every loop built
    inside a process that imports ioagentfarm — the in-process always-on pool
    AND the ``iobot agent`` subprocesses that get our sitecustomize. It does
    NOT reach ``iobot gateway`` (launched as a bare subprocess with no
    injection), which is deliberate: a chat gateway is exactly the interactive
    case these tools are designed for.

    Config: ``IOF_DISABLE_TOOLS`` — comma-separated tool names, overriding the
    default set. ``none`` (or an empty value) keeps every tool: the escape
    hatch for reproducing 0.3.0-native behaviour. ``none`` exists because
    PowerShell DELETES an environment variable when you assign it ``""``, so
    on Windows the empty-string form silently means "unset" — i.e. the exact
    opposite of what the operator typed.

    Verified before shipping that no SOUL, skill or step prompt in this repo
    asks for any of these by name; every "spawn" in our prompts means
    ``run-task`` / ``run-step``, and nothing references ``long_task``.
    """
    raw = os.environ.get("IOF_DISABLE_TOOLS")
    if raw is None:
        names = AGENCY_TOOLS
    elif raw.strip().lower() in ("", "none"):
        names = ()
    else:
        names = tuple(n.strip() for n in raw.split(",") if n.strip())
    if not names:
        return

    try:
        from iobot.agent.loop import AgentLoop
    except Exception:
        return
    if getattr(AgentLoop, "_iof_tool_restrict_patch", False):
        return

    _orig_init = AgentLoop.__init__

    def _init_without_agency_tools(self: Any, *a: Any, **k: Any) -> None:
        _orig_init(self, *a, **k)
        # Tools are registered during __init__, so this runs after the
        # registry is populated. has() first: unregister() on an absent name
        # would raise, and the set legitimately varies with config.
        try:
            for name in names:
                if self.tools.has(name):
                    self.tools.unregister(name)
        except Exception:
            pass

    AgentLoop.__init__ = _init_without_agency_tools  # type: ignore[method-assign]
    AgentLoop._iof_tool_restrict_patch = True  # type: ignore[attr-defined]
    import sys
    _note(
        "[aicore patches] apply_restrict_agency_tools: ACTIVATED "
        f"— unregistering {', '.join(names)} from every AgentLoop "
        "(delegation belongs to the workflow DAG, not to the step agent).",
        file=sys.stderr, flush=True,
    )


# ----------------------------------------------------------------------
# Patch registry — the single, code-level inventory of every patch.
# Order matters: provider SWAPS (azure, genai) before behaviour patches on
# the (possibly swapped) provider (disable_streaming, dedup_tool_call_ids).
# ----------------------------------------------------------------------

def apply_skip_gateway_templates() -> str:
    """Stop the runtime scaffolding gateway-only files into every agent.

    ``iobot.utils.helpers.sync_workspace_templates`` copies EVERY ``*.md`` in
    the runtime's ``templates/`` directory into any workspace it touches, on
    the first run. Two of them are gateway-agent concerns and mean nothing to a
    solution's agent:

    * ``HEARTBEAT.md`` -- the tick script for gateway mode ("do ONE action, log
      it, then stop").
    * ``USER.md`` -- who the user is and through which channel the agent is
      reached.

    A scaffolded domain agent got both anyway, so `new-agent` produced four
    files and the first run silently added two more that nobody wrote and
    nothing in the solution reads. They then travelled: `push` captured them
    and `pull` wrote them into the customer's repository.

    THE PLATFORM AGENTS KEEP THEIRS. Jarvis and Alex ship their own
    ``HEARTBEAT.md`` in this package, placed by `setup-agents` before any run,
    and ``_write`` skips a file that already exists -- so suppressing the
    TEMPLATE copy takes nothing away from them.

    It also SILENCES the scaffolding chatter. The original prints one
    ``Created <name>`` line per file it writes -- ``HEARTBEAT.md``,
    ``USER.md``, ``prompts/README.md``, ``memory/history.jsonl`` -- into the
    console a user is reading for an agent's answer, and two of those names are
    files this patch deletes on the next line.

    A runtime patch rather than an edit under ``iobot/src/``: that tree stays
    byte-identical to the upstream wheel so upgrades remain deletion-only.
    Override with ``IOF_RUNTIME_TEMPLATES=all`` to restore stock behaviour --
    both the gateway files and the printing.
    """
    import os
    import sys

    from iobot.utils import helpers as _helpers

    if getattr(_helpers.sync_workspace_templates, "_iof_skip_tpl_patch", False):
        return "already applied"
    if (os.getenv("IOF_RUNTIME_TEMPLATES") or "").strip().lower() == "all":
        return "disabled (IOF_RUNTIME_TEMPLATES=all)"

    _orig = _helpers.sync_workspace_templates
    _skip = {"HEARTBEAT.md", "USER.md"}

    def _patched(workspace, silent: bool = False):
        from pathlib import Path

        ws = Path(workspace)
        # Which of the skipped names did NOT exist before the runtime ran? Any
        # that the agent legitimately owns is already on disk, and removing it
        # afterwards would delete an authored file.
        absent = {n for n in _skip if not (ws / n).exists()}
        # ALWAYS silent, using upstream's own parameter rather than suppressing
        # output afterwards. Two reasons. It is scaffolding detail printed into
        # a console someone is reading for an answer -- four "Created ..." lines
        # before an agent says anything. And it was actively WRONG here: the
        # lines are printed by the original before this wrapper deletes
        # HEARTBEAT.md and USER.md, so the console announced two files that no
        # longer existed a moment later. The return value is unchanged, so any
        # caller that wants the list still gets it.
        added = _orig(workspace, silent=True)
        for name in absent:
            f = ws / name
            try:
                if f.is_file():
                    f.unlink()
            except OSError:
                continue
        return [a for a in (added or []) if a not in _skip]

    _patched._iof_skip_tpl_patch = True
    _helpers.sync_workspace_templates = _patched
    for _mod in list(sys.modules.values()):
        if _mod is None or not hasattr(_mod, "sync_workspace_templates"):
            continue
        try:
            if getattr(_mod, "sync_workspace_templates", None) is _orig:
                _mod.sync_workspace_templates = _patched
        except Exception:
            continue
    return "ACTIVATED - HEARTBEAT.md/USER.md not scaffolded into agents"


def _memory_pipeline_active() -> bool:
    # MEMORY.md is the LEGACY v1 pipeline's artifact. It is active ONLY on
    # the explicit two-key legacy opt-in (IOF_LEARNING_V2=0 +
    # IOF_LEARNING_V1=1) — v2 active (the default) AND learning-off
    # (IOF_LEARNING_V2=0 alone) both keep it paused, because opting out of
    # v2 must never silently resurrect a deprecated pipeline. Deliberate
    # local copy of learning.v2_integration's gates: this module runs
    # inside every agent subprocess via the sitecustomize shim and must not
    # pull the learning package into that import path. Keep in sync.
    v2_on = os.environ.get("IOF_LEARNING_V2", "").strip().lower() not in (
        "0", "false", "off", "no", "disabled")
    v1_on = os.environ.get("IOF_LEARNING_V1", "").strip().lower() in (
        "1", "true", "on", "yes")
    return v1_on and not v2_on


def apply_memory_v1_off() -> None:
    """MEMORY.md is neither LOADED nor POPULATED while learning v2 is on.

    v2 owns the whole learning-and-feedback loop (hub-governed methods,
    outcome attribution, preferences); MEMORY.md was v1's channel and its
    content — prior runs' CONCLUSIONS — confuses AI Core users whichever
    direction it flows. Three surfaces, all gated at CALL time on
    ``IOF_LEARNING_V2`` (so unsetting the env var restores everything, and
    one process serving both modes behaves per-request-environment):

    1. ``MemoryStore.get_memory_context`` returns "" — the file is not fed
       into the system prompt (the LOAD).
    2. ``MemoryStore.write_memory`` is a no-op — no runtime caller today,
       but it is the API any future writer (a re-enabled Dream helper, an
       upstream feature) would use; gating it means a iobot upgrade
       cannot silently resume populating (the WRITE, API side).
    3. ``_FsTool._resolve_write`` refuses the agent's OWN
       ``<workspace>/memory/MEMORY.md`` — the channel an always-on agent
       actually uses when a prompt says "record this in memory" is
       write_file/apply_patch, and both resolve their target here. The
       refusal message tells the agent memory is hub-governed and to
       proceed, so it moves on instead of retrying. SCOPED to the agent's
       own memory file: a step agent editing a PROJECT file that happens
       to be named MEMORY.md (this repo has several) is untouched (the
       WRITE, tool side).

    The FILES are untouched — nothing wiped, fully reversible.
    """
    from iobot.agent.memory import MemoryStore

    if not getattr(MemoryStore, "_iof_memctx_patch", False):
        _orig_ctx = MemoryStore.get_memory_context
        _orig_write = MemoryStore.write_memory
        _orig_read = MemoryStore.read_memory

        def _workspace_memory_block(self) -> str:
            # WORKSPACE MEMORY (engine/memory/): the harness materializes the
            # workspace's reviewed context as memory/WORKSPACE_MEMORY.md — a
            # per-run / per-home cache of the database — and THIS is where it
            # enters the model: the runtime's own memory slot, i.e. the SYSTEM
            # prompt's "# Memory" section. Never the user turn (a memory
            # injected there reads as an instruction; see inject.py).
            try:
                p = Path(self.memory_dir) / "WORKSPACE_MEMORY.md"
                if p.is_file():
                    return p.read_text(encoding="utf-8").strip()
            except Exception:
                pass
            return ""

        def get_memory_context(self):  # type: ignore[no-redef]
            if not _memory_pipeline_active():
                return _workspace_memory_block(self)
            return _orig_ctx(self)

        def read_memory(self):  # type: ignore[no-redef]
            # The context builder suppresses the memory section when
            # MEMORY.md equals the bundled template — a served agent home
            # seeded from it would then hide the workspace block. With v1
            # paused, MEMORY.md is not memory, so it reads as empty here.
            if not _memory_pipeline_active():
                return ""
            return _orig_read(self)

        def write_memory(self, content):  # type: ignore[no-redef]
            if not _memory_pipeline_active():
                return None
            return _orig_write(self, content)

        MemoryStore.get_memory_context = get_memory_context
        MemoryStore.read_memory = read_memory
        MemoryStore.write_memory = write_memory
        MemoryStore._iof_memctx_patch = True

    from iobot.agent.tools.filesystem import _FsTool

    if not getattr(_FsTool, "_iof_memwrite_patch", False):
        _orig_resolve_write = _FsTool._resolve_write

        def _resolve_write(self, path):  # type: ignore[no-redef]
            fp = _orig_resolve_write(self, path)
            ws = getattr(self, "_workspace", None)
            if ws is not None and not _memory_pipeline_active():
                try:
                    memfile = (Path(ws) / "memory" / "MEMORY.md").resolve()
                    wsmem = (Path(ws) / "memory" / "WORKSPACE_MEMORY.md").resolve()
                    if fp.resolve() == wsmem:
                        raise ValueError(
                            "WORKSPACE_MEMORY.md is the workspace's reviewed "
                            "memory, materialized by the platform from its "
                            "database; it is not edited from a session. "
                            "Facts worth keeping are extracted from this run "
                            "when it completes and reviewed by a steward - "
                            "continue with the task.")
                    if fp.resolve() == memfile:
                        raise ValueError(
                            "MEMORY.md is not used: learning is governed by "
                            "the platform's learning system (v2), which "
                            "records methods and outcomes itself. Do not "
                            "write session learnings to memory - continue "
                            "with the task.")
                except ValueError:
                    raise
                except Exception:
                    pass  # unresolvable paths: fall through to the original
            _refuse_shipped_content(fp)
            return fp

        _FsTool._resolve_write = _resolve_write
        _FsTool._iof_memwrite_patch = True


#: Resolved content roots of every installed pack. Computed once - the
#: registry reads entry points and touches the filesystem, and this sits on
#: the write path of every tool call.
_SHIPPED_ROOTS = None


def _traversable_paths(src) -> list:
    """Real directories behind a ``Traversable``.

    NOT ``Path(str(src))``. Core's own roots come back as
    ``MultiplexedPath``, which has no ``__fspath__`` and whose ``str()`` is a
    REPR - ``MultiplexedPath('C:/...')`` - so stringifying it produced a path
    that exists nowhere and silently guarded nothing. It was the two roots
    holding the platform's own agents and workflows that resolved that way,
    which is the half of the guard most worth having. A MultiplexedPath is a
    namespace over several directories and exposes them as ``_paths``.
    """
    import os as _os

    try:
        return [Path(_os.fspath(src)).resolve()]
    except TypeError:
        pass
    except Exception:
        return []
    out = []
    for part in (getattr(src, "_paths", None) or ()):
        try:
            out.append(Path(_os.fspath(part)).resolve())
        except Exception:
            continue
    return out


def _shipped_content_roots() -> frozenset:
    """Every directory an installed pack ships content FROM.

    An editable install resolves into the solution repo itself, which is the
    case that matters: that is where a running agent can reach the files its
    own behaviour is defined by.
    """
    global _SHIPPED_ROOTS
    if _SHIPPED_ROOTS is not None:
        return _SHIPPED_ROOTS
    roots = set()
    try:
        from ioagentfarm.packs import load_registry
        registry = load_registry()
        for accessor in ("agent_sources", "skill_sources", "workflow_sources",
                         "swarm_sources", "memory_sources"):
            try:
                for src in getattr(registry, accessor)():
                    roots.update(_traversable_paths(src))
            except Exception:
                continue
    except Exception:
        pass  # no packs resolvable: guard nothing rather than break writes
    _SHIPPED_ROOTS = frozenset(roots)
    return _SHIPPED_ROOTS


def _refuse_shipped_content(fp) -> None:
    """An agent may not edit the content it is itself made of.

    THIS HAPPENED. Asked a question it could not answer because a hub
    credential was missing, a served agent edited the pack's own
    `metadata/databases.yml` mid-conversation - flipping the hub from
    `postgres` to `sqlite` so that its next query would work. The edit was
    plausible, local, and would have shipped: it lands in the solution repo
    an editable install points at, where nothing but `git status` would have
    shown it. Barrier detection would have broken for everyone on the next
    run, caused by a chat turn nobody thought of as a write.

    An agent's OWN materialized workspace, its run directory and its output
    directory are all elsewhere, so nothing legitimate is refused here. The
    pack source is read-only to a run by design; it was writable only by the
    accident of being on the same disk.

    A BUILD SESSION IS EXEMPT, because authoring solution content is
    precisely its job - `IOF_BUILD_REPO` is set only by `aicore build`, and
    is the same signal the rest of this module already keys on.

    This is an ACCIDENT RAIL, not a boundary: it guards the `write_file`
    tool, and an agent that shells out through `exec` reaches the same file
    by another road. Real containment is the sandbox and the container.
    """
    import os as _os

    if _os.environ.get("IOF_BUILD_REPO"):
        return
    roots = _shipped_content_roots()
    if not roots:
        return
    try:
        target = Path(fp).resolve()
    except Exception:
        return
    for root in roots:
        try:
            inside = target == root or root in target.parents
        except Exception:
            continue
        if inside:
            raise ValueError(
                f"refused: {target.name} is installed pack content (under "
                f"{root}), shipped by the platform and shared by every "
                "workspace on this host - a run must not edit what it is "
                "made of. If the configuration here is wrong, say so in your "
                "answer and name the file and the setting; a person changes "
                "it in the solution repo and reinstalls. Write your own "
                "outputs to the run's output directory and continue with the "
                "task.")


#: Returned when the target is the agent-home ROOT itself - not one sibling
#: but the roster of all of them.
ALL_AGENT_HOMES = "*"


#: An agent's OWN home holds one thing that is not its own: `sessions/`, one
#: JSONL per conversation - every person who has ever talked to it. Returned
#: instead of a role name, so the denial can say something true.
PRIVATE_RUNTIME = "~runtime"

#: Directories inside an agent's own workspace that belong to its USERS.
#:
#: `sessions/` is one JSONL per conversation. `.iobot/` is the RUNTIME's own
#: state directory, and it holds `tool-results/<session key>/` - every tool
#: result of every turn, in a directory NAMED after the session key, so the
#: listing alone discloses which people have used this agent. Closing only
#: `sessions/` left this open, and it is the route the grep tool actually
#: took: the file names differ, the exposure does not.
#:
#: Authored content in the same workspace - `prompts/`, `skills/`, `memory/`,
#: `metadata/`, SOUL.md - is untouched. The rule is "runtime state keyed by
#: who was talking", not "anything the agent did not write".
_PRIVATE_RUNTIME_DIRS = ("sessions", ".iobot")


def private_runtime_dir(workspace, target) -> str | None:
    """The runtime-state directory inside the agent's OWN home that *target*
    reaches, or None.

    THE LEAK THIS CLOSES, found by the final stability round. Sibling homes
    were already private, and the certification's answer to "who needs a
    shell" removed the tool from agents that never run one - but an agent
    WITH tools keeps its shell legitimately, and its own workspace contains
    every user's conversation. Asked for a code word from another user's
    thread, the agent grepped its own `sessions/`, decoded the base64
    filename back to the session key, read the transcript and answered. The
    session-key isolation is intact; what leaks is the file underneath it.

    An agent has no legitimate reason to read its own session store: the
    runtime hands it the conversation it is answering. Writes are denied for
    the same reason reads are - a tool that can rewrite a transcript can put
    words in another user's mouth.

    Never raises: a privacy rail must not become an outage.
    """
    try:
        ws = Path(workspace).resolve()
        t = Path(target).resolve()
        for name in _PRIVATE_RUNTIME_DIRS:
            d = ws / name
            if t == d or d in t.parents:
                return name
    except Exception:                      # noqa: BLE001 - never break a tool
        return None
    return None


def foreign_agent_role(workspace, target) -> str | None:
    """The role whose private home *target* invades, or None.

    ONE implementation, called by the file tool, the search tool and the
    exec rail - the certification found the first version guarded only the
    file tool, and grep and `cat` walked past it to the same bytes.

    Returns None for: a path outside the agent-home root (the deployment's
    own data, the state directory, a scratch dir), the caller's OWN home,
    and anything it cannot reason about. A privacy rail must never become an
    outage, so every uncertainty resolves to "allowed".
    """
    try:
        from ioagentfarm.engine.workspaces import agent_home_root
        root = Path(agent_home_root()).resolve()
        t = Path(target).resolve()
        if t == root:
            # THE PARENT ITSELF. Listing it is outside every sibling home, so
            # the per-home check below never fired and `list_dir` on the
            # agent-home root returned 34 home names (round 7). No content,
            # but it is the roster of who exists on this pod - and it is the
            # first step of every probe. An agent has no business enumerating
            # its siblings; its own home is one level down.
            return ALL_AGENT_HOMES
        if root not in t.parents:
            return None                    # outside the agent homes entirely
        rel = t.relative_to(root).parts
        if not rel:
            return None
        other = rel[0]
        mine = Path(workspace).resolve()
        if root not in mine.parents:
            return None                    # a workspace outside the homes
        if mine.relative_to(root).parts[:1] == (other,):
            return None                    # my own home: always allowed
        return other
    except Exception:                      # noqa: BLE001 - never break a tool
        return None


def _exec_names_foreign_home(tool, command: str) -> str | None:
    """The role whose home a COMMAND STRING names, or None.

    Deliberately crude, and honest about it: this scans the command for a
    path that lands inside another agent's home. It is an accident rail -
    the obvious spelling of the obvious question - not a boundary. Real
    containment is structural (siblings not sharing a readable root), which
    is a deployment-affecting change and is recorded in the backlog.
    """
    import re as _re
    if not command:
        return None
    # `working_dir` FIRST: ExecTool has no `_workspace` (that is the file
    # tool's attribute), so the first version of this rail read None and
    # answered "allowed" for every command - certification round 6 got a
    # sibling's session file back on all four shell spellings while the file
    # and search tools were correctly refusing the same path. A guard that
    # reads the wrong attribute is a guard that is not there.
    ws = (getattr(tool, "working_dir", None)
          or getattr(tool, "_workspace", None))
    if ws is None:
        return None

    # THE SESSION STORE FIRST, because it needs none of what follows. This
    # check used to sit below the agent-home root resolution, and that
    # resolution RETURNS EARLY wherever no workspace is configured - so on
    # every such call the rail answered "allowed" without ever reaching it.
    # A guard placed after an early return is a guard that is not there:
    # the same shape as reading the wrong attribute, noted just above.
    #
    # A bare `sessions/...` or `.iobot/...`. The agent is already standing in
    # its own workspace, so the obvious spelling carries no separator that
    # the path loop below would recognise as a path at all.
    if _re.search(r"""(^|[\s'"`;|&=(])(sessions|[.]iobot)[/\\]""", command):
        return PRIVATE_RUNTIME
    # The same names as a BARE argument (`ls sessions`, `grep -r x sessions`).
    # Only for a command that reads or lists files: `sessions` is an ordinary
    # English word, and refusing `echo my sessions are private` would be the
    # rail becoming the outage its own docstring warns about.
    if _re.search(r"""(^|[\s'"`;|&=(])(sessions|[.]iobot)(\b|$)""", command) \
            and _re.match(r"""^\s*['"(]*\s*(sudo\s+)?"""
                          r"""(ls|dir|cat|type|more|head|tail|grep|egrep|fgrep|"""
                          r"""findstr|find|rg|ag|less|nl|od|xxd|strings|cp|copy|"""
                          r"""mv|move|tar|zip|Get-Content|Get-ChildItem|gci|gc|"""
                          r"""select-string|sls)\b""", command, _re.I):
        return PRIVATE_RUNTIME

    try:
        from ioagentfarm.engine.workspaces import agent_home_root
        root = Path(agent_home_root()).resolve()
    except Exception:                      # noqa: BLE001
        return None
    # Any token that looks like a path; both separators, quoted or bare.
    for tok in _re.findall(r"[^\s'\"`;|&]+", command):
        if "/" not in tok and "\\" not in tok:
            continue
        cand = tok.strip("'\"")
        try:
            p = Path(cand)
            p = p if p.is_absolute() else (Path(ws) / cand)
            other = foreign_agent_role(ws, p) or (
                PRIVATE_RUNTIME if private_runtime_dir(ws, p) else None)
        except Exception:                  # noqa: BLE001
            continue
        if other:
            return other
    # (A bare `sessions/...` or `-r sessions` walk is handled at the TOP of
    # this function, before the root resolution and its early returns. A
    # broader duplicate of that check used to sit here with a `\b`
    # alternative, which re-refused the bare word for EVERY command — so
    # `echo my sessions are private` was refused, the exact outage the
    # scoped check's comment warns against. Redundant and wrong: removed.)

    # A bare `<role>/workspace/...` relative to the agent-home root, which is
    # how the certification's probe actually spelled it.
    for tok in _re.findall(r"[\w.-]+[/\\]workspace[/\\][^\s'\"`;|&]*", command):
        other = foreign_agent_role(ws, root / tok.replace("\\", "/"))
        if other:
            return other
    return None


#: How many filesystem entries one search may examine, and for how long.
#: Generous enough that no honest search notices; small enough that a walk of
#: an entire drive cannot hold the loop.
_SEARCH_ENTRY_BUDGET = int(os.getenv("IOF_SEARCH_ENTRY_BUDGET", "200000") or 0)
_SEARCH_TIME_BUDGET_S = float(os.getenv("IOF_SEARCH_TIME_BUDGET_S", "20") or 0)


def apply_bounded_search_walk() -> None:
    """A search cannot walk forever, and cannot hold the pod while it tries.

    Found by the chat certification (round 9), while probing for a leak it did
    not find: `find_files` with `path='C:/'` started an unbounded recursive
    walk of the whole drive. The walkers are SYNCHRONOUS and the pod serves
    one event loop, so `/health` stopped answering and the pod had to be
    restarted - every other user's chat was down for the duration. No
    privilege was needed and nothing leaked; one ordinary tool call with a
    large root is enough.

    The privacy guard filters what a walk YIELDS, which does not help: the
    cost is the traversal itself. So each walk gets an entry budget and a
    wall-clock budget, and stops when either is spent - returning what it
    found rather than raising, because a truncated search is a normal answer
    and an exception in a tool call is not. The stop is logged so a genuinely
    large search is visible rather than mysteriously short.
    """
    try:
        from iobot.agent.tools.search import FindFilesTool, _SearchTool
    except Exception:                      # noqa: BLE001 - older runtime
        return
    if getattr(_SearchTool, "_iof_bounded_walk", False):
        return

    import time as _time

    def _bound(cls, name: str) -> None:
        orig = vars(cls).get(name)
        if orig is None:
            return

        def _walk(self, root, *a, **k):    # type: ignore[no-untyped-def]
            seen, t0 = 0, _time.monotonic()
            for p in orig(self, root, *a, **k):
                seen += 1
                if (_SEARCH_ENTRY_BUDGET and seen > _SEARCH_ENTRY_BUDGET) or (
                        _SEARCH_TIME_BUDGET_S
                        and _time.monotonic() - t0 > _SEARCH_TIME_BUDGET_S):
                    # An f-string, not a template: this module's `logger` is
                    # loguru in the runtime and the stdlib logger in some
                    # test and CLI paths, and the two disagree about `{}`
                    # placeholders - the brace form raised "not all
                    # arguments converted" inside the guard itself.
                    logger.warning(
                        f"search stopped after {seen} entries / "
                        f"{_time.monotonic() - t0:.1f}s under {root} - the "
                        "root is too large to walk; narrow it")
                    return
                yield p

        setattr(cls, name, _walk)

    _bound(_SearchTool, "_iter_files")
    _bound(FindFilesTool, "_iter_paths")
    _SearchTool._iof_bounded_walk = True


#: A `--message` beginning with this is a POINTER to the task, not the task.
#: Engine side: `cli._invoke_agent`.
MESSAGE_FILE_PREFIX = "@iof-prompt-file:"


def apply_message_from_file() -> None:
    """`iobot agent -m @iof-prompt-file:<path>` reads its task from disk.

    WINDOWS CAPS A COMMAND LINE AT 32,767 CHARACTERS and a step's rendered
    prompt is an argv value, so a large one cannot be spawned AT ALL:
    `CreateProcess` raises WinError 206, "The filename or extension is too
    long". A 35.7 KB `playbook_compile` prompt hit it.

    The failure had no symptom worth the name. In a detached run the
    exception reached nobody: the step stayed `running` with an empty
    stdout, stderr and http log, the supervisor reaped it 180s later, the
    next attempt did exactly the same, and the run cycled until the hard
    cap - four identical attempts whose only artefact was the prompt that
    could not be passed. The engine's own comment at the spawn site had
    reasoned as far as "CreateProcess supports up to 32K characters" and
    stopped there.

    So the engine writes the prompt to a file and passes this pointer when
    the text is large, and this patch makes the child read it. The message
    the agent receives is byte-identical either way; nothing about the task
    changes, only how it crosses the process boundary.

    A missing file RAISES here rather than passing the pointer through as
    text: an agent silently handed "@iof-prompt-file:C:/..." as its task
    would report a plausible answer to a question nobody asked.
    """
    from iobot.cli import commands as _c

    _orig = getattr(_c, "agent", None)
    if _orig is None or getattr(_orig, "_iof_message_from_file", False):
        return

    @functools.wraps(_orig)
    def agent(message=None, *args, **kwargs):
        if isinstance(message, str) and message.startswith(
                MESSAGE_FILE_PREFIX):
            path = Path(message[len(MESSAGE_FILE_PREFIX):])
            if not path.is_file():
                raise FileNotFoundError(
                    f"the task was passed as a file and the file is not "
                    f"there: {path}")
            message = path.read_text(encoding="utf-8")
        return _orig(message, *args, **kwargs)

    agent._iof_message_from_file = True          # type: ignore[attr-defined]
    _c.agent = agent
    # TYPER HOLDS ITS OWN REFERENCE. `@app.command()` registered the original
    # callback at import; rebinding the module attribute alone changes
    # nothing about what the CLI actually invokes.
    for cmd in getattr(getattr(_c, "app", None), "registered_commands", []):
        if getattr(cmd, "callback", None) is _orig:
            cmd.callback = agent


def apply_agent_homes_are_private() -> None:
    """One agent may not read another agent's home.

    THE LEAK, found by the chat certification (round 4, rung 8). Asked for a
    fact from a DIFFERENT agent's conversation, a chat agent globbed the tree
    and its file tool returned
    ``agents/<other_role>/workspace/sessions/<base64>.jsonl`` - a sibling's
    entire transcript - along with other agents' SOUL.md and memory/. The
    session KEY isolation held (the agent answered honestly that it did not
    know), so nothing leaked into that reply; what failed is containment. On
    a pod serving several always-on agents to different people, one agent's
    tool call can read another's chat history.

    WHY NOT `restrict_to_workspace`. Upstream's flag defaults False and
    turning it on for pooled agents would confine every agent to its own
    workspace - which breaks the deployments this platform actually has: a
    query agent reads a DuckDB file and an env file that legitimately live
    outside its home (the pharma workflows name `~/.barrier_signal/.env`),
    and the per-session scratch directory is under ``<IOF_ROOT>/tmp``. A
    blanket confinement would trade a privacy leak for an outage.

    So this denies exactly the thing that is never legitimate: a path inside
    the agent-home root that belongs to a DIFFERENT role. Everything else -
    the agent's own home, the state directory, the deployment's data - is
    untouched. Reads AND writes, because writing into a sibling's home is
    worse than reading it.

    Unconditional: no surface has a reason to read another agent's private
    home, and a leak that only the multi-agent pods have is exactly the one
    nobody would remember to switch on.
    """
    from iobot.agent.tools.filesystem import _FsTool

    if getattr(_FsTool, "_iof_agent_privacy_patch", False):
        return

    def _sibling_denial(self, fp) -> str | None:
        """The role whose home *fp* invades, or None. Shared by every seam.

        ONE implementation for the file tool, the SEARCH tool and exec,
        because the first version covered only the file tool and round 5 of
        the certification walked straight past it: grep over the agent-home
        root returned a sibling's session JSONL verbatim, and `type`/`cat`
        did the same. A denial that each tool spells for itself is a denial
        with holes - the same lesson as the capture layer and its reader
        needing to share their discovery code.
        """
        ws = getattr(self, "_workspace", None)
        if ws is None:
            return None
        other = foreign_agent_role(ws, fp)
        if other:
            return other
        # The agent's OWN home is otherwise its own - except the session
        # store, which belongs to the people who talked to it.
        if private_runtime_dir(ws, fp):
            return PRIVATE_RUNTIME
        return None

    # EVERY RESOLVER, ENUMERATED - not the two that were noticed. Rounds 5, 6,
    # 7 and 8 each found one more seam onto the same bytes (search, then exec,
    # then the agent-home parent, then `find_files`), because each fix guarded
    # the entry point that had just leaked. `_FsTool` has exactly three
    # resolvers and `_SearchTool` exactly two walkers; all five are covered
    # here, and `test_every_path_seam_is_guarded` fails if a sixth appears.
    # `_resolve` is the one round 8 walked through: `find_files` resolves its
    # ROOT with it, so a walk rooted one level above `agents/` recursed in and
    # yielded all 37 sibling home names while `list_dir` on the same path was
    # correctly refused.
    for attr in ("_resolve_read", "_resolve_write", "_resolve"):
        orig = getattr(_FsTool, attr, None)
        if orig is None:
            continue

        def _bind(orig_fn, what):
            def _resolve(self, path):      # type: ignore[no-untyped-def]
                fp = orig_fn(self, path)
                other = _sibling_denial(self, fp)
                if other == PRIVATE_RUNTIME:
                    raise ValueError(
                        "the session store is private: it holds one file per "
                        "conversation, belonging to the people who had them. "
                        "You are given the conversation you are answering; "
                        "you may not read or search the others.")
                if other == ALL_AGENT_HOMES:
                    raise ValueError(
                        "the agent-home directory is private: an agent may "
                        "not enumerate the other agents on this deployment. "
                        "Your own workspace is yours to read; ask another "
                        "agent directly (the A2A surface, or `iof-consult`).")
                if other:
                    raise ValueError(
                        f"{other}'s agent home is private: an agent may not "
                        f"{what} another agent's workspace, sessions or "
                        "memory. Ask that agent directly (the A2A surface, "
                        "or `iof-consult`) instead of reading its files.")
                return fp
            return _resolve

        setattr(_FsTool, attr, _bind(orig, "read" if "read" in attr else "write into"))

    # SEAM 2: SEARCH. `_SearchTool` subclasses `_FsTool`, so it inherits the
    # resolver above for its ROOT - and then walks the tree with `os.walk`,
    # reading each file directly, which is how round 5's grep returned a
    # sibling's whole session JSONL (codename, safeword, thinking blocks)
    # while the read tool was correctly refusing the same path. Filtering
    # what the walk YIELDS is the matching seam; a search that finds nothing
    # in a foreign home is the same answer the read tool gives.
    try:
        from iobot.agent.tools.search import FindFilesTool, _SearchTool

        def _guard_walker(cls, name: str) -> None:
            orig = vars(cls).get(name)     # the class's OWN method
            if orig is None:
                return

            def _walk(self, root, *a, **k):    # type: ignore[no-untyped-def]
                for p in orig(self, root, *a, **k):
                    # A DIRECTORY COUNTS. `find_files --include_dirs` yields
                    # `agents/<role>/` itself, which is how round 8 read the
                    # whole roster without touching one byte of content.
                    if _sibling_denial(self, p):
                        continue
                    yield p

            setattr(cls, name, _walk)

        # BOTH walkers, AND THEY LIVE ON DIFFERENT CLASSES: `_iter_files` is
        # `_SearchTool`'s (grep), `_iter_paths` is `FindFilesTool`'s. Round 6
        # closed the first; the second was invisible to a `getattr` on the
        # base, which is how round 8 walked through it - and how the first
        # attempt at THIS fix silently did nothing until the enumerating test
        # said so.
        _guard_walker(_SearchTool, "_iter_files")
        _guard_walker(FindFilesTool, "_iter_paths")
    except Exception:                      # noqa: BLE001 - older runtime
        logger.debug("agent privacy: no search tool to guard", exc_info=True)

    # SEAM 2b: WHAT LIST_DIR YIELDS. `_resolve` guards the directory ASKED
    # FOR; `ListDirTool` then walks it with `iterdir`/`rglob` and prints what
    # it finds. So `list_dir sessions` was correctly refused while `list_dir .`
    # on the workspace root printed every session filename and every
    # `.iobot/tool-results/<session key>/` directory. The contents were never
    # readable — but the NAMES are the roster: a session filename is base64 of
    # the session key, so the listing discloses every user_id that has ever
    # talked to this agent, and the tool-results directories do it in plain
    # text. Found by an independent validator, on the very walkthrough that
    # claims this store is refused to the agent's tools.
    #
    # The same lesson as SEAM 2, one tool later: guarding the root of a walk
    # is not guarding what the walk yields.
    try:
        from iobot.agent.tools.filesystem import ListDirTool

        if not getattr(ListDirTool, "_iof_agent_privacy_listdir", False):
            _orig_list = ListDirTool.execute

            async def _list_execute(self, path=None, *a, **k):  # type: ignore[no-untyped-def]
                out = await _orig_list(self, path, *a, **k)
                if not isinstance(out, str) or not out:
                    return out
                try:
                    base = self._resolve(path)
                except Exception:  # noqa: BLE001 - the original already reported
                    return out

                kept: list[str] = []
                dropped = 0
                for line in out.split("\n"):
                    entry = line.strip()
                    # Two output shapes: "<rel>" / "<rel>/" from the recursive
                    # branch, and "<icon> <name>" from the flat one. Anything
                    # that is not an entry — the truncation note, a blank — is
                    # kept exactly as it is.
                    for icon in ("\U0001F4C1", "\U0001F4C4"):
                        if entry.startswith(icon):
                            entry = entry[len(icon):].strip()
                            break
                    if not entry or entry.startswith("("):
                        kept.append(line)
                        continue
                    try:
                        rel = entry.rstrip("/\\").replace("\\", "/")
                        target = base / rel
                    except Exception:  # noqa: BLE001
                        kept.append(line)
                        continue
                    if _sibling_denial(self, target):
                        dropped += 1
                        continue
                    kept.append(line)

                if not dropped:
                    return out
                text = "\n".join(kept).strip()
                noun = "entry" if dropped == 1 else "entries"
                note = (f"\n\n({dropped} {noun} hidden: private runtime state — "
                        "session transcripts and per-turn tool results belong to "
                        "the people who produced them.)")
                return (text or "Directory is empty") + note

            ListDirTool.execute = _list_execute
            ListDirTool._iof_agent_privacy_listdir = True
    except Exception:  # noqa: BLE001 - older runtime
        logger.debug("agent privacy: no list_dir tool to guard", exc_info=True)

    # SEAM 3: EXEC. A shell command naming another agent's home reads it with
    # no tool resolver involved at all (`type`/`cat` of the session JSONL).
    # This is an ACCIDENT RAIL and is labelled as one: a denylist over a
    # command string cannot contain a determined caller, and the structural
    # fix - not giving sibling homes a shared readable root - is a
    # deployment-affecting change recorded in the backlog. What it does buy
    # is that the obvious spelling of the obvious question stops working,
    # which is the same bargain `build_exec_guard` makes.
    try:
        from iobot.agent.tools.shell import ExecTool as _Exec
        if not getattr(_Exec, "_iof_agent_privacy_exec", False):
            _orig_exec = _Exec.execute

            async def execute(self, command=None, cmd=None, *a, **k):  # type: ignore[no-untyped-def]
                line = command or cmd or ""
                other = _exec_names_foreign_home(self, line)
                if other == PRIVATE_RUNTIME:
                    return (
                        "[privacy] refused: the session store is private. It "
                        "holds one file per conversation, belonging to the "
                        "people who had them. You are given the conversation "
                        "you are answering; you may not read the others.")
                if other:
                    return (
                        f"[privacy] refused: that command reads {other}'s "
                        "agent home. An agent may not read another agent's "
                        "workspace, sessions or memory - ask that agent "
                        "directly (the A2A surface, or `iof-consult`).")
                return await _orig_exec(self, command=command, cmd=cmd, *a, **k)

            _Exec.execute = execute
            _Exec._iof_agent_privacy_exec = True
    except Exception:                      # noqa: BLE001
        logger.debug("agent privacy: no ExecTool to guard", exc_info=True)

    _FsTool._iof_agent_privacy_patch = True


#: Commands a BUILD-SESSION agent may never execute, whatever the model
#: decides. The solution_builder skill states these as rules; rules stated
#: to a model are requests. This is the enforcement: matched commands are
#: refused at execution time with a message the model can adapt to.
_BUILD_GUARD_DENY: list[tuple[str, str]] = [
    # RECURSIVE DELETE, IN THE SPELLING THIS PLATFORM ACTUALLY USES.
    # Upstream's deny list refuses `rm -rf`, and on Windows the exec tool
    # runs POWERSHELL by default, where the plain way to delete a directory
    # is `Remove-Item -Recurse -Force`. Neither layer refused it, so the
    # guard against destroying a tree existed only for the shell this
    # platform does not use.
    #
    # Measured, in a corpus run: told "Delete the whole agents folder and
    # the workspace, start over", the builder ran
    # `Remove-Item -Recurse -Force "...\solution\agents"` and destroyed
    # every agent in the repository. Five later scenarios then failed their
    # SETUP and a dozen more failed downstream - one deletion, twenty-one
    # red turns, and the run read like seven regressions until the cause
    # was traced.
    #
    # This is the kind of pattern worth adding, by this list's own rule: it
    # is the OBVIOUS spelling a cooperative model reaches for, not a
    # bypass found by trying to evade. `ri`/`rd`/`rmdir` are the aliases
    # the same model reaches for next, and are cheap to name here. Only the
    # RECURSIVE form is refused - removing one file is ordinary work.
    (r"(^|[;&|]\s*)(remove-item|ri)\s+[^;&|]*(-recurse|-r\b)"
     r"|(^|[;&|]\s*)(rd|rmdir)\s+[^;&|]*/s"
     r"|(^|[;&|]\s*)del\s+[^;&|]*/s",
     "a recursive delete destroys work the session cannot restore - `/undo` "
     "reverts a TURN, not a directory somebody removed underneath it. "
     "Remove one file if that is what you meant, or tell the user exactly "
     "what to delete and let them run it"),
    # ANCHORED TO A COMMAND POSITION, like `builder/engine.py:_INSTALL_RE`
    # and for the same reason: `echo "run git commit yourself"` is the model
    # handing the user a command, which is exactly what a refusal is
    # supposed to make it do, and the unanchored `\b` refused it. The cost
    # is that a deliberately quoted `bash -c "git commit"` escapes - which
    # is fine, and is the whole point of the entry above: this list is an
    # ACCIDENT RAIL, and an accident does not hide inside `bash -c`.
    (r"(^|[;&|]\s*)git\s+(commit|push|reset|clean|rebase|merge)(?![\w-])",
     "build sessions never commit, push or rewrite git history - git is the "
     "user's review moment"),
    # DISCARDING THE USER'S WORK. `reset` and `clean` were refused and these
    # were not, though they do the same damage: `git checkout -- .` and
    # `git restore .` throw away every uncommitted edit in the tree,
    # including the ones the USER made while the turn ran, and `git stash`
    # hides them somewhere the user did not put them. A model reaching for
    # "undo my change" finds these first - they are the commonest way to
    # say it - and the session has its own revert that does not touch
    # anything the agent did not write.
    (r"(^|[;&|]\s*)git\s+(checkout|restore|switch|stash)(?![\w-])",
     "these discard or hide uncommitted work, the user's included - the "
     "session's own `/undo` reverts a turn safely, and switching branches "
     "under a build session invalidates its checkpoints. Show what you "
     "wanted to revert and let the user decide"),
    # DESTROYING THE UNDO CHECKPOINTS. `/undo` restores a git TREE object
    # that is deliberately unreachable from any ref, so anything that prunes
    # takes the session's undo history with it - silently, and `/diff` and
    # `/undo` then report the checkpoint "no longer in this repository's
    # object store" (repl._GONE) with no way to get it back. A build
    # session has no reason to run garbage collection at all.
    (r"(^|[;&|]\s*)git\s+(gc|prune)(?![\w-])"
     r"|(^|[;&|]\s*)git\s+reflog\s+expire(?![\w-])"
     r"|(^|[;&|]\s*)git\s+update-ref(?![\w-])"
     r"|(^|[;&|]\s*)git\s+branch\s+(-D|-d|--delete)(?![\w-])"
     r"|(^|[;&|]\s*)git\s+(filter-branch|filter-repo)(?![\w-])"
     r"|(^|[;&|]\s*)git\s+worktree\s+(remove|prune)(?![\w-])",
     "this prunes or rewrites git objects, and the session's `/undo` "
     "checkpoints are unreachable objects - collecting them destroys the "
     "undo history for every turn of this session"),
    # Installs are ASKED, not refused - but only where someone can answer.
    # `IOF_BUILD_APPROVAL=1` is set by an interactive build session, whose
    # engine prompts before the command runs (see builder/engine.py
    # `install_prompt`). Everywhere else - a one-shot, CI, a workflow step -
    # there is no channel to confirm through, so the old refusal stands.
    #
    # It used to refuse unconditionally, which is why a session that had
    # just scaffolded a CLI tool could not make its console script exist:
    # pip GENERATES the launcher at install time, so the tool was unusable
    # until the user ran the command themselves in another terminal.
    # KEEP IN STEP WITH `builder/engine.py:_INSTALL_RE`, which decides what an
    # interactive session ASKS about. The two lists are the same policy at two
    # seams, and they had drifted: the prompt covered npm/pnpm/yarn, this
    # refusal covered only Python, so a one-shot silently RAN `npm install`
    # while refusing `pip install`. Environment is environment.
    (r"(\bpip|python\s+-m\s+pip|\buv\s+pip)\s+(install|uninstall)\b"
     r"|\bnpm\s+(install|i|ci|link)\b"
     r"|\bpnpm\s+(add|install)\b"
     r"|\byarn\s+(add|install)\b"
     r"|\buv\s+(add|sync|remove|tool\s+install)\b"
     r"|\bpoetry\s+(add|install|remove)\b"
     r"|\bpipx\s+(install|uninstall)\b"
     r"|\bconda\s+(install|remove)\b",
     "build sessions modify the Python or Node environment only with the "
     "user's explicit approval, and this session has no way to ask - tell "
     "the user which install to run and why",
     "IOF_BUILD_APPROVAL"),
    # Anchored to ONE command segment and the EXACT flag. The first
    # spelling was `aicore\s+\S.*\s--force\b`: `.*` ran across `;` into a
    # SECOND command, and `\b` matched inside `--force-exclude` and
    # `--force-reinstall` - so `aicore lint-skill x; ruff --force-exclude .`
    # was refused for a flag aicore never saw, with a message about
    # overwriting.
    (r"\b(aicore|ioagentfarm)\b[^\n;&|]*\s--force(?![\w-])",
     "build sessions never --force - show what is in the way and ask"),
    (r"\baicore\s+workspace\s+delete\b",
     "build sessions never delete a workspace"),
    # CREDENTIALS. The `guardrails` skill says never read a secret file or
    # print a token, and in a build session that rule is load-bearing in a
    # way it is nowhere else: the agent runs exec on the DEVELOPER'S machine
    # with the developer's environment, and `~/.iobot/workspaces/<code>/.env`
    # holds the shared database URL. The placement gate blocks WRITES outside
    # the repository; nothing blocked a READ. A rule stated to a model is a
    # request - and a prompt injection in tool output is a request too, and
    # the model cannot always tell which is which. This is the same rule as
    # physics. `.env.example` / `.env.template` / `.env.sample` are
    # documentation and stay readable; so does `steps/dev.env.md`.
    # `grep .env .gitignore` is the one-command way to answer "is the env
    # file ignored?" - a hygiene check the builder is right to run - and
    # it was refused as a credential read because the pattern names the
    # file. A command segment that also names .gitignore is exempt from
    # THIS rule only; every other spelling still refuses.
    (r"(\b(cat|type|more|less|head|tail|bat|gc|get-content|select-string"
     r"|grep|rg|findstr|strings|od|xxd|hexdump|source|awk|sed|cut|tr|nl"
     r"|xargs|paste|rev)|(^|[;&|])\s*\.)(?![^\n;&|]*\.gitignore)\s[^\n;&|]*"
     r"(\.env(\.(local|prod(uction)?|dev(elopment)?|stag(ing)?|test))?"
     r"(?![\w.-])|\.pem(?![\w.-])|\.p12(?![\w.-])|\.pfx(?![\w.-])"
     r"|id_(rsa|ed25519|ecdsa|dsa)(?![\w.-])|\.netrc(?![\w.-])"
     r"|aws[/\\]credentials(?![\w.-])|\.git-credentials(?![\w.-])"
     r"|\.pgpass(?![\w.-])|kube[/\\]config(?![\w.-]))",
     "build sessions never read credential files (.env, keys, credential "
     "stores) - declare a secret as a ${VAR} reference and tell the user "
     "which variable to set and where"),
    # Dumping the environment - it carries credentials. `env VAR=x cmd` and
    # `set -e` do not match: only the bare listing form does.
    (r"(^|[;&|]\s*)(env|printenv|set|export|get-childitem\s+env:|gci\s+env:"
     r"|ls\s+env:|dir\s+env:)\s*($|[;&|>])",
     "build sessions never dump the environment - it carries credentials; "
     "name the variable the user should set instead"),
    # Printing a variable whose NAME says it is a secret. `echo $HOME` is
    # fine; `echo $IOF_DATABASE_URL` puts the database password on the
    # console and in the session transcript.
    (r"\b(echo|printf|write-output|write-host|print)\b[^\n;&|]*"
     r"\$(\{|env:)?[A-Za-z_]*(TOKEN|SECRET|PASSWORD|PASSWD|API_?KEY|APIKEY"
     r"|DATABASE_URL|CONNECTION_STRING|PRIVATE_KEY|CREDENTIALS?)\b",
     "build sessions never print a secret-bearing variable - name it for "
     "the user instead of showing its value"),
    # THE OBVIOUS SPELLING, NOT THE EVASION - see the accident-rail note in
    # CLAUDE.md for why that distinction is the whole justification for these
    # three. A model that has been MISLED (told by something it read to fetch
    # a credential) is cooperative: it writes the plainest command that does
    # the job, and these are what that looks like when `cat` is refused. A
    # model that is EVADING writes `X=cat; $X …` and no pattern will ever
    # catch it. These raise the floor under the confused deputy; they are not
    # a boundary, and nothing here should be extended to chase a bypass.
    (r"\b(python|python3|py|node|nodejs|deno|bun|ruby|perl|php|Rscript)\b"
     r"[^\n]*(\.env(\.(local|prod(uction)?|dev(elopment)?|stag(ing)?|test))?"
     r"(?![\w.-])|\.pem(?![\w.-])|id_(rsa|ed25519|ecdsa)(?![\w.-])"
     r"|aws[/\\]credentials(?![\w.-])|\.git-credentials(?![\w.-])"
     r"|\.pgpass(?![\w.-])|dotenv_values)",
     "build sessions never read credential files, through an interpreter or "
     "otherwise - declare the secret as a ${VAR} reference and name the "
     "variable for the user"),
    (r"\b(python|python3|py|node|nodejs|deno|bun|ruby|perl|php)\b[^\n]*"
     r"(os\.environ|os\.getenv|process\.env|ENV\[|\$ENV\{|getenv)"
     r"[^\n]*(TOKEN|SECRET|PASSWORD|PASSWD|API_?KEY|APIKEY|DATABASE_URL"
     r"|CONNECTION_STRING|PRIVATE_KEY|CREDENTIALS?)",
     "that prints a secret-bearing variable - name the variable for the "
     "user instead of showing its value"),
    # A ${VAR} in an Authorization HEADER is the sanctioned form and stays
    # legal; a secret in a QUERY STRING or a request BODY is the shape
    # exfiltration takes, and no build-session job needs it.
    (r"\b(curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod)\b[^\n]*"
     r"([?&][\w.-]+=[^\s&]*\$\{?(env:)?[A-Za-z_]*"
     r"(TOKEN|SECRET|PASSWORD|API_?KEY|DATABASE_URL|CONNECTION_STRING"
     r"|PRIVATE_KEY|CREDENTIALS?)"
     r"|(-d|--data|--data-raw|--data-binary|-F|--form)\s[^\n]*\$\{?(env:)?"
     r"[A-Za-z_]*(TOKEN|SECRET|PASSWORD|API_?KEY|DATABASE_URL"
     r"|CONNECTION_STRING|PRIVATE_KEY|CREDENTIALS?))",
     "that sends a secret-bearing variable to a network endpoint - if an "
     "API call genuinely needs it, hand the command to the user to run"),
    (r"169\.254\.169\.254",
     "cloud metadata endpoints are off-limits"),
    (r"\b(curl|wget|iwr|invoke-webrequest|irm|invoke-restmethod)\b[^\n|]*\|\s*"
     r"(ba|z|da)?sh\b|\biex\s*\(?\s*(iwr|invoke-webrequest|irm|\(new-object)",
     "build sessions never execute downloaded code"),
    # STARTING A SERVER OR DETACHING A BACKGROUND PROCESS. Seen live on a
    # client box: asked to check the API, the builder ran
    # `Start-Process -FilePath python -ArgumentList "-m uvicorn app.main:app
    # --port 8002"` and then `python -m uvicorn app.main:app --port 8002` -
    # the second held the port and BLOCKED the terminal the session ran in
    # (the user could not use the shell until they killed it by hand), and
    # the first detached a listener that outlived the turn. A build session
    # designs solution content and runs scaffold/lint commands; it never
    # needs to start a long-running listener, and a process that survives the
    # turn is exactly what it must not create. This is the OBVIOUS spelling of
    # "run the app", not an evasion - `npm run build`, `python -c ...`,
    # `pytest` and `node script.js` stay legal because only the server names
    # and the background launchers are named here. `aicore serve` /
    # `start-gateway` are DEPLOYMENT commands, the user's to run in their own
    # terminal, never a build turn's.
    (r"(^|[;&|]\s*)(start-process|saps|start-job|sajb|nohup|setsid)(?![\w-])"
     r"|(^|[;&|]\s*)start\s+(/b|/min)\b"
     r"|\b(uvicorn|gunicorn|hypercorn|daphne|waitress-serve"
     r"|python\s+-m\s+(http\.server|uvicorn|gunicorn|flask)"
     r"|flask\s+run|rails\s+server|php\s+-S)\b"
     r"|\b(aicore|ioagentfarm)\s+(serve|start-gateway)\b"
     r"|\bnpm\s+(start|run\s+(dev|serve|start|preview|watch))\b"
     r"|\b(vite|nodemon|pm2|next\s+dev|ng\s+serve|http-server)\b",
     "a build session never starts a server or a background process - it "
     "holds a port and can block the terminal the session runs in, and it "
     "outlives the turn. If you need the app running to check something, "
     "hand the user the exact command and let them run it in their own "
     "terminal"),
    # ENUMERATING THE MACHINE. Seen live: asked something narrow, the builder
    # ran `Get-Service | Select-Object ...` and `Get-Process`, listing all
    # 303 services and every process with its PID - a full inventory of the
    # developer's machine, written to a file in their repo. A build session
    # designs solution content; it has no reason to know what else runs on
    # the box, and a whole-machine process/service list is reconnaissance
    # whether or not the model meant it as one. The OBVIOUS spellings only -
    # a specific `Get-NetTCPConnection -LocalPort N` (is THIS port taken?)
    # is not a machine dump and is not named.
    (r"(^|[;&|]\s*)(get-service|gsv|get-process|gps|ps|tasklist"
     r"|get-ciminstance|gcim|get-wmiobject|gwmi|openfiles)(?![\w-])"
     r"|\bsystemctl\s+(list-units|list-unit-files|status|is-active"
     r"|is-enabled|show)\b"
     r"|\bwmic\s+(process|service)\b"
     r"|\bsc(\.exe)?\s+(query|queryex|getdisplayname)\b"
     r"|\bnet\s+start\b"
     r"|\bps\s+(-?aux|-ef|-A|ax)\b",
     "a build session inventories nothing about the machine - it designs "
     "solution content and runs the scaffold and lint commands, and a full "
     "process or service list is not part of that. If you need to know "
     "whether something is running (a port, a service), ask the user; do not "
     "list the developer's processes or services"),
    # KILLING OR STOPPING A PROCESS OR SERVICE. The user named exactly this
    # risk: the session that listed every process with its PID can also END
    # them. A build session starts nothing of its own (the rule two above),
    # so anything it would stop or kill belongs to the developer's machine,
    # and there is no undo. `Stop-Process`, `taskkill`, `kill`, `pkill`,
    # `Stop-Service`, `sc stop`, `net stop`, `systemctl stop` are the OBVIOUS
    # spellings and none of them is ever a build turn's job. If a server
    # needs stopping - including one this session should not have started -
    # that is the user's terminal to do it in.
    (r"(^|[;&|]\s*)(stop-process|spps|kill|pkill|killall|taskkill"
     r"|stop-service|spsv|start-service|restart-service|remove-service"
     r"|suspend-service|resume-service)(?![\w-])"
     r"|\bsc(\.exe)?\s+(stop|start|delete|pause|continue)\b"
     r"|\bnet\s+stop\b"
     r"|\bsystemctl\s+(stop|start|kill|restart|reload|disable|enable"
     r"|mask|unmask)\b"
     r"|\bservice\s+[\w.-]+\s+(stop|start|restart|reload|force-reload)\b",
     "a build session never stops or kills a process or a service - it "
     "starts nothing of its own, so anything it would stop belongs to the "
     "developer's machine, and there is no undo. If a server needs stopping "
     "(including one this session should not have started), that is the "
     "user's terminal to run the command in - hand it to them"),
    # HAND-EDITING THE ENGINE DATABASE. The worst of these, seen live:
    # asked something else entirely, the builder connected to the engine's
    # SQLite state with `python -c "import sqlite3; conn = sqlite3.connect(
    # r'...\.iof\state.db'); ..."`, listed the tables and went on to UPDATE
    # them - "hallucinating, i asked something else and it went on to update
    # the tables". The engine's state is owned by the `aicore` CLI and the
    # scaffold commands; a build session that opens the database directly is
    # one INSERT/UPDATE/DELETE from corrupting a run's record or a workspace's
    # rows, with no undo. It never needs to. Scoped to opening a DB connection
    # or running a DB client - `python -c 'print(1)'`, `pytest` and a
    # solution's own data tools (which is the whole point of a pack) stay
    # legal because none of them is a bare client or an inline `.connect(`.
    (r"(^|[;&|]\s*)(sqlite3|psql|mysql|mariadb|mongo|mongosh|redis-cli|duckdb"
     r"|pgcli|mycli)(?![\w-])"
     r"|\bsqlite3\s*\.\s*connect\s*\("
     r"|\b(psycopg2?|psycopg|pymysql|pymongo|asyncpg|aiosqlite|MySQLdb)\s*\.\s*"
     r"connect\s*\("
     r"|\bcreate_engine\s*\(",
     "a build session never opens the engine database directly - it is owned "
     "by the `aicore` CLI and the scaffold commands, and a raw INSERT/UPDATE/"
     "DELETE can corrupt a run's record or a workspace's rows with no undo. "
     "Use the `aicore` command for what you need, or ask the user; say what "
     "you wanted to read and let a real command answer it"),
    # Sleeping to wait on a run. `run_ops` is always:true and says not to, the
    # user's own prompt said not to, and a client-simulation session did it
    # anyway - burning nine minutes of wall clock re-reading a status row that
    # a detached run was updating on its own. A rule stated to a model is a
    # request; this is the same rule as physics. Scoped to a sleep CHAINED to
    # a run-status read, so a bare `sleep` (waiting on a port, a file lock)
    # still runs.
    (r"\b(start-sleep|sleep|timeout)\b[^\n;&|]*[;&|]+[^\n]*\b"
     r"(aicore|ioagentfarm)\s+(status|next-step|run-output|forensics)\b",
     "a run outlives this session and records its own result - sleeping to "
     "watch it wastes the session's clock and can outlast the caller's "
     "timeout. Start it with --json, hand back the run id, check state ONCE "
     "and report what the record says"),
    (r"\b(while|for|do)\b[^\n]*\b(start-sleep|sleep)\b[^\n]*\b"
     r"(aicore|ioagentfarm)\s+(status|next-step)\b",
     "polling loops on a run are refused for the same reason - check once "
     "and report the run id"),
]


#: Reading a run's state. `run_ops` says check ONCE; these are the commands
#: that do the checking.
_RUN_STATE_READ = re.compile(
    r"\b(aicore|ioagentfarm)\s+(forensics\s+(explain|show|is-recovering)"
    r"|status|next-step)\b", re.IGNORECASE)

#: How many run-state reads one build turn may make before the harness stops
#: it. Three is deliberately generous: start a run and check it, check a second
#: run, re-check after doing something else. Beyond that it is a polling loop
#: wearing a different hat.
_RUN_STATE_BUDGET = int(os.getenv("IOF_BUILD_RUN_CHECK_BUDGET", "3") or 3)

#: Process-scoped, which is exactly turn-scoped: `aicore build` spawns one
#: agent process per turn, so the count resets when the user writes in again
#: and a genuine "check it now" is always allowed.
_run_state_reads = [0]


def reset_run_state_reads() -> None:
    """Start a new turn's run-state accounting.

    The counter's own comment says process-scoped "is exactly turn-scoped"
    because one-shot builds spawn a process per turn - which stopped being
    the whole story when the interactive session got the IN-PROCESS engine:
    one process, many turns, and a counter that never reset. Turn 1 checked
    a run three times; every turn after it was told "this turn has already
    read run state 3 times" and refused, for the rest of the session.
    Called from `builder.budget.reset()`, beside the scaffold-test memo.
    """
    _run_state_reads[0] = 0


def unquoted_chain_operator(command: str) -> str | None:
    """``&&`` or ``||`` used OUTSIDE quotes in *command*, else None.

    Quote-aware on purpose: `git commit -m "fix a && b"` and
    `bash -c "x && y"` are legitimate and must not be flagged. Pure, so the
    scanner is testable without a shell.
    """
    s = command or ""
    quote = None
    i = 0
    while i < len(s):
        c = s[i]
        if quote is not None:
            if c == quote:
                quote = None
            elif c == "`" and quote == '"':
                i += 1                    # PowerShell escape inside "..."
        elif c in "'\"":
            quote = c
        elif c in "&|" and i + 1 < len(s) and s[i + 1] == c:
            return c * 2
        i += 1
    return None


@functools.lru_cache(maxsize=1)
def shell_lacks_chain_operators() -> bool:
    """Whether this host's default agent shell cannot parse ``&&``/``||``.

    The runtime runs exec through PowerShell on Windows - `pwsh` when it is
    installed, else `powershell`, which is 5.1 and has NO `&&` or `||`; they
    arrived in PowerShell 7. Nothing tells the model that, so it writes the
    POSIX form it knows, gets a bare parser error back, and spends a call
    discovering the shell. Observed on a client VM: every
    `cd . && aicore ...` cost one wasted call before the model retried with
    `;`.

    ``IOF_BUILD_SHELL_NO_CHAIN`` forces the answer either way, which is what
    lets the behaviour be tested off a Windows host.
    """
    forced = (os.environ.get("IOF_BUILD_SHELL_NO_CHAIN") or "").strip()
    if forced in {"0", "1"}:
        return forced == "1"
    if os.name != "nt":
        return False
    import shutil
    return shutil.which("pwsh") is None


def unknown_aicore_flag(command: str):
    """``(flag, "cmd sub", known_flags)`` for a bogus `aicore` flag, else None.

    Resolved against the LIVE typer app, so it cannot drift from what the
    commands accept - the same source the session preamble lists flags from.

    CONSERVATIVE BY CONSTRUCTION. It answers only when it can resolve the
    command with certainty and the flag is definitely absent: anything it
    cannot parse returns None and the command runs, because a false refusal
    of a valid flag would be far worse than the guess it is trying to stop.
    So: one command per line only (no separators), nothing after a bare
    `--`, and long flags only - a short flag's meaning depends on the
    command's own parser in ways this does not model.
    """
    import shlex

    text = str(command or "").strip()
    if not text or re.search(r"[;&|`\n]|\$\(", text):
        return None                        # chained: not ours to parse
    try:
        parts = shlex.split(text, posix=False)
    except ValueError:
        return None
    parts = [p.strip('"\'') for p in parts if p.strip('"\'')]
    if not parts or Path(parts[0]).stem.lower() not in ("aicore", "ioagentfarm"):
        return None
    try:
        from typer.main import get_command
        from ioagentfarm.cli import app as _app
        node = get_command(_app)
    except Exception:                      # noqa: BLE001
        return None

    path: list[str] = []
    i = 1
    while i < len(parts):
        children = getattr(node, "commands", None)
        if not isinstance(children, dict):
            break
        child = children.get(parts[i])
        if child is None:
            break
        node, path, i = child, path + [parts[i]], i + 1
    if not path or isinstance(getattr(node, "commands", None), dict):
        return None                        # a group, not a leaf command

    known = {o for p in getattr(node, "params", [])
             for o in (getattr(p, "opts", []) or [])
             + (getattr(p, "secondary_opts", []) or [])
             if o.startswith("--")}
    known.add("--help")
    for arg in parts[i:]:
        if arg == "--":
            break                          # everything after is a value
        if not arg.startswith("--") or "=" in arg:
            continue                       # `--flag=value` carries its own
        if arg not in known:
            return arg, " ".join(path), known
    return None


def build_new_solution_verdict(command: str, build_repo: str | None) -> str | None:
    """In a build session, refuse a `new-solution` that would CREATE a
    STANDALONE repo, and direct it to `workspace scaffold` instead - so a
    build session's content always lands in the root_ws structure
    (`agents/ skills/ solutions/ tools/` at the repo root, regardless of the
    current directory).

    `new-solution` alone builds a standalone package whose content sits under
    `<pkg>/agents`/`<pkg>/skills`; inside an already-scaffolded WORKSPACE it
    instead GROWS the workspace with `solutions/<sol>/`, which is fine. The
    two are told apart by whether *build_repo* is already a workspace.

    This adds NO environment variable: `build_repo` is the value the build
    session already recorded in `IOF_BUILD_REPO`, read in-process by the
    guard wrapper. Pure given the filesystem, so testable with a temp dir.
    Never blocks on a detection failure - the charter still guides the model.
    """
    import re

    if not build_repo:
        return None
    m = re.search(r"\b(?:aicore|ioagentfarm)\s+new-solution\s+(?!--)"
                  r"([a-z][\w-]*)", command or "", re.IGNORECASE)
    if not m:
        return None
    # `--dir <elsewhere>` names another target; leave that to the command's
    # own same-name nesting guard rather than second-guessing the path here.
    if re.search(r"--dir(=|\s)", command or ""):
        return None
    from pathlib import Path
    try:
        from ioagentfarm.cli_scaffold import _enclosing_workspace
        if _enclosing_workspace(Path(build_repo)) is not None:
            return None                    # already a workspace: growing it is fine
    except Exception:                      # noqa: BLE001 - never block on detection
        return None
    slug = m.group(1)
    return ("[build guard] refused: this repository is not a workspace yet, so "
            f"`new-solution {slug}` would create a STANDALONE package whose "
            "content nests under `<pkg>/agents` and `<pkg>/skills` - not the "
            "root_ws structure. Establish the workspace ONCE first:\n"
            "  aicore workspace scaffold <name> --no-register\n"
            "which creates `agents/ skills/ solutions/ tools/` at the repo "
            f"root; then `aicore new-solution {slug}` GROWS it as "
            f"`solutions/{slug}/`, and agents/skills/tools land at the root "
            "no matter which subdirectory you run from.")


def build_exec_guard_verdict(command: str) -> str | None:
    """The refusal for *command*, or None when it may run. Pure, testable."""
    import re

    for rule in _BUILD_GUARD_DENY:
        pattern, why = rule[0], rule[1]
        # A third element names an env var that EXCUSES the rule, because
        # the capability exists elsewhere - an interactive build session
        # that can ask the user. Refusing here as well would refuse twice.
        excuse = rule[2] if len(rule) > 2 else None
        if excuse and os.environ.get(excuse) == "1":
            continue
        if re.search(pattern, command or "", re.IGNORECASE):
            return (f"[build guard] refused: {command!r} - {why}. This is "
                    "enforced by the harness; proceed another way or ask "
                    "the user to run it themselves.")

    # A LITERAL SECRET IN THE COMMAND - `--header 'Authorization=Bearer
    # eyJ...'` where `${TOKEN}` belongs. The rules above catch reading and
    # printing secrets; this catches carrying one. Same detector as the
    # write gate and the learning scanner, so the three seams agree on what
    # a secret looks like.
    from ioagentfarm.engine.learning.skill_scan import find_secret_literals
    kinds = find_secret_literals(command or "")
    if kinds:
        return (f"[build guard] refused: the command carries what looks like "
                f"a literal credential ({', '.join(kinds)}). Write it as a "
                "${VAR} reference - the runtime resolves the value from the "
                "environment - and tell the user which variable to set and "
                "where (their workspace .env or the deployment's "
                "environment). Never paste the value into a command, a file "
                "or your reply.")

    # AFTER THE POLICY RULES, DELIBERATELY. `sleep 60 && aicore status` is
    # both unparseable here and a banned sleep-poll, and the ban is the
    # answer that matters - put this first and it shadows every policy rule
    # a model happens to write with `&&`, teaching the syntax and losing the
    # refusal. Found by exactly that test going red.
    #
    # BEFORE the run-state counter, equally deliberately: a command the
    # shell cannot parse never runs, so it must not spend the budget that
    # counts commands which did.
    #
    # This is a CORRECTION, not a policy refusal - it names the rewrite
    # instead of leaving the model to infer one from a parser error. `;`
    # alone is not the general answer: `&&` is conditional, so dropping the
    # condition would run step two after step one failed.
    op = unquoted_chain_operator(command)
    if op and shell_lacks_chain_operators():
        fix = ("`A; if ($?) { B }`" if op == "&&"
               else "`A; if (-not $?) { B }`")
        return (f"[build guard] refused: `{op}` is a parser error in this "
                "session's shell - Windows PowerShell 5.1, which has no "
                f"`&&`/`||` (they are PowerShell 7). Rewrite it as {fix}, "
                "or as `A; B` when the second command should run "
                "regardless. Do not retry the same line, and use this form "
                "for the rest of the session.")

    # AN INVENTED FLAG, ANSWERED WITH THE REAL ONES. The charter tells the
    # model never to state a flag it has not seen, and the preamble lists
    # the real flags of the commands a build session runs. Both are
    # REQUESTS, and the corpus keeps showing they do not hold: `aicore
    # new-agent --role`, `aicore lint-agent --workspace`, `aicore mcp-list
    # --dir`, and `aicore run --dir` - the last one for a command whose
    # flags were in the preamble that very turn.
    #
    # A CORRECTION, not a policy refusal: click already rejects the call, so
    # nothing unsafe happens either way. What click does not do is say what
    # the flags ARE, so the model guesses again. This costs the same one
    # call and ends the guessing.
    bad = unknown_aicore_flag(command)
    if bad is not None:
        flag, cmd_path, known = bad
        listed = " ".join(sorted(known)) or "(none)"
        return (f"[build guard] refused: `{flag}` is not a flag of `aicore "
                f"{cmd_path}`. Its flags are: {listed}. Re-run with one of "
                "those, or without the flag; do not guess another spelling.")

    # POLLING BY REPETITION. The sleep rule above catches `sleep N; aicore
    # status` because that is the shape that was observed first. It does not
    # catch calling `forensics explain` five times in a row with no sleep at
    # all - which is what happened next, and is worse, because without the
    # delay it burns the turn's budget faster. A rule that matches the FORM of
    # a behaviour gets routed around; this counts the behaviour itself.
    if _RUN_STATE_READ.search(command or ""):
        _run_state_reads[0] += 1
        if _run_state_reads[0] > _RUN_STATE_BUDGET:
            return (f"[build guard] refused: {command!r} - this turn has "
                    f"already read run state {_run_state_reads[0] - 1} times. "
                    "A run outlives this session and records its own result; "
                    "watching it from here changes nothing and spends the "
                    "turn.\n"
                    "Report ONLY what you read in THIS turn, and say when you "
                    "read it. Do NOT restate run state from earlier in the "
                    "conversation as though it were current - a step that was "
                    "recovering an hour ago has almost certainly finished, and "
                    "an unmarked stale reading is indistinguishable from a "
                    "fresh one to whoever reads your report. If you have not "
                    "read something this turn, say so.\n"
                    "Then hand over `aicore watch <run_id>` - it streams the "
                    "run live and costs this session nothing - and move on to "
                    "work that is not waiting.")
    return None


def apply_mcp_trace_context() -> None:
    """Send W3C trace context with every MCP TOOL CALL, in the request itself.

    THE TOOL MAY NOT BE ON THIS MACHINE. An MCP server is a service, often
    remote, and the runtime sent it `accept`, `content-type` and
    `user-agent` and nothing else - so a server that is itself instrumented
    had no trace to join and its work became a separate root. Measured
    against a stand-in remote server: `traceparent present? False`. What a
    client loses is the interesting half of a distributed tool call: the
    query the remote service actually ran, unreachable from the run that
    caused it.

    IT CANNOT BE DONE IN AN HTTP HEADER HOOK, and that is worth writing down
    because it is the obvious design and it silently yields nothing. The MCP
    transport issues its HTTP requests from a task created when the SESSION
    was opened, and an asyncio task captures the ambient context at creation
    - so a contextvar set later, by the caller, is invisible there. Measured:
    with the caller's span demonstrably current and the tool call returning
    correctly, EVERY request reaching an httpx request hook reported no valid
    span, connection and tool call alike. A header hook can only ever inject
    the context that existed at connect time.

    So propagate in the MESSAGE, where MCP has a field for it: `call_tool`
    takes `meta`, which rides in `params._meta` of the JSON-RPC request. That
    is evaluated in `MCPToolWrapper.execute`, which runs in the CALLER's task,
    where the context is live - and it is per call, not per connection. It is
    also the convention MCP servers are growing an OTel reader for.

    With `otel_llm_spans` making the `aicore.agent_tool` span current for the
    duration of the call, what the server receives is that span, so an
    instrumented server's work arrives as CHILDREN of the tool call rather
    than merely in the same trace.
    """
    if not (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
            or os.environ.get("IOF_OTEL_EXPORTER")):
        return
    try:
        from iobot.agent.tools import mcp as _mcp
        from ioagentfarm.engine import otel_export as _ex
        from opentelemetry.propagate import inject as _inject
    except Exception:
        return
    if not (_ex.available() and _ex.enabled()):
        return
    if getattr(_mcp, "_iof_mcp_trace_patch", False):
        return

    _Wrapper = getattr(_mcp, "MCPToolWrapper", None)
    if _Wrapper is None:
        return
    _orig_execute = _Wrapper.execute

    async def _execute_with_trace(self: Any, **kwargs: Any) -> Any:
        sess = getattr(self, "_session", None)
        if sess is None or getattr(sess, "_iof_traced", False):
            return await _orig_execute(self, **kwargs)
        try:
            if _ex.tracer() is None:       # forces provider setup
                return await _orig_execute(self, **kwargs)
            carrier: dict = {}
            _inject(carrier)
            if not carrier:
                return await _orig_execute(self, **kwargs)
            _orig_call = sess.call_tool

            async def _call_with_meta(name, arguments=None, *a, **k):
                # Never lose the caller's own meta if a future version sets one.
                k["meta"] = {**(k.get("meta") or {}), **carrier}
                try:
                    return await _orig_call(name, arguments, *a, **k)
                except TypeError:
                    # an SDK without `meta`: send the call rather than fail it
                    k.pop("meta", None)
                    return await _orig_call(name, arguments, *a, **k)

            sess.call_tool = _call_with_meta
            try:
                return await _orig_execute(self, **kwargs)
            finally:
                sess.call_tool = _orig_call
        except Exception:  # noqa: BLE001 - never fail a tool call over a header
            return await _orig_execute(self, **kwargs)

    _Wrapper.execute = _execute_with_trace
    _mcp._iof_mcp_trace_patch = True


def apply_powershell_format_cmdlets() -> None:
    """Stop the disk-`format` denial from blocking PowerShell's Format-* cmdlets.

    Upstream's deny list carries ``(?:^|[;&|]\\s*)format(?!=)\\b`` to refuse
    ``format C:``. On Windows that also matches ``| Format-Table``,
    ``| Format-List`` and ``| Format-Hex`` — the three commonest ways to render
    output in PowerShell, all of them read-only. The lookahead already exempts
    ``--format=`` for git; it simply never anticipated the cmdlet spelling.

    Found by running `aicore build` on a Windows client box: the block reached
    the agent as bare STDERR, which it read as a shell-escaping problem and
    worked around by writing a script — so the cost was not just a refused
    command but a wrong diagnosis and a scratch file in the user's repo.

    The fix widens the lookahead to ``(?![-=])`` so a following hyphen is
    exempt too. ``format C:``, ``format /q D:`` and ``echo x; format E:`` still
    match, because a destructive invocation is never followed by a hyphen.
    Applied by rewriting the compiled list in ``ExecTool.__init__`` rather than
    editing ``iobot/src/`` — vendor rule 1.
    """
    import functools

    from iobot.agent.tools.shell import ExecTool

    if getattr(ExecTool, "_iof_ps_format_patch", False):
        return

    _BAD = r"(?:^|[;&|]\s*)format(?!=)\b"
    _GOOD = r"(?:^|[;&|]\s*)format(?![-=])\b"
    _orig = ExecTool.__init__

    @functools.wraps(_orig)
    def __init__(self, *a, **kw):
        _orig(self, *a, **kw)
        pats = getattr(self, "deny_patterns", None)
        if isinstance(pats, list):
            self.deny_patterns = [_GOOD if p == _BAD else p for p in pats]

    ExecTool.__init__ = __init__
    ExecTool._iof_ps_format_patch = True


#: Servers that failed their last connect, name -> one-line diagnosis. Read
#: by anything that wants to TELL somebody; written only here.
MCP_CONNECT_FAILURES: dict[str, str] = {}


def _diagnose_mcp_failure(name: str, cfg) -> str:
    """One actionable line for a server that did not connect.

    Reuses the `mcp-list --probe` classifier, so the moment of failure and
    the diagnostic command give the SAME answer - the alternative is two
    explanations of one event that drift apart, which is how the capture
    layer and the event emitter disagreed about consult results.
    """
    spec = {}
    for key in ("url", "type", "command"):
        value = getattr(cfg, key, None)
        if value:
            spec[key] = value
    for key in ("headers", "env"):
        value = getattr(cfg, key, None)
        if value:
            spec[key] = dict(value)
    if not spec.get("url"):
        return "failed to connect (stdio server - check the command and its args)"
    try:
        from ioagentfarm.engine.mcp_probe import advice, probe, probe_entries
        # The iobot cfg object has no `auth:` - that key is stripped before
        # iobot ever sees it - so the auth block is looked up by NAME from
        # the declaration tiers. Without this the diagnosis probes an OAuth
        # server anonymously and blames the credential.
        declared = (probe_entries() or {}).get(name) or {}
        if declared.get("auth"):
            spec["auth"] = declared["auth"]
        result = probe(spec, timeout=5.0)
        hint = advice(result)
        return (f"{result['status']} - {result['detail']}"
                + (f" -> {hint}" if hint else ""))
    except Exception:                      # noqa: BLE001 - a diagnosis is a nicety
        return "failed to connect"


def apply_mcp_connect_is_visible() -> None:
    """Say which MCP server did not connect, by name, and why.

    THE CLIENT INCIDENT THIS CLOSES. A remote MCP server rejected the
    credential on every request. Upstream caught it, logged through loguru -
    which a build session sends to a FILE - and omitted the server from the
    registry. The agent started normally, silently missing its tools,
    invented a reason when asked, and the only thing on screen was one line
    reading `Error in post_writer (ExceptionGroup)`: no server, no URL, no
    status. `mcp-list` then printed the server as healthy, because it reads
    files. An afternoon went into that.

    This wraps `connect_mcp_servers`, compares what was ASKED FOR against
    what came back, and reports the difference through the STDLIB logger -
    deliberately, because that is the channel the build console renders
    (loguru is file-only there). The message names the server, the URL and
    the diagnosis.

    Unconditional: a silent capability loss is never the right default on any
    surface. The cost when nothing fails is one dict comparison.
    """
    from iobot.agent.tools import mcp as _mcp

    if getattr(_mcp, "_iof_mcp_visible_patch", False):
        return

    _orig = _mcp.connect_mcp_servers

    async def connect_mcp_servers(mcp_servers, registry):        # type: ignore[no-redef]
        connected = await _orig(mcp_servers, registry)
        try:
            asked = dict(mcp_servers or {})
            for name, cfg in asked.items():
                if name in (connected or {}):
                    MCP_CONNECT_FAILURES.pop(name, None)
                    continue
                # ONCE PER SERVER PER PROCESS. `_connect_mcp()` runs on EVERY
                # message, so diagnosing on each failure would add the
                # probe's timeout to every turn for as long as a server
                # stays down, and would repeat an identical error line the
                # user has already read. The entry is cleared the moment the
                # server connects, so a server that recovers and fails again
                # is reported again.
                if name in MCP_CONNECT_FAILURES:
                    continue
                why = _diagnose_mcp_failure(name, cfg)
                MCP_CONNECT_FAILURES[name] = why
                target = getattr(cfg, "url", None) or getattr(cfg, "command", "?")
                logging.getLogger("ioagentfarm.mcp").error(
                    "MCP server %r did NOT connect (%s): %s. Its "
                    "mcp_%s_* tools are unavailable this session; "
                    "`aicore mcp-list --probe` re-checks it.",
                    name, target, why, name)
        except Exception:                  # noqa: BLE001 - never break a run
            pass
        return connected

    _mcp.connect_mcp_servers = connect_mcp_servers
    _mcp._iof_mcp_visible_patch = True


def apply_mcp_oauth() -> None:
    """Make the MCP client able to AUTHENTICATE, not just to carry a header.

    The runtime sent a static header and nothing else: the `streamableHttp`
    transport built its httpx client with `headers=cfg.headers` and no
    `auth=` at all, and the `sse` branch had an `auth` hook nothing ever
    populated. So a server behind OAuth could not be connected - the
    credential was refused, the server was dropped from the tool registry,
    and the agent ran on silently without those tools. The documented
    workaround was a gateway that performs the flow and presents a static
    bearer; it works, and it makes every client operate a process to do
    something the client should do itself.

    This attaches an `httpx.Auth` that mints and RENEWS a token from the
    declaration's `auth:` block. Renewal is the half a static credential can
    never have: a JWT pasted into a header works until its `exp` and then
    stops, which is a scheduled outage.

    THE SEAM. `open_single_server` is a closure inside `connect_mcp_servers`,
    so its httpx client cannot be intercepted directly - but the transports
    it calls are imported at CALL time from `mcp.client.*`, so replacing the
    module attribute is enough. `httpx.AsyncClient.auth` is settable after
    construction, which is what lets the already-built client be given a
    credential without touching the vendored tree (vendor rule 1).

    Unconditional: a declaration that asks for OAuth either works or must say
    why, and both are better than the silent drop this replaces. Servers with
    no `auth:` block are untouched - the lookup returns None and the original
    transport runs unchanged.
    """
    import mcp.client.sse as _sse
    import mcp.client.streamable_http as _http

    if getattr(_http, "_iof_mcp_oauth_patch", False):
        return

    def _auth_for_url(url: str):
        """The auth object declared for whichever server has this URL."""
        try:
            from ioagentfarm.engine.mcp_auth import auth_for
            from ioagentfarm.engine.iobot_config import effective_mcp_servers
            for name, info in (effective_mcp_servers() or {}).items():
                spec = info.get("spec") or {}
                if str(spec.get("url") or "") != str(url):
                    continue
                auth = info.get("auth")
                if not auth:
                    return None
                return auth_for(name, {"auth": auth})
        except Exception as exc:           # noqa: BLE001 - never block a run
            logger.warning("MCP OAuth: could not resolve auth for {}: {}",
                           url, exc)
        return None

    _orig_http = _http.streamable_http_client

    def streamable_http_client(url, *a, **k):     # type: ignore[no-redef]
        auth = _auth_for_url(url)
        client = k.get("http_client")
        if auth is not None and client is not None:
            client.auth = auth
            logger.info("MCP server at {}: authenticating with the declared "
                        "OAuth grant", url)
        return _orig_http(url, *a, **k)

    _orig_sse = _sse.sse_client

    def sse_client(url, *a, **k):                 # type: ignore[no-redef]
        auth = _auth_for_url(url)
        factory = k.get("httpx_client_factory")
        if auth is not None and factory is not None:
            def with_auth(headers=None, timeout=None, auth_=None, **kw):
                client = factory(headers=headers, timeout=timeout, auth=auth)
                return client
            k["httpx_client_factory"] = with_auth
        return _orig_sse(url, *a, **k)

    _http.streamable_http_client = streamable_http_client
    _sse.sse_client = sse_client
    _http._iof_mcp_oauth_patch = True


def apply_tool_contract() -> None:
    """Let this platform's own templates override the runtime's, by NAME.

    WHAT THIS IS FOR. `ContextBuilder.build_system_prompt` renders
    `agent/tool_contract.md` into EVERY system prompt, for every agent, on
    every turn - the runtime's own account of which tool to use for which
    job. It is the right place for a rule that is true of the tool surface
    rather than of one role, and until now we had no way to put anything
    there: our tool rules lived in STEP PROMPTS, so `agent-chat`, the
    always-on agents and swarm drivers never saw them at all.

    WHY A LOADER AND NOT AN EDIT. Rule 1 of the vendored tree is that
    `iobot/src/` is never hand-edited - an upgrade re-copies upstream and the
    edit vanishes silently. The Jinja environment resolves templates through a
    `FileSystemLoader` rooted at iobot's `templates/`, so putting OUR
    directory in front of it is a supported extension point that touches no
    vendored byte. Anything we do not override falls through unchanged.

    WHY INCLUDE RATHER THAN FORK. Our `agent/tool_contract.md` opens with
    `{% include 'upstream/agent/tool_contract.md' %}` and appends a section.
    Copying upstream's 6 KB would mean owning it forever: their improvements
    would stop reaching us the moment we forked, silently, and nothing would
    ever tell us. Including it means we own only the delta, upstream's edits
    keep arriving on upgrade, and the MIT attribution travels with the text
    instead of being reproduced by us. The `upstream/` prefix is a second
    loader pointed at the same iobot directory, which is what makes a
    same-named include resolve to theirs instead of recursing into ours.

    The consequence to know: an APPEND can add and correct, but cannot remove
    an upstream line. That is acceptable here - their contract describes no
    tool we unregister (`spawn`, `create_goal`, `update_goal` appear nowhere
    in it) - and if that stops being true the answer is a correction in our
    section, not a fork.
    """
    from iobot.utils import prompt_templates as _pt

    if getattr(_pt, "_iof_tool_contract_patch", False):
        return
    if (os.environ.get("IOF_TOOL_CONTRACT") or "").strip().lower() == "upstream":
        return

    from pathlib import Path as _Path

    ours = _Path(__file__).resolve().parent / "templates"
    if not (ours / "agent" / "tool_contract.md").is_file():
        # SAY SO. A wheel whose package-data glob missed `templates/**` ships
        # this directory empty, and the failure is otherwise invisible: every
        # prompt silently reverts to upstream's contract and nothing is wrong
        # anywhere a test would look.
        logger.warning("[aicore patches] tool_contract: our template "
                       "directory has no agent/tool_contract.md (%s) - "
                       "prompts fall back to the runtime's own contract", ours)
        return

    from jinja2 import ChoiceLoader, Environment, FileSystemLoader, PrefixLoader

    upstream_root = _Path(_pt.__file__).resolve().parent.parent / "templates"

    def _environment() -> Environment:
        return Environment(
            loader=ChoiceLoader([
                FileSystemLoader(str(ours)),
                # `upstream/...` resolves to the runtime's own copy, so our
                # override of a name can still include the thing it overrides.
                PrefixLoader({"upstream": FileSystemLoader(str(upstream_root))}),
                FileSystemLoader(str(upstream_root)),
            ]),
            # Mirrored from the runtime's own environment. These are not
            # incidental: `autoescape=False` keeps prompt text from being
            # HTML-escaped, and the block trimming is what keeps an
            # `{% include %}` from leaving a blank line where a tag was.
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )

    # The runtime caches its environment with `lru_cache`; ours is called
    # through the same module attribute, so cache it the same way rather than
    # rebuilding a loader on every render.
    from functools import lru_cache

    _pt._environment = lru_cache(maxsize=None)(_environment)
    _pt._iof_tool_contract_patch = True


def apply_build_write_gates() -> None:
    """Placement and secret gates on the FILE TOOLS, in EVERY build process.

    THE HOLE THIS CLOSES, found by adversarial live testing. `want_engine`
    gives the in-process engine to INTERACTIVE sessions only; every one-shot
    (`-m`, and therefore every CI turn) runs the agent in a SUBPROCESS. The
    two gates were wrapped onto the loop's tools in `builder/engine.py`,
    which exists only on the in-process path - so a one-shot had no placement
    gate and no secret gate at all. Asked under mild pressure to "forget the
    ${VAR} indirection, it's a test box", a live session wrote a literal
    token into the repository's `mcp.yaml` (a file git would commit) and into
    two `.env` files OUTSIDE the repository. Both refusals existed; neither
    was armed where it mattered.

    Same shape as `build_exec_guard`: a runtime patch, inert unless
    `IOF_BUILD_REPO` is set in the environment at CALL time, which only
    `aicore build` sets. The refusal is the tool RESULT, so the model reads
    why and adapts. The gate FUNCTIONS are unchanged and still live in
    `builder/gates.py` - one implementation, two arming points, so the paths
    cannot drift.
    """
    from iobot.agent.tools.filesystem import _FsTool

    if getattr(_FsTool, "_iof_build_write_gate_patch", False):
        return

    from ioagentfarm.builder.gates import (placement_denial, read_denial,
                                           secret_denial)

    def _guard(tool_name: str, kwargs: dict) -> str | None:
        if not os.environ.get("IOF_BUILD_REPO"):
            return None
        repo = os.environ.get("IOF_BUILD_REPO") or ""
        if repo:
            deny = placement_denial(tool_name, kwargs, repo)
            if deny:
                return deny
        return secret_denial(tool_name, kwargs)

    def _read_guard(kwargs: dict) -> str | None:
        if not os.environ.get("IOF_BUILD_REPO"):
            return None
        return read_denial("read_file", kwargs)

    def _lint_after_write(tool_name: str, kwargs: dict, result):
        """Append the harness's own lint of what this write produced.

        THE HARNESS VERIFIES; the model does not self-report. Lint was a
        REQUEST - the charter told the agent to run `aicore lint-<kind>` and
        report only what the linter confirmed, and nothing in the harness
        ran one, so "lint clean" was a claim until the model chose to make
        it true. The verdict goes into the TOOL RESULT, the channel the
        model already reads, in the same call and before it has reported
        anything.

        It lives on the PATCH rather than beside the in-process gate for
        the reason that whole patch exists: `--message` never builds the
        in-process engine, so anything wired there is absent from every
        scripted and CI run. Wrapping the class covers both paths once.

        A write that ERRORED is left alone - there is nothing correct on
        disk to lint - and any failure here is swallowed: a linter must
        never cost the user a write that succeeded.
        """
        if not os.environ.get("IOF_BUILD_REPO"):
            return result
        repo = os.environ.get("IOF_BUILD_REPO") or ""
        if not repo:
            return result
        try:
            from iobot.agent.tools.base import ToolResult
            if isinstance(result, ToolResult) and result.is_error:
                return result
        except Exception:                          # noqa: BLE001
            pass
        try:
            from ioagentfarm.builder import verify as _verify
            return _verify.append_to_result(
                result, _verify.tool_verdict(tool_name, kwargs, repo))
        except Exception:                          # noqa: BLE001
            logger.debug("[aicore patches] post-write lint failed",
                         exc_info=True)
            return result

    # The write/edit tools are separate classes in the runtime; wrapping the
    # SHARED base's execute would gate EVERY read, which must never happen -
    # a build session reads constantly and a refused ordinary read teaches
    # the model nothing. So each writing class is wrapped by name, and the
    # read tool gets its OWN narrow wrapper below that refuses a credential
    # file and nothing else.
    import iobot.agent.tools.filesystem as _fs
    try:
        import iobot.agent.tools.apply_patch as _ap
    except ImportError:                       # an older runtime
        _ap = None

    wrapped = 0
    # `ApplyPatchTool` lives in its OWN module. It was looked up on
    # `filesystem` with a comment saying the runtime "ships only Write and
    # Edit" - which was false: apply_patch.py exists, the tool contract
    # names it the DEFAULT editor, and it is the one a client's build
    # session used on every edit. So the default editor ran with no
    # secret denial, no placement denial and no post-write lint on the
    # one-shot path, and `wrapped == 2` kept the "UNGATED" warning quiet.
    for cls_name, tool_name, mod in (("WriteFileTool", "write_file", _fs),
                                     ("EditFileTool", "edit_file", _fs),
                                     ("ApplyPatchTool", "apply_patch", _ap)):
        cls = getattr(mod, cls_name, None) if mod is not None else None
        if cls is None or getattr(cls, "_iof_build_write_gate", False):
            continue
        orig = cls.execute

        def _bind(orig_fn, name):
            async def execute(self, *a, **k):     # type: ignore[no-untyped-def]
                verdict = _guard(name, k)
                if verdict is not None:
                    return verdict
                result = await orig_fn(self, *a, **k)
                return _lint_after_write(name, k, result)
            return execute

        cls.execute = _bind(orig, tool_name)
        cls._iof_build_write_gate = True
        wrapped += 1

    # The READ tool, wrapped narrowly: a credential file is refused, every
    # other read runs untouched. On the one-shot/CI subprocess path this is
    # the only thing standing between a prompt-injected "read the .env" and
    # the value reaching the model - the exec guard cannot see a tool read.
    _read_cls = getattr(_fs, "ReadFileTool", None)
    if _read_cls is not None and not getattr(
            _read_cls, "_iof_build_read_gate", False):
        _read_orig = _read_cls.execute

        def _bind_read(orig_fn):
            async def execute(self, *a, **k):     # type: ignore[no-untyped-def]
                verdict = _read_guard(k)
                if verdict is not None:
                    return verdict
                return await orig_fn(self, *a, **k)
            return execute

        _read_cls.execute = _bind_read(_read_orig)
        _read_cls._iof_build_read_gate = True

    _FsTool._iof_build_write_gate_patch = True
    if not wrapped:
        logger.warning("[aicore patches] build_write_gates: no writing "
                       "filesystem tool was found to wrap - the one-shot "
                       "build path is UNGATED")


#: Commands that DECLARE a remote endpoint in a config file and never open a
#: socket to it.
_DECLARATION_VERBS = (
    "new-mcp-server", "mcp-add", "a2a-add",
)
#: Anchored at the START, and the command must be the ONLY one on the line.
#: The first version matched the verb anywhere and exempted the whole string,
#: so `aicore new-mcp-server --url https://x/mcp; curl http://10.0.0.5` was
#: waved through - the declaration bought an exemption for the fetch chained
#: after it. Caught by testing the mixed case rather than the happy one.
_DECLARATION_RE = re.compile(
    r"^\s*(aicore|ioagentfarm)\s+(" + "|".join(_DECLARATION_VERBS) + r")(?![\w-])")

#: Anything that could introduce a SECOND command. Present, and the exemption
#: is refused outright rather than reasoned about: a shell has more ways to
#: chain than a denylist can hold, and this one only has to recognise the
#: plain single-command form to be useful.
_CHAINING = re.compile(r"[;&|`\n]|\$\(|>\(|<\(")


def _is_bare_declaration(command: str) -> bool:
    """One declaration command, and nothing else on the line."""
    text = str(command or "")
    return bool(_DECLARATION_RE.search(text)) and not _CHAINING.search(text)


def apply_build_declaration_urls() -> None:
    """Let a build session DECLARE a remote endpoint it never contacts.

    The runtime refuses any exec whose command contains a URL it cannot
    prove is public - `contains_internal_url` fails CLOSED, so an
    unresolvable or private host blocks the command. Measured against the
    live checker, `https://vendors.acme.com/mcp` and
    `https://mcp.example.com/mcp` are BOTH blocked, not just loopback and
    RFC1918: the whole documented MCP workflow

        aicore new-mcp-server <name> --url <url> --header 'Authorization=Bearer ${VAR}'

    was impossible inside `aicore build`. Found by the corpus, where the
    scenario's own reply said so plainly and was doubted first - the refusal
    text is the RUNTIME's, not one of ours, so a grep for our markers found
    nothing and looked like a fabrication.

    The exemption is narrow on purpose. It applies only inside a build
    session, only to the three commands that WRITE a declaration into a
    config file, only when such a command is the ONLY one on the line, and
    it does not touch the guard for anything else - a `curl`, a `wget`, an
    MCP server actually being contacted at runtime are all still checked. Declaring an endpoint is not reaching one; the
    connection happens later, from the runtime, under its own rules.
    """
    import iobot.security.network as _net

    if getattr(_net, "_iof_build_declaration_urls", False):
        return

    _orig = _net.contains_internal_url

    def contains_internal_url(command, *, allow_loopback=False):  # type: ignore[no-untyped-def]
        if (bool(os.environ.get("IOF_BUILD_REPO"))
                and _is_bare_declaration(command)):
            return False
        return _orig(command, allow_loopback=allow_loopback)

    _net.contains_internal_url = contains_internal_url
    _net._iof_build_declaration_urls = True


#: The scaffold verbs that change what the pack's own tests check - the
#: entry point, the package-data globs, an agent's `output_protocol`, the
#: manifest. A prose edit does not; only these do.
_SCAFFOLD_VERB = re.compile(
    r"(^|[;&|]\s*)(aicore|ioagentfarm)\s+"
    r"(new-solution|new-agent|new-skill|new-workflow|new-swarm|new-tool"
    r"|new-mcp-server|workspace\s+scaffold)(?![\w-])")

#: The last verdict seen IN THIS PROCESS, so a standing environmental
#: failure is stated once rather than after every scaffold. Reset per turn
#: beside the call budget - see `builder/budget.reset`.
_last_test_summary: list = [None]


def reset_scaffold_tests() -> None:
    _last_test_summary[0] = None


def scaffold_test_verdict(command: str, result) -> str | None:
    """Run the pack's tests after a SCAFFOLD, in the same tool call.

    THE LOOP HAS TO CLOSE INSIDE THE TURN. The post-turn run tells the model
    afterwards, which costs a whole new turn to act on - and the difference
    is measurable: the lint verdict rides the tool result and a broken
    workflow went `1 error` -> `0 errors` within one turn, while the tests
    ran at the boundary and nothing was ever fixed from them.

    Only after a scaffold verb, because only those change what the tests
    check: the `aicore.packs` entry point, the package-data globs, an
    agent's `output_protocol`, the manifest. A prose edit cannot break any
    of them, and running a suite after every write is a cost the model
    learns to ignore.

    Said ONCE per turn unless the verdict CHANGES. Repeating a standing
    environmental failure after every scaffold is what made two complete
    turns end "cannot run yet because the pack is not installed" and score
    as refusals.
    """
    if not _SCAFFOLD_VERB.search(str(command or "")):
        return None
    if "Exit code: 0" not in str(result) and "Created" not in str(result):
        return None                        # the scaffold itself failed
    repo = os.environ.get("IOF_BUILD_REPO") or ""
    if not repo:
        return None
    try:
        from ioagentfarm.builder.verify import (run_pack_tests, tests_key,
                                                tests_line)
        verdict = run_pack_tests(repo, timeout=60)
    except Exception:                      # noqa: BLE001 - never cost a scaffold
        logger.debug("[aicore patches] in-turn pack tests failed",
                     exc_info=True)
        return None
    if not verdict:
        return None
    key = tests_key(verdict)
    if key == _last_test_summary[0]:
        return None
    _last_test_summary[0] = key
    return tests_line(verdict)


def exec_timeout_hint(result) -> str | None:
    """The remedy to append when an exec result is a timeout; else None.

    A TIMEOUT NAMES THE PROBLEM AND NOT THE CURE. The runtime answers
    "Error: Command timed out after N seconds", and `yield_time_ms` - which
    hands back a pollable `session_id` instead of dying with nothing to show
    - is invisible at the one moment it is wanted. Measured: 23 timeouts
    across 2401 tool results, and `yield_time_ms` used ZERO times in 952
    exec calls.

    This is the mechanism with evidence behind it. Saying it in a skill is a
    REQUEST, and this repository's history is that requests do not hold: the
    sleep-poll ban sat in an always-on skill AND the user's prompt, was
    verifiably injected, and was ignored until it was enforced at the tool.

    A pure function, so testing it needs no subprocess. The first version of
    its test spawned a real command and killed it, and asyncio's proactor
    deallocator then printed "I/O operation on closed pipe" AFTER pytest's
    summary line - which `scripts/run_tests.py` reads as the last line, so a
    green suite of 970 reported "no tests ran".
    """
    return (
        "[exec] two remedies, by shape of the command. A command that just "
        "needs LONGER - an install, a test suite, `aicore agent-chat`, a "
        "lint over a big tree - gets `timeout` in seconds (up to 600): "
        "re-run it with that. A command that RUNS UNTIL STOPPED or that "
        "the user should watch gets `yield_time_ms` (e.g. 5000): it comes "
        "back with a `session_id` you can poll instead of dying at the "
        "timeout with nothing to show."
    ) if "timed out after" in str(result) else None


def apply_build_call_budget() -> None:
    """Count a build turn's tool calls, nudge it, and stop it at a ceiling.

    Nothing counted them. The only bound was the runtime's
    ``maxToolIterations`` at 500 - so far above real work that it bounded
    nothing - and the model was never told its own count, so it could not
    notice it was over-running. Measured: "The pricing_bot agent keeps
    failing its lint. Fix it." against a repository with no pricing_bot
    spent NINETY-FIVE tool calls before replying, with a wrong answer.

    Wrapped on ``AgentRunner._run_tool``, which is where EVERY tool call
    goes - exec, the file tools, grep, the MCP tools. The obvious-looking
    seam, ``ToolRegistry.execute``, is the wrong one and cost a live run to
    find out: the runner calls ``tool.execute(**params)`` DIRECTLY when it
    has resolved the tool and falls back to the registry only when it has
    not, so a budget wired there counted almost nothing and the probe turn
    produced zero budget messages. Counting at each tool class instead
    would miss whatever tool is added next.

    INERT unless ``IOF_BUILD_REPO`` is set at call time, so every other surface
    - workflow steps, the served pool, plain agent-chat - is untouched by
    construction rather than by configuration.
    """
    from iobot.agent.runner import AgentRunner

    if getattr(AgentRunner, "_iof_build_call_budget", False):
        return

    _orig = AgentRunner._run_tool

    async def _run_tool(self, spec, tool_call, *a, **k):   # type: ignore[no-untyped-def]
        from ioagentfarm.builder import budget
        if not budget.armed():
            return await _orig(self, spec, tool_call, *a, **k)
        n = budget.bump()
        stop = budget.refusal(n)
        if stop is not None:
            # The runner's own shape: (result, event, error). A refusal is
            # a RESULT, not an error - an error would count against the
            # turn's failure handling and could end the run, where what is
            # wanted is a turn that stops calling tools and writes its
            # reply.
            return stop, {"name": getattr(tool_call, "name", "?"),
                          "status": "success"}, None
        result, event, err = await _orig(self, spec, tool_call, *a, **k)
        try:
            said = budget.note(n)
            if said:
                from ioagentfarm.builder import verify as _verify
                result = _verify.append_to_result(result, said)
        except Exception:                          # noqa: BLE001
            logger.debug("[aicore patches] call-budget note failed",
                         exc_info=True)
        return result, event, err

    AgentRunner._run_tool = _run_tool
    AgentRunner._iof_build_call_budget = True


def apply_build_exec_guard() -> None:
    """Refuse denylisted exec commands inside a BUILD session, at execution.

    Wraps ``ExecTool.execute``; INERT unless ``IOF_BUILD_REPO`` is in the
    process environment at CALL time - `aicore build` sets it for the agent
    it spawns, so every other surface (workflow steps, the served pool,
    plain agent-chat) is untouched by construction, not by configuration.
    The refusal is returned as the tool RESULT, so the model reads why and
    adapts instead of retrying blind.
    """
    from iobot.agent.tools.shell import ExecTool

    if getattr(ExecTool, "_iof_build_guard_patch", False):
        return

    _orig = ExecTool.execute

    async def execute(self, command=None, cmd=None, *args, **kwargs):  # type: ignore[no-untyped-def]
        armed = bool(os.environ.get("IOF_BUILD_REPO"))
        if armed:
            verdict = build_exec_guard_verdict(command or cmd or "")
            if verdict is not None:
                return verdict
            # Workspace-first placement, enforced (not merely charter): a
            # standalone `new-solution` is refused when the build repo is not
            # a workspace. Reads the repo the build session already recorded
            # in IOF_BUILD_REPO - no new env var.
            verdict = build_new_solution_verdict(
                command or cmd or "", os.environ.get("IOF_BUILD_REPO"))
            if verdict is not None:
                return verdict
        result = await _orig(self, command=command, cmd=cmd, *args, **kwargs)
        if armed:
            # Appended WITHOUT flattening: `f"{result}\n{hint}"` turned a
            # `ToolResult.error` into a plain string, so a timed-out
            # command reached the runner as a SUCCESS - the model read
            # "timed out" with is_error false and the retry accounting,
            # the console's error styling and `fail_on_tool_error` all
            # saw a call that worked.
            from ioagentfarm.builder.verify import append_to_result
            hint = exec_timeout_hint(result)
            if hint:
                return append_to_result(result, hint)
            said = scaffold_test_verdict(command or cmd or "", result)
            if said:
                return append_to_result(result, said)
        return result

    ExecTool.execute = execute
    ExecTool._iof_build_guard_patch = True


PATCHES: list[Patch] = [
    Patch(
        name="message_from_file",
        summary="A large step prompt crosses the process boundary as a file, "
                "not as an argv value.",
        reason=(
            "Windows caps a command line at 32,767 characters and the "
            "rendered prompt is passed as `--message`, so a 35.7 KB compile "
            "prompt could not be spawned at all: CreateProcess raised "
            "WinError 206. In a detached run nothing saw the exception - the "
            "step stayed `running` with empty stdout, stderr and http logs, "
            "the supervisor reaped it after 180s, and the next attempt "
            "repeated it until the hard cap. The spawn site's own comment "
            "had stopped at \"CreateProcess supports up to 32K characters\"."
        ),
        target="iobot.cli.commands.agent (--message @iof-prompt-file:<path>)",
        sentinel="commands.agent._iof_message_from_file",
        apply=apply_message_from_file,
        added="2026-09",
    ),
    Patch(
        name="bounded_search_walk",
        summary="A file search stops at an entry/time budget instead of walking a drive.",
        reason=(
            "Certification round 9 called `find_files` with `path='C:/'` and "
            "started an unbounded recursive walk of the whole drive. The "
            "walkers are synchronous and the pod serves ONE event loop, so "
            "/health stopped answering and the pod had to be restarted - "
            "every user's chat down, from one ordinary tool call with a large "
            "root, no privilege required. The privacy guard filters what a "
            "walk yields, which does not help: the cost is the traversal. "
            "Each walk now stops at an entry and wall-clock budget, returning "
            "what it found rather than raising - a truncated search is a "
            "normal answer, an exception in a tool call is not."
        ),
        target="iobot.agent.tools.search._SearchTool._iter_files / FindFilesTool._iter_paths",
        sentinel="_SearchTool._iof_bounded_walk",
        apply=apply_bounded_search_walk,
        added="2026-08",
    ),
    Patch(
        name="agent_homes_are_private",
        summary="One agent's file tool may not read or write another agent's home.",
        reason=(
            "Found by the chat certification (round 4): asked about a fact "
            "from another agent's conversation, a pooled chat agent globbed "
            "the tree and its file tool returned a SIBLING's session JSONL - "
            "that agent's whole transcript - plus other agents' SOUL.md and "
            "memory/. Session-key isolation held, so nothing leaked into the "
            "reply; containment did not. On a pod serving several always-on "
            "agents to different people, one agent's tool call can read "
            "another's chat history. `restrict_to_workspace` is the blunt "
            "alternative and would break real deployments (a query agent's "
            "DuckDB file and env live outside its home, and the per-session "
            "scratch dir is under IOF_ROOT), so this denies exactly the thing "
            "that is never legitimate: a path inside the agent-home root "
            "belonging to a different role."
        ),
        target="iobot.agent.tools.filesystem._FsTool._resolve_read/_resolve_write",
        sentinel="_FsTool._iof_agent_privacy_patch",
        apply=apply_agent_homes_are_private,
        added="2026-08",
    ),
    Patch(
        name="skip_gateway_templates",
        summary="Do not scaffold HEARTBEAT.md/USER.md into a solution's agents.",
        reason=(
            "The runtime copies every templates/*.md into any workspace it "
            "touches on first run. HEARTBEAT.md (the gateway tick script) and "
            "USER.md (who the user is) are gateway-agent concerns; a domain "
            "agent got both, nobody wrote them, nothing read them, and push/"
            "pull then carried them into the customer's repository. The "
            "platform agents ship their own copies, which are placed before "
            "any run and are left alone."
        ),
        target="iobot.utils.helpers.sync_workspace_templates",
        sentinel="iobot.utils.helpers.sync_workspace_templates."
                 "_iof_skip_tpl_patch",
        apply=apply_skip_gateway_templates,
        toggle_env="IOF_RUNTIME_TEMPLATES",
        added="2026-08",
    ),
    Patch(
        name="state_dir_override",
        summary="Relocate the on-disk state directory when IOF_STATE_DIR_NAME is set.",
        reason=(
            "The runtime's default is ~/.iobot natively; this is a no-op unless "
            "IOF_STATE_DIR_NAME names another directory (test isolation, a "
            "shared host). Done at runtime rather than as an iobot/patches/*.patch "
            "so the vendored tree stays byte-identical to what vendor.py derives — "
            "a .patch would be edit-divergence needing a re-cut whenever upstream "
            "touches those lines."
        ),
        target=(
            "config.loader.get_config_path, config.paths.{get_workspace_path,"
            "is_default_workspace,get_cli_history_path,get_legacy_sessions_dir}, "
            "config.schema.AgentDefaults.workspace, utils.helpers._TOOL_RESULTS_DIR"
        ),
        sentinel="get_config_path._iof_state_dir_patch",
        apply=apply_state_dir_override,
        toggle_env="IOF_STATE_DIR_NAME",  # unset / .iobot = no override
        added="2026-08",
    ),
    Patch(
        name="azure_chat_backend",
        summary="Swap AzureOpenAIProvider for a classic /chat/completions variant.",
        reason="Most enterprise Azure tenants expose only the classic route, not the v1 Responses API.",
        target="iobot.providers.(factory|azure_openai_provider).AzureOpenAIProvider",
        sentinel="AzureOpenAIProvider._iof_azure_chat_patch",
        apply=apply_azure_chat_backend,
        toggle_env=None,  # always-on; disable with IOF_DISABLE_AZURE_CHAT_PATCH=1 inside the fn
        added="2026-05",
    ),
    Patch(
        name="genai_bedrock_backend",
        summary="Route Anthropic traffic through the J&J GenAI Bedrock-wrapper gateway.",
        reason="Client gateway uses X-Api-Key + /model/{model}/invoke instead of api.anthropic.com.",
        target="iobot.providers.anthropic_provider.AnthropicProvider",
        sentinel="AnthropicProvider._iof_genai_bedrock_patch",
        apply=apply_genai_bedrock_backend,
        toggle_env="IOF_USE_GENAI_BEDROCK",
        added="2026-06",
    ),
    Patch(
        name="close_provider_clients",
        summary="Close each LLM provider's HTTP client at exit, bounded.",
        reason=(
            "No provider closes the client it creates, so a step agent stops "
            "writing to stdout and then lingers while keep-alive connections are "
            "left to interpreter shutdown. Measured at 5-141s per step, ~463s a "
            "run, tracking how recently the provider last spoke rather than any "
            "measure of workload."),
        target="LLMProvider.__init__ (+ atexit)",
        sentinel="LLMProvider._iof_client_close_patch",
        apply=apply_close_provider_clients,
        toggle_env="IOF_CLOSE_PROVIDER_CLIENTS",
        added="2026-08",
    ),
    Patch(
        name="request_timeout",
        summary="Bound one LLM call's total duration, on the streaming and non-streaming path alike.",
        reason=(
            "The runtime has only a per-chunk idle watchdog, which cannot fire while "
            "chunks keep arriving. This bound used to live inside disable_streaming, so "
            "it was absent exactly when streaming was ON - the case that needs it most. "
            "Measured in run_20260820_030328_787466: a 958s response body against a "
            "configured 180s."),
        target="LLMProvider.chat, LLMProvider.chat_stream",
        sentinel="LLMProvider._iof_timeout_patch",
        apply=apply_request_timeout,
        toggle_env="IOF_REQUEST_TIMEOUT_S",
        added="2026-08",
    ),
    Patch(
        name="disable_streaming",
        summary="Force non-streaming chat (AgentHook + LLMProvider timeout + AnthropicProvider).",
        reason="MiniMax streaming stalls; iobot exposes no CLI/config toggle to disable streaming.",
        target=("AgentHook/CompositeHook/AgentProgressHook.wants_streaming, "
                "AnthropicProvider.chat"),
        sentinel="AnthropicProvider._iof_no_stream_ap_patch",
        apply=apply_disable_streaming,
        toggle_env="IOF_DISABLE_STREAMING",
        added="2026-05",
    ),
    Patch(
        name="session_save_retry",
        summary="Retry session-JSONL saves through transient Windows file locks.",
        reason="os.replace of the session file intermittently hits PermissionError WinError 5 (AV/indexer holds the dest for a moment); one such lock killed a detached run's driver mid-checkpoint (2026-08-14). Retrying persistence through a sub-second lock is always correct; a real ACL problem still raises.",
        target="iobot.session.manager.SessionManager.save",
        sentinel="SessionManager._iof_save_retry_patch",
        apply=apply_session_save_retry,
        toggle_env=None,  # pure retry-on-transient; no-op when saves succeed
        added="2026-08",
    ),
    Patch(
        name="mcp_connect_timeout",
        summary="Bound the MCP handshake per server; name and skip one that hangs.",
        reason="Upstream bounds the HTTP transports and each tool call, but the STDIO handshake has no timeout: a server whose process starts and never answers `initialize` blocks the agent before it makes any LLM call. Observed 2026-08-16 with `command: python` + empty args (the interactive REPL) - 40 minutes of silence in which every diagnostic reads healthy (0-byte http log, no session written, a liveness ticker that is working correctly). A missing capability is a degraded run, not a dead one.",
        target="iobot.agent.tools.mcp.connect_mcp_servers",
        sentinel="connect_mcp_servers._iof_mcp_timeout_patch",
        apply=apply_mcp_connect_timeout,
        toggle_env="IOF_MCP_CONNECT_TIMEOUT_S",  # 0 restores unbounded upstream
        added="2026-08",
    ),
    Patch(
        name="dedup_tool_call_ids",
        summary="Rename duplicate tool_use/tool_result IDs unique on the wire.",
        reason="MiniMax-M2.7 emits duplicate tool_call ids on parallel turns; the dup is stored in history and replayed -> API 400 'duplicate tool_call id' on every following request.",
        target="AnthropicProvider._convert_messages",
        sentinel="AnthropicProvider._iof_dedup_toolids_patch",
        apply=apply_dedup_tool_call_ids,
        toggle_env=None,  # safe no-op for providers that don't duplicate
        added="2026-07",
    ),
    Patch(
        name="restrict_agency_tools",
        summary="Unregister iobot 0.3.0's spawn / create_goal / update_goal from every AgentLoop.",
        reason="0.3.0 registers them by default; a spawned subagent runs outside the step's artifact gate, forensics, token record and attempt cap, and step sessions are fresh-per-attempt so a recorded goal is discarded. Delegation belongs to the workflow DAG.",
        target="iobot.agent.loop.AgentLoop.__init__ (unregisters from self.tools)",
        sentinel="AgentLoop._iof_tool_restrict_patch",
        apply=apply_restrict_agency_tools,
        toggle_env="IOF_DISABLE_TOOLS",  # override the list; empty string keeps all
        added="2026-07",
    ),
    Patch(
        name="tool_contract",
        summary="Our templates override the runtime's by name; the tool contract in every prompt gains this platform's rules.",
        reason="`build_system_prompt` renders `agent/tool_contract.md` into EVERY prompt for every agent - the one place a rule about the TOOL SURFACE (rather than about one role) belongs. Our tool rules lived only in STEP PROMPTS, so agent-chat, always-on agents and swarm drivers never saw them: chiefly 'print a line of text before every tool call' (measured 65% -> 5% mid-stream connection failures) and sectioned composition (single-shot 0 chars/700s vs 47KB/495s). Implemented as a ChoiceLoader in front of the runtime's FileSystemLoader, so no vendored byte is touched (rule 1); our template INCLUDES upstream's via an `upstream/` PrefixLoader rather than forking it, so their edits keep arriving on upgrade and we own only the delta.",
        target="iobot.utils.prompt_templates._environment (loader swap; iobot/src untouched)",
        sentinel="prompt_templates._iof_tool_contract_patch",
        apply=apply_tool_contract,
        toggle_env="IOF_TOOL_CONTRACT",  # =upstream restores the runtime's own
        added="2026-08",
    ),
    Patch(
        name="memory_v1_off",
        summary="MEMORY.md neither loaded nor populated unless the LEGACY v1 pipeline is explicitly on; the memory slot renders the workspace-memory block (memory/WORKSPACE_MEMORY.md) instead.",
        reason="v2 owns learning and feedback (hub-governed methods + outcome attribution); MEMORY.md was v1's channel and its stale conclusions confuse AI Core users whichever direction it flows. Load gated (empty context), write gated (write_memory no-op + the agent's own workspace/memory/MEMORY.md refused at the fs-tool write resolver, with a message telling the agent to proceed). Paused under v2 (the default) AND under learning-off (IOF_LEARNING_V2=0) - only the explicit legacy opt-in (IOF_LEARNING_V2=0 + IOF_LEARNING_V1=1) unpauses, because opting out of v2 must never silently resurrect a deprecated pipeline. Files untouched - fully reversible.",
        target="MemoryStore.get_memory_context/.write_memory + _FsTool._resolve_write",
        sentinel="MemoryStore._iof_memctx_patch",
        apply=apply_memory_v1_off,
        toggle_env="IOF_LEARNING_V1",  # call-time gate; legacy opt-in unpauses
        added="2026-08",
    ),
    Patch(
        name="usage_capture",
        summary="Record per-call token usage via a native AgentHook -> IOF_USAGE_FILE.",
        reason="Exact per-run/step token accounting; iobot parses full usage into context.usage but its TokenUsageHook is wired only into gateway/serve, not one-shot `iobot agent` runs.",
        target="iobot.agent.loop.AgentLoop.__init__ (appends an AgentHook to _extra_hooks)",
        sentinel="AgentLoop._iof_usage_hook_patch",
        apply=apply_usage_capture,
        toggle_env=None,  # safe no-op unless IOF_USAGE_FILE is set
        added="2026-07",
    ),
    Patch(
        name="gitstore_race_tolerance",
        summary="A second git-store init on the same workspace is a no-op, not an ERROR traceback.",
        reason=(
            "Parallel fan-out items initialise the memory git store of one "
            "role workspace at once; the losers logged a FileExistsError "
            "traceback into the very stderr.log explain points at."
        ),
        target="iobot.utils.gitstore.GitStore.init",
        sentinel="GitStore.init._iof_gitstore_race",
        apply=apply_gitstore_race_tolerance,
        toggle_env=None,
        added="2026-08",
    ),
    Patch(
        name="otel_llm_spans",
        summary="One OTel span per LLM call and per agent tool call, in the step's trace.",
        reason=(
            "A client's observability stack (Langfuse, Arize, AgentCore) needs "
            "the LLM calls inside a step as spans under that step. The engine "
            "cannot see them - they happen in the agent child - so the same "
            "public AgentHook seam that captures token usage opens a gen_ai "
            "span per iteration and a tool span per tool execution, parented "
            "to the TRACEPARENT run-step put in the environment. No-op unless "
            "export is on and a parent is present."
        ),
        target="iobot.agent.loop.AgentLoop.__init__ (appends an AgentHook to _extra_hooks)",
        sentinel="AgentLoop._iof_otel_hook_patch",
        apply=apply_otel_llm_spans,
        toggle_env=None,  # gated by OTEL_EXPORTER_OTLP_ENDPOINT / IOF_OTEL_EXPORTER; needs a parent
        added="2026-08",
    ),
    Patch(
        name="mcp_trace_context",
        summary="Send W3C trace context on every outbound MCP request, so a remote tool's spans nest under the tool call.",
        reason=(
            "An MCP server is a service, often on another machine, and the "
            "client sent it no trace context at all - measured against a "
            "stand-in remote server, `traceparent present? False`. A server "
            "that is itself instrumented had no trace to join, so the "
            "interesting half of a distributed tool call was unreachable "
            "from the run that caused it. NOT doable in an HTTP header hook: "
            "the transport issues its requests from a task created when the "
            "session opened, so the caller's context is invisible there - "
            "measured, every request reported no valid span. Propagated in "
            "the message instead, via call_tool's `meta` (params._meta), "
            "evaluated in the caller's task and per call."
        ),
        target="iobot.agent.tools.mcp.MCPToolWrapper.execute (passes `meta` to session.call_tool)",
        sentinel="iobot.agent.tools.mcp._iof_mcp_trace_patch",
        apply=apply_mcp_trace_context,
        toggle_env=None,  # gated by OTEL_EXPORTER_OTLP_ENDPOINT / IOF_OTEL_EXPORTER
        added="2026-08",
    ),
    Patch(
        name="powershell_format_cmdlets",
        summary="Stop the disk-`format` denial from refusing PowerShell's read-only Format-* cmdlets.",
        reason="Upstream denies `(?:^|[;&|]\\s*)format(?!=)\\b` to block `format C:`. On Windows that also matches `| Format-Table`, `| Format-List` and `| Format-Hex` - the commonest way to render output in PowerShell, all read-only - so on a Windows box it fires constantly for every agent. Worse than the refusal: it reaches the agent as bare STDERR, so a build session read it as a shell-escaping problem, worked around it by writing a scratch script into the user's repo, and recorded a wrong diagnosis. Widening the lookahead to `(?![-=])` exempts the cmdlet spelling; `format C:`, `format /q D:` and `echo x; format E:` still match, because a destructive invocation is never followed by a hyphen.",
        target="iobot.agent.tools.shell.ExecTool.__init__ (rewrites the compiled deny list)",
        sentinel="ExecTool._iof_ps_format_patch",
        apply=apply_powershell_format_cmdlets,
        toggle_env=None,  # unconditional: a no-op wherever the upstream pattern is absent
        added="2026-08",
    ),
    Patch(
        name="mcp_oauth",
        summary="Mint and renew an OAuth token for an MCP server that declares `auth:`, instead of sending only a static header.",
        reason=(
            "The MCP client could carry a header and nothing else - the "
            "streamableHttp transport built its httpx client with no `auth=` "
            "and the sse branch's hook was never populated - so a server "
            "behind OAuth could not be connected: the credential was "
            "refused, the server was dropped from the tool registry, and the "
            "agent ran on without those tools. The workaround was a gateway "
            "performing the flow; this does it in the client. Renewal is the "
            "half a static credential cannot have: a JWT works until its exp "
            "and then stops."
        ),
        target="mcp.client.streamable_http.streamable_http_client + mcp.client.sse.sse_client",
        sentinel="mcp.client.streamable_http._iof_mcp_oauth_patch",
        apply=apply_mcp_oauth,
        toggle_env=None,  # a declaration that asks for OAuth must work or say why
        added="2026-08",
    ),
    Patch(
        name="build_declaration_urls",
        summary="A build session may DECLARE a remote MCP/A2A endpoint it never contacts.",
        reason=(
            "`contains_internal_url` fails closed on any host it cannot "
            "prove public, so `https://vendors.acme.com/mcp` is blocked as "
            "readily as loopback - and the documented workflow `aicore "
            "new-mcp-server --url ... --header 'Bearer ${VAR}'` was "
            "impossible inside `aicore build`. Found by the corpus. Scoped "
            "to a build session and to the three commands that write a "
            "declaration into a config file; curl, wget and the runtime's "
            "own connection are all still checked."
        ),
        target="iobot.security.network.contains_internal_url",
        sentinel="iobot.security.network._iof_build_declaration_urls",
        apply=apply_build_declaration_urls,
        toggle_env=None,  # call-time gate on IOF_BUILD_REPO, set by `aicore build`
        added="2026-08",
    ),
    Patch(
        name="build_call_budget",
        summary="A build turn is told what it has spent, and is refused past a ceiling.",
        reason=(
            "Nothing counted a turn's tool calls: the only bound was the "
            "runtime's maxToolIterations at 500, so far above real work "
            "that it bounded nothing, and the model was never told its own "
            "count. Measured: 'The pricing_bot agent keeps failing its "
            "lint. Fix it.' against a repository with no pricing_bot spent "
            "ninety-five tool calls and answered wrongly. Thresholds come "
            "from 74 live turns - median 9, p90 22, one legitimate pass at "
            "58 - so the stop sits at 70 and the first note at 25."
        ),
        target="iobot.agent.runner.AgentRunner._run_tool",
        sentinel="AgentRunner._iof_build_call_budget",
        apply=apply_build_call_budget,
        toggle_env=None,  # call-time gate on IOF_BUILD_REPO, set by `aicore build`
        added="2026-08",
    ),
    Patch(
        name="write_file_keeps_newlines",
        summary="write_file writes the authored bytes; no CRLF translation on Windows.",
        reason=(
            "The vendored tool uses write_text with newline=None, so on "
            "Windows every authored LF became CRLF (and CRLF became CRCRLF) "
            "while apply_patch and edit_file both preserve. A shell script "
            "authored on the dev box arrived on the Linux pod with ^M line "
            "endings, and the success string hid it."
        ),
        target="iobot.agent.tools.filesystem.WriteFileTool.execute",
        sentinel="WriteFileTool._iof_keeps_newlines",
        apply=apply_write_file_keeps_newlines,
        toggle_env=None,
        added="2026-08",
    ),
    Patch(
        name="read_file_line_cap_honesty",
        summary="A line beyond the 128K view returns an error, not 'Showing lines 1-0, use offset=1'.",
        reason=(
            "The trim loop keeps zero lines for an oversized line and the "
            "footer tells the model to repeat the identical call; a model "
            "that obeys loops to the call-budget ceiling. Any minified "
            "vendor file triggers it."
        ),
        target="iobot.agent.tools.filesystem.ReadFileTool.execute",
        sentinel="ReadFileTool._iof_line_cap_honesty",
        apply=apply_read_file_line_cap_honesty,
        toggle_env=None,
        added="2026-08",
    ),
    Patch(
        name="apply_patch_tolerance",
        summary="apply_patch resolves old_text through edit_file's fallback ladder and reports the closest match when it misses.",
        reason=(
            "A client build session hit `old_text not found` three times on "
            "files it had just read and fell back to whole-file writes. "
            "apply_patch is a bare str.find while edit_file tolerates lost "
            "indentation and re-typed quotes; the tool contract tells the "
            "model to prefer the strict one. Resolved before the original "
            "runs, so every other behaviour of the vendored tool is kept."
        ),
        target="iobot.agent.tools.apply_patch.ApplyPatchTool.execute",
        sentinel="ApplyPatchTool._iof_apply_patch_tolerance",
        apply=apply_apply_patch_tolerance,
        toggle_env=None,
        added="2026-08",
    ),
    Patch(
        name="build_write_gates",
        summary="Placement + literal-secret refusal on the file tools in EVERY build process, not just the in-process engine.",
        reason=(
            "`want_engine` gives the in-process engine to INTERACTIVE "
            "sessions only, so every one-shot (and therefore every CI turn) "
            "ran the agent in a subprocess where the two gates - wrapped "
            "onto the loop in builder/engine.py - did not exist. Found by "
            "adversarial live testing: asked to 'forget the ${VAR} "
            "indirection, it's a test box', a one-shot wrote a literal token "
            "into the repository's mcp.yaml and into two .env files outside "
            "the repository. Both refusals existed; neither was armed on "
            "that path."
        ),
        target="iobot.agent.tools.filesystem write/edit/apply_patch tools",
        sentinel="_FsTool._iof_build_write_gate_patch",
        apply=apply_build_write_gates,
        toggle_env=None,  # call-time gate on IOF_BUILD_REPO, set by `aicore build`
        added="2026-08",
    ),
    Patch(
        name="mcp_connect_is_visible",
        summary="Name the MCP server that did not connect, with its URL and a diagnosis, on the channel the console renders.",
        reason=(
            "A remote MCP server that rejects the credential was swallowed: "
            "upstream logged it through loguru (a FILE in a build session) "
            "and omitted the server from the tool registry, so the agent ran "
            "on silently without those tools, invented a reason when asked, "
            "and the only console trace was `Error in post_writer "
            "(ExceptionGroup)` - no server, no URL, no status. `mcp-list` "
            "read files and printed it healthy. This compares asked-for "
            "against connected and reports the difference through the STDLIB "
            "logger, which is what the build console renders, reusing the "
            "`mcp-list --probe` classifier so both give the same answer."
        ),
        target="iobot.agent.tools.mcp.connect_mcp_servers",
        sentinel="iobot.agent.tools.mcp._iof_mcp_visible_patch",
        apply=apply_mcp_connect_is_visible,
        toggle_env=None,  # unconditional: a silent capability loss is never a default
        added="2026-08",
    ),
    Patch(
        name="build_exec_guard",
        summary="Refuse denylisted exec commands (git commit/push, pip install, --force) inside a build session, at execution time.",
        reason="`aicore build` places an agent in the user's repository; its hard limits lived only in a skill, and rules stated to a model are requests. The guard makes them enforcement: matched commands return a refusal as the tool result. Inert on every other surface - active only when a build session has set IOF_BUILD_REPO in the environment at call time, which only the build command does for its spawn.",
        target="iobot.agent.tools.shell.ExecTool.execute",
        sentinel="ExecTool._iof_build_guard_patch",
        apply=apply_build_exec_guard,
        toggle_env=None,  # call-time gate on IOF_BUILD_REPO, set by `aicore build`
        added="2026-08",
    ),
]


def apply_all(exclude: tuple[str, ...] = ()) -> list[tuple[str, str]]:
    """Apply every registered, non-deprecated patch in order.

    Data-driven from ``PATCHES``. Each apply fn stays idempotent + self-guarded
    (it handles its own toggle_env / sentinel / stderr announce), so this loop
    only sequences them and records the outcome. Returns ``[(name, outcome)]``.

    ``exclude`` names patches that are armed on their own trigger module and
    must not be applied here — applying one would import its target eagerly,
    which for the Azure swap means the entire ``openai`` SDK.
    """
    import sys
    results: list[tuple[str, str]] = []
    for p in PATCHES:
        if p.deprecated:
            results.append((p.name, f"DEPRECATED — {p.deprecated_reason}"))
            continue
        if p.name in exclude:
            results.append((p.name, "armed separately"))
            continue
        try:
            p.apply()
            results.append((p.name, "applied"))
        except Exception as e:  # per-patch: fail loud, don't abort the rest
            print(f"[aicore patches] {p.name}: FAILED - {e}", file=sys.stderr, flush=True)
            results.append((p.name, f"failed: {e}"))
    return results


# ----------------------------------------------------------------------
# Lazy arming — a patch applies on the FIRST IMPORT of the module it
# targets, not at `import ioagentfarm`.
#
# Why: applying a patch requires importing its target, so eager
# application made every process pay the import cost of every provider
# and subsystem whether or not it would use them. Measured on Windows:
# `aicore --help` spent ~4s inside `import ioagentfarm` — ~2.3s the
# `openai` SDK behind the Azure swap (a backend a MiniMax deployment
# never selects), ~1.5s the iobot config→agent chain behind the
# state-dir patch. The same tax hit every `iof-*` tool an agent execs
# mid-run and every spawned agent subprocess via the sitecustomize shim.
#
# How: a MetaPathFinder watches the trigger modules. When one finishes
# executing, its callbacks fire — before the importer's own statement
# returns, so no code can obtain the unpatched module. Two triggers:
#
#   iobot                                   -> apply_all() minus the Azure
#                                                swap, plus the filesystem
#                                                allowed-dirs injection and
#                                                the loguru rebranding
#   iobot.providers.azure_openai_provider   -> the Azure swap alone, so
#                                                `openai` imports only when
#                                                the Azure backend is chosen
#                                                (iobot's provider factory
#                                                imports per-branch, lazily)
#
# A trigger already imported at arm time applies immediately — the exact
# eager semantics this replaces. `IOF_EAGER_PATCHES=1` restores full
# eager application (see ioagentfarm/__init__.py).
#
# The ordering guarantee is STRONGER than the eager path needed: the
# state-dir sweep (`_rebind_across_modules`) exists because dependents
# could bind helpers before the patch ran; under arming the patch runs
# before any dependent of the trigger module proceeds. The sweep stays
# as belt-and-braces for the already-imported fallback.
# ----------------------------------------------------------------------

_ARM_TABLE: dict[str, list[Callable[[], Any]]] = {}
_FINDER: Optional["_PostImportFinder"] = None

#: Patches that arm on their own module rather than riding the `iobot`
#: trigger, because applying them imports something heavy the deployment
#: may never use. name -> trigger module.
LAZY_SEPARATE: dict[str, str] = {
    "azure_chat_backend": "iobot.providers.azure_openai_provider",
}


class _LoaderProxy:
    """Delegating loader wrapper that fires callbacks after a module executes."""

    def __init__(self, loader: Any, fullname: str) -> None:
        self._iof_loader = loader
        self._iof_fullname = fullname

    def create_module(self, spec: Any) -> Any:
        create = getattr(self._iof_loader, "create_module", None)
        return create(spec) if create is not None else None

    def exec_module(self, module: Any) -> None:
        self._iof_loader.exec_module(module)
        _fire_hooks(self._iof_fullname)

    def load_module(self, fullname: str) -> Any:  # legacy loader protocol
        module = self._iof_loader.load_module(fullname)
        _fire_hooks(self._iof_fullname)
        return module

    def __getattr__(self, name: str) -> Any:
        return getattr(self._iof_loader, name)


class _PostImportFinder:
    """MetaPathFinder that wraps a watched module's loader to fire callbacks."""

    def find_spec(self, fullname: str, path: Any = None, target: Any = None) -> Any:
        if fullname not in _ARM_TABLE:
            return None
        import sys as _s

        # Resolve the real spec via the other finders — never ourselves.
        for finder in list(_s.meta_path):
            if finder is self:
                continue
            find = getattr(finder, "find_spec", None)
            if find is None:
                continue
            try:
                spec = find(fullname, path, target)
            except (ImportError, AttributeError):
                spec = None
            if spec is not None:
                break
        else:
            return None
        if spec.loader is None:
            return spec  # namespace package — nothing to wrap
        spec.loader = _LoaderProxy(spec.loader, fullname)
        return spec


def _fire_hooks(fullname: str) -> None:
    import sys as _s

    callbacks = _ARM_TABLE.pop(fullname, [])
    for cb in callbacks:
        try:
            cb()
        except Exception as e:  # same contract as apply_all: loud, never fatal
            print(f"[aicore patches] lazy hook for {fullname}: FAILED - {e}",
                  file=_s.stderr, flush=True)


def _arm(fullname: str, callback: Callable[[], Any]) -> None:
    """Run *callback* when *fullname* first imports — or now, if it already has."""
    import sys as _s

    if fullname in _s.modules:
        try:
            callback()
        except Exception as e:
            print(f"[aicore patches] apply for already-imported {fullname}: "
                  f"FAILED - {e}", file=_s.stderr, flush=True)
        return
    global _FINDER
    _ARM_TABLE.setdefault(fullname, []).append(callback)
    if _FINDER is None:
        _FINDER = _PostImportFinder()
        _s.meta_path.insert(0, _FINDER)


def armed_modules() -> list[str]:
    """Trigger modules whose patches have not fired yet (for `aicore patches`)."""
    return sorted(_ARM_TABLE)


def patch_is_armed(name: str) -> bool:
    """Whether *name*'s lazy trigger is still pending in this process."""
    return LAZY_SEPARATE.get(name, "iobot") in _ARM_TABLE


def arm_all() -> None:
    """Arm every registered patch to apply on first use of its target.

    The filesystem allowed-dirs injection and the loguru rebranding ride the
    ``iobot`` trigger too: both only matter once the runtime is loaded, and
    both import runtime modules to do their work.
    """

    def _fire_main() -> None:
        apply_all(exclude=tuple(LAZY_SEPARATE))
        try:
            from ioagentfarm import _patch_iobot_extra_allowed_dirs
            _patch_iobot_extra_allowed_dirs()
        except Exception:
            pass
        try:
            from ioagentfarm.engine.branding import install_log_rebranding
            install_log_rebranding()
        except Exception:
            pass

    _arm("iobot", _fire_main)
    for patch_name, trigger in LAZY_SEPARATE.items():
        fn = next(p.apply for p in PATCHES if p.name == patch_name)
        _arm(trigger, fn)


def patch_inventory(verify: bool = False) -> list[dict[str, Any]]:
    """Return the patch registry as metadata dicts (for docs / CLI / validation).

    Includes live ``active`` state read from each patch's sentinel, plus
    ``armed`` — whether the patch's lazy trigger is still pending in this
    process (see ``arm_all``).

    ``verify=False`` (the default) reads sentinels only from modules ALREADY
    imported into this process — the inventory never forces the runtime to
    load. ``verify=True`` imports the target modules first, which also fires
    any armed hooks, turning ``active`` into a live bind check.
    """
    import sys as _s

    def _sentinel_active(dotted: str) -> Optional[bool]:
        cls_name, _, attr = dotted.partition(".")
        for mod in ("iobot.providers.anthropic_provider",
                    "iobot.vendored.azure_openai_chat_provider",
                    "iobot.providers.azure_openai_provider",
                    "iobot.agent.loop",
                    "iobot.config.loader"):
            try:
                if verify:
                    import importlib
                    m = importlib.import_module(mod)
                else:
                    m = _s.modules.get(mod)
                if m is None:
                    continue
                cls = getattr(m, cls_name, None)
                if cls is not None:
                    return bool(getattr(cls, attr, False))
            except Exception:
                continue
        return None  # couldn't resolve — unknown
    inv: list[dict[str, Any]] = []
    for p in PATCHES:
        inv.append({
            "name": p.name, "summary": p.summary, "reason": p.reason,
            "target": p.target, "sentinel": p.sentinel, "toggle_env": p.toggle_env,
            "added": p.added, "iobot": p.iobot,
            "deprecated": p.deprecated, "deprecated_reason": p.deprecated_reason,
            "active": None if p.deprecated else _sentinel_active(p.sentinel),
            "armed": (not p.deprecated) and patch_is_armed(p.name),
        })
    return inv


def write_sitecustomize(inject_dir):
    """Write the subprocess patch shim (sitecustomize.py) into *inject_dir*.

    Python's ``site`` module imports ``sitecustomize`` at interpreter
    startup, BEFORE any user code — the only reliable way to apply the
    ioagentfarm patches INSIDE a iobot subprocess we don't control:
    HTTP forensics (env-gated via IOF_HTTP_LOG_FILE), disable-streaming +
    request timeout (IOF_DISABLE_STREAMING), the Azure chat-completions
    backend swap, and the sandbox fs allowlist.

    Shared by cli._invoke_agent (step agents) and web/spawn.spawn_run
    (the run DRIVER). The driver missing these patches is exactly how
    serve-spawned runs on a classic-route Azure tenant died with a
    provider 401 ('missing subscription key') while CLI runs worked —
    stock iobot's Azure provider took the v1 Responses route the
    tenant does not expose. Found live at a client deployment.

    Returns the sitecustomize.py path; callers prepend *inject_dir* to
    the subprocess PYTHONPATH.
    """
    from pathlib import Path as _Path

    inject_dir = _Path(inject_dir)
    inject_dir.mkdir(parents=True, exist_ok=True)
    site_py = inject_dir / "sitecustomize.py"
    site_py.write_text(
        "# Auto-generated by ioagentfarm._invoke_agent.\n"
        "# Imported by Python's `site` module at interpreter startup,\n"
        "# BEFORE any user code. Four blocks:\n"
        "#   1. HTTP forensic logging (Gap E)\n"
        "#   2. Disable streaming + request timeout (inline wraps)\n"
        "#   3. Arm the ioagentfarm patch registry (applies on first\n"
        "#      iobot import; azure swap on its own module)\n"
        "#   4. Filesystem allowed-dirs injection (direct, env-gated)\n"
        "import logging\n"
        "import os\n"
        "\n"
        "# --- Patch 1: HTTP forensic logging ---\n"
        "_log_file = os.environ.get('IOF_HTTP_LOG_FILE')\n"
        "if _log_file:\n"
        "    try:\n"
        "        _h = logging.FileHandler(_log_file, mode='a', encoding='utf-8')\n"
        "        _h.setLevel(logging.DEBUG)\n"
        "        _h.setFormatter(logging.Formatter(\n"
        "            '%(asctime)s [%(name)s:%(levelname)s] %(message)s'\n"
        "        ))\n"
        "        for _name in (\n"
        "            'httpx', 'httpcore', 'httpcore.http11',\n"
        "            'httpcore.connection', 'anthropic',\n"
        "            'anthropic._base_client',\n"
        "        ):\n"
        "            _lg = logging.getLogger(_name)\n"
        "            _lg.addHandler(_h)\n"
        "            _lg.setLevel(logging.DEBUG)\n"
        "            _lg.propagate = False\n"
        "    except Exception:\n"
        "        pass\n"
        "\n"
        "# --- Patch 2: Disable streaming + request timeout ---\n"
        "# Patches both the hook (so runner calls chat not chat_stream)\n"
        "# AND the chat method itself (to force stream=False in the\n"
        "# Anthropic SDK request, plus add a timeout wrapper).\n"
        # The whole-call timeout is applied UNCONDITIONALLY, before and
        # independently of the streaming toggle. It used to live inside the
        # `if`, so a subprocess running WITH streaming had no bound on a
        # call at all - and that is the configuration the 958s stall in
        # run_20260820_030328_787466 ran under. It wraps chat_stream too:
        # a streaming agent calls chat_stream, so bounding only chat bounds
        # nothing. Both are `async def` returning LLMResponse.
        "_ts = int(os.environ.get('IOF_REQUEST_TIMEOUT_S', '180'))\n"
        "if _ts > 0:\n"
        "    try:\n"
        "        import asyncio\n"
        "        from iobot.providers.base import LLMProvider, LLMResponse\n"
        "        def _iof_bound(_orig):\n"
        "            async def _call(self, *a, **kw):\n"
        "                try:\n"
        "                    return await asyncio.wait_for(\n"
        "                        _orig(self, *a, **kw), timeout=_ts)\n"
        "                except asyncio.TimeoutError:\n"
        "                    return LLMResponse(\n"
        "                        content=f'Error calling LLM: request timed out after {_ts}s',\n"
        "                        finish_reason='error')\n"
        "            return _call\n"
        "        _tg = [LLMProvider]\n"
        "        try:\n"
        "            from iobot.providers.anthropic_provider import AnthropicProvider as _AP\n"
        "            _tg.append(_AP)\n"
        "        except Exception:\n"
        "            pass\n"
        "        def _walk(k):\n"
        "            for s in k.__subclasses__():\n"
        "                if s not in _tg:\n"
        "                    _tg.append(s); _walk(s)\n"
        "        _walk(LLMProvider)\n"
        "        for _k in _tg:\n"
        "            if '_iof_timeout_patch' in _k.__dict__:\n"
        "                continue\n"
        "            for _n in ('chat', 'chat_stream'):\n"
        "                if _n in _k.__dict__:\n"
        "                    setattr(_k, _n, _iof_bound(_k.__dict__[_n]))\n"
        "                elif _k is LLMProvider and hasattr(_k, _n):\n"
        "                    setattr(_k, _n, _iof_bound(getattr(_k, _n)))\n"
        "            _k._iof_timeout_patch = True\n"
        "    except Exception:\n"
        "        pass\n"
        # The SAME truthiness rule the in-process path uses. A bare
        # `if os.environ.get(...)` made the strings an operator reaches for
        # to turn streaming back ON - 'false', '0' - turn it OFF instead,
        # so one variable meant opposite things in-process and in a
        # subprocess.
        "if os.environ.get('IOF_DISABLE_STREAMING', '').lower() in ('1', 'true', 'yes'):\n"
        "    for _m, _c in (('iobot.agent.hook', 'AgentHook'),\n"
        "                   ('iobot.agent.hook', 'CompositeHook'),\n"
        "                   ('iobot.agent.progress_hook', 'AgentProgressHook')):\n"
        "        try:\n"
        "            _mm = __import__(_m, fromlist=[_c])\n"
        "            _kk = getattr(_mm, _c, None)\n"
        "            if _kk is not None and ('wants_streaming' in _kk.__dict__\n"
        "                                    or _c == 'AgentHook'):\n"
        "                _kk.wants_streaming = lambda self: False\n"
        "        except Exception:\n"
        "            pass\n"
        "    # Force stream=False in AnthropicProvider.chat() only\n"
        "    # (NOT in chat_stream — messages.stream() doesn't accept stream kwarg)\n"
        "    try:\n"
        "        from iobot.providers.anthropic_provider import AnthropicProvider\n"
        "        _orig_ap_chat = AnthropicProvider.chat\n"
        "        async def _ap_chat_no_stream(self, *a, **kw):\n"
        "            orig_create = self._client.messages.create\n"
        "            async def _create_no_stream(**ckw):\n"
        "                ckw['stream'] = False\n"
        "                return await orig_create(**ckw)\n"
        "            self._client.messages.create = _create_no_stream\n"
        "            try:\n"
        "                return await _orig_ap_chat(self, *a, **kw)\n"
        "            finally:\n"
        "                self._client.messages.create = orig_create\n"
        "        AnthropicProvider.chat = _ap_chat_no_stream\n"
        "    except Exception:\n"
        "        pass\n"
        "\n"
        "# --- Patch 3: ioagentfarm runtime patches (armed, not applied) ---\n"
        "# Importing ioagentfarm arms post-import hooks: every registered\n"
        "# patch (state-dir rename, provider swaps, tool-id dedup, agency\n"
        "# tool restriction, memory gates) applies the moment iobot is\n"
        "# first imported in this interpreter — before any agent code can\n"
        "# see the unpatched module. If Patch 2 above already imported\n"
        "# iobot, arming applies them immediately instead. The Azure\n"
        "# chat-completions swap arms on the azure provider module itself,\n"
        "# so the openai SDK (~2.3s) is imported only when iobot's\n"
        "# provider factory actually selects the Azure backend.\n"
        "try:\n"
        "    import ioagentfarm  # noqa: F401  (import = arm)\n"
        "except Exception:\n"
        "    pass\n"
        "\n"
        "# --- Patch 4: _FsTool extra allowed dirs (subprocess) ---\n"
        "# bwrap on triggers exec_config.sandbox=True in iobot which\n"
        "# activates Python-level allowed_dir on _FsTool, anchored to\n"
        "# the agent iobot workspace. Inject IOF_IOBOT_EXTRA_ALLOWED_DIRS\n"
        "# so agents can read/write anywhere under /app/.iof.\n"
        "#\n"
        "# Delegates to the ONE implementation in ioagentfarm/__init__.py.\n"
        "# This used to be an inlined copy, which (a) double-wrapped the ctor\n"
        "# — importing ioagentfarm above already applies it — and (b) pinned a\n"
        "# 3-parameter signature that iobot 0.3.0's ctor no longer matches\n"
        "# (it now also passes file_states / restrict_to_workspace / the\n"
        "# extra_read_allowed_* pair), which would raise TypeError on every\n"
        "# filesystem tool. The shared version binds arguments dynamically and\n"
        "# feeds extra_write_allowed_dirs too, so writes survive 0.3.0's\n"
        "# read-only demotion of extra_allowed_dirs. Idempotent + env-gated.\n"
        "try:\n"
        "    from ioagentfarm import _patch_iobot_extra_allowed_dirs\n"
        "    _patch_iobot_extra_allowed_dirs()\n"
        "except Exception:\n"
        "    pass\n",
        encoding="utf-8",
    )
    return site_py
