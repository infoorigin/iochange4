"""``aicore feedback`` - what people said about chat replies.

    aicore feedback list   [--since 7d] [--agent <role>] [--signal up|down|correction] [--json]
    aicore feedback export --out feedback.jsonl [--since ...] [--agent ...] [--all-workspaces]

Reads the ``message_feedback`` table of the selected workspace's database
through the CLI's own resolvers, so local mode and the workspace ``.env``
apply as everywhere. Storage: ``engine/feedback.py``.
"""
from __future__ import annotations

import json
import os
from typing import Optional

import typer

feedback_app = typer.Typer(
    name="feedback",
    help="End-user feedback on chat replies: list it, summarise it, export it.",
    no_args_is_help=True,
)

_WS = typer.Option(None, "--workspace", "-w", help="Workspace code (default: the selection in force).")
_SINCE = typer.Option(None, "--since", help="ISO date/time, or a window: 7d, 24h, 30m.")
_AGENT = typer.Option(None, "--agent", help="Only feedback on this agent role.")
_SIGNAL = typer.Option(None, "--signal", help="Only this signal: up, down or correction.")
_JSON = typer.Option(False, "--json", help="Machine-readable output.")


def _ctx(workspace: Optional[str]):
    from ioagentfarm import cli as _cli
    from ioagentfarm.engine.workspaces import RETIRED_WORKSPACE_CODES, selected_workspace
    code = selected_workspace(workspace)[0]
    if not code:
        raise typer.BadParameter(
            "no workspace selected: pass --workspace <code>, set IOF_WORKSPACE, "
            "or run `aicore workspace use <code>`")
    if code in RETIRED_WORKSPACE_CODES:
        raise typer.BadParameter(f"'{code}' is not a selectable workspace")
    from ioagentfarm.engine.workspace_env import load_workspace_env
    load_workspace_env(code)
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace
    store = _cli._store(_cli._root())
    return store, code


def _since_or_die(since: Optional[str]) -> Optional[str]:
    from ioagentfarm.engine.feedback import FeedbackError, parse_since
    try:
        return parse_since(since)
    except FeedbackError as exc:
        raise typer.BadParameter(str(exc))


@feedback_app.command("list")
def list_cmd(workspace: Optional[str] = _WS, since: Optional[str] = _SINCE,
             agent: Optional[str] = _AGENT, signal: Optional[str] = _SIGNAL,
             limit: int = typer.Option(50, "--limit", help="Newest N rows."),
             as_json: bool = _JSON):
    """List feedback rows, newest first, with the counts by signal and agent."""
    from ioagentfarm.engine import feedback as fb
    store, code = _ctx(workspace)
    since_iso = _since_or_die(since)
    try:
        rows = fb.list_feedback(store, workspace=code, since=since_iso,
                                agent=agent, signal=signal, limit=limit)
    except fb.FeedbackError as exc:
        raise typer.BadParameter(str(exc))
    summ = fb.summary(store, workspace=code, since=since_iso)
    if as_json:
        typer.echo(json.dumps({"workspace": code, "since": since_iso,
                               "rows": rows, "summary": summ}, indent=2, default=str))
        return
    typer.echo(f"feedback in workspace '{code}'"
               + (f" since {since_iso}" if since_iso else "") + ":")
    typer.echo(f"  total {summ['total']}  up {summ['by_signal']['up']}"
               f"  down {summ['by_signal']['down']}"
               f"  correction {summ['by_signal']['correction']}")
    for a in summ["by_agent"]:
        typer.echo(f"  agent {a['agent'] or '(unattributed)':<24} up {a['up']:<4} "
                   f"down {a['down']:<4} correction {a['correction']:<4}")
    if not rows:
        typer.echo("  (no rows)")
        return
    typer.echo("")
    typer.echo(f"  {'id':>5}  {'created_at':<25} {'signal':<10} {'agent':<16} {'user':<20} target")
    for r in rows:
        target = r["item_id"] or (f"messages#{r['message_id']}" if r["message_id"] else "-")
        line = (f"  {r['id']:>5}  {r['created_at']:<25} {r['signal']:<10} "
                f"{(r['agent'] or '-')[:16]:<16} {(r['user_id'] or '-')[:20]:<20} {target}")
        if r["comment"]:
            line += f"  \"{r['comment'][:60]}\""
        typer.echo(line)


@feedback_app.command("export")
def export_cmd(out: str = typer.Option(..., "--out", help="Path of the JSONL file to write."),
               workspace: Optional[str] = _WS, since: Optional[str] = _SINCE,
               agent: Optional[str] = _AGENT, signal: Optional[str] = _SIGNAL,
               all_workspaces: bool = typer.Option(
                   False, "--all-workspaces",
                   help="Export every workspace in this database, not only the selected one.")):
    """Write feedback rows as JSON lines (one object per line), oldest first."""
    from ioagentfarm.engine import feedback as fb
    store, code = _ctx(workspace)
    since_iso = _since_or_die(since)
    try:
        rows = fb.list_feedback(store, workspace=None if all_workspaces else code,
                                since=since_iso, agent=agent, signal=signal,
                                limit=1_000_000)
    except fb.FeedbackError as exc:
        raise typer.BadParameter(str(exc))
    n = fb.export_jsonl(reversed(rows), out)
    typer.echo(f"wrote {n} row(s) to {out}")
