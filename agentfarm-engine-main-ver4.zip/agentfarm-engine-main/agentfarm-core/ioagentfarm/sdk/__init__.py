"""The tool-side SDK: what a deterministic tool says back to the engine.

Sugar over the stdout protocol, never a second contract. Everything here
prints a `KEY: value` line the engine already parses (`engine/protocol.py`),
so a tool written in another language reaches the same behaviour by printing
the same line. The SDK exists so a Python tool does not have to remember the
spelling.

    from ioagentfarm.sdk import route
    route.next("step4")                     # a route step chooses its successor
    route.fail("critique text")             # a gate rejects; upstream re-runs

See `route` for what each does and what the workflow must declare for it.
"""
from ioagentfarm.sdk import route  # noqa: F401

__all__ = ["route"]
