"""Observability from inside a tool - attributes, events, metrics, spans.

Every exec tool a workflow runs is already inside a trace when export is on:
`run-step` puts the step span's W3C `traceparent` in the environment, and on
first use this module opens an `aicore.tool` span under it for the life of
the process. What a developer adds lands on that span - visible in Langfuse,
Arize, Phoenix, AWS AgentCore, whatever OTLP backend the deployment names -
beside the engine's own spans, in the same trace as the run.

    from ioagentfarm.sdk import obs

    obs.attr("cards.planned", len(cards))               # attribute on my span
    obs.event("registry.validated", unknown=0)          # a timestamped event
    obs.metric("fv.rows_fetched", n, unit="{row}")      # a histogram point
    obs.metric("fv.warehouse_errors", 1, kind="counter")
    with obs.span("warehouse.query", pair=label):       # a child span
        rows = run_sql(...)

Everything is a no-op when export is off (no OTEL_EXPORTER_OTLP_ENDPOINT)
or the `agentfarm-core[otel]` extra is not installed, so a tool written with
these calls runs unchanged on a box with no observability at all. The calls
never raise: a broken exporter must not fail a step.

Standard OTel underneath - a developer who prefers the raw API can use
`opentelemetry.trace.get_current_span()` directly; it is the same span.

WHAT AN AGENT-EXEC'D TOOL SEES. A tool the agent runtime execs (as opposed to
a `type: exec` step) starts with a stripped environment, but `TRACEPARENT` is
in `PASSTHROUGH_ENV_KEYS`, so it inherits the step's context and its span
joins the run's trace. That value is the STEP span's traceparent - set once
for the agent child, never rewritten per tool call - so the span parents to
the step and sits BESIDE the `aicore.agent_tool` span for the same exec
rather than beneath it. `aicore.run_id` is carried too, so a backend can
join on the attribute either way.
"""
from __future__ import annotations

import atexit
import threading
import os
import sys
import time
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional

_root = None            # the tool's own span, opened on first use
_root_token = None
_hists: Dict[str, Any] = {}
_counters: Dict[str, Any] = {}
_init_done = False


def _export():
    try:
        from ioagentfarm.engine import otel_export as ex
        return ex if (ex.available() and ex.enabled()) else None
    except Exception:  # noqa: BLE001
        return None


_init_lock = threading.Lock()


def _init() -> bool:
    """Open the tool span under the step's traceparent. Once per process.

    Under a lock: a tool whose FIRST obs call happens on eight pool threads
    at once (fv_compute's per-query spans) used to race here - the first
    thread flipped `_init_done` and the other seven read "done, no root"
    and yielded no span at all. Nine queries, two spans exported.
    """
    global _root, _root_token, _init_done
    if _init_done:
        return _root is not None
    with _init_lock:
        if _init_done:
            return _root is not None
        return _init_locked()


def _init_locked() -> bool:
    """The work of `_init`, under its lock.

    `_init_done` is published LAST. The fast path in `_init` reads it
    without the lock, so a flag set before the root span exists lets a
    racing thread read "done, no root" and yield no span - which is what
    the lock alone did not fix: nine queries on eight threads, one span.
    """
    global _root, _root_token, _init_done
    try:
        ex = _export()
        if ex is None:
            return False
        try:
            from opentelemetry import trace
            from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
            tracer = ex.tracer()
            if tracer is None:
                return False
            carrier = {}
            tp = os.environ.get("TRACEPARENT")
            if tp:
                carrier["traceparent"] = tp
            parent = TraceContextTextMapPropagator().extract(carrier) if carrier else None
            name = os.path.basename(sys.argv[0] or "tool").replace(".exe", "").replace(".py", "")
            attrs = {"openinference.span.kind": "TOOL", "aicore.tool.argv": " ".join(sys.argv[1:])[:500]}
            for env, key in (("IOF_RUN_ID", "aicore.run_id"), ("IOF_STEP_KEY", "aicore.step_key")):
                if os.environ.get(env):
                    attrs[key] = os.environ[env]
            root = tracer.start_span(f"aicore.tool {name}", context=parent, attributes=attrs)
            _root = root
            _root_token = trace.context_api.attach(trace.set_span_in_context(root))
            atexit.register(_close)
            return True
        except Exception:  # noqa: BLE001
            _root = None
            return False
    finally:
        _init_done = True


_closed = False


def _close() -> None:
    global _closed
    if _closed:
        return
    _closed = True
    ex = _export()
    try:
        if _root is not None:
            from opentelemetry.trace import Status, StatusCode
            code = getattr(sys, "last_value", None)
            if code is not None:
                _root.set_status(Status(StatusCode.ERROR, type(code).__name__))
            _root.end()
    except Exception:  # noqa: BLE001
        pass
    if ex is not None:
        ex.flush()


def _span():
    if not _init():
        return None
    try:
        from opentelemetry import trace
        s = trace.get_current_span()
        return s if s.get_span_context().is_valid else _root
    except Exception:  # noqa: BLE001
        return None


# --------------------------------------------------------------------------
# the API
# --------------------------------------------------------------------------

def attr(key: str, value: Any) -> None:
    """Set an attribute on the active span.

    EXPORTED AS WRITTEN. `IOF_OTEL_CONTENT` governs the message bodies the
    ENGINE records - a step's goal, an agent turn's input and output - and
    does not apply to what a tool passes here. Record identifiers, counts and
    outcomes; treat a value read from source data as content until you know
    otherwise.
    """
    s = _span()
    if s is None:
        return
    try:
        s.set_attribute(str(key), _scalar(value))
    except Exception:  # noqa: BLE001
        pass


def attrs(**kv: Any) -> None:
    for k, v in kv.items():
        attr(k, v)


def event(name: str, **attributes: Any) -> None:
    """Add a timestamped event to the active span.

    Its attributes are exported as written - see `attr`.
    """
    s = _span()
    if s is None:
        return
    try:
        s.add_event(str(name), attributes={k: _scalar(v) for k, v in attributes.items()})
    except Exception:  # noqa: BLE001
        pass


def metric(name: str, value: float, *, unit: str = "", kind: str = "histogram",
           **attributes: Any) -> None:
    """Record a metric point. `kind` is "histogram" (default) or "counter".

    Names are yours; prefix them with your solution so they do not collide
    with `aicore.*` and `gen_ai.*`. Attributes become metric dimensions -
    keep their cardinality low (a step key, a brand; never a run id).

    VALUES ARE EXPORTED AS WRITTEN. `IOF_OTEL_CONTENT` governs the message
    bodies the ENGINE records; it does not apply here. Record identifiers,
    counts and outcomes - not customer text, personal data or credentials.

    A deployment whose platform takes traces only (Phoenix, for one) sets
    `OTEL_METRICS_EXPORTER=none`, and a point recorded then reaches nobody.
    That used to be silent; it now says so once, on stderr.
    """
    ex = _export()
    if ex is None or ex.meter() is None:
        return
    if not _metrics_reach_anyone(ex, name):
        return
    try:
        m = ex.meter()
        tags = {k: _scalar(v) for k, v in attributes.items()}
        if os.environ.get("IOF_STEP_KEY"):
            tags.setdefault("aicore.step_key", os.environ["IOF_STEP_KEY"])
        if kind == "counter":
            inst = _counters.get(name)
            if inst is None:
                inst = _counters[name] = m.create_counter(name, unit=unit)
            inst.add(value, tags)
        else:
            inst = _hists.get(name)
            if inst is None:
                inst = _hists[name] = m.create_histogram(name, unit=unit)
            inst.record(value, tags)
    except Exception:  # noqa: BLE001
        pass


_warned_metrics_off = False


def _metrics_reach_anyone(ex: Any, name: str) -> bool:
    """False when this point would be recorded and then go nowhere.

    A METRIC THAT VANISHES MUST NOT VANISH QUIETLY. With
    `OTEL_METRICS_EXPORTER=none` the meter provider is built with no readers,
    so `meter()` still hands back a live meter and every `metric()` call
    succeeds into an instrument nothing reads. A developer following the
    deployment guidance for a traces-only platform - which is the documented
    setting for Phoenix - therefore loses their solution's own metrics with
    no error, no log line, and working code.

    Said once per process, naming the variable and the way out, because the
    developer who needs it is reading their own tool's output.
    """
    global _warned_metrics_off
    try:
        if ex.metrics_enabled():
            return True
    except Exception:  # noqa: BLE001 - an older engine: assume they land
        return True
    if not _warned_metrics_off:
        _warned_metrics_off = True
        try:
            print(f"[obs] metric {name!r} recorded nothing: "
                  "OTEL_METRICS_EXPORTER=none disables metrics for this "
                  "deployment. Traces, spans, attributes and events are "
                  "unaffected. To keep metrics, send them to a collector "
                  "that accepts them with OTEL_EXPORTER_OTLP_METRICS_ENDPOINT.",
                  file=sys.stderr, flush=True)
        except Exception:  # noqa: BLE001 - never fail a tool over a warning
            pass
    return False


@contextmanager
def span(name: str, *, kind: str = "CHAIN", **attributes: Any) -> Iterator[Optional[Any]]:
    """A child span for a unit of work inside the tool.

    `kind` is the OpenInference span kind Arize and Phoenix categorise on -
    CHAIN (a unit of work, the default), TOOL, LLM, RETRIEVER. Without it
    these arrived as `UNKNOWN` and a backend could show them but not classify
    them; `gen_ai.*` has no equivalent field, so this attribute is the whole
    of what a viewer has to go on."""
    ex = _export()
    if ex is None or not _init() or ex.tracer() is None:
        yield None
        return
    try:
        from opentelemetry import trace
        from opentelemetry.trace import Status, StatusCode
        tracer = ex.tracer()
        # A worker thread has no current span (context is thread-local), so
        # a span opened there would become a new ROOT and float outside the
        # run's trace. Parent it to the tool's own span explicitly then - a
        # thread-pool fan-out inside a tool is the common case, not the edge.
        _ctx = None
        _cur = trace.get_current_span()
        if _cur is None or not _cur.get_span_context().is_valid:
            _root = _span()
            if _root is not None:
                _ctx = trace.set_span_in_context(_root)
        _attrs = {k: _scalar(v) for k, v in attributes.items()}
        if kind:
            _attrs.setdefault("openinference.span.kind", str(kind).upper())
        with tracer.start_as_current_span(
                str(name), context=_ctx, attributes=_attrs) as s:
            try:
                yield s
            except BaseException as e:  # noqa: BLE001 - record, then re-raise
                s.set_status(Status(StatusCode.ERROR, type(e).__name__))
                s.record_exception(e)
                raise
    except Exception:  # noqa: BLE001 - exporter trouble must not fail the tool
        yield None


def traceparent() -> Optional[str]:
    """The W3C `traceparent` of the current unit of work - this tool's span
    (or the child span open right now), else the one the step handed the
    process. For an outbound call (A2A `iof-consult`, an HTTP client) so the
    callee joins this trace."""
    try:
        if _init():
            s = _span()
            if s is not None:
                sc = s.get_span_context()
                if sc.is_valid:
                    return f"00-{sc.trace_id:032x}-{sc.span_id:016x}-01"
    except Exception:  # noqa: BLE001
        pass
    return os.environ.get("TRACEPARENT") or None


def enabled() -> bool:
    """Is anything going to leave this process? For a tool that wants to
    skip building expensive attributes when nobody is listening."""
    return _export() is not None


def _scalar(v: Any) -> Any:
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    return str(v)[:500]
