"""Routing from inside a tool - the data-dependent turn, fenced.

A `type: route` step declares the universe of turns it can take:

    - key: triage
      type: route
      command: iof-x-triage --out {{output_dir}}
      routes: [deep_dive, quick_note, escalate]

and the tool picks, at runtime, which of THOSE run:

    from ioagentfarm.sdk import route
    route.next("deep_dive")                # or several: route.next("a", "b")
    route.next()                           # none - every route is skipped

That is a `switch`, not a `goto`. The tool chooses among declared targets and
cannot invent one: a name outside `routes:` fails the step, by name. So the
set of paths a workflow can take stays a static question - lint can check
every target exists and every step is reachable - while WHICH path is taken
is decided by data. For a real business process that is Temporal's `if`
without Temporal's invisibility: the branches are in the YAML.

A gate that wants the work redone uses `fail`:

    - key: verify
      type: exec
      deps: [draft]
      on_fail: { reset: [draft], feedback: critique.md }

    route.fail("Section 3 cites a figure not in the evidence.")

which writes the critique and exits non-zero. The engine sends `draft` (and
everything downstream of it that already ran) back to pending, puts the text
in draft's "Feedback from previous attempt", and gives verify another attempt
at the fresh result. Bounded by verify's own `max_attempts` - the loop's
limit is written where a reviewer sees it, and no tool can write an unbounded
one.

WHERE THE DECISION LIVES. Both calls only PRINT / WRITE; the engine applies
them in `_finalize_step`. Nothing routes in the driver. That is what lets any
driver - project_lead, the code driver, or a Temporal workflow whose
activities call `next-step` and `run-step` - run a routed workflow with no
routing code of its own.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional, Union

#: Set by `_run_exec_step` for every exec/route command. The shared artifact
#: dir is `{{output_dir}}` - where requires_artifacts is checked and where a
#: feedback file has to land for the engine to find it.
ENV_ARTIFACT_DIR = "IOF_ARTIFACT_DIR"
ENV_FEEDBACK = "IOF_STEP_FEEDBACK"

DEFAULT_FEEDBACK_FILE = "feedback.md"
#: Set by the engine for a step whose `on_fail.feedback` names a file.
ENV_FEEDBACK_FILE = "IOF_FEEDBACK_FILE"


def next(*step_keys: str) -> None:  # noqa: A001 - the verb is the API
    """Choose which of this route step's declared `routes:` run.

    Prints the ROUTE_JSON line the engine reads. Call it once; the last call
    wins if a tool calls it twice. No argument means "none of them", which
    closes every declared route and lets a join downstream proceed.
    """
    # `next("a", "b")`, `next(["a", "b"])` and `next(("a",))` are one call:
    # the reference showed the list form and the product refused it.
    flat: list = []
    for k in step_keys:
        flat.extend(k if isinstance(k, (list, tuple, set, frozenset)) else [k])
    keys = [str(k) for k in flat if str(k).strip()]
    sys.stdout.write("ROUTE_JSON: " + json.dumps({"next": keys}) + "\n")
    sys.stdout.flush()


def fail(feedback: Union[str, Path, None] = None, *,
         file: Union[str, None] = None, code: int = 1) -> None:
    """Reject the work and hand back a reason. Exits the process.

    `feedback` is the critique as text, or a Path to a file already written.
    It is stored as `<file>` in the shared artifact dir - name the same file
    in the step's `on_fail.feedback` (default `feedback.md`). Then exits with
    `code` (non-zero), which is the only thing the engine reads as failure.
    """
    # The engine names the file the step's `on_fail.feedback` declares in
    # IOF_FEEDBACK_FILE; `file=` overrides it; feedback.md is the last resort.
    # Defaulting to feedback.md regardless lost the note whenever the YAML
    # said otherwise, with the run green (novice finding, round 6).
    file = file or os.environ.get(ENV_FEEDBACK_FILE) or DEFAULT_FEEDBACK_FILE
    if feedback is not None:
        art = os.environ.get(ENV_ARTIFACT_DIR)
        if art:
            target = Path(art) / file
            target.parent.mkdir(parents=True, exist_ok=True)
            text = (Path(feedback).read_text(encoding="utf-8")
                    if isinstance(feedback, Path) else str(feedback))
            target.write_text(text, encoding="utf-8")
        else:
            # No artifact dir means we are not under the engine (a unit test,
            # a shell). Say so on stderr rather than lose the critique.
            sys.stderr.write(f"[route.fail] {ENV_ARTIFACT_DIR} not set; "
                             f"feedback not stored:\n{feedback}\n")
    sys.stdout.flush()
    sys.exit(code)


def feedback() -> Optional[str]:
    """The feedback a previous attempt left for THIS step, or None.

    For an exec/route step the engine passes it as IOF_STEP_FEEDBACK (and as
    `{{feedback}}` in the command). An agent step sees it in its prompt.
    """
    v = os.environ.get(ENV_FEEDBACK, "")
    return v if v.strip() else None
