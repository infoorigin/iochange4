"""``aicore memory`` — the steward's surface over workspace memory.

    aicore memory status                      # counts, posture, claims
    aicore memory list [--scope S] [--status draft|active|...]
    aicore memory show <id>                   # the row + its history
    aicore memory pending                     # the review queue
    aicore memory approve <id> [--as WHO]
    aicore memory reject  <id> --reason "..." [--as WHO]
    aicore memory forget  <id> --reason "..." [--as WHO]
    aicore memory add "<fact>" [--scope S] [--mark M] [--as WHO]
    aicore memory consolidate [--run ID] [--force]   # one run, or a sweep
    aicore memory sweep                       # expire + curated sync + unconsolidated runs
    aicore memory sync                        # curated tiers only
    aicore memory posture [review|auto]
    aicore memory history [--limit N]
    aicore memory render [--role R] [--user U]  # the block an agent receives

Every command names its workspace (``--workspace`` or the selection in
force) and opens the database through the CLI's own resolvers, so local
mode and the mode banner apply exactly as for every other command.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.markup import escape
from rich.table import Table

memory_app = typer.Typer(
    name="memory",
    help="Workspace memory: review, approve, forget and consolidate the durable context agents share.",
    no_args_is_help=True,
)

_console = Console()


def _actor(as_: Optional[str]) -> str:
    return (as_ or os.environ.get("IOF_REVIEWER") or os.environ.get("USERNAME")
            or os.environ.get("USER") or "unknown")


def _ctx(workspace: Optional[str]):
    """``(root, run_store, memory_store, workspace_code)`` through the CLI's
    resolvers (local-mode adoption, banner, fail-closed workspace)."""
    from ioagentfarm import cli as _cli
    from ioagentfarm.engine.memory.hooks import memory_store
    from ioagentfarm.engine.workspaces import selected_workspace, RETIRED_WORKSPACE_CODES
    code = selected_workspace(workspace)[0]
    if not code:
        raise typer.BadParameter(
            "no workspace selected: pass --workspace <code>, set IOF_WORKSPACE, "
            "or run `aicore workspace use <code>`")
    if code in RETIRED_WORKSPACE_CODES:
        raise typer.BadParameter(f"'{code}' is not a selectable workspace")
    # The workspace .env is what names the database. Without this load the
    # steward's commands opened a default SQLite and reported an empty
    # review queue while 118 drafts sat in the workspace's Postgres.
    from ioagentfarm.engine.workspace_env import load_workspace_env
    load_workspace_env(code)
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace
    root = _cli._root()
    run_store = _cli._store(root)
    return root, run_store, memory_store(root), code


def _print(obj, as_json: bool) -> None:
    if as_json:
        typer.echo(json.dumps(obj, indent=2, default=str))


_WS = typer.Option(None, "--workspace", "-w", help="Workspace code (default: the selection in force).")
_JSON = typer.Option(False, "--json", help="Machine-readable output.")


@memory_app.command("status")
def status(workspace: Optional[str] = _WS, as_json: bool = _JSON):
    """Counts by status, the posture, and the run claims."""
    root, _rs, store, code = _ctx(workspace)

    # ASK THE DATABASE ABOUT ITSELF BEFORE REPORTING ITS CONTENTS. A validator
    # zeroed 4 KB of one page: `memory list` raised `database disk image is
    # malformed` while THIS command printed `draft 8 | active 4 | total 12`.
    # Nothing swallowed an error - SQLite corruption is per page, so the count
    # query read a sound page and returned real numbers from an unsound file.
    # Two commands over one file gave opposite pictures, and the one an
    # operator reads first said everything was fine.
    db_ok, db_detail = store.integrity()
    if not db_ok:
        try:
            from ioagentfarm.engine import degraded
            degraded.record(
                "database.integrity",
                f"the state database failed an integrity check ({db_detail}). "
                "Counts read from it may be incomplete or wrong.",
                scope=code)
        except Exception:  # noqa: BLE001
            pass

    counts = store.counts(code)
    claims = store.run_claims(code)
    posture = store.posture(code)
    out = {"workspace": code, "posture": posture, "counts": counts,
           "database_ok": db_ok, "database_detail": db_detail,
           "runs": {"done": sum(1 for c in claims if c["status"] == "done"),
                    "claimed": sum(1 for c in claims if c["status"] == "claimed"),
                    "failed": sum(1 for c in claims if c["status"] == "failed")},
           "extractor": os.environ.get("IOF_MEMORY_EXTRACTOR") or "iobot",
           "enabled": (os.environ.get("IOF_MEMORY") or "on")}
    if as_json:
        return _print(out, True)
    _console.print(f"workspace [bold]{code}[/bold]  posture=[bold]{posture}[/bold]  "
                   f"extractor={out['extractor']}  memory={out['enabled']}")
    t = Table(show_header=True)
    for k in ("draft", "active", "superseded", "removed", "rejected", "total"):
        t.add_column(k, justify="right")
    t.add_row(*[str(counts.get(k, 0)) for k in ("draft", "active", "superseded", "removed", "rejected", "total")])
    _console.print(t)
    if not db_ok:
        # ABOVE nothing and BELOW the table, deliberately: a reader who has
        # just read the numbers is the one who needs to know they are suspect.
        _console.print(
            "[red]the state database FAILED an integrity check[/red] - the "
            "counts above were read from it and may be incomplete or wrong.")
        _console.print(f"  {db_detail}", markup=False)
        _console.print(
            "  Restore from a backup taken WITH its write-ahead log: a copy "
            "taken without one passes this check and silently rolls state "
            "back.")
    _console.print(f"runs consolidated: {out['runs']['done']}  in progress: {out['runs']['claimed']}  "
                   f"failed: {out['runs']['failed']}")


def _table(rows, title: str = "") -> None:
    t = Table(show_header=True, title=title or None)
    for col in ("id", "status", "mark", "scope", "kind", "origin", "fact"):
        t.add_column(col)
    for f in rows:
        fact = f.fact if len(f.fact) <= 110 else f.fact[:107] + "..."
        t.add_row(str(f.id), f.status, f.mark, f.scope, f.kind, f.origin,
                  escape(fact.replace("\n", " ")))
    _console.print(t)


@memory_app.command("list")
def list_(workspace: Optional[str] = _WS,
          scope: Optional[str] = typer.Option(None, "--scope", help="workspace | role:<r> | user:<id> | solution:<c>"),
          status: str = typer.Option("active", "--status", help="draft | active | superseded | removed | rejected | all"),
          as_json: bool = _JSON):
    """Rows of the workspace, active by default."""
    _root, _rs, store, code = _ctx(workspace)
    rows = store.all_rows(code) if status == "all" else store.by_status(code, status)
    if scope:
        rows = [r for r in rows if r.scope == scope]
    if as_json:
        return _print([r.to_dict() for r in rows], True)
    if not rows:
        _console.print(f"no {status} rows in workspace {code}")
        return
    _table(rows, title=f"{code}: {status}")


@memory_app.command("show")
def show(memory_id: int = typer.Argument(..., help="Row id"), workspace: Optional[str] = _WS,
         as_json: bool = _JSON):
    """One row in full, with its history."""
    _root, _rs, store, code = _ctx(workspace)
    row = store.get(code, memory_id)
    if row is None:
        raise typer.BadParameter(f"no memory row #{memory_id} in workspace {code}")
    hist = store.history_for(code, memory_id)
    if as_json:
        return _print({"row": row.to_dict(), "history": hist}, True)
    # `[durable]` / `[role:x]` are rich style tags unless escaped — the
    # steward would otherwise never see the mark or the scope.
    _console.print(f"[bold]#{row.id}[/bold]  {row.status}  "
                   + escape(f"[{row.mark}]  [{row.scope}]  ")
                   + f"{row.kind}  origin={escape(row.origin)}  source={escape(row.source_ref)}")
    _console.print(escape(row.fact))
    if row.evidence:
        _console.print(f"[dim]evidence: {escape(row.evidence)}[/dim]")
    if row.expires_at:
        _console.print(f"[dim]expires: {row.expires_at}[/dim]")
    for h in hist:
        _console.print(f"  {h['at']}  {h['event']:<11} {h['actor']:<14} "
                       + escape(str(h['detail'])))


@memory_app.command("pending")
def pending(workspace: Optional[str] = _WS, as_json: bool = _JSON):
    """Drafts awaiting a decision."""
    _root, _rs, store, code = _ctx(workspace)
    rows = store.pending(code)
    if as_json:
        return _print([r.to_dict() for r in rows], True)
    if not rows:
        _console.print(f"no pending drafts in workspace {code}")
        return
    _table(rows, title=f"{code}: pending")
    _console.print("approve with `aicore memory approve <id>`; reject with `aicore memory reject <id> --reason ...`")


@memory_app.command("approve")
def approve(memory_id: int = typer.Argument(...), workspace: Optional[str] = _WS,
            as_: Optional[str] = typer.Option(None, "--as", help="Approver identity for the audit trail."),
            as_json: bool = _JSON):
    """Draft → active. A conflicting active row is superseded in place."""
    _root, _rs, store, code = _ctx(workspace)
    row, outcome = store.approve(code, memory_id, actor=_actor(as_))
    out = {"id": memory_id, "outcome": outcome, "row": row.to_dict() if row else None}
    if as_json:
        return _print(out, True)
    if outcome == "approved":
        _console.print(f"[green]approved[/green] #{memory_id} — now active in {code}")
    elif outcome == "duplicate":
        _console.print(f"[yellow]duplicate[/yellow] — #{row.id} already holds that fact; #{memory_id} marked superseded")
    elif outcome == "stale":
        _console.print(f"[yellow]stale[/yellow] — #{row.id} carries a NEWER value of the same fact "
                       f"(source {row.source_at}); #{memory_id} closed as superseded, nothing rolled back")
    elif outcome == "not_pending":
        _console.print(f"[yellow]not pending[/yellow] — #{memory_id} is {row.status if row else '?'} (decided already)")
    else:
        raise typer.BadParameter(f"no memory row #{memory_id} in workspace {code}")


@memory_app.command("reject")
def reject(memory_id: int = typer.Argument(...), workspace: Optional[str] = _WS,
           reason: str = typer.Option("", "--reason"),
           as_: Optional[str] = typer.Option(None, "--as"), as_json: bool = _JSON):
    """Refuse a draft. It stays in the record as rejected."""
    _root, _rs, store, code = _ctx(workspace)
    outcome = store.reject(code, memory_id, actor=_actor(as_), reason=reason)
    if as_json:
        return _print({"id": memory_id, "outcome": outcome}, True)
    _console.print(f"{'[red]rejected[/red]' if outcome == 'rejected' else '[yellow]' + outcome + '[/yellow]'} #{memory_id}")


@memory_app.command("forget")
def forget(memory_id: int = typer.Argument(...), workspace: Optional[str] = _WS,
           reason: str = typer.Option("", "--reason"),
           as_: Optional[str] = typer.Option(None, "--as"), as_json: bool = _JSON):
    """Retire an active row. It is never injected again; the record stays."""
    _root, _rs, store, code = _ctx(workspace)
    outcome = store.forget(code, memory_id, actor=_actor(as_), reason=reason)
    if as_json:
        return _print({"id": memory_id, "outcome": outcome}, True)
    _console.print(f"{'[green]removed[/green]' if outcome == 'removed' else '[yellow]' + outcome + '[/yellow]'} #{memory_id}")


@memory_app.command("add")
def add(fact: str = typer.Argument(..., help="The fact, one atomic statement."),
        workspace: Optional[str] = _WS,
        # THE FLAG THAT DECIDES WHO SEES THE FACT, and it shipped with no
        # help text at all. A validator following the memory walkthrough could
        # not create a scoped row from the documentation: `--help` named the
        # flag and said nothing about it, so the only route to a `user:<id>`
        # row was to wait for the extractor to propose one. The sibling
        # option on `list` already carried this text.
        scope: str = typer.Option(
            "workspace", "--scope",
            help="Who the fact reaches: workspace | role:<r> | user:<id> "
                 "| solution:<c>"),
        mark: str = typer.Option("durable", "--mark", help="permanent | durable | ephemeral"),
        as_: Optional[str] = typer.Option(None, "--as"),
        draft: bool = typer.Option(False, "--draft", help="Add as a draft instead of active."),
        as_json: bool = _JSON):
    """Add a fact by hand. Active immediately (a steward wrote it) unless --draft.
    The rails still apply: a finding, a secret or a dangerous body is refused."""
    # ONE PATH with `POST /api/users/{id}/memory`: `hooks.add_by_hand` runs
    # the rails and the insert for both surfaces, so a rail cannot apply at
    # the terminal and not over HTTP.
    from ioagentfarm.engine.memory.hooks import add_by_hand
    _root, _rs, store, code = _ctx(workspace)
    gate, row, outcome = add_by_hand(store, code, fact=fact, scope=scope, mark=mark,
                                     draft=draft, actor=_actor(as_))
    if gate.dropped or gate.candidate is None:
        raise typer.BadParameter(f"refused: {gate.reason}")
    if as_json:
        return _print({"outcome": outcome, "row": row.to_dict() if row else None,
                       "notes": gate.notes}, True)
    _console.print(escape(f"{outcome} #{row.id if row else '?'} [{gate.candidate.mark}] "
                          f"[{gate.candidate.scope}] {gate.candidate.fact}"))
    for n in gate.notes:
        _console.print(f"[dim]{escape(n)}[/dim]")


@memory_app.command("consolidate")
def consolidate(workspace: Optional[str] = _WS,
                run: Optional[str] = typer.Option(None, "--run", help="Consolidate this completed run."),
                force: bool = typer.Option(False, "--force", help="Re-run even if already consolidated."),
                as_json: bool = _JSON):
    """Extract and consolidate one completed run (or, with no --run, sweep)."""
    root, run_store, store, code = _ctx(workspace)
    if not run:
        return sweep(workspace=code, as_json=as_json)
    from ioagentfarm.engine.memory.consolidate import consolidate_run
    rep = consolidate_run(store, run_store, root, code, run, force=force)
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO
        get_forensics(root).emit(
            run_id=run, event_type="run.memory_consolidated", severity=SEVERITY_INFO,
            message=("memory consolidated" if rep.get("claimed") else "memory consolidation skipped"),
            payload={k: v for k, v in rep.items() if k not in ("dropped_at_extraction",)})
    except Exception:  # noqa: BLE001
        pass
    if as_json:
        return _print(rep, True)
    if rep.get("skipped"):
        _console.print(f"skipped: {rep['skipped']}")
    elif rep.get("error"):
        _console.print(f"[red]failed[/red]: {rep['error']}")
    else:
        r = rep.get("result") or {}
        _console.print(f"run {run}: candidates={rep.get('candidates', 0)} posture={rep.get('posture')} "
                       f"drafts={len(r.get('added', []))} activated={len(r.get('activated', []))} "
                       f"replaced={len(r.get('replaced', []))} dropped={len(r.get('dropped', []))} "
                       f"changed={rep.get('changed')}")
        for d in rep.get("dropped_at_extraction") or []:
            _console.print(f"  [dim]dropped: {d.get('reason')} — {d.get('fact')}[/dim]")


@memory_app.command("sweep")
def sweep(workspace: Optional[str] = _WS, as_json: bool = _JSON):
    """Expire, re-sync the curated tiers, consolidate unconsolidated runs."""
    from ioagentfarm.engine.memory.hooks import sweep as _sweep
    root, run_store, _store, code = _ctx(workspace)
    out = _sweep(root, run_store, code)
    if as_json:
        return _print(out, True)
    _console.print(f"workspace {code}: expired={out.get('expired', 0)} "
                   f"curated={out.get('curated')} consolidated={len(out.get('consolidated', []))} "
                   f"in-progress-elsewhere={out.get('skipped', 0)}")
    for c in out.get("consolidated", []):
        _console.print(f"  {c['run_id']}: claimed={c['claimed']} changed={c['changed']} "
                       f"candidates={c.get('candidates')} {c.get('skipped') or c.get('error') or ''}")


@memory_app.command("sync")
def sync(workspace: Optional[str] = _WS, as_json: bool = _JSON):
    """Re-read the curated tiers (pack memory/ + workspace memory/) into the store."""
    from ioagentfarm.engine.memory.packtier import sync_curated, workspace_memory_dir
    _root, _rs, store, code = _ctx(workspace)
    out = sync_curated(store, code)
    if as_json:
        return _print(out, True)
    _console.print(f"pack: {out['pack']}   workspace ({workspace_memory_dir(code)}): {out['workspace']}")


@memory_app.command("posture")
def posture(value: Optional[str] = typer.Argument(None, help="review | auto (omit to show)"),
            workspace: Optional[str] = _WS, as_: Optional[str] = typer.Option(None, "--as"),
            as_json: bool = _JSON):
    """Show or set the governance posture. `review` (default): extraction
    produces drafts a steward approves. `auto`: extraction activates directly."""
    _root, _rs, store, code = _ctx(workspace)
    if value:
        try:
            store.set_posture(code, value, actor=_actor(as_))
        except ValueError as e:
            raise typer.BadParameter(str(e))
    p = store.posture(code)
    if as_json:
        return _print({"workspace": code, "posture": p}, True)
    _console.print(f"workspace {code}: posture={p}")


@memory_app.command("history")
def history(workspace: Optional[str] = _WS, limit: int = typer.Option(50, "--limit"),
            as_json: bool = _JSON):
    """The audit trail, newest first."""
    _root, _rs, store, code = _ctx(workspace)
    rows = store.history(code, limit=limit)
    if as_json:
        return _print(rows, True)
    for h in rows:
        # ESCAPE THE DETAIL. It carries the row's own text, and the PII rail
        # writes placeholders that are Rich style tags: `[email]`, `[phone]`,
        # `[mrn]`. Unescaped they were CONSUMED, so the audit trail read
        # "Reach Alice at  or  for sign-off" - as if redaction had deleted the
        # values rather than labelling them, which is the opposite of what a
        # compliance reader needs. `show` escaped; this did not (found by
        # walking the user-state guide, 2026-09-03).
        _console.print(f"{h['at']}  #{h.get('memory_id') or '-':<6} "
                       f"{h['event']:<11} {h['actor']:<14} "
                       + escape(str(h['detail'])))


@memory_app.command("render")
def render(workspace: Optional[str] = _WS,
           role: Optional[str] = typer.Option(None, "--role"),
           user: Optional[str] = typer.Option(None, "--user"),
           solution: Optional[str] = typer.Option(None, "--solution")):
    """Print the block exactly as an agent receives it."""
    from ioagentfarm.engine.memory.inject import block_for, user_block
    _root, _rs, store, code = _ctx(workspace)
    block = block_for(store, code, role=role, solution=solution)
    if user:
        block = (block + "\n" if block else "") + user_block(store, code, user)
    typer.echo(block if block else "(empty — no active memory for these scopes)")
