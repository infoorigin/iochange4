"""Azure OpenAI provider that uses the classic ``/chat/completions`` API.

Why this exists
---------------
The bundled ``iobot.providers.azure_openai_provider.AzureOpenAIProvider``
targets the new Azure **v1 Responses API** preview (``/openai/v1/responses``).
That route only exists on Azure resources that have opted into the v1 preview
— a small subset of regions and model SKUs. Every other Azure deployment
(the vast majority of enterprise tenants) only exposes the classic
``/openai/deployments/<deployment>/chat/completions?api-version=...`` route,
which returns ``404 Resource not found`` against the v1 preview path.

This provider points an ``AsyncAzureOpenAI`` client at the resource endpoint
and lets the official OpenAI SDK construct the deployment-scoped Chat
Completions URL with the configured ``api_version`` query parameter. Every
classic Azure OpenAI tenant supports this path.

Behaviorally this is otherwise an ``OpenAICompatProvider`` — message
sanitization, tool-call parsing, error handling, retries, streaming all
inherited unchanged. Only the SDK client and the implicit choice of API
surface differ.

Configuration
-------------
- ``api_key``  — Azure OpenAI key
- ``api_base`` — resource endpoint, e.g. ``https://<resource>.openai.azure.com``
  (NO trailing ``/openai/...`` path; the SDK adds that)
- ``model``    — Azure deployment name (NOT the published model name)
- ``AZURE_OPENAI_API_VERSION`` env var — defaults to ``2024-10-21``
  (a stable GA api-version that supports gpt-4o / gpt-4-turbo / gpt-3.5-turbo)
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from typing import Any

from openai import AsyncAzureOpenAI

from iobot.providers.base import LLMProvider
from iobot.providers.openai_compat_provider import OpenAICompatProvider
from iobot.providers.base import LLMResponse

_DEFAULT_API_VERSION = "2024-10-21"

logger = logging.getLogger("ioagentfarm.azure_openai_chat")


class AzureOpenAIChatProvider(OpenAICompatProvider):
    """Azure OpenAI via classic Chat Completions + ``AsyncAzureOpenAI``.

    Drop-in replacement for ``iobot.providers.azure_openai_provider.AzureOpenAIProvider``
    on tenants whose resource exposes only the deployments-based API surface.
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_base: str | None = None,
        default_model: str | None = None,
    ):
        # ✅ Resolve from env FIRST
        api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")
        api_base = api_base or os.environ.get("AZURE_OPENAI_API_BASE")
        default_model = default_model or os.environ.get("AZURE_OPENAI_MODEL", "gpt-4o")

        # DEBUG, not console output. These were `print`s, so every agent
        # process announced its endpoint and model on stdout — twice per step
        # and again per LLM call, in a console a user is reading for run
        # progress. The module already has a logger; use it, so the detail is
        # available at DEBUG and silent otherwise.
        logger.debug("azure provider: api_base=%s default_model=%s",
                     api_base, default_model)

        # ✅ Now validate
        if not api_key:
            raise ValueError("Azure OpenAI api_key is required")
        if not api_base:
            raise ValueError("Azure OpenAI api_base is required")

        # ✅ Use consistent values everywhere
        LLMProvider.__init__(self, api_key, api_base)

        self.default_model = default_model
        self.extra_headers: dict[str, str] = {}
        # Minimal spec to opt into GPT-5+ / o-series compatibility:
        # - supports_max_completion_tokens=True → parent emits max_completion_tokens
        # - supports_prompt_caching=False → no cache-control injection
        # - strip_model_prefix=False → preserve full model name
        # - model_overrides=[] → no per-model param tweaks
        #
        # ProviderSpec field parity: iobot's shared error-handler
        # (OpenAICompatProvider._handle_error) accesses ``spec.is_local`` —
        # without it, ANY upstream failure (5xx, connection drop, rate
        # limit) crashes inside the error formatter with
        # AttributeError("'types.SimpleNamespace' object has no attribute
        # 'is_local'"), which gets caught by _safe_chat_stream and
        # returned as content. The original error is masked. We mirror
        # every boolean/string field on ProviderSpec that shared
        # iobot code paths might probe, all defaulted to safe values.
        from types import SimpleNamespace
        self._spec = SimpleNamespace(
            name="azure_openai",
            supports_max_completion_tokens=True,
            supports_prompt_caching=False,
            strip_model_prefix=False,
            model_overrides=[],
            # ProviderSpec parity defaults — must be present so
            # iobot's shared error/dispatch code doesn't crash on
            # attribute lookup.
            is_local=False,
            is_gateway=False,
            is_oauth=False,
            is_direct=False,
            default_api_base="",
            detect_by_key_prefix="",
            detect_by_base_keyword="",
        )

        self._effective_base = api_base

        # ── Parent-init parity ────────────────────────────────────────────
        # This class calls LLMProvider.__init__ directly (above), skipping
        # OpenAICompatProvider.__init__, because the parent requires a real
        # ProviderSpec we do not have. The cost of that shortcut: every
        # attribute the parent sets must be mirrored here, or shared parent
        # code paths raise AttributeError at runtime — far from this file,
        # and only on the branch that happens to touch the missing name.
        #
        # Observed live: iobot's `_should_use_responses_api()` reads
        # `self._api_type`, so EVERY chat_stream call died with
        # "'AzureOpenAIChatProvider' object has no attribute '_api_type'".
        # The others below were missing too and would have failed the same
        # way on their own code paths.
        #
        # WHEN UPGRADING IOBOT: diff OpenAICompatProvider.__init__ against
        # this block. A new attribute there is a latent crash here.
        self._api_type = "auto"          # parent: "auto" unless spec.name == "openai"
        self._extra_body: dict[str, Any] = {}
        self._extra_query: dict[str, str] = {}
        self._default_headers = {"x-session-affinity": uuid.uuid4().hex}
        self._api_key_for_client = api_key or "no-key"
        self._is_local = False           # Azure endpoints are never local
        self._client_lock = asyncio.Lock()
        # Responses-API circuit breaker state (parent reads these when a
        # responses-API call fails and it decides whether to fall back).
        self._responses_failures: dict[str, int] = {}
        self._responses_tripped_at: dict[str, float] = {}

        api_version = os.environ.get("AZURE_OPENAI_API_VERSION", _DEFAULT_API_VERSION)

        self._client = AsyncAzureOpenAI(
            api_key=api_key,
            azure_endpoint=api_base.rstrip("/"),
            api_version=api_version,
            default_headers={"x-session-affinity": uuid.uuid4().hex},
            max_retries=0,
        )
        # TEMP DEBUG: log request body to see if tools are passed through
        async def _log_request(request):
            import sys, json
            try:
                body = json.loads(request.content) if request.content else {}
                tools = body.get('tools') or []
                first_tool_name = 'NONE'
                if isinstance(tools, list) and len(tools) > 0:
                    first = tools[0]
                    if isinstance(first, dict):
                        fn = first.get('function') or {}
                        first_tool_name = fn.get('name', 'UNKNOWN')
                logger.debug(
                    "[AZURE_REQ] tools_count=%d tool_choice=%s model=%s "
                    "first_tool=%s",
                    len(tools), body.get('tool_choice', 'MISSING'),
                    body.get('model', '?'), first_tool_name,
                )
            except Exception as e:                       # noqa: BLE001
                logger.debug("[AZURE_REQ] log failed: %s", e)
        self._client._client.event_hooks['request'].append(_log_request)

    def _is_gpt5_or_reasoning(self, model: str | None) -> bool:
        if not model:
            model = self.default_model
        m = model.lower()
        return (
            m.startswith("gpt-5") or m.startswith("o1") or m.startswith("o3")
            or m.startswith("o4") or "gpt-5" in m
        )

    async def chat(self, *args, **kwargs):
        model = kwargs.get('model') or self.default_model
        if self._is_gpt5_or_reasoning(model):
            kwargs.pop('temperature', None)
        tools = kwargs.get('tools')
        logger.debug("[AZURE_CHAT_ENTRY] model=%s tools_count=%d kwargs_keys=%s",
                     model, len(tools) if tools else 0, list(kwargs.keys()))
        return await super().chat(*args, **kwargs)

    async def chat_stream(self, *args, **kwargs):
        model = kwargs.get('model') or self.default_model
        if self._is_gpt5_or_reasoning(model):
            kwargs.pop('temperature', None)
        tools = kwargs.get('tools')
        logger.debug("[AZURE_CHAT_STREAM_ENTRY] model=%s tools_count=%d "
                     "kwargs_keys=%s",
                     model, len(tools) if tools else 0, list(kwargs.keys()))
        return await super().chat_stream(*args, **kwargs)

    def get_default_model(self) -> str:
        return self.default_model

    def _handle_error(
        self,
        e: Exception,
        *,
        spec: Any = None,
        api_base: str | None = None,
    ) -> LLMResponse:
        """Log the upstream exception in full BEFORE deferring to the
        parent's formatter.

        iobot's parent ``_handle_error`` collapses the original
        exception down to a one-line ``content`` string on the returned
        ``LLMResponse``, then the agent loop catches that as a "soft"
        error and the original exception object is lost. Under load this
        masked the actual OpenAI failure (rate limit / 5xx / connection
        drop) behind whatever cosmetic glitch happened next in the
        formatter (e.g. the ``spec.is_local`` AttributeError). Logging
        here is the only place we have the full exception with type,
        body, status code, and traceback before the format step erases
        it.
        """
        response = getattr(e, "response", None)
        status_code = getattr(response, "status_code", None)
        body = (
            getattr(e, "body", None)
            or getattr(e, "doc", None)
            or (getattr(response, "text", None) if response else None)
        )
        body_text = (
            str(body)[:1000] if body is not None else ""
        )
        # A CONNECTION FAULT GETS A LINE. Forty frames of httpx, httpcore,
        # anyio and asyncio name nothing the reader can act on - everything
        # useful is already on this line - and a stack trace printed for a
        # transient the harness is designed to absorb reads as "the product
        # is broken". The traceback stays available at DEBUG. A response
        # error keeps its stack: that one has a cause worth finding.
        transient = status_code is None and not body_text
        logger.error(
            "AzureOpenAIChat upstream LLM call failed: "
            "type=%s status=%s msg=%s body=%s%s",
            type(e).__name__,
            status_code,
            str(e)[:500],
            body_text,
            " (transient; set the log level to DEBUG for the traceback)"
            if transient else "",
            exc_info=not transient,
        )
        if transient:
            logger.debug("AzureOpenAIChat upstream call traceback", exc_info=True)
        return OpenAICompatProvider._handle_error(
            e, spec=spec, api_base=api_base,
        )