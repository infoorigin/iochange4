"""GenAI Bedrock wrapper provider — routes Anthropic Claude traffic
through the client's gateway.

Why this exists
---------------
The client (J&J) exposes Bedrock-hosted Claude models behind a custom
API gateway at ``https://genaiapigwna.jnj.com``. Auth is API-key based
(no AWS SigV4), and routes follow Bedrock Runtime's URL pattern:

    POST /model/{modelName}/invoke      <- Anthropic Messages format
    POST /model/{modelName}/converse    <- Bedrock-native Converse format

Probe (``scripts/probe_bedrock_wrapper.py``) confirmed:

  - Auth header: ``X-Api-Key`` (case-insensitive — ``x-api-key`` also works)
  - ``/invoke`` with native Anthropic Messages format returns a clean
    Anthropic-shaped response (``{model, type, role, content:[{type:text,...}],
    stop_reason, usage, ...}``) — plus extra Bedrock-only fields
    (``amazon-bedrock-trace``, ``appliedGuardrailDetails``,
    ``outputAssessments``) that the official Anthropic SDK ignores
    cleanly (pydantic models with ``extra="ignore"``).
  - ``/converse`` requires Bedrock-native body shape (``content`` as
    blocks, ``system`` as array, ``inferenceConfig``). Different wire
    format — would require a separate translation layer.

Decision: route through ``/invoke`` with Anthropic Messages format
because (a) the wrapper returns Anthropic-shaped responses we can
deserialize with the existing SDK, (b) the AnthropicProvider's
message formatting + tool-use loop + retry logic all stay reusable —
we only need to rewrite the wire-level URL + auth.

Implementation
--------------
This provider subclasses ``AnthropicProvider`` and configures the
underlying ``AsyncAnthropic`` client with a custom ``httpx.AsyncClient``
whose request hook:

1. Parses the request body to extract the ``model`` field.
2. Rewrites the URL from ``{api_base}/v1/messages`` to
   ``{api_base}/model/{model}/invoke``.
3. Strips the ``model`` field from the body (Bedrock /invoke uses the
   URL path for model selection) and injects
   ``anthropic_version: "bedrock-2023-05-31"`` (required by the
   wrapper).
4. Replaces Anthropic's ``x-api-key`` + ``anthropic-version`` headers
   with our ``X-Api-Key`` header (the wrapper expects that name).

Streaming is not supported by the wrapper at the moment. ``chat_stream``
falls back to non-streaming ``chat`` and yields the result as a single
synthesized stream event so the agent loop's streaming consumer
doesn't break.

Configuration
-------------
- ``api_key``  — wrapper API key. Env: ``GENAI_API_KEY``.
- ``api_base`` — wrapper base URL, e.g. ``https://genaiapigwna.jnj.com``.
  Env: ``GENAI_API_BASE``. NO trailing slash, NO ``/v1`` suffix.
- ``default_model`` — Bedrock model ID, e.g.
  ``us.anthropic.claude-opus-4-6-v1``. Env: ``GENAI_MODEL``.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

import httpx

from iobot.providers.anthropic_provider import AnthropicProvider

logger = logging.getLogger("ioagentfarm.genai_bedrock")


class GenaiBedrockProvider(AnthropicProvider):
    """Anthropic Claude routed through the client's Bedrock wrapper.

    Drop-in replacement for ``iobot.providers.anthropic_provider.AnthropicProvider``
    when the agent talks to ``https://genaiapigwna.jnj.com``-style
    gateways instead of ``api.anthropic.com``. All message formatting,
    tool-call extraction, retry logic, and response parsing inherited
    from the parent class.
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_base: str | None = None,
        default_model: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ):
        # Resolve from env, allow caller args to override.
        api_key = api_key or os.environ.get("GENAI_API_KEY")
        api_base = api_base or os.environ.get("GENAI_API_BASE")
        default_model = (
            default_model
            or os.environ.get("GENAI_MODEL")
            or "us.anthropic.claude-sonnet-4-20250514-v1"
        )

        if not api_key:
            raise ValueError(
                "GenAI Bedrock api_key is required "
                "(set GENAI_API_KEY env or pass api_key=…)"
            )
        if not api_base:
            raise ValueError(
                "GenAI Bedrock api_base is required "
                "(set GENAI_API_BASE env or pass api_base=…)"
            )
        api_base = api_base.rstrip("/")

        # IMPORTANT: we use a custom Transport, NOT an httpx event_hook,
        # to rewrite requests.
        #
        # Why this matters (was the bug that cost us a debugging
        # cycle): event_hooks on the "request" event CAN mutate
        # request.url and request.headers — those mutations stick on
        # the wire. But event_hooks CANNOT reliably mutate the request
        # body. The hook sees `request.content` as a one-time cache;
        # the actual bytes sent on the wire come from
        # `request.stream`, which was already assembled before the
        # hook fires. Setting `request._content = new_bytes` updates
        # the cache (visible to the next `request.content` read) but
        # NOT the underlying stream. The original Anthropic Messages
        # body went on the wire — `model` field intact, no
        # `anthropic_version`, plus the Anthropic SDK's `x-api-key`
        # header instead of our `X-Api-Key`. The wrapper rejected it
        # and the SDK reported a generic "Connection error" without
        # detail.
        #
        # Transport-based approach: subclass AsyncBaseTransport,
        # build a brand-new Request inside `handle_async_request`
        # with the correct URL/body/headers, hand it to the wrapped
        # default transport. Body mutation is no longer "mutation" —
        # it's "build a new request from scratch", which always works.

        class GenaiBedrockTransport(httpx.AsyncBaseTransport):
            def __init__(self):
                self._wrapped = httpx.AsyncHTTPTransport()

            async def handle_async_request(
                self, request: httpx.Request,
            ) -> httpx.Response:
                import sys
                try:
                    orig_url = str(request.url)

                    # Read the original body (small — single JSON blob)
                    body: dict[str, Any] = {}
                    raw = await request.aread()
                    if raw:
                        try:
                            body = json.loads(raw)
                        except (json.JSONDecodeError, ValueError):
                            # Non-JSON body — pass through unchanged
                            return await self._wrapped.handle_async_request(
                                request
                            )

                    model = body.get("model") or default_model
                    if not model:
                        logger.warning(
                            "GenAI transport: no model in body, no "
                            "default_model — passthrough will likely 404"
                        )
                        return await self._wrapped.handle_async_request(
                            request
                        )

                    # Rewrite: URL path, body (strip model, inject
                    # anthropic_version), auth header (X-Api-Key only).
                    new_url = f"{api_base}/model/{model}/invoke"
                    body.pop("model", None)
                    body.setdefault("anthropic_version", "bedrock-2023-05-31")
                    new_body = json.dumps(body).encode("utf-8")

                    new_headers = {
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        "X-Api-Key": api_key,
                        "Content-Length": str(len(new_body)),
                    }

                    # Build a fresh Request — body now goes on the wire.
                    new_request = httpx.Request(
                        method=request.method,
                        url=new_url,
                        headers=new_headers,
                        content=new_body,
                        extensions=request.extensions,
                    )

                    # DEBUG: one line per request is console noise during a
                    # run. The FAILURE paths below stay on stderr, because
                    # they must not depend on logging being configured.
                    logger.debug(
                        "[GenAI transport] %s -> %s (model=%s, body=%d bytes)",
                        orig_url, new_url, model, len(new_body),
                    )

                    response = await self._wrapped.handle_async_request(
                        new_request,
                    )

                    if response.status_code >= 400:
                        # Read the response body so the error surface is
                        # actually visible — anthropic SDK otherwise
                        # buries it as a generic APIStatusError.
                        try:
                            err_body = await response.aread()
                            err_text = err_body.decode(
                                "utf-8", errors="replace",
                            )[:500]
                        except Exception:
                            err_text = "<could not read response body>"
                        print(
                            f"[GenAI transport] response "
                            f"{response.status_code} from {new_url}: "
                            f"{err_text}",
                            file=sys.stderr, flush=True,
                        )
                    else:
                        logger.debug(
                            "[GenAI transport] response %s from %s (ok)",
                            response.status_code, new_url,
                        )
                    return response
                except Exception as exc:
                    import traceback
                    print(
                        f"[GenAI transport] EXCEPTION: {type(exc).__name__}: "
                        f"{exc}\n{traceback.format_exc()}",
                        file=sys.stderr, flush=True,
                    )
                    raise

            async def aclose(self) -> None:
                await self._wrapped.aclose()

        custom_http_client = httpx.AsyncClient(
            transport=GenaiBedrockTransport(),
            timeout=httpx.Timeout(120.0, connect=10.0),
        )

        # Initialise the parent. We pass a placeholder api_key (the
        # SDK requires one and will set it as `x-api-key` header — our
        # hook strips that and replaces with X-Api-Key on the way out)
        # and the actual api_base so AsyncAnthropic's base_url is set
        # correctly. Then we replace the SDK's auto-built client with
        # our hook-equipped one.
        super().__init__(
            api_key="genai-placeholder-stripped-by-hook",
            api_base=api_base,
            default_model=default_model,
            extra_headers=extra_headers,
        )

        # Rebuild the AsyncAnthropic client with our custom http_client.
        # The parent already imported AsyncAnthropic; reuse the import.
        from anthropic import AsyncAnthropic

        self._client = AsyncAnthropic(
            api_key="genai-placeholder-stripped-by-hook",
            base_url=api_base,
            http_client=custom_http_client,
            max_retries=0,
        )

        # Spec-compat namespace (matches the parent's optional spec
        # surface used by some shared logic in OpenAICompatProvider —
        # AnthropicProvider doesn't strictly require it, but we mirror
        # the pattern used by AzureOpenAIChatProvider for safety).
        #
        # ProviderSpec field parity: iobot's shared error-handler
        # (OpenAICompatProvider._handle_error) accesses ``spec.is_local`` —
        # without it, ANY upstream failure (5xx, connection drop, rate
        # limit) crashes inside the error formatter with
        # AttributeError("'types.SimpleNamespace' object has no attribute
        # 'is_local'"), which gets caught by _safe_chat_stream and
        # returned as content. The original error is masked. We mirror
        # every boolean/string field on ProviderSpec that shared
        # iobot code paths might probe, all defaulted to safe values.
        from types import SimpleNamespace
        self._spec = SimpleNamespace(
            name="genai_bedrock",
            supports_max_completion_tokens=False,
            supports_prompt_caching=True,  # Claude on Bedrock supports caching
            strip_model_prefix=False,
            model_overrides=[],
            # ProviderSpec parity defaults — must be present so
            # iobot's shared error/dispatch code doesn't crash on
            # attribute lookup.
            is_local=False,
            is_gateway=False,
            is_oauth=False,
            is_direct=False,
            default_api_base="",
            detect_by_key_prefix="",
            detect_by_base_keyword="",
        )

        logger.info(
            "GenaiBedrockProvider initialised: base=%s, default_model=%s",
            api_base, default_model,
        )
        # This was a stderr `print` that bypassed logging, added during a
        # bug-hunt in which logger.info lines were not reaching the server
        # output and it was unclear whether __init__ ran at all. That
        # question is long settled, and the line now prints on every agent
        # process in a console someone is reading for run progress. The
        # logger.info above already records initialisation; the client
        # identity is the only detail this added, and it belongs at DEBUG.
        logger.debug("GenaiBedrockProvider http_client_id=%s",
                     id(custom_http_client))

    async def chat_stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        reasoning_effort: str | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        on_content_delta: Any = None,
    ):
        """Streaming fallback — wrapper doesn't support SSE.

        Mirrors ``AnthropicProvider.chat_stream``'s **signature and
        return type** (an ``LLMResponse``, NOT an async generator —
        iobot's agent loop awaits this and uses ``on_content_delta``
        for progressive UI updates).

        Implementation: calls non-streaming ``chat()`` to get the full
        response, then (if a content-delta callback was supplied) fires
        it once with the complete text so the agent loop's progress
        narration gets a single update. Token-level streaming is not
        possible without the gateway exposing
        ``/model/{model}/invoke-with-response-stream``.

        The earlier version of this override accepted ``*args, **kwargs``
        and forwarded everything to ``chat()`` — which doesn't accept
        ``on_content_delta`` and crashed with ``TypeError: chat() got
        an unexpected keyword argument 'on_content_delta'`` during
        iobot's pre-warm phase. Fixed by matching the parent's
        keyword signature explicitly so we can intercept the callback.
        """
        response = await self.chat(
            messages=messages,
            tools=tools,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            reasoning_effort=reasoning_effort,
            tool_choice=tool_choice,
        )
        if on_content_delta is not None:
            text = getattr(response, "content", None) or ""
            if text:
                try:
                    await on_content_delta(text)
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "on_content_delta callback raised (non-fatal): %s",
                        exc,
                    )
        return response

    def get_default_model(self) -> str:
        return self.default_model

    @classmethod
    def _handle_error(cls, e: Exception):  # type: ignore[override]
        """Log the upstream exception in full BEFORE deferring to the
        parent's formatter.

        The parent ``AnthropicProvider._handle_error`` collapses the
        original exception down to a one-line ``content`` string on the
        returned ``LLMResponse``. The agent loop then catches that as a
        soft error and the original exception object is gone. Logging
        here is the only place we have type, status code, body, and
        traceback before the format step erases them.
        """
        response = getattr(e, "response", None)
        status_code = (
            getattr(e, "status_code", None)
            or (getattr(response, "status_code", None) if response else None)
        )
        body = (
            getattr(e, "body", None)
            or getattr(e, "doc", None)
            or (getattr(response, "text", None) if response else None)
        )
        body_text = str(body)[:1000] if body is not None else ""
        # A CONNECTION FAULT GETS A LINE. Forty frames of httpx, httpcore,
        # anyio and asyncio name nothing the reader can act on - everything
        # useful is already on this line - and a stack trace printed for a
        # transient the harness is designed to absorb reads as "the product
        # is broken". The traceback stays available at DEBUG. A response
        # error keeps its stack: that one has a cause worth finding.
        transient = status_code is None and not body_text
        logger.error(
            "GenaiBedrock upstream LLM call failed: "
            "type=%s status=%s msg=%s body=%s%s",
            type(e).__name__,
            status_code,
            str(e)[:500],
            body_text,
            " (transient; set the log level to DEBUG for the traceback)"
            if transient else "",
            exc_info=not transient,
        )
        if transient:
            logger.debug("GenaiBedrock upstream call traceback", exc_info=True)
        return AnthropicProvider._handle_error(e)
