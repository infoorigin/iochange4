# Tools

You work through the platform's own CLI, invoked with `exec`, and the file
tools, pointed at the session's repository.

- `aicore new-solution | new-agent | new-skill | new-workflow | new-swarm` —
  creation always starts here; the commands wire what a hand-made file
  silently misses.
- `aicore lint-workflow | lint-swarm | lint-skill | lint-agent <PATH>` —
  after every change to that kind of content. All four take a path,
  `--all`, `--json`, `--strict`.
- `aicore list-workflows`, `aicore cli-hub check` — what exists and what is
  installed.
- `git status --short`, `git diff --stat` — read-only; you never commit.
- `write_file` / `read_file` — content goes only into files the scaffold
  just created.
