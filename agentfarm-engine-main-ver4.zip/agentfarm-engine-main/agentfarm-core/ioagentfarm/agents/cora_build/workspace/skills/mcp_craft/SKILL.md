---
name: mcp_craft
description: "When a build session must connect an agent to an MCP server or an external A2A agent, or a request mentions auth, a token, a header or OAuth: declare the server with `aicore new-mcp-server`, carry its auth as a `${VAR}` reference (never a value), make it discoverable with a usage skill, verify with `aicore mcp-list --probe`, and pick the right credential shape - a static header, or an `--auth-*` client-credentials grant the runtime performs and renews. Read before touching mcp.yaml, any auth/token/header request, or an external-agent roster."
---

# MCP craft - servers, auth, external agents

An MCP server gives every agent in scope a set of tools the runtime
registers at session start as `mcp_<server>_<tool>`. You declare it; the
runtime connects it. Nothing here needs an install, a console script or a
restart of anything.

## Where a build session may write, and where it may not

| Tier | Command | Where it lands | From a build session |
|---|---|---|---|
| Solution (pack) | `aicore new-mcp-server <name> ...` | `mcp.yaml` in this repository | **you run it** |
| Machine | `aicore mcp-add <name> ...` | `~/.iobot/config.json` | hand the command to the user |
| Workspace | `aicore mcp-add <name> ... --workspace <code>` | `~/.iobot/workspaces/<code>/mcp.yaml` | hand the command to the user |

Only the pack tier is inside the repository named in the session header.
The other two are outside it, which your hard limits forbid you to touch -
so when a request needs a machine- or workspace-level override, write the
exact command in your reply and say which tier it sets and why.

## Auth is a reference, never a value

This is the point where a session goes wrong in one of two ways: it refuses
because the request mentions a token, or it pastes the token into a file.
Both are wrong. The compliant form carries a NAME:

```bash
# remote server (sse / streamableHttp - auto-detected from the URL)
aicore new-mcp-server search --url https://mcp.example.com/mcp \
    --header 'Authorization=Bearer ${MCP_SEARCH_TOKEN}'

# stdio server launched by the runtime
aicore new-mcp-server github --command npx \
    --args "-y,@modelcontextprotocol/server-github" \
    --env 'GITHUB_TOKEN=${GITHUB_TOKEN}'
```

`${VAR}` stays unexpanded in every file; the runtime resolves it from the
environment when it loads the configuration. The rules that follow from it:

- **Name the variable `<SERVER>_TOKEN` (or the vendor's own name) in
  upper case**, then tell the user in one line where to set it: their
  workspace `.env` (`~/.iobot/workspaces/<code>/.env`) for a desktop, the
  deployment's environment for a pod. You do not write that file.
- **Never ask for the value, and never echo one.** If the user pastes a
  token, do not repeat it, do not put it anywhere: declare the reference,
  and say "put that value in `<VAR>` in your workspace `.env`". The harness
  refuses a write or a command that carries a literal credential, with the
  reference named as the fix - that refusal is correct, not an obstacle.
- **A request that mentions auth is an ordinary request.** "Connect rey to
  an MCP server that needs a bearer token" is fully specified: one
  `new-mcp-server` with a `${VAR}` header, one line naming the variable.
  A request that names OAuth is ALSO ordinary - a different answer, never a
  refusal. The next section is that answer.
- A server whose variable is unset is DROPPED at config load with a warning
  naming the variable; the others connect. `aicore mcp-list` shows it.

## Auth: two shapes work, and one still does not

**A STATIC CREDENTIAL IN A HEADER** - an API key, a bearer token, a JWT.
The declaration carries `${VAR}`; the runtime sends it as given.

```bash
aicore new-mcp-server vendors --url https://vendor/mcp \
    --header 'Authorization=Bearer ${VENDORS_TOKEN}'
```

Nothing renews a static credential. A JWT with an `exp` therefore works
until it expires and then stops - measured, and it looks exactly like a
broken server. When the user says the token is short-lived, or mentions an
expiry at all, use the grant below instead.

**AN OAUTH CLIENT-CREDENTIALS GRANT, WHICH THE RUNTIME PERFORMS ITSELF.**
It fetches the token from the vendor's token endpoint and re-mints it before
expiry.

```bash
aicore mcp-add vendors --url https://vendor/mcp --workspace <code> \
    --auth-type oauth2_client_credentials \
    --auth-token-url https://vendor/token \
    --auth-client-id '${VENDOR_CLIENT_ID}' \
    --auth-client-secret '${VENDOR_CLIENT_SECRET}' \
    --auth-scope 'mcp:tools'
```

`new-mcp-server` takes the same `--auth-*` flags for the pack tier. The
client id and secret are `${VAR}` references like any other credential - you
never ask for the values, and they go in the workspace `.env`. A half-written
set of flags is refused by the command, naming the missing one.

**WHAT STILL DOES NOT WORK: an interactive authorization-code flow** - the
kind where a person logs in at the vendor and a redirect comes back. A
headless agent has no browser and nowhere to receive a redirect. There the
answer is still a gateway or reverse proxy that holds the flow and presents
a credential this platform can send.

**When the user describes OAuth**, ask ONE question before declaring: is it
machine-to-machine (a client id and secret, a token endpoint), or does a
person log in? The first is the grant above and you can build it now. The
second needs the gateway, and you say so plainly and keep building
everything that does not depend on the answer - the agent, the usage skill,
the workflow step.

**Verify rather than assume.** `aicore mcp-list --probe` presents the same
credential the runtime does, so an authenticated server reads `ok`. If a
declared grant is rejected it says so and points at the token URL, the
client id and secret, and the scope - not at the server.

**The two ways to get this wrong**, both worse than the honest answer:
refusing the request because the word OAuth appeared (the rest of the work
is fully specified and the user still needs it), and declaring a credential
shape you have not checked against what the vendor actually operates - a
static header for a server that issues short-lived tokens leaves the user
with an agent whose tools stop working days later.

## Narrow, then make it discoverable

- `--enabled-tools a,b,c` restricts registration to named tools. Use it
  when a server offers write operations a deployment must not expose.
- Connection and discoverability are separate. Every declared server
  connects for every agent in scope; a SKILL tells an agent WHEN its tools
  are the right answer:

  ```bash
  aicore new-skill <server>_usage --mcp-server <server> --role <agent>
  ```

  The generated skill names the `mcp_<server>_*` convention and carries the
  judgement - which tool answers which job, how to read what comes back,
  when not to reach for it. It restates no parameters: the live tool
  definitions are current in a way a file cannot be. `--mcp-server` is
  refused if no tier declares the server, so declare first.
- Verify: `aicore mcp-list` - the merged view, with provenance per server
  and any server dropped for an unset variable. **`aicore mcp-list
  --probe` goes further and CONTACTS each remote server**, reporting
  `ok` / `unauthorized` / `not-found` / `unreachable` and naming the
  OAuth case when the server answers with an authorization challenge.
  Use it whenever a declaration is new or a user says the tools are
  missing: without it a rejected credential looks exactly like a
  working one, and you would be guessing.

## External agents (A2A) - the same shape, one tier up

An external agent is registered per WORKSPACE (`aicore a2a-add <name>
--url ... --header 'Authorization=Bearer ${VAR}'`), which is outside the
repository: write the command for the user. The judgement skill is the
shared `a2a_consult`; assign it explicitly to the agent that will consult
(`--role`), nothing carries it by default. A swarm scopes both kinds through
its roster: `agents:` names external agents, `mcp_servers:` names servers;
omitted means all registered, `[]` means none. `swarm_craft` has the
roster rules.

## Read before you write

Run `aicore new-mcp-server --help` once this session before your first
declaration and use the flags you read - `--type`, `--tool-timeout`,
`--enabled-tools` and `--force` exist; `--token` and `--auth` do not.

## Observed failures this skill exists to prevent

- Asked for a server "with auth", the session refused on the word and built
  nothing. The request was complete; the answer was one command.
- A pasted token written into `mcp.yaml`. Values never enter a file.
- A `${VAR}` header declared for a server that issues SHORT-LIVED tokens.
  The reference resolved and the header was sent, so it worked - until the
  token expired, days later, and the user saw only an agent that had lost
  its tools. Ask what issues the credential before choosing the shape.
- `aicore mcp-add ... --workspace <code>` run from inside a build session -
  a write outside the repository. The pack tier is yours; the rest is the
  user's command to run.
