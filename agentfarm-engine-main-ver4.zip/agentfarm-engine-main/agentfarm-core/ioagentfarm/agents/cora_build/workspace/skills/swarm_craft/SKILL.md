---
name: swarm_craft
description: "When creating or editing a swarm: roster semantics, budgets, the deliverable gate, and how a swarm compiles into a run. Read this before touching any swarms/ directory."
---

# Swarm craft

A swarm is a goal, a meta-agent and a roster - not a second engine. It
COMPILES into a one-step workflow at run creation, so everything a workflow
run gets (retries, forensics, the artifact gate, the hard attempt cap) a
swarm run inherits. Author the controls; the machinery is already there.

## Roster semantics are three-valued, and the difference is the control

- `agents:` OMITTED - every registered external agent is available.
- `agents: [a, b]` - exactly those, and an unknown name is warned BY NAME.
- `agents: []` - none.
- `mcp_servers:` mirrors the same three values. A roster is a CAPABILITY
  boundary: when in doubt, list names - scoping down is the point.
- `a2a_consult` is added automatically unless `agents: []`; never add it by
  hand.

## Budgets: one is physics, one is contract

- `budget.tool_calls` is HARD - it becomes the run's `maxToolIterations`
  (floor 20). The run cannot exceed it.
- `budget.consults` is a briefing contract the meta-agent is told to honour
  - judgement, not enforcement. Do not describe it as a hard limit.

## The gate and the checkpoint

- `deliverable:` compiles to `requires_artifacts` - the run fails closed if
  the file is missing, whatever the agent reported. Always set it.
- The generated briefing mandates a `_run_plan.md` checklist; retried
  attempts RESUME from it. Never remove that instruction from meta.md.

## Rules the compiler enforces

- `role: project_lead` is refused - that is the driver's role.
- The compiled role always emits a `skills:` list; that is what triggers the
  filtered workspace carrying the scoped A2A catalog.

## Validate before reporting done

1. `aicore lint-swarm <PATH-to-the-swarm-dir> --json` - lint-clean means
   run-loadable; the linter compiles in memory and graph-validates. **Use
   the PATH.** A swarm in a not-yet-installed solution is invisible by
   name, and "no swarm named ..." is a discovery failure, never a pass.
2. `aicore run-swarm <name> --goal "..." --dry-run` - prints the roster and
   compiled shape, no cost.
