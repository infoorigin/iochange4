---
name: run_ops
description: "When starting, watching or recovering a workflow, swarm or task run: non-blocking starts, reading a run's state, and the recovery rules that must never be fought."
always: true
---

<!-- ALWAYS-ON DELIBERATELY, and the other craft skills are NOT - measured,
not assumed. Across 14 build sessions / 529 messages: solution_builder was
read in 11 (the preamble names it, and that works), and the authoring craft
skills fired in the sessions that authored - workflow_craft and swarm_craft
in the two long build sessions, agent_craft and skill_craft in a third. So
on-demand delivery works when the trigger is "I am about to write a
workflow".

run_ops was the outlier: read ONCE in 14 sessions, in a session that started
no run - and in NONE of the three sessions that did. Its trigger is a
SITUATION rather than an artifact the agent is about to create, and the
agent does not recognise "I am about to wait for something" as a moment
needing guidance. That asymmetry is why this one file is always-on and the
others stay on demand. Keep it SHORT; it is in every turn. -->


# Run operations

The platform is a resilient harness: transient failures are EXPECTED and
absorbed by retry, recovery and the hard attempt cap. Most run-side mistakes
are fighting that machinery. These rules keep you out of its way.

## Starting

- From a build session, ALWAYS start non-blocking:
  `aicore run <workflow> --goal "..." --json` - it returns the run id
  immediately. A blocking run would freeze this conversation for its whole
  duration. Same for `aicore run-swarm ... --json`.
- Report the run id to the user the moment you have it; it is the handle
  for everything that follows.
- Critical work goes through a WORKFLOW, not `run-task`: tasks have no
  auto-retry, so a single model error kills one silently ("done", no
  output). Use run-task only for one-off, low-stakes work.
- Validate before running: lint, then `--dry-run` - a run that fails on a
  YAML mistake wastes minutes that lint catches in seconds.

## NEVER WAIT FOR A RUN INSIDE THE SESSION

Starting non-blocking and then waiting for the result anyway defeats the
point, and asking for the result is what makes waiting feel necessary. It
is not: **the run does not need this session.** It is a detached
subprocess writing to the store, and killing the session does not kill it
- observed live, where a session was terminated mid-wait and the run
carried on to `done` by itself.

What waiting costs, also observed live: repeated `Start-Sleep 90` execs
spent the session's tool iterations and tokens doing nothing, and it was
THE SESSION, not the run, that eventually hit the caller's timeout. The
run had been fine throughout.

So when the user asks you to run something and report the results:

1. Start it with `--json` and give them the run id immediately, **with the
   watch command** - a detached run emits nothing, so an id on its own hands
   the user silence:

   ```
   aicore forensics watch <run_id>
   ```

   It narrates each step as it happens and says WHY when one goes quiet
   (recovery vs stuck). They run it; you do not - it is a loop, and a loop
   inside this session is the thing the section below forbids.
2. Check the state ONCE.
3. If it has finished, read the deliverable and answer.
4. If it has not, say exactly that with the step state so far, and hand
   over the command that shows progress. Offer to read the deliverable
   when they next write. Do NOT sleep, do NOT loop, do NOT poll.
5. Before you call it complete, ask what the run did NOT cover, and say so.

An unfinished run reported honestly is a good answer. A session that
blocked for ten minutes and was killed before it could answer is not.

## When one workflow must follow another, do NOT wait for it

Just start the second one. If it declares `depends_on_runs:` and the first is
still producing, the engine REFUSES it and names the run that is in the way:

```
barrier_detection consumes what these runs are still producing ...
  signal_detection  run_20260816_174845_670401  [running]
```

That is your answer, and it cost one command instead of a polling loop. Report
it, and start the second workflow again when the user next writes in.

This is worth stating because the two rules look contradictory without it: "run
B only after A finishes" seems to require watching A, and watching A is exactly
what the section above forbids. It does not — the engine already knows the
ordering, so asking it is one call, while watching for the moment to ask is
many. A refusal here is INFORMATION, not a failure: it means you were early,
and nothing was damaged by trying.

If the second workflow starts cleanly, the first had already finished. Either
way you learn what you needed in a single command.

## `done` is not the same as complete

A run reaching `done` means every step that ran, ran. It does not mean the
work is finished: a pipeline consumes what is queued for it, and whatever
was never queued is silently absent from the result rather than reported as
missing. Nothing fails. The deliverable simply rests on less evidence than
the user believes, and the confidence scores quietly reflect it.

So step 5 is not optional politeness. Before reporting a pipeline complete:

- Run the domain's own status command and read the BACKLOG line, not just
  the totals. Most solutions print one - `iof-signals status` ends with
  `unprocessed notes (awaiting AI signal detection): N`.
- Compare what went in against what came out. If three extracts were
  ingested and the output only draws on one kind of evidence, say which
  kind is missing and why.
- State it in the answer even when nobody asked. "Four barriers, all from
  rule-derived signals; 100 call notes are still unprocessed so no
  text-derived evidence is included" is a complete answer. "Four barriers"
  is not.

Observed live, and it is why this section exists: a client-simulation
session ran a detection pipeline to `done`, reported four barriers with a
confident narrative, and never mentioned that 100 of the ingested call
notes had not been processed - so every barrier rested on one of the two
detection methods. The number was printed IN ITS OWN TOOL OUTPUT, in the
`iof-signals status` it had already run. Reading a line is not noticing it.
The user had to find it.

## Watching

- `aicore status` - recent runs and step states.
- `aicore forensics explain <run_id>` - the one-command postmortem: verdict,
  per-step table, artifact gates, where to look next. This is the FIRST
  resort for "what happened", never the last.
- Report what the record says, and only that. If the record cannot answer,
  say so and name what you checked - never infer a plausible story.

## When one line is not the answer

`explain` settles most questions. When it does not, four skills go deeper -
read the one that matches what was asked, and do not guess in its place:

| The question | Skill |
|---|---|
| "why did it fail", "what went wrong", "is it stuck", "what went right" | `run_diagnostics` - symptom to the line of YOUR definition to change |
| "is this any good", "can I trust this output", "review the analysis" | `run_review` - quality of the reasoning, not the status |
| "what did it cost", tokens, cache, budget | `run_costs` - via the audit CLI; never estimate a number |
| "show me what it produced", read a deliverable or a step output | `run_context` |

Diagnosing is not licence to re-run: the build-session boundary below still
holds.

## The rules that must never be fought

- NEVER kill or restart a run because it looks stuck. What looks like a
  hang is usually recovery working. Check first:
  `aicore forensics is-recovering <run_id> <step_key>` - exit 10 means
  recovery is in progress; leave it alone.
- A step exceeding a tool timeout while its subprocess keeps running is
  BENIGN - the orchestrator polls until done. Do not "fix" it.
- Every run converges: `done`, or a clean failure under the hard attempt
  cap. Waiting is a strategy.
- `step-retry` and `step-skip` are for runs that have already STOPPED,
  never ones still executing. A run INTERRUPTED whole - Ctrl+C, a dead
  session - takes `aicore resume <run-id>` instead: it reaps what the crash
  orphaned and re-spawns the driver, and it refuses while a driver still
  looks alive, so it cannot double-drive a healthy run. Retry at most once before diagnosing; the
  forensic record, not repetition, is how a failure gets understood.

## The build-session boundary

You start or touch a run ONLY when the user explicitly asks. Building and
running are separate acts, and a run the user did not ask for spends their
tokens on your initiative.
