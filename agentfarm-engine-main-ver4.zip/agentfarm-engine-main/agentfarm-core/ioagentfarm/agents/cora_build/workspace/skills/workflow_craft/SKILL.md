---
name: workflow_craft
description: "When creating or editing a workflow: step prompts, artifact gates, catalog wiring, skills filters and the failure modes each exists to prevent. Read this before touching any workflows/ directory."
---

# Workflow craft

The scaffold gives a workflow its shape; this skill is the judgement that
fills it. Every rule here exists because its absence broke a real run.

## Gates and keys

- Every step declares `requires_artifacts: [<file>]` — exact spelling, plural.
  The gate flips a step to failed when the deliverable is missing, even if
  the agent reported success; without it, a broken handoff becomes the next
  step's hallucination. The loader IGNORES unknown keys silently, so a typo
  disables the gate with no error — `aicore lint-workflow <name> --json`
  after every edit is not optional.
- A `skills:` list on a role is the EXACT set for that job. Any `always: true`
  skill it does not name is DROPPED (only `output_protocol` is added back).
  Omit `skills:` entirely to keep the agent's full baseline; never write a
  short list copied from another workflow.
- `vars:` carries per-workflow configuration; reference as `{{var}}` in any
  step prompt. Deterministic work belongs in a `type: exec` step, not an
  agent — if the step's correct behaviour can be written as a script, it
  should be a script.
- `timeout: <seconds>` on an exec step is its own ceiling. Without it the
  step inherits `IOF_EXEC_STEP_TIMEOUT_S`, one value for the whole
  deployment — so a 20-second staging step and a 30-minute query step get
  the same one. State the ceiling on the step; keep the deployment default
  above the largest, or it fires first and the per-step value never applies.

## Artifacts: one shared directory

`{{output_dir}}` is the SHARED artifacts directory for the whole run, and it
is where `requires_artifacts` is checked. It is not the step's own folder.

- Steps never traverse. A later step reads `{{output_dir}}/plan.json` — no
  `../`, no step-key path segment.
- Namespace filenames by step. Two steps writing `results.json` overwrite
  each other in silence.
- **Fan-out items share it too.** Every materialized `story:<id>:<suffix>`
  step renders the same `{{output_dir}}`, so a per-item output MUST carry
  the item in its path — `reasoning/{{story_id}}.json`. Without that, nine
  items leave one file and eight silent losses.
- **A step that READS `{{output_dir}}/<file>` depends on the step that
  is gated on it.** `deps:` is the only thing that orders steps - a
  parallel driver starts everything whose deps are done, so a reader
  without the dep can run first, fail on a missing file, and pass on
  retry: a green run that was wrong once. `lint-workflow` warns.

## Parallelism, and who decides the order

Nothing in a workflow says "run these in parallel". Two steps whose `deps`
are satisfied at the same moment are runnable at the same moment — the DAG
is the parallel construct. Three levels, and a real pipeline uses all three:

1. **Inside one exec step** — the tool's own concurrency, one process. This
   is right whenever each item's work is a script; making them steps instead
   caps them at `IOF_FANOUT_MAX_CHILDREN` and adds a subprocess each for no
   recovery benefit.
2. **Sibling steps** — two steps declaring the same `deps`.
3. **Fan-out items** — `stories_from` on an exec step plus `per_item_steps`,
   one materialized step per manifest entry. Use this when each item needs an
   AGENT; the items are then claimed, retried and captured independently.

`per_item_steps` carries only `key_suffix`, `role`, `prompt`, `title`,
`max_attempts`, `deps` and `mcp_tools` — **no `requires_artifacts`**. So a
fan-out cannot be gated item by item: follow it with an exec step
(`deps: [<anchor>]`, which the engine rewires onto every story step) that
asserts every expected output exists. Without that the run can finish short
and report success.

## The two turns a DAG can take

A `deps:` graph cannot loop or branch on data. Two fenced constructs give it
both without giving up what makes it lintable - every reachable step is still
in the YAML, and every loop is bounded by a number a reviewer can read.

**Branch on data - `type: route`.** Runs `command` like exec; the tool then
says which of the step's DECLARED `routes:` run, and the rest are closed
("skipped by route"), along with anything reachable only through them:

```yaml
- key: triage
  type: route
  routes: [deep_dive, quick_note]     # the universe of turns - every one a real step
  command: iof-x-triage --out {{output_dir}}
  requires_artifacts: [triage.json]
- key: deep_dive
  deps: [triage]                      # a target MUST depend on the route step
  ...
```

In the tool: `from ioagentfarm.sdk import route; route.next("deep_dive")`. A
name outside `routes:` fails the step BY NAME - a switch, never a goto. A join
that also depends on a live branch still runs. When the correct branch can be
computed, write a route; when only a model can tell, keep `--driver agent`.

**Go back with feedback - `on_fail`.** A gate that rejects the work sends its
producers back to pending, carrying a critique:

```yaml
- key: verify
  type: exec
  deps: [draft]
  max_attempts: 3                     # THE LOOP'S BOUND - say it here
  on_fail: { reset: [draft], feedback: critique.md }
  command: iof-x-verify --out {{output_dir}}
```

In the tool: `route.fail("Section 3 cites a figure not in the evidence.")` -
it writes `critique.md` and exits non-zero. `draft` and everything downstream
of it that already ran go back to pending; the text lands in draft's
"Feedback from previous attempt" (an exec tool reads `route.feedback()`).
When verify's own attempts are exhausted the failure stands, nothing is
reset, and the run is `blocked` - a person retries. Name a producer this step
actually depends on; resetting anything else changes nothing it consumes.

Both are applied by the ENGINE at step finalization, so they work under any
driver. Neither is needed for a straight pipeline - reach for them only when
the sequence genuinely depends on output.

**`aicore run <wf> --driver code`** puts the step order in the DAG instead of
in project_lead, and dispatches every runnable step together. Recommend it
for a pipeline whose sequence is fully determined by its `deps` — it removes
the model from the control plane and makes independent branches actually run
in parallel. It does NOT make the run AI-free and must never be described
that way: every step still runs whatever the workflow says, agents included.
Keep the default `--driver agent` when the route genuinely has to be decided
at runtime.

## Step prompts

- First instruction: read `{{metadata_dir}}/catalog.yaml` before querying
  anything, and never guess an entity or column that is not in it. A gap is
  a finding — "not available in `<entity>`" — never an invention.
- Instruct the agent to print one line of text before EVERY tool call. The
  stream consumer requires a text block ahead of tool use; without the line,
  turns fail in ways that look like network errors. **The scaffold already
  writes this into every step prompt it generates — when you author over
  that file, keep the line.** It was dropped in all three steps of a real
  workflow while the other rules on this page survived, which is why
  `lint-workflow` now warns when a step prompt lacks it. Treat that warning
  as a defect, not noise.
- Large deliverables use SECTIONED COMPOSITION: each section written to its
  own temp file (`_<step>_section_NN_<name>.md`), assembled by a final exec
  `cat` into the deliverable. Single-shot composition of a large file stalls
  the stream and fails after minutes of apparent work.
- Every figure carries its source — entity plus the filter that produced it.
  End the prompt with the output contract: `STATUS: done|failed` and
  `OUTPUT: <summary>`.

**QUOTE FIGURES BACK FROM THE ARTIFACT; NEVER RESTATE THEM FROM MEMORY.**
When a step computes numbers into a JSON file and then writes prose about
them, instruct it to RE-READ that file and quote from it. The prose is
composed many turns after the number was computed, so the model is
reconstructing rather than recalling — and reconstruction is confident and
occasionally wrong. Observed live: a prescriber step reported prior NBRx of
621 and 560 in its markdown while the JSON it had written itself held 506
and 409. Nothing in the step caught it; the downstream reviewer did, by
opening the JSON. Write the instruction explicitly — *"before composing,
read `<file>` and take every figure from it verbatim"* — because an agent
that just computed a number does not feel any need to look it up.

A downstream step must do the same: read the UPSTREAM ARTIFACT, not the
upstream step's prose summary. Prose is a report about the data; the JSON
is the data.

## The catalog

- `metadata/catalog.yaml` descriptions carry REAL data: cardinality, value
  ranges, totals, distributions. That is what grounds the agent.
- Descriptions only — no example queries, no do-not lists, no from-clauses.
  Those bias the shape of every query the agent writes.
- Sample data goes in `metadata/data/` beside the catalog, never the repo
  root: `{{metadata_dir}}` resolves to the workflow's own metadata.

**DERIVE every figure from the file; never state it from your plan.** After
writing sample data, COMPUTE the row count, distinct counts and totals by
reading the file back, and write those numbers into the catalog. Observed
live: a catalog authored alongside its own sample data claimed 7 plans and
2,050,000 lives while the file beside it held 9 plans and 2,048,000 — the
figures came from the intent, and the data drifted from it during writing.
The run agent queried the file and reported the truth, so the damage was
not a wrong answer this time; a catalog that misstates its own data is
still a grounding surface that lies, which is the one thing it must not be.

**Sweep the COLUMN descriptions too, not just the entity.** They are seeded
with placeholder figures and are easy to leave behind: the same catalog
still told the agent the `plan` column held "approximately 1,100 distinct
plans" against a 9-plan file. A stale column description outlives the
entity description that was updated around it, and it is read at exactly
the moment the agent decides whether a query is worth running.

**A CATALOG ENTITY WITH NO RESOLVABLE SOURCE IS A BROKEN WORKFLOW, AND
NOTHING CATCHES IT.** Lint validates structure and dry-run prints the DAG;
neither opens the data. A workflow that lints clean, dry-runs clean, and
declares `source: "data/claims.parquet"` with no such file sends the first
step hunting for data that does not exist - observed live, where the agent
correctly refused to fabricate and the run produced empty artifacts. So
when you declare an entity, do ONE of these and say which:

1. write a small representative sample to `metadata/data/<file>` yourself
   and point the catalog at it - the default for a new workflow, because it
   makes the pipeline runnable the moment it is created; or
2. point the entity at a database the workspace already has configured; or
3. state plainly in your reply that the workflow is NOT RUNNABLE until the
   user supplies `<file>` at `<path>`, and name both.

Never report a data-backed workflow as finished on lint alone.

## Validate before reporting done

1. `aicore lint-workflow <PATH-to-the-workflow-dir> --json` — zero errors
   AND zero warnings. **Use the PATH, not the name.** A workflow in a
   solution that has not been `pip install -e .`-ed is invisible to
   name-based lookup: `lint-workflow <name>` answers "no workflow named
   ..." and that is a DISCOVERY failure, not a clean bill of health. In a
   solution that is not yet installed, the path form is the only one that
   tells you anything.
2. `aicore run <name> --goal "..." --dry-run` — the DAG prints, no cost.
   This one DOES need the pack installed; if the name is not found, run
   `pip install -e .` in the repo — the session confirms it with the user
   before it runs — and retry. If the install is declined, or the session
   cannot ask (a one-shot), say so rather than reporting a pass.
3. Report both results verbatim; a lint you did not run is a claim, not a
   result, and a "not found" is never a pass.
