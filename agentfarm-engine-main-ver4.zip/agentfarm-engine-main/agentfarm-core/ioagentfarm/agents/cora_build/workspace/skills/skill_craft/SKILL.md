---
name: skill_craft
description: "When creating or editing a skill: the always-on decision, trigger-phrased descriptions, frontmatter traps, and tool pairing. Read this before writing any SKILL.md."
---

# Skill craft

A skill that loads but never fires looks identical to one that works. Every
rule here prevents a silent version of that failure.

## The one decision that decides everything: `always`

A carried skill reaches the agent one of two ways, and choosing wrongly is
invisible — nothing errors, the skill is simply never consulted.

| Choose | When |
|---|---|
| `always: true` — full text in every request | The judgement must govern EVERY answer: output contracts, formatting rules, grounding discipline, safety boundaries. |
| omit (on demand) — name + description only; the agent reads the file when the job matches | Task-specific judgement, where loading the text every time wastes context. |

The test: "must this hold even when the user's request is a complete,
self-contained instruction?" If yes, `always: true` — an on-demand skill
does NOT fire on a direct instruction the model can satisfy without it. A
formatting skill left on demand is the canonical silent failure: the agent
is told a formatting skill exists, answers directly, and the rule never
applies.

## Frontmatter, and the ways it silently breaks

- `description` is ALWAYS double-quoted. An unquoted value containing ": "
  makes YAML reject the WHOLE frontmatter (`mapping values are not allowed
  here`), so the skill loads with no name and no description and can never
  be matched. `aicore lint-skill <dir>` catches it.
  `<<` anywhere in frontmatter is the YAML merge key, not text.
- `name:` must equal the directory name; the DIRECTORY is what the runtime
  resolves and what a workflow's `skills:` list names. Lowercase with
  underscores — an editor that flags the underscore is applying someone
  else's schema; ignore it.

## The description is the trigger

For an on-demand skill, the description is the ONLY thing the agent matches
a job against. Phrase it as the situation, not the mechanism: "When a
delivery window was missed and the carrier disputes it" fires; "helper for
the deliveries table" never does. In a workflow, firing also needs the step
prompt to describe the job in the skill's terms — naming it in `skills:`
controls carriage, not use.

## Body shape

Three sections earn their place: *When this applies* (the situation), *How
to work* (concrete steps, smallest results), *What not to do* (the mistake
this skill exists to prevent — every skill has one, usually the thing that
looks reasonable and is subtly wrong). No figures from any specific dataset:
a skill is transferable technique, never a conclusion.

## Pairing with a tool

A skill that teaches a CLI tool is created with
`aicore new-skill <name>_usage --tool <tool> [--role <agent>]` — the command
verifies the tool is declared in `tools.yaml` and puts the binary in the
description. Never write a skill that instructs an agent to run a binary
nobody installed: the agent burns the step's attempts on "command not
found".

## Never fork a shared skill

If an SDK or pack skill already carries the judgement, ASSIGN it
(`aicore assign-skill <name> --role <agent>`); copying its content into a
workspace freezes a fork no upgrade will ever reach.

## Validate before reporting done

`aicore lint-skill <PATH-to-the-skill-dir> --json` - zero errors. It
catches the frontmatter traps above, which are otherwise invisible
until an agent silently fails to match the skill to a job. Use the
PATH; a skill in a solution that is not installed is invisible by
name, and that is a discovery failure, never a pass.
