---
name: solution_design
description: "When the user describes a GOAL, a problem or an outcome rather than a component - 'we need to reduce contract risk', 'how should we approach X', 'what would you build' - propose the shape before building it: what the platform's primitives can carry, two or three options with their real tradeoffs, a recommendation, and the smallest first slice. Read before scaffolding anything for a request that did not name what to create."
---

# Solution design - decide the shape before you build it

`solution_builder` answers *"create a skill for X"*. This answers *"we have
this problem"*, which is a different job and the one that goes wrong more
expensively: scaffolding the first thing that sounds right produces content
nobody asked for, and the user discovers the mismatch after the work exists.

**The tell.** The request names an OUTCOME, not an artifact: "we want to
catch renewal risk earlier", "our analysts spend a day a week on this",
"how should we approach vendor onboarding", "what would you build for X".
No agent, no workflow, no skill is named. That is a design request even when
it arrives phrased as an instruction.

## What you are choosing between

The platform has five shapes and they are not interchangeable. Knowing which
one fits is most of the value you add:

| Shape | Use it when | Wrong when |
|---|---|---|
| **A skill on an existing agent** | The agent already has the data and the job is judgement | The work needs different data or a different identity |
| **A new agent** | A distinct role with its own identity, tools and memory | It is one more thing an existing agent already does |
| **A workflow** | The steps are KNOWN and ordered, and each has a deliverable | The route depends on what earlier steps find |
| **A swarm** | The GOAL is known, the route is not, and a meta-agent should decide | The sequence is fixed - a workflow is cheaper and more legible |
| **A CLI tool** (`new-tool`) | The answer is deterministic - a calculation, an extract, a query | It needs judgement; an agent asked to compute returns something plausible and occasionally wrong |

Two more that are not "content" but are often the real answer: an **MCP
server** (the data lives in a system the agent should query live, not a file
someone pastes) and **nothing at all** (the user already has a tool that does
this and needs it wired, not rebuilt).

## How to answer

**One turn. Options, tradeoffs, a recommendation, and the first slice.**
Do not scaffold yet, and do not ask a list of questions before saying
anything useful - a design you can react to beats an interview.

1. **Say the problem back in one line**, in their words, including the part
   you are least sure of. If you got it wrong they correct one sentence
   instead of rejecting a built thing.
2. **Two or three options, each with what it costs.** A tradeoff is not
   "simpler vs more complex" - name what each one cannot do. "A workflow
   makes the order explicit and auditable, and it cannot adapt when the
   first step finds nothing" is a tradeoff; "a workflow is more structured"
   is not.
3. **Recommend one, and say why in a sentence.** A design that ends with
   "let me know which you prefer" hands the decision back with none of the
   judgement they came for. Recommend FIRST and mark it, then list the
   others.
4. **Name the smallest first slice** that produces something real - usually
   one agent and one skill against real data, not the whole shape. What you
   learn from it changes the rest.
5. **State what you would need**, precisely and briefly: which system holds
   the data, whether there is an API or a database, who the user of the
   output is. Two or three items, not a questionnaire.
6. **End with the one-line command that starts it**, so approval is a word
   and not a new conversation: "Say go and I will create the `renewal_watch`
   agent with a `contract_risk` skill against the vendors MCP server."

## Ground the design in what is actually here

**Read before you propose.** A design that ignores what the repository
already has is a rebuild pitched as a plan. Before answering: list the
agents, skills and workflows that exist, and check `aicore mcp-list` for
data the deployment can already reach. Then say explicitly what you would
REUSE - "extend `procurement_max` rather than add an agent, because it
already carries the vendor tools" is worth more than any diagram.

**Design for the grain of the platform.** Two properties are worth building
around because they are load-bearing here and rare elsewhere:

- **A deliverable gate.** A workflow step can declare `requires_artifacts`,
  and the step FAILS if the file is missing however confidently the agent
  reported success. Where the output matters, put the gate in the design and
  say so - it is the difference between a pipeline that reports done and one
  that is done.
- **Deterministic work belongs in a tool.** If part of the job is a
  calculation, a filter or a query, propose `new-tool` for that part and let
  the agent reason over its output. This is the single most common design
  improvement available, and the reason is not style: an agent asked to
  compute produces an answer that is plausible and occasionally wrong, with
  nothing to tell the two apart.

## After they choose

Switch to `solution_builder` and build it - scaffold command first, real
content into the files it made, lint, report. Keep the design visible while
you do: if building reveals the design was wrong, say that in one line and
stop, rather than quietly building something else.

**Record the decision.** A design chosen and its constraint is exactly what
`CORABUILD.md` is for - one entry, the shape and why, so the next session
does not re-litigate it. Not the options you rejected; the decision and what
it depends on.

## What makes a design answer bad

- **A questionnaire.** Four questions and no proposal. You have enough to
  propose something and be corrected.
- **Every option presented as equal.** That is not neutrality, it is
  withheld judgement.
- **A shape with no first slice.** "Build a swarm with five agents" is a
  wish; "start with one agent against last month's extract" is a plan.
- **Diagrams instead of decisions.** Boxes and arrows that do not say which
  of the five shapes each box IS.
- **Scaffolding while proposing.** If you create files in a design turn the
  user cannot say no cheaply, which is the entire point of proposing first.
