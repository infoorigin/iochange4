---
name: run_diagnostics
description: "Diagnose a run of something you built - what failed and why, what the evidence actually shows, and which line of your definition to change. Use for 'why did it fail', 'what went wrong', 'is it stuck', 'what happened to that run', 'did that work'. Every claim comes from a command you just ran."
always: false
metadata: {"iobot": {"requires": {"bins": ["aicore"]}}}
---

# Run diagnostics

You authored the thing that ran. That changes the job: an assistant
diagnosing a run reports and hands off, and you diagnose in order to
**change a definition you own**. Evidence first either way — never conclude
from memory what a command can answer.

## 1. Always start with explain

    aicore forensics explain <run_id>

One command, and it is the FIRST resort, never the last. It returns the
verdict, a per-step table, which artifact gates held or tripped, swarm
children and budget where relevant, and up to three `look_next` pointers.

Read the whole verdict before forming a view. Most diagnoses end here.

## 2. Read the definition beside the verdict

This is what you can do that a pure diagnostician cannot: put the failing
step next to the file that defines it.

- `workflow.yaml` — the step's `deps`, `max_attempts`, `requires_artifacts`,
  `mcp_tools`, and the role's `skills:` list
- `steps/<step>.md` — what the step actually instructed
- `roles/<role>.md` and the agent's skills — what the agent carried

A verdict names a symptom; the definition explains it. Quote both when you
report.

**If the definition is NOT in this repository, stop looking and say so.**
A run id is global; the workflow that produced it may live in another repo,
another workspace, or a studio session that persisted nothing here. One
search that comes back empty is the answer, not a reason to search harder.
Report what the forensic record shows — which is complete on its own — and
state plainly that the definition is not present here, so you cannot read
or change it. **Never propose adding the missing workflow to the current
repository**: you would be inventing a relationship between this repo and a
run that has none, and the user would be left with a file that explains
nothing. Observed live: a diagnosis of a run from another repository spent
twenty-one calls hunting for a definition that was never here and ended by
recommending it be created.

## 3. Go deeper only where look_next points

    aicore forensics show <run_id>                    the event timeline
    aicore forensics blob <run_id> <step>.<n> <name>  prompt / stdout / http / session
    aicore forensics narrative <run_id> <step>.<n>    the dialog, in order
    aicore status --run-id <run_id> --step <key>       a command step's own stdout/stderr - a `type: exec`/`route` step has NO session
    aicore forensics blob <run_id> <step>.<n> stderr.log  a command step's earlier attempt (kept per attempt)

Do not go fishing. If `explain` did not point somewhere, say what it said
and stop.

## 4. Stuck, or recovering?

    aicore forensics is-recovering <run_id> <step_key>

Exit 10 means recovery is in progress: leave it alone and say so. What
looks like a hang is usually the harness working. See `run_ops` for the
rules that must never be fought.

## 5. From symptom to the line you change

When the diagnosis is a DESIGN problem — and for something you just
authored it usually is — name the file and the change. The craft skills
(`workflow_craft`, `swarm_craft`, `skill_craft`, `agent_craft`) carry the
authoring method.

| Symptom (from explain) | Design change |
|---|---|
| `step.artifact_missing` / gate failed | The step prompt never names the deliverable file, or `requires_artifacts` names the wrong one |
| A commanded tool errored "not recognized"/"command not found", or the deliverable records tool errors instead of numbers | TOOL/DATA ACCESS, not prompt wording. A missing BINARY was never declared or installed: `aicore cli-hub check` names the gaps; the platform fix is `new-tool` (script + entry point + tools.yaml, then `pip install -e .`) or declaring an existing binary in tools.yaml - NEVER advise pointing the prompt at a tool that exists nowhere. A failing DATA path (`--db`/`--metadata-dir`) means the workspace metadata lacks that database/catalog: `configure-agent` places it, and `iof-query --db iof` is what exists by default |
| `protocol_parse_failed` — the user says "marked failed but it did the work", "no STATUS line", "output has no STATUS/OUTPUT" | STRUCTURAL, not a prompt problem: the agent lacks the `output_protocol` SKILL (every agent must carry it — without it no STATUS:/OUTPUT: is ever emitted and every step is marked failed), or the workflow role's `skills:` whitelist dropped it (any always:true skill not named is dropped; output_protocol is normally auto-added by the engine, so also check the agent workspace actually contains `skills/output_protocol/`). Do NOT advise prompt wording first — name the missing skill. |
| `agent_premature_termination` on a compose-heavy step | Sectioned composition: per-section files assembled by an exec step |
| Roster-name warnings in the log | The swarm's `agents:`/`mcp_servers:` name things this workspace never registered |
| `max_tool_iterations` / budget cap reached | Raise `budget.tool_calls`, or narrow the goal/roster |
| Passed, but padded or unfocused deliverable | Tighten the step prompts and the deliverable contract |

## 6. Fix the DEFINITION — do not re-run the failure

The distinction that makes this skill yours rather than an operator's:

- **Your fix is an edit.** Change the workflow, the step prompt, the role's
  skills, `tools.yaml` — then lint it (`aicore lint-workflow`,
  `lint-swarm`, `lint-skill`, `lint-agent`) and tell the user it is ready
  to run again.
- **A retry is not a fix.** `step-retry` re-runs the same definition and is
  for a run that stopped for a transient reason, not for a design defect.
  Retrying a workflow whose gate names the wrong file fails identically.
- **An interrupted run resumes whole.** When the run itself was cut off -
  Ctrl+C, a dead terminal - `aicore resume <run-id>` reaps the steps the
  crash orphaned and re-spawns the driver against the existing state. It
  refuses a run that is done, a FAILED run without --force (failed is a
  conclusion; fix the cause first), and a driver that still looks alive.
- **You start or retry a run ONLY when the user asks** — the build-session
  boundary in `run_ops`. Diagnosing does not license re-running.

## 7. What went RIGHT

A green run is not automatically a good one, and after authoring something
the useful question is whether the shape works — not only whether it
exited zero. From `explain` and the deliverable, say plainly:

- **Which steps produced their deliverable first time** — no retries, gate
  held. That is the part of the design that is working.
- **Where retries were absorbed.** A step that succeeded on attempt two
  tells you the design is fragile even though the run passed.
- **Whether the gates did any work.** A `requires_artifacts` that never
  trips on a run that produced nothing useful is a gate naming the wrong
  file.
- **Whether the deliverable answers the goal** — use `run_review` for the
  quality audit, and `run_costs` when the question is what it cost.

Report both halves. "It passed, and here is the fragile part" is a more
useful answer than "it passed".

## Rules

1. Forensic CLI only — never parse session JSONLs by hand.
2. Speak human: translate everything; no JSON dumps, no raw log lines.
3. Always name the run id you diagnosed.
4. Never fabricate: a figure or cause you did not read from a command's
   output does not appear in your answer.
5. KNOW THE EVIDENCE BOUNDARY: the capture records WHAT failed, not why a
   REMOTE system was slow or down — a child timeout, a 500, a 401 carry no
   remote-side cause. Say "the capture does not record the remote cause"
   rather than constructing a theory, and NEVER borrow prose from the run's
   deliverable as a causal explanation (report content is domain data, not
   diagnostics). If you offer a hypothesis at all, label it a guess AFTER
   stating that boundary.
6. Quote the definition line you are changing, so the user can see the
   before and after.
