---
name: agent_craft
description: "When creating or editing an agent: what belongs in a SOUL, what never does, the one-accountability rule, and the files an agent cannot function without. Read this before writing any SOUL.md."
---

# Agent craft

An agent is an identity that many workflows borrow. Author it for every job
it will ever be given, not the one in front of you.

## What a SOUL is, and is not

- A SOUL carries IDENTITY and JUDGEMENT BOUNDARIES: who the agent is, what
  it optimises for, what it refuses, how it reports. It is never templated
  and never edited by a run.
- Task instructions do NOT belong in a SOUL — they belong in the workflow
  step prompt that borrows the agent. A SOUL that says "compute on-time
  rates for Q3" is wrong twice: it decays, and it leaks one workflow's job
  into every other workflow's context.
- Dataset names, entity names and figures do not belong in a SOUL. The
  catalog supplies the dataset at run time; one agent serves many datasets.

## One accountability

One agent owns ONE kind of judgement. "Analyses supply data and also
reviews compliance" is two agents, or one agent plus a reviewer step —
a dual-mandate SOUL produces an agent that hedges both jobs. If a request
needs two accountabilities, say so and propose the split.

## The files an agent cannot function without

- `skills/output_protocol/` — REQUIRED, and the scaffold places it. An
  agent without it emits no `STATUS:`/`OUTPUT:` marker, so every workflow
  step it runs is recorded failed and retried. Never delete it, never
  rewrite it.
- `memory/MEMORY.md` exists but is governance-managed; never author
  conclusions into it and never instruct the agent to.
- `TOOLS.md` lists what the agent may run; the paired skills say WHEN. A
  tool listed nowhere is invisible; a skill teaching an unlisted tool is a
  trap (see skill_craft).

## Shape and naming

- Role slug: lowercase_underscores (`brand_analyst`); the display name
  ("Priya") lives in the SOUL and is set by `new-agent --name`.
- Structure that reads well: who you are · what you optimise for · how you
  work · how you report · boundaries. Boundaries are the section most
  authors skip and the one that most changes behaviour — state what the
  agent refuses and what it escalates instead.
- Keep it under a page. A SOUL competes for context with the skills and the
  step prompt on every single turn.

## A specialisation is a SKILL, not a paragraph in the SOUL

`new-agent` gives an agent an identity and `output_protocol` - nothing
else. The job the user described ("helps with LiteLLM installs and
troubleshooting", "reviews promotional material") is METHOD, and method
lives in a skill: `aicore new-skill <name> --role <role>`, then write the
how-to into its `SKILL.md`. An agent created from a request that
describes a job and left with only `output_protocol` is half built, and
the user will ask where its skills are. Measured twice on a client box.
So: when the request describes what the agent DOES, scaffold at least one
skill for it in the same turn, and name it in your report.

## Cloning - "an agent like X"

A twin carries X's skills. `aicore new-agent <role> --like <x>` copies
every skill directory X holds into the new agent; write the new SOUL
yourself (identity is never copied). Without `--like`, a new agent has
only `output_protocol`, whatever X had.

## Names core already ships

`new-agent` refuses a role that an installed pack already ships
(`project_lead`, `analyst`, `developer`, `reviewer`, `jarvis`,
`queryngine`, `cora_build`, ...): a run resolves agents by name in
registry order and would run the other pack's agent in its place. When
the user wants "a project lead called George", the role is
`<pack>_project_lead` (or any name that is theirs) and the workflow's
`role:` uses that.

## After creating

Smoke it: `aicore agent-chat --role <role> -m "Who are you and what do you
do?"` — standalone on this box by default (no server, no run lookup; the
agent is resolved from the pack on first use, so no seeding step comes
first). The answer should sound like the SOUL, name its boundaries, and
claim no dataset.

## Validate before reporting done

`aicore lint-agent <PATH-to-the-agent-dir> --json` - zero errors. It
checks the identity files, the a2a card, every skill the agent
carries, and the one that costs most: an agent with no output
contract emits no `STATUS:`/`OUTPUT:`, so every step it runs is
marked failed and retried to the attempt cap having done the work
correctly every time.
