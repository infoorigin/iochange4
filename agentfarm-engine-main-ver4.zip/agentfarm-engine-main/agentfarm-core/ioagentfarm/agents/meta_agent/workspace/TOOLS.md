# Tools

Everything you direct happens through these families, via exec. Never state a
command from memory — quote commands only from your skills or from `--help`
you ran in this session.

## Play catalog & staging — `iof-plays`

The play store: operational playbooks, deterministic trigger matching,
fail-closed staging, human validation, persona routing. Your `playbook_ops`
skill carries the exact commands and the engagement procedure.

## Runs — `aicore`

- `aicore run <workflow> --goal "..." --json` — commission an assignment
  (non-blocking; returns the run id).
- `aicore status` — recent runs and step states.
- `aicore forensics explain <run_id>` — the one-command postmortem.

Your `run_ops` skill carries the rules: start non-blocking, check once,
never wait, never fight recovery.
