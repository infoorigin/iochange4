---
name: playbook_ops
description: "The engagement procedure: matching a business trigger to an operational playbook, commissioning its workflows, honoring the human-validation gate, and reporting from records."
always: true
---

# Playbook operations — how you run an engagement

An engagement is one business situation handled under one approved playbook.
You run it end to end: match, commission, report, escalate, close. The
platform executes; you direct and narrate.

## 1. Match the trigger

When a message describes a business situation or names a trigger, match it
before anything else:

    iof-plays match --trigger "<the user's message, verbatim>" --requester "<who is asking>" --json

- `matched: true` → note `play_id`, `workflow_generate`, `workflow_deliver`
  and `params_needed`.
- `ambiguous: true` → the text names MORE THAN ONE play. Present the
  candidates and ASK which applies. Never pick one silently — a wrong
  match is a governed execution of the wrong procedure.
- `matched: false` with `known_triggers` → the user may have PARAPHRASED
  ("our speaker didn't turn up" for "Speaker No-Show"). If one known
  trigger clearly means what they said, STATE your reading ("I read this
  as <trigger>") and re-run match with that canonical phrase — the match
  itself stays deterministic and recorded. If no known trigger clearly
  applies, say so, list them, and stop. Never improvise an unapproved
  procedure, and never stretch a trigger to fit.
  The miss itself is RECORDED by `match` (`recorded: true`, with
  `times_asked`): tell the requester their request has been noted as
  something no playbook covers yet, and do not re-run the same miss to
  "check again". `iof-plays unmatched` lists what has been asked for and
  not covered, most asked first — the input for the next playbook.
- Asked what a playbook CAN ask for, or how to write one: `iof-plays
  template` renders it from what this workspace declares. Asked what
  playbooks have asked for that the workspace lacks: `iof-plays
  capability-requests` (recorded at compile-stage; the other half of
  "what to build next" beside `unmatched`).

## 2. Check the parameters

`params_needed` lists what the playbook requires (for the summary play:
account_id, brands, persona). If the user's message already contains them,
proceed. If any are missing, ask for exactly the missing ones — one short
question — and wait.

## 3. Commission the engagement

One delegation, non-blocking, the business trigger passed verbatim as the
goal (the workflow's intake step parses it):

    aicore run <workflow_generate> --goal "<the user's trigger message>" --json

Report the run id to the user immediately. Then check state ONCE
(`aicore status`); report what it says. NEVER wait, sleep or poll — see
run_ops. The run does not need this conversation to finish.

## 4. The human-validation gate

When the generate run completes, the pipeline stages its deliverable for
human validation. Report it:

    iof-plays pending --json

Tell the user the staging id and that a person must validate it:

    iof-plays approve <staging_id> --as <their name>

**You never run approve or reject yourself.** If asked to, decline in one
line: validation is a human gate by playbook policy.

## 5. Delivery — only after approval

When the user confirms the staging is approved (or asks for delivery),
commission the deliver workflow with the staging id in the goal:

    aicore run <workflow_deliver> --goal "Deliver approved staging <staging_id>" --json

The routing step refuses anything not approved — if it refuses, report that
verbatim; do not retry around it.

## 5b. CASE-species plays (long-running escalation ladders)

A play whose policy says `species: case` (e.g. OS Vacancy) runs as durable
CASES, not as one pipeline. The rulebook decides every move; you relay
events and commission the actions it names. Never decide a transition
yourself, never track a case's position in this conversation.

**Nothing is memorized — everything resolves from the match.** There may
be hundreds of plays. The match output IS the play's operating contract:
its `policy` (species, template, roles, windows) and its workflow names.
A case play's ACTION WORKFLOW is its `workflow_generate` field (usually
the shared generic case-action workflow). Read it from the match; never
recall a workflow name from a previous engagement.

**Opening.** When the trigger arrives (it names the group — e.g. a barrier —
and the affected items/territories):

    iof-case open --play <play_id> --group <group_ref> --items "A,B,C"

The output names, per case, the rule that fired and the ACTION required.
For each opened case, commission the play's action workflow — one
delegation per case:

    aicore run <workflow_generate from the match> --goal "case:<case_id> action:<action> — <one line of context>" --json

Where the action's delivery is a WORKFLOW (the rulebook says
`"delivery": "workflow"`), the action workflow commissions that run
itself (`iof-case commission`) and the scheduler applies its result to
the case when it finishes. You do not start the run, and you never relay
its completion by hand: `iof-case runs` shows what is commissioned and
what has settled.

**You need not commission every notice.** The scheduler dispatches the
action workflow for every undelivered decision on its next pass — the
ones the clock made at night included. Commissioning the FIRST notice
yourself right after `open` is fine and faster; the platform refuses a
second delivery of the same decision, so you cannot double-send. `iof-case
dispatch --dry-run` says what is owed right now.

**The rulebook is DATA, not something you remember.** Each template
family's states, typed events and actions live in the database:

    iof-case rulebook show <template_id>

Never assume one play's vocabulary applies to another (OS Vacancy says
backfill_received; a sample-discrepancy case says count_submitted). A
revised rulebook takes effect immediately — what you read yesterday may
have gained a state or a role today, which is exactly why you read it
instead of remembering it.

**Events.** When the monitoring process (or a person) reports something
about an item, relay it as ONE typed event from that template's rulebook:

    iof-case transition --case <case_id> --event <event> --detail "<verbatim source>" [--key <occurrence id>]

- When the report carries an occurrence identifier (a clock id, a
  notification id, a deadline timestamp), pass it as `--key` — a retried
  delivery of the same occurrence is then suppressed instead of firing
  the next rung. Never invent a key; omit it when the source has none.
- A FREE-TEXT reply (a DM's email, a manager's message) is the ONE place
  your judgement enters, and the CRITERIA are the play's, not yours:
  read the template's `event_rubrics` (`iof-case rulebook show
  <template>`) and classify against them. State the classification, the
  rubric line it satisfies, and the quoted evidence in --detail, then
  transition. If NO rubric clearly fits — the reply is vague, mixed, or
  between two rubrics — do NOT transition: report the reply and your
  doubt to the user and ask; a wrong classification executes the wrong
  rule deterministically.
- The transition output names the rule and the ACTION. If the action is
  anything other than `close`, commission the play's action workflow with
  it, as above. `close` needs no workflow — the rulebook already closed
  the case.
- When the action's delivery is `open_play` (the rulebook orders CHILD
  cases of another play), include the children in the goal as
  `items:<comma-separated>` — they come from the triggering event (the
  accounts/territories it named), never from your memory:

      aicore run <workflow_generate> --goal "case:<case_id> action:<action> items:MEM-004,MEM-007 — <one line of context>" --json

  The action workflow opens and links the children and records the
  delivery. Never open the children yourself with `iof-case open` — the
  delivery must land on the parent's ledger through its pending action.
- A REFUSED transition (unmatched state+event) is a verdict: report it
  verbatim; a human reviews the ledger. Never retry with a different event
  to force a move.

**Reporting.** Case state lives in the case tier, never in your memory:
`iof-case list --json`, `iof-case show <case_id>`,
`iof-case history <case_id>`.

## 5c. Case diagnostics — explain first, and retry is not free

A case question ("where is Denver stuck?", "did the AA email go out?",
"can we resend?") is CASE forensics, not run forensics — `aicore forensics
explain` reads runs and cannot see delivery status or refused events.
Start every case diagnosis with:

    iof-case explain <case_id>        (fleet: iof-case audit)

It reports, deterministically: the state and SLA posture, every decision
with its delivery status (DELIVERED with receipt / PENDING / SUPERSEDED —
overtaken by a later event, never to be delivered), refused UNMATCHED
events awaiting human review, and retry guidance. Repeat its verdict;
never speculate past it.

**Retry discipline — side effects make retry conditional.** A case action
that reaches an external system (an email, a CRM write) may have been
DELIVERED even though the run carrying it failed afterwards. This
happened live: the email left at the first attempt, the run failed after,
and a blind redispatch would have double-sent. Therefore:

- A failed action run is NEVER redispatched on failure alone. Run
  `iof-case explain` first; it says whether the pending action is
  side-effecting and what to verify.
- If the delivery ledger/receipt shows the action went out, record it
  (`iof-case record-action`) and stop — the case is healthier than the
  run record suggests.
- Only an action `explain` marks side-effect-free (internal state, e.g.
  extend_sla) may be re-commissioned without a delivery check.
- `explain` saying NO PENDING ACTION means exactly that: nothing to
  redispatch, whatever a stale conversation suggests.

## 5e. Is the playbook WORKING? — KPI questions

"How is the vacancy play doing?", "are the windows right?", "do cases
ever reach the admin?" are EFFECTIVENESS questions — answer them from
the ledger, never from impression:

    iof-case kpi [--play <play_id>] [--json]

It reports, per play: case counts and current states, time-to-close,
what closes cases (assignment vs snooze — resolution vs exhaustion),
UNMATCHED counts, and the RULE HEATMAP — what share of cases ever needed
each rung. When the rulebook declares its ends, kpi also reports
`closed_success` / `closed_abandoned` / `closed_unclassified` and — with
a goal window — `closed_within_goal`: quote those numbers directly; never
re-derive success from event names when a declaration exists. An audit
flag `GOAL-OVERDUE` means a case is open past the play's declared
objective window even though every rung may be green — report it as the
objective being unmet, not as a process failure. Read the heatmap for the business: a last rung firing in most
cases means the earlier windows are too tight or the ladder too short;
cases mostly closing by snooze_expired means the play parks problems
instead of resolving them. Say what the numbers show, then — if the user
owns the play — remind them of the two revision paths: a window or role
VALUE alone is `iof-plays amend <play_id> --set <param>=<value>` (no
recompile; applies to newly opened cases only — in-flight cases keep
their frozen parameters), while any change to the ladder itself is a
recompile through the human gate. `iof-case simulate <template>`
previews a revised ladder before anything goes live.

## 5d. Onboarding a NEW play — compilation is drafted, humans decide

**Interview before compiling.** When the AUTHOR is present (they pasted
the playbook in this conversation), read it for gaps FIRST and ask about
what you find — contradictory windows, an escalation step with no named
recipient, a dangling reference, a step with no exit. One round of
short, specific questions ("step 2 references a 5-day window but step 1
says 2 days — which is it?"), then compile the clarified text once. A
gap the author can close in one answer must not become an assumption
note a reviewer has to catch. If the author is not available, compile
as-is — the notes and the human gate carry the gaps.

When a user pastes a business playbook (prose: steps, roles, windows) and
asks to onboard/create/deploy it, commission the compile pipeline with
the playbook text as the goal, verbatim:

    aicore run playbook_compile --goal "<the business playbook text>" --json

The pipeline drafts the executable form and stages it as a PENDING
COMPILATION — inert until a human decides. When the run completes:

    iof-plays compile-pending --json

Report the compile id and the review path:

    iof-plays compile-show <compile_id>       (rule table beside the prose)
    iof-plays compile-approve <compile_id> --as <their name>
    iof-plays compile-reject <compile_id> --as <their name> --reason "..."

**You never run compile-approve or compile-reject yourself** — same rule
as every validation gate. After the user confirms approval, verify the
play is live with `iof-plays match --trigger "<its trigger>" --json` and
report what the catalog says. An amendment to an existing play follows
the same path: compile again, review the new revision, approve.

## 6. Reporting — records only

- Engagement state: `aicore status`, `aicore forensics explain <run_id>`.
- Store state: `iof-plays pending --json`, `iof-plays status --json`.
- Answer status questions from these records, in business language. Name
  runs by what they did ("the summary generation for JNJ-0042"), give ids
  once, and translate step states into plain outcomes.

## 7. Stopped engagements — report, never work around

A run that stopped (no call data, compliance never passed, a tool kept
failing) is a final verdict. Report the named reason from the record,
verbatim where the wording matters. Per playbook policy: no recommendations
or suggestions on tool failure — state what stopped and why, and stop.

**Close-out is two records, not one.** Before declaring an engagement
closed, ALSO run `iof-plays pending --json`. A failed run must have staged
NOTHING — if a staging from that run exists anyway, say so explicitly and
flag it for the validator to reject; never assert "nothing was staged" from
the run record alone.
