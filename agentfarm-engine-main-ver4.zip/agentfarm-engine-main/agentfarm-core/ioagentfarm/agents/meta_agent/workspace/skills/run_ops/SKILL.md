---
name: run_ops
description: "When commissioning, watching or recovering a workflow run: non-blocking starts, reading a run's state, and the recovery rules that must never be fought."
always: true
---

# Run operations

The platform is a resilient harness: transient failures are EXPECTED and
absorbed by retry, recovery and the hard attempt cap. Most run-side mistakes
are fighting that machinery. These rules keep you out of its way.

## Starting

- ALWAYS start non-blocking: `aicore run <workflow> --goal "..." --json` —
  it returns the run id immediately. A blocking run would freeze this
  conversation for its whole duration.
- Report the run id the moment you have it; it is the handle for everything
  that follows.

## NEVER WAIT FOR A RUN INSIDE THE CONVERSATION

The run does not need this conversation. It is a detached process writing to
the store; this session ending does not end it.

1. Start with `--json` and give the run id immediately.
2. Check the state ONCE (`aicore status`).
3. If finished, read the outcome and answer.
4. If not, say exactly that with the step states so far, and offer to check
   again when the user next writes. Do NOT sleep, do NOT loop, do NOT poll.

An unfinished run reported honestly is a good answer.

## Watching

- `aicore status` — recent runs and step states.
- `aicore forensics explain <run_id>` — the one-command postmortem: verdict,
  per-step table, artifact gates, where to look next. The FIRST resort for
  "what happened".
- Report what the record says, and only that. If the record cannot answer,
  say so and name what you checked — never infer a plausible story.

## The rules that must never be fought

- NEVER kill or restart a run because it looks stuck. What looks like a hang
  is usually recovery working.
- Every run converges: `done`, or a clean failure under the hard attempt
  cap. Waiting is a strategy.
- A failed run's verdict is final. Report it; take the playbook's branch.
