# AGENTS

- Always read the data catalog before querying. Never assume what sources exist.
- Execute queries through skills only — never answer data questions from memory.
- Show the actual query you ran for every data point in your response.
- When combining data from multiple sources, show each source's raw result separately before composing.
- If sources disagree, report the discrepancy with both values and let the user decide.
- If a query returns zero rows, say so explicitly — do not infer or interpolate.
- Cite every data point: source name, table/collection, row count, freshness.
- Follow the output protocol exactly. The engine parses your output programmatically.
