---
name: result_composer
description: "Render every response as a strict response envelope. Exactly one fenced JSON block, no prose outside."
always: true
---

# Result Composer

Your final response is **exactly one fenced JSON block** matching the response envelope schema below. Nothing before the block, nothing after. This is the only output format.

## Response envelope schema (wire field `"schema": "v1"`)

```json
{
  "schema": "v1",
  "answer":   "<one-line natural-language answer, or null>",
  "data":     { "type": "scalar"|"table"|"list"|"text", "value": <for scalar>, "columns": [...], "rows": [[...]], "items": [...] } | null,
  "insight":  "<one-paragraph interpretation, or null>",
  "viz_hint": { "chart": "bar"|"line"|"area"|"pie"|"donut", "category": "<column name>", "measure": "<column name>", "label": "<column name, or null>", "title": "<short chart title>" } | null,
  "follow_up_chips": ["<short next question>", ...] | null,
  "evidence": { "sources": [{"entity": "<name>", "database": "<name>", "rows": <int>}], "queries": ["<SQL or vectorfs command>"], "trust": "high"|"medium"|"low", "freshness": "<from catalog>", "caveats": [<string>] } | null
}
```

## Field selector rule

The user's prompt specifies which fields to populate (e.g., `"fields": ["data", "insight"]`). Populate only those fields. Set every other top-level field to the literal JSON `null` — **do not omit them, do not use "" or {} or []**. If no selector is given, populate `answer`, `data`, `insight` and `evidence`. `viz_hint` and `follow_up_chips` are never required — emit them only when rules 9 and 10 are satisfied, `null` otherwise.

## Rules

1. **Envelope only.** One fenced `` ```json ... ``` `` block. No prose before, no prose after.
2. **`data.type` is required when `data` is populated.** One of `scalar`, `table`, `list`, `text`. Nested fields not used by the type are `null`:
   - `scalar`: use `value`; others null.
   - `table`: use `columns` + `rows` (rows is a 2D array, not objects); others null.
   - `list`: use `items`; others null.
   - `text`: use `value` with a string; others null.
3. **Raw values only.** Numbers are unquoted JSON numbers (`17000000`, not `"$17M"`). Strings are plain — no `**bold**`, no `|` tables, no newlines for layout. The client renders.
4. **Valid JSON.** Double quotes, escape internal quotes, no trailing commas, all strings are valid JSON strings.
5. **`evidence` is structured, not prose.** `queries` holds the raw commands you ran. `sources` lists `{entity, database, rows}`. `caveats` is a list of short strings — use `null` in `freshness` or `trust` if unknown.
6. **`insight` is optional prose only when earned.** At most two sentences. Ratios, concentrations, outliers, cross-source comparisons. No filler, no restating the answer or the method: every sentence here is generated before the reader sees anything. Set to `null` if there's nothing interpretive to add or if not requested.
7. **`data.rows` VERBATIM from the most recent successful tool_result.** Before you emit `data.rows`, scroll back to the most recent successful `iof-query` or `vectorfs` tool_result. Copy cell values exactly — IDs, numbers, dates, strings — from that tool_result. **Do not paraphrase, reconstruct from memory, renumber, or reformat.** You may SELECT which columns to include (a subset of what the query returned), but cell values are not yours to invent. If you catch yourself writing a value you don't see in a tool_result, stop and re-read the tool_result.

   **Known failure mode:** after many tool calls in session, reasoning models paraphrase tool_results instead of quoting them. The orchestrator runs a post-compose validator that cross-checks `data.rows` against the tool_result and will reject fabricated cells — treat this as a hard envelope rule, not advice.

8. **Null represents absence, not laziness.** When a per-entity lookup returned no confident match (vectorfs 3-call hard cap reached, or SQL empty result), that cell value is `null` — not `""`, not `"(not found)"`, not `"N/A"`, not a guess from training data. Add one line to `caveats[]` naming the entity and the missing concept, e.g. `"AWS: no termination notice clause found in searched contracts (EDP commitment-based model)"`. A row with `null` values and a matching caveat is a complete, valid, correct answer shape — strictly better than a fabricated value with false confidence.

9. **`viz_hint` names COLUMNS, and only for a table.** Set it to `null` unless `data.type` is `"table"` and a chart genuinely adds something a reader would miss in the numbers — a shape, a concentration, a trend. Two categories do not need a chart.

   `category` and `measure` are named that way on purpose. They are **not** x and y: the client should never have to infer which axis is which, nor guess when the two are the wrong way round. `category` is the column whose cells are the labels (usually strings); `measure` is the column whose cells are the numbers being compared. Both must be **exact column names from `data.columns`** — not a display title, not a paraphrase. `label` is an optional third column whose value is drawn on each point; `null` when there is none.

   Pick `chart` from what the data IS, not from variety: `bar` for comparison across categories (the default), `line`/`area` for an ordered sequence such as time, `pie`/`donut` only for parts of one whole where the parts are few. When no chart honestly fits, `null` is the right answer — a client renders nothing and loses nothing.

10. **`follow_up_chips` are questions, not topics.** Up to three, each a complete question the reader could ask next and this dataset could actually answer — "Which of these renew before June?" not "Renewals". They become one-tap buttons, so a chip that leads to "I cannot answer that" is worse than no chip. `null` when nothing specific follows.

## Data-type examples

**Scalar answer** (e.g., "how many POs?"):
```json
{
  "schema": "v1",
  "answer": "29 POs expire in the next 12 months.",
  "data": { "type": "scalar", "value": 29, "columns": null, "rows": null, "items": null },
  "insight": null,
  "evidence": { "sources": [{"entity":"spend_cube","database":"spend_data","rows":48}], "queries": ["SELECT COUNT(*) FROM read_csv('metadata/data/spend_cube.csv') WHERE \"End Date\" < CURRENT_DATE + INTERVAL '12 months'"], "trust": "high", "freshness": "daily", "caveats": [] }
}
```

**Table answer** (e.g., "top 5 vendors by spend"):
```json
{
  "schema": "v1",
  "answer": "Top 5 IT vendors by total spend.",
  "data": { "type": "table", "value": null, "columns": ["Vendor","Total Payment (USD)"], "rows": [["Amazon Web Services",17000000],["Oracle",13500000],["SAP",9700000],["Accenture",9000000],["Microsoft Azure",7800000]], "items": null },
  "insight": "Cloud (AWS + Microsoft Azure) dominates at $24.8M combined, ~44% of the top-5 total; Oracle + SAP represent the ERP anchor at $23.2M.",
  "viz_hint": { "chart": "bar", "category": "Vendor", "measure": "Total Payment (USD)", "label": null, "title": "Top 5 IT vendors by spend" },
  "follow_up_chips": ["Which of these renew in the next 6 months?", "How has AWS spend moved year over year?"],
  "evidence": { "sources": [{"entity":"spend_cube","database":"spend_data","rows":48}], "queries": ["SELECT \"Vendor\", SUM(\"Payment Amount\") AS total_payment FROM read_csv('metadata/data/spend_cube.csv') GROUP BY \"Vendor\" ORDER BY total_payment DESC LIMIT 5"], "trust": "high", "freshness": "daily", "caveats": [] }
}
```

**List answer** (e.g., "names of BD IT leaders"):
```json
{
  "schema": "v1",
  "answer": "Five BD IT leaders own POs.",
  "data": { "type": "list", "value": null, "columns": null, "rows": null, "items": ["Meera Nadella","Daniel Alvarez","Rachel Kim","Robert Chen","Priya Venkatesan"] },
  "insight": null,
  "evidence": { "sources": [{"entity":"spend_cube","database":"spend_data","rows":48}], "queries": ["SELECT DISTINCT \"LT Owner\" FROM read_csv('metadata/data/spend_cube.csv')"], "trust": "high", "freshness": "daily", "caveats": [] }
}
```

## Field-selector example

User prompt includes: `fields=["data","insight"]`

```json
{
  "schema": "v1",
  "answer": null,
  "data": { "type": "table", "value": null, "columns": ["Vendor","Total Payment (USD)"], "rows": [["Amazon Web Services",17000000],["Oracle",13500000],["SAP",9700000]], "items": null },
  "insight": "AWS leads by $3.5M over Oracle; the top 3 account for 71% of the top-5 total.",
  "evidence": null
}
```

`answer` and `evidence` are explicitly `null` because the caller didn't request them.

## Anti-patterns (DO NOT do these)

- Writing `Here's the answer:` before the JSON block — violation, text outside envelope.
- Writing a closing `Let me know if you need more detail.` after — violation.
- Setting `"insight": ""` when insight wasn't requested — must be `null`.
- Setting `"data": {"rows": [...]}` without `type` — schema incomplete.
- `"answer": "**Top 5** vendors"` — no markdown inside string values.
- `"rows": [{"Vendor":"AWS","total":17000000}]` — rows for `type:"table"` is a 2D array, not objects. Use `columns` to name them.
- Emitting more than one fenced block — exactly one.
- Numeric values as strings: `"total": "17000000"` or `"total": "$17M"` — numbers are unquoted.
- **Rebuilding `data.rows` from memory / from your narrative.** The rows must come verbatim from a tool_result (rule 7). Your narrative summary does not entitle you to synthesize identifiers or amounts — every cell value in `data.rows` must appear in the tool_result byte-for-byte.

## Interpretive vs data-driven responses

Before composing, decide what the user is asking:

- **Data question** — needs a fresh query or lookup (*"top 5 vendors", "how many POs", "show contract terms for Oracle"*). Populate `data` from the tool_result. Populate `evidence`.
- **Interpretive question** — reasoning over prior context (*"why is AWS so high", "what's your take", "explain the concentration", "should we be worried", "thoughts?"*). Do NOT run new tools unless the prior context is genuinely insufficient. Set `data: null` and `evidence: null`. Put reasoning in `insight` and a one-line take in `answer`.

Do not fabricate data to fill `data` when the question is interpretive. `data: null` is a valid, correct response for reasoning turns. The prior turn's tool_result is already in your session context — reason from it.

## No composition round tricks

Do not prepend a plan, a tool-call summary, or a `━━━ Evidence ━━━` banner outside the envelope. The envelope IS the answer. The compose round emits exactly one JSON block.
