---
name: catalog_reader
description: Interpret the embedded multi-source catalog. Pick the right entities, route source_side joins to a single query and local_stack joins to fetch+compose, hand off query syntax to the matching skill (data_query / vectorfs_query).
always: true
---

# Catalog Reader

## Goal

Pick the right sources and route the query. Don't generate SQL here — that's `data_query`'s job. Don't invoke vectorfs commands here — that's `vectorfs_query`'s job.

The catalog is embedded in the **Current catalog** section below — do NOT call `read_file` to read it.

## Catalog structure

```yaml
databases:
  <db_name>:
    type: duckdb | postgres | mysql | vectorfs | ...
    semantic: "What this DB is for"
    trust: high | medium | low
    freshness: realtime | daily | weekly | monthly | on-ingest

entities:
  - name: <entity_name>
    database: <db_name>             # which DB it lives in
    source_path: <file>             # CSV/parquet path (omitted for real DBs)
    table: <schema.table>           # SQL table (when in a real DB)
    grain: "What one row represents"
    semantic: "When to query this entity"
    dimensions: [{name, type, description}, ...]
    measures:   [{name, sql, description}, ...]

joins:
  - from: <entityA.col>
    to:   <entityB.col>
    type: lookup | aggregate_match | semantic
    location: source_side | local_stack
```

## How to interpret

### Step 1 — pick entities by semantic match
Read the user's question. Match it to the entity `semantic:` descriptions. Don't pick by name alone.
- "Top vendors by spend" → `purchase_orders` (transactional, line-item)
- "Quarterly trend" → `quarterly_spend` (pre-aggregated cube, faster)
- "Contract termination clause" → `contracts` (vectorfs)

### Step 2 — read each entity's `database:` to find query strategy

Look up the entity's database in the `databases:` section, check its `type:`, then route:

| Database `type:` | Use which skill | What it handles |
|-----------------|-----------------|-----------------|
| `duckdb`, `postgres`, `mysql`, `parquet`, `csv` | **`data_query`** | iof-query CLI, SQL syntax, read_csv/read_parquet for file sources, table names for real DBs |
| `vectorfs` | **`vectorfs_query`** | vectorfs CLI, semantic search, ls/cat/grep/explore on the document filesystem |

`data_query` knows how to query any structured backend (duckdb file paths, real postgres tables, etc.) — read its SKILL.md when you need exact syntax.

**For queryngine in always-on mode:** the `data_query` skill mentions `{{metadata_dir}}` as a template — that template is NOT resolved here. Always pass the literal value **`--metadata-dir metadata`** (relative path; iof-query resolves it from your workspace cwd to the embedded `metadata/` subdirectory). For CSV-backed entities (those with `source_path:`), wrap the path in `read_csv('<source_path>')` exactly as it appears in the catalog.

### Step 3 — route the join by `location:`

**`location: source_side`** → both entities in the SAME database. Push the JOIN to that database in **one** `data_query` (or `vectorfs_query`) call. Fast path.

**`location: local_stack`** → entities in DIFFERENT databases. You CANNOT join in SQL. Pattern:
1. Query side A independently
2. Query side B independently (use entity-specific values from A as filters/queries when applicable)
3. Compose the join in your final answer by matching keys
4. Report match quality (exact / fuzzy / similarity)

## Routing examples

### Example 1: source_side join
**Question:** "Top 5 suppliers by approved spend with their risk scores."

Catalog tells me:
- `purchase_orders` lives in `spend_data` (type: duckdb)
- `suppliers` lives in `spend_data` (type: duckdb) — same DB
- Join `purchase_orders.supplier_id → suppliers.supplier_id` has `location: source_side`

→ Use **`data_query`** skill, push JOIN to DuckDB in one call.

### Example 2: local_stack join (cross-source)
**Question:** "For our top 3 spend suppliers, look up termination notice periods from contract docs."

Catalog tells me:
- `suppliers` lives in `spend_data` (type: duckdb)
- `contracts` lives in `vectorfs_contracts` (type: vectorfs) — different DB
- Join `suppliers.supplier_name → contracts.document_name` has `location: local_stack`

→ Two phases:
1. **`data_query`** to fetch top 3 supplier names from `spend_data`
2. **`vectorfs_query`** with each name as a specific search ("Acme Technologies termination notice"), not a generic search
3. Compose the join in the final answer; report match confidence

## Rules

- Always read the catalog first (it's already in your system prompt — no I/O cost).
- Never query an entity not listed in the catalog.
- Always report `trust` and `freshness` from the entity's database in your evidence panel.
- For `local_stack` joins, report match confidence (exact / fuzzy / similarity score).
- When sources disagree, show both values — never silently pick one.
- If no catalog is embedded below, tell the user: "No data catalog configured. Run `aicore configure-agent queryngine <metadata_dir>` to deploy one."

## Common mistakes

- ❌ Generating SQL inside this skill — defer to `data_query`
- ❌ Trying to JOIN across databases in one SQL query — use the local_stack pattern
- ❌ Generic vectorfs queries when entity names are available — use entity-specific queries
- ❌ Picking an entity by name without reading its `semantic:` description
