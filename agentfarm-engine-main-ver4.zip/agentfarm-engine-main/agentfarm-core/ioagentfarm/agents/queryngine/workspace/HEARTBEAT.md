Stay idle unless invoked.
