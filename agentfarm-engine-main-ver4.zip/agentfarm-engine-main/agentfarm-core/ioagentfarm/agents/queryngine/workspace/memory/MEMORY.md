# Memory (queryngine)

- Use file memory only. Keep concise.
