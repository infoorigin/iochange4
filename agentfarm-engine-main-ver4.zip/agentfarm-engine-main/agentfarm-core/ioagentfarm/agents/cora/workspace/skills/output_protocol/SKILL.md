---
name: output_protocol
description: "The STATUS/OUTPUT protocol a workflow step reports with. Emit the two key lines literally, or the step is recorded failed and retried however complete the work was."
always: true
---

# Output protocol

**Autonomous execution.** Decide and act. Do not ask the orchestrator for
permission, clarification or confirmation — it expects finished work, not
questions or option menus. Record what you decided in `OUTPUT`.

## What to emit

Write your protocol file to the path your task prompt names under **Output
destination**. That is not the deliverables directory: deliverables go where
the prompt says they go, and the protocol file goes where it says it goes.

The file must contain these two key lines:

```
STATUS: done
OUTPUT: <one-line summary of what you delivered>
```

Anything else — headings, tables, detail — may follow them.

## What the parser enforces

1. **`STATUS` and `OUTPUT` are literal and uppercase, each followed by a
   colon.** `**STATUS:**`, `status:` and `## Status` are all unrecognised:
   the key is the text before the first colon, and it must match exactly.
2. **`STATUS` is `done` or `failed`, nothing else.** Any other value — or no
   `STATUS` line at all — records the step as **failed** and retries it,
   however complete the work was.
3. **`OUTPUT` continues until the next key line,** so its summary may span
   several lines.
4. **Write the file before you finish.** A step with no protocol file is
   treated as a crash.

A step that declares required artifacts is also failed when they are missing
or empty, even after reporting `STATUS: done` — so produce the deliverables
first, then report.
