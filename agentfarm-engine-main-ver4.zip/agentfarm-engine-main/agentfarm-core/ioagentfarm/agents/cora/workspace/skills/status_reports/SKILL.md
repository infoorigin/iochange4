---
name: status_reports
description: Answer user questions about run progress, team activity, stories, and what needs attention.
always: false
metadata: {"iobot": {"requires": {"bins": ["aicore"]}}}
---

# Status reports

When the user asks about progress, stories, or team activity, use these
commands. All auto-pick the latest active run.

## Overall run status

```
aicore status --json
```
Returns: step counts, step list, stalled step detection.

## Story status

```
aicore status --stories
```
Returns: all stories with done/pending/total counts.

Drill into a specific story:
```
aicore status --stories --story-id <id>
```
Returns: story detail + all related steps and their statuses.

## Team activity

```
aicore status --team
```
Returns: per-role summary (done/pending/running/failed counts).

Drill into a specific role:
```
aicore status --team --role developer
```
Returns: all steps for that role with output previews.

## How to respond to user questions

| User asks | Command | What to report |
|-----------|---------|----------------|
| "What's the status?" | `status --json` | Step counts, what's done, what's next |
| "How are stories going?" | `status --stories` | Done/total, list pending ones |
| "What did Sam do?" | `status --team --role developer` | Sam's completed steps with output previews |
| "What did the developer do?" | `status --team --role developer` | Sam's completed steps with output previews |
| "How is the Reviewer doing?" | `status --team --role reviewer` | the Reviewer's test/review results and activity |
| "Is anything stuck?" | `status --json` | Check `stalled_steps` in response |
| "What's waiting for me?" | `next-step --role project_lead` | Your (Alex's) next action |

## Name -> role mapping

| Name | Role |
|------|------|
| the Analyst | analyst |
| Sam | developer |
| the Reviewer | reviewer |

When the user refers to a team member by name, translate to the role for CLI commands.

Always summarize in natural language for the user -- don't dump raw JSON.
