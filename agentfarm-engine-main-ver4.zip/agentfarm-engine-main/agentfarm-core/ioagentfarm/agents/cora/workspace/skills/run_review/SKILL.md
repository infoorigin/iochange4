---
name: run_review
description: "Audit the QUALITY of a run's reasoning, not just its status: did the deliverable use the evidence the run actually gathered, does the conclusion follow, was anything ignored or invented, and was the goal fully answered. Use for 'review this run', 'is this any good', 'can I trust this output', 'critique the analysis'."
always: false
metadata: {"iobot": {"requires": {"bins": ["aicore"]}}}
---

# Reviewing a run's reasoning

`run_diagnostics` answers *what happened*. This answers *was it any good* -
the question a user asks before acting on a deliverable. It is DOMAIN-
AGNOSTIC: you do not need to know the subject matter, because every check
below compares the run's OUTPUT against the run's OWN EVIDENCE. If the two
disagree, that is a defect whatever the domain.

## Step 1 - assemble the three things

1. **The goal** - `aicore forensics explain <run_id>` prints it (also the
   status, the steps, and any failed capabilities you will need in check 4).
2. **The deliverable** - `aicore run-output --run-id <run_id> --list` then
   `--file <name>` for the main artifact.
3. **The evidence the run gathered** - what the agent actually had:
   * swarm runs: `--file results.json` (each child's returned data) and the
     per-child `<id>_result.json` files;
   * workflow runs: each earlier step's output, `aicore status --run-id
     <run_id> --step <key>`;
   * either: the tool calls the agent made, `aicore forensics narrative
     <run_id> <step>.<attempt>` when you need to see what it actually ran.

Never review a deliverable without the evidence set. Prose alone cannot tell
you whether a number was gathered or invented - that comparison IS the review.

**THE EVIDENCE SET IS THIS RUN ONLY.** The agent's `memory/MEMORY.md`, its
session history and anything from an earlier run are NOT evidence about this
one: memory persists across runs, so a failure recorded there may belong to a
run from last week. Reading a prior run's `HTTP 401` as this run's failed
capability is a FALSE ACCUSATION - it has happened, and a review that invents
defects is worse than no review. Only `explain`'s output for THIS run id and
files under THIS run's directory count.

If the evidence set cannot be retrieved - no `results.json`, no step outputs,
commands erroring - then say exactly that, name what you tried, and review
only what you CAN check (checks 3 and 5 work on the deliverable alone). Never
substitute a different source and never infer a failure you could not see.

## Step 2 - the five checks

Run all five. Report each with a concrete citation (a figure, a sentence, a
child name), never a general impression.

| # | Check | What a failure looks like |
|---|---|---|
| 1 | **Traceability** - every figure and factual claim in the deliverable appears in the gathered evidence | A number in the report that no child/step/tool returned. This is the most serious finding: it is fabrication, report it first and plainly. |
| 2 | **Coverage of evidence** - every material piece of evidence the run GATHERED is either used in the conclusion or explicitly set aside with a reason | A signal was collected and then silently ignored - the single most common quality failure. An inconvenient finding that vanishes between the evidence and the recommendation is a defect even when the recommendation is otherwise reasonable. |
| 3 | **Internal consistency** - the conclusion follows from the stated findings, and no two statements contradict | A recommendation that contradicts a finding stated two paragraphs above it, or a "no risks identified" summary over a body that lists one. |
| 4 | **Honesty about gaps** - capabilities that failed, data that was unavailable, and questions that could not be answered are named IN the deliverable | `explain` shows a failed child or a missing data source, and the deliverable reads as if everything succeeded. Compare the two directly. |
| 5 | **Goal coverage** - every part of the goal is answered, including the parts that are inconvenient | A goal asking for "X, and explicitly flag Y" that answers X and never mentions Y. Re-read the goal clause by clause. |

## Step 3 - the judgement the checks cannot make

Two failures survive all five checks, so look for them deliberately:

* **The unexamined obvious answer.** When one option looks best on the
  headline signal, did the run test that against its other evidence, or
  simply follow it? A recommendation that agrees with the loudest signal
  and never engages the evidence pulling the other way is weak even when it
  turns out right. Say so.
* **Conflict left unresolved.** When two pieces of gathered evidence point
  opposite ways, a good deliverable NAMES the tension and says how it
  resolved it. Silence there means the conflict was not noticed.

## Step 4 - the verdict

Lead with a one-line judgement: trustworthy as-is / trustworthy with the
caveats below / do not act on this yet. Then the findings, most serious
first, each with its citation. Then, only if asked or if a defect is
structural, the design fix - that belongs to the authoring skill for the
content kind (platform_advisor in the assistant; `workflow_craft`,
`swarm_craft` and `agent_craft` in the builder), and a reasoning
defect usually traces to a step prompt that never demanded the missing
thing.

## Rules

1. Compare, never assume. Every finding cites the deliverable AND the
   evidence it does or does not match.
2. A clean review is a real result - say "no defects found across the five
   checks" plainly rather than manufacturing criticism.
3. You review the REASONING, not the subject matter. Do not contest a
   domain fact the evidence supports, and never substitute your own
   domain opinion for the agent's - your authority is the run's own
   evidence.
4. Never fabricate in a review either: if you could not retrieve the
   evidence set, say which command failed and stop.
