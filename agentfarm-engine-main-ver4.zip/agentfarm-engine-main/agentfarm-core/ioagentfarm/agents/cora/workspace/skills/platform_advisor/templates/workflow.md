# Workflow template

A workflow is a FIXED ROUTE: known steps, known order, artifact handoffs. It
lives at `solutions/<solution>/workflows/<name>/` (flat workspace layout) or
`<pkg>/workflows/<name>/` (packaged). Scaffold with
`aicore new-workflow <name> --solution <s> --steps a:role,b:role`, then paste
your authored content over the generated files.

## Rules that make output lint-clean by construction

- `name:` MUST equal the directory name - everything that addresses a
  workflow uses the directory, and a mismatch fails silently at snapshot time.
- Top-level keys are EXACTLY: `name, description, protocol, learning, vars,
  team, sandbox, roles, steps`. The loader silently ignores unknown keys -
  a typo does not error, it just never happens. Lint catches it; do not rely
  on lint to catch what you can avoid.
- Role keys: `name, prompt, skills, model, allowed_tools`. Step keys: `key,
  title, role, type, prompt, deps, max_attempts, command, stories_from,
  fresh_session, loop_source_key, per_item_steps, requires_artifacts`.
- EVERY step declares `requires_artifacts` - the fail-closed gate is what
  stops a broken handoff from becoming a fabricated downstream section.
- `roles:` is a LIST of mappings (YAML deduplicates mapping keys); every
  declared role must be used by a step.
- `skills:` on a role is the EXACT set for the job: any always:true skill it
  does not name is dropped, except `output_protocol` (added unconditionally).
  Omit the key to load all the agent's skills; never write an empty list.
- `vars:` values are QUOTED STRINGS (`Workflow.vars` is Dict[str, str]).
- `learning: disabled` until the learning redesign lands (observation capture
  anchors later runs on stale findings).
- Steps form a chain via `deps:`; a step with no deps starts immediately.
- Large compositions: per-section files + a final `type: exec` assemble step,
  never one giant write.

## Exemplar (complete, lints clean)

```yaml
# file: competitor_snapshot/workflow.yaml
name: competitor_snapshot
description: Analyze a competitor question, then compose a one-page report.

protocol:
  required_keys: ["STATUS", "OUTPUT"]

learning: disabled

team:
  - role: report_writer

roles:
  - name: report_writer
    prompt: roles/report_writer.md

steps:
  - key: analyze
    title: Analyze
    role: report_writer
    prompt: steps/analyze.md
    max_attempts: 2
    requires_artifacts: [analysis.md]

  - key: compose
    title: Compose
    role: report_writer
    deps: [analyze]
    prompt: steps/compose.md
    max_attempts: 2
    requires_artifacts: [report.md]
```

```markdown
# file: competitor_snapshot/roles/report_writer.md
You are the report writer. You produce tight, structured written
deliverables: analysis first, report second, nothing padded. You write the
file each step names, in the working directory it names, and report
STATUS/OUTPUT per your protocol.
```

```markdown
# file: competitor_snapshot/steps/analyze.md
# Analyze

Write `analysis.md` in your working directory: a short structured analysis of
the goal - what is being asked, the three most useful angles, and the section
outline the report should follow. Under 60 lines. Do not compose the report
here; the next step reads this file as its input.

Print at least one line of text immediately BEFORE every tool call.
```

```markdown
# file: competitor_snapshot/steps/compose.md
# Compose

Read the analysis from the previous step:

{{step_output.analyze}}

Write `report.md` in your working directory: the report the analysis
outlined. Follow its section list, one tight paragraph per section, opening
with a two-sentence executive summary. Under 80 lines.

Print at least one line of text immediately BEFORE every tool call. The
orchestrator's stream consumer requires a text block before any tool_use
block; turns that open with a tool call are a known cause of dropped
responses.
```

Template variables available in step prompts: `{{goal}}`, `{{progress}}`,
`{{step_output.<key>}}`, `{{run_id}}`, `{{workflow_dir}}`, `{{metadata_dir}}`,
plus any `vars:` keys.

Close every authored workflow with: run `aicore lint-workflow <name>` -
generated YAML is unverified until linted.
