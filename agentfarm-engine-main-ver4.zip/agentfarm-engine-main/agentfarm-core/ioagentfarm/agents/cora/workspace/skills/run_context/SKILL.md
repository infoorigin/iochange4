---
name: run_context
description: Access run deliverables and step outputs via the run-output CLI tool.
always: false
---

# Run Context

## Overview

During interactive sessions or follow-up conversations, use the `run-output`
CLI tool to access deliverables from the current run. Do NOT search the workspace.

## Reading deliverables

### List available files
```bash
aicore run-output --run-id <run_id> --list
```

### Read a full report
```bash
aicore run-output --run-id <run_id> --file strategy_plan.md
```

### Search within a report (recommended for large files)
```bash
aicore run-output --run-id <run_id> --file strategy_plan.md --grep "Play J"
```

### Read raw step output from DB
```bash
aicore run-output --run-id <run_id> --step-key strategize
```

## Writing revised deliverables

When asked to revise a strategy, report, or review — use this two-step pattern:

### Step 1: Write the file to your workspace
```
write_file("strategy_plan_v2.md", "<revised content>")
```

### Step 2: Publish it to the run's project directory
```bash
aicore run-output --run-id <run_id> --publish strategy_plan_v2.md --role strategist
```

This copies the file from your workspace to the run directory and cleans up.

**Important:**
- Always version deliverables (v2, v3) — never overwrite the original
- The publish command needs `--role` so it knows which workspace to read from
- After publishing, summarize what changed between versions

## Available deliverables

| File | Author | Contains |
|------|--------|----------|
| `intelligence_report.md` | the Analyst (analyst) | Signals, barriers, evidence, focus areas |
| `strategy_plan.md` | the Strategist (strategist) | Options, comparisons, simulations, rationale |
| `compliance_review.md` | the Reviewer (reviewer) | Compliance, benefits, quality gates, sign-off |
