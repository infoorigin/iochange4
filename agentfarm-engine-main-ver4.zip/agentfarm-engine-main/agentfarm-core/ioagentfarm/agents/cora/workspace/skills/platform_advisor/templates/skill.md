# Skill template

A skill is a JUDGEMENT document: when to use a capability, how to read what
it returns, when not to. The capability itself lives in a CLI tool, MCP
server, or A2A agent - if the need is deterministic computation, build a
tool (`aicore new-tool`), not a skill.

Placement: `aicore new-skill <name> [--role <agent>] [--tool <t> | --mcp-server <m>]`.
`--role` puts it in that agent's workspace (assignment by location); omitted,
it is workspace-level and held by nobody until a workflow step names it or
`aicore assign-skill` grants it.

## Frontmatter contract

- `description:` is DOUBLE-QUOTED (a plain scalar containing ": " is a YAML
  mapping, not a string) and is THE MATCHING SURFACE - the agent matches a
  job against this line. For a tool skill, the binary name belongs in it; for
  an MCP skill, the `mcp_<server>_*` prefix does.
- `always: true` puts the whole file in the system prompt on every call - pay
  that token cost only for skills that must never be missed (protocols,
  routing). Everything else stays `always: false` and loads on demand via
  the description.
- No `roles:` key - it gates nothing; assignment is by location or by the
  assignment record.

## Exemplar

The frontmatter below is the contract (the skill body follows the `---`):

```yaml
# file: dispute_handling/SKILL-frontmatter.yaml
name: dispute_handling
description: "When a delivery window is missed and the carrier disputes it: how to assess fault, what evidence settles it, when to escalate."
always: false
```

Body sections that earn their place: when this applies (name the situation,
not the tool); how to work (concrete steps, small results); what not to do
(the mistake this skill exists to prevent). A tool skill adds "Running it"
(defer flags to `--help`; explain how to READ the output). An MCP skill adds
"The server's tools" (the live tool list is the reference; teach which tool
answers which job, and the say-so rule when `mcp_<server>_*` tools are not
registered).

Close every authored skill by naming where it lands and, when paired with a
capability, the pairing command you used (`--tool <t>` / `--mcp-server <m>`).
