# MCP server and external A2A agent templates

Two kinds of external capability, two registries. Neither requires client
code - the runtime connects MCP servers and registers their tools live as
`mcp_<server>_<tool>`; external A2A agents are consulted via `iof-consult`
under the `a2a_consult` skill.

## MCP server declaration

Three tiers, higher wins by server name, whole-entry replacement:
pack `mcp.yaml` (ships defaults) -> global `~/.iobot/config.json`
(`aicore mcp-add`) -> workspace (`aicore mcp-add --workspace <code>`).

Rules: exactly one of `command` (stdio) or `url` (sse/streamableHttp);
`${VAR}` references stay UNEXPANDED on disk (the runtime resolves at load; a
server referencing an unset variable is dropped loudly, never crashes the
run); `enabledTools` narrows a server; an override entry with
`enabled: false` suppresses a lower tier's server.

```yaml
# file: mcp.yaml
mcp_servers:
  github:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"
  search:
    url: "https://mcp.example.com/mcp"
    headers:
      Authorization: "Bearer ${MCP_SEARCH_TOKEN}"
    enabledTools: [search, fetch]
```

Pack-tier authoring command: `aicore new-mcp-server <name> --command ...`
(or `--url ...`); pair it with `aicore new-skill <name>_usage --mcp-server
<name>`. Verify the merged view with `aicore mcp-list`.

## External A2A agent registration

Per-workspace registry; the token VALUE goes in the workspace `.env`, the
registry carries only the `${VAR}` reference; routing matches against
description/tags/examples, so write them for the router, not the filing
cabinet.

```
aicore a2a-add partner-insights https://partner.example.com/a2a/insights \
    --description "Partner market-insights agent: share, growth and competitive queries" \
    --tag market-share --tag partner \
    --example "Which regions grew share last quarter?" \
    --header "Authorization=Bearer ${PARTNER_A2A_TOKEN}" \
    --workspace <code>
```

Registered agents materialize into agent workspaces as
`metadata/external_agents.yaml` at warmup and run creation; a swarm's
`agents:` roster scopes which entries a given run can see. Verify with
`aicore a2a-list --workspace <code>` (shows whether each `${VAR}` resolves;
never prints values).
