---
name: run_costs
description: Answer run cost, token, cache, budget and behaviour questions via the deterministic `iof-run-audit` CLI. Never open usage.jsonl or session files directly; never estimate a number.
always: false
metadata: {"iobot": {"requires": {"bins": ["aicore", "iof-run-audit"]}}}
---

# Run costs - tokens, dollars, budgets, behaviour

For ANY question about what a run COST, how much it CONSUMED, or how its
agents BEHAVED economically, run the matching `iof-run-audit` subcommand and
answer FROM ITS OUTPUT. This complements `run_diagnostics` (why did it fail);
this skill owns: tokens, cost, cache efficiency, bottlenecks, budget
overruns, spirals, and run-vs-run comparisons.

## Hard rules

1. NEVER open `usage.jsonl`, `session-snapshot.jsonl`, or `http.log` directly
   - they are huge and will blow out your context. `iof-run-audit` reads them
   deterministically and returns compact tables.
2. NEVER estimate token numbers from memory. Every figure you report comes
   from the command output you just ran. If the tool errors or returns
   nothing, say exactly what you ran and what it returned.
3. If the user names no run, resolve the run_id first (data_query or
   `iof-run-audit list-runs`), then say which run you audited.

## Token semantics (get this right)

- `in` is INCLUSIVE of cache read + cache write. True total = `in + out`;
  uncached input = `in - cache_read - cache_write`.
- The billed-equivalent line is an ESTIMATE (uncached + 0.1x cache-read +
  1.25x cache-write + out) and is provider-dependent. A provider reporting no
  cache split means "no cache accounting reported", never "nothing was
  cached".
- Benchmark budgets were measured on MiniMax-M2.7; on other providers they
  are reference points, not truth.

## Question -> command

| Question shape | Command |
|---|---|
| tokens used / what did it cost / what was cached | `iof-run-audit summary --run-id <id>` |
| why slow / where did time or tokens go | `iof-run-audit bottlenecks --run-id <id>` |
| agent rogue / spiraling / re-deriving | `iof-run-audit spirals --run-id <id>` |
| did we overrun budget | `iof-run-audit budget --run-id <id>` |
| dollars, at a rate card | `iof-run-audit cost --run-id <id> --card <card>` (repeat `--run-id` for a lifecycle total; `--in-rate/--out-rate` for explicit rates) |
| did run B regress vs run A | `iof-run-audit compare --run-id <A> --run-id <B>` |
| what ran recently / most expensive | `iof-run-audit list-runs --limit 15` |

Spiral flags are self-contained evidence - relay near-verbatim
(`BUDGET_OVERRUN`, `REDERIVE_STREAK`, `SAME_TOOL_STREAK`, `NO_TEXT_TURNS`,
`VALIDATOR_REJECTS`, `STEP_RETRY`, `STALL_AUTORETRY`), then translate to
plain language keeping the numbers.

## Cost answers

- ALWAYS name the rate card and its as-of date ("at Opus 4.8 rates, as of
  2026-06"). Cards live in `run_audit_price_cards.yaml`; a card with no rates
  configured means the deployment has not set them - offer the
  `--in-rate/--out-rate` form.
- A cost figure is a what-if re-pricing of recorded usage, NOT a provider
  invoice - say so when the deployment's provider differs from the card.
- A run with no `usage.jsonl` predates usage capture: say so and offer
  `aicore forensics stats` (via run_diagnostics) for non-token counters.

## Answer format (always)

- Per-run numbers in a markdown table, one row per run, bold total.
- Lead with the direct answer (the total or the verdict), then the breakdown
  table, then caveats (estimate labels, provider-dependence) in one line.
- Thousands separators on large numbers; 2 decimals on dollars; round for
  prose (3.30M, 686K) with exact values only on request.
- Name the subcommand you ran as the source.
