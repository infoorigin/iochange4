---
name: presentation
description: Generate consulting-grade HTML slide decks from run deliverables or ad-hoc content. Supports brand customization and iterative editing.
---

# Presentation Skill

Generate visually rich, self-contained HTML presentations. McKinsey-styled, enterprise-grade, zero dependencies.

## When to use

Trigger phrases: "create a presentation", "make a deck", "generate slides", "build a presentation", "slide deck"

## Step 1: Gather content

**From a run (primary use case):**
```bash
aicore run-output --run-id <run_id> --list
aicore run-output --run-id <run_id> --file intelligence_report.md
aicore run-output --run-id <run_id> --file strategy_plan.md
aicore run-output --run-id <run_id> --file compliance_review.md
```
Read each deliverable. Extract: key metrics, findings, barriers, strategies, recommendations, action items.

**Ad-hoc (user provides content):**
Use the user's message content directly. Ask for clarification if too vague.

## Step 2: Determine style

Check if user specified brand colors, background preference, or styling hints.

| User says | Action |
|---|---|
| Nothing about style | Use **Swiss Consulting** theme (default) |
| "White background, brand blue #1B365D" | Build custom `:root` — see `themes.md` |
| "Dark", "executive", "premium" | Use **Executive Dark** theme |
| "Clean", "minimal" | Use **Minimal Light** theme |
| "Modern", "tech" | Use **Modern Corporate** theme |

Read `themes.md` for the full `:root` CSS variables for each theme and rules for deriving custom brand themes from partial input.

## Step 3: Structure the deck

**Standard run summary (7-10 slides):**

| # | Slide | Layout | Content from |
|---|-------|--------|-------------|
| 1 | Title | `.title-slide` | Workflow name, goal, date |
| 2 | Executive Summary | `.card-grid` + `.metric-card` | 3-4 headline KPIs from all reports |
| 3 | Analysis Findings | bullet list | the Analyst's intelligence report: signals, data sources |
| 4 | Barriers Identified | table or cards | Barriers with severity, confidence, evidence |
| 5 | Strategy Recommendation | table | the Strategist's play comparison — target, speed, impact |
| 6 | Recommended Play Details | `.two-column` | Deep dive on top 1-2 plays |
| 7 | Compliance & Quality | bullets + tags | the Reviewer's verdict, risk flags, sign-off status |
| 8 | Next Steps | numbered list | Prioritized action items with owners/timeline |
| 9 | Appendix | small table | Data sources, methodology, team roster |

**Layout variety rule:** NEVER use the same layout for 2 consecutive slides. Rotate between metric cards, bullets, tables, two-column, and card grids.

## Step 4: Generate the HTML

Read `html-template.md` for the full skeleton. Follow these rules:

### Structure rules
- Every slide: `<section class="slide" id="slide-N">` (numbered for editing)
- All content wrapped in `<div class="slide-content">`
- Add `<span class="slide-number">N</span>` to each slide
- Add `class="reveal"` to every content element for animations

### CSS rules
- Inline `viewport-base.css` completely inside `<style>`
- Add theme `:root` variables at the top of `<style>`
- Every slide: `height: 100vh; overflow: hidden` — NON-NEGOTIABLE
- All font sizes use `clamp()` — NEVER fixed px/rem
- Import fonts from Google Fonts via `<link>` in `<head>`

### Content density limits (NON-NEGOTIABLE)
- Title: 1 heading + subtitle + date
- Content: heading + 4-6 bullets max
- Cards: heading + 3-4 metric cards max
- Table: heading + 7 data rows max
- Two-column: heading + 2 blocks (each: subheading + 3 bullets)

If content exceeds limits → **split across multiple slides**. Never cram.

### JS rules
- Include the `SlidePresentation` class from `html-template.md`
- Handles: keyboard nav, touch/swipe, wheel scroll, progress bar, nav dots, Intersection Observer animations

## Step 5: Write and publish

```bash
# Write the HTML file
write_file("presentation.html", "<full HTML content>")

# Publish to run directory (if associated with a run)
aicore run-output --run-id <run_id> --publish presentation.html --role cora
```

Tell the user: "Presentation ready — N slides. Open presentation.html in your browser. Use arrow keys or scroll to navigate."

## Step 6: Self-review

After generating, read the file back and verify:
- [ ] Every slide has `id="slide-N"` with correct sequential numbers
- [ ] No slide has more content than the density limits
- [ ] Layout varies between consecutive slides
- [ ] `:root` variables match the requested theme/brand
- [ ] All `class="reveal"` elements are present for animations
- [ ] `viewport-base.css` is fully inlined
- [ ] `SlidePresentation` JS class is included
- [ ] Font import `<link>` matches the theme fonts

If issues found, fix them before telling the user it's ready.

## Editing slides (iterative refinement)

When the user asks to fix or change a specific slide:

1. Read the HTML file: `read_file("presentation.html")`
2. Find the target: `<section class="slide" id="slide-N">`
3. Edit only that section
4. If splitting a slide: insert new `<section>` after it, renumber all subsequent `id="slide-N"` and `<span class="slide-number">`
5. Write the updated file back

**Common edit requests:**
- "Fix slide 3" → read, find `id="slide-3"`, edit content, write back
- "Split slide 4" → create two sections from one, renumber
- "Make the table bigger" → adjust clamp() values or reduce columns
- "Change the accent color" → update `--accent-primary` in `:root`
- "Add a slide after slide 5" → insert new section, renumber
- "Remove slide 7" → delete section, renumber

## Step 7: Export to PPTX or PDF (on request)

When the user asks for PowerPoint or PDF export:

**Important:** Export BEFORE publishing the HTML. The `--publish` command moves the
file out of your workspace. Use the project directory path for the input.

```bash
# First, find the project directory path
aicore run-output --run-id <run_id> --list

# Export from project dir (where the HTML already lives after publish)
node skills/presentation/slides_export.js --input <project_dir>/presentation.html --output presentation.pptx --format pptx
node skills/presentation/slides_export.js --input <project_dir>/presentation.html --output presentation.pdf --format pdf

# Publish the exports (copies from workspace to project dir + S3)
aicore run-output --run-id <run_id> --publish presentation.pptx --role cora
aicore run-output --run-id <run_id> --publish presentation.pdf --role cora
```

If the HTML is already published, read it from the project dir directly:
```bash
# The project dir is shown in run context, e.g.:
# .iof/instances/<run_id>/project/presentation.html
```

**PPTX export**: Text, tables, and shapes are editable in PowerPoint. Gradients and rounded corners are preserved as vectors. Users can make manual changes after export.

**PDF export**: Pixel-perfect rendering at 1920x1080. Good for print and email distribution.

## Reference files

Read these files in your workspace for detailed specifications:
- `skills/presentation/themes.md` — CSS theme variables, brand derivation rules
- `skills/presentation/viewport-base.css` — mandatory baseline CSS (inline entirely)
- `skills/presentation/html-template.md` — full HTML skeleton, JS class, slide type reference
- `skills/presentation/slides_export.js` — Node.js export tool (HTML → PPTX/PDF)
