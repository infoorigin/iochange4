---
name: run_diagnostics
description: Diagnose any workflow or swarm run - what happened, why it failed, is it stuck - starting from `aicore forensics explain`. Every claim comes from a command you just ran, never from memory.
always: false
metadata: {"iobot": {"requires": {"bins": ["aicore"]}}}
---

# Run diagnostics

For any "what happened / what went wrong / is it stuck / did it work" question
about a run, follow this protocol. Evidence first: never conclude from memory
what a command can answer.

## 1. Classify the run

`runs.kind` (via the data_query skill) tells you what you are looking at:

| kind | Shape | Where its evidence lives |
|---|---|---|
| `workflow` | Multi-step DAG driven by Alex | steps table; `forensics/attempts/<step>.<n>/` blobs |
| `swarm` | ONE step `run`: a meta-agent directing a roster | the same, PLUS `project/dispatch.json`, `results.json`, per-child `*_result.json`, and the `_run_plan.md` checkpoint |

Swarm budgets are TWO different mechanisms - be precise about which one you
are judging: `budget.tool_calls` is HARD (it becomes the run's
maxToolIterations; the session physically cannot loop past it - a breach
shows up as a max_tool_iterations failure), while `budget.consults` is a
BRIEFING CONTRACT (advisory; an overage means the meta-agent overspent its
instructions, and explain's verdict flags it). Never describe the whole
guardrail as logging-only, and never suggest building a hard cap that
already exists.

An ID starting `task_*` is an AD-HOC TASK, not a run. Its row lives in the
`tasks` table (data_query: task_id, run_id, role, status, output_text). When
it was spawned WITH a run id, its blobs live under that run:
`aicore forensics stats <run_id>` includes a tasks section, and
`aicore forensics blob <run_id> task:<task_id> session-snapshot.jsonl` (or
`exit.json`, `http.log`) opens them - that is how you answer "which tools
did the task run". A task spawned without a run id has NO blobs (documented
boundary) - say so.

An ID starting `sv_*` is a session run from a different deployment - say so
and stop; nothing here applies to it.

## 2. Always start with explain

```
exec aicore forensics explain <run_id>
```

One command returns: the verdict sentence, per-step outcomes with translated
failure reasons, the retry story, artifact-gate results, swarm children (who
was consulted, who failed, with what error), checkpoint and budget
observance, token totals, and `look_next` - up to three paste-ready commands
for going deeper.

Report the verdict conversationally: outcome first, then the cause, then what
you checked. For swarm runs, name each failed child and quote its error
exactly as explain reports it.

## 3. Go deeper only where look_next points

Run the exact commands explain suggests - typically:

- `aicore forensics blob <run_id> <step.attempt> session-snapshot.jsonl` - the failing attempt's dialog
- `aicore forensics narrative <run_id> <step.attempt>` - human-readable replay ("what did the agent actually do?")
- `aicore forensics show <run_id> --severity warn` - the event timeline
- `aicore forensics stats <run_id>` - per-attempt counters
- For a `type: exec` / `route` step there is NO session - its record is the command's own stdout and stderr: `aicore status --run-id <run_id> --step <key>` (the last attempt) or `aicore forensics blob <run_id> <step.attempt> stderr.log` (any attempt). explain already quotes the last stderr line in its verdict.

Never hand-assemble blob paths; use the commands.

## 4. Cost questions are NOT this skill

Tokens, cost, cache efficiency, dollar what-ifs: use the `run_costs` skill
(`iof-run-audit`). `aicore forensics stats` carries NO token data - answering
a cost question from it reports numbers as unavailable while they sit in a
file it does not read.

## 5. Stuck, or recovering?

Before ANY intervention advice:

```
exec aicore forensics is-recovering <run_id> <step_key>
```

Exit 10 = recovery in progress: hands off, tell the user the harness is
handling it and you will check back. Exit 0 = safe to act.

## 6. Fix it - delegate to Alex, never write yourself

```
exec curl -s -X POST http://localhost:8111/api/run/<run_id>/message \
  -H "Content-Type: application/json" \
  -d '{"message": "@project_lead run: aicore step-retry --step-key <step> --run-id <run_id>"}'
```

| User says | You tell Alex |
|---|---|
| "retry <step>" | `@project_lead run: aicore step-retry --step-key <step> --run-id <run_id>` |
| "skip <step>" | `@project_lead run: aicore step-skip --step-key <step> --run-id <run_id>` |
| "it crashed / it's stuck" (is-recovering exited 0) | `@project_lead run: aicore step-retry --step-key <step> --run-id <run_id> --crash-recovery` |
| "continue the run / it was interrupted" (driver gone, steps pending) | `aicore resume <run_id>` - reaps orphaned steps, re-spawns the driver; refuses if a driver is still alive |

After delegating, confirm what you asked for and that you will verify it
started.

## 7. From symptom to design fix

When the diagnosis is a DESIGN problem, say so and offer the change - the
`platform_advisor` skill carries the method and the authoring templates:

| Symptom (from explain) | Design change |
|---|---|
| `step.artifact_missing` / gate failed | The step prompt never names the deliverable file, or `requires_artifacts` names the wrong one |
| A commanded tool errored "not recognized"/"command not found", or the deliverable records tool errors instead of numbers | TOOL/DATA ACCESS, not prompt wording. A missing BINARY was never declared or installed: `aicore cli-hub check` names the gaps; the platform fix is `new-tool` (script + entry point + tools.yaml, then `pip install -e .`) or declaring an existing binary in tools.yaml - NEVER advise pointing the prompt at a tool that exists nowhere. A failing DATA path (`--db`/`--metadata-dir`) means the workspace metadata lacks that database/catalog: `configure-agent` places it, and `iof-query --db iof` is what exists by default |
| `protocol_parse_failed` — the user says "marked failed but it did the work", "no STATUS line", "output has no STATUS/OUTPUT" | STRUCTURAL, not a prompt problem: the agent lacks the `output_protocol` SKILL (every agent must carry it — without it no STATUS:/OUTPUT: is ever emitted and every step is marked failed), or the workflow role's `skills:` whitelist dropped it (any always:true skill not named is dropped; output_protocol is normally auto-added by the engine, so also check the agent workspace actually contains `skills/output_protocol/`). Do NOT advise prompt wording first — name the missing skill. |
| `agent_premature_termination` on a compose-heavy step | Sectioned composition: per-section files assembled by an exec step |
| Roster-name warnings in the log | The swarm's `agents:`/`mcp_servers:` name things this workspace never registered |
| `max_tool_iterations` / budget cap reached | Raise `budget.tool_calls`, or narrow the goal/roster |
| Passed, but padded or unfocused deliverable | Tighten the step prompts and the deliverable contract |

## Rules

1. Forensic CLI only - never parse session JSONLs by hand.
2. Speak human - translate everything; no JSON dumps, no raw log lines.
3. Never run write commands - retries and skips are Alex's job.
4. Always name the run_id you diagnosed.
5. No run named? Ask, or resolve the latest via data_query - and say which one you used.
6. Never fabricate: a figure or cause you did not read from a command's output does not appear in your answer.
7. KNOW THE EVIDENCE BOUNDARY: the capture records WHAT failed, not why a
   REMOTE system was slow or down - a child timeout, a 500, a 401 carry no
   remote-side cause. Say "the capture does not record the remote cause"
   rather than constructing a theory, and NEVER borrow prose from the run's
   deliverable as a causal explanation (report content is domain data, not
   diagnostics). If you offer a hypothesis at all, label it a guess AFTER
   stating that boundary.
