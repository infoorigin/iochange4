# Swarm template

A swarm is a KNOWN DESTINATION with the route decided at runtime: one
meta-agent, a goal supplied at run time, and a roster of capabilities
(external A2A agents + MCP servers) it may use. It lives at
`solutions/<solution>/swarms/<name>/`. Scaffold with
`aicore new-swarm <name> --solution <s> --role <r> --agents a,b --mcp x`,
run with `aicore run-swarm <name> --goal "..."`.

## Rules that make output lint-clean by construction

- `name:` MUST equal the directory name.
- Top-level keys are EXACTLY: `name, description, role, agents, mcp_servers,
  skills, deliverable, max_attempts, budget, vars`. Unknown keys are ERRORS
  with did-you-mean.
- `vars:` values MUST be quoted strings - never a bare int, never a list
  (the model is `Dict[str, str]`). A list is expressed as one comma-joined
  string: `focus: "rx-benchmark,price-movement"`; a number is quoted:
  `lookback_days: "7"`. The linter refuses anything else.
- `role:` names an existing agent in the family and MUST NOT be
  `project_lead` (that role is the run driver).
- `agents:` semantics are three-valued: OMIT the key = every external agent
  registered for the workspace; a LIST = exactly that roster; `[]` = none.
  `mcp_servers:` mirrors it against the declared MCP tiers. Scope down - an
  unscoped roster is a capability leak into the meta-agent's routing.
- `a2a_consult` is ensured automatically whenever the swarm can consult
  (agents omitted or non-empty); you never need to list it.
- `deliverable:` (default `swarm_report.md`) is the fail-closed gate - the
  run does not complete until the file exists and is non-empty.
- `budget.tool_calls` is a HARD cap (values under 20 are raised to 20 - the
  run driver shares the config); `budget.consults` is a briefing contract the
  meta-agent follows, not physics. Set both; a swarm without a budget can
  rabbit-hole.
- A description is required in practice - operators pick a swarm from that
  line and the generated persona quotes it.
- Optional files: `meta.md` overrides the generated goal briefing;
  `roles/<role>.md` overrides the generated orchestrator persona;
  `metadata/` ships reference data (`{{metadata_dir}}`).
- Recurrence ("weekly", "every morning") is NOT a swarm property - a swarm
  runs when invoked. Schedule with cron/heartbeat driving `aicore run-swarm`.

## Exemplar (complete, lints clean)

```yaml
# file: pricing_watch/swarm.yaml
name: pricing_watch
description: Watch competitor pricing signals and report the week's movements.
role: intel_orchestrator
agents: [rx-sales]
mcp_servers: []
deliverable: pricing_watch.md
max_attempts: 2
budget:
  tool_calls: 80
  consults: 4
```

The compiled run gives the meta-agent: your goal, the scoped roster catalog
(`metadata/external_agents.yaml`), the `a2a_consult` protocol, a checkpoint
mandate (`_run_plan.md` - retries resume from it), and the deliverable
contract.

Close every authored swarm with: run `aicore lint-swarm <name>` - generated
YAML is unverified until linted.
