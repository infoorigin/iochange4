# Presentation Themes

## Accent color priority

1. **User provides brand color** → use it as `--accent-primary`
2. **No brand color specified** → use the theme's default accent (e.g., navy for Swiss Consulting)

## Built-in themes

Pick one based on user preference or default to **Swiss Consulting**.

### 1. Swiss Consulting (default)

Classic McKinsey/BCG aesthetic. White background, clean grid layouts. Default accent: navy. Replace with user's brand color when provided.

```css
:root {
  --bg-primary: #ffffff;
  --bg-secondary: #f5f7fa;
  --text-primary: #1a1a2e;
  --text-secondary: #4a4a5a;
  --accent-primary: #0052cc;
  --accent-secondary: #0077b6;
  --accent-muted: rgba(0, 82, 204, 0.08);
  --card-bg: #f0f4f8;
  --border-color: rgba(0, 0, 0, 0.08);
  --font-display: 'Plus Jakarta Sans', sans-serif;
  --font-body: 'DM Sans', sans-serif;
}
```
Google Fonts import: `Plus+Jakarta+Sans:wght@400;600;700;800&family=DM+Sans:wght@400;500;600`

### 2. Executive Dark

C-suite presentations. Dark background, gold/warm accents, elegant serif headings.

```css
:root {
  --bg-primary: #0f0f14;
  --bg-secondary: #1a1a24;
  --text-primary: #e8e4df;
  --text-secondary: #a0998f;
  --accent-primary: #d4a574;
  --accent-secondary: #c9b896;
  --accent-muted: rgba(212, 165, 116, 0.12);
  --card-bg: rgba(255, 255, 255, 0.05);
  --border-color: rgba(255, 255, 255, 0.08);
  --font-display: 'Cormorant Garamond', serif;
  --font-body: 'DM Sans', sans-serif;
}
```
Google Fonts import: `Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@400;500;600`

### 3. Modern Corporate

Light gray foundation, teal accents. Data-visualization-friendly. Good for technical presentations.

```css
:root {
  --bg-primary: #fafbfc;
  --bg-secondary: #eef1f5;
  --text-primary: #1e293b;
  --text-secondary: #475569;
  --accent-primary: #0d9488;
  --accent-secondary: #0891b2;
  --accent-muted: rgba(13, 148, 136, 0.08);
  --card-bg: #ffffff;
  --border-color: rgba(0, 0, 0, 0.06);
  --font-display: 'Inter', sans-serif;
  --font-body: 'Inter', sans-serif;
}
```
Google Fonts import: `Inter:wght@400;500;600;700;800`

Note: add `box-shadow: 0 1px 3px rgba(0,0,0,0.06)` to `.card` and `.metric-card` for this theme.

### 4. Minimal Light

Maximum readability. Pure white, black text, single accent. For data-heavy or regulatory content.

```css
:root {
  --bg-primary: #ffffff;
  --bg-secondary: #f9f9f9;
  --text-primary: #111111;
  --text-secondary: #555555;
  --accent-primary: #2563eb;
  --accent-secondary: #3b82f6;
  --accent-muted: rgba(37, 99, 235, 0.06);
  --card-bg: #f4f4f5;
  --border-color: rgba(0, 0, 0, 0.06);
  --font-display: 'Source Serif 4', serif;
  --font-body: 'Source Sans 3', sans-serif;
}
```
Google Fonts import: `Source+Serif+4:wght@400;600;700&family=Source+Sans+3:wght@400;500;600`

---

## Custom brand theme

When the user provides brand colors, fonts, or styling hints, build a custom `:root` block.

### Deriving from partial input

| User provides | How to derive the rest |
|---|---|
| 1 color (e.g., "#1B365D") | Use as `--accent-primary`. White bg, dark text. Derive `--accent-secondary` as 20% lighter. `--accent-muted` as 8% opacity. |
| "white background" | `--bg-primary: #ffffff`, `--text-primary: #1a1a2e`. Use Swiss Consulting accent or ask. |
| "dark background" | `--bg-primary: #0f0f14`, `--text-primary: #e8e4df`. Use Executive Dark accent or ask. |
| 2 colors | First = accent-primary, second = accent-secondary. Auto-detect bg (white unless dark specified). |
| Full brand spec (bg + colors + fonts) | Use all values directly. |
| "corporate" / "professional" | Use Swiss Consulting. |
| "elegant" / "premium" | Use Executive Dark. |
| "clean" / "minimal" | Use Minimal Light. |
| "modern" / "tech" | Use Modern Corporate. |

### Contrast rules

- Light bg (`--bg-primary` lightness > 60%) → dark text (`#1a1a2e` or darker)
- Dark bg (`--bg-primary` lightness < 40%) → light text (`#e8e4df` or lighter)
- `--accent-primary` must have at least 4.5:1 contrast ratio against `--bg-primary`
- `--card-bg` should be a subtle shift from `--bg-primary` (5-10% difference)
- `--accent-muted` = accent-primary at 6-10% opacity (for tag backgrounds, highlights)

### Example: user says "white background, brand blue #1B365D"

```css
:root {
  --bg-primary: #ffffff;
  --bg-secondary: #f5f7fa;
  --text-primary: #1a1a2e;
  --text-secondary: #4a4a5a;
  --accent-primary: #1B365D;
  --accent-secondary: #2a5080;
  --accent-muted: rgba(27, 54, 93, 0.08);
  --card-bg: #f0f3f7;
  --border-color: rgba(0, 0, 0, 0.08);
  --font-display: 'Plus Jakarta Sans', sans-serif;
  --font-body: 'DM Sans', sans-serif;
}
```
