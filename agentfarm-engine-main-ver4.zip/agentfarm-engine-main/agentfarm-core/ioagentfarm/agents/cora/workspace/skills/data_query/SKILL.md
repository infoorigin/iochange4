---
name: data_query
description: Query the AI Core Harness database (runs, steps, tasks, messages, workflows) to answer user questions about platform activity.
---

# data_query

## Goal

Answer questions about runs, steps, tasks, messages, and workflows by querying the AI Core Harness database via SQL.

## Metadata location

The metadata directory is at: `metadata/cora`

This contains `catalog.yml` (entity index), `databases.yml` (connection config), and `entities/` (shared column definitions).

## Process

### Step 1: Discover available data

Read `metadata/cora/catalog.yml` to see all available entities, their grains, and field summaries.

### Step 2: Explore relevant entities

Read the entity YAML files in `metadata/entities/` (note: entities are in the parent directory, shared across agents). For each entity, note:
- `table:` — the actual database table (schema.table_name)
- `database:` — which database config to use
- `dimensions:` — real columns (name, type, sql, primary_key)
- `measures:` — formulas (name + sql field — NEVER use name as a column)
- `joins:` — relationships to other entities (target_entity, join_columns)
- `filters:` — pre-defined WHERE conditions

### Step 3: Verify join conditions (if joining tables)

For every JOIN you plan to write:
1. Read BOTH entity YAML files
2. Find a column that appears in BOTH `dimensions:` sections (shared column name)
3. If no shared column, check the `joins:` section of each YAML for relationship hints
4. Use confirmed columns only — NEVER guess join conditions

### Step 4: Build SQL

Using ONLY confirmed columns and formulas:
- Every SELECT column must exist in a `dimensions:` section of a YAML you read
- If a column only appears as a measure `name:`, replace it with the `sql:` formula
- PostgreSQL dialect: double-quotes for identifiers, `TO_CHAR()` for date formatting
- Add `LIMIT 200` to all queries
- Use `NULLIF(denominator, 0)` for any division
- Timestamp columns stored as text require `::timestamp` cast for date math

### Step 5: Execute via CLI tool

```
iof-query --db iof --sql "<query>" --metadata-dir metadata/cora
```

Credentials are loaded automatically from `.env` — no manual setup needed.

The script returns JSON:
```json
{"success": true, "columns": [...], "rows": [...], "row_count": N, "database": "..."}
```

Or on error:
```json
{"success": false, "error": "...", "error_type": "COLUMN_NOT_FOUND"}
```

For complex SQL with special characters, write to a file and use `--sql-file`:
```
iof-query --db iof --sql-file query.sql --metadata-dir metadata/cora
```

### Step 6: Handle errors and retry

If the query fails:
- **COLUMN_NOT_FOUND**: Re-read the entity YAML, find the correct column name
- **TABLE_NOT_FOUND**: Verify schema.table from the entity YAML
- **SYNTAX_ERROR**: Fix SQL syntax and retry
- Retry up to 2 times with corrected SQL

## Checklist before executing

- [ ] Every SELECT column exists in a `dimensions:` section of a YAML I read
- [ ] Every measure uses the `sql:` formula, not the measure `name:`
- [ ] Every JOIN key is confirmed from a YAML I read
- [ ] LIMIT 200 is present
- [ ] Database is `iof` (the AI Core Harness database)

## When to use

Use this skill when users ask about:
- Run status, counts, history ("how many pharma runs this week?")
- Step failures, retries, durations ("which steps failed the most?")
- Task activity ("show pending tasks")
- Message volume, agent activity ("how many messages per run?")
- Workflow metadata ("what workflows are available?")

Do NOT use this for domain-specific data queries (EDI, candidates, pharma data) — route those to the appropriate agent instead.
