# HTML Template Reference

Every generated presentation must follow this skeleton. All CSS and JS are inlined — single self-contained file.

## Full document structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{presentation_title}}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family={{font_display}}:wght@400;600;700;800&family={{font_body}}:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    /* 1. Theme variables (from themes.md or custom brand) */
    :root {
      --bg-primary: #ffffff;
      --bg-secondary: #f8f9fa;
      --text-primary: #1a1a2e;
      --text-secondary: #4a4a5a;
      --accent-primary: #0052cc;
      --accent-secondary: #00a3e0;
      --accent-muted: rgba(0, 82, 204, 0.1);
      --card-bg: #f0f4f8;
      --border-color: rgba(0, 0, 0, 0.08);
      --font-display: 'Plus Jakarta Sans', sans-serif;
      --font-body: 'Inter', sans-serif;
    }

    /* 2. viewport-base.css (inline the ENTIRE file here) */
    /* ... */

    /* 3. Theme-specific overrides */
    body {
      font-family: var(--font-body);
      background: var(--bg-primary);
      color: var(--text-primary);
    }

    .slide h1, .slide h2, .slide h3 {
      font-family: var(--font-display);
      color: var(--text-primary);
    }

    /* 4. Slide-type-specific styles */
    .title-slide {
      text-align: center;
      background: var(--bg-primary);
    }

    .title-slide .divider {
      width: 60px;
      height: 3px;
      background: var(--accent-primary);
      margin: 1rem auto;
    }

    .section-slide {
      background: var(--accent-primary);
      color: white;
    }

    .metric-card {
      text-align: center;
      padding: clamp(1rem, 2vw, 2rem);
      background: var(--card-bg);
      border-radius: 8px;
      border-left: 4px solid var(--accent-primary);
    }

    .severity-critical { color: #dc3545; font-weight: 700; }
    .severity-high { color: #fd7e14; font-weight: 700; }
    .severity-medium { color: #ffc107; font-weight: 600; }

    .tag {
      display: inline-block;
      padding: 0.2em 0.6em;
      border-radius: 4px;
      font-size: clamp(0.6rem, 1vw, 0.8rem);
      font-weight: 600;
      background: var(--accent-muted);
      color: var(--accent-primary);
    }

    .slide-number {
      position: absolute;
      bottom: 1rem;
      right: 1.5rem;
      font-size: clamp(0.6rem, 0.8vw, 0.75rem);
      opacity: 0.4;
      font-family: var(--font-body);
    }
  </style>
</head>
<body>
  <div class="progress-bar" id="progressBar"></div>
  <div class="nav-dots" id="navDots"></div>

  <div class="presentation" id="presentation">

    <!-- Slide 1: Title -->
    <section class="slide title-slide" id="slide-1">
      <div class="slide-content" style="text-align: center;">
        <h1 class="reveal">{{main_title}}</h1>
        <div class="divider reveal"></div>
        <p class="subtitle reveal">{{subtitle}}</p>
        <p class="reveal" style="opacity: 0.5; margin-top: 1rem;">
          {{date}} &middot; {{team_or_org}}
        </p>
      </div>
      <span class="slide-number">1</span>
    </section>

    <!-- Slide 2: Executive Summary (metric cards) -->
    <section class="slide" id="slide-2">
      <div class="slide-content">
        <h2 class="reveal">Executive Summary</h2>
        <div class="card-grid reveal">
          <div class="metric-card">
            <div class="metric-value">{{value1}}</div>
            <div class="metric-label">{{label1}}</div>
          </div>
          <div class="metric-card">
            <div class="metric-value">{{value2}}</div>
            <div class="metric-label">{{label2}}</div>
          </div>
          <div class="metric-card">
            <div class="metric-value">{{value3}}</div>
            <div class="metric-label">{{label3}}</div>
          </div>
        </div>
        <p class="reveal" style="margin-top: 1rem;">{{summary_sentence}}</p>
      </div>
      <span class="slide-number">2</span>
    </section>

    <!-- Slide 3: Key Findings (bullet list) -->
    <section class="slide" id="slide-3">
      <div class="slide-content">
        <h2 class="reveal">Key Findings</h2>
        <ul>
          <li class="reveal"><strong>{{finding1_label}}:</strong> {{finding1_detail}}</li>
          <li class="reveal"><strong>{{finding2_label}}:</strong> {{finding2_detail}}</li>
          <li class="reveal"><strong>{{finding3_label}}:</strong> {{finding3_detail}}</li>
          <li class="reveal"><strong>{{finding4_label}}:</strong> {{finding4_detail}}</li>
        </ul>
      </div>
      <span class="slide-number">3</span>
    </section>

    <!-- Slide 4: Comparison Table -->
    <section class="slide" id="slide-4">
      <div class="slide-content">
        <h2 class="reveal">Strategy Comparison</h2>
        <table class="reveal">
          <thead>
            <tr><th>Play</th><th>Target</th><th>Speed</th><th>Impact</th></tr>
          </thead>
          <tbody>
            <tr><td>{{play_a}}</td><td>{{target_a}}</td><td>{{speed_a}}</td><td>{{impact_a}}</td></tr>
            <tr><td>{{play_b}}</td><td>{{target_b}}</td><td>{{speed_b}}</td><td>{{impact_b}}</td></tr>
          </tbody>
        </table>
      </div>
      <span class="slide-number">4</span>
    </section>

    <!-- Slide 5: Two-column layout -->
    <section class="slide" id="slide-5">
      <div class="slide-content">
        <h2 class="reveal">{{two_col_title}}</h2>
        <div class="two-column">
          <div class="reveal">
            <h3>{{left_heading}}</h3>
            <p>{{left_content}}</p>
          </div>
          <div class="reveal">
            <h3>{{right_heading}}</h3>
            <p>{{right_content}}</p>
          </div>
        </div>
      </div>
      <span class="slide-number">5</span>
    </section>

    <!-- More slides... -->

  </div>

  <script>
    class SlidePresentation {
      constructor() {
        this.container = document.getElementById('presentation');
        this.slides = document.querySelectorAll('.slide');
        this.currentSlide = 0;
        this.totalSlides = this.slides.length;
        this.progressBar = document.getElementById('progressBar');
        this.navDotsContainer = document.getElementById('navDots');
        this.isScrolling = false;

        this.createNavDots();
        this.setupObserver();
        this.setupKeyboard();
        this.setupTouch();
        this.setupWheel();
        this.updateProgress();
      }

      createNavDots() {
        for (let i = 0; i < this.totalSlides; i++) {
          const dot = document.createElement('button');
          dot.className = 'nav-dot' + (i === 0 ? ' active' : '');
          dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
          dot.addEventListener('click', () => this.goToSlide(i));
          this.navDotsContainer.appendChild(dot);
        }
      }

      setupObserver() {
        // Reveal animations
        const revealObserver = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) entry.target.classList.add('visible');
          });
        }, { threshold: 0.1 });
        document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

        // Track current slide
        const slideObserver = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              this.currentSlide = Array.from(this.slides).indexOf(entry.target);
              this.updateProgress();
              this.updateDots();
            }
          });
        }, { threshold: 0.5 });
        this.slides.forEach(slide => slideObserver.observe(slide));
      }

      setupKeyboard() {
        document.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown' || e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
            e.preventDefault();
            this.nextSlide();
          } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft' || e.key === 'PageUp') {
            e.preventDefault();
            this.prevSlide();
          } else if (e.key === 'Home') {
            e.preventDefault();
            this.goToSlide(0);
          } else if (e.key === 'End') {
            e.preventDefault();
            this.goToSlide(this.totalSlides - 1);
          }
        });
      }

      setupTouch() {
        let startY = 0;
        this.container.addEventListener('touchstart', (e) => { startY = e.touches[0].clientY; }, { passive: true });
        this.container.addEventListener('touchend', (e) => {
          const diff = startY - e.changedTouches[0].clientY;
          if (Math.abs(diff) > 50) {
            diff > 0 ? this.nextSlide() : this.prevSlide();
          }
        }, { passive: true });
      }

      setupWheel() {
        this.container.addEventListener('wheel', (e) => {
          if (this.isScrolling) return;
          this.isScrolling = true;
          if (e.deltaY > 0) this.nextSlide();
          else if (e.deltaY < 0) this.prevSlide();
          setTimeout(() => { this.isScrolling = false; }, 800);
        }, { passive: true });
      }

      goToSlide(index) {
        if (index >= 0 && index < this.totalSlides) {
          this.slides[index].scrollIntoView({ behavior: 'smooth' });
        }
      }

      nextSlide() { this.goToSlide(this.currentSlide + 1); }
      prevSlide() { this.goToSlide(this.currentSlide - 1); }

      updateProgress() {
        const pct = ((this.currentSlide + 1) / this.totalSlides) * 100;
        this.progressBar.style.width = pct + '%';
      }

      updateDots() {
        const dots = this.navDotsContainer.querySelectorAll('.nav-dot');
        dots.forEach((dot, i) => dot.classList.toggle('active', i === this.currentSlide));
      }
    }

    document.addEventListener('DOMContentLoaded', () => new SlidePresentation());
  </script>
</body>
</html>
```

## Slide type reference

| Type | CSS class | Max content | Use for |
|------|-----------|-------------|---------|
| Title | `.title-slide` | 1 heading + subtitle + date | Opening slide |
| Section divider | `.section-slide` | 1 heading + subtitle | Separating major sections |
| Metric cards | `.card-grid` + `.metric-card` | 3-4 cards | KPIs, summary stats |
| Bullet list | `<ul>` with `<li class="reveal">` | 4-6 bullets max | Key findings, action items |
| Table | `<table>` | 5-7 rows max | Comparisons, data |
| Two-column | `.two-column` | 2 blocks side-by-side | Before/after, pros/cons |
| Quote/callout | Styled `<blockquote>` | 1 quote (3 lines max) | Key insight highlight |

## Layout variety rule

NEVER use the same layout for 2 consecutive slides. Rotate between:
metric cards → bullets → table → two-column → cards → bullets

## Content density limits (NON-NEGOTIABLE)

- Title slide: 1 heading + 1 subtitle + optional date line
- Content slide: 1 heading + 4-6 bullets OR 1 heading + 2 short paragraphs
- Card grid: 1 heading + 3-4 metric cards (never more than 4)
- Table: 1 heading + max 7 data rows
- Two-column: 1 heading + 2 blocks (each block: subheading + 3 bullets or 1 paragraph)

If content exceeds limits → split across multiple slides. NEVER cram.
