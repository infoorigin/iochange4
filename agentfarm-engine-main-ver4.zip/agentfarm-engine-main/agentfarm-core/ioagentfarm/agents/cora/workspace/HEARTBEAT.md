# Heartbeat tick

This file is checked periodically by the heartbeat cron job.
On each tick, follow these steps in order. Do ONE action, log it, then stop.

## Tick order

**Step 1: Check completed ad-hoc tasks**
```
aicore task-list --status done --user-id <user_id>
aicore task-list --status failed --user-id <user_id>
```
For each completed/failed task: notify the user with the result, then:
```
aicore task-update --task-id <id> --status notified
```

**Step 2: Check active workflow progress**
```
aicore status --json --user-id <user_id>
```
If a run completed or failed since last tick, notify the user.

**Step 3: If nothing to report** → reply with HEARTBEAT_OK

## Heartbeat logging

After EVERY tick, append a log line to `heartbeat.log`:
```
[<ISO timestamp>] TICK <action> | <details>
```
Actions: `idle`, `task_done`, `task_failed`, `run_complete`, `run_failed`, `waiting`
