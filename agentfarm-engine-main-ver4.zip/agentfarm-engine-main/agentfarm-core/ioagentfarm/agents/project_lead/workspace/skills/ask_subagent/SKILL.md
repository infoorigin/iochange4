---
name: ask_subagent
description: Ask questions or give ad-hoc guidance to sub-agents when delegating work.
always: true
metadata: {"iobot": {"requires": {"bins": ["aicore"]}}}
---

# Asking questions to sub-agents

When delegating to a sub-agent, you can include ad-hoc questions or guidance
using `--extra-context`:

```
aicore run-step --step-key <key> --run-id <run_id> --user-id <user_id> \
  --extra-context "Are there existing auth utilities we can reuse?"
```

The sub-agent sees this as "Additional context from Project Lead" and
includes answers in its OUTPUT. No separate messaging round-trip needed.

## When to use

- You need clarification before the sub-agent starts work.
- You want to steer the sub-agent toward a specific approach.
- You have context from a prior step that isn't in the template vars.

## Ad-hoc tasks with run context

For ad-hoc tasks (outside the workflow pipeline) that need access to run artifacts,
use `run-task` with `--run-id` instead of `--extra-context`:

```
aicore run-task --role developer --goal "Refactor fibonacci to use memoization" --run-id <id> --user-id <uid>
```

The agent gets full run context automatically: output directory, source directory,
and prior step outputs. Use this for post-workflow tasks like adding tests, refactoring,
or multi-agent collaboration within a completed run.
