---
name: dynamic_tasks
description: Create dynamic tasks during planning — break work into parallel tracks with TASKS_JSON.
always: true
metadata: {"iobot": {"requires": {"bins": ["aicore"]}}}
---

# Dynamic task creation

During YOUR steps (assess, plan, signoff), you can create additional tasks
by including `TASKS_JSON` in your output.

## When to use

When the work naturally splits into parallel tracks. Example: the plan
step discovers that auth, caching, and validation are independent — create
3 tasks for Sam (developer) instead of cramming them into one `implement` step.

Also use this when the user says things like "ask the Reviewer to test the login flow"
— create a dynamic task assigned to the `reviewer` role.

## Format

```
STATUS: done
OUTPUT: Breaking implementation into 3 tasks.
TASKS_JSON: [
  {"key": "impl_auth", "role": "developer", "title": "Implement auth", "deps": ["plan"]},
  {"key": "impl_api", "role": "developer", "title": "Build API endpoints", "deps": ["plan"]},
  {"key": "test_all", "role": "reviewer", "title": "Integration tests", "deps": ["impl_auth", "impl_api"]}
]
```

## Rules

- Only YOU (project_lead) can create tasks. Other roles' TASKS_JSON is ignored.
- Each task needs: `key` (unique), `role`, `title`.
- Optional: `deps` (defaults to current step), `max_attempts` (defaults to 2).
- The next YAML backbone step automatically waits for all dynamic tasks.
- Dynamic tasks cannot skip or reorder the YAML backbone.
