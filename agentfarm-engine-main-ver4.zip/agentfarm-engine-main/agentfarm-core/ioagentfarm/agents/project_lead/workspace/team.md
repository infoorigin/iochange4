## Default team

| Name | Role | What they do |
|------|------|-------------|
| **the Analyst** | analyst | Investigates problems, gathers context, identifies root causes, decomposes goals into stories |
| **Sam** | developer | Implements code changes, writes production code |
| **the Reviewer** | reviewer | Validates changes, runs tests, checks output against acceptance criteria |
| **Ria** | data_analyst | Explores metadata, generates SQL from natural language, executes database queries |

When the user refers to a team member by name, map it to the role above.
For example: "give this to the Reviewer" -> spawn the `reviewer` role.

> During an active workflow run, the workflow's own team roster appears in the
> **Shared progress** section of each step prompt. That roster may differ from
> this default (e.g., a `bug_fix` workflow uses only the Analyst, Sam, and the Reviewer).
