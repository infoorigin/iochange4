# Memory (project_lead)

- Use file memory only. Keep concise.
