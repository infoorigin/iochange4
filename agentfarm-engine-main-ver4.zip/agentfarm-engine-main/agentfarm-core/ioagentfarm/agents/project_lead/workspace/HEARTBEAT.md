# Heartbeat tick

This file is checked periodically by the heartbeat cron job.
On each tick, follow these steps in order. Do ONE action, log it, then stop.

## Tick order

**Step 1: Check completed ad-hoc tasks**
```
aicore task-list --status done --user-id <user_id>
aicore task-list --status failed --user-id <user_id>
```
For each completed/failed task: notify the user with the result, then:
```
aicore task-update --task-id <id> --status notified
```

**Step 2: Advance active workflow**
```
aicore next-step --user-id <user_id>
```
- If `done: true` → workflow complete, notify user with summary.
- If `waiting: true` → sub-agent still running, nothing to do.
- If `role = project_lead` → execute inline (write output file, then step-complete).
- If `role = other` → delegate in background:
  ```
  aicore run-step --step-key <key> --run-id <run_id> --user-id <user_id> --background
  ```

**Step 3: If no active runs and no pending tasks** → reply with HEARTBEAT_OK

## Heartbeat logging

After EVERY tick, append a log line to `heartbeat.log` in your workspace:

```
[<ISO timestamp>] TICK <action> | <details>
```

Actions:
- `idle` — no active runs, no pending tasks
- `advanced` — spawned or completed a workflow step
- `task_done` — notified user of completed task
- `task_failed` — notified user of failed task
- `spawned` — launched a background step or task
- `waiting` — sub-agent still running, nothing to do

Examples:
```
[2026-02-22T14:30:00] TICK idle | no active runs or tasks
[2026-02-22T15:00:00] TICK advanced | step=implement role=developer run=run_20260222_150000
[2026-02-22T15:30:00] TICK task_done | task=task_20260222_143000 role=analyst
[2026-02-22T16:00:00] TICK spawned | step=test role=reviewer run=run_20260222_150000
[2026-02-22T16:30:00] TICK waiting | step=test still running
```

Use `write_file()` to APPEND to `heartbeat.log` (read existing content first, then write back with new line appended).
