"""Pluggable cloud storage backend for run artifacts.

Syncs project artifacts and logs to cloud storage at step boundaries
so that if a pod dies, step-retry on another pod picks up from the
last checkpoint.

Each run gets a folder: ``<bucket>/<prefix>/<run_id>/``

Two operations:
    push — upload local dir to cloud (after step completes)
    pull — download cloud dir to local (before step starts / on retry)

Backends:
    NoopStorage  — disabled, local-only (default)
    S3Storage    — Amazon S3 / S3-compatible (MinIO, etc.)

Selected via IOF_STORAGE env var: "none" (default), "s3".
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from pathlib import Path

from loguru import logger


class StorageBackend(ABC):
    """Protocol for cloud storage backends."""

    @abstractmethod
    def push(self, run_id: str, local_dir: Path, sub_prefix: str = "") -> None:
        """Upload local_dir contents to cloud: <run_id>/<sub_prefix>/<relative_path>."""
        ...

    @abstractmethod
    def pull(self, run_id: str, local_dir: Path, sub_prefix: str = "") -> None:
        """Download cloud contents for run_id/<sub_prefix> to local_dir."""
        ...

    def push_file(self, run_id: str, local_path: Path, sub_prefix: str = "",
                  name: str | None = None) -> None:
        """Upload a single file to cloud: <run_id>/<sub_prefix>/<filename>.

        ``name`` stores it under another object name than the local file's -
        a step session's local name carries the user id it ran under, which
        a puller on another pod cannot know.
        """
        pass  # default: no-op

    def pull_file(self, run_id: str, filename: str, local_path: Path, sub_prefix: str = "") -> bool:
        """Download a single file from cloud to local_path. Returns True if found."""
        return False

    def pull_prefix(self, prefix: str, local_dir: Path) -> None:
        """Download cloud contents at an arbitrary prefix to local_dir.

        Unlike pull() which is run-scoped, this downloads from any S3 prefix
        relative to the configured IOF_S3_PREFIX. Used for shared input data.
        """
        pass  # default: no-op

    # ---------------------------------------------------------------------
    # Dataset distribution — source-of-truth CSVs at a stable S3 path
    # shared across envs. Unlike run/session sync (ephemeral per-run), these
    # are the raw input bytes that feed brand.dataset scenarios.
    # Key layout: s3://<bucket>/<prefix>/datasets/<brand_slug>/<dataset_id>/*.csv
    # ---------------------------------------------------------------------

    def push_dataset(
        self, brand_slug: str, dataset_id: str, local_dir: Path
    ) -> int:
        """Upload a dataset folder's CSVs to S3. Returns # files uploaded."""
        return 0  # default: no-op

    def pull_dataset(
        self, brand_slug: str, dataset_id: str, local_dir: Path
    ) -> int:
        """Download a dataset from S3 into local_dir. Returns # files fetched (0 if none)."""
        return 0  # default: no-op

    def read_log(self, run_id: str, offset: int = 0) -> tuple[str, int]:
        """Read the run's stdout log from cloud starting at offset.

        Returns (new_content, new_offset).  Default: no cloud log.
        """
        return "", offset

    @property
    def is_cloud(self) -> bool:
        """True if this backend stores data remotely."""
        return False


# ---------------------------------------------------------------------------
# NoopStorage — disabled, local-only
# ---------------------------------------------------------------------------

class NoopStorage(StorageBackend):
    """No cloud sync — everything stays local. Default for dev."""

    def push(self, run_id, local_dir, sub_prefix=""):
        pass

    def pull(self, run_id, local_dir, sub_prefix=""):
        pass


# ---------------------------------------------------------------------------
# S3Storage — Amazon S3 / S3-compatible
# ---------------------------------------------------------------------------

class S3Storage(StorageBackend):
    """Sync run artifacts to Amazon S3 or S3-compatible storage.

    Config via env vars:
        IOF_S3_BUCKET     — bucket name (required)
        IOF_S3_PREFIX     — key prefix (default: "ioagentfarm/runs")
        IOF_S3_ENDPOINT   — custom endpoint for MinIO etc. (optional)
        IOF_S3_REGION     — AWS region (optional)

    Requires: ``pip install boto3``
    """

    def __init__(self):
        self._bucket = os.getenv("IOF_S3_BUCKET", "")
        self._prefix = os.getenv("IOF_S3_PREFIX", "ioagentfarm/runs")
        self._endpoint = os.getenv("IOF_S3_ENDPOINT", "") or None
        self._region = os.getenv("IOF_S3_REGION", "") or None
        self._access_key = os.getenv("AWS_ACCESS_KEY_ID", "") or None
        self._secret_key = os.getenv("AWS_SECRET_ACCESS_KEY", "") or None

        if not self._bucket:
            raise RuntimeError("IOF_S3_BUCKET env var required for S3 storage")

        logger.info(
            "S3Storage init: bucket={} prefix={} region={} endpoint={} credentials={}",
            self._bucket,
            self._prefix,
            self._region or "(default)",
            self._endpoint or "(default)",
            "explicit" if (self._access_key and self._secret_key) else "boto3-chain",
        )

    def _client(self):
        import boto3
        kwargs = {}
        if self._endpoint:
            kwargs["endpoint_url"] = self._endpoint
        if self._region:
            kwargs["region_name"] = self._region
        if self._access_key and self._secret_key:
            kwargs["aws_access_key_id"] = self._access_key
            kwargs["aws_secret_access_key"] = self._secret_key
        return boto3.client("s3", **kwargs)

    def _classify_error(self, exc: Exception, operation: str, key: str) -> None:
        """Log S3 errors with actionable context for pod debugging.

        Writes to both loguru (run log file) and stdout (container logs / ArgoCD).
        """
        msg = str(exc)
        diag = ""
        if "AccessDenied" in msg:
            arn = ""
            if "User:" in msg:
                arn = msg.split("User:")[1].split("is not")[0].strip()
            action = ""
            if "perform:" in msg:
                action = msg.split("perform:")[1].split("on")[0].strip()
            diag = (f"S3 {operation} ACCESS DENIED: key={key} | IAM={arn or '?'} | "
                    f"missing={action or '?'} | Fix: attach s3:PutObject,GetObject,ListBucket,DeleteObject")
        elif "NoSuchBucket" in msg:
            diag = f"S3 {operation} BUCKET NOT FOUND: bucket={self._bucket} | Fix: create bucket or check IOF_S3_BUCKET"
        elif "NoCredentialProviders" in msg or "NoCredentials" in msg or "InvalidAccessKeyId" in msg:
            diag = (f"S3 {operation} CREDENTIALS ERROR: {msg[:150]} | "
                    f"Fix: set AWS keys or ensure IAM role attached to pod")
        elif "EndpointConnectionError" in msg or "ConnectionError" in msg:
            diag = (f"S3 {operation} CONNECTION ERROR: endpoint={self._endpoint or 'default'} | "
                    f"Fix: check IOF_S3_ENDPOINT, VPC, DNS")
        elif "SlowDown" in msg or "503" in msg:
            diag = f"S3 {operation} THROTTLED: key={key} | will retry on next step boundary"
        else:
            diag = f"S3 {operation} failed: key={key} | {msg[:200]}"

        logger.error(diag)
        print(f"[IOF:S3:ERROR] {diag}", flush=True)

    def push(self, run_id, local_dir, sub_prefix=""):
        if not local_dir.exists():
            logger.debug("S3 push skipped: local_dir={} does not exist", local_dir)
            return

        s3 = self._client()
        count = 0
        errors = 0
        first_error = None

        files = [f for f in local_dir.rglob("*") if f.is_file()]
        s3_sub = f"/{sub_prefix}" if sub_prefix else ""
        logger.info("S3 push starting: run_id={} sub={} files_to_upload={} local_dir={}", run_id, sub_prefix or "(root)", len(files), local_dir)

        for file_path in files:
            relative = file_path.relative_to(local_dir)
            key = f"{self._prefix}/{run_id}{s3_sub}/{relative.as_posix()}"
            try:
                s3.upload_file(str(file_path), self._bucket, key)
                count += 1
                logger.debug("S3 push ok: {}", key)
            except Exception as exc:
                errors += 1
                if first_error is None:
                    first_error = exc
                self._classify_error(exc, "push", key)
                # Stop early on auth/bucket errors — all subsequent uploads will fail too
                exc_msg = str(exc)
                if any(t in exc_msg for t in ("AccessDenied", "NoSuchBucket", "InvalidAccessKeyId", "NoCredential")):
                    logger.error(
                        "S3 push aborting: run_id={} — all uploads will fail with same auth/bucket error "
                        "(skipping remaining {} files)",
                        run_id, len(files) - count - errors,
                    )
                    break

        logger.info(
            "S3 push done: run_id={} uploaded={}/{} errors={} bucket={}/{}",
            run_id, count, len(files), errors, self._bucket, self._prefix,
        )

    def pull(self, run_id, local_dir, sub_prefix=""):
        s3 = self._client()
        s3_sub = f"/{sub_prefix}" if sub_prefix else ""
        prefix = f"{self._prefix}/{run_id}{s3_sub}/"
        count = 0
        errors = 0

        logger.info("S3 pull starting: run_id={} prefix={} local_dir={}", run_id, prefix, local_dir)

        try:
            paginator = s3.get_paginator("list_objects_v2")
            total_objects = 0
            for page in paginator.paginate(Bucket=self._bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    total_objects += 1
                    key = obj["Key"]
                    relative = key[len(prefix):]
                    if not relative:
                        continue
                    local_path = local_dir / relative
                    local_path.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        s3.download_file(self._bucket, key, str(local_path))
                        count += 1
                        logger.debug("S3 pull ok: {} -> {}", key, local_path)
                    except Exception as exc:
                        errors += 1
                        self._classify_error(exc, "pull", key)

            if total_objects == 0:
                logger.info("S3 pull: no objects found for run_id={} (prefix={})", run_id, prefix)

        except Exception as exc:
            self._classify_error(exc, "pull/list", f"{self._bucket}/{prefix}")

        logger.info(
            "S3 pull done: run_id={} downloaded={} errors={} bucket={}/{}",
            run_id, count, errors, self._bucket, self._prefix,
        )

    def push_file(self, run_id, local_path, sub_prefix="", name=None):
        if not local_path.exists():
            logger.debug("S3 push_file skipped: {} does not exist", local_path)
            return
        s3 = self._client()
        s3_sub = f"/{sub_prefix}" if sub_prefix else ""
        key = f"{self._prefix}/{run_id}{s3_sub}/{name or local_path.name}"
        try:
            s3.upload_file(str(local_path), self._bucket, key)
            logger.info("S3 push_file ok: {}", key)
        except Exception as exc:
            self._classify_error(exc, "push_file", key)

    def pull_file(self, run_id, filename, local_path, sub_prefix=""):
        s3 = self._client()
        s3_sub = f"/{sub_prefix}" if sub_prefix else ""
        key = f"{self._prefix}/{run_id}{s3_sub}/{filename}"
        try:
            local_path.parent.mkdir(parents=True, exist_ok=True)
            s3.download_file(self._bucket, key, str(local_path))
            logger.info("S3 pull_file ok: {} -> {}", key, local_path)
            return True
        except Exception as exc:
            # NoSuchKey is expected when session doesn't exist in S3 yet
            if "NoSuchKey" in str(exc) or "404" in str(exc):
                logger.debug("S3 pull_file: not found {}", key)
            else:
                self._classify_error(exc, "pull_file", key)
            return False

    def pull_prefix(self, prefix: str, local_dir: Path) -> None:
        """Download files from an arbitrary S3 prefix to local_dir."""
        s3 = self._client()
        full_prefix = f"{self._prefix}/{prefix}"
        count = 0

        logger.info("S3 pull_prefix starting: prefix={} local_dir={}", full_prefix, local_dir)

        try:
            paginator = s3.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=self._bucket, Prefix=full_prefix):
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    relative = key[len(full_prefix):]
                    if not relative:
                        continue
                    local_path = local_dir / relative
                    local_path.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        s3.download_file(self._bucket, key, str(local_path))
                        count += 1
                    except Exception as exc:
                        self._classify_error(exc, "pull_prefix", key)
        except Exception as exc:
            self._classify_error(exc, "pull_prefix/list", f"{self._bucket}/{full_prefix}")

        logger.info("S3 pull_prefix done: prefix={} downloaded={}", full_prefix, count)

    # ---------------------------------------------------------------------
    # Dataset distribution (S3-backed source of truth for CSV bytes)
    # ---------------------------------------------------------------------

    def _dataset_s3_prefix(self, brand_slug: str, dataset_id: str) -> str:
        """Return the S3 key prefix for a brand dataset's CSVs."""
        return f"{self._prefix}/datasets/{brand_slug}/{dataset_id}"

    def push_dataset(
        self, brand_slug: str, dataset_id: str, local_dir: Path,
    ) -> int:
        if not local_dir.exists() or not local_dir.is_dir():
            logger.warning(
                "S3 push_dataset: local_dir does not exist: {}", local_dir
            )
            return 0
        s3 = self._client()
        base = self._dataset_s3_prefix(brand_slug, dataset_id)
        count = 0
        errors = 0
        files = sorted(f for f in local_dir.iterdir() if f.is_file())
        logger.info(
            "S3 push_dataset: brand={} dataset={} files={} -> s3://{}/{}/",
            brand_slug, dataset_id, len(files), self._bucket, base,
        )
        for f in files:
            key = f"{base}/{f.name}"
            try:
                s3.upload_file(str(f), self._bucket, key)
                count += 1
            except Exception as exc:
                errors += 1
                self._classify_error(exc, "push_dataset", key)
        logger.info(
            "S3 push_dataset done: brand={} dataset={} uploaded={}/{} errors={}",
            brand_slug, dataset_id, count, len(files), errors,
        )
        return count

    def pull_dataset(
        self, brand_slug: str, dataset_id: str, local_dir: Path,
    ) -> int:
        s3 = self._client()
        base = self._dataset_s3_prefix(brand_slug, dataset_id)
        prefix = f"{base}/"
        count = 0
        errors = 0
        local_dir.mkdir(parents=True, exist_ok=True)
        logger.info(
            "S3 pull_dataset: brand={} dataset={} <- s3://{}/{}",
            brand_slug, dataset_id, self._bucket, prefix,
        )
        try:
            paginator = s3.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=self._bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    rel = key[len(prefix):]
                    if not rel:
                        continue
                    target = local_dir / rel
                    target.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        s3.download_file(self._bucket, key, str(target))
                        count += 1
                    except Exception as exc:
                        errors += 1
                        self._classify_error(exc, "pull_dataset", key)
        except Exception as exc:
            self._classify_error(exc, "pull_dataset/list", f"{self._bucket}/{prefix}")
        logger.info(
            "S3 pull_dataset done: brand={} dataset={} downloaded={} errors={}",
            brand_slug, dataset_id, count, errors,
        )
        return count

    @property
    def is_cloud(self) -> bool:
        return True

    def read_log(self, run_id: str, offset: int = 0) -> tuple[str, int]:
        """Read run_stdout.log from S3 starting at byte offset."""
        s3 = self._client()
        key = f"{self._prefix}/{run_id}/instances/logs/run_stdout.log"
        try:
            resp = s3.get_object(
                Bucket=self._bucket,
                Key=key,
                Range=f"bytes={offset}-",
            )
            body = resp["Body"].read().decode("utf-8", errors="replace")
            new_offset = offset + len(body.encode("utf-8"))
            logger.debug("S3 read_log: key={} offset={}->{} bytes={}", key, offset, new_offset, len(body))
            return body, new_offset
        except s3.exceptions.NoSuchKey:
            logger.debug("S3 read_log: key={} not found (run may not have started yet)", key)
            return "", offset
        except Exception as exc:
            # Range not satisfiable = no new content
            if "InvalidRange" in str(exc) or "416" in str(exc):
                return "", offset
            self._classify_error(exc, "read_log", key)
            return "", offset


# ---------------------------------------------------------------------------
# Factory — select backend via IOF_STORAGE env var
# ---------------------------------------------------------------------------

_storage_instance: StorageBackend | None = None


def get_storage() -> StorageBackend:
    """Get the configured storage backend. Cached after first call."""
    global _storage_instance
    if _storage_instance is not None:
        return _storage_instance

    backend = os.getenv("IOF_STORAGE", "none").lower()

    if backend == "s3":
        try:
            _storage_instance = S3Storage()
            logger.info(
                "Storage backend: S3 (bucket={} prefix={} region={})",
                _storage_instance._bucket,
                _storage_instance._prefix,
                _storage_instance._region or "default",
            )
        except Exception as exc:
            logger.error("Failed to initialize S3 storage: {} — falling back to NoopStorage", exc)
            _storage_instance = NoopStorage()
    else:
        _storage_instance = NoopStorage()
        if backend != "none":
            logger.warning("Unknown IOF_STORAGE value '{}' — falling back to NoopStorage", backend)

    return _storage_instance
