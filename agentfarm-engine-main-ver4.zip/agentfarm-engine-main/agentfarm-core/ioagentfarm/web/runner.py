"""Pluggable run backend — abstracts how workflow runs are executed.

Three operations:
    spawn  — start a workflow run
    status — is the process alive? (running / finished / unknown)
    logs   — async iterator of log lines for SSE streaming

Three backends:
    LocalRunner   — subprocess.Popen on the same machine (dev/single-node)
    K8sRunner     — Kubernetes Job, one pod per run (enterprise/horizontal)
    SandboxRunner — OpenShell sandbox, one per workflow (secure isolation)

Selected via IOF_RUNNER env var: "local" (default), "k8s", or "sandbox".
"""

from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import AsyncIterator

from loguru import logger


class RunnerBackend(ABC):
    """Protocol for workflow run execution backends."""

    @abstractmethod
    def spawn(
        self,
        *,
        run_id: str,
        cmd: list[str],
        env: dict[str, str],
        cwd: str,
        log_dir: Path,
        workflow_name: str | None = None,
    ) -> None:
        """Start the run process. Fire-and-forget.

        Args:
            workflow_name: Optional workflow name for sandbox isolation.
                           SandboxRunner uses this to resolve the correct
                           per-workflow sandbox.
        """
        ...

    @abstractmethod
    def status(self, run_id: str, log_dir: Path) -> str:
        """Check if the run process is alive: running | finished | unknown."""
        ...

    @abstractmethod
    async def log_lines(self, run_id: str, log_dir: Path) -> AsyncIterator[str]:
        """Async iterator yielding new log content as it appears."""
        ...


# ---------------------------------------------------------------------------
# LocalRunner — subprocess on the same machine
# ---------------------------------------------------------------------------

class LocalRunner(RunnerBackend):
    """Run workflows as detached local subprocesses.

    Good for: dev, single-node deployment, testing.
    """

    def spawn(self, *, run_id, cmd, env, cwd, log_dir, workflow_name=None):
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "run_stdout.log"
        pid_file = log_dir / "run.pid"

        with open(log_file, "a", encoding="utf-8") as f:
            if sys.platform == "win32":
                proc = subprocess.Popen(
                    cmd, env=env, cwd=cwd,
                    stdout=f, stderr=subprocess.STDOUT,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                )
            else:
                proc = subprocess.Popen(
                    cmd, env=env, cwd=cwd,
                    stdout=f, stderr=subprocess.STDOUT,
                    start_new_session=True,
                )

        pid_file.write_text(str(proc.pid), encoding="utf-8")
        logger.info("LocalRunner spawned: run_id={} pid={}", run_id, proc.pid)

    def status(self, run_id, log_dir):
        pid_file = log_dir / "run.pid"
        if not pid_file.exists():
            return "unknown"
        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
        except (ValueError, OSError):
            return "unknown"
        # NEVER `os.kill(pid, 0)` here. On Windows that is not a probe:
        # CPython maps any signal other than CTRL_C/CTRL_BREAK to
        # TerminateProcess, so "is the driver alive?" - asked by the status
        # route and by every SSE stream - KILLED the driver it asked about.
        # The supervisor's liveness check already knows this; share it.
        from ioagentfarm.engine.supervisor import _pid_alive
        return "running" if _pid_alive(pid) else "finished"

    async def log_lines(self, run_id, log_dir):
        log_path = log_dir / "run_stdout.log"
        pos = 0
        idle = 0.0

        # Wait for log file to appear
        while not log_path.exists():
            idle += 0.5
            if idle > 30:
                yield "[error] Log file not created — run may have failed to start\n"
                return
            await asyncio.sleep(0.5)

        idle = 0.0
        while True:
            try:
                size = log_path.stat().st_size
            except OSError:
                break

            if size > pos:
                with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                    f.seek(pos)
                    text = f.read()
                    pos = f.tell()
                if text.strip():
                    yield text
                idle = 0.0
            else:
                idle += 0.5
                if idle >= 300:
                    return

            await asyncio.sleep(0.5)


# ---------------------------------------------------------------------------
# K8sRunner — Kubernetes Job, one pod per run
# ---------------------------------------------------------------------------

class K8sRunner(RunnerBackend):
    """Run workflows as Kubernetes Jobs — one pod per run.

    Good for: enterprise, horizontal scaling, fault tolerance.

    Requires: ``pip install kubernetes`` and a valid kubeconfig or
    in-cluster service account.

    Config via env vars:
        IOF_K8S_NAMESPACE  — namespace for Jobs (default: "ioagentfarm")
        IOF_K8S_IMAGE      — container image (e.g. "myregistry/ioagentfarm:latest")
        IOF_K8S_SERVICE_ACCOUNT — service account for pods (optional)
    """

    def __init__(self):
        self._namespace = os.getenv("IOF_K8S_NAMESPACE", "ioagentfarm")
        self._image = os.getenv("IOF_K8S_IMAGE", "")
        self._service_account = os.getenv("IOF_K8S_SERVICE_ACCOUNT", "")

    def spawn(self, *, run_id, cmd, env, cwd, log_dir, workflow_name=None):
        from kubernetes import client, config as k8s_config

        try:
            k8s_config.load_incluster_config()
        except k8s_config.ConfigException:
            k8s_config.load_kube_config()

        if not self._image:
            raise RuntimeError("IOF_K8S_IMAGE env var required for K8s runner")

        # Convert env dict to k8s env vars
        k8s_env = [client.V1EnvVar(name=k, value=v) for k, v in env.items()]

        container = client.V1Container(
            name="run",
            image=self._image,
            command=cmd,
            env=k8s_env,
            working_dir=cwd,
        )

        pod_spec = client.V1PodSpec(
            containers=[container],
            restart_policy="Never",
        )
        if self._service_account:
            pod_spec.service_account_name = self._service_account

        job_name = f"iof-run-{run_id[:40]}".lower().replace("_", "-")

        job = client.V1Job(
            api_version="batch/v1",
            kind="Job",
            metadata=client.V1ObjectMeta(
                name=job_name,
                namespace=self._namespace,
                labels={
                    "app": "ioagentfarm",
                    "run-id": run_id,
                },
            ),
            spec=client.V1JobSpec(
                template=client.V1PodTemplateSpec(
                    metadata=client.V1ObjectMeta(
                        labels={
                            "app": "ioagentfarm",
                            "run-id": run_id,
                        },
                    ),
                    spec=pod_spec,
                ),
                backoff_limit=0,
                ttl_seconds_after_finished=3600,
            ),
        )

        batch_api = client.BatchV1Api()
        batch_api.create_namespaced_job(namespace=self._namespace, body=job)

        # Write job name for status/log lookups
        log_dir.mkdir(parents=True, exist_ok=True)
        (log_dir / "k8s_job.txt").write_text(job_name, encoding="utf-8")

        logger.info("K8sRunner spawned: run_id={} job={}", run_id, job_name)

    def status(self, run_id, log_dir):
        from kubernetes import client, config as k8s_config

        job_file = log_dir / "k8s_job.txt"
        if not job_file.exists():
            return "unknown"

        job_name = job_file.read_text(encoding="utf-8").strip()

        try:
            k8s_config.load_incluster_config()
        except Exception:
            k8s_config.load_kube_config()

        batch_api = client.BatchV1Api()
        try:
            job = batch_api.read_namespaced_job(name=job_name, namespace=self._namespace)
        except client.exceptions.ApiException:
            return "unknown"

        if job.status.succeeded and job.status.succeeded > 0:
            return "finished"
        if job.status.failed and job.status.failed > 0:
            return "finished"
        return "running"

    async def log_lines(self, run_id, log_dir):
        from kubernetes import client, config as k8s_config, watch

        job_file = log_dir / "k8s_job.txt"
        if not job_file.exists():
            yield "[error] No K8s job found for this run\n"
            return

        job_name = job_file.read_text(encoding="utf-8").strip()

        try:
            k8s_config.load_incluster_config()
        except Exception:
            k8s_config.load_kube_config()

        core_api = client.CoreV1Api()

        # Wait for pod to be running
        for _ in range(60):
            pods = core_api.list_namespaced_pod(
                namespace=self._namespace,
                label_selector=f"job-name={job_name}",
            )
            if pods.items:
                pod = pods.items[0]
                if pod.status.phase in ("Running", "Succeeded", "Failed"):
                    break
            await asyncio.sleep(1)
        else:
            yield "[error] Pod did not start within 60s\n"
            return

        pod_name = pods.items[0].metadata.name

        # Stream logs via K8s API (run in thread to avoid blocking)
        def _read_logs():
            return core_api.read_namespaced_pod_log(
                name=pod_name,
                namespace=self._namespace,
                follow=True,
                _preload_content=False,
            )

        log_stream = await asyncio.to_thread(_read_logs)

        try:
            for chunk in log_stream:
                text = chunk.decode("utf-8", errors="replace") if isinstance(chunk, bytes) else chunk
                if text.strip():
                    yield text
                await asyncio.sleep(0)  # yield to event loop
        finally:
            log_stream.close()


# ---------------------------------------------------------------------------
# Factory — select backend via IOF_RUNNER env var
# ---------------------------------------------------------------------------

_runner_instance: RunnerBackend | None = None


class SandboxRunner(LocalRunner):
    """Run workflows inside OpenShell sandboxes — one sandbox per workflow.

    Extends LocalRunner: the subprocess is spawned locally, but the command
    is wrapped with ``openshell sandbox exec <name> --`` so it executes
    inside the sandbox.  stdout/pid/log handling is inherited from LocalRunner.

    Security:
    - Environment filtered to whitelist (no credential leakage)
    - Anti-spoof token set (prevents IOF_SANDBOX_ID forgery)
    """

    def spawn(self, *, run_id, cmd, env, cwd, log_dir, workflow_name=None):
        from ioagentfarm.engine.sandbox import sandbox_wrap_cmd, should_sandbox, make_sandbox_env
        from ioagentfarm.engine.sandbox_manager import get_sandbox_manager

        # Verify sandbox exists before wrapping (prevents cryptic openshell errors)
        if should_sandbox() and workflow_name:
            mgr = get_sandbox_manager()
            if mgr:
                sb_name = mgr.resolve_sandbox_name(workflow_name)
                if sb_name:
                    from ioagentfarm.engine.sandbox import get_sandbox_client
                    client = get_sandbox_client()
                    if not client.health_check(sb_name):
                        logger.warning(
                            "Sandbox '{}' health check failed — recreating",
                            sb_name,
                        )
                        # Trigger recreation on next get_or_create
                        from ioagentfarm.engine.workflow_loader import WorkflowLoader
                        try:
                            wf = WorkflowLoader().load(workflow_name)
                            if wf.sandbox:
                                mgr.get_or_create(workflow_name, wf.sandbox)
                        except Exception:
                            pass

        wrapped = sandbox_wrap_cmd(cmd, workflow_name=workflow_name)
        if should_sandbox():
            env = make_sandbox_env(env)
        super().spawn(run_id=run_id, cmd=wrapped, env=env, cwd=cwd, log_dir=log_dir)


def get_runner() -> RunnerBackend:
    """Get the configured runner backend. Cached after first call."""
    global _runner_instance
    if _runner_instance is not None:
        return _runner_instance

    backend = os.getenv("IOF_RUNNER", "local").lower()

    if backend == "k8s":
        _runner_instance = K8sRunner()
        logger.info("Using K8s runner (namespace={})", _runner_instance._namespace)
    elif backend == "sandbox":
        _runner_instance = SandboxRunner()
        logger.info("Using sandbox runner (OpenShell)")
    else:
        _runner_instance = LocalRunner()
        logger.info("Using local runner (subprocess)")

    return _runner_instance
