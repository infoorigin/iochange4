"""Server-Sent Events (SSE) streaming — auto-selects source.

If the run's process is local (same pod) → tail the local log file.
If cloud storage is enabled and log isn't local → poll S3 for updates.

Event types:
    output — new text from the run process
    done   — stream finished
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

from fastapi.responses import StreamingResponse

from ioagentfarm.web.runner import get_runner


async def _local_tail(run_id: str, log_dir: Path):
    """Tail the local log file — real-time, sub-second latency.

    Ends when the driver process is gone and nothing new has arrived for
    two seconds. It used to end only after 300s of silence, so every client
    of a finished run held its stream open for five minutes.
    """
    log_path = log_dir / "run_stdout.log"
    pos = 0
    idle = 0.0
    runner = get_runner()

    while not log_path.exists():
        idle += 0.5
        if idle > 30:
            yield _sse("error", {"message": "Log file not created"})
            return
        await asyncio.sleep(0.5)

    idle = 0.0
    while True:
        try:
            size = log_path.stat().st_size
        except OSError:
            break

        if size > pos:
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                f.seek(pos)
                text = f.read()
                pos = f.tell()
            if text.strip():
                yield _sse("output", {"run_id": run_id, "text": text})
            idle = 0.0
        else:
            idle += 0.5
            if idle >= 300:
                break
            if idle >= 2.0 and runner.status(run_id, log_dir) == "finished":
                break

        await asyncio.sleep(0.5)

    yield _sse("done", {"run_id": run_id, "reason": "finished"})


async def _cloud_poll(run_id: str):
    """Poll cloud storage for log updates — step-boundary granularity."""
    from ioagentfarm.web.storage import get_storage

    storage = get_storage()
    offset = 0
    idle = 0.0
    # ONE store for the life of the stream, not one per 2s tick: each
    # construction re-checked the whole engine schema against the database.
    store = None

    while True:
        text, new_offset = storage.read_log(run_id, offset)

        if text.strip():
            yield _sse("output", {"run_id": run_id, "text": text})
            offset = new_offset
            idle = 0.0
        else:
            idle += 2.0
            if idle >= 300:
                break

        # Check DB for terminal state
        try:
            if store is None:
                from ioagentfarm.engine.store import Store
                from ioagentfarm.engine.db import make_adapter
                import os
                root = Path(os.getenv("IOF_ROOT", ".iof")).resolve()
                db_url = os.getenv("IOF_DATABASE_URL", "")
                if not db_url:
                    db_url = f"sqlite:///{root / 'state.db'}"
                store = Store(make_adapter(db_url))
                store.init()
            run = store.get_run(run_id)
            if run and run["status"] in ("done", "failed"):
                # One final read to catch any last push
                text, _ = storage.read_log(run_id, offset)
                if text.strip():
                    yield _sse("output", {"run_id": run_id, "text": text})
                yield _sse("done", {"run_id": run_id, "reason": run["status"]})
                return
        except Exception:
            pass

        await asyncio.sleep(2.0)

    yield _sse("done", {"run_id": run_id, "reason": "idle_timeout"})


async def _event_generator(run_id: str, log_dir: Path):
    """Route to local tail or cloud poll based on what's available."""
    from ioagentfarm.web.storage import get_storage

    runner = get_runner()
    local_status = runner.status(run_id, log_dir)
    log_file = log_dir / "run_stdout.log"

    # If process is running locally or log file exists locally → tail it
    if local_status == "running" or log_file.exists():
        async for event in _local_tail(run_id, log_dir):
            yield event
        return

    # If cloud storage is enabled → poll S3
    storage = get_storage()
    if storage.is_cloud:
        async for event in _cloud_poll(run_id):
            yield event
        return

    # Nothing available
    yield _sse("error", {"message": f"No logs available for {run_id}"})


def _sse(event: str, data: dict) -> str:
    payload = json.dumps(data, ensure_ascii=False)
    return f"event: {event}\ndata: {payload}\n\n"


def create_sse_response(run_id: str, log_dir: Path) -> StreamingResponse:
    return StreamingResponse(
        _event_generator(run_id, log_dir),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
