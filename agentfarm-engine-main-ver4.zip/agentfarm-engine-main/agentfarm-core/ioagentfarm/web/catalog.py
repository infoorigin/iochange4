"""Engine catalog API - WHAT CONTENT IS INSTALLED HERE, read from the packs.

The One Truth model (docs/one-truth-content-model.md s3.2 / s4.3): the
installed pack is the only source of agents, skills and workflows, and the
Studio - whose API pod has no filesystem - reads base content FROM THE
ENGINE, the same engine-proxied pattern already used for agent memory and
the workflow-catalog sync. So the Studio shows what this environment is
running, and every item says which distribution, version and commit it came
from.

    GET /api/catalog                    names + the boot stamp (cheap)
    GET /api/catalog/agents             every pack agent: role, name, pack, stamp, skills, has_card
    GET /api/catalog/agents/{role}      the pack TEMPLATE's files ({rel: text}) + stamp
    GET /api/catalog/skills             every pack skill: name, source, pack, stamp
    GET /api/catalog/skills/{name}      the first pack source's files (+ ?role= for an agent-local one)
    GET /api/catalog/workflows          every pack workflow: name, solution, steps, stamp
    GET /api/catalog/workflows/{name}   workflow.yaml + every file under the pack dir + stamp

Three rules, each load-bearing:

* **Resolved from the INSTALLED PACKS on this box - never a database.** The
  registry (``ioagentfarm.packs.load_registry``) is walked directly, in pack
  order (core first, then entry-point packs by name - the same first-wins
  order ``_role_workspace`` / ``_workflow_dir`` resolve with). Nothing here
  consults ``studio_*`` tables, the tenant's materialized agent homes, or the
  pushed/staged trees under ``<IOF_ROOT>/workspaces/<code>/`` - those are
  caches and unpromoted content, and this endpoint's whole point is to show
  the base the engine runs. A Studio-authored / imported / unpromoted agent
  is therefore NOT in this catalog; the 404 says so.
* **Every item carries the stamp of the distribution it came from.** A pack
  root path is mapped back to a :class:`~ioagentfarm.engine.content.Stamp`
  by matching ``Stamp.root`` as a path prefix (longest match; when several
  wheels share one site-packages root the top-level import package is
  resolved to its distribution). Unmatched roots fall back to the pack-only
  ``stamp_line()`` - honest about "one of these", never blank.
* **Loud on failure.** An unexpected error is a 500 whose detail names the
  exception; an empty list is never returned to mask a problem, because a
  Studio showing "no agents" is exactly the silent failure the model exists
  to remove.

Workspace-scoped like the rest of the engine: the pod serves ONE workspace
(``app.state.workspace_code``, set by ``serve``'s lifespan); a request naming
another - ``X-Workspace-Id`` header or ``?workspace=`` - is refused with 409
(the same handshake ``POST /api/chat/*`` performs), and a process with no
workspace resolved answers 503.
"""

from __future__ import annotations

import functools
import inspect
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable

import yaml
from fastapi import APIRouter, HTTPException, Request
from loguru import logger

from ioagentfarm import packs as _packs
from ioagentfarm.engine.content import Stamp, stamp_dict, stamp_line, stamps

router = APIRouter(prefix="/api/catalog", tags=["catalog"])

#: Suffixes never read as text. ``.pyc``/``.so`` are the same list
#: ``ensure_agent_workspace`` skips when it seeds a home; the rest are the
#: obvious binary assets a skill may carry (a template deck, a font).
_BINARY_SUFFIXES = frozenset({
    ".pyc", ".pyo", ".exe", ".dll", ".so", ".dylib",
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".pdf",
    ".zip", ".gz", ".tar", ".pptx", ".xlsx", ".docx",
    ".woff", ".woff2", ".ttf", ".otf", ".db", ".sqlite", ".parquet",
})
_SKIP_PARTS = frozenset({"__pycache__", "sessions"})

_ROLE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")
_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")


# ---------------------------------------------------------------------------
# workspace + failure discipline
# ---------------------------------------------------------------------------

def workspace_for(request: Request) -> str:
    """The workspace this engine serves, refusing a request that names another.

    ``app.state.workspace_code`` is set by ``serve``'s lifespan (fail-fast:
    serve does not start without one); outside serve - a test client, an
    embedded app - the selected workspace from the environment is used. A
    caller's ``X-Workspace-Id`` / ``?workspace=`` that disagrees is a 409:
    the catalog answers for ONE workspace's installed content, and pointing
    another tenant's Studio at this engine must not silently show it this
    tenant's packs as its own.
    """
    ws = getattr(request.app.state, "workspace_code", None)
    if not ws:
        from ioagentfarm.engine.workspaces import maybe_workspace_code
        ws = maybe_workspace_code()
    if not ws:
        raise HTTPException(status_code=503,
                            detail="serve has no workspace resolved")
    asked = (request.headers.get("X-Workspace-Id")
             or request.query_params.get("workspace") or "").strip()
    if asked and asked != ws:
        raise HTTPException(
            status_code=409,
            detail=(f"this engine serves workspace '{ws}'; the request names "
                    f"'{asked}'. Point the caller at the engine for its "
                    f"workspace."))
    return ws


def _loud(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Unexpected error -> 500 naming it. Never a bare 'Internal Server Error',
    never a quiet empty list.

    Shape-preserving: a SYNC handler stays sync. These routes read the
    filesystem, so they are declared `def` on purpose - Starlette then runs
    them in its threadpool and concurrent catalog reads actually overlap.
    Wrapping one in an async wrapper would put the blocking read back on the
    event loop and undo that silently, which is the failure this branch of
    the function exists to prevent.
    """
    def _fail(exc: Exception) -> HTTPException:
        logger.exception("catalog: {} failed", fn.__name__)
        return HTTPException(
            status_code=500,
            detail=f"catalog {fn.__name__} failed: "
                   f"{type(exc).__name__}: {exc}")

    if inspect.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def awrapped(*args: Any, **kwargs: Any) -> Any:
            try:
                return await fn(*args, **kwargs)
            except HTTPException:
                raise
            except Exception as exc:  # noqa: BLE001 - re-raised WITH detail
                raise _fail(exc) from exc
        return awrapped

    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        try:
            return fn(*args, **kwargs)
        except HTTPException:
            raise
        except Exception as exc:  # noqa: BLE001 - re-raised as a 500 WITH detail
            raise _fail(exc) from exc
    return wrapped


# ---------------------------------------------------------------------------
# stamps - which distribution a pack root belongs to
# ---------------------------------------------------------------------------

def _norm(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name or "").lower()


@lru_cache(maxsize=1)
def _dists_by_top_level() -> dict[str, list[str]]:
    """``{import package: [distribution, ...]}`` for everything installed.

    Walks every dist-info once (measured seconds cold in a full venv - see
    ``content._pack_distributions``), hence cached for the process. Needed
    ONLY when several wheels share one site-packages root, i.e. on a pod;
    an editable checkout resolves by prefix alone.
    """
    try:
        from importlib.metadata import packages_distributions
        return {k: list(v) for k, v in packages_distributions().items()}
    except Exception:  # noqa: BLE001 - a missing map degrades to the fallback line
        logger.debug("catalog: packages_distributions() unavailable", exc_info=True)
        return {}


def stamp_for_path(path: Any, items: list[Stamp] | None = None) -> Stamp | None:
    """The Stamp whose ``root`` contains *path* - or ``None`` when no
    installed distribution claims it.

    Longest ``root`` prefix wins (a checkout's root is its project dir; a
    wheel's is its site-packages dir, so a checkout nested anywhere under a
    site dir still wins by being deeper). When several stamps tie - every
    wheel in one site-packages shares the same root - the top-level import
    package under that root is resolved to its distribution.
    """
    items = stamps() if items is None else items
    try:
        p = Path(str(path)).resolve()
    except (OSError, RuntimeError):
        return None
    ties: list[tuple[Stamp, Path]] = []
    best = -1
    for s in items:
        if not s.root:
            continue
        try:
            r = Path(s.root).resolve()
        except (OSError, RuntimeError):
            continue
        if p != r and r not in p.parents:
            continue
        n = len(r.parts)
        if n > best:
            best, ties = n, [(s, r)]
        elif n == best:
            ties.append((s, r))
    if not ties:
        return None
    if len(ties) == 1:
        return ties[0][0]
    root = ties[0][1]
    try:
        top = p.relative_to(root).parts[0]
    except (ValueError, IndexError):
        return None
    dists = {_norm(d) for d in _dists_by_top_level().get(top, [])}
    for s, _ in ties:
        if _norm(s.dist) in dists:
            return s
    return None


def render_stamp(path: Any, items: list[Stamp]) -> str:
    """``Stamp.render()`` for the distribution *path* belongs to, else the
    pack-only ``stamp_line()`` (never an empty string)."""
    s = stamp_for_path(path, items)
    if s is not None:
        return s.render()
    return stamp_line(items, packs_only=True)


# ---------------------------------------------------------------------------
# reading pack trees
# ---------------------------------------------------------------------------

def _as_path(t: Any) -> Path:
    """A ``Traversable`` handed out by ``importlib.resources`` for an on-disk
    package IS a ``pathlib.Path`` (a ``MultiplexedPath`` root yields real
    ``Path`` children on ``joinpath``/``iterdir``); packs on disk are the
    contract every reader here relies on (``rglob``, ``relative_to``). A
    ``MultiplexedPath`` ROOT (a namespace package such as core's
    ``ioagentfarm.agents``) resolves to its first backing directory."""
    if isinstance(t, Path):
        return t
    backing = getattr(t, "_paths", None)
    if backing:
        return Path(str(backing[0]))
    return Path(str(t))


def _root_paths(t: Any) -> list[Path]:
    """Every on-disk directory behind a pack root (>1 only for a
    ``MultiplexedPath``)."""
    backing = getattr(t, "_paths", None)
    if backing:
        return [Path(str(b)) for b in backing]
    return [_as_path(t)]


def _iterdir(root: Any) -> list[Any]:
    try:
        return sorted(root.iterdir(), key=lambda e: e.name)
    except (OSError, TypeError, NotADirectoryError):
        return []


def read_tree(root: Path) -> dict[str, str]:
    """``{rel_posix: text}`` for every text file under *root*.

    Binary files (by suffix, or anything that is not UTF-8) are SKIPPED, as
    are ``__pycache__`` and ``sessions/`` - never content. Nothing else is
    excluded: a pack template's ``memory/MEMORY.md`` is a seed the pack ships
    and is shown as such.
    """
    files: dict[str, str] = {}
    root = _as_path(root)
    for f in sorted(root.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(root)
        if any(part in _SKIP_PARTS for part in rel.parts):
            continue
        if f.suffix.lower() in _BINARY_SUFFIXES:
            continue
        try:
            files[rel.as_posix()] = f.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue   # binary without a telling suffix
    return files


def _skill_names_in(skills_dir: Any) -> list[str]:
    out: list[str] = []
    for entry in _iterdir(skills_dir):
        try:
            if (entry / "SKILL.md").is_file():
                out.append(entry.name)
        except (OSError, TypeError, NotADirectoryError):
            continue
    return out


# ---------------------------------------------------------------------------
# enumeration - the installed packs, in registry order
# ---------------------------------------------------------------------------

def _declared_skill_names(ws: Any) -> list[str]:
    """The names an agent's ``skills.yaml`` DECLARES - what `assign-skill`
    writes. A declared skill is held by the agent though its files live at
    pack level, so the catalog has to count it or the assignment is
    invisible over HTTP (walked 2026-09-02: `assign-skill` succeeded,
    `list-skills --role` listed it, `/api/catalog/agents` did not)."""
    try:
        f = ws / "skills.yaml"
        if not f.is_file():
            return []
        from ioagentfarm.engine.workspaces import parse_declared_skills
        return parse_declared_skills(f.read_text(encoding="utf-8"),
                                     where=str(f))
    except Exception:  # noqa: BLE001 - a bad declaration is not a 500
        return []


def _agent_skill_names(ws: Any) -> list[str]:
    """Agent-local skill directories plus the names its skills.yaml declares."""
    return sorted(set(_skill_names_in(ws / "skills")) | set(_declared_skill_names(ws)))


def pack_agents() -> list[dict[str, Any]]:
    """``[{role, pack, ws}]`` for every ``<role>/workspace/SOUL.md`` a pack
    ships - first pack wins a role, matching ``_role_workspace``. Sorted by
    role. ``_``/``.``-prefixed entries are inject/metadata dirs, not agents."""
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for p in _packs.load_registry().packs:
        if p.agents is None:
            continue
        for entry in _iterdir(p.agents):
            if entry.name.startswith(("_", ".")) or entry.name in seen:
                continue
            ws = entry / "workspace"
            try:
                if not (ws / "SOUL.md").is_file():
                    continue
            except (OSError, TypeError, NotADirectoryError):
                continue
            seen.add(entry.name)
            out.append({"role": entry.name, "pack": p.name, "ws": _as_path(ws)})
    out.sort(key=lambda a: a["role"])
    return out


def pack_skills() -> list[dict[str, Any]]:
    """``[{name, source, pack, dir}]`` - every pack-level skill root first
    (``Pack.skills`` and the legacy ``<agents>/_common/skills``), source
    ``'pack'``; then every pack agent template's ``skills/``, source
    ``'agent-local:<role>'``. Every occurrence is listed - an agent-local copy
    shadowing a shared name is the designed override tier, and the Studio
    needs to see both."""
    out: list[dict[str, Any]] = []
    for p in _packs.load_registry().packs:
        roots: list[Any] = []
        if p.skills is not None:
            roots.append(p.skills)
        if p.agents is not None:
            common = p.agents / "_common" / "skills"
            try:
                if common.is_dir():
                    roots.append(common)
            except (OSError, TypeError, NotADirectoryError):
                pass
        for root in roots:
            for entry in _iterdir(root):
                try:
                    if not (entry / "SKILL.md").is_file():
                        continue
                except (OSError, TypeError, NotADirectoryError):
                    continue
                out.append({"name": entry.name, "source": "pack",
                            "pack": p.name, "dir": _as_path(entry)})
    for a in pack_agents():
        sk = a["ws"] / "skills"
        for name in _skill_names_in(sk):
            out.append({"name": name, "source": f"agent-local:{a['role']}",
                        "pack": a["pack"], "dir": sk / name})
    return out


def _workflow_pack(wf_dir: Path) -> Any:
    """The Pack whose ``workflows`` root holds *wf_dir*, else ``None``."""
    parent = _as_path(wf_dir).resolve().parent
    for p in _packs.load_registry().packs:
        if p.workflows is None:
            continue
        for root in _root_paths(p.workflows):
            try:
                if root.resolve() == parent:
                    return p
            except (OSError, RuntimeError):
                continue
    return None


def pack_workflows(workspace: str) -> list[dict[str, Any]]:
    """``[{name, solution, pack, dir}]`` - the loader's listing restricted to
    names an installed pack provides (``_workflow_dir(name) is not None``);
    an unpromoted staged workflow the loader would still list is not the
    pack's and is not here."""
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    loader = WorkflowLoader()
    out: list[dict[str, Any]] = []
    for name in loader.list_workflows(workspace):
        d = loader._workflow_dir(name)
        if d is None:
            continue
        p = _workflow_pack(d)
        out.append({
            "name": name,
            "solution": (p.solution or p.name) if p is not None else None,
            "pack": p.name if p is not None else None,
            "dir": _as_path(d),
        })
    return out


def _step_count(wf_dir: Path) -> int | None:
    try:
        data = yaml.safe_load((wf_dir / "workflow.yaml").read_text(encoding="utf-8")) or {}
        return len(data.get("steps") or []) if isinstance(data, dict) else None
    except Exception:  # noqa: BLE001 - a malformed yaml is listed, not hidden
        return None


# ---------------------------------------------------------------------------
# routes
# ---------------------------------------------------------------------------

@router.get("")
@_loud
def catalog_index(request: Request):
    ws = workspace_for(request)
    return {
        "workspace": ws,
        "content": stamp_dict(),
        "agents": [a["role"] for a in pack_agents()],
        "skills": sorted({s["name"] for s in pack_skills()}),
        "workflows": [w["name"] for w in pack_workflows(ws)],
    }


@router.get("/agents")
@_loud
def catalog_agents(request: Request):
    from ioagentfarm.engine.workspaces import _soul_display_name
    ws = workspace_for(request)
    items = stamps()
    out = []
    for a in pack_agents():
        soul = a["ws"] / "SOUL.md"
        try:
            name = _soul_display_name(soul.read_text(encoding="utf-8")) or a["role"]
        except (OSError, UnicodeDecodeError):
            name = a["role"]
        out.append({
            "role": a["role"],
            "name": name,
            "pack": a["pack"],
            "stamp": render_stamp(a["ws"], items),
            "skills": _agent_skill_names(a["ws"]),
            "declared": _declared_skill_names(a["ws"]),
            "has_card": (a["ws"] / "a2a-card.yaml").is_file(),
        })
    return {"workspace": ws, "agents": out}


@router.get("/agents/{role}")
@_loud
def catalog_agent(role: str, request: Request):
    from ioagentfarm.engine.workspaces import canonical_role
    ws = workspace_for(request)
    if not _ROLE_RE.match(role):
        raise HTTPException(status_code=400, detail="bad role")
    role = canonical_role(role)
    hit = next((a for a in pack_agents() if a["role"] == role), None)
    if hit is None:
        raise HTTPException(
            status_code=404,
            detail=(f"no installed pack on this engine provides an agent "
                    f"named {role!r}. The pack catalog lists only agents an "
                    f"installed distribution ships; a Studio-authored, "
                    f"imported or otherwise unpromoted agent is not in it "
                    f"until it is promoted into a pack."))
    return {
        "workspace": ws,
        "role": role,
        "pack": hit["pack"],
        "files": read_tree(hit["ws"]),
        "stamp": render_stamp(hit["ws"], stamps()),
    }


@router.get("/skills")
@_loud
def catalog_skills(request: Request):
    ws = workspace_for(request)
    items = stamps()
    return {"workspace": ws, "skills": [
        {"name": s["name"], "source": s["source"], "pack": s["pack"],
         "stamp": render_stamp(s["dir"], items)}
        for s in pack_skills()]}


@router.get("/skills/{name}")
@_loud
def catalog_skill(name: str, request: Request, role: str | None = None):
    ws = workspace_for(request)
    if not _NAME_RE.match(name):
        raise HTTPException(status_code=400, detail="bad skill name")
    if role is not None and not _ROLE_RE.match(role):
        raise HTTPException(status_code=400, detail="bad role")
    all_ = [s for s in pack_skills() if s["name"] == name]
    if role:
        from ioagentfarm.engine.workspaces import canonical_role
        wanted = f"agent-local:{canonical_role(role)}"
        hits = [s for s in all_ if s["source"] == wanted]
        if not hits:
            # Not in the agent's own skills/ - but DECLARED by it? Then the
            # pack copy is what the agent holds, and the answer says so.
            agent = next((a for a in pack_agents()
                          if a["role"] == canonical_role(role)), None)
            if agent is not None and name in _declared_skill_names(agent["ws"]):
                hits = [dict(s, source=f"declared-by:{canonical_role(role)} "
                                       f"({s['source']})")
                        for s in all_]
    else:
        hits = all_          # pack sources come first in enumeration order
    if not hits:
        where = f" in agent {role!r}'s template" if role else ""
        raise HTTPException(
            status_code=404,
            detail=(f"no installed pack on this engine provides a skill named "
                    f"{name!r}{where}. Skills held only as a tenant/Studio row "
                    f"are not in the pack catalog."))
    hit = hits[0]
    return {
        "workspace": ws,
        "name": name,
        "source": hit["source"],
        "pack": hit["pack"],
        "files": read_tree(hit["dir"]),
        "stamp": render_stamp(hit["dir"], stamps()),
        "also": [{"source": s["source"], "pack": s["pack"]} for s in all_[1:]]
                if not role else [],
    }


@router.get("/workflows")
@_loud
def catalog_workflows(request: Request):
    ws = workspace_for(request)
    items = stamps()
    return {"workspace": ws, "workflows": [
        {"name": w["name"], "solution": w["solution"], "pack": w["pack"],
         "steps": _step_count(w["dir"]),
         "stamp": render_stamp(w["dir"], items)}
        for w in pack_workflows(ws)]}


@router.get("/workflows/{name}")
@_loud
def catalog_workflow(name: str, request: Request):
    ws = workspace_for(request)
    if not _NAME_RE.match(name):
        raise HTTPException(status_code=400, detail="bad workflow name")
    hit = next((w for w in pack_workflows(ws) if w["name"] == name), None)
    if hit is None:
        raise HTTPException(
            status_code=404,
            detail=(f"no installed pack on this engine provides a workflow "
                    f"named {name!r}. An unpromoted (Studio-authored / staged) "
                    f"workflow is not in the pack catalog."))
    d = hit["dir"]
    return {
        "workspace": ws,
        "name": name,
        "solution": hit["solution"],
        "pack": hit["pack"],
        "yaml": (d / "workflow.yaml").read_text(encoding="utf-8"),
        "files": read_tree(d),
        "stamp": render_stamp(d, stamps()),
    }
