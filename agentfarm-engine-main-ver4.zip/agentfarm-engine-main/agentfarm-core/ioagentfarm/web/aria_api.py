"""ARIA business-rules CRUD API.

Mounted at /api/aria and /api/vendors in app.py:
  app.include_router(aria_router)

Endpoints
---------
GET/POST/PUT/DELETE /api/aria/rules
GET/POST/PUT/DELETE /api/aria/clauses
GET/POST/PUT/DELETE /api/aria/checklists
GET/POST/PUT/DELETE /api/aria/negotiation-terms
GET/POST/PUT/DELETE /api/vendors/fiscal-calendars
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel

aria_router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _store(request: Request):
    return request.app.state.store


def _404(detail: str):
    raise HTTPException(status_code=404, detail=detail)


# ---------------------------------------------------------------------------
# aria_rules — scalar thresholds
# ---------------------------------------------------------------------------

class AriaRuleIn(BaseModel):
    domain: str
    rule_key: str
    rule_name: str
    value_type: str
    value: str
    applies_to: Optional[str] = None
    description: Optional[str] = None


class AriaRuleUpdate(BaseModel):
    rule_name: Optional[str] = None
    value_type: Optional[str] = None
    value: Optional[str] = None
    applies_to: Optional[str] = None
    description: Optional[str] = None


@aria_router.get("/api/aria/rules")
def list_aria_rules(request: Request):
    store = _store(request)
    with store._tx() as cursor:
        cursor.execute(
            "SELECT id, domain, rule_key, rule_name, value_type, value, "
            "applies_to, description, is_active, created_at, updated_at "
            "FROM aria_rules ORDER BY domain, rule_key"
        )
        rows = [dict(r) for r in cursor.fetchall()]
    grouped: Dict[str, List[Any]] = {}
    for r in rows:
        grouped.setdefault(r["domain"], []).append(r)
    return {"domains": grouped}


@aria_router.post("/api/aria/rules", status_code=201)
def create_aria_rule(request: Request, body: AriaRuleIn):
    store = _store(request)
    rid = store.upsert_aria_rule(
        body.domain, body.rule_key, body.rule_name, body.value_type, body.value,
        body.applies_to, body.description,
    )
    return {"id": rid}


@aria_router.put("/api/aria/rules/{rule_id}")
def update_aria_rule(request: Request, rule_id: int, body: AriaRuleUpdate):
    store = _store(request)
    with store._tx() as cursor:
        cursor.execute(store._q("SELECT * FROM aria_rules WHERE id=?"), (rule_id,))
        row = cursor.fetchone()
        if not row:
            _404(f"aria_rule {rule_id} not found")
        existing = dict(row)
        cursor.execute(
            store._q("UPDATE aria_rules SET rule_name=?, value_type=?, value=?, "
                     "applies_to=?, description=?, updated_at=? WHERE id=?"),
            (
                body.rule_name or existing["rule_name"],
                body.value_type or existing["value_type"],
                body.value if body.value is not None else existing["value"],
                body.applies_to if body.applies_to is not None else existing["applies_to"],
                body.description if body.description is not None else existing["description"],
                store._now(), rule_id,
            ),
        )
    return {"id": rule_id}


@aria_router.delete("/api/aria/rules/{rule_id}", status_code=204)
def delete_aria_rule(request: Request, rule_id: int):
    store = _store(request)
    store.set_aria_entity_active("aria_rules", rule_id, False)


# ---------------------------------------------------------------------------
# aria_clause_rules — CRA clause penalties
# ---------------------------------------------------------------------------

class AriaClauseIn(BaseModel):
    rule_set: str
    clause_field: str
    clause_label: str
    penalty_points: int
    applies_to: Optional[str] = None
    severity: Optional[str] = None
    description: Optional[str] = None
    sort_order: int = 0


class AriaClauseUpdate(BaseModel):
    clause_label: Optional[str] = None
    penalty_points: Optional[int] = None
    applies_to: Optional[str] = None
    severity: Optional[str] = None
    description: Optional[str] = None
    sort_order: Optional[int] = None


@aria_router.get("/api/aria/clauses")
def list_aria_clauses(
    request: Request,
    rule_set: Optional[str] = Query(default=None),
):
    store = _store(request)
    q = ("SELECT id, rule_set, clause_field, clause_label, penalty_points, "
         "applies_to, severity, description, is_active, sort_order "
         "FROM aria_clause_rules")
    params = []
    if rule_set:
        q += " WHERE rule_set=?"
        params.append(rule_set)
    q += " ORDER BY rule_set, sort_order, clause_field"
    with store._tx() as cursor:
        cursor.execute(store._q(q), tuple(params))
        return {"clauses": [dict(r) for r in cursor.fetchall()]}


@aria_router.post("/api/aria/clauses", status_code=201)
def create_aria_clause(request: Request, body: AriaClauseIn):
    store = _store(request)
    cid = store.upsert_aria_clause(
        body.rule_set, body.clause_field, body.clause_label, body.penalty_points,
        body.applies_to, body.severity, body.description, body.sort_order,
    )
    return {"id": cid}


@aria_router.put("/api/aria/clauses/{clause_id}")
def update_aria_clause(request: Request, clause_id: int, body: AriaClauseUpdate):
    store = _store(request)
    with store._tx() as cursor:
        cursor.execute(store._q("SELECT * FROM aria_clause_rules WHERE id=?"), (clause_id,))
        row = cursor.fetchone()
        if not row:
            _404(f"aria_clause {clause_id} not found")
        e = dict(row)
        cursor.execute(
            store._q("UPDATE aria_clause_rules SET clause_label=?, penalty_points=?, "
                     "applies_to=?, severity=?, description=?, sort_order=? WHERE id=?"),
            (
                body.clause_label or e["clause_label"],
                body.penalty_points if body.penalty_points is not None else e["penalty_points"],
                body.applies_to if body.applies_to is not None else e["applies_to"],
                body.severity if body.severity is not None else e["severity"],
                body.description if body.description is not None else e["description"],
                body.sort_order if body.sort_order is not None else e["sort_order"],
                clause_id,
            ),
        )
    return {"id": clause_id}


@aria_router.delete("/api/aria/clauses/{clause_id}", status_code=204)
def delete_aria_clause(request: Request, clause_id: int):
    store = _store(request)
    store.set_aria_entity_active("aria_clause_rules", clause_id, False)


# ---------------------------------------------------------------------------
# aria_checklists — ordered intake/exit checklists
# ---------------------------------------------------------------------------

class AriaChecklistStepIn(BaseModel):
    domain: str
    checklist_id: str
    step_order: int
    step_key: str
    step_label: str
    step_detail: Optional[str] = None
    required: int = 1
    applies_to: Optional[str] = None


class AriaChecklistStepUpdate(BaseModel):
    step_label: Optional[str] = None
    step_detail: Optional[str] = None
    required: Optional[int] = None
    applies_to: Optional[str] = None
    step_order: Optional[int] = None


@aria_router.get("/api/aria/checklists")
def list_aria_checklists(
    request: Request,
    checklist_id: Optional[str] = Query(default=None),
    domain: Optional[str] = Query(default=None),
):
    store = _store(request)
    q = ("SELECT id, domain, checklist_id, step_order, step_key, step_label, "
         "step_detail, required, applies_to, is_active "
         "FROM aria_checklists WHERE is_active=1")
    params = []
    if checklist_id:
        q += " AND checklist_id=?"
        params.append(checklist_id)
    if domain:
        q += " AND domain=?"
        params.append(domain)
    q += " ORDER BY checklist_id, step_order"
    with store._tx() as cursor:
        cursor.execute(store._q(q), tuple(params))
        return {"steps": [dict(r) for r in cursor.fetchall()]}


@aria_router.post("/api/aria/checklists", status_code=201)
def create_aria_checklist_step(request: Request, body: AriaChecklistStepIn):
    store = _store(request)
    sid = store.upsert_aria_checklist_step(
        body.domain, body.checklist_id, body.step_order, body.step_key,
        body.step_label, body.step_detail, body.required, body.applies_to,
    )
    return {"id": sid}


@aria_router.put("/api/aria/checklists/{step_id}")
def update_aria_checklist_step(request: Request, step_id: int, body: AriaChecklistStepUpdate):
    store = _store(request)
    with store._tx() as cursor:
        cursor.execute(store._q("SELECT * FROM aria_checklists WHERE id=?"), (step_id,))
        row = cursor.fetchone()
        if not row:
            _404(f"aria_checklist step {step_id} not found")
        e = dict(row)
        cursor.execute(
            store._q("UPDATE aria_checklists SET step_label=?, step_detail=?, "
                     "required=?, applies_to=?, step_order=? WHERE id=?"),
            (
                body.step_label or e["step_label"],
                body.step_detail if body.step_detail is not None else e["step_detail"],
                body.required if body.required is not None else e["required"],
                body.applies_to if body.applies_to is not None else e["applies_to"],
                body.step_order if body.step_order is not None else e["step_order"],
                step_id,
            ),
        )
    return {"id": step_id}


@aria_router.delete("/api/aria/checklists/{step_id}", status_code=204)
def delete_aria_checklist_step(request: Request, step_id: int):
    store = _store(request)
    store.set_aria_entity_active("aria_checklists", step_id, False)


# ---------------------------------------------------------------------------
# negotiation_terms — BD playbook from negotiation-rules.xlsx
# ---------------------------------------------------------------------------

class NegotiationTermIn(BaseModel):
    term_slug: str
    term_name: str
    category: str
    difficulty: str
    bd_relevant: Optional[str] = None
    explanation: Optional[str] = None
    risk_description: Optional[str] = None
    moderate_leverage_action: Optional[str] = None
    high_leverage_action: Optional[str] = None
    applies_to: Optional[str] = None
    sort_order: int = 0


class NegotiationTermUpdate(BaseModel):
    term_name: Optional[str] = None
    category: Optional[str] = None
    difficulty: Optional[str] = None
    bd_relevant: Optional[str] = None
    moderate_leverage_action: Optional[str] = None
    high_leverage_action: Optional[str] = None
    applies_to: Optional[str] = None


@aria_router.get("/api/aria/negotiation-terms")
def list_negotiation_terms(
    request: Request,
    category: Optional[str] = Query(default=None),
    bd_relevant: Optional[str] = Query(default=None),
):
    store = _store(request)
    return {"terms": store.load_negotiation_terms(
        category=category,
        bd_relevant=(bd_relevant in ("must", "yes", "true", "1")),
    )}


@aria_router.post("/api/aria/negotiation-terms", status_code=201)
def create_negotiation_term(request: Request, body: NegotiationTermIn):
    store = _store(request)
    tid = store.upsert_negotiation_term(
        body.term_slug, body.term_name, body.category, body.difficulty,
        body.bd_relevant, body.explanation, body.risk_description,
        body.moderate_leverage_action, body.high_leverage_action,
        body.applies_to, body.sort_order,
    )
    return {"id": tid}


@aria_router.put("/api/aria/negotiation-terms/{term_id}")
def update_negotiation_term(request: Request, term_id: int, body: NegotiationTermUpdate):
    store = _store(request)
    with store._tx() as cursor:
        cursor.execute(store._q("SELECT * FROM negotiation_terms WHERE id=?"), (term_id,))
        row = cursor.fetchone()
        if not row:
            _404(f"negotiation_term {term_id} not found")
        e = dict(row)
        cursor.execute(
            store._q("UPDATE negotiation_terms SET term_name=?, category=?, difficulty=?, "
                     "bd_relevant=?, moderate_leverage_action=?, high_leverage_action=?, "
                     "applies_to=? WHERE id=?"),
            (
                body.term_name or e["term_name"],
                body.category or e["category"],
                body.difficulty or e["difficulty"],
                body.bd_relevant if body.bd_relevant is not None else e["bd_relevant"],
                body.moderate_leverage_action if body.moderate_leverage_action is not None
                    else e["moderate_leverage_action"],
                body.high_leverage_action if body.high_leverage_action is not None
                    else e["high_leverage_action"],
                body.applies_to if body.applies_to is not None else e["applies_to"],
                term_id,
            ),
        )
    return {"id": term_id}


@aria_router.delete("/api/aria/negotiation-terms/{term_id}", status_code=204)
def delete_negotiation_term(request: Request, term_id: int):
    store = _store(request)
    store.set_aria_entity_active("negotiation_terms", term_id, False)


# ---------------------------------------------------------------------------
# vendor_fiscal_calendars — cross-agent shared config
# ---------------------------------------------------------------------------

class VendorCalendarIn(BaseModel):
    vendor_name: str
    vendor_slug: str
    vendor_category: str
    fy_end_month: int
    fy_end_label: str
    best_window_label: str
    discount_uplift_pct: Optional[str] = None
    notes: Optional[str] = None


class VendorCalendarUpdate(BaseModel):
    vendor_name: Optional[str] = None
    vendor_category: Optional[str] = None
    fy_end_month: Optional[int] = None
    fy_end_label: Optional[str] = None
    best_window_label: Optional[str] = None
    discount_uplift_pct: Optional[str] = None
    notes: Optional[str] = None


@aria_router.get("/api/vendors/fiscal-calendars")
def list_vendor_fiscal_calendars(
    request: Request,
    category: Optional[str] = Query(default=None),
):
    store = _store(request)
    return {"vendors": store.load_vendor_fiscal_calendars(category=category)}


@aria_router.post("/api/vendors/fiscal-calendars", status_code=201)
def create_vendor_calendar(request: Request, body: VendorCalendarIn):
    store = _store(request)
    vid = store.upsert_vendor_fiscal_calendar(
        body.vendor_name, body.vendor_slug, body.vendor_category,
        body.fy_end_month, body.fy_end_label, body.best_window_label,
        body.discount_uplift_pct, body.notes,
    )
    return {"id": vid}


@aria_router.put("/api/vendors/fiscal-calendars/{vendor_id}")
def update_vendor_calendar(request: Request, vendor_id: int, body: VendorCalendarUpdate):
    store = _store(request)
    with store._tx() as cursor:
        cursor.execute(
            store._q("SELECT * FROM vendor_fiscal_calendars WHERE id=?"), (vendor_id,)
        )
        row = cursor.fetchone()
        if not row:
            _404(f"vendor_fiscal_calendar {vendor_id} not found")
        e = dict(row)
        cursor.execute(
            store._q("UPDATE vendor_fiscal_calendars SET vendor_name=?, vendor_category=?, "
                     "fy_end_month=?, fy_end_label=?, best_window_label=?, "
                     "discount_uplift_pct=?, notes=? WHERE id=?"),
            (
                body.vendor_name or e["vendor_name"],
                body.vendor_category or e["vendor_category"],
                body.fy_end_month if body.fy_end_month is not None else e["fy_end_month"],
                body.fy_end_label or e["fy_end_label"],
                body.best_window_label or e["best_window_label"],
                body.discount_uplift_pct if body.discount_uplift_pct is not None
                    else e["discount_uplift_pct"],
                body.notes if body.notes is not None else e["notes"],
                vendor_id,
            ),
        )
    return {"id": vendor_id}


@aria_router.delete("/api/vendors/fiscal-calendars/{vendor_id}", status_code=204)
def delete_vendor_calendar(request: Request, vendor_id: int):
    store = _store(request)
    store.set_aria_entity_active("vendor_fiscal_calendars", vendor_id, False)
