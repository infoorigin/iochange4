"""Concurrency ceiling for the always-on agent pool.

Why this exists
---------------
iobot has a concurrency semaphore (``IOBOT_MAX_CONCURRENT_REQUESTS``), but
it is acquired in ``AgentLoop._dispatch`` — the BUS path — only. Every
always-on surface we run (Studio chat proxy, A2A, MS Teams, cron callbacks)
calls ``process_direct``, which takes the per-session lock and no gate. So the
pool is unbounded: N simultaneous users means N simultaneous LLM calls, and the
first backpressure anyone meets is the provider's rate limit.

Measured on iobot 0.3.0, not inferred (``scripts/concurrency_test.py``):
6 requests across 6 sessions completed in 4.24s against a 12.37s serial
estimate, and capping ``--concurrency 2`` changed nothing (3.79s) — which is
what proves the gate is absent from this path rather than merely generous.

Acquisition order is the whole design
-------------------------------------
The obvious implementation is wrong::

    async with semaphore:              # WRONG
        await process_direct(...)

``process_direct`` takes its per-session lock INSIDE. So several requests on
one session would each hold a global slot while all but one idle on that lock,
starving every other session — one user double-clicking can wedge the pod.

iobot avoids this in ``_dispatch`` with ``async with lock, gate``: session
lock FIRST, global gate SECOND, so waiters queue without occupying a slot. We
mirror that. Our per-session lock is a second lock in front of iobot's
internal one (``asyncio.Lock`` is not reentrant, so we cannot reuse theirs); it
serializes exactly what iobot would serialize anyway, and its only job is to
make sure a queued same-session request is not holding a global slot.

Default is UNLIMITED
--------------------
Unset or ``0`` returns the original callable unwrapped — zero overhead, zero
behaviour change. Turn it on once real Studio concurrency numbers exist; a
number picked from a synthetic test on one machine is a guess.
"""

from __future__ import annotations

import asyncio
import os
import time
from contextlib import asynccontextmanager
from typing import Any, Awaitable, Callable, Optional

from loguru import logger

DEFAULT_QUEUE_TIMEOUT_S = 60.0


class PoolSaturated(Exception):
    """Every pool slot was busy for longer than the queue timeout.

    Failing loudly beats an unbounded queue: without a timeout, saturation
    reaches the client as a generic gateway timeout carrying no hint that a cap
    was involved.

    How callers actually see it (measured against a live pod capped at 1, NOT
    assumed — every one of these surfaces catches broadly around
    ``process_direct``, so the ``PoolSaturated`` handler in ``app.py`` does not
    get a chance to run):

    - ``POST /a2a/<role>``  -> HTTP 200, JSON-RPC ``error`` -32603, message
      ``"PoolSaturated: agent pool saturated (N slots busy); waited Ns..."``
    - ``POST /api/chat/*``  -> HTTP 200 with an ``error`` field, that router's
      existing convention for every failure
    - MS Teams             -> same shape as chat, via the same pool call

    The message is precise in each case, so the failure is diagnosable; what is
    NOT delivered is a 503 status or a ``Retry-After`` header, which means a
    generic HTTP client cannot distinguish saturation from success without
    reading the body. Making that uniform means touching each router's error
    handling — deliberately out of scope here.
    """

    def __init__(self, waited_s: float, limit: int) -> None:
        super().__init__(
            f"agent pool saturated ({limit} slots busy); "
            f"waited {waited_s:.1f}s for a slot"
        )
        self.waited_s = waited_s
        self.limit = limit


def _int_env(name: str, default: int) -> int:
    raw = (os.environ.get(name) or "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        logger.warning("pool_limit: {}={!r} is not an integer; using {}",
                       name, raw, default)
        return default


def _float_env(name: str, default: float) -> float:
    raw = (os.environ.get(name) or "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        logger.warning("pool_limit: {}={!r} is not a number; using {}",
                       name, raw, default)
        return default


class PoolLimiter:
    """Per-pod ceiling on concurrent agent turns.

    One instance per process, shared across roles on purpose: the resource being
    protected is the model provider's rate limit, which every role shares. A
    per-role limiter would let R roles run R x limit calls at once.
    """

    def __init__(self, limit: int, queue_timeout_s: float = DEFAULT_QUEUE_TIMEOUT_S):
        if limit <= 0:
            raise ValueError("PoolLimiter requires a positive limit")
        self.limit = limit
        self.queue_timeout_s = queue_timeout_s
        self._sem = asyncio.Semaphore(limit)
        self._session_locks: dict[str, asyncio.Lock] = {}
        # Refcount per session so an idle lock can be reaped without ever
        # dropping one that a waiter still holds a reference to — see _session.
        self._session_waiters: dict[str, int] = {}

    @property
    def in_flight(self) -> int:
        """Slots currently held. For logging and tests, not for control flow."""
        return self.limit - self._sem._value  # noqa: SLF001 - no public accessor

    @asynccontextmanager
    async def _session(self, session_key: str):
        """Serialize one session, and reap the lock once nobody wants it.

        Without reaping this dict grows one entry per session forever — a slow
        leak on a long-lived pod. Reaping naively is worse: popping a lock while
        a waiter still holds it means the next arrival creates a SECOND lock for
        the same session and the serialization silently stops working. The
        refcount is incremented before the lock is awaited and decremented after
        it is released, with no await in between either time, so a session is
        only ever reaped when genuinely idle.
        """
        lock = self._session_locks.setdefault(session_key, asyncio.Lock())
        self._session_waiters[session_key] = self._session_waiters.get(session_key, 0) + 1
        try:
            async with lock:
                yield
        finally:
            remaining = self._session_waiters.get(session_key, 1) - 1
            if remaining <= 0:
                self._session_waiters.pop(session_key, None)
                self._session_locks.pop(session_key, None)
            else:
                self._session_waiters[session_key] = remaining

    @asynccontextmanager
    async def slot(self, session_key: str):
        """Hold a pool slot for one agent turn. Session lock first, then gate."""
        async with self._session(session_key):
            waited = 0.0
            if self._sem.locked():
                # Only log when a request ACTUALLY queues. Saturation that is
                # never surfaced looks exactly like a slow model.
                logger.info(
                    "pool_limit: all {} slots busy, queueing session={}",
                    self.limit, session_key,
                )
                started = time.perf_counter()
                try:
                    await asyncio.wait_for(self._sem.acquire(),
                                           timeout=self.queue_timeout_s)
                except asyncio.TimeoutError:
                    waited = time.perf_counter() - started
                    logger.warning(
                        "pool_limit: session={} gave up after {:.1f}s",
                        session_key, waited,
                    )
                    raise PoolSaturated(waited, self.limit) from None
                waited = time.perf_counter() - started
                logger.info("pool_limit: session={} waited {:.1f}s for a slot",
                            session_key, waited)
            else:
                await self._sem.acquire()
            try:
                yield
            finally:
                self._sem.release()


_limiter: Optional[PoolLimiter] = None


def get_limiter() -> Optional[PoolLimiter]:
    """The process-wide limiter, or None when unlimited (the default)."""
    global _limiter
    limit = _int_env("IOF_POOL_MAX_CONCURRENCY", 0)
    if limit <= 0:
        return None
    if _limiter is None or _limiter.limit != limit:
        _limiter = PoolLimiter(
            limit, _float_env("IOF_POOL_QUEUE_TIMEOUT_S", DEFAULT_QUEUE_TIMEOUT_S)
        )
        logger.info(
            "pool_limit: agent pool capped at {} concurrent turns "
            "(queue timeout {:.0f}s)", _limiter.limit, _limiter.queue_timeout_s,
        )
    return _limiter


def reset_limiter() -> None:
    """Drop the cached limiter. Tests only — env changes take effect again."""
    global _limiter
    _limiter = None


def wrap_with_pool_limit(
    process_direct: Callable[..., Awaitable[Any]],
) -> Callable[..., Awaitable[Any]]:
    """Wrap a bound ``AgentLoop.process_direct`` with the pool ceiling.

    Returns the callable UNCHANGED when no limit is configured, so the default
    build carries no wrapper, no lock bookkeeping and no behaviour change.

    Applied once in ``AgentPool.get()``, which is why it covers every surface —
    Studio chat, A2A, Teams, cron all call this one bound method.
    """
    if get_limiter() is None:
        return process_direct

    async def limited(*args: Any, **kwargs: Any) -> Any:
        limiter = get_limiter()
        if limiter is None:  # flipped off at runtime; behave as before
            return await process_direct(*args, **kwargs)
        # process_direct(content, session_key=..., ...) — session_key is the
        # second positional, so accept either calling convention.
        session_key = kwargs.get("session_key")
        if session_key is None and len(args) > 1:
            session_key = args[1]
        async with limiter.slot(str(session_key or "cli:direct")):
            return await process_direct(*args, **kwargs)

    return limited
