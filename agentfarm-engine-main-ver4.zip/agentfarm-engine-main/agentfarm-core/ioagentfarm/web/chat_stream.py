"""Server-Sent Events for a chat turn — the reply as it is produced.

``POST /api/chat/{ns}`` answers when the turn is over. For a conversational UI
that is the wrong shape: an agent turn is an agent LOOP — it thinks, calls a
tool, reads the result, calls another — and a caller that can only wait sees
nothing for as long as that takes. The existing surface answers this by
STORING progress rows and letting a client poll for them (``_progress_row`` in
``web/app.py`` says so in its docstring: *the client never sees the model's
stream*). Polling is a second request path, a latency floor and a cache
problem; a chat UI wants the events pushed.

This module adds the push without a second implementation of the turn. The
streaming endpoint calls THE SAME handler; a context variable carries a sink,
and the two places where the handler already learns something worth showing —
the progress row it writes, and the model's own text deltas — also hand the
event to the sink. With no sink set (every existing caller) the two hooks are
one ``ContextVar.get()`` returning ``None``, so the non-streaming path is
byte-for-byte what it was.

Events, in the order a caller sees them::

    event: status    {"text": "iof-query: SELECT ..."}   what the agent is doing
    event: delta     {"text": "Access in "}              model text as it arrives
    event: message   {...}                               the SAME body the POST
                                                         endpoint returns
    event: error     {"error": "..."}                    the turn failed
    event: done      {}                                  always last

``delta`` events only appear when the deployment lets the provider stream
(``IOF_DISABLE_STREAMING`` unset). Where it is disabled — the default for this
engine's model, for stall reasons documented in ``_iobot_patches`` — a
caller still gets ``status`` throughout and one ``message`` at the end, which
is the useful half and the reason this is not gated on provider streaming.

A caller that goes away is not worked for: the turn is cancelled when the
client disconnects.
"""
from __future__ import annotations

import asyncio
import json
from contextvars import ContextVar
from typing import Any, Awaitable, Callable, Optional

from fastapi import HTTPException
from fastapi.responses import StreamingResponse
from loguru import logger

#: Sentinel pushed by the driver when the turn is over.
_END = object()

#: The sink for the turn running in THIS context. ``asyncio.create_task``
#: copies the current context, so setting it before the task is created is
#: what makes the handler's hooks find it.
_SINK: ContextVar[Optional["ChatSink"]] = ContextVar("iof_chat_sse_sink", default=None)


class ChatSink:
    """A queue of SSE events for one streamed chat turn."""

    def __init__(self) -> None:
        self.queue: asyncio.Queue = asyncio.Queue()
        self._closed = False

    def emit(self, event: str, data: dict) -> None:
        """Never raises and never blocks — a progress hook must not break a turn."""
        if self._closed:
            return
        try:
            self.queue.put_nowait((event, data))
        except Exception:  # noqa: BLE001 - defensive; the queue is unbounded
            logger.debug("chat sse: event dropped", exc_info=True)

    def close(self) -> None:
        self._closed = True
        try:
            self.queue.put_nowait((_END, None))
        except Exception:  # noqa: BLE001
            pass


def emit(event: str, data: dict) -> None:
    """Hand one event to the streaming caller, if this turn has one."""
    sink = _SINK.get()
    if sink is not None:
        sink.emit(event, data)


def streaming() -> bool:
    """True when the turn running in this context has a streaming caller."""
    return _SINK.get() is not None


def _first_event_timeout() -> float:
    """How long to wait for the first event before starting the stream.

    Short, because a refusal is a CHECK - an empty message, an unknown agent,
    a workspace mismatch - and every one of them answers in milliseconds. The
    only thing this bound gives up is turning a slow FAILURE into an HTTP
    status instead of an in-band error, which is the right trade against
    showing a caller nothing at all.
    """
    import os
    raw = (os.environ.get("IOF_CHAT_STREAM_FIRST_EVENT_S") or "").strip()
    try:
        value = float(raw)
        if value > 0:
            return value
    except (TypeError, ValueError):
        pass
    return 5.0


def frame(event: str, data: Any) -> str:
    return "event: " + event + "\ndata: " + json.dumps(data, ensure_ascii=False) + "\n\n"


async def stream_turn(
    handler: Callable[[], Awaitable[dict]],
    request,
    *,
    heartbeat_s: float = 15.0,
    format_frame: Optional[Callable[[str, Any], str]] = None,
    preamble: Optional[str] = None,
) -> StreamingResponse:
    """Run ``handler`` with a sink attached and stream what it produces.

    The handler's own up-front refusals — an empty message, an unknown agent,
    a workspace that is not this one — must stay real HTTP status codes, not
    an ``error`` event inside a 200. So the first thing awaited is "either an
    event, or the handler finishing": nothing has been written to the wire
    yet, so an exception raised before the first event is re-raised here and
    FastAPI renders it normally.

    *format_frame* renders one ``(event, data)`` pair for the wire. It exists
    so the A2A surface can emit JSON-RPC ``StreamResponse`` frames - a
    completely different shape, with no ``event:`` line - through THIS driver
    rather than a second copy of it. Every decision above is subtle and was
    paid for once; two copies would drift the first time one is fixed.

    *preamble* is written before anything else when the caller must put a
    frame on the wire ahead of the handler - A2A sends the ``Task`` first, so
    a client has the id to correlate against.
    """
    fmt = format_frame or frame
    sink = ChatSink()
    token = _SINK.set(sink)
    try:
        task = asyncio.create_task(handler())
    finally:
        # The task copied the context; this frame must not keep the sink, or a
        # later turn on this connection would inherit it.
        _SINK.reset(token)

    # THE FIRST WAIT IS BOUNDED, and it was not. Nothing reaches the client -
    # not even the response headers - until the first event arrives, because
    # a refusal that happens before any output has to be an HTTP status
    # rather than an `error` inside a 200. That reasoning is right and the
    # unbounded wait was not: an agent that takes forty seconds to its first
    # token showed the caller absolutely nothing for forty seconds. A user
    # reported it as "curl got stuck", which is exactly what it looks like.
    #
    # So: wait a short while for either outcome, then START THE STREAM
    # anyway. The refusal path is unchanged for every fast failure - which is
    # all of them, since a refusal is a check, not a model call - and a slow
    # turn now gets headers and a keep-alive while it thinks. A failure after
    # that becomes the in-band `error` event this module already sends.
    getter = asyncio.ensure_future(sink.queue.get())
    done, _pending = await asyncio.wait(
        {task, getter}, timeout=_first_event_timeout(),
        return_when=asyncio.FIRST_COMPLETED)

    first: Optional[tuple] = None
    if getter in done:
        first = getter.result()
    elif task in done and task.exception() is not None:
        getter.cancel()
        # Refused before it produced anything: an HTTP error, not a stream.
        raise task.exception()
    else:
        # Still thinking. Hand the generator the pending getter rather than
        # cancelling it, or the first real event would be dropped on the
        # floor - which would be a worse bug than the one being fixed.
        sink.pending_getter = getter

    async def _drive():
        """Close the sink when the turn ends, so the generator can finish."""
        try:
            await asyncio.shield(task)
        except BaseException:  # noqa: BLE001 - the generator reports it
            pass
        finally:
            sink.close()

    asyncio.ensure_future(_drive())

    async def _events():
        # Nothing has been sent yet and the turn is slow: give the client its
        # headers now. A comment frame is not an event and no client parses
        # it as one.
        if preamble:
            yield preamble
        if first is None:
            yield ": thinking" + chr(10) + chr(10)
        pending = first
        try:
            while True:
                if pending is None:
                    waiter = getattr(sink, "pending_getter", None)
                    if waiter is not None:
                        sink.pending_getter = None
                    try:
                        pending = await asyncio.wait_for(
                            waiter if waiter is not None else sink.queue.get(),
                            timeout=heartbeat_s)
                    except asyncio.TimeoutError:
                        # A proxy that sees nothing for long enough closes the
                        # connection; a comment frame is not an event and no
                        # client parses it as one.
                        yield ": keep-alive\n\n"
                        if await request.is_disconnected():
                            task.cancel()
                            return
                        continue
                event, data = pending
                pending = None
                if event is _END:
                    break
                yield fmt(event, data)
        except asyncio.CancelledError:  # pragma: no cover - client vanished
            task.cancel()
            raise

        # The turn is over: publish its result in the same shape the POST
        # endpoint returns, so a caller has ONE body to parse either way.
        try:
            body = await task
            yield fmt("message", body)
        except HTTPException as exc:  # raised after streaming began
            yield fmt("error", {"error": exc.detail, "status": exc.status_code})
        except asyncio.CancelledError:  # pragma: no cover
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("chat sse: turn failed")
            yield fmt("error", {"error": type(exc).__name__ + ": " + str(exc)})
        finally:
            yield fmt("done", {})

    return StreamingResponse(
        _events(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            # nginx buffers text/event-stream by default, which turns a live
            # stream into one delivery at the end — the exact failure this
            # endpoint exists to remove.
            "X-Accel-Buffering": "no",
        },
    )
