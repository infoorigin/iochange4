"""Conversations: durable threads with an agent, on an OpenAI-shaped surface.

WHY THIS IS IN THE ENGINE. The thread layer was built in the Studio API, which
meant MULTI-THREAD CHAT REQUIRED THE STUDIO: a chat UI wanting more than one
conversation with an agent had to run the Studio and its database beside the
engine, for a feature the engine's own tables already backed. The tables are
core-owned - their DDL is in ``workspace_sync.ensure_platform_schema``, which
``aicore init`` runs - so only the ROUTES were on the wrong side.

WHAT MULTIPLE THREADS REST ON. A conversation id is minted per create, and the
session key is ``conv:<id>:<agent>`` - one engine session per (conversation,
agent). N conversations with one agent therefore hold N separate memories,
which is the whole point of the surface. There is no unique constraint on
(owner, agent): several threads with one agent is the intended use, not a
collision to resolve.

THE SESSION KEY IS PASSED, NOT SMUGGLED. ``adhoc_chat(session_key=...)`` is a
new interface added for this. Before it, the only lever on which session a turn
resumed was ``user_id`` - the correlation key for narration rows - because the
key was derived from it, so a caller wanting its own thread had to pack a
thread id into a field meant for something else. ``session_key`` is deliberately
NOT a field on ``ChatRequest`` and cannot be set over the wire: naming a session
is naming whose memory to resume, and ``/api/chat`` knows its caller only as
well as the ``user_id`` it was handed.

THE WIRE SHAPE FOLLOWS OPENAI'S CONVERSATIONS API, and the reason is not
fashion: a client, SDK or eval harness built against that shape should work by
changing a base URL. What we adopt - typed resources (``object``), the list
envelope, cursor pagination, prefixed ids, content as typed parts, the error
envelope - is listed in ``docs/``. Two rules keep it honest:

- **A standard field means exactly what the standard says.** An agent's turn is
  ``role: "assistant"`` ALWAYS, even when a workspace has forty agents; WHICH
  agent is ``x_agent``. A stock client renders the thread correctly and cannot
  tell one agent from another - degraded, never wrong.
- **``metadata`` belongs to the caller.** It is stored verbatim and never read.
  Our own derived facts (the auto-title, the agent) live in ``x_`` fields, so we
  never spend the caller's bag or collide with their keys.

WHERE WE KNOWINGLY DIVERGE. The standard has no list-conversations call and no
notion of who owns a thread, because it models one person talking to one model.
Both are required here and are marked as extensions where they appear.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/conversations", tags=["conversations"])

#: Same shape the Studio uses for an agent role everywhere else.
AGENT_RE = re.compile(r"^[a-z][a-z0-9_-]{1,39}[a-z0-9]$")
_TITLE_CHARS = 60
_MAX_CONTENT = 32_000
_MAX_METADATA_KEYS = 16
_MAX_METADATA_LEN = 512

#: Poll cadence for the narration reader. A turn is minutes long and mostly
#: silent - the agent spends most of it inside one model call - so this runs
#: fast while rows are flowing and slow while nothing is happening.
_POLL_S = 0.7
_POLL_IDLE_S = 2.5
_POLL_FAST_FOR_S = 6.0
_PING_S = 15.0

#: Said once per process, not per request - an operator needs the fact, not a
#: log line per turn.
_WARNED_ANON = False


# ── errors, in the standard's shape ──────────────────────────────

class ConvError(HTTPException):
    """An error that renders as ``{"error": {...}}``.

    A subclass rather than a bare ``JSONResponse`` return so it can be raised
    from the helpers that detect it, several frames below the route.
    """

    def __init__(self, status_code: int, message: str, err_type: str,
                 code: str = "", param: str = ""):
        super().__init__(status_code=status_code, detail=message)
        self.payload = {"error": {"message": message, "type": err_type,
                                  "param": param or None, "code": code or None}}


def install_error_shape(app) -> None:
    """Render :class:`ConvError` as the standard error envelope.

    Registered on the app because a router cannot carry exception handlers, and
    scoped by TYPE rather than by path: a handler for ``HTTPException`` would
    silently restyle every other route on the engine.
    """
    @app.exception_handler(ConvError)
    async def _handle(_request, exc: ConvError):       # noqa: ANN202
        return JSONResponse(status_code=exc.status_code, content=exc.payload)


def _not_found(what: str = "conversation") -> ConvError:
    """404 for a thread that exists but is not the caller's, as well as one
    that does not exist.

    The two are deliberately indistinguishable: a 403 would confirm the thread
    is real, which turns the endpoint into an existence oracle for other
    people's conversations.
    """
    return ConvError(404, f"No {what} found with that id.",
                     "invalid_request_error", code="not_found")


# ── plumbing ─────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _unix(iso: str) -> int:
    """Stored ISO -> the standard's integer seconds.

    The column stays ISO because it is also read by the Studio's own router and
    by anyone with a SQL prompt; the conversion is a rendering concern.
    """
    try:
        return int(datetime.fromisoformat(iso).timestamp())
    except (ValueError, TypeError):
        return 0


def _ws() -> str:
    from ioagentfarm.engine.workspaces import resolved_workspace_code
    return resolved_workspace_code()


def _store():
    from ioagentfarm.web.app import _store as engine_store
    return engine_store()


_SCHEMA_READY: set[str] = set()


def _ensure(store) -> None:
    """Create the platform tables once per process per database.

    Keyed by the database target rather than a bare boolean, for the reason
    ``ensure_agent_workspace``'s memo had to learn: a process can address more
    than one database, and a flag saying "already done" about a database it has
    never seen is a table that does not exist.
    """
    target = os.getenv("IOF_DATABASE_URL", "") or "sqlite"
    if target in _SCHEMA_READY:
        return
    from ioagentfarm.workspace_sync import ensure_platform_schema
    with store._conn() as con:
        store._db.init_connection(con)
        ensure_platform_schema(con, store._db.placeholder() == "%s")
    _SCHEMA_READY.add(target)


def _owner(request: Request, fallback: str = "") -> str:
    """Who owns the thread this request is about.

    A verified principal's end user when there is one - ``actor`` first, so a
    Studio proxying for a person is that PERSON and not the service account.

    ``IOF_ENGINE_AUTH=off`` DOES NOT MEAN ``principal_of`` RETURNS None. It
    installs a real Principal with ``subject="anonymous"`` and ``method="none"``,
    so a bare ``is not None`` check resolves EVERY caller to one owner called
    "anonymous" - a live run showed a second user listing the first user's
    threads and opening one with HTTP 200. Keyed on ``method``, whose documented
    job is how the caller authenticated, rather than on the subject string: an
    IdP is free to issue a subject called "anonymous", and that caller IS
    authenticated.
    """
    global _WARNED_ANON
    try:
        from ioagentfarm.web.auth import principal_of
        principal = principal_of(request)
    except Exception:                       # noqa: BLE001 - auth is optional
        principal = None
    if principal is not None and getattr(principal, "method", "") != "none":
        who = (getattr(principal, "actor", "") or getattr(principal, "email", "")
               or getattr(principal, "subject", ""))
        if who:
            return who
    who = (fallback or "").strip()
    if not _WARNED_ANON:
        _WARNED_ANON = True
        logger.warning(
            "conversations: no verified caller, so a thread is owned by the "
            "UNVERIFIED `user_id` its client sends. Threads are separated by "
            "that value, but nothing proves it - a caller who sends someone "
            "else's user_id reads their conversations. Set IOF_ENGINE_AUTH to "
            "make ownership a verified identity.")
    if not who:
        raise ConvError(
            400, "user_id is required when the engine runs without "
                 "authentication, because it is the only thing that can own a "
                 "conversation. Send one, or set IOF_ENGINE_AUTH.",
            "invalid_request_error", code="missing_owner", param="user_id")
    return who


def _clean_metadata(raw) -> str:
    """The caller's bag, validated and stored verbatim."""
    if raw in (None, {}):
        return ""
    if not isinstance(raw, dict):
        raise ConvError(400, "metadata must be an object.",
                        "invalid_request_error", param="metadata")
    if len(raw) > _MAX_METADATA_KEYS:
        raise ConvError(400, f"metadata supports at most "
                             f"{_MAX_METADATA_KEYS} keys.",
                        "invalid_request_error", param="metadata")
    for k, v in raw.items():
        if not isinstance(k, str) or not isinstance(v, str):
            raise ConvError(400, "metadata keys and values must be strings.",
                            "invalid_request_error", param="metadata")
        if len(k) > _MAX_METADATA_LEN or len(v) > _MAX_METADATA_LEN:
            raise ConvError(400, f"metadata keys and values are limited to "
                                 f"{_MAX_METADATA_LEN} characters.",
                            "invalid_request_error", param="metadata")
    return json.dumps(raw)


def _load_metadata(raw: str) -> dict:
    if not raw:
        return {}
    try:
        out = json.loads(raw)
        return out if isinstance(out, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def _title_from(text: str) -> str:
    """First line, trimmed - a placeholder until the thread has a better name.

    Deliberately not the agent's answer: the question is what the owner will
    recognise the thread by.
    """
    line = (text or "").strip().splitlines()[0] if (text or "").strip() else ""
    return line[:_TITLE_CHARS].strip()


# ── rendering ────────────────────────────────────────────────────

def _conversation_out(r: dict) -> dict:
    """A conversation in the standard's shape.

    ``x_agent`` and ``x_title`` are ours: the standard has no notion of which
    assistant a thread belongs to, nor a name for one. They are prefixed so a
    stock client ignores them rather than tripping on them.
    """
    return {
        "id": r["id"],
        "object": "conversation",
        "created_at": _unix(r["created_at"]),
        "metadata": _load_metadata(r.get("metadata_json") or ""),
        "x_agent": r["role"],
        "x_title": r["title"],
        "x_updated_at": _unix(r["updated_at"]),
    }


def _item_out(r: dict, agent: str = "") -> dict:
    """One turn as a conversation item.

    ``role`` is the STANDARD's role - ``user`` or ``assistant`` - never an
    agent name, so a stock client renders the thread correctly. Which agent
    spoke is ``x_agent``.
    """
    role = r["role"]
    part = "input_text" if role == "user" else "output_text"
    out = {
        "id": r["id"],
        "object": "conversation.item",
        "type": "message",
        "role": role,
        "content": [{"type": part, "text": r["content"]}],
        "created_at": _unix(r["created_at"]),
        "x_seq": r["seq"],
    }
    if role == "assistant":
        out["x_agent"] = agent
        env = None
        raw = r.get("envelope_json") or ""
        if raw:
            try:
                env = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                # A rendering enrichment, so one bad row degrades to None
                # rather than making the whole conversation unreadable.
                logger.warning("conversation item %s has an unparsable "
                               "envelope", r.get("id"))
        out["x_envelope"] = env
        out["x_error"] = r.get("error") or None
        out["x_thoughts"] = r.get("thoughts") or None
    return out


def _list_envelope(items: list[dict], has_more: bool) -> dict:
    return {
        "object": "list",
        "data": items,
        "first_id": items[0]["id"] if items else None,
        "last_id": items[-1]["id"] if items else None,
        "has_more": has_more,
    }


# ── the owned read ───────────────────────────────────────────────

def _get_owned(store, cur, conv_id: str, owner: str) -> dict:
    """The caller's conversation, or 404.

    Ownership is checked in the QUERY, not after it - see :func:`_not_found`.
    """
    cur.execute(store._q(
        "SELECT workspace_code, id, role, author, title, metadata_json,"
        " created_at, updated_at FROM studio_conversations"
        " WHERE workspace_code=? AND id=? AND author=?"),
        (_ws(), conv_id, owner))
    row = cur.fetchone()
    if row is None:
        raise _not_found()
    return dict(row)


# ── schemas ──────────────────────────────────────────────────────

class ConversationCreate(BaseModel):
    agent: str
    metadata: dict | None = None
    title: str = ""
    user_id: str | None = None


class ConversationUpdate(BaseModel):
    metadata: dict | None = None
    title: str | None = None
    user_id: str | None = None


class ItemCreate(BaseModel):
    """A message to append. `role` is the standard's, and only `user` is
    accepted: an assistant turn is produced by the agent, never asserted by a
    caller - accepting one would let a client write words into an agent's mouth
    and into its memory."""
    role: str = "user"
    content: str
    user_id: str | None = None


class ResponseCreate(BaseModel):
    """Run a turn. ``input`` is the new question; omit it to answer an item
    already appended (the resumable path)."""
    input: str = ""
    item_id: str = ""
    stream: bool = False
    user_id: str | None = None


# ── conversations ────────────────────────────────────────────────

@router.post("")
def create_conversation(body: ConversationCreate, request: Request) -> dict:
    """Open a thread with one agent.

    A fresh id every time, with no lookup of an existing thread: several
    conversations with one agent is the point of the surface.
    """
    owner = _owner(request, body.user_id or "")
    agent = (body.agent or "").strip()
    if not AGENT_RE.match(agent):
        raise ConvError(400, f"'{agent}' is not a valid agent name.",
                        "invalid_request_error", param="agent")
    meta = _clean_metadata(body.metadata)
    store = _store()
    _ensure(store)
    conv_id = f"conv_{uuid.uuid4().hex}"
    now = _now_iso()
    with store._tx() as cur:
        cur.execute(store._q(
            "INSERT INTO studio_conversations (workspace_code, id, role,"
            " author, title, metadata_json, created_at, updated_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?)"),
            (_ws(), conv_id, agent, owner,
             (body.title or "").strip()[:_TITLE_CHARS], meta, now, now))
    return _conversation_out({
        "id": conv_id, "role": agent, "title": (body.title or "").strip(),
        "metadata_json": meta, "created_at": now, "updated_at": now})


@router.get("")
def list_conversations(request: Request,
                       limit: int = Query(default=20, ge=1, le=100),
                       after: str = Query(default=""),
                       order: str = Query(default="desc"),
                       user_id: str = Query(default="")) -> dict:
    """The caller's threads, most recently active first.

    AN EXTENSION: the standard has no list call, because it models one person
    talking to one model and hands thread management to the client. A chat UI
    with a conversation rail cannot work that way, so this exists - in the
    standard's list shape, so a client that understands one list understands
    this one.

    Cursor, not offset. Offset-paging a table that is being appended to skips
    and repeats rows, and this one is appended to by every turn.
    """
    owner = _owner(request, user_id)
    store = _store()
    _ensure(store)
    desc = order.lower() != "asc"
    cmp_op = "<" if desc else ">"
    direction = "DESC" if desc else "ASC"
    with store._tx() as cur:
        params: list = [_ws(), owner]
        where = "workspace_code=? AND author=?"
        if after:
            cur.execute(store._q(
                "SELECT updated_at, id FROM studio_conversations"
                " WHERE workspace_code=? AND id=? AND author=?"),
                (_ws(), after, owner))
            anchor = cur.fetchone()
            if anchor is None:
                raise ConvError(400, f"No conversation found for after={after!r}.",
                                "invalid_request_error", param="after")
            a = dict(anchor)
            # Row-value comparison, so the (updated_at, id) tie-break is the
            # same one the ORDER BY uses. Supported by both backends.
            where += f" AND (updated_at, id) {cmp_op} (?, ?)"
            params += [a["updated_at"], a["id"]]
        cur.execute(store._q(
            "SELECT id, role, title, metadata_json, created_at, updated_at"
            f" FROM studio_conversations WHERE {where}"
            f" ORDER BY updated_at {direction}, id {direction} LIMIT ?"),
            (*params, limit + 1))
        rows = [dict(r) for r in cur.fetchall()]
    has_more = len(rows) > limit
    return _list_envelope([_conversation_out(r) for r in rows[:limit]],
                          has_more)


@router.get("/{conv_id}")
def get_conversation(conv_id: str, request: Request,
                     user_id: str = Query(default="")) -> dict:
    owner = _owner(request, user_id)
    store = _store()
    _ensure(store)
    with store._tx() as cur:
        return _conversation_out(_get_owned(store, cur, conv_id, owner))


@router.post("/{conv_id}")
def update_conversation(conv_id: str, body: ConversationUpdate,
                        request: Request) -> dict:
    """Update a thread's metadata or name.

    POST, not PATCH: the standard updates a conversation with POST, and a
    client that knows it should not have to learn a second verb here.

    ``updated_at`` is NOT bumped. It orders the rail by when the thread was
    last WORKED on, and renaming is housekeeping - moving a months-old thread
    to the top of "Today" because its name was tidied would be a lie about what
    happened.
    """
    owner = _owner(request, body.user_id or "")
    store = _store()
    _ensure(store)
    with store._tx() as cur:
        rec = _get_owned(store, cur, conv_id, owner)
        if body.metadata is not None:
            meta = _clean_metadata(body.metadata)
            cur.execute(store._q(
                "UPDATE studio_conversations SET metadata_json=?"
                " WHERE workspace_code=? AND id=?"), (meta, _ws(), conv_id))
            rec["metadata_json"] = meta
        if body.title is not None:
            title = body.title.strip()[:_TITLE_CHARS]
            if not title:
                # An empty name is refused rather than stored: `_touch` fills a
                # blank title from the next question, so accepting "" would arm
                # a silent rename on the following turn rather than clearing
                # the name, which is a different thing from what was asked.
                raise ConvError(400, "A conversation needs a name.",
                                "invalid_request_error", param="title")
            cur.execute(store._q(
                "UPDATE studio_conversations SET title=?"
                " WHERE workspace_code=? AND id=?"), (title, _ws(), conv_id))
            rec["title"] = title
    return _conversation_out(rec)


@router.delete("/{conv_id}")
def delete_conversation(conv_id: str, request: Request,
                        user_id: str = Query(default="")) -> dict:
    """Forget a thread.

    The engine's own session is left alone - it ages out on its own terms, and
    reaching into it from here would couple this table's lifecycle to the
    runtime's.
    """
    owner = _owner(request, user_id)
    store = _store()
    _ensure(store)
    with store._tx() as cur:
        _get_owned(store, cur, conv_id, owner)
        cur.execute(store._q(
            "DELETE FROM studio_conversation_messages"
            " WHERE workspace_code=? AND conversation_id=?"), (_ws(), conv_id))
        cur.execute(store._q(
            "DELETE FROM studio_conversations"
            " WHERE workspace_code=? AND id=?"), (_ws(), conv_id))
    return {"id": conv_id, "object": "conversation.deleted", "deleted": True}


# ── items ────────────────────────────────────────────────────────

def _session_key(conv_id: str, agent: str) -> str:
    """The engine session this thread's memory lives in.

    One key per (conversation, agent), which is what makes N conversations with
    ONE agent hold N separate memories. Namespaced ``conv:`` so it cannot
    collide with the run-scoped (``web:``/``chat:``) or A2A (``a2a:``) keys the
    engine also holds.
    """
    return f"conv:{conv_id}:{agent}"


def _next_seq(store, cur, conv_id: str) -> int:
    cur.execute(store._q(
        "SELECT COALESCE(MAX(seq), 0) AS s FROM studio_conversation_messages"
        " WHERE workspace_code=? AND conversation_id=?"), (_ws(), conv_id))
    return int(dict(cur.fetchone())["s"]) + 1


def _insert_item(store, cur, conv_id: str, seq: int, role: str, content: str,
                 envelope: dict | None = None, run_id: str = "",
                 error: str = "", thoughts: str = "") -> dict:
    item_id = f"msg_{uuid.uuid4().hex}"
    now = _now_iso()
    cur.execute(store._q(
        "INSERT INTO studio_conversation_messages (workspace_code,"
        " conversation_id, seq, id, role, content, envelope_json, run_id,"
        " error, thoughts, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"),
        (_ws(), conv_id, seq, item_id, role, content,
         json.dumps(envelope) if envelope is not None else "",
         run_id or "", error or "", thoughts or "", now))
    return {"seq": seq, "id": item_id, "role": role, "content": content,
            "envelope_json": json.dumps(envelope) if envelope is not None else "",
            "run_id": run_id or "", "error": error or "",
            "thoughts": thoughts or "", "created_at": now}


def _touch(store, cur, conv_id: str, title_seed: str = "") -> None:
    """Bump `updated_at`, and name an untitled thread from its first question."""
    cur.execute(store._q(
        "UPDATE studio_conversations SET updated_at=?"
        " WHERE workspace_code=? AND id=?"), (_now_iso(), _ws(), conv_id))
    if title_seed:
        cur.execute(store._q(
            "UPDATE studio_conversations SET title=?"
            " WHERE workspace_code=? AND id=? AND title=''"),
            (_title_from(title_seed), _ws(), conv_id))


@router.get("/{conv_id}/items")
def list_items(conv_id: str, request: Request,
               limit: int = Query(default=50, ge=1, le=100),
               after: str = Query(default=""),
               order: str = Query(default="asc"),
               user_id: str = Query(default="")) -> dict:
    """The thread's turns.

    Ordered by `seq`, NOT `created_at`: the timestamp is a display value and
    ties at second resolution during a fast exchange, so it cannot order a
    transcript.
    """
    owner = _owner(request, user_id)
    store = _store()
    _ensure(store)
    desc = order.lower() == "desc"
    with store._tx() as cur:
        rec = _get_owned(store, cur, conv_id, owner)
        params: list = [_ws(), conv_id]
        where = "workspace_code=? AND conversation_id=?"
        if after:
            cur.execute(store._q(
                "SELECT seq FROM studio_conversation_messages"
                " WHERE workspace_code=? AND conversation_id=? AND id=?"),
                (_ws(), conv_id, after))
            anchor = cur.fetchone()
            if anchor is None:
                raise ConvError(400, f"No item found for after={after!r}.",
                                "invalid_request_error", param="after")
            where += f" AND seq {'<' if desc else '>'} ?"
            params.append(int(dict(anchor)["seq"]))
        cur.execute(store._q(
            "SELECT seq, id, role, content, envelope_json, run_id, error,"
            " thoughts, created_at FROM studio_conversation_messages"
            f" WHERE {where} ORDER BY seq {'DESC' if desc else 'ASC'} LIMIT ?"),
            (*params, limit + 1))
        rows = [dict(r) for r in cur.fetchall()]
    has_more = len(rows) > limit
    return _list_envelope([_item_out(r, rec["role"]) for r in rows[:limit]],
                          has_more)


@router.post("/{conv_id}/items")
def create_item(conv_id: str, body: ItemCreate, request: Request) -> dict:
    """Append a message WITHOUT running the agent.

    Store-only, as the standard's items are: inference is
    ``POST /{id}/responses``. Splitting them is what makes a streamed turn
    resumable - the question is durable before the agent is asked, so a client
    that never manages to open the stream has not lost what its user typed.
    """
    owner = _owner(request, body.user_id or "")
    if body.role != "user":
        raise ConvError(
            400, "Only a 'user' item may be appended. An assistant turn is "
                 "produced by the agent, never asserted by a caller.",
            "invalid_request_error", param="role")
    content = (body.content or "").strip()
    if not content:
        raise ConvError(400, "content is required.", "invalid_request_error",
                        param="content")
    if len(content) > _MAX_CONTENT:
        raise ConvError(400, f"content exceeds {_MAX_CONTENT} characters.",
                        "invalid_request_error", param="content")
    # GUARDRAILS (engine/guardrails.py): the stored item is the REDACTED
    # text, never the original; a refusal is HTTP 422 before anything is
    # written. No policy = unchanged.
    from ioagentfarm.engine.guardrails import guard_input as _guard_input
    content, _ = _guard_input(content, _ws())
    store = _store()
    _ensure(store)
    with store._tx() as cur:
        rec = _get_owned(store, cur, conv_id, owner)
        seq = _next_seq(store, cur, conv_id)
        item = _insert_item(store, cur, conv_id, seq, "user", content)
    return _item_out(item, rec["role"])


# ── responses: running a turn ────────────────────────────────────

async def _ask_agent(*, agent: str, content: str, ws: str,
                     session_key: str) -> tuple[str, dict | None, str, str]:
    """One turn against the always-on agent surface, IN THIS PROCESS.

    The Studio reached the same handler over HTTP through
    ``engine_routing.engine_json``. Here it is a call: ``adhoc_chat`` never reads
    its ``request`` argument, so there is nothing to fabricate.
    """
    from ioagentfarm.web.app import ChatRequest, adhoc_chat

    req = ChatRequest(
        content=content,
        agent=agent,
        sender_id="conversations",
        # THE SAME VALUE AS THE SESSION KEY, on purpose. `user_id` is the
        # correlation key the engine stamps on the `thought` rows it writes
        # while working, and the progress stream polls `messages` for exactly
        # this string. Two derived values would be a reader and a writer
        # computing the same thing independently - a shape this codebase has
        # already paid for. One value cannot drift.
        user_id=session_key,
        workspace=ws,
        # A PERSON is reading this, in a client that renders the envelope.
        conversation=True,
        # NO `format` KEY. `format: "json"` makes the engine append a prompt
        # suffix demanding a DIFFERENT and poorer schema than the v1 envelope
        # `result_composer` mandates, and being appended last it wins. The
        # symptom was an agent that "ignored its own always:true skill"; the
        # cause was the caller telling it to.
    )
    try:
        data = await adhoc_chat(agent, req, None, session_key=session_key)
    except HTTPException as exc:
        # A failed turn is RECORDED, not lost: the question is already stored,
        # and a thread that silently drops its answer is worse than one that
        # shows what went wrong.
        detail = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
        return "", None, "", str(detail)[:500]
    except Exception as exc:                # noqa: BLE001 - recorded, not raised
        logger.exception("conversation turn failed")
        return "", None, "", str(exc)[:500]

    if not isinstance(data, dict):
        body = getattr(data, "body", None)
        try:
            data = json.loads(body) if body else {}
        except (json.JSONDecodeError, TypeError):
            data = {}

    reply = (data.get("content") or "").strip()
    envelope = data.get("envelope") if isinstance(
        data.get("envelope"), dict) else None
    run_id = str(data.get("id") or "")
    err = str(data.get("error") or "")
    if not reply and not err:
        err = "the agent returned an empty reply"
    return reply, envelope, run_id, err


def _load_question(store, cur, conv_id: str, item_id: str) -> dict:
    cur.execute(store._q(
        "SELECT seq, id, role, content FROM studio_conversation_messages"
        " WHERE workspace_code=? AND conversation_id=? AND id=?"),
        (_ws(), conv_id, item_id))
    row = cur.fetchone()
    if row is None or dict(row)["role"] != "user":
        raise _not_found("user item")
    return dict(row)


def _answer_for(store, cur, conv_id: str, seq: int) -> dict | None:
    """The assistant turn answering `seq`, when it has already been stored."""
    cur.execute(store._q(
        "SELECT seq, id, role, content, envelope_json, run_id, error,"
        " thoughts, created_at FROM studio_conversation_messages"
        " WHERE workspace_code=? AND conversation_id=? AND seq=?"
        " AND role='assistant'"), (_ws(), conv_id, seq + 1))
    row = cur.fetchone()
    return dict(row) if row is not None else None


def _narration_since(user_id: str, last_id: int) -> list[dict]:
    """The narration rows a stream has not sent yet.

    A module-level function because it runs in a worker thread: it must own its
    cursor for the whole call and hand back plain dicts, not one the event loop
    would then have to touch.
    """
    store = _store()
    with store._tx() as cur:
        cur.execute(store._q(
            "SELECT id, content, msg_type FROM messages"
            " WHERE user_id=? AND id>? AND msg_type IN ('thought','preview')"
            " ORDER BY id ASC LIMIT 50"), (user_id, last_id))
        return [dict(r) for r in cur.fetchall()]


@router.post("/{conv_id}/responses")
async def create_response(conv_id: str, body: ResponseCreate,
                          request: Request):
    """Run a turn and return the assistant's item.

    Three ways to call it, and the third is what makes a long turn survivable:

    - ``input`` - append the question and answer it, in one call.
    - ``item_id`` - answer a question already appended by ``POST /items``.
    - ``stream: true`` - the same, as Server-Sent Events.

    A turn that has already been answered REPLAYS instead of running again, so
    a reconnect is safe and costs nothing.
    """
    owner = _owner(request, body.user_id or "")
    store = _store()
    _ensure(store)
    ws = _ws()

    given = (body.input or "").strip()
    if bool(given) == bool(body.item_id):
        raise ConvError(
            400, "Send either `input` (a new question) or `item_id` (one "
                 "already appended), and not both.",
            "invalid_request_error", param="input")
    if given and len(given) > _MAX_CONTENT:
        raise ConvError(400, f"input exceeds {_MAX_CONTENT} characters.",
                        "invalid_request_error", param="input")
    if given:
        # GUARDRAILS (engine/guardrails.py): refused as HTTP 422 before the
        # question is stored; stored REDACTED when the policy says so. The
        # turn itself re-checks inside adhoc_chat, which is idempotent on
        # already-redacted text. No policy = unchanged.
        from ioagentfarm.engine.guardrails import guard_input as _guard_input
        given, _ = _guard_input(given, ws)

    with store._tx() as cur:
        rec = _get_owned(store, cur, conv_id, owner)
        if given:
            seq = _next_seq(store, cur, conv_id)
            question = _insert_item(store, cur, conv_id, seq, "user", given)
        else:
            question = _load_question(store, cur, conv_id, body.item_id)
        settled = _answer_for(store, cur, conv_id, question["seq"])

    agent = rec["role"]
    session_key = _session_key(conv_id, agent)

    if body.stream:
        return _stream_response(request, store, ws, conv_id, agent,
                                session_key, question, settled)

    if settled is not None:
        return _item_out(settled, agent)

    reply, envelope, run_id, err = await _ask_agent(
        agent=agent, content=question["content"], ws=ws,
        session_key=session_key)

    with store._tx() as cur:
        # Re-checked under the write: two callers racing on one question must
        # not both answer it.
        already = _answer_for(store, cur, conv_id, question["seq"])
        if already is not None:
            stored = already
        else:
            stored = _insert_item(store, cur, conv_id, question["seq"] + 1,
                                  "assistant", reply, envelope, run_id, err)
            _touch(store, cur, conv_id, title_seed=question["content"])
    return _item_out(stored, agent)


def _stream_response(request, store, ws, conv_id, agent, session_key,
                     question, settled):
    """The turn as SSE.

    Events: ``response.created``, ``response.thought`` (a step the agent took),
    ``response.output_text.preview`` (the answer, early), ``ping``,
    ``response.completed``.

    A thought is PROGRESS, never the answer. The answer comes from the turn's
    own return value, which already carries the parsed envelope - so a thought
    row that is dropped, duplicated or arrives late cannot corrupt what is
    stored.
    """
    import asyncio

    from sse_starlette.sse import EventSourceResponse

    async def events():
        if settled is not None:
            yield {"event": "response.completed",
                   "data": json.dumps(_item_out(settled, agent))}
            return

        # The high water mark is read BEFORE the agent starts. Without it an
        # earlier turn's thoughts - same key - would replay into this stream.
        with store._tx() as cur:
            cur.execute(store._q(
                "SELECT COALESCE(MAX(id), 0) AS m FROM messages"
                " WHERE user_id=?"), (session_key,))
            last_id = int(dict(cur.fetchone())["m"])

        turn = asyncio.create_task(_ask_agent(
            agent=agent, content=question["content"], ws=ws,
            session_key=session_key))

        yield {"event": "response.created", "data": json.dumps(
            {"conversation_id": conv_id, "item_id": question["id"],
             "x_agent": agent, "created_at": int(time.time())})}

        # Kept, not just forwarded. The reasoning is the only record of HOW an
        # answer was reached, and it was on screen for the minutes the user
        # waited and then thrown away the instant the answer arrived.
        narration: list[str] = []
        quiet = 0.0
        try:
            since_row = 1e9                # nothing has arrived yet
            while not turn.done():
                interval = (_POLL_S if since_row < _POLL_FAST_FOR_S
                            else _POLL_IDLE_S)
                await asyncio.sleep(interval)
                quiet += interval
                since_row += interval
                # A disconnected client does NOT cancel the turn. The agent is
                # already working and its answer is worth storing either way -
                # the alternative is a question in the thread that can never be
                # answered because the reader closed a tab.
                if await request.is_disconnected():
                    break
                # OFF THE EVENT LOOP: the store is synchronous, so reading here
                # would block every other stream this process serves for a
                # remote round trip.
                rows = await asyncio.to_thread(_narration_since, session_key,
                                               last_id)
                if rows:
                    since_row = 0.0
                for r in rows:
                    last_id = max(last_id, int(r["id"]))
                    text = r.get("content") or ""
                    # NOT stripped. A client concatenates these chunks to
                    # rebuild the paragraph the agent is writing, and the
                    # boundaries are exactly where the spaces live.
                    if not text.strip():
                        continue
                    quiet = 0.0
                    if r.get("msg_type") == "preview":
                        # Deliberately NOT appended to `narration`: that becomes
                        # the durable `thoughts` field, and the answer is not a
                        # record of how the answer was reached.
                        yield {"event": "response.output_text.preview",
                               "data": json.dumps({"text": text})}
                        continue
                    narration.append(text)
                    yield {"event": "response.thought",
                           "data": json.dumps({"text": text})}
                if quiet >= _PING_S:
                    quiet = 0.0
                    yield {"event": "ping", "data": "{}"}

            reply, envelope, run_id, err = await turn
        except asyncio.CancelledError:
            raise
        except Exception as exc:            # noqa: BLE001 - recorded, not raised
            logger.exception("conversation turn failed")
            reply, envelope, run_id, err = "", None, "", str(exc)[:500]

        with store._tx() as cur:
            already = _answer_for(store, cur, conv_id, question["seq"])
            if already is not None:
                stored = already
            else:
                stored = _insert_item(
                    store, cur, conv_id, question["seq"] + 1, "assistant",
                    reply, envelope, run_id, err, "".join(narration))
                _touch(store, cur, conv_id, title_seed=question["content"])

        yield {"event": "response.completed",
               "data": json.dumps(_item_out(stored, agent))}

    return EventSourceResponse(events())
