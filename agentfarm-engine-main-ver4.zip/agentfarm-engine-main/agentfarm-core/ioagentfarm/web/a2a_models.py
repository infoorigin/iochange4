"""Pydantic models for the A2A (Agent2Agent) protocol — JSON-RPC 2.0 binding.

Hand-rolled: these are the types this service SERVES, and nothing in the
request path imports the SDK. That is no longer about avoiding a
dependency - `a2a-sdk` is a declared runtime one since 2026-08-30, and
is at 1.x - it is about the served shape staying ours to reason about,
with `tests/test_a2a_streaming_is_spec_shaped.py` holding it against the
generated protobuf field by field.
Field names match the A2A spec v0.3 verbatim so payloads are wire-compatible.

This module is intentionally minimal: only the shapes we actually need for
synchronous `message/send`, `tasks/get`, `tasks/cancel`, and the public
Agent Card. Streaming, push notifications, gRPC/REST bindings are deferred.
"""

from __future__ import annotations

from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# A2A core data types
# ---------------------------------------------------------------------------


# A2A v1.0 Parts use a member-based OneOf (no `kind` discriminator). A Part
# carries exactly one of `text` / `data` / `raw` / `url`; the populated member
# IS the discriminator. We serialize with exclude_none so unset members drop.
class TextPart(BaseModel):
    text: str
    metadata: Optional[dict[str, Any]] = None


class FilePart(BaseModel):
    # v1.0: file bytes/url are flat members, with `mediaType` (was `mimeType`).
    raw: Optional[str] = None       # base64 bytes
    url: Optional[str] = None       # remote file reference
    filename: Optional[str] = None
    mediaType: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None


class DataPart(BaseModel):
    data: dict[str, Any]
    metadata: Optional[dict[str, Any]] = None


Part = Union[TextPart, DataPart, FilePart]


class Message(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: Literal["ROLE_USER", "ROLE_AGENT"]
    parts: list[Part]
    messageId: str
    taskId: Optional[str] = None
    contextId: Optional[str] = None
    referenceTaskIds: Optional[list[str]] = None
    metadata: Optional[dict[str, Any]] = None
    extensions: Optional[list[str]] = None


# A2A v1.0: prefixed SCREAMING_SNAKE_CASE (was lowercase/kebab in v0.3).
TaskState = Literal[
    "TASK_STATE_SUBMITTED",
    "TASK_STATE_WORKING",
    "TASK_STATE_INPUT_REQUIRED",
    "TASK_STATE_COMPLETED",
    "TASK_STATE_CANCELED",
    "TASK_STATE_FAILED",
    "TASK_STATE_REJECTED",
    "TASK_STATE_AUTH_REQUIRED",
    "TASK_STATE_UNKNOWN",
]


class TaskStatus(BaseModel):
    state: TaskState
    message: Optional[Message] = None
    timestamp: Optional[str] = None  # ISO 8601


class Artifact(BaseModel):
    artifactId: str
    name: Optional[str] = None
    description: Optional[str] = None
    parts: list[Part]
    metadata: Optional[dict[str, Any]] = None
    extensions: Optional[list[str]] = None


class Task(BaseModel):
    # Fields mirror the canonical `lf.a2a.v1.Task` protobuf EXACTLY. The
    # official a2a-sdk parses our JSON-RPC result with strict
    # `json_format.ParseDict` (unknown fields raise), so any extra member
    # (`kind`, `createdAt`, `lastModified`, …) breaks every spec client.
    # Proto Task carries only these six — do not add to this list.
    id: str
    contextId: str
    status: TaskStatus
    artifacts: Optional[list[Artifact]] = None
    history: Optional[list[Message]] = None
    metadata: Optional[dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Streaming events (`SendStreamingMessage`)
# ---------------------------------------------------------------------------
#
# FIELD NAMES TAKEN FROM THE PROTO, NOT FROM MEMORY. `a2a-sdk` 1.1.2 was
# installed and its descriptors read:
#
#   lf.a2a.v1.StreamResponse           oneof payload: task | message |
#                                      statusUpdate | artifactUpdate
#   lf.a2a.v1.TaskStatusUpdateEvent    taskId contextId status metadata
#   lf.a2a.v1.TaskArtifactUpdateEvent  taskId contextId artifact append
#                                      lastChunk metadata
#
# That mattered: `TaskStatusUpdateEvent` has NO `final` member, which is what
# a from-memory implementation would have added - and a spec client parses
# our frames with `json_format.ParseDict`, where an unknown field RAISES.
# Same rule as `Task` above: do not add members to these.


class TaskStatusUpdateEvent(BaseModel):
    taskId: str
    contextId: str
    status: TaskStatus
    metadata: Optional[dict[str, Any]] = None


class TaskArtifactUpdateEvent(BaseModel):
    taskId: str
    contextId: str
    artifact: Artifact
    append: Optional[bool] = None
    lastChunk: Optional[bool] = None
    metadata: Optional[dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Agent Card
# ---------------------------------------------------------------------------


class AgentCapabilities(BaseModel):
    streaming: bool = False
    pushNotifications: bool = False
    stateTransitionHistory: bool = False


class AgentSkill(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    tags: list[str] = Field(default_factory=list)
    examples: Optional[list[str]] = None
    inputModes: Optional[list[str]] = None
    outputModes: Optional[list[str]] = None


class AgentProvider(BaseModel):
    organization: str
    url: Optional[str] = None


class AgentInterface(BaseModel):
    """A single protocol endpoint. A2A v1.0 moves `url` + `protocolVersion`
    out of AgentCard and into a `supportedInterfaces[]` array so one agent
    can advertise multiple bindings/versions at distinct URLs.
    """

    url: str
    protocolBinding: str = "JSONRPC"
    protocolVersion: str = "1.0"
    tenant: Optional[str] = None


class AgentCard(BaseModel):
    """Public Agent Card returned from /.well-known/agent-card.json.

    A2A v1.0 shape. `securitySchemes` and `security` are empty here (v1
    runs without auth); add real entries when we move beyond the VPC.
    """

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    description: str
    provider: AgentProvider
    supportedInterfaces: list[AgentInterface] = Field(default_factory=list)
    version: str = "1.0.0"
    capabilities: AgentCapabilities = Field(default_factory=AgentCapabilities)
    defaultInputModes: list[str] = Field(default_factory=lambda: ["text/plain"])
    defaultOutputModes: list[str] = Field(default_factory=lambda: ["text/plain"])
    skills: list[AgentSkill] = Field(default_factory=list)
    securitySchemes: dict[str, Any] = Field(default_factory=dict)
    security: list[dict[str, Any]] = Field(default_factory=list)
    documentationUrl: Optional[str] = None
    iconUrl: Optional[str] = None


# ---------------------------------------------------------------------------
# JSON-RPC 2.0 envelopes
# ---------------------------------------------------------------------------


class JsonRpcRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    jsonrpc: Literal["2.0"]
    id: Optional[Union[str, int]] = None
    method: str
    params: Optional[dict[str, Any]] = None


class JsonRpcError(BaseModel):
    code: int
    message: str
    data: Optional[Any] = None


class JsonRpcResponse(BaseModel):
    jsonrpc: Literal["2.0"] = "2.0"
    id: Optional[Union[str, int]] = None
    result: Optional[Any] = None
    error: Optional[JsonRpcError] = None


# A2A-specific JSON-RPC error codes (-32001 to -32099 reserved by spec).
ERR_PARSE = -32700
ERR_INVALID_REQUEST = -32600
ERR_METHOD_NOT_FOUND = -32601
ERR_INVALID_PARAMS = -32602
ERR_INTERNAL = -32603

ERR_TASK_NOT_FOUND = -32001
ERR_TASK_NOT_CANCELABLE = -32002
ERR_PUSH_NOT_SUPPORTED = -32003
ERR_UNSUPPORTED_OPERATION = -32004
ERR_CONTENT_TYPE_NOT_SUPPORTED = -32005
ERR_INVALID_AGENT_RESPONSE = -32006
