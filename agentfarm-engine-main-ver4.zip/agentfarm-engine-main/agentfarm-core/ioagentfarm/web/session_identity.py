"""Per-session identity for always-on agents (One Truth s3.4, scenario 13).

"A served always-on agent resolves its identity per session, not per
process. Otherwise a ``SOUL.md`` edit lands only when ``serve`` restarts."

What the runtime actually does (read, not assumed - ``iobot/src/iobot/
agent/context.py``): ``AgentLoop._build_initial_messages`` calls
``ContextBuilder.build_messages`` -> ``build_system_prompt`` on EVERY turn,
and that reads ``SOUL.md`` / ``USER.md`` / ``AGENTS.md`` from the workspace
with ``read_text`` each time (``_load_bootstrap_files``); ``SkillsLoader``
holds no cache either - ``get_always_skills`` re-scans ``skills/*/SKILL.md``
and ``load_skills_for_context`` re-reads them per call. Nothing about
identity is captured at ``AgentLoop`` construction except the workspace PATH.

So the whole job is to make the agent HOME current. The pool's ``AgentLoop``
is built once per role over ``iobot_agent_workspace(role)``; this wrapper
re-seeds that home from the installed pack (``ensure_agent_workspace``, which
re-reads the pack template on every call and never touches ``memory/``) the
FIRST time each session key is seen - once per new session, on the pool's
``process_direct`` path, which is every always-on surface (Studio chat, A2A,
Teams, cron). The next turn's system prompt is then built from the refreshed
files: an edit on a checkout reaches the very next session with no restart,
and a pod that ``pip``-upgraded under a running serve (rolling image swap
aside) would too.

Fail-open with a WARNING: a refresh that cannot run (pack gone, disk full)
leaves the session on the home as it stands - an answer from yesterday's
identity beats no answer.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable

from loguru import logger

#: Bound on the seen-set so a pod that mints unbounded session keys (A2A
#: contextIds, warmup ids) cannot grow it forever. Clearing costs at most one
#: redundant refresh per live session - cheap, and correct.
MAX_SEEN_KEYS = 50_000


def session_key_of(args: tuple, kwargs: dict) -> str | None:
    """``process_direct(content, session_key=..., ...)`` - the key is the
    kwarg, or the second positional. Same convention ``pool_limit`` reads."""
    key = kwargs.get("session_key")
    if key is None and len(args) > 1:
        key = args[1]
    return str(key) if key is not None else None


def refresh_agent_home(role: str, workspace_code: str) -> None:
    """Re-seed ``<agent home>/<role>/workspace`` from the installed pack.

    ``ensure_agent_workspace`` re-reads the pack template's identity files
    (SOUL, TOOLS, skills/, a2a-card.yaml) on every call under the One Truth
    seeding rule and preserves ``memory/`` and ``sessions/``.
    """
    from ioagentfarm.engine.workspaces import (ensure_agent_workspace,
                                              iobot_agent_workspace)
    ensure_agent_workspace(role, iobot_agent_workspace(role),
                           workspace_code=workspace_code)


def wrap_with_session_identity(
    process_direct: Callable[..., Awaitable[Any]],
    *,
    role: str,
    workspace_code: str,
    seen: set[tuple[str, str]],
    refresh: Callable[[str, str], None] | None = None,
) -> Callable[..., Awaitable[Any]]:
    """Wrap a bound ``process_direct`` so a NEW session key refreshes the
    agent's home from the installed pack before its first turn.

    *seen* is shared across roles (one set per pool, exposed on
    ``app.state.seen_session_keys``); the memo key is ``(role, session_key)``.
    It is recorded BEFORE the refresh awaits, so two first turns racing on
    one key refresh once. *refresh* is injectable for tests; the default is
    :func:`refresh_agent_home`, run in a worker thread because it is file I/O.
    """
    do_refresh = refresh or refresh_agent_home

    async def refreshed(*args: Any, **kwargs: Any) -> Any:
        key = session_key_of(args, kwargs)
        if key is not None:
            memo = (role, key)
            if memo not in seen:
                if len(seen) >= MAX_SEEN_KEYS:
                    seen.clear()
                seen.add(memo)
                try:
                    await asyncio.to_thread(do_refresh, role, workspace_code)
                    logger.info(
                        "session identity: agent home for role={} refreshed "
                        "from the installed pack for new session {}",
                        role, key)
                except Exception as exc:  # noqa: BLE001 - fail-open by design
                    logger.warning(
                        "session identity: could not refresh agent home for "
                        "role={} (new session {}): {} - the session runs on "
                        "the home as it stands", role, key, exc)
                    # AND TELL THE CALLER. Fail-open is right - a stale home
                    # still answers - but the answer then comes from content
                    # the environment can no longer reproduce. A validator
                    # uninstalled the workspace package and the CLI correctly
                    # reported the agent gone while `serve` kept answering as
                    # it, with nothing in the reply to say so.
                    try:
                        from ioagentfarm.engine import degraded
                        degraded.record(
                            "agent.home_not_refreshed",
                            f"agent '{role}' is answering from a materialized "
                            f"copy that could not be refreshed from its pack "
                            f"({exc}). Its identity and skills may not match "
                            f"what is installed.",
                            scope=role)
                    except Exception:  # noqa: BLE001
                        pass
        return await process_direct(*args, **kwargs)

    return refreshed
