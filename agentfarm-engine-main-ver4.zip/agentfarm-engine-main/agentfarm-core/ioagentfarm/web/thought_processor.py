"""
Classify and sanitize raw iobot thought lines before DB persistence.

Raw thoughts contain sensitive metadata (DB names, column names, internal
file paths, SQL queries). This module transforms them into:
  - Human-readable markdown labels for tool calls (emoji + bold, safe to display)
  - Verbatim LLM reasoning text (the engine thinking out loud)
  - None for pure internal scaffolding (suppressed entirely)
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache


# Domain-neutral default labels. A pack may override any of these (and add
# `api:<endpoint>` display names) via its Pack.labels — so procurement flavor
# ("contract documents", "iCertis") is supplied by the procurement pack, not
# baked into core. See PackRegistry.labels().
_DEFAULT_LABELS: dict[str, str] = {
    "file_read":  "📂 **Reading documents**",
    "doc_search": "🔎 **Searching documents**",
    "data_query": "🔍 **Querying data**",
}


@lru_cache(maxsize=1)
def _labels() -> dict[str, str]:
    merged = dict(_DEFAULT_LABELS)
    try:
        from ioagentfarm.packs import load_registry
        merged.update(load_registry().labels())
    except Exception:
        pass
    return merged


def _label(key: str) -> str:
    return _labels().get(key, _DEFAULT_LABELS.get(key, ""))


@dataclass
class ThoughtEvent:
    type: str   # "reasoning" | "data_query" | "api_call" | "doc_search" | "file_read"
    label: str  # sanitized markdown string — what gets persisted


# Suppress entirely — internal scaffolding, always contains sensitive data
_SUPPRESS_PREFIXES = (
    "list_dir(",
    "write_file(",  # suppresses SQL content (column/table names leak here)
)

# Endpoint flag value → business display name. Populated by the active pack via
# Pack.labels keys of the form `api:<endpoint>` (core ships no domain endpoints).
def _api_display(endpoint: str) -> str:
    return _labels().get(f"api:{endpoint}", "external data source")

# Patterns for stripping sensitive CLI flags / paths from exec commands
_RE_DATABASE = re.compile(r"\s*--database\s+\S+")
_RE_SQL_FILE = re.compile(r"\s*--sql-file\s+\S+")
_RE_TMP_PATH = re.compile(r"~?/[\w./\-]+/(?:\.iof|tmp)/\S*")
_RE_IOF_PATH = re.compile(r"\.iof/instances/\S+")

# Internal CLI binaries — ops we never surface
_INTERNAL_BINS = ("iof-seed", "iof-store", "cat ", "ls ", "mkdir", "cp ", "mv ", "rm ")


def classify_thought(text: str) -> ThoughtEvent | None:
    """
    Transform a raw iobot thought line into a sanitized ThoughtEvent,
    or None to suppress it entirely.

    Call this after the existing _is_noise() filter — it handles a different
    layer (business content vs framework noise).
    """
    # Internal scaffolding: always suppress
    if any(text.startswith(p) for p in _SUPPRESS_PREFIXES):
        return None

    # exec() — extract semantic meaning, strip all sensitive flags/paths
    if text.startswith("exec("):
        return _classify_exec(text)

    # read_file — surface non-internal reads only
    if text.startswith("read_file("):
        path = _extract_arg(text, "path")
        if path and _is_internal_path(path):
            return None
        return ThoughtEvent(
            type="file_read",
            label=_label("file_read"),
        )

    # search — safe to show the query text
    if text.startswith("search("):
        query = _extract_arg(text, "query") or ""
        detail = f" — looking for *{query[:60]}*" if query else ""
        return ThoughtEvent(
            type="doc_search",
            label=f"{_label('doc_search')}{detail}",
        )

    # grep — safe to show the pattern
    if text.startswith("grep("):
        pattern = _extract_arg(text, "pattern") or ""
        detail = f" — scanning for *{pattern[:60]}*" if pattern else ""
        return ThoughtEvent(
            type="doc_search",
            label=f"{_label('doc_search')}{detail}",
        )

    # Generic iobot tool-call label — suppress, already covered by specific rules
    if text.startswith("Tool call:"):
        return None

    # Everything else = LLM reasoning — preserve verbatim
    return ThoughtEvent(type="reasoning", label=text)


def _classify_exec(text: str) -> ThoughtEvent | None:
    cmd = _extract_arg(text, "cmd") or ""

    if "iof-query" in cmd:
        return ThoughtEvent(
            type="data_query",
            label=_label("data_query"),
        )

    if "iof-api" in cmd:
        endpoint = _extract_flag(cmd, "--endpoint")
        display = _api_display(endpoint or "")
        return ThoughtEvent(
            type="api_call",
            label=f"📡 **Fetching data from {display}**",
        )

    if "vectorfs" in cmd:
        return ThoughtEvent(
            type="doc_search",
            label=_label("doc_search"),
        )

    if _is_internal_cmd(cmd):
        return None

    # Unknown exec — sanitize and surface a short label
    sanitized = _strip_sensitive(cmd)
    # If sanitization leaves nothing meaningful, suppress
    if not sanitized or len(sanitized) < 4:
        return None
    return ThoughtEvent(
        type="data_query",
        label=f"⚙️ **Running analysis** — `{sanitized[:80]}`",
    )


# ── helpers ──────────────────────────────────────────────────────────────────

def _extract_arg(text: str, key: str) -> str | None:
    """Extract key="value" or key='value' from a tool call string."""
    m = re.search(rf'{key}=["\']([^"\']*)["\']', text)
    return m.group(1) if m else None


def _extract_flag(cmd: str, flag: str) -> str | None:
    """Extract --flag value from a shell command string."""
    m = re.search(rf"{re.escape(flag)}\s+(\S+)", cmd)
    return m.group(1) if m else None


def _is_internal_path(path: str) -> bool:
    return any(s in path for s in (".iof", "/tmp/", "~/.iobot", "scratch"))


def _is_internal_cmd(cmd: str) -> bool:
    stripped = cmd.strip()
    return any(stripped.startswith(b) for b in _INTERNAL_BINS)


def _strip_sensitive(cmd: str) -> str:
    cmd = _RE_DATABASE.sub("", cmd)
    cmd = _RE_SQL_FILE.sub("", cmd)
    cmd = _RE_TMP_PATH.sub("[workspace]", cmd)
    cmd = _RE_IOF_PATH.sub("[workspace]", cmd)
    return cmd.strip()
