"""User-scoped workspace memory over HTTP: ``/api/users/{user_id}/memory``.

The engine already held a person's durable context - ``aicore memory add
--scope user:<id>`` writes a ``user:<id>`` row into ``workspace_memory``
and `inject.user_block` renders it into that person's turns - but the only
HTTP surface on memory was the per-AGENT ``GET/DELETE
/api/agents/{role}/memory`` (docs/capabilities/evidence/C-chat-state-auth.md,
section 13). An application could not read or write what it knew about its
user without a shell on the engine host.

Three routes, each the CLI's own operation:

* ``GET    /api/users/{id}/memory``        - the active ``user:<id>`` rows,
  serialised as ``aicore memory list --scope user:<id> --json`` prints them,
  plus the count of drafts awaiting a steward.
* ``POST   /api/users/{id}/memory``        - ``{text, durable?, draft?}``,
  through `hooks.add_by_hand` - the SAME function ``aicore memory add``
  calls, so the finding-drop, the PII redaction and the security scan apply
  here exactly as at the terminal. A refused fact is a 422 naming the rail.
* ``DELETE /api/users/{id}/memory/{row}``  - ``aicore memory forget``. A row
  that is not this user's is not found (404), never revealed.

WHOSE MEMORY. With ``IOF_CHAT_BIND_PRINCIPAL=1`` and a verified caller, the
path's ``{user_id}`` must be the bound person (`app._bound_owner`: actor
first, so a Studio proxying for a person binds to the person) - a mismatch
is a 403, never a silent rewrite. Unbound, or with auth off, the path is
trusted as the CLI's ``--scope user:<id>`` is trusted today.
"""
from __future__ import annotations

import os
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

router = APIRouter(tags=["user-memory"])


class MemoryWrite(BaseModel):
    text: str = Field(..., min_length=1, description="The fact, one atomic statement.")
    durable: bool = Field(True, description="False marks the row ephemeral (it expires).")
    draft: bool = Field(False, description="Add as a draft for a steward instead of active.")
    mark: Optional[str] = Field(None, description="permanent | durable | ephemeral; outranks `durable`.")
    actor: Optional[str] = Field(None, description="Audit-trail identity when no verified caller is present.")


def _scope(user_id: str) -> str:
    from ioagentfarm.engine.memory.models import user_scope
    return user_scope(user_id)


def _workspace(request: Request) -> str:
    ws = getattr(request.app.state, "workspace_code", None)
    if not ws:
        from ioagentfarm.engine.workspaces import maybe_workspace_code
        ws = maybe_workspace_code()
    if not ws:
        raise HTTPException(status_code=503, detail="serve has no workspace resolved")
    return str(ws)


def _store():
    """The same `WorkspaceMemoryStore` ``aicore memory`` opens: keyed by the
    database URL, under the engine's state root."""
    from ioagentfarm.web.app import _root
    from ioagentfarm.engine.memory.hooks import memory_store
    return memory_store(_root())


def _verified_caller(request: Request) -> str:
    """The verified caller's identity for the audit trail, or ''."""
    try:
        from ioagentfarm.web.auth import principal_of
        principal = principal_of(request)
    except Exception:  # noqa: BLE001 - auth is optional
        return ""
    if principal is None or getattr(principal, "method", "") == "none":
        return ""
    return (getattr(principal, "actor", "") or getattr(principal, "email", "")
            or getattr(principal, "subject", "") or "")


def _bind(request: Request, user_id: str) -> None:
    """Refuse the request when the principal is bound and names someone else.

    Imported at call time from `web.app` (the router is mounted BY app.py,
    so a module-level import would be circular) - and the source module is
    the one a test patches, as `conversations._owner` documents.
    """
    from ioagentfarm.web.app import _bound_owner
    bound = _bound_owner(request)
    if bound is not None and bound != user_id:
        raise HTTPException(
            status_code=403,
            detail=(f"this request is bound to the verified caller '{bound}'; "
                    f"it cannot read or write memory for '{user_id}'."))


def _actor(request: Request, asserted: Optional[str]) -> str:
    return (_verified_caller(request) or (asserted or "").strip()
            or os.environ.get("IOF_REVIEWER") or "http")


def _row_dict(row) -> dict[str, Any]:
    return row.to_dict()


@router.get("/api/users/{user_id}/memory")
async def get_user_memory(user_id: str, request: Request) -> dict:
    """The active rows of ``user:<id>`` and how many drafts await review."""
    _bind(request, user_id)
    code = _workspace(request)
    store = _store()
    scope = _scope(user_id)
    active = [r for r in store.by_status(code, "active") if r.scope == scope]
    pending = [r for r in store.pending(code) if r.scope == scope]
    return {"workspace": code, "user_id": user_id, "scope": scope,
            "active": [_row_dict(r) for r in active], "pending": len(pending)}


@router.post("/api/users/{user_id}/memory")
async def add_user_memory(user_id: str, body: MemoryWrite, request: Request) -> dict:
    """Add one fact for ``user:<id>`` through the rails - the CLI's path."""
    _bind(request, user_id)
    code = _workspace(request)
    store = _store()
    from ioagentfarm.engine.memory.hooks import add_by_hand
    mark = (body.mark or "").strip() or ("durable" if body.durable else "ephemeral")
    gate, row, outcome = add_by_hand(store, code, fact=body.text, scope=_scope(user_id),
                                     mark=mark, draft=body.draft,
                                     actor=_actor(request, body.actor))
    if gate.dropped or row is None:
        raise HTTPException(status_code=422, detail=f"refused: {gate.reason}")
    return {"workspace": code, "user_id": user_id, "scope": _scope(user_id),
            "outcome": outcome, "row": _row_dict(row), "notes": list(gate.notes)}


@router.delete("/api/users/{user_id}/memory/{row_id}")
async def forget_user_memory(user_id: str, row_id: int, request: Request) -> dict:
    """Retire one of this user's rows - ``aicore memory forget``. The record
    stays; the row is never injected again."""
    _bind(request, user_id)
    code = _workspace(request)
    store = _store()
    row = store.get(code, row_id)
    if row is None or row.scope != _scope(user_id):
        # Not this user's row reads as not found: the surface must not
        # confirm that another person's memory id exists.
        raise HTTPException(status_code=404,
                            detail=f"no memory row #{row_id} for '{user_id}' in workspace {code}")
    outcome = store.forget(code, row_id, actor=_actor(request, None), reason="forgotten over HTTP")
    return {"workspace": code, "user_id": user_id, "id": row_id, "outcome": outcome}
