"""Standalone FastAPI web server for ioagentfarm.

Subprocess-per-run architecture: each workflow run is an independent OS
process (``ioagentfarm run``).  The web server is a thin HTTP layer over
the DB and CLI — it never imports iobot or holds any agent state.
"""
