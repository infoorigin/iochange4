"""The engine web API's authentication — fail-closed, IdP-agnostic.

**This closes backlog I1 / D1.** Until now the engine web API
(``ioagentfarm serve``, port 8111) had *no authentication at all*: anything
that could reach the port created runs in any workspace, read every agent's
memory, and spent money doing it. The documented mitigation was "keep it on an
internal network", which is a deployment convention, not a control — and the
first time an ingress, a port-forward, a service mesh default or a curious
notebook reaches it, the convention is gone with nothing to notice.

WHY A MIDDLEWARE AND NOT ``Depends``
------------------------------------
The Studio API guards its routers with a router-level
``Depends(require_member)``, and the comment there says why: *a new route
cannot be added unguarded*. That works because its routes live in routers.
The engine's do not — ``web/app.py`` declares ~50 routes with bare ``@app.get``
across 4,600 lines, plus seven routers mounted from the lifespan. A dependency
per route is fifty edits today and a silent hole the next time somebody adds
the fifty-first: the failure mode of a forgotten ``Depends`` is a route that
works, for everyone.

A middleware inverts that. Everything is guarded; the exemptions are a short
literal list in one place, and a new route is protected by default — the
failure mode of forgetting becomes a 401 on your own new endpoint, which you
find in the first minute rather than in an audit.

WHAT IS EXEMPT, AND WHY EACH ONE
--------------------------------
``/health`` and ``/ready``
    Kubernetes probes. The kubelet has no identity to present, and an engine
    whose liveness probe 401s is an engine that is restarted forever. They
    disclose nothing but "alive" and "warm".

``OPTIONS`` (any path)
    CORS preflight is ANONYMOUS BY SPEC — the browser sends it precisely to
    ask whether it may send ``Authorization``, so it cannot carry one. The
    Studio API learned this live: refusing the preflight made every call fail
    from a split-origin browser with a bare "Network Error", and no
    TestClient-based test could see it because TestClient does not preflight.
    The real request that follows is still authenticated.

``/a2a/<role>/.well-known/agent-card.json`` — **only when explicitly opened.**
    An Agent Card is *designed* to be publicly discoverable, and a peer often
    reads it before it knows what credential to present. But it also
    enumerates this deployment's agents and their skills, which is
    reconnaissance. Default closed, opened with
    ``IOF_ENGINE_AUTH_PUBLIC_AGENT_CARD=1`` — a deployment that wants open
    discovery says so.

Note what is NOT exempt: ``/docs`` and ``/openapi.json``. They enumerate every
endpoint and its request shape, which is the most useful thing an attacker can
read before doing anything else.

TWO MECHANISMS, ACCEPTED TOGETHER
---------------------------------
``IOF_ENGINE_AUTH`` selects any combination of:

``oidc``
    A bearer JWT from the deployment's identity provider, verified against its
    published JWKS by :mod:`ioagentfarm.security.oidc`. **Microsoft Entra ID**
    in production, **Okta** supported from the same configuration. This is the
    real answer: short-lived, centrally revocable, signed by a third party, and
    it carries WHO — so the audit trail stops saying "someone on the network".

``apikey``
    A shared secret in ``X-IOF-Engine-Key``. For an air-gapped install with no
    reachable IdP, a local stack, or a smoke test. Several keys may be
    configured at once so a rotation is not an outage, and comparison is
    constant-time.

Both can be on during a migration: the rail moves to OIDC while a job that
still holds a key keeps working, and the engine log names which mechanism
admitted each caller so the operator can watch the key fall out of use.

THE STARTUP RULE — the part that makes this hard to get wrong
-------------------------------------------------------------
Configuration alone does not protect anything if the default is open and the
default is what runs. So :func:`assert_safe_to_serve` refuses to start a
**non-loopback** listener with authentication off unless the operator wrote
``IOF_ENGINE_AUTH=off`` themselves. A laptop on 127.0.0.1 is unchanged; a pod
binding 0.0.0.0 either has auth configured or has an explicit, greppable,
reviewable statement that it does not. You cannot arrive at an exposed
unauthenticated engine by forgetting something.

DELEGATION: WHO THE RUN IS ACTUALLY FOR
---------------------------------------
The Studio API calls the engine as itself — a service principal — so without
help the engine learns only "the API called", and every run in the audit trail
belongs to the API. ``X-IOF-Actor`` carries the end user the API already
verified.

It is trusted ONLY from an authenticated caller, and only one holding the
delegation entitlement when one is configured
(``IOF_ENGINE_DELEGATION_ROLE``). That is the standard trusted-subsystem
shape, and its security rests entirely on the header being unreadable from
outside: before this module existed, ``X-IOF-Actor`` would have been a
free-text claim from anyone who could reach the port. It is not
authentication — it is an authenticated service's assertion about its own
user, and the log records both halves (``api@… (for jane@…)``) so neither is
lost.
"""

from __future__ import annotations

import hmac
import logging
import os
import threading
from dataclasses import dataclass

from ioagentfarm.security import oidc
from ioagentfarm.security.oidc import OidcConfig, OidcConfigError, Principal

logger = logging.getLogger(__name__)

#: The env prefix the engine's OIDC verifier reads.
OIDC_ENV_PREFIX = "IOF_ENGINE_OIDC"

#: Header carrying the shared secret in ``apikey`` mode. Deliberately not
#: ``Authorization``: a dedicated header cannot be confused with a JWT by an
#: intermediary, and it is what lets both mechanisms be accepted at once.
API_KEY_HEADER = "X-IOF-Engine-Key"

#: Header by which an authenticated SERVICE names the end user it acts for.
ACTOR_HEADER = "X-IOF-Actor"

#: Paths that answer without a credential. Exact matches only — a prefix test
#: here would make ``/healthy-looking-route`` exempt, and a guard whose
#: exemption list can be extended by naming a route is not a guard.
_EXEMPT_PATHS = frozenset({"/health", "/ready"})

#: Suffix of the A2A public agent card. Matched as a suffix because the role
#: is in the middle of the path; opened only by explicit configuration.
_AGENT_CARD_SUFFIX = "/.well-known/agent-card.json"

#: What a 401 advertises. RFC 6750: a client that gets this knows to go and
#: acquire a bearer token rather than to retry the same anonymous call.
#:
#: THE REALM MUST NOT NAME THE PUBLISHER. It was hardcoded to the internal
#: product name, so every deployment with authentication on announced it
#: to every unauthenticated caller - the one leak a customer cannot fix by
#: editing documentation (found while making the guides safe to hand over,
#: 2026-09-03). The realm now identifies the RESOURCE this deployment
#: guards: its configured audience, which is the value a client needs to
#: request a token for anyway. `IOF_ENGINE_REALM` overrides it; with
#: neither, a neutral name.
_DEFAULT_REALM = "aicore-engine"


def _realm(config=None) -> str:
    explicit = (os.environ.get("IOF_ENGINE_REALM") or "").strip()
    if explicit:
        return explicit
    audience = ""
    try:
        audience = (getattr(getattr(config, "oidc", None), "audience", "")
                    or os.environ.get("IOF_ENGINE_OIDC_AUDIENCE") or "").strip()
    except Exception:  # noqa: BLE001 - a header must never raise
        audience = (os.environ.get("IOF_ENGINE_OIDC_AUDIENCE") or "").strip()
    # A quoted string cannot carry a bare double quote (RFC 7235).
    return (audience or _DEFAULT_REALM).replace('"', "")


def _www_authenticate(config=None) -> str:
    return f'Bearer realm="{_realm(config)}"'


#: Kept for callers that want the plain default; every response builds its
#: own through `_www_authenticate` so the configured audience wins.
_WWW_AUTHENTICATE = f'Bearer realm="{_DEFAULT_REALM}"'


def _how_to_present(config) -> str:
    """The mechanisms this service accepts, as the header to send. The
    shared key's header name was in no client page and the challenge names
    Bearer - the one scheme a key cannot use (novice finding, round 6).
    Says HOW, never which of "no credential / bad credential" applied."""
    ways = []
    mechs = getattr(config, "mechanisms", ()) or ()
    if "apikey" in mechs:
        ways.append(f"the shared key in the {API_KEY_HEADER} header")
    if "oidc" in mechs:
        ways.append("a bearer token (Authorization: Bearer <token>)")
    return "present " + " or ".join(ways) if ways else ""


class EngineAuthError(RuntimeError):
    """The engine's auth configuration cannot work. Raised at startup."""


@dataclass(frozen=True)
class EngineAuthConfig:
    """The engine's inbound policy, resolved once at import/startup."""

    #: ``apikey`` and/or ``oidc``; empty means unauthenticated.
    mechanisms: frozenset[str]
    api_keys: tuple[str, ...] = ()
    oidc_config: OidcConfig | None = None
    #: True when the operator wrote ``IOF_ENGINE_AUTH=off`` rather than simply
    #: leaving everything unset. This is the difference between a stated
    #: decision and an omission, and :func:`assert_safe_to_serve` acts on it.
    explicitly_off: bool = False
    public_agent_card: bool = False
    #: App role/scope a caller must hold to assert ``X-IOF-Actor``. Empty means
    #: any authenticated caller may delegate.
    delegation_role: str = ""

    @property
    def enabled(self) -> bool:
        return bool(self.mechanisms)

    def describe(self) -> dict:
        """Non-secret summary for the startup banner and ``/api/whoami``."""
        out: dict = {
            "enabled": self.enabled,
            "mechanisms": sorted(self.mechanisms) or ["none"],
            "explicitly_off": self.explicitly_off,
            "public_agent_card": self.public_agent_card,
        }
        if self.api_keys:
            # The COUNT, never a key and never a prefix of one.
            out["api_keys_configured"] = len(self.api_keys)
        if self.oidc_config is not None:
            out["oidc"] = self.oidc_config.describe()
        if self.delegation_role:
            out["delegation_role"] = self.delegation_role
        return out


_OFF_WORDS = frozenset({"off", "none", "0", "false", "no", "disabled"})
_VALID_MECHANISMS = frozenset({"apikey", "oidc"})

#: Every variable that changes the policy. :func:`active_config` memoizes on a
#: DIGEST of their values rather than resolving once at import.
#:
#: Import-time resolution was the first shape and it is wrong twice over. A
#: test cannot vary the policy at all — the module is imported once per
#: process and `web/app.py` is imported by half the suite — so the guard would
#: be pinned only in whatever state the first import happened to see. And in
#: production it makes the policy depend on IMPORT ORDER relative to the
#: workspace `.env` load, which is exactly the class of bug this repo has on
#: record several times over ("resolve the workspace before the store").
#:
#: Digest, not the raw values, because IOF_ENGINE_API_KEYS is a secret and a
#: cache key is a place values are readable from.
_POLICY_ENV = (
    "IOF_ENGINE_AUTH", "IOF_ENGINE_API_KEYS", "IOF_ENGINE_API_KEY",
    "IOF_ENGINE_AUTH_PUBLIC_AGENT_CARD", "IOF_ENGINE_DELEGATION_ROLE",
    "IOF_ENGINE_OIDC_ISSUER", "IOF_ENGINE_OIDC_AUDIENCE",
    "IOF_ENGINE_OIDC_TENANT_ID", "IOF_ENGINE_OIDC_JWKS_URI",
    "IOF_ENGINE_OIDC_ALGORITHMS", "IOF_ENGINE_OIDC_REQUIRED_SCOPES",
    "IOF_ENGINE_OIDC_REQUIRED_ROLES", "IOF_ENGINE_OIDC_LEEWAY_S",
    "IOF_ENGINE_OIDC_JWKS_TTL_S",
)

_config_cache: dict[str, "EngineAuthConfig | EngineAuthError"] = {}
_config_lock = threading.Lock()


def _policy_fingerprint(env) -> str:
    import hashlib

    raw = "\x00".join(f"{name}={env.get(name, '')}" for name in _POLICY_ENV)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def active_config(env: dict[str, str] | None = None) -> EngineAuthConfig:
    """The policy in force, memoized per distinct environment.

    A CONFIGURATION ERROR IS CACHED TOO, and re-raised. Not laziness: a
    malformed policy that raised on every request would re-run key-length
    checks and OIDC discovery per request, turning one mistake into a load
    amplifier — while the answer cannot change until the environment does.
    """
    src = os.environ if env is None else env
    key = _policy_fingerprint(src)
    with _config_lock:
        cached = _config_cache.get(key)
    if cached is not None:
        if isinstance(cached, EngineAuthError):
            raise cached
        return cached
    try:
        made: EngineAuthConfig | EngineAuthError = load_config(src)
    except EngineAuthError as exc:
        made = exc
    with _config_lock:
        _config_cache[key] = made
    if isinstance(made, EngineAuthError):
        raise made
    return made


def reset_config_cache() -> None:
    """Forget the memoized policy (tests, and a forced re-read)."""
    with _config_lock:
        _config_cache.clear()


def load_config(env: dict[str, str] | None = None) -> EngineAuthConfig:
    """Resolve the engine's inbound auth policy from the environment.

    Raises :class:`EngineAuthError` on a configuration that cannot be safe —
    a named mechanism with nothing behind it, chiefly. A half-configured
    guard is worse than none, because it is the state in which somebody
    believes the port is protected.
    """
    src = os.environ if env is None else env

    def get(name: str, default: str = "") -> str:
        return (src.get(name, default) or "").strip()

    raw = get("IOF_ENGINE_AUTH")
    explicitly_off = raw.lower() in _OFF_WORDS and raw != ""

    named = {part.strip().lower()
             for part in raw.replace(";", ",").split(",") if part.strip()}
    named -= _OFF_WORDS

    unknown = named - _VALID_MECHANISMS
    if unknown:
        raise EngineAuthError(
            f"IOF_ENGINE_AUTH names unknown mechanism(s) {sorted(unknown)}. "
            "Use 'oidc', 'apikey', both (comma-separated), or 'off'.")

    api_keys: tuple[str, ...] = ()
    if "apikey" in named:
        # Several keys so a rotation overlaps rather than cuts over. Split on
        # comma AND newline: a Kubernetes secret mounted as a file arrives
        # newline-separated and a key list that silently becomes one long
        # key is a rotation that fails closed at the worst moment.
        keys = tuple(k for k in
                     (part.strip() for part in
                      get("IOF_ENGINE_API_KEYS").replace("\n", ",").split(","))
                     if k)
        single = get("IOF_ENGINE_API_KEY")
        if single and single not in keys:
            keys = keys + (single,)
        if not keys:
            raise EngineAuthError(
                "IOF_ENGINE_AUTH names 'apikey' but neither "
                "IOF_ENGINE_API_KEYS nor IOF_ENGINE_API_KEY is set — the "
                "engine would accept every request with any key")
        weak = [k for k in keys if len(k) < 32]
        if weak:
            # Refused, not warned. A short shared secret is brute-forceable
            # over an HTTP endpoint that answers in milliseconds, and a
            # warning in a pod log is read by nobody.
            raise EngineAuthError(
                f"{len(weak)} configured engine API key(s) are shorter than "
                "32 characters. Generate one with "
                "`python -c \"import secrets; print(secrets.token_urlsafe(32))\"`.")
        api_keys = keys

    oidc_config: OidcConfig | None = None
    if "oidc" in named:
        try:
            oidc_config = oidc.config_from_env(OIDC_ENV_PREFIX, env=src)
        except OidcConfigError as exc:
            raise EngineAuthError(
                f"IOF_ENGINE_AUTH names 'oidc' but the verifier cannot be "
                f"built: {exc}") from exc
        if oidc_config is None:
            raise EngineAuthError(
                "IOF_ENGINE_AUTH names 'oidc' but no "
                f"{OIDC_ENV_PREFIX}_* variables are set. Minimum for Entra: "
                f"{OIDC_ENV_PREFIX}_TENANT_ID and {OIDC_ENV_PREFIX}_AUDIENCE. "
                f"For any other provider: {OIDC_ENV_PREFIX}_ISSUER and "
                f"{OIDC_ENV_PREFIX}_AUDIENCE.")

    return EngineAuthConfig(
        mechanisms=frozenset(named),
        api_keys=api_keys,
        oidc_config=oidc_config,
        explicitly_off=explicitly_off,
        public_agent_card=get("IOF_ENGINE_AUTH_PUBLIC_AGENT_CARD") in ("1", "true", "yes"),
        delegation_role=get("IOF_ENGINE_DELEGATION_ROLE"),
    )


# ── the startup rule ─────────────────────────────────────────────────────────

def _is_loopback(host: str) -> bool:
    """Is *host* an address only this machine can reach?

    Conservative on purpose: anything not recognisably loopback counts as
    exposed. Being wrong in this direction costs an operator one explicit
    ``IOF_ENGINE_AUTH=off``; being wrong the other way is the thing this
    module exists to prevent.
    """
    value = (host or "").strip().strip("[]").lower()
    if value in ("localhost", "::1", "127.0.0.1"):
        return True
    if value.startswith("127."):
        return True
    return False


def assert_safe_to_serve(host: str, config: EngineAuthConfig | None = None) -> None:
    """Refuse to bind an exposed listener with authentication off.

    Called by ``serve`` before uvicorn starts. A loopback bind is untouched —
    that is every laptop, every test, every ``client_simulation`` run — and an
    exposed bind must either configure a mechanism or carry an explicit
    ``IOF_ENGINE_AUTH=off``.

    The explicit opt-out is not a loophole, it is the point: there are real
    deployments behind a service mesh doing mTLS, and their operator should be
    able to say so. What is removed is arriving here by *forgetting*.
    """
    cfg = config if config is not None else load_config()
    if cfg.enabled or _is_loopback(host):
        return
    if cfg.explicitly_off:
        logger.warning(
            "ENGINE AUTH IS OFF and this listener binds %s — every caller "
            "that can reach this port can create runs in any workspace. "
            "IOF_ENGINE_AUTH=off was set explicitly, so this is allowed; "
            "make sure something else (a service mesh, a network policy) is "
            "the control.", host)
        return
    # NO COLUMN PADDING. This is printed through rich, which wraps to the
    # console width, and hand-aligned columns come out shredded on any
    # terminal narrower than they assume — turning the one message that has
    # to be followed exactly into something that looks broken. One setting
    # per line instead.
    raise EngineAuthError(
        f"refusing to serve on {host} with no authentication.\n\n"
        "The engine web API creates runs and reads agent memory. Bound to "
        "anything but loopback, it is reachable by whatever shares the "
        "network.\n\n"
        "Configure one of:\n\n"
        "  Microsoft Entra ID\n"
        "    IOF_ENGINE_AUTH=oidc\n"
        "    IOF_ENGINE_OIDC_TENANT_ID=<directory (tenant) id>\n"
        "    IOF_ENGINE_OIDC_AUDIENCE=api://<engine application id uri>\n\n"
        "  Okta, or any OIDC provider\n"
        "    IOF_ENGINE_AUTH=oidc\n"
        "    IOF_ENGINE_OIDC_ISSUER=https://<issuer>\n"
        "    IOF_ENGINE_OIDC_AUDIENCE=<audience>\n\n"
        "  Shared secret\n"
        "    IOF_ENGINE_AUTH=apikey\n"
        "    IOF_ENGINE_API_KEYS=<32+ characters>\n\n"
        "Or state the decision: IOF_ENGINE_AUTH=off "
        "(allowed, and logged loudly on every start).\n"
        "Or bind loopback: --host 127.0.0.1")


# ── authenticating one request ───────────────────────────────────────────────

def _api_key_principal(presented: str, config: EngineAuthConfig) -> Principal | None:
    """Match *presented* against the configured keys, in constant time.

    ``compare_digest`` against EVERY key, with no early exit: a loop that
    breaks on the first match leaks, through timing, how many keys were tried
    — which is a slow read of the key list's shape. The cost is a handful of
    microseconds.
    """
    if not presented:
        return None
    # COMPARE BYTES, NOT STR. `hmac.compare_digest` on two `str` raises
    # `TypeError: comparing strings with non-ASCII characters is not
    # supported` the moment either side holds a byte >= 0x80 - and a header
    # is attacker-controlled. The TypeError escaped this function, the
    # middleware caught only `TokenRejected`, and the generic 500 handler
    # rendered a loguru diagnostic traceback that dumps every local in the
    # frame - INCLUDING `key`, the configured shared secret, in plaintext.
    #
    # A validator did it with one 0xFF byte and counted three copies of the
    # secret in the log after two requests. Anonymous, repeatable, and a
    # log-flood lever besides. The line above this one takes care to log the
    # key COUNT and says "never a key and never a prefix of one"; this path
    # discarded that.
    #
    # Encoding first also keeps the comparison constant-time, which comparing
    # str could not guarantee across encodings.
    try:
        presented_b = presented.encode("utf-8", "surrogatepass")
    except Exception:  # noqa: BLE001 - an unencodable header is simply wrong
        return None
    matched = False
    for key in config.api_keys:
        try:
            if hmac.compare_digest(presented_b, key.encode("utf-8")):
                matched = True
        except Exception:  # noqa: BLE001 - never let a key's own shape raise
            continue
    if not matched:
        return None
    return Principal(
        subject="engine-api-key",
        kind="service",
        issuer="(shared secret)",
        client_id="api-key",
        method="apikey",
    )


def authenticate(headers, config: EngineAuthConfig) -> Principal:
    """The verified caller behind *headers*, or raise.

    ``headers`` is anything with a case-insensitive ``.get`` — Starlette's
    ``Headers``, or a plain dict in a test.

    Raises :class:`oidc.TokenRejected`, whose ``.status`` the caller renders.
    The reason is for the LOG: a client is told only "authentication
    required", because a prober that can tell "expired" from "wrong audience"
    from "unknown key" has been handed a tuning oracle.
    """
    if not config.enabled:
        return Principal(subject="anonymous", kind="service",
                         issuer="(unauthenticated)", method="none")

    tried: list[str] = []

    if "apikey" in config.mechanisms:
        presented = (headers.get(API_KEY_HEADER) or "").strip()
        if presented:
            principal = _api_key_principal(presented, config)
            if principal is not None:
                return principal
            tried.append("api key presented and did not match")
        else:
            tried.append(f"no {API_KEY_HEADER} header")

    if "oidc" in config.mechanisms and config.oidc_config is not None:
        authorization = headers.get("Authorization")
        for token in oidc.iter_bearer(authorization):
            # Let TokenRejected propagate: an expired or wrong-audience token
            # is a SPECIFIC failure worth logging as itself, and falling
            # through to "no credential" would file it as anonymous.
            return oidc.verify(token, config.oidc_config)
        tried.append("no bearer token")

    raise oidc.TokenRejected(
        "no acceptable credential (" + "; ".join(tried) + ")")


def resolve_actor(headers, principal: Principal, config: EngineAuthConfig
                  ) -> Principal:
    """Attach a delegated end user to *principal*, when it may assert one.

    Returns the principal unchanged when there is no actor header, when
    authentication is off (an unauthenticated caller asserting an identity is
    exactly the spoofing this closes), or when a delegation entitlement is
    configured and the caller does not hold it.
    """
    actor = (headers.get(ACTOR_HEADER) or "").strip()
    if not actor or not config.enabled:
        return principal
    if config.delegation_role:
        held = principal.roles | principal.scopes
        if config.delegation_role not in held:
            logger.warning(
                "caller %s asserted %s=%r without the delegation entitlement "
                "%r — the assertion is DROPPED and the call proceeds as the "
                "service itself", principal.label(), ACTOR_HEADER, actor,
                config.delegation_role)
            return principal
    # Length-bounded: this reaches log lines and audit records, and an
    # unbounded header value is a log-injection primitive.
    return Principal(
        subject=principal.subject, kind=principal.kind,
        issuer=principal.issuer, client_id=principal.client_id,
        scopes=principal.scopes, roles=principal.roles,
        email=principal.email, tenant_id=principal.tenant_id,
        claims=principal.claims, method=principal.method,
        actor=actor[:320].replace("\n", " ").replace("\r", " "),
    )


def always_exempt(path: str, method: str) -> bool:
    """Exempt REGARDLESS of policy — decidable without reading configuration.

    Split out from :func:`is_exempt` because the middleware must answer this
    BEFORE it resolves the policy, and that ordering is load-bearing rather
    than tidy. A broken ``IOF_ENGINE_AUTH`` makes the policy unresolvable and
    every request 503; if the probes went through the same path, a typo in one
    variable would become a Kubernetes restart loop — and a pod that restarts
    every thirty seconds destroys the log line explaining what is wrong with
    it. Found by the test that asserts exactly this.

    So: the kubelet can always see the pod, and CORS preflights are always
    answered, whatever state the configuration is in.
    """
    return path in _EXEMPT_PATHS


def is_cors_preflight(method: str, headers) -> bool:
    """A real browser preflight, not merely the OPTIONS verb.

    The exemption used to be `method == "OPTIONS"`, full stop - so an
    anonymous caller could read the whole route table: `OPTIONS /api/whoami`
    answered 405 with `allow: GET`, `OPTIONS /api/run` answered 405 with
    `allow: POST`, and a path that does not exist answered 404. That is
    precisely the reconnaissance this design closed by NOT exempting
    `/openapi.json` ("the most useful thing an attacker can read before doing
    anything else"), reopened through the exemption's own back door - and it
    worked in every configuration state, including a broken policy where
    everything else answers 503.

    A genuine preflight carries `Origin` AND `Access-Control-Request-Method`,
    and is answered by CORSMiddleware with a constant 200 that names no
    route. Requiring both closes the enumeration at zero cost to browsers.
    """
    if method.upper() != "OPTIONS":
        return False
    try:
        return bool(headers.get("origin")
                    and headers.get("access-control-request-method"))
    except Exception:  # noqa: BLE001 - a malformed header set is not a flight
        return False


def is_exempt(path: str, method: str, config: EngineAuthConfig,
              headers=None) -> bool:
    """Does this request answer without a credential? See the module docstring."""
    if headers is not None and is_cors_preflight(method, headers):
        return True
    if always_exempt(path, method):
        return True
    if config.public_agent_card and path.endswith(_AGENT_CARD_SUFFIX):
        return True
    return False


# ── the middleware ───────────────────────────────────────────────────────────

def install(app) -> EngineAuthConfig:
    """Install the guard on *app* and return the resolved policy.

    Registered so it becomes the OUTERMOST middleware: authentication runs
    before anything else can answer, including the deployment-identity
    handshake — whose 409 names this engine's deployment, and which an
    unauthenticated caller therefore should not be able to read.

    Being outside ``CORSMiddleware`` means a refusal from here short-circuits
    before CORS can decorate it, so it carries ``Access-Control-Allow-Origin``
    itself. That is not belt-and-braces: this repo has the failure on record
    twice — a refusal without the header reaches a split-origin browser as a
    bare "Network Error", so the actionable message is invisible to the only
    person who could act on it.
    """
    from fastapi import Request
    from fastapi.responses import JSONResponse

    @app.middleware("http")
    async def _engine_auth(request: Request, call_next):
        # The probes and CORS preflights answer BEFORE the policy is even
        # read — see `always_exempt` for why that ordering matters.
        if always_exempt(request.url.path, request.method):
            request.state.principal = None
            return await call_next(request)

        # Resolved PER REQUEST through the env-fingerprinted memo, not
        # captured here. Capturing would freeze the policy at whatever the
        # environment held when this module was first imported — which is
        # before `serve` loads the workspace `.env` in some orders, and is
        # unvaryable from a test in all of them.
        try:
            config = active_config()
        except EngineAuthError as broken:
            # FAIL CLOSED on a broken policy. The alternative — falling back
            # to "off" — is the single worst outcome available here: a typo in
            # IOF_ENGINE_AUTH would silently open the port, which is the state
            # this whole module exists to make unreachable.
            logger.error("engine auth policy is unusable, refusing every "
                         "request: %s", broken)
            return JSONResponse(
                status_code=503,
                content={"detail": "engine authentication is misconfigured; "
                                   "see the engine log"},
                headers={"Access-Control-Allow-Origin": "*"})

        if is_exempt(request.url.path, request.method, config,
                     request.headers):
            request.state.principal = None
            return await call_next(request)

        try:
            principal = authenticate(request.headers, config)
        except oidc.TokenRejected as rejected:
            # The reason is logged HERE and nowhere else. Everything the
            # client learns is the status and a fixed sentence.
            logger.warning("engine auth refused %s %s from %s: %s",
                           request.method, request.url.path,
                           request.client.host if request.client else "?",
                           rejected.reason)
            detail = ("Forbidden: the credential is valid but not entitled to "
                      "this API." if rejected.status == 403 else
                      "Authentication required.")
            _hint = _how_to_present(config) if rejected.status == 401 else ""
            return JSONResponse(
                status_code=rejected.status,
                content={"detail": detail, **({"hint": _hint} if _hint else {})},
                headers={"WWW-Authenticate": _www_authenticate(config),
                         "Access-Control-Allow-Origin": "*"},
            )
        except Exception as exc:  # noqa: BLE001
            # NOTHING FROM AUTHENTICATION MAY REACH THE GENERIC HANDLER. This
            # block caught only `TokenRejected`, so any other exception - a
            # `TypeError` from a header byte the comparison could not take -
            # escaped to the 500 handler, whose loguru diagnostic renders
            # every local in the frame. One of those locals was the
            # configured shared secret, and an anonymous caller could
            # provoke it at will.
            #
            # The specific cause is fixed above; this is the rail that makes
            # the CLASS safe. Credential handling touches attacker-controlled
            # bytes, so an unexpected failure here must fail CLOSED and
            # quietly: 401 to the caller, the type in the log, and no frame.
            logger.warning(
                "engine auth errored on %s %s from %s: %s - refusing",
                request.method, request.url.path,
                request.client.host if request.client else "?",
                type(exc).__name__)
            return JSONResponse(
                status_code=401,
                content={"detail": "Authentication required."},
                headers={"WWW-Authenticate": _www_authenticate(),
                         "Access-Control-Allow-Origin": "*"},
            )

        request.state.principal = resolve_actor(request.headers, principal,
                                                config)
        return await call_next(request)

    # The posture AT INSTALL, for the log. It is not captured for enforcement
    # (see above) — this line is so a pod's first log page says what the guard
    # was doing, which is the difference between noticing "auth: OFF" and
    # discovering it during an incident.
    #
    # DOES NOT RAISE. `web/app.py` installs this at module import, and the CLI
    # imports that module for reasons unrelated to serving; a broken policy
    # that made the module unimportable would take out commands that never
    # touch the web API, and the operator would see an ImportError rather than
    # the configuration message. The middleware refuses every request with 503
    # regardless — the guard is unaffected, only the reporting is.
    try:
        installed = active_config()
    except EngineAuthError as broken:
        logger.error("engine auth policy is unusable — EVERY request will be "
                     "refused with 503 until it is fixed: %s", broken)
        return EngineAuthConfig(mechanisms=frozenset())
    if installed.enabled:
        logger.info("engine auth ENABLED: %s", installed.describe())
    else:
        logger.warning(
            "ENGINE AUTH IS OFF — every caller that can reach this port can "
            "create runs in any workspace. See IOF_ENGINE_AUTH.")
    return installed


def principal_of(request) -> Principal | None:
    """The verified caller for *request*, or None on an exempt path."""
    return getattr(request.state, "principal", None)
