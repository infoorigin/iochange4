"""FastAPI web server for ioagentfarm — hybrid architecture.

Workflow runs are independent OS processes (subprocess-per-run).
Follow-up messages go to an always-on gateway project_lead (in-process AgentLoop)
via ``process_direct()`` — no lock contention, instant responses.

- GET  /api/workflows                — list available workflows
- GET  /api/agents                   — list agent roles
- POST /api/run                      — create run + spawn background execution
- GET  /api/run/{id}                 — run detail (steps, tasks, goal)
- GET  /api/run/{id}/status          — process + DB status with step counts
- GET  /api/run/{id}/stream          — SSE real-time output
- POST /api/run/{id}/message         — chat (Jarvis routes or @agent direct)
- GET  /api/run/{id}/messages        — conversation history
- POST /api/run/{id}/task            — spawn ad-hoc agent task
- GET  /api/run/{id}/tasks           — list tasks
- GET  /api/run/{id}/tasks/{tid}     — task detail
- GET  /api/run/{id}/steps           — list steps
- GET  /api/run/{id}/steps/{key}     — step detail
- POST /api/run/{id}/steps/{key}/reset  — reset step
- POST /api/run/{id}/steps/{key}/retry  — retry failed step
- POST /api/chat/{workflow}          — ad-hoc chat (no run)
- GET  /api/chat/{workflow}/messages — ad-hoc chat history
- GET  /health                       — health check
"""

from __future__ import annotations

import json
import os
import re
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel

from loguru import logger

from ioagentfarm.web.sse import create_sse_response
from ioagentfarm.web import chat_stream
from ioagentfarm.web.spawn import spawn_run
from ioagentfarm.engine.workspaces import (iobot_agent_workspace,
                                          ensure_iobot_agent, canonical_role)

# Heavy imports — must happen at module level (before uvicorn event loop).
from iobot.config.loader import load_config, set_config_path  # noqa: E402
from iobot.config.schema import ToolsConfig  # noqa: E402  (v0.2.0: replaces web_config+exec_config)
from iobot.bus.queue import MessageBus  # noqa: E402
from iobot.agent.loop import AgentLoop  # noqa: E402
from iobot.session.manager import SessionManager  # noqa: E402
from ioagentfarm.engine.provider_factory import make_provider  # noqa: E402
from ioagentfarm.web.pool_limit import PoolSaturated  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

from ioagentfarm.engine.stream_utils import LineBufferedStream


def _root() -> Path:
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve()


def _get_learning_lifecycle():
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.learning import LearningLifecycle
    db_url = os.getenv("IOF_DATABASE_URL", "")
    adapter = make_adapter(db_url)
    ll = LearningLifecycle(adapter)
    ll.init()
    return ll



_sqlite_fallback_warned = False


def _warn_sqlite_fallback() -> None:
    """Warn ONCE that no IOF_DATABASE_URL was visible, naming the workspace.

    Once per process because `_store()` is called on many request paths and a
    line per call would bury it. Naming the workspace is the point: "no
    database configured" is unremarkable, "workspace X declares a database and
    this process is not using it" is the actual finding.
    """
    global _sqlite_fallback_warned
    if _sqlite_fallback_warned:
        return
    _sqlite_fallback_warned = True
    try:
        from ioagentfarm.engine.workspace_env import workspace_env_path
        from ioagentfarm.engine.workspaces import resolved_workspace_code
        code = resolved_workspace_code()
        env_file = workspace_env_path(code)
        if env_file.is_file() and "IOF_DATABASE_URL" in env_file.read_text(encoding="utf-8", errors="replace"):
            logger.warning(
                "store: IOF_DATABASE_URL is unset, so this process is using a LOCAL "
                "SQLite - but workspace '{}' declares one in {}. Runs, messages and "
                "thoughts written here will not be visible to anything reading that "
                "database. Export IOF_DATABASE_URL, or start via a path that loads "
                "the workspace env.", code, env_file)
            return
        logger.warning(
            "store: IOF_DATABASE_URL is unset; using a local SQLite under IOF_ROOT "
            "(workspace '{}').", code)
    except Exception:
        logger.warning("store: IOF_DATABASE_URL is unset; using a local SQLite under IOF_ROOT.")

def _store():
    from ioagentfarm.engine.store import Store
    from ioagentfarm.engine.db import make_adapter
    root = _root()
    root.mkdir(parents=True, exist_ok=True)
    db_url = os.getenv("IOF_DATABASE_URL", "")
    if not db_url:
        # A LOCAL SQLITE IS A REAL ANSWER FOR A LAPTOP AND THE WRONG ONE FOR A
        # TENANT. Say so, once. When a workspace declares a database and this
        # process cannot see it, every run, message and thought lands here
        # instead — and the Studio API, which reads the workspace's database,
        # shows an empty chain-of-thought panel with nothing failing anywhere.
        # Silence is what made that cost hours; the fallback itself is fine.
        _warn_sqlite_fallback()
        db_url = f"sqlite:///{root / 'state.db'}"
    store = Store(make_adapter(db_url))
    store.init()
    return store


def _run_log_dir(run_id: str) -> Path:
    return _root() / "instances" / run_id / "logs"


# ---------------------------------------------------------------------------
# Agent pool — lazy per-role AgentLoops with shared config
# ---------------------------------------------------------------------------

def _set_inbound_tp(request) -> None:
    """An inbound W3C `traceparent` header parents the chat turn this
    request serves (see engine/otel_export.set_inbound_traceparent). Any
    OTel-aware client - and `iof-consult`, so agent-to-agent calls are one
    trace. Never raises; a no-op with export off."""
    try:
        from ioagentfarm.engine import otel_export as _ex
        _ex.set_inbound_traceparent(request.headers.get("traceparent"))
    except Exception:  # noqa: BLE001
        pass


class AgentPool:
    """Lazy pool of AgentLoops — one per role, shared provider.

    The expensive parts (provider, config, MCP server list) are created
    once.  Each role gets its own AgentLoop with a different workspace,
    created on first request.  Horizontally scalable — each pod has its
    own independent pool, no shared state.
    """

    def __init__(self):
        self._agents: dict[str, object] = {}  # role → AgentLoop
        self._config = None
        self._provider = None
        self._mcp_servers: dict[str, object] = {}  # name → MCPServerConfig
        self._initialized = False
        #: (author, role)-keyed loops over private draft homes — built lazily
        #: (most deployments never mint one). See web/draft_sessions.py.
        self._draft_pool = None
        #: ``(role, session_key)`` pairs whose FIRST turn has already refreshed
        #: the agent's home from the installed pack (One Truth s3.4 — identity
        #: is resolved per SESSION, not per process). Shared across roles;
        #: exposed as ``app.state.seen_session_keys``. See web/session_identity.py.
        self.seen_sessions: set[tuple[str, str]] = set()

    def _init_shared(self):
        """One-time: load config + create provider (shared across all roles)."""
        if self._initialized:
            return

        # Ensure venv binaries are first in PATH so iobot's exec tool
        # spawns the correct ioagentfarm/iobot (venv-local, not system).
        import shutil, sys
        venv_bin = str(Path(sys.executable).parent)
        current_path = os.environ.get("PATH", "")
        if venv_bin not in current_path.split(os.pathsep):
            os.environ["PATH"] = venv_bin + os.pathsep + current_path
            logger.info("Agent pool: prepended venv bin to PATH: {}", venv_bin)

        # Discover bin directories that the parent process can access but
        # which iobot's exec tool would otherwise strip from the subprocess
        # PATH (it strips env to HOME/LANG/TERM and only re-adds path_append).
        # Use shutil.which() against the parent process PATH so we pick up
        # whatever the user has installed locally OR the K8s pod has in its
        # image — no hardcoded paths.
        # NATIVE paths joined with os.pathsep: iobot 0.3.0's ExecTool
        # composes path_append into env["PATH"] with os.pathsep and defaults
        # to PowerShell on Windows — the Git-Bash `/c/...:...` form the 0.1.5
        # `bash -l -c` path needed is garbage there, and made every venv
        # console script invisible to always-on agents on Windows.
        extra_path_parts: list[str] = []
        seen_bin: set[str] = set()
        for binary in ("vectorfs", "node", "npm", "iof-query"):
            located = shutil.which(binary)
            if not located:
                continue
            bin_dir = str(Path(located).parent)
            if bin_dir in seen_bin:
                continue
            seen_bin.add(bin_dir)
            extra_path_parts.append(bin_dir)
            logger.info("Agent pool: found {} bin dir: {}", binary, bin_dir)
        self._extra_path = os.pathsep.join(extra_path_parts)

        # Ensure IOF_ROOT is in env so exec subprocesses find the state dir.
        root_path = _root()
        os.environ["IOF_ROOT"] = str(root_path)
        logger.info("Agent pool: IOF_ROOT={}", root_path)

        gateway_config_path = root_path / "instances" / "gateway" / "config.json"
        config_path = gateway_config_path if gateway_config_path.exists() else None

        if config_path:
            set_config_path(config_path)
        config = load_config(config_path)
        # Set default workspace to project_lead (overridden per-role in get())
        config.agents.defaults.workspace = str(iobot_agent_workspace("project_lead"))

        provider = make_provider(config)

        # MCP servers for in-process agents. AgentLoop reads its OWN
        # `mcp_servers=` kwarg — the ToolsConfig copy handed to it below is
        # never read — and this path bypasses iobot's config env-resolution
        # entirely (load_config does not resolve ${VAR}), so the merged
        # pack -> global -> workspace view is resolved in memory here.
        # connect_mcp_servers reads entries by ATTRIBUTE, so each one must be
        # a validated MCPServerConfig; an invalid entry drops with a warning
        # rather than failing serve startup.
        from iobot.config.schema import MCPServerConfig
        from ioagentfarm.engine.iobot_config import (
            merged_mcp_servers, resolve_mcp_env_refs)
        self._mcp_servers = {}
        for name, spec in resolve_mcp_env_refs(merged_mcp_servers()).items():
            try:
                self._mcp_servers[name] = MCPServerConfig.model_validate(spec)
            except Exception as exc:
                logger.warning("Agent pool: MCP server {} has an invalid "
                               "spec ({}) — skipped", name, exc)
        if self._mcp_servers:
            logger.info("Agent pool: MCP servers available to always-on "
                        "agents: {}", sorted(self._mcp_servers))

        self._config = config
        self._provider = provider
        self._initialized = True

    # Roles that legitimately need install/build commands
    _PERMISSIVE_ROLES = {"developer"}

    # Base deny patterns — applied to ALL roles including developer
    _BASE_DENY_PATTERNS = [
        # Credential access
        r"\.env\b",                          # any .env file access
        r"\bprintenv\b",
        r"\bAWS_SECRET\b",
        r"\bIOF_DATABASE_URL\b",
        r"\bos\.environ\b",                  # Python env access
        r"\bos\.getenv\b",                   # Python env access
        # Process killing
        r"\b(kill|pkill|taskkill|killall)\s",
        # Direct database access
        r"\bpsycopg2\b",
        r"\bsqlite3\b",
        r"\bmysql\.connector\b",
        r"\bSQLAlchemy\b",
        # Skill injection
        r"\bskills\s+(add|install)\b",       # ClawHub / skill registries
    ]

    # Additional deny patterns for non-developer roles
    _INSTALL_DENY_PATTERNS = [
        # Package installation
        r"\bpip\s+install\b",
        r"\bnpm\s+install\b",
        r"\bnpx\s+(?!playwright)",          # allow npx playwright (for exports)
        r"\byarn\s+(add|install)\b",
        r"\bcargo\s+install\b",
        r"\bgem\s+install\b",
        # External downloads
        r"\bcurl\b.*\|\s*(bash|sh|python)",  # curl | bash
        r"\bwget\b.*\|\s*(bash|sh|python)",  # wget | bash
        r"\bgit\s+clone\b",
    ]

    def get(self, role: str) -> object:
        """Get or create an AgentLoop for the given role.

        The slug is canonicalised first, so a retired name (``jarvis``) and
        the current one (``cora``) resolve to ONE pooled agent rather than two
        with divergent sessions and memory.
        """
        role = canonical_role(role)
        # THE BACKSTOP FOR DESK-SIDE ROLES. Every served surface - chat,
        # streamed chat, run follow-ups, A2A, Teams - reaches an agent
        # through this method, so the refusal lives here as well as at each
        # entry point. The first fix was applied to one handler and a
        # validator had already reached the agent through another.
        from ioagentfarm.engine.always_on import is_desk_side
        if is_desk_side(role):
            raise PermissionError(
                f"agent '{role}' is a desk-side role and is not served over "
                "HTTP: it runs shell commands and writes files. Run "
                "`aicore build` at a terminal on the machine that owns the "
                "workspace.")
        if role in self._agents:
            return self._agents[role]

        self._init_shared()

        # The pool serves THIS deployment's workspace — resolved explicitly
        # (fail-closed; serve refused to start without one) so the agent's
        # home and its hydration row can never name different tenants.
        from ioagentfarm.engine.workspaces import resolved_workspace_code
        pod_workspace_code = resolved_workspace_code()
        ensure_iobot_agent(role, workspace_code=pod_workspace_code)
        workspace = iobot_agent_workspace(role)

        agent = self._build_agent_loop(role, workspace, pod_workspace_code)

        # PER-SESSION IDENTITY (One Truth s3.4, scenario 13). iobot rebuilds
        # the system prompt from the workspace FILES on every turn (SOUL.md,
        # USER.md, skills/ are read per call — context.py, skills.py), so the
        # one thing to keep current is the HOME. The first turn of every NEW
        # session key re-seeds it from the installed pack; a SOUL/skill edit on
        # a checkout reaches the very next session with no restart. Outermost
        # wrapper on purpose: the refresh runs before a pool slot is taken.
        from ioagentfarm.web.session_identity import wrap_with_session_identity
        agent.process_direct = wrap_with_session_identity(
            agent.process_direct, role=role, workspace_code=pod_workspace_code,
            seen=self.seen_sessions)

        self._agents[role] = agent
        logger.info("Agent pool: created AgentLoop for role={}", role)
        return agent

    def _build_agent_loop(self, role: str, workspace, workspace_code: str) -> object:
        """One AgentLoop over *workspace* — everything between "the home
        exists" and "the loop can serve": metadata seed, external agents,
        the ctor, tool removal, exec hardening, the learning wrap and the
        pool concurrency ceiling.

        Extracted so the DRAFT pool (web/draft_sessions.py) builds its loops
        through the SAME path as the shared pool — a draft session hardened
        differently from a real one would make Try-it results unreproducible.
        Deliberately EXCLUDED: ``ensure_iobot_agent`` (a draft home is
        materialized by draft_files, never seeded through the shared-home
        path) and ``wrap_with_session_identity`` (its refresh targets the
        SHARED home; pointed at a draft home it would re-seed pack bytes
        over the author's overlay on every new session).
        """
        self._init_shared()

        # Ensure metadata (databases.yml + catalog.yml) are present in the
        # deployed workspace. configure-agent writes these but is run manually;
        # if it hasn't been run yet, copy them from the project metadata dir
        # so iof-query can find the DB connection config on first startup.
        _meta_src = Path(__file__).parent.parent / "metadata" / role
        _meta_dst = Path(workspace) / "metadata"
        _meta_dst.mkdir(parents=True, exist_ok=True)
        for _mf in ("databases.yml", "catalog.yml", "catalog.yaml"):
            _src = _meta_src / _mf
            _dst = _meta_dst / _mf
            if _src.exists() and not _dst.exists():
                import shutil as _shutil
                _shutil.copy2(_src, _dst)
                logger.info("AgentPool: copied {} → {}", _mf, _dst)

        # External A2A agents registered for this workspace (a2a-add) land as
        # metadata/external_agents.yaml — the file the a2a_consult skill
        # reads. Refreshed (or removed, if the registry emptied) on every
        # warmup, which is also why a2a-add takes effect at the NEXT warmup
        # for an already-cached agent.
        try:
            from ioagentfarm.engine.a2a_registry import materialize_external_agents
            materialize_external_agents(Path(workspace))
        except Exception as exc:
            logger.warning("AgentPool: external-agents materialization "
                           "failed for {}: {}", role, exc)

        # Merge discovered bin dirs (vectorfs/node/etc.) into exec.path_append
        # so the bash subprocess that runs exec'd commands can find them.
        exec_cfg = self._config.tools.exec
        if self._extra_path:
            existing = exec_cfg.path_append or ""
            merged = (existing + os.pathsep + self._extra_path).strip(os.pathsep)
            exec_cfg = exec_cfg.model_copy(update={"path_append": merged})

        # An always-on agent's `exec` subprocess is stripped to
        # {HOME, LANG, TERM} like any other, so without this it re-resolves
        # IOF_DATABASE_URL from $HOME/.env — a different database from the one
        # this process is serving. Jarvis then answers "your last run" with a
        # run from someone else's environment, faithfully and wrongly. The
        # per-run path has always applied this; the pool did not.
        from ioagentfarm.engine.iobot_config import PASSTHROUGH_ENV_KEYS
        exec_cfg = exec_cfg.model_copy(update={
            "allowed_env_keys": sorted(set(
                list(exec_cfg.allowed_env_keys or []) + list(PASSTHROUGH_ENV_KEYS)))})

        # iobot 0.2.0: web_config + exec_config consolidated into tools_config: ToolsConfig
        tools_cfg = ToolsConfig(
            web=self._config.tools.web,
            exec=exec_cfg,
            restrict_to_workspace=self._config.tools.restrict_to_workspace,
            mcp_servers=self._config.tools.mcp_servers,
        )

        agent = AgentLoop(
            bus=MessageBus(),
            provider=self._provider,
            workspace=workspace,
            model=self._config.agents.defaults.model,
            max_iterations=self._config.agents.defaults.max_tool_iterations,
            context_window_tokens=self._config.agents.defaults.context_window_tokens,
            tools_config=tools_cfg,
            session_manager=SessionManager(workspace),
            channels_config=self._config.channels,
            # The kwarg AgentLoop actually reads (loop.py stores it as
            # _mcp_servers; tools_config.mcp_servers is ignored). Without it
            # every always-on agent ran with zero MCP servers regardless of
            # what mcp-add configured.
            mcp_servers=self._mcp_servers,
        )

        # Remove tools that agents don't need — saves ~1050 tokens per LLM call.
        # message/spawn are handled by ioagentfarm's orchestration, not iobot's.
        for name in ("message", "spawn"):
            if agent.tools.has(name):
                agent.tools.unregister(name)

        # A CHAT AGENT THAT RUNS NO COMMANDS GETS NO SHELL. Certification
        # round 6 read another user's secret out of a sibling agent's session
        # file through four shell spellings, and showed why a denylist cannot
        # close it: one route wrote a python script and ran it, another built
        # the path from an environment variable and a wildcard, naming no
        # sibling at all. The rail catches the obvious spelling; it cannot
        # catch a shell. What CAN be closed is who has one: a warm
        # conversational agent - the client-facing case - never runs a
        # command, so `exec` is pure exposure for it, while a query agent
        # runs `iof-query` and losing it would be an outage. `needs_exec`
        # asks the agent's OWN content (and, for a query agent, whether data
        # was actually deployed - the seeded `data_query` skill is on
        # everyone and means nothing on its own). Fails OPEN.
        #
        # This REDUCES exposure; it is not containment. An agent that keeps
        # exec can still read what the pod's OS user can read - real
        # containment is OS-level and is recorded in the backlog.
        try:
            from ioagentfarm.engine.output_contract import needs_exec
            if not needs_exec(workspace) and agent.tools.has("exec"):
                agent.tools.unregister("exec")
                logger.info(
                    "pool: role={} runs no commands (no query data, no CLI "
                    "tool named in its skills) - exec removed", role)
        except Exception:                  # noqa: BLE001 - never fail warmup
            logger.debug("pool: exec-need check failed for role=%s", role,
                         exc_info=True)

        # Harden exec tool — base patterns for ALL roles (credentials, process
        # kill, direct DB, skill injection). Install patterns only for non-developer.
        for tool in agent.tools._tools.values():
            if hasattr(tool, 'deny_patterns'):
                tool.deny_patterns.extend(self._BASE_DENY_PATTERNS)
                if role not in self._PERMISSIVE_ROLES:
                    tool.deny_patterns.extend(self._INSTALL_DENY_PATTERNS)
                logger.debug("Exec hardened for role={} ({} deny patterns)", role, len(tool.deny_patterns))

        # Learning: compile GLOBAL team preferences into USER.md at warmup, and
        # make method-learning a property of the AGENT by wrapping process_direct.
        # Both gated — no-op unless IOF_PREFERENCES_DB / IOF_LEARNING_V2.
        from ioagentfarm.engine.learning.hooks import compile_global_prefs, wrap_process_direct
        compile_global_prefs(workspace)
        agent.process_direct = wrap_process_direct(agent.process_direct, role)

        # Workspace memory: materialize the workspace's reviewed context into
        # this agent's home (the runtime renders memory/WORKSPACE_MEMORY.md
        # into the system prompt) and refresh it before every turn, version-
        # gated; extract from each turn afterwards. Returns the callable
        # untouched when IOF_MEMORY is off. See engine/memory/hooks.py.
        from ioagentfarm.engine.memory.hooks import (
            refresh_served_workspace, wrap_with_workspace_memory)
        refresh_served_workspace(_root(), workspace, role=role,
                                 workspace_code=workspace_code)
        agent.process_direct = wrap_with_workspace_memory(
            agent.process_direct, role=role, workspace_code=workspace_code,
            workspace=workspace, root=_root())

        # Pool concurrency ceiling. iobot's own semaphore gates its BUS path
        # only, so process_direct — every always-on surface — is otherwise
        # unbounded. Wrapping here rather than per-router is what makes chat,
        # A2A, Teams and cron all inherit it from one line. UNLIMITED unless
        # IOF_POOL_MAX_CONCURRENCY is set, in which case this returns the
        # callable untouched. See web/pool_limit.py for the ordering rationale.
        from ioagentfarm.web.pool_limit import wrap_with_pool_limit
        agent.process_direct = wrap_with_pool_limit(agent.process_direct)

        # OpenTelemetry: one span per turn, outermost so it includes any wait
        # at the ceiling above - latency as the caller experienced it. Returns
        # the callable untouched when export is off.
        from ioagentfarm.engine.otel_export import wrap_chat
        agent.process_direct = wrap_chat(agent.process_direct, role)

        return agent

    async def get_draft(self, author: str, role: str):
        """The *author*'s draft loop for *role* — pack (+) their overlay.

        Delegates to :class:`~ioagentfarm.web.draft_sessions.DraftPool`,
        which re-reads the author's drafts on EVERY call and rebuilds the
        private home when their signature moved, so a Save lands on the very
        next turn. Returns ``(loop, draft_home, open_drafts)``.
        """
        role = canonical_role(role)
        self._init_shared()
        from ioagentfarm.engine.workspaces import resolved_workspace_code
        if self._draft_pool is None:
            from ioagentfarm.web.draft_sessions import DraftPool
            self._draft_pool = DraftPool(self._build_agent_loop)
        return await self._draft_pool.get(
            author, role, workspace_code=resolved_workspace_code(),
            store=_store())

    @property
    def active_roles(self) -> list[str]:
        return list(self._agents.keys())

    async def shutdown(self):
        for role, agent in self._agents.items():
            try:
                await agent.close_mcp()
                agent.stop()
            except Exception:
                pass
        self._agents.clear()
        # Draft loops hold MCP connections of their own; the shared map above
        # never contained them, so without this a shutdown leaked exactly the
        # loops nobody can reach any more.
        if self._draft_pool is not None:
            try:
                await self._draft_pool.shutdown()
            except Exception:
                pass
            self._draft_pool = None


def _build_run_context(run_id: str, store=None) -> str:
    """Build a concise pipeline status summary + team conversation thread.

    Includes:
    - Pipeline status (steps, statuses, output snippets)
    - Recent team conversation (user messages + agent replies, not internal noise)

    This is injected into follow-up/chat messages so agents are aware they are
    part of a group conversation.  NOT used for step execution (run-step) —
    working agents stay focused on their task prompt.

    ``store``: the caller's open store. Without one this opens its own, which
    is a fresh database connection - 1.36s per chat turn measured against
    RDS from a laptop, and the run-message handler already holds one.
    """
    store = store if store is not None else _store()
    run = store.get_run(run_id)
    if not run:
        return ""

    steps = store.list_steps(run_id)
    if not steps:
        return ""

    status_labels = {"done": "done", "running": "RUNNING", "failed": "FAILED", "pending": "pending"}
    lines = [
        f"[Run context] {run_id} — workflow: {run['workflow_name']}, goal: {run['goal']}",
        f"Run status: {run['status']}",
        f"Project dir: {run.get('project_dir', 'N/A')}",
        "Steps:",
    ]
    for s in steps:
        label = status_labels.get(s["status"], s["status"])
        line = f"  {s['seq']}. {s['step_key']} ({s['role']}) — {label}"
        if s["status"] == "done" and s.get("output_text"):
            snippet = s["output_text"][:200].replace("\n", " ")
            line += f"  output: {snippet}"
        lines.append(line)

    # Team conversation thread — recent meaningful messages (not internal noise)
    try:
        messages = store.get_messages_since(run_id, after_id=0, limit=50)
        # Filter to user messages + agent message replies (skip thoughts, output, feedback_cards)
        chat_msgs = [
            m for m in messages
            if m.get("msg_type") in ("message",) and m.get("content", "").strip()
        ]
        if chat_msgs:
            lines.append("")
            lines.append("Team conversation (recent):")
            for m in chat_msgs[-20:]:  # Last 20 messages max
                source = m.get("source", "")
                if source == "user":
                    speaker = "User"
                elif source == "agent":
                    name = m.get("agent_name") or m.get("role") or "Agent"
                    speaker = f"{name}"
                else:
                    speaker = source
                snippet = m["content"][:300].replace("\n", " ")
                lines.append(f"  [{speaker}] {snippet}")
    except Exception:
        pass  # Best-effort — don't break context if messages table is unavailable

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# App lifecycle — start/stop gateway project_lead
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Envelope extraction
#
# Ported verbatim from the cora_query reference implementation
# (feature/cora-direct-query @ 86b9329). The comments are theirs and record
# failures observed in a pod log, not hypotheticals.
# ---------------------------------------------------------------------------

def _iter_json_objects(text: str):
    """Yield every complete top-level {...} span in `text`, braces balanced.

    Code fences are deliberately NOT used to locate the envelope. Two real
    failure modes in the pod DB prove they cannot be trusted as delimiters:

      - A language-tagged opener (```sql, ```python) precedes the envelope, so
        any regex keyed on ```(json)? pairs fences off by one and loses it.
      - The envelope's own `insight` markdown contains a ``` code block, so the
        fences inside a JSON string are indistinguishable from structural ones
        and positional pairing splits the object mid-string.

    Scanning braces while tracking string state and escapes is immune to both:
    a brace or fence inside a string literal is simply skipped.
    """
    i, n = 0, len(text)
    while i < n:
        start = text.find("{", i)
        if start == -1:
            return
        depth = 0
        in_str = False
        esc = False
        j = start
        while j < n:
            ch = text[j]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            elif ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    yield text[start:j + 1]
                    break
            j += 1
        if j >= n:
            return  # unterminated object; nothing further can close
        i = j + 1


def _looks_like_envelope(cand: dict) -> bool:
    """True when a parsed dict is plausibly a v1 response envelope.

    Used to prefer the real envelope over an unrelated JSON payload the agent
    may also have emitted (e.g. aria returning a negotiation-playbook object).
    """
    if cand.get("schema") == "v1":
        return True
    return any(k in cand for k in ("answer", "data", "insight", "evidence"))


def _extract_envelope_lenient(response: str) -> dict | None:
    """Pull the v1 envelope out of an agent response, tolerating sloppiness.

    Extraction must NOT require the fence to end the response. The original
    regex was anchored (`\\s*$`), so a single trailing character dropped the
    whole payload. Three real shapes were observed failing in one pod log, all
    logged as `envelope=False` and surfaced to callers as `envelope: null`:

      1. cora — valid fenced envelope followed by a one-line evidence footer
      2. aria — a bare JSON object with no code fence at all
      3. aria — plain prose with no envelope (correctly None; an agent-side
         compliance gap, not a parse failure)

    `result_composer` forbids 1 and 2, but prompt compliance is probabilistic
    while this parse is deterministic — so the parser absorbs the violation
    rather than losing the payload. Do NOT re-anchor this to end-of-string.

    Preference order: an envelope-shaped fenced block (last one wins, since an
    agent that narrates a JSON sample first puts the real envelope last), then
    any fenced dict, then the whole response parsed as bare JSON.
    """
    if not response:
        return None

    found: list[dict] = []
    for span in _iter_json_objects(response):
        try:
            cand = json.loads(span)
        except Exception:
            continue
        if isinstance(cand, dict):
            found.append(cand)

    if not found:
        return None
    for cand in reversed(found):
        if _looks_like_envelope(cand):
            return cand
    return found[-1]


def _install_prompt_dumper():
    """Wrap AnthropicProvider._build_kwargs to dump every API call to a JSONL file.

    Enabled by IOF_DUMP_PROMPTS=1. Used for debugging prompt cache hit rates —
    diff two consecutive dumps to find what's varying in the prefix.
    """
    if os.environ.get("IOF_DUMP_PROMPTS", "").lower() not in ("1", "true", "yes"):
        return
    try:
        from iobot.providers.anthropic_provider import AnthropicProvider
    except Exception as exc:
        logger.warning("Cannot install prompt dumper: {}", exc)
        return

    import json
    import time
    from pathlib import Path

    dump_path = Path(_root()) / "prompt_dumps.jsonl"
    dump_path.parent.mkdir(parents=True, exist_ok=True)
    orig_build = AnthropicProvider._build_kwargs

    def _wrapped(self, messages, tools, model, max_tokens, temperature,
                 reasoning_effort, tool_choice, supports_caching=True):
        kwargs = orig_build(self, messages, tools, model, max_tokens, temperature,
                            reasoning_effort, tool_choice, supports_caching)
        try:
            entry = {
                "ts": time.time(),
                "model": kwargs.get("model"),
                "system": kwargs.get("system"),
                "messages": kwargs.get("messages"),
                "tools": kwargs.get("tools"),
            }
            with open(dump_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except Exception as exc:
            logger.warning("prompt dump failed: {}", exc)
        return kwargs

    AnthropicProvider._build_kwargs = _wrapped
    logger.info("Prompt dumper installed -> {}", dump_path)


def _expose_card_declared(pool, workspace_code: str,
                          already: list[str]) -> list[str]:
    """Join card-declared agents to the pool: the agent card IS the switch.

    Any workspace agent whose ``a2a-card.yaml`` declares ``expose: true``
    joins the pool at startup, which is what mounts it on the A2A surface
    (``/a2a/<role>`` mirrors the pool). Creating an agent and authoring its
    card is therefore sufficient to expose it — no deployment env edit.
    ``IOF_ALWAYS_ON_AGENTS`` remains the operator's list; the two union.

    Card-exposed agents are NOT given the two-call cache warmup the
    always-on list gets: exposure declares reachability, not traffic, and a
    workspace may expose many agents. They warm on first call.

    Returns the roles it added (for logs and tests). Never raises — a bad
    card must not stop serve.
    """
    added: list[str] = []
    try:
        from ioagentfarm.web.a2a import exposed_roles
        for role in exposed_roles(workspace_code):
            role = canonical_role(role)
            if role in already or role in added:
                continue
            try:
                pool.get(role)
                added.append(role)
                logger.info("Exposed via agent card: {}", role)
            except Exception as exc:
                logger.warning("Card-declared exposure failed for '{}': {}",
                               role, exc)
    except Exception as exc:
        logger.warning("card-exposure scan failed: {}", exc)
    return added


def _bound_host_of(app) -> str | None:
    """The host this process is actually listening on, if it can be known.

    uvicorn puts its `Config` on the running server, and a programmatic
    `serve` records the host on app.state. When neither is available the
    caller treats it as EXPOSED rather than skipping the check - assuming
    loopback is the assumption that fails open, which is the whole defect
    this guards.
    """
    explicit = getattr(app.state, "bind_host", None)
    if explicit:
        return str(explicit)
    try:
        import os as _os
        env_host = (_os.environ.get("UVICORN_HOST")
                    or _os.environ.get("HOST") or "").strip()
        if env_host:
            return env_host
    except Exception:  # noqa: BLE001
        pass
    try:
        import sys as _sys
        argv = " ".join(_sys.argv)
        if "--host" in argv:
            parts = _sys.argv
            i = parts.index("--host")
            if i + 1 < len(parts):
                return parts[i + 1]
    except Exception:  # noqa: BLE001
        pass
    # Not knowable here. `serve` has already checked, and a process that
    # bypassed it is exactly the one we cannot let through - but refusing on
    # a guess would break embedding and tests, so this returns None and the
    # caller logs the gap instead of failing.
    return None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Start agent pool + sandbox manager on startup.

    Pre-warms agents listed in IOF_ALWAYS_ON_AGENTS (comma-separated).
    Default: just 'cora' (the Core Assistant). Add others per deployment, e.g.
    `IOF_ALWAYS_ON_AGENTS=cora,queryngine` for query-heavy deployments. A
    deployment still naming the retired 'jarvis' keeps working — the slug is
    resolved through `canonical_role`.

    Each pre-warmed agent also receives a ping query to populate the
    Anthropic prompt cache so the first real user request hits a warm cache.
    Failures during pre-warm are logged but never block startup — agents
    are still created lazily on demand if needed.
    """
    # Identity banner: which home/config THIS process resolves. One glance
    # settles the "CLI works but serve-spawned runs fail their first LLM
    # call" class of issue (serve launched under a different user/elevated
    # shell reads a different — usually empty — config.json).
    from ioagentfarm.engine.iobot_config import (
        IOBOT_CONFIG_PATH, read_iobot_config,
    )
    _cfg = read_iobot_config()
    logger.info(
        "serve identity: home={} | iobot config={} (exists={}, providers={}) | IOF_ROOT={}",
        Path.home(), IOBOT_CONFIG_PATH, IOBOT_CONFIG_PATH.exists(),
        sorted((_cfg.get("providers") or {}).keys()) or "NONE",
        os.getenv("IOF_ROOT", ".iof"),
    )

    # FAIL-FAST: serve needs a workspace before it does anything else. A pod
    # that boots without one used to limp into the retired 'default'
    # fallback — its pool agents, catalog writes and run attribution all
    # landed in a workspace nobody chose, silently. Refusing to start is
    # the honest failure, and the message names the one thing to set.
    from ioagentfarm.engine.workspaces import (
        WorkspaceNotSelected, WorkspaceRetired, resolved_workspace_code,
    )
    try:
        _serve_ws = resolved_workspace_code()
    except (WorkspaceNotSelected, WorkspaceRetired) as exc:
        raise SystemExit(
            f"aicore serve refuses to start: {exc}\n"
            "Set IOF_WORKSPACE to this deployment's workspace code (pod "
            "spec / .env), or select one with `aicore workspace use "
            "<code>`.") from exc
    # THE SAFETY RULE BELONGS TO THE APPLICATION, NOT TO ONE COMMAND.
    # `assert_safe_to_serve` had exactly one caller - `aicore serve` - so
    # `uvicorn ioagentfarm.web.app:app --host 0.0.0.0` bound an exposed port
    # with authentication off and answered `GET /api/whoami` 200 anonymously.
    # A validator did precisely that, and it is not an exotic path: gunicorn
    # with uvicorn workers, a manifest naming the module, and the multi-worker
    # shape the horizontal-scaling docs describe all take it.
    #
    # Checked HERE, in the lifespan, where nothing can route around it. The
    # bound host is read from the server when it is available; a process that
    # cannot say what it bound is assumed exposed, because assuming loopback
    # is the assumption that fails open.
    try:
        from ioagentfarm.web.auth import EngineAuthError, assert_safe_to_serve
        _bound = _bound_host_of(app)
        if _bound is not None:
            assert_safe_to_serve(_bound)
    except EngineAuthError as exc:
        logger.error("refusing to serve: {}", exc)
        raise
    except Exception:  # noqa: BLE001 - never fail startup over the probe
        logger.debug("bind-safety check skipped", exc_info=True)

    logger.info("serve workspace: {}", _serve_ws)
    app.state.workspace_code = _serve_ws
    # Bridge the runtime's own warnings into the degradation register, so a
    # problem it detects reaches the caller and `/ready` instead of only a log.
    try:
        from ioagentfarm.engine import degraded as _deg
        _deg.watch_runtime_logs()
    except Exception:  # noqa: BLE001
        logger.debug("degradation bridge not installed", exc_info=True)
    # DID THIS WORKSPACE EXIST WHEN WE STARTED? That is what distinguishes
    # "deleted underneath a running engine" - which must be refused - from
    # "never created, being made lazily on first run", which is a legitimate
    # path the CLI and the tests both use. Presence alone cannot tell them
    # apart; presence AT STARTUP can.
    try:
        app.state.workspace_existed_at_startup = _store().workspace_exists(_serve_ws)
    except Exception:  # noqa: BLE001 - a young database has no table yet
        app.state.workspace_existed_at_startup = False

    # REGISTER WHAT IS RUNNING HERE (One Truth model, docs/one-truth-content-
    # model.md §3.3/§4.2): one `content_registration` row per installed content
    # distribution, stamped with this boot's time and host, BEFORE any agent
    # is materialized from that content. FAIL-OPEN: registration is a record,
    # not a gate — a database hiccup here must never keep the pod from
    # serving, so anything raised is a WARNING and boot continues. The store
    # built for it is reused below (`app.state.store`).
    _boot_store = None
    try:
        import socket as _socket
        from ioagentfarm.engine.content import stamp_line, stamps
        from ioagentfarm.engine.registration import register_content
        _boot_store = _store()
        _items = stamps()
        _host = _socket.gethostname()
        register_content(_boot_store, _serve_ws, host=_host, items=_items)
        logger.info("content registered: {} (workspace {}, host {})",
                    stamp_line(_items), _serve_ws, _host)
    except Exception as exc:
        logger.warning("content registration failed: {} — continuing without "
                       "it (the pod serves; `aicore current` will show no "
                       "registration for this host)", exc)

    # PROVENANCE SELF-REGISTRATION. `agents.pack` is what the Studio scopes
    # each workspace's catalog on, and nothing wrote it any more: `aicore
    # sync` is a One Truth no-op BY DECISION, which quietly took the
    # provenance half down with the content tier. The residue was a required
    # install step living in a curl (`POST /api/agents/sync`) - the first
    # client install shipped with every tenant seeing only platform agents.
    # A Studio button would be wrong too: in the pod topology each engine
    # must account for itself, on its own boot. So serve registers its own
    # packs' provenance here, beside the content registration it already
    # does. Upsert-only (`prune` stays opt-in), so per-workspace pods with
    # different pack sets never delete each other's rows. The endpoint
    # remains for a no-restart refresh.
    try:
        from ioagentfarm.engine.catalog_sync import sync_agents as _startup_sync
        logger.info("provenance self-registered: {} agents",
                    len(_startup_sync(_store())))
    except Exception as exc:
        logger.warning("startup provenance sync failed: {} - the Studio will "
                       "show only platform agents until POST /api/agents/sync "
                       "succeeds", exc)

    # VALIDATE DECLARED CLI TOOLS (One Truth s4.2, scenario 11) — the same
    # check-only pass as `aicore cli-hub check`, over every installed pack's
    # tools.yaml. A binary on PATH is the one host fact no table can supply,
    # and a missing one is far cheaper here than as `command not found` inside
    # the first agent step. FAIL-CLOSED: a gap refuses boot (the RuntimeError
    # propagates out of lifespan, uvicorn reports startup failure and `serve`
    # exits non-zero) with every missing binary and its declaring pack named.
    # IOF_TOOLS_CHECK=warn is the documented escape hatch — logs and boots.
    from ioagentfarm.engine.tools_gate import (DeclaredToolsMissing,
                                               check_declared_tools)
    try:
        # SCOPED TO THE WORKSPACE THIS SERVICE SERVES. One engine venv holds
        # every workspace it serves over its life, so unscoped this refused to
        # boot over a tool declared by somebody else's pack — a workspace that
        # is not being served, whose binary this deployment never needed.
        check_declared_tools(
            workspace_code=getattr(app.state, "workspace_code", None))
    except DeclaredToolsMissing as exc:
        logger.error("aicore serve refuses to start: {}", exc)
        raise

    _install_prompt_dumper()
    pool = AgentPool()
    # The per-session identity memo (web/session_identity.py) lives on the
    # pool; surfaced here so operators/tests can read it off the app.
    app.state.seen_session_keys = pool.seen_sessions
    # ONE implementation, shared with the startup banner. They each worked
    # this out separately and disagreed: the banner read the variable, this
    # inserts the gateway agent unconditionally, and an operator read a line
    # denying two model calls it had just paid for.
    from ioagentfarm.engine.always_on import resolved_always_on
    always_on = resolved_always_on()

    for role in always_on:
        try:
            pool.get(role)
            logger.info("Pre-warmed agent: {}", role)
        except Exception as exc:
            logger.warning("Pre-warm failed for '{}': {} — agent will be created on demand if used", role, exc)

    _expose_card_declared(pool, _serve_ws, already=always_on)

    # Cache pre-warm: send TWO ping queries to each pre-warmed agent so the
    # Anthropic prompt cache (system prompt + skills + embedded catalog) is
    # populated before the first real user request. The first call writes
    # the cache, the second call confirms it reads back. Without this, the
    # first real user pays the full ~30s cold-cache cost on agents with
    # large embedded contexts; after this, all users hit the warm cache
    # at ~12s.
    async def _noop(*args, **kwargs):
        pass

    # Use a unique warmup session id per server start so stale session
    # files from previous runs never accumulate history (which would
    # break Anthropic prompt cache prefix matching for real user calls).
    import time as _time
    warmup_id = f"warmup_{int(_time.time())}"

    for role in always_on:
        agent = pool._agents.get(role)
        if not agent:
            continue

        # Wipe stale warmup session files so the warmup call always starts
        # with empty history, matching the structure of a fresh user call.
        try:
            from ioagentfarm.engine.workspaces import iobot_agent_workspace
            sessions_dir = iobot_agent_workspace(role) / "sessions"
            if sessions_dir.is_dir():
                for stale in sessions_dir.glob("warmup*.jsonl"):
                    stale.unlink()
        except Exception:
            pass

        try:
            # Use the same channel/handlers as adhoc_chat so the LLM call
            # path is identical to a real user request — that's what
            # populates the prompt cache with the right prefix. Two calls:
            # first writes the cache, second confirms it reads back.
            for n in (1, 2):
                await agent.process_direct(
                    "Reply with the single word: ready",
                    session_key=f"{warmup_id}:{role}:{n}",
                    channel="web",
                    chat_id=f"web:chat:{role}",
                    on_progress=_noop,
                    on_stream=_noop,
                )
            logger.info("Cache warmed for agent: {}", role)
        except Exception as exc:
            logger.warning("Cache warmup failed for '{}': {}", role, exc)

    app.state.agent_pool = pool

    # External A2A agent-registry discovery (env-gated; full no-op unless
    # IOF_AGENT_REGISTRY_URL is set). Discovers approved A2A agents from an org
    # registry and writes catalog_dynamic.yaml into the orchestrator agent's
    # workspace so it can route to them. The target agent is named via
    # IOF_REGISTRY_CATALOG_AGENT (core names no domain agent); discovery runs
    # only when that agent is also in the always-on pool. See engine/ainf_registry.py.
    _registry_url = os.environ.get("IOF_AGENT_REGISTRY_URL", "").strip()
    _catalog_agent = os.environ.get("IOF_REGISTRY_CATALOG_AGENT", "").strip()
    if _registry_url and _catalog_agent and _catalog_agent in always_on:
        import asyncio
        from ioagentfarm.engine.ainf_registry import discover_ainf_agents, write_catalog_dynamic
        _reg_api_key = os.environ.get("IOF_AGENT_REGISTRY_API_KEY", "")
        _self_node_id = os.environ.get("IOF_AINF_SELF_NODE_ID", "")
        _reporting_url = os.environ.get("REPORTING_BASE_URL", "http://localhost:8000").rstrip("/") + "/a2a/reporting"
        _refresh_secs = int(os.environ.get("IOF_AGENT_REGISTRY_REFRESH_SECONDS", "300"))

        async def _run_registry_discovery():
            agents = await discover_ainf_agents(_registry_url, _reg_api_key, _self_node_id)
            ws = iobot_agent_workspace(_catalog_agent)
            await write_catalog_dynamic(agents, ws, _reporting_url)

        async def _registry_refresh_loop():
            while True:
                await asyncio.sleep(_refresh_secs)
                try:
                    await _run_registry_discovery()
                except Exception as exc:
                    logger.warning("agent registry refresh failed: {}", exc)

        try:
            await _run_registry_discovery()  # blocking initial catalog write
        except Exception as exc:
            logger.critical("agent registry initial discovery failed: {} — routing degrades until next refresh", exc)
        app.state.registry_refresh_task = asyncio.create_task(_registry_refresh_loop())
        logger.info("Agent registry discovery enabled (agent={}, refresh={}s)", _catalog_agent, _refresh_secs)

    # Initialize sandbox manager when IOF_RUNNER=sandbox
    sandbox_mgr = None
    if os.getenv("IOF_RUNNER", "local").lower() == "sandbox":
        from ioagentfarm.engine.sandbox_manager import init_sandbox_manager
        from ioagentfarm.engine.workflow_loader import WorkflowLoader

        sandbox_mgr = init_sandbox_manager()

        # Prewarm sandboxes for workflows that request it
        try:
            loader = WorkflowLoader()
            prewarm_configs = {}
            for wf_name in loader.list_workflows():
                wf = loader.load(wf_name)
                if wf.sandbox and wf.sandbox.prewarm:
                    prewarm_configs[wf_name] = wf.sandbox
            if prewarm_configs:
                count = sandbox_mgr.prewarm(prewarm_configs)
                logger.info("Pre-warmed {} sandbox(es) at startup", count)
        except Exception as exc:
            logger.warning("Sandbox prewarm failed: {} — sandboxes created on demand", exc)

    app.state.sandbox_manager = sandbox_mgr

    # Expose store on app.state so aria_api endpoints can access it via request
    # (the one built for boot registration above, when that succeeded).
    app.state.store = _boot_store if _boot_store is not None else _store()

    # Background task: periodically clean up idle sandboxes
    import asyncio
    cleanup_task = None
    if sandbox_mgr:
        async def _sandbox_maintenance():
            """Periodic sandbox maintenance: idle cleanup + health checks."""
            tick = 0
            while True:
                await asyncio.sleep(60)  # check every minute
                tick += 1
                try:
                    sandbox_mgr.cleanup_idle()
                except Exception as exc:
                    logger.warning("Sandbox idle cleanup error: {}", exc)

                # Health check every 5 minutes (not every minute)
                if tick % 5 == 0:
                    try:
                        results = sandbox_mgr.health_check_all()
                        dead = [n for n, ok in results.items() if not ok]
                        if dead:
                            logger.warning("Dead sandboxes auto-recovered: {}", dead)
                    except Exception as exc:
                        logger.warning("Sandbox health check error: {}", exc)

        cleanup_task = asyncio.create_task(_sandbox_maintenance())

    # Run supervisor — self-healing for stuck runs ("no run left behind").
    # Sweeps every IOF_SUPERVISOR_INTERVAL_S (default 60): reaps 'running'
    # steps whose executor heartbeat went stale (same transition as
    # `step-retry --crash-recovery`) and resurrects dead drivers for runs
    # with runnable steps waiting (bounded by IOF_SUPERVISOR_MAX_RESUMES →
    # beyond it the run fails with reason supervisor_gave_up). DB-based, so
    # one sweeping pod heals runs spawned by any pod. Kill-switch:
    # IOF_SUPERVISOR=0. See engine/supervisor.py + docs/forensics.md.
    supervisor_task = None
    if os.environ.get("IOF_SUPERVISOR", "1").strip().lower() not in ("0", "false", "no"):
        from ioagentfarm.engine.supervisor import supervise_once as _supervise_once
        _sup_interval = int(os.environ.get("IOF_SUPERVISOR_INTERVAL_S", "60"))

        async def _supervisor_loop():
            while True:
                await asyncio.sleep(_sup_interval)
                try:
                    actions = await asyncio.to_thread(
                        _supervise_once, app.state.store, _root())
                    if actions:
                        logger.warning("Run supervisor actions: {}", actions)
                except Exception as exc:
                    logger.warning("Run supervisor sweep failed: {}", exc)

        supervisor_task = asyncio.create_task(_supervisor_loop())
        logger.info("Run supervisor started (interval={}s)", _sup_interval)
    else:
        logger.info("Run supervisor disabled (IOF_SUPERVISOR=0)")

    # Workspace-memory sweep — the crash-safety net for consolidation. A
    # completed run's consolidation runs detached on the pod that finalized
    # it; if that process dies (pod eviction, OOM, a restart), the run's
    # claim goes stale and THIS loop, on any pod, takes it over. It also
    # retires expired ephemeral rows and re-syncs the curated tiers. Any
    # cadence is safe: the claim table serialises pods. Off with
    # IOF_MEMORY=0; interval IOF_MEMORY_SWEEP_INTERVAL_S (default 300).
    memory_sweep_task = None
    try:
        from ioagentfarm.engine.memory.hooks import enabled as _memory_enabled, sweep as _memory_sweep
        if _memory_enabled():
            _mem_interval = int(os.environ.get("IOF_MEMORY_SWEEP_INTERVAL_S", "300"))
            _mem_ws = getattr(app.state, "workspace_code", None)

            async def _memory_sweep_loop():
                while True:
                    await asyncio.sleep(_mem_interval)
                    try:
                        out = await asyncio.to_thread(
                            _memory_sweep, _root(), app.state.store, _mem_ws)
                        if out.get("consolidated") or out.get("expired"):
                            logger.info("Workspace-memory sweep: {}", out)
                    except Exception as exc:
                        logger.warning("Workspace-memory sweep failed: {}", exc)

            if _mem_ws:
                memory_sweep_task = asyncio.create_task(_memory_sweep_loop())
                logger.info("Workspace-memory sweep started (interval={}s)", _mem_interval)
        else:
            logger.info("Workspace memory disabled (IOF_MEMORY=0)")
    except Exception as exc:  # noqa: BLE001 - never blocks serve startup
        logger.warning("Workspace-memory sweep not started: {}", exc)

    # (Session mode / Savant Strategy Lab removed — this is a workflow-driven
    # solution; the session_engine module was deleted. IOF_SESSION_BRANDS is no
    # longer consulted.)

    # Mount document ingestion API (POST /api/ingest/documents)
    try:
        from ioagentfarm.web.ingest_router import create_ingest_router
        app.include_router(create_ingest_router())
        logger.info("Document ingestion API mounted at /api/ingest")
    except Exception as exc:
        logger.warning("Ingest router init failed: {} — /api/ingest disabled", exc)

    # Mount Teams channel if configured (or emulator mode)
    teams_bot = None
    if os.getenv("TEAMS_APP_ID") or os.getenv("TEAMS_EMULATOR"):
        print("Got env TEAMS variable")
        try:
            from ioagentfarm.channels.teams import create_teams_router
            teams_router = create_teams_router(pool)
            app.include_router(teams_router)
            teams_bot = getattr(teams_router, "teams_bot", None)
            logger.info("Teams channel mounted at /api/teams")
        except Exception as exc:
            logger.warning("Teams channel init failed: {} — Teams disabled", exc)

    # Start background task notification loop (proactive Teams messages on task completion)
    task_notify_loop = None
    if teams_bot:
        task_notify_loop = asyncio.create_task(teams_bot._monitor_tasks_loop())
        logger.info("Task notification loop started")

    # Mount A2A (Agent2Agent) protocol surface. Exposes every always-on
    # agent in the pool as a JSON-RPC 2.0 endpoint + public Agent Card.
    # Thin wrapper over process_direct() — same agent pool, same workspace,
    # same cache-warmed prefix as /api/chat/{workflow}. Default ON; disable
    # via IOF_A2A_ENABLED=false.
    try:
        from ioagentfarm.web.a2a import a2a_enabled, create_a2a_router
        if a2a_enabled():
            app.include_router(create_a2a_router())
            logger.info(
                "A2A mounted at /a2a/<role> — agents: {}",
                ", ".join(sorted(pool._agents.keys())),
            )
    except Exception as exc:
        logger.warning("A2A init failed: {} — A2A disabled", exc)

    # Mount the case-timer listener (/api/case-timers/*) — the intake an
    # external monitoring system calls when a window expires. Mounted ONLY
    # when IOF_TIMER_TOKEN is set: this API carries no authentication of
    # its own, so an unconfigured deployment must expose nothing rather
    # than an open door onto every case.
    try:
        from ioagentfarm.web.case_timers_api import (
            create_case_timer_router, listener_enabled)
        if listener_enabled():
            app.include_router(create_case_timer_router())
            logger.info("Case-timer listener mounted at /api/case-timers "
                        "(token required)")
        else:
            logger.info("Case-timer listener NOT mounted — set "
                        "IOF_TIMER_TOKEN to enable it")
    except Exception as exc:
        logger.warning("Case-timer listener init failed: {}", exc)

    # Mount ARIA business-rules CRUD API (/api/aria/*, /api/vendors/*).
    # ARIA's tables are a procurement DOMAIN feature and are NOT created by
    # core init(); a deployment that turns the ARIA API on ensures them here,
    # so a generic engine DB that never mounts ARIA carries no orphan
    # procurement tables. The read/write methods also self-ensure.
    try:
        from ioagentfarm.web.aria_api import aria_router
        # Ensure on the store the router actually serves from (app.state.store,
        # set above) - its GET endpoints read the aria tables with raw SQL, so
        # they must exist before the first request. The write methods also
        # self-ensure.
        try:
            app.state.store.ensure_aria_schema()
        except Exception as _ax:  # noqa: BLE001
            logger.warning("ARIA schema ensure failed: {}", _ax)
        app.include_router(aria_router)
        logger.info("ARIA rules API mounted at /api/aria and /api/vendors")
    except Exception as exc:
        logger.warning("ARIA rules API init failed: {} — /api/aria disabled", exc)

    # Mark the pod ready: agent pool warmed, cache primed, mounts wired.
    # K8s readinessProbe targets /ready and only routes traffic here once
    # this flips to True. Without this, the first user on a cold pod pays
    # the ~30s cold-cache penalty even though the pod was responding 200
    # on / earlier.
    app.state.ready = True
    logger.info("Lifespan complete — pod is ready to serve traffic.")

    yield

    # Mark pod NOT ready first so the K8s readinessProbe pulls it out of
    # the load balancer rotation BEFORE we tear down resources. Without
    # this, in-flight requests landing during the grace period would hit
    # a half-shutdown agent pool / DB pool.
    app.state.ready = False

    if task_notify_loop:
        task_notify_loop.cancel()
    if teams_bot:
        await teams_bot.shutdown()
    if cleanup_task:
        cleanup_task.cancel()
    if supervisor_task:
        supervisor_task.cancel()
    if memory_sweep_task:
        memory_sweep_task.cancel()
    if sandbox_mgr:
        sandbox_mgr.shutdown()
    await pool.shutdown()

    # Close all pooled DB connections cleanly so PostgreSQL doesn't see a
    # cluster of idle connections lingering on its end past the K8s grace
    # period. Walks every cached adapter (there's typically just one,
    # keyed by IOF_DATABASE_URL).
    try:
        from ioagentfarm.engine.db import reset_adapter_cache
        reset_adapter_cache()
    except Exception:
        logger.exception("Failed to close DB pool on shutdown.")


def _pkg_version() -> str:
    """The installed package's version, for the OpenAPI document.

    Falls back to the import-time constant, and to "0" if even that is gone -
    a version string must never be the reason a service will not start.
    """
    # THE PACKAGE FIRST, THE DISTRIBUTION SECOND. An editable install writes
    # its metadata once, so `importlib.metadata.version` keeps returning the
    # version that was current AT INSTALL TIME - it reported 0.6.4 minutes
    # after the tree became 0.6.5. `__init__.__version__` is read from the
    # source that is actually running. On a wheel the two agree, so nothing
    # is lost by preferring the fresher one.
    try:
        import ioagentfarm
        v = getattr(ioagentfarm, "__version__", "")
        if v:
            return str(v)
    except Exception:  # noqa: BLE001
        pass
    try:
        # Not the shipped name literally: an organisation that republishes
        # the SDK installs it under its own, and a hardcoded lookup then
        # misses and reports "0". `core_dist` resolves the distribution
        # that actually provides this import package.
        from importlib.metadata import version as _v
        from ioagentfarm.engine.content import core_dist
        return _v(core_dist())
    except Exception:  # noqa: BLE001
        return "0"


# THE VERSION IS READ, NOT REPEATED. This literal was `"0.6.3"` while the
# package was 0.6.4, so `/docs` and the OpenAPI document advertised a release
# that had been superseded - the exact failure the backlog's own G3 item warns
# about ("a version bump is part of the change, not paperwork"), realised
# inside the surface a client integrates against. A third copy nobody listed
# is worse than two copies somebody does.
def _docs_urls() -> dict:
    """Whether the interactive API browser is served, and under what title.

    TWO THINGS A CLIENT ASKED FOR, in one place.

    The title said `ioagentfarm` - the IMPORT PACKAGE name, which the product
    has not been called for some time. It is the first word on the Swagger
    page, so it was the product's name to anyone who opened it.
    `IOF_ENGINE_TITLE` overrides it for a deployment that republishes the SDK
    under its own name, the same way the distribution name is not a constant.

    And `/docs`, `/redoc` and `/openapi.json` list every route on the engine.
    They are NOT auth-exempt - a guarded engine answers 401 - but an engine
    with authentication off serves the whole map to anyone who reaches the
    port. `IOF_ENGINE_DOCS=off` withdraws them for a deployment that would
    rather not publish it. They stay ON by default because an engine on
    loopback is a development tool and the browser is most of its value.
    """
    import os
    title = (os.environ.get("IOF_ENGINE_TITLE") or "AI Core Harness Engine")
    off = (os.environ.get("IOF_ENGINE_DOCS") or "").strip().lower() in (
        "off", "0", "false", "no")
    return {
        "title": title,
        "docs_url": None if off else "/docs",
        "redoc_url": None if off else "/redoc",
        "openapi_url": None if off else "/openapi.json",
    }


app = FastAPI(version=_pkg_version(), lifespan=lifespan, **_docs_urls())
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=False,
)

# ENGINE CATALOG (One Truth s4.3): /api/catalog[/agents|/skills|/workflows]
# — what content is INSTALLED HERE, read from the packs on this box, each item
# stamped with its distribution/version/commit. The Studio API pod has no
# filesystem and reads base content through this. Mounted at module level
# (unlike the lifespan-mounted A2A/aria routers) because it needs nothing the
# lifespan builds — no pool, no store — and must answer under a TestClient
# that never ran it; the workspace it answers for is app.state.workspace_code
# once serve set it, else the environment's selection (503 with neither).
from ioagentfarm.web.catalog import router as _catalog_router  # noqa: E402
app.include_router(_catalog_router)
# Draft validation rides the catalog namespace: it answers about the SAME
# installed base the catalog serves, with the same workspace handshake.
from ioagentfarm.web.draft_validate import router as _draft_validate_router  # noqa: E402
app.include_router(_draft_validate_router)
# Conversations: the durable thread layer. Mounted here rather than behind a
# feature flag because a chat UI's ability to hold MORE THAN ONE thread with an
# agent is the reason it moved out of the Studio API - gating it would leave
# the dependency it was moved to remove.
from ioagentfarm.web import conversations as _conversations  # noqa: E402
app.include_router(_conversations.router)
# The standard's error envelope, for this router's routes only. Scoped by
# EXCEPTION TYPE rather than by path: a handler registered for HTTPException
# would silently restyle every other route on the engine.
_conversations.install_error_shape(app)
# Feedback on ONE chat reply (thumbs / correction) on both chat surfaces, and
# its summary. Owner-bound through the conversations router's own helpers.
from ioagentfarm.web import feedback as _feedback  # noqa: E402
app.include_router(_feedback.router)
# Deterministic capability router (POST /api/route) and user-scoped memory
# (/api/users/{id}/memory): engine/router.py and web/user_memory.py. Module
# level, like the catalog - nothing the lifespan builds is needed.
from ioagentfarm.web import route as _route_api, user_memory as _user_memory  # noqa: E402
app.include_router(_route_api.router); app.include_router(_user_memory.router)  # noqa: E702
# Chat guardrails refusals render as their bare body (engine/guardrails.py).
from ioagentfarm.engine import guardrails as _guardrails      # noqa: E402
_guardrails.install_error_shape(app)


def deployment_mismatch(header_value: str | None) -> str | None:
    """The deployment identity handshake — both-set-only, else no check.

    When this engine declares ``IOF_DEPLOYMENT`` (e.g. ``prod``) and a caller
    sends ``X-IOF-Deployment`` with a DIFFERENT value, the call is refused:
    a dev API pointed at a prod engine URL (the misconfiguration the env-only
    topology cannot itself prevent) fails loudly on its first rail call
    instead of silently running dev traffic against prod. Either side unset
    means no check — existing single-deployment stacks are untouched.

    Returns the refusal detail, or ``None`` when the call may proceed.
    """
    ours = os.environ.get("IOF_DEPLOYMENT", "").strip()
    theirs = (header_value or "").strip()
    if not ours or not theirs or ours == theirs:
        return None
    return (f"deployment mismatch: this engine is deployment '{ours}' but "
            f"the caller declared '{theirs}' — the caller's engine routing "
            f"(IOF_ENGINE_URLS / IOF_ENGINE_URL_TEMPLATE / IOF_RUN_API_URL) "
            f"points at the wrong environment")


@app.middleware("http")
async def _deployment_handshake(request: Request, call_next):
    detail = deployment_mismatch(request.headers.get("X-IOF-Deployment"))
    if detail is not None:
        # Registered after CORSMiddleware, so this response short-circuits
        # OUTSIDE it — carry the ACAO header ourselves (allow_origins is "*")
        # or a browser caller sees a bare "Network Error" instead of the
        # refusal (the exact masking bug the API's tenancy middleware had).
        return JSONResponse(status_code=409, content={"detail": detail},
                            headers={"Access-Control-Allow-Origin": "*"})
    return await call_next(request)


# AUTHENTICATION — registered LAST among the middlewares, which makes it the
# OUTERMOST one: nothing else answers before the caller is known. That
# ordering is deliberate rather than incidental. The deployment handshake
# above returns a 409 naming THIS ENGINE'S DEPLOYMENT ("this engine is
# deployment 'prod'"), which is a fact an unauthenticated caller should not be
# able to read; putting auth outside it means they cannot.
#
# Fail-closed: every route is guarded except the K8s probes and CORS
# preflights. See ioagentfarm/web/auth.py for what is exempt and why, and for
# the startup rule that stops an exposed listener from running unauthenticated
# by omission. Backlog I1/D1.
from ioagentfarm.web import auth as _engine_auth  # noqa: E402

ENGINE_AUTH = _engine_auth.install(app)


@app.get("/api/whoami")
async def whoami(request: Request) -> JSONResponse:
    """Who does this engine think you are, and how did it decide?

    The endpoint an operator hits FIRST when a rail 401s, and the one an
    end-to-end test asserts on — because "the call succeeded" does not
    distinguish a verified service principal from an engine that is
    authenticating nobody. It reports the mechanism, the subject, the
    delegated end user, and the entitlements the token actually carried,
    so a scope gate that is passing for the wrong reason is visible.

    Guarded like everything else: with auth ON this needs a credential, so it
    is also the cheapest proof that the guard is installed at all.
    """
    principal = _engine_auth.principal_of(request)
    # The LIVE policy, not the one captured at install: this endpoint's job is
    # to answer "what is this engine doing right now", and a cached answer is
    # the one thing it must not give.
    return JSONResponse({
        "authenticated": bool(principal and principal.method != "none"),
        "policy": _engine_auth.active_config().describe(),
        "principal": None if principal is None else {
            "subject": principal.subject,
            "kind": principal.kind,
            "issuer": principal.issuer,
            "client_id": principal.client_id,
            "email": principal.email,
            "tenant_id": principal.tenant_id,
            "scopes": sorted(principal.scopes),
            "roles": sorted(principal.roles),
            "method": principal.method,
            "actor": principal.actor,
            "label": principal.label(),
        },
    })


@app.exception_handler(KeyError)
async def _missing_row_handler(request: Request, exc: KeyError):
    """`Store.get_run` RAISES KeyError for an unknown id. Three routes tested
    a falsy return that never comes and answered 500 with a traceback, so a
    monitor could not tell "gone" from "broken" (novice finding, round 6).
    A run-shaped key is 404; anything else stays an engine error."""
    key = exc.args[0] if exc.args else ""
    if isinstance(key, str) and key.startswith("run_"):
        return JSONResponse(status_code=404,
                            content={"detail": f"No run '{key}' in this database."})
    return await _unhandled_error_handler(request, exc)


@app.exception_handler(Exception)
async def _unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
    """Unhandled exceptions become JSON 500s that traverse the middleware.

    Starlette's default ServerErrorMiddleware short-circuits OUTSIDE
    CORSMiddleware, so a raw 500 reaches a split-origin browser with no
    Access-Control-Allow-Origin and renders as a bare 'Failed to fetch' -
    the real traceback invisible to the person who could report it. Found
    live: a run-creation TypeError surfaced in the browser as a generic
    network error. The handler logs the traceback and returns a JSON body
    naming the engine log as the place to look.

    THE HEADER IS SET EXPLICITLY, and the comment that used to stand here -
    "a JSON body (which DOES pass through CORS)" - was wrong. Measured in
    both services: an exception handler runs on ServerErrorMiddleware, which
    is OUTSIDE CORSMiddleware, so its response carries no
    `Access-Control-Allow-Origin` however well-formed the body is, and the
    browser still reports a CORS failure with the detail invisible. The body
    was only ever readable to someone reading the pod log. `allow_origins`
    is `*` here, so `*` is the honest echo.
    """
    logger.exception("Unhandled error on {} {}", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        headers={"Access-Control-Allow-Origin": "*"},
        content={"detail": f"engine error: {type(exc).__name__}: {exc}. "
                           "The engine log carries the traceback."})


@app.exception_handler(PoolSaturated)
async def _pool_saturated_handler(request: Request, exc: PoolSaturated) -> JSONResponse:
    """Map a refused pool slot to 503 + Retry-After.

    FALLBACK ONLY — no current surface reaches it. Verified against a live pod
    capped at 1: ``/a2a/<role>`` renders saturation as a JSON-RPC -32603 error
    and ``/api/chat/*`` as HTTP 200 with an ``error`` field, because both catch
    broadly around ``process_direct`` before the exception can propagate here.
    Kept so that a route which does NOT swallow it degrades correctly rather
    than as a 500, but do not describe the API as "returning 503 when
    saturated" — today it does not. See ``PoolSaturated`` for the shapes
    callers actually receive.
    """
    return JSONResponse(
        status_code=503,
        headers={"Retry-After": "5"},
        content={
            "error": "agent_pool_saturated",
            "detail": str(exc),
            "limit": exc.limit,
            "waited_s": round(exc.waited_s, 1),
        },
    )


# ---------------------------------------------------------------------------
# Health + readiness probes (for K8s)
# ---------------------------------------------------------------------------
#
# /health  — liveness probe. Returns 200 as long as the process is alive
#            and FastAPI is dispatching requests. K8s should restart the
#            pod if this fails. Never returns 503.
# /ready   — readiness probe. Returns 200 only after lifespan completes
#            (agent pool created, agents pre-warmed, prompt cache primed,
#            session router mounted). Until then returns 503 — K8s
#            keeps traffic away from cold pods. Critical for HPA
#            scale-up where new pods take ~30s to be useful.

@app.get("/health")
async def health_check() -> JSONResponse:
    """Liveness — process is alive. Used by K8s livenessProbe."""
    return JSONResponse({"ok": True}, status_code=200)


@app.get("/ready")
async def readiness_check(request: Request) -> JSONResponse:
    """Readiness — pod is ready for traffic. Used by K8s readinessProbe."""
    is_ready = bool(getattr(request.app.state, "ready", False))
    if not is_ready:
        return JSONResponse(
            {"ok": False, "ready": False, "reason": "lifespan still warming"},
            status_code=503,
        )
    pool = getattr(request.app.state, "agent_pool", None)
    body = {
        "ok": True,
        "ready": True,
        "agents_warmed": pool is not None,
    }
    # DEGRADATIONS ARE PART OF READINESS. A validator left an engine that
    # answered every chat turn with an error, and `/ready` said
    # `{"ready": true, "agents_warmed": true}` throughout - so a load balancer
    # kept routing to it. Readiness that cannot say "I am serving wrong
    # answers" is a liveness check wearing the wrong name.
    #
    # Still 200 and still ready: the pod IS serving, and taking it out of
    # rotation over a single unreadable session would turn one bad
    # conversation into an outage. What changes is that the condition is
    # visible to whoever looks.
    try:
        from ioagentfarm.engine import degraded as _deg
        _warn = _deg.warnings_for()
        if _warn:
            body["degraded"] = _deg.is_degraded()
            body["warnings"] = _warn
    except Exception:  # noqa: BLE001 - readiness must not depend on this
        pass
    return JSONResponse(body, status_code=200)


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ResumeRequest(BaseModel):
    #: Resume even though the run's driver heartbeat looks live, or the run
    #: is failed (concluded, not interrupted). The CLI's ``--force``.
    force: bool = False


class CancelRequest(BaseModel):
    reason: str = ""


class RunRequest(BaseModel):
    workflow: str
    goal: str
    project_dir: str | None = None
    user_id: str | None = None
    #: Tenant workspace code (iof.workspaces.code). None -> IOF_WORKSPACE env.
    #: There is NO fallback beyond that: a request that names no workspace on
    #: a pod with none configured is refused with a 400 — the platform never
    #: invents a tenant.
    workspace: str | None = None
    #: Per-run workflow var overrides — the HTTP equivalent of the CLI's
    #: repeatable ``--var KEY=VALUE``. Persisted to the instance dir's
    #: workflow_vars.json exactly like the CLI path, so the scheduler picks
    #: them up identically regardless of which surface created the run.
    variables: dict[str, str] | None = None
    #: Which control plane drives the run: ``agent`` (project_lead, the
    #: default) or ``code`` (the deterministic driver - ``aicore run --driver
    #: code``). The field did not exist and a caller's ``driver`` was
    #: silently dropped: every API-created run of an exec-only pipeline paid
    #: an LLM orchestrator (novice finding, round 6). Validated: anything
    #: else is 422.
    driver: str | None = None
    #: DRAFT RUN: resolve this author's open drafts on top of the pack for
    #: this run and nothing else (One Truth s3.5). The Studio API supplies
    #: the verified identity email — the engine has no auth, so trusting
    #: this field is the caller's contract, same as ``user_id``. None (every
    #: ordinary caller) leaves the run byte-identical to today.
    draft_author: str | None = None


def _run_workspace_code(explicit: str | None) -> str:
    """Resolve the tenant workspace code for run creation — fail-closed.

    Explicit request field > ``IOF_WORKSPACE`` env. Nothing else: the old
    'universal fallback contract' resolved missing AND malformed codes to
    ``default``, which is how a run could land in a workspace nobody chose
    and why "which workspace served this answer?" had no answer. Missing or
    malformed or retired now raises ``HTTPException(400)`` naming the fix.
    """
    from ioagentfarm.engine.workspaces import (RETIRED_WORKSPACE_CODES,
                                               WORKSPACE_CODE_RE)
    code = (explicit or os.getenv("IOF_WORKSPACE") or "").strip()
    if not code:
        raise HTTPException(
            status_code=400,
            detail="workspace is required: name it in the request "
                   "('workspace': '<code>') or set IOF_WORKSPACE on the "
                   "server. The platform never supplies a workspace on the "
                   "caller's behalf.")
    if not WORKSPACE_CODE_RE.match(code):
        raise HTTPException(
            status_code=400,
            detail=f"invalid workspace code {code!r}: expected "
                   "[a-z][a-z0-9_-]{1,40}")
    if code in RETIRED_WORKSPACE_CODES:
        raise HTTPException(
            status_code=400,
            detail="the 'default' workspace is retired. Create a named "
                   "workspace (aicore workspace create <code>) and adopt "
                   "existing data with: aicore workspace rename default "
                   "<code>")
    return code


def _workspace_code_for_run(store, run: dict) -> str | None:
    """The workspace a run row is attributed to, or None if unattributed.

    Reads ``runs.workspace_id`` back through the workspaces registry — the
    single source for "which tenant does this run belong to". Retired codes
    count as unattributed: a row stamped under the old fallback names a
    workspace that can no longer execute anything.
    """
    from ioagentfarm.engine.workspaces import RETIRED_WORKSPACE_CODES
    ws_id = run.get("workspace_id")
    if not ws_id:
        return None
    try:
        row = store.get_workspace_by_id(ws_id)
    except Exception:
        return None
    code = (row or {}).get("code", "").strip()
    if not code or code in RETIRED_WORKSPACE_CODES:
        return None
    return code


class TaskRequest(BaseModel):
    role: str
    goal: str
    user_id: str | None = None


class MessageRequest(BaseModel):
    content: str
    sender_id: str = "web_user"
    user_id: str | None = None
    role: str | None = None  # default: cora (web gateway); set to talk to a specific agent
    # THE THREAD, separate from the person. `conversation_id` names the
    # conversation and scopes the session key; `user_id` stays the PERSON -
    # attribution and user-scope memory key on it whichever thread is
    # talking. Omitted, the thread falls back to user_id (the historic
    # one-thread-per-person behaviour), so no existing caller changes.
    conversation_id: str | None = None
    # K6 named output format — the same per-request choice ChatRequest has:
    # "v1" (the builtin response envelope) or any format the agent's own
    # workspace declares via an `output_format:` skill. None keeps the plain
    # reply. There is no legacy "json" value on this route; every name
    # resolves through the registry.
    format: str | None = None


def _resolve_request_format(role: str, workspace_path: Path, name: str,
                            owns_envelope_hint: bool = False):
    """Resolve a request-named K6 output format for *role*, or refuse.

    ONE implementation for every route that accepts ``format`` (the ad-hoc
    chat route and the run-message route) — two copies of this rule would
    drift on what a valid format is. Returns ``(fmt, suffix)`` where
    *suffix* is the prompt injection to append for the turn, or ``""`` when
    the agent's own always-on skill already mandates the envelope
    (re-stating it would only spend prompt tokens).

    Raises 400 for an unknown name — listing what IS declared, plus the
    warmed-agent restart hint (a format declared while `serve` is running
    is invisible to an already-warmed agent until the pod restarts) — and
    409 when an envelope-owning agent is asked for a DIFFERENT format: two
    contradictory format directives in one prompt is coin-flip compliance.
    """
    from ioagentfarm.engine.output_contract import emits_v1_envelope
    from ioagentfarm.engine.output_formats import (
        declared_format_names, format_instructions_suffix, resolve_format)
    fmt = None
    try:
        fmt = resolve_format(workspace_path, name)
    except Exception as exc:               # discovery must never kill a chat
        logger.warning("output_format.resolve_failed name={} err={}", name, exc)
    if fmt is None:
        try:
            known = declared_format_names(workspace_path)
        except Exception:                  # noqa: BLE001
            known = ["v1"]
        raise HTTPException(status_code=400, detail=(
            f"unknown output format {name!r} for agent '{role}'. "
            f"Declared formats here: {', '.join(known)}. A format is "
            "declared by a skill whose frontmatter carries "
            "`output_format: <name>` with a fenced JSON Schema block. "
            "If you just declared it while this engine was running, an "
            "already-warmed agent will not see it until the pod is "
            "restarted."))
    owns = owns_envelope_hint
    if not owns:
        try:
            owns = emits_v1_envelope(workspace_path)
        except Exception:                  # noqa: BLE001 - fails safe (open)
            owns = False
    if owns and fmt.name != "viz_envelope":
        raise HTTPException(status_code=409, detail=(
            f"agent '{role}' carries an always-on contract for the "
            "response envelope (schema v1); asking it for format "
            f"'{fmt.name}' would put two contradictory format "
            "directives in one prompt (coin-flip compliance). Request "
            "format 'viz_envelope' here, or use an agent without the "
            "envelope contract."))
    suffix = "" if (owns and fmt.name == "viz_envelope") \
        else format_instructions_suffix(fmt)
    return fmt, suffix


# ---------------------------------------------------------------------------
# GET /api/sandboxes — sandbox status for monitoring
# ---------------------------------------------------------------------------

@app.get("/api/sandboxes")
async def list_sandboxes():
    """List active sandbox instances and their status.

    Returns sandbox name, policy, workflow, pool, and health for
    each managed sandbox. Only available when IOF_RUNNER=sandbox.
    """
    mgr = getattr(app.state, "sandbox_manager", None)
    if not mgr:
        return {"enabled": False, "sandboxes": [], "message": "Sandbox mode not active (IOF_RUNNER != sandbox)"}

    sandboxes = []
    for sb in mgr.list_sandboxes():
        sandboxes.append({
            "name": sb.name,
            "policy": sb.policy,
            "status": sb.status,
            "workflow": sb.workflow,
            "pool": sb.pool,
        })

    return {
        "enabled": True,
        "count": len(sandboxes),
        "sandboxes": sandboxes,
    }


# ---------------------------------------------------------------------------
# GET /api/workflows
# ---------------------------------------------------------------------------

@app.get("/api/workflows")
async def list_workflows():
    """List available workflows with their steps, team roster, and roles."""
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    from ioagentfarm.engine.workspaces import get_agent_name
    loader = WorkflowLoader()
    names = loader.list_workflows()
    workflows = []
    for name in names:
        wf = loader.load(name)
        # Team roster from YAML + the Core Assistant (web gateway, always present)
        team = [{"role": "cora", "name": get_agent_name("cora")}]
        for member in wf.team_roster:
            try:
                team.append({"role": member.role, "name": get_agent_name(member.role)})
            except Exception:
                team.append({"role": member.role, "name": member.role})

        workflows.append({
            "name": name,
            "description": wf.description or "",
            "steps": [
                {"key": s.key, "role": s.role, "deps": s.deps}
                for s in wf.steps
            ],
            "roles": list(wf.roles.keys()),
            "team": team,
        })
    return {"workflows": workflows}


# ---------------------------------------------------------------------------
# POST /api/workflows/sync — sync all YAML workflows to DB
# ---------------------------------------------------------------------------

class WorkflowsSyncRequest(BaseModel):
    #: Which workspace's catalog to write. None -> IOF_WORKSPACE; nothing
    #: selected anywhere is a 400, never a silent import into a workspace
    #: nobody chose.
    workspace: str | None = None


@app.post("/api/workflows/sync")
def sync_workflows(req: WorkflowsSyncRequest | None = None):
    """Read all workflow YAMLs and upsert into the workflows DB table.

    Call after deploying new/updated workflow YAMLs to sync the DB without
    starting a run.  Thin wrapper over ``engine.catalog_sync.sync_workflows``
    — the same code ``aicore sync`` runs, so the HTTP and CLI surfaces
    cannot drift.
    """
    from ioagentfarm.engine.catalog_sync import sync_workflows as _sync

    ws_code = _run_workspace_code(req.workspace if req else None)
    synced = _sync(_store(), workspace_code=ws_code)
    return {"synced": len([s for s in synced if "error" not in s]),
            "total": len(synced), "workspace": ws_code, "workflows": synced}


def _attributed_user(request: Request, claimed: str | None) -> str:
    """Who a run belongs to: the VERIFIED identity when there is one.

    Backlog I3. Precedence, most trustworthy first:

    1. ``X-IOF-Actor`` from an authenticated caller — the end user the Studio
       API verified and delegated. This is the normal interface case, and it
       is trustworthy exactly because the engine now authenticates the caller:
       before that guard existed the header would have been a free-text claim
       from anyone who could reach the port.
    2. A verified HUMAN principal — a deployment where the SPA holds an IdP
       token directly and calls the engine as itself.
    3. ``req.user_id`` — client-supplied, kept because the CLI and the
       unauthenticated local stack have nothing better and their attribution
       (``cli:<os user>``) is honest about what it is.

    NOT a silent overwrite. When a verified identity disagrees with what the
    caller claimed, the claim is kept ALONGSIDE it rather than dropped: an
    interface that labels its runs (``ui:studio``) is saying something true
    about the channel, and the verified user is saying something true about
    the person. Losing either makes a support question unanswerable.
    """
    principal = _engine_auth.principal_of(request)
    fallback = claimed or "web:default"
    if principal is None or principal.method == "none":
        # Auth is off, or an exempt path. Unchanged behaviour, deliberately:
        # this must not start rewriting attribution on the local stacks and
        # CLI paths that have no identity to offer.
        return fallback

    verified = principal.actor or (principal.email if principal.kind == "user"
                                   else "")
    if not verified:
        # An authenticated SERVICE with no delegated user — a scheduler, a
        # smoke test, another workload. Naming the client is better than
        # "web:default", which says nothing at all.
        return f"svc:{principal.client_id or principal.subject}"

    channel = (claimed or "").split(":", 1)[0] if ":" in (claimed or "") else ""
    return f"{channel}:{verified}" if channel else f"user:{verified}"


# ---------------------------------------------------------------------------
# POST /api/run — create run + spawn background execution
# ---------------------------------------------------------------------------

@app.post("/api/run")
def start_run(req: RunRequest, request: Request):
    """Create a workflow run, materialize steps, spawn execution in background.

    Returns the run_id immediately.  The workflow executes as an independent
    OS process.  Use ``GET /api/run/{run_id}/stream`` to follow real-time
    output via SSE.

    ATTRIBUTION PREFERS THE VERIFIED IDENTITY (backlog I3). ``req.user_id`` is
    client-supplied — it was the only source, so a run's owner was whatever the
    caller typed, while the per-user endpoints filter on a *verified* identity.
    That was a spoofable audit trail and a visible bug at once: runs created
    through the interface returned nothing for the user who created them.
    """
    store = _store()
    root_path = _root()

    # Fail-fast disk guard (see engine/guards.py): refuse run creation on a
    # nearly-full state volume with a named error instead of failing late
    # with corrupt artifacts.
    from ioagentfarm.engine.guards import ensure_free_disk, DiskSpaceError
    try:
        ensure_free_disk(root_path)
    except DiskSpaceError as exc:
        raise HTTPException(status_code=507, detail=str(exc))

    # Resolve the tenant BEFORE loading: a scoped workspace's workflow lives
    # in its own override tree, and this server handles concurrent tenants, so
    # the code must be passed explicitly rather than read from process env.
    ws_code = _run_workspace_code(req.workspace)

    # DRAFT RUN: the author's overlay is resolved BEFORE the load, so a
    # workflow draft is what this run parses, snapshots and executes. Every
    # request without draft_author skips this entirely (draft_ctx stays
    # None) and runs the pack, byte-identical to before drafts existed.
    draft_ctx = None
    if req.draft_author:
        from ioagentfarm.engine import draft_runs
        try:
            draft_ctx = draft_runs.resolve_for_run(
                store, ws_code, req.draft_author, req.workflow)
        except draft_runs.DraftRunRefused as exc:
            raise HTTPException(status_code=400, detail=str(exc))

    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    loader = WorkflowLoader()
    try:
        if draft_ctx is not None and draft_ctx.workflow_files is not None:
            # The merged tree is validated through the SAME parse a pack dir
            # gets; the snapshot below re-derives identical bytes (pack copy
            # + raw overlay), so what was validated is what runs.
            from ioagentfarm.engine.draft_runs import materialized_workflow
            with materialized_workflow(draft_ctx.workflow_files) as wf_dir:
                wf = loader.load_from_dir(wf_dir)
        else:
            wf = loader.load(req.workflow, workspace=ws_code)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid workflow: {exc}")

    project_path = Path(req.project_dir).resolve() if req.project_dir else None

    uid = _attributed_user(request, req.user_id)

    # Run attribution IS the execution workspace. _run_workspace_code is
    # fail-closed, so by here the code is explicit and valid — the old
    # owning-workspace inference existed only to guess a tenant for the
    # retired 'default' fallback, and guessing is what made attribution
    # untrustworthy.
    # A SERVED ENGINE MUST NOT RESURRECT A DELETED TENANT. `ensure_workspace`
    # is create-or-get, and this call is what wrote a deleted workspace back:
    # a validator deleted a tenant while its engine was serving, was told the
    # delete succeeded, then sent ONE `POST /api/run` - and the row returned
    # with no members and no settings, accruing run history and unopenable in
    # the Studio forever. `workspace rename` had the same shape and produced
    # TWO tenants where there had been one.
    #
    # Refused rather than recreated: a run for a workspace that no longer
    # exists is a request the operator has already answered.
    # Refused only when the row was there at startup and is gone NOW - the
    # workspace was deleted or renamed underneath a live engine. A workspace
    # that never existed is created lazily, as it always was: that is how a
    # first run in a fresh local directory works, and refusing it would break
    # the ordinary path to fix the pathological one.
    if (getattr(app.state, "workspace_existed_at_startup", False)
            and ws_code == getattr(app.state, "workspace_code", None)
            and not store.workspace_exists(ws_code)):
        raise HTTPException(status_code=409, detail=(
            f"workspace '{ws_code}' no longer exists - it was deleted or "
            "renamed while this engine was running. Restart the engine for "
            "the workspace it should serve now; starting a run would "
            "recreate the tenant without its members or settings."))

    ws_id = store.ensure_workspace(
        code=ws_code,
        name=ws_code.replace("_", " ").title(),
    )
    wf_id = store.ensure_workflow(
        code=req.workflow,
        name=req.workflow.replace("_", " ").title(),
        description=wf.description,
        steps_json=json.dumps([s.key for s in wf.steps]),
        roles_json=json.dumps(list(wf.roles.keys())),
        team_json=json.dumps([{"role": m.role} for m in wf.team_roster]),
        workspace_code=ws_code,
    )

    _driver = (req.driver or "agent").strip().lower()
    if _driver not in ("agent", "code"):
        raise HTTPException(status_code=422,
                            detail=f"driver must be 'agent' or 'code', not {req.driver!r}")
    run_id = store.create_run(
        workflow_name=req.workflow,
        goal=req.goal,
        project_dir=str(project_path) if project_path else "",
        user_id=uid,
        workflow_id=wf_id,
        workspace_id=ws_id,
    )
    # The driver is a property of the RUN (runs.driver): resume and the
    # supervisor read it back, exactly as the CLI records it.
    store.set_run_driver(run_id, _driver)
    # Same opening boundary event the CLI creation paths emit — without it a
    # Studio-created run's timeline starts mid-story and `forensics explain`
    # reads an incomplete record for exactly the runs Studio users ask about.
    from ioagentfarm.cli import _emit_run_created
    _emit_run_created(root_path, run_id, req.workflow, "workflow", req.goal,
                      workspace_code=ws_code,
                      draft=draft_ctx.as_provenance() if draft_ctx else None)
    loader.snapshot_workflow(
        req.workflow, run_id, root=root_path, workspace=ws_code,
        overlay=draft_ctx.workflow_overlay if draft_ctx else None)
    if draft_ctx is not None:
        # drafts.json is how a run-step subprocess (possibly on another pod)
        # learns this run resolves the author's agent/skill drafts — the
        # request that carried draft_author is gone by then.
        from ioagentfarm.engine.draft_runs import write_run_drafts
        write_run_drafts(root_path, run_id, draft_ctx)

    # Persist var overrides into the instance dir so the scheduler picks
    # them up — byte-identical to the CLI's --var handling.
    if req.variables:
        vars_file = root_path / "instances" / run_id / "workflow_vars.json"
        vars_file.parent.mkdir(parents=True, exist_ok=True)
        vars_file.write_text(json.dumps(req.variables), encoding="utf-8")

    store.materialize_steps(run_id, wf)

    active_file = root_path / "active_run"
    active_file.write_text(run_id, encoding="utf-8")

    steps = store.list_steps(run_id)

    # Pull input data from S3 into the run's reference/csv directory.
    # This overwrites the bundled CSV files with the latest from S3,
    # keeping the path consistent with what pharma_query.py expects.
    try:
        from ioagentfarm.web.storage import get_storage
        storage = get_storage()
        if storage.is_cloud:
            # Pull to a temp location first, then copy to the analyst's workspace
            # after create_filtered_workspace runs (during run-step).
            # For now, pull to a shared location that run-step can copy from.
            input_data_dir = root_path / "instances" / run_id / "input_data"
            input_data_dir.mkdir(parents=True, exist_ok=True)
            storage.pull_prefix(
                prefix=f"input_data/{req.workflow}/",
                local_dir=input_data_dir,
            )
            logger.info("Input data pulled from S3 for workflow=%s run=%s", req.workflow, run_id)

            # Overlay user-customizable metadata files (playbook.yaml, catalog.yaml)
            # from input_data/ onto the frozen workflow snapshot's metadata/.
            # This lets users edit playbooks in S3 without touching the codebase.
            metadata_dst = root_path / "instances" / run_id / "workflow" / "metadata"
            for overlay_name in ("playbook.yaml", "catalog.yaml", "databases.yml"):
                overlay_src = input_data_dir / overlay_name
                if overlay_src.exists() and metadata_dst.is_dir():
                    import shutil
                    shutil.copy2(str(overlay_src), str(metadata_dst / overlay_name))
                    logger.info("S3 overlay: %s -> workflow snapshot metadata", overlay_name)
    except Exception:
        logger.debug("Input data pull skipped (non-critical)", exc_info=True)

    spawn_run(
        run_id=run_id,
        driver=_driver,
        workflow=req.workflow,
        goal=req.goal,
        project_dir=str(project_path) if project_path else "",
        user_id=uid,
        root_path=root_path,
        workspace=ws_code,
    )

    # Persist system message — run started
    step_names = ", ".join(s["step_key"] for s in steps)
    store.insert_message(
        run_id=run_id,
        user_id=uid,
        source="system",
        workspace_id=ws_id,
        workflow_id=wf_id,
        content=f"Run started — {req.workflow} ({len(steps)} steps: {step_names}). Goal: {req.goal}",
        msg_type="message",
    )

    return {
        "run_id": run_id,
        "workflow": req.workflow,
        "goal": req.goal,
        "driver": _driver,
        "total_steps": len(steps),
        "status": "started",
    }


# ---------------------------------------------------------------------------
# POST /api/run/{run_id}/task — spawn ad-hoc agent task within run context
# ---------------------------------------------------------------------------

@app.post("/api/run/{run_id}/task")
def start_task(run_id: str, req: TaskRequest):
    """Spawn an ad-hoc agent task within the context of an existing run.

    The task agent gets full run context: output directory, prior step outputs,
    source directory.  Executes as an independent OS subprocess — same as a
    workflow run.

    Use this to ask any agent to do work within a completed (or running) run:
    - Ask reviewer to add tests
    - Tell developer to refactor code
    - Have analyst investigate a specific area

    Returns the task_id immediately.  The agent works in the background.
    """
    store = _store()
    root_path = _root()

    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

    uid = req.user_id or "web:default"

    from ioagentfarm.web.spawn import spawn_task
    from ioagentfarm.engine.workspaces import get_agent_name

    task_id = spawn_task(
        run_id=run_id,
        role=req.role,
        goal=req.goal,
        user_id=uid,
        root_path=root_path,
    )

    agent_display_name = get_agent_name(req.role)
    store.insert_message(
        run_id=run_id,
        task_id=task_id,
        user_id=uid,
        source="task_spawned",
        role=req.role,
        agent_name=agent_display_name,
        content=f"Task assigned to {agent_display_name} ({req.role}): {req.goal}",
        msg_type="message",
    )

    return {
        "run_id": run_id,
        "task_id": task_id,
        "role": req.role,
        "goal": req.goal,
        "status": "spawned",
    }


# ---------------------------------------------------------------------------
# GET /api/run/{run_id}/status — lightweight process status
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}/status")
def run_status(run_id: str):
    """Check if the run's process is alive.

    Tries local PID first.  If PID not found (cross-pod request),
    falls back to DB run status.
    """
    from ioagentfarm.web.runner import get_runner

    log_dir = _run_log_dir(run_id)
    runner = get_runner()

    # Check local PID
    process_status = runner.status(run_id, log_dir) if log_dir.exists() else "unknown"

    # Always check DB for the authoritative run status
    store = _store()
    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

    db_status = run["status"]
    steps = store.list_steps(run_id)
    done_count = sum(1 for s in steps if s["status"] == "done")
    failed_count = sum(1 for s in steps if s["status"] == "failed")
    running_count = sum(1 for s in steps if s["status"] == "running")
    total_count = len(steps)

    # The database is authoritative and this is a READ. The old branch
    # "auto-resolved" a run whose PID this pod did not own to `stale` - a
    # status the docs do not have - and WROTE it into the run row, so a
    # healthy CLI-started run read `status=stale` in `aicore status`
    # twenty-five seconds later (novice finding, round 6). Liveness comes
    # from the driver heartbeat, the clock the supervisor and the CLI use;
    # nothing here mutates.
    from ioagentfarm.engine.supervisor import driver_state
    ds = driver_state(run, steps)
    status = db_status
    driver = {
        "kind": run.get("driver") or "agent",
        "alive": bool(db_status == "running" and not ds["stale"]),
        "heartbeat_age_s": ds["heartbeat_age_s"],
        "stale_after_s": ds["threshold_s"],
    }

    return {
        "run_id": run_id,
        "status": status,
        "driver": driver,
        "process": process_status,
        "steps": {
            "total": total_count,
            "done": done_count,
            "failed": failed_count,
            "running": running_count,
        },
    }


# ---------------------------------------------------------------------------
# POST /api/run/{run_id}/resume — resume a stale/crashed run
# ---------------------------------------------------------------------------

@app.post("/api/run/{run_id}/resume")
def resume_run(run_id: str, request: Request, req: ResumeRequest | None = None):
    """Resume a stale or crashed run from where it left off.

    Resets any orphaned 'running' steps to 'pending', pulls state from S3
    if needed, and re-spawns Alex to continue the pipeline.
    """
    store = _store()
    root_path = _root()

    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

    # The run's own workspace, read back from its row. Resume must preserve
    # the tenant: this call used to omit workspace= from spawn_run, so
    # resuming a tenant run silently re-spawned it under the old 'default'
    # fallback — a different agent home, a different roster, and a forensic
    # trail that no longer matched the run it claimed to continue.
    run_ws = _workspace_code_for_run(store, run)
    if not run_ws:
        raise HTTPException(
            status_code=409,
            detail=f"Run {run_id} is not attributed to a workspace and "
                   "cannot be resumed. Runs created before workspace "
                   "attribution was enforced must be re-created.")

    force = bool(req.force) if req is not None else False
    if run["status"] == "done":
        raise HTTPException(status_code=409,
                            detail=f"Run {run_id} is done - nothing to resume.")
    if run["status"] == "failed" and not force:
        raise HTTPException(
            status_code=409,
            detail=(f"Run {run_id} is FAILED - it was concluded, not interrupted. Fix what "
                    "stopped it (step-retry bumps a capped step, step-skip unblocks a dead "
                    'one), then resume with {"force": true}.'))

    # THE SAME WINDOW THE CLI HONOURS. This endpoint had none: it reset a
    # step a live driver was running and spawned a second driver beside
    # it, and the record then blamed a file race (novice finding, round 6).
    from ioagentfarm.engine import supervisor as _sup
    steps = store.list_steps(run_id)
    ds = _sup.driver_state(run, steps)
    age = ds.get("heartbeat_age_s")
    if age is not None and not ds["stale"] and not force:
        raise HTTPException(
            status_code=409,
            detail=(f"driver heartbeat is {int(age)}s old (stale after {int(ds['threshold_s'])}s "
                    f"for a {run.get('driver') or 'agent'} driver) - a driver appears to be "
                    "running. If you know it is dead, wait for the threshold or pass "
                    '{"force": true}.'))

    # Pull state from S3 if instance dir is missing (cross-pod recovery)
    instance_dir = root_path / "instances" / run_id
    if not instance_dir.exists():
        try:
            from ioagentfarm.web.storage import get_storage
            get_storage().pull(run_id, instance_dir, sub_prefix="instances")
        except Exception:
            logger.debug("S3 pull failed for resume (non-critical)", exc_info=True)

    run_dir = root_path / "runs" / run_id
    if not run_dir.exists():
        try:
            from ioagentfarm.web.storage import get_storage
            get_storage().pull(run_id, run_dir, sub_prefix="state")
        except Exception:
            logger.debug("S3 state pull failed for resume (non-critical)", exc_info=True)

    # Reap first, resume second - the supervisor's own sweep, scoped to this
    # run, drivers OFF because spawning one is the next line's job.
    actions = _sup.supervise_once(store, root_path, run_id=run_id, resume_drivers=False)
    reset_count = len([a for a in (actions or []) if isinstance(a, dict)])
    # the dead driver's own steps (see the CLI's resume): a command step
    # silent for 30 s died with it - reset now, not at the 180 s sweep
    import datetime as _dt
    for _s in store.list_steps(run_id):
        if _s.get("status") != "running":
            continue
        _hb = _sup._age_s(_dt.datetime.now(_dt.timezone.utc), _sup._parse_ts(_s.get("heartbeat_at")))
        if force or _hb is None or _hb > 30:
            try:
                store.crash_recover_step(run_id, _s["step_key"])
                reset_count += 1
                from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="step.reaped_on_resume", severity=SEVERITY_WARN,
                    step_key=_s["step_key"], role=None,
                    message=f"step '{_s['step_key']}' reset by resume - heartbeat "
                            f"{'never' if _hb is None else f'{_hb:.0f}s old'}; the driver it ran under is gone",
                    payload={"heartbeat_age_s": _hb, "force": bool(force), "surface": "api"})
            except Exception:  # noqa: BLE001
                continue
    if store.get_run(run_id).get("status") == "failed" and run["status"] != "failed":
        raise HTTPException(status_code=409,
                            detail=f"Run {run_id} was failed while this resume ran (a cancel or a "
                                   "verdict landed) - nothing spawned.")

    if run["status"] == "failed":
        with store._tx() as cursor:
            cursor.execute(
                store._q("UPDATE runs SET status='running', updated_at=? WHERE id=?"),
                (store._now(), run_id),
            )

    # Stamp the driver heartbeat NOW so the supervisor gives the fresh
    # driver its full window to boot.
    store.touch_driver_heartbeat(run_id)

    # The run's OWN driver (runs.driver) - never "Alex" for a code-driven run.
    _sup._spawn_driver(store.get_run(run_id), root_path, run_ws)
    actor = _attributed_user(request, None)
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO
        get_forensics(root_path).emit(
            run_id=run_id, event_type="run.resumed", severity=SEVERITY_INFO,
            step_key=None, role=None,
            message=f"resumed by {actor} (api)" + (" (force)" if force else ""),
            payload={"by": actor, "force": bool(force), "surface": "api"})
    except Exception:  # noqa: BLE001
        pass

    steps_after = store.list_steps(run_id)
    done = sum(1 for s in steps_after if s["status"] == "done")
    pending = sum(1 for s in steps_after if s["status"] == "pending")
    driver_kind = run.get("driver") or "agent"

    return {
        "run_id": run_id,
        "status": "resumed",
        "driver": driver_kind,
        "steps_reset": reset_count,
        "steps_done": done,
        "steps_pending": pending,
        "message": f"Run resumed - {reset_count} stuck step(s) reset, {driver_kind} driver re-spawned.",
    }


# ---------------------------------------------------------------------------
# POST /api/run/{run_id}/cancel — stop a run for good
# ---------------------------------------------------------------------------

@app.post("/api/run/{run_id}/cancel")
def cancel_run_endpoint(run_id: str, request: Request, req: CancelRequest | None = None):
    """Stop a run for good: no retry, no resurrection, no further model
    calls. The supervisor leaves a failed run alone; `step-retry` re-opens
    a step if this was a mistake. 404 unknown run, 409 already concluded.
    """
    from ioagentfarm.engine import supervisor as _sup
    store = _store()
    root_path = _root()
    run = store.get_run(run_id)          # KeyError -> 404 (handler below)
    if run.get("status") in ("done", "failed"):
        raise HTTPException(status_code=409,
                            detail=f"Run {run_id} is {run['status']} - nothing to cancel.")
    actor = _attributed_user(request, None)
    out = _sup.cancel_run(store, root_path, run_id, by=actor,
                          reason=(req.reason if req is not None else "") or "")
    return {"run_id": run_id, "status": "cancelled", "run_status": "failed",
            "killed_pids": out.get("killed_pids", []),
            "stopped_steps": out.get("stopped_steps", []), "by": actor,
            "message": (f"Run cancelled by {actor}; {len(out.get('stopped_steps', []))} running "
                        "step(s) failed with the reason; nothing will resume it.")}


# ---------------------------------------------------------------------------
# GET /api/run/{run_id}/stream — SSE real-time output
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}/stream")
async def run_stream(run_id: str):
    """SSE stream of run output — local file tail or K8s pod logs."""
    log_dir = _run_log_dir(run_id)

    # If logs not local (e.g. pod recovery), try pulling from cloud storage
    if not log_dir.exists():
        try:
            from ioagentfarm.web.storage import get_storage
            instance_dir = _root() / "instances" / run_id
            logger.info("SSE: logs not local for run_id={}, attempting S3 pull", run_id)
            get_storage().pull(run_id, instance_dir, sub_prefix="instances")
        except Exception as exc:
            logger.error("SSE: S3 pull failed for run_id={}: {}", run_id, exc)

    if not log_dir.parent.exists():
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

    return create_sse_response(run_id, log_dir)


# ---------------------------------------------------------------------------
# POST /api/run/{run_id}/message — follow-up to gateway project_lead
# ---------------------------------------------------------------------------

@app.post("/api/run/{run_id}/message")
async def send_message(run_id: str, req: MessageRequest, request: Request):
    """Send a message to an agent in the context of a run.

    Routing (in priority order):
    1. ``@AgentName`` mention in content — routes directly to that agent
    2. ``role`` field in request — routes to specified role
    3. Default: cora (gateway)

    When routing to a step agent (analyst, strategist, reviewer), uses the
    step's original session key so the agent has full conversation history
    from the workflow run. This enables interactive follow-up — asking Strategist
    why he chose Play J, telling Analyst to dig deeper, etc.

    Intent detection (from agent response):
    - Agent writes a new deliverable version → auto-cascade downstream steps
    - Feedback keywords → record to learning system
    """
    _set_inbound_tp(request)
    # A DESK-SIDE ROLE DOES NOT ANSWER OVER HTTP. `cora_build` carries a
    # shell and writes files; a validator reached it anonymously on this
    # endpoint and had it run `echo`, and the same route returned `whoami`
    # and the host's path from `meta_agent`. The port is a trust boundary
    # either way - but it should bound unwanted CHAT, not host compromise.
    from ioagentfarm.engine.always_on import is_desk_side
    # MessageRequest carries `role`, not `agent` — reading the field the CHAT
    # model has made this guard a 500 on EVERY run follow-up, desk-side or not.
    if is_desk_side(req.role or ""):
        raise HTTPException(status_code=403, detail=(
            f"agent '{req.role}' is a desk-side role and is not served over "
            "HTTP. It runs shell commands and writes files, so it answers "
            "only at a terminal: run `aicore build` on the machine that owns "
            "the workspace."))

    pool: AgentPool = getattr(app.state, "agent_pool", None)
    if not pool:
        raise HTTPException(status_code=503, detail="Agent pool not available")

    store = _store()
    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

    content = req.content

    # Parse @AgentName mentions to resolve role
    from ioagentfarm.engine.workspaces import get_agent_name, _agent_names
    resolved_role = req.role
    agent_names = _agent_names()
    name_to_role = {name.lower(): role for role, name in agent_names.items()}
    if not resolved_role:
        import re
        mention = re.search(r"@(\w+)", content)
        if mention:
            mentioned_name = mention.group(1).lower()
            if mentioned_name in name_to_role:
                resolved_role = name_to_role[mentioned_name]
                content = re.sub(r"@\w+\s*", "", content, count=1).strip()

    role = resolved_role or "cora"

    # A run whose every step is a command has NO agent to address. The
    # Core Assistant answered anyway - three model turns on a `sleep`
    # pipeline, none of them in the run's usage (novice finding, round 7).
    # Refuse unless the caller named a role explicitly.
    _run_roles = {s.get("role") for s in store.list_steps(run_id)}
    if not req.role and role == "cora" and _run_roles and _run_roles <= {"system", None, ""}:
        raise HTTPException(
            status_code=409,
            detail=(f"Run {run_id} is a command-only pipeline (roles: system) - there is no "
                    "agent in this run to address, and a chat here would be answered by the "
                    "Core Assistant at your cost. Read the run instead: "
                    f"`aicore forensics explain {run_id}` / GET /api/run/{run_id}/status; "
                    "or name an agent explicitly with \"role\"."))

    try:
        agent = pool.get(role)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not create agent for role '{role}': {exc}")

    # A NAMED output format (K6): the same per-request choice the ad-hoc
    # chat route has, so a run-scoped caller can get a structured reply from
    # the same registry — "v1" builtin, more declared by the agent's own
    # workspace (`output_format:` skills). Resolved BEFORE the user message
    # is persisted or the model is called, so an unknown name costs nothing.
    custom_fmt = None
    _fmt_suffix = ""
    if req.format:
        from ioagentfarm.engine.workspaces import \
            iobot_agent_workspace as _fmt_naw
        custom_fmt, _fmt_suffix = _resolve_request_format(
            role, _fmt_naw(role), req.format,
            owns_envelope_hint=(role in _V1_ROLES))

    uid = req.user_id or f"web:{req.sender_id}"

    # THREAD vs PERSON, kept separate. `conversation_id` names the thread
    # and is what the session key carries below; `uid` stays the person and
    # is what every attribution row records. Sent empty it is refused like
    # an empty user_id - explicit-and-blank is a caller bug, not a default.
    if req.conversation_id is not None and not req.conversation_id.strip():
        raise HTTPException(status_code=400, detail=(
            "`conversation_id` is empty. It names the conversation thread "
            "(one user may hold several per run); send a stable id, or omit "
            "the field to thread by user_id."))
    # RUNS ARE TEAM-VISIBLE; A PERSON IS NOT IMPERSONABLE. Anyone in the
    # workspace may chat about a run - that is the team-artifact model and
    # this does not narrow it - but bob asserting amy's user_id landed in
    # HER thread with her memory and wrote rows under her name (found live,
    # hardening round 2). Bound, he talks about the same run as himself.
    _owner = _bound_owner(request)
    if _owner:
        if req.user_id and req.user_id != _owner:
            raise HTTPException(status_code=403, detail=(
                f"user_id '{req.user_id}' does not match the authenticated "
                "principal. With IOF_CHAT_BIND_PRINCIPAL on, a run "
                "conversation belongs to the verified caller; omit user_id "
                "or send your own. The run itself stays team-visible."))
        uid = _owner
    thread = req.conversation_id or uid
    # THE SESSION KEY CARRIES THE PERSON, NOT ONLY THE THREAD NAME.
    # `conversation_id` is chosen by the CLIENT, so two people who pick the
    # same ordinary name ("q3-review") landed in ONE agent session: a
    # hardening probe had a second verified principal name another's thread
    # and the agent replayed her question and her figures back to him. The
    # STORED conversation_id stays the caller's own value - history filters
    # on it - and only the session is namespaced.
    session_thread = f"{uid}::{thread}" if req.conversation_id else uid

    from ioagentfarm.engine.workspaces import get_agent_name
    agent_display_name = get_agent_name(role)

    # Persist user message
    store.insert_message(
        run_id=run_id,
        user_id=uid,
        conversation_id=thread,
        source="user",
        content=req.content,
        msg_type="message",
    )

    # Determine session key: fork-on-first-chat pattern.
    #
    # Each user gets their own session that STARTS with the step's full JSONL
    # history (tool calls, reasoning, data reads) but is isolated from other
    # users' follow-up conversations.  This prevents:
    #   - Session collision (Sudhir on web + Raj on Teams interleaving)
    #   - AgentLoop lock contention (separate session keys = separate locks)
    #   - S3 race conditions (different files)
    #
    # Flow:
    #   1. User's chat session key: chat:{run_id}:{step_key}:u:{uid}
    #   2. On first chat, copy step's original JSONL → user's fork
    #   3. All subsequent messages append to user's fork
    # THE STEP, AND ITS SESSION, RESOLVE THROUGH ONE MODULE. This block used
    # to take the first step in sequence order for the role (the Studio shows
    # the newest done one) and to look for its session as
    # `iof_<run>_<step>_u_<uid>.jsonl` in the role's home - a name the runtime
    # stopped writing and a directory a step never wrote to. "No step session
    # to fork - starting fresh chat" on every thread, on every host, since
    # the runtime moved to base64 stems. See engine/step_sessions.py.
    from ioagentfarm.engine.step_sessions import choose_step_for_role, fork_step_session
    steps = store.list_steps(run_id)
    step_for_role = choose_step_for_role(steps, role)

    if step_for_role:
        step_key = step_for_role["step_key"]
        # User-scoped chat session (isolated per user)
        session_key = f"chat:{run_id}:{step_key}:u:{session_thread}"

        # Fork step's original JSONL on first chat
        try:
            from ioagentfarm.web.storage import get_storage
            from ioagentfarm.engine.workspaces import iobot_agent_workspace
            outcome = fork_step_session(
                get_storage(), _root(), run_id, step_key, role,
                session_key, iobot_agent_workspace(role) / "sessions")
            if outcome == "fresh":
                logger.info("No step session to fork — starting fresh chat for {}", session_key)
            elif outcome != "existing":
                logger.info("Step session for user chat: {} ({} {})", session_key, outcome, step_key)
        except Exception:
            logger.debug("Session fork/pull failed (non-critical)", exc_info=True)
    else:
        session_key = f"web:{run_id}:{role}:u:{session_thread}"

    # Tell the agent how to access deliverables via run-output CLI tool.
    # Don't inject file contents (could be 50K+). Agent reads on demand.
    deliverables_hint = (
        f"\n\n[Run deliverables — use exec to access via CLI tool]\n"
        f"  List files:  aicore run-output --run-id {run_id} --list\n"
        f"  Read file:   aicore run-output --run-id {run_id} --file <name>\n"
        f"  Search:      aicore run-output --run-id {run_id} --file <name> --grep \"<term>\"\n"
        f"  Write:       echo \"<content>\" | aicore run-output --run-id {run_id} --write <name>\n"
    )

    # Inject live pipeline status - on THIS request's store. Opening another
    # is a fresh database connection per turn, measured at 1.36s of the
    # ~3s this handler spent before the model on a laptop against RDS.
    run_context = _build_run_context(run_id, store=store)
    augmented_message = f"{run_context}{deliverables_hint}\n\n[User message] {content}"
    if _fmt_suffix:
        # A named format owns the shape this turn — injected the same way
        # the chat route does it (engine/output_formats.py).
        augmented_message = augmented_message + _fmt_suffix

    # Stream intermediate thoughts (tool calls, reasoning) to messages table
    from ioagentfarm.cli_orchestration import _is_noise

    # Collect streamed chunks to detect which are tool calls vs final response
    _progress_chunks: list[str] = []

    async def _on_progress(text: str, **kwargs) -> None:
        stripped = text.strip()
        if not stripped or _is_noise(stripped):
            return
        _progress_chunks.append(stripped)
        # Only persist tool calls and intermediate reasoning (not final response lines).
        # Tool calls start with exec(, read_file(, write_file(, list_dir( etc.
        is_tool_call = any(stripped.startswith(t) for t in ("exec(", "read_file(", "write_file(", "list_dir(", "search("))
        if is_tool_call:
            # The SAME event, pushed: a streaming caller sees what a polling
            # client reads from the store (msg_type='thought') - one writer.
            chat_stream.emit("status", {"text": stripped})
            store.insert_message(
                run_id=run_id, user_id=uid, conversation_id=thread,
                source="agent", role=role,
                agent_name=agent_display_name, content=stripped, msg_type="thought",
            )

    _line_stream = LineBufferedStream(_on_progress)

    async def stream(delta: str) -> None:
        # Raw model text for a streaming caller; the line buffer (and so the
        # stored progress rows) is untouched - a chat UI renders characters,
        # a progress row is a sentence.
        chat_stream.emit("delta", {"text": delta})
        await _line_stream(delta)

    stream.flush = _line_stream.flush
    result = await agent.process_direct(
        augmented_message,
        session_key=session_key,
        channel="web",
        chat_id=f"web:{run_id}",
        on_progress=_on_progress,
        on_stream=stream,
    )
    await stream.flush()
    response = result.content if result else ""

    # K6 enforcement for a NAMED format: extract -> validate against its
    # schema -> one bounded corrective retry through the SAME run-scoped
    # session — and BEFORE the reply is persisted, so the stored message is
    # the corrected one, not the draft the retry replaced.
    envelope = None
    format_validation = None
    if custom_fmt is not None and response:
        from ioagentfarm.engine.output_formats import enforce_format

        async def _fmt_turn(corrective: str) -> str:
            r = await agent.process_direct(
                corrective, session_key=session_key,
                channel="web", chat_id=f"web:{run_id}")
            return r.content if r else ""

        try:
            response, envelope, _fmt_problems = await enforce_format(
                custom_fmt, response, _fmt_turn)
            format_validation = {
                "format": custom_fmt.name,
                "valid": not _fmt_problems,
                "problems": _fmt_problems[:10],
            }
            if _fmt_problems:
                logger.warning(
                    "output_format.invalid name={} role={} run={} problems={}",
                    custom_fmt.name, role, run_id, len(_fmt_problems))
        except Exception as _fmt_enf_exc:  # noqa: BLE001 - never eat a reply
            logger.warning("output_format.enforce_failed name={} err={}",
                           custom_fmt.name, _fmt_enf_exc)

    # Persist final agent response
    msg_id = store.insert_message(
        run_id=run_id,
        user_id=uid,
        conversation_id=thread,
        source="agent",
        role=role,
        agent_name=agent_display_name,
        content=response,
        msg_type="message",
    )

    # Push updated session JSONL to S3 so subsequent chats on other pods
    # also see the follow-up conversation history.
    if step_for_role:
        try:
            from ioagentfarm.web.storage import get_storage as _get_stor
            from ioagentfarm.engine.workspaces import iobot_agent_workspace as _naw
            from ioagentfarm.engine.step_sessions import encode_stem, session_file as _sess
            # The runtime's own file for this thread, pushed under the name
            # the fork pulls it back by - never the legacy `_` spelling,
            # whose `exists()` was False and pushed nothing.
            session_file = _sess(_naw(role) / "sessions", session_key)
            if session_file.exists():
                _get_stor().push_file(run_id, session_file, sub_prefix="sessions",
                                      name=f"{encode_stem(session_key)}.jsonl")
        except Exception:
            logger.debug("Session S3 push after chat failed (non-critical)", exc_info=True)

    # Intent detection: if agent revised a deliverable, cascade downstream steps + S3 push
    cascade_triggered = False
    revision_keywords = ["updated", "revised", "written to", "wrote", "is written", "strategy_plan_v", "intelligence_report_v", "compliance_review_v"]
    if step_for_role and any(kw in response.lower() for kw in revision_keywords):
        cascade_triggered = True  # revision detected — always flag for S3 push + UI
        # Find downstream steps that depend on this step
        try:
            from ioagentfarm.engine.workflow_loader import WorkflowLoader
            wf = WorkflowLoader().load(run["workflow_name"], run_id=run_id, root=_root())
            revised_key = step_for_role["step_key"]
            for step_def in wf.steps:
                if revised_key in (step_def.deps or []):
                    # Reset downstream step to pending for re-execution
                    downstream = next((s for s in steps if s["step_key"] == step_def.key), None)
                    if downstream and downstream["status"] == "done":
                        with store._tx() as cursor:
                            now = store._now()
                            cursor.execute(
                                store._q("UPDATE steps SET status='pending', output_text=NULL, updated_at=? WHERE run_id=? AND step_key=?"),
                                (now, run_id, step_def.key),
                            )
                        cascade_triggered = True
                        logger.info("Cascade: reset step '%s' to pending after revision of '%s'", step_def.key, revised_key)
            # Push updated project directory to S3 after any revision
            try:
                from ioagentfarm.web.storage import get_storage
                instance_dir = _root() / "instances" / run_id
                if instance_dir.exists():
                    get_storage().push(run_id, instance_dir, sub_prefix="instances")
                    logger.info("S3 push after revision for run_id=%s", run_id)
            except Exception:
                logger.debug("S3 push after revision failed (non-critical)", exc_info=True)
        except Exception:
            logger.debug("Cascade check failed", exc_info=True)

    # Feedback detection: record to learning system
    feedback_signals = {
        "never works": "negative",
        "always fails": "negative",
        "wrong approach": "negative",
        "great strategy": "positive",
        "good call": "positive",
        "exactly right": "positive",
    }
    for phrase, signal in feedback_signals.items():
        if phrase in req.content.lower() and step_for_role:
            try:
                ll = _get_learning_lifecycle()
                ll.append_observation(
                    run_id=run_id,
                    step_key=step_for_role["step_key"],
                    role=role,
                    workflow=run.get("workflow_name", ""),
                    content=req.content,
                )
                logger.info("Recorded %s feedback for step %s: %s", signal, step_for_role["step_key"], req.content[:100])
            except Exception:
                logger.debug("Feedback recording failed", exc_info=True)
            break

    result_data = {
        "id": f"msg_{msg_id}",
        "run_id": run_id,
        "agent": role,
        "agent_name": agent_display_name,
        "content": response,
    }
    if custom_fmt is not None:
        # The same three fields the chat route returns for a named format,
        # so one client-side reader serves both surfaces.
        result_data["format"] = custom_fmt.name
        result_data["envelope"] = envelope
        result_data["format_validation"] = format_validation
    if cascade_triggered:
        result_data["cascade"] = True
        result_data["cascade_message"] = "Strategy revised — downstream steps reset for re-validation."

    return result_data


@app.post(
    "/api/run/{run_id}/message/stream",
    summary="Run-scoped chat, streamed (SSE)",
    response_class=StreamingResponse,
)
async def send_message_stream(run_id: str, req: MessageRequest, request: Request):
    """The same run-scoped turn as ``POST /api/run/{run_id}/message``,
    streamed as Server-Sent Events: ``status`` events as the agent works
    (the same lines the store records as thought rows), ``delta`` events
    carrying model text as it arrives, then one ``message`` event whose
    payload is exactly the body the non-streaming endpoint returns.

    Body and semantics are identical - same thread rules
    (``conversation_id`` / ``user_id``), same formats, same refusals; a
    caller switches transport without changing anything else. Read it with
    a client that does not buffer (``curl -N``, or ``fetch`` +
    ``response.body.getReader()`` - ``EventSource`` cannot POST).
    Refusals raised before the turn starts (unknown run, empty
    conversation_id, unknown format) stay ordinary HTTP status codes.
    """
    return await chat_stream.stream_turn(
        lambda: send_message(run_id, req, request), request)


# ---------------------------------------------------------------------------
# GET /api/run/{run_id} — run detail
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}")
def run_detail(run_id: str):
    """Full run detail: status, steps, tasks, goal, timestamps."""
    store = _store()
    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

    from ioagentfarm.engine.workspaces import get_agent_name

    steps = store.list_steps(run_id)
    tasks = store.list_tasks(run_id=run_id)

    return {
        "id": run["id"],
        "workflow": run["workflow_name"],
        "goal": run["goal"],
        "status": run["status"],
        "project_dir": run.get("project_dir", ""),
        "parent_run_id": run.get("parent_run_id"),
        "user_id": run.get("user_id"),
        "steps": [
            {
                "key": s["step_key"],
                "role": s["role"],
                "agent_name": get_agent_name(s["role"]),
                "status": s["status"],
                "attempt": s["attempt"],
                "output_snippet": (s.get("output_text") or "")[:200],
            }
            for s in steps
        ],
        "tasks": [
            {
                "id": t["task_id"],
                "role": t["role"],
                "title": t["title"],
                "status": t["status"],
            }
            for t in tasks
        ],
        "created_at": run.get("created_at"),
        "updated_at": run.get("updated_at"),
    }


# ---------------------------------------------------------------------------
# GET /api/run/{run_id}/explain/artifacts — the filesystem-bound remainder
# of a run explanation, served where the files live
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}/explain/artifacts")
def run_explain_artifacts(run_id: str):
    """Usage totals, structural failure parsing and swarm artifacts.

    The Studio API composes ~85% of a run explanation from the shared DB;
    this endpoint serves the remainder that only exists on the engine
    host's filesystem (usage.jsonl, per-attempt session snapshots, swarm
    result files). Proxied by the API pod on the same rail as agent
    memory. Reuses the CLI postmortem's own readers so the Studio and
    `aicore forensics explain` cannot disagree about these numbers.
    """
    store = _store()
    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

    from ioagentfarm.cli_forensics import (
        FAILURE_TRANSLATIONS, _forensics_attempts_root, _read_json_utf8sig,
        _read_snapshot_markers, _usage_totals,
    )
    from ioagentfarm.engine.forensics import parse_session_failure

    usage = _usage_totals(run_id)

    structural: dict[str, str] = {}
    attempts_root = _forensics_attempts_root(run_id)
    if attempts_root is not None:
        latest: dict[str, tuple[int, Path]] = {}
        for d in attempts_root.iterdir():
            if not d.is_dir() or "." not in d.name:
                continue
            step_key, _, n = d.name.rpartition(".")
            try:
                n_int = int(n)
            except ValueError:
                continue
            if step_key not in latest or n_int > latest[step_key][0]:
                latest[step_key] = (n_int, d)
        for step_key, (_n, d) in latest.items():
            try:
                failure = parse_session_failure(
                    d / "session-snapshot.jsonl") or {}
            except Exception:
                failure = {}
            reason = failure.get("reason")
            if reason:
                structural[step_key] = (
                    FAILURE_TRANSLATIONS.get(reason) or reason)

    swarm = None
    markers = _read_snapshot_markers(run_id)
    kind = run.get("kind") or (
        "swarm" if markers.get("kind") == "swarm" else "workflow")
    if kind == "swarm":
        from ioagentfarm.engine.forensics import find_swarm_results
        from ioagentfarm.engine.iobot_config import get_run_output_dir
        project = get_run_output_dir(_iof_root_path(), run_id)
        results_path = find_swarm_results(project)
        artifact_dir = results_path.parent if results_path else project
        children = []
        results_doc = (_read_json_utf8sig(results_path)
                       if results_path else None)
        if isinstance(results_doc, dict):
            for r in results_doc.get("results") or []:
                if isinstance(r, dict):
                    children.append({"id": r.get("id"),
                                     "ok": bool(r.get("ok")),
                                     "error": r.get("error")})
        dispatch_doc = _read_json_utf8sig(artifact_dir / "dispatch.json")
        consults = (len(children) if children
                    else len(dispatch_doc)
                    if isinstance(dispatch_doc, list) else 0)
        budget = markers.get("budget") if isinstance(
            markers.get("budget"), dict) else {}
        swarm = {
            "children": children,
            "checkpoint_present": (project / "_run_plan.md").exists(),
            "consults_used": consults,
            "consult_budget": budget.get("consults"),
            "tool_call_budget": budget.get("tool_calls"),
        }

    return {"usage": usage if usage.get("available") else None,
            "structural_failures": structural,
            "swarm": swarm}


def _iof_root_path() -> Path:
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve()


# ---------------------------------------------------------------------------
# GET /api/run/{run_id}/steps — list steps
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}/steps")
def list_steps(run_id: str):
    """All steps with status, role, output snippet."""
    store = _store()
    from ioagentfarm.engine.workspaces import get_agent_name

    steps = store.list_steps(run_id)
    return {
        "run_id": run_id,
        "steps": [
            {
                "key": s["step_key"],
                "seq": s["seq"],
                "role": s["role"],
                "agent_name": get_agent_name(s["role"]),
                "status": s["status"],
                "attempt": s["attempt"],
                "max_attempts": s["max_attempts"],
                "output_snippet": (s.get("output_text") or "")[:200],
                "created_at": s.get("created_at"),
                "updated_at": s.get("updated_at"),
            }
            for s in steps
        ],
    }


# ---------------------------------------------------------------------------
# GET /api/run/{run_id}/steps/{step_key} — step detail
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}/steps/{step_key}")
def step_detail(run_id: str, step_key: str):
    """Step detail: full output, attempt count, timestamps."""
    store = _store()
    from ioagentfarm.engine.workspaces import get_agent_name

    steps = store.list_steps(run_id)
    step = next((s for s in steps if s["step_key"] == step_key), None)
    if not step:
        raise HTTPException(status_code=404, detail=f"Step '{step_key}' not found in run {run_id}")

    return {
        "run_id": run_id,
        "key": step["step_key"],
        "seq": step["seq"],
        "role": step["role"],
        "agent_name": get_agent_name(step["role"]),
        "status": step["status"],
        "attempt": step["attempt"],
        "max_attempts": step["max_attempts"],
        "deps": json.loads(step.get("deps_json") or "[]"),
        "output": step.get("output_text") or "",
        "created_at": step.get("created_at"),
        "updated_at": step.get("updated_at"),
    }


# ---------------------------------------------------------------------------
# POST /api/run/{run_id}/steps/{step_key}/reset — reset step
# POST /api/run/{run_id}/steps/{step_key}/retry — retry step
# ---------------------------------------------------------------------------

@app.post("/api/run/{run_id}/steps/{step_key}/reset")
def reset_step(run_id: str, step_key: str):
    """Reset a step back to pending (recovery)."""
    store = _store()
    steps = store.list_steps(run_id)
    step = next((s for s in steps if s["step_key"] == step_key), None)
    if not step:
        raise HTTPException(status_code=404, detail=f"Step '{step_key}' not found")
    if step["status"] not in ("running", "failed", "done"):
        raise HTTPException(status_code=400, detail=f"Step '{step_key}' is '{step['status']}'. Can only reset running, failed, or done steps.")

    with store._tx() as cursor:
        now = store._now()
        cursor.execute(
            store._q("UPDATE steps SET status='pending', updated_at=? WHERE run_id=? AND step_key=?"),
            (now, run_id, step_key),
        )
        cursor.execute(
            store._q("UPDATE runs SET status='running', updated_at=? WHERE id=? AND status IN ('done','failed')"),
            (now, run_id),
        )

    return {"run_id": run_id, "step_key": step_key, "action": "reset", "new_status": "pending"}


@app.post("/api/run/{run_id}/steps/{step_key}/retry")
def retry_step(run_id: str, step_key: str):
    """Retry a failed step (bump max_attempts and reset)."""
    store = _store()
    steps = store.list_steps(run_id)
    step = next((s for s in steps if s["step_key"] == step_key), None)
    if not step:
        raise HTTPException(status_code=404, detail=f"Step '{step_key}' not found")
    if step["status"] != "failed":
        raise HTTPException(status_code=400, detail=f"Step '{step_key}' is '{step['status']}'. Can only retry failed steps.")

    with store._tx() as cursor:
        now = store._now()
        new_max = step["max_attempts"] + 1
        cursor.execute(
            store._q("UPDATE steps SET status='pending', max_attempts=?, updated_at=? WHERE run_id=? AND step_key=?"),
            (new_max, now, run_id, step_key),
        )
        cursor.execute(
            store._q("UPDATE runs SET status='running', updated_at=? WHERE id=? AND status='failed'"),
            (now, run_id),
        )

    return {"run_id": run_id, "step_key": step_key, "action": "retry", "new_status": "pending", "max_attempts": new_max}


# ---------------------------------------------------------------------------
# GET /api/run/{run_id}/tasks — list tasks for a run
# GET /api/run/{run_id}/tasks/{task_id} — task detail
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}/tasks")
def list_run_tasks(run_id: str, status: str | None = None):
    """List tasks for a run, optionally filtered by status."""
    store = _store()
    tasks = store.list_tasks(run_id=run_id, status=status)
    return {
        "run_id": run_id,
        "tasks": [
            {
                "id": t["task_id"],
                "role": t["role"],
                "title": t["title"],
                "status": t["status"],
                "output_snippet": (t.get("output_text") or "")[:200],
                "created_at": t.get("created_at"),
                "completed_at": t.get("completed_at"),
            }
            for t in tasks
        ],
    }


@app.get("/api/run/{run_id}/tasks/{task_id}")
def task_detail(run_id: str, task_id: str):
    """Task detail: full output, timestamps."""
    store = _store()
    task = store.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    return {
        "id": task["task_id"],
        "run_id": task.get("run_id"),
        "role": task["role"],
        "title": task["title"],
        "body": task["body"],
        "status": task["status"],
        "output": task.get("output_text") or "",
        "created_at": task.get("created_at"),
        "spawned_at": task.get("spawned_at"),
        "completed_at": task.get("completed_at"),
    }


# ---------------------------------------------------------------------------
# GET /api/run/{run_id}/messages — conversation history
# ---------------------------------------------------------------------------

@app.get("/api/run/{run_id}/messages")
def list_messages(
    run_id: str,
    after: int = 0,
    limit: int = 100,
    step_key: str | None = None,
    conversation_id: str | None = None,
):
    """Conversation history for a run — unified thread of user, agent, step, task messages.

    Pass ``step_key=chat-<role>`` (e.g. ``chat-analyst``, ``chat-strategist``,
    ``chat-reviewer``) to fetch only the post-submission chat thread for a
    specific role tab — workflow messages (briefing/dialogue/reviewing)
    use different step_keys and are filtered out. Without ``step_key``,
    returns the full unified thread.

    Pass ``conversation_id`` to fetch ONE chat thread's history — the same
    value the POST carried. This is how a UI resumed on another pod (or
    after a browser close) re-renders one conversation: chat rows are
    stamped with their thread at write time, so per-thread history is a
    database read, not a session-file read.
    """
    store = _store()
    messages = store.get_messages_since(
        run_id, after_id=after, step_key=step_key,
        conversation_id=conversation_id, limit=limit,
    )
    return {
        "run_id": run_id,
        "messages": messages,
        "has_more": len(messages) == limit,
    }


# ---------------------------------------------------------------------------
# POST /api/chat/{ns} — ad-hoc chat (no run); ns = the ROLE being addressed
# GET  /api/chat/{ns}/messages — ad-hoc chat history (person + thread)
# ---------------------------------------------------------------------------

class ChatRequest(BaseModel):
    content: str
    agent: str | None = None  # default: cora; set to talk to a specific agent
    sender_id: str = "web_user"
    user_id: str | None = None
    format: str | None = None  # "json" to request structured output envelope
    # THE THREAD, separate from the person - see MessageRequest.conversation_id.
    conversation_id: str | None = None
    composition_mode: str | None = None  # "none" | "smart" | "always"; default "smart"
    # The caller's workspace. An engine pod serves exactly ONE workspace; a
    # request naming a different one is refused rather than silently answered
    # by another tenant's agents. Optional so a same-pod caller may omit it.
    workspace: str | None = None
    # DRAFT SESSION (Try-it): answer from this author's private draft home
    # (pack + their overlay) instead of the shared pool. Supplied by the
    # Studio API from a verified identity — the engine has no auth, so the
    # field is the caller's contract, same as ``user_id``. None keeps the
    # request on the shared pool, byte-identical to today.
    draft_author: str | None = None
    # INTERACTIVE CONVERSATION, set by the Studio's conversations router.
    # It is what scopes the widened v1 treatment below: an agent that promises
    # the envelope gets it parsed, window-measured and row-checked HERE, where
    # a person is reading the answer in a client that renders it. Every other
    # caller of this endpoint — the builder's test panel, a machine caller —
    # keeps exactly today's behaviour, so the blast radius of the widening is
    # one route rather than every consumer of /api/chat at once.
    conversation: bool = False


# JSON output prompt suffix — asks the agent to wrap its final answer in a
# parseable envelope while still writing its normal evidence panel above it.
_JSON_FORMAT_SUFFIX = """

---
**Output format requirement:** In addition to your normal prose answer, append
a final fenced code block exactly like this (valid JSON, nothing after it):

```json
{
  "answer": "<one-line or short-paragraph human answer>",
  "rows": [ /* structured data if any, else empty array */ ],
  "queries": [ /* SQL/vectorfs commands you ran */ ],
  "sources": [ /* entity names or collection names touched */ ],
  "confidence": "high" | "medium" | "low",
  "caveats": [ /* any warnings: stale data, disagreement, low similarity */ ]
}
```

The JSON block MUST be the last content in your response so downstream consumers
can parse it by extracting the final ```json ... ``` block.
"""


# Per-session scratch directory suffix — concurrency-safe temp file isolation.
# The web handler creates a unique dir per session_key (derived hash) and
# injects the path so Quinn writes scratch files (e.g., query.sql) there
# instead of a shared workspace-root filename that parallel requests would
# race on. Hash is deterministic per session, so follow-up turns for the
# same user reuse the same dir.
#: Conversation-route only, and OFF unless the deployment asks (2026-09-05).
#: The reference model (MiniMax) streams `thinking` text between tool calls,
#: and THAT prose is what the Studio's thoughts panel renders - so the chat
#: path never needed to ask for narration. On a provider that does not
#: volunteer text before tool calls (Azure OpenAI, observed on the first
#: client install), the panel degrades to concatenated tool-call labels: raw
#: commands and paths in front of a business user; such a deployment sets
#: `IOF_CHAT_NARRATE=1` in the workspace .env and gets this block back.
#: Measured cost of carrying it everywhere: 20-40 output tokens per model
#: round, on a chat turn that is two rounds - about a second per answer at
#: 50 tokens/s, paid by every deployment for a panel most never look at. The
#: workflow step prompts still carry their own copy of the rule; there it is
#: also the defence against the empty-text stream failure.
_NARRATE_SUFFIX = """

---
**Narrate as you work.** Before every tool call, write ONE short plain-language
sentence saying what you are about to do and why - e.g. "Pulling monthly PA
approval rates from the claims data." Never put raw commands, file paths or
code in these sentences: they are shown live to a business user while they
wait. This narration is separate from your final answer's format rules.
"""

def _chat_narration_enabled() -> bool:
    """`IOF_CHAT_NARRATE=1` asks the model to narrate before every tool call
    on the conversation route (see `_NARRATE_SUFFIX`). Off by default."""
    return os.environ.get("IOF_CHAT_NARRATE", "").strip().lower() in ("1", "true", "yes", "on")


_SCRATCH_DIR_SUFFIX = """

---
**Scratch workspace for this call:** `{dir}/`

**When you do query, it is ONE tool call** — pass the SQL inline; do not write
it to a file first (the file was a second model round on every question and
bought nothing for a query that fits on a line). Whether to query at all is
your composer skill's call: an interpretive follow-up over results already in
this conversation needs no new query.

```
iof-query --scratch {dir} --db <source> --sql "SELECT ..." --metadata-dir metadata
```

Double quotes around the SQL, single quotes inside it. Only a statement too
long for one line (several hundred characters, a long IN list) goes through a
file, and then into THIS directory: `--sql-file {dir}/query.sql`.

The directory is isolated per-session. It holds the per-session tool-call
budget counter (tool_budget.json) that the CLIs read to track your usage and
refuse further calls past the hard cap — which is why `--scratch {dir}` goes on
every `iof-query` call, and `--scratch {dir}` is the FIRST argument of every
`vectorfs` call (before the grep/cat/ls command):

```
vectorfs --scratch {dir} "grep -ri 'termination' /contracts/aws"
vectorfs --scratch {dir} "ls /contracts"
vectorfs --scratch {dir} "cat /contracts/oracle/0015"
```

Do NOT write to `query.sql` at workspace root — parallel requests from other
users share that path and will overwrite each other's SQL mid-execution.
Omitting `--scratch` means the tool cannot track budget and will emit a
warning. Always include it.
"""


# Composition mode suffixes — control how verbose the final answer is.
# `smart` (default) minimizes output for simple tabular/scalar answers.
# `none` returns raw data with zero narrative. `always` is unchanged (no suffix).
_COMPOSITION_SUFFIX_NONE = """

---
**Composition mode: NONE.** After your last tool_result, your final response
MUST be the raw data only — no narrative, no prose, no analysis, no evidence
panel. Scalar answer: just the number/string. Tabular answer: minimal markdown
table or compact JSON. Nothing else. The client will compose its own UI.
"""

#: Roles ALWAYS treated as v1-envelope agents, on every route. Kept as a
#: literal only so the two that predate the detector cannot regress: `aria`
#: has no agent workspace in this repository (its home is the sibling product),
#: so nothing on disk could tell us about it. Every other agent is recognised
#: by what it SHIPS - see `engine/output_contract.emits_v1_envelope`.
_V1_ROLES = ("queryngine", "aria", "ainf_query")

_PHASE1_SUFFIX = """

---
**PHASE 1 OF 2 - numbers only.** Run your query and return the envelope with ONLY these populated:

- `answer` - the one-line verdict
- `data` - the table
- `viz_hint`

Set `insight`, `follow_up_chips` and `evidence` to null. Do not write the commercial read yet; you will be asked for it next, and writing it now delays the numbers reaching the user for no benefit.
"""

_PHASE2_PROMPT = """**PHASE 2 OF 2 - the read.** The rows you just returned are in this session; do NOT query again.

Return a JSON block containing ONLY the three fields you left null:

```json
{"insight": "...", "follow_up_chips": ["..."], "evidence": {...}}
```

Do NOT repeat `answer`, `data` or `viz_hint` - they are already delivered, and regenerating those rows costs the user time for cells they can already see. The engine merges your three fields onto them.
"""


def _merge_phases(p1: dict, p2: dict) -> dict:
    """Phase 2's three fields onto phase 1's numbers.

    The direction matters. Phase 1 owns `answer`, `data` and `viz_hint` and
    phase 2 is told not to repeat them, so a merge the other way round would
    let an omission blank the table the reader is already looking at.

    The second loop fills only holes phase 1 LEFT (`None` or absent), which is
    what lets phase 2 supply a field nobody anticipated without letting it
    overwrite a figure. `attachment` is in the explicit list because phase 1
    legitimately sets it to null and phase 2 legitimately fills it.
    """
    merged = dict(p1)
    for k in ("insight", "follow_up_chips", "evidence", "attachment"):
        if p2.get(k) is not None:
            merged[k] = p2[k]
    for k, v in p2.items():
        if merged.get(k) is None:
            merged[k] = v
    return merged


def _two_phase_enabled(*, v1: bool, conversation: bool) -> bool:
    """Default ON for a v1 agent on the conversation route.

    Inverted from the reference implementation, where it is opt-in and off, and
    driven by the agent's contract rather than its name. Two passes cost one
    extra LLM round and buy two things: the verdict reaches the reader while
    the commentary is still being written, and phase 2 never regenerates the
    table - so the figures cannot drift between generations, which one prompt
    asking for everything at once cannot promise.

    CONVERSATION ONLY, and that is the narrower half of this rule. The phase
    prompts split the answer across two turns, so a caller that is not a person
    watching a client render the halves pays the extra round for nothing - and
    a machine caller parsing one reply would receive two. `v1` is required
    because those prompts NAME the envelope's fields; an agent with a different
    output contract would be asked for fields it has never heard of.

    The variable keeps the reference's name though the scope is now wider than
    one agent: it is the knob that deployment already documents.
    """
    if not (conversation and v1):
        return False
    return os.environ.get("IOF_CORA_TWO_PHASE", "").strip().lower() not in (
        "0", "false", "no", "off")


_COMPOSITION_SUFFIX_SMART = """

---
**Composition mode: SMART.** Keep the final answer minimal.
- Scalar answer (one number / one name): respond with just that value plus a
  one-line evidence tag. Do not add insight, framing, or follow-up suggestions.
- Small tabular (≤ 10 rows, one source): a plain markdown table plus a one-line
  evidence tag. No narrative above or below.
- Multi-source, narrative-required, or cross-cutting question: compose as
  normal (this is the case where narrative earns its cost).
Cut every token that does not directly answer the question.
"""

# Tool-call budget (queryngine only) — bounds absence-spirals, over-thoroughness,
# and infra-rabbit-hole failures. See vectorfs_query/SKILL.md for the matching
# skill-level rules. This suffix is prompt-level reinforcement; the numeric cap
# also drives the telemetry in chat.end logs.
_QUERYNGINE_TOOL_BUDGET = 8          # advisory — surfaced in skill + prompt
_QUERYNGINE_TOOL_BUDGET_HARD = 15    # hard — enforced at tool layer via per-session budget file

_BUDGET_SUFFIX = """

---
**TOOL CALL BUDGET: {budget} calls total for this request.** Every exec call to
`vectorfs` or `iof-query` costs 1. When you reach {budget}, you MUST compose the
envelope with whatever data you have — do not attempt more tool calls. A partial
answer with honest `caveats[]` is strictly better than a perfect answer that
burned 30 rounds.

Three hard rules within the budget:
1. **Representative, not exhaustive.** For *"top N vendors"* / *"which vendors
   have X"* / *"compare Y across vendors"* questions, ONE confident data point
   per entity is enough. Don't iterate for completeness.
2. **No meta-debugging.** If a tool returns an error or unexpected output,
   note it in `caveats` and move on. Forbidden: `python -c "print(...)"`,
   environment-variable checks, connectivity probes, grep for QDRANT_URL /
   VECTORFS_STORE. Infra is not your problem.
3. **Absence is a valid answer.** If a clause isn't in the searched contracts
   after 2-3 scoped greps, conclude not-present. Return `null` for that row's
   value and add a caveat like `"AWS: no termination notice clause found"`.
"""


def _render_aria_rules_block(rules: dict) -> str:
    """Format active ARIA business rules as a markdown suffix block.

    Returns empty string when rules is empty so the caller can skip injection
    and ARIA falls back to hardcoded defaults in her skill files.
    """
    if not rules:
        return ""

    lines: list[str] = ["\n\n---\n## Active business rules (override skill file defaults)\n"]

    # --- CRA clause penalties ---
    clauses = rules.get("clauses", {})
    if clauses:
        lines.append("### CRA clause penalties")
        lines.append("| Clause field | Rule set | Penalty pts |")
        lines.append("|---|---|---|")
        for rule_set, rows in clauses.items():
            for r in rows:
                lines.append(f"| {r['clause_field']} | {rule_set} | +{r['penalty_points']} |")

    # --- Scalar rules by domain ---
    scalar_rules = rules.get("rules", {})
    if scalar_rules:
        for domain, keys in scalar_rules.items():
            lines.append(f"\n### {domain.replace('_', ' ').title()} thresholds")
            for key, meta in keys.items():
                val = meta.get("value", "")
                try:
                    import json as _json
                    parsed = _json.loads(val)
                    if isinstance(parsed, dict):
                        val = " | ".join(f"{k}: {v}" for k, v in parsed.items())
                    elif isinstance(parsed, list):
                        val = ", ".join(str(x) for x in parsed)
                except Exception:
                    pass
                applies = f" (applies_to: {meta['applies_to']})" if meta.get("applies_to") else ""
                lines.append(f"- **{key}**: {val}{applies}")

    # --- Checklists ---
    checklists = rules.get("checklists", {})
    if checklists:
        lines.append("\n### Operational checklists")
        for cid, steps in checklists.items():
            required_steps = [s for s in steps if s.get("required")]
            advisory_steps = [s for s in steps if not s.get("required")]
            lines.append(f"\n**{cid.replace('_', ' ').title()}** ({len(steps)} steps):")
            for s in sorted(steps, key=lambda x: x.get("step_order", 0)):
                req_flag = "" if s.get("required") else " *(advisory)*"
                detail = f" — {s['step_detail']}" if s.get("step_detail") else ""
                lines.append(f"  {s['step_order']}. **{s['step_label']}**{req_flag}{detail}")

    # --- Vendor fiscal calendars (compact table) ---
    calendars = rules.get("calendars", [])
    if calendars:
        lines.append("\n### Vendor fiscal year-end / negotiation windows")
        lines.append("| Vendor | FY End | Best Window | Discount Uplift |")
        lines.append("|---|---|---|---|")
        for c in calendars:
            uplift = c.get("discount_uplift_pct") or "—"
            lines.append(f"| {c['vendor_name']} | {c['fy_end_label']} | {c['best_window_label']} | {uplift} |")

    # --- Negotiation terms playbook (compact — bd_relevant only) ---
    neg_terms = rules.get("negotiation_terms", [])
    if neg_terms:
        lines.append("\n### Negotiation terms playbook (BD-relevant only)")
        lines.append("| Term | Category | Difficulty | Moderate leverage | High leverage |")
        lines.append("|---|---|---|---|---|")
        for t in neg_terms:
            mod = (t.get("moderate_leverage_action") or "")[:120].replace("|", "/").replace("\n", " ")
            high = (t.get("high_leverage_action") or "")[:120].replace("|", "/").replace("\n", " ")
            lines.append(f"| {t['term_name']} | {t['category']} | {t['difficulty']} | {mod} | {high} |")

    return "\n".join(lines)


# FIX 1G — CJK encoding artifact sanitization for ARIA responses.
# MiniMax occasionally leaks CJK tokenization artifacts into generated text.
# Strip any CJK codepoint runs that appear outside of legitimate vendor/entity names.
import re as _re_san

_CJK_RANGES = [
    (0x4E00, 0x9FFF),   # CJK Unified Ideographs
    (0x3400, 0x4DBF),   # CJK Extension A
    (0xF900, 0xFAFF),   # CJK Compatibility
    (0x3000, 0x303F),   # CJK Symbols & Punctuation
    (0xFF00, 0xFFEF),   # Halfwidth/Fullwidth Forms
]


def _has_cjk(text: str) -> bool:
    for ch in text:
        cp = ord(ch)
        if any(lo <= cp <= hi for lo, hi in _CJK_RANGES):
            return True
    return False


from ioagentfarm.engine.always_on import is_desk_side  # noqa: E402


def _chat_workspace_id(store, code: str | None) -> int | None:
    """The workspaces row id for *code*, for stamping a chat message.

    EVERY conversation row must carry the tenant it belongs to, because that
    is the only thing ``workspace delete`` can match on. Chat messages have no
    run, so the per-run sweep never reached them, and they were written with
    ``workspace_id = NULL`` - so the unconditional message delete added for
    exactly this matched nothing. An independent validator counted 558 rows
    surviving a documented teardown, 34 of them holding the secrets the
    walkthrough had planted, and every caller identifier that ever chatted.

    Returns ``None`` rather than raising: an unattributed message is bad, and
    a turn that fails because the lookup did is worse.
    """
    if not code:
        return None
    try:
        row = store.get_workspace(code)
        return int(row["id"]) if row and row.get("id") is not None else None
    except Exception:  # noqa: BLE001 - never break a turn over attribution
        logger.debug("workspace id unresolved for chat message", exc_info=True)
        return None


_SHARED_THREAD_WARNED: set = set()


def _warn_shared_thread(uid: str) -> None:
    """Say ONCE that an unattributed caller is on a shared conversation.

    Omitting `user_id` is a legacy shape that still works, and it is the most
    expensive integration mistake available here: every caller that omits it
    lands on the same thread and can read the others' messages. It cannot be
    refused without breaking single-caller deployments that rely on it, so it
    is announced - once per default identity per process, because a warning on
    every turn is a warning nobody reads.
    """
    if uid in _SHARED_THREAD_WARNED:
        return
    _SHARED_THREAD_WARNED.add(uid)
    logger.warning(
        "chat request carried no `user_id`; this caller is on the SHARED "
        "thread {!r}. Every caller that omits the field joins it and can read "
        "the others' messages. Send a stable per-caller identifier.", uid)


import re as _re_mod

_PROVIDER_ERROR_RE = _re_mod.compile(
    r"^\s*Error:\s*\{\s*['\"]type['\"]\s*:\s*['\"]error['\"]")


def _provider_error_in(response: str):
    """The provider error a reply is CARRYING, if it is carrying one.

    Matched narrowly on the runtime's own shape - ``Error: {'type': 'error',
    ...}`` - not on the word "Error", because an agent may legitimately
    discuss errors, quote one from a log, or explain a failure it handled.
    Widening this would turn ordinary answers into reported failures, which
    is a worse defect than the one it fixes.
    """
    if not isinstance(response, str) or not response:
        return None
    if _PROVIDER_ERROR_RE.match(response):
        return response.strip()[:500]
    return None


#: Prefixes that CONSUME their argument, so nothing after them in that
#: segment is a program: ``cd /x`` runs no tool, and the ``/x`` is a path.
#: The whole segment is dropped.
#:
#: Commands that PRECEDE the real work rather than doing it, in BOTH shells.
#:
#: The bash spellings were here and the PowerShell ones were not - and the
#: agent's ``exec`` runs through PowerShell on Windows, which the tools
#: walkthrough states in its own troubleshooting. So the fix was written for
#: a shell the deployment does not use, and a validator caught
#: ``Set-Location C:/...; iof-...`` reported as ``exec:Set-Location``.
_SHELL_PREFIXES = frozenset({
    # POSIX
    "cd", "chdir", "export", "source", ".", "env", "time", "nohup", "exec",
    "then", "do", "else", "eval", "command", "builtin",
    # PowerShell (and its aliases, which is how they are actually typed)
    "set-location", "sl", "push-location", "pushd", "pop-location", "popd",
    "set-item", "new-item", "out-null", "write-host", "write-output",
    "select-object", "where-object", "foreach-object", "measure-object",
    # cmd
    "setlocal", "endlocal",
})

#: WRAPPERS: the program they run is the NEXT token, not the segment's end.
#: Treating these like `cd` dropped the whole segment, so `env iof-query ...`
#: reported no program at all - the validator's "segment-skipped rather than
#: stepped past" note. They are stepped past, one token at a time.
_WRAPPER_PREFIXES = frozenset({
    "env", "time", "nohup", "exec", "call", "start", "command", "builtin",
    "eval", "stdbuf", "nice", "xargs",
})

#: Interpreters whose REAL command is inside a quoted argument.
_INTERPRETERS = frozenset({
    "bash", "sh", "zsh", "dash", "ksh", "powershell", "pwsh", "powershell.exe",
    "cmd", "cmd.exe", "busybox", "python", "python3", "py",
})

#: Where one command in a compound line ends and the next begins.
_SEPARATORS = re.compile(r"&&|\|\||;|\||\n|`n")


def _binary_of(token: str) -> str:
    """The program name from a token: no path, no quotes, no ``.exe``."""
    name = (token or "").strip().strip("\"'()")
    name = name.replace("\\", "/").rsplit("/", 1)[-1]
    if name.lower().endswith(".exe"):
        name = name[:-4]
    return name


def _segments_of(command: str) -> list:
    """Split into commands at separators that are OUTSIDE quotes.

    Splitting the raw string first was wrong: a `;` inside a quoted payload
    (`bash -lc "cd /x; iof-query ..."`) cut the command in half, leaving an
    unbalanced quote that defeated the tokenizer and reported a path fragment
    as a program. Tokenize once, then group.
    """
    try:
        import shlex
        lex = shlex.shlex(command, posix=False, punctuation_chars=True)
        lex.whitespace_split = True
        tokens = list(lex)
    except Exception:  # noqa: BLE001
        tokens = command.split()
    segments, current = [], []
    for tok in tokens:
        if tok in (";", "&&", "||", "|", "&", chr(10)):
            if current:
                segments.append(current)
            current = []
        else:
            current.append(tok)
    if current:
        segments.append(current)
    return segments


def _split_command(command: str) -> list:
    """Tokens, respecting quotes.

    ``str.split`` turned ``"C:/Program Files/py/python.exe" -c ...`` into
    ``exec:Program``. ``shlex`` handles the quoting; a malformed command
    falls back rather than raising, because a label must never break a turn.
    """
    try:
        import shlex
        return shlex.split(command, posix=False)
    except Exception:  # noqa: BLE001
        return command.split()


def _programs_in(command: str, depth: int = 0) -> list:
    """EVERY program a shell command runs, in order, de-duplicated.

    Reporting ONE program was the wrong model and failed four times: the
    first token (``cd``), then the first token of the first segment
    (``Set-Location``), then any leading command that is not on a prefix list
    (``echo``, ``cat``, ``dir``). Each fix moved the guess; none removed it.

    A compound command runs several programs and the honest answer names them
    all - then a caller asking "did the declared tool answer this?" gets a
    yes or no rather than a guess that is right most of the time. Shell
    prefixes are still dropped, because ``cd`` is not a source of an answer.
    """
    if depth > 2 or not command:
        return []
    out: list = []
    for tokens in _segments_of(command):
        tokens = list(tokens)
        # Step PAST env assignments WITHIN the segment.
        while tokens and "=" in tokens[0] and not tokens[0].startswith("-"):
            tokens = tokens[1:]
        if not tokens:
            continue
        # Step past WRAPPERS (the program is the next token); DROP the
        # segment on a consuming prefix (`cd /x` runs nothing).
        while tokens and _binary_of(tokens[0]).lower() in _WRAPPER_PREFIXES:
            tokens = tokens[1:]
            while tokens and tokens[0].startswith("-"):
                tokens = tokens[1:]
        if not tokens:
            continue
        binary = _binary_of(tokens[0])
        if not binary or binary.lower() in _SHELL_PREFIXES:
            continue
        if binary.lower() in _INTERPRETERS:
            # `bash -lc "iof-query ..."` - the real work is in the payload.
            inner: list = []
            for tok in tokens[1:]:
                if tok.startswith("-"):
                    continue
                inner = _programs_in(tok.strip("\"'"), depth + 1)
                if inner:
                    break
            out.extend(inner or [binary])
            continue
        out.append(binary)
    seen: set = set()
    return [p for p in out if not (p in seen or seen.add(p))]


def _invoked_name(tool: str, arguments) -> str:
    """``exec`` plus the binaries it ran, so a caller can tell them apart.

    Every console script - a pack's own tool, ``iof-query``, anything on PATH
    - reaches the model as one tool called ``exec``. Reporting that name alone
    could not answer the question this field exists for. A program name is not
    sensitive: it is what was run, not what was passed to it.

    Several programs in one command are joined with ``+``, so nothing is
    hidden by a guess about which one mattered.
    """
    if tool != "exec":
        return tool
    try:
        command = ""
        if isinstance(arguments, dict):
            command = str(arguments.get("command") or arguments.get("cmd") or "")
        elif isinstance(arguments, str):
            command = arguments
        programs = _programs_in(command)
        if programs:
            return "exec:" + "+".join(programs)
    except Exception:  # noqa: BLE001 - a label must never break a turn
        pass
    return tool


def _first_arg(arguments) -> str:
    """The one argument a reader recognises, shortened.

    A tool line is only useful if it says WHICH file or query; the whole
    argument dict is noise on a progress row.
    """
    if isinstance(arguments, str):
        text = arguments
    elif isinstance(arguments, dict):
        for key in ("command", "path", "file_path", "sql", "query", "name"):
            if arguments.get(key):
                text = str(arguments[key])
                break
        else:
            text = str(next(iter(arguments.values()), "")) if arguments else ""
    else:
        text = ""
    text = " ".join(str(text).split())
    return text[:90] + ("..." if len(text) > 90 else "")


def _sanitize_aria_output(text: str, context: str = "") -> str:
    """Strip CJK tokenization artifacts from ARIA responses."""
    if not text or not _has_cjk(text):
        return text
    cleaned = _re_san.sub(r"[一-鿿㐀-䶿豈-﫿　-〿＀-￯]+", "", text)
    logger.warning("aria.sanitize_artifact context={} original_len={} cleaned_len={}", context, len(text), len(cleaned))
    return cleaned


def _bound_owner(request) -> str | None:
    """The verified PERSON this request must act as - or None when unbound.

    `IOF_CHAT_BIND_PRINCIPAL=1` closes the gap the Conversations surface
    already closed for threads: the legacy ad-hoc chat routes trusted the
    `user_id` the client sent, so any verified caller could read any
    person's chat history by naming them. Bound, the owner is derived the
    way `/v1/conversations` derives it - actor first, so a UI proxying
    through a service account binds to the human, not the service.

    Opt-in for now: existing proxies that authenticate as a service and
    send end-user ids in `user_id` keep working until they can send the
    actor claim. None when the flag is off, when no auth layer is
    installed, or when the caller is unauthenticated (`method == "none"`)
    - an anonymous engine has nothing to bind to.
    """
    if os.getenv("IOF_CHAT_BIND_PRINCIPAL", "").strip().lower() not in (
            "1", "true", "yes"):
        return None
    try:
        from ioagentfarm.web.auth import principal_of
        principal = principal_of(request)
    except Exception:  # noqa: BLE001 - auth is optional
        return None
    if principal is None or getattr(principal, "method", "") == "none":
        return None
    who = (getattr(principal, "actor", "") or getattr(principal, "email", "")
           or getattr(principal, "subject", ""))
    return who or None


@app.post("/api/chat/{ns}")
async def adhoc_chat_route(ns: str, req: ChatRequest,
                           request: Request):
    """The HTTP surface for :func:`adhoc_chat`.

    ``ns`` is the chat NAMESPACE — by convention the ROLE being addressed
    (``/api/chat/insights_meta``), and part of the session key, so the same
    thread name under two namespaces is two threads. The parameter was
    historically called ``workflow_name``; the surface is role-based and
    the docs have always written it ``/api/chat/{ns}``.

    A separate function ONLY so that ``session_key`` cannot be set over the
    wire. **Naming a session is naming whose memory to resume**, and this
    endpoint's notion of who is calling is never better than the ``user_id`` it
    was handed — so an in-process caller that has already resolved an owner
    (the conversations router) may pass a key, and an HTTP caller may not.

    Nothing else belongs here: the turn, and every test that reads its source,
    stays :func:`adhoc_chat`.
    """
    return await adhoc_chat(ns, req, request)


async def adhoc_chat(workflow_name: str, req: ChatRequest, request: Request,
                     *, session_key: str | None = None):
    """Ad-hoc chat scoped to a workflow — no run context.

    Use for general questions, data queries, or conversations
    not tied to a specific run.

    Set `format: "json"` to receive the answer with a trailing JSON envelope
    suitable for programmatic consumption (the envelope is also extracted and
    returned separately on the response).

    ``session_key`` NAMES THE SESSION, and is the interface the conversation
    layer needed. Before it, the only lever on which session a turn resumed was
    ``user_id`` — the correlation key stamped on the narration rows — because
    the key was derived from it. A caller wanting its own thread therefore had
    to smuggle a thread id through a field meant for something else, and the
    Studio did exactly that: it computed a key, sent it in a field
    ``ChatRequest`` does not declare (so pydantic dropped it), and got separate
    threads only as a side effect of the id it had also packed into
    ``user_id``. It is keyword-only and absent from ``ChatRequest`` so it
    reaches no wire; see :func:`adhoc_chat_route`.
    """
    _set_inbound_tp(request)
    import time as _time

    # AN EMPTY MESSAGE BUYS NOTHING, and it is refused FIRST - before the
    # pool, the store row, the prompt assembly and the model call. It used to
    # be accepted, dispatched and billed: HTTP 200 after a full LLM call
    # (14s, the slowest turn of the B3 certification round) on a message
    # nobody wrote. Worse, the engine's own suffixes are appended to
    # `content`, so with an empty one the model received a prompt made
    # ENTIRELY of engine scaffolding and answered that - "I'm ready to help
    # you run SQL queries" from a warm conversational agent, which reads as
    # the agent going rogue. Beside the 422 a malformed body already gets.
    if not (req.content or "").strip():
        raise HTTPException(status_code=400, detail=(
            "`content` is empty. A chat request must carry the user's "
            "message; an empty one would spend a model call on the engine's "
            "own prompt scaffolding and answer that instead."))

    # GUARDRAILS, INPUT HALF (engine/guardrails.py). No policy declared =
    # `_gr` is None and nothing below changes. A refusal is HTTP 422 here,
    # BEFORE the pool, the store row and the prompt - the model is never
    # asked. With redaction on, `req.content` is REPLACED, so the stored row,
    # the prompt, the session file and the chat.start digest all see the
    # redacted text; the original is not kept anywhere in this process.
    from ioagentfarm.engine.guardrails import (guard_input as _guard_in,
                                               guard_output as _guard_out)
    _gr_text, _gr = _guard_in(
        req.content, req.workspace or getattr(app.state, "workspace_code", None))
    if _gr is not None and _gr_text != req.content:
        req.content = _gr_text

    # A DESK-SIDE ROLE DOES NOT ANSWER OVER HTTP. Refused here so the caller
    # gets a 403 that says where it DOES answer; `AgentPool.get` refuses it
    # again as a backstop for every other surface.
    if is_desk_side(req.agent or ""):
        raise HTTPException(status_code=403, detail=(
            f"agent '{req.agent}' is a desk-side role and is not served over "
            "HTTP. It runs shell commands and writes files, so it answers "
            "only at a terminal: run `aicore build` on the machine that owns "
            "the workspace."))

    # AN EXPLICIT EMPTY `user_id` IS A CALLER BUG, AND IT POOLS CONVERSATIONS.
    # `user_id` IS the conversation thread. Sent empty it falls through to the
    # shared default, so several unrelated callers land in ONE thread and read
    # each other's messages. An independent validator demonstrated it in three
    # requests: caller 1 stated a confidential deal value, callers 2 and 3 -
    # one omitting the field, one sending "" - were both told it.
    #
    # Omission is a legacy shape and still works (warned below); a field
    # PRESENT and blank is unambiguous - the caller meant to identify someone
    # and sent nothing - so it is refused rather than quietly pooled.
    if req.user_id is not None and not req.user_id.strip():
        raise HTTPException(status_code=400, detail=(
            "`user_id` is empty. It is the conversation thread: an empty "
            "value falls through to a shared default, so unrelated callers "
            "would share one conversation and read each other's messages. "
            "Send a stable per-caller identifier, or omit the field entirely "
            "if this deployment has a single caller."))

    pool: AgentPool = getattr(app.state, "agent_pool", None)
    if not pool:
        raise HTTPException(status_code=503, detail="Agent pool not available")

    pod_ws = getattr(app.state, "workspace_code", None)
    if req.workspace and pod_ws and req.workspace != pod_ws:
        raise HTTPException(
            status_code=409,
            detail=(f"this engine serves workspace '{pod_ws}'; the request "
                    f"names '{req.workspace}'. Point the caller at the "
                    f"engine for its workspace."))

    store = _store()
    # ATTRIBUTE EVERY MESSAGE THIS TURN WRITES. See _chat_workspace_id: an
    # unstamped row is a row no deletion can find.
    chat_ws_id = _chat_workspace_id(store, req.workspace or pod_ws)
    role = req.agent or "cora"
    uid = req.user_id or f"web:{req.sender_id}"
    _owner = _bound_owner(request)
    if _owner:
        if req.user_id and req.user_id != _owner:
            # An authenticated caller asserting a DIFFERENT person is the
            # exact impersonation binding exists to stop - refused, never
            # silently rewritten, so a misconfigured client learns.
            raise HTTPException(status_code=403, detail=(
                f"user_id '{req.user_id}' does not match the authenticated "
                "principal. With IOF_CHAT_BIND_PRINCIPAL on, chat acts as "
                "the verified caller; omit user_id or send your own."))
        uid = _owner
    if req.conversation_id is not None and not req.conversation_id.strip():
        raise HTTPException(status_code=400, detail=(
            "`conversation_id` is empty. It names the conversation thread "
            "(one user may hold several); send a stable id, or omit the "
            "field to thread by user_id."))
    # THREAD vs PERSON - see MessageRequest.conversation_id. The thread
    # scopes the session; uid stays what attribution, user-scope memory and
    # preferences key on. An explicit conversation_id is an explicit thread
    # choice, so the shared-default warning does not apply.
    thread = req.conversation_id or uid
    # THE SESSION KEY CARRIES THE PERSON, NOT ONLY THE THREAD NAME.
    # `conversation_id` is chosen by the CLIENT, so two people who pick the
    # same ordinary name ("q3-review") landed in ONE agent session: a
    # hardening probe had a second verified principal name another's thread
    # and the agent replayed her question and her figures back to him. The
    # STORED conversation_id stays the caller's own value - history filters
    # on it - and only the session is namespaced.
    session_thread = f"{uid}::{thread}" if req.conversation_id else uid
    if not req.user_id and not req.conversation_id:
        _warn_shared_thread(uid)

    # THE FIRST ROW IS WRITTEN BEFORE ANYTHING SLOW, and that placement is
    # the whole value of it. Written later in this handler - after the agent
    # pool is asked for the agent, the scratch directory is made and the
    # prompt is composed - it arrived 48 SECONDS after the question, because
    # everything above it can block. Here it needs only the role and the
    # user, so the reader learns the request was received while the agent is
    # still being constructed.
    try:
        # Imported HERE, not relied upon from below: this row is written
        # before the handler's own `get_agent_name` import, and the first
        # version of it raised NameError into the `except` beneath - which
        # swallowed it, so the row silently never appeared and the fix
        # looked like it had not worked at all.
        from ioagentfarm.engine.workspaces import (
            get_agent_name as _get_agent_name)
        _who = _get_agent_name(role)
        store.insert_message(user_id=uid, conversation_id=thread,
                             source="agent", role=role,
                             workspace_id=chat_ws_id,
                             agent_name=_who,
                             content=f"{_who} is working on it",
                             msg_type="thought")
    except Exception:                     # noqa: BLE001 - never break a turn
        logger.warning("opening progress row not written", exc_info=True)

    # DRAFT SESSION: the loop AND the workspace path both come from the
    # author's private draft home — the plan-cache metadata dir and the
    # envelope validator's session read below key off workspace_path, and a
    # draft session answering from the draft loop while validating against
    # the SHARED home's session file would validate somebody else's turns.
    draft_items: list[dict] | None = None
    if req.draft_author:
        try:
            agent, _draft_home, _draft_rows = await pool.get_draft(
                req.draft_author, role)
        except Exception as exc:
            raise HTTPException(
                status_code=400,
                detail=f"Could not create draft agent for role '{role}': {exc}")
        from ioagentfarm.engine.drafts import provenance_summary
        draft_items = provenance_summary(_draft_rows)
        workspace_path = Path(_draft_home)
    else:
        try:
            agent = pool.get(role)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Could not create agent for role '{role}': {exc}")
        workspace_path = iobot_agent_workspace(role)

    from ioagentfarm.engine.workspaces import get_agent_name
    agent_display_name = get_agent_name(role)

    # Is this a v1-envelope agent? By NAME for the three that always were, and
    # otherwise by what the agent ships - but only on the conversation route,
    # which is what keeps the widening to one caller.
    from ioagentfarm.engine.output_contract import (emits_v1_envelope,
                                                    uses_query_tools)
    v1_by_content = bool(req.conversation) and emits_v1_envelope(workspace_path)
    is_v1 = role in _V1_ROLES or v1_by_content
    if v1_by_content and role not in _V1_ROLES:
        logger.info("chat.v1_by_contract role={} - its own always-on skill"
                    " mandates the envelope", role)

    # Persist user message
    store.insert_message(
        user_id=uid,
        conversation_id=thread,
        workspace_id=chat_ws_id,
        source="user",
        content=req.content,
        msg_type="message",
    )

    # Stable session per user+workflow+role (no run). A draft session gets
    # its OWN key namespace: its JSONL lives in the draft home's sessions/,
    # and sharing the ordinary key would let a later non-draft turn resume a
    # conversation whose earlier answers came from the overlay.
    if session_key:
        # NAMED BY THE CALLER. Highest precedence, including over a draft
        # author: a caller that supplies a key has already decided which
        # memory this turn belongs to, and a derivation quietly overriding it
        # would be the same laundering this parameter exists to end.
        pass
    elif req.draft_author:
        from ioagentfarm.engine.drafts import author_slug
        session_key = f"web:draft:{author_slug(req.draft_author)}:{role}:u:{session_thread}"
    else:
        session_key = f"web:chat:{workflow_name}:{role}:u:{session_thread}"

    # Per-session scratch directory. Derived from session_key so same user
    # reuses the same dir across turns, but parallel requests from other
    # users get different dirs — eliminates races on shared temp files like
    # `query.sql`. If the dir cannot be created we skip the injection rather
    # than fail the request.
    import hashlib as _hashlib
    from pathlib import Path as _Path
    scratch_hash: str | None = None
    scratch_dir: _Path | None = None
    budget_file: _Path | None = None
    try:
        scratch_hash = _hashlib.sha256(session_key.encode("utf-8")).hexdigest()[:10]
        # No literal /app/.iof fallback: that is the POD's root, and using it
        # as the default meant a host without IOF_ROOT exported prepared its
        # scratch under a Linux path (drive-relative C:\app\.iof on Windows).
        # serve exports IOF_ROOT at startup, so this resolves consistently.
        iof_root = _iof_root_path()
        scratch_dir = iof_root / "tmp" / role / scratch_hash
        scratch_dir.mkdir(parents=True, exist_ok=True)
        # Initialize per-session tool-call budget. File lives in the per-session
        # scratch dir (unique per user+workflow+role), so concurrent requests
        # from different users never touch the same budget file. Tools read
        # this file on each invocation and refuse past the limit — see
        # vectorfs.ts `--scratch` flag and query_executor.py auto-derive.
        if role == "queryngine":
            budget_file = scratch_dir / "tool_budget.json"
            # write-then-rename pattern for atomic initialization
            import json as _json, tempfile as _tempfile, os as _os
            _tmp = scratch_dir / f".tool_budget.{_os.getpid()}.tmp"
            _tmp.write_text(_json.dumps({"used": 0, "limit": _QUERYNGINE_TOOL_BUDGET_HARD}), encoding="utf-8")
            _tmp.replace(budget_file)
    except Exception as _scratch_exc:
        logger.warning("chat.scratch_dir.create_failed role={} err={}", role, _scratch_exc)
        scratch_hash = None
        scratch_dir = None
        budget_file = None

    # Stream intermediate thoughts to messages table, and count them for observability
    from ioagentfarm.cli_orchestration import _is_noise
    from ioagentfarm.web.thought_processor import classify_thought

    thought_count = 0
    tool_call_count = 0
    # WHICH tools ran, not just how many. `tool_calls` is one scalar, so a
    # caller could not tell an answer read from the declared tool from one the
    # model composed out of whatever else it could see - and that is exactly
    # the distinction a grounded deployment has to make. An independent
    # validator found every wrong-source reply carrying a HIGHER tool_calls
    # than a correct one, because the agent had gone looking. Ordered, unique,
    # first use first.
    tools_used: list[str] = []

    def _bump_budget_file() -> None:
        """Atomically increment `used` in the per-session budget file.

        Per-session scratch dir is unique per (user, workflow, role), so this
        never races with other users' requests. Within one request the
        orchestrator is single-threaded (asyncio) so no in-request race.
        """
        if budget_file is None:
            return
        try:
            import json as _json
            data = _json.loads(budget_file.read_text(encoding="utf-8"))
            data["used"] = int(data.get("used", 0)) + 1
            _tmp = budget_file.with_suffix(".json.tmp")
            _tmp.write_text(_json.dumps(data), encoding="utf-8")
            _tmp.replace(budget_file)
        except Exception as _bump_exc:
            logger.debug("budget.bump_failed err={}", _bump_exc)

    # ENVELOPE LATCH, ported from the reference implementation - the piece
    # deliberately SKIPPED in the first port, because the reference model's
    # stream never forwarded the final generation through the progress hook.
    # A runtime that does (observed live: iobot 0.8 + Azure OpenAI) floods the
    # thoughts panel with the entire envelope - schema, answer, and every data
    # row - which is both the "raw JSON in the thoughts" symptom and most of
    # the perceived slowness: hundreds of row-chunks each riding the
    # store -> poll -> render pipeline. Once a marker is seen, chunks are
    # dropped until a tool call proves the agent went back to work; the latch
    # resets per GENERATION (each _turn, and the fabrication retry), exactly
    # as the reference does - without the reset, phase 2's narration is
    # suppressed wholesale by phase 1's envelope.
    _envelope_started = [False]
    _ENVELOPE_MARKERS = ('```json', '"schema"', '{"schema')

    def _friendly(label: str) -> str:
        """Conversation-route tool labels, in the watcher's language.

        The sanitized labels are right for an operator ("write .../query.sql")
        and wrong in front of a business user, who reads them as noise between
        the narration sentences. Applied ONLY on the conversation route - every
        other consumer keeps the operator-grade label.
        """
        low = label.lower()
        if low.startswith("write"):
            return "Preparing the query"
        if "iof-query" in low:
            return "Running the data query"
        if low.startswith("read"):
            return "Reading the results"
        if low.startswith(("exec", "$", "cd ")):
            return "Running a command"
        return label

    def _progress_row(content: str) -> None:
        """Write one row the reader's client will actually see.

        THE CLIENT NEVER SEES THE MODEL'S STREAM. It renders rows stored
        here with `msg_type='thought'`, which the Studio API polls. So
        whatever writes these rows decides what a person watching a
        conversation sees, and for how long they see nothing.
        """
        # The SAME event, pushed. A streaming caller sees exactly what a
        # polling client would read from the store - one writer, so the two
        # surfaces cannot drift about what the agent was doing.
        chat_stream.emit("status", {"text": content})
        try:
            store.insert_message(
                user_id=uid, conversation_id=thread,
                source="agent", role=role,
                workspace_id=chat_ws_id,
                agent_name=agent_display_name, content=content,
                msg_type="thought")
        except Exception:                 # noqa: BLE001 - never break a turn
            logger.debug("progress row not written", exc_info=True)

    async def _on_progress(text: str, **kwargs) -> None:
        nonlocal thought_count, tool_call_count

        # WHAT THE HARNESS OBSERVES, NOT WHAT THE MODEL REMEMBERS TO SAY.
        #
        # This callback used to read `text` alone - the model's own
        # narration - and that text does not exist until an LLM call
        # COMPLETES. Measured against this engine, that left a person
        # watching 27-72 seconds of blank screen before the first
        # character, and single gaps of 60 seconds mid-answer, because a
        # call that takes 100 seconds says nothing until it returns.
        #
        # The runtime has been handing us `tool_events` in kwargs all
        # along - phase start/end/error, the tool's name and arguments -
        # and this path threw them away. They are facts the harness knows
        # the moment they happen, so they are written the moment they
        # happen. Streaming the provider does NOT fix this and was
        # measured to make the turn ~20s slower; the gap was never the
        # provider, it was who writes the rows.
        # The COUNT comes from these events too, for the same reason the
        # rows do. It was taken from `classify_thought(text)` - the model's
        # own narration - so a tool the model called without describing it
        # in a recognised form counted as nothing: a chat that demonstrably
        # ran two MCP tools (their spans are in the trace, carrying the
        # server's answers) reported `tool_calls: 0`, and the queryngine
        # budget derived from that number was blind in the same way.
        for ev in (kwargs.get("tool_events") or []):
            if not isinstance(ev, dict):
                continue
            phase, name = ev.get("phase"), str(ev.get("name") or "tool")
            if phase == "start":
                arg = _first_arg(ev.get("arguments"))
                _progress_row(f"{name}{f': {arg}' if arg else ''}")
                tool_call_count += 1      # counted here, not from narration
                # NAME WHAT WAS INVOKED, not the tool class. `exec` is how
                # EVERY console script runs - the declared domain tool and the
                # query engine alike - so a bare "exec" cannot tell a caller
                # which source answered, which is the whole reason this field
                # exists. An independent validator proved it: the access-check
                # reply and the database reply both reported `exec`.
                label = _invoked_name(name, ev.get("arguments"))
                if label not in tools_used:
                    tools_used.append(label)
                _bump_budget_file()
            elif phase == "error":
                _progress_row(f"{name} failed: "
                              f"{str(ev.get('error') or '')[:120]}")

        stripped = text.strip()
        if not stripped or _is_noise(stripped):
            return

        # Suppress the envelope and everything after it. A tool call means
        # the agent went back to work, so progress resumes.
        if _envelope_started[0]:
            if stripped.startswith(("exec(", "read_file(", "write_file(",
                                    "list_dir(", "search(")):
                _envelope_started[0] = False
            else:
                return
        elif any(m in stripped for m in _ENVELOPE_MARKERS):
            _envelope_started[0] = True
            return

        event = classify_thought(stripped)
        if event is None:
            return  # suppressed: internal scaffolding or sensitive op

        thought_count += 1
        # NOT counted here any more - see the tool-event branch above. The
        # narration is what the model said, and it says nothing when the
        # model simply calls a tool.

        # VERBATIM MEANS VERBATIM, for reasoning. `classify_thought` says the
        # reasoning fallback "preserves verbatim" — and then gets handed
        # `stripped`, so the whitespace at every chunk boundary is gone before
        # it is stored. A consumer concatenating the log to rebuild the
        # paragraph the agent wrote gets "The useris asking": observed, in the
        # Studio's conversation stream. The chunks split mid-word too
        # ("entities/s" + "ources"), so a client cannot tell which boundaries
        # lost a space and which never had one — the information is destroyed
        # here or nowhere.
        #
        # Classification still runs on `stripped`: the prefix rules
        # (`Tool call:`, `exec(`, …) would stop matching with leading
        # whitespace. Only the REASONING label reverts to the raw chunk. Every
        # other type keeps `event.label`, which is a sanitized string, and
        # sanitising is why those exist — `write_file(` labels are collapsed
        # precisely because SQL leaks column and table names through them.
        store.insert_message(
            user_id=uid,
            conversation_id=thread,
            source="agent",
            role=role,
            workspace_id=chat_ws_id,
            agent_name=agent_display_name,
            content=(text if event.type == "reasoning"
                     else (_friendly(event.label) if req.conversation
                           else event.label)),
            msg_type="thought",
        )

    # Compose final prompt (append JSON envelope instructions if requested)
    prompt = req.content
    # Preferences are a USER property: prepend this user's USER+GROUP prefs to the
    # prompt at the request surface (no-op unless IOF_PREFERENCES_DB).
    from ioagentfarm.engine.learning.hooks import inject_prefs
    prompt = inject_prefs(uid, prompt)
    # Workspace memory, USER scope: per person, so per turn (the workspace
    # and role scopes ride the agent home's system prompt). Labelled as
    # context, never as instructions. No-op unless the user has any.
    from ioagentfarm.engine.memory.hooks import chat_user_block
    _user_memory = chat_user_block(_root(), pod_ws, uid)
    if _user_memory:
        prompt = _user_memory + "\n" + prompt
    if req.format == "json":
        prompt = prompt + _JSON_FORMAT_SUFFIX

    # A NAMED output format (backlog K6, phase 1): the caller picks a declared
    # format PER REQUEST - the same agent can answer in several shapes.
    # "json" above keeps its legacy suffix-and-extract behaviour untouched;
    # any other value resolves against the workspace's declared formats
    # ("v1" is builtin and cannot be shadowed). The reply is then enforced
    # after the turn: extract -> validate against the format's schema -> one
    # bounded corrective retry. See engine/output_formats.py.
    # The resolve + 400 + envelope-conflict 409 + suffix rule live in ONE
    # place, `_resolve_request_format`, shared with the run-message route —
    # two copies of what-is-a-valid-format would drift. `is_v1` rides in as
    # the owns-envelope hint: it is conversation-gated BY DESIGN (widening
    # the whole v1 pipeline is a deliberate scoping), and the helper still
    # checks the workspace's own contract for RAW API callers — a by-content
    # envelope agent asked for a DIFFERENT named format is a contract
    # conflict on EVERY route (found live in the K6 certification).
    custom_fmt = None
    if req.format and req.format != "json":
        custom_fmt, _fmt_suffix = _resolve_request_format(
            role, workspace_path, req.format, owns_envelope_hint=is_v1)
        if _fmt_suffix:
            prompt = prompt + _fmt_suffix

    # Composition mode: control how verbose the final answer is. Default smart.
    # EXCEPTION: queryngine's result_composer skill enforces the v1 JSON
    # envelope as the only output. The smart/none suffixes contradict that
    # contract (they tell the agent to emit minimal markdown / raw data),
    # producing coin-flip format compliance depending on which always:true
    # directive the model honors that call. Bench surfaced this as a real
    # failure mode — see benchmarks/queryngine/. For queryngine, the envelope
    # is the composition mode; no suffix is applied.
    # Same applies to aria — her result_composer skill (always:true) mandates
    # exactly one fenced JSON block with nothing outside. Appending the smart
    # suffix contradicts that contract and produces coin-flip format compliance.
    comp_mode = (req.composition_mode or "smart").lower()
    if is_v1:
        comp_mode = "envelope"  # for logging only
    elif req.composition_mode is None:
        # THE AGENT'S OWN VOICE IS A CONTRACT TOO. The default used to append
        # the SMART suffix - "Keep the final answer minimal ... Do not add
        # insight, framing, or follow-up suggestions ... Cut every token that
        # does not directly answer the question" - to EVERY chat turn, where
        # it outranked the agent's authored SOUL. Found in the B2
        # certification: an agent whose SOUL says "open with a greeting" and
        # "ALWAYS end every reply with - Hera" answered `4. Basic
        # arithmetic.`; the SAME agent over /a2a (no suffix on that route)
        # answered in its own warm voice, and the model's own reasoning row
        # cited "Following the composition mode: SMART". One of four replies
        # kept the signature - the coin-flip this file already names for two
        # contradictory format directives, one layer up.
        #
        # An envelope contract was protected from this (`is_v1` above) and a
        # named format is (below); a persona was not. Now the engine adds no
        # composition directive unless the CALLER asked for one - the old
        # behaviour is one field away (`composition_mode: "smart"`), and the
        # docs say so.
        comp_mode = "agent"     # for logging only: the SOUL governs
    elif custom_fmt is not None:
        # a NAMED format owns the shape this turn - the smart/none suffixes
        # would contradict it, the exact coin-flip the envelope agents hit.
        comp_mode = f"format:{custom_fmt.name}"  # for logging only
    elif comp_mode == "none":
        prompt = prompt + _COMPOSITION_SUFFIX_NONE
    elif comp_mode == "smart":
        prompt = prompt + _COMPOSITION_SUFFIX_SMART
    # "always" — no suffix, unchanged behavior

    # A person is watching this turn happen - ask the model to narrate.
    # Not under a NAMED format: narration is prose outside the block the
    # format forbids.
    if req.conversation and custom_fmt is None:
        if _chat_narration_enabled():
            prompt = prompt + _NARRATE_SUFFIX

    # Inject per-session scratch path (concurrency safety for temp files) -
    # ONLY for an agent that actually runs a query tool. The block is 2.4 KB
    # of `iof-query --sql-file` / `vectorfs --scratch` instruction, and the
    # B2 certification found it on every turn of a warm conversational agent
    # carrying neither binary: tokens paid on each turn, plus a standing
    # invitation to run a command that is not installed. `uses_query_tools`
    # fails OPEN (see its docstring) because the scratch directory is the
    # concurrency guarantee for the agents that do query - withholding it is
    # the expensive mistake, injecting it is only wasteful.
    if scratch_hash and uses_query_tools(workspace_path):
        # The REAL directory, not a literal. This template used to hardcode
        # /app/.iof/tmp/... - the pod's path - while the engine created (and
        # put the budget file in) <IOF_ROOT>/tmp/... . On a pod the two
        # coincide; everywhere else the agent was instructed into a directory
        # nobody prepared - observed on the first Windows client install,
        # where the agent wrote to C:\app\.iof (drive-relative resolution
        # of the Linux path) while the engine's scratch sat under IOF_ROOT.
        # Forward slashes on purpose: every consumer here (PowerShell, cmd,
        # iof-query, the Windows API) accepts them, and backslashes inside a
        # prompt invite escaping mistakes by the model.
        prompt = prompt + _SCRATCH_DIR_SUFFIX.format(
            hash=scratch_hash, dir=str(scratch_dir).replace(chr(92), "/"))

    # Inject tool-call budget (queryngine only). Prompt-level reinforcement of
    # the 8-call cap that also lives in vectorfs_query/SKILL.md. Three stacked
    # failure modes observed without this: absence-spiral, over-thoroughness,
    # infra-rabbit-hole. Budget bounds all three at the LLM layer.
    if role == "queryngine":
        prompt = prompt + _BUDGET_SUFFIX.format(budget=_QUERYNGINE_TOOL_BUDGET)

    # Inject active ARIA business rules from DB (ARIA only).
    # Rules override hardcoded defaults in skill files. Empty result →
    # graceful degradation (skill file defaults remain in effect).
    if role == "aria":
        try:
            _aria_rules = _store().load_aria_rules()
            _aria_block = _render_aria_rules_block(_aria_rules)
            if _aria_block:
                prompt = prompt + _aria_block
        except Exception as _ve:
            logger.warning("ARIA rules injection failed: {} — using skill defaults", _ve)

    # Plan cache (queryngine only). On hit: re-execute cached SQL server-side
    # and rewrite the prompt so Quinn composes the envelope in a single LLM
    # round. Accuracy guardrail: SQL is re-executed live, cached rows are
    # NEVER returned. See ioagentfarm/engine/plan_cache.py.
    plan_cache_hit = False
    plan_cache_key: str | None = None
    _pc_catalog_hash = ""
    _pc_data_fp = ""
    _pc_synonyms: dict[str, str] = {}
    _pc_timings: dict[str, float] = {}
    if role == "queryngine":
        try:
            from ioagentfarm.engine.plan_cache_runtime import (
                get_plan_cache, execute_cached_sql, build_cache_hit_prompt,
            )
            from ioagentfarm.engine.plan_cache import PlanCache
            _pc_t0 = _time.perf_counter()
            metadata_dir_for_cache = workspace_path / "metadata"
            _pc_catalog_hash = PlanCache.compute_catalog_hash(
                metadata_dir_for_cache / "catalog.yaml")
            _pc_data_fp = PlanCache.compute_data_fingerprint(
                metadata_dir_for_cache)
            _pc_synonyms = PlanCache.load_synonyms(metadata_dir_for_cache)
            _pc_timings["key_build_ms"] = (_time.perf_counter() - _pc_t0) * 1000
            cache = get_plan_cache(_root())
            _pc_t1 = _time.perf_counter()
            entry = cache.lookup(
                question=req.content, role=role, user_scope=uid,
                synonyms=_pc_synonyms,
                catalog_hash=_pc_catalog_hash,
                data_fingerprint=_pc_data_fp,
            )
            _pc_timings["lookup_ms"] = (_time.perf_counter() - _pc_t1) * 1000
            if entry is not None:
                _pc_t2 = _time.perf_counter()
                fresh = execute_cached_sql(
                    sql=entry.sql,
                    db_name=entry.db_name,
                    metadata_dir=metadata_dir_for_cache,
                )
                _pc_timings["sql_exec_ms"] = (_time.perf_counter() - _pc_t2) * 1000
                if fresh is not None:
                    _pc_t3 = _time.perf_counter()
                    prompt = build_cache_hit_prompt(
                        question=req.content,
                        sql=entry.sql,
                        result=fresh,
                        entity=entry.entity,
                        db_name=entry.db_name,
                    )
                    _pc_timings["prompt_build_ms"] = (_time.perf_counter() - _pc_t3) * 1000
                    _pc_timings["prompt_chars"] = len(prompt)
                    plan_cache_hit = True
                    plan_cache_key = entry.cache_key
                    logger.info(
                        "plan_cache.hit role={} user={} key={} hits={} timings={}",
                        role, uid, entry.cache_key[:12], entry.hit_count,
                        _pc_timings)
                else:
                    logger.info(
                        "plan_cache.hit_but_exec_failed role={} user={} key={}",
                        role, uid, entry.cache_key[:12])
        except Exception as _pc_exc:
            logger.warning("plan_cache.lookup_failed role={} err={}",
                           role, _pc_exc)

    # Observability: log query start (fix #8).
    #
    # THE MESSAGE TEXT IS NOT LOGGED BY DEFAULT. This line used to carry the
    # first 120 characters of whatever the user typed, at INFO, on every
    # turn - so every conversation was duplicated into wherever the pod's
    # stdout goes, outside the session store and outside every control that
    # protects it. An always-on agent sees customer text; a pharma
    # deployment has PII and MLR rules about exactly that, and log shipping
    # is the one path nobody reviews. The same reasoning already keeps
    # message bodies out of the OTel spans (`wrap_chat` exports lengths, and
    # `IOF_OTEL_CONTENT=1` opts in) - this is that decision applied to the
    # log line beside it.
    #
    # Length and a short digest keep the line useful for correlating a turn
    # with a trace or a support report without reproducing the content.
    t0 = _time.time()
    _msg = req.content or ""
    if (os.environ.get("IOF_LOG_CHAT_CONTENT") or "").strip().lower() in ("1", "true", "yes"):
        _q = _msg[:120].replace("\n", " ")
    else:
        import hashlib as _hashlib
        _q = (f"<{len(_msg)} chars, sha256:"
              f"{_hashlib.sha256(_msg.encode('utf-8', 'replace')).hexdigest()[:8]}>")
    logger.info(
        "chat.start role={} user={} workflow={} format={} comp_mode={} cache={} q={}",
        role, uid, workflow_name, req.format or "text", comp_mode,
        "hit" if plan_cache_hit else "miss", _q,
    )

    # The model's own text, as it arrives. The line buffer is what the STORED
    # progress rows have always been built from and is untouched; a streaming
    # caller additionally gets the raw delta, because a chat UI renders
    # characters and a progress row is a sentence.
    _line_stream = LineBufferedStream(_on_progress)

    async def stream(delta: str) -> None:
        chat_stream.emit("delta", {"text": delta})
        await _line_stream(delta)

    stream.flush = _line_stream.flush
    error: str | None = None
    # SHARED SESSION, BEFORE THE TURN. Two pods serving one workspace each
    # kept a private copy of this conversation; the chat surface had no
    # storage sync at all, so a turn taken on the other pod was invisible AND
    # then overwritten. Pull the shared copy and drop the cached one, so the
    # runtime re-reads it. A no-op unless IOF_STORAGE is configured.
    try:
        from ioagentfarm.web import chat_session_sync as _sess
        _sess.pull_before_turn(workspace_path, pod_ws or "", session_key, agent)
    except Exception:  # noqa: BLE001 - sharing must never break a turn
        logger.debug("chat session pull skipped", exc_info=True)

    # AN AGENT WITH NO IDENTITY IS A DIFFERENT AGENT. `lint-agent` says "no
    # SOUL.md - the agent has no identity at all"; the serving path answered
    # as a generic assistant with every stated guardrail gone, HTTP 200,
    # `error: null`. The linter knew and the caller was not told.
    try:
        from ioagentfarm.engine import degraded as _deg
        if not (workspace_path / "SOUL.md").is_file():
            _deg.record(
                "agent.no_identity",
                f"agent '{role}' has no SOUL.md, so it is answering without "
                f"its stated identity or any guardrail written into it. Run "
                f"`aicore lint-agent {role}`.",
                scope=role)
        else:
            _deg.clear("agent.no_identity", role)
    except Exception:  # noqa: BLE001 - a warning must not break a turn
        pass

    _llm_t0 = _time.perf_counter()

    async def _turn(text: str):
        # each generation gets a fresh latch, or phase 2 streams blind
        _envelope_started[0] = False
        result = await agent.process_direct(
            text,
            session_key=session_key,
            channel="web",
            chat_id=f"web:chat:{workflow_name}",
            on_progress=_on_progress,
            on_stream=stream,
        )
        await stream.flush()
        return result.content if result else ""

    try:
        if _two_phase_enabled(v1=is_v1, conversation=bool(req.conversation)):
            # PHASE 1 - the numbers. The one-line verdict is published the
            # moment it exists, so the reader has the finding while phase 2 is
            # still writing the read. Following the reference implementation,
            # only `answer` goes early; `data` and `viz_hint` are computed here
            # too but arrive with the final message.
            _p1t0 = _time.perf_counter()
            _p1 = await _turn(prompt + _PHASE1_SUFFIX)
            _p1e = _extract_envelope_lenient(_p1)
            if isinstance(_p1e, dict) and _p1e.get("answer"):
                # `preview` is its own msg_type, NOT `thought`: a thought is
                # progress and this is the answer, arriving early. Safe to add
                # because the other two readers of `messages` are run_id-scoped
                # and a chat turn carries no run_id, so it cannot surface as a
                # stray bubble in the Sessions UI.
                store.insert_message(
                    user_id=uid, conversation_id=thread,
                    source="agent", role=role,
                    workspace_id=chat_ws_id,
                    agent_name=agent_display_name,
                    content=str(_p1e["answer"]), msg_type="preview",
                )
            logger.info("two_phase.phase1 role={} s={:.1f} chars={} preview={}",
                        role, _time.perf_counter() - _p1t0, len(_p1),
                        bool(isinstance(_p1e, dict) and _p1e.get("answer")))

            # PHASE 2 - the read. Three fields, merged onto phase 1 rather than
            # regenerated, which is what keeps the figures identical.
            #
            # "do NOT query again" is a REQUEST, not a cap: the per-session tool
            # budget is initialised for `queryngine` only, so nothing here
            # refuses a second round of queries. That makes it worth counting
            # rather than assuming — a phase 2 that re-queries costs the tokens
            # this design exists to save, and would otherwise be invisible.
            _tc_before = tool_call_count
            _p2 = await _turn(_PHASE2_PROMPT)
            if tool_call_count > _tc_before:
                logger.warning(
                    "two_phase.phase2_queried role={} user={} calls={} -"
                    " the read was asked not to query again",
                    role, uid, tool_call_count - _tc_before)
            response = _p2
            try:
                _p2e = _extract_envelope_lenient(_p2)
                if isinstance(_p1e, dict) and isinstance(_p2e, dict):
                    _merged = _merge_phases(_p1e, _p2e)
                    response = "```json\n" + json.dumps(
                        _merged, ensure_ascii=False) + "\n```"
                    logger.info("two_phase.merged fields={}", sorted(_p2e.keys()))
                elif isinstance(_p1e, dict) and not _p2e:
                    # phase 2 unusable - phase 1 still answers the question
                    response = _p1
            except Exception as _mexc:
                logger.warning("two_phase.merge_failed err={}", _mexc)
                if not response.strip() and _p1.strip():
                    response = _p1
        else:
            response = await _turn(prompt)
    except Exception as exc:
        await stream.flush()
        response = f"(chat error: {exc})"
        error = str(exc)

    # A PROVIDER FAILURE THE RUNTIME SWALLOWED IS STILL A FAILURE. The agent
    # loop catches some errors and RETURNS them as the reply text rather than
    # raising, so nothing above ran and the payload carried no `error` key at
    # all - a 200 whose `content` was a raw provider blob. A validator sent an
    # oversize message and got back
    #   Error: {'type': 'error', 'error': {'type': 'invalid_request_error', ...
    # as the agent's answer, while the documentation promises a failure
    # arrives in an `error` field. A client built to that contract renders the
    # blob to its user as though the agent had said it.
    if not error:
        detected = _provider_error_in(response)
        if detected:
            error = detected

    llm_duration_s = round(_time.perf_counter() - _llm_t0, 2)
    duration_s = round(_time.time() - t0, 2)
    logger.info(
        "chat.llm_phase role={} cache={} llm_s={} prompt_chars={}",
        role, "hit" if plan_cache_hit else "miss", llm_duration_s, len(prompt),
    )

    # Extract JSON envelope if present (fix #5)
    # Always extract for aria/queryngine — they always emit the v1 envelope.
    # For other roles, only extract when caller explicitly requests format="json".
    #
    # `cora_query` joined the list when it moved into core: it carries the same
    # `always: true` `result_composer` and emits the same v1 envelope, so its
    # answers were being parsed by nobody — the agent returned a correct,
    # grounded envelope and the caller got `envelope: None` and a wall of raw
    # JSON as prose. Observed in the Studio's conversation UI.
    #
    # A hardcoded tuple is the weak part of this and will bite again: it is a
    # list of "roles known to emit v1" maintained by hand, a long way from the
    # skill that makes the promise. The self-describing fix is to key on the
    # payload's own `schema` and let it speak for itself. Not done here
    # because it widens behaviour for every role at once, which is a change
    # to make deliberately rather than while porting an agent.
    envelope = None
    format_validation = None
    if custom_fmt is not None and response and not error:
        # K6 enforcement for a NAMED format: extract -> validate against its
        # schema -> one bounded corrective retry through the same session
        # (`_turn`), the same discipline as the v1 fabrication retry below.
        from ioagentfarm.engine.output_formats import enforce_format
        try:
            response, envelope, _fmt_problems = await enforce_format(
                custom_fmt, response, _turn)
            format_validation = {
                "format": custom_fmt.name,
                "valid": not _fmt_problems,
                "problems": _fmt_problems[:10],
            }
            if _fmt_problems:
                logger.warning(
                    "output_format.invalid name={} role={} problems={}",
                    custom_fmt.name, role, len(_fmt_problems))
        except Exception as _fmt_enf_exc:  # noqa: BLE001 - never eat a reply
            logger.warning("output_format.enforce_failed name={} err={}",
                           custom_fmt.name, _fmt_enf_exc)
    elif (is_v1 or req.format == "json") and response:
        envelope = _extract_envelope_lenient(response)

    # data_window reconciliation. Deterministic sanity checks on the one evidence
    # field nothing else cross-checks; logged, never retried - the numbers in the
    # answer are right even when the disclosure is wrong, and a retry costs a
    # full LLM round.
    window_validation = None
    if is_v1 and isinstance(envelope, dict):
        try:
            from ioagentfarm.engine.envelope_validator import (
                validate_data_window, extract_window_stats, compute_data_window,
            )
            _safe_wv = re.sub(r"[^A-Za-z0-9_]", "_", session_key)
            _sp = workspace_path / "sessions" / f"{_safe_wv}.jsonl"

            # Deterministic data_window: lift it from the agent's own query
            # results rather than trusting it to restate numbers it has seen.
            _stats = extract_window_stats(_sp)
            if not _stats:
                # No aliases in the result - compute the window from the bounds
                # it declared plus the population the cited metric definition
                # itself specifies. Projection, not a claim.
                _stats = compute_data_window(
                    envelope, os.environ.get("IOF_DATABASE_URL", "").strip('"'))
            if _stats:
                _ev_w = envelope.setdefault("evidence", {}) if isinstance(
                    envelope.get("evidence"), (dict, type(None))) else None
                if isinstance(_ev_w, dict):
                    _prev = _ev_w.get("data_window")
                    if _prev != _stats:
                        logger.info(
                            "data_window.overwritten role={} from={} to={}",
                            role, _prev, _stats,
                        )
                    _ev_w["data_window"] = _stats

            _wv = validate_data_window(envelope, _sp)
            if _wv is not None and _wv.checked:
                window_validation = {"ok": _wv.ok, "reason": _wv.reason}
                if not _wv.ok:
                    logger.warning("data_window.inconsistent role={} user={} detail={}",
                                   role, uid, _wv.reason)
        except Exception as _wv_exc:
            logger.debug("data_window.check_failed err={}", _wv_exc)

    # Envelope fabrication guard (queryngine only). Cross-check that
    # `data.rows` values actually appear in the session's most recent
    # iof-query tool_result. If Quinn paraphrased/fabricated cell values
    # (observed failure mode on long sessions), re-invoke with a corrective
    # prompt once and keep the cleaner result. See engine/envelope_validator.py.
    envelope_validation = None
    if is_v1 and not error and response:
        try:
            from ioagentfarm.engine.plan_cache_runtime import (
                extract_envelope as _extract_env,
            )
            from ioagentfarm.engine.envelope_validator import (
                validate_envelope_rows, build_corrective_prompt,
            )
            # Session file path matches iobot's safe_key convention:
            # replace non-alphanumeric (including ':') with '_'.
            import re as _re2
            safe_key = _re2.sub(r"[^A-Za-z0-9_]", "_", session_key)
            session_path = workspace_path / "sessions" / f"{safe_key}.jsonl"
            _env = _extract_env(response)
            if _env is not None:
                vres = validate_envelope_rows(_env, session_path)
                envelope_validation = {
                    "checked": vres.checked,
                    "ok": vres.ok,
                    "violations": len(vres.violations),
                    "summary": vres.summary(),
                }
                if vres.checked and not vres.ok:
                    # Re-invoke Quinn with a corrective prompt. One retry only.
                    logger.warning(
                        "envelope.fabrication_detected role={} user={} "
                        "violations={} envelope_rows={} source_rows={}",
                        role, uid, len(vres.violations),
                        vres.envelope_row_count, vres.source_row_count,
                    )
                    # Re-read source rows from session for the corrective prompt
                    import json as _json2
                    src_rows: list = []
                    try:
                        lines = session_path.read_text(encoding="utf-8").splitlines()
                        if vres.source_event_index is not None \
                                and vres.source_event_index < len(lines):
                            src_obj_line = lines[vres.source_event_index]
                            src_obj = _json2.loads(src_obj_line)
                            content = src_obj.get("content", "")
                            mm = _re2.search(r"\{.*\}", content, _re2.DOTALL)
                            if mm:
                                inner = _json2.loads(mm.group(0))
                                if isinstance(inner, dict):
                                    src_rows = inner.get("rows") or []
                    except Exception:
                        pass
                    corrective = build_corrective_prompt(
                        vres.violations, src_rows)
                    _retry_t0 = _time.perf_counter()
                    try:
                        retry_result = await agent.process_direct(
                            corrective,
                            session_key=session_key,
                            channel="web",
                            chat_id=f"web:chat:{workflow_name}",
                            on_progress=_on_progress,
                            on_stream=stream,
                        )
                        await stream.flush()
                        retry_response = (retry_result.content
                                          if retry_result else "")
                    except Exception as retry_exc:
                        logger.warning(
                            "envelope.retry_failed role={} err={}",
                            role, retry_exc)
                        retry_response = ""
                    retry_duration = round(
                        _time.perf_counter() - _retry_t0, 2)
                    if retry_response:
                        _env2 = _extract_env(retry_response)
                        if _env2 is not None:
                            vres2 = validate_envelope_rows(
                                _env2, session_path)
                            envelope_validation["retry"] = {
                                "ok": vres2.ok,
                                "violations": len(vres2.violations),
                                "duration_s": retry_duration,
                            }
                            if vres2.ok:
                                response = retry_response
                                envelope = _env2
                                logger.info(
                                    "envelope.retry_success role={} user={} "
                                    "duration_s={}",
                                    role, uid, retry_duration)
                            else:
                                # Annotate the envelope with a caveat; keep
                                # original since retry also failed.
                                logger.warning(
                                    "envelope.retry_still_fabricated role={} "
                                    "user={} violations={}",
                                    role, uid, len(vres2.violations))
        except Exception as _vexc:
            logger.warning("envelope.validator_failed role={} err={}",
                           role, _vexc)

    # Plan cache write (queryngine only). Stored on successful response when
    # the envelope contains a usable SQL + database reference. Skipped on
    # cache hits (we already have the plan) and on errors. Also skip if the
    # envelope failed fabrication validation — don't cache a bad plan.
    if (role == "queryngine" and not plan_cache_hit and not error
            and response
            and (envelope_validation is None
                 or not envelope_validation.get("checked")
                 or envelope_validation.get("ok")
                 or (envelope_validation.get("retry") or {}).get("ok"))):
        try:
            from ioagentfarm.engine.plan_cache_runtime import (
                get_plan_cache, extract_envelope as _extract_env,
                extract_sql_and_db_from_envelope,
            )
            env = _extract_env(response)
            if env is not None:
                pair = extract_sql_and_db_from_envelope(env)
                if pair is not None:
                    sql, db_name, entity = pair
                    cache = get_plan_cache(_root())
                    stored_key = cache.store(
                        question=req.content, role=role, user_scope=uid,
                        synonyms=_pc_synonyms,
                        catalog_hash=_pc_catalog_hash,
                        data_fingerprint=_pc_data_fp,
                        sql=sql, db_name=db_name, entity=entity,
                    )
                    if stored_key:
                        plan_cache_key = stored_key
                        logger.info(
                            "plan_cache.store role={} user={} key={}",
                            role, uid, stored_key[:12])
        except Exception as _pc_exc:
            logger.warning("plan_cache.store_failed role={} err={}",
                           role, _pc_exc)

    # Observability: log query end with structured metrics
    logger.info(
        "chat.end role={} user={} workflow={} duration_s={} thoughts={} tool_calls={} budget={} chars={} envelope={} error={}",
        role, uid, workflow_name,
        duration_s, thought_count, tool_call_count,
        _QUERYNGINE_TOOL_BUDGET if role == "queryngine" else None,
        len(response), bool(envelope), error or "none",
    )

    # FIX 1G — strip CJK encoding artifacts from ARIA responses before persist
    if role == "aria" and response:
        response = _sanitize_aria_output(response, context="response")
    if role == "aria" and envelope:
        for _fld in ("answer", "insight"):
            if isinstance(envelope.get(_fld), str):
                envelope[_fld] = _sanitize_aria_output(envelope[_fld], context=f"envelope.{_fld}")

    # GUARDRAILS, OUTPUT HALF: applied BEFORE the row is stored, so what the
    # history endpoint replays is what the caller was shown. A no-op with no
    # policy (`_gr` is None).
    if _gr is not None:
        response, _gr = _guard_out(response, _gr, envelope)

    # Persist final agent response
    msg_id = store.insert_message(
        user_id=uid,
        conversation_id=thread,
        workspace_id=chat_ws_id,
        source="agent",
        role=role,
        agent_name=agent_display_name,
        content=response,
        msg_type="message",
    )

    # ...and back to shared storage, so the next turn on any pod sees it.
    try:
        from ioagentfarm.web import chat_session_sync as _sess
        _sess.push_after_turn(workspace_path, pod_ws or "", session_key)
    except Exception:  # noqa: BLE001 - the turn is already answered
        logger.debug("chat session push skipped", exc_info=True)

    payload = {
        "id": f"msg_{msg_id}",
        "workflow": workflow_name,
        "agent": role,
        "agent_name": agent_display_name,
        "content": response,
        "duration_s": duration_s,
        "thoughts": thought_count,
        "tool_calls": tool_call_count,
        "tools_used": list(tools_used),
    }
    # WHAT THE ENGINE KNOWS IS WRONG, BESIDE THE ANSWER. The whole class of
    # defect this addresses is an HTTP 200 with `error: null` from an engine
    # that had already logged the problem. Absent when there is nothing to
    # say, so an ordinary reply is unchanged.
    try:
        from ioagentfarm.engine import degraded as _deg
        _warn = _deg.warnings_for(scope=role)
        if _warn:
            payload["warnings"] = _warn
    except Exception:  # noqa: BLE001
        pass
    if role == "queryngine":
        payload["budget"] = _QUERYNGINE_TOOL_BUDGET
        payload["budget_exceeded"] = tool_call_count > _QUERYNGINE_TOOL_BUDGET
    if req.draft_author:
        # The reply says WHICH content answered: the environment's stamp plus
        # the exact drafts resolved for THIS turn (read by the same get that
        # picked the loop). Without it a Try-it answer is indistinguishable
        # from a pack answer, which is the ambiguity drafts must not add.
        try:
            from ioagentfarm.engine.content import stamp_line
            _stamp = stamp_line()
        except Exception:
            _stamp = ""
        payload["provenance"] = {
            "stamp": _stamp,
            "draft": {"author": req.draft_author.strip().lower(),
                      "items": draft_items or []},
        }
    if envelope is not None:
        payload["envelope"] = envelope
    if custom_fmt is not None:
        payload["format"] = custom_fmt.name
        if format_validation is not None:
            payload["format_validation"] = format_validation
    if role == "queryngine":
        payload["plan_cache"] = {
            "hit": plan_cache_hit,
            "key": plan_cache_key[:12] if plan_cache_key else None,
        }
        if envelope_validation is not None:
            payload["envelope_validation"] = envelope_validation
        if window_validation is not None:
            payload["window_validation"] = window_validation
    if _gr is not None:
        # Absent with no policy, so an unguarded reply is byte-identical.
        payload["guardrails"] = _gr
    if error:
        payload["error"] = error
    return payload


@app.post(
    "/api/chat/{ns}/stream",
    summary="Chat with an always-on agent, streamed (SSE - not testable here)",
    response_class=StreamingResponse,
    responses={200: {
        "description": (
            "A Server-Sent Events stream: `status`, then `delta` events "
            "carrying model text as it arrives, then one `message` event "
            "whose payload is the body the non-streaming endpoint returns."),
        "content": {"text/event-stream": {"example": (
            ": thinking" + chr(10) + chr(10)
            + "event: status" + chr(10)
            + 'data: {"state": "thinking"}' + chr(10) + chr(10)
            + "event: delta" + chr(10)
            + 'data: {"text": "Hello"}' + chr(10) + chr(10)
            + "event: message" + chr(10)
            + 'data: {"content": "Hello - I am ...", "agent": "..."}'
            + chr(10) + chr(10))}},
    }},
)
async def adhoc_chat_stream(ns: str, req: ChatRequest, request: Request):
    """The same chat turn, streamed as Server-Sent Events.

    **This endpoint cannot be exercised from this page.** Swagger UI's
    "Try it out" reads the whole response before it renders anything, so an
    event stream shows as a spinner that only resolves when the turn ends -
    which is the one thing streaming exists to avoid. That is a limitation of
    the browser client, not of the endpoint. Use a client that reads the body
    as it arrives:

    ```bash
    curl -N -X POST http://127.0.0.1:8131/api/chat/general/stream       -H "Content-Type: application/json"       -d '{"content": "Who are you?", "agent": "chat_advisor"}'
    ```

    `-N` is load-bearing: without it curl buffers, and the call looks stuck.
    In PowerShell, `Invoke-RestMethod` also buffers - use `curl.exe -N ...`.

    In a browser, `EventSource` cannot be used (it only issues GET); read the
    body of a `fetch` POST through `response.body.getReader()`.

    Body and semantics are identical to `POST /api/chat/{ns}` -
    same thread rules, same formats, same refusals - so a caller switches
    transport without changing anything else. The difference is WHEN the
    caller learns things: `status` events while the agent works, `delta`
    events carrying model text as it arrives, and finally one `message`
    event whose payload is exactly the body the non-streaming endpoint
    returns.

    Refusals that happen before the turn starts (empty content, unknown
    agent, unknown format, wrong workspace) are still ordinary HTTP status
    codes - the stream has not begun, so there is nothing to put them in.
    """
    return await chat_stream.stream_turn(
        lambda: adhoc_chat(ns, req, request), request)


@app.get("/api/chat/{ns}/messages")
def list_chat_messages(ns: str, request: Request,
                             user_id: str = "web:web_user",
                             after: int = 0, limit: int = 100,
                             conversation_id: str | None = None):
    """Ad-hoc chat history (no run).

    ``ns`` mirrors the POST's path segment for symmetry, and is NOT a
    filter: it cannot be one, because a user's own rows carry no agent
    attribution, so filtering on it would drop half the conversation.
    History is selected by PERSON (``user_id``) and THREAD
    (``conversation_id``) — pass ``conversation_id`` to re-render one
    conversation; without it every thread the person holds interleaves
    in one response.
    """
    _owner = _bound_owner(request)
    if _owner:
        if user_id and user_id not in ("web:web_user", _owner):
            raise HTTPException(status_code=403, detail=(
                "user_id does not match the authenticated principal. With "
                "IOF_CHAT_BIND_PRINCIPAL on, history reads return the "
                "verified caller's own rows."))
        user_id = _owner
    store = _store()
    # Ad-hoc chat rows are the ones with no run_id.
    q = ("SELECT id, user_id, conversation_id, source, role, agent_name, "
         "content, msg_type, created_at "
         "FROM messages WHERE run_id IS NULL AND user_id=? AND id>?")
    params: list = [user_id, after]
    if conversation_id:
        q += " AND conversation_id=?"
        params.append(conversation_id)
    q += " ORDER BY id ASC LIMIT ?"
    params.append(limit)
    with store._tx() as cursor:
        cursor.execute(store._q(q), tuple(params))
        messages = [dict(r) for r in cursor.fetchall()]

    return {
        "ns": ns,
        "messages": messages,
        "has_more": len(messages) == limit,
    }


# ---------------------------------------------------------------------------
# GET /api/agents — available team members
# ---------------------------------------------------------------------------

    

@app.get("/api/agents")
def list_agents():
    """List agents with display metadata.

    DB is the source of truth. Returns role + name + title + color + avatar
    from the `agents` table (populated by POST /api/agents/sync). Any bundled
    agents not yet in the DB are included with their SOUL.md name and a
    default gray style, so UIs can still render them before the first sync.
    """
    from ioagentfarm.engine.workspaces import get_agent_name, list_bundled_agents

    store = _store()
    agents: list[dict] = []
    seen_roles: set[str] = set()

    # Primary: DB rows (source of truth)
    try:
        with store._tx() as cur:
            cur.execute(store._q("SELECT role, name, title, avatar, color FROM agents ORDER BY role"))
            for row in cur.fetchall():
                r = dict(row) if hasattr(row, "keys") else {
                    "role": row[0], "name": row[1], "title": row[2], "avatar": row[3], "color": row[4],
                }
                agents.append(r)
                seen_roles.add(r["role"])
    except Exception as exc:
        logger.warning("agents DB read failed, falling back to bundled scan: {}", exc)

    # Fallback: bundled agents not in the DB yet — include with defaults
    for role in list_bundled_agents():
        if role in seen_roles:
            continue
        try:
            name = get_agent_name(role)
        except Exception:
            name = role
        agents.append({
            "role": role,
            "name": name,
            "title": role.replace("_", " ").title(),
            "avatar": role[:2].upper(),
            "color": "#888888",
        })

    pool: AgentPool = getattr(app.state, "agent_pool", None)
    active = pool.active_roles if pool else []

    return {"agents": agents, "active": active}


# ---------------------------------------------------------------------------
# POST /api/agents/sync — sync agent metadata from SOUL.md to DB
# ---------------------------------------------------------------------------

# Display styles and pack provenance live in engine/catalog_sync.py — the
# single implementation the CLI (`aicore sync`) and `setup-agents` share
# with this endpoint. Re-exported here because the studio API imports
# `_role_pack_map` from this module.
from ioagentfarm.engine.catalog_sync import (        # noqa: E402
    AGENT_STYLES as _AGENT_STYLES,
    derive_style as _derive_agent_style,
    role_pack_map as _role_pack_map,
)


@app.post("/api/agents/sync")
def sync_agents():
    """Sync agent metadata from SOUL.md files to the agents DB table.

    Reads agent names from bundled workspaces and upserts into the agents
    table with display styles (title, color, avatar) and PACK PROVENANCE —
    the column the studio scopes each workspace's agent list on. Until it
    runs, every tenant sees every installed pack's agents.

    Also available without a running server as ``aicore sync``, and run
    automatically by ``setup-agents``.
    """
    from ioagentfarm.engine.catalog_sync import sync_agents as _sync

    synced = _sync(_store())
    return {"synced": len(synced), "agents": synced}


_ROLE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")


def _agent_memory_file(role: str):
    """``<agent home>/<role>/workspace/memory/MEMORY.md``, or a 404.

    Agent memory is the one piece of an agent that is NOT database-backed:
    it accumulates per host, and ``studio_agent_defs`` excludes it so that one
    pod's learnings can never overwrite another's. That makes it unreachable
    from the Studio API pod, which has no agent home — hence these endpoints.
    """
    from ioagentfarm.engine.workspaces import iobot_agent_workspace

    if not _ROLE_RE.match(role):
        raise HTTPException(status_code=400, detail="bad role")
    ws = iobot_agent_workspace(role)
    if not (ws / "SOUL.md").is_file():
        raise HTTPException(status_code=404,
                            detail=f"Agent '{role}' has no workspace on this host")
    return ws / "memory" / "MEMORY.md"


@app.get("/api/agents/{role}/memory")
async def get_agent_memory(role: str):
    """This host's accumulated MEMORY.md for an agent."""
    mem = _agent_memory_file(role)
    text = ""
    if mem.is_file():
        text = mem.read_text(encoding="utf-8", errors="replace")
    return {"role": role, "memory": text}


@app.delete("/api/agents/{role}/memory")
async def clear_agent_memory(role: str):
    """Reset an agent's accumulated memory (explicit operator action)."""
    mem = _agent_memory_file(role)
    mem.parent.mkdir(parents=True, exist_ok=True)
    mem.write_text("# Memory\n", encoding="utf-8")
    return {"role": role, "cleared": True}


# ---------------------------------------------------------------------------
# Learning governance — the steward workflow over HTTP.
#
# Drafts, the audit trail and the approved-skill inbox are all
# filesystem/JSONL under IOF_ROOT (see engine/learning/governance.py), so the
# Studio API pod — which has no filesystem state — reaches them through these
# endpoints on the proxy rail, exactly like agent memory. Thin wrappers: the
# scan, the fail-closed dangerous-approve refusal and the file moves all stay
# in governance.py, never reimplemented here.
# ---------------------------------------------------------------------------

@app.get("/api/learning/pending")
async def learning_pending(workspace: str | None = None,
                           include_unscoped: bool = True):
    from ioagentfarm.engine.learning import governance as gov
    drafts = gov.pending(workspace=workspace,
                         include_unscoped=include_unscoped)
    return {"drafts": [d.to_dict() for d in drafts]}


@app.get("/api/learning/drafts/{ident}")
async def learning_draft(ident: str):
    from ioagentfarm.engine.learning import governance as gov
    rec = gov.show(ident)
    if rec is None:
        raise HTTPException(status_code=404,
                            detail=f"no pending draft addressed by '{ident}'")
    return rec.to_dict()


@app.post("/api/learning/drafts/{ident}/decision")
async def learning_decision(ident: str, req: dict):
    """Approve or reject a draft. A DANGEROUS scan makes approval a 409 —
    the same fail-closed refusal the CLI enforces, surfaced as a status the
    console can render against the approve button."""
    from ioagentfarm.engine.learning import governance as gov
    decision = (req.get("decision") or "").strip().lower()
    approver = (req.get("approver") or "").strip() or "unknown"
    note = (req.get("note") or "").strip()
    if decision not in ("approve", "reject"):
        raise HTTPException(status_code=400,
                            detail="decision must be 'approve' or 'reject'")
    try:
        if decision == "approve":
            outcome = gov.approve(ident, approver=approver, note=note)
        else:
            outcome = gov.reject(ident, approver=approver, reason=note)
    except gov.ReviewError as exc:
        msg = str(exc)
        if msg.startswith("REFUSED"):
            raise HTTPException(status_code=409, detail=msg)
        raise HTTPException(status_code=404, detail=msg)
    return {"ok": True, "outcome": outcome.get("status", decision),
            "refused_reason": None, "detail": outcome}


@app.get("/api/learning/audit")
async def learning_audit(limit: int = 100):
    from ioagentfarm.engine.learning import governance as gov
    return {"entries": gov.audit_log(limit=limit)}


# ---------------------------------------------------------------------------
# A2A console surfaces — the exposure view and the external-agent registry
# over HTTP.
#
# The OUTBOUND registry is a workspace YAML file under the engine's state dir
# (engine/a2a_registry.py) and the INBOUND exposure answer unions on-disk
# agent homes (web/a2a.py:exposed_roles) — both filesystem-bound, so the
# Studio API pod reaches them through these endpoints on the proxy rail.
# ${VAR} references in urls/headers stay UNEXPANDED in every response;
# resolution happens only inside validate, and resolved values never leave
# this process (responses and error text are scrubbed).
# ---------------------------------------------------------------------------

def _a2a_entry_public(entry: dict) -> dict:
    """One registry entry as the console sees it: verbatim (refs unexpanded)
    plus the names-only credential diagnostic."""
    from ioagentfarm.engine.a2a_registry import unresolved_header_vars
    out = dict(entry)
    out["credentials"] = {"unresolved": unresolved_header_vars(entry)}
    return out


@app.get("/api/a2a/exposed")
async def a2a_exposed():
    """The pod's exposed-agent answer: who is on the A2A surface, and why."""
    import os as _os
    from ioagentfarm.engine.workspaces import canonical_role
    from ioagentfarm.web.a2a import (_load_card_yaml, _soul_first_paragraph,
                                     exposed_roles, get_agent_name)
    ws = getattr(app.state, "workspace_code", None)
    if not ws:
        raise HTTPException(status_code=503,
                            detail="serve has no workspace resolved")
    raw = _os.environ.get("IOF_ALWAYS_ON_AGENTS", "cora").strip()
    always = {canonical_role(a.strip()) for a in raw.split(",") if a.strip()}
    always.add("cora")
    card_declared = set(exposed_roles(ws))
    agents = []
    for role in sorted(always | card_declared):
        authored = _load_card_yaml(role)
        agents.append({
            "role": role,
            "name": authored.get("name") or get_agent_name(role),
            "description": (authored.get("description")
                            or _soul_first_paragraph(role)),
            "source": "always_on" if role in always else "card",
        })
    return {"agents": agents}


@app.get("/api/a2a/external")
async def a2a_external_list():
    from ioagentfarm.engine.a2a_registry import read_external_agents
    return {"agents": [_a2a_entry_public(e) for e in read_external_agents()]}


@app.post("/api/a2a/external")
async def a2a_external_upsert(req: dict):
    from ioagentfarm.engine.a2a_registry import (add_external_agent,
                                                 read_external_agents)
    name = (req.get("name") or "").strip()
    url = (req.get("a2a_url") or "").strip()
    if not name or not url:
        raise HTTPException(status_code=400,
                            detail="name and a2a_url are required")
    add_external_agent(
        name, url,
        description=(req.get("description") or "").strip(),
        tags=[str(t) for t in (req.get("tags") or [])],
        examples=[str(e) for e in (req.get("examples") or [])],
        headers={str(k): str(v)
                 for k, v in (req.get("headers") or {}).items()} or None,
    )
    entry = next((e for e in read_external_agents()
                  if e.get("name") == name), None)
    return _a2a_entry_public(entry or {"name": name})


@app.delete("/api/a2a/external/{name}")
async def a2a_external_remove(name: str):
    from ioagentfarm.engine.a2a_registry import remove_external_agent
    if not remove_external_agent(name):
        raise HTTPException(status_code=404,
                            detail=f"no external agent named '{name}'")
    return {"ok": True}


def _a2a_resolve_refs(value: str) -> str:
    """Expand ``${VAR}`` / ``${VAR:-default}`` from this process's env —
    the same references iof-consult expands at dispatch time. Unset refs
    stay verbatim (the credentials diagnostic already names them)."""
    import os as _os
    from ioagentfarm.engine.a2a_registry import _ENV_REF_RE

    def sub(m):
        val = _os.environ.get(m.group(1))
        if val is None:
            val = m.group(2)
        return val if val is not None else m.group(0)
    return _ENV_REF_RE.sub(sub, value)


@app.post("/api/a2a/external/{name}/validate")
async def a2a_external_validate(name: str):
    """Three escalating checks in one response. Secrets NEVER leave: every
    resolved header value is scrubbed from any text that could echo it
    (URLs in exception messages, response bodies)."""
    from ioagentfarm.engine.a2a_registry import (read_external_agents,
                                                 unresolved_header_vars)
    entry = next((e for e in read_external_agents()
                  if e.get("name") == name), None)
    if entry is None:
        raise HTTPException(status_code=404,
                            detail=f"no external agent named '{name}'")

    unresolved = unresolved_header_vars(entry)
    url = _a2a_resolve_refs(str(entry.get("a2a_url") or ""))
    headers = {k: _a2a_resolve_refs(str(v))
               for k, v in (entry.get("headers") or {}).items()}
    secrets = [v for v in headers.values() if v and "${" not in v]

    def scrub(text: str) -> str:
        for s in secrets:
            text = text.replace(s, "***")
        return text

    result = {
        "credentials": {"ok": not unresolved, "unresolved": unresolved},
        "reachability": {"ok": False, "status": None, "error": None,
                         "card": None},
        "handshake": {"ok": False, "error": None},
    }

    import httpx
    card_url = url.rstrip("/") + "/.well-known/agent-card.json"
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get(card_url, headers=headers)
        result["reachability"]["status"] = r.status_code
        if r.status_code < 400:
            try:
                card = r.json()
                result["reachability"]["ok"] = True
                result["reachability"]["card"] = {
                    "name": card.get("name"),
                    "skills_count": len(card.get("skills") or []),
                }
            except ValueError:
                result["reachability"]["error"] = "card is not JSON"
        else:
            result["reachability"]["error"] = f"HTTP {r.status_code}"
    except httpx.HTTPError as exc:
        result["reachability"]["error"] = scrub(
            f"{type(exc).__name__}: {exc}")

    probe = {"jsonrpc": "2.0", "id": "validate-probe", "method": "GetTask",
             "params": {"taskId": "a2a-validate-probe"}}
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.post(url, headers=headers, json=probe)
        body = r.json()
        # A well-formed JSON-RPC peer answers with jsonrpc + (result|error)
        # even for a bogus task id — that is the protocol-shape proof.
        if body.get("jsonrpc") == "2.0" and ("result" in body
                                             or "error" in body):
            result["handshake"]["ok"] = True
        else:
            result["handshake"]["error"] = "response is not JSON-RPC 2.0"
    except ValueError:
        result["handshake"]["error"] = "response is not JSON"
    except httpx.HTTPError as exc:
        result["handshake"]["error"] = scrub(f"{type(exc).__name__}: {exc}")
    return result


# ---------------------------------------------------------------------------
# Capability fabric — tools, MCP tiers and swarms over HTTP.
#
# All three are ENGINE truth the Studio API pod cannot see: tool presence is
# a PATH/exec question against installed packs, the MCP view merges files
# under the state dir, and swarms resolve from installed packs plus the
# <IOF_ROOT>/swarms/ override tree. Same proxy-rail contract as learning and
# the A2A console. Secrets discipline: MCP summaries carry command/url only —
# never the env dict, whose global-tier entries may hold literal values.
# ---------------------------------------------------------------------------

def _collect_skill_texts() -> list[tuple[str, str, str]]:
    """``[(skill_name, skill_text, scope)]`` from pack sources (scope=pack)
    and the selected workspace's agent-home skills (scope=workspace).

    The matching itself lives in ``engine.tool_teaching`` — the ONE seam the
    Studio's per-agent "via <skill>" view shares, so the two surfaces cannot
    disagree about which skill teaches which tool (they did: the console
    matched only the ``tool:`` frontmatter key and said "no skill" for every
    incumbent prose-taught skill the per-agent view attributed correctly).
    """
    out: list[tuple[str, str, str]] = []
    seen: set[tuple[str, str]] = set()

    def _scan(entries, scope):
        for entry in entries:
            try:
                md = entry / "SKILL.md"
                if md.is_file() and (entry.name, scope) not in seen:
                    seen.add((entry.name, scope))
                    out.append((entry.name,
                                md.read_text(encoding="utf-8"), scope))
            except (OSError, TypeError, AttributeError):
                continue

    try:
        from ioagentfarm.packs import load_registry
        for source in load_registry().skill_sources():
            try:
                _scan(source.iterdir(), "pack")
            except (OSError, TypeError, AttributeError):
                continue
    except Exception:
        logger.debug("pack skill scan failed", exc_info=True)
    try:
        from ioagentfarm.engine.workspaces import agent_home_root
        home = agent_home_root()
        if home.is_dir():
            for agent_dir in home.iterdir():
                skills = agent_dir / "workspace" / "skills"
                if skills.is_dir():
                    _scan(skills.iterdir(), "workspace")
    except Exception:
        logger.debug("workspace skill scan failed", exc_info=True)
    return out


@app.get("/api/tools")
async def capability_tools():
    """Every pack-declared CLI tool with live presence — `cli-hub check` as
    an endpoint, plus the taught-by edge of the capability graph."""
    from ioagentfarm.packs import load_registry
    from ioagentfarm.tools_resolver import (ToolSpec, _gap_guidance,
                                            display_pack, validate)

    from ioagentfarm.engine.tool_teaching import teaches

    skill_texts = _collect_skill_texts()
    out = []
    for raw in load_registry().tools():
        spec = ToolSpec.from_dict(raw, pack=raw.get("_pack", "?"))
        present = validate(spec)
        if present is True:
            detail = None
        elif present is None:
            detail = "not validatable (declare 'bin' or 'check')"
        else:
            detail = _gap_guidance(spec)
        taught_by = [{"skill": name, "scope": scope}
                     for name, text, scope in skill_texts
                     if teaches(spec.name, spec.bin or "", name, text)]
        # `pack` stays the IDENTITY (callers scope and de-duplicate on it);
        # `declared_by` is the label to show, resolved from the installed
        # distribution so the console names the engine this deployment
        # actually has rather than the one this source tree publishes under.
        out.append({"name": spec.name, "pack": spec.pack,
                    "declared_by": display_pack(spec.pack),
                    "owner": spec.owner,
                    "installer": spec.installer, "bin": spec.bin,
                    "present": present is True, "detail": detail,
                    "taught_by": taught_by})
    return {"tools": out}


@app.get("/api/mcp/effective")
async def capability_mcp():
    """The merged cross-tier MCP view a run would get, with provenance.

    Summaries carry the command or url only (refs unexpanded); the env dict
    never appears — a global-tier entry may hold a literal secret.
    """
    from ioagentfarm.engine.iobot_config import effective_mcp_servers
    from ioagentfarm.engine.workspaces import (WorkspaceNotSelected,
                                               WorkspaceRetired)
    try:
        merged = effective_mcp_servers()
    except (WorkspaceNotSelected, WorkspaceRetired) as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    servers = []
    for name in sorted(merged):
        entry = merged[name]
        spec = entry.get("spec") or {}
        if spec.get("url"):
            summary = str(spec["url"])
        else:
            args = spec.get("args") or []
            summary = " ".join([str(spec.get("command") or ""),
                                *[str(a) for a in args]]).strip()
        tier_raw = str(entry.get("tier") or "global")
        tier = ("pack" if tier_raw.startswith("pack")
                else "workspace" if tier_raw.startswith("workspace")
                else "global")
        servers.append({
            "name": name, "tier": tier, "tier_detail": tier_raw,
            "summary": summary,
            "enabled": entry.get("status") != "disabled",
            "unresolved": sorted(entry.get("missing") or []),
        })
    return {"servers": servers}


def _swarm_source_of(name: str, root: Path) -> str:
    return ("override"
            if (root / "swarms" / name / "swarm.yaml").is_file() else "pack")


def _swarm_yaml_text(name: str, root: Path):
    """(text, source) resolved with SwarmLoader's exact precedence."""
    override = root / "swarms" / name / "swarm.yaml"
    if override.is_file():
        return override.read_text(encoding="utf-8"), "override"
    from ioagentfarm.packs import load_registry
    for source in load_registry().swarm_sources():
        try:
            candidate = source / name / "swarm.yaml"
            if candidate.is_file():
                return candidate.read_text(encoding="utf-8"), "pack"
        except (OSError, TypeError, AttributeError):
            continue
    raise FileNotFoundError(name)


def _lint_groups(text: str, name: str) -> dict:
    from ioagentfarm.engine.swarm_lint import lint_swarm_text
    from ioagentfarm.engine.workflow_lint import ERROR
    findings = lint_swarm_text(text, dir_name=name)
    def _row(f):
        return {"where": f.where, "message": f.message, "fix": f.fix,
                "line": f.line}
    return {"errors": [_row(f) for f in findings if f.severity == ERROR],
            "warnings": [_row(f) for f in findings if f.severity != ERROR]}


@app.get("/api/swarms")
async def capability_swarms():
    from ioagentfarm.engine.swarms import SwarmLoader
    root = _root()
    swarms = SwarmLoader().list_swarms(root=root)
    out = []
    for name in sorted(swarms):
        s = swarms[name]
        out.append({
            "name": name, "solution": None, "meta_agent": s.role,
            "description": s.description,
            # None = "all registered" (the roster key was omitted) — a count
            # would need the registry and would go stale; null is honest.
            "roster_count": (None if s.agents is None else len(s.agents)),
            "mcp_count": (None if s.mcp_servers is None
                          else len(s.mcp_servers)),
            "deliverable": s.deliverable,
            "source": _swarm_source_of(name, root),
        })
    return {"swarms": out}


@app.get("/api/swarms/{name}")
async def capability_swarm_detail(name: str):
    from ioagentfarm.engine.swarms import compiled_skills, parse_swarm
    root = _root()
    try:
        text, source = _swarm_yaml_text(name, root)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"no swarm named '{name}'")
    compiled = None
    try:
        swarm = parse_swarm(text)
        compiled = {
            "roster": swarm.agents, "mcp_servers": swarm.mcp_servers,
            "skills": compiled_skills(swarm),
            "budget": (swarm.budget.model_dump() if swarm.budget else {}),
            "deliverable": swarm.deliverable, "meta_agent": swarm.role,
        }
    except ValueError:
        pass  # lint reports the why; the raw yaml is still returned
    return {"name": name, "yaml": text, "compiled": compiled,
            "lint": _lint_groups(text, name), "source": source}


@app.put("/api/swarms/{name}")
async def capability_swarm_save(name: str, req: dict):
    """Save to the override tree. Lint is ADVISORY (the workflow-save
    precedent: refusing content that saves today would strand edits) — but
    text that is not YAML at all is refused; there is nothing to save."""
    import re as _re

    import yaml as _yaml
    if not _re.match(r"^[a-z][a-z0-9_]{1,48}$", name):
        raise HTTPException(status_code=400,
                            detail="swarm name must match ^[a-z][a-z0-9_]+$")
    text = req.get("yaml")
    if not isinstance(text, str) or not text.strip():
        raise HTTPException(status_code=400, detail="body must carry 'yaml'")
    try:
        parsed = _yaml.safe_load(text)
    except _yaml.YAMLError as exc:
        raise HTTPException(status_code=400, detail=f"not valid YAML: {exc}")
    if not isinstance(parsed, dict):
        raise HTTPException(status_code=400,
                            detail="top level must be a mapping")
    root = _root()
    target = root / "swarms" / name / "swarm.yaml"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding="utf-8")
    return {"name": name, "yaml": text, "lint": _lint_groups(text, name),
            "source": "override"}


@app.post("/api/swarms/{name}/run")
def capability_swarm_run(name: str, req: dict):
    """Create and spawn a swarm run — the exact `run-swarm` machinery:
    compile-is-the-snapshot before anything else touches the run, steps
    materialized through the REAL workflow loader, detached spawn."""
    from ioagentfarm.cli import ORCHESTRATOR_ROLE, _emit_run_created
    from ioagentfarm.engine.swarms import SwarmLoader, compile_swarm
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    from ioagentfarm.engine.workspaces import (ensure_iobot_agent,
                                               resolved_workspace_code)

    goal = (req.get("goal") or "").strip()
    if not goal:
        raise HTTPException(status_code=400, detail="body must carry 'goal'")
    root = _root()
    try:
        swarm = SwarmLoader().load(name, root=root)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"no swarm named '{name}'")
    except ValueError as exc:
        raise HTTPException(status_code=400,
                            detail=f"swarm '{name}' failed to load: {exc}")

    from ioagentfarm.engine.guards import DiskSpaceError, ensure_free_disk
    try:
        ensure_free_disk(root)
    except DiskSpaceError as exc:
        raise HTTPException(status_code=507, detail=str(exc))

    ws_code = resolved_workspace_code()   # serve fail-fasts without one
    store = _store()
    for role_name in (swarm.role, ORCHESTRATOR_ROLE):
        try:
            ensure_iobot_agent(role_name, workspace_code=ws_code)
        except Exception:
            logger.warning("could not pre-seed %s for swarm run", role_name,
                           exc_info=True)
    ws_id = store.ensure_workspace(
        code=ws_code, name=ws_code.replace("_", " ").title())
    # Deliberately NO ensure_workflow: a swarm is not a workflow-catalog row;
    # runs.kind='swarm' carries the distinction.
    run_id = store.create_run(workflow_name=swarm.name, goal=goal,
                              project_dir="", user_id="web:studio",
                              workflow_id=None, workspace_id=ws_id,
                              kind="swarm")
    _emit_run_created(root, run_id, swarm.name, "swarm", goal,
                      workspace_code=ws_code)
    compile_swarm(swarm, run_id, root)
    compiled_wf = WorkflowLoader().load(swarm.name, run_id=run_id, root=root)
    store.materialize_steps(run_id, compiled_wf)
    spawn_run(run_id=run_id, workflow=swarm.name, goal=goal, project_dir="",
              user_id="web:studio", root_path=root, workspace=ws_code)
    return {"run_id": run_id}


@app.post("/api/skills/sync")
def sync_skills():
    """Publish the installed packs' SKILL CATALOG into ``pack_skills``.

    The counterpart of ``/api/agents/sync``, and until 2026-08 it did not
    exist in either process. Consequence on a correctly deployed API pod (no
    packs, no agent home): every SDK skill — ``presentation``, ``data_query``,
    ``guardrails``, ``vectorfs_query`` — was absent from the Studio entirely,
    because the only trace a pack skill left in the database was an
    assignment-only ``studio_skills`` row carrying no name, description or
    body.

    Global, refreshed and pruned on every call: an SDK upgrade lands
    everywhere at once, and a skill dropped from the wheel loses its row.

    Also available without a running server as ``aicore sync``, and run
    automatically by ``setup-agents``.
    """
    from ioagentfarm.engine.catalog_sync import sync_pack_skills as _sync

    synced = _sync(_store())
    return {"synced": len(synced), "skills": synced}


class WorkflowDefsSyncRequest(BaseModel):
    #: REQUIRED — the workspace whose Studio catalog this import writes.
    #: The old default ('default') meant a body that omitted the field
    #: imported the whole pack catalog into a workspace nobody chose.
    workspace_code: str
    #: None = the full installed catalog; a list = only those packs, which
    #: is how a scoped tenant's catalog is seeded.
    include_packs: list[str] | None = None


@app.post("/api/workflows/defs/sync")
async def sync_workflow_defs(req: WorkflowDefsSyncRequest):
    """Import the installed pack WORKFLOWS into ``studio_workflow_defs``.

    Distinct from ``/api/workflows/sync``, which writes the engine's own
    run-metadata registry. This one writes the Studio's DB-canonical catalog,
    and it lives here because it needs the packs — the Studio API pod does not
    have them. It had its own copy of this until 2026-08, globbing a repo
    layout that exists only on a developer's checkout.
    """
    from ioagentfarm.engine.catalog_sync import sync_workflow_defs as _sync

    ws_code = _run_workspace_code(req.workspace_code)
    return _sync(ws_code, include_packs=req.include_packs)


# ---------------------------------------------------------------------------
# POST /api/feedback — skill feedback from any channel
# ---------------------------------------------------------------------------

class FeedbackRequest(BaseModel):
    run_id: str
    step_key: str
    role: str
    signal: str  # positive, negative, correction
    content: str = ""
    user_id: str = ""
    learning_id: str = ""  # optional: target specific skill from feedback card


@app.post("/api/feedback")
def submit_feedback(req: FeedbackRequest):
    """Record user feedback on learnings applied in a step.

    Finds all active learnings for the step's role+workflow and records
    the feedback signal against each one.
    """
    store = _store()
    run = store.get_run(req.run_id)
    if not run:
        raise HTTPException(404, f"Run {req.run_id} not found")

    workflow = run["workflow_name"]

    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.learning import LearningLifecycle
    adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
    ll = LearningLifecycle(adapter)
    ll.init()

    recorded = 0
    if req.learning_id:
        # Targeted feedback from feedback card (specific skill)
        ll.record_feedback(
            req.learning_id,
            signal=req.signal,
            content=req.content,
            user_id=req.user_id,
            run_id=req.run_id,
            step_key=req.step_key,
            source_channel="api",
        )
        recorded = 1
    else:
        # Broad feedback on all active skills for this role+workflow
        skills = ll.get_skills(role=req.role, workflow=workflow)
        for skill in skills:
            ll.record_feedback(
                skill["learning_id"],
                signal=req.signal,
                content=req.content,
                user_id=req.user_id,
                run_id=req.run_id,
                step_key=req.step_key,
                source_channel="api",
            )
            recorded += 1

    return {
        "status": "ok",
        "signal": req.signal,
        "skills_updated": recorded,
        "workflow": workflow,
        "role": req.role,
    }


# ---------------------------------------------------------------------------
# GET /api/learnings — list learnings with optional filters
# ---------------------------------------------------------------------------

@app.get("/api/learnings")
def list_learnings(role: str = "", workflow: str = "", active_only: bool = True):
    """List learnings with optional role/workflow filters."""
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.learning import LearningLifecycle
    adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
    ll = LearningLifecycle(adapter)
    ll.init()

    from ioagentfarm.engine.learning import LearningStore
    skills = ll._store.list_learnings(
        role=role or None,
        workflow=workflow or None,
        active_only=active_only,
    )
    for s in skills:
        s["health"] = round(LearningStore.learning_health(s), 3)

    return {"learnings": skills, "total": len(skills)}


# ---------------------------------------------------------------------------
# GET /api/learnings/summary — learning store summary stats
# ---------------------------------------------------------------------------

@app.get("/api/learnings/summary")
def learnings_summary(role: str = "", workflow: str = ""):
    """Summary stats for the learning store."""
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.learning import LearningLifecycle
    adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
    ll = LearningLifecycle(adapter)
    ll.init()
    return ll.summary(role=role or None, workflow=workflow or None)


# ---------------------------------------------------------------------------
# GET /api/learnings/analytics — effectiveness metrics + feedback loop closure
# ---------------------------------------------------------------------------

@app.get("/api/learnings/analytics")
async def learnings_analytics(role: str = "", workflow: str = ""):
    """Learning effectiveness analytics with feedback loop closure metrics.

    Returns top performers, underperformers, feedback distribution by channel,
    and overall ROI signal (completion rate with skills, net sentiment).
    """
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.learning import LearningLifecycle
    adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
    ll = LearningLifecycle(adapter)
    ll.init()
    return ll.analytics(role=role or None, workflow=workflow or None)


# ---------------------------------------------------------------------------
# POST /api/learnings/rationalize — deduplicate learned skills
# ---------------------------------------------------------------------------

class RationalizeRequest(BaseModel):
    role: str
    workflow: str
    similarity_threshold: float = 0.6


@app.post("/api/learnings/rationalize")
async def rationalize_learnings(req: RationalizeRequest):
    """Deduplicate and merge similar learned skills within a scope."""
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.learning import LearningLifecycle
    adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
    ll = LearningLifecycle(adapter)
    ll.init()
    return ll.rationalize(
        role=req.role, workflow=req.workflow,
        similarity_threshold=req.similarity_threshold,
    )


# ---------------------------------------------------------------------------
# GET /health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    pool: AgentPool = getattr(app.state, "agent_pool", None)
    return {
        "status": "ok",
        # `/health` answers BEFORE the auth policy is read - it is one of the
        # three exempt routes - so anything in this body is readable by
        # anyone who can reach the port. It named the publisher's import
        # package, which is the same leak the WWW-Authenticate realm had and
        # the one documentation cannot fix (found sweeping the external
        # surfaces, 2026-09-03). It names the SERVICE now.
        "service": "aicore-engine",
        "agents": pool.active_roles if pool else [],
    }
