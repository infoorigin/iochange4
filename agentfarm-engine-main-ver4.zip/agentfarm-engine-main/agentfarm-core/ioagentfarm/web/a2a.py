"""A2A (Agent2Agent) protocol web surface — JSON-RPC 2.0 binding.

Exposes every always-on agent in the pool as an A2A-callable service:

  GET  /a2a/agents                                  — flat list of A2A-enabled roles
  GET  /a2a/{role}/.well-known/agent-card.json      — public Agent Card
  POST /a2a/{role}                                  — JSON-RPC endpoint (method dispatch)

The handler is a THIN wrapper: it translates the A2A wire format to a
`process_direct()` call on the same pre-warmed AgentLoop that backs the
`/api/chat/{workflow}` endpoint. Same agent pool, same iobot workspace,
same cache-warmed prefix — only the wire format on the way in differs.

Wire format is A2A spec v1.0 (clean cut from v0.3 — no backward compat):
PascalCase methods (`SendMessage`/`GetTask`/`CancelTask`), member-based
Parts (no `kind`), `TASK_STATE_*` enums, `ROLE_*` roles, and a card whose
endpoint lives in `supportedInterfaces[]`.

v1.0 implements: `SendMessage`, `GetTask`, `CancelTask`.
Deliberately NOT implemented: streaming (`SendStreamingMessage`,
`SubscribeToTask`), push notifications, auth. The agent card advertises
`capabilities.streaming = false` so spec-compliant clients won't call the
streaming methods; if they do, we return JSON-RPC -32601 Method not found.
"""

from __future__ import annotations

import json
import os
from collections import OrderedDict
from datetime import datetime, timezone
from importlib import resources
from typing import Any, Optional
from uuid import uuid4

import yaml
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from loguru import logger

from ioagentfarm.engine.workspaces import (
    AGENT_PKG,
    get_agent_name,
    iobot_agent_workspace,
)
from ioagentfarm.web.a2a_models import (
    ERR_INTERNAL,
    ERR_INVALID_PARAMS,
    ERR_INVALID_REQUEST,
    ERR_METHOD_NOT_FOUND,
    ERR_TASK_NOT_CANCELABLE,
    ERR_TASK_NOT_FOUND,
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentProvider,
    AgentSkill,
    Artifact,
    TaskArtifactUpdateEvent,
    TaskStatusUpdateEvent,
    DataPart,
    JsonRpcError,
    JsonRpcRequest,
    JsonRpcResponse,
    Task,
    TaskStatus,
    TextPart,
)


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


# Per-role bounded LRU cache so `tasks/get` can replay recent results.
# Bounded because v1 is sync — once the response is returned, the caller
# already has it; the cache is just a courtesy for spec-compliant clients
# that prefer polling. 100 per role is more than enough.
_TASK_CACHE_MAX = 100
_task_cache: dict[str, "OrderedDict[str, dict]"] = {}


def _task_cache_put(role: str, task_id: str, task: dict) -> None:
    bucket = _task_cache.setdefault(role, OrderedDict())
    bucket[task_id] = task
    bucket.move_to_end(task_id)
    while len(bucket) > _TASK_CACHE_MAX:
        bucket.popitem(last=False)


def _task_cache_get(role: str, task_id: str) -> Optional[dict]:
    bucket = _task_cache.get(role)
    if not bucket:
        return None
    return bucket.get(task_id)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


async def _noop_cb(*_args, **_kwargs):
    pass


def _jsonrpc_error(req_id: Any, code: int, message: str, data: Any = None) -> dict:
    """Build a JSON-RPC error response envelope.

    Per spec, JSON-RPC errors still return HTTP 200; the error lives inside
    the envelope. Callers that treat 4xx/5xx as transport errors won't
    mistake a `MethodNotFound` for a server crash.
    """
    return JsonRpcResponse(
        id=req_id, error=JsonRpcError(code=code, message=message, data=data)
    ).model_dump(exclude_none=True)


def _jsonrpc_result(req_id: Any, result: Any) -> dict:
    return JsonRpcResponse(id=req_id, result=result).model_dump(exclude_none=True)


def _log_a2a(direction: str, role: str, method: Any, payload: Any) -> None:
    """Log the raw A2A JSON-RPC wire envelope exactly as it crosses the boundary.

    Two lines per event:
      1. One-line header (not JSON) — identifies the event for log scanning.
      2. The complete wire envelope as pretty-printed JSON — this IS the A2A
         payload; no wrapper added so it remains spec-recognizable and can be
         replayed verbatim against any A2A v1.0 consumer.

    Passed as single positional args so loguru never treats `{}`/`{key}` inside
    the JSON as format placeholders.
    """
    logger.info("A2A {} | role={} | method={}", direction, role, method)
    try:
        body = json.dumps(payload, indent=2, ensure_ascii=False)
    except Exception:
        body = repr(payload)
    logger.info("{}", body)


# ---------------------------------------------------------------------------
# Agent Card loader
# ---------------------------------------------------------------------------


def _load_card_yaml(role: str) -> dict:
    """Read `workspace/a2a-card.yaml` for a role.

    Checks live iobot workspace first, then bundled template. Returns
    {} when neither exists — caller falls back to a minimal auto-card.
    """
    # Live workspace overrides bundled template
    live = iobot_agent_workspace(role) / "a2a-card.yaml"
    if live.is_file():
        try:
            return yaml.safe_load(live.read_text(encoding="utf-8")) or {}
        except Exception as exc:
            logger.warning("A2A card YAML parse failed for {} (live): {}", role, exc)

    # THE INSTALLED PACKS COME BEFORE THE PLATFORM TEMPLATE. A card shipped
    # by a workspace pack at agents/<role>/workspace/a2a-card.yaml was read
    # by nothing until a chat or run materialized the agent home, so
    # `list-agents --scope` and the served card said `exposed: no`, skills
    # `chat`, description "Agent '<role>'." about an agent whose author had
    # just declared the opposite (walked 2026-09-02). The pack is where the
    # author writes it; the home is a copy.
    try:
        from ioagentfarm.packs import load_registry
        for root in load_registry().agent_sources():
            try:
                shipped = root / role / "workspace" / "a2a-card.yaml"
                if shipped.is_file():
                    return yaml.safe_load(shipped.read_text(encoding="utf-8")) or {}
            except Exception as exc:  # noqa: BLE001 - one bad root is not all
                logger.warning("A2A card YAML parse failed for {} (pack): {}", role, exc)
    except Exception:  # noqa: BLE001 - no registry: fall through
        pass

    try:
        bundled = resources.files(AGENT_PKG) / role / "workspace" / "a2a-card.yaml"
        if bundled.is_file():
            try:
                return yaml.safe_load(bundled.read_text(encoding="utf-8")) or {}
            except Exception as exc:
                logger.warning("A2A card YAML parse failed for {} (bundled): {}", role, exc)
    except Exception:
        pass

    return {}


def _db_card_yaml(role: str, workspace_code: str) -> dict:
    """The authored a2a-card.yaml from the agent's DB row, if any.

    A Studio-authored agent exists as a ``studio_agent_defs`` row before any
    host has materialized its workspace — at serve startup, exactly when the
    exposure scan runs. Without this tier a card authored in the Studio would
    declare exposure that nothing ever reads until some other path happens to
    materialize the agent: a producer without a consumer, failing quietly.
    Tenant row first, platform tier second — same precedence as hydration.
    """
    from ioagentfarm.engine import hydration as _h
    from ioagentfarm.engine.workspaces import PLATFORM_TIER
    try:
        adapter, con = _h._connect()
    except Exception:
        return {}
    try:
        cur = _h._raw(con).cursor()
        for ws in dict.fromkeys((workspace_code, PLATFORM_TIER)):
            cur.execute(_h._q(adapter,
                        "SELECT files_json FROM studio_agent_defs "
                        "WHERE role = ? AND workspace_code = ?"), (role, ws))
            row = cur.fetchone()
            if not row:
                continue
            files = json.loads(_row_value(row, "files_json") or "{}")
            text = files.get("a2a-card.yaml")
            if text:
                try:
                    return yaml.safe_load(text) or {}
                except Exception as exc:
                    logger.warning("A2A card YAML parse failed for {} (db): {}",
                                   role, exc)
        return {}
    except Exception:
        return {}
    finally:
        _h._release(con)


def _row_value(row: Any, key: str) -> Any:
    if isinstance(row, dict):
        return row.get(key)
    try:
        return row[key]
    except Exception:
        return row[0]


def card_exposes(role: str, workspace_code: str) -> bool:
    """Whether the role's agent card declares ``expose: true``.

    The card file is the exposure declaration: authoring it with
    ``expose: true`` is what puts an agent on the A2A surface — no
    deployment env edit. Precedence: live workspace file, then the DB row
    (the Studio-authored, not-yet-materialized case), then the bundled pack
    card. Absent or anything but ``true`` means not exposed; operators can
    still expose any role via ``IOF_ALWAYS_ON_AGENTS``.
    """
    authored = _load_card_yaml(role)
    if not authored:
        authored = _db_card_yaml(role, workspace_code)
    return authored.get("expose") is True


def exposed_roles(workspace_code: str) -> list[str]:
    """The workspace's roles whose agent cards declare exposure.

    The roster is the union of the DB roster (Studio-authored and imported
    agents) and the workspace's on-disk agent homes (seeded or adopted
    agents commonly have no DB row at all) — an authored card counts
    wherever the agent actually lives.
    """
    roles: set[str] = set()
    try:
        from ioagentfarm.workspace_sync import workspace_agent_roles
        roles.update(workspace_agent_roles(workspace_code))
    except Exception as exc:
        logger.warning("card-exposure DB roster scan failed: {}", exc)
    try:
        from ioagentfarm.engine.workspaces import agent_home_root
        root = agent_home_root()
        if root.is_dir():
            roles.update(p.name for p in root.iterdir()
                         if (p / "workspace").is_dir())
    except Exception as exc:
        logger.warning("card-exposure disk roster scan failed: {}", exc)
    from ioagentfarm.engine.always_on import is_desk_side
    out: list[str] = []
    for role in roles:
        # A DESK-SIDE ROLE IS NEVER EXPOSED, whatever its card says. The A2A
        # surface is the other door onto the same pool, and a guard applied
        # at one door is not a guard.
        if is_desk_side(role):
            continue
        try:
            if card_exposes(role, workspace_code):
                out.append(role)
        except Exception as exc:
            logger.warning("card read failed for '{}': {}", role, exc)
    return sorted(out)


def _soul_first_paragraph(role: str) -> str:
    """First non-heading paragraph of SOUL.md — used as auto-card description."""
    candidates: list[Any] = [iobot_agent_workspace(role) / "SOUL.md"]
    try:
        candidates.append(resources.files(AGENT_PKG) / role / "workspace" / "SOUL.md")
    except Exception:
        pass
    for candidate in candidates:
        try:
            if not candidate.is_file():
                continue
            text = candidate.read_text(encoding="utf-8")
        except Exception:
            continue
        for block in text.split("\n\n"):
            block = block.strip()
            if not block or block.startswith("#"):
                continue
            return block.split("\n", 1)[0].strip()[:300]
    return f"Agent '{role}'."


def build_agent_card(role: str, base_url: str) -> AgentCard:
    """Compose the full Agent Card for a role.

    YAML provides authored fields (name, description, version, skills).
    Handler fills the rest from defaults — `url`, `capabilities`,
    `protocolVersion`, etc. This way agent authors only write what's
    domain-specific to their agent.
    """
    authored = _load_card_yaml(role)
    card_id = authored.get("id") or role
    name = authored.get("name") or get_agent_name(role)
    description = authored.get("description") or _soul_first_paragraph(role)
    version = authored.get("version") or "1.0.0"

    # A2A v1.0 makes `provider` required. Prefer authored block; otherwise
    # synthesize a minimal provider from the agent's display name so the card
    # stays spec-valid even for agents that haven't authored an a2a-card.yaml.
    provider_raw = authored.get("provider")
    if isinstance(provider_raw, dict) and provider_raw.get("organization"):
        provider = AgentProvider(**provider_raw)
    else:
        provider = AgentProvider(organization=name)

    skills_raw = authored.get("skills") or []
    skills = [
        AgentSkill(
            id=s.get("id") or "default",
            name=s.get("name") or s.get("id") or "default",
            description=s.get("description"),
            tags=list(s.get("tags") or []),
            examples=s.get("examples"),
            inputModes=s.get("inputModes"),
            outputModes=s.get("outputModes"),
        )
        for s in skills_raw
    ]
    if not skills:
        # Every card MUST have at least one skill per spec.
        skills = [
            AgentSkill(
                id="chat",
                name="Chat",
                description=f"Free-form conversation with {name}.",
                tags=["chat"],
            )
        ]

    # Capabilities and default I/O modes are authored per-agent when the
    # agent's real contract isn't text/plain (e.g. a JSON-in/JSON-out card
    # like sia_agent/profound_a2a) — fall back to the historical text/plain,
    # all-false defaults when unauthored.
    capabilities_raw = authored.get("capabilities") or {}
    # STREAMING IS SERVED, so the card says so - and the default is now True
    # rather than authored per agent. A client reads this field to decide
    # whether to call `SendStreamingMessage` at all, so it has to follow the
    # dispatch table, not an author's opinion: advertising false while the
    # method works costs every caller the feature silently, and advertising
    # true while it does not is worse. An agent card may still turn it OFF
    # explicitly.
    capabilities = AgentCapabilities(
        streaming=bool(capabilities_raw.get("streaming", True)),
        pushNotifications=bool(capabilities_raw.get("pushNotifications", False)),
        stateTransitionHistory=bool(capabilities_raw.get("stateTransitionHistory", False)),
    )
    default_input_modes = authored.get("defaultInputModes") or ["text/plain"]
    default_output_modes = authored.get("defaultOutputModes") or ["text/plain"]

    return AgentCard(
        id=card_id,
        name=name,
        description=description,
        provider=provider,
        supportedInterfaces=[
            AgentInterface(
                url=f"{base_url.rstrip('/')}/a2a/{role}",
                protocolBinding="JSONRPC",
                protocolVersion="1.0",
            )
        ],
        version=version,
        capabilities=capabilities,
        defaultInputModes=default_input_modes,
        defaultOutputModes=default_output_modes,
        skills=skills,
    )


# ---------------------------------------------------------------------------
# JSON-RPC method handlers
# ---------------------------------------------------------------------------


def _stream_frame(rpc_id, payload: dict) -> str:
    """One SSE frame: a whole JSON-RPC response carrying a `StreamResponse`.

    No `event:` line - the spec client reads `data:` and parses it as a
    JSON-RPC response. Adding one is harmless to that client and misleading
    to a human reading the wire, so it is left off.
    """
    import json as _j
    body = {"jsonrpc": "2.0", "id": rpc_id, "result": payload}
    return "data: " + _j.dumps(body, ensure_ascii=False) + chr(10) + chr(10)


def _status_update(task_id: str, ctx_id: str, state: str) -> dict:
    return {"statusUpdate": TaskStatusUpdateEvent(
        taskId=task_id, contextId=ctx_id,
        status=TaskStatus(state=state, timestamp=_now_iso()),
    ).model_dump(exclude_none=True)}


def _artifact_text(task_dict: dict) -> str:
    """The reply as ONE string, from a dumped Task: every part of the
    `response` artifact - a TextPart verbatim, a DataPart as its JSON."""
    import json as _j
    out: list[str] = []
    for art in (task_dict or {}).get("artifacts") or []:
        if (art or {}).get("name") not in (None, "response"):
            continue
        for part in art.get("parts") or []:
            if "text" in part and part["text"]:
                out.append(str(part["text"]))
            elif "data" in part and part["data"] is not None:
                out.append(_j.dumps(part["data"], ensure_ascii=False))
    return "".join(out)


def _last_chunk_text(task_dict: dict, sent_any: bool) -> str:
    """What the closing artifactUpdate carries: nothing when increments
    already delivered the text, the whole text when none did."""
    return "" if sent_any else _artifact_text(task_dict)


def _text_chunk(task_id: str, ctx_id: str, artifact_id: str, text: str,
                *, last: bool = False) -> dict:
    return {"artifactUpdate": TaskArtifactUpdateEvent(
        taskId=task_id, contextId=ctx_id,
        artifact=Artifact(artifactId=artifact_id, name="response",
                          parts=[TextPart(text=text)]),
        append=True, lastChunk=last or None,
    ).model_dump(exclude_none=True)}


async def _stream_message_send(role: str, params: dict, pool, rpc_id,
                               request):
    """A2A v1.0 `SendStreamingMessage` — the same turn, streamed.

    The frames, in order::

        task            SUBMITTED  - first, so the client can correlate
        statusUpdate    WORKING    - the turn is live
        artifactUpdate  append     - one per text delta
        artifactUpdate  lastChunk  - the artifact is complete
        task            COMPLETED  - the body `SendMessage` would have returned
        statusUpdate    COMPLETED  - terminal

    The final `task` is redundant for a client accumulating deltas and makes
    the stream impossible to half-read: a caller that ignores the
    incremental frames still ends with exactly the sync body. One frame is a
    cheap price for that.

    Runs through `chat_stream.stream_turn`, so the bounded first wait, the
    refusal rule, the heartbeat and cancel-on-disconnect are the ones already
    proven on the chat surface rather than a second copy.

    WHEN THE FIRST FRAME ARRIVES, measured rather than assumed. The preamble
    is written from inside the generator, which does not start until the
    bounded first wait resolves - so with provider streaming DISABLED
    (`IOF_DISABLE_STREAMING`, on in this deployment for MiniMax stall
    reliability) no delta arrives and the first frame lands at
    `IOF_CHAT_STREAM_FIRST_EVENT_S`, 5s by default. Live: 5.36s into a 9.38s
    turn. With deltas flowing it is the first delta.

    That ordering is deliberate, not an oversight. Emitting the preamble
    IMMEDIATELY would commit to a 200 and an event stream before the handler
    has had a chance to refuse - and a refusal here must come back as a
    JSON-RPC error object, which is what a spec client expects. Verified:
    `parts: []` returns HTTP 200 `application/json` with -32602, not a
    stream carrying an error frame. Lowering the timeout trades one against
    the other.
    """
    from ioagentfarm.web import chat_stream

    ctx_id = _peek_context_id(params)
    task_id = f"task-{uuid4().hex[:12]}"
    artifact_id = f"art-{uuid4().hex[:8]}"

    async def _turn() -> dict:
        # The sync method owns every rule about this request. Give it the ids
        # we have already published so the client's correlation holds.
        return await _method_message_send(
            role, params, pool, task_id=task_id, ctx_id=ctx_id)

    sent = {"any": False}

    def _fmt(event: str, data) -> str:
        if event == "delta":
            text = (data or {}).get("text") if isinstance(data, dict) else None
            if not text:
                return ": empty-delta" + chr(10) + chr(10)
            sent["any"] = True
            return _stream_frame(
                rpc_id, _text_chunk(task_id, ctx_id, artifact_id, text))
        if event == "status":
            return _stream_frame(
                rpc_id, _status_update(task_id, ctx_id, "TASK_STATE_WORKING"))
        if event == "message":
            # `data` is the sync body: {"task": {...}}. Emit it verbatim as
            # the `task` member, then the terminal status.
            payload = data.get("task") if isinstance(data, dict) else None
            out = ""
            if payload is not None:
                # WITH PROVIDER STREAMING OFF (this deployment) no delta ever
                # arrives, and the closing chunk carried "" - a client that
                # accumulates artifactUpdate text ended the turn with nothing
                # while the answer sat only in the task frame (walked
                # 2026-09-02). The last chunk carries the whole text when no
                # increment did; when increments flowed it stays empty so
                # nothing is delivered twice.
                out += _stream_frame(
                    rpc_id, _text_chunk(task_id, ctx_id, artifact_id,
                                        _last_chunk_text(payload, sent["any"]),
                                        last=True))
                out += _stream_frame(rpc_id, {"task": payload})
            out += _stream_frame(
                rpc_id, _status_update(task_id, ctx_id, "TASK_STATE_COMPLETED"))
            return out
        if event == "error":
            # A failure AFTER the stream began cannot be an HTTP status, so
            # it is a JSON-RPC error frame plus a FAILED terminal status - a
            # client that only watches status still learns the turn died.
            detail = data if isinstance(data, dict) else {"error": str(data)}
            import json as _j
            body = {"jsonrpc": "2.0", "id": rpc_id,
                    "error": {"code": ERR_INTERNAL,
                              "message": str(detail.get("error") or detail)}}
            return ("data: " + _j.dumps(body, ensure_ascii=False)
                    + chr(10) + chr(10)
                    + _stream_frame(rpc_id, _status_update(
                        task_id, ctx_id, "TASK_STATE_FAILED")))
        if event == "done":
            return ""          # the terminal frame is the status above
        return ": " + event + chr(10) + chr(10)

    preamble = _stream_frame(rpc_id, {"task": {
        "id": task_id,
        "contextId": ctx_id,
        "status": {"state": "TASK_STATE_SUBMITTED", "timestamp": _now_iso()},
    }}) + _stream_frame(
        rpc_id, _status_update(task_id, ctx_id, "TASK_STATE_WORKING"))

    return await chat_stream.stream_turn(
        _turn, request, format_frame=_fmt, preamble=preamble)


def _peek_context_id(params: dict) -> str:
    """The contextId this turn will use, resolved BEFORE the turn runs.

    The first frame carries it, so it cannot be minted inside the handler.
    Same rule as the sync path, and deliberately the same three lines: a
    blank or whitespace value is ABSENT, never a thread key - a validator
    proved that `"   "` was a shared thread two callers could read each
    other's secrets through.
    """
    message = (params or {}).get("message") or {}
    raw = (message.get("contextId")
           or (params.get("contextId") if isinstance(params, dict) else None))
    if not isinstance(raw, str) or not raw.strip():
        return f"ctx-{uuid4().hex[:12]}"
    return raw


async def _method_message_send(role: str, params: dict, pool, *,
                               task_id: str | None = None,
                               ctx_id: str | None = None) -> dict:
    """Implements A2A v1.0 `SendMessage` — sync request/response.

    *task_id* and *ctx_id* let the STREAMING caller pass the ids it has
    already put on the wire in its first frame. They are not an alternative
    resolution path: when absent, this function mints them exactly as before,
    and the streaming caller derives `ctx_id` with the same blank-is-absent
    rule. One turn, one set of ids, whichever surface asked for it.
    """
    message = (params or {}).get("message") or {}
    parts = message.get("parts") or []
    # A2A v1.0 Parts are member-based (no `kind`): a text part is any part
    # carrying a string `text` member. Concatenate all text members.
    prompt = "".join(
        p["text"] for p in parts
        if isinstance(p, dict) and isinstance(p.get("text"), str)
    ).strip()
    if not prompt:
        raise _A2AError(
            ERR_INVALID_PARAMS,
            "params.message.parts must include at least one non-empty text part",
        )

    # Session model:
    #   contextId  -> iobot session_key (multi-turn continuity)
    #   taskId     -> our LRU key (one task per turn in sync mode)
    # `contextId` BELONGS TO THE MESSAGE per A2A v1.0, and a caller that puts
    # it beside the message instead is the common mistake — the JSON-RPC
    # `params` object is the obvious place to a reader who has not memorised
    # the schema. Read from either, message first.
    #
    # Taking only one spelling made the failure SILENT and total: a fresh
    # context was minted, the reply carried an id the caller never sent, and
    # every turn started a new conversation with no error anywhere. Multi-turn
    # simply did not work, and nothing said why. Losing continuity because a
    # field sits one level up is not a distinction worth defending.
    #
    # A BLANK contextId IS NOT A CONTEXT. `""` already fell through to a fresh
    # id, but `"   "` did not: it became a thread key verbatim, and because it
    # is a value any caller can send by accident, it is a SHARED thread. A
    # validator proved the leak - one caller stored a secret under `"   "` and
    # an unrelated caller sending the same blank read it straight back, with
    # the session persisting on disk as the base64 of `a2a:<role>:   `.
    #
    # This is the same defect the chat surface was fixed for one release
    # earlier, at the other door. `user_id` there is refused outright because
    # a present-but-blank field is unambiguous; here the field is optional by
    # protocol, so a blank is treated as ABSENT and gets a fresh context -
    # which is what the caller who sent nothing meaningful actually wants.
    _raw_ctx = (message.get("contextId")
                or (params.get("contextId") if isinstance(params, dict) else None))
    if not isinstance(_raw_ctx, str) or not _raw_ctx.strip():
        _raw_ctx = None
    ctx_id = ctx_id or _raw_ctx or f"ctx-{uuid4().hex[:12]}"
    task_id = task_id or f"task-{uuid4().hex[:12]}"
    session_key = f"a2a:{role}:{ctx_id}"

    agent = pool.get(role)
    result = await agent.process_direct(
        prompt,
        session_key=session_key,
        channel="a2a",
        chat_id=f"a2a:{role}",
        on_progress=_noop_cb,
        on_stream=_noop_cb,
    )
    response_text = result.content if hasattr(result, "content") else str(result)

    # A2A v1.0: structured output goes in a DataPart (member `data`), free
    # text in a TextPart. Agents emit a fenced JSON block (```json...```)
    # preceded by chain-of-thought text. Extract the JSON block separately so
    # the caller gets a parsed object, not a string. Arrays are wrapped as
    # {"results": [...]} because DataPart.data must be a dict (proto-exact).
    import json as _json
    import re as _re

    _fence = _re.search(r"```(?:json)?\s*\n([\s\S]*?)\n```", response_text)
    _cot_text = response_text  # default: full text is chain-of-thought

    if _fence:
        _json_str = _fence.group(1).strip()
        _cot_text = response_text[: _fence.start()].strip()
        try:
            _parsed = _json.loads(_json_str)
            if isinstance(_parsed, list):
                artifact_part = DataPart(data={"results": _parsed})
            elif isinstance(_parsed, dict):
                artifact_part = DataPart(data=_parsed)
            else:
                artifact_part = TextPart(text=_json_str)
        except (_json.JSONDecodeError, TypeError, ValueError):
            artifact_part = TextPart(text=_json_str)
    else:
        # No fenced block — try plain JSON parse
        try:
            _parsed = _json.loads(response_text)
            if isinstance(_parsed, list):
                artifact_part = DataPart(data={"results": _parsed})
                _cot_text = ""
            elif isinstance(_parsed, dict):
                artifact_part = DataPart(data=_parsed)
                _cot_text = ""
            else:
                artifact_part = TextPart(text=response_text)
        except (_json.JSONDecodeError, TypeError, ValueError):
            artifact_part = TextPart(text=response_text)

    # A CHAIN-OF-THOUGHT ARTIFACT THAT REPEATS THE ANSWER IS NOISE. The
    # default above treats the whole reply as reasoning, which is right
    # only when the answer itself was extracted from a fenced block: for a
    # plain-prose reply the response artifact IS that text, and a client
    # splitting the two received the answer twice (found by walking the
    # streaming guide, 2026-09-03).
    if _cot_text and isinstance(artifact_part, TextPart) and \
            _cot_text.strip() == (artifact_part.text or "").strip():
        _cot_text = ""

    _artifacts = [
        Artifact(
            artifactId=f"art-{uuid4().hex[:8]}",
            name="response",
            parts=[artifact_part],
        )
    ]
    if _cot_text:
        _artifacts.append(
            Artifact(
                artifactId=f"art-{uuid4().hex[:8]}",
                name="chain_of_thought",
                parts=[TextPart(text=_cot_text)],
            )
        )

    task = Task(
        id=task_id,
        contextId=ctx_id,
        status=TaskStatus(state="TASK_STATE_COMPLETED", timestamp=_now_iso()),
        artifacts=_artifacts,
        history=None,  # caller already has the request; we don't echo
    )
    task_dict = task.model_dump(exclude_none=True)
    _task_cache_put(role, task_id, task_dict)
    # A2A v1.0 SendMessage result is a OneOf wrapper — wrap the Task under `task`.
    return {"task": task_dict}


def _method_tasks_get(role: str, params: dict) -> dict:
    task_id = (params or {}).get("id")
    if not task_id:
        raise _A2AError(ERR_INVALID_PARAMS, "params.id is required")
    task = _task_cache_get(role, task_id)
    if not task:
        raise _A2AError(ERR_TASK_NOT_FOUND, f"task '{task_id}' not found")
    return task


def _method_tasks_cancel(role: str, params: dict) -> dict:
    task_id = (params or {}).get("id")
    if not task_id:
        raise _A2AError(ERR_INVALID_PARAMS, "params.id is required")
    task = _task_cache_get(role, task_id)
    if not task:
        raise _A2AError(ERR_TASK_NOT_FOUND, f"task '{task_id}' not found")
    # v1 is sync — by the time a caller could cancel, the task is already
    # completed. Spec says return TaskNotCancelableError for terminal states.
    state = (task.get("status") or {}).get("state")
    if state in {
        "TASK_STATE_COMPLETED",
        "TASK_STATE_CANCELED",
        "TASK_STATE_FAILED",
        "TASK_STATE_REJECTED",
    }:
        raise _A2AError(ERR_TASK_NOT_CANCELABLE, f"task in terminal state '{state}'")
    return task  # unreachable in sync v1, kept for forward-compat


# ---------------------------------------------------------------------------
# Internal error sentinel for JSON-RPC handlers
# ---------------------------------------------------------------------------


class _A2AError(Exception):
    def __init__(self, code: int, message: str, data: Any = None):
        self.code = code
        self.message = message
        self.data = data
        super().__init__(message)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------


def _enabled_roles(pool) -> list[str]:
    """Roles eligible for the A2A surface.

    Every always-on agent in the pool gets an A2A endpoint — the surface
    mirrors `IOF_ALWAYS_ON_AGENTS` exactly. Lazily-spawned roles are NOT
    exposed (they wouldn't be pre-warmed, defeating the always-on premise).

    A DESK-SIDE ROLE IS FILTERED HERE TOO, so it cannot be reached by name on
    the JSON-RPC surface even if something put it in the pool. The refusal
    lives at every door onto the pool, not at the one a validator happened to
    knock on.
    """
    from ioagentfarm.engine.always_on import is_desk_side
    return sorted(r for r in getattr(pool, "_agents", {}).keys()
                  if not is_desk_side(r))


def create_a2a_router() -> APIRouter:
    """Build the FastAPI router. Pool is read from `request.app.state` per call
    so lazily-added agents (post-startup) become discoverable automatically.
    """
    router = APIRouter(tags=["a2a"])

    @router.get("/a2a/agents")
    async def list_agents(request: Request) -> dict:
        pool = request.app.state.agent_pool
        return {"agents": _enabled_roles(pool)}

    @router.get("/a2a/{role}/.well-known/agent-card.json")
    async def agent_card(role: str, request: Request) -> JSONResponse:
        pool = request.app.state.agent_pool
        if role not in _enabled_roles(pool):
            raise HTTPException(status_code=404, detail=f"agent '{role}' not found")
        # Use the request's base_url so the card advertises the URL the
        # caller actually reached us at — works for localhost, K8s
        # service DNS, and ingress hostnames without config.
        # Honour X-Forwarded-Proto so TLS-terminating proxies produce https://.
        base = str(request.base_url).rstrip("/")
        forwarded_proto = request.headers.get("x-forwarded-proto")
        if forwarded_proto and base.startswith("http://") and forwarded_proto == "https":
            base = "https://" + base[len("http://"):]
        card = build_agent_card(role, base)
        return JSONResponse(card.model_dump(exclude_none=True))

    @router.post("/a2a/{role}")
    async def jsonrpc(role: str, request: Request) -> JSONResponse:
        pool = request.app.state.agent_pool
        try:   # an A2A caller's traceparent: this turn is a child of its span
            from ioagentfarm.engine import otel_export as _ex
            _ex.set_inbound_traceparent(request.headers.get("traceparent"))
        except Exception:  # noqa: BLE001
            pass

        # Parse envelope
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                _jsonrpc_error(None, ERR_INVALID_REQUEST, "request body is not valid JSON")
            )

        # Log the full inbound A2A request envelope (pretty-printed).
        req_method = body.get("method") if isinstance(body, dict) else None
        _log_a2a("REQUEST", role, req_method, body)

        def _respond(payload: dict) -> JSONResponse:
            """Log the full outbound A2A response envelope, then return it.

            Every response path funnels through here so the final JSON the
            caller receives (JSON-RPC wrapper + Task/error) is always logged.
            """
            _log_a2a("RESPONSE", role, req_method, payload)
            return JSONResponse(payload)

        try:
            rpc = JsonRpcRequest(**body)
        except Exception as exc:
            return _respond(_jsonrpc_error(body.get("id"), ERR_INVALID_REQUEST, str(exc)))

        if role not in _enabled_roles(pool):
            return _respond(
                _jsonrpc_error(rpc.id, ERR_METHOD_NOT_FOUND, f"agent '{role}' not found")
            )

        method = rpc.method
        params = rpc.params or {}

        try:
            # A2A v1.0 JSON-RPC methods are PascalCase (were path-style in v0.3).
            if method == "SendMessage":
                result = await _method_message_send(role, params, pool)
            elif method == "GetTask":
                result = _method_tasks_get(role, params)
            elif method == "CancelTask":
                result = _method_tasks_cancel(role, params)
            elif method == "SendStreamingMessage":
                # Returns a StreamingResponse, not a JSON body - so it leaves
                # here directly rather than through `_respond`, which logs and
                # wraps a dict. The frames are logged individually instead.
                return await _stream_message_send(
                    role, params, pool, rpc.id, request)
            elif method in {
                "SubscribeToTask",
                "SetTaskPushNotificationConfig",
                "GetTaskPushNotificationConfig",
                "ListTaskPushNotificationConfig",
                "DeleteTaskPushNotificationConfig",
            }:
                return _respond(
                    _jsonrpc_error(
                        rpc.id,
                        ERR_METHOD_NOT_FOUND,
                        f"method '{method}' not supported in v1.0 "
                        "(capabilities advertise pushNotifications=false)",
                    )
                )
            else:
                return _respond(
                    _jsonrpc_error(rpc.id, ERR_METHOD_NOT_FOUND, f"unknown method '{method}'")
                )
        except _A2AError as exc:
            return _respond(_jsonrpc_error(rpc.id, exc.code, exc.message, exc.data))
        except Exception as exc:
            logger.exception("A2A handler crashed: role={} method={}", role, method)
            return _respond(
                _jsonrpc_error(rpc.id, ERR_INTERNAL, f"{type(exc).__name__}: {exc}")
            )

        return _respond(_jsonrpc_result(rpc.id, result))

    return router


def a2a_enabled() -> bool:
    """Env toggle for the whole A2A surface — default ON."""
    return os.environ.get("IOF_A2A_ENABLED", "true").strip().lower() not in {
        "0", "false", "no", "off",
    }
