"""``POST /api/route`` - the deterministic capability router over HTTP.

An application that wants to know WHICH agent to send a request to, before
paying for a turn, asks here. The answer is `engine/router.py`'s: lexical,
explained per term, and never a guess - ``chosen`` is null when no declared
scope matches, with the reason spelled out. No model is called.

Mounted at module level like the catalog router: it needs nothing the
lifespan builds. The workspace is the one this engine serves
(``app.state.workspace_code`` once `serve` set it, else the environment's
selection); with none selected the local cards are still read from their
bundled packs and only the external registry is skipped.
"""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field

router = APIRouter(tags=["route"])


class RouteRequest(BaseModel):
    query: str = Field(..., min_length=1, description="The request to route.")
    top: int = Field(3, ge=1, le=50, description="How many candidates to return.")
    min_score: int = Field(1, ge=0, description="Below this the result chooses nobody.")
    include_external: bool = Field(True, description="Score the workspace's external A2A agents too.")


def _workspace(request: Request) -> Optional[str]:
    ws = getattr(request.app.state, "workspace_code", None)
    if ws:
        return str(ws)
    try:
        from ioagentfarm.engine.workspaces import maybe_workspace_code
        return maybe_workspace_code()
    except Exception:  # noqa: BLE001 - a listing surface, never a traceback
        return None


@router.post("/api/route")
async def route_query(body: RouteRequest, request: Request) -> dict:
    """Rank the routable agents for a query; choose the best if it clears
    ``min_score``. Deterministic, explained, no model call."""
    from ioagentfarm.engine.router import route
    result = route(body.query, _workspace(request), top=body.top,
                   min_score=body.min_score, include_external=body.include_external)
    out = result.to_dict()
    out["workspace"] = _workspace(request)
    return out
