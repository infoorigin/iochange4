"""Shared session storage for the always-on chat surface.

WHY THIS EXISTS. `POST /api/chat/{ns}` writes its conversation to a JSONL
file on the pod's local disk and nothing ever uploaded it. Every session sync
in the engine - three in `send_message`, one at step completion - is on the
RUN path; the always-on chat endpoint appeared in none of them. So two pods
serving one workspace each kept their own copy of a conversation and neither
ever read the other's.

A concurrency validator reproduced the consequence in three turns on one
`user_id`:

    turn A, pod 1: "Fact one: the code is ALPHA111"   -> acknowledged
    turn B, pod 2: "Fact two: the code is BETA222"    -> acknowledged
    turn C, pod 1: "List every code I have given you"
                -> "1. ALPHA111 - That's the only code provided so far."

Turn B was not merely unseen: pod 1 answered from its stale in-memory session
and then **overwrote the file**, destroying the record. Confidently wrong, and
the evidence gone. Two engines on one workspace is the documented
horizontal-scaling posture, so this is the default production shape.

WHAT THIS DOES, AND THE PART IT DOES NOT DO.

Before a turn: pull the session from shared storage, then INVALIDATE the
in-memory copy so the runtime actually re-reads it. After a turn: push it
back.

The invalidation is the load-bearing half. `SessionManager` caches `Session`
objects (`_cache` plus an overflow `WeakValueDictionary`), so a warm pod
never re-reads the file - pulling without invalidating downloads a file the
pod then ignores and overwrites. The first version of several fixes in this
codebase reached one layer and left the layer above holding the old state;
this one says so out loud.

**It does not make two simultaneous turns safe.** Two turns on one session
landing on two pods inside the same second still race - pull, pull, append,
append, last writer wins. This shrinks the window from *every turn on the
other pod* to *two turns in the same second*. Closing it needs a conditional
put (an S3 ETag precondition) or a per-session lock, which is a larger
change; until then the honest claim is "safe for ordinary pod scaling", not
"serialised".

Inert without shared storage: `IOF_STORAGE=none` (the default) makes every
function here a no-op, so a single-pod deployment pays nothing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from loguru import logger

#: A chat has no run, and the storage layout's first segment is a PATH
#: segment rather than a foreign key - so the WORKSPACE goes there. Two
#: workspaces can hold the same session key
#: (`web:chat:general:cora:u:alice`), and putting a constant here instead
#: would have collided them into one conversation across tenants, which is a
#: worse bug than the one being fixed.
def _slot(workspace_code: str) -> str:
    return f"chat-sessions/{(workspace_code or 'unknown').strip()}"


def _storage():
    """The configured backend, or ``None`` when storage is off."""
    try:
        from ioagentfarm.web.storage import get_storage
        stor = get_storage()
    except Exception:  # noqa: BLE001 - never break a turn over telemetry
        return None
    # NoopStorage is what `IOF_STORAGE=none` yields; it has the methods but
    # does nothing, and calling it would spend a code path for no reason.
    if stor is None or type(stor).__name__.lower().startswith("noop"):
        return None
    return stor


def session_file(workspace_path: Path, session_key: str) -> Path:
    """Where the runtime keeps this conversation on local disk."""
    return (Path(workspace_path) / "sessions"
            / f"{session_key.replace(':', '_')}.jsonl")


def pull_before_turn(workspace_path: Path, workspace_code: str,
                     session_key: str, agent: Any) -> bool:
    """Fetch the shared copy and drop the cached one. Returns True if pulled.

    UNCONDITIONAL, not "if the file is missing". The existing run-path pull
    is `if not chat_file.exists()`, which recovers a cold pod and does
    nothing for a warm one - and a warm pod is the case that loses data.
    """
    stor = _storage()
    if stor is None or not session_key:
        return False
    local = session_file(workspace_path, session_key)
    pulled = False
    try:
        pulled = bool(stor.pull_file(
            _slot(workspace_code), local.name, local, sub_prefix="sessions"))
    except Exception:  # noqa: BLE001 - a missing object is normal
        logger.debug("chat session pull failed for {}", session_key,
                     exc_info=True)
        return False

    # THE HALF THAT MAKES THE PULL MEAN ANYTHING. Without it the runtime
    # answers from `_cache` and then overwrites the file just downloaded.
    if pulled:
        _invalidate(agent, session_key)
    return pulled


def push_after_turn(workspace_path: Path, workspace_code: str,
                    session_key: str) -> None:
    """Upload the conversation as it now stands. Never raises."""
    stor = _storage()
    if stor is None or not session_key:
        return
    local = session_file(workspace_path, session_key)
    if not local.is_file():
        return
    try:
        stor.push_file(_slot(workspace_code), local, sub_prefix="sessions")
    except Exception:  # noqa: BLE001 - a turn already answered must not fail
        logger.debug("chat session push failed for {}", session_key,
                     exc_info=True)


def _invalidate(agent: Any, session_key: str) -> None:
    """Drop the runtime's cached Session so the file is read again.

    `SessionManager.invalidate` exists upstream and nothing in this codebase
    called it, which is exactly why a warm pod never noticed another pod's
    writes. Reached defensively: the attribute path is the runtime's, and a
    version that moved it must degrade to "no sharing" rather than to a
    broken turn.
    """
    for attr in ("session_manager", "sessions", "_session_manager"):
        mgr = getattr(agent, attr, None)
        invalidate = getattr(mgr, "invalidate", None)
        if callable(invalidate):
            try:
                invalidate(session_key)
                return
            except Exception:  # noqa: BLE001
                logger.debug("session invalidate failed", exc_info=True)
                return
    logger.debug("no session manager on the agent; cached session kept")
