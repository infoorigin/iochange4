"""POST /api/catalog/drafts/validate — lint a draft against the RUNNING base.

Owns exactly one thing: materialising "installed pack (+) this overlay" into
a throwaway directory and returning the workflow linter's findings as JSON.
The Studio's Save path calls this instead of its old ``_materialize_override``
+ ``_dry_run`` pair, because only THIS engine knows which pack bytes the
draft would actually run against — the API pod has no filesystem and no
packs, so any validation it did locally would be against nothing.

Stateless by design: the caller sends the overlay in the request and nothing
is read from or written to the ``content_drafts`` table — a validation must
be possible BEFORE the first Save, and a failed one must leave no record.

Must not import: the Studio API's ``app.*`` modules (this is the engine
side of the seam), and ``engine.drafts``' SQL verbs (statelessness above).
The workspace 409/503 handshake and the loud-failure discipline are reused
from :mod:`ioagentfarm.web.catalog` rather than copied, so the two routers
cannot drift on either.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from ioagentfarm.web.catalog import _NAME_RE, _loud, workspace_for

router = APIRouter(prefix="/api/catalog/drafts", tags=["catalog"])

#: Only workflows have a linter today. agent/skill drafts are validated at
#: save time by ``normalise_files`` alone; refusing the kind HERE (rather
#: than answering "ok") keeps "validated" meaning "the linter ran".
VALIDATABLE_KINDS = ("workflow",)


class DraftValidateRequest(BaseModel):
    kind: str
    name: str
    #: Overlay map ``{rel_path: text | null}`` — null deletes from the base.
    files: dict[str, str | None] = {}


@router.post("/validate")
@_loud
async def validate_draft(req: DraftValidateRequest, request: Request):
    """Findings for base (+) overlay, exactly as a draft run would load it."""
    ws = workspace_for(request)
    if req.kind not in VALIDATABLE_KINDS:
        raise HTTPException(
            status_code=400,
            detail=(f"only {', '.join(VALIDATABLE_KINDS)} drafts can be "
                    f"validated, got kind={req.kind!r}"))
    if not _NAME_RE.match(req.name):
        raise HTTPException(status_code=400, detail="bad workflow name")

    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    from ioagentfarm.engine.workflow_lint import lint_workflow_dir

    loader = WorkflowLoader()
    base = loader._workflow_dir(req.name)

    with tempfile.TemporaryDirectory(prefix="iof-draft-validate-") as td:
        # The workflow dir is NAMED after the workflow (a subdir of the temp
        # root, never the random temp name itself): the linter checks `name:`
        # against the directory name, and a random temp name would fail every
        # draft with an error about a directory that does not exist for the
        # author.
        target = Path(td) / req.name
        target.mkdir()
        if base is not None:
            loader._copy_traversable(base, target)
        from ioagentfarm.engine.draft_files import apply_overlay
        try:
            apply_overlay(target, req.files)
        except ValueError as exc:
            # A malformed overlay (path escape, non-text body) is the
            # caller's mistake, not a server fault - name it as a 400 so the
            # Studio shows the message instead of a generic failure toast.
            raise HTTPException(status_code=400, detail=str(exc))
        result = lint_workflow_dir(target)

    return {
        "workspace": ws,
        "kind": req.kind,
        "name": req.name,
        "base": "pack" if base is not None else "new-item",
        "ok": result.ok,
        "errors": len(result.errors),
        "warnings": len(result.warnings),
        "findings": [{
            "severity": f.severity,
            "where": f.where,
            "message": f.message,
            "fix": f.fix,
            "line": f.line,
        } for f in result.findings],
    }
