"""FastAPI router for document ingestion via HTTP upload.

Provides POST /api/ingest/documents — triggers the doc_ingestion workflow
for uploaded contract documents (PDF/DOCX).
"""

from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class IngestRequest(BaseModel):
    schema: str = "contract_master"
    doc_type: str = "auto"


def create_ingest_router() -> APIRouter:
    router = APIRouter(prefix="/api/ingest", tags=["ingest"])

    @router.post("/documents")
    async def ingest_documents(
        files: list[UploadFile],
        schema: str = "contract_master",
        doc_type: str = "auto",
    ) -> JSONResponse:
        """Upload contract documents (PDF/DOCX) for ingestion.

        Saves uploaded files to a temp directory and triggers the doc_ingestion
        workflow asynchronously. Returns a run ID for status polling.
        """
        if not files:
            raise HTTPException(status_code=400, detail="No files uploaded")

        # Validate file types
        allowed_extensions = {".pdf", ".docx", ".txt"}
        for f in files:
            ext = Path(f.filename or "").suffix.lower()
            if ext not in allowed_extensions:
                raise HTTPException(
                    status_code=400,
                    detail=f"Unsupported file type: {f.filename}. Allowed: {', '.join(allowed_extensions)}",
                )

        # Save files to temp directory
        tmp_dir = Path(tempfile.mkdtemp(prefix="iof_ingest_"))
        saved = []
        try:
            for upload in files:
                dest = tmp_dir / (upload.filename or "document")
                content = await upload.read()
                dest.write_bytes(content)
                saved.append(str(dest))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to save uploaded files: {e}")

        # Trigger doc_ingestion workflow asynchronously
        try:
            from ioagentfarm.cli import _run_workflow_async
            run_id = await _run_workflow_async(
                workflow="doc_ingestion",
                vars={"docs_dir": str(tmp_dir), "schema": schema, "doc_type": doc_type},
            )
        except Exception:
            # Fallback: trigger via CLI subprocess (non-blocking)
            import subprocess
            import uuid
            run_id = str(uuid.uuid4())[:8]
            cmd = [
                "ioagentfarm", "run", "doc_ingestion",
                "--vars", f'{{"docs_dir": "{tmp_dir}", "schema": "{schema}", "doc_type": "{doc_type}"}}',
                "--json",
            ]
            subprocess.Popen(cmd, env=os.environ.copy())

        return JSONResponse({
            "success": True,
            "run_id": run_id,
            "files_uploaded": len(saved),
            "docs_dir": str(tmp_dir),
            "schema": schema,
            "doc_type": doc_type,
            "message": "Ingestion started. Poll GET /api/run/{run_id}/status for progress.",
        })

    @router.get("/status/{run_id}")
    async def ingest_status(run_id: str) -> JSONResponse:
        """Get status of a document ingestion run."""
        try:
            from ioagentfarm.engine.store import Store
            store = Store()
            run = store.get_run(run_id)
            if run is None:
                raise HTTPException(status_code=404, detail=f"Run {run_id} not found")
            return JSONResponse({
                "run_id": run_id,
                "status": run.status,
                "workflow": run.workflow,
            })
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    return router
