"""Spawn workflow runs and ad-hoc tasks via the pluggable runner backend.

Builds the iobot command + environment, then delegates to the configured
RunnerBackend (local subprocess or K8s Job).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from loguru import logger

from ioagentfarm.web.runner import get_runner


def _ensure_sandbox_for_workflow(workflow_name: str) -> None:
    """Ensure a sandbox exists for the given workflow.

    If the SandboxManager is initialized (web API mode), creates the sandbox
    on demand using the workflow's sandbox config.  If the manager is not
    initialized (CLI mode), this is a no-op — sandbox_wrap_cmd handles it.
    """
    from ioagentfarm.engine.sandbox_manager import get_sandbox_manager
    mgr = get_sandbox_manager()
    if not mgr:
        return  # CLI mode or manager not initialized

    # Check if already mapped
    if mgr.resolve_sandbox_name(workflow_name):
        return

    # Load workflow to get sandbox config
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    try:
        wf = WorkflowLoader().load(workflow_name)
        if wf.sandbox:
            mgr.get_or_create(workflow_name, wf.sandbox)
    except Exception as exc:
        logger.warning("Failed to create sandbox for workflow '{}': {}", workflow_name, exc)


def _iobot_bin() -> str:
    """Resolve the runtime binary. See engine/runtime_bin.py.

    This is the Studio/UI run path, so a miss here is invisible until someone
    starts a run from the browser — which is why it shares one implementation
    with the CLI rather than keeping its own copy.
    """
    from ioagentfarm.engine.runtime_bin import runtime_bin
    return runtime_bin()


def _base_env(root_path: Path) -> dict[str, str]:
    """Build a clean environment for subprocesses."""
    env = os.environ.copy()
    env["IOF_ROOT"] = str(root_path)
    env.setdefault("PYTHONIOENCODING", "utf-8")
    venv_bin = str(Path(sys.executable).parent)
    env["PATH"] = venv_bin + os.pathsep + env.get("PATH", "")
    return env


def driver_cmd(driver: str, *, run_id: str, user_id: str, root_path,
               agent_cmd: list) -> list:
    """The process that drives *run_id*: project_lead (the agent driver) or
    the code driver's own loop. One place, so --json, resume and the
    supervisor cannot disagree with the blocking `run` about who drives."""
    if (driver or "agent").strip().lower() == "code":
        return [sys.executable, "-m", "ioagentfarm.cli", "_drive",
                "--run-id", run_id, "--user-id", user_id, "--root", str(root_path)]
    return agent_cmd


def _run_driver(root_path, run_id: str, explicit: str | None) -> str:
    """The run row's driver, unless the caller said. Read from the row so a
    resumed or resurrected run keeps the driver it was started with."""
    if explicit:
        return explicit
    try:
        from ioagentfarm.cli import _store
        return str((_store(root_path).get_run(run_id) or {}).get("driver") or "agent")
    except Exception:  # noqa: BLE001
        return "agent"


def spawn_run(
    *,
    run_id: str,
    driver: str | None = None,
    workflow: str,
    goal: str,
    project_dir: str,
    user_id: str,
    root_path: Path,
    workspace: str,
    detach: bool = False,
) -> None:
    """Build the iobot command and delegate to the runner backend.

    The run has already been created and steps materialized by the API.
    This starts the project_lead driving the pipeline via the configured backend
    (local subprocess or K8s Job).

    *workspace* is the tenant workspace code and is REQUIRED — every run
    executes in an isolated agent home under
    ``<IOF_ROOT>/workspaces/<code>/agents``, resolved explicitly here (NOT
    via process-global env: the web server handles concurrent requests for
    different tenants) and propagated to the driver subprocess via
    ``IOF_WORKSPACE``/``IOF_AGENT_HOME`` env. The parameter used to default
    to ``"default"`` with a machine-global roster; that is how a resumed or
    supervisor-resurrected tenant run silently changed tenant mid-run.

    When *detach* is True (CLI usage), stdout is redirected directly to the log
    file and no daemon thread is started.  The subprocess outlives the parent.
    When False (web server, default), stdout is piped and a daemon thread
    tails it into both the log file and the messages table for SSE streaming.
    """
    from ioagentfarm.engine.workspaces import (
        RETIRED_WORKSPACE_CODES, ensure_agent_workspace,
    )
    from ioagentfarm.engine.iobot_config import create_instance_config, get_run_output_dir

    workspace = (workspace or "").strip()
    if not workspace or workspace in RETIRED_WORKSPACE_CODES:
        raise ValueError(
            f"spawn_run requires a workspace (got {workspace!r}): a run "
            "always executes in a named workspace's agent home")

    agent_home = root_path / "workspaces" / workspace / "agents"

    # The tenant's roster, not the machine's — same resolution the CLI and
    # the importer use. Seeding every installed agent into a tenant home
    # recorded each one's shared-skill assignment against THIS workspace,
    # so a tenant's `studio_skills` rows filled up with other solutions'
    # agents every time a run started here.
    from ioagentfarm.workspace_sync import workspace_agent_roles
    roster = workspace_agent_roles(workspace)
    # Only the roles THIS run can use. Seeding the whole roster rewrote every
    # agent's identity files on every launch - the platform assistants
    # included - which is what two concurrent launches raced on.
    try:
        import yaml as _yaml
        _wf_yaml = root_path / "instances" / run_id / "workflow" / "workflow.yaml"
        _wf = _yaml.safe_load(_wf_yaml.read_text(encoding="utf-8")) or {}
        _used = {str(r.get("name")) for r in (_wf.get("roles") or []) if isinstance(r, dict)}
        _used |= {str(t.get("role")) for s_ in (_wf.get("steps") or []) if isinstance(s_, dict)
                  for t in (s_.get("per_item_steps") or []) if isinstance(t, dict)}
        _used.add("project_lead")
        if _used & set(roster):
            roster = [r for r in roster if r in _used]
    except Exception:  # noqa: BLE001 - no snapshot: seed as before
        pass

    for role in roster:
        try:
            # Tenant home: solution roles hydrate from THIS tenant's DB
            # content, platform-shared roles from the platform tier (handled
            # inside ensure_agent_workspace) so one Core Assistant identity
            # reaches every tenant while memory/ stays per tenant.
            ensure_agent_workspace(role, agent_home / role / "workspace",
                                   workspace_code=workspace)
        except FileNotFoundError:
            # Role exists only as a tenant workspace dir (imported solution
            # agent with no pack template) — already materialized by import.
            continue

    lead_ws = agent_home / "project_lead" / "workspace"
    instance_config = create_instance_config(root_path, run_id, project_dir)

    # Run-scoped output directory — agents write artifacts here
    run_output_dir = get_run_output_dir(root_path, run_id)
    run_output_dir.mkdir(parents=True, exist_ok=True)

    task_msg = (
        f"IMPORTANT: A run has already been created for you. Do NOT create another run.\n\n"
        f"Run ID: {run_id}\n"
        f"Workflow: {workflow}\n"
        f"Goal: {goal}\n"
        f"Source directory: {project_dir}\n"
        f"Output directory: {run_output_dir}\n"
        f"User ID: {user_id}\n\n"
        f"Drive this run to completion by looping:\n"
        f"1. `ioagentfarm next-step --run-id {run_id} --user-id {user_id}` — get next step\n"
        f"2. If role=project_lead, execute inline:\n"
        f"   a. Write your output to a file using an ABSOLUTE path (e.g. /tmp/iof_output.txt). Must contain STATUS: done/failed and OUTPUT: <detailed result>\n"
        f"   b. `ioagentfarm step-complete --step-key <key> --run-id {run_id} --output-file /tmp/iof_output.txt --user-id {user_id}`\n"
        f"3. If role=anything else: `ioagentfarm run-step --step-key <key> --run-id {run_id} --user-id {user_id}`\n"
        f"4. Repeat until next-step returns done=true.\n"
        f"\nIMPORTANT: Do NOT create or modify project files. You are the project lead — you plan and delegate, never implement.\n"
    )

    # Fresh orchestrate session per spawn (stateless-driver principle: ALL
    # run state lives in the DB; the driver transcript adds nothing
    # `next-step` doesn't already say). Chaos-observed failure without this:
    # a resurrected driver resumed the PREVIOUS driver's orchestrate session
    # and died instantly on a provider 400 caused by that transcript's
    # malformed tool-call history — and every subsequent resume inherited
    # the same poisoned session until the resume budget ran out. A unique
    # suffix per spawn makes every driver (initial, /resume, supervisor
    # resurrection) start clean.
    from datetime import datetime, timezone
    _spawn_tag = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    session_key = f"iof:{run_id}:orchestrate:u:{user_id}:s{_spawn_tag}"

    cmd = driver_cmd(
        _run_driver(root_path, run_id, driver), run_id=run_id, user_id=user_id,
        root_path=root_path,
        agent_cmd=[_iobot_bin(), "agent",
                   "--message", task_msg,
                   "--session", session_key,
                   "--workspace", str(lead_ws),
                   "--config", str(instance_config)])

    # Sandbox: ensure sandbox exists for this workflow, then wrap the command
    from ioagentfarm.engine.sandbox import sandbox_wrap_cmd, should_sandbox, make_sandbox_env
    if should_sandbox():
        _ensure_sandbox_for_workflow(workflow)
    cmd = sandbox_wrap_cmd(cmd, workflow_name=workflow)

    env = _base_env(root_path)
    env["IOBOT_WORKSPACE"] = str(lead_ws)
    # Tenant workspace propagation: the driver and every nested subprocess
    # (run-step -> iobot agent) resolve their agent home from these.
    # Always a real code — the guard above refused anything else, so a
    # downstream reader can no longer mistake a fallback for a selection.
    env["IOF_WORKSPACE"] = workspace
    env["IOF_AGENT_HOME"] = str(agent_home)

    # Patch shim for the DRIVER process — parity with _invoke_agent's step
    # spawns. Without it the driver runs STOCK iobot: no disable-streaming,
    # no request timeout, and critically no Azure chat-backend swap — on a
    # classic-route Azure tenant the driver's FIRST LLM call 401s ('missing
    # subscription key': stock provider takes the v1 Responses route with
    # the key unused) while CLI runs, which inject the shim, work. Steps
    # were never affected (run-step re-injects); only the driver was naked.
    # Found live at a client deployment.
    try:
        from ioagentfarm._iobot_patches import write_sitecustomize
        _inject_dir = root_path / "instances" / run_id / "_iof_logging_inject"
        write_sitecustomize(_inject_dir)
        env["PYTHONPATH"] = str(_inject_dir) + os.pathsep + env.get("PYTHONPATH", "")
        # Driver token capture rides the same shim (the usage hook registers
        # on ioagentfarm import) — one JSONL line per driver LLM call.
        env.setdefault("IOF_USAGE_FILE",
                       str(root_path / "instances" / run_id / "usage.jsonl"))
    except Exception as exc:
        # RUNNING UNPATCHED IS NOT A DEGRADED MODE, IT IS A DIFFERENT PRODUCT.
        # This shim is the only thing that applies the runtime patches inside
        # the spawned process: the provider swaps, `dedup_tool_call_ids`,
        # `disable_streaming`, and two RESTRICTIONS - `restrict_agency_tools`
        # and the `_FsTool` allowed-dirs fix. Without it an Azure or GenAI
        # deployment talks to the wrong provider class, and the agent's
        # containment is silently gone.
        #
        # It used to warn and carry on, and the command still exited 0 saying
        # "fresh driver spawned". A validator raced two spawns for one run on
        # Windows, hit `PermissionError` on the shim's own file, and was told
        # the run had been recovered - with both restrictions absent. A
        # security control that reports success when it did not apply is
        # worse than one that is missing.
        #
        # Retried once, because the observed cause is an exclusive-open race
        # between two spawns and not a broken environment; then refused.
        try:
            import time as _t
            _t.sleep(0.25)
            from ioagentfarm._iobot_patches import write_sitecustomize
            _inject_dir = root_path / "instances" / run_id / "_iof_logging_inject"
            write_sitecustomize(_inject_dir)
            env["PYTHONPATH"] = (str(_inject_dir) + os.pathsep
                                 + env.get("PYTHONPATH", ""))
            env.setdefault("IOF_USAGE_FILE",
                           str(root_path / "instances" / run_id / "usage.jsonl"))
            logger.warning("driver patch-shim injection succeeded on retry")
        except Exception:
            logger.opt(exception=True).error(
                "driver patch-shim injection failed twice; REFUSING to spawn "
                "an unpatched driver - it would run without the provider "
                "swaps and without `restrict_agency_tools` and the "
                "filesystem allow-list")
            raise RuntimeError(
                "cannot start the run: the runtime patch shim could not be "
                f"written ({type(exc).__name__}: {exc}). A driver without it "
                "runs with the wrong provider and without two security "
                "restrictions, so the run is refused rather than started "
                "unprotected. If another process is spawning the same run, "
                "retry; otherwise check permissions on "
                f"{root_path / 'instances' / run_id}."
            ) from exc
    # If sandbox mode, filter env and set anti-spoof token
    if should_sandbox():
        env = make_sandbox_env(env)

    log_dir = root_path / "instances" / run_id / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    log_file = log_dir / "run_stdout.log"
    pid_file = log_dir / "run.pid"

    # Stderr goes to a separate log file so subprocess crashes (Python
    # tracebacks, import errors, env-stripping issues) are visible post-mortem.
    # Previously redirected to DEVNULL which masked silent crashes.
    stderr_log = log_dir / "run_stderr.log"
    # APPEND, NEVER TRUNCATE. `explain` cites `run_stdout.log` as the only
    # surviving record of a driver killed mid-attempt, and prints that
    # citation directly above `aicore resume` - so following the product's
    # own advice destroyed the evidence it had just named: 9,964 bytes at
    # 18:58:57, 0 bytes at 18:58:58 (certification round 5). A resumed run is
    # a continuation of the same run, so its console is a continuation too.
    stderr_fh = open(stderr_log, "a", encoding="utf-8")

    if detach:
        # CLI mode: redirect stdout to log file directly.  The subprocess
        # outlives the parent — no daemon thread needed.
        log_fh = open(log_file, "a", encoding="utf-8")
        if sys.platform == "win32":
            proc = subprocess.Popen(
                cmd, env=env, cwd=str(run_output_dir),
                stdout=log_fh, stderr=stderr_fh,
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
            )
        else:
            proc = subprocess.Popen(
                cmd, env=env, cwd=str(run_output_dir),
                stdout=log_fh, stderr=stderr_fh,
                start_new_session=True,
            )
        pid_file.write_text(str(proc.pid), encoding="utf-8")
        logger.info("spawn_run (detached): run_id={} pid={}", run_id, proc.pid)
    else:
        # Web server mode. THE DRIVER WRITES TO THE FILE, NOT TO A PIPE INTO
        # THIS PROCESS. It used to write to a pipe that a daemon thread here
        # copied into the log file - so the driver depended on the engine
        # process for every line it printed: when the engine restarted the
        # pipe closed and the driver died on its next print, and when the
        # thread died first (its store setup raised) the pipe filled and the
        # driver blocked forever on a write, silent, heartbeat and all. The
        # SSE tail reads the file, so nothing here needed the pipe.
        import threading

        log_fh = open(log_file, "a", encoding="utf-8")
        if sys.platform == "win32":
            proc = subprocess.Popen(
                cmd, env=env, cwd=str(run_output_dir),
                stdout=log_fh, stderr=stderr_fh,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
        else:
            proc = subprocess.Popen(
                cmd, env=env, cwd=str(run_output_dir),
                stdout=log_fh, stderr=stderr_fh,
                start_new_session=True,
            )
        log_fh.close()

        pid_file.write_text(str(proc.pid), encoding="utf-8")
        logger.info("spawn_run: run_id={} pid={}", run_id, proc.pid)

        def _tail_and_persist():
            """Daemon thread: waits for the driver and records a refusal."""
            # Orchestrator exited — check if it refused the goal or crashed
            # before delegating any steps.
            proc.wait()
            try:
                from ioagentfarm.engine.store import Store
                from ioagentfarm.engine.db import make_adapter

                db_url = os.environ.get("IOF_DATABASE_URL", "")
                if not db_url:
                    db_url = f"sqlite:///{root_path / 'state.db'}"
                store = Store(make_adapter(db_url))
                store.init()
                steps = store.list_steps(run_id)
                all_pending = all(s["status"] == "pending" for s in steps)
                if all_pending and steps:
                    # Alex didn't delegate a single step — goal was refused or crashed
                    try:
                        output = log_file.read_text(encoding="utf-8", errors="replace").strip()
                    except OSError:
                        output = ""
                    reason = output[-500:] if output else "Orchestrator exited without delegating any steps"
                    store.insert_message(
                        run_id=run_id,
                        source="system",
                        role="project_lead",
                        agent_name="Alex",
                        content=f"Run refused: {reason}",
                        msg_type="message",
                    )
                    with store._tx() as cursor:
                        cursor.execute(
                            store._q("UPDATE runs SET status='failed', updated_at=? WHERE id=?"),
                            (store._now(), run_id),
                        )
                    logger.info("Run %s failed: orchestrator refused/crashed without delegating", run_id)
            except Exception:
                logger.debug("Post-exit check failed for run %s", run_id, exc_info=True)

        thread = threading.Thread(target=_tail_and_persist, daemon=True)
        thread.start()


def spawn_task(
    *,
    run_id: str,
    role: str,
    goal: str,
    user_id: str,
    root_path: Path,
) -> str:
    """Spawn an ad-hoc agent task within the context of an existing run.

    Launches ``ioagentfarm run-task`` as a background subprocess.  The CLI
    handles task creation, run-context enrichment, agent invocation, and
    output capture internally.

    Sandbox: resolves the workflow from the run's DB record so ad-hoc tasks
    inherit the same sandbox isolation as the parent workflow.

    Returns the task_id (pre-generated) immediately.
    """
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.store import Store
    db_url = os.environ.get("IOF_DATABASE_URL", f"sqlite:///{root_path / 'state.db'}")
    store = Store(make_adapter(db_url))
    store.init()

    # A task inside a run executes in the RUN'S workspace, read back from
    # its row — never from ambient resolution, which could name a different
    # tenant than the run this task claims to belong to.
    from ioagentfarm.engine.workspaces import (
        RETIRED_WORKSPACE_CODES, ensure_agent_workspace,
    )
    task_ws = None
    run_row = store.get_run(run_id)
    ws_id = (run_row or {}).get("workspace_id")
    if ws_id:
        try:
            ws_row = store.get_workspace_by_id(ws_id)
            code = (ws_row or {}).get("code", "").strip()
            if code and code not in RETIRED_WORKSPACE_CODES:
                task_ws = code
        except Exception:
            task_ws = None
    if not task_ws:
        raise ValueError(
            f"run {run_id} is not attributed to a workspace; an ad-hoc "
            "task cannot run without one")
    task_agent_home = root_path / "workspaces" / task_ws / "agents"
    ensure_agent_workspace(role, task_agent_home / role / "workspace",
                           workspace_code=task_ws)

    # Create task in DB BEFORE spawning so we have the real task_id.
    # Pass --task-id to the child so it reuses this task (no duplicate).
    task_id = store.create_task(role=role, title=goal[:80], body=goal, run_id=run_id, user_id=user_id)
    store.mark_task_spawned(task_id)

    # Resolve run's output dir for cwd
    from ioagentfarm.engine.iobot_config import get_run_output_dir
    run_output_dir = get_run_output_dir(root_path, run_id)
    run_output_dir.mkdir(parents=True, exist_ok=True)

    # Use the ioagentfarm binary (not python -m)
    venv_bin = Path(sys.executable).parent
    suffix = ".exe" if sys.platform == "win32" else ""
    iof_bin = str(venv_bin / f"ioagentfarm{suffix}")

    cmd = [
        iof_bin, "run-task",
        "--role", role,
        "--goal", goal,
        "--run-id", run_id,
        "--user-id", user_id,
        "--task-id", task_id,
    ]

    # Workflow name for sandbox isolation — from the run row already loaded.
    workflow_name = (run_row or {}).get("workflow_name")

    # Sandbox: wrap command with sandbox exec if IOF_RUNNER=sandbox
    from ioagentfarm.engine.sandbox import sandbox_wrap_cmd, should_sandbox, make_sandbox_env
    if should_sandbox() and workflow_name:
        _ensure_sandbox_for_workflow(workflow_name)
    cmd = sandbox_wrap_cmd(cmd, workflow_name=workflow_name)

    env = _base_env(root_path)
    env["PYTHONUNBUFFERED"] = "1"
    # The child (run-task -> iobot agent) resolves its agent home from
    # these — the run's workspace, established above.
    env["IOF_WORKSPACE"] = task_ws
    env["IOF_AGENT_HOME"] = str(task_agent_home)
    env["FORCE_COLOR"] = "0"
    env["TERM"] = "dumb"

    # If sandbox mode, filter env and set anti-spoof token
    if should_sandbox():
        env = make_sandbox_env(env)

    # Per-task log dir to avoid collisions with the run's logs
    task_log_dir = root_path / "instances" / run_id / "task_logs" / task_id
    task_log_dir.mkdir(parents=True, exist_ok=True)

    runner = get_runner()
    runner.spawn(
        run_id=f"task:{task_id}",
        cmd=cmd,
        env=env,
        cwd=str(run_output_dir),
        log_dir=task_log_dir,
        workflow_name=workflow_name,
    )

    logger.info("spawn_task: task_id={} role={} run_id={} workflow={} log_dir={}",
                task_id, role, run_id, workflow_name, task_log_dir)
    return task_id
