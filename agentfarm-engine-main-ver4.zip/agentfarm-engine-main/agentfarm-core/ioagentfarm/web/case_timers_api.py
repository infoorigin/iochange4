"""The monitoring listener — one authenticated intake for timer events.

Every emitter reaches the case tier through the same apply path: the
scheduler the platform ships (in process, over the same database), a
client's own monitoring estate (over this route), or a person at a
terminal. The guarantees cannot differ by caller because there is only
one implementation.

AUTHENTICATION IS REQUIRED AND FAIL-CLOSED. The engine's own API carries
no authentication, so a timer route mounted there without a check would
let anything on the network advance any case. This router refuses every
request unless ``IOF_TIMER_TOKEN`` is set and presented; the route is not
mounted at all when the variable is absent, so an unconfigured deployment
exposes nothing rather than exposing an open door.

The response is the ACKNOWLEDGEMENT CONTRACT: exactly one outcome is
retryable. A caller that retries any other hammers a case that is
behaving correctly.
"""
from __future__ import annotations

import hmac
import logging
import os

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

#: Outcomes the caller must treat as settled work.
_SETTLED = ("fired", "suppressed", "fenced", "unmatched", "skipped")


def timer_token() -> str:
    return (os.environ.get("IOF_TIMER_TOKEN") or "").strip()


def listener_enabled() -> bool:
    """The route mounts only when a token is configured. An unconfigured
    deployment must expose nothing, not an unauthenticated endpoint."""
    return bool(timer_token())


class TimerEvent(BaseModel):
    case_id: str = Field(..., description="the case this clock belongs to")
    event: str = Field(..., description="a typed event from the rulebook")
    idem_key: str = Field(..., description="identifies the occurrence; a "
                                           "repeat is suppressed, never "
                                           "re-applied")
    clock_seq: int | None = Field(
        None, description="the clock this trigger was raised against; a "
                          "trigger naming a superseded clock is refused")
    detail: str = Field("", description="the source message, recorded on "
                                        "the case ledger as evidence")


class TimerAck(BaseModel):
    outcome: str
    retryable: bool
    detail: str = ""
    state: str | None = None


def create_case_timer_router() -> APIRouter:
    router = APIRouter(prefix="/api/case-timers", tags=["case-timers"])

    def _authenticate(token: str | None) -> None:
        expected = timer_token()
        if not expected:
            # Defence in depth: the router is not mounted without a token,
            # so reaching here means a misconfiguration rather than a
            # request problem.
            raise HTTPException(status_code=503,
                                detail="timer listener is not configured")
        if not token or not hmac.compare_digest(token, expected):
            raise HTTPException(status_code=401,
                                detail="invalid or missing timer token")

    @router.post("/fire", response_model=TimerAck)
    def fire(payload: TimerEvent,
             x_timer_token: str | None = Header(None)) -> TimerAck:
        """Apply one timer trigger and report what happened."""
        _authenticate(x_timer_token)
        from ioagentfarm.tools.case_store import apply_timer_event
        try:
            res = apply_timer_event(payload.case_id, payload.event,
                                    payload.clock_seq, payload.idem_key,
                                    payload.detail)
        except Exception as exc:                       # pragma: no cover
            logger.exception("timer apply failed for %s", payload.case_id)
            # An unexpected failure is the retryable outcome, never a
            # settled one: the caller must be able to try again.
            return TimerAck(outcome="error", retryable=True,
                            detail=str(exc))
        outcome = res.get("outcome", "error")
        return TimerAck(outcome=outcome,
                        retryable=outcome not in _SETTLED,
                        detail=res.get("detail", ""),
                        state=res.get("state"))

    @router.get("/due")
    def due(x_timer_token: str | None = Header(None)) -> dict:
        """What the platform is waiting on. Lets an external scheduler
        poll rather than hold its own timers."""
        _authenticate(x_timer_token)
        import contextlib
        import io
        import json as _json
        from ioagentfarm.tools.case_store import cmd_due

        class _Args:
            now, json = "", True

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_due(_Args())
        try:
            return _json.loads(buf.getvalue())
        except ValueError:                             # pragma: no cover
            return {"due": []}

    return router
