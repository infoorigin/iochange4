"""Feedback on a chat reply, on both chat surfaces, and its summary.

    POST /v1/conversations/{id}/items/{item_id}/feedback   {signal, comment?, user_id?}
    POST /api/chat/{ns}/messages/{message_id}/feedback     {signal, comment?, user_id?}
    GET  /api/feedback/summary?since=

OWNERSHIP IS THE CONVERSATIONS ROUTER'S. The v1 route resolves the owner the
way ``/v1/conversations`` does (``conversations._owner``: verified actor first,
then the ``user_id`` the client sent when the engine runs unauthenticated) and
reads the thread through ``_get_owned`` - so feedback on somebody else's
thread is the same 404 that reading it is, and never a 403 that confirms the
thread exists. The legacy route binds ``user_id`` the way the legacy chat
surface does: with ``IOF_CHAT_BIND_PRINCIPAL`` on, the verified principal
replaces whatever the client sent (``app._bound_owner``); off, the message
must belong to the ``user_id`` named, when one is.

An unknown signal is a 422 that lists the legal values, on both surfaces.
The v1 surface renders it in the standard error envelope (``ConvError``); the
legacy surface in FastAPI's plain ``detail``.

Storage and the summary fold: ``engine/feedback.py``.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field

from ioagentfarm.engine import feedback as fb

logger = logging.getLogger(__name__)

router = APIRouter(tags=["feedback"])


class FeedbackIn(BaseModel):
    signal: str = Field(..., description="one of: up, down, correction")
    comment: str | None = None
    user_id: str | None = None


def _conv():
    from ioagentfarm.web import conversations
    return conversations


def _store():
    from ioagentfarm.web.app import _store as engine_store
    return engine_store()


def _ws() -> str:
    from ioagentfarm.engine.workspaces import resolved_workspace_code
    return resolved_workspace_code()


# -- the conversations surface ------------------------------------

@router.post("/v1/conversations/{conv_id}/items/{item_id}/feedback")
def conversation_item_feedback(conv_id: str, item_id: str, body: FeedbackIn,
                               request: Request) -> dict:
    conv = _conv()
    try:
        signal = fb.validate_signal(body.signal)
        comment = fb.clean_comment(body.comment)
    except fb.FeedbackError as exc:
        raise conv.ConvError(exc.status, str(exc), "invalid_request_error",
                             code="invalid_signal", param="signal")
    owner = conv._owner(request, body.user_id or "")
    store = conv._store()
    conv._ensure(store)
    with store._tx() as cur:
        thread = conv._get_owned(store, cur, conv_id, owner)
        cur.execute(store._q(
            "SELECT id, role FROM studio_conversation_messages"
            " WHERE workspace_code=? AND conversation_id=? AND id=?"),
            (conv._ws(), conv_id, item_id))
        row = cur.fetchone()
    if row is None:
        raise conv._not_found("item")
    rec = fb.record(store, workspace=conv._ws(), signal=signal, user_id=owner,
                    agent=thread.get("role") or "", comment=comment,
                    conversation_id=conv_id, item_id=item_id)
    return {"object": "conversation.item.feedback", **rec}


# -- the legacy surface -------------------------------------------

def _legacy_message_id(raw: str) -> int:
    """`POST /api/chat/{ns}` answers with ``id: "msg_43"`` and the history
    read lists the bare ``43``; a client may send either back."""
    text = (raw or "").strip()
    if text.startswith("msg_"):
        text = text[4:]
    if not text.isdigit():
        raise HTTPException(status_code=422, detail=(
            "message_id must be the id of a chat message - the integer "
            "`id` from GET /api/chat/{ns}/messages, or the `msg_<id>` the "
            f"chat reply carries (got {raw!r})"))
    return int(text)


@router.post("/api/chat/{ns}/messages/{message_id}/feedback")
def chat_message_feedback(ns: str, message_id: str, body: FeedbackIn,
                          request: Request) -> dict:
    try:
        signal = fb.validate_signal(body.signal)
        comment = fb.clean_comment(body.comment)
    except fb.FeedbackError as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))
    message_id = _legacy_message_id(message_id)
    user_id = (body.user_id or "").strip()
    from ioagentfarm.web.app import _bound_owner
    bound = _bound_owner(request)
    if bound:
        if user_id and user_id not in ("web:web_user", bound):
            raise HTTPException(status_code=403, detail=(
                "user_id does not match the authenticated principal. With "
                "IOF_CHAT_BIND_PRINCIPAL on, feedback is recorded for the "
                "verified caller."))
        user_id = bound
    store = _store()
    q = ("SELECT id, user_id, conversation_id, agent_name, role FROM messages"
         " WHERE run_id IS NULL AND id=?")
    params: list = [message_id]
    if user_id:
        q += " AND user_id=?"
        params.append(user_id)
    with store._tx() as cur:
        cur.execute(store._q(q), tuple(params))
        row = cur.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="No message found with that id.")
    msg = dict(row)
    agent = msg.get("agent_name") or msg.get("role") or ns
    rec = fb.record(store, workspace=_ws(), signal=signal, user_id=user_id,
                    agent=agent, comment=comment,
                    conversation_id=msg.get("conversation_id"),
                    message_id=message_id)
    return {"ns": ns, **rec}


# -- the summary --------------------------------------------------

@router.get("/api/feedback/summary")
def feedback_summary(since: str | None = Query(
        default=None, description="ISO date/time or a window: 7d, 24h, 30m")) -> dict:
    try:
        since_iso = fb.parse_since(since)
    except fb.FeedbackError as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))
    return fb.summary(_store(), workspace=_ws(), since=since_iso)
