"""The draft agent pool — one author's Try-it sessions on their own overlay.

Owns the (author, role) -> AgentLoop cache behind ``AgentPool.get_draft``:
resolving the author's open drafts on EVERY request, rebuilding the private
draft home (``draft_files.materialize_draft_home``) whenever the draft set's
signature moved, and bounding how many private loops one pod holds
(``IOF_DRAFT_POOL_MAX``, LRU, MCP closed on eviction).

What it must not do, and why each rule exists:

* **Never serve a cached loop past a Save.** The signature is recomputed
  from the DATABASE on every get, under a per-key lock — a "seen" memo would
  answer the turn AFTER a Save from the pre-Save home, which is exactly the
  stale-content ambiguity drafts exist to remove. A rebuild lands on the
  very next turn of the SAME session key.
* **Never wrap a draft loop with ``wrap_with_session_identity``.** That
  wrapper refreshes the SHARED home from the installed pack; pointed at a
  draft home it would re-seed pack bytes over the author's overlay on the
  first turn of every session. The signature check above is the draft-side
  equivalent, and ``materialize_draft_home`` refreshes the shared home
  itself, so pack edits still reach a draft session.
* **Never touch the shared pool's entries.** A draft loop is keyed by
  (author, role) in its own map; ``AgentPool._agents`` stays exactly what
  every other user is served from.

Must not import: ``ioagentfarm.web.session_identity`` (see above) and the
Studio API's modules. The loop builder is INJECTED (``AgentPool._build_agent_loop``)
rather than imported so this module never reaches into app.py's shared state.
"""

from __future__ import annotations

import asyncio
import os
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from loguru import logger

#: Default LRU cap. Draft loops are per-AUTHOR, so an active Studio can mint
#: many more of them than the role-keyed shared pool ever holds; unbounded,
#: a busy tenant's pod accumulates one AgentLoop (plus MCP connections) per
#: author-role pair forever.
DEFAULT_MAX = 32
POOL_MAX_ENV = "IOF_DRAFT_POOL_MAX"


@dataclass
class _Entry:
    loop: Any
    signature: str
    home: Path


def _pool_cap() -> int:
    """Read the cap per call — an operator (or a test) may change it while
    the process runs, and a stale ctor-time copy would ignore that."""
    raw = (os.environ.get(POOL_MAX_ENV) or "").strip()
    try:
        value = int(raw) if raw else DEFAULT_MAX
    except ValueError:
        logger.warning("draft pool: {}={!r} is not an integer - using {}",
                       POOL_MAX_ENV, raw, DEFAULT_MAX)
        return DEFAULT_MAX
    return value if value > 0 else DEFAULT_MAX


async def _close_loop(loop: Any) -> None:
    """Best-effort MCP close + stop; an evicted loop must never keep a
    server subprocess alive with nothing routing to it."""
    for call in ("close_mcp",):
        fn = getattr(loop, call, None)
        if fn is None:
            continue
        try:
            result = fn()
            if asyncio.iscoroutine(result):
                await result
        except Exception:  # noqa: BLE001 - closing is cleanup, not delivery
            logger.debug("draft pool: {} failed during eviction", call)
    stop = getattr(loop, "stop", None)
    if stop is not None:
        try:
            stop()
        except Exception:  # noqa: BLE001
            pass


class DraftPool:
    """(author, role) -> (AgentLoop over the author's draft home, signature).

    *build_loop* is ``AgentPool._build_agent_loop`` — the same ctor path the
    shared pool uses (metadata copy, external agents, tool removal, exec
    hardening, learning wrap, pool limit), minus the session-identity wrap.
    """

    def __init__(self, build_loop: Callable[[str, Any, str], Any]):
        self._build_loop = build_loop
        self._entries: "OrderedDict[tuple[str, str], _Entry]" = OrderedDict()
        self._locks: dict[tuple[str, str], asyncio.Lock] = {}

    async def get(self, author: str, role: str, *, workspace_code: str,
                  store: Any) -> tuple[Any, Path, list[dict]]:
        """The author's current draft loop for *role*.

        Returns ``(loop, draft_home, open_drafts)`` — the drafts are returned
        so the caller can stamp provenance from the SAME read that decided
        which home answers, rather than a second read that may already
        disagree with it.
        """
        author = (author or "").strip().lower()
        if not author:
            raise ValueError("draft session: an author is required")

        from ioagentfarm.engine.drafts import draft_signature, for_author
        # DB + file I/O off the event loop: a draft rebuild copies a whole
        # agent home, and blocking here would stall every in-flight chat.
        drafts = await asyncio.to_thread(for_author, store, workspace_code,
                                         author)
        signature = draft_signature(drafts)

        key = (author, role)
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            entry = self._entries.get(key)
            if entry is not None and entry.signature == signature:
                self._entries.move_to_end(key)
                return entry.loop, entry.home, drafts

            from ioagentfarm.engine.draft_files import materialize_draft_home
            home = await asyncio.to_thread(
                materialize_draft_home, role, workspace_code, author, drafts)
            loop = self._build_loop(role, home, workspace_code)
            if entry is not None:
                # The old loop is being REPLACED (a Save moved the
                # signature); close it now or its MCP servers outlive every
                # route to them.
                await _close_loop(entry.loop)
            self._entries[key] = _Entry(loop=loop, signature=signature,
                                        home=home)
            self._entries.move_to_end(key)
            logger.info("draft pool: built loop for author={} role={} "
                        "signature={}", author, role, signature[:12])

        await self._evict_over_cap(keep=key)
        return loop, home, drafts

    async def _evict_over_cap(self, keep: tuple[str, str]) -> None:
        cap = _pool_cap()
        while len(self._entries) > cap:
            victim_key = next((k for k in self._entries if k != keep), None)
            if victim_key is None:
                return
            victim = self._entries.pop(victim_key)
            self._locks.pop(victim_key, None)
            logger.info("draft pool: evicting author={} role={} (cap {})",
                        victim_key[0], victim_key[1], cap)
            await _close_loop(victim.loop)

    async def shutdown(self) -> None:
        """Close every draft loop — called from ``AgentPool.shutdown``."""
        entries = list(self._entries.values())
        self._entries.clear()
        self._locks.clear()
        for entry in entries:
            await _close_loop(entry.loop)
