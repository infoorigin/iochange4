"""Solution manifest — the generic reader for ``aicore.solution.yaml``.

A solution git repo describes itself with one YAML file at its root; the
platform reads it to know which directories hold the solution's agents,
skills and workflows, plus optional business-facing metadata overrides.
Core reads this file GENERICALLY (the ``inject.yaml`` / ``tools.yaml``
precedent) — it never names a domain, a role, or a table.

Schema (all sections optional except ``solution``)::

    solution: pharma            # WORKSPACE FAMILY code (== Pack.name)
    version: 1
    roots:
      agents:    [path/to/agents, ...]     # dirs of <role>/workspace/ trees
      skills:    [path/to/skills, ...]     # dirs of <skill>/SKILL.md trees
      workflows: [path/to/workflows, ...]  # dirs of <code>/workflow.yaml trees
      swarms:    [path/to/swarms, ...]     # dirs of <code>/swarm.yaml trees
    solutions:                             # OPTIONAL per-solution attribution
      barrier_signal:                      # solution code within the family
        workflows: [barrier_signal/pkg/workflows]
        swarms: [barrier_signal/pkg/swarms]
      signal_brief:
        workflows: [signal_brief/pkg/workflows]
    overrides:
      agents:
        <role>: {label: ..., summary: ...}
      skills:
        <name>: {category: ...}

``solutions:`` is the workspace-repo form: agents/skills/tools are FAMILY
level (declared once under ``roots``), while each solution names its own
workflow roots. Solution workflow roots are APPENDED to ``workflows_roots``
so every existing consumer sees one flat list; the extra information —
which solution owns which workflow — is served by
``workflow_solution_map()``. Workflows under plain ``roots.workflows``
attribute to the family code itself. A reader older than this key ignores
it entirely and degrades to "one solution", which was the old behavior.

Validation is FAIL-CLOSED and total: every problem is collected and the
whole manifest is rejected — the platform never half-imports a solution
(the ``iof-playbook seed-templates`` validate-all-before-write discipline).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

#: The manifest filename the scaffold writes, and the one preferred on read.
MANIFEST_NAME = "aicore.solution.yaml"

#: Filenames still accepted on read. A repository scaffolded before the
#: product was named AI Core Harness carries the first of these. The rename
#: is ours, not the customer's, so their repo must keep loading untouched —
#: which is why this is a read-compatible rename and not a cutover.
LEGACY_MANIFEST_NAMES = ("agentfarm.solution.yaml",)

#: Every accepted manifest filename, preferred first.
MANIFEST_NAMES = (MANIFEST_NAME, *LEGACY_MANIFEST_NAMES)


def find_manifest(repo_root: Path) -> Path | None:
    """The repo's manifest, preferring the current name.

    ``None`` when the directory holds none of the accepted names. A repo
    carrying both is served the current one; the legacy file is then dead
    weight rather than a conflict.
    """
    for name in MANIFEST_NAMES:
        candidate = repo_root / name
        if candidate.is_file():
            return candidate
    return None


_CODE_RE = re.compile(r"^[a-z][a-z0-9_-]{1,40}$")


@dataclass(frozen=True)
class SolutionManifest:
    solution: str
    version: int
    repo_root: Path
    agents_roots: list[Path] = field(default_factory=list)
    skills_roots: list[Path] = field(default_factory=list)
    workflows_roots: list[Path] = field(default_factory=list)
    swarms_roots: list[Path] = field(default_factory=list)
    overrides: dict = field(default_factory=dict)
    #: ``{solution_code: [workflow roots]}`` from the optional ``solutions:``
    #: key. These roots are ALSO present in ``workflows_roots`` (appended at
    #: load time) — this mapping only records attribution. Empty for a
    #: single-solution repo.
    solutions: dict[str, list[Path]] = field(default_factory=dict)
    #: ``{solution_code: [swarm roots]}`` — the swarm counterpart of
    #: ``solutions``. Same append-to-flat-list + attribution-only contract.
    solutions_swarms: dict[str, list[Path]] = field(default_factory=dict)

    def workflow_dirs(self) -> dict[str, Path]:
        """{workflow_code: dir} across the manifest's workflow roots
        (first root wins on duplicates — validation rejects them anyway)."""
        found: dict[str, Path] = {}
        for root in self.workflows_roots:
            if not root.is_dir():
                continue
            for d in sorted(root.iterdir()):
                if d.is_dir() and (d / "workflow.yaml").is_file():
                    found.setdefault(d.name, d)
        return found

    def workflow_solution_map(self) -> dict[str, str]:
        """{workflow_code: solution_code} — which solution owns each workflow.

        A workflow under a root claimed by a ``solutions:`` entry attributes
        to that solution; one under a plain ``roots.workflows`` root
        attributes to the family code (``self.solution``). Single-solution
        repos therefore map everything to the family code, which is exactly
        the old one-solution reading.
        """
        owner_of_root: dict[Path, str] = {}
        for code, roots in self.solutions.items():
            for r in roots:
                owner_of_root[r] = code
        out: dict[str, str] = {}
        for root in self.workflows_roots:
            if not root.is_dir():
                continue
            owner = owner_of_root.get(root, self.solution)
            for d in sorted(root.iterdir()):
                if d.is_dir() and (d / "workflow.yaml").is_file():
                    out.setdefault(d.name, owner)
        return out

    def swarm_dirs(self) -> dict[str, Path]:
        """{swarm_code: dir} across the manifest's swarm roots
        (first root wins on duplicates — validation rejects them anyway)."""
        found: dict[str, Path] = {}
        for root in self.swarms_roots:
            if not root.is_dir():
                continue
            for d in sorted(root.iterdir()):
                if d.is_dir() and (d / "swarm.yaml").is_file():
                    found.setdefault(d.name, d)
        return found

    def swarm_solution_map(self) -> dict[str, str]:
        """{swarm_code: solution_code} — the swarm mirror of
        :meth:`workflow_solution_map`."""
        owner_of_root: dict[Path, str] = {}
        for code, roots in self.solutions_swarms.items():
            for r in roots:
                owner_of_root[r] = code
        out: dict[str, str] = {}
        for root in self.swarms_roots:
            if not root.is_dir():
                continue
            owner = owner_of_root.get(root, self.solution)
            for d in sorted(root.iterdir()):
                if d.is_dir() and (d / "swarm.yaml").is_file():
                    out.setdefault(d.name, owner)
        return out

    def agent_dirs(self) -> dict[str, Path]:
        """{role: <role dir>} — each must contain workspace/SOUL.md."""
        found: dict[str, Path] = {}
        for root in self.agents_roots:
            if not root.is_dir():
                continue
            for d in sorted(root.iterdir()):
                if d.is_dir() and (d / "workspace" / "SOUL.md").is_file():
                    found.setdefault(d.name, d)
        return found

    def injected_skills(self) -> dict[str, tuple[Path, list[str]]]:
        """{skill_name: (dir, roles)} from ``_<x>/inject.yaml`` content dirs.

        A pack can contribute a skill to an agent it does not own by shipping
        an underscore-prefixed dir under an AGENTS root::

            agents/_signal_brief/inject.yaml   {skills_dir: skills,
                                                roles: [pharma_domain_analyst]}
            agents/_signal_brief/skills/<name>/SKILL.md

        The runtime already honours this (``PackRegistry.domain_skill_
        injections``), but the importer did not: ``agent_dirs()`` skips the dir
        (no ``workspace/SOUL.md``) and ``skill_dirs()`` never looked under an
        agents root, so the skill reached a host only via the installed wheel.
        On the split deployment that is exactly the gap that matters — the API
        pod installs no packs and reads the database, so an inject skill was
        invisible in the Studio.

        Assignment comes from ``roles:`` here rather than the SKILL.md
        frontmatter: the whole point of an inject dir is that the CONTRIBUTING
        pack decides who receives the skill.
        """
        found: dict[str, tuple[Path, list[str]]] = {}
        for root in self.agents_roots:
            if not root.is_dir():
                continue
            for entry in sorted(root.iterdir()):
                if not entry.is_dir() or not entry.name.startswith("_"):
                    continue
                spec_file = entry / "inject.yaml"
                if not spec_file.is_file():
                    continue
                try:
                    spec = yaml.safe_load(
                        spec_file.read_text(encoding="utf-8")) or {}
                except (OSError, yaml.YAMLError):
                    continue
                if not isinstance(spec, dict):
                    continue
                sdir = entry / str(spec.get("skills_dir", "skills"))
                roles = [str(r) for r in (spec.get("roles") or [])]
                if not sdir.is_dir():
                    continue
                for d in sorted(sdir.iterdir()):
                    if d.is_dir() and (d / "SKILL.md").is_file():
                        found.setdefault(d.name, (d, roles))
        return found

    def skill_dirs(self) -> dict[str, Path]:
        """{skill_name: dir} — each must contain SKILL.md.

        Declared skills roots first, then inject-dir skills; a standalone skill
        of the same name wins, since the skills root is the more explicit
        declaration.
        """
        found: dict[str, Path] = {}
        for root in self.skills_roots:
            if not root.is_dir():
                continue
            for d in sorted(root.iterdir()):
                if d.is_dir() and (d / "SKILL.md").is_file():
                    found.setdefault(d.name, d)
        for name, (d, _roles) in self.injected_skills().items():
            found.setdefault(name, d)
        return found

    def skill_assignment(self, name: str) -> list[str] | None:
        """Roles an inject.yaml assigns this skill to, else ``None``.

        ``None`` means "fall back to the SKILL.md ``roles:`` frontmatter" —
        the normal case for a standalone skill.
        """
        hit = self.injected_skills().get(name)
        return hit[1] if hit and hit[1] else None


class ManifestError(ValueError):
    """Raised with ALL validation problems, newline-joined."""

    def __init__(self, problems: list[str]):
        self.problems = problems
        super().__init__("solution manifest rejected:\n  - "
                         + "\n  - ".join(problems))


def load_manifest(repo_root: Path) -> SolutionManifest:
    """Read + structurally validate the repo's solution manifest.

    Raises :class:`ManifestError` (all problems at once) — never a partial
    manifest.
    """
    problems: list[str] = []
    path = find_manifest(repo_root)
    if path is None:
        raise ManifestError([f"{MANIFEST_NAME} not found at {repo_root}"])
    # Errors name the file that is actually on disk, so a repo still on the
    # legacy name is not told to go and look at one it does not have.
    name = path.name

    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ManifestError([f"{name} is not valid YAML: {exc}"])
    if not isinstance(data, dict):
        raise ManifestError([f"{name} must be a mapping"])

    solution = str(data.get("solution") or "").strip()
    if not _CODE_RE.match(solution):
        problems.append(
            "`solution` must be a lowercase code ([a-z0-9_-], starts with a "
            f"letter); got {solution!r}")

    version = data.get("version", 1)
    if version != 1:
        problems.append(f"unsupported manifest version {version!r} (expected 1)")

    roots = data.get("roots") or {}
    if not isinstance(roots, dict):
        problems.append("`roots` must be a mapping of agents/skills/workflows lists")
        roots = {}
    unknown_roots = set(roots) - {"agents", "skills", "workflows", "swarms"}
    if unknown_roots:
        problems.append(f"unknown `roots` keys: {sorted(unknown_roots)}")

    def _resolve_list(label: str, raw: object) -> list[Path]:
        out: list[Path] = []
        if raw is None:
            return out
        if not isinstance(raw, list):
            problems.append(f"{label} must be a list of paths")
            return out
        for rel in raw:
            p = (repo_root / str(rel)).resolve()
            # paths must stay inside the repo — a manifest must not be able
            # to point the importer at arbitrary host directories
            try:
                p.relative_to(repo_root.resolve())
            except ValueError:
                problems.append(f"{label}: {rel!r} escapes the repository")
                continue
            if not p.is_dir():
                problems.append(f"{label}: {rel!r} does not exist")
                continue
            out.append(p)
        return out

    def _resolve(kind: str) -> list[Path]:
        return _resolve_list(f"roots.{kind}", roots.get(kind))

    agents_roots = _resolve("agents")
    skills_roots = _resolve("skills")
    workflows_roots = _resolve("workflows")
    swarms_roots = _resolve("swarms")

    # -- optional per-solution workflow attribution (`solutions:`) --------
    # Solution roots are APPENDED to workflows_roots so every existing
    # consumer sees one flat list; workflow_solution_map() serves the
    # attribution. Validation mirrors `roots`: fail-closed, all problems
    # collected, and no root may be claimed twice.
    solutions_map: dict[str, list[Path]] = {}
    solutions_swarms_map: dict[str, list[Path]] = {}
    raw_solutions = data.get("solutions") or {}
    if not isinstance(raw_solutions, dict):
        problems.append("`solutions` must be a mapping of solution codes")
        raw_solutions = {}
    claimed: dict[Path, str] = {p: "roots.workflows" for p in workflows_roots}
    claimed.update({p: "roots.swarms" for p in swarms_roots})
    for code, spec in raw_solutions.items():
        scode = str(code).strip()
        if not _CODE_RE.match(scode):
            problems.append(
                "`solutions` keys must be lowercase codes ([a-z0-9_-], "
                f"starts with a letter); got {code!r}")
            continue
        if not isinstance(spec, dict):
            problems.append(f"solutions.{scode} must be a mapping "
                            "(e.g. {workflows: [path, ...]})")
            continue
        unknown = set(spec) - {"workflows", "swarms"}
        if unknown:
            problems.append(
                f"unknown solutions.{scode} keys: {sorted(unknown)} — only "
                "workflows and swarms are solution-level; agents/skills/"
                "tools are family-level under `roots`")
        s_roots = _resolve_list(f"solutions.{scode}.workflows",
                                spec.get("workflows"))
        for p in s_roots:
            prior = claimed.get(p)
            if prior is not None:
                problems.append(
                    f"solutions.{scode}: workflow root {p} already claimed "
                    f"by {prior} — a root belongs to exactly one solution")
                continue
            claimed[p] = f"solutions.{scode}"
            workflows_roots.append(p)
            solutions_map.setdefault(scode, []).append(p)
        sw_roots = _resolve_list(f"solutions.{scode}.swarms",
                                 spec.get("swarms"))
        for p in sw_roots:
            prior = claimed.get(p)
            if prior is not None:
                problems.append(
                    f"solutions.{scode}: swarm root {p} already claimed "
                    f"by {prior} — a root belongs to exactly one solution")
                continue
            claimed[p] = f"solutions.{scode} (swarms)"
            swarms_roots.append(p)
            solutions_swarms_map.setdefault(scode, []).append(p)

    if not (agents_roots or skills_roots or workflows_roots or swarms_roots):
        problems.append("manifest declares no usable roots "
                        "(agents/skills/workflows/swarms)")

    overrides = data.get("overrides") or {}
    if not isinstance(overrides, dict):
        problems.append("`overrides` must be a mapping")
        overrides = {}

    manifest = SolutionManifest(
        solution=solution or "invalid",
        version=1,
        repo_root=repo_root,
        agents_roots=agents_roots,
        skills_roots=skills_roots,
        workflows_roots=workflows_roots,
        swarms_roots=swarms_roots,
        overrides=overrides,
        solutions=solutions_map,
        solutions_swarms=solutions_swarms_map,
    )

    # Cross-item validation on the resolved content --------------------
    # duplicate detection across roots (same role/skill/workflow/swarm twice)
    for kind, dirs_fn in (("agents", "agent_dirs"), ("skills", "skill_dirs"),
                          ("workflows", "workflow_dirs"),
                          ("swarms", "swarm_dirs")):
        seen: dict[str, Path] = {}
        for root in getattr(manifest, f"{kind}_roots"):
            if not root.is_dir():
                continue
            for d in sorted(root.iterdir()):
                if not d.is_dir():
                    continue
                marker = {"agents": d / "workspace" / "SOUL.md",
                          "skills": d / "SKILL.md",
                          "workflows": d / "workflow.yaml",
                          "swarms": d / "swarm.yaml"}[kind]
                if not marker.is_file():
                    continue
                if d.name in seen and seen[d.name] != d:
                    problems.append(
                        f"{kind}: {d.name!r} declared by two roots "
                        f"({seen[d.name]} and {d})")
                seen[d.name] = d
        if kind == "skills":
            # An inject-dir skill colliding with a declared one is the same
            # ambiguity as two roots declaring it. skill_dirs() resolves it
            # (skills root wins) but silently, so name it here.
            for name, (d, _roles) in manifest.injected_skills().items():
                if name in seen and seen[name] != d:
                    problems.append(
                        f"skills: {name!r} declared both by a skills root "
                        f"({seen[name]}) and an inject dir ({d})")

    if problems:
        raise ManifestError(problems)
    return manifest


def validate_reserved(manifest: SolutionManifest,
                      reserved_agents: set[str],
                      reserved_skills: set[str]) -> list[str]:
    """Shadow check: a solution may not redefine platform-shared content.

    Returns problems (empty = ok). Kept separate from :func:`load_manifest`
    because the reserved sets come from the PLATFORM (pack registry), which
    the generic loader must not import.
    """
    problems: list[str] = []
    for role in sorted(set(manifest.agent_dirs()) & reserved_agents):
        problems.append(
            f"agents: {role!r} shadows a platform-shared agent — shared "
            "agents are framework-owned and identical in every workspace")
    for skill in sorted(set(manifest.skill_dirs()) & reserved_skills):
        problems.append(
            f"skills: {skill!r} shadows a platform-shared skill — shared "
            "skills arrive from the agentfarm-skills wheel, not solutions")
    return problems
