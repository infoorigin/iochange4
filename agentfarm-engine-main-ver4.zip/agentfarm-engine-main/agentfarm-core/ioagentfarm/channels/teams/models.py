"""Lightweight Activity models for the Teams channel.

Replaces the ``microsoft-agents-*`` SDK with thin Pydantic models covering
only the fields we actually use.  The Bot Framework / Agents connector
protocol is just JSON over HTTP — no SDK required.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ------------------------------------------------------------------
# Sub-models
# ------------------------------------------------------------------

class ChannelAccount(BaseModel):
    """User or bot identity."""
    id: str = ""
    name: Optional[str] = None
    aad_object_id: Optional[str] = Field(None, alias="aadObjectId")

    model_config = {"populate_by_name": True}


class ConversationAccount(BaseModel):
    """Conversation (channel thread or DM)."""
    id: str = ""
    name: Optional[str] = None
    conversation_type: Optional[str] = Field(None, alias="conversationType")
    tenant_id: Optional[str] = Field(None, alias="tenantId")

    model_config = {"populate_by_name": True}


class Attachment(BaseModel):
    """Message attachment (Adaptive Cards, files, etc.)."""
    content_type: str = Field("", alias="contentType")
    content: Optional[Any] = None
    name: Optional[str] = None

    model_config = {"populate_by_name": True}


class Entity(BaseModel):
    """Activity entity (mentions, etc.)."""
    type: Optional[str] = None
    text: Optional[str] = None
    mentioned: Optional[ChannelAccount] = None

    model_config = {"extra": "allow"}


# ------------------------------------------------------------------
# Activity
# ------------------------------------------------------------------

class Activity(BaseModel):
    """Bot Framework / Agents SDK Activity — thin subset.

    See https://learn.microsoft.com/en-us/azure/bot-service/rest-api/bot-framework-rest-connector-api-reference
    """
    type: str = "message"
    id: Optional[str] = None
    timestamp: Optional[str] = None
    text: Optional[str] = None
    from_property: Optional[ChannelAccount] = Field(None, alias="from")
    recipient: Optional[ChannelAccount] = None
    conversation: Optional[ConversationAccount] = None
    channel_id: Optional[str] = Field(None, alias="channelId")
    service_url: Optional[str] = Field(None, alias="serviceUrl")
    reply_to_id: Optional[str] = Field(None, alias="replyToId")
    attachments: Optional[List[Attachment]] = None
    entities: Optional[List[Entity]] = None
    channel_data: Optional[Dict[str, Any]] = Field(None, alias="channelData")
    members_added: Optional[List[ChannelAccount]] = Field(None, alias="membersAdded")
    name: Optional[str] = None
    value: Optional[Any] = None

    model_config = {"populate_by_name": True}


# ------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------

class ActivityTypes:
    message = "message"
    typing = "typing"
    conversation_update = "conversationUpdate"
    invoke = "invoke"
