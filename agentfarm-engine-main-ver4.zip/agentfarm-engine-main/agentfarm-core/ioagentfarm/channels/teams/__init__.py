"""MS Teams channel adapter for ioagentfarm.

Provides a FastAPI router that receives Bot Framework Activity webhooks
from Microsoft Teams and routes messages through the existing AgentPool.

Usage:
    from ioagentfarm.channels.teams import create_teams_router

    router = create_teams_router(agent_pool)
    app.include_router(router)

Requires env vars: TEAMS_APP_ID, TEAMS_APP_SECRET, TEAMS_TENANT_ID.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import APIRouter


def create_teams_router(pool: object) -> "APIRouter":
    """Create and return the Teams FastAPI router.

    Parameters
    ----------
    pool : AgentPool
        The shared agent pool from ``ioagentfarm serve``.
    """
    from .router import build_router
    print("In create_teams_router")
    return build_router(pool)
