"""Teams bot — activity handling, agent routing, proactive messaging.

No external SDK dependency.  Uses lightweight Pydantic Activity models
and httpx for REST calls to the connector service.  Routes messages
through the existing AgentPool + ``process_direct()`` pipeline.

All agent work (answering, tasks, workflows) runs inside ``process_direct()``
— Jarvis drives everything within a single call, so there is no separate
background process to monitor.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

import httpx

from ioagentfarm.channels.teams.cards import (
    error_card,
    run_started_card,
    welcome_card,
)
from ioagentfarm.channels.teams.config import TeamsConfig
from ioagentfarm.channels.teams.models import (
    Activity,
    ActivityTypes,
    Attachment,
    ChannelAccount,
)
from ioagentfarm.channels.teams.state import TeamsState

logger = logging.getLogger(__name__)


class TeamsBot:
    """Handles Teams activities and bridges to ioagentfarm's AgentPool.

    Parameters
    ----------
    pool : AgentPool
        The shared agent pool from ``ioagentfarm serve``.
    state : TeamsState
        Teams-specific DB state (thread-to-run mapping, conversation refs).
    config : TeamsConfig
        Teams channel configuration.
    """

    def __init__(self, pool: object, state: TeamsState, config: TeamsConfig) -> None:
        self._pool = pool
        self._state = state
        self._config = config
        # Shared httpx client (connection pooling)
        self._http: Optional[httpx.AsyncClient] = None
        # Cached store instance
        self._store = None
        # Cached MSAL app (reuses token cache across calls)
        self._msal_app = None
        # Dedup: track processed activity IDs to prevent duplicate runs on webhook retries
        self._processed_activities: Dict[str, float] = {}
        self._dedup_ttl = 300  # 5 minutes

    def _get_http(self) -> httpx.AsyncClient:
        """Lazily create a shared httpx client."""
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(timeout=30)
        return self._http

    def _get_store(self):
        """Get or create a Store instance (reused across calls)."""
        if self._store is not None:
            return self._store
        from ioagentfarm.engine.db import make_adapter
        from ioagentfarm.engine.store import Store
        import os
        adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
        store = Store(adapter)
        store.init()
        self._store = store
        return store

    def _get_learning_lifecycle(self):
        """Get or create a LearningLifecycle instance (reused across calls)."""
        if not hasattr(self, "_learning_lifecycle") or self._learning_lifecycle is None:
            from ioagentfarm.engine.db import make_adapter
            from ioagentfarm.engine.learning import LearningLifecycle
            import os
            adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
            ll = LearningLifecycle(adapter)
            ll.init()
            self._learning_lifecycle = ll
        return self._learning_lifecycle

    # ------------------------------------------------------------------
    # Activity dispatcher
    # ------------------------------------------------------------------

    async def handle_activity(self, activity: Activity) -> None:
        """Main entry point — dispatches by activity type."""
        try:
            if activity.type == ActivityTypes.message:
                await self._handle_message(activity)
            elif activity.type == ActivityTypes.conversation_update:
                await self._handle_conversation_update(activity)
            elif activity.type == ActivityTypes.invoke:
                await self._handle_invoke(activity)
            else:
                logger.debug("Ignoring activity type: %s", activity.type)
        except Exception:
            logger.exception("Error handling activity %s", activity.id)
            try:
                await self._send_reply(
                    activity,
                    attachment=_card_attachment(
                        error_card("An unexpected error occurred. Please try again.")
                    ),
                )
            except Exception:
                logger.exception("Failed to send error card")

    # ------------------------------------------------------------------
    # Message handling
    # ------------------------------------------------------------------

    def _is_duplicate(self, activity_id: str) -> bool:
        """Check if this activity was already processed (webhook retry protection)."""
        import time
        now = time.time()
        # Cleanup expired entries
        expired = [k for k, t in self._processed_activities.items() if now - t > self._dedup_ttl]
        for k in expired:
            del self._processed_activities[k]
        # Check and mark
        if activity_id in self._processed_activities:
            return True
        self._processed_activities[activity_id] = now
        return False

    async def _handle_message(self, activity: Activity) -> None:
        """Route an incoming message to the agent pool."""
        text = (activity.text or "").strip()
        if not text:
            return

        # Dedup: skip if this activity was already processed (webhook retry)
        if activity.id and self._is_duplicate(activity.id):
            logger.info("Skipping duplicate activity %s (webhook retry)", activity.id)
            return

        # Strip bot @mention from channel messages
        text = self._strip_mention(activity, text)
        if not text:
            return

        thread_id = self._extract_thread_id(activity)
        if thread_id == "unknown":
            logger.warning("Could not extract thread_id from activity %s", activity.id)

        user_id = self._extract_user_id(activity)

        # Persist conversation reference for proactive messaging
        conv_ref = self._build_conversation_reference(activity)
        self._state.save_conversation_ref(
            thread_id, conv_ref, activity.service_url or "",
        )

        # Send typing indicator
        await self._send_typing(activity)

        # Look up thread-to-run mapping
        run_id = self._state.get_run_for_thread(thread_id)

        store = self._get_store()

        from ioagentfarm.engine.workspaces import get_agent_name
        role = "cora"
        agent_display_name = get_agent_name(role)

        try:
            agent = self._pool.get(role)
        except Exception as exc:
            logger.error("Could not get agent for role=%s: %s", role, exc)
            await self._send_reply(
                activity,
                attachment=_card_attachment(error_card(f"Agent unavailable: {exc}")),
            )
            return

        uid = f"teams:{user_id}"

        # Persist user message
        store.insert_message(
            run_id=run_id or "",
            user_id=uid,
            source="user",
            content=text,
            msg_type="message",
        )

        # Snapshot existing run IDs BEFORE agent processes (for new-run detection)
        existing_run_ids = set()
        if not run_id:
            existing_run_ids = {r["id"] for r in store.list_runs(user_id=uid)}

        # Build message for agent
        # When no thread-to-run mapping exists (1:1 chat), inject the user's
        # recent runs summary so Jarvis can match by workflow/goal or ask the
        # user which run they mean.  Don't auto-pick one — there could be hundreds.
        if run_id:
            from ioagentfarm.web.app import _build_run_context
            run_context = _build_run_context(run_id)
            augmented = f"{run_context}\n\n[User message] {text}" if run_context else text
            session_key = f"teams:{run_id}:{role}:u:{uid}"
        else:
            # Inject recent runs list so Jarvis can resolve which run the user means
            runs_hint = ""
            try:
                recent = store.list_runs(user_id=uid, limit=10)
                if not recent:
                    recent = store.list_runs(limit=10)
                if recent:
                    lines = ["[Recent runs — use run_id in commands]"]
                    for r in recent:
                        lines.append(
                            f"  {r['id']} | {r.get('workflow_name','')} | {r.get('status','')} | {(r.get('goal','') or '')[:80]}"
                        )
                    runs_hint = "\n".join(lines) + "\n\n"
            except Exception:
                logger.debug("Could not list recent runs", exc_info=True)
            augmented = f"{runs_hint}[User message] {text}"
            session_key = f"teams:chat:{role}:u:{uid}"

        # on_progress: persist intermediate thoughts
        from ioagentfarm.cli_orchestration import _is_noise

        async def _on_progress(text_chunk: str, **kwargs) -> None:
            stripped = text_chunk.strip()
            if not stripped or _is_noise(stripped):
                return
            store.insert_message(
                run_id=run_id or "",
                user_id=uid,
                source="agent",
                role=role,
                agent_name=agent_display_name,
                content=stripped,
                msg_type="thought",
            )

        # Process via agent — Jarvis handles everything (answers, tasks,
        # workflows) within this single call.  No background subprocess.
        from ioagentfarm.engine.stream_utils import LineBufferedStream
        stream = LineBufferedStream(_on_progress)
        result = await agent.process_direct(
            augmented,
            session_key=session_key,
            channel="teams",
            chat_id=f"teams:{thread_id}",
            on_progress=_on_progress,
            on_stream=stream,
        )
        await stream.flush()
        response = result.content if result else ""

        # Persist final response
        store.insert_message(
            run_id=run_id or "",
            user_id=uid,
            source="agent",
            role=role,
            agent_name=agent_display_name,
            content=response,
            msg_type="message",
        )

        # Send the response to Teams
        await self._send_reply(activity, text=response)

        # Check if Jarvis created a new run (compare before/after snapshots)
        if not run_id:
            new_run_id = self._detect_new_run(store, uid, existing_run_ids)
            if new_run_id:
                self._state.save_thread_mapping(
                    thread_id, new_run_id,
                    channel_id=self._extract_channel_id(activity),
                    user_id=uid,
                )
                run = store.get_run(new_run_id)
                steps = store.list_steps(new_run_id)
                step_dicts = [
                    {"step_key": s["step_key"], "role": s["role"], "status": s["status"]}
                    for s in steps
                ]
                await self._send_reply(
                    activity,
                    attachment=_card_attachment(
                        run_started_card(new_run_id, run["workflow_name"], run["goal"], step_dicts)
                    ),
                )
                # Monitor the run in background and push results back to Teams when done
                asyncio.create_task(
                    self._monitor_run_and_notify(activity, new_run_id, thread_id)
                )

    # ------------------------------------------------------------------
    # Conversation update (welcome)
    # ------------------------------------------------------------------

    async def _handle_conversation_update(self, activity: Activity) -> None:
        """Send welcome card when bot is added to a conversation."""
        if not activity.members_added:
            return
        bot_id = (activity.recipient or ChannelAccount()).id
        for member in activity.members_added:
            if member.id != bot_id:
                continue
            await self._send_reply(activity, attachment=_card_attachment(welcome_card()))
            break

    # ------------------------------------------------------------------
    # Invoke — feedback actions
    # ------------------------------------------------------------------

    async def _handle_invoke(self, activity: Activity) -> None:
        """Handle Action.Submit from Adaptive Cards (e.g. feedback buttons)."""
        value = activity.value or {}
        if isinstance(value, dict) and value.get("action") == "skill_feedback":
            await self._handle_skill_feedback(activity, value)
        else:
            logger.debug("Invoke activity: %s", activity.name)

    async def _handle_skill_feedback(
        self, activity: Activity, data: Dict[str, Any],
    ) -> None:
        """Process a feedback submission from a Teams Adaptive Card."""
        signal = data.get("signal", "")
        run_id = data.get("run_id", "")
        step_key = data.get("step_key", "")
        role = data.get("role", "")
        correction_text = data.get("correction_text", "")
        user_id = f"teams:{self._extract_user_id(activity)}"

        content = correction_text if signal == "correction" else ""

        try:
            ll = self._get_learning_lifecycle()
            # Find learned skills active for this role+workflow during this step
            store = self._get_store()
            run = store.get_run(run_id) if run_id else None
            workflow = run["workflow_name"] if run else ""

            skills = ll.get_skills(
                role=role, workflow=workflow,
            ) if role and workflow else []

            if skills:
                for skill in skills:
                    ll.record_feedback(
                        skill["learning_id"],
                        signal=signal,
                        content=content,
                        user_id=user_id,
                        run_id=run_id,
                        step_key=step_key,
                        source_channel="teams",
                    )
                ack = {
                    "positive": "Thanks! Noted as helpful.",
                    "negative": "Got it. I'll learn from this.",
                    "correction": "Correction recorded. I'll update my approach.",
                }
                await self._send_reply(activity, text=ack.get(signal, "Feedback recorded."))
                logger.info(
                    "Learning feedback: signal=%s run=%s step=%s role=%s skills=%d user=%s",
                    signal, run_id, step_key, role, len(skills), user_id,
                )
            else:
                await self._send_reply(activity, text="Feedback recorded.")
        except Exception:
            logger.exception("Error recording learning feedback")
            await self._send_reply(activity, text="Feedback recorded.")

    # ------------------------------------------------------------------
    # Proactive messaging — send to a thread using stored conversation ref
    # ------------------------------------------------------------------

    async def _send_proactive(
        self, thread_id: str, text: str = "", attachment: Optional[Attachment] = None,
    ) -> bool:
        """Send a proactive message to a Teams thread using stored conversation ref.

        Unlike _send_reply (which needs the original activity), this works
        at any time — even after server restart — using the conversation
        reference stored in teams_conversation_refs table.

        Returns True if sent successfully, False otherwise.
        """
        ref_data = self._state.get_conversation_ref(thread_id)
        if not ref_data:
            logger.warning("No conversation ref for thread %s — cannot send proactive message", thread_id)
            return False

        conv_ref = ref_data["conversation_ref"]
        service_url = ref_data.get("service_url") or conv_ref.get("serviceUrl", "")
        conversation = conv_ref.get("conversation", {})
        conv_id = conversation.get("id", "")

        if not service_url or not conv_id:
            logger.warning("Incomplete conversation ref for thread %s", thread_id)
            return False

        payload: Dict[str, Any] = {"type": "message"}
        if text:
            payload["text"] = text
        if attachment:
            payload["attachments"] = [attachment.model_dump(by_alias=True, exclude_none=True)]

        try:
            await self._post_activity(service_url, conv_id, payload)
            return True
        except Exception:
            logger.exception("Failed to send proactive message to thread %s", thread_id)
            return False

    # ------------------------------------------------------------------
    # Run monitoring — push results back to Teams when workflow completes
    # ------------------------------------------------------------------

    async def _monitor_run_and_notify(
        self, activity: Activity, run_id: str, thread_id: str,
    ) -> None:
        """Poll the run until done/failed, push progress and results to Teams thread.

        Uses proactive messaging via stored conversation_ref — survives
        beyond the original HTTP request lifecycle. Falls back to _send_reply
        with the original activity if conversation_ref is not yet stored.
        """
        store = self._get_store()
        max_polls = 120  # 120 * 15s = 30 minutes max
        poll_interval = 15  # seconds

        logger.info("Teams: monitoring run %s for thread %s", run_id, thread_id)

        async def _notify(text: str = "", attachment: Optional[Attachment] = None) -> None:
            """Send via proactive messaging, fall back to reply."""
            sent = await self._send_proactive(thread_id, text=text, attachment=attachment)
            if not sent:
                await self._send_reply(activity, text=text, attachment=attachment)

        last_done_count = 0
        for _ in range(max_polls):
            await asyncio.sleep(poll_interval)
            try:
                run = store.get_run(run_id)
                if not run:
                    break
                steps = store.list_steps(run_id)
                done = sum(1 for s in steps if s["status"] == "done")
                failed = sum(1 for s in steps if s["status"] == "failed")
                total = len(steps)

                # Send progress update when a step completes
                if done > last_done_count:
                    last_done_count = done
                    completed_steps = [s for s in steps if s["status"] == "done"]
                    latest = completed_steps[-1] if completed_steps else None
                    if latest and done < total:
                        from ioagentfarm.channels.teams.cards import progress_card
                        from ioagentfarm.engine.workspaces import get_agent_name
                        agent_name = get_agent_name(latest["role"])
                        snippet = (latest.get("output_text", "") or "")[:200].replace("\n", " ")
                        await _notify(
                            attachment=_card_attachment(
                                progress_card(
                                    step_name=latest["step_key"],
                                    role=latest["role"],
                                    agent_name=agent_name,
                                    status=latest["status"],
                                    output_snippet=snippet,
                                    run_id=run_id,
                                )
                            ),
                        )

                # Run finished
                if run["status"] in ("done", "failed") or done + failed >= total:
                    final_status = "done" if failed == 0 else "failed"
                    summary = f"{done}/{total} steps completed"
                    if failed:
                        summary += f", {failed} failed"
                    step_dicts = [
                        {"step_key": s["step_key"], "role": s["role"], "status": s["status"]}
                        for s in steps
                    ]
                    from ioagentfarm.channels.teams.cards import result_card
                    await _notify(
                        attachment=_card_attachment(
                            result_card(
                                run_id=run_id,
                                status=final_status,
                                summary=summary,
                                steps=step_dicts,
                            )
                        ),
                    )
                    logger.info("Teams: run %s %s — notified thread %s", run_id, final_status, thread_id)
                    return

            except Exception:
                logger.exception("Teams: error polling run %s", run_id)

        logger.warning("Teams: run %s monitoring timed out after %d polls", run_id, max_polls)

    # ------------------------------------------------------------------
    # Background task notification loop
    # ------------------------------------------------------------------

    async def _monitor_tasks_loop(self):
        """Poll for completed tasks and proactively notify users in Teams.

        Runs as a single background coroutine in the web server. Checks every
        30s for tasks with status 'done'/'failed' that haven't been notified.
        Uses atomic claim (mark_task_notified) to prevent duplicate notifications
        across pods. Exits after 30 minutes of no activity to avoid infinite loops
        — restarted by lifespan if needed.
        """
        from ioagentfarm.engine.workspaces import get_agent_name

        poll_interval = 30   # seconds
        max_idle = 60 * 30   # 30 minutes with no completions → restart
        idle_time = 0

        while True:
            await asyncio.sleep(poll_interval)
            try:
                store = self._get_store()
                completed = store.get_completed_tasks_for_notify()

                if not completed:
                    idle_time += poll_interval
                    if idle_time >= max_idle:
                        logger.info("Task notification loop: idle timeout, restarting")
                        idle_time = 0
                    continue

                idle_time = 0  # reset on activity

                for task in completed:
                    task_id = task["task_id"]

                    # Atomic claim — only one pod sends the notification
                    if not store.mark_task_notified(task_id):
                        continue  # another pod already claimed it

                    # Find Teams thread for this task's run
                    run_id = task.get("run_id")
                    if not run_id:
                        continue

                    thread_id = self._state.get_thread_for_run(run_id)
                    if not thread_id:
                        logger.debug("No Teams thread for run %s, skipping notification for task %s", run_id, task_id)
                        continue

                    # Build notification message
                    agent_name = get_agent_name(task["role"])
                    status = task["status"]  # already 'notified' but was 'done'/'failed'
                    snippet = (task.get("output_text") or "")[:500]

                    if "failed" in (task.get("body") or ""):
                        # Task was marked failed before we claimed it
                        text = f"**{agent_name}** task `{task_id}` — **failed**\n\n{snippet}"
                    else:
                        text = (
                            f"**{agent_name}** finished task `{task_id}` ✅\n\n"
                            f"**Summary:**\n{snippet}"
                        )

                    sent = await self._send_proactive(thread_id, text=text)
                    if sent:
                        logger.info("Task notification sent: %s → thread %s", task_id, thread_id)
                    else:
                        logger.warning("Task notification failed: %s → thread %s", task_id, thread_id)

            except Exception:
                logger.debug("Task notification loop error", exc_info=True)

    # ------------------------------------------------------------------
    # Sending messages via REST
    # ------------------------------------------------------------------

    async def _send_reply(
        self, activity: Activity, text: str = "", attachment: Optional[Attachment] = None,
    ) -> None:
        """Send an inline reply to an incoming activity."""
        reply: Dict[str, Any] = {
            "type": "message",
            "from": {
                "id": activity.recipient.id,
                "name": activity.recipient.name,
            },
            "conversation": {
                "id": activity.conversation.id,
            },
            "recipient": {
                "id": activity.from_property.id,
                "name": activity.from_property.name,
            },
            "replyToId": activity.id
        }
        if text:
            reply["text"] = text
        if attachment:
            reply["attachments"] = [attachment.model_dump(by_alias=True, exclude_none=True)]

        conv_id = activity.conversation.id if activity.conversation else ""
        await self._post_activity(activity.service_url or "", conv_id, reply)

    async def _send_typing(self, activity: Activity) -> None:
        """Send a typing indicator."""
        payload = {"type": "typing", "replyToId": activity.id}
        conv_id = activity.conversation.id if activity.conversation else ""
        try:
            await self._post_activity(activity.service_url or "", conv_id, payload)
        except Exception:
            logger.debug("Typing indicator failed (non-critical)")

    async def _post_activity(
        self, service_url: str, conversation_id: str, payload: Dict[str, Any],
    ) -> None:
        """POST an activity to the connector service."""
        if not service_url or not conversation_id:
            logger.warning("Cannot post — missing service_url or conversation_id")
            return

        url = f"{service_url.rstrip('/')}/v3/conversations/{conversation_id}/activities"
        headers: Dict[str, str] = {"Content-Type": "application/json"}

        token = await self._get_access_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        client = self._get_http()
        resp = await client.post(url, json=payload, headers=headers)
        if resp.status_code >= 400:
            logger.warning("POST activity failed: %s %s — %s", resp.status_code, url, resp.text[:200])


    async def _get_access_token(self) -> str:
        if not self._config.is_configured:
            logger.warning("Teams config not set — skipping token")
            return ""

        try:
            import msal

            if self._msal_app is None:
                tenent_id="0975418a-8a70-4df4-8044-1c574a26ffc1"
                authority = f"https://login.microsoftonline.com/{tenent_id}"
                self._msal_app = msal.ConfidentialClientApplication(
                    self._config.app_id,
                    authority=authority,
                    client_credential=self._config.app_secret,
                )

            result = self._msal_app.acquire_token_for_client(
                scopes=["https://api.botframework.com/.default"]
            )

            if "access_token" not in result:
                logger.error("MSAL TOKEN ERROR: %s", result)
                return ""

            token = result["access_token"]
            logger.info("Access token generated (len=%s)", len(token))

            return token

        except Exception as e:
            logger.exception("Token acquisition failed")
            return ""

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _strip_mention(activity: Activity, text: str) -> str:
        """Remove bot @mention from message text."""
        if not activity.entities:
            return text
        bot_id = (activity.recipient or ChannelAccount()).id
        for entity in activity.entities:
            if entity.type == "mention" and entity.mentioned:
                if entity.mentioned.id == bot_id:
                    mention_text = entity.text or ""
                    if mention_text:
                        text = text.replace(mention_text, "").strip()
        return text

    @staticmethod
    def _extract_thread_id(activity: Activity) -> str:
        conv = activity.conversation
        if not conv:
            return activity.id or "unknown"
        return conv.id or activity.id or "unknown"

    @staticmethod
    def _extract_user_id(activity: Activity) -> str:
        fp = activity.from_property
        if not fp:
            return "unknown"
        if fp.aad_object_id:
            return fp.aad_object_id
        return fp.id or "unknown"

    @staticmethod
    def _extract_channel_id(activity: Activity) -> str:
        cd = activity.channel_data or {}
        return cd.get("teamsChannelId", "") if isinstance(cd, dict) else ""

    @staticmethod
    def _build_conversation_reference(activity: Activity) -> Dict[str, Any]:
        def _account(a):
            if not a:
                return None
            return {"id": a.id, "name": a.name}

        def _conv(c):
            if not c:
                return None
            d: Dict[str, Any] = {"id": c.id}
            if c.name:
                d["name"] = c.name
            if c.conversation_type:
                d["conversationType"] = c.conversation_type
            if c.tenant_id:
                d["tenantId"] = c.tenant_id
            return d

        return {
            "bot": _account(activity.recipient),
            "user": _account(activity.from_property),
            "conversation": _conv(activity.conversation),
            "channelId": activity.channel_id or "msteams",
            "serviceUrl": activity.service_url,
        }

    @staticmethod
    def _detect_new_run(store, user_id: str, existing_run_ids: set) -> Optional[str]:
        """Detect a run created by Jarvis during this message processing.

        Compares current runs against the snapshot taken before processing.
        Returns the newest run_id that wasn't in the snapshot, or None.
        """
        current_runs = store.list_runs(user_id=user_id)
        for run in current_runs:
            if run["id"] not in existing_run_ids and run["status"] in ("active", "running"):
                return run["id"]
        return None

    async def shutdown(self) -> None:
        """Close the HTTP client."""
        if self._http and not self._http.is_closed:
            await self._http.aclose()


# ------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------

def _card_attachment(card: Dict[str, Any]) -> Attachment:
    return Attachment(content_type="application/vnd.microsoft.card.adaptive", content=card)
