"""FastAPI router for the MS Teams webhook endpoint.

No external SDK dependency — uses lightweight Activity models and httpx.
JWT validation in production uses PyJWT against Microsoft's JWKS endpoint.

**Emulator mode:** Set ``TEAMS_EMULATOR=true`` to skip auth validation and
test locally with the Agents Playground.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Any, Dict, Optional, Set

from fastapi import APIRouter, Request, Response, HTTPException

from ioagentfarm.channels.teams.bot import TeamsBot
from ioagentfarm.channels.teams.config import TeamsConfig, load_teams_config
from ioagentfarm.channels.teams.models import Activity
from ioagentfarm.channels.teams.state import TeamsState

logger = logging.getLogger(__name__)

# JWKS cache (module-level, shared across requests)
_jwks_cache: Dict[str, Any] = {}
_jwks_cache_ts: float = 0.0
_JWKS_CACHE_TTL = 3600  # 1 hour


def _is_emulator_mode(config: TeamsConfig) -> bool:
    """True when running against the local Agents Playground (no Azure)."""
    if os.getenv("TEAMS_EMULATOR", "").lower() in ("1", "true", "yes"):
        return True
    if config.app_id.lower() == "emulator":
        return True
    return False


# Allowed service URL domains for Bot Framework connector
_ALLOWED_SERVICE_DOMAINS = (
    ".botframework.com",
    ".botframework.azure.us",
    ".botframework.azure.de",
    "localhost",
    "127.0.0.1",
)


async def _get_jwks() -> Dict[str, Any]:
    """Fetch Microsoft's JWKS with caching (1 hour TTL)."""
    global _jwks_cache, _jwks_cache_ts
    now = time.monotonic()
    if _jwks_cache and (now - _jwks_cache_ts) < _JWKS_CACHE_TTL:
        return _jwks_cache

    import httpx
    jwks_url = "https://login.botframework.com/v1/.well-known/keys"
    async with httpx.AsyncClient() as client:
        resp = await client.get(jwks_url, timeout=10)
        _jwks_cache = resp.json()
        _jwks_cache_ts = now
    return _jwks_cache


async def _validate_jwt(auth_header: str, config: TeamsConfig) -> None:
    """Validate a Bot Framework / Agents JWT token.

    Uses PyJWT + Microsoft's cached JWKS endpoint. Raises on invalid token.
    """
    import jwt

    if not auth_header.startswith("Bearer "):
        raise ValueError("Missing Bearer token")

    token = auth_header.split(" ", 1)[1]
    jwks = await _get_jwks()

    # Decode and validate
    header = jwt.get_unverified_header(token)
    kid = header.get("kid", "")
    matching = [k for k in jwks.get("keys", []) if k.get("kid") == kid]
    if not matching:
        raise ValueError(f"No JWKS key found for kid={kid}")

    key = jwt.algorithms.RSAAlgorithm.from_jwk(matching[0])
    claims = jwt.decode(
        token,
        key,
        algorithms=["RS256"],
        audience=config.app_id,
        options={"verify_exp": True},
    )

    # Verify tenant if configured
    if config.tenant_id:
        tid = claims.get("tid", "")
        if tid != config.tenant_id:
            raise ValueError(f"Tenant mismatch: expected {config.tenant_id}, got {tid}")


def build_router(pool: object) -> APIRouter:
    """Construct the Teams APIRouter.

    Parameters
    ----------
    pool : AgentPool
        The shared agent pool from ``ioagentfarm serve``.

    Returns the router AND stores the bot on the router for lifespan access.
    """
    print("In build_router")
    config = load_teams_config()
    emulator = _is_emulator_mode(config)

    if not emulator and not config.is_configured:
        raise RuntimeError(
            "Teams channel requires TEAMS_APP_ID and TEAMS_APP_SECRET env vars "
            "(or set TEAMS_EMULATOR=true for local Agents Playground testing)"
        )

    # DB state
    from ioagentfarm.engine.db import make_adapter
    adapter = make_adapter(os.getenv("IOF_DATABASE_URL", ""))
    state = TeamsState(adapter)
    state.ensure_tables()

    bot = TeamsBot(pool=pool, state=state, config=config)

    if emulator:
        logger.warning("Teams channel in EMULATOR mode — token validation disabled")

    router = APIRouter(prefix="/api/teams", tags=["teams"])
    # Expose bot for lifespan shutdown
    router.teams_bot = bot  # type: ignore[attr-defined]

    # Track background tasks to prevent GC
    _background_tasks: Set[asyncio.Task] = set()

    # ------------------------------------------------------------------
    # POST /api/teams/messages
    # ------------------------------------------------------------------

    @router.post("/messages")
    async def teams_webhook(request: Request):
        """Receive an Activity from Teams / Agents Playground.

        Validates JWT in production, skips in emulator mode.
        Returns 200 immediately; processes the message in the background.
        """
        body = await request.body()
        auth_header = request.headers.get("Authorization", "")

        # Parse the Activity
        try:
            activity_dict = json.loads(body)
            activity = Activity.model_validate(activity_dict)
        except Exception as exc:
            logger.warning("Invalid activity payload: %s", exc)
            raise HTTPException(status_code=400, detail="Invalid activity payload")

        # Validate JWT (production mode — required)
        if not emulator:
            if not auth_header:
                raise HTTPException(status_code=401, detail="Missing Authorization header")
            try:
                await _validate_jwt(auth_header, config)
            except Exception as exc:
                logger.warning("Teams auth failed: %s", exc)
                raise HTTPException(status_code=401, detail="Authentication failed")

        # Dispatch in background — return 200 immediately
        task = asyncio.create_task(bot.handle_activity(activity))
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)

        return Response(status_code=200)

    # ------------------------------------------------------------------
    # GET /api/teams/health
    # ------------------------------------------------------------------

    @router.get("/health")
    async def teams_health():
        return {
            "status": "ok",
            "channel": "teams",
            "configured": config.is_configured,
            "emulator_mode": emulator,
        }

    return router
