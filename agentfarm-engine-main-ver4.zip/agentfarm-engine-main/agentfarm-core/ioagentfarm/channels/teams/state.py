"""Teams-specific DB state: thread-to-run mapping and conversation references."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from ioagentfarm.engine.db import DbAdapter

logger = logging.getLogger(__name__)


class TeamsState:
    """Manages Teams-specific tables using the existing DbAdapter backend.

    Tables:
        teams_thread_map        — maps Teams thread IDs to aicore run IDs
        teams_conversation_refs — stores serialised conversation references
                                  for proactive messaging back to Teams threads
    """

    def __init__(self, db: DbAdapter) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _q(self, sql: str) -> str:
        """Rewrite ``?`` placeholders for the active backend."""
        return sql.replace("?", self._db.placeholder())

    def _conn(self):
        """Get an initialised connection (sets search_path for PostgreSQL)."""
        conn = self._db.connect()
        self._db.init_connection(conn)
        return conn

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def ensure_tables(self) -> None:
        """Create Teams tables if they don't exist (idempotent)."""
        conn = self._conn()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS teams_thread_map (
                    id         {auto_id},
                    thread_id  TEXT NOT NULL UNIQUE,
                    run_id     TEXT NOT NULL,
                    channel_id TEXT NOT NULL DEFAULT '',
                    user_id    TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                )""".format(auto_id=self._db.auto_id())
            )
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS teams_conversation_refs (
                    id               {auto_id},
                    thread_id        TEXT NOT NULL UNIQUE,
                    conversation_ref TEXT NOT NULL,
                    service_url      TEXT NOT NULL DEFAULT '',
                    created_at       TEXT NOT NULL
                )""".format(auto_id=self._db.auto_id())
            )
            conn.commit()
            logger.info("Teams tables ensured")
        finally:
            cursor.close()

    # ------------------------------------------------------------------
    # Thread-to-Run mapping
    # ------------------------------------------------------------------

    def save_thread_mapping(
        self,
        thread_id: str,
        run_id: str,
        channel_id: str = "",
        user_id: str = "",
    ) -> None:
        """Create or update the mapping from a Teams thread to an agentfarm run."""
        conn = self._conn()
        cursor = conn.cursor()
        now = self._now()
        try:
            # Try update first, then insert (portable upsert)
            cursor.execute(
                self._q("UPDATE teams_thread_map SET run_id=?, channel_id=?, user_id=?, created_at=? WHERE thread_id=?"),
                (run_id, channel_id, user_id, now, thread_id),
            )
            if cursor.rowcount == 0:
                cursor.execute(
                    self._q(
                        "INSERT INTO teams_thread_map(thread_id, run_id, channel_id, user_id, created_at) "
                        "VALUES(?,?,?,?,?)"
                    ),
                    (thread_id, run_id, channel_id, user_id, now),
                )
            conn.commit()
        finally:
            cursor.close()

    def get_run_for_thread(self, thread_id: str) -> Optional[str]:
        """Return the run_id associated with a Teams thread, or None."""
        conn = self._conn()
        cursor = conn.cursor()
        try:
            cursor.execute(
                self._q("SELECT run_id FROM teams_thread_map WHERE thread_id=?"),
                (thread_id,),
            )
            row = cursor.fetchone()
            return row["run_id"] if row else None
        finally:
            cursor.close()

    def get_thread_for_run(self, run_id: str) -> Optional[str]:
        """Return the thread_id associated with a run, or None (reverse lookup)."""
        conn = self._conn()
        cursor = conn.cursor()
        try:
            cursor.execute(
                self._q("SELECT thread_id FROM teams_thread_map WHERE run_id=?"),
                (run_id,),
            )
            row = cursor.fetchone()
            return row["thread_id"] if row else None
        finally:
            cursor.close()

    # ------------------------------------------------------------------
    # Conversation references (for proactive messaging)
    # ------------------------------------------------------------------

    def save_conversation_ref(
        self,
        thread_id: str,
        conversation_ref: Dict[str, Any],
        service_url: str = "",
    ) -> None:
        """Store (or update) a serialised conversation reference for a thread."""
        ref_json = json.dumps(conversation_ref)
        conn = self._conn()
        cursor = conn.cursor()
        now = self._now()
        try:
            # Try update first, then insert (portable upsert)
            cursor.execute(
                self._q("UPDATE teams_conversation_refs SET conversation_ref=?, service_url=?, created_at=? WHERE thread_id=?"),
                (ref_json, service_url, now, thread_id),
            )
            if cursor.rowcount == 0:
                cursor.execute(
                    self._q(
                        "INSERT INTO teams_conversation_refs(thread_id, conversation_ref, service_url, created_at) "
                        "VALUES(?,?,?,?)"
                    ),
                    (thread_id, ref_json, service_url, now),
                )
            conn.commit()
        finally:
            cursor.close()

    def get_conversation_ref(self, thread_id: str) -> Optional[Dict[str, Any]]:
        """Return the conversation reference dict for a thread, or None."""
        conn = self._conn()
        cursor = conn.cursor()
        try:
            cursor.execute(
                self._q(
                    "SELECT conversation_ref, service_url "
                    "FROM teams_conversation_refs WHERE thread_id=?"
                ),
                (thread_id,),
            )
            row = cursor.fetchone()
            if not row:
                return None
            return {
                "conversation_ref": json.loads(row["conversation_ref"]),
                "service_url": row["service_url"],
            }
        finally:
            cursor.close()
