"""Teams channel configuration."""

from __future__ import annotations

import os
from pydantic import BaseModel, Field


class TeamsConfig(BaseModel):
    """Configuration for the MS Teams channel.

    All values are read from environment variables at startup.
    """

    app_id: str = Field(default="", description="Azure Bot registration App ID")
    app_secret: str = Field(default="", description="Azure Bot registration secret")
    tenant_id: str = Field(
        default="",
        description="Azure AD tenant ID (single-tenant restriction)",
    )

    @property
    def is_configured(self) -> bool:
        return bool(self.app_id and self.app_secret)


def load_teams_config() -> TeamsConfig:
    """Load Teams config from environment variables."""
    return TeamsConfig(
        app_id=os.getenv("TEAMS_APP_ID", ""),
        app_secret=os.getenv("TEAMS_APP_SECRET", ""),
        tenant_id=os.getenv("TEAMS_TENANT_ID", ""),
    )
