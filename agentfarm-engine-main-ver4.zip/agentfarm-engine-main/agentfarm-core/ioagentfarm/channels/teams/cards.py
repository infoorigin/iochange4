"""Adaptive Card builders for Teams channel.

Each function returns a Python dict representing an Adaptive Card JSON payload
ready to be wrapped in a Bot Framework ``Attachment``.
"""

from __future__ import annotations

from typing import Any, Dict, List


_SCHEMA = "http://adaptivecards.io/schemas/adaptive-card.json"
_VERSION = "1.4"


def _card(body: List[Dict[str, Any]], actions: List[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    """Base Adaptive Card wrapper."""
    card: Dict[str, Any] = {
        "$schema": _SCHEMA,
        "type": "AdaptiveCard",
        "version": _VERSION,
        "body": body,
    }
    if actions:
        card["actions"] = actions
    return card


# ------------------------------------------------------------------
# Welcome
# ------------------------------------------------------------------

def welcome_card() -> Dict[str, Any]:
    """Shown when the bot is added to a channel or 1:1 conversation."""
    return _card(
        body=[
            {
                "type": "TextBlock",
                "text": "AgentFarm",
                "size": "Large",
                "weight": "Bolder",
            },
            {
                "type": "TextBlock",
                "text": (
                    "I'm your AI team lead. Tell me what you need — "
                    "I'll route it to the right agent or start a workflow."
                ),
                "wrap": True,
            },
            {
                "type": "TextBlock",
                "text": "**Examples:**",
                "spacing": "Medium",
            },
            {
                "type": "TextBlock",
                "text": (
                    "- _Analyze the Q3 shipping data for late ASNs_\n"
                    "- _Match resumes for the Sr. Data Eng role_\n"
                    "- _What's the status of my last run?_"
                ),
                "wrap": True,
            },
        ],
    )


# ------------------------------------------------------------------
# Thinking / ACK
# ------------------------------------------------------------------

def thinking_card() -> Dict[str, Any]:
    """Placeholder while the agent is processing."""
    return _card(
        body=[
            {
                "type": "TextBlock",
                "text": "Working on it...",
                "isSubtle": True,
                "spacing": "None",
            },
        ],
    )


# ------------------------------------------------------------------
# Progress (per-step)
# ------------------------------------------------------------------

_STATUS_ICONS = {
    "pending": "\u25cb",   # ○
    "running": "\u23f3",   # ⏳
    "done": "\u2705",      # ✅
    "failed": "\u274c",    # ❌
    "skipped": "\u23ed",   # ⏭
}


def progress_card(
    step_name: str,
    role: str,
    agent_name: str,
    status: str,
    output_snippet: str = "",
    run_id: str = "",
) -> Dict[str, Any]:
    """Step completion update posted to a thread."""
    icon = _STATUS_ICONS.get(status, "\u2753")
    body: List[Dict[str, Any]] = [
        {
            "type": "ColumnSet",
            "columns": [
                {
                    "type": "Column",
                    "width": "auto",
                    "items": [{"type": "TextBlock", "text": icon, "size": "Medium"}],
                },
                {
                    "type": "Column",
                    "width": "stretch",
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": f"**{step_name}** ({agent_name})",
                            "wrap": True,
                        },
                        {
                            "type": "TextBlock",
                            "text": status,
                            "isSubtle": True,
                            "spacing": "None",
                        },
                    ],
                },
            ],
        },
    ]
    if output_snippet:
        body.append(
            {
                "type": "TextBlock",
                "text": output_snippet[:500],
                "wrap": True,
                "size": "Small",
                "spacing": "Small",
            }
        )
    return _card(body)


# ------------------------------------------------------------------
# Run started
# ------------------------------------------------------------------

def run_started_card(
    run_id: str,
    workflow: str,
    goal: str,
    steps: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Posted when a new workflow run is created from a Teams message."""
    step_lines = []
    for s in steps:
        icon = _STATUS_ICONS.get(s.get("status", "pending"), "\u25cb")
        step_lines.append(f"{icon} {s.get('step_key', '?')} ({s.get('role', '?')})")

    return _card(
        body=[
            {
                "type": "TextBlock",
                "text": f"Workflow: **{workflow}**",
                "size": "Medium",
                "weight": "Bolder",
            },
            {
                "type": "TextBlock",
                "text": goal[:300],
                "wrap": True,
                "isSubtle": True,
            },
            {
                "type": "FactSet",
                "facts": [
                    {"title": "Run", "value": run_id},
                    {"title": "Steps", "value": str(len(steps))},
                ],
            },
            {
                "type": "TextBlock",
                "text": "\n".join(step_lines),
                "wrap": True,
                "fontType": "Monospace",
                "size": "Small",
                "spacing": "Medium",
            },
            {
                "type": "TextBlock",
                "text": "I'll update this thread as I progress.",
                "isSubtle": True,
                "spacing": "Medium",
            },
        ],
    )


# ------------------------------------------------------------------
# Result (final)
# ------------------------------------------------------------------

def result_card(
    run_id: str,
    status: str,
    summary: str,
    steps: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Final run result card."""
    icon = "\u2705" if status == "done" else "\u274c"
    step_lines = []
    for s in steps:
        si = _STATUS_ICONS.get(s.get("status", "pending"), "\u25cb")
        step_lines.append(f"{si} {s.get('step_key', '?')} — {s.get('status', '?')}")

    body: List[Dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": f"{icon} Run {status.upper()}",
            "size": "Medium",
            "weight": "Bolder",
            "color": "Good" if status == "done" else "Attention",
        },
        {
            "type": "TextBlock",
            "text": summary[:1000],
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": "\n".join(step_lines),
            "wrap": True,
            "fontType": "Monospace",
            "size": "Small",
            "spacing": "Medium",
        },
        {
            "type": "FactSet",
            "facts": [{"title": "Run ID", "value": run_id}],
        },
    ]
    return _card(body)


# ------------------------------------------------------------------
# Error
# ------------------------------------------------------------------

def feedback_card(
    step_key: str,
    role: str,
    agent_name: str,
    run_id: str,
    output_snippet: str = "",
) -> Dict[str, Any]:
    """Step result with feedback buttons (thumbs up / thumbs down / correct it)."""
    body: List[Dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": f"**{step_key}** ({agent_name}) — done",
            "wrap": True,
        },
    ]
    if output_snippet:
        body.append(
            {
                "type": "TextBlock",
                "text": output_snippet[:500],
                "wrap": True,
                "size": "Small",
            }
        )
    actions = [
        {
            "type": "Action.Submit",
            "title": "\U0001f44d Helpful",
            "data": {
                "action": "skill_feedback",
                "signal": "positive",
                "run_id": run_id,
                "step_key": step_key,
                "role": role,
            },
        },
        {
            "type": "Action.Submit",
            "title": "\U0001f44e Wrong",
            "data": {
                "action": "skill_feedback",
                "signal": "negative",
                "run_id": run_id,
                "step_key": step_key,
                "role": role,
            },
        },
        {
            "type": "Action.ShowCard",
            "title": "\u270f\ufe0f Correct it",
            "card": _card(
                body=[
                    {
                        "type": "Input.Text",
                        "id": "correction_text",
                        "placeholder": "What should be different?",
                        "isMultiline": True,
                    },
                ],
                actions=[
                    {
                        "type": "Action.Submit",
                        "title": "Submit correction",
                        "data": {
                            "action": "skill_feedback",
                            "signal": "correction",
                            "run_id": run_id,
                            "step_key": step_key,
                            "role": role,
                        },
                    },
                ],
            ),
        },
    ]
    return _card(body, actions)


# ------------------------------------------------------------------
# Error
# ------------------------------------------------------------------

def error_card(message: str) -> Dict[str, Any]:
    """Error display."""
    return _card(
        body=[
            {
                "type": "TextBlock",
                "text": "Something went wrong",
                "weight": "Bolder",
                "color": "Attention",
            },
            {
                "type": "TextBlock",
                "text": message[:500],
                "wrap": True,
            },
        ],
    )
