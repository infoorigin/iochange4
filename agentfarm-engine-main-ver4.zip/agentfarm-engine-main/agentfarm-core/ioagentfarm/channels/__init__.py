"""Channel adapters for iobot gateway integration."""
