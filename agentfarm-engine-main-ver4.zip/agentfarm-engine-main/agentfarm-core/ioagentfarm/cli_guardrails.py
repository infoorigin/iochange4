"""``aicore guardrails`` - what the chat guardrails would do to a message.

Two commands. ``check`` runs one message through the resolved policy and
prints the decision, the redacted text and the flags - the same code path
``POST /api/chat/{ns}`` runs, so an operator can see why a turn was refused
without sending it to the engine. ``show`` prints the policy in force and
the file it came from, or says that none is declared.

Deterministic and offline: neither command needs a database, a model or a
running engine. Output is ASCII.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import typer

app = typer.Typer(help="Chat guardrails: the policy in force, and what it does to a message.")


def _policy(workspace: Optional[str]):
    from ioagentfarm.engine.guardrails import PolicyError, load_policy
    try:
        return load_policy(workspace)
    except PolicyError as e:
        typer.echo(f"guardrails policy error: {e}", err=True)
        raise typer.Exit(code=2)


@app.command("show")
def show(workspace: Optional[str] = typer.Option(
             None, "--workspace", "-w", help="Workspace code (default: the one in force)."),
         as_json: bool = typer.Option(False, "--json", help="Print the policy as JSON.")):
    """Print the resolved policy and where it came from."""
    from ioagentfarm.engine.guardrails import ENV_VAR, FILE_NAME
    policy = _policy(workspace)
    if policy is None:
        typer.echo("no guardrails policy is declared; every chat surface runs unguarded.")
        typer.echo(f"declare one at {ENV_VAR}=<path> or ~/.iobot/workspaces/<code>/{FILE_NAME}")
        return
    d = policy.describe()
    if as_json:
        typer.echo(json.dumps(d, indent=2))
        return
    typer.echo(f"source:                  {d['source']}")
    typer.echo(f"input.prompt_injection:  {d['input']['prompt_injection']}")
    typer.echo(f"input.pii:               {d['input']['pii']}")
    typer.echo(f"input.deny_patterns:     {d['input']['deny_patterns'] or '(none)'}")
    typer.echo(f"output.pii:              {d['output']['pii']}")
    typer.echo(f"output.disclaimer:       {d['output']['disclaimer'] or '(none)'}")
    typer.echo(f"phi:                     {'true' if d['phi'] else 'false'}")


@app.command("check")
def check(text: Optional[str] = typer.Argument(None, help="The message to check."),
          file: Optional[Path] = typer.Option(
              None, "--file", "-f", help="Read the message from a file instead."),
          workspace: Optional[str] = typer.Option(
              None, "--workspace", "-w", help="Workspace code (default: the one in force)."),
          as_json: bool = typer.Option(False, "--json", help="Print the decision as JSON.")):
    """Run one message through the policy: decision, redacted text, flags."""
    if file is not None:
        text = file.read_text(encoding="utf-8")
    if text is None:
        typer.echo("give the message as an argument or with --file", err=True)
        raise typer.Exit(code=2)
    policy = _policy(workspace)
    if policy is None:
        typer.echo("no guardrails policy is declared; the message would reach the model unchanged.")
        raise typer.Exit(code=0)
    d = policy.check_input(text)
    if as_json:
        out = d.to_dict()
        out["output_preview"] = policy.filter_output("").text if policy.disclaimer else ""
        typer.echo(json.dumps(out, indent=2))
    else:
        typer.echo(f"policy:   {policy.source}")
        typer.echo(f"decision: {d.action}")
        if d.reason:
            typer.echo(f"reason:   {d.reason}")
            typer.echo(f"detail:   {d.detail}")
        typer.echo(f"flags:    {', '.join(d.flags) if d.flags else '(none)'}")
        if d.action != "refuse":
            typer.echo("text the model would receive:")
            typer.echo("  " + d.text.replace("\n", "\n  "))
        if policy.disclaimer:
            typer.echo(f"reply disclaimer: {policy.disclaimer}")
    sys.stdout.flush()
    raise typer.Exit(code=1 if d.action == "refuse" else 0)
