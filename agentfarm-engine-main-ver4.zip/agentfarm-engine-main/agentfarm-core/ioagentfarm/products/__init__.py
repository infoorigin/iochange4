# savants — brand definitions for Savant Strategy Lab
# Each sub-directory is a brand with product.yaml, skills/, and missions/.
