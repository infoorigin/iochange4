"""Forensics CLI — Phase 4 of the forensic observability work.

User-facing commands for inspecting the structured event log and the
per-attempt blob directories. Mounted as a typer sub-app at::

    aicore forensics show <run_id>
    aicore forensics tail <run_id>
    aicore forensics blob <run_id> <step.attempt> <name>
    aicore forensics list

Design principles
-----------------
* Read-only — no commands here mutate state. Pruning lives in a separate
  command (out of scope for this phase).
* Human-readable by default, ``--json`` for machine consumption.
* Defaults are tuned for the common case ("what happened to my last failed
  run?") — `forensics list --failed` shows recent failures, `forensics show`
  produces a timeline you can scan in 5 seconds.
* Resilient to missing data — every blob lookup is wrapped, every event read
  is best-effort. The CLI must work even if the forensics dir is partially
  populated (the run is still in flight).
"""
from __future__ import annotations

import json
import re
import os
import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

forensics_app = typer.Typer(
    name="forensics",
    help="Inspect the forensic event log and per-attempt blob directories.",
    no_args_is_help=True,
)

_console = Console()


@forensics_app.callback()
def _resolve_workspace_first(ctx: typer.Context) -> None:
    """Load the workspace env BEFORE any subcommand touches the database.

    `get_forensics()` reads IOF_DATABASE_URL from the environment and falls
    back to a local SQLite file when it is unset — and that variable lives in
    the workspace's own .env, which only the workspace resolver loads. Without
    this callback every forensics command opened an EMPTY local database on a
    Postgres deployment and reported `db: unavailable (filesystem-only view)`.

    That is honest, unlike the same defect in `supervise` which reported
    nothing at all, but the degradation was unnecessary: `explain` is the
    documented first resort for "what happened", and filesystem-only costs it
    the event timeline, the run status, swarm children, and the run.coverage
    census — the record of what a run did NOT process.

    Fails soft on purpose. Forensics is what you reach for when things are
    already broken, so an unresolvable workspace must still give the
    filesystem-only view rather than refuse to run.
    """
    try:
        from ioagentfarm.cli import _workspace_code, local_mode
        code = _workspace_code()
        # LOCALISE THE DATABASE THE WAY `run` DID. `run` calls local_mode()
        # before opening the store, so a local-mode workspace's runs live in
        # ITS `.iof/state.db`; this callback resolved the workspace and
        # stopped there, so `explain` opened whatever database the ambient
        # environment named, found no such run, and "degraded gracefully" -
        # a 7/7 done run reported as `status: unknown` with
        # `agent_premature_termination` on every step. The first resort for
        # "what happened" answered the wrong database and did not say so.
        local_mode(code=code)
    except Exception:
        pass


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _ghost_run(run_id: str) -> bool:
    """True when the database is reachable and knows no such run - the
    difference between a missing record and a mistyped id (exit 3)."""
    try:
        from ioagentfarm.cli import _store as _cli_store
        _cli_store(_root()).get_run(run_id)
        return False
    except KeyError:
        return True
    except Exception:  # noqa: BLE001
        return False


def _gate_digest_mismatches_now(run_id: str) -> list:
    """Re-verify each passed gate's recorded deliverable digest against the
    file on disk RIGHT NOW.

    The run-end re-check (``cli_orchestration._recheck_gates_at_run_end``)
    only fires at the done-transition, so a process a step left behind that
    tampers with a declared artifact AFTER the run completed slips past it -
    on a single-step run, the gate-pass and the done-transition are
    microseconds apart, so almost any detached child wins that race (novice
    re-cert, round 7 B-3). ``explain`` is a READ, so re-verifying the recorded
    digest here catches the tamper whenever anyone looks. Returns
    ``[{step_key, diffs: [{artifact, what}]}]``. Never raises.
    """
    import hashlib
    gate_dir = _root() / "instances" / run_id / "gate"
    out_dir = _root() / "instances" / run_id / "project"
    out: list = []
    if not gate_dir.is_dir():
        return out
    for gf in sorted(gate_dir.glob("*.json")):
        try:
            rec = json.loads(gf.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        diffs = []
        for name, d0 in (rec.get("digests") or {}).items():
            try:
                now_sha = hashlib.sha256((out_dir / name).read_bytes()).hexdigest()
            except OSError:
                now_sha = None
            if now_sha != (d0 or {}).get("sha256"):
                diffs.append({"artifact": name,
                              "what": "missing" if now_sha is None else "changed"})
        if diffs:
            out.append({"step_key": rec.get("step_key"), "diffs": diffs})
    return out


def _root() -> Path:
    """Resolve IOF_ROOT - THE convention, not the same one written again.

    This used to be a byte-identical copy of `cli._root`, as was
    `cli_workspace._root`. Local-mode adoption was added to the resolver and
    reached one of the three, so `forensics explain`, `forensics tokens` and
    `forensics watch` kept reading the shared database while the operator had
    been told the workspace was local - the blobs on disk and the run row in
    the database describing different runs.

    Deferred import because `cli` imports this module at load.
    """
    from ioagentfarm.cli import _root as _cli_root

    return _cli_root()


def _forensics():
    from ioagentfarm.engine.forensics import get_forensics
    return get_forensics(_root())


def _severity_marker(sev: str) -> str:
    """Return a colored marker for a severity (Rich markup)."""
    return {
        "info":  "[dim]-[/dim]",
        "warn":  "[yellow]![/yellow]",
        "error": "[red]X[/red]",
        "fatal": "[red bold]F[/red bold]",
    }.get(sev, "?")


def _task_dir(run_id: str, task_ref: str) -> Path:
    """Resolve a TASK forensics directory from a ``task:<task_id>[.<n>]`` ref.

    Layout (written by ``run-task`` when linked to a run):
    ``<root>/instances/<run_id>/forensics/tasks/<task_id>.<n>/``.
    Without an explicit ``.<n>``, the LATEST n that exists wins (n=1 when
    none exist, so error messages name the path that would have been).
    """
    ref = task_ref[len("task:"):]
    tasks_root = _root() / "instances" / run_id / "forensics" / "tasks"
    if "." in ref:
        return tasks_root / ref
    latest = None
    if tasks_root.exists():
        for p in sorted(tasks_root.iterdir()):
            if p.is_dir() and p.name.startswith(ref + "."):
                latest = p
    return latest if latest is not None else tasks_root / f"{ref}.1"


def _attempt_dir(run_id: str, step_attempt: str) -> Path:
    """Resolve a per-attempt forensics directory.

    ``step_attempt`` can be ``analyze.1`` (the directory name), ``analyze``
    (defaults to attempt 1), or ``task:<task_id>[.<n>]`` for an ad-hoc task
    captured by ``run-task`` (latest ``<n>`` when omitted).

    Three layouts are supported:

    * Workflow/swarm runs (``cli_orchestration.run_step``):
      ``<root>/instances/<run_id>/forensics/attempts/<step.attempt>/``
    * Ad-hoc tasks (``run-task`` with ``--run-id``):
      ``<root>/instances/<run_id>/forensics/tasks/<task_id>.<n>/``
    * Agentfarm sessions (``session_engine.forensics``):
      ``<root>/savant/<session_id>/forensics/attempts/<step.attempt>/``

    We pick whichever layout actually exists. If neither directory exists,
    we return the workflow path so error messages stay consistent with
    the historical behaviour.
    """
    if step_attempt.startswith("task:"):
        return _task_dir(run_id, step_attempt)
    # FOLD THE KEY THE WAY THE WRITER DID. A fan-out step's key is
    # `story:fv_trx_vs_plan:reason`, and the forensics writer folds ':' to
    # '_' because Windows cannot create a directory containing ':' at all.
    # This reader took the key verbatim, so `narrative <run> story:x:reason`
    # looked for a directory that can never exist and reported "no
    # session-snapshot.jsonl" for an attempt whose bundle was right there.
    # `explain` names steps by their real key, which is what a person then
    # pastes here - the two have to agree.
    from ioagentfarm.cli_orchestration import safe_step_key
    step_attempt = safe_step_key(step_attempt)
    if "." not in step_attempt:
        step_attempt = f"{step_attempt}.1"
    workflow_path = (
        _root() / "instances" / run_id / "forensics"
        / "attempts" / step_attempt
    )
    session_path = (
        _root() / "savant" / run_id / "forensics"
        / "attempts" / step_attempt
    )
    if not workflow_path.exists() and session_path.exists():
        return session_path
    return workflow_path


def _trim(line: str, n: int = 240) -> str:
    """Keep the END of a long line - on a Windows path the file name is the
    last thing on it, and a head-cut lost exactly that (novice finding)."""
    line = (line or "").strip()
    if len(line) <= n:
        return line
    return line[:80] + " ... " + line[-(n - 86):]


def _exec_failure(run_id: str, step_key: str) -> dict:
    """What a command step's own record says about why it failed.

    A `type: exec` / `route` step has no session snapshot; its record is
    the stderr the engine keeps beside OUTPUT.md, and OUTPUT.md itself.
    Classified into the vocabulary FAILURE_TRANSLATIONS speaks, with the
    decisive line as detail - so the verdict reads "the command exited
    non-zero - FileNotFoundError: ... plann.json" instead of "see the
    step's session snapshot". Empty when there is no record.
    """
    safe = step_key.replace(":", "_").replace("/", "_")
    sdir = _root() / "runs" / run_id / "steps" / safe
    try:
        err = (sdir / "_exec_stderr.log").read_text(encoding="utf-8", errors="replace")
    except OSError:
        err = ""
    try:
        out = (sdir / "OUTPUT.md").read_text(encoding="utf-8", errors="replace")
    except OSError:
        out = ""
    if not err and not out:
        return {}
    lines = [ln.strip() for ln in err.splitlines() if ln.strip()]
    both = err + "\n" + out
    low = both.lower()
    if "timed out after" in low:
        src = next((ln for ln in both.splitlines() if "timed out after" in ln.lower()), "")
        return {"reason": "exec_timeout", "detail": _trim(src.strip().strip("[]"))}
    if ("is not recognized as an internal or external command" in low
            or "command not found" in low
            or "failed to launch command" in low):
        return {"reason": "command_not_found", "detail": _trim(lines[-1] if lines else "")}
    _m = re.search(r"exec step failed \(exit code (-?\d+)\)", out)
    if _m and int(_m.group(1)) in (143, 137, -15, -9, 130):
        return {"reason": "exec_killed", "detail": _trim(f"exit code {_m.group(1)}")}
    if lines:
        return {"reason": "exec_nonzero", "detail": _trim(lines[-1])}
    if "STATUS: failed" not in out:
        return {}
    if "exec step completed" in out:
        # rc 0, and the tool printed its own STATUS: failed on stdout
        tail = out.split("--- stdout (tail) ---", 1)[-1]
        outl = [ln.strip() for ln in tail.splitlines() if ln.strip().startswith("OUTPUT:")]
        return {"reason": "exec_reported_failed",
                "detail": _trim(outl[-1] if outl else "STATUS: failed on stdout")}
    outl = [ln.strip() for ln in out.splitlines() if ln.strip().startswith("OUTPUT:")]
    return {"reason": "exec_nonzero", "detail": _trim(outl[-1] if outl else "")}


def _forensics_attempts_root(run_id: str) -> Optional[Path]:
    """Return the forensics ``attempts/`` dir for a run_id, regardless of
    whether it's a workflow run (instances/) or an agentfarm session (savant/).

    Returns None if neither exists.
    """
    workflow_root = _root() / "instances" / run_id / "forensics" / "attempts"
    session_root = _root() / "savant" / run_id / "forensics" / "attempts"
    if workflow_root.exists():
        return workflow_root
    if session_root.exists():
        return session_root
    return None


def _forensics_tasks_root(run_id: str) -> Optional[Path]:
    """The ``forensics/tasks/`` dir for a run (ad-hoc task blobs), or None."""
    tasks_root = _root() / "instances" / run_id / "forensics" / "tasks"
    return tasks_root if tasks_root.exists() else None


def _short_ts(ts: str) -> str:
    """Trim ISO timestamps to HH:MM:SS for compact tables."""
    if not ts:
        return ""
    # Expect ISO8601 like "2026-04-11T11:41:21.736517+00:00"
    if "T" in ts:
        try:
            return ts.split("T", 1)[1].split(".", 1)[0]
        except Exception:
            return ts[:19]
    return ts[:19]


# ----------------------------------------------------------------------
# forensics list
# ----------------------------------------------------------------------


@forensics_app.command("list")
def forensics_list(
    limit: int = typer.Option(20, "--limit", "-n", help="Max number of runs to show"),
    only_failed: bool = typer.Option(
        False, "--failed", help="Only show runs with at least one error/fatal event",
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Emit machine-readable JSON instead of a table",
    ),
):
    """List recent runs that have forensic events, newest first.

    Useful as the entry point: \"what failed recently?\". Combine with
    ``--failed`` to skip clean runs.
    """
    rows = _forensics().list_runs(limit=limit, only_failed=only_failed)
    if json_output:
        typer.echo(json.dumps(rows, indent=2, default=str))
        return

    if not rows:
        _console.print(
            "[dim]No forensic events found"
            + (" (failed runs only)" if only_failed else "")
            + ". Has the run been instrumented yet?[/dim]"
        )
        return

    table = Table(title="Recent runs (forensic events)")
    table.add_column("run_id", style="cyan", no_wrap=True)
    table.add_column("events", justify="right")
    table.add_column("warn", justify="right", style="yellow")
    table.add_column("error", justify="right", style="red")
    table.add_column("fatal", justify="right", style="red bold")
    table.add_column("first -> last (UTC)", style="dim")
    for r in rows:
        table.add_row(
            r["run_id"],
            str(r.get("event_count") or 0),
            str(r.get("warn_count") or 0),
            str(r.get("error_count") or 0),
            str(r.get("fatal_count") or 0),
            f"{_short_ts(r.get('first_ts',''))} -> {_short_ts(r.get('last_ts',''))}",
        )
    _console.print(table)


# ----------------------------------------------------------------------
# forensics show
# ----------------------------------------------------------------------


@forensics_app.command("show")
def forensics_show(
    run_id: str = typer.Argument(..., help="The run_id to inspect"),
    step_key: Optional[str] = typer.Option(
        None, "--step", "-s",
        help="Limit to a single step (e.g. 'analyze')",
    ),
    attempt: Optional[int] = typer.Option(
        None, "--attempt", "-a", help="Limit to a single attempt (with --step)",
    ),
    severity: Optional[str] = typer.Option(
        None, "--severity",
        help="Minimum severity: info|warn|error|fatal",
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Emit machine-readable JSON instead of a table",
    ),
):
    """Reconstruct the timeline for a run.

    The output is the merged event log: every step.started, subprocess
    exit, OUTPUT.md write/missing, protocol parse failure, etc., in
    chronological order. Each event lists the per-attempt blob dir if
    relevant - use ``forensics blob`` to dump a specific blob.
    """
    # An unknown run printed an empty table and exit 0 (novice, round 6).
    # Checked against the database when one is reachable; the
    # filesystem-only degradation keeps working without it.
    try:
        from ioagentfarm.cli import _store as _cli_store
        _cli_store(_root()).get_run(run_id)
    except KeyError:
        typer.echo(f"No run '{run_id}' in this database. `aicore status` lists recent runs.", err=True)
        raise typer.Exit(code=3)
    except Exception:  # noqa: BLE001
        pass
    f = _forensics()
    if step_key:
        events = f.get_step_timeline(run_id, step_key, attempt=attempt)
    else:
        events = f.get_run_timeline(run_id, severity_min=severity)

    if json_output:
        typer.echo(json.dumps(events, indent=2, default=str))
        return

    if not events:
        _console.print(
            f"[dim]No forensic events for run {run_id}"
            + (f" step={step_key}" if step_key else "")
            + ". Either the run is too old (pre-Phase 3) or it never ran.[/dim]"
        )
        return

    table = Table(
        title=f"Forensic timeline - {run_id}"
        + (f" / {step_key}" if step_key else ""),
    )
    table.add_column("", width=1)  # severity marker
    table.add_column("ts (UTC)", style="dim", no_wrap=True)
    # `overflow="fold"` on the two wide columns: at 80 columns a fan-out key
    # like `story:fv_trx_vs_plan:reason.2` was cut to "story:fv_trx_..." and
    # the message to twelve characters, which a novice read as the tool
    # being broken. Folding keeps every character on screen.
    table.add_column("step.attempt", style="cyan", overflow="fold",
                     max_width=30)
    table.add_column("event", style="bold", no_wrap=True)
    table.add_column("message", overflow="fold")

    for e in events:
        sev = e.get("severity") or "info"
        sk = e.get("step_key") or "-"
        at = e.get("attempt")
        sa = f"{sk}.{at}" if at is not None else sk
        msg = e.get("message") or ""
        # Truncate long messages — full payload is in the JSON view
        if len(msg) > 110:
            msg = msg[:107] + "..."
        table.add_row(
            _severity_marker(sev),
            _short_ts(e.get("ts", "")),
            sa,
            e.get("event_type") or "",
            msg,
        )
    _console.print(table)

    # Summary footer: counts by severity, blob hint
    sev_counts = {}
    for e in events:
        sev_counts[e.get("severity", "info")] = sev_counts.get(e.get("severity", "info"), 0) + 1
    summary = " ".join(f"{k}:{v}" for k, v in sev_counts.items())
    _console.print(f"[dim]{summary} | {len(events)} events total[/dim]")
    forensics_root = _forensics_attempts_root(run_id)
    if forensics_root is not None:
        attempts = sorted(p.name for p in forensics_root.iterdir() if p.is_dir())
        if attempts:
            kind = "session" if forensics_root.parts[-3] == run_id and "savant" in forensics_root.parts else "run"
            _console.print(
                f"[dim]Blob dirs available ({kind}): {', '.join(attempts)} "
                f"(use 'forensics blob {run_id} <step.attempt> <name>' to inspect)[/dim]"
            )


# ----------------------------------------------------------------------
# forensics tail
# ----------------------------------------------------------------------


@forensics_app.command("tail")
def forensics_tail(
    run_id: str = typer.Argument(..., help="The run_id to follow"),
    interval: float = typer.Option(
        1.0, "--interval", "-i",
        help="Poll interval in seconds (events are append-only)",
    ),
    severity: Optional[str] = typer.Option(
        None, "--severity",
        help="Minimum severity: info|warn|error|fatal",
    ),
):
    """Follow forensic events for an in-flight run (live tail).

    Polls the DB at ``--interval`` seconds and prints any new events.
    Stops when interrupted with Ctrl+C. Useful for watching a long-running
    procurement run progress through its steps.
    """
    # A mistyped id used to tail forever — the loop polls an empty timeline
    # and nothing says the run does not exist, so a paged operator watches a
    # blank screen (novice finding, round 8). `explain`/`show` already reject
    # a ghost; `tail` now does too.
    if _ghost_run(run_id):
        typer.echo(f"No run '{run_id}' in this database. `aicore status --all` lists recent runs.", err=True)
        raise typer.Exit(code=3)
    f = _forensics()
    last_ts: Optional[str] = None
    seen_ids: set = set()
    _console.print(f"[dim]Tailing forensic events for {run_id} (Ctrl+C to stop)[/dim]")
    try:
        while True:
            events = f.get_run_timeline(
                run_id, since_ts=last_ts, severity_min=severity,
            )
            for e in events:
                eid = e.get("event_id")
                if eid in seen_ids:
                    continue
                seen_ids.add(eid)
                last_ts = e.get("ts") or last_ts
                sev = e.get("severity") or "info"
                sk = e.get("step_key") or "-"
                at = e.get("attempt")
                sa = f"{sk}.{at}" if at is not None else sk
                marker = _severity_marker(sev)
                msg = e.get("message") or ""
                if len(msg) > 140:
                    msg = msg[:137] + "..."
                _console.print(
                    f"{marker} [dim]{_short_ts(e.get('ts',''))}[/dim] "
                    f"[cyan]{sa}[/cyan] [bold]{e.get('event_type','')}[/bold]  {msg}"
                )
            time.sleep(interval)
    except KeyboardInterrupt:
        _console.print("\n[dim]stopped.[/dim]")


# ----------------------------------------------------------------------
# forensics is-recovering  (Alex ↔ Fix 6 coordination)
# ----------------------------------------------------------------------


@forensics_app.command("is-recovering")
def forensics_is_recovering(
    run_id: str = typer.Argument(..., help="The run_id to inspect"),
    step_key: str = typer.Argument(..., help="Step key (e.g. 'analyze', 'strategize', 'review')"),
):
    """Binary answer: is this step currently being handled by Fix 6 / a live subprocess?

    The definitive check Alex must run BEFORE invoking ``step-retry`` or
    ``step-retry --crash-recovery``. Prevents the Alex-vs-Fix-6 race where
    Alex spawns a parallel subprocess on a step that's already recovering
    silently via the in-step auto-retry layer.

    The logic is structural, not time-based:

    - Find the LATEST ``step.started`` event for (run_id, step_key).
    - If no matching ``step.finalized`` event exists for that same attempt,
      the subprocess is still alive OR Fix 6 is handling the retry.
      -> ``is_recovering=true`` (HANDS OFF, keep polling next-step).
    - If the latest attempt HAS been finalized, the step has completed a
      full lifecycle and Alex may decide what to do next.
      -> ``is_recovering=false``.

    Output:

    - stdout: JSON with ``is_recovering``, ``reason``, ``latest_attempt``,
      ``latest_event``, ``events_since_start``.
    - exit code: ``0`` if safe to intervene (not recovering), ``10`` if
      step is recovering (do not intervene).

    Shell idiom Alex should use::

        if aicore forensics is-recovering <run_id> <step_key>; then
            # exit 0 -> safe to step-retry (not recovering)
            step-retry --step-key <step_key>
        else
            # exit 10 -> Fix 6 is handling it, do nothing
            sleep 30 && next-step
        fi
    """
    events = _forensics().get_step_timeline(run_id, step_key)

    # DB-status override (supervisor interplay). The structural check below
    # ("latest step.started without a matching step.finalized ⇒ recovering")
    # has a blind spot: a subprocess KILLED mid-flight (pod eviction, chaos,
    # OOM) never emits step.finalized, so the step would read as "recovering"
    # FOREVER — observed live: the run supervisor reaped a killed step back
    # to 'pending', and the resurrected driver then waited indefinitely on
    # is_recovering=true instead of re-delegating. The store is the
    # authority: run-step claims a step (status='running') BEFORE emitting
    # step.started, so a step sitting at 'pending' provably has NO live
    # executor and NO active Fix-6 — it is waiting to be delegated.
    try:
        from ioagentfarm.cli import _root, _store
        _step_rows = _store(_root()).list_steps(run_id)
        _row = next((s for s in _step_rows if s["step_key"] == step_key), None)
        if _row is not None and _row["status"] == "pending":
            result = {
                "is_recovering": False,
                "reason": "step_pending_no_executor",
                "detail": (
                    "Step status is 'pending' in the store — any prior "
                    "subprocess is gone (finished, crashed, or reaped by the "
                    "run supervisor). Safe to delegate via run-step."
                ),
                "step_key": step_key,
                "run_id": run_id,
                "latest_attempt": int(_row.get("attempt") or 0),
                "latest_event": events[-1].get("event_type") if events else None,
                "events_since_start": 0,
            }
            typer.echo(json.dumps(result))
            raise typer.Exit(code=0)
    except typer.Exit:
        raise
    except Exception:
        pass  # store unavailable — fall back to the structural check

    if not events:
        result = {
            "is_recovering": False,
            "reason": "no_events_for_step",
            "step_key": step_key,
            "run_id": run_id,
            "latest_attempt": None,
            "latest_event": None,
            "events_since_start": 0,
        }
        typer.echo(json.dumps(result))
        raise typer.Exit(code=0)

    # Find the LATEST step.started event and its attempt number.
    latest_started_idx: Optional[int] = None
    latest_started_attempt: Optional[int] = None
    for i, e in enumerate(events):
        if e.get("event_type") == "step.started":
            latest_started_idx = i
            latest_started_attempt = e.get("attempt")

    if latest_started_idx is None:
        # Events exist but no step.started — pre-subprocess phase.
        result = {
            "is_recovering": False,
            "reason": "never_started",
            "step_key": step_key,
            "run_id": run_id,
            "latest_attempt": None,
            "latest_event": events[-1].get("event_type"),
            "events_since_start": 0,
        }
        typer.echo(json.dumps(result))
        raise typer.Exit(code=0)

    # Slice events at/after the latest step.started.
    post_start = events[latest_started_idx:]

    # Is there a step.finalized event for this exact attempt in that slice?
    finalized = False
    for e in post_start:
        if (
            e.get("event_type") == "step.finalized"
            and e.get("attempt") == latest_started_attempt
        ):
            finalized = True
            break

    latest_event = post_start[-1].get("event_type") if post_start else None
    events_since_start = len(post_start)

    if finalized:
        result = {
            "is_recovering": False,
            "reason": "latest_attempt_finalized",
            "step_key": step_key,
            "run_id": run_id,
            "latest_attempt": latest_started_attempt,
            "latest_event": latest_event,
            "events_since_start": events_since_start,
        }
        typer.echo(json.dumps(result))
        raise typer.Exit(code=0)

    # Not finalized — classify WHY it's still in flight.
    post_start_types = [e.get("event_type") for e in post_start]
    if "step.auto_retry_after_stall" in post_start_types:
        reason = "fix6_auto_retry_active"
    elif "step.subprocess_exited" in post_start_types:
        # Subprocess exited but _finalize_step hasn't emitted its event yet —
        # Fix 6 may be about to kick off the retry, or finalization is
        # queued. Either way, Alex should NOT touch this.
        reason = "finalizing_or_fix6_deciding"
    else:
        reason = "subprocess_running"

    result = {
        "is_recovering": True,
        "reason": reason,
        "step_key": step_key,
        "run_id": run_id,
        "latest_attempt": latest_started_attempt,
        "latest_event": latest_event,
        "events_since_start": events_since_start,
    }
    typer.echo(json.dumps(result))
    raise typer.Exit(code=10)


# ----------------------------------------------------------------------
# forensics blob
# ----------------------------------------------------------------------


@forensics_app.command("blob")
def forensics_blob(
    run_id: str = typer.Argument(..., help="The run_id"),
    step_attempt: str = typer.Argument(
        ..., help="step.attempt e.g. 'analyze.1' (or just 'analyze' for attempt 1)",
    ),
    name: Optional[str] = typer.Argument(
        None,
        help=(
            "Blob name: stdout.log | stderr.log | prompt.txt | env-snapshot.json "
            "| exit.json | session-snapshot.jsonl | output-md-snapshot.txt. "
            "Omit to list all blobs in the dir."
        ),
    ),
):
    """Dump a specific blob from a per-attempt forensics directory.

    Pass without ``name`` to list available blobs. The output is raw
    file contents - pipe through ``less`` or redirect to a file as
    needed. Binary blobs (stdout.log) are written to stdout as bytes.
    """
    blob_dir = _attempt_dir(run_id, step_attempt)
    if not blob_dir.exists():
        _console.print(
            f"[red]No forensics dir at {blob_dir}[/red]\n"
            f"[dim]Hint: run 'ioagentfarm forensics show {run_id}' "
            f"to see what attempts exist.[/dim]"
        )
        raise typer.Exit(code=3 if _ghost_run(run_id) else 1)

    if name is None:
        # List mode
        files = sorted(p.name for p in blob_dir.iterdir() if p.is_file())
        if not files:
            _console.print(f"[dim]Empty: {blob_dir}[/dim]")
            return
        _console.print(f"[bold]Blobs in {blob_dir}:[/bold]")
        for fname in files:
            size = (blob_dir / fname).stat().st_size
            _console.print(f"  {fname}  [dim]({size:,} bytes)[/dim]")
        return

    blob_path = blob_dir / name
    if not blob_path.exists():
        _console.print(
            f"[red]Blob not found: {blob_path}[/red]\n"
            f"[dim]Available: {sorted(p.name for p in blob_dir.iterdir() if p.is_file())}[/dim]"
        )
        raise typer.Exit(code=1)

    # Binary blobs (raw stdout/stderr from the byte-mode reader) → write
    # to stdout buffer to preserve bytes. Text blobs → decode and print.
    binary_blobs = {"stdout.log"}
    if name in binary_blobs:
        sys.stdout.buffer.write(blob_path.read_bytes())
        sys.stdout.flush()
    else:
        try:
            content = blob_path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            _console.print(f"[red]Failed to read {blob_path}: {e}[/red]")
            raise typer.Exit(code=1)
        sys.stdout.write(content)
        sys.stdout.flush()


# ----------------------------------------------------------------------
# Shared helpers for stats/narrative (deterministic extractors)
# ----------------------------------------------------------------------


def _read_json_file(p: Path) -> Optional[dict]:
    """Best-effort JSON read. Returns None on any failure."""
    try:
        return json.loads(p.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return None


def _walk_session_stats(session_path: Path) -> dict:
    """Walk a session-snapshot.jsonl and return aggregate counts.

    Handles both post-exit role-tagged format and inflight metadata
    checkpoint wrappers - same unwrap logic as ``parse_session_failure``.
    """
    stats = {
        "session_lines": 0,
        "user_messages": 0,
        "assistant_turns": 0,
        "tool_results": 0,
        "tool_calls_total": 0,
        "tool_calls_by_name": {},
        "tool_calls_by_target": {},
        "last_assistant_text": "",
        "last_assistant_tool_calls": 0,
        "wrote_output_md": False,
    }
    if not session_path.exists():
        return stats
    try:
        with open(session_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return stats
    stats["session_lines"] = len(lines)
    for ln in lines:
        try:
            obj = json.loads(ln)
        except Exception:
            continue
        if obj.get("_type") == "metadata":
            ckpt = (obj.get("metadata") or {}).get("runtime_checkpoint")
            if not ckpt:
                continue
            asst = ckpt.get("assistant_message")
            if not asst or asst.get("role") != "assistant":
                continue
            obj = asst
        role = obj.get("role")
        if role == "user":
            stats["user_messages"] += 1
        elif role == "tool":
            stats["tool_results"] += 1
        elif role == "assistant":
            stats["assistant_turns"] += 1
            text = (obj.get("content") or "").strip()
            tcs = obj.get("tool_calls") or []
            stats["last_assistant_text"] = text
            stats["last_assistant_tool_calls"] = len(tcs)
            for tc in tcs:
                stats["tool_calls_total"] += 1
                fn = tc.get("function") or {}
                name = fn.get("name") or "?"
                stats["tool_calls_by_name"][name] = (
                    stats["tool_calls_by_name"].get(name, 0) + 1
                )
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except Exception:
                    args = {}
                target = None
                if name in ("write_file", "read_file"):
                    target = args.get("path")
                    if target and name == "write_file" and "OUTPUT.md" in target:
                        stats["wrote_output_md"] = True
                elif name in ("exec", "shell", "bash"):
                    cmd = args.get("command") or args.get("cmd") or ""
                    target = (cmd.split() or ["?"])[0][:32]
                if target:
                    key = f"{name}:{target}"
                    stats["tool_calls_by_target"][key] = (
                        stats["tool_calls_by_target"].get(key, 0) + 1
                    )
    return stats


# ----------------------------------------------------------------------
# forensics stats — deterministic per-attempt metrics extractor
# ----------------------------------------------------------------------


@forensics_app.command("stats")
def forensics_stats(
    run_id: str = typer.Argument(..., help="The run_id to extract stats for"),
    pretty: bool = typer.Option(
        False, "--pretty", help="Render as human-readable tables instead of JSON",
    ),
):
    """Extract deterministic per-attempt metrics from a run's forensic blobs.

    Hard-facts counterpart to ``forensics show``. Instead of a timeline,
    emits a structured JSON document with per-step per-attempt counters
    (tool calls, session sizes, outcome, retries). Designed to be consumed
    by the forensic_analysis workflow where Analyst needs objective numbers
    without parsing JSONLs by hand.
    """
    from ioagentfarm.engine.forensics import parse_session_failure

    attempts_root = _forensics_attempts_root(run_id)
    if attempts_root is None:
        _console.print(
            f"[red]No forensics attempts dir for {run_id}[/red]\n"
            f"[dim]Looked under instances/<id>/ and savant/<id>/. "
            f"Either the run is too old (pre-Phase 3) or the id is wrong.[/dim]"
        )
        raise typer.Exit(code=3 if _ghost_run(run_id) else 1)

    result: dict = {"run_id": run_id, "steps": {}, "totals": {}}
    total_wall = 0.0
    total_tool_calls = 0
    total_retries = 0
    failed_attempts = 0

    for attempt_dir in sorted(attempts_root.iterdir()):
        if not attempt_dir.is_dir():
            continue
        name = attempt_dir.name
        if "." not in name:
            continue
        step_key, attempt_num = name.rsplit(".", 1)
        try:
            attempt_num_int = int(attempt_num)
        except ValueError:
            continue

        exit_info = _read_json_file(attempt_dir / "exit.json") or {}

        if isinstance(exit_info, dict) and 'rc' in exit_info and 'exit_code' not in exit_info:

            exit_info['exit_code'] = exit_info.get('rc')   # a command step's record (older exit.json)
        session_stats = _walk_session_stats(attempt_dir / "session-snapshot.jsonl")
        failure = parse_session_failure(attempt_dir / "session-snapshot.jsonl") or {}

        output_md_size = None
        output_snapshot = attempt_dir / "output-md-snapshot.txt"
        if output_snapshot.exists():
            try:
                output_md_size = output_snapshot.stat().st_size
            except Exception:
                pass

        stall_dirs = sorted(
            d for d in attempt_dir.iterdir()
            if d.is_dir() and d.name.startswith("stall_attempt_")
        )
        preserved_retries = []
        for sd in stall_dirs:
            sd_exit = _read_json_file(sd / "exit.json") or {}
            sd_session = _walk_session_stats(sd / "session-snapshot.jsonl")
            sd_failure = parse_session_failure(sd / "session-snapshot.jsonl") or {}
            preserved_retries.append({
                "stall_attempt": sd.name,
                "exit_code": sd_exit.get("exit_code"),
                "duration_s": sd_exit.get("duration_s"),
                "failure_reason": sd_failure.get("reason"),
                "tool_calls_total": sd_session.get("tool_calls_total", 0),
                "session_lines": sd_session.get("session_lines", 0),
            })

        duration = exit_info.get("duration_s") or 0
        total_wall += duration
        total_tool_calls += session_stats.get("tool_calls_total", 0)
        total_retries += len(preserved_retries)
        if exit_info.get("exit_code") not in (None, 0) or failure.get("reason"):
            failed_attempts += 1

        attempt_entry = {
            "attempt": attempt_num_int,
            "exit_code": exit_info.get("exit_code"),
            "duration_s": duration,
            "signal_killed": exit_info.get("signal_killed", False),
            "started_at": exit_info.get("started_at"),
            "ended_at": exit_info.get("ended_at"),
            "session_lines": session_stats.get("session_lines", 0),
            "user_messages": session_stats.get("user_messages", 0),
            "assistant_turns": session_stats.get("assistant_turns", 0),
            "tool_calls_total": session_stats.get("tool_calls_total", 0),
            "tool_calls_by_name": session_stats.get("tool_calls_by_name", {}),
            "tool_calls_by_target_top": dict(sorted(
                session_stats.get("tool_calls_by_target", {}).items(),
                key=lambda kv: -kv[1],
            )[:10]),
            "wrote_output_md": session_stats.get("wrote_output_md", False),
            "output_md_snapshot_bytes": output_md_size,
            "last_assistant_tool_calls": session_stats.get("last_assistant_tool_calls", 0),
            "last_assistant_text_preview": (session_stats.get("last_assistant_text") or "")[:240],
            "failure_reason": failure.get("reason"),
            "failure_pattern": failure.get("matched_pattern"),
            "preserved_stall_retries": preserved_retries,
        }
        result["steps"].setdefault(step_key, []).append(attempt_entry)

    for step_key in result["steps"]:
        result["steps"][step_key].sort(key=lambda a: a["attempt"])

    # Ad-hoc task blobs (run-task with --run-id) — same extractors, own
    # section so a task never masquerades as a workflow step.
    tasks_root = _forensics_tasks_root(run_id)
    if tasks_root is not None:
        tasks_out = {}
        for td in sorted(tasks_root.iterdir()):
            if not td.is_dir() or "." not in td.name:
                continue
            t_exit = _read_json_file(td / "exit.json") or {}
            t_sess = _walk_session_stats(td / "session-snapshot.jsonl")
            t_fail = parse_session_failure(td / "session-snapshot.jsonl") or {}
            tasks_out[td.name] = {
                "exit_code": t_exit.get("exit_code"),
                "duration_s": t_exit.get("duration_s"),
                "tool_calls_total": t_sess.get("tool_calls_total", 0),
                "assistant_turns": t_sess.get("assistant_turns", 0),
                "failure_reason": t_fail.get("reason"),
            }
        if tasks_out:
            result["tasks"] = tasks_out

    result["totals"] = {
        "wall_clock_s": round(total_wall, 2),
        "tool_calls_total": total_tool_calls,
        "auto_retries": total_retries,
        "failed_attempts": failed_attempts,
        "total_step_attempts": sum(len(v) for v in result["steps"].values()),
    }

    if not pretty:
        typer.echo(json.dumps(result, indent=2, default=str))
        return

    _console.print(f"[bold]Forensic stats - {run_id}[/bold]")
    t = result["totals"]
    _console.print(
        f"[dim]wall_clock: {t['wall_clock_s']}s  |  "
        f"tool_calls: {t['tool_calls_total']}  |  "
        f"auto_retries: {t['auto_retries']}  |  "
        f"failed_attempts: {t['failed_attempts']}  |  "
        f"total_attempts: {t['total_step_attempts']}[/dim]\n"
    )
    for step_key, attempts in result["steps"].items():
        table = Table(title=step_key)
        table.add_column("att", justify="right")
        table.add_column("rc", justify="right")
        table.add_column("dur_s", justify="right")
        table.add_column("asst", justify="right")
        table.add_column("tool_calls", justify="right")
        table.add_column("OUTPUT.md", justify="center")
        table.add_column("failure", style="red")
        table.add_column("stalls", justify="right")
        for a in attempts:
            rc = a.get("exit_code")
            table.add_row(
                str(a["attempt"]),
                str(rc) if rc is not None else "-",
                f"{a.get('duration_s', 0):.1f}",
                str(a.get("assistant_turns", 0)),
                str(a.get("tool_calls_total", 0)),
                "Y" if a.get("wrote_output_md") else "N",
                (a.get("failure_reason") or ""),
                str(len(a.get("preserved_stall_retries") or [])),
            )
        _console.print(table)


# ----------------------------------------------------------------------
# forensics explain — the one-command postmortem
# ----------------------------------------------------------------------

#: Failure reasons (parse_session_failure vocabulary) -> plain English.
#: This table used to live as prose inside Jarvis's run_diagnostics skill;
#: it belongs in the deterministic layer so every consumer (CLI, skills,
#: tests) reads ONE translation.
FAILURE_TRANSLATIONS = {
    # command (exec / route) steps - derived from the step's own stderr
    "exec_timeout": "the command exceeded the step's timeout and was stopped",
    "command_not_found": ("the command is not on PATH - the tools package is "
                          "not installed in this environment (`pip install "
                          "-e .` in the workspace repo), or the name in "
                          "`command:` is wrong"),
    "exec_nonzero": "the command exited non-zero",
    "exec_killed": ("the command was KILLED (an interruption - a stop, a kill, a "
                    "reboot - not a defect in the step)"),
    "exec_reported_failed": ("the command exited 0 but printed `STATUS: failed` on "
                             "stdout - the tool itself reported failure"),
    "artifact_missing": ("the step reported done but a required artifact was "
                         "missing or empty in the shared artifact directory"),
    "route_undeclared": "the route step chose a step outside its `routes:` list",
    "route_missing": ("the route step ended without choosing a route (no "
                      "`route.next(...)` call, no ROUTE_JSON line)"),
    "on_fail_exhausted": ("the on_fail loop used up this gate step's own "
                          "max_attempts (the reset step's re-runs are free)"),
    "llm_stream_stalled": (
        "the LLM provider stopped sending tokens for 90+ seconds mid-response "
        "(iobot's stream watchdog fired); usually single-shot composition of "
        "a large deliverable - the sectioned-composition pattern avoids it"),
    "llm_request_failed": (
        "the LLM provider rejected or dropped the request mid-flight; "
        "transient provider-side failure, auto-retried by Fix 6"),
    "llm_connection_error": (
        "the HTTP connection to the LLM provider broke mid-response "
        "(wire-level, e.g. malformed response bytes); not a network outage on "
        "our side - fresh-request retry is the fix and Fix 6 does it"),
    "max_tool_iterations": (
        "the agent hit the session's tool-iteration cap before finishing - "
        "either the goal is too broad for the budget or the agent looped; "
        "raise budget.tool_calls or narrow the goal"),
    "context_window_exceeded": (
        "the conversation outgrew the model's context window; the step needs "
        "smaller working sets (aggregate in SQL, summarize between phases)"),
    "llm_rate_limited": (
        "the LLM provider rate-limited the request; backoff-and-retry "
        "territory, not a defect in the run"),
    "llm_auth_failed": (
        "the LLM provider refused the credentials; check the provider key in "
        "the runtime config - nothing about this run itself is at fault"),
    "llm_generic_error": (
        "iobot recorded a generic LLM error as the final turn; the exact "
        "cause is in the attempt's http.log"),
    "agent_premature_termination": (
        "the agent's final turn had no tool call and no STATUS marker, so the "
        "agent loop read it as 'done talking' and exited with no work product; "
        "an agent-protocol miss, auto-retried by Fix 6"),
}

#: Failure reasons whose wire-level cause lives in http.log.
_CONNECTION_SHAPED = {"llm_connection_error", "llm_request_failed",
                     "llm_stream_stalled", "llm_generic_error"}


def _iter_usage_rows(run_id: str):
    """Yield parsed usage.jsonl rows for a run (empty when absent/bad)."""
    usage_file = _root() / "instances" / run_id / "usage.jsonl"
    if not usage_file.is_file():
        return
    try:
        lines = usage_file.read_text(encoding="utf-8").splitlines()
    except Exception:
        return
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
        except Exception:
            continue


def _usage_totals(run_id: str) -> dict:
    """Sum usage.jsonl into the explain schema's usage block."""
    totals = {"available": False, "calls": 0, "in": 0, "out": 0,
              "cache_read": 0, "cache_write": 0}
    for d in _iter_usage_rows(run_id):
        totals["available"] = True
        totals["calls"] += 1
        totals["in"] += int(d.get("in", 0) or 0)
        totals["out"] += int(d.get("out", 0) or 0)
        totals["cache_read"] += int(d.get("cr", 0) or 0)
        totals["cache_write"] += int(d.get("cw", 0) or 0)
    return totals


def _read_snapshot_markers(run_id: str) -> dict:
    """The run snapshot's swarm markers: {kind, budget, agents} (best-effort).

    A compiled swarm's ``workflow.yaml`` carries loader-ignored marker keys;
    the raw YAML is their only carrier, so explain reads it directly - the
    same convention create_filtered_workspace and create_instance_config use.
    """
    out: dict = {}
    try:
        import yaml as _yaml
        wf_yaml = _root() / "instances" / run_id / "workflow" / "workflow.yaml"
        if wf_yaml.exists():
            data = _yaml.safe_load(
                wf_yaml.read_text(encoding="utf-8-sig")) or {}
            if isinstance(data, dict):
                out = data
    except Exception:
        pass
    return out


def _read_json_utf8sig(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except Exception:
        return None


def _hms(seconds) -> str:
    """`70.4s` is readable; `1523.0s` is not. Minutes matter to a reader."""
    try:
        s = float(seconds)
    except (TypeError, ValueError):
        return str(seconds)
    if s < 90:
        return f"{s:.1f}s"
    m, sec = divmod(int(s), 60)
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m" if h else f"{m}m{sec:02d}s"



def _append_spend_without_attempt_note(result: dict) -> None:
    """Say so when model calls were spent that no step attempt accounts for.

    A driver killed or cancelled mid-attempt leaves its step reading
    `pending, attempt 0` while the usage file already holds the calls it
    spent - 17 in one joint-stability run, 20 in another - so `explain`
    described a step that had never started and an operator had no idea money
    had been spent. The numbers were already in the document; nothing put
    them together.

    THE KEY IS `attempts`, PLURAL. Reading the singular made the condition
    true of EVERY run, so a run that converged 2/2 with both attempts
    recorded was told 21 calls had gone unrecorded and its driver had been
    interrupted - contradicting the verdict printed two lines above it. Split
    out of the inline block it used to be so it can be tested at all, which
    is why the misspelling survived.
    """
    try:
        calls = int((result.get("usage") or {}).get("calls") or 0)
        steps = result.get("steps") or []
        if not (calls and steps):
            return
        if not all(int(s.get("attempts") or 0) == 0 for s in steps):
            return
        result["verdict"] = ((result.get("verdict") or "").rstrip()
                             + f" NOTE: {calls} model call(s) were spent"
                               " with no attempt recorded against any"
                               " step - the driver was interrupted before"
                               " it could report one, so the work is in"
                               " the console log, not the step record.")
        result["spent_without_attempt"] = calls
    except Exception:                      # noqa: BLE001 - never break explain
        pass


def _build_explain(run_id: str) -> dict:
    """Compose the one-document postmortem for a run. Pure and read-only.

    Everything here is derived from EXISTING capture: the run/steps rows,
    the forensic timeline, per-attempt blobs, usage.jsonl, and (for swarms)
    the run's project-dir artifacts. DB unavailability degrades to a
    filesystem-only view with an explicit ``"db": "unavailable"`` field -
    never an exception.
    """
    from ioagentfarm.engine.forensics import parse_session_failure

    result: dict = {"run_id": run_id}
    markers = _read_snapshot_markers(run_id)

    # --- DB layer (best-effort) ------------------------------------------
    run_row = None
    step_rows: list = []
    db_available = True
    db_why = ""
    try:
        from ioagentfarm.cli import _root as _cli_root, _store
        _resolved_root = _cli_root()
        store = _store(_resolved_root)
        run_row = store.get_run(run_id)
        step_rows = store.list_steps(run_id)
    except Exception as exc:
        db_available = False
        # SAY WHY, AND SAY WHICH ROOT WAS TRIED. This swallowed the reason,
        # so "db: unavailable" was a dead end for everyone who met it —
        # including the Core Assistant, which can only report what the
        # command tells it. The root is the load-bearing detail: `_root()`
        # falls back to `.iof` RELATIVE TO THE CURRENT DIRECTORY, so a
        # command run from somewhere other than the project (an agent's
        # exec'd tool runs in the agent's workspace) silently looks for a
        # database that was never there. Printing the path turns that from
        # an unanswerable state into an obvious one.
        try:
            _root_shown = str(_cli_root())
        except Exception:                    # pragma: no cover - defensive
            _root_shown = "(unresolvable)"
        db_why = f"{type(exc).__name__}: {exc}".strip()
        result["db_root"] = _root_shown
        result["db_error"] = db_why
        if isinstance(exc, KeyError):
            # the database answered; it has no such run - not "unavailable"
            result["missing_run"] = True
    if not db_available:
        result["db"] = "unavailable"
    # A run whose driver died reads `running` forever; say so, by the
    # supervisor's own clock (novice finding, round 3).
    try:
        if run_row and run_row.get("status") == "running":
            from ioagentfarm.engine.supervisor import driver_state
            result["driver_state"] = driver_state(run_row, step_rows)
    except Exception:  # noqa: BLE001
        pass

    kind = ((run_row or {}).get("kind")
            or ("swarm" if markers.get("kind") == "swarm" else "workflow"))
    result["kind"] = kind
    result["status"] = (run_row or {}).get("status", "unknown")
    result["goal"] = (run_row or {}).get("goal", "")
    result["driver"] = (run_row or {}).get("driver") or "agent"
    result["workflow"] = (run_row or {}).get("workflow_name",
                                             markers.get("name", ""))

    # --- content provenance (filesystem-only; never raises) ----------------
    # WHICH pack/version/commit the run was created from, read from the
    # provenance.json the creation seam writes (docs/one-truth-content-model
    # section 3.3). A run older than that file says so honestly rather than
    # guessing from what is installed NOW - which may not be what ran.
    try:
        from ioagentfarm.engine.content import run_content_line
        result["content"] = run_content_line(_root(), run_id)
    except Exception:   # pragma: no cover - run_content_line is itself fail-open
        result["content"] = "(not recorded)"

    # --- timeline (never raises; [] when DB is down) ----------------------
    # get_run_timeline self-protects, but get_forensics() itself can raise
    # on an unusable adapter — the degraded view must survive that too.
    try:
        events = _forensics().get_run_timeline(run_id)
    except Exception:
        events = []
    sev_counts = {"warn": 0, "error": 0, "fatal": 0}
    last_error = None
    for e in events:
        sev = e.get("severity")
        if sev in sev_counts:
            sev_counts[sev] += 1
        if sev in ("error", "fatal"):
            last_error = e.get("message")
    result["events"] = {**sev_counts, "last_error": last_error}
    artifact_events: dict = {}
    for e in events:
        if e.get("event_type") in ("step.artifact_missing", "step.artifact_gate_passed") and e.get("step_key"):
            artifact_events.setdefault(e["step_key"], []).append(e)
    # Events that CLASSIFY a failure the engine itself decided, a false
    # alarm the engine later withdrew, and the one warning a green run can
    # carry. Read once here; the per-step loop consults them.
    _classifying = {"step.route_undeclared": "route_undeclared",
                    "step.route_missing": "route_missing",
                    "step.on_fail_exhausted": "on_fail_exhausted",
                    "step.hard_cap_reached": "hard_attempt_cap_reached"}
    classified: dict = {}
    false_alarms: set = set()
    route_warnings: list = []
    reset_gates: set = set()      # steps whose on_fail sent others back
    reaped: set = set()           # steps the supervisor reset after a crash
    recovery: list = []           # what recovered this run, in order
    closed_steps: set = set()     # steps a route closed (never ran)
    exec_writes: dict = {}        # step -> files that CHANGED during its attempt
    exec_declares: dict = {}      # step -> its requires_artifacts (what it owns)
    for e in events:
        et, sk = e.get("event_type"), e.get("step_key")
        if et in _classifying and sk:
            classified[sk] = (_classifying[et], _trim(e.get("message") or "", 300))
        elif et == "step.retry_not_needed" and sk:
            false_alarms.add(sk)
        elif et in ("step.route_target_already_ran", "step.fanout_empty",
                    "run.shared_project_dir", "step.stories_unconsumed",
                    "run.artifact_changed_after_gate", "step.route_ambiguous",
                    "step.reaped_on_resume", "run.interrupted"):
            route_warnings.append(e.get("message") or et)
        elif et == "step.reset_on_fail" and sk:
            reset_gates.add(sk)
        elif et == "supervisor.step_reaped" and sk:
            reaped.add(sk)
            recovery.append(f"step '{sk}' reaped by the supervisor ({_trim(e.get('message') or '', 120)})")
        elif et in ("supervisor.driver_resumed", "run.resumed", "run.spawn_failed"):
            recovery.append(f"{et}: {_trim(e.get('message') or '', 160)}")
        elif et == "step.routed":
            try:
                _rp = json.loads(e.get("payload_json") or "{}")
            except Exception:  # noqa: BLE001
                _rp = {}
            closed_steps.update(str(x) for x in (_rp.get("skipped") or []))
            if not (_rp.get("chosen") or []):
                route_warnings.append(
                    f"route '{sk}' chose nothing - it closed "
                    f"{sorted(_rp.get('skipped') or [])}; the run did no work "
                    "past it. If that is not the intent, the tool must name a route")
        elif et in ("step.exec_completed", "step.exec_failed") and sk:
            try:
                _pl = json.loads(e.get("payload_json") or "{}")
            except Exception:  # noqa: BLE001
                _pl = {}
            exec_writes.setdefault(sk, set()).update(str(x) for x in (_pl.get("wrote") or []))
            exec_declares.setdefault(sk, set()).update(str(x) for x in (_pl.get("declares") or []))

    # --- per-step view from blobs (+ DB rows when present) ----------------
    attempts_root = _forensics_attempts_root(run_id)
    per_step: dict = {}
    if attempts_root is not None:
        for d in sorted(attempts_root.iterdir()):
            if not d.is_dir() or "." not in d.name:
                continue
            step_key, _, n = d.name.rpartition(".")
            try:
                n_int = int(n)
            except ValueError:
                continue
            per_step.setdefault(step_key, []).append((n_int, d))

    step_rows_by_key = {s["step_key"]: s for s in step_rows}

    # A blob directory is named with the SANITIZED step key - `:` and `/` are
    # illegal in a Windows path - while the database keeps the real one. Union
    # them naively and every fan-out step appears TWICE: once as
    # `story:G01:detect` with its real verdict, and once as
    # `story_G01_detect` with no role and verdict `unknown`. On Windows that
    # happens to every loop workflow, so a 5-step run reads as 8 steps, three
    # of them apparently unexplained. Map each blob key back onto the row it
    # belongs to before unioning.
    _sanitized_to_real = {k.replace(":", "_").replace("/", "_"): k
                          for k in step_rows_by_key}
    for blob_key in list(per_step):
        real = _sanitized_to_real.get(blob_key)
        if real and real != blob_key:
            per_step.setdefault(real, []).extend(per_step.pop(blob_key))

    all_keys = list(dict.fromkeys(
        [s["step_key"] for s in step_rows] + sorted(per_step)))

    steps_out = []
    total_duration = 0.0
    shared_writes: dict = {}   # project-relative path -> {step keys that wrote it}
    # A command step records the files that CHANGED while it ran. Under a
    # parallel driver a producer's file lands during a consumer's window
    # too, so a file DECLARED by one step (its requires_artifacts) belongs
    # to that step alone; only undeclared files can be ambiguous.
    _owner = {}
    for _sk, _decl in exec_declares.items():
        for _f in _decl:
            _owner.setdefault(_f, set()).add(_sk)
    for _sk, _files in exec_writes.items():
        for _f in _files:
            if _owner.get(_f) and _sk not in _owner[_f]:
                continue
            shared_writes.setdefault(_f, set()).add(_sk)
    first_failed: Optional[dict] = None
    for key in all_keys:
        row = step_rows_by_key.get(key)
        attempts = sorted(per_step.get(key, []))
        duration = 0.0
        stall_retries = 0
        failure = {}
        tool_calls = 0
        wrote_output = False
        latest_dir: Optional[Path] = None
        latest_n = None
        killed_attempt = False
        for n_int, d in attempts:
            latest_dir, latest_n = d, n_int
            exit_info = _read_json_file(d / "exit.json") or {}
            if exit_info.get("rc") in (143, 137, -15, -9, 130):
                killed_attempt = True
            duration += float(exit_info.get("duration_s") or 0)
            stall_retries += sum(
                1 for sd in d.iterdir()
                if sd.is_dir() and sd.name.startswith("stall_attempt_"))
        is_exec = any((_read_json_file(_d / "exit.json") or {}).get("kind")
                      == "exec" for _n, _d in attempts)
        if (latest_dir is not None
                and (latest_dir / "session-snapshot.jsonl").exists()):
            failure = parse_session_failure(
                latest_dir / "session-snapshot.jsonl") or {}
            sess = _walk_session_stats(latest_dir / "session-snapshot.jsonl")
            tool_calls = sess.get("tool_calls_total", 0)
            wrote_output = sess.get("wrote_output_md", False)
            for _k in (sess.get("tool_calls_by_target") or {}):
                if not _k.startswith("write_file:"):
                    continue
                _p = _k[len("write_file:"):].replace("\\", "/")
                if "/project/" in _p:
                    shared_writes.setdefault(
                        _p.rsplit("/project/", 1)[1], set()).add(key)
        total_duration += duration

        status = (row or {}).get("status") or "unknown"
        # A command step has no session to parse: its record is its own
        # stderr, or the event by which the engine failed it. Found by a
        # novice reading "see the step's session snapshot" for a step that
        # never had one.
        if status == "failed" and not failure.get("reason"):
            failure = ({"reason": classified[key][0], "detail": classified[key][1]}
                       if key in classified else _exec_failure(run_id, key) or {})
            if str(failure.get("reason", "")).startswith(("exec_", "command_")):
                is_exec = True
        elif status == "done" and key in false_alarms:
            # the engine withdrew the stall reason - the step is fine, and
            # the column must not read `agent_premature_termination` beside
            # a verdict of ok
            failure = {}
        gate = "n/a"
        # THE GATE IS ONLY THE CAUSE WHEN THE GATE ACTUALLY REFUSED (round 9,
        # S6-1). `artifact_events` holds BOTH `step.artifact_missing` and
        # `step.artifact_gate_passed`, so "this step has an artifact event and
        # is not done" was true of a step whose gate PASSED and which then
        # failed for some other reason. A gated route step choosing an
        # undeclared target had its cause - already correctly classified from
        # `step.route_undeclared` a dozen lines above - overwritten with
        # `artifact_missing`, and the detail read `missing: ?` because it was
        # reading a passed gate's payload for a list of missing files that
        # does not exist there. The timeline held the truth the whole time;
        # the headline contradicted it, which is worse than saying nothing.
        _gate_refused = bool(
            artifact_events.get(key)
            and artifact_events[key][-1].get("event_type") == "step.artifact_missing")
        if key in artifact_events:
            if status == "done":
                gate = "passed"
            elif not _gate_refused:
                # failed, but not here: the gate passed and something later
                # (a route, on_fail, the attempt cap) failed the step.
                gate = "passed"
            else:
                missing = []
                try:
                    payload = json.loads(
                        artifact_events[key][-1].get("payload_json") or "{}")
                    missing = payload.get("missing") or []
                    _looked = payload.get("output_dir")
                except Exception:
                    _looked = None
                gate = "failed:" + (missing[0] if missing else "?")
                # the gate IS the failure: name the file, say whether it was
                # missing or empty, and where the gate looked
                try:
                    _pl2 = json.loads(artifact_events[key][-1].get("payload_json") or "{}")
                except Exception:  # noqa: BLE001
                    _pl2 = {}
                _mf, _ef = _pl2.get("missing_files"), _pl2.get("empty_files")
                if _mf is not None or _ef:
                    _what = "; ".join(x for x in (
                        f"missing: {', '.join(_mf)}" if _mf else "",
                        f"empty (0 bytes): {', '.join(_ef)}" if _ef else "") if x)
                else:
                    _what = "missing: " + (", ".join(missing) or "?")
                failure = {"reason": "artifact_missing",
                           "detail": _trim(_what + (f" - looked in {_looked}" if _looked else ""), 300)}
        reason = failure.get("reason")
        if status == "done" and key in closed_steps and not attempts:
            verdict = "closed"      # a route did not choose it; it never ran
        elif status == "done":
            verdict = "ok_after_retries" if stall_retries else "ok"
        elif status == "failed":
            # `gate_failed` means the GATE refused it, not "it failed and it
            # happens to have a gate" - see _gate_refused above.
            verdict = "gate_failed" if _gate_refused else "failed"
        else:
            verdict = status
        try:
            _meta = json.loads((row or {}).get("meta_json") or "{}")
        except Exception:  # noqa: BLE001
            _meta = {}
        entry = {
            "key": key,
            "role": (row or {}).get("role", ""),
            "reset_by": _meta.get("reset_by"),
            "status": status,
            "attempts": int((row or {}).get("attempt") or (latest_n or 0)),
            "max_attempts": int((row or {}).get("max_attempts") or 0),
            "duration_s": round(duration, 1),
            "verdict": verdict,
            "failure_reason": reason,
            "failure_translated": FAILURE_TRANSLATIONS.get(reason)
            if reason else None,
            "failure_detail": failure.get("detail"),
            "kind": "exec" if is_exec else "agent",
            "wrote": sorted(exec_writes.get(key, ())),
            "killed_attempt": killed_attempt,
            "stall_retries": stall_retries,
            "artifact_gate": gate,
            "tool_calls": tool_calls,
            "wrote_output": wrote_output,
        }
        steps_out.append(entry)
        if first_failed is None and (status == "failed"
                                     or (reason and status != "done")):
            first_failed = {**entry, "_latest_dir": latest_dir,
                            "_latest_n": latest_n}
    result["steps"] = steps_out
    # WALL CLOCK IS ELAPSED TIME, NOT THE SUM OF STEP DURATIONS.
    #
    # This reported the sum of the SUCCESSFUL attempts' `exit.json` durations
    # and called it wall clock. It therefore excluded the gaps between steps
    # (driver thinking, next-step polling) AND every preserved stall retry,
    # which is precisely where a slow run spends its time. Observed
    # 2026-08-16: a run that took ~25 minutes reported `wall clock: 70.4s`,
    # off by a factor of twenty, because all three of its steps had burned
    # their time in Fix-6 retries whose blobs live in stall_attempt_* and were
    # never counted. That is the number an operator quotes when asked how long
    # something took.
    #
    # Both figures are now reported, because their DIFFERENCE is the useful
    # part: elapsed 25min against 70s of successful step time says almost all
    # of it went on retries and waiting, which is a diagnosis rather than a
    # measurement.
    result["step_time_s"] = round(total_duration, 1)
    elapsed = None
    try:
        from datetime import datetime, timezone

        def _t(v):
            if not v:
                return None
            d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
            return d if d.tzinfo else d.replace(tzinfo=timezone.utc)

        start = _t((run_row or {}).get("created_at"))
        if start is not None:
            end = _t((run_row or {}).get("updated_at"))
            if events:
                stamps = [_t(e.get("created_at") or e.get("ts")) for e in events]
                stamps = [s for s in stamps if s is not None]
                if stamps:
                    end = max([end] + stamps) if end else max(stamps)
            # A RUN THAT IS STILL `running` HAS NOT STOPPED, so its wall clock
            # runs to NOW - not to its last event. Round 8 read
            # `wall clock: 32.9s` beside `no heartbeat for 319s` in the same
            # verdict: the run had been abandoned for five minutes and the
            # headline number said half a minute, because `updated_at` froze
            # when the driver died. `end` was only defaulted to now when there
            # was NO end at all, which is never true for a run with events.
            if result.get("status") == "running":
                end = datetime.now(timezone.utc)
            if end is not None:
                elapsed = max(0.0, (end - start).total_seconds())
    except Exception:                                        # noqa: BLE001
        elapsed = None
    result["wall_clock_s"] = round(elapsed, 1) if elapsed is not None else round(total_duration, 1)

    # --- swarm section -----------------------------------------------------
    result["swarm"] = None
    if kind == "swarm":
        from ioagentfarm.engine.iobot_config import get_run_output_dir
        project = get_run_output_dir(_root(), run_id)
        # Two real layouts (project root, or the a2a_consult scratch path
        # carried into the project dir) — resolved by the SHARED helper the
        # swarm.child_result emitter also uses, so the events and this table
        # can never disagree about where a run's children are recorded.
        from ioagentfarm.engine.forensics import find_swarm_results
        results_path = find_swarm_results(project)
        artifact_dir = results_path.parent if results_path else project
        children = []
        results_doc = _read_json_utf8sig(results_path) if results_path else None
        if isinstance(results_doc, dict):
            for r in results_doc.get("results") or []:
                if isinstance(r, dict):
                    children.append({"id": r.get("id"),
                                     "ok": bool(r.get("ok")),
                                     "error": r.get("error")})
        dispatch_doc = _read_json_utf8sig(artifact_dir / "dispatch.json")
        consults = (len(children) if children
                    else len(dispatch_doc) if isinstance(dispatch_doc, list)
                    else 0)
        budget = markers.get("budget") if isinstance(
            markers.get("budget"), dict) else {}
        result["swarm"] = {
            "children": children,
            "checkpoint_present": (project / "_run_plan.md").exists(),
            "consults_used": consults,
            "consult_budget": budget.get("consults"),
            "tool_call_budget": budget.get("tool_calls"),
        }

    # --- usage + supervisor ------------------------------------------------
    result["usage"] = _usage_totals(run_id)
    result["supervisor"] = {
        "reaped_steps": sum(1 for e in events
                            if e.get("event_type") == "supervisor.step_reaped"),
        "driver_resumes": int((run_row or {}).get("supervisor_resumes") or 0),
    }

    # --- verdict sentence --------------------------------------------------
    failed_children = [c for c in ((result["swarm"] or {}).get("children")
                                   or []) if not c.get("ok")]
    # A consult-budget overage is a DISCIPLINE finding even on a done run:
    # the briefing contract said N dispatches and the meta-agent spent more.
    swarm_info = result.get("swarm") or {}
    consult_overage = (
        isinstance(swarm_info.get("consult_budget"), int)
        and isinstance(swarm_info.get("consults_used"), int)
        and swarm_info["consults_used"] > swarm_info["consult_budget"])
    total_stalls = sum(s["stall_retries"] for s in steps_out)
    if result["status"] == "done" and not first_failed:
        v = f"Run converged: {len([s for s in steps_out if s['status'] == 'done'])}/{len(steps_out)} step(s) done"
        if total_stalls:
            v += f" after {total_stalls} auto-retr" + ("y" if total_stalls == 1 else "ies")
        if failed_children:
            names = ", ".join(str(c.get("id")) for c in failed_children)
            v += f"; child agent(s) failed and were reported as unavailable: {names}"
        if consult_overage:
            v += (f"; CONSULT BUDGET EXCEEDED "
                  f"({swarm_info['consults_used']}/{swarm_info['consult_budget']})"
                  " - the meta-agent overspent its briefing contract")
        result["verdict"] = v + "."
    elif first_failed is not None:
        reason = (first_failed.get("failure_translated")
                  or first_failed.get("failure_reason")
                  or ("required artifact never produced"
                      if first_failed["verdict"] == "gate_failed"
                      else ("see the step's session snapshot"
                            if first_failed.get("_latest_n") is not None
                            else "no forensic attempt was recorded - "
                                 f"`aicore status --run-id {run_id} --step "
                                 f"{first_failed['key']}`")))
        if first_failed.get("failure_detail"):
            reason = f"{reason} - {first_failed['failure_detail']}"
        verdict = (f"Run {result['status']} at step "
                   f"'{first_failed['key']}': {reason}")
        if consult_overage:
            verdict += (f" (consult budget also exceeded: "
                        f"{swarm_info['consults_used']}"
                        f"/{swarm_info['consult_budget']})")
        # THE CAP IS THE FACT THAT ENDS THE STORY, so it is said even though
        # the gate reason is what failed. Driver round 6: a run stopped by
        # `step.hard_cap_reached` - a FATAL event, twice on the timeline -
        # was narrated only as "the step reported done but a required
        # artifact was missing", which is true of every attempt and silent on
        # the one thing an operator needs: it will not be retried again.
        # `forensics show` marked it; `explain` is the documented first
        # resort and did not.
        _capped = [e for e in events
                   if e.get("event_type") == "step.hard_cap_reached"]
        if _capped:
            _n = len(_capped)
            verdict += (
                f". The hard attempt cap stopped it"
                + (f" ({_n} step(s))" if _n > 1 else "")
                + " - this step will NOT be retried again; raise "
                  "`max_attempts` in the workflow if the work genuinely "
                  "needs more attempts, or fix what it keeps failing on")
        result["verdict"] = verdict
    else:
        # THE DRIVER-NEVER-STARTED CASE. A run whose driver could not make
        # its own LLM calls (total provider outage) has no failed STEP to
        # point at - every step sits pending - so the branches above find
        # nothing and this used to answer "Run status: running", the one
        # answer a postmortem must never give. The give-up events are the
        # evidence; surface them. Proven by chaos-proxy storm testing.
        gave_up = next((e for e in events
                        if e.get("event_type") in ("run.driver_gave_up",
                                                   "supervisor.gave_up")), None)
        if gave_up is not None:
            never_started = [s["key"] for s in steps_out
                             if s.get("status") == "pending"]
            result["verdict"] = (
                "Run did not converge: "
                + (gave_up.get("message") or "the driver gave up")
                + (f"; step(s) never started: {', '.join(never_started)}"
                   if never_started else "")
                + ". No step ran, so there is no step-level failure to read -"
                  " suspect the model endpoint or credentials.")
            result["driver_gave_up"] = True
        else:
            result["verdict"] = f"Run status: {result['status']}."
            _ds = result.get("driver_state") or {}
            if _ds.get("stale"):
                _age = _ds.get("heartbeat_age_s")
                result["verdict"] = (
                    f"Run reads running, but its driver has not been heard from "
                    f"for {'ever' if _age is None else f'{_age:.0f}s'} (stale after "
                    f"{_ds.get('threshold_s'):.0f}s) - the driver is gone and nothing "
                    f"will move. `aicore resume {run_id}` restarts it.")
            elif result["status"] == "failed":
                # A run that FAILED with no failed STEP, no give-up and (below)
                # no cancel on record: its driver ended before any step
                # completed - killed, crashed, or a foreground Ctrl+C. explain
                # used to answer only "Run status: failed" with no cause and no
                # pointer to the recovery, so a 2 a.m. operator had to decide
                # blind (novice finding, round 8 N1). The cancel branch further
                # down overrides this for a real cancellation.
                _never = [s["key"] for s in steps_out
                          if s.get("status") in ("pending", "running")]
                # "before any step completed" IS A CLAIM ABOUT THE TIMELINE,
                # so it is only made when the timeline agrees. Round 4 of the
                # driver certification caught this asserting "only run.created
                # here confirms nothing ran" against ten events, two gate
                # failures, one gate passed and a step at `done 3/2`. A
                # postmortem that contradicts its own evidence is worse than
                # one that says less.
                _ran = [e for e in events
                        if e.get("event_type") not in ("run.created",)]
                if _ran:
                    result["verdict"] = (
                        "Run FAILED with no step-level cause on record, but "
                        f"the timeline holds {len(_ran)} event(s) - work DID "
                        "happen; read them before concluding anything."
                        + (f" Step(s) that never finished: {', '.join(_never)}."
                           if _never else "")
                        + f" Continue it with `aicore resume {run_id} --force`.")
                else:
                    result["verdict"] = (
                        "Run FAILED with no step-level cause on record - its driver "
                        "ended before any step completed (killed, crashed, or "
                        "interrupted; a give-up or a cancellation would show here "
                        "otherwise)."
                        + (f" Step(s) that never finished: {', '.join(_never)}." if _never else "")
                        + f" Continue it with `aicore resume {run_id} --force`.")
                result["driver_died_silently"] = True

    # THE DEAD-DRIVER LINE IS NOT PREEMPTED BY A FAILING STEP. The staleness
    # diagnosis above lives in the branch reached only when NO step carries a
    # failure - so a run killed during a retry, which has both a failing step
    # and a dead driver, got the step's verdict and no word about the driver:
    # certification round 4 watched `explain` say "Run running at step
    # 'assess'" 5m32s after the kill, with the heartbeat 363s past its
    # threshold, no dead-driver line and no resume pointer. The operator is
    # told the run is alive. Appended here, after every branch, so nothing can
    # preempt it.
    # WORK WAS DONE THAT NO ATTEMPT RECORDS. A driver killed or cancelled
    # mid-attempt leaves its step reading `pending, attempt 0` while the
    # usage file already holds the calls it spent - 17 in one joint-stability
    # run, 20 in another - so `explain` described a step that had never
    # started and an operator had no idea money had been spent. The numbers
    # were already in the document; nothing put them together. Said here
    # because it is the shape of every interrupted agent run.
    _append_spend_without_attempt_note(result)

    _ds_final = result.get("driver_state") or {}
    if (result.get("status") == "running" and _ds_final.get("stale")
            and "driver is gone" not in (result.get("verdict") or "")):
        _age_f = _ds_final.get("heartbeat_age_s")
        _thr_f = _ds_final.get("threshold_s")
        result["verdict"] = ((result.get("verdict") or "").rstrip()
                             + f" The DRIVER is gone: no heartbeat for "
                               f"{'ever' if _age_f is None else f'{_age_f:.0f}s'}"
                             + (f" (stale after {_thr_f:.0f}s)" if _thr_f else "")
                             + f" - nothing will move until `aicore resume "
                               f"{run_id}` restarts it.")
        result["driver_gone"] = True

    # --- what the run did NOT cover -----------------------------------------
    # A `done` verdict answers "did my steps run", never "did I consume what
    # was available". The workflow declares the commands that describe its own
    # coverage; the harness runs them at completion and emits run.coverage.
    # Surfacing it HERE is the point of the whole mechanism: explain is the
    # first resort for "what happened", so the shortfall reaches the reader
    # without their having to know to ask.
    coverage = [e for e in events if e.get("event_type") == "run.coverage"]
    if coverage:
        # READ `payload_json`, NOT `payload`. The event row carries the former
        # — the artifact-gate reader forty lines up already json.loads() it —
        # and `.get("payload")` returned None every time, so `checks` was
        # always empty and this whole section never rendered. The coverage
        # mechanism recorded the backlog census FAITHFULLY and displayed
        # nothing: a run that consumed none of its input reported `done` with
        # its shortfall sitting in the database, unread.
        #
        # This is the lesson that produced the mechanism, repeating inside it:
        # an emitted event is not a delivered answer. Validate the READER.
        raw = coverage[-1]
        payload = raw.get("payload")
        if not isinstance(payload, dict):
            try:
                payload = json.loads(raw.get("payload_json") or "{}")
            except (ValueError, TypeError):
                payload = {}
        checks = payload.get("checks") or []
        if checks:
            result["coverage"] = checks

    # --- look_next pointers -------------------------------------------------
    look_next = []

    # THE DRIVER'S REASONING, IF ANY WAS CAPTURED. On an agent-driven run this
    # is the whole of "why did it do that", and no reader knew the directory
    # existed: `stats` and `blob` key on `attempts/`, which an INLINE
    # project_lead step never creates, so both answered "No forensics attempts
    # dir - the run is too old or the id is wrong" about a run that was
    # neither. The certification found the orchestrate blobs by listing the
    # filesystem. Cited FIRST because it is the first thing to read about a
    # driver decision, and only when a turn was actually captured - a pointer
    # at an empty file is worse than none.
    try:
        from ioagentfarm.engine.forensics import orchestrate_reasoning
        # `_root()`, not `root_path` - which is not a name in this function.
        # The first spelling raised NameError on EVERY call and the bare
        # `except` below ate it, so `look_next` silently never cited the
        # reasoning: the locator was correct and unreachable. Round 1 pinned
        # the writer, round 2 pinned the locator and the fact that this
        # source text mentions it - nobody had pinned this READER'S OUTPUT,
        # which is the only thing a person sees. The test now calls
        # `_build_explain` and reads look_next.
        _reason = orchestrate_reasoning(_root(), run_id)
    except Exception:                      # noqa: BLE001 - never break explain
        _reason = None
    if _reason is not None:
        _rp, _rn = _reason
        look_next.append(
            f'cat "{_rp}"'
            f" - the driver's own session ({_rn} turn(s)): why it picked,"
            " retried or gave up")
    else:
        # NO MACHINE-READABLE TURN SURVIVED - which happens when the driver is
        # killed MID-ATTEMPT: the runtime flushes its session at the end of a
        # turn, so an interrupted one leaves a header and nothing else, in the
        # live file AND in every snapshot. Round 4 measured a run that made 33
        # LLM calls and kept 0 turns. What it DID keep is the driver's console:
        # 57 narration blocks in `logs/run_stdout.log`. The reader suppressed
        # the citation because there were no turns, so the one surviving record
        # of that run's reasoning was never offered. Cited here, plainly
        # labelled as narration rather than a session.
        try:
            _stdout = _root() / "instances" / run_id / "logs" / "run_stdout.log"
            if _stdout.is_file() and _stdout.stat().st_size > 0:
                # STATE THE OBSERVATION, NOT AN INFERRED CAUSE. An
                # interrupted attempt is the usual reason no turn survives,
                # but it is not the only one - this line read "the driver
                # was interrupted mid-attempt" on a run that converged 2/2
                # and was never touched (walked 2026-09-03). A postmortem
                # that invents a cause is worse than one that reports a
                # gap.
                look_next.append(
                    f'cat "{_stdout}"'
                    " - no machine-readable session turn was captured"
                    " (an interrupted attempt is the usual cause), but the"
                    " driver's console narration survived")
        except OSError:
            pass
    _ff_session = (first_failed is not None
                   and first_failed.get("_latest_n") is not None
                   and first_failed.get("_latest_dir") is not None
                   and (first_failed["_latest_dir"]
                        / "session-snapshot.jsonl").exists())
    if _ff_session:
        sa = f"{first_failed['key']}.{first_failed['_latest_n']}"
        look_next.append(
            f"aicore forensics blob {run_id} {sa} session-snapshot.jsonl"
            " - the attempt that carried the failure")
        if first_failed.get("failure_reason") in _CONNECTION_SHAPED:
            http_log = first_failed["_latest_dir"] / "http.log"
            look_next.append(
                f'grep -E "Exception|RemoteProtocol|Error" "{http_log}"'
                " - the wire-level error behind the LLM failure")
        if first_failed.get("stall_retries"):
            look_next.append(
                f"aicore forensics stats {run_id}"
                " - per-attempt counters incl. the preserved stall retries")
    elif first_failed is not None:
        # a command step: no session, so point at the record it does have
        look_next.append(
            f"aicore status --run-id {run_id} --step {first_failed['key']}"
            " - the command's own stdout and stderr")
        if first_failed.get("_latest_n") is not None:
            _d = first_failed.get("_latest_dir")
            _has_err = bool(_d and (_d / "stderr.log").exists()
                            and (_d / "stderr.log").stat().st_size)
            look_next.append(
                f"aicore forensics blob {run_id} "
                f"{first_failed['key']}.{first_failed['_latest_n']} "
                + ("stderr.log - that attempt's stderr, kept per attempt" if _has_err
                   else "stdout.log - what the tool itself claimed (its stderr was empty)"))
        look_next.append(
            f"aicore forensics show {run_id} -s {first_failed['key']}"
            " - every event the step recorded, in order")
    elif failed_children:
        look_next.append(
            f"aicore run-output --run-id {run_id} --file results.json"
            " - the per-child dispatch results incl. each error")
    elif result.get("driver_gave_up"):
        look_next.append(
            "aicore config-check"
            " - the driver could not complete its own LLM calls; verify the"
            " provider endpoint, key and model first")
        look_next.append(
            f"aicore forensics show {run_id}"
            " - the full event timeline incl. the give-up record")
    elif result.get("driver_died_silently"):
        look_next.append(
            f"aicore resume {run_id} --force"
            " - the driver ended before any step completed; --force continues"
            " it from where it left off (a live driver would refuse without it)")
        look_next.append(
            f"aicore forensics show {run_id}"
            " - the full timeline; only run.created here confirms nothing ran")
    _cancel = next((e for e in events if e.get("event_type") == "run.cancelled"), None)
    if _cancel is not None:
        try:
            _cp = json.loads(_cancel.get("payload_json") or "{}")
        except (TypeError, ValueError):
            _cp = _cancel.get("payload") or {}
        result["cancelled"] = {"by": _cp.get("by"), "reason": _cp.get("reason"),
                               "stopped_steps": _cp.get("stopped_steps") or []}
        # THE RUN ROW OUTRANKS THE EVENT. A run cancelled and then resumed
        # converges to `done`, and this branch keyed off the cancel event
        # alone: the headline read "Run CANCELLED ... Nothing restarts it"
        # about a run whose own Warnings section said it was RECOVERED and
        # whose two steps were both ok (seen while walking the harness
        # guide, 2026-09-02). The cancellation stays in the record; it is
        # the verdict only while the run is still cancelled.
        if str(result.get("status") or "").lower() not in ("done", "completed"):
            result["verdict"] = (
                f"Run CANCELLED - {_cancel.get('message') or 'cancelled'}"
                + (f"; stopped: {', '.join(_cp.get('stopped_steps') or [])}"
                   if _cp.get("stopped_steps") else "")
                + ". Nothing restarts it; `aicore step-retry` re-opens a step if "
                  "that was a mistake.")
            look_next = [f"aicore forensics show {run_id} - the timeline up to the cancellation"]
    result["look_next"] = look_next[:3]
    # --- warnings: a green run that deserves a second look -----------------
    # A run reads `done` with every gate passed and was still wrong once: a
    # step that read a file before its writer had run failed, retried, and
    # passed. The success check cannot see that; the attempt count can.
    warnings = list(route_warnings)
    if recovery:
        warnings.append("this run was RECOVERED - " + "; ".join(recovery[:4])
                        + ("; ..." if len(recovery) > 4 else "")
                        + " (a retried attempt after a kill is the recovery working, not a race)")
    result["recovery"] = recovery
    for st in steps_out:
        if (st.get("kind") == "exec" and st["status"] == "done"
                and int(st.get("attempts") or 0) > 1
                and not st.get("reset_by")      # an on_fail RESET step re-ran on purpose
                and st["key"] not in reset_gates     # and so did the GATE that reset it
                and st["key"] not in reaped          # a crash-reaped attempt is not a race
                and not st.get("killed_attempt")):   # nor a killed one
            warnings.append(
                f"step '{st['key']}' needed {st['attempts']} attempts - an "
                "earlier one failed and the retry passed; the usual cause is "
                "a file read before the step that writes it had run "
                f"(`aicore forensics blob {run_id} {st['key']}.1 stderr.log`)")
    for _rel, _writers in sorted(shared_writes.items()):
        if len(_writers) > 1:
            if all(w in exec_writes for w in _writers):
                warnings.append(
                    f"`{_rel}` changed while {len(_writers)} command steps ran "
                    f"({', '.join(sorted(_writers))}) - parallel steps share one "
                    "artifact directory; if both write it, last writer wins. "
                    "Declare it in the owning step's requires_artifacts, and "
                    "make the reader depend on the writer")
            else:
                warnings.append(
                    f"{len(_writers)} steps wrote the same shared file `{_rel}` "
                    f"({', '.join(sorted(_writers))}) - one artifact directory, "
                    "last writer wins; name per-item files with {{story_id}}")
    # Re-verify passed-gate deliverables on READ - catches a deliverable
    # tampered with AFTER the run completed, which the run-end re-check races
    # and loses on a single-step run (novice re-cert, round 7 B-3). Deduped
    # against the in-run `run.artifact_changed_after_gate` warning above.
    try:
        for _mm in _gate_digest_mismatches_now(run_id):
            _names = ", ".join(f"{d['artifact']} ({d['what']})" for d in _mm["diffs"])
            if any(_mm["step_key"] and _mm["step_key"] in w and "gate" in w for w in warnings):
                continue
            warnings.append(
                f"deliverable(s) of '{_mm['step_key']}' NO LONGER match the artifact gate "
                f"digest (re-checked now): {_names} - the file on disk is not what the gate "
                "saw, so a `done` run is not proof the deliverable is intact")
    except Exception:  # noqa: BLE001
        pass
    result["warnings"] = warnings
    if warnings and result.get("verdict"):
        result["verdict"] = (str(result["verdict"]).rstrip(".")
                             + f" - {len(warnings)} warning(s), see below.")
    try:
        from ioagentfarm.engine.otel_export import run_spans_file
        _sp = run_spans_file(_root(), run_id)
        if _sp.is_file():
            result["spans_file"] = str(_sp)
    except Exception:  # noqa: BLE001
        pass
    if result.get("missing_run"):
        result["db"] = "no such run"
        result["verdict"] = (f"No run '{run_id}' in the database at "
                             f"{result.get('db_root')}. `aicore status` lists recent runs.")
        result["look_next"] = ["aicore status - recent runs, with their ids"]
        result["warnings"] = []
    return result


@forensics_app.command("explain")
def forensics_explain(
    run_id: str = typer.Argument(..., help="The run_id to explain"),
    json_output: bool = typer.Option(
        False, "--json", help="Emit the machine-readable postmortem document"),
):
    """One-command postmortem: what happened, why, and where to look next.

    The first command to run for ANY 'what happened to run X' question -
    workflow or swarm. Composes the run row, the forensic timeline, the
    per-attempt blobs, usage totals and (for swarms) the child dispatch
    results into a single ranked verdict. Costs live in `iof-run-audit`,
    not here.
    """
    doc = _build_explain(run_id)

    if json_output:
        typer.echo(json.dumps(doc, indent=2, default=str))
        if doc.get("missing_run"):
            raise typer.Exit(code=3)
        return

    if doc.get("missing_run"):
        # not a complete, invented header ("predates provenance") for a run
        # that never existed (novice, round 6)
        _console.print(f"No run '{run_id}' in this database. `aicore status` lists recent runs.",
                       markup=False)
        raise typer.Exit(code=3)

    _console.print(f"[bold]Explain - {run_id}[/bold]")
    header = (f"kind: {doc['kind']}  |  driver: {doc.get('driver') or 'agent'}"
              f"  |  status: {doc['status']}  |  "
              f"wall clock: {_hms(doc['wall_clock_s'])}"
              + (f"  (step time {_hms(doc['step_time_s'])})"
                 if doc.get("step_time_s") is not None
                 and abs(doc["step_time_s"] - doc["wall_clock_s"]) > 5 else ""))
    if doc.get("db") == "unavailable":
        header += "  |  db: unavailable (filesystem-only view)"
    _console.print(f"[dim]{header}[/dim]")
    if doc.get("db") == "unavailable":
        # The reason and the ROOT, on screen. Without them this state is
        # unanswerable: the reader cannot tell a missing database from a
        # database being looked for in the wrong place, and neither can the
        # assistant, which reports what this command tells it.
        _console.print(
            f"[yellow]  db root tried:[/yellow] {doc.get('db_root', '?')}"
            "   [dim](IOF_ROOT, else `.iof` relative to the current "
            "directory)[/dim]", soft_wrap=True)
        if doc.get("db_error"):
            _console.print(f"[yellow]  db error:[/yellow] "
                           f"{doc['db_error']}", soft_wrap=True)
    if doc.get("goal"):
        _console.print(f"[dim]goal: {doc['goal'][:120]}[/dim]")
    _console.print(f"[dim]content: {doc.get('content') or '(not recorded)'}[/dim]",
                   soft_wrap=True)
    _console.print(f"\n{doc['verdict']}\n")

    if doc["steps"]:
        table = Table(title="Steps")
        table.add_column("step", style="cyan")
        table.add_column("role")
        table.add_column("verdict")
        table.add_column("att", justify="right")
        table.add_column("dur_s", justify="right")
        table.add_column("gate")
        table.add_column("failure", style="red")
        for s in doc["steps"]:
            table.add_row(
                s["key"], s["role"], s["verdict"], str(s["attempts"]),
                f"{s['duration_s']:.0f}", s["artifact_gate"],
                s.get("failure_reason") or "")
        _console.print(table)

    if doc.get("swarm"):
        sw = doc["swarm"]
        table = Table(title="Swarm children")
        table.add_column("child", style="cyan")
        table.add_column("ok")
        table.add_column("error", style="red")
        for c in sw["children"]:
            table.add_row(str(c.get("id")), "yes" if c.get("ok") else "NO",
                          (c.get("error") or "")[:80])
        _console.print(table)
        budget_bits = [f"checkpoint: {'written' if sw['checkpoint_present'] else 'MISSING'}",
                       f"consults: {sw['consults_used']}"]
        if sw.get("consult_budget"):
            budget_bits[-1] += f"/{sw['consult_budget']}"
        if sw.get("tool_call_budget"):
            budget_bits.append(f"tool-call cap: {sw['tool_call_budget']}")
        _console.print(f"[dim]{'  |  '.join(budget_bits)}[/dim]")

    u = doc["usage"]
    if u["available"]:
        _console.print(
            f"[dim]usage: {u['calls']} LLM calls, {u['in']:,} in / "
            f"{u['out']:,} out (cache {u['cache_read']:,}r/"
            # PASTE-READY, or it is not a pointer. `iof-run-audit cost` takes
            # `--run-id`; printing a positional made every copy of this line
            # fail with "unrecognized arguments" (Phase A round 1). The
            # `run_costs` skill had it right - this is the copy that drifted.
            f"{u['cache_write']:,}w) - costs: iof-run-audit cost "
            f"--run-id {run_id}[/dim]")
    else:
        _console.print("[dim]usage: not recorded for this run[/dim]")

    # Printed BEFORE "Look next" and after the verdict, deliberately: it is a
    # result, not a debugging pointer. `done` says the steps ran; this says
    # what was left uncovered, and the two belong side by side.
    if doc.get("coverage"):
        _console.print("\n[bold]Coverage at completion[/bold]")
        _console.print("[dim]what this run did NOT cover is as much a result "
                       "as what it did[/dim]")
        for chk in doc["coverage"]:
            head = f"  {chk.get('name', 'check')}"
            if chk.get("exit_code"):
                head += f"  [red](command failed, exit {chk['exit_code']})[/red]"
            _console.print(head)
            # `markup=False` is deliberate — a coverage command or its output
            # may contain square brackets, and Rich would eat them or raise.
            # So the dim styling has to come from `style=`, which applies
            # without parsing: inline [dim] tags would print literally here.
            _console.print(f"    $ {chk.get('command', '')}",
                           markup=False, style="dim")
            for line in (chk.get("output") or "(no output)").splitlines():
                _console.print(f"      {line}", markup=False)

    if doc.get("spans_file"):
        _console.print(f"otel spans (console exporter): {doc['spans_file']}", markup=False, style="dim")
    if doc.get("warnings"):
        _console.print("\n[bold yellow]Warnings[/bold yellow]")
        for w in doc["warnings"]:
            _console.print(f"  - {w}", markup=False)
    if doc["look_next"]:
        _console.print("\n[bold]Look next[/bold]")
        for i, cmd in enumerate(doc["look_next"], 1):
            _console.print(f"  {i}. {cmd}", markup=False)
    if doc.get("missing_run"):
        raise typer.Exit(code=3)


# ----------------------------------------------------------------------
# forensics narrative — human-readable session reconstruction
# ----------------------------------------------------------------------


def _fmt_rel_time(started_at: Optional[float], ts_epoch: Optional[float]) -> str:
    """Format a relative time offset as [MM:SS] since attempt start."""
    if started_at is None or ts_epoch is None:
        return "       "
    delta = max(0, int(ts_epoch - started_at))
    mm, ss = divmod(delta, 60)
    return f"[{mm:02d}:{ss:02d}]"


def _parse_ts(ts_str: Optional[str]) -> Optional[float]:
    """Parse a session JSONL timestamp to epoch seconds (best-effort)."""
    if not ts_str:
        return None
    try:
        from datetime import datetime
        if ts_str.endswith("Z"):
            ts_str = ts_str[:-1] + "+00:00"
        return datetime.fromisoformat(ts_str).timestamp()
    except Exception:
        return None


@forensics_app.command("narrative")
def forensics_narrative(
    run_id: str = typer.Argument(..., help="The run_id"),
    step_attempt: str = typer.Argument(
        ..., help="step.attempt e.g. 'analyze.1' (or 'analyze' for attempt 1)",
    ),
    max_text: int = typer.Option(
        200, "--max-text", help="Max chars to show per assistant/tool turn",
    ),
):
    """Reconstruct a step attempt's session as a human-readable markdown timeline.

    Reads session-snapshot.jsonl and renders each assistant turn (with its
    tool calls) and each tool result in chronological order. Relative
    timestamps come from exit.json's start time. Designed for the
    forensic_analysis workflow - Analyst reads this instead of hand-parsing
    multi-thousand-line JSONLs.

    Output is plain markdown (no Rich formatting) so it can be captured
    cleanly via ``exec aicore forensics narrative ... > file.md``.
    """
    from ioagentfarm.engine.forensics import parse_session_failure

    blob_dir = _attempt_dir(run_id, step_attempt)
    session_path = blob_dir / "session-snapshot.jsonl"
    if not session_path.exists():
        typer.echo(f"# ERROR: no session-snapshot.jsonl at {session_path}")
        raise typer.Exit(code=1)

    exit_info = _read_json_file(blob_dir / "exit.json") or {}
    started_at = exit_info.get("started_at")
    failure = parse_session_failure(session_path) or {}
    session_stats = _walk_session_stats(session_path)

    lines_out = []
    lines_out.append(f"# {step_attempt} - session narrative")
    lines_out.append("")
    lines_out.append(
        f"**Duration:** {exit_info.get('duration_s', 0):.1f}s  |  "
        f"**Exit code:** {exit_info.get('exit_code', '?')}  |  "
        f"**Signal killed:** {exit_info.get('signal_killed', False)}  |  "
        f"**Tool calls:** {session_stats.get('tool_calls_total', 0)}  |  "
        f"**Assistant turns:** {session_stats.get('assistant_turns', 0)}"
    )
    lines_out.append("")
    # THE ENGINE'S VERDICT OUTRANKS THE SESSION PATTERN. `run_step` already
    # decides whether a session-level failure signature was real: when the
    # deliverable turned out complete it emits `step.retry_not_needed` and
    # accepts the step. This header read only the pattern, so a step that
    # produced a correct card and reached `done` opened with "Outcome: FAILED
    # - agent_premature_termination" - the opposite of what `explain` says
    # about the same step, and the first line a person reads.
    false_alarm = _retry_not_needed_reason(run_id, step_attempt)
    if failure.get("reason") and false_alarm:
        lines_out.append(
            f"**Outcome:** done - session signalled `{failure['reason']}` "
            f"but the deliverable was complete; the engine accepted it "
            f"without a retry (`step.retry_not_needed`)")
    elif failure.get("reason"):
        lines_out.append(f"**Outcome:** FAILED - `{failure['reason']}`")
        lines_out.append(f"**Failure pattern:** {failure.get('matched_pattern', '')}")
    else:
        lines_out.append("**Outcome:** clean exit")
    lines_out.append("")
    lines_out.append("## Timeline")
    lines_out.append("")

    try:
        with open(session_path, "r", encoding="utf-8") as f:
            raw_lines = f.readlines()
    except Exception as e:
        typer.echo(f"# ERROR: failed to read session: {e}")
        raise typer.Exit(code=1)

    turn_index = 0
    for raw in raw_lines:
        try:
            obj = json.loads(raw)
        except Exception:
            continue
        if obj.get("_type") == "metadata":
            ckpt = (obj.get("metadata") or {}).get("runtime_checkpoint")
            asst = ckpt.get("assistant_message") if ckpt else None
            if not asst or asst.get("role") != "assistant":
                continue
            obj = asst

        role = obj.get("role")
        ts_str = obj.get("timestamp") or obj.get("ts")
        ts_epoch = _parse_ts(ts_str)
        rel = _fmt_rel_time(started_at, ts_epoch)

        if role == "user":
            content = (obj.get("content") or "").strip()
            first_line = next(
                (ln for ln in content.split("\n") if ln.strip() and not ln.startswith("#")),
                "",
            )
            preview = first_line[:max_text] or "(step prompt)"
            lines_out.append(f"{rel} **USER:** {preview}")
            lines_out.append("")
        elif role == "assistant":
            turn_index += 1
            text = (obj.get("content") or "").strip()
            tcs = obj.get("tool_calls") or []
            if text:
                preview = text[:max_text].replace("\n", " ")
                if len(text) > max_text:
                    preview += "…"
                lines_out.append(f"{rel} **ASSISTANT #{turn_index}:** {preview}")
            else:
                lines_out.append(f"{rel} **ASSISTANT #{turn_index}:** *(no text - thinking only)*")
            for tc in tcs:
                fn = tc.get("function") or {}
                tname = fn.get("name") or "?"
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except Exception:
                    args = {}
                if tname in ("write_file", "read_file"):
                    target = args.get("path", "?")
                    lines_out.append(f"         -> **{tname}** `{target}`")
                elif tname in ("exec", "shell", "bash"):
                    cmd = (args.get("command") or args.get("cmd") or "")
                    preview = cmd[:max_text].replace("\n", " ")
                    if len(cmd) > max_text:
                        preview += "…"
                    lines_out.append(f"         -> **exec** `{preview}`")
                elif tname == "grep":
                    pattern = args.get("pattern") or args.get("query") or "?"
                    path = args.get("path") or args.get("glob") or ""
                    lines_out.append(f"         -> **grep** `{pattern}` in `{path}`")
                elif tname == "glob":
                    pattern = args.get("pattern") or args.get("glob") or "?"
                    lines_out.append(f"         -> **glob** `{pattern}`")
                else:
                    lines_out.append(f"         -> **{tname}** {str(args)[:max_text]}")
            if not tcs and not text:
                lines_out.append(f"         -> *(empty turn - no text, no tool calls)*")
            lines_out.append("")
        elif role == "tool":
            content = (obj.get("content") or "").strip()
            tool_name = obj.get("name") or "?"
            first_meaningful = next(
                (ln for ln in content.split("\n") if ln.strip()),
                "",
            )
            preview = first_meaningful[:max_text].replace("\n", " ")
            if len(first_meaningful) > max_text:
                preview += "…"
            if "[tool output persisted]" in content:
                preview = f"(large output persisted to disk)  {preview}"
            lines_out.append(f"{rel} **TOOL ({tool_name}):** {preview}")
            lines_out.append("")

    lines_out.append("## Why this attempt ended")
    lines_out.append("")
    if failure.get("reason") == "agent_premature_termination":
        last_text = session_stats.get("last_assistant_text") or ""
        preview = last_text[:400].replace("\n", " ")
        lines_out.append(
            "The last assistant turn emitted text **without** a tool call AND "
            "without a `STATUS:` protocol marker. iobot's agent loop treats "
            "this as 'agent done talking' and exits the loop with rc=0, "
            "leaving OUTPUT.md unwritten."
        )
        lines_out.append("")
        lines_out.append("Last assistant text preview:")
        lines_out.append(f"> {preview}...")
    elif failure.get("reason") == "llm_connection_error":
        lines_out.append(
            "iobot wrote `\"Error calling LLM: Connection error\"` as the final "
            "assistant message. Confirmed root cause (from Gap E http.log): "
            "upstream MiniMax server sent a malformed HTTP response byte sequence "
            "(`RemoteProtocolError: illegal status line`). This is a server-side "
            "wire-protocol bug, not a network failure, not anything in iobot or "
            "our code. Fresh-request retry is the only fix and Fix 6 handles it "
            "automatically."
        )
    elif failure.get("reason") == "llm_stream_stalled":
        lines_out.append(
            "iobot's 90-second text_stream watchdog fired — no tokens received "
            "from the provider for 90+ seconds. Usually caused by single-shot "
            "composition of a large response; the sectioned-composition pattern "
            "is the workaround."
        )
    elif failure.get("reason"):
        lines_out.append(
            f"Detected failure pattern: `{failure['reason']}` "
            f"(matched: {failure.get('matched_pattern', '')})"
        )
    else:
        lines_out.append(
            "Clean exit — the agent emitted its final tool calls (including "
            "writing OUTPUT.md with the protocol header) and the agent loop "
            "completed normally."
        )
    lines_out.append("")

    typer.echo("\n".join(lines_out))


# ----------------------------------------------------------------------
# forensics tokens — exact per-run LLM token usage
# ----------------------------------------------------------------------


def _usage_label(session: str) -> str:
    """Derive a compact per-line label from a iobot session key.

    Orchestrator sessions look like ``iof:<run_id>:orchestrate:u:<uid>``;
    delegated-step sessions like ``iof_<run_id>_<step>_u_<uid>`` (or a iobot
    variant). We only need a readable grouping key, so: 'orchestrate' if the
    session names it, else the middle segment that isn't the run_id/uid, else
    the raw session.
    """
    s = session or "?"
    if "orchestrate" in s:
        return "orchestrate"
    # colon style: iof:<run_id>:<step>:u:<uid>  -> the 3rd segment is the step
    if s.startswith("iof:") and s.count(":") >= 2:
        return s.split(":")[2]
    # underscore style: iof_<run>_<step>_u_<uid>  -> token before _u_
    if "_u_" in s:
        head = s.split("_u_", 1)[0]
        parts = head.split("_")
        # drop leading 'iof' + the run_id chunks (run_YYYYMMDD_HHMMSS_micro)
        # heuristic: the step is the trailing non-numeric token(s)
        tail = [p for p in parts if p and not p.isdigit() and p not in ("iof", "run")]
        if tail:
            return tail[-1]
    return s


@forensics_app.command("tokens")
def tokens(
    run_id: str = typer.Argument(..., help="The run_id to total tokens for"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON"),
):
    """Exact LLM token usage for a run - captured natively via iobot's AgentHook.

    Every LLM call appends one line to ``<root>/instances/<run_id>/usage.jsonl``
    (the ``apply_usage_capture`` hook reads ``context.usage`` - no provider
    monkey-patching). Lines are grouped by session so you see the orchestrator's
    own driving calls separately from each delegated step. Input counts include
    cached tokens; the breakdown line splits new vs cache-read vs cache-write.
    """
    from collections import OrderedDict

    usage_file = _root() / "instances" / run_id / "usage.jsonl"
    if not usage_file.is_file():
        typer.echo(
            f"no token usage recorded for run {run_id} "
            f"(expected {usage_file}; runs before the usage-capture hook have none)"
        )
        # an exec-only run's legitimate zero and a typo printed the same
        # line with the same code (novice, rounds 6-7): 3 for a ghost
        raise typer.Exit(code=3 if _ghost_run(run_id) else 1)

    per_label: "OrderedDict[str, list]" = OrderedDict()  # label -> [calls,in,out,cr,cw]
    tot_calls = tot_in = tot_out = tot_cr = tot_cw = 0
    for d in _iter_usage_rows(run_id):
        label = _usage_label(d.get("session", ""))
        i = int(d.get("in", 0) or 0)
        o = int(d.get("out", 0) or 0)
        cr = int(d.get("cr", 0) or 0)
        cw = int(d.get("cw", 0) or 0)
        row = per_label.setdefault(label, [0, 0, 0, 0, 0])
        row[0] += 1; row[1] += i; row[2] += o; row[3] += cr; row[4] += cw
        tot_calls += 1; tot_in += i; tot_out += o; tot_cr += cr; tot_cw += cw

    tot_new = tot_in - tot_cr - tot_cw  # new (uncached) input

    if json_output:
        typer.echo(json.dumps({
            "run_id": run_id, "calls": tot_calls,
            "input_tokens": tot_in, "input_new": tot_new,
            "cache_read": tot_cr, "cache_write": tot_cw,
            "output_tokens": tot_out, "total_tokens": tot_in + tot_out,
            "by_session": {
                k: {"calls": v[0], "input": v[1], "output": v[2],
                    "cache_read": v[3], "cache_write": v[4]}
                for k, v in per_label.items()
            },
        }, indent=2))
        return

    if not per_label:
        try:
            from ioagentfarm.cli import _store as _cli_store
            _cli_store(_root()).get_run(run_id)
        except KeyError:
            # an exec-only run's legitimate zero and a typo printed the same
            # line with the same code (novice, round 6)
            typer.echo(f"No run '{run_id}' in this database. `aicore status` lists recent runs.", err=True)
            raise typer.Exit(code=3)
        except Exception:  # noqa: BLE001
            pass
        typer.echo(f"no token usage recorded for run {run_id}")
        return

    table = Table(title=f"Token usage - {run_id}")
    table.add_column("session", style="cyan", no_wrap=True)
    table.add_column("calls", justify="right")
    table.add_column("input", justify="right")
    table.add_column("output", justify="right")
    table.add_column("total", justify="right")
    # heaviest first, but keep orchestrate visible
    for label, v in sorted(per_label.items(), key=lambda kv: -(kv[1][1] + kv[1][2])):
        table.add_row(label, str(v[0]), f"{v[1]:,}", f"{v[2]:,}", f"{v[1] + v[2]:,}")
    table.add_row("TOTAL", str(tot_calls), f"{tot_in:,}",
                  f"{tot_out:,}", f"{tot_in + tot_out:,}", style="bold")
    _console.print(table)
    if tot_cr or tot_cw:
        _console.print(f"[dim]input breakdown: {tot_new:,} new + {tot_cr:,} "
                       f"cache-read + {tot_cw:,} cache-write[/dim]")



def _summarise_finished(store, root_path, run_id: str, run: dict, tail: int) -> None:
    """A finished run: the outcome, then its closing lines.

    Replaying a completed run's whole history is the wrong answer twice over -
    it buries the verdict under a thousand lines of reasoning that is already
    over, and it makes `watch` useless as the thing you reach for when you come
    back to a run you left.
    """
    from ioagentfarm.engine import watch as W

    status = (run.get("status") or "").upper()
    colour = "green" if status == "DONE" else "red"
    _console.print(f"[bold {colour}]{status}[/bold {colour}]  {run_id}  "
                   f"[dim]{run.get('workflow_name','')}[/dim]")

    steps = store.list_steps(run_id)
    by = {}
    for st in steps:
        by[st.get("status") or "?"] = by.get(st.get("status") or "?", 0) + 1
    _console.print("  steps: " + ", ".join(f"{n} {k}" for k, n in sorted(by.items())))
    for st in steps:
        if st.get("status") == "failed":
            _console.print(f"  [red]failed:[/red] {st['step_key']} "
                           f"(attempt {st.get('attempt')})")

    # retries taken vs SAVED - the two numbers that say how much of the wall
    # clock was work and how much was the harness recovering from itself.
    try:
        events = f_timeline(run_id)
        took = sum(1 for e in events
                   if e.get("event_type") == "step.auto_retry_after_stall")
        saved = sum(1 for e in events
                    if e.get("event_type") == "step.retry_not_needed")
        if took or saved:
            _console.print(f"  retries: {took} taken, {saved} avoided "
                           f"[dim](a finished step that omitted its STATUS "
                           f"marker is accepted, not re-run)[/dim]")
    except Exception:                                        # noqa: BLE001
        pass

    # the closing lines of whichever step ran last - what it was saying as it
    # finished, which is what somebody returning to the run wants first
    last = None
    for st in steps:
        d = W.live_attempt_dir(root_path, run_id, st["step_key"])
        if d is not None and (d / "stdout.log").exists():
            m = (d / "stdout.log").stat().st_mtime
            if last is None or m > last[0]:
                last = (m, st["step_key"], d)
    if last is not None and tail > 0:
        lines, _ = W.agent_lines(last[2] / "stdout.log", 0)
        if lines:
            _console.print(f"\n[bold]closing lines - {last[1]}[/bold]")
            for line in lines[-tail:]:
                _console.print(f"  {line}", markup=False, highlight=False)

    _console.print(f"\n[dim]full postmortem: aicore forensics explain {run_id}"
                   f"\nreplay everything:  aicore watch {run_id} --replay[/dim]")


def f_timeline(run_id: str):
    try:
        return _forensics().get_run_timeline(run_id) or []
    except Exception:                                        # noqa: BLE001
        return []


def _retry_not_needed_reason(run_id: str, step_attempt: str) -> str:
    """The false-alarm reason the engine recorded for this attempt, or "".

    `run_step` emits `step.retry_not_needed` when a session-level failure
    signature turned out to sit beside a complete deliverable. Any reader
    that classifies an attempt from the session pattern alone must consult
    this first, or it contradicts `explain` about the same step.
    """
    from ioagentfarm.cli_orchestration import safe_step_key
    key, _, att = step_attempt.rpartition(".")
    if not key or not att.isdigit():
        key, att = step_attempt, "1"
    for e in f_timeline(run_id):
        if e.get("event_type") != "step.retry_not_needed":
            continue
        if safe_step_key(str(e.get("step_key") or "")) != safe_step_key(key):
            continue
        if str(e.get("attempt") or "1") != att:
            continue
        return str((e.get("payload") or {}).get("reason")
                   or e.get("message") or "false alarm")
    return ""


@forensics_app.command("watch")
def forensics_watch(
    run_id: str = typer.Argument(None, help="Run to watch (default: the active run)"),
    interval: float = typer.Option(5.0, "--interval", "-i", help="Poll seconds"),
    quiet_after: float = typer.Option(
        None, "--quiet-after",
        help="Seconds of step silence before diagnosing (default: the "
             "supervisor's own IOF_SUPERVISOR_STEP_STALE_S)"),
    replay: bool = typer.Option(
        False, "--replay",
        help="Stream a FINISHED run's full history instead of summarising it."),
    tail: int = typer.Option(
        12, "--tail",
        help="Closing agent lines to show for a finished run."),
    events_only: bool = typer.Option(
        False, "--events-only",
        help="Step transitions only. By default the AGENT'S OWN OUTPUT is "
             "streamed too - its reasoning and progress lines, the same "
             "console an attached `aicore run` shows."),
):
    """Narrate a detached run, and say WHY when it goes quiet.

    `aicore run` streams the agent's output while it blocks. `aicore run
    --json` detaches - which is what run_ops asks for, because a run outlives
    the session that started it - and then nothing is emitted at all: the run
    progresses and the console is silent.

    This fills that gap. It renders the forensic event stream as work rather
    than as engine vocabulary ("analyze -> done" instead of
    "step.subprocess_exited rc=0 after 16.087s"), and when a step stops moving
    past the supervisor's own staleness threshold it asks the question a
    person would ask next - is this recovery, or is it stuck? - and answers it
    from `is-recovering`'s structural check.

    It only ever REPORTS. It never retries, kills or intervenes: fighting the
    recovery machinery is the one thing the resilience design asks nobody to
    do.
    """
    from ioagentfarm.engine import watch as W

    from ioagentfarm.cli import _root as _cli_root, _resolve_run_id, _store

    root_path = _cli_root()
    store = _store(root_path)
    if not run_id:
        run_id = _resolve_run_id(store, root_path, None, "") or ""
        if not run_id:
            typer.secho("no run to watch - pass a run_id", err=True,
                        fg=typer.colors.RED)
            raise typer.Exit(code=2)

    if quiet_after is None:
        from ioagentfarm.engine.supervisor import _step_stale_s
        quiet_after = _step_stale_s()

    f = _forensics()
    last_ts = None
    seen: set = set()
    diagnosed: set = set()
    offsets: dict = {}

    # A RUN THAT HAS ALREADY FINISHED IS NOT SOMETHING TO WATCH. Events and
    # agent output are both persisted, so pointing this at a completed run
    # replayed every line of it - a thousand lines of reasoning that is over,
    # scrolling past faster than anyone reads, with the verdict buried at the
    # end. What somebody wants there is the outcome and the closing lines.
    # `--replay` if they genuinely want the whole thing.
    _said_driver_gone = False
    try:
        _run0 = store.get_run(run_id)
    except KeyError:
        _console.print(f"[red]No run '{run_id}' in this database.[/red] "
                       "`aicore status` lists recent runs.")
        raise typer.Exit(code=3)
    if _run0 and _run0.get("status") in ("done", "failed") and not replay:
        _summarise_finished(store, root_path, run_id, _run0, tail)
        if _run0.get("status") == "failed":
            # a script that gates on `watch` gets an exit code, not just the
            # word FAILED - and it is 1, the table's "failed"; 3 is not-found
            # (a batch-12 slip put 3 here; novice finding, round 7)
            raise typer.Exit(code=1)
        return

    _console.print(f"[bold]watching {run_id}[/bold]  "
                   f"[dim](Ctrl+C to stop; it keeps running either way)[/dim]")
    try:
        while True:
            for e in f.get_run_timeline(run_id, since_ts=last_ts) or []:
                eid = e.get("event_id")
                if eid in seen:
                    continue
                seen.add(eid)
                last_ts = e.get("ts") or last_ts
                line = W.humanise(e)
                if not line:
                    continue
                sev = e.get("severity") or "info"
                colour = ("red" if sev in ("error", "fatal")
                          else "yellow" if sev == "warn" else "white")
                _console.print(f"[dim]{_short_ts(e.get('ts',''))}[/dim] "
                               f"[{colour}]{line}[/{colour}]", markup=True)

            # THE AGENT'S OWN OUTPUT - the reason someone watches at all.
            # `aicore run` prints this while it blocks; a detached run writes
            # it to the attempt's stdout.log and nothing surfaced it.
            if not events_only:
                # EVERY step that has produced output, not only the RUNNING
                # one. Events are persisted, so a watch started mid-run
                # replays the backlog instantly - and if this only read live
                # steps, every step that finished before you started watching
                # would contribute its transitions and none of its reasoning.
                # The offsets dict means nothing is printed twice, so a step
                # that finishes between polls still has its output shown.
                for s_ in store.list_steps(run_id):
                    if s_.get("status") in ("pending",):
                        continue
                    d = W.live_attempt_dir(root_path, run_id, s_["step_key"])
                    if d is None:
                        continue
                    key = str(d)
                    lines, offsets[key] = W.agent_lines(
                        d / "stdout.log", offsets.get(key, 0))
                    for line in lines:
                        # markup=False so a bracket in the AGENT's own output
                        # cannot be parsed as a style tag (or crash on an
                        # unclosed one), which means the label cannot use tags
                        # either - it is plain text and dimmed by the caller.
                        _console.print(f"  {s_['step_key']} | {line}",
                                       markup=False, highlight=False)

            run = store.get_run(run_id)
            if run and run.get("status") in ("done", "failed"):
                _console.print(f"\n[bold]{run['status'].upper()}[/bold] - "
                               f"aicore forensics explain {run_id}")
                if run.get("status") == "failed":
                    raise typer.Exit(code=1)
                return

            # Nothing arriving is not the same as nothing happening. Ask why.
            # First the driver itself: dead between two steps, no step is
            # running and the per-step diagnosis below never fires.
            try:
                from ioagentfarm.engine.supervisor import driver_state
                _ds = driver_state(run, store.list_steps(run_id))
                if _ds["stale"] and not _said_driver_gone:
                    _said_driver_gone = True
                    _a = _ds["heartbeat_age_s"]
                    _console.print(
                        f"  [red]the DRIVER is gone[/red] - no heartbeat for "
                        f"{'ever' if _a is None else f'{_a:.0f}s'}; nothing will move. "
                        f"Restart it: aicore resume {run_id}")
            except Exception:  # noqa: BLE001
                pass
            for s in store.list_steps(run_id):
                if s.get("status") != "running":
                    continue
                quiet = W.quiet_for(s)
                if quiet is None or quiet < quiet_after:
                    continue
                key = (s["step_key"], int(quiet // max(quiet_after, 1)))
                if key in diagnosed:
                    continue
                diagnosed.add(key)
                why = W.diagnose(store, run_id, s["step_key"], root_path)
                _console.print(
                    f"[yellow]  {s['step_key']} quiet for "
                    f"{int(quiet)}s -> {why}[/yellow]")
            time.sleep(interval)
    except KeyboardInterrupt:
        _console.print("\n[dim]stopped watching. The run is unaffected.[/dim]")
