"""``aicore route "<query>"`` - which agent's DECLARED scope matches, and why.

The terminal half of `engine/router.py`. Prints an ASCII table of the
candidates (agent, kind, score, matched terms, why) and the choice - or the
stated reason nothing was chosen. ``--json`` prints `RouteResult.to_dict()`.
No model is called; the answer is the same every time for the same cards.
"""
from __future__ import annotations

import os
from typing import Optional

import typer
from rich.console import Console
from rich.markup import escape
from rich.table import Table

_console = Console()


def route(
    query: str = typer.Argument(..., help="The request to route."),
    top: int = typer.Option(3, "--top", help="How many candidates to show."),
    min_score: int = typer.Option(1, "--min-score", help="Below this nothing is chosen."),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace code (default: the selection in force)."),
    no_external: bool = typer.Option(False, "--no-external", help="Skip the workspace's external A2A registry."),
    as_json: bool = typer.Option(False, "--json", help="Machine-readable."),
):
    """Which agent should handle a request - decided from the agents' cards, not by a model.

    Scores every local role (the roster `list-agents` prints) on its A2A
    card's skill tags, skill ids/names, examples and description, and every
    external agent in the workspace's registry on its declared description,
    tags and examples. Explained per term; `chosen` is empty when no
    declared scope matches, and the meta-agent (a swarm) or the default chat
    role handles it.
    """
    import json as _json
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace
    from ioagentfarm.engine.discovery import ascii_only
    from ioagentfarm.engine.router import route as _route
    from ioagentfarm.engine.workspaces import maybe_workspace_code
    code = maybe_workspace_code()
    if not code and not os.environ.get("IOF_AGENT_HOME", "").strip():
        _console.print("[red]route reads each agent's card from its home inside a "
                       "workspace, and none is selected[/red]", soft_wrap=True)
        _console.print("  [dim]select one:[/dim]  aicore workspace use <code>   "
                       "(or pass --workspace)", soft_wrap=True)
        raise typer.Exit(code=1)
    result = _route(query, code, top=top, min_score=min_score,
                    include_external=not no_external)
    if as_json:
        typer.echo(_json.dumps(result.to_dict(), indent=2))
        return
    table = Table(title=f"route: {ascii_only(query)[:70]}", show_lines=False)
    table.add_column("agent", style="cyan", no_wrap=True)
    table.add_column("kind", style="dim", no_wrap=True)
    table.add_column("score", justify="right", no_wrap=True)
    table.add_column("matched")
    table.add_column("why")
    for c in result.candidates:
        agent = c.agent + ("  [green]<- chosen[/green]" if c.agent == result.chosen else "")
        table.add_row(agent, c.kind, str(c.score),
                      escape(ascii_only(", ".join(c.matched)) or "-"),
                      escape(ascii_only(c.why)))
    _console.print(table)
    if result.chosen:
        _console.print(f"chosen: [bold]{result.chosen}[/bold]  (method={result.method}, "
                       f"min-score={result.min_score}, tokens: "
                       f"{escape(ascii_only(', '.join(result.tokens)) or '-')})")
    else:
        _console.print(f"chosen: [yellow]none[/yellow] - {escape(ascii_only(result.why))}")
