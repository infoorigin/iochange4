"""``aicore eval`` - run a suite live or from a cassette, and read results.

    aicore eval run    <suite.yaml> --live http://127.0.0.1:8111 [--record out.jsonl]
    aicore eval run    <suite.yaml> --replay cassette.jsonl
    aicore eval record <suite.yaml> --live URL --out cassette.jsonl
    aicore eval list   [--json]
    aicore eval show   <suite> [--all] [--json]

Exit codes: 0 every case passed, 3 at least one failed, 2 usage error.
Engine: ``engine/eval/``; reference: docs/reference/eval-and-feedback.md.
"""
from __future__ import annotations

import json
import os
import sys
from typing import List, Optional

import typer

eval_app = typer.Typer(
    name="eval",
    help="Offline eval: run a suite live or from a recorded cassette; list and show results.",
    no_args_is_help=True,
)

_WS = typer.Option(None, "--workspace", "-w", help="Workspace whose database records the results (default: the selection in force).")
_JSON = typer.Option(False, "--json", help="Machine-readable output.")
FAIL_EXIT = 3


def _store_for(workspace: Optional[str]):
    """The results store, through the CLI's own resolvers. A run with no
    workspace selected still runs - results land in the root's default store,
    and `_store` announces which one on stderr."""
    from ioagentfarm import cli as _cli
    try:
        from ioagentfarm.engine.workspaces import selected_workspace
        code = selected_workspace(workspace)[0]
    except Exception:       # noqa: BLE001 - selection is optional here
        code = None
    if code:
        from ioagentfarm.engine.workspace_env import load_workspace_env
        load_workspace_env(code)
        if workspace:
            os.environ["IOF_WORKSPACE"] = workspace
    return _cli._store(_cli._root())


def _load(suite_path: str):
    from ioagentfarm.engine.eval.suite import SuiteError, load_suite
    try:
        return load_suite(suite_path)
    except SuiteError as exc:
        typer.echo(f"eval: {exc}", err=True)
        raise typer.Exit(code=2)


def _print_result(r) -> None:
    mark = "PASS" if r.passed else "FAIL"
    dur = f"{r.duration_s:.1f}s" if r.duration_s is not None else "-"
    line = f"  [{mark}] {r.case_id:<28} {dur:>8}"
    if not r.passed:
        line += f"  {r.reason}"
    typer.echo(line)


def _run(suite_path: str, live: Optional[str], replay: Optional[str],
         record: Optional[str], only: List[str], workspace: Optional[str],
         persist: bool, as_json: bool, agent: Optional[str]) -> None:
    from ioagentfarm.engine.eval import results as R
    from ioagentfarm.engine.eval.runner import (LiveExecutor, ReplayExecutor,
                                                run_suite, tally)
    if bool(live) == bool(replay):
        typer.echo("eval: pass exactly one of --live URL or --replay CASSETTE", err=True)
        raise typer.Exit(code=2)
    if record and not live:
        typer.echo("eval: --record only applies with --live (a replay is already recorded)", err=True)
        raise typer.Exit(code=2)
    suite = _load(suite_path)
    if agent:
        suite.agent = agent
    if live:
        executor = LiveExecutor(live)
    else:
        try:
            executor = ReplayExecutor(replay)
        except (FileNotFoundError, ValueError) as exc:
            typer.echo(f"eval: {exc}", err=True)
            raise typer.Exit(code=2)
    if not as_json:
        where = f"live against {live}" if live else f"replay from {replay}"
        typer.echo(f"eval suite '{suite.name}' (agent {suite.agent}, "
                   f"{len(suite.cases)} case(s)) {where}"
                   + (f", recording to {record}" if record else ""))
    results = run_suite(suite, executor, record_to=record,
                        only=set(only) if only else None,
                        on_case=None if as_json else _print_result)
    stamp = None
    if persist:
        try:
            stamp = R.persist(_store_for(workspace), results)
        except Exception as exc:    # noqa: BLE001 - a result store is not the run
            typer.echo(f"eval: results were NOT persisted ({type(exc).__name__}: {exc})", err=True)
    t = tally(results)
    if as_json:
        typer.echo(json.dumps({"suite": suite.name, "agent": suite.agent,
                               "mode": executor.mode, "recorded_to": record,
                               "persisted_at": stamp, **t,
                               "results": [r.as_dict() for r in results]},
                              indent=2, default=str))
    else:
        typer.echo(f"pass rate: {t['passed']}/{t['total']}"
                   + (f"  (recorded at {stamp})" if stamp else ""))
    raise typer.Exit(code=0 if t["failed"] == 0 and t["total"] > 0 else FAIL_EXIT)


@eval_app.command("run")
def run_cmd(suite: str = typer.Argument(..., help="Path to the suite YAML."),
            live: Optional[str] = typer.Option(None, "--live", help="Engine base URL to drive, e.g. http://127.0.0.1:8111."),
            replay: Optional[str] = typer.Option(None, "--replay", help="Cassette (JSONL) to grade offline - no server, no model."),
            record: Optional[str] = typer.Option(None, "--record", help="With --live: write the turns to this cassette."),
            only: List[str] = typer.Option([], "--case", help="Run only this case id (repeatable)."),
            agent: Optional[str] = typer.Option(None, "--agent", help="Override the suite's agent role."),
            workspace: Optional[str] = _WS,
            persist: bool = typer.Option(True, "--persist/--no-persist", help="Write results to eval_results."),
            as_json: bool = _JSON):
    """Run a suite. Exactly one of --live or --replay."""
    _run(suite, live, replay, record, only, workspace, persist, as_json, agent)


@eval_app.command("record")
def record_cmd(suite: str = typer.Argument(..., help="Path to the suite YAML."),
               live: str = typer.Option(..., "--live", help="Engine base URL to drive."),
               out: str = typer.Option(..., "--out", help="Cassette (JSONL) to write."),
               only: List[str] = typer.Option([], "--case", help="Record only this case id (repeatable)."),
               agent: Optional[str] = typer.Option(None, "--agent", help="Override the suite's agent role."),
               workspace: Optional[str] = _WS,
               persist: bool = typer.Option(True, "--persist/--no-persist"),
               as_json: bool = _JSON):
    """Run live and write the cassette `eval run --replay` grades offline."""
    _run(suite, live, None, out, only, workspace, persist, as_json, agent)


@eval_app.command("list")
def list_cmd(workspace: Optional[str] = _WS, as_json: bool = _JSON):
    """Every suite with a persisted result, and its latest run's tally."""
    from ioagentfarm.engine.eval import results as R
    rows = R.list_suites(_store_for(workspace))
    if as_json:
        typer.echo(json.dumps(rows, indent=2, default=str))
        return
    if not rows:
        typer.echo("no eval results recorded yet - run `aicore eval run <suite> --replay|--live ...`")
        return
    typer.echo(f"  {'suite':<28} {'last run':<26} {'mode':<7} {'runs':>4}  passed")
    for r in rows:
        typer.echo(f"  {r['suite']:<28} {r['last_run']:<26} {r['mode']:<7} "
                   f"{r['runs']:>4}  {r['passed']}/{r['total']}")


@eval_app.command("show")
def show_cmd(suite: str = typer.Argument(..., help="Suite name (as listed)."),
             all_runs: bool = typer.Option(False, "--all", help="Every run, newest first, not only the latest."),
             workspace: Optional[str] = _WS, as_json: bool = _JSON):
    """The latest run's per-case results for a suite."""
    from ioagentfarm.engine.eval import results as R
    rows = R.show(_store_for(workspace), suite, all_runs=all_runs)
    if as_json:
        typer.echo(json.dumps(rows, indent=2, default=str))
        return
    if not rows:
        typer.echo(f"no results for suite '{suite}' - `aicore eval list` names the suites recorded")
        raise typer.Exit(code=1)
    typer.echo(f"  {'created_at':<26} {'mode':<7} {'case':<28} {'result':<6} {'dur':>7}  reason")
    for r in rows:
        dur = f"{r['duration_s']:.1f}s" if r["duration_s"] is not None else "-"
        typer.echo(f"  {r['created_at']:<26} {r['mode']:<7} {r['case_id']:<28} "
                   f"{'PASS' if int(r['passed']) else 'FAIL':<6} {dur:>7}  {r['reason']}")
    if any(not int(r["passed"]) for r in rows):
        sys.exit(FAIL_EXIT)
