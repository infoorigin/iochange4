"""``aicore retention`` — what the retention policy would delete, and deleting it.

    aicore retention show  [--json]
    aicore retention prune [--older-than 30d] [--what runs,blobs,conversations,memory]
                           [--dry-run] [--yes] [--json]

The policy comes from ``IOF_RETENTION`` (a path) or
``~/.iobot/workspaces/<code>/retention.yaml``; with neither, ``prune``
refuses unless ``--older-than`` names a window explicitly. Nothing here
deletes on a number nobody wrote down. Engine: ``engine/retention.py``.
"""
from __future__ import annotations

import json
import os
from typing import List, Optional

import typer

retention_app = typer.Typer(
    name="retention",
    help="Data retention: show what the policy would delete now, and prune it.",
    no_args_is_help=True,
)

_WS = typer.Option(None, "--workspace", "-w", help="Workspace code (default: the selection in force).")
_JSON = typer.Option(False, "--json", help="Machine-readable output.")


def _ctx(workspace: Optional[str]):
    """``(root, store, workspace_code)`` through the CLI's own resolvers, so
    local mode, the workspace .env and the mode banner apply as everywhere."""
    from ioagentfarm import cli as _cli
    from ioagentfarm.engine.workspaces import selected_workspace, RETIRED_WORKSPACE_CODES
    code = selected_workspace(workspace)[0]
    if not code:
        raise typer.BadParameter(
            "no workspace selected: pass --workspace <code>, set IOF_WORKSPACE, "
            "or run `aicore workspace use <code>`")
    if code in RETIRED_WORKSPACE_CODES:
        raise typer.BadParameter(f"'{code}' is not a selectable workspace")
    from ioagentfarm.engine.workspace_env import load_workspace_env
    load_workspace_env(code)
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace
    root = _cli._root()
    store = _cli._store(root)
    return root, store, code


def _policy_or_error(code: str, as_json: bool):
    from ioagentfarm.engine.retention import PolicyError, load_policy
    try:
        return load_policy(code)
    except PolicyError as exc:
        if as_json:
            typer.echo(json.dumps({"error": str(exc)}))
        raise typer.BadParameter(str(exc))


def _classes(what: Optional[str]) -> List[str]:
    from ioagentfarm.engine.retention import CLASSES
    if not what:
        return list(CLASSES)
    names = [w.strip() for w in what.split(",") if w.strip()]
    bad = [n for n in names if n not in CLASSES]
    if bad:
        raise typer.BadParameter(
            f"unknown class(es) {', '.join(bad)}; the legal values are {', '.join(CLASSES)}")
    return names


def _table(rows: List[List[str]], header: List[str]) -> str:
    """A plain ASCII table - no box glyphs, so it survives any console."""
    widths = [len(h) for h in header]
    for r in rows:
        for i, cell in enumerate(r):
            widths[i] = max(widths[i], len(str(cell)))
    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    out = [line, "| " + " | ".join(str(h).ljust(widths[i]) for i, h in enumerate(header)) + " |", line]
    for r in rows:
        out.append("| " + " | ".join(str(c).ljust(widths[i]) for i, c in enumerate(r)) + " |")
    out.append(line)
    return "\n".join(out)


def _render_plan(p, policy) -> str:
    from ioagentfarm.engine.retention import format_duration
    c = p.counts()
    rows = [
        ["runs", format_duration(policy.runs), str(c["runs"]),
         f"+ {c['run_children']} child rows (steps, tasks, stories, messages, events)"],
        ["blobs", format_duration(policy.blobs), str(c["blobs"]),
         "instance directories under <IOF_ROOT>/instances/"
         + (" (failed runs kept)" if policy.keep_failed else "")],
        ["conversations", format_duration(policy.conversations), str(c["conversations"]),
         f"+ {c['conversation_messages']} turns, {c['messages_unattached']} chat messages "
         f"with no run"],
        ["memory", "expires_at", str(c["memory"]), "rows past their own expiry"],
    ]
    rows = [r for r in rows if r[0] in p.classes]
    text = _table(rows, ["class", "window", "delete now", "detail"])
    left = ", ".join(f"{k}={v}" for k, v in sorted(p.left.items()) if v)
    if left:
        text += f"\nleft alone: {left}"
    return text


@retention_app.command("show")
def show(workspace: Optional[str] = _WS, as_json: bool = _JSON):
    """The resolved policy, where it came from, and what `prune` would delete now."""
    from ioagentfarm.engine.retention import Policy, plan
    root, store, code = _ctx(workspace)
    policy = _policy_or_error(code, as_json)
    effective = policy or Policy()
    p = plan(store, root, effective, workspace_code=code)
    if as_json:
        out = p.as_dict()
        out["policy_present"] = policy is not None
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo(f"workspace: {code}")
    typer.echo(f"policy:    {policy.source if policy else '(none)'}")
    if policy is None:
        typer.echo("           no retention policy applies - `prune` needs an explicit "
                   "--older-than; nothing is deleted on a default")
    else:
        typer.echo(f"           runs={_fmt(policy.runs)} blobs={_fmt(policy.blobs)} "
                   f"conversations={_fmt(policy.conversations)} keep_failed={policy.keep_failed}")
    typer.echo(f"root:      {root}")
    typer.echo("")
    typer.echo(_render_plan(p, effective))


def _fmt(td) -> str:
    from ioagentfarm.engine.retention import format_duration
    return format_duration(td)


@retention_app.command("prune")
def prune(
    older_than: Optional[str] = typer.Option(
        None, "--older-than", help="Window for every class named by --what, e.g. 30d or 12h. "
                                   "Overrides the policy; required when no policy file applies."),
    what: Optional[str] = typer.Option(
        None, "--what", help="Comma-separated classes: runs,blobs,conversations,memory "
                             "(default: all)."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print the plan and delete nothing."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Do not ask for confirmation."),
    workspace: Optional[str] = _WS,
    as_json: bool = _JSON,
):
    """Delete what the policy (or --older-than) says has expired. Asks first unless --yes."""
    from ioagentfarm.engine.retention import (PolicyError, apply, override, parse_duration,
                                              plan)
    root, store, code = _ctx(workspace)
    classes = _classes(what)
    policy = _policy_or_error(code, as_json)
    if older_than:
        try:
            window = parse_duration(older_than)
        except PolicyError as exc:
            raise typer.BadParameter(str(exc))
        effective = override(policy, window, classes)
    elif policy is None:
        msg = ("no retention policy applies to this workspace (no IOF_RETENTION file, no "
               f"~/.iobot/workspaces/{code}/retention.yaml) - pass --older-than <n>d|<n>h "
               "to say what expired; nothing is deleted on a default")
        if as_json:
            typer.echo(json.dumps({"error": msg}))
        raise typer.BadParameter(msg)
    else:
        effective = policy
    windowed = [c for c in classes if c == "memory" or effective.window(c) is not None]
    p = plan(store, root, effective, workspace_code=code, classes=windowed)

    if not as_json:
        typer.echo(f"workspace: {code}")
        typer.echo(f"policy:    {effective.source}")
        typer.echo("")
        typer.echo(_render_plan(p, effective))
    if dry_run:
        if as_json:
            out = p.as_dict()
            out["dry_run"] = True
            typer.echo(json.dumps(out, indent=2, default=str))
        else:
            typer.echo("\ndry run: nothing deleted")
        return
    if p.is_empty():
        if as_json:
            typer.echo(json.dumps({"plan": p.as_dict(), "removed": {}, "dry_run": False},
                                  indent=2, default=str))
        else:
            typer.echo("\nnothing to delete")
        return
    if not yes:
        if as_json:
            typer.echo(json.dumps({"error": "confirmation required: pass --yes (or --dry-run)"}))
            raise typer.Exit(code=2)
        if not typer.confirm("Delete the rows and directories above?", default=False):
            typer.echo("aborted: nothing deleted")
            raise typer.Exit(code=1)
    report = apply(store, root, p)
    if as_json:
        out = report.as_dict()
        out["plan"] = p.as_dict()
        out["dry_run"] = False
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo("")
    removed = ", ".join(f"{k}={v}" for k, v in sorted(report.removed.items())) or "nothing"
    typer.echo(f"removed: {removed}")
    for s in report.skipped:
        typer.echo(f"skipped: {s}")
    for e in report.errors:
        typer.echo(f"error:   {e}", err=True)
