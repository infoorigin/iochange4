"""What the repository ACTUALLY contains, counted by the harness.

THE FAILURE THIS EXISTS FOR, measured in a live session. Told to rename an
agent and then to revert, Cora left BOTH `contract_ida` and `contract_nina`
on disk and reported: *"contract_ida never existed as a real agent
directory, so nothing needed renaming."* Asked in the next turn to "list
every agent directory that is actually on disk", it listed two of the three
and closed with *"everything was already built correctly"*. The orphan it
had made itself was the one it could not see.

A model summarising its own work is describing the tree it INTENDED. The
review charter already carries the rule that answers this - *state facts
about the repository only from what you OBSERVED* - but that rule lives on
the review path, and the failure is on the build path.

So the count is taken from the filesystem, by code, and printed by the
console. It is the same principle as the rest of this console: narration,
tool lines, edit hunks and the context meter are all produced by the harness
from what it observes, never by asking the model to report on itself. What
the model says is a claim; this is the measurement beside it.

Deliberately CHEAP and shallow: a directory listing and a YAML key count,
no imports of the pack machinery, nothing that can fail slowly. It runs
after every mutating turn.
"""
from __future__ import annotations

from pathlib import Path

#: Directories that are never content, whatever they contain.
_SKIP = {".git", ".iof", ".venv", "node_modules", "__pycache__", "build",
         "dist", ".pytest_cache", ".mypy_cache"}

#: How deep to look for a content root. A solution sits at the repo root or
#: one level down (`solutions/<name>/`, `<pkg>/`); three levels is already
#: generous and keeps this off a big checkout's hot path.
_MAX_DEPTH = 3


def _content_dirs(root: Path, name: str) -> list[Path]:
    """Every `<name>/` directory that looks like content, shallowest first."""
    found: list[Path] = []
    root = Path(root)
    stack = [(root, 0)]
    while stack:
        cur, depth = stack.pop()
        try:
            entries = list(cur.iterdir())
        except OSError:
            continue
        for entry in entries:
            if not entry.is_dir() or entry.name in _SKIP:
                continue
            if entry.name == name:
                found.append(entry)
            elif depth < _MAX_DEPTH:
                stack.append((entry, depth + 1))
    return found


def _named_children(dirs: list[Path], marker: str | None = None) -> list[str]:
    """Child directory names across *dirs*, optionally requiring a marker file."""
    out: set[str] = set()
    for d in dirs:
        try:
            for child in d.iterdir():
                if not child.is_dir() or child.name.startswith((".", "_")):
                    continue
                if marker and not any(child.glob(marker)):
                    continue
                out.add(child.name)
        except OSError:
            continue
    return sorted(out)


def locate(repo) -> dict:
    """Where each piece of content LIVES: ``{kind: {name: relative path}}``.

    `take` answers "what is here" and throws the directory away, which is
    all a console summary needs. `/undo` needs the path: a directory that
    did not exist before a turn and now holds an agent is build output, and
    without somewhere to look that up every scaffolded file reads as the
    user's own work.

    Same markers as `take`, so the two cannot disagree about what counts as
    an agent. Never raises, for the same reason.
    """
    repo = Path(repo)
    out: dict = {"agents": {}, "skills": {}, "workflows": {}, "swarms": {},
                 "mcp_servers": {}}
    try:
        for kind, marker in (("agents", "**/SOUL.md"),
                             ("workflows", "workflow.yaml"),
                             ("swarms", "swarm.yaml"),
                             ("skills", "SKILL.md")):
            for d in _content_dirs(repo, kind):
                for child in d.iterdir():
                    if not child.is_dir() or child.name.startswith((".", "_")):
                        continue
                    if marker and not any(child.glob(marker)):
                        continue
                    out[kind].setdefault(child.name, _rel(child, repo))
        # A server is a NAME inside a file, not a directory - so the path
        # that carries it is the declaration file itself.
        import os as _os
        _mcp_paths = []
        for base, dirs, files in _os.walk(repo):
            dirs[:] = [d for d in dirs if d not in _SKIP]
            if "mcp.yaml" in files:
                _mcp_paths.append(Path(base) / "mcp.yaml")
        for path in _mcp_paths:
            try:
                import yaml
                data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                servers = data.get("mcp_servers")
                if isinstance(servers, dict):
                    for name in servers:
                        out["mcp_servers"].setdefault(str(name),
                                                      _rel(path, repo))
            except Exception:              # noqa: BLE001
                continue
    except Exception:                      # noqa: BLE001 - see docstring
        pass
    return out


def _rel(path: Path, repo: Path) -> str:
    try:
        return str(Path(path).resolve().relative_to(Path(repo).resolve())
                   ).replace("\\", "/")
    except (OSError, ValueError):
        return str(path)


def take(repo) -> dict:
    """The inventory: agents, skills, workflows, swarms, MCP servers.

    Never raises - an inventory that can fail is one more thing to explain
    when a turn already went wrong.
    """
    repo = Path(repo)
    inv: dict = {"agents": [], "skills": [], "workflows": [], "swarms": [],
                 "mcp_servers": []}
    try:
        # An agent is a directory holding SOUL.md, at any nesting under an
        # `agents/` dir. The marker matters: `new-agent` makes
        # `agents/<role>/workspace/SOUL.md`, and a half-made agent with no
        # SOUL is exactly the orphan worth showing.
        inv["agents"] = _named_children(_content_dirs(repo, "agents"),
                                        "**/SOUL.md")
        inv["workflows"] = _named_children(_content_dirs(repo, "workflows"),
                                           "workflow.yaml")
        inv["swarms"] = _named_children(_content_dirs(repo, "swarms"),
                                        "swarm.yaml")
        inv["skills"] = _named_children(_content_dirs(repo, "skills"),
                                        "SKILL.md")
        inv["mcp_servers"] = _mcp_names(repo)
    except Exception:                      # noqa: BLE001 - see docstring
        pass
    return inv


def _mcp_names(repo: Path) -> list[str]:
    """Server names declared by this repository's own `mcp.yaml` files."""
    names: set[str] = set()
    for path in Path(repo).rglob("mcp.yaml"):
        if any(part in _SKIP for part in path.parts):
            continue
        try:
            import yaml
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            servers = data.get("mcp_servers")
            if isinstance(servers, dict):
                names |= {str(k) for k in servers}
        except Exception:                  # noqa: BLE001
            continue
    return sorted(names)


def changed(before: dict, after: dict) -> dict:
    """What appeared and disappeared between two inventories."""
    delta: dict = {}
    for key in after:
        was, now = set(before.get(key) or []), set(after.get(key) or [])
        added, gone = sorted(now - was), sorted(was - now)
        if added or gone:
            delta[key] = {"added": added, "removed": gone}
    return delta


def summary_line(inv: dict) -> str:
    """One line naming what is here, or "" when the repo holds no content."""
    parts = []
    for key, label in (("agents", "agents"), ("skills", "skills"),
                       ("workflows", "workflows"), ("swarms", "swarms"),
                       ("mcp_servers", "mcp")):
        items = inv.get(key) or []
        if items:
            parts.append(f"{label}: {', '.join(items)}")
    return "  ".join(parts)
