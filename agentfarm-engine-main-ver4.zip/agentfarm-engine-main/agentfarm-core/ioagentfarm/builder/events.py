"""Parsing the session record into display events for the live view."""
from __future__ import annotations

import json
import re


# The runtime CHECKPOINTS the session file after every round - the metadata
# line carries `runtime_checkpoint` with the round's assistant message,
# pending tool calls and completed results, thinking held in separate fields.
# The watcher renders those events, which is how the console stays lively
# without pattern-matching the stream and without asking the model to narrate
# its own progress: the harness shows what it OBSERVES, never what the model
# remembers to say.

_ARG_KEYS = ("command", "path", "file_path", "name", "url", "query")

#: Tools whose CONTENT is worth showing as it is written - the diff-green
#: preview that makes a build feel watched rather than waited on.
_WRITE_TOOLS = ("write_file", "apply_patch", "edit_file")

#: Tools whose arguments carry OLD and NEW text - the real red/green hunk.
_EDIT_TOOLS = ("edit_file", "apply_patch")

#: Lines of authored content shown per write. Enough to see the shape of
#: what is landing; never the whole file - that is what /diff is for.
_PREVIEW_LINES = 12


def _parse_call(tc: dict) -> tuple[str, dict]:
    """(tool name, arguments dict) from one pending_tool_calls entry."""
    fn = (tc.get("function") or {}) if isinstance(tc, dict) else {}
    name = str(fn.get("name") or tc.get("name") or "tool")
    raw = fn.get("arguments") or tc.get("arguments") or ""
    try:
        d = json.loads(raw) if isinstance(raw, str) else (raw or {})
        return name, d if isinstance(d, dict) else {}
    except ValueError:
        return name, {}


def _shorten_arg(arg: str, repo=None, width: int = 72) -> str:
    """Make one tool argument READABLE at a glance.

    Truncating a path at the head is the same as printing nothing: a run of
    reads rendered as `read_file: C:\\Users\\...\\ghts-io-procur...` eight
    times, which is what a silent stretch of the console actually looked
    like. A path is identified by its END and a command by its BEGINNING,
    so they are shortened from opposite sides - and anything under the repo
    is shown relative to it, which alone removes most of the length.
    """
    arg = " ".join(str(arg).split())
    if repo is not None:
        try:
            from pathlib import Path
            base = str(Path(repo).resolve())
            # substring rather than relative_to: the argument may be a whole
            # command line with the path embedded in it.
            if base in arg:
                arg = arg.replace(base + "\\", "").replace(base + "/", "")
                arg = arg.replace(base, ".")
        except (OSError, ValueError):
            pass
    if len(arg) <= width:
        return arg
    looks_like_path = " " not in arg and ("/" in arg or "\\" in arg)
    if looks_like_path:
        return "..." + arg[-(width - 3):]        # the filename identifies it
    return arg[:width - 3] + "..."               # the verb identifies it


def _compact_call(tc: dict, repo=None) -> str:
    """`exec: aicore new-agent pricing_analyst ...` - name plus the one
    argument a reader recognises, shortened so it still reads."""
    name, d = _parse_call(tc)
    arg = ""
    for k in _ARG_KEYS:
        if d.get(k):
            arg = str(d[k])
            break
    else:
        if d:
            arg = str(next(iter(d.values()), ""))
    arg = _shorten_arg(arg, repo)
    return f"{name}: {arg}" if arg else name


def _write_preview(d: dict, repo=None) -> tuple[str, list[str], int] | None:
    """(path, preview lines, hidden-line count) for a content-writing call.

    The path is shortened like any other argument: the write line is the
    most valuable one in the stream and an absolute temp path pushes the
    filename off the end of it.
    """
    path = _shorten_arg(str(d.get("path") or d.get("file_path") or ""), repo)
    content = d.get("content")
    if not path or not isinstance(content, str) or not content.strip():
        return None
    lines = content.splitlines()
    return path, lines[:_PREVIEW_LINES], max(0, len(lines) - _PREVIEW_LINES)


def _checkpoint_events(meta: dict, seen: set,
                       repo=None) -> list[tuple[str, str]]:
    """New (kind, text) display events from one metadata snapshot.

    ``seen`` de-duplicates across polls: a checkpoint is rewritten in place,
    so every poll sees the current round again. Keys are (iteration, phase,
    n) tuples - stable for a given round, distinct across rounds.
    """
    cp = (meta or {}).get("runtime_checkpoint") or {}
    if not isinstance(cp, dict):
        return []
    it, phase = cp.get("iteration"), cp.get("phase")
    out: list[tuple[str, str]] = []

    am = cp.get("assistant_message") or {}
    text = (am.get("content") or "").strip() if isinstance(am, dict) else ""
    if text and ("prose", it) not in seen:
        seen.add(("prose", it))
        out.append(("prose", text))

    for n, tc in enumerate(cp.get("pending_tool_calls") or []):
        k = ("call", it, n)
        if k not in seen:
            seen.add(k)
            name, d = _parse_call(tc)
            if name in _EDIT_TOOLS:
                hunks, more = _edit_hunks(name, d, repo)
                if hunks:
                    out.append(("edit", (hunks, more)))
                    continue
            if name in _WRITE_TOOLS:
                pv = _write_preview(d, repo)
                if pv:
                    out.append(("write", pv))
                    continue
            out.append(("call", _compact_call(tc, repo)))

    if phase == "tools_completed":
        for n, tr in enumerate(cp.get("completed_tool_results") or []):
            k = ("result", it, n)
            if k in seen:
                continue
            seen.add(k)
            body = str((tr or {}).get("content", "")) if isinstance(tr, dict) \
                else str(tr)
            first = body.strip().splitlines()[0] if body.strip() else ""
            if first.startswith(("Error", "error:", "Traceback")):
                out.append(("error", first[:110]))
            elif _is_reply_call(cp, n):
                out.append(("reply", _reply_lines(body)))
            else:
                # EVERY call visibly lands, not only the failed ones. The
                # single biggest distance to the Claude Code feel, measured
                # in the 2026-08-11 field run: a read showed the call and
                # then silence, so a burst of tool lines read as dead air
                # even though every one of them returned data.
                out.append(("result", _result_summary(body)))
    return out


#: Commands whose OUTPUT is the deliverable. Every other exec result is
#: summarised to one line - the call landed, roughly what came back - and
#: that was right until a user asked the builder to talk to another agent
#: and read "Ray replied successfully" where Ray's reply should have been.
#: The result of a conversation the user asked for is theirs to read.
_REPLY_COMMANDS = ("aicore agent-chat", "ioagentfarm agent-chat",
                   "iof-consult")

#: Header lines the chat command prints before the agent's words.
_REPLY_NOISE = ("Using config:", "Using workspace:")
_REPLY_MAX_LINES = 60


def _is_reply_call(cp: dict, n: int) -> bool:
    """Is completed result *n* the output of an agent conversation?"""
    calls = cp.get("pending_tool_calls") or []
    if n >= len(calls):
        return False
    name, d = _parse_call(calls[n])
    if name != "exec":
        return False
    cmd = " ".join(str(d.get("command") or "").split())
    return any(cmd.startswith(c) or f" {c} " in f" {cmd} "
               for c in _REPLY_COMMANDS)


def _reply_lines(body) -> tuple[list[str], int]:
    """(lines to print, hidden count) - the reply without its headers."""
    lines = [l.rstrip() for l in str(body or "").splitlines()]
    while lines and (not lines[0].strip()
                     or lines[0].lstrip().startswith(_REPLY_NOISE)):
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    return lines[:_REPLY_MAX_LINES], max(0, len(lines) - _REPLY_MAX_LINES)


def _result_summary(body) -> str:
    """One dim line saying what a tool call RETURNED.

    Compact on purpose - the point is that the call landed and roughly what
    came back, not the payload. The payload is in the session record.
    """
    s = str(body or "").strip()
    if not s:
        return "done"
    lines = s.splitlines()
    first = " ".join(lines[0].split())
    if len(first) > 88:
        first = first[:85] + "..."
    if len(lines) == 1:
        return first or "done"
    return f"{len(lines)} line(s) - {first}"


#: `[step 2/6] wrote the catalog` - the plan-progress marker /go asks the
#: model to print as it completes each numbered step. RECOGNITION is
#: engineering (this regex + the check-glyph render); EMISSION is a request
#: to the model, and degrades to ordinary narration when ignored - no state,
#: no failure mode, just a lost nicety.
_PLAN_STEP = re.compile(r"^\[step\s+(\d+)\s*/\s*(\d+)\]\s*(.*)", re.IGNORECASE)


def _plan_step(text: str) -> tuple[int, int, str] | None:
    m = _PLAN_STEP.match(str(text).strip())
    return (int(m.group(1)), int(m.group(2)), m.group(3).strip()) if m else None


def _edit_hunks(name: str, d: dict, repo=None):
    """((path, [("-"/"+", line), ...], hidden), ...), plus uncounted edits.

    The last big Claude Code element with no counterpart here: an edit
    showed only its path, so the one moment the user most wants to watch -
    existing content CHANGING - was invisible. The arguments have carried
    the full old/new text all along (`edit_file`: path/old_text/new_text;
    `apply_patch`: an `edits` list of the same shape); this just stops
    throwing them away.
    """
    if name == "edit_file":
        entries = [d]
    elif name == "apply_patch":
        entries = [e for e in (d.get("edits") or []) if isinstance(e, dict)]
    else:
        return [], 0
    hunks = []
    for e in entries[:3]:
        path = _shorten_arg(str(e.get("path") or ""), repo)
        old = str(e.get("old_text") or "")
        new = str(e.get("new_text") or "")
        if not path or not (old.strip() or new.strip()):
            continue
        minus, plus = old.splitlines(), new.splitlines()
        # one budget across both sides; old first, because what is being
        # REPLACED is the context the new lines need
        keep_minus = minus[:_PREVIEW_LINES // 2] if plus else             minus[:_PREVIEW_LINES]
        keep_plus = plus[:_PREVIEW_LINES - len(keep_minus)]
        hidden = (len(minus) - len(keep_minus)) + (len(plus) - len(keep_plus))
        lines = ([("-", ln) for ln in keep_minus]
                 + [("+", ln) for ln in keep_plus])
        hunks.append((path, lines, hidden))
    return hunks, max(0, len(entries) - 3)


def repo_rel(path, repo=None) -> str:
    """One canonical form: repo-relative, forward slashes.

    The tool arguments carry ABSOLUTE paths and the checkpoint diff
    carries repo-relative ones with forward slashes, so comparing them
    raw can never match - measured live, where `/undo` refused to revert
    the agent's own file because attribution had silently missed every
    one of them. Fail-safe direction, still wrong. Both sides go through
    this.
    """
    import os as _os
    from pathlib import Path
    p = str(path).strip().strip('"')
    if repo is not None:
        try:
            cand = Path(p)
            if not cand.is_absolute():
                cand = Path(repo) / cand
            p = str(cand.resolve().relative_to(Path(repo).resolve()))
        except (OSError, ValueError):
            pass
    # Separators only where a separator can BE a backslash. On POSIX a
    # backslash is an ordinary filename character, and rewriting it makes
    # the attributed path stop matching the one git reported.
    if _os.sep == "\\":
        p = p.replace("\\", "/")
    # `lstrip("./")` strips a CHARACTER SET, not a prefix: it turned
    # `.gitignore` into `gitignore` and `.aicore/commands/x.md` into
    # `aicore/commands/x.md`, so every DOTFILE the builder wrote failed to
    # match git's own path and `/undo` classed it as the user's own work.
    # Dotfiles are most of what a solution repo's plumbing is.
    while p.startswith("./"):
        p = p[2:]
    # COMPOSED, because macOS is not. APFS/HFS+ store filenames decomposed,
    # so resolving a path through the filesystem above can hand back `e` +
    # combining acute where the tool argument had a single `é`. This is the
    # string `/undo` compares against git's, and git composes its side.
    import unicodedata
    return unicodedata.normalize("NFC", p)


def written_paths(name: str, args: dict, repo=None) -> list[str]:
    """Repo-relative paths a write/edit tool call TARGETS, unshortened.

    This is the attribution `/undo` needs. A checkpoint diff cannot tell the
    turn's work from the user's: a file the user edited in their editor
    while the turn ran looks identical to one the agent wrote, and reverting
    to the checkpoint destroys it. These paths are the ones the harness
    OBSERVED the agent target, so anything else in the diff is unattributed
    and must not be reverted without the user saying so.

    Deliberately not a filter for undo: scaffold commands create files
    through `exec`, which names no path, so attribution is a floor and never
    a complete account of the turn.
    """
    if name not in _WRITE_TOOLS:
        return []
    out = []
    for key in ("path", "file_path"):
        if args.get(key):
            out.append(repo_rel(args[key], repo))
    for e in (args.get("edits") or []):
        if isinstance(e, dict) and e.get("path"):
            out.append(repo_rel(e["path"], repo))
    return out
