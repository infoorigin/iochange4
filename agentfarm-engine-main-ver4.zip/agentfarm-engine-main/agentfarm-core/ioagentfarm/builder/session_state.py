"""The state one build session shares, and the operations over it.

Extracted from ``build()``, which reached 493 lines because seven closures
needed the same dozen names: the console, the glyph set, the state dict, the
repo, the role, the engine holder. A closure over an enclosing function is a
fine way to share three names and a poor way to share twelve - nothing can
be tested on its own, and every slash command has to live inside the same
function body.

The class holds that state once; the slash commands in :mod:`repl` are plain
module-level functions that take it.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from loguru import logger

#: Provider refusals that mean "this conversation no longer fits". The
#: wire error arrives as reply TEXT (never an exception), so the words are
#: the only signal there is.
import re as _re

_CTX_OVERFLOW_RX = _re.compile(
    r"context.length|context_length|prompt is too long|maximum context"
    r"|input length exceeds|too many tokens|context window", _re.I)

from ioagentfarm.builder.checkpoints import (_capture_tree, _review_diff,
                                           cp_provisional, cp_tree,
                                           _turn_changes, _undo_to_tree)
from ioagentfarm.builder.console import _glyphs, TAG, suspended_live
from ioagentfarm.builder.input_hub import prompt_input
from ioagentfarm.builder.events import _WRITE_TOOLS, repo_rel
from ioagentfarm.builder.session import (_PREAMBLE, commands_clause,
                                         mcp_clause, today_line,
                                         placement_clause,
                                         session_commands_clause, _save_state,
                                         _session_key, memory_clause,
                                         solution_clause)
from ioagentfarm.builder.turn import _PLAN_WRAP, _REVIEW_WRAP, _one_turn


#: How a narration line opens when it announces the NEXT action. The charter
#: bans "Let me" outright, so these are the forms that survive. Matched on
#: the FIRST WORD rather than by regex: the first version of this used `\b`
#: word boundaries, a heredoc turned each one into a literal backspace, and
#: the pattern then matched nothing at all while looking correct.
_ANNOUNCING = (
    "checking", "check", "reading", "read", "looking", "inspecting",
    "now", "next", "starting", "running", "fetching", "creating",
    "adding", "assigning", "wiring", "updating", "writing", "about",
)

#: Words and shapes that make a message a REPORT rather than an announcement.
#: Any one of these and the reply is describing an outcome.
_REPORTING = (
    "done", "created", "added", "wrote", "failed", "error", "lint",
    "git status", "here is", "here are", "result", "cannot", "can't",
    "not installed", "0 errors", "clean", "```",
)


def _looks_unfinished(reply: str) -> bool:
    """Does this reply announce an action and report none?

    Narrow on purpose - it must never fire on an ordinary short answer. A
    long reply is a report even if it opens with a verb; anything carrying
    an outcome word, a list, a table or a code fence is a report. What is
    left is the single dangling narration line this exists to catch.
    """
    text = (reply or "").strip()
    if not text or len(text) > 400 or len(text.splitlines()) > 2:
        return False
    low = text.lower()
    if any(word in low for word in _REPORTING):
        return False
    if text.lstrip().startswith(("-", "*", "|", "#")):
        return False
    first = low.split()[0].strip(",.:;") if low.split() else ""
    return first in _ANNOUNCING or low.startswith(("i'll ", "i will "))


class BuildSession:
    """Everything one `aicore build` invocation needs to run a turn."""

    def __init__(self, *, role: str, repo: Path, uid: str, ws_code: str,
                 root: Path, digest: str, state: dict, cfg_path,
                 console, git_ok: bool, gated: bool):
        self.role = role
        self.repo = repo
        self.uid = uid
        self.ws_code = ws_code
        self.root = root
        self.digest = digest
        self.state = state
        self.cfg_path = cfg_path
        self.console = console
        self.git_ok = git_ok
        #: MCP servers that will not answer this session, checked ONCE in
        #: this process (the runtime's own failure lands in a subprocess
        #: stderr log nothing renders). Filled by the caller; empty is the
        #: normal case and costs nothing.
        self.mcp_down: list = []
        self.G = _glyphs(console)
        self.engine = None
        self.gated = bool(gated)
        #: repo-relative paths the LAST turn's write/edit tools
        #: targeted. `/undo` reverts these without asking and
        #: never touches anything else without consent.
        self.written: set = set()

    # ── state ────────────────────────────────────────────────────────────
    def active(self) -> tuple:
        name = self.state["active"]
        return name, self.state["sessions"][name]

    def save(self, dropped: "set[str] | None" = None) -> None:
        """Persist the conversation map. ``dropped`` names conversations this
        caller deliberately removed — see ``_save_state``: the peer-merge
        cannot tell a rename-away from a peer's new session, so a removal has
        to be stated or it comes straight back."""
        _save_state(self.root, self.digest, self.state, dropped)

    # ── the in-process engine and its approval gate ──────────────────────
    def start_engine(self) -> None:
        """Attach the in-process engine, or explain why there is none.

        Failure is structural fallback: the notice names the reason and every
        turn then runs exactly as it did before the engine existed.
        """
        try:
            from ioagentfarm.builder.engine import BuildEngine
            engine = BuildEngine(self.role, self.repo, self.cfg_path)
            # BUILT HERE, NOT ON THE FIRST TURN. `BuildEngine.__init__`
            # only assigns six attributes and cannot realistically fail,
            # so this notice - and the subprocess fallback it announces -
            # was unreachable. The work that CAN fail (the config, the
            # provider, the MCP tiers, the tool wrapping) happened lazily
            # inside the first turn, where the failure was reported as
            # "the turn failed" and repeated identically on every turn
            # after it: a session dead from its first message with a
            # working fallback sitting unused.
            engine.build()
            self.engine = engine
        except Exception as exc:              # noqa: BLE001
            logger.debug("in-process engine unavailable", exc_info=True)
            self.console.print(
                f"[yellow]{TAG} in-process engine unavailable ({exc}) - "
                f"using subprocess turns[/]")
            self.engine = None

    def _approval_gate(self, tool_name: str, kwargs: dict) -> bool:
        """The y/n/all prompt between the model's decision and execution."""
        cmd = str(kwargs.get("command") or kwargs.get("cmd") or "")
        path = str(kwargs.get("path") or kwargs.get("file_path") or "")
        # ON A QUIET SCREEN: the turn's spinner is stopped for the prompt
        # and restarted after it. See `console.suspended_live` for the
        # 50-minute install prompt nobody could see.
        with suspended_live():
            self.console.print(f"\n[bold yellow]approve?[/] [cyan]{tool_name}[/] "
                               f"[dim]{(cmd or path)[:100]}[/]")
            if tool_name in _WRITE_TOOLS and kwargs.get("content"):
                for ln in str(kwargs["content"]).splitlines()[:6]:
                    self.console.print(f"    + {ln[:100]}", style="green",
                                       highlight=False, markup=False)
            elif tool_name in ("edit_file", "apply_patch"):
                # An edit's approval used to show only `approve? edit_file
                # <path>` - a yes/no about content the user could not see,
                # while the DISPLAY channel already knew the hunks.
                try:
                    from ioagentfarm.builder.events import _edit_hunks
                    hunks, _more = _edit_hunks(tool_name, kwargs, self.repo)
                    for _p, lines_, _hidden in hunks[:2]:
                        for sign, ln in lines_[:8]:
                            self.console.print(
                                f"    {sign} {ln[:100]}",
                                style="red" if sign == "-" else "green",
                                highlight=False, markup=False)
                except Exception:         # noqa: BLE001 - preview only
                    pass
            try:
                ans = prompt_input(
                    self.console,
                    "[bold]  \\[y]es  \\[n]o  \\[a]ll for this session > "
                ).strip().lower()
            except EOFError:
                return False
        if ans.startswith("a"):
            self.gated = False
            self.console.print("[dim]approval gate off for this session - "
                               "/gated on restores it[/]")
            return True
        return ans.startswith("y")

    def arm_gate(self) -> None:
        if self.engine is None:
            return
        use = self.gated and self.console.is_terminal
        self.engine.set_gate(self._approval_gate if use else None)
        # Installs are confirmed whether or not the general gate is on: a
        # session legitimately needs `pip install -e .` after `new-tool`
        # (a console script is generated by pip, not read from files), and
        # the harness used to refuse it outright, so the assistant printed
        # an instruction and the user ran it in another terminal.
        self.engine.set_install_gate(
            self._install_gate if self.console.is_terminal else None)

    def _install_gate(self, _kind: str, kwargs: dict) -> bool:
        """Confirm one environment-changing command.

        `IOF_BUILD_INSTALLS=never` (or `off`) refuses every install in this
        session without asking - for a machine where the person, not the
        builder, owns the environment. The refusal names the command so the
        person can run it themselves; the model is told the same.
        """
        cmd = str(kwargs.get("command") or "")
        _policy = (os.environ.get("IOF_BUILD_INSTALLS") or "ask").strip().lower()
        if _policy in ("never", "off", "0", "false", "no"):
            with suspended_live():
                self.console.print()
                self.console.print("[bold yellow]install refused[/] - "
                                   "IOF_BUILD_INSTALLS=never: the builder does not "
                                   "change this environment. Run it yourself:")
                self.console.print(f"    [cyan]{cmd[:300]}[/]", highlight=False)
            return False
        if getattr(self, "install_all", False):
            return True
        with suspended_live():
            self.console.print()
            self.console.print("[bold yellow]install?[/] this changes the "
                               "Python/Node environment, not just the repo:")
            self.console.print(f"    [cyan]{cmd[:300]}[/]", highlight=False)
            self.console.print("[dim]    (nothing runs until you answer; "
                               "n declines, Ctrl+C cancels the turn)[/]")
            try:
                ans = prompt_input(
                    self.console,
                    "[bold]  \\[y]es  \\[n]o  \\[a]ll installs this "
                    "session > ").strip().lower()
            except EOFError:
                return False
        if ans.startswith("a"):
            # Three `new-tool` scaffolds used to mean three identical
            # `pip install -e .` prompts with no way to stop asking.
            self.install_all = True
            self.console.print("[dim]installs approved for this session - "
                               "/gated on still gates everything else[/]")
            return True
        return ans.startswith("y")

    # ── turns ────────────────────────────────────────────────────────────
    def send(self, text: str, *, mode: str = "act",
             quiet: bool = False, activity: bool = False) -> dict:
        """One turn in *mode*: act, plan or review. Returns what happened.

        act turns record a checkpoint and report changes. plan and review
        turns are READ-ONLY BY ENFORCEMENT: whatever the model writes is
        reverted afterwards, so the working tree provably ends as it began.
        A review turn runs in its own `-review` session, so the reviewer's
        history never contains the authoring it is judging.
        """
        name, sess = self.active()
        suffix = sess["suffix"] + ("-review" if mode == "review" else "")
        key = _session_key(self.role, self.digest, suffix)
        if mode == "review":
            payload = text                       # self-contained charter
        else:
            first = int(sess.get("turns", 0)) == 0
            carry = obs = None
            # THE REQUEST THAT OPENED THIS CONVERSATION, kept once. A
            # multi-turn build drifts because every turn re-derives what it
            # is doing from the transcript, and the further in it gets the
            # more transcript there is to re-derive it from. The harness has
            # known this string all along and never said it back.
            if first and text.strip():
                # REDACTED BEFORE IT IS STORED. The goal is persisted to
                # `build_sessions/<digest>.json` and re-injected every turn,
                # so a credential in the opening message would be written to
                # disk and repeated for the life of the conversation.
                # Measured within an hour of adding this: a corpus scenario
                # opens "Here is the token: ghp_..." and the state file had
                # it verbatim. The reply redactor never covered this - it
                # guards what the model SAYS, and this is what the user
                # typed.
                goal = " ".join(text.split())[:400]
                try:
                    from ioagentfarm.builder.gates import redact_secrets
                    goal, _kinds = redact_secrets(goal)
                except Exception:            # noqa: BLE001 - never block a turn
                    logger.debug("goal redaction failed", exc_info=True)
                sess["goal"] = goal
            body = _PLAN_WRAP.format(message=text) if mode == "plan" else text
            if first:
                payload = _PREAMBLE.format(
                    repo=self.repo.resolve(),
                    workspace=self.ws_code,
                    today=today_line(),
                    placement=placement_clause(self.repo, self.git_ok),
                    memory=memory_clause(self.repo),
                    solution=solution_clause(self.repo),
                    commands=commands_clause(),
                    session_commands=session_commands_clause(),
                    mcp=mcp_clause(self.mcp_down),
                    message=body)
                carry = sess.pop("carry", None)
                if carry:
                    # /compact's handover: the successor session starts with
                    # the predecessor's distilled context, once.
                    payload = (f"{payload}\n\n[carried context from the "
                               f"previous conversation]\n{carry}")
            else:
                payload = body
            # THE MEASURED END-STATE of the previous turn, prepended once.
            # The conversation history already carries the tool results (and
            # their lint verdicts); what it does NOT carry is what the
            # harness measured AFTER the turn - the actual changed set and
            # inventory, computed outside any tool call. Without this the
            # model plans the next turn from the tree it INTENDED. Prepended,
            # not appended, so it frames the request rather than trailing it.
            obs = sess.pop("pending_observation", None)
            if obs and not first:
                payload = f"{obs}\n\n{payload}"
            # THE PLAN, for the same reason and from the same place. A
            # multi-turn build re-derives what it is doing from a transcript
            # that grows every turn; the harness has held the checklist all
            # along and never said it back. The ticks in it are the harness's
            # own observations, so this also states what is NOT yet done -
            # the half a transcript carries least clearly.
            if mode == "act":
                try:
                    from ioagentfarm.builder import plan_state as _plan
                    said = _plan.clause(sess)
                    if said:
                        payload = f"{said}\n\n{payload}"
                except Exception:          # noqa: BLE001 - never block a turn
                    logger.debug("plan clause failed", exc_info=True)
        # WHAT IS HERE BEFORE THE TURN. Compared afterwards so the console
        # can state what actually appeared - see builder/inventory.py for the
        # session this exists because of.
        from ioagentfarm.builder import inventory as _inv
        inv_before = _inv.take(self.repo)
        tree = _capture_tree(self.repo) if self.git_ok else None
        if self.git_ok and tree is None and not quiet:
            self.console.print(f"[yellow]{TAG} no checkpoint for this turn - "
                               "/undo will not cover it (reason in the log)[/]")
        self.arm_gate()
        # A new turn spends from a full budget. The one-shot path spawns a
        # process per turn and starts at zero on its own; the interactive
        # REPL runs every turn in THIS process, where without a reset the
        # second turn would inherit the first turn's count and the fifth
        # would be refused before it started.
        try:
            from ioagentfarm.builder import budget as _budget
            _budget.reset()
        except Exception:                    # noqa: BLE001 - never block a turn
            pass
        self.written = set()
        # RECORDED BEFORE THE TURN, so an INTERRUPTED one can still be
        # undone. The checkpoint used to be appended after `_one_turn`
        # returned - and a turn cancelled with Ctrl+C never gets there. A
        # user who waited ninety seconds, hit Ctrl+C, and found a scaffolded
        # agent on disk was told "the session keeps what completed", then
        # answered "nothing to undo in this session" - reassuring, and
        # wrong. Proven by simulating exactly that.
        #
        # `provisional` marks it as not-yet-finished so the post-turn code
        # completes this entry instead of appending a second one. Only for
        # an ACT turn: plan reverts its own writes and review takes no
        # checkpoint at all.
        if tree and mode == "act":
            # `inv_before` rides along because attribution cannot be known
            # yet: nothing has been written, so `written` is empty and
            # `created` is unanswerable. Kept here, `/undo` can compute what
            # the cancelled turn brought into being - the same
            # inventory-delta the completed path uses - instead of offering
            # every scaffolded file back to the user as their own edit.
            sess.setdefault("checkpoints", []).append(
                {"tree": tree, "written": [], "created": [],
                 "provisional": True, "inv_before": inv_before})
            sess["checkpoints"] = sess["checkpoints"][-10:]
            self.save()
        try:
            reply = _one_turn(role=self.role, message=payload, uid=self.uid,
                              session_key=key, cfg_path=self.cfg_path,
                              repo=self.repo, quiet=quiet, activity=activity,
                              engine=self.engine, written=self.written)
        except BaseException:
            # AN INTERRUPTED TURN DOES NOT EAT THE HANDOVER. `carry` (the
            # /compact summary) and `pending_observation` were popped and
            # PERSISTED-gone before the model ever saw them; Ctrl+C on the
            # first turn after a compaction destroyed the distilled
            # context permanently and silently. Put back what never
            # arrived.
            if mode == "act":
                if carry:
                    sess["carry"] = carry
                if obs:
                    sess["pending_observation"] = obs
                try:
                    self.save()
                except Exception:         # noqa: BLE001 - already unwinding
                    pass
            raise
        # `enforced` is the honest answer to "could the harness hold this
        # turn to its mode?". Plan and review are sold as ENFORCED - the
        # tree is restored afterwards - but the restore is a git operation,
        # so without a repository a planning turn's writes simply STAY, and
        # nothing said so: the "no checkpoint" warning above is itself
        # gated on git_ok, and is suppressed under --json anyway. A caller
        # that trusts plan mode to be inert has to be able to see this.
        # AN EMBEDDED REPOSITORY BLINDS THE CHECKPOINTS - the outer git
        # records it as one gitlink, so /diff shows a single opaque entry
        # and /undo cannot restore files inside it. The scaffold no longer
        # creates one in-session; anything else that does (a clone, a tool)
        # gets named here rather than discovered turns later as
        # `changed: []` on a turn that plainly wrote.
        try:
            for _ch in (changed or []):
                _p = self.repo / str(_ch.get("path") or "")
                if _p.is_dir() and (_p / ".git").exists() \
                        and _p.resolve() != Path(self.repo).resolve():
                    self.console.print(
                        f"[yellow]{TAG} {_ch.get('path')} contains its own "
                        ".git - the session's /diff and /undo cannot see "
                        "inside an embedded repository. If this content "
                        "belongs to the session, remove that .git; if it "
                        "is a real sub-repo, know that undo does not cover "
                        "it.[/]")
                    break
        except Exception:                  # noqa: BLE001 - a notice only
            logger.debug("embedded-repo check failed", exc_info=True)
        enforced = bool(tree) if mode in ("plan", "review") else True
        result = {"reply": reply, "mode": mode, "session": name,
                  "changed": [], "reverted": [], "enforced": enforced}
        if isinstance(reply, str) and _CTX_OVERFLOW_RX.search(reply):
            # A 400 for an oversized prompt is returned as a REPLY, writes
            # no usage record, and so never moves the meter - the classic
            # dead session: every later turn replays the same payload and
            # fails identically. The flag makes the interactive loop force
            # one compaction attempt; /new is the documented fallback.
            self.force_compact = True
            result["context_overflow"] = True
        if not enforced and not quiet:
            self.console.print(
                f"[yellow]{TAG} {mode} mode is NOT enforced here - the "
                "revert needs a git repository, so anything this turn "
                "wrote has been kept. Run `git init` for an enforced "
                f"{mode} turn.[/]")
        if mode == "review":
            if tree:
                result["reverted"] = _undo_to_tree(self.repo, tree)
            return result
        sess["turns"] = int(sess.get("turns", 0)) + 1
        if tree:
            if mode == "plan":
                # ENFORCEMENT: a planning turn may not change the tree.
                reverted = _undo_to_tree(self.repo, tree)
                result["reverted"] = reverted
                if reverted and not quiet:
                    self.console.print(f"[yellow]{TAG} plan mode reverted "
                                       f"{len(reverted)} file(s) the planner "
                                       "wrote[/]")
                # THE PLAN BECOMES STATE HERE. It lived only in this reply,
                # so a cancelled turn lost it and every later turn re-read
                # it out of a growing transcript.
                try:
                    from ioagentfarm.builder import plan_state as _plan
                    stored = _plan.store(sess, reply or "")
                    if stored:
                        result["plan_items"] = len(stored)
                        if not quiet:
                            named = sum(1 for i in stored if i["paths"])
                            self.console.print(
                                f"[dim]{TAG} plan recorded: {len(stored)} "
                                f"item(s), {named} naming files the harness "
                                f"can tick from what changes {self.G['sep']} "
                                f"/plan to view[/]", soft_wrap=True)
                except Exception:          # noqa: BLE001
                    logger.debug("plan store failed", exc_info=True)
            else:
                # The attribution set rides WITH the tree. `self.written` is
                # in-memory and starts empty every run; persisting only the
                # tree left `/undo` unable to tell the builder's files from
                # the user's in any later invocation.
                # THE SCAFFOLD'S OUTPUT IS THE BUILDER'S WORK TOO.
                # `written` sees the write TOOLS only, and the scaffold
                # commands create content through `exec` - so every file
                # `aicore new-agent` produced was classed as the user's own
                # edit, named back to them, and left in place by a `/undo`
                # that reported success. Content that did not exist before
                # this turn and exists now is build output: the user did not
                # create an agent while waiting for one.
                #
                # COMPLETES the provisional entry this turn opened rather
                # than appending a second one - the tree is the same, only
                # the attribution was unknown until now.
                entry = {
                    "tree": tree,
                    "written": sorted({repo_rel(p, self.repo)
                                       for p in self.written}),
                    "created": _created_dirs(inv_before, self.repo),
                }
                cps = sess.setdefault("checkpoints", [])
                # Through the helper, like every other checkpoint field: an
                # entry written by an older build is a BARE SHA STRING, and
                # `.get()` on one raises. It cannot be one HERE - this turn
                # appended the entry itself - but a reader that is correct
                # only because of where it sits is one refactor from a
                # traceback, and `/undo`'s copy of this line proved it.
                if cps and cp_provisional(cps[-1]) and \
                        cp_tree(cps[-1]) == tree:
                    cps[-1] = entry
                else:
                    cps.append(entry)
                sess["checkpoints"] = sess["checkpoints"][-10:]
                changes = _turn_changes(self.repo, tree)
                result["changed"] = [{"status": s, "path": p}
                                     for s, p in changes]
                # TICKED FROM GIT, NOT FROM THE REPLY. `/go` asks the model
                # to print `[step N/M]` lines and the console renders those
                # as progress - so a model that stops printing them looks
                # finished, and one that prints them without doing the work
                # looks done. An item is ticked here only when the files it
                # NAMES actually moved, which is git's answer.
                try:
                    from ioagentfarm.builder import plan_state as _plan
                    newly = _plan.tick_from_changed(sess, result["changed"])
                    if newly:
                        result["plan_ticked"] = [i["text"] for i in newly]
                        done, total = _plan.progress(sess)
                        if not quiet:
                            self.console.print(
                                f"[green]{TAG} plan {done}/{total}[/] "
                                f"[dim]- {len(newly)} item(s) confirmed by "
                                f"the files that changed[/]", soft_wrap=True)
                except Exception:          # noqa: BLE001
                    logger.debug("plan tick failed", exc_info=True)
                if changes and not quiet:
                    self.console.print(
                        f"[dim]{len(changes)} file(s) changed "
                        f"{self.G['sep']} /diff to view {self.G['sep']} "
                        f"/undo to revert[/]")
        # THE HARNESS COUNTS THE CONTENT, because the model describes the tree
        # it INTENDED. Measured: after a rename-then-revert, both the old and
        # the new agent were on disk and the reply said the old one "never
        # existed"; asked to list what was there, it named two of three. This
        # line is the measurement beside the claim.
        if not quiet:
            inv_after = _inv.take(self.repo)
            delta = _inv.changed(inv_before, inv_after)
            for kind, moved in delta.items():
                if moved["added"]:
                    self.console.print(
                        f"[dim]{self.G['sep']} {kind} added: "
                        f"{', '.join(moved['added'])}[/]", soft_wrap=True)
                if moved["removed"]:
                    self.console.print(
                        f"[dim]{self.G['sep']} {kind} removed: "
                        f"{', '.join(moved['removed'])}[/]", soft_wrap=True)
            if delta:
                line = _inv.summary_line(inv_after)
                if line:
                    self.console.print(f"[dim]now in this repo {self.G['arrow']} "
                                       f"{line}[/]", soft_wrap=True)
            result["inventory"] = inv_after
        # THE HARNESS LINTS WHAT THE TURN WROTE - the verdict is a fact, not
        # the model's claim about it. Every path the turn touched is
        # re-linted in-process; the result rides in the JSON, prints beside
        # the reply, contradicts a "lint clean" that is not true, and is
        # carried into the next turn as the measured end-state. Runs on act
        # turns only: a plan/review turn's writes are reverted, so there is
        # nothing on disk to lint.
        if mode == "act":
            try:
                from ioagentfarm.builder import verify as _verify
                # THE CHANGED SET, not just what the write TOOLS touched.
                # `self.written` sees write_file/edit_file only, and the
                # scaffold commands create content through `exec` - so a
                # turn that ran `aicore new-workflow` and wrote six files
                # produced no lint at all, which is exactly the turn most
                # worth linting. The git-measured changed set covers both;
                # `written` remains the floor for a repo with no git.
                paths = {c["path"] for c in (result.get("changed") or [])
                         if c.get("path")}
                paths |= {repo_rel(p, self.repo) for p in self.written}
                verdicts = _verify.verify_paths(sorted(paths), self.repo)
            except Exception:                    # noqa: BLE001 - never block a turn
                verdicts = []
            if verdicts:
                result["lint"] = verdicts
                if not quiet:
                    for v in verdicts:
                        colour = ("red" if v["errors"] else
                                  "yellow" if v["warnings"] else "green")
                        self.console.print(
                            f"[{colour}]{v['text'].splitlines()[0]}[/]")
                clash = _verify.contradiction(reply, verdicts)
                if clash and not quiet:
                    self.console.print(f"[red]{TAG} {clash}[/]")
                if clash:
                    result["lint_contradiction"] = clash
            # THE PACK'S OWN TESTS, when this turn brought content into
            # being. Lint proves a file PARSES; the pack test proves it
            # LOADS - the entry point, the package-data globs, the manifest,
            # none of which a linter can see and all of which are fatal at
            # run time. Measured: across 141 exec calls in a corpus run the
            # builder ran pytest exactly ZERO times, and the sandbox's own
            # pack had two failing tests nobody had ever looked at.
            #
            # Only when content was CREATED: a question, a read-only turn or
            # an edit to prose has nothing for them to say, and a suite re-run
            # every turn is a cost the model learns to ignore.
            # WHAT NOW POINTS AT NOTHING. A pack is a graph held together
            # by NAMES - `role: rey`, a swarm roster, a `skills:` filter -
            # and none of them is a path, so nothing breaks on disk when the
            # thing they name goes away: the YAML parses, the linter passes,
            # and the failure waits for a run. Measured twice in one corpus:
            # a rename left every reference pointing at the old name, and a
            # deleted agents directory left a workflow naming `scout` for
            # thirteen further scenarios with nothing saying so.
            refs: list = []
            if result.get("changed"):
                try:
                    from ioagentfarm.builder import references as _refs
                    refs = _refs.dangling(self.repo)
                except Exception:            # noqa: BLE001 - never block a turn
                    logger.debug("reference sweep failed", exc_info=True)
            if refs:
                result["dangling_references"] = refs
                if not quiet:
                    from ioagentfarm.builder import references as _refs
                    self.console.print(f"[yellow]{_refs.dangling_line(refs)}[/]",
                                       soft_wrap=True)
            tests = None
            if result.get("changed"):
                try:
                    tests = _verify.run_pack_tests(self.repo)
                except Exception:            # noqa: BLE001 - never block a turn
                    logger.debug("pack tests could not run", exc_info=True)
            # SAID ONCE, NOT EVERY TURN. A pack that is not installed fails
            # the same way after every write, and repeating it taught the
            # model to editorialise: two complete turns ended "cannot run
            # yet because the pack is not installed" and were scored as
            # refusals. A standing environmental fact is worth stating when
            # it CHANGES - which is also when it is worth acting on.
            key = _verify.tests_key(tests) if tests else ""
            same = bool(tests) and sess.get("tests_summary") == key
            if tests:
                sess["tests_summary"] = key
                result["tests"] = tests
                if same:
                    tests = None             # carried forward, not repeated
            if tests:
                if not quiet:
                    colour = "green" if tests.get("ok") else "yellow"
                    self.console.print(
                        f"[{colour}]{_verify.tests_line(tests)}[/]",
                        soft_wrap=True)
            # Carry the measurement forward, even when nothing changed - the
            # NEXT turn should start from "changed: nothing" rather than
            # re-deriving it.
            try:
                obs_text = _verify.observation(
                    changed=result.get("changed") or [],
                    inventory_line=(_inv.summary_line(inv_after)
                                    if not quiet else ""),
                    verdicts=verdicts,
                    tool_calls=result.get("tool_calls"),
                    tests=tests, refs=refs,
                    goal=sess.get("goal") or "",
                    left=_verify.outstanding(reply))
                sess["pending_observation"] = obs_text
            except Exception:                    # noqa: BLE001
                pass
        # THE PLAN-INSTEAD-OF-ACT ABSORBER. The most-reported failure: an
        # instruction answered with a numbered plan plus a question, nothing
        # placed. The skill now forbids it, but a prompt is a request - so
        # when an ACT turn changed nothing and the reply carries the plan
        # template's own tell ("/go"), the harness says so and makes the
        # recovery ONE KEYSTROKE instead of a retyped paragraph. Gated on
        # git_ok because without a checkpoint "changed nothing" is not a
        # measurement.
        if (mode == "act" and not quiet and self.git_ok
                and not result["changed"] and not result["reverted"]
                and reply and "/go" in reply):
            self.console.print(
                f"[yellow]{TAG} the builder proposed instead of acting - "
                "/go executes the plan above[/]")
        # THE STOPPED-MID-THOUGHT ABSORBER, a sibling of the one above and
        # for the same reason: a rule stated to a model is a request, and
        # this one demonstrably does not hold. Measured twice - a four-part
        # instruction that ended "Now assigning vendors_usage to Ida..."
        # after seventy-two calls, and a diagnosis that ended "Checking if
        # Rey exists in the workspace before attempting to run it." after
        # two. Both read as work in progress; both were the end of the turn.
        # The user cannot tell the difference between that and a crash.
        #
        # Detected on the SHAPE the failure actually has: a short final
        # message that announces an action and reports none. Deliberately
        # narrow - it must not fire on an ordinary short answer - so it wants
        # an announcing verb AND no report AND a reply short enough to be a
        # single narration line.
        if mode == "act" and not quiet and reply and _looks_unfinished(reply):
            self.console.print(
                f"[yellow]{TAG} that turn ended on an intention, not a "
                "result - the work may be unfinished. Ask it to continue, "
                "or /undo and re-ask[/]", soft_wrap=True)
        self.save()
        return result

    def run_review(self, *, quiet: bool = False) -> dict | None:
        if not self.git_ok:
            if not quiet:
                self.console.print("[yellow]/review needs a git repository[/]")
            return None
        _, sess = self.active()
        cps = sess.get("checkpoints") or []
        base = cp_tree(cps[-1]) if cps else None
        diff = _review_diff(self.repo, base)
        if not diff and base:
            # An empty diff has two meanings and only one is clean: the
            # baseline may simply be GONE (git gc collected the unreachable
            # tree), and rendering that as "nothing to review" is the
            # lost-baseline-as-clean-tree confusion the tree_exists guard
            # exists to prevent. Checked only on the empty answer, so a
            # working diff never pays the extra git call.
            from ioagentfarm.builder.checkpoints import tree_exists
            if not tree_exists(self.repo, base):
                if not quiet:
                    self.console.print(
                        "[yellow]the review baseline is gone (git gc "
                        "collected it) - reviewing these changes is not "
                        "possible; make a change and /review again[/]")
                return None
        if not diff:
            if not quiet:
                self.console.print("[dim]nothing to review - no changes "
                                   "found[/]")
            return None
        if not quiet:
            # The review STREAMS. Fully quiet made this the product's
            # longest dead air - two minutes of blank screen inside the
            # trust-building feature (2026-08-11 field run). Activity shows
            # live; only the verdict waits for the end.
            self.console.print(f"[dim]{TAG} adversarial review running - "
                               "verdict at the end[/]")
        # THE FACTS, BEFORE THE TURN. The charter asks the reviewer to list a
        # parent directory before claiming a path is missing - a request, and
        # this repository has measured twice what a request is worth against a
        # model that believes it already knows. So the listing is done here
        # and printed above the diff: a reviewer cannot declare a directory
        # nonexistent while its contents sit in its own prompt.
        payload = _REVIEW_WRAP.format(diff=diff)
        try:
            from ioagentfarm.builder import review_evidence as _ev
            block = _ev.evidence_block(self.repo, diff)
            if block:
                payload = f"{block}\n\n{payload}"
        except Exception:                          # noqa: BLE001
            logger.debug("review evidence failed", exc_info=True)

        result = self.send(payload, mode="review",
                           quiet=True, activity=not quiet)

        # AND THE DETECTION HALF, for the claim that still gets made. Same
        # shape as the reply that claims "lint clean" while the harness holds
        # errors: contradicted BY NAME, so a wrong finding costs the reviewer
        # its credibility instead of costing the user an afternoon.
        try:
            from ioagentfarm.builder import review_evidence as _ev
            wrong = _ev.contradictions(self.repo, result.get("reply") or "")
            if wrong:
                result["contradictions"] = wrong
                if not quiet:
                    self.console.print()
                    for line in wrong:
                        self.console.print(f"[red]{TAG} contradicted:[/] "
                                           f"{line}", soft_wrap=True)
        except Exception:                          # noqa: BLE001
            logger.debug("review contradiction check failed", exc_info=True)
        if not quiet and result.get("reply"):
            from rich.markdown import Markdown
            reply = result["reply"].strip()
            lines = reply.splitlines()
            # The verdict line is a CONTRACT: APPROVE or FIX. The field run
            # produced a reply that led with a claim instead, and the
            # renderer colored that fragment as if it were the verdict.
            # Find the real verdict line; when there is none, SAY SO rather
            # than dress up whatever came first.
            def _verdict(ln: str) -> bool:
                # models decorate ("## FIX", "**APPROVE**"); the contract is
                # the WORD leading the line, not the line being bare
                return ln.strip().lstrip("#*> ").upper()                     .startswith(("APPROVE", "FIX"))
            vline = next((ln for ln in lines if _verdict(ln)), None)
            self.console.print()
            if vline is not None:
                verdict = vline.strip().upper()
                colour = "green" if verdict.startswith("APPROVE") \
                    else "yellow"
                self.console.print(f"[bold {colour}]review[/] "
                                   f"[{colour}]{verdict[:60]}[/]")
                body = "\n".join(ln for ln in lines if ln is not vline)
            else:
                self.console.print(
                    "[bold yellow]review[/] [yellow]NO VERDICT LINE - the "
                    "reviewer did not follow its contract; full reply "
                    "below[/]")
                body = reply
            if body.strip():
                self.console.print(Markdown(body))
        elif not quiet:
            self.console.print("[yellow]review turn completed with no "
                               "readable verdict - see the review session "
                               "record[/]")
        return result

    def show_sessions(self) -> None:
        name = self.state["active"]
        for n, s in sorted(self.state["sessions"].items()):
            if n == name:
                self.console.print(f"  [bold green]{self.G['on']} {n}[/]  "
                                   f"[dim]{s['turns']} turn(s)[/]  "
                                   f"[green]active[/]")
            else:
                self.console.print(f"  [dim]{self.G['off']} {n}  "
                                   f"{s['turns']} turn(s)[/]")

    def guarded(self, fn, *a, **kw):
        """A turn the user can CANCEL, or that can FAIL, without losing the
        session.

        Ctrl+C reaches the whole foreground process group - the console
        group on Windows, the terminal's process group on POSIX - so the
        spawned agent dies with the interrupt; catching it here returns to
        the prompt instead of exiting the CLI, and the session record keeps
        every round that completed - the runtime's own checkpoint restore
        handles a partial turn on the next message.

        Any OTHER exception is caught for the same reason. A provider that
        raises mid-turn, a tool that throws, a bug in this code - none of
        them are a reason to destroy the user's REPL and everything they
        had on screen. The turn is lost, the conversation is not: the
        session record is the store, so the next message continues from
        whatever completed. The traceback goes to the log, and the engine
        is rebuilt on the next turn because a half-finished loop's internal
        state is not worth trusting.
        """
        try:
            return fn(*a, **kw)
        except KeyboardInterrupt:
            print()
            # NAMES THE REVERT, because a cancelled turn is exactly when the
            # user wants it and the old wording implied there was nothing to
            # revert: "the session keeps what completed" is true of the
            # conversation and says nothing about the FILES a half-finished
            # turn left behind.
            self.console.print(
                f"[yellow]{TAG} turn cancelled - the conversation keeps what "
                "completed. Anything the turn had already written is still "
                "on disk: `/diff` shows it and `/undo` reverts it. Otherwise "
                "just say what to do next.[/]", soft_wrap=True)
            if self.engine is not None:
                # a cancelled coroutine leaves the loop's internal state
                # unknown; rebuild on the next turn rather than trust it
                self.engine.reset()
            return None
        except Exception as exc:              # noqa: BLE001 - see docstring
            logger.exception("build turn failed")
            self.console.print(
                f"[red]{TAG} the turn failed: {type(exc).__name__}: "
                f"{str(exc)[:200]}[/]")
            self.console.print(
                "[dim]the conversation is intact - the session record has "
                "every round that completed. Say what to do next, or "
                "/undo to revert what this turn wrote.[/]")
            if self.engine is not None:
                self.engine.reset()
            return None


def want_engine(*, message: str, review: bool) -> bool:
    """Interactive sessions get the in-process engine; one-shots do not.

    Warmup amortizes over turns and the approval gate needs it, while a
    one-shot pays the warmup either way and the CI contract stays on the
    subprocess path. ``IOF_BUILD_INPROCESS=1`` forces it there for
    validation.
    """
    return ((not message and not review)
            or os.environ.get("IOF_BUILD_INPROCESS") == "1")


def _created_dirs(inv_before: dict, repo) -> list:
    """Repo-relative paths of content this turn brought into existence.

    Compared against the inventory taken BEFORE the turn, so it names only
    what appeared: an agent directory a scaffold made, a skill, a workflow,
    the `mcp.yaml` a server was declared in. Content that already existed
    and was merely edited is NOT here - that file is either attributed
    through the write tools or is genuinely ambiguous, and ambiguous is
    exactly what `/undo` must keep asking about.

    Never raises: a checkpoint that cannot be written is worse than one
    with a shorter attribution list.
    """
    try:
        from ioagentfarm.builder import inventory as _inv
        now = _inv.locate(repo)
        out: set = set()
        for kind, found in now.items():
            had = set(inv_before.get(kind) or [])
            for name, path in found.items():
                if name not in had and path:
                    out.add(path)
        return sorted(out)
    except Exception:                      # noqa: BLE001 - see docstring
        logger.debug("could not record created content", exc_info=True)
        return []
