"""A build turn knows how much it has spent, and cannot spend without bound.

Nothing counted a turn's tool calls. The only ceiling was the runtime's
``maxToolIterations`` at 500 - so far above real work that it bounded
nothing - and the model was never told its own count, so it had no way to
notice it was over-running. Measured: *"The pricing_bot agent keeps failing
its lint. Fix it."* against a repository with no pricing_bot spent
**ninety-five tool calls** before replying, and the reply was wrong.

Two mechanisms, and the difference between them is deliberate:

* **The notes are a request.** At the soft threshold the turn is told what
  it has spent and asked whether it is still serving the ask. A model that
  is merely absorbed will stop; one that is lost will not.
* **The stop is physics.** Past the hard threshold every tool call is
  refused with the same instruction: report what you have. This is the same
  reasoning as `IOF_HARD_ATTEMPT_CAP_MULTIPLIER` in the run engine - "the
  driver is an LLM and does not reliably obey 'never retry more than
  once'".

**The thresholds come from measurement, not taste.** Across 74 live turns:
median 9 calls, p90 22, p95 35 - and one legitimate PASS at 58. So the stop
sits above real work (70) and the first note near p90 (25), which is why a
long, honest build is not interrupted and the 95-call turn is.

Set ``IOF_BUILD_CALL_SOFT`` / ``IOF_BUILD_CALL_HARD`` to move them; either
at ``0`` disables that half.
"""
from __future__ import annotations

import os

_DEFAULT_SOFT = 25
_DEFAULT_HARD = 70

#: Turn-scoped. The one-shot path spawns a process per turn so it starts at
#: zero on its own; the interactive REPL runs many turns in one process and
#: calls `reset()` before each.
_count = 0
_notes_fired: set[int] = set()


def _limit(name: str, default: int) -> int:
    raw = (os.environ.get(name) or "").strip()
    if not raw:
        return default
    try:
        return max(0, int(raw))
    except ValueError:
        return default


def soft_limit() -> int:
    return _limit("IOF_BUILD_CALL_SOFT", _DEFAULT_SOFT)


def hard_limit() -> int:
    return _limit("IOF_BUILD_CALL_HARD", _DEFAULT_HARD)


def reset() -> None:
    """Start a new turn's accounting."""
    global _count
    _count = 0
    _notes_fired.clear()
    # The in-turn pack-test verdict is said once per TURN unless it changes,
    # and its memo lives in the patch module beside the guard that emits it.
    # Reset here so the two cannot disagree about when a turn began.
    try:
        from ioagentfarm._iobot_patches import (reset_run_state_reads,
                                                  reset_scaffold_tests)
        reset_scaffold_tests()
        reset_run_state_reads()
    except Exception:                     # noqa: BLE001 - never block a turn
        pass


def count() -> int:
    return _count


def bump() -> int:
    """Record one tool call; returns the new count."""
    global _count
    _count += 1
    return _count


def refusal(n: int) -> str | None:
    """The hard stop, if this call is past it.

    Refuses EVERY tool, not just the expensive ones: a turn at the ceiling
    should be writing its reply, and leaving reads open is how a stalled
    turn keeps looking for a way to continue.
    """
    hard = hard_limit()
    if not hard or n <= hard:
        return None
    return (f"[budget] refused: this turn has made {n - 1} tool calls, past "
            f"its ceiling of {hard}. Stop now and reply with what you have: "
            "what you completed, where it is on disk, what is incomplete, "
            "and what you would do next. Do not call another tool - they "
            "will all be refused until you answer. If the work genuinely "
            "needs more steps, say so and let the user run another turn.")


def note(n: int) -> str | None:
    """The soft nudge, at most twice a turn.

    Fired ONCE at each threshold rather than on every call past it: a note
    repeated thirty times is noise the model learns to skip, and it would
    also crowd out the tool output it is attached to.
    """
    soft, hard = soft_limit(), hard_limit()
    if not soft or n < soft:
        return None
    marks = [soft]
    if hard and hard > soft:
        marks.append(soft + (hard - soft) // 2)
    for m in marks:
        if n >= m and m not in _notes_fired:
            _notes_fired.add(m)
            tail = (f" The ceiling is {hard}, after which every tool call is "
                    f"refused." if hard else "")
            return (f"[budget] this turn has now made {n} tool calls (a "
                    f"typical build turn takes about 9).{tail} If you are "
                    "close to done, finish. If you are searching for "
                    "something you have not found, stop and say what you "
                    "were looking for - a short answer now is worth more "
                    "than a long one later.")
    return None


def armed() -> bool:
    """True only inside a build session, checked at CALL time.

    The signal is `IOF_BUILD_REPO` - the repository the session opened, set
    by `builder/turn.py`. Its PRESENCE is the build-session marker: there was
    a separate `IOF_BUILD_GUARD=1` boolean set beside it, but the two were
    always set and cleared together (a flag that said "enforce" and a value
    that said "which repo"), so the boolean was redundant and is gone. One
    signal now: if the session recorded a repo, the guards are armed.
    """
    return bool(os.environ.get("IOF_BUILD_REPO"))
