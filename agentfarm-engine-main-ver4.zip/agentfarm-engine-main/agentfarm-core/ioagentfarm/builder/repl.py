"""The `aicore build` command: options, the slash commands, the input loop.

The slash commands are a TABLE of module-level handlers, not an if/elif
chain inside the loop. The chain is how this function reached 493 lines: it
put every command's body in the same scope, so none could be read, tested or
changed on its own, and adding one meant editing the loop.

A handler takes ``(s, line, args)`` - the :class:`BuildSession`, the raw
input line (some commands need the untokenized remainder), and the tokens
after the command - and returns ``None`` to continue or :data:`_STOP` to
leave the loop.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import typer
from loguru import logger

from ioagentfarm.builder.checkpoints import (_is_git_repo, _turn_changes,
                                           _undo_to_tree, cp_created,
                                           cp_inv_before, cp_provisional,
                                           cp_tree, cp_written, tree_exists,
                                           under_created)
from ioagentfarm.builder.console import _console, TAG
from ioagentfarm.builder.events import repo_rel
from ioagentfarm.builder.refs import (_expand_file_refs, _remember, _repo_macro,
                                    _transcript_tail)
from ioagentfarm.builder.session import (_create_session, _load_state,
                                       mcp_health,
                                       _rename_session, _repo_digest,
                                       _save_state, _session_file,
                                       _session_key, _slug)
from ioagentfarm.builder.session_state import BuildSession, want_engine
from ioagentfarm.builder.turn import _ensure_builder_skill

#: Returned by a handler to leave the input loop.
_STOP = object()

#: Returned by `dispatch_guarded` when the command RAISED. Interactively
#: this is just "keep going"; the one-shot path reports it, so a CI script
#: is never told `dispatched: true` about a command that blew up.
_FAILED = object()

#: What `/diff` and `/undo` say when the checkpoint's tree object is no
#: longer in the object store. Checkpoint objects are unreachable by design,
#: so anything that prunes - `git gc --prune=now`, a re-`git init`, a copy
#: of the repo without its objects - takes the baseline with it. Both
#: commands used to render that as a clean tree.
_GONE = ("[yellow]the checkpoint for the last turn is no longer in this "
         "repository's object store - `git gc` (or a re-`git init`) removed "
         "it, so there is nothing to compare against. This is NOT the same "
         "as 'nothing changed'; `git status` still shows the working "
         "tree.[/]")


# ── slash commands ───────────────────────────────────────────────────────

def _cmd_exit(s, line, args):
    return _STOP


def _cmd_sessions(s, line, args):
    s.show_sessions()


def _cmd_plan(s, line, args):
    req = line[len("/plan"):].strip()
    if not req:
        # NO ARGUMENT NOW MEANS "SHOW ME THE PLAN". It used to mean only a
        # usage hint, which was the right answer when nothing held a plan;
        # now that the session does, the checklist with its ticks is what
        # someone typing `/plan` at this point is asking for.
        from ioagentfarm.builder import plan_state as _plan
        _, sess = s.active()
        if not _plan.render(s.console, sess, s.G):
            s.console.print("[yellow]/plan <request> - the builder proposes; "
                            "nothing is written[/]")
    else:
        s.guarded(s.send, req, mode="plan")


def _cmd_go(s, line, args):
    s.guarded(s.send,
              "Execute the plan you proposed above, exactly. If anything "
              "must deviate from it, name the deviation before acting. As "
              "you COMPLETE each numbered step of the plan, print a line "
              "that is exactly `[step N/M] <what was done>` - the console "
              "renders these as ticked progress.")


def _cmd_review(s, line, args):
    s.guarded(s.run_review)


def _cmd_gated(s, line, args):
    if args and args[0] in ("on", "off"):
        s.gated = args[0] == "on"
        if s.gated and s.engine is None:
            s.console.print("[yellow]approval mode needs the in-process "
                            "engine, which is unavailable this session[/]")
        else:
            s.console.print(f"{TAG} approval gate "
                            f"[bold]{'on' if s.gated else 'off'}[/]")
    else:
        s.console.print(f"{TAG} approval gate is "
                        f"{'on' if s.gated else 'off'} - /gated on|off to "
                        f"change")


def _cmd_compact(s, line, args):
    # A long session slows and costs more every turn. Distill it in ONE quiet
    # turn, then continue in a fresh session that carries the summary - the
    # old conversation stays under /switch.
    s.console.print(f"[dim]{TAG} distilling this conversation ...[/]")
    result = s.guarded(
        s.send,
        "Summarize the durable context of this session for a successor "
        "session: repository facts, decisions made, content created with "
        "paths, and open threads. At most 25 lines of plain text. No "
        "preamble.",
        quiet=True)
    summary = (result or {}).get("reply")
    if not summary:
        # BACK OFF. `_compact_if_full` fires after every turn while the
        # percentage stays high, so a failing summarisation retried on
        # every turn forever - one wasted model call each. Three turns of
        # room before the automatic retry; /compact retries by hand.
        _, sess_ = s.active()
        s._compact_failed_turn = int(sess_.get("turns", 0))
        s.console.print("[yellow]compaction failed - no summary could be "
                        "read; the session is unchanged. /compact retries; "
                        "if it keeps failing, /new starts fresh (this "
                        "conversation stays under /switch)[/]")
        return
    old = s.state["active"]
    old_sess = s.state["sessions"][old]
    created = _create_session(s.state, None)
    new_sess = s.state["sessions"][created]
    new_sess["carry"] = summary
    # THE SUCCESSOR INHERITS WHAT THE USER RELIES ON. A compacted session
    # used to start with nothing but the summary: /undo answered "nothing
    # to undo in this session" one keystroke after six files were
    # scaffolded, /diff went blank, and the plan the model was working
    # vanished - all silently, because auto-compaction fires without the
    # user typing anything.
    for key_ in ("checkpoints", "plan", "goal", "pending_observation"):
        if old_sess.get(key_):
            val = old_sess[key_]
            new_sess[key_] = list(val) if isinstance(val, list) else val
    s.save()
    _relock(s)
    s._compact_failed_turn = None
    s.console.print(f"{TAG} compacted [dim]{old}[/] {s.G['arrow']} "
                    f"[bold green]{created}[/] (the full conversation "
                    f"stays under /switch {old}; checkpoints and the plan "
                    "carried - /undo still covers the last turn)")
    s.console.print("[dim]what was carried:[/]")
    for ln in str(summary).splitlines()[:25]:
        s.console.print(f"[dim]  {ln[:110]}[/]", highlight=False,
                        markup=False)


def _cmd_transcript(s, line, args):
    spath = _session_file(
        s.role, _session_key(s.role, s.digest, s.active()[1]["suffix"]),
        s.uid)
    for who, text in _transcript_tail(spath, 12):
        style = {"user": "bold", "assistant": ""}.get(who, "dim")
        first = " ".join(text.split())[:160]
        s.console.print(f"[{style}]{who:9s}[/] {first}"
                        if style else f"{who:9s} {first}",
                        highlight=False, markup=bool(style))


def _cmd_diff(s, line, args):
    _, sess = s.active()
    cps = sess.get("checkpoints") or []
    if not s.git_ok:
        s.console.print("[yellow]/diff needs a git repository[/]")
    elif not cps:
        s.console.print("[dim]no turn checkpoint yet in this session[/]")
    elif not tree_exists(s.repo, cp_tree(cps[-1])):
        s.console.print(_GONE)
    else:
        changes = _turn_changes(s.repo, cp_tree(cps[-1]))
        if not changes:
            s.console.print("[dim]no changes since the last turn began[/]")
        for st, path in changes:
            colour = {"A": "green", "D": "red"}.get(st, "yellow")
            s.console.print(f"  [{colour}]{st}[/] {path}", highlight=False)


def _cmd_undo(s, line, args):
    """Revert the last turn - and NEVER the user's own work with it.

    A checkpoint diff cannot tell who changed a file. Measured: with a
    file edited and another created by the USER while a turn ran, `/undo`
    deleted the new file and threw away the edit, silently, having asked
    nothing. Snapshot semantics are still right - scaffold commands create
    files through `exec` and only the snapshot sees those - so the fix is
    consent, not a narrower revert: paths the harness OBSERVED the agent
    write go back without ceremony, and everything else is named and
    offered. A non-interactive session reverts the attributed paths and
    leaves the rest, which is the fail-safe direction.
    """
    _, sess = s.active()
    cps = sess.get("checkpoints") or []
    if not s.git_ok:
        s.console.print("[yellow]/undo needs a git repository[/]")
        return
    if not cps:
        s.console.print("[dim]nothing to undo in this session[/]")
        return

    tree = cp_tree(cps[-1])
    if not tree_exists(s.repo, tree):
        # Without this the next branch reads "the last turn changed
        # nothing - checkpoint dropped" and DROPS it: a lost baseline
        # rendered as a clean tree, and the one record of the turn thrown
        # away on the strength of it. The checkpoint is kept.
        s.console.print(_GONE)
        return
    changes = _turn_changes(s.repo, tree)
    if not changes:
        cps.pop()
        s.save()
        s.console.print("[dim]the last turn changed nothing - checkpoint "
                        "dropped[/]")
        return

    # The PERSISTED set is what makes this work in a session resumed in a new
    # process. In-process the two agree (both describe the same turn); the
    # union is belt-and-braces for a checkpoint written by an older build,
    # which carries no record and would otherwise attribute nothing.
    known = cp_written(cps[-1]) | {repo_rel(p, s.repo) for p in s.written}
    # AND WHAT THE SCAFFOLD MADE. `known` sees the write TOOLS only, and the
    # scaffold commands create content through `exec`, which names no path -
    # so `aicore new-agent rey` produced four files that `/undo` handed back
    # to the user as their own edits and, non-interactively, left on disk
    # while reporting success. Content that did not exist before the turn is
    # the builder's; a directory that already existed and was merely edited
    # stays ambiguous, which is what the prompt below is for.
    created = cp_created(cps[-1])
    # A PROVISIONAL checkpoint belongs to a turn that was cancelled before
    # it could attribute anything, so its `created` is empty and every file
    # it scaffolded would be offered back to the user as their own edit -
    # which, non-interactively, means reverting nothing at all. The
    # inventory taken before that turn is stored with it, so what the turn
    # brought into being is computable now.
    _inv_before = cp_inv_before(cps[-1])
    if cp_provisional(cps[-1]) and _inv_before is not None:
        try:
            from ioagentfarm.builder.session_state import _created_dirs
            created |= set(_created_dirs(_inv_before, s.repo))
        except Exception:                 # noqa: BLE001 - never break /undo
            logger.debug("could not attribute a cancelled turn",
                         exc_info=True)
    mine = [(st, p) for st, p in changes
            if repo_rel(p, s.repo) in known
            or under_created(repo_rel(p, s.repo), created)]
    theirs = [(st, p) for st, p in changes
              if repo_rel(p, s.repo) not in known
              and not under_created(repo_rel(p, s.repo), created)]

    if theirs:
        s.console.print(f"[yellow]{TAG} these changed since the turn began "
                        "but the builder did not write them - your own edits, "
                        "or a command's output:[/]")
        for st, p in theirs:
            s.console.print(f"  [yellow]{st}[/] {p}", highlight=False)
        prompt = ("[bold]revert everything above too? "
                  "\\[y]es  \\[n]o, only the builder's files > ")
        try:
            from ioagentfarm.builder.input_hub import prompt_input
            take_all = prompt_input(s.console, prompt) \
                .strip().lower().startswith("y") \
                if s.console.is_terminal else False
        except (EOFError, KeyboardInterrupt):
            take_all = False
        if not take_all and not mine:
            s.console.print("[dim]nothing reverted - the checkpoint is "
                            "kept[/]")
            return
    else:
        take_all = True

    only = None if take_all else [p for _, p in mine]
    failed: list = []
    touched = _undo_to_tree(s.repo, tree, only=only, failed=failed)
    if take_all and not failed:
        # A checkpoint is spent only when it was fully used - and a revert
        # that could not restore everything has NOT been fully used, so
        # keeping it lets the user close their editor and run /undo again.
        cps.pop()
    s.save()
    if failed:
        s.console.print(f"[red]{TAG} {len(failed)} file(s) could NOT be "
                        "reverted - the checkpoint is kept so you can retry "
                        "once whatever holds them is closed:[/]")
        for p, why in failed[:10]:
            s.console.print(f"  [red]{p}[/] [dim]{why[:90]}[/]",
                            highlight=False)
    if touched:
        s.console.print(f"{TAG} reverted {len(touched)} file(s) to the "
                        "start of the last turn:")
        for p in touched:
            s.console.print(f"  [dim]{p}[/]", highlight=False)
        if not take_all:
            s.console.print("[dim]your own changes were left alone; the "
                            "checkpoint is kept so /undo can still take "
                            "them[/]")
    else:
        s.console.print("[dim]nothing reverted[/]")


def _cmd_remember(s, line, args):
    note = line[len("/remember"):].strip()
    if not note:
        s.console.print("[yellow]/remember <note> - appended to "
                        "CORABUILD.md, read at every session start[/]")
    else:
        f = _remember(s.repo, note)
        s.console.print(f"{TAG} noted in [cyan]{f.name}[/]")


def _cmd_new(s, line, args):
    """Create a conversation - or SAY SO when the name already existed.

    Names are slugged into the runtime session key, so `/new "a b"`,
    `/new a-b` and `/new "A B"` are one conversation, and `_create_session`
    switches to an existing name rather than clobbering it (correctly - the
    JSONL behind it is real history). Announcing that as "new conversation"
    is what made it a trap: the user asks for a fresh context, is told they
    have one, and the model then answers out of a conversation they thought
    was gone.
    """
    # THE WHOLE REMAINDER IS THE NAME, not the first word. `/new market
    # research` tokenized to ["market", "research"] and `args[0]` took
    # "market" - so a two-word name silently made a conversation the user
    # had not asked for and could not guess the name of. `/remember` and
    # `/plan` already read the untokenized line for exactly this reason.
    name = line[len("/new"):].strip() or None
    existed = bool(name) and _slug(name) in s.state["sessions"]
    created = _create_session(s.state, name)
    s.save()
    _relock(s)
    if existed:
        s.console.print(f"[yellow]{TAG} a conversation named "
                        f"[bold]{created}[/] already exists - switched to it, "
                        f"with its history. /new with no name always starts "
                        f"an empty one.[/]")
    else:
        s.console.print(f"{TAG} new conversation [bold green]{created}[/]")


def _cmd_switch(s, line, args):
    # Matched on the SLUG of the whole remainder, for the same reason
    # `/new` reads it: the names on offer are slugs, so `/switch market
    # research` and `/switch Market-Research` should both find
    # `market-research` rather than report it missing.
    want = line[len("/switch"):].strip()
    target = want if want in s.state["sessions"] else _slug(want) if want         else ""
    if target in s.state["sessions"]:
        s.state["active"] = target
        s.save()
        _relock(s)
        s.console.print(f"{TAG} switched to [bold green]{target}[/]")
    else:
        s.console.print("[yellow]/switch <name> - one of:[/]")
        s.show_sessions()


def _cmd_rename(s, line, args):
    # The OLD name has to survive the call: `save()` must be told the removal
    # was deliberate, or the peer-merge in `_save_state` restores it and the
    # rename reads as a copy.
    old = None
    if len(args) == 1:
        old = s.state["active"]
        ok = _rename_session(s.state, old, args[0])
    elif len(args) == 2:
        old = args[0]
        ok = _rename_session(s.state, old, args[1])
    else:
        ok = False
    if ok:
        s.save(dropped={old} if old else None)
        s.console.print(f"{TAG} renamed {s.G['arrow']} "
                        f"[bold green]{s.state['active']}[/]")
    else:
        s.console.print("[yellow]/rename <new> or /rename <old> <new> - the "
                        "name may be taken[/]")


#: ONE LINE PER COMMAND, for three readers: `/help` at the prompt, the
#: unknown-command hint, and the MODEL - which otherwise knows nothing about
#: these. They are harness commands the USER types; the model never runs
#: one and never saw the list, so asked "how do I start a new conversation?"
#: it could not say `/new`. The session states them in its preamble the
#: way it states the CLI command index. Every key in COMMANDS has a line
#: here (pinned), and the client reference page lists the same set.
COMMAND_HELP = {
    "/plan <request>": "the builder proposes only; nothing is written",
    "/go": "execute the plan proposed in the previous turn",
    "/review": "adversarial review of the current changes, read-only",
    "/diff": "files the last turn added, modified or deleted",
    "/undo": "revert the last turn (git checkpoint)",
    "/remember <note>": "append a standing note to CORABUILD.md",
    "/new [name]": "start a NEW conversation in this repository (the "
                   "current one is kept)",
    "/sessions": "list this repository's conversations",
    "/switch <name>": "continue another conversation",
    "/rename <new>": "rename the active conversation",
    "/compact": "summarise this conversation and continue in a fresh one",
    "/transcript": "show the tail of the stored conversation",
    "/gated on|off": "approval mode: every mutating action asks y/n",
    "/help": "this list",
    "/exit": "leave the session (the conversation is kept); /quit too",
}


def session_commands_index() -> str:
    """One line per session command - the text `/help` prints and the
    preamble carries."""
    width = max(len(k) for k in COMMAND_HELP)
    return "\n".join(f"{k.ljust(width)}  {v}" for k, v in COMMAND_HELP.items())


def _relock(s) -> None:
    """Re-point the conversation lock after /new, /switch or /compact.

    Warn-only on a held target: the user chose the conversation by name,
    so the call is theirs - but they get told, because the cost of sharing
    is silent (the two sessions overwrite each other's saves).
    """
    try:
        from ioagentfarm.builder.lock import acquire_conversation, holder_line
        if not acquire_conversation(s):
            s.console.print(f"[yellow]{TAG} careful - this conversation is "
                            f"open in another build session "
                            f"({holder_line(s)}); the two will overwrite "
                            "each other's record. /new is safer.[/]")
    except Exception:                     # noqa: BLE001 - a lock is a guard,
        logger.debug("relock failed", exc_info=True)


def _cmd_help(s, line, args):
    s.console.print(f"{TAG} session commands - typed at this prompt; "
                    "anything else is a message to the builder:")
    for ln in session_commands_index().splitlines():
        s.console.print(f"  {ln}", highlight=False)
    s.console.print("[dim]  exit, quit and help also work without the "
                    "slash[/]")
    s.console.print("[dim]  mid-turn prompts: every install asks y/n/a "
                    "(a = allow installs this session); /gated on asks "
                    "before every mutating action. Ctrl+C at a prompt "
                    "cancels the turn.[/]")


#: command -> handler. `/session` with no argument aliases `/sessions`; with
#: an argument it is not a command at all and falls through to the macro
#: lookup, which is the historical behaviour.
COMMANDS = {
    "/exit": _cmd_exit, "/quit": _cmd_exit,
    "/sessions": _cmd_sessions,
    "/plan": _cmd_plan, "/go": _cmd_go, "/review": _cmd_review,
    "/gated": _cmd_gated, "/compact": _cmd_compact,
    "/transcript": _cmd_transcript,
    "/diff": _cmd_diff, "/undo": _cmd_undo, "/remember": _cmd_remember,
    "/new": _cmd_new, "/switch": _cmd_switch, "/rename": _cmd_rename,
    "/help": _cmd_help,
}


#: When the conversation is compacted without being asked, and when the
#: user is merely warned. Percentages of the model's own context window.
#: `/compact` existed from the start and was MANUAL ONLY: nothing measured
#: the session, so a long one degraded quietly - the largest seen on disk
#: was 190 KB in a single turn of 192 messages - and the user found out by
#: the answers getting vaguer. Set either to 0 to switch that half off.
_COMPACT_AT = "IOF_BUILD_COMPACT_AT"
_COMPACT_WARN = "IOF_BUILD_COMPACT_WARN"


def _pct_env(name: str, default: int) -> int:
    raw = (os.environ.get(name) or "").strip()
    if not raw:
        return default
    try:
        return max(0, min(100, int(raw)))
    except ValueError:
        return default


def _context_pct(s) -> float | None:
    """How full this conversation's context is, from the runtime's own
    per-call record. None when nothing has been measured yet."""
    try:
        from ioagentfarm.builder import usage as _usage
        key = _session_key(s.role, s.digest, s.active()[1]["suffix"])
        stats = _usage.read(_usage.usage_path(_root(), key))
        return float(stats["context_pct"]) if stats else None
    except Exception:                     # noqa: BLE001 - never block the loop
        return None


def _compact_if_full(s) -> None:
    """Warn, then compact, before the window runs out.

    Automatic because the alternative is a session that gets quietly worse:
    the model does not announce that it is crowded, and by the time a user
    notices vague answers the context is already the problem. Compaction is
    not lossy in the way it looks - the full conversation stays under
    `/switch`, and the successor carries a distilled summary.

    Announced, never silent: it starts a new conversation, and a user who
    typed nothing should still be told why the session name changed.
    """
    # A provider that just refused the context as TOO LARGE is a stronger
    # signal than the meter (which reads the last SUCCESSFUL call and so
    # never crosses its threshold on the way down). One forced attempt.
    if getattr(s, "force_compact", False):
        s.force_compact = False
        s.console.print(f"[yellow]{TAG} the model refused the last request "
                        "as too large for its context - compacting[/]")
        _cmd_compact(s, "", "")
        return
    pct = _context_pct(s)
    if pct is None:
        return
    at = _pct_env(_COMPACT_AT, 75)
    warn = _pct_env(_COMPACT_WARN, 60)
    failed_at = getattr(s, "_compact_failed_turn", None)
    if failed_at is not None:
        turns_now = int(s.active()[1].get("turns", 0))
        if turns_now < failed_at + 3:
            return                        # recently failed; see _cmd_compact
        s._compact_failed_turn = None
    if at and pct >= at:
        s.console.print(f"[yellow]{TAG} context is {pct:.0f}% full - "
                        "compacting so the next turns keep their room "
                        "(the full conversation stays under /switch)[/]")
        _cmd_compact(s, "", "")
        return
    if warn and pct >= warn and not getattr(s, "_compact_warned", False):
        s._compact_warned = True
        s.console.print(f"[dim]{TAG} context is {pct:.0f}% full - /compact "
                        f"starts a fresh conversation carrying a summary[/]")


def dispatch_guarded(s, line: str):
    """One input line, and NO command may end the session by raising.

    `s.guarded` wraps the model TURN, so a provider failure never destroyed
    the REPL - but a slash command runs outside it, and the loop calls
    `_dispatch` bare. Every command that touches the world could therefore
    take the whole session with it: measured, `/undo` raised PermissionError
    on a read-only file (ordinary on Windows) and on a directory standing
    where a file was, and each one printed a traceback and ended the
    session, losing the conversation the user was in the middle of.

    The individual causes are fixed at their source; this is the floor that
    makes the NEXT one a red line instead of a dead session. It deliberately
    does not catch KeyboardInterrupt - Ctrl+C at a command should still
    reach the loop, which handles it.
    """
    try:
        return _dispatch(s, line)
    except KeyboardInterrupt:
        # A COMMAND IS NOT THE SESSION. This used to be deliberately let
        # through "so the loop handles it" - but the loop only handles
        # Ctrl+C around `console.input`, so an interrupt during a command
        # ended the REPL. `/undo` is the case that made it expensive: it
        # restores files one at a time, so Ctrl+C halfway left a
        # HALF-REVERTED tree, dropped no checkpoint, saved nothing, and
        # took away the prompt that could have finished the job. A message
        # to the model is still cancellable - that path raises inside
        # `guarded`, which owns it.
        print()
        s.console.print(f"[yellow]{TAG} {line.split()[0]} interrupted - the "
                        "session is intact. Anything it had already done is "
                        "on disk; run it again to finish.[/]")
        return _FAILED
    except Exception as exc:              # noqa: BLE001 - see docstring
        logger.exception("build command failed: {}", line[:120])
        s.console.print(f"[red]{TAG} that command failed: "
                        f"{type(exc).__name__}: {str(exc)[:200]}[/]")
        s.console.print("[dim]the session is intact - the detail is in the "
                        "build log. Try something else, or /exit.[/]")
        return _FAILED


#: Bare words that mean the HARNESS, typed without the slash. Seen on a
#: client box: `exit` and `help` went to the model as paid turns and came
#: back as refusals ("I'm an enterprise assistant focused on professional
#: tasks"), and `exit` then needed Ctrl+C. Only words with no plausible
#: reading as a request to the builder are here - `diff`, `new`, `review`
#: stay messages, because "review" alone can be a real instruction.
BARE_COMMANDS = {
    "exit": "/exit", "quit": "/quit", "q": "/quit",
    "help": "/help", "?": "/help",
}

#: Characters a person types when they mean "nothing": an empty message
#: that arrived as `""` was a paid turn that asked nothing, and the model
#: refused it. A line made only of these is blank.
_NOISE = set("\"'`\u201c\u201d\u2018\u2019 \t")


def is_blank_input(line: str) -> bool:
    """True when *line* carries no request - empty, or quotes/backticks
    only (`""`, `''`, "``")."""
    return not line or all(ch in _NOISE for ch in line)


def _dispatch(s, line: str):
    """One input line. Returns :data:`_STOP` to leave the loop."""
    parts = line.split()
    cmd, args = parts[0], parts[1:]
    if not args and cmd.lower() in BARE_COMMANDS:
        cmd = BARE_COMMANDS[cmd.lower()]
    if cmd == "/session" and not args:
        cmd = "/sessions"
    handler = COMMANDS.get(cmd)
    if handler is not None:
        return handler(s, line, args)
    if cmd.startswith("/"):
        macro = _repo_macro(s.repo, cmd[1:])
        if macro is not None:
            extra = line[len(cmd):].strip()
            s.guarded(s.send, f"{macro}\n\n{extra}" if extra else macro)
            return None
        s.console.print(f"[yellow]unknown command {cmd}[/] - /help lists "
                        "the session commands; a message without a leading "
                        "slash goes to the builder")
        return None
    s.guarded(s.send, _expand_file_refs(s.repo, line, s.console))
    return None


def _message_flag_present() -> bool:
    """Did the caller actually TYPE --message?

    typer hands the default `""` for both "omitted" and "passed empty", and
    the two need opposite answers: omitted opens an interactive session,
    passed-empty is a caller asking for a turn with nothing in it. argv is
    the only place the difference survives.
    """
    import sys
    argv = sys.argv[1:]
    for i, a in enumerate(argv):
        if a in ("--message", "-m"):
            return True
        if a.startswith("--message=") or (a.startswith("-m") and len(a) > 2):
            return True
    return False


def _resolve_workspace(explicit: str, console, *, interactive: bool) -> str:
    """The ONE workspace moment, in the session itself.

    A workspace selected before launch - `--workspace`, `IOF_WORKSPACE`, or
    `workspace use` - is used silently, which is the common case. With NONE
    selected, an interactive session ASKS - list the existing workspaces,
    use the one the user names, or create a new one through the same
    machinery as `aicore workspace create` - instead of refusing with an
    error that sends a new user away to run two commands and come back.
    One-shots and CI keep the fail-closed refusal: nobody is there to
    answer, and a guessed workspace is the platform's cardinal sin.
    """
    from ioagentfarm.cli import _workspace_code

    code = ""
    try:
        code = _workspace_code(explicit, required=False) or ""
    except Exception:                     # noqa: BLE001 - resolve below
        code = ""
    if code:
        return code
    if not interactive:
        return _workspace_code(explicit, required=True)   # standard refusal

    from ioagentfarm import cli_workspace as wsc
    existing: list[str] = []
    try:
        from ioagentfarm.engine.workspaces import RETIRED_WORKSPACE_CODES
        existing = [w["code"] for w in wsc._store().list_workspaces()
                    if w["code"] not in RETIRED_WORKSPACE_CODES]
    except Exception:                     # noqa: BLE001 - list is a nicety
        existing = []

    console.print("[bold]No workspace is selected.[/] A build session runs "
                  "inside one workspace - everything it creates belongs "
                  "there.")
    if existing:
        console.print("existing: " + "  ".join(f"[cyan]{c}[/]"
                                               for c in existing))
        console.print("[dim]type one of the above to use it, or a new "
                      "lowercase code to create it[/]")
    else:
        console.print("[dim]none exist yet - type a short lowercase code "
                      "to create one (e.g. retail, pharma)[/]")
    from ioagentfarm.engine.workspaces import workspace_code_problem
    while True:
        try:
            ans = console.input("[bold]workspace > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            raise typer.Exit(code=2)
        if not ans:
            continue
        if ans in existing:
            # The real `workspace use`, not its two inner helpers: the
            # first version called _activate + _adopt_local, which apply
            # settings to THIS process and persist nothing - the next
            # `aicore build` asked again, found live when run C of the
            # three-branch validation re-prompted after run B had
            # "selected" acme. use() also writes the durable pointer.
            try:
                wsc.use(code=ans)
            except typer.Exit:
                raise
            except Exception as exc:      # noqa: BLE001 - retry
                console.print(f"[red]{str(exc)[:200]}[/] - try another code")
                continue
            console.print(f"{TAG} using workspace [cyan]{ans}[/]")
            return ans
        # A NEW code is validated HERE, before anything is created, with the
        # rule the scaffold applies to the same string one command later
        # (`aicore new-workspace <code>` makes it a package prefix). The
        # first version handed the code straight to create(), whose refusal
        # is a typer.Exit that this loop re-raised - so a two-letter code
        # typed at the prompt ENDED THE SESSION instead of asking again, and
        # a three-letter one was accepted here and refused by the scaffold.
        problem = workspace_code_problem(ans, new=True)
        if problem:
            console.print(f"[red]{problem}[/] - try another code")
            continue
        # LOCAL OR SHARED is asked before the tenant exists, because that is
        # the only moment the answer can take effect: `aicore local on`
        # AFTER creation leaves the row in the shared database. The question
        # appears only when the target IS a shared server; a SQLite file is
        # one developer's whether or not local mode is on.
        where = _placement_choice(ans, console)
        if where is None:
            continue
        try:
            # the same function `aicore workspace create` runs: checks the
            # code, activates, adopts local mode, grants membership. A
            # shared target the user just chose is confirmed (yes=True) -
            # asking "create it there?" again would be the same question
            # twice; local mode passes create()'s own check silently.
            wsc.create(code=ans, name="", description="", member=None,
                       no_member=False, yes=(where == "shared"))
        except typer.Abort:
            console.print("[yellow]declined - type another code, or Ctrl+C "
                          "to leave[/]")
            continue
        except typer.Exit:
            raise
        except Exception as exc:          # noqa: BLE001 - bad code, retry
            console.print(f"[red]{str(exc)[:200]}[/] - try another code")
            continue
        console.print(f"{TAG} created and selected workspace [cyan]{ans}[/]"
                      + (" [dim](local mode)[/]" if where == "local" else ""))
        return ans


def _placement_choice(code: str, console) -> str | None:
    """``local`` | ``shared`` | ``sqlite`` (nothing to ask) | ``None`` (re-ask).

    Asked only when creating *code* would land it in a database other
    people read. Choosing local turns local mode on for this directory and
    this process before the tenant is created - the order `aicore local`
    documents as the only one that works. A tester who never ran `local on`
    because nothing made them is the case this closes: the choice is put in
    front of them at the one moment it is still free.
    """
    import os as _os
    from ioagentfarm.engine import workspace_env as _we

    if _we.directory_local():
        return "local"
    url = (_os.getenv("IOF_DATABASE_URL") or "").strip()
    if not url or url.startswith("sqlite:"):
        return "sqlite"
    try:
        from ioagentfarm.cli import _root
        from ioagentfarm.engine.db import describe_db_target
        target = describe_db_target(_root())
    except Exception:                     # noqa: BLE001 - show something
        target = url.rsplit("@", 1)[-1]
    console.print(f"[bold]Where should '{code}' live?[/]")
    console.print("  [cyan]1[/]  local  - a SQLite file under this "
                  "directory's state dir; nothing shared (recommended for "
                  "trying things out)")
    console.print(f"  [cyan]2[/]  shared - {target}  [dim](set by "
                  f"{_we.source_of('IOF_DATABASE_URL')}; other people will "
                  "see it)[/]")
    while True:
        try:
            pick = console.input("[bold]  1 or 2 > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            raise typer.Exit(code=2)
        if pick in ("1", "local", "l"):
            from ioagentfarm.cli import local_mode
            _we.set_directory_local(True)
            local_mode(True, code=code)
            console.print(f"{TAG} local mode on for this directory - "
                          "`aicore local off` reverses it")
            return "local"
        if pick in ("2", "shared", "s"):
            return "shared"
        if pick in ("", "b", "back"):
            return None
        console.print("[yellow]1 or 2 (empty line to pick another code)[/]")


# ── the command ──────────────────────────────────────────────────────────

def build(
    role: str = typer.Option(
        "cora_build", "--role", "-r",
        help="The agent to build with. Default: cora_build, the platform's "
             "dedicated builder. The Core Assistant (cora) stays the "
             "general-purpose assistant."),
    message: str = typer.Option(
        "", "--message", "-m",
        help="Run a single turn non-interactively and exit. Without it, an "
             "interactive session opens."),
    new_session: bool = typer.Option(
        False, "--new-session",
        help="Start a fresh conversation for this repository. The previous "
             "session's JSONL is kept; it is simply no longer continued."),
    session: str = typer.Option(
        "", "--session", "-s",
        help="Named conversation to continue or create for this repository. "
             "Default: the one last active here."),
    workspace: str = typer.Option(
        "", "--workspace", "-w",
        help="Tenant workspace. Defaults to IOF_WORKSPACE, then the one set "
             "by `workspace use`."),
    plan: bool = typer.Option(
        False, "--plan",
        help="With --message: a planning turn. The builder proposes; any "
             "file change it makes is reverted by the harness. Approve with "
             "a follow-up --message '/go' or interactively."),
    review: bool = typer.Option(
        False, "--review",
        help="Adversarially review the current changes (the last turn's "
             "diff, or the working tree against HEAD) in a fresh review "
             "session. Read-only: any change the reviewer makes is "
             "reverted. Usable without --message."),
    json_out: bool = typer.Option(
        False, "--json",
        help="One-shot machine output: print a single JSON object as the "
             "final line - reply, files changed, whether a revert ran. "
             "For CI. Requires --message, --plan or --review."),
    gated: bool = typer.Option(
        False, "--gated",
        help="Approval mode: every mutating action (exec, file writes) "
             "pauses for y/n before executing. Interactive terminals only; "
             "toggle in-session with /gated on|off."),
):
    """Interactive solution building with cora_build, in this directory.

    The assistant designs content and places it with the platform scaffold
    commands - `new-agent`, `new-skill`, `new-workflow` - then writes the
    real content into the files those commands created, lints what changed,
    and reports `git status`. Conversations continue across invocations:
    each repository keeps named sessions, stored as the agent session JSONL.
    In the prompt: /plan <request>, /go, /review, /gated on|off, /diff,
    /undo, /remember <note>, /compact, /transcript, /new \\[name],
    /sessions, /switch <name>, /rename <new>, /help, /exit (or /quit).

    Local only: the agent runs on this machine and no server is contacted.
    """
    from ioagentfarm.cli import (_activate_workspace, _default_user_id,
                                 _root, _workspace_code)
    from ioagentfarm.cli_orchestration import ensure_iobot_agent

    console = _console()

    # THE STATE DIRECTORY IS CHECKED FIRST, AND BY NAME. Everything below
    # writes under it, so an unusable root surfaced as whatever happened to
    # touch it first: with `IOF_ROOT` pointing at a FILE the failure came
    # back as `No agent 'cora_build': [WinError 183] Cannot create a file
    # when that file already exists` - a message about the agent, for a
    # problem with a path, which sends the reader looking in the wrong
    # place entirely.
    # THE CONSOLE IS QUIET FROM THE FIRST LINE OF THE COMMAND, not from the
    # first turn. `quiet_runtime_logs` used to be called by the engine's
    # lazy `_build`, which left two gaps: everything logged BEFORE turn one
    # went to loguru's default stderr sink, and the one-shot path - which
    # never builds the in-process engine - was never quieted at all, so a
    # `--message` run printed every runtime record it produced. Seen live:
    # a checkpoint warning landed in the middle of a session, formatted as
    # a raw log record with ANSI codes. The log is a file the user opens if
    # they want it; nothing about it may reach the screen.
    try:
        from ioagentfarm.builder.engine import BuildEngine
        BuildEngine.quiet_runtime_logs()
    except Exception:                     # noqa: BLE001 - never block a build
        pass

    try:
        _root().mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        out = {"error": f"the engine state directory {_root()} is not "
                        f"usable ({exc}). IOF_ROOT must name a directory "
                        f"this user can write; it currently resolves to "
                        f"something else."}
        print(json.dumps(out) if json_out else out["error"])
        raise typer.Exit(code=1)

    ws_code = _resolve_workspace(workspace, console,
                                 interactive=not (message or review
                                                  or json_out))
    _activate_workspace(ws_code, _root())
    uid = _default_user_id()
    repo = Path.cwd()

    if not (role or "").strip():
        # `--role "$ROLE"` with the variable unset. Resolving "" reached
        # importlib.resources and came back as a bare `StopIteration`,
        # which names nothing the caller can act on.
        out = {"error": "--role was given but is empty; name the agent to "
                        "build with, or omit --role for cora_build"}
        print(json.dumps(out) if json_out else out["error"])
        raise typer.Exit(code=2)

    try:
        ensure_iobot_agent(role)
    except typer.Exit:
        raise
    except Exception as exc:              # noqa: BLE001 - see below
        # NOT just FileNotFoundError. `--role ""` - a shell variable that
        # did not expand - reached importlib.resources and came back as a
        # bare StopIteration traceback, and any other resolution failure
        # (a pack half-installed, a workspace path that is not readable)
        # did the same. The user gets a sentence naming the role either
        # way; the traceback belongs in the log.
        logger.debug("agent resolution failed for role {!r}", role,
                     exc_info=True)
        detail = str(exc) or type(exc).__name__
        print(json.dumps({"error": f"No agent '{role}': {detail}"}))
        raise typer.Exit(code=1)

    if _ensure_builder_skill(role):
        print(f"[build] placed missing builder skill(s) into {role}'s "
              "workspace (seeded before they shipped)")

    # The same per-role instance config the ad-hoc chat builds, under its own
    # key so build tool-state never tangles with plain chat.
    try:
        from ioagentfarm.engine.iobot_config import create_instance_config
        cfg_path = create_instance_config(_root(), f"build-{role}", str(repo))
    except Exception:                      # noqa: BLE001 - never block a build
        logger.debug("build instance config unavailable for {!r}", role,
                     exc_info=True)
        cfg_path = None

    root = _root()
    digest = _repo_digest(repo)
    state = _load_state(root, digest, repo)
    # `--new-session` WITH `--session NAME` means a FRESH conversation under
    # that name. Run as two independent ifs, the second silently undid the
    # first: the named session was selected and then abandoned for an
    # auto-named one, so a scripted first turn landed in `s2` while every
    # later turn landed in the name - two conversations, no continuity.
    #
    # Found by a scenario that passed once and failed once: asked to build
    # what it had just designed, the builder answered "no prior conversation
    # history is accessible in this session" and asked three questions. That
    # was TRUE, and it looked like a model failure for as long as nobody read
    # the session files.
    if session and new_session:
        name = _slug(session)
        if name in state["sessions"]:
            # The name is taken and the caller asked for a NEW one, so it
            # gets a sibling rather than the existing conversation - never a
            # silent switch into history the caller did not ask for.
            n = 2
            while f"{name}-{n}" in state["sessions"]:
                n += 1
            name = f"{name}-{n}"
        _create_session(state, name)
    elif session:
        _create_session(state, session)   # create-or-switch by name
    elif new_session:
        _create_session(state, None)
    _save_state(root, digest, state)

    s = BuildSession(role=role, repo=repo, uid=uid, ws_code=ws_code,
                     root=root, digest=digest, state=state,
                     cfg_path=cfg_path, console=console,
                     git_ok=_is_git_repo(repo), gated=gated)
    G = s.G
    # MCP HEALTH, CHECKED WHERE THE CONSOLE IS. The runtime's own connect
    # failure is written to a subprocess stderr log that nothing renders, so
    # a rejected credential reached the user as an agent quietly missing its
    # tools - and the agent, given no signal, invented a reason. One probe
    # per REMOTE server, once per session, before the first turn: the person
    # is told, and so is the model (the preamble carries it).
    try:
        s.mcp_down = mcp_health()
    except Exception:                     # noqa: BLE001 - never block a session
        s.mcp_down = []
    for bad in s.mcp_down:
        console.print(f"[yellow]{TAG} MCP server [bold]{bad['name']}[/] will "
                      f"not answer this session[/] - {bad['status']}: "
                      f"{bad['detail']}", soft_wrap=True)
        if bad.get("advice"):
            console.print(f"[dim]      {bad['advice']}[/]", soft_wrap=True)
        console.print(f"[dim]      its mcp_{bad['name']}_* tools are "
                      f"unavailable; `aicore mcp-list --probe` re-checks[/]",
                      soft_wrap=True)
    # ONE CONVERSATION, ONE WRITER. The runtime rewrites the whole session
    # JSONL from memory on every save and the state file merges
    # per-conversation-name, so two sessions holding one conversation
    # silently overwrite each other's turns (and fight over one .jsonl.tmp
    # on Windows). A held conversation is DIVERTED, not shared: the second
    # session continues under a fresh name, exactly as a second Claude Code
    # session gets its own conversation. `--session <name>` targets are
    # refused instead - the caller named the conversation on purpose.
    from ioagentfarm.builder.lock import acquire_conversation, holder_line
    if not acquire_conversation(s):
        who = holder_line(s)
        held = s.active()[0]
        if session:
            out = {"error": f"conversation '{held}' is open in another "
                            f"build session ({who}) - close it, or pick "
                            "another --session name"}
            print(json.dumps(out) if json_out else out["error"])
            raise typer.Exit(code=1)
        created = _create_session(s.state, None)
        s.save()
        acquire_conversation(s)
        console.print(f"[yellow]{TAG} conversation [bold]{held}[/] is open "
                      f"in another build session ({who}) - continuing in "
                      f"[bold green]{created}[/] so neither overwrites the "
                      "other[/]")
    if message.strip() == "" and (message != "" or _message_flag_present()):
        # AN EMPTY --message IS NOT AN INTERACTIVE SESSION. `if message:`
        # is falsy for "", so `--message ""` fell past every one-shot
        # branch and opened the REPL: in CI, where stdin is a closed pipe,
        # that reads EOF and exits 0 having done NOTHING - a green step
        # that ran no turn. On a terminal it just sits there. A caller that
        # passed the flag asked for one turn, so say what is wrong.
        #
        # WHITESPACE IS EMPTY TOO. `--message "   "` (a script's unset
        # variable between quotes, a stray newline) is non-empty to `==`
        # and was sent to the model as a turn - a paid call that asked
        # nothing. A non-empty blank string can only have been PASSED, so
        # it needs no argv check; the argv check still tells `""` apart
        # from an omitted flag.
        out = {"error": "--message was given but is empty (or only "
                        "whitespace); pass the text of the turn, or omit "
                        "--message for an interactive session"}
        print(json.dumps(out) if json_out else out["error"])
        raise typer.Exit(code=2)

    if want_engine(message=message, review=review):
        s.start_engine()

    # ── one-shot paths: the CI contract ──────────────────────────────────
    if message:
        message = _expand_file_refs(repo, message, console)
        # A SLASH COMMAND IS A COMMAND, whichever way it arrives. Without
        # this, `--message "/undo"` was handed to the MODEL as prose: it
        # improvised an undo by deleting what it remembered creating, could
        # not restore what it had modified, left the workflow referencing a
        # deleted step prompt - and reported the repository was "as it was
        # before this session". The harness's own undo is a git tree restore
        # that depends on nothing the model recalls. The interactive REPL
        # dispatched these all along, so the same input did two different
        # things depending on how it was typed; the command's own help even
        # documents `--message '/go'`, which could never have worked.
        head = message.strip().split()[0] if message.strip() else ""
        # A repository MACRO is a command too. `_dispatch` resolves one and
        # the one-shot path did not, so `--message "/release-notes"` sent the
        # literal string to the model - which improvises rather than failing,
        # so the macro silently never ran.
        if head.startswith("/") and head not in COMMANDS and head != "/session":
            macro = _repo_macro(repo, head[1:])
            if macro is not None:
                extra = message.strip()[len(head):].strip()
                message = f"{macro}\n\n{extra}" if extra else macro
                head = ""
            else:
                # A MISTYPED command must not become an instruction. It used
                # to be handed to the model as prose: one observed `/nope`
                # turn created 11 files nobody asked for. The interactive
                # REPL has always refused these; a script deserves the same
                # answer, and a non-zero exit so it stops.
                # --json PROMISES a JSON object as the final line, and
                # this branch printed console prose - so the one input a
                # CI script is most likely to get wrong (a typo'd command)
                # was also the one whose answer it could not parse.
                if json_out:
                    print(json.dumps(
                        {"error": f"unknown command {head}",
                         "command": head, "dispatched": False,
                         "hint": f".aicore/commands/{head[1:]}.md would "
                                 "define it as a repository macro"},
                        ensure_ascii=False), flush=True)
                else:
                    console.print(f"[red]unknown command {head}[/] - not a "
                                  "built-in and no repository macro at "
                                  f".aicore/commands/{head[1:]}.md")
                raise typer.Exit(code=2)
        if head in COMMANDS or (head == "/session"):
            # JSON goes LAST, after the command has actually run. Printed
            # first it broke the documented contract - "the final stdout
            # line is a single JSON object" - because the command's own
            # output followed it, so a CI script reading the last line got
            # console prose. It also claimed `dispatched: true` before
            # dispatching, which was untrue if the command then failed.
            ok = dispatch_guarded(s, message.strip()) is not _FAILED
            if json_out:
                print(json.dumps({"command": head, "dispatched": ok},
                                 ensure_ascii=False), flush=True)
            return
    if message or review:
        if json_out:
            # THE FINAL LINE IS THE CONTRACT: upstream banners (local mode,
            # seeding) may precede it, so CI parses the LAST stdout line -
            # which means the contract has to survive the turn FAILING.
            # These calls used to run bare: a provider error, a tool crash
            # or Ctrl+C came out of `build()` as a traceback on stderr with
            # no JSON line at all, and the caller reading the last stdout
            # line got a banner to parse.
            try:
                if review and not message:
                    # Name the REASON. "nothing to review" reads as "your
                    # tree is clean", and the commonest cause is the
                    # opposite: a directory that is not a git repository,
                    # where the review has no baseline to diff against.
                    out = s.run_review(quiet=True) or {
                        "reply": None, "mode": "review", "changed": [],
                        "reverted": [], "enforced": False,
                        "note": ("review needs a git repository - run "
                                 "`git init`" if not s.git_ok
                                 else "nothing to review")}
                else:
                    out = s.send(message, mode="plan" if plan else "act",
                                 quiet=True)
                    if review:
                        out["review"] = s.run_review(quiet=True)
            except KeyboardInterrupt:
                print(json.dumps({"error": "interrupted", "reply": None,
                                  "changed": []},
                                 ensure_ascii=False), flush=True)
                raise typer.Exit(code=130)
            except Exception as exc:      # noqa: BLE001 - see comment above
                logger.exception("one-shot build turn failed")
                print(json.dumps(
                    {"error": f"{type(exc).__name__}: {str(exc)[:400]}",
                     "reply": None, "changed": []},
                    ensure_ascii=False), flush=True)
                raise typer.Exit(code=1)
            print(json.dumps(out, ensure_ascii=False), flush=True)
            return
        if review and not message:
            s.run_review()
            return
        s.send(message, mode="plan" if plan else "act")
        if review:
            s.run_review()
        return
    if json_out or plan:
        print(json.dumps({"error": "--json and --plan are one-shot options; "
                          "pass --message (or --review alone)"}))
        raise typer.Exit(code=2)

    # ── the interactive loop ─────────────────────────────────────────────
    name, _ = s.active()
    console.print(f"[bold]build[/] {G['sep']} {role} {G['sep']} "
                  f"[dim]{repo}[/]")
    console.print(f"workspace [cyan]{ws_code}[/] {G['sep']} session "
                  f"[bold green]{name}[/]")
    console.print("[dim]content is placed with the scaffold commands. "
                  f"@path pulls a file into the message {G['sep']} Ctrl+C "
                  f"cancels a turn. /plan <request> {G['sep']} /go {G['sep']} "
                  f"/review {G['sep']} /diff {G['sep']} /undo {G['sep']} "
                  f"/remember <note> {G['sep']} /gated on|off "
                  f"{G['sep']} /help {G['sep']} /compact "
                  f"{G['sep']} /transcript {G['sep']} /new \\[name] "
                  f"{G['sep']} /sessions "
                  f"{G['sep']} /switch <name> {G['sep']} /rename <new> "
                  f"{G['sep']} /exit[/]")
    if not s.git_ok:
        console.print("[yellow]not a git repository - /undo and /diff are "
                      "unavailable here; run `git init` to enable turn "
                      "checkpoints[/]")
    # WHERE YOU LEFT OFF. A provisional checkpoint at the head means the
    # last session's final turn never finished - a crash, a closed
    # terminal, Ctrl+C - and the next start used to open with a clean
    # prompt saying nothing about it.
    try:
        from ioagentfarm.builder.checkpoints import cp_provisional
        _, _sess0 = s.active()
        _cps0 = _sess0.get("checkpoints") or []
        if _cps0 and cp_provisional(_cps0[-1]):
            console.print(f"[yellow]{TAG} the previous turn was "
                          "interrupted - what it had already written is "
                          "on disk. /diff shows it; /undo reverts it.[/]")
    except Exception:                     # noqa: BLE001 - a notice only
        logger.debug("interrupted-turn notice failed", exc_info=True)

    # THE HUB TAKES STDIN from here to /exit: one reader thread, every
    # consumer asks the queue. Started after the startup prompts (which
    # read stdin directly) and only on a real terminal; when it does not
    # start, every entry point falls back to console.input - the old
    # behaviour exactly. See builder/input_hub.py for the design.
    from ioagentfarm.builder import input_hub, winconsole
    hub_on = input_hub.start()
    if hub_on:
        console.print("[dim]you can type while a turn runs - the message "
                      "queues and sends when it finishes (Ctrl+C "
                      "interrupts instead)[/]")
    s._qe_token = winconsole.disable_quickedit()
    if s._qe_token is not None:
        console.print("[dim]QuickEdit paused for this session (drag-select "
                      "freezes the console mid-turn); restored on exit[/]")
    try:
        while True:
            name, _ = s.active()
            # a line typed during the turn is already on the hub's queue;
            # the prompt below returns it instantly - announce it so the
            # transcript shows what was sent and why no typing echoed here
            backlog = hub_on and input_hub.hub().pending()
            try:
                line = input_hub.repl_input(
                    console,
                    f"\n[bold]build[/] [bold green]{name}[/] > ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if backlog and line:
                console.print(f"{line}  [dim](typed during the turn)[/]",
                              highlight=False)
            if is_blank_input(line):
                if line:
                    console.print("[dim]nothing to send - type a request, or "
                                  "/help for the session commands[/]")
                continue
            if dispatch_guarded(s, line) is _STOP:
                break
            # ONLY here, and deliberately not inside `dispatch_guarded`: that
            # helper also serves the ONE-SHOT slash-command path
            # (`aicore build --message "/go"`), where compaction would spend an
            # extra model call the caller never asked for, in a script that
            # asked for exactly one command. A long session is an INTERACTIVE
            # condition.
            # GUARDED like everything else in this loop. It is the one
            # call the user did not make - it fires by itself at 75% - so
            # it is the last place a raise should be able to end the
            # session. It was also the only unguarded one.
            try:
                _compact_if_full(s)
            except KeyboardInterrupt:
                print()
                s.console.print(f"[yellow]{TAG} compaction interrupted - the "
                                "conversation is unchanged[/]")
            except Exception as exc:      # noqa: BLE001
                logger.exception("automatic compaction failed")
                s.console.print(f"[yellow]{TAG} automatic compaction failed "
                                f"({type(exc).__name__}) - the conversation "
                                "is unchanged; /compact retries it[/]")
    finally:
        # LEAVE CLEANLY. `/exit` returned from this function and left the
        # engine's event loop, its MCP server subprocesses and their
        # pipes to the interpreter's finalizer - which on Windows drains
        # the proactor's overlapped I/O with no bound and no output, so a
        # session that had an MCP server open "hung on /exit" with a
        # blank screen. The engine knows how to close what it opened.
        _shutdown(s)


def _shutdown(s) -> None:
    """Close the engine on the way out of an interactive session.

    Bounded and silent on failure: the user asked to leave, and nothing
    about closing may keep them here or print a traceback at them.
    """
    try:
        from ioagentfarm.builder import input_hub, winconsole
        input_hub.stop()
        winconsole.restore(getattr(s, "_qe_token", None))
    except Exception:                          # noqa: BLE001 - leaving
        logger.debug("input teardown failed", exc_info=True)
    lk = getattr(s, "lock", None)
    if lk is not None:
        lk.release()
    eng = getattr(s, "engine", None)
    if eng is None:
        return
    try:
        eng.close()
    except Exception:                          # noqa: BLE001 - leaving
        logger.debug("engine close on exit failed", exc_info=True)


def register_commands(app: typer.Typer) -> None:
    app.command("build")(build)
