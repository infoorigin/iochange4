"""Build-session identity: the state file, the key, and the JSONL.

The session IS the agent's own session record - these helpers derive its
key and filename rather than persisting anything of their own.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import unicodedata
from pathlib import Path

from loguru import logger


_SESSION_PREFIX = "build"


#: Answers cached per directory - the question is about a FILESYSTEM, and
#: one stat per repository per process is enough to ask it.
_FOLD_CACHE: dict = {}


def _case_insensitive_paths(probe: Path | None = None) -> bool:
    """Does THIS filesystem treat two paths differing only in case as one?

    MEASURED WHERE IT CAN BE, not inferred from the platform. The platform
    only gives the DEFAULT, and both defaults are wrong somewhere real: a
    case-sensitive APFS volume is a supported macOS choice (and the one a
    developer who has been bitten by case-only renames tends to pick), and
    a case-insensitive mount on Linux is ordinary the moment a repository
    lives on a network share or an exFAT disk.

    Getting it wrong in the folding direction is the one that costs: two
    distinct repositories would share a conversation map, so the second
    session continues the first's history and writes over it. The probe
    is one `samefile` against a case-swapped sibling; with nothing to
    probe, or nothing in the name to swap, the platform default stands.
    """
    default = sys.platform in ("win32", "darwin", "cygwin")
    if probe is None:
        return default
    try:
        target = Path(probe)
        key = str(target)
        if key in _FOLD_CACHE:
            return _FOLD_CACHE[key]
        swapped = target.parent / target.name.swapcase()
        if swapped.name == target.name or not target.exists():
            return default                # nothing to learn from this name
        answer = swapped.exists() and os.path.samefile(target, swapped)
        _FOLD_CACHE[key] = answer
        return answer
    except OSError:
        return default


def _repo_digest(repo: Path, *, legacy: bool = False) -> str:
    """The key for this repository's conversations.

    LOWERCASING IS ONLY CORRECT WHERE THE FILESYSTEM IS. On Windows and
    macOS `/work/Repo` and `/work/repo` are the same directory, so folding
    the case is what keeps one conversation when the path is typed either
    way. ON LINUX THEY ARE TWO DIFFERENT REPOSITORIES, and folding merges
    their conversations into one state file - so a session opened in the
    second would continue the first's history and write over its map.

    *legacy* forces the old unconditional fold, so a state file written
    before this distinction can still be found. See `_load_state`.
    """
    resolved = repo.resolve()
    text = str(resolved)
    if legacy or _case_insensitive_paths(resolved):
        text = text.lower()
    # macOS hands back DECOMPOSED path text; the same repository opened
    # from a shell that composes would otherwise key a second, empty
    # conversation map. Compose before hashing so one directory is one key.
    text = unicodedata.normalize("NFC", text)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:10]


def _state_file(root: Path, digest: str) -> Path:
    return root / "build_sessions" / f"{digest}.json"


def _slug(name: str) -> str:
    """Session names become part of the runtime session key; keep them tame."""
    import re
    s = re.sub(r"[^a-z0-9_-]+", "-", name.strip().lower()).strip("-")
    return s or "session"


def _fresh(repo: Path) -> dict:
    return {"repo": str(repo.resolve()), "active": "main",
            "sessions": {"main": {"suffix": "main", "turns": 0}}}


def _int(value, default: int = 0) -> int:
    """An int, whatever the file actually holds there."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _normalize(state, repo: Path) -> dict:
    """Migrate the original single-conversation shape, and REPAIR any other.

    The v1 state was ``{generation, turns}`` and the key suffix was ``g<N>``.
    The suffix is PRESERVED under a session named ``main`` so the existing
    JSONL continues - a state-format change must never orphan a conversation.

    Everything else here exists because PARSING IS NOT VALIDATING.
    `_load_state` caught `JSONDecodeError` and stopped there, so a file that
    was valid JSON of the wrong SHAPE walked straight into the session and
    took the command down before its first prompt - 17 distinct startup
    crashes over the shapes a hand-edited or half-migrated file actually
    takes: a bare list (`AttributeError`), a session map with no `active`
    (`KeyError`), an `active` naming a conversation that is not there, a
    session entry that is a string, a `generation` of `"three"`. The file is
    small, editable, sitting in the state directory, and the failure lands
    before anything the user can react to.

    So each field is repaired toward the nearest sane value and NOTHING is
    dropped that can be kept: an unusable `active` picks an existing
    conversation instead of erasing the map, and a session entry that is not
    a mapping is replaced only for itself. What cannot be repaired at all
    returns None, and the caller sets the file aside exactly as it does for
    unparseable JSON - the transcripts are never touched either way.
    """
    if not isinstance(state, dict):
        return None                       # a list, a string, a number, null
    if "sessions" not in state:
        gen = _int(state.get("generation"), 1)
        return {
            "repo": state.get("repo") or str(repo.resolve()),
            "active": "main",
            "sessions": {"main": {"suffix": f"g{gen}",
                                  "turns": _int(state.get("turns"))}},
        }
    sessions = state.get("sessions")
    if not isinstance(sessions, dict):
        return None                       # the one thing with no sane repair
    clean: dict = {}
    for name, sess in sessions.items():
        name = str(name)
        if not isinstance(sess, dict):
            # A conversation whose entry is junk still has a JSONL on disk
            # named by its suffix, and the suffix is conventionally the
            # name - so rebuilding the entry re-attaches the transcript
            # instead of orphaning it.
            sess = {}
        entry = dict(sess)
        entry["suffix"] = str(entry.get("suffix") or name) or "main"
        entry["turns"] = _int(entry.get("turns"))
        if not isinstance(entry.get("checkpoints"), list):
            entry.pop("checkpoints", None)
        clean[name] = entry
    if not clean:
        clean = {"main": {"suffix": "main", "turns": 0}}
    active = state.get("active")
    if not isinstance(active, str) or active not in clean:
        # Pick one rather than fail: `main` when it is there, else whichever
        # conversation sorts first, so the choice is at least stable.
        active = "main" if "main" in clean else sorted(clean)[0]
    return {"repo": state.get("repo") or str(repo.resolve()),
            "active": active, "sessions": clean}


def _load_state(root: Path, digest: str, repo: Path) -> dict:
    """The repository's conversations. A damaged file is KEPT, not replaced.

    This file is the only map from a conversation's name to the JSONL that
    holds it. Falling back to a fresh state and then saving over the
    damaged one made every named conversation unreachable while its
    transcript sat intact on disk - measured, and unrecoverable once the
    save landed. So a file that will not parse is moved aside under a
    `.corrupt` name and the fact is reported; the transcripts stay where
    they are and can be re-attached by hand.
    """
    f = _state_file(root, digest)
    if not f.is_file():
        # NOTHING IS ORPHANED BY THE CASE FIX. A state file written before
        # `_repo_digest` stopped folding case on Linux sits under the old
        # key; found here, it is adopted at the new one, so the named
        # conversations and their transcripts survive the upgrade instead
        # of the session silently starting empty beside them.
        legacy = _state_file(root, _repo_digest(repo, legacy=True))
        if legacy.is_file() and legacy != f:
            try:
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_bytes(legacy.read_bytes())
                logger.info("build sessions adopted from the pre-case-fix "
                            "key {} -> {}", legacy.name, f.name)
            except OSError:
                f = legacy                # read it where it lies
    if f.is_file():
        exc: Exception | None = None
        try:
            state = _normalize(json.loads(f.read_text(encoding="utf-8")), repo)
            if state is not None:
                return state
            exc = ValueError("valid JSON, but not a session map")
        except (OSError, json.JSONDecodeError, ValueError,
                TypeError, AttributeError) as err:
            # The last three are what a wrong-SHAPED file raises inside
            # `_normalize`. They used to escape and end the command with a
            # traceback before the first prompt; the file is hand-editable
            # and sitting in the state directory, so that is a reachable
            # startup crash rather than a theoretical one.
            exc = err
        keep = f.with_suffix(".corrupt.json")
        try:
            if keep.exists():
                keep.unlink()
            f.rename(keep)
            logger.warning(
                "build session state at {} was unusable ({}); moved to "
                "{}. Named conversations are reset; their transcripts "
                "are intact in the agent workspace.", f, exc, keep.name)
        except OSError:
            logger.warning("build session state at {} was unusable ({}) "
                           "and could not be set aside", f, exc)
    return _fresh(repo)


def _save_state(root: Path, digest: str, state: dict,
                dropped: "set[str] | None" = None) -> None:
    """Persist the conversation map ATOMICALLY, merging concurrent peers.

    Two properties this file did not have, and needs, because it is the
    only thing that can find a conversation again:

    * **Atomic.** A plain write truncates the file first, so an interrupted
      save leaves invalid JSON - the exact damage that loses every named
      conversation. Write a sibling, fsync, then `os.replace`, which is
      atomic on both platforms.
    * **Merged.** Two `aicore build` sessions in one repository each hold
      the state they loaded, and a plain write makes the later one silently
      delete the other's conversations. Re-read immediately before writing
      and keep any name this process does not know about; ours wins on a
      genuine conflict, since it is the one being edited.

    ``dropped`` names conversations this caller DELIBERATELY removed. The
    merge cannot infer that: a name present on disk and absent from ours
    looks identical whether we just renamed it away or a peer created it
    while we worked, and the merge has to assume the second or it eats a
    peer's session. Without this, `/rename alpha beta` produced BOTH names
    pointing at the same JSONL - a copy, not a rename - so the list grew on
    every rename and `/switch alpha` silently landed in beta's conversation.
    """
    f = _state_file(root, digest)
    f.parent.mkdir(parents=True, exist_ok=True)
    merged = dict(state)
    try:
        if f.is_file():
            disk = json.loads(f.read_text(encoding="utf-8"))
            if isinstance(disk.get("sessions"), dict):
                sessions = dict(disk["sessions"])
                sessions.update(state.get("sessions") or {})
                for name in (dropped or ()):
                    sessions.pop(name, None)
                merged["sessions"] = sessions
    except (OSError, json.JSONDecodeError):
        pass                      # unreadable peer state never blocks a save
    tmp = f.with_suffix(f".{os.getpid()}.tmp")
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(merged, fh, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, f)
    except OSError:
        logger.warning("build session state could not be written to {}", f)
        try:
            tmp.unlink()
        except OSError:
            pass


def _session_key(role: str, digest: str, suffix: str) -> str:
    return f"{_SESSION_PREFIX}:{role}:{digest}:{suffix}"


def _create_session(state: dict, name: str | None) -> str:
    """Create-and-activate. Auto-named ``s2``, ``s3``, ... when no name."""
    sessions = state["sessions"]
    if name:
        base = _slug(name)
    else:
        n = len(sessions) + 1
        while f"s{n}" in sessions:
            n += 1
        base = f"s{n}"
    if base in sessions:
        state["active"] = base            # existing name: switch, not clobber
        return base
    suffix = base
    taken = {s["suffix"] for s in sessions.values()}
    n = 2
    while suffix in taken:
        suffix = f"{base}-{n}"; n += 1
    sessions[base] = {"suffix": suffix, "turns": 0}
    state["active"] = base
    return base


def _rename_session(state: dict, old: str, new: str) -> bool:
    """Display rename only. The SUFFIX never changes: it is what names the
    JSONL on disk, so changing it would orphan the conversation mid-rename."""
    new = _slug(new)
    sessions = state["sessions"]
    if old not in sessions or new in sessions or not new:
        return False
    sessions[new] = sessions.pop(old)
    if state.get("active") == old:
        state["active"] = new
    return True


#: The first turn of a session carries the ground truth the assistant cannot
#: infer: where the repo is, and that the build discipline applies. It is sent
#: ONCE per session generation - the session JSONL keeps it in history for
#: every later turn, which is the whole reason the session is the store.
_PREAMBLE = """\
[build session]
repo: {repo}
workspace: {workspace}
date: {today}

This is an interactive build session in the repository above. Load your
`solution_builder` skill now (read its SKILL.md from your skills summary) and
follow it for every action in this session.{placement}{memory}{solution}{commands}{session_commands}{mcp} Address the
request below.

{message}"""


#: THE SESSION'S OWN COMMANDS ARE FACTS THE MODEL DOES NOT HAVE. `/new`,
#: `/undo`, `/switch` are typed by the USER and handled by the harness; the
#: model never sees them run and was never told they exist - so asked "how
#: do I start a new conversation?" it could not answer `/new`, in a session
#: whose banner had printed the list. Stated once per session, next to the
#: CLI index, with the one rule that matters: the model cannot run them.
_SESSION_COMMANDS_CLAUSE = (
    "\n\nSession commands the USER types at this prompt (you cannot run "
    "them - when asked how to do one of these, name the command):\n{index}")


def session_commands_clause() -> str:
    """The session-command sentence for the preamble, or "" on failure."""
    try:
        from ioagentfarm.builder.repl import session_commands_index
        index = session_commands_index()
    except Exception:                     # noqa: BLE001 - never block a turn
        return ""
    return _SESSION_COMMANDS_CLAUSE.format(index=index) if index else ""


#: THE COMMAND LIST IS A FACT THE HARNESS KNOWS. The builder's charter says
#: "never state a command from memory", and the skill said "`aicore --help`
#: IS the command list" - so every new conversation opened with one to three
#: `--help` calls before the first real action, and a user watching the
#: console saw the tool consult its own manual. Worse, a compacted or
#: renamed session forgot and did it again. The list is derived from the
#: live typer app at the moment the session starts, so it is current for
#: THIS engine (a command added in an upgrade appears; one retired
#: disappears) and costs the model nothing to obtain. FLAGS are deliberately
#: not included: one line per command keeps this under two thousand tokens,
#: and `aicore <cmd> --help` stays the source for a flag - which is the
#: call that still earns its cost, because a flag is where the guesses were.
_COMMANDS_CLAUSE = (
    "\n\nThe CLI's command list, current for this engine (one line each; a "
    "command not listed here does not exist - never use one; flags are "
    "not listed: run `aicore <cmd> --help` once before using a flag you "
    "have not seen this session):\n{index}")


def command_index(limit: int = 96) -> str:
    """One line per CLI command from the live typer app, or "" on failure.

    Walks the click tree `typer` builds - sub-apps (`workspace`, `forensics`,
    `learning`, `drafts`, `cli-hub`) appear as two-word commands. Hidden
    commands (retired spellings kept so the error names the replacement)
    are skipped; a user never sees them in `--help` either.
    """
    import re as _re
    try:
        from typer.main import get_command
        from ioagentfarm.cli import app as _app
        root = get_command(_app)
    except Exception:                     # noqa: BLE001 - never block a turn
        return ""
    lines: list[str] = []

    def walk(cmd, prefix: str) -> None:
        # DUCK-TYPED, not isinstance(click.Group): typer 0.2x's TyperGroup
        # derives from its own `typer._click.core.Command`, and the
        # isinstance form silently produced a one-line index (the root
        # command and nothing under it) - found by the smoke test, not by
        # an error, which is exactly why the index is asserted non-trivial
        # in tests_build.
        children = getattr(cmd, "commands", None)
        if isinstance(children, dict):
            for name in sorted(children):
                child = children[name]
                if getattr(child, "hidden", False):
                    continue
                walk(child, f"{prefix} {name}")
            return
        if getattr(cmd, "hidden", False):
            return
        text = (cmd.help or cmd.short_help or "").strip().splitlines()
        first = text[0].strip() if text else ""
        first = _re.sub(r"\s+", " ", first)
        lines.append(f"{prefix} - {first[:limit]}" if first else prefix)

    try:
        walk(root, "aicore")
    except Exception:                     # noqa: BLE001 - partial is fine
        pass
    return "\n".join(lines)


#: The commands a build session actually runs. Their flags are stated;
#: every other command's are not, because the index is read every session
#: and 96 commands' options would dwarf it.
#:
#: `run` and `run-swarm` are here despite authoring nothing. The corpus
#: caught `aicore run-swarm --dir`, which does not exist - and `--dir` is on
#: nearly every scaffold command above, so stating those and not these
#: invites exactly that generalisation. A partial list is its own hazard:
#: whatever is listed teaches a shape, and the commands next to it inherit
#: the shape without the check.
_FLAGGED = ("new-solution", "new-agent", "new-skill", "new-workflow",
            "new-swarm", "new-tool", "new-mcp-server",
            "lint-agent", "lint-skill", "lint-workflow", "lint-swarm",
            "run", "run-swarm", "list-workflows", "list-swarms")


def command_flags(names=_FLAGGED) -> str:
    """The real options of the authoring commands, from the live app.

    The index gave one line per command and deliberately no flags, and the
    charter closed the gap with a rule - run `--help` before using a flag,
    never state one from memory. It is a request, and it was broken the way
    the charter itself predicts: `aicore new-agent --role` and `aicore
    lint-agent --workspace`, neither of which exists. Both are plausible by
    SYMMETRY - `new-workflow` does take `--role`, `lint-workflow` does take
    `--workspace` - which is precisely the inference a rule cannot stop.

    838 bytes against an 8 KB index, and read from the same click tree the
    CLI dispatches on, so it cannot drift from what the commands accept.
    """
    try:
        from typer.main import get_command
        from ioagentfarm.cli import app as _app
        root = get_command(_app)
        children = getattr(root, "commands", None) or {}
    except Exception:                     # noqa: BLE001 - never block a turn
        return ""
    out: list[str] = []
    for name in names:
        cmd = children.get(name)
        if cmd is None or getattr(cmd, "hidden", False):
            continue
        # HIDDEN PARAMS ARE SKIPPED, not just hidden commands. `new-tool`
        # keeps `--role` and `--no-skill` as hidden options that error
        # naming their replacement (click renders an unknown option as a
        # typo, which reads wrongly for a retirement). Listing a retired
        # option as available is worse than listing nothing: it invites
        # exactly the call the option exists to refuse.
        flags = sorted({o for p in getattr(cmd, "params", [])
                        if not getattr(p, "hidden", False)
                        for o in (getattr(p, "opts", []) or [])
                        if o.startswith("--") and o != "--help"})
        if flags:
            out.append(f"aicore {name}: {' '.join(flags)}")
    return "\n".join(out)


def commands_clause() -> str:
    """The command-index sentence for the preamble, or "" when unavailable."""
    index = command_index()
    if not index:
        return ""
    clause = _COMMANDS_CLAUSE.format(index=index)
    flags = command_flags()
    if flags:
        clause += ("\n\nThe COMPLETE options of the commands that author "
                   "content - these are all of them, so an option not "
                   "listed here does not exist. For any OTHER command, run "
                   "`aicore <cmd> --help` before using a flag.\n\n"
                   f"{flags}\n")
    return clause


def placement_clause(repo, git_ok: bool) -> str:
    """Where commands already run, and whether git is really the undo.

    Two more facts the harness has and never said. `grant_repo_placement`
    points every tool's working directory at the repository, silently: the
    model was told the PATH and not that it was already there, so it prefixed
    commands with `cd <repo>;` defensively - eighteen times in one corpus
    run, every one of them a no-op.

    And `git_ok` decides whether plan mode's restore, `/undo` and `/diff`
    work at all. The charter tells the agent "git is the user's undo" and to
    end every action at `git status`; in a directory that is not a
    repository that advice is wrong, the JSON says `enforced: false` to the
    CALLER, and the model - which is what makes the promise to the user -
    was never told.
    """
    where = (" Your exec commands and file tools already run in the "
             "repository above; there is no need to `cd` into it.")
    if git_ok:
        return where + (" It is a git repository, so `git status --short` "
                        "reports your own changes and git is the user's undo.")
    return where + (" It is NOT a git repository: `git status` will fail, "
                    "plan and review mode cannot restore the tree, and "
                    "`/undo` is unavailable - so do not offer git as the "
                    "undo. Say `git init` gives them one.")


#: TODAY, stated by the harness. The model has no clock and will not say so:
#: asked to date its own entries in CORABUILD.md it wrote 2025-01-26,
#: 2025-01-27 and 2025-01-28 into a file read in full at the start of every
#: session - nineteen months adrift, in the one place a wrong fact is read
#: again by every session that follows. A date is not something to infer
#: from a training prior, and the harness has always known it.
def today_line() -> str:
    from datetime import date
    return date.today().isoformat()


#: Dating is named HERE rather than left to the agent: the entries it writes
#: outlive the session, and an entry stamped with a hallucinated date is
#: worse than an undated one - it reads as evidence.
_MEMORY_DATED = (" Date any entry you add there with the session date above, "
                 "never from memory.")

#: What to say about the standing-instructions file. The harness KNOWS
#: whether it exists, so it states the fact rather than posing a condition
#: the agent can only resolve by trying: "if the repository contains a
#: CORABUILD.md" cost every session in every repo without one a wasted call
#: AND showed the user a red error as the first thing on screen. Found by
#: running a fresh session in an empty repository and reading what the user
#: sees.
_MEMORY_KEEP = (" It is yours to maintain: when a note there is superseded, "
                "contradicted or has grown vague, rewrite that entry rather "
                "than adding a second one beside it, and keep the file short "
                "enough to be read in full at every session start."
                + _MEMORY_DATED)

#: INLINED, not asked for. The harness already opens this file to decide
#: which sentence to emit, so it held the content and stated only that it
#: existed - the same shape as the date. Asking cost a tool-call round trip
#: per session to deliver about a kilobyte, and it is a REQUEST: measured
#: across 33 sessions the agent complied in 32, and the miss was a session
#: told to "read docs/vendor_spec.md and create a skill for rey" while three
#: unread decisions in that very file recorded which skills rey already
#: carried and why. When the user names a file to read, the model can
#: substitute it for its orientation.
_MEMORY_PRESENT = (" This repository has a CORABUILD.md. Its contents are "
                   "below - they are the standing conventions here and they "
                   "outrank your own defaults; you do not need to read the "
                   "file again." + _MEMORY_KEEP)

#: The fallback when the file has grown past what belongs in every preamble.
#: Injecting an unbounded file would make every session pay for someone's
#: 50 KB of notes, so past the cap it goes back to being read on demand -
#: and the agent is told WHY, because "read it" after an inlined-by-default
#: contract would otherwise look like the file was missing.
_MEMORY_PRESENT_LARGE = (
    " This repository has a CORABUILD.md, and it is too large to inline "
    "({size} bytes) - read it before your first action. It carries the "
    "standing conventions here, and they outrank your own defaults."
    + _MEMORY_KEEP)
_MEMORY_ABSENT = (" This repository has no CORABUILD.md; do not look for one. "
                  "Create it only when the user states something that must "
                  "outlive this session - a convention, a decision and its "
                  "constraint, or something not to do again."
                  + _MEMORY_DATED)


#: What to say about the SOLUTION. Same principle as the BUILD.md clause,
#: and found the same way - by running a session in a directory that had no
#: solution. Every scaffold command refuses there ("no solution repo at ...
#: looked for aicore.solution.yaml and pyproject.toml"), and the agent, told
#: to create a skill and refused by the CLI, went looking for any directory
#: with a `skills/` in it and wrote into its OWN agent workspace under the
#: state directory. Content nobody ships, in a place nobody looks.
#:
#: So the harness states which case this is, and what to do about it.
#: Worded with care, twice over. First: to the USER there is exactly ONE
#: workspace - the one selected before this session could start (the
#: `workspace:` line in this preamble). The folder setup is an internal
#: detail of that same workspace, so it is never a question and the word
#: "workspace" is never used as if a second one were being created; an
#: earlier wording that proposed "a family code" read to a real user as a
#: second workspace and confused them. Second: the only name ever ASKED
#: for is a SOLUTION's, when workflows enter the picture - the same shape
#: as the documented walkthrough, where `workspace create <code>` happens
#: once and `new-solution <name>` is just "the solution".
_SOLUTION_ABSENT = (
    " THIS DIRECTORY IS NOT SET UP YET, so every scaffold command will"
    " refuse until it is. Do NOT ask the user anything about this - the"
    " workspace is the one in the `workspace:` line above, and there is"
    " only ever that one. As the FIRST action of the turn, say one plain"
    " line - 'Setting this folder up for workspace <code>.' - and run"
    " `aicore workspace scaffold <code>` with that exact code, in the repository"
    " root above. That puts `agents/`, `skills/` and `tools/` directly at"
    " this directory. A solution (the container for workflows) is separate:"
    " when the request needs one and none exists, ask the user what to call"
    " THE SOLUTION - a short lowercase name - and add it with"
    " `aicore new-solution <name>` run inside this repository, under"
    " `solutions/`. Agents, skills and tools need no solution. Never say"
    " 'family code' to the user, never invent a different workspace name,"
    " and never place content outside what the scaffolds make.")


#: Never searched for a solution marker. `.iof` is the one that bites: a
#: synced workspace tree under it can carry a solution manifest, and the
#: first version of this walk found it and told the agent "the solution is
#: at `.iof/workspaces/...`" - directing content INTO the state directory,
#: which is the exact reported failure this clause exists to prevent.
_SOLUTION_SKIP = {".iof", ".git", ".venv", "node_modules", "__pycache__",
                  "build", "dist"}


def solution_clause(repo) -> str:
    """The solution sentence for THIS repository, decided by the harness.

    A bounded, pruned walk rather than ``rglob``: rglob descends into
    ``.venv`` and ``node_modules`` (seconds of first-turn latency in a big
    checkout, for nothing) and into ``.iof`` (see :data:`_SOLUTION_SKIP`).
    Shallowest match wins - the repo's own solution, not one vendored
    somewhere below it.
    """
    import os as _os
    from pathlib import Path as _P
    markers = ("aicore.solution.yaml", "agentfarm.solution.yaml")
    try:
        root = _P(repo)
        hits = []
        for cur, dirs, files in _os.walk(root):
            dirs[:] = [d for d in dirs if d not in _SOLUTION_SKIP]
            if any(m in files for m in markers):
                hits.append(_P(cur))
            # a solution is near the top; three levels is already generous
            if _P(cur).relative_to(root).parts[3:]:
                dirs[:] = []
        if hits:
            best = min(hits, key=lambda p: len(p.relative_to(root).parts))
            rel = best.relative_to(root)
            where = f"`{rel.as_posix()}`" if str(rel) != "." else "the root"
            return (f" The solution in this repository is at {where};"
                    " place all content inside it.")
        return _SOLUTION_ABSENT
    except Exception:                     # noqa: BLE001 - never block a turn
        return ""


#: What the preamble says about an MCP server that will not answer. The MODEL
#: needs this, not just the user: asked why a tool was missing, an agent with
#: no signal INVENTED a reason - it reported a variable as unset when it was
#: set, and sent the user to run `aicore login`, which had nothing to do with
#: anything. An agent told the truth reports the truth.
_MCP_DOWN_CLAUSE = (
    "\n\nMCP servers that did NOT connect for this session, and are "
    "therefore unavailable to you no matter what a declaration says:\n{lines}"
    "\nDo not guess at why a tool is missing and do not claim a variable is "
    "unset unless you have checked it in THIS process - `aicore mcp-list` run "
    "through exec cannot see the session's environment. Report the reason "
    "above verbatim if asked.")


def mcp_health(timeout: float = 5.0) -> list[dict]:
    """Which declared MCP servers will not answer, checked HERE, once.

    The runtime's own failure lands in a subprocess's stderr log, which no
    console shows. This runs in the PARENT, before the first turn, so the
    person watching finds out at the moment it matters and the model is told
    rather than left to invent. Remote servers only - a stdio server is
    launched by the runtime and there is nothing to contact.
    """
    try:
        from ioagentfarm.engine.mcp_probe import (OK, SKIPPED, advice, probe,
                                                  probe_entries)
        # `probe_entries`, NOT `merged_mcp_servers`: the latter strips the
        # `auth:` block (it is ours, not iobot's), so this probed an OAuth
        # server anonymously, got a 401, and warned the user AND the model
        # about a server the runtime was connected to. A false negative that
        # the model then acted on is worse than no check at all.
        servers = probe_entries() or {}
    except Exception:                      # noqa: BLE001 - never block a session
        return []
    bad: list[dict] = []
    for name in sorted(servers):
        spec = servers[name] or {}
        if not spec.get("url"):
            continue
        try:
            result = probe(spec, timeout=timeout)
        except Exception:                  # noqa: BLE001
            continue
        if result["status"] in (OK, SKIPPED):
            continue
        bad.append({"name": name, "url": spec.get("url", ""),
                    "status": result["status"], "detail": result["detail"],
                    "advice": advice(result)})
    return bad


def mcp_clause(bad: list[dict]) -> str:
    """The preamble sentence for *bad*, or "" when everything answered."""
    if not bad:
        return ""
    lines = "\n".join(
        f"- {b['name']} ({b['url']}): {b['status']} - {b['detail']}"
        + (f" -> {b['advice']}" if b.get("advice") else "")
        for b in bad)
    return _MCP_DOWN_CLAUSE.format(lines=lines)


#: How much CORABUILD.md the preamble will carry. Generous against what the
#: file is FOR - the charter tells the agent to keep it readable in full at
#: every session start, and the largest seen in practice was 1.6 KB - while
#: still bounding what one repository's notes can cost every session.
MEMORY_INLINE_MAX = 8000


def memory_clause(repo) -> str:
    """The CORABUILD.md clause for THIS repository, decided by the harness.

    The file's CONTENT is inlined, not requested. The harness opens it here
    anyway to decide whether it exists; stating only that it exists left the
    standing conventions to a tool call the model made 32 times out of 33.
    """
    from ioagentfarm.builder.refs import memory_path
    try:
        path = memory_path(repo)
        if not path.is_file():
            return _MEMORY_ABSENT
        body = path.read_text(encoding="utf-8", errors="replace").strip()
        size = path.stat().st_size
        if not body or size > MEMORY_INLINE_MAX:
            return _MEMORY_PRESENT_LARGE.format(size=size)
        return (f"{_MEMORY_PRESENT}\n\n"
                f"--- CORABUILD.md ---\n{body}\n--- end CORABUILD.md ---\n")
    except Exception:                     # noqa: BLE001 - never block a turn
        return ""


#: What the user sees in a build session is the assistant's FINAL words and
#: nothing else - the Claude Code convention. Filtering the live stream by
#: pattern was tried and LOST: the runtime's live redraw emits thinking as
#: bare fragments with no reliable marker ("Let me ask the user", "But"), so
#: any prefix filter leaks. The structural answer: suppress the stream
#: entirely and read the reply from the session JSONL after the turn - the
#: authoritative record, and the same file that makes the session
#: persistent. The forensics tee and on_output still carry every line.
def _session_file(role: str, session_key: str, uid: str) -> Path | None:
    """The JSONL the runtime writes for this session.

    The runtime appends ``:u:<user_id>`` to the key (multi-user isolation)
    and names the file with the urlsafe base64 of the full key, unpadded.
    Derived, not searched: a mtime search would race the warmup sessions
    beside it.
    """
    import base64

    from ioagentfarm.engine.workspaces import iobot_agent_workspace

    try:
        full = f"{session_key}:u:{uid}" if uid else session_key
        name = base64.urlsafe_b64encode(full.encode("utf-8")) \
            .rstrip(b"=").decode("ascii")
        return Path(iobot_agent_workspace(role)) / "sessions" / \
            f"{name}.jsonl"
    except Exception:                     # noqa: BLE001
        logger.debug("session file unresolvable for {!r}", session_key,
                     exc_info=True)
        return None


def _final_reply(session_path: Path | None) -> str | None:
    """The LAST assistant message's text, from the session record."""
    if session_path is None or not session_path.is_file():
        return None
    reply = None
    try:
        for line in session_path.read_text(encoding="utf-8").splitlines():
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            if d.get("role") != "assistant":
                continue
            c = d.get("content")
            if isinstance(c, list):
                c = "\n".join(str(b.get("text", "")) for b in c
                              if isinstance(b, dict) and b.get("text"))
            if isinstance(c, str) and c.strip():
                reply = c.strip()
    except OSError:
        return None
    return reply
