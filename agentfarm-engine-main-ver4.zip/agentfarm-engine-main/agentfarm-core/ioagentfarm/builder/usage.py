"""builder.usage — the context and cost meter.

The one element the console comparison still scored MISSING against Claude
Code. A build session that cannot say how full its context is leaves the
user guessing when to `/compact`, and a session that cannot say what a turn
cost leaves them guessing what the work is worth.

The numbers are not estimated. The runtime already appends one JSONL record
per model call to ``IOF_USAGE_FILE`` (the usage-capture patch); this module
points that at a per-session file and reads it back. Nothing here counts
tokens itself — an estimated meter is worse than none, because it is
believed.

Deliberately NOT per-call log lines: raw usage lines from the runtime's own
logger are what buried the quiet console when the in-process engine landed,
and they were removed. This is one compact line at the end of a turn, plus a
context figure that rides the spinner already on screen.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

#: Fallback when the runtime declares no window. MiniMax-M2.x's real window;
#: only used to compute a PERCENTAGE, never to cap anything.
_DEFAULT_WINDOW = 204_800


def _safe_name(session_key: str) -> str:
    """A filename from a session key. Hashed rather than sanitized: the key
    carries a repo digest and a user id, and neither belongs in a path that
    a support bundle might collect."""
    import hashlib
    return hashlib.sha1(session_key.encode("utf-8")).hexdigest()[:16]


def usage_path(root: Path, session_key: str) -> Path:
    """Where this session's usage records accumulate."""
    return Path(root) / "build-usage" / f"{_safe_name(session_key)}.jsonl"


def arm(root: Path, session_key: str) -> Path:
    """Point the runtime's usage capture at this session's file.

    Safe to call every turn: the capture hook is a no-op whenever the
    variable is unset, so arming it is the only thing that turns the meter
    on, and nothing else in the process is affected.
    """
    p = usage_path(root, session_key)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        os.environ["IOF_USAGE_FILE"] = str(p)
    except Exception:                     # noqa: BLE001 - a meter must
        pass                              # never break a turn
    return p


#: (config path, mtime_ns) -> window, so the ticker's once-a-second reads
#: do not re-parse a config that has not changed.
_WINDOW_MEMO: dict = {}


def context_window() -> int:
    """The model's context window, resolved the way the RUNTIME resolves it.

    The first version read only `agents.defaults.contextWindowTokens` -
    but the runtime resolves the window through the model PRESET
    (`resolve_preset()`), so a deployment on a preset-declared model was
    metered against the wrong number: a 32k model read as 200k, the meter
    sat at 15% while the runtime silently dropped history from the front,
    and auto-compaction never fired. Validate the CONSUMER: ask the
    runtime's own config object.
    """
    cfg = Path.home() / os.environ.get("IOF_STATE_DIR_NAME", ".iobot") \
        / "config.json"
    try:
        key = (str(cfg), cfg.stat().st_mtime_ns)
    except OSError:
        key = (str(cfg), 0)
    if key in _WINDOW_MEMO:
        return _WINDOW_MEMO[key]
    window = 0
    try:
        from iobot.config.loader import load_config
        preset = load_config(None).resolve_preset()
        window = int(getattr(preset, "context_window_tokens", 0) or 0)
    except Exception:                     # noqa: BLE001 - fall through
        pass
    if not window:
        try:
            data = json.loads(cfg.read_text(encoding="utf-8"))
            for k in ("contextWindowTokens", "context_window_tokens"):
                for scope in (data.get("agents", {}).get("defaults", {}),
                              data):
                    if isinstance(scope, dict) and scope.get(k):
                        window = int(scope[k])
                        break
                if window:
                    break
        except Exception:                 # noqa: BLE001
            pass
    window = window or _DEFAULT_WINDOW
    _WINDOW_MEMO.clear()
    _WINDOW_MEMO[key] = window
    return window


#: path -> (size, mtime_ns, parsed records). The spinner reads the usage
#: file once a second and `_context_pct` once a turn; both re-read and
#: re-parsed EVERY record ever written, so a long session paid O(n) per
#: tick. The file is append-only, so size+mtime identity is exact.
_RECORDS_MEMO: dict = {}


def _records(path: Path, since: int = 0) -> list[dict]:
    try:
        st = path.stat()
        key = (st.st_size, st.st_mtime_ns)
    except OSError:
        return []
    cached = _RECORDS_MEMO.get(str(path))
    if cached and cached[0] == key:
        return cached[1][since:]
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except Exception:                     # noqa: BLE001 - no file yet
        return []
    out = []
    for line in lines:
        try:
            out.append(json.loads(line))
        except Exception:                 # noqa: BLE001 - partial write
            continue
    _RECORDS_MEMO.clear()
    _RECORDS_MEMO[str(path)] = (key, out)
    return out[since:]


def line_count(path: Path) -> int:
    """Records already present — the mark a turn measures its delta from."""
    try:
        return len(path.read_text(encoding="utf-8").splitlines())
    except Exception:                     # noqa: BLE001
        return 0


def read(path: Path, since: int = 0) -> dict | None:
    """Aggregate the records a turn produced.

    ``context`` is the LAST call's input, not the sum: every call resends
    the conversation, so summing inputs would report a number many times
    larger than anything that was ever in the window — the classic way a
    token meter becomes a lie.
    """
    recs = _records(path, since)
    if not recs:
        return None
    total_in = sum(int(r.get("in") or 0) for r in recs)
    total_out = sum(int(r.get("out") or 0) for r in recs)
    cache_read = sum(int(r.get("cr") or 0) for r in recs)
    window = context_window()
    context = int(recs[-1].get("in") or 0)
    return {
        "calls": len(recs),
        "in": total_in,
        "out": total_out,
        "cache_read": cache_read,
        "cached_pct": round(100.0 * cache_read / total_in, 1) if total_in
        else 0.0,
        "context": context,
        "window": window,
        "context_pct": round(100.0 * context / window, 1) if window else 0.0,
    }


def _compact(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}k"
    return str(n)


def footer(stats: dict, G: dict) -> str:
    """The one line a turn prints. Context first — it is the number that
    changes what the user does next."""
    ctx = (f"{_compact(stats['context'])}/{_compact(stats['window'])} "
           f"context ({stats['context_pct']:.0f}%)")
    cost = (f"{_compact(stats['in'])} in {G['sep']} "
            f"{_compact(stats['out'])} out")
    cached = (f" {G['sep']} {stats['cached_pct']:.0f}% cached"
              if stats["cache_read"] else "")
    calls = f" {G['sep']} {stats['calls']} call" + \
            ("s" if stats["calls"] != 1 else "")
    return f"{ctx}  {G['sep']}  {cost}{cached}{calls}"


def spinner_suffix(path: Path, since: int) -> str:
    """A context figure for the status line, or nothing.

    Read live while the turn runs, so a long turn shows the window filling
    rather than only reporting it afterwards. Silent until the first call
    returns — a meter reading zero is worse than no meter.
    """
    stats = read(path, since)
    if not stats or not stats["context"]:
        return ""
    return f"  {_compact(stats['context'])} ctx ({stats['context_pct']:.0f}%)"
