"""Console glyphs and a console that cannot be crashed by encoding.

Split out of cli_build so every module can draw from one glyph set.
"""
from __future__ import annotations

import sys



#: The console's decorative characters, and the ASCII set to fall back to.
#: Rich RAISES UnicodeEncodeError rather than substituting, so one bullet on
#: a legacy Windows code page - which is what you get the moment output is
#: redirected to a file or piped - kills the REPL mid-turn, in the renderer,
#: with the model's work already paid for. This repository learned the same
#: lesson once when the runtime's emoji logo crashed a non-UTF-8 console.
_GLYPHS_RICH = {"prose": "·", "tool": "●", "fail": "✗",
                "ell": "…", "arrow": "→", "sep": "·",
                "on": "●", "off": "○",
                "res": "⎿", "check": "✓"}
_GLYPHS_ASCII = {"prose": "-", "tool": "*", "fail": "x",
                 "ell": "...", "arrow": "->", "sep": "-",
                 "on": "*", "off": "o",
                 "res": ">", "check": "*"}


def _glyphs(console) -> dict:
    """Pick the richest glyph set this console can actually encode."""
    enc = getattr(getattr(console, "file", None), "encoding", None)
    if not enc:
        return _GLYPHS_ASCII
    try:
        "".join(_GLYPHS_RICH.values()).encode(enc)
    except (UnicodeEncodeError, LookupError):
        return _GLYPHS_ASCII
    return _GLYPHS_RICH


#: Rich's DEFAULT theme is tuned for a light terminal, and three of its
#: magenta tokens are the ones this console prints most: `repr.path` /
#: `repr.filename` (every tool argument and write target is a path) and
#: the markdown heading levels (a reply is rendered as Markdown, so every
#: heading the model writes came out magenta). On a black background that
#: reads as barely-legible purple. These are re-pointed at the palette the
#: build console already uses - cyan for structure, weight for hierarchy -
#: rather than the highlighter being switched off, which would also lose
#: the number and string coloring that makes a result line scannable.
#: The harness's own label, escaped for Rich.
#:
#: `console.print("[build] reverted 3 files")` renders as `" reverted 3
#: files"`. Rich reads `[build]` as a STYLE TAG, finds no such style, and
#: drops it silently - no error, no warning, just the label gone and a
#: stray leading space where it was. Twenty-three lines were written with
#: this prefix and not one of them ever showed it, while the four written
#: with a plain `print()` did - so the same voice appeared on some lines
#: and not others, which is what made it invisible for so long.
#:
#: The same swallow ate the `[truncated]` marker on an oversized `@file`
#: reference, which the client documentation promises by name. Any literal
#: square-bracketed word going through `console.print` needs this
#: treatment; :func:`bracket` is the general form.
TAG = "\\[build]"


def bracket(word: str) -> str:
    """A literal `[word]` that survives Rich's markup parser."""
    return "\\[" + word + "]"


_THEME_OVERRIDES = {
    "repr.path": "cyan",
    "repr.filename": "bold cyan",
    "repr.call": "bold cyan",
    "repr.attrib_value": "cyan",
    "repr.none": "italic dim",
    "iso8601.time": "cyan",
    "prompt.choices": "bold cyan",
    "markdown.h2": "bold cyan",
    "markdown.h3": "bold",
    "markdown.h4": "bold dim",
    "markdown.block_quote": "dim",
}


def _console():
    """A console that cannot be crashed by a character it cannot encode.

    The glyph set above only covers OUR characters, which is the smaller
    half of the problem. Most of what this console prints is not ours: the
    model's own prose (em dashes, curly quotes, arrows - routinely), the
    diff preview of a file the agent just wrote, git output, a path. Any
    one of those raises on a legacy code page, in the renderer, after the
    turn is paid for.

    So the stream is made non-strict as well. The two work together and
    neither replaces the other: this guarantees the console never dies,
    the glyph set is what makes the degraded output legible - ``->``
    rather than the substitution character.

    It also carries :data:`_THEME_OVERRIDES`, so the console is legible on
    a dark terminal rather than only on the light one Rich assumes.
    """
    from rich.console import Console
    from rich.theme import Theme

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError, OSError):
            pass                          # already wrapped, or not a TextIO
    try:
        return Console(theme=Theme(_THEME_OVERRIDES))
    except Exception:                     # noqa: BLE001 - a theme is a nicety
        return Console()


#: The console a turn is currently drawing on, so a log record rendered
#: from ANOTHER thread goes through the same Console object that owns the
#: spinner. Rich clears and redraws its live region around its own prints;
#: a second Console writing to the same stream does not know the region is
#: there and tears it. Registered for the duration of a turn only.
_ACTIVE = None


def set_active_console(console) -> None:
    """Register (or clear, with ``None``) the console a turn is drawing on."""
    global _ACTIVE
    _ACTIVE = console


def active_console():
    """The turn's console if one is drawing, otherwise a fresh one."""
    return _ACTIVE if _ACTIVE is not None else _console()


def turn_active() -> bool:
    """Is a turn drawing right now? The input hub asks, to decide whether
    an unprompted line deserves the "queued - sends when this turn
    finishes" acknowledgement."""
    return _ACTIVE is not None


#: The turn's LIVE REGION (the spinner), so a prompt raised from inside a
#: turn can take it down before asking. Measured on a client box: the
#: install gate printed `install? ... [y]es [n]o >` through the REPL's
#: Console while the turn's spinner - a DIFFERENT Console object, created
#: per turn - repainted its status line over it once a second. The user
#: never saw a prompt to answer; `console.input()` sat blocking the event
#: loop for 50 minutes while the ticker's elapsed counter climbed, and the
#: screen read "running tools 50m35s... exec: pip install -e ." - pip never
#: started. Registered for the duration of a turn only.
_LIVE = None
_SUSPENDED = 0


def set_active_live(live) -> None:
    """Register (or clear, with ``None``) the turn's live status.

    Registering also RESETS the suspend counter: a turn owns the screen
    from its first line, and a count carried over from a previous turn
    could only be a leak - there is no prompt open across turns.
    """
    global _LIVE, _SUSPENDED
    _LIVE = live
    if live is not None:
        _SUSPENDED = 0


def live_suspended() -> bool:
    """True while a prompt owns the screen - the ticker must not repaint."""
    return _SUSPENDED > 0


class suspended_live:
    """Stop the turn's live region for the duration of a prompt.

    A context manager: on entry the spinner is stopped and its line
    cleared, so the prompt prints on a quiet screen; on exit it is started
    again. Safe with no live region registered (a non-terminal, or a call
    outside a turn) - then it does nothing. Reentrant, and every step
    swallows: a prompt must never fail because the decoration around it
    did.
    """

    def __enter__(self):
        global _SUSPENDED
        _SUSPENDED += 1
        # BaseException, and the counter is unwound before it leaves. A
        # Ctrl+C landing inside `stop()` used to escape AFTER the
        # increment, so `__exit__` never ran and `live_suspended()` stayed
        # True for the rest of the session: the ticker skipped every
        # repaint from then on and every later turn looked frozen.
        if _SUSPENDED == 1 and _LIVE is not None:
            try:
                _LIVE.stop()
            except BaseException:          # noqa: BLE001 - decoration only
                _SUSPENDED -= 1
                raise
        return self

    def __exit__(self, *exc):
        global _SUSPENDED
        _SUSPENDED = max(0, _SUSPENDED - 1)
        if _SUSPENDED == 0 and _LIVE is not None:
            try:
                _LIVE.start()
            except Exception:              # noqa: BLE001
                pass
        return False


def _short_path(path) -> str:
    """The shortest form of *path* that still finds the file from here.

    An absolute state-directory path wrapped onto a second line, which is
    a poor way to end a fix whose point is that an error is ONE line.
    """
    import os

    text = str(path)
    try:
        rel = os.path.relpath(text)
        if len(rel) < len(text) and not rel.startswith(".." + os.sep):
            return rel
    except (ValueError, OSError):         # different drive, or no cwd
        pass
    return text


class CompactLogHandler:
    """Render a log record as ONE red line - never a traceback.

    The runtime's providers report an upstream failure with
    ``logger.error(..., exc_info=True)`` on a STDLIB logger. With no stdlib
    handler configured anywhere, Python falls back to
    ``logging.lastResort``, which prints the bare message AND expands
    `exc_info` - so a single connection error put a forty-line traceback
    from inside the openai and httpx packages into the middle of a build
    conversation. The traceback is worth keeping; the console is not where
    it belongs. It goes to the log file, and the user gets the one line
    that tells them what happened.

    Deliberately not a subclass at class-creation time: `logging` is
    imported inside :meth:`install` so this module stays cheap to import.
    """

    #: Printed once per process, under the first error - after that the
    #: pointer is noise, and the point of the line is to stay one line.
    _hinted = False

    @staticmethod
    def _line(record) -> str:
        """The one line: the message, flattened and bounded.

        A diagnostic format string carries fields that are worth having in
        the log and are only noise on screen when they came back empty -
        the providers report `type=… status=… msg=… body=`, and a
        connection error has neither a status nor a body. Empty fields are
        dropped; nothing that has a value is ever hidden.
        """
        import re

        try:
            msg = record.getMessage()
        except Exception:                 # noqa: BLE001 - a bad format string
            msg = str(getattr(record, "msg", ""))
        msg = " ".join(str(msg).split())
        msg = re.sub(r"\s*\b\w+=(?:None)?(?=\s|$)", "", msg).strip()
        exc = getattr(record, "exc_info", None)
        if exc and exc[0] is not None:
            name = getattr(exc[0], "__name__", "")
            if name and name not in msg:
                msg = f"{msg} ({name})" if msg else name
        return msg[:240] + ("…" if len(msg) > 240 else "")

    @classmethod
    def render(cls, record, log_path=None) -> None:
        """Print the compact line. Never raises - this is an error path."""
        try:
            console = active_console()
            G = _glyphs(console)
            console.print(f"[red]{G['fail']} {cls._line(record)}[/]")
            if not cls._hinted and log_path:
                cls._hinted = True
                console.print(f"[dim]details in {_short_path(log_path)}[/]")
        except Exception:                 # noqa: BLE001 - never break a turn
            pass
