"""One reader owns stdin; everyone else asks the hub.

THE PROBLEM THIS ENDS (backlog H16). The build session read the keyboard
with blocking ``console.input()`` calls - the REPL prompt on the main
thread, and the y/n gates ON THE EVENT-LOOP THREAD from inside a tool
coroutine. While a gate waited: exec-session pipe readers starved (a
running ``yield_time_ms`` child deadlocked on a full pipe and was later
reported timed-out), MCP receive loops starved, and every wall-clock
deadline set before the prompt expired against a loop that never ran.
Meanwhile anything TYPED during a turn sat in the OS console buffer,
echoed over the spinner, and was consumed by the next prompt as if the
user had just typed it - unacknowledged, sometimes interleaved.

The obvious fix - a thread per prompt - was prototyped and rejected: a
prompt abandoned by Ctrl+C leaves its reader blocked on stdin, and that
orphan STEALS the next line the user types at the REPL.

So there is exactly ONE reader thread, started for the whole interactive
session, and it never blocks anyone: it moves lines from stdin onto a
queue. Consumers take from the queue, never from stdin:

- the REPL prompt takes the next line (polling, so Ctrl+C still lands);
- a mid-turn gate REGISTERS a prompt and waits on it from a worker
  thread (``asyncio.to_thread`` in the engine), so the event loop keeps
  running while the question is open;
- a line typed while a turn runs and NO prompt is open is a QUEUED
  MESSAGE: acknowledged with one dim line, delivered at the turn
  boundary - the Claude Code behaviour;
- Ctrl+C cancels the PROMPT via a token; the race where a worker pops a
  line in the same instant is closed by re-queueing the line as a
  message instead of feeding it to a dead prompt.

Degradation is structural: the hub starts only on a real terminal and
can be disabled outright (``IOF_BUILD_INPUT_HUB=0``); every entry point
falls back to plain ``console.input`` when the hub is not running, which
is exactly the pre-hub behaviour.
"""
from __future__ import annotations

import os
import queue
import sys
import threading
import time

from loguru import logger

#: What the reader puts on the queue when stdin closes.
_EOF = object()

#: Poll step for blocking waits. Small enough that a queued line feels
#: instant and Ctrl+C lands promptly; large enough to cost nothing.
_POLL_S = 0.1


class _Prompt:
    """One open question. Exactly zero or one exists at a time."""

    def __init__(self) -> None:
        self.answered = threading.Event()
        self.cancelled = threading.Event()
        self.answer: str | None = None      # None = cancelled or EOF
        self.eof = False


class InputHub:
    def __init__(self, readline=None):
        #: injectable for tests; the default reads the process's stdin
        self._default_reader = readline is None
        self._readline = readline or (lambda: sys.stdin.readline())
        self._messages: "queue.Queue" = queue.Queue()
        self._prompt: _Prompt | None = None
        self._prompt_lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._running = False
        self._eof = False
        #: set by the turn (via console.set_active_console) - read to decide
        #: whether an unprompted line deserves the "queued" acknowledgement
        self._ack_console = None

    # ── lifecycle ────────────────────────────────────────────────────────
    def start(self) -> bool:
        """Start the reader. False (and no thread) when the hub must not
        run: not a terminal, disabled, or already running."""
        if self._running:
            return True
        if (os.environ.get("IOF_BUILD_INPUT_HUB", "").strip() == "0"):
            return False
        try:
            if self._default_reader and not sys.stdin.isatty():
                return False               # a piped stdin gets no reader
        except Exception:                  # noqa: BLE001 - odd stdin = no hub
            return False
        self._running = True
        self._thread = threading.Thread(
            target=self._read_forever, name="build-input-hub", daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        """Mark stopped. The reader is a daemon blocked in stdin; it is not
        joinable and does not need to be - consumers stop asking."""
        self._running = False
        self.cancel_prompt()

    def running(self) -> bool:
        return self._running

    # ── the one reader ───────────────────────────────────────────────────
    def _read_forever(self) -> None:
        while self._running:
            try:
                line = self._readline()
            except (EOFError, KeyboardInterrupt):
                # Ctrl+C aborts a console read on some Windows builds; the
                # MAIN thread gets the real KeyboardInterrupt. Not our exit.
                continue
            except OSError:
                # an aborted ReadConsole (Ctrl+C on other builds); retry
                time.sleep(0.05)
                continue
            except Exception:              # noqa: BLE001 - never die silent
                logger.debug("input hub reader error", exc_info=True)
                time.sleep(0.2)
                continue
            if line == "":
                self._deliver_eof()
                return
            self._deliver(line.rstrip("\r\n"))

    def _deliver(self, line: str) -> None:
        with self._prompt_lock:
            p = self._prompt
            if p is not None and not p.cancelled.is_set():
                self._prompt = None
                p.answer = line
                p.answered.set()
                return
        self._messages.put(line)
        self._ack(line)

    def _deliver_eof(self) -> None:
        self._eof = True
        with self._prompt_lock:
            p, self._prompt = self._prompt, None
        if p is not None:
            p.eof = True
            p.answered.set()
        self._messages.put(_EOF)

    def _ack(self, line: str) -> None:
        """One dim line saying the message was HEARD, printed above the
        spinner - only while a turn is drawing (otherwise the REPL loop is
        about to consume it anyway)."""
        try:
            from ioagentfarm.builder import console as C
            if not C.turn_active():
                return
            C.active_console().print(
                f"[dim]queued: {line[:70]!r} - sends when this turn "
                "finishes (Ctrl+C interrupts instead)[/]")
        except Exception:                  # noqa: BLE001 - an ack is a nicety
            pass

    # ── consumers ────────────────────────────────────────────────────────
    def readline(self) -> str:
        """The next line, for the REPL prompt. Blocking, but POLLING, so a
        Ctrl+C in the main thread is raised between steps rather than
        swallowed by a bare queue wait. Raises EOFError at end of stdin."""
        while True:
            try:
                item = self._messages.get(timeout=_POLL_S)
            except queue.Empty:
                if self._eof:
                    raise EOFError
                continue
            if item is _EOF:
                self._eof = True
                raise EOFError
            return item

    def drain_messages(self) -> list[str]:
        """Every line typed while nobody was asking - the turn-boundary
        delivery. Never blocks."""
        out: list[str] = []
        while True:
            try:
                item = self._messages.get_nowait()
            except queue.Empty:
                return out
            if item is _EOF:
                self._eof = True
                self._messages.put(_EOF)   # keep the sentinel for readline
                return out
            out.append(item)

    def ask(self) -> str:
        """One answer for an open gate prompt. Called from a WORKER thread
        (``asyncio.to_thread``), so the event loop keeps running while the
        user decides. Raises EOFError on closed stdin; returns "" when the
        prompt was cancelled (Ctrl+C ended the turn) - the caller's answer
        parsing reads "" as a decline, and the turn is already dying."""
        p = _Prompt()
        with self._prompt_lock:
            if self._prompt is not None:
                # a second concurrent prompt cannot happen (tool calls are
                # sequential); if it ever does, fail safe as a decline
                logger.debug("input hub: a second prompt while one is open")
                return ""
            self._prompt = p
        while not p.answered.wait(_POLL_S):
            if p.cancelled.is_set():
                with self._prompt_lock:
                    if self._prompt is p:
                        self._prompt = None
                return ""
        if p.eof:
            raise EOFError
        if p.cancelled.is_set():
            # the race: answered and cancelled in the same instant. The
            # user's line must not vanish into a dead prompt - it becomes
            # the next message instead.
            if p.answer is not None:
                self._messages.put(p.answer)
                self._ack(p.answer)
            return ""
        return p.answer or ""

    def pending(self) -> bool:
        """Is a queued message waiting? (the REPL asks, to announce that
        the next prompt will answer itself from the mid-turn backlog)."""
        return not self._messages.empty()

    def cancel_prompt(self) -> None:
        """End the open prompt, if any - the Ctrl+C path. The waiting
        worker returns "" without consuming anything; a line that arrives
        later goes to the message queue like any other."""
        with self._prompt_lock:
            p = self._prompt
        if p is not None:
            p.cancelled.set()

    def prompt_open(self) -> bool:
        with self._prompt_lock:
            return self._prompt is not None


#: The session's hub. One per process, like the stdin it owns.
_HUB = InputHub()


def hub() -> InputHub:
    return _HUB


def start() -> bool:
    return _HUB.start()


def stop() -> None:
    _HUB.stop()


def running() -> bool:
    return _HUB.running()


def cancel_prompt() -> None:
    _HUB.cancel_prompt()


def prompt_input(console, markup: str) -> str:
    """Render *markup* as a prompt and read one line.

    THE one way session code asks the keyboard once the hub may be
    running: a direct ``console.input`` would be a second stdin reader
    competing with the hub's. Falls back to ``console.input`` - the exact
    old behaviour - when the hub is not running (non-tty, disabled, or a
    one-shot)."""
    if not _HUB.running():
        return console.input(markup)
    console.print(markup, end="")
    return _HUB.ask()


def repl_input(console, markup: str) -> str:
    """The REPL prompt itself: render, then take the next line (which may
    have been typed minutes ago, mid-turn - that is the point)."""
    if not _HUB.running():
        return console.input(markup)
    console.print(markup, end="")
    return _HUB.readline()
