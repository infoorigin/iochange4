"""The plan as durable state, ticked from what happened - not from a claim.

WHAT WAS MISSING. `/plan` produced a numbered plan in the REPLY, `/go` asked
the model to execute it, and nothing anywhere held the plan. Three costs, all
of them quiet:

* A multi-turn build re-derives what it is doing from the transcript, and the
  further in it gets the more transcript there is to re-derive it from. The
  session record already fixed exactly this for the opening request - "the
  harness has known this string all along and never said it back" - and the
  PLAN is the same fact one level down.
* A cancelled or failed turn loses it. `guarded()` keeps the conversation, but
  the plan lived only in a reply the next turn has to re-read and re-interpret.
* Progress was the model's word for it. `/go` asks for `[step N/M]` lines and
  the console renders them as ticks, so a model that stops printing them looks
  finished, and one that prints them without doing the work looks done.

THE PRECEDENT IS ALREADY IN THIS REPOSITORY. A swarm's briefing mandates
`_run_plan.md` - "the parts of the goal as a checklist, updated after every
completed part. This is your checkpoint - a retried session resumes from it
instead of starting over" - and Fix-6 smart continuation READS it, which is
what makes a retried attempt resume rather than restart. `forensics` reports
`checkpoint_present` from the same file. The builder had no equivalent.

TICKED BY THE HARNESS, NOT BY THE MODEL. `verify.py` states the rule this
module follows: the harness verifies, the model does not self-report. An item
naming paths is done when THOSE PATHS ACTUALLY CHANGED on disk, observed from
`result["changed"]`, which is git's answer and not the model's. An item naming
no path cannot be ticked that way and is left open - honestly - rather than
guessed at, because a checklist that ticks itself optimistically is worse than
none: it reports progress that did not happen.
"""
from __future__ import annotations

import re

#: A numbered plan item: "1. text", "1) text", "- 1. text", with optional
#: markdown decoration. Anchored to the line start so a "1." inside prose
#: does not open a new item.
_ITEM = re.compile(r"^\s*(?:[-*]\s*)?(\d{1,2})[.)]\s+(.+?)\s*$")

#: A path inside an item's text. Either something with a directory
#: separator, or a bare filename with an extension we author.
_PATH = re.compile(
    r"`([^`]+)`"                                   # backticked wins
    r"|([\w.-]+(?:[/\\][\w.-]+)+)"                 # a/b/c
    r"|(\b[\w-]+\.(?:md|ya?ml|py|json|toml)\b)")   # bare file.ext

#: Items beyond this are almost certainly a list that is not a plan.
_MAX_ITEMS = 30


def _paths_in(text: str) -> list[str]:
    out: list[str] = []
    for backticked, slashed, bare in _PATH.findall(text):
        token = (backticked or slashed or bare).strip().strip("'\",()[]")
        # A backticked span can be a COMMAND (`aicore new-agent rey`), not a
        # path. Keep it only when it still looks like one.
        if backticked and not _PATH.match(token):
            continue
        if token and token not in out:
            out.append(token.replace("\\", "/"))
    return out


def extract_items(reply: str) -> list[dict]:
    """The numbered steps of a plan reply, with the paths each one names."""
    items: list[dict] = []
    seen_numbers: set[str] = set()
    for line in (reply or "").splitlines():
        m = _ITEM.match(line)
        if not m:
            continue
        number, text = m.group(1), m.group(2)
        # A plan restates its numbering once; a reply that lists 1..N twice
        # (a summary after the plan) must not double the checklist.
        if number in seen_numbers:
            continue
        seen_numbers.add(number)
        clean = text.strip().lstrip("*_# ").rstrip("*_ ")
        if not clean:
            continue
        items.append({"text": clean[:200], "paths": _paths_in(clean),
                      "done": False})
        if len(items) >= _MAX_ITEMS:
            break
    return items


def store(sess: dict, reply: str) -> list[dict]:
    """Record the plan from a planning turn's reply. Returns the items."""
    items = extract_items(reply)
    if items:
        sess["plan"] = {"items": items}
    return items


def items(sess: dict) -> list[dict]:
    return list(((sess or {}).get("plan") or {}).get("items") or [])


def clear(sess: dict) -> None:
    sess.pop("plan", None)


def tick_from_changed(sess: dict, changed) -> list[dict]:
    """Mark items done whose named paths actually changed. Returns the newly
    ticked items.

    An item is done when EVERY path it names has changed - not any. "create
    the agent and wire it into the workflow" naming two files is half done
    when one moved, and reporting it complete is the failure this whole
    module exists to avoid.
    """
    plan = (sess or {}).get("plan") or {}
    todo = plan.get("items") or []
    if not todo:
        return []
    touched = set()
    for entry in changed or []:
        p = entry.get("path") if isinstance(entry, dict) else str(entry)
        if p:
            touched.add(str(p).replace("\\", "/"))

    newly: list[dict] = []
    for item in todo:
        if item.get("done") or not item.get("paths"):
            continue
        if all(any(t == p or t.endswith("/" + p) or p.endswith("/" + t)
                   for t in touched)
               for p in item["paths"]):
            item["done"] = True
            newly.append(item)
    return newly


def progress(sess: dict) -> tuple[int, int]:
    todo = items(sess)
    return sum(1 for i in todo if i.get("done")), len(todo)


def clause(sess: dict) -> str:
    """The plan, as the act turn's own context.

    Injected so the turn does not re-derive the plan from a growing
    transcript. Ticks are the harness's, so this doubles as telling the
    model what it has NOT yet done - which is the half a transcript states
    least clearly.
    """
    todo = items(sess)
    if not todo:
        return ""
    done, total = progress(sess)
    lines = [f"[plan] {done}/{total} complete. The harness ticks an item when "
             f"the files it names actually change; these ticks are "
             f"observations, not claims."]
    for n, item in enumerate(todo, 1):
        mark = "x" if item.get("done") else " "
        lines.append(f"  [{mark}] {n}. {item['text']}")
    lines.append("Work the remaining items. Name any deviation before acting.")
    return "\n".join(lines)


def render(console, sess: dict, glyphs: dict | None = None) -> bool:
    """Print the checklist. False when there is no plan to print."""
    todo = items(sess)
    if not todo:
        return False
    g = glyphs or {}
    on, off = g.get("on", "[x]"), g.get("off", "[ ]")
    done, total = progress(sess)
    console.print(f"[bold]plan[/] [dim]{done}/{total} complete[/]")
    for n, item in enumerate(todo, 1):
        if item.get("done"):
            console.print(f"  [green]{on}[/] [dim]{n}. {item['text']}[/]",
                          soft_wrap=True)
        else:
            console.print(f"  {off} {n}. {item['text']}", soft_wrap=True)
    unticked = [i for i in todo if not i.get("done") and not i.get("paths")]
    if unticked:
        console.print(f"  [dim]{len(unticked)} item(s) name no file, so the "
                      f"harness cannot tick them from what changed.[/]",
                      soft_wrap=True)
    return True
