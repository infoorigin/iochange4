"""One build turn - spawn or in-process - and the prompt wrappers.

The display contract lives here: what the user sees is the assistant's
FINAL words plus a live activity stream, never raw model thinking.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import threading
import time
from pathlib import Path

from loguru import logger

from ioagentfarm.builder.console import (_console, _glyphs, TAG,
                                         set_active_console,
                                         set_active_live, live_suspended)
from ioagentfarm.builder.events import (_EDIT_TOOLS, _WRITE_TOOLS,
                                        _checkpoint_events, _compact_call,
                                        _edit_hunks, _plan_step,
                                        _result_summary, _write_preview,
                                        written_paths)
from ioagentfarm.builder.session import _final_reply, _session_file


#: workspace's assignment is authoritative, so a skill added to the SDK
#: never auto-joins an existing home - each new builder skill would repeat
#: the "politely reports the skill missing" failure without this list.
_BUILDER_SKILLS = ("solution_builder", "solution_design", "workflow_craft",
                   "swarm_craft", "skill_craft", "agent_craft", "mcp_craft",
                   "run_ops")


def _ensure_builder_skill(role: str) -> bool:
    """Place any missing builder skill into *role*'s seeded workspace.

    The session preamble and solution_builder's routing table name these
    skills; a workspace seeded before one shipped does not have it, and the
    failure is the worst kind - the assistant politely reports the skill
    missing and carries on without the judgement. Copy-never-overwrite, from
    the installed package, so an upgraded engine heals old workspaces on
    first use and a local edit is never clobbered.
    """
    from importlib.resources import files

    from ioagentfarm.engine.workspaces import iobot_agent_workspace

    placed = False
    try:
        skills_dir = Path(iobot_agent_workspace(role)) / "skills"
        for name in _BUILDER_SKILLS:
            dest = skills_dir / name / "SKILL.md"
            if dest.is_file():
                continue
            src = (files("ioagentfarm") / "agents" / "cora_build" /
                   "workspace" / "skills" / name / "SKILL.md")
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(src.read_text(encoding="utf-8"),
                            encoding="utf-8")
            placed = True
    except Exception:                     # noqa: BLE001 - never block a build
        logger.debug("could not place builder skills for {!r}", role,
                     exc_info=True)
    return placed


#: Plan mode and review are ENFORCED, not requested: both wrap the message,
#: and the harness auto-reverts anything the turn wrote (checkpoint-based),
#: so "propose only" and "review only" are guarantees about the working tree
#: rather than hopes about the model.
_PLAN_WRAP = """\
[plan mode]
Propose only - do not create, modify or delete anything. Any file change you
make in this turn will be REVERTED by the harness. Reply with a numbered
plan: the files you would create or modify (with paths), the commands you
would run, and any question whose answer changes the plan. End with:
"Reply /go to execute this plan."

{message}"""

_REVIEW_WRAP = """\
[review]
You are reviewing changes you did not write. Do not modify anything - any
change you make will be reverted. Adversarially review the diff below for:
frontmatter that will not parse (unquoted descriptions containing ": "),
content placed outside what a scaffold created, skills an agent carries but
nothing triggers, secrets or credentials in content, and missing lint runs.
NEVER flag a workflow or swarm key from memory: run
`aicore lint-workflow <PATH-to-the-dir> --json` (or lint-swarm) and report
only what the linter confirms - the linter is authoritative and your recall
of the schema is not. USE THE PATH, not the name: content in a solution
that has not been installed is invisible by name, and "no workflow named
..." is a discovery failure you must NOT read as clean. If a linter cannot
be run at all, say so in the verdict rather than approving unlinted work.
EVIDENCE RULES: state facts about the repository only from what you
OBSERVED in this turn. If a command fails, QUOTE its exact output in the
finding - never translate a failed invocation into a claim about the tree
(a refused lint is NOT "the directory does not exist"). Before claiming
any path is missing, list its parent directory and quote what you saw.
A finding without quoted evidence is not a finding.
Reply with a verdict line - APPROVE or FIX - followed by numbered findings,
each with the file and what to change. No prose beyond that.

{diff}"""


def _collect_written(meta: dict, written: set, repo=None) -> None:
    """Attribute the subprocess path's writes, from the raw checkpoint."""
    from ioagentfarm.builder.events import _parse_call
    cp = (meta or {}).get("runtime_checkpoint") or {}
    for tc in (cp.get("pending_tool_calls") or []):
        name, d = _parse_call(tc)
        written.update(written_paths(name, d, repo))


def _status_line(phase: dict, start: float, G: dict,
                 meter: str = "") -> str:
    """The spinner's label: phase, the concrete action, elapsed.

    ENGINEERING, not judgement. The skill decides WHAT the assistant says;
    this guarantees the screen is never uninformative while it says nothing.
    Rich animates the dots either way, but animation without a changing
    number reads as a hang - and the label used to change only when an
    event fired, so a 90-second model call showed a frozen phrase.
    """
    import time as _t
    secs = int(_t.monotonic() - start)
    m, s = divmod(secs, 60)
    span = f"{m}m{s:02d}s" if m else f"{s}s"
    detail = phase.get("detail")
    tail = f" [dim]{detail}[/]" if detail else ""
    return (f"[dim]{phase['label']} {span}{G['ell']}[/]{tail}"
            f"[dim]{meter}  {G['sep']} Ctrl+C cancels[/]")


def _one_turn(*, role: str, message: str, uid: str, session_key: str,
              cfg_path, repo: Path, quiet: bool = False,
              activity: bool = False, engine=None,
              written: set | None = None) -> str | None:
    """Run one turn. Returns the reply text (also printed unless *quiet*).

    *quiet* suppresses the final-reply print; *activity* re-enables the
    LIVE STREAM (tool lines, results, liveness) even under quiet. The
    review turn is the reason both exist: its verdict must render once,
    formatted, at the end - but running it fully quiet made it the
    product's longest dead air, two minutes of blank screen inside the
    trust-building feature (2026-08-11 field run).

    With *engine* (an in-process BuildEngine), the turn runs in this process
    - no spawn, approval gate possible - writing the SAME session JSONL, so
    the watcher, the reply readback and every session feature are shared
    with the subprocess path rather than duplicated.
    """
    import collections
    import threading
    import time

    console = _console()
    G = _glyphs(console)
    # A provider logging an upstream failure from its own thread renders
    # through THIS console, so Rich clears and redraws the spinner around
    # the line instead of a second Console tearing the live region.
    set_active_console(console)
    from ioagentfarm.cli import _invoke_agent, _root

    spath = _session_file(role, session_key, uid)
    show = (not quiet) or activity          # the live stream's gate
    start = time.monotonic()
    last_event = {"t": start}
    stall_note = {"said": False}
    #: The display queue (backlog H18). A console write can block
    #: INDEFINITELY on Windows - conhost's QuickEdit halts every write
    #: while the user drag-selects - and `_render` used to write from the
    #: EVENT-LOOP thread under `lock`: a stuck console froze the loop, and
    #: Ctrl+C with it, indistinguishably from a model stall. The loop (and
    #: the subprocess watcher) now only APPEND; the ticker thread does
    #: every write. Bounded so a wedged console costs old display lines,
    #: never memory, never the loop.
    display_q = collections.deque(maxlen=600)
    stop = threading.Event()
    # One lock over console writes: the watcher thread and the spinner's own
    # refresh both draw; rich is not thread-safe by contract.
    lock = threading.Lock()

    def _render(kind: str, text: str) -> None:
        """PRODUCER only - see display_q above; _emit does the writing."""
        last_event["t"] = time.monotonic()
        if not show:
            return
        display_q.append((kind, text))

    def _emit(kind: str, text: str) -> None:
        # Three visually distinct channels, the Claude Code convention:
        # PROSE is the agent talking (plain, bold marker), ACTIVITY is a
        # tool call (dim cyan bullet), and WRITTEN CONTENT is diff-green
        # `+` lines - code appearing as it is authored.
        with lock:
            if kind == "prose":
                step = _plan_step(text)
                if step:
                    # `[step 2/6] wrote the catalog` - progress against the
                    # plan, rendered as a ticked checklist line. Recognition
                    # is ours; emission is the model's, and a model that
                    # ignores the marker degrades to plain narration.
                    n, m, rest = step
                    console.print(f"[bold green]{G['check']} step {n}/{m}[/] "
                                  f"{rest}", highlight=False)
                else:
                    console.print(f"[bold]{G['prose']}[/] {text}",
                                  highlight=False)
            elif kind == "call":
                console.print(f"  [cyan]{G['tool']}[/] [dim]{text}[/]",
                              highlight=False)
            elif kind == "write":
                path, lines, hidden = text
                console.print(f"  [cyan]{G['tool']}[/] [bold]write[/] "
                              f"[dim]{path}[/]", highlight=False)
                for ln in lines:
                    console.print(f"    + {ln[:110]}", style="green",
                                  highlight=False, markup=False)
                if hidden:
                    console.print(f"    {G['ell']} +{hidden} more line(s)",
                                  style="dim", highlight=False, markup=False)
            elif kind == "edit":
                hunks, more = text
                for path, lines, hidden in hunks:
                    console.print(f"  [cyan]{G['tool']}[/] [bold]edit[/] "
                                  f"[dim]{path}[/]", highlight=False)
                    for sign, ln in lines:
                        console.print(f"    {sign} {ln[:110]}",
                                      style="red" if sign == "-" else "green",
                                      highlight=False, markup=False)
                    if hidden:
                        console.print(f"    {G['ell']} +{hidden} more "
                                      "line(s)", style="dim",
                                      highlight=False, markup=False)
                if more:
                    console.print(f"    {G['ell']} +{more} more edit(s)",
                                  style="dim", highlight=False, markup=False)
            elif kind == "result":
                # the call LANDING - dim, one line, every call gets one
                console.print(f"    {G['res']} {text}", style="dim",
                              highlight=False, markup=False)
            elif kind == "reply":
                # ANOTHER AGENT'S WORDS, in full: the user asked for the
                # conversation, so the reply is theirs to read, not a
                # one-line "replied successfully" from the builder.
                lines, hidden = text
                console.print(f"    {G['res']} reply:", style="dim",
                              highlight=False, markup=False)
                for ln in lines:
                    console.print(f"    | {ln}", highlight=False,
                                  markup=False)
                if hidden:
                    console.print(f"    {G['ell']} +{hidden} more line(s)",
                                  style="dim", highlight=False, markup=False)
            elif kind == "error":
                console.print(f"  [red]{G['fail']} {text}[/]", highlight=False)
            if status is not None:
                phase["label"] = {"prose": "thinking",
                                  "call": "running tools",
                                  "write": "writing",
                                  "edit": "editing",
                                  "result": "running tools",
                                  "error": "recovering"}.get(kind, "working")
                if kind in ("call", "write"):
                    # the concrete thing, so a frozen screen still says WHAT
                    detail = text[0] if isinstance(text, tuple) else str(text)
                    phase["detail"] = " ".join(detail.split())[:48]
                status.update(_status_line(phase, start, G))

    def _engine_event(kind: str, payload) -> None:
        """Native-channel events from the in-process engine.

        Same three display channels as the watcher, without touching the
        session file - see BuildEngine.turn for why reading it in-process
        was fatal on Windows.
        """
        if kind == "prose":
            _render("prose", " ".join(str(payload).split())[:400])
            return
        if kind == "result":
            name, result = payload
            _render("result", f"{name}: {_result_summary(result)}"[:110])
            return
        if kind == "error":
            _render("error", str(payload)[:110])
            return
        name, args = payload
        if written is not None and isinstance(args, dict):
            written.update(written_paths(name, args, repo))
        if name in _EDIT_TOOLS:
            hunks, more = _edit_hunks(name,
                                      args if isinstance(args, dict) else {},
                                      repo)
            if hunks:
                _render("edit", (hunks, more))
                return
        if name in _WRITE_TOOLS:
            pv = _write_preview(args if isinstance(args, dict) else {},
                                repo)
            if pv:
                _render("write", pv)
                return
        _render("call", _compact_call(
            {"function": {"name": name, "arguments": json.dumps(args)}},
            repo))

    def _watch() -> None:
        seen: set = set()
        last_mtime = 0.0
        while not stop.is_set():
            try:
                if spath and spath.is_file():
                    m = spath.stat().st_mtime
                    if m != last_mtime:
                        last_mtime = m
                        head = spath.read_text(encoding="utf-8") \
                            .split("\n", 1)[0]
                        meta = json.loads(head) if head.strip() else {}
                        cp_meta = meta.get("metadata", meta)
                        if written is not None:
                            _collect_written(cp_meta, written, repo)
                        for kind, text in _checkpoint_events(
                                cp_meta, seen, repo):
                            _render(kind, text)
            except (OSError, ValueError):
                pass
            stop.wait(0.5)

    def _pulse() -> None:
        # Liveness for a console WITHOUT a live display (piped output, CI).
        # The ticker decides WHICH of the two runs; this one only formats
        # the no-spinner case, and stays callable as _invoke_agent's
        # heartbeat on the subprocess path.
        if not show or status is not None:
            return
        elapsed = int(time.monotonic() - start)
        if elapsed < 2:
            print("[build] working ...", flush=True)
        elif time.monotonic() - last_event["t"] > 30:
            m, s = divmod(elapsed, 60)
            span = f"{m}m{s:02d}s" if m else f"{s}s"
            print(f"[build] still working - {span}", flush=True)

    # The spinner is what keeps the screen alive between events: a terminal
    # gets an animated status line whose label follows the latest activity;
    # everything printed above it scrolls normally. Non-terminals keep the
    # plain pulse - a spinner in a log file is noise.
    status = None
    phase = {"label": "starting", "detail": None}
    if show and console.is_terminal:
        status = console.status(f"[dim]starting {G['ell']}[/]",
                                spinner="dots")
        status.start()
        set_active_live(status)

    def _tick() -> None:
        """The liveness floor, on ONE timer for both console kinds.

        A terminal gets the status label refreshed so elapsed time moves; a
        non-terminal gets the periodic pulse. It runs for BOTH turn paths,
        which is the bug this replaced: `heartbeat=_pulse` was handed only
        to `_invoke_agent`, so the in-process engine - the DEFAULT for an
        interactive session - printed nothing at all when its output was
        piped. Found by running a real turn and reading the captured log:
        95 seconds, not one liveness line.
        """
        beat = {"next": 0.0}
        while not stop.wait(0.1):
            # the display drains at 10Hz so events land as they happen;
            # the status line and stall check keep their 1s cadence below
            while display_q:
                try:
                    _emit(*display_q.popleft())
                except Exception:         # noqa: BLE001 - display only
                    logger.debug("display emit failed", exc_info=True)
            now_ = time.monotonic()
            if now_ < beat["next"]:
                continue
            beat["next"] = now_ + 1.0
            if status is not None:
                try:
                    meter = _usage.spinner_suffix(_upath, _umark)
                except Exception:         # noqa: BLE001 - never break the tick
                    meter = ""
                if live_suspended():
                    continue          # a prompt owns the screen
                # THE IN-PROCESS PATH HAD NO STALL VOICE AT ALL: the
                # subprocess path has a 300s watchdog, the default
                # interactive path had only a counter that kept climbing.
                # This does not kill anything - the runtime's own call
                # timeout does the bounding - it tells the user what the
                # frozen label means and that Ctrl+C is safe.
                quiet_s = time.monotonic() - last_event["t"]
                if quiet_s > (build_stall_timeout() or 300) \
                        and not stall_note["said"]:
                    stall_note["said"] = True
                    with lock:
                        console.print(
                            f"[yellow]\\[build] no new activity for "
                            f"{int(quiet_s // 60)}m - the model call may "
                            "be stalled. Ctrl+C cancels safely: the turn "
                            "is checkpointed (/undo covers it) and what "
                            "completed is kept.[/]")
                with lock:
                    status.update(_status_line(phase, start, G, meter))
            else:
                _pulse()

    ticker = None
    if show:
        ticker = threading.Thread(target=_tick, daemon=True)
        ticker.start()

    # Arm the exec guard for THIS spawn's environment: the runtime patch
    # checks the signal at call time, so every other surface stays untouched.
    # ONE signal, `IOF_BUILD_REPO` - its PRESENCE means "in a build session"
    # (there used to be a redundant `IOF_BUILD_GUARD=1` boolean beside it; the
    # two were always set and cleared together, so the repo is the whole
    # marker now). CAPTURED FIRST and restored in the finally: it is
    # process-global, and leaving it armed after the turn pointed the write
    # gates of any LATER in-process work (another CliRunner invocation, an
    # embedding wrapper) at a repository from a finished turn.
    #
    # WHICH REPOSITORY, and why the value matters: the write/placement gates
    # need a root to measure "inside" against, and the subprocess has only a
    # cwd - which a `working_dir` argument can move. Passing it explicitly is
    # what lets the placement gate exist on this path at all.
    _prior_env = {"IOF_BUILD_REPO": os.environ.get("IOF_BUILD_REPO")}
    os.environ["IOF_BUILD_REPO"] = str(Path(repo).resolve())

    # Arm the context/cost meter. The runtime appends one record per model
    # call; `mark` is where THIS turn starts, so the footer reports the turn
    # rather than the session's whole history.
    from ioagentfarm.builder import usage as _usage
    _upath = _usage.arm(_root(), session_key)
    _umark = _usage.line_count(_upath)

    # THE WATCHER IS SUBPROCESS-ONLY. In-process it raced the session
    # writer's os.replace and killed the REPL on Windows; the engine feeds
    # the same display from the runtime's native progress channel instead.
    watcher = None
    if engine is None:
        watcher = threading.Thread(target=_watch, daemon=True,
                                   name="build-session-watch")
        watcher.start()
    reply = None
    #: Set by the stall watchdog. A list because the callback runs on
    #: the watchdog THREAD and this is read after the join.
    stalled: list = []
    try:
        if engine is not None:
            full = f"{session_key}:u:{uid}" if uid else session_key
            # NOT `asyncio.run` - the engine owns the loop, because the
            # cached provider client is bound to it. See `run_turn`.
            reply = engine.run_turn(message, full, on_event=_engine_event)
        else:
            def _on_stall(seconds: int) -> None:
                """Say it on the way out, not afterwards.

                The user has been watching a silent screen; by the time the
                reply is read back the console has already scrolled. This
                lands at the moment the harness gives up.
                """
                stalled.append(seconds)
                if not quiet:
                    console.print(
                        f"[yellow]{TAG} no output for {seconds}s - ending "
                        "this turn. The model was most likely retrying "
                        "upstream. Anything already written is on disk; "
                        "`/diff` shows it and `/undo` reverts it.[/]",
                        soft_wrap=True)

            try:
                _spawn_turn(
                    role=role, session_key=session_key, uid=uid,
                    message=message, cfg_path=cfg_path, repo=repo,
                    pulse=_pulse, on_stall=_on_stall)
            except OSError as exc:
                # THE PROMPT DID NOT FIT ON A COMMAND LINE. The subprocess
                # path passes the whole prompt as an argv entry, and Windows
                # caps a command line at 32,767 characters: a 28 KB message
                # plus the ~12 KB preamble overran it and CreateProcess
                # failed with WinError 206 before anything ran. What the
                # user saw was a turn that took two seconds, made no tool
                # calls, and printed nothing at all - the harness's own
                # `json_last_line` contract broken with an empty line.
                #
                # The in-process engine passes the message in MEMORY, so it
                # has no such limit. This is not a preference between the
                # two paths, it is the only one that can carry this turn.
                if not _is_too_long(exc):
                    raise
                logger.info("prompt too long for a command line ({} chars) "
                            "- running this turn in-process", len(message))
                if not quiet:
                    console.print(
                        f"[dim]{TAG} this request is too large to hand to a "
                        "subprocess - running it in this process instead[/]",
                        soft_wrap=True)
                from ioagentfarm.builder.engine import BuildEngine
                fallback = BuildEngine(role, repo, cfg_path)
                full = f"{session_key}:u:{uid}" if uid else session_key
                reply = fallback.run_turn(message, full,
                                          on_event=_engine_event)
    finally:
        stop.set()
        if watcher is not None:
            watcher.join(timeout=2)
        if ticker is not None:
            ticker.join(timeout=2)
        # whatever the ticker had not drained prints now, in order, on the
        # main thread - the ticker is stopped, so there is no second writer
        while display_q:
            try:
                _emit(*display_q.popleft())
            except Exception:             # noqa: BLE001 - display only
                break
        if status is not None:
            status.stop()
        set_active_console(None)
        set_active_live(None)
        for _k, _v in _prior_env.items():
            if _v is None:
                os.environ.pop(_k, None)
            else:
                os.environ[_k] = _v

    if reply is None:
        reply = _final_reply(spath)
    # A STALLED TURN SAYS SO, in the reply itself. The runtime's own
    # placeholder for this is "[Assistant reply unavailable due to
    # model error.]", which tells the user nothing they can act on -
    # not that it waited, not for how long, not that their files are
    # safe. Whatever the model managed to say is kept underneath.
    if stalled:
        secs = stalled[0]
        note = (f"The turn was ended after {secs}s with no output "
                "from the model - most likely an upstream retry "
                "loop, not work in progress. Nothing was lost: "
                "anything already written is on disk, `/diff` "
                "shows it and `/undo` reverts it. Try again, or "
                "ask for something smaller.")
        # The runtime's own placeholder carries nothing, so it is replaced
        # rather than appended to; anything else the model managed to say is
        # kept underneath the explanation.
        salvage = "" if "unavailable" in str(reply or "") else str(reply or "")
        reply = f"{note}\n\n{salvage}".strip() if salvage else note
    # BEFORE THE PRINT, not after it. A literal secret in the reply is
    # stripped here because this is the last point that covers BOTH
    # surfaces: the console render below and the value returned to the
    # caller. Redacting in `send()` - the obvious place, since that is
    # where the JSON payload is assembled - would have left the
    # interactive console printing the token, which is the surface most
    # likely to be on a shared screen.
    secrets_seen = []
    try:
        from ioagentfarm.builder.gates import redact_secrets
        reply, secrets_seen = redact_secrets(reply)
    except Exception:                     # noqa: BLE001 - never lose a reply
        from loguru import logger as _log
        _log.debug("reply redaction failed", exc_info=True)
    if secrets_seen and not quiet:
        console.print(
            f"[yellow]{TAG} a literal {', '.join(secrets_seen)} was "
            "removed from that reply - the value belongs in your .env, "
            "never in a message[/]", soft_wrap=True)
    if not quiet:
        if reply:
            # Markdown-rendered: the reply is authored prose, and lists,
            # emphasis and code spans should read as intended.
            from rich.markdown import Markdown
            console.print()
            try:
                console.print(Markdown(reply))
            except Exception:             # noqa: BLE001 - never lose a reply
                print(reply, flush=True)
        else:
            print("[build] the turn completed but no reply could be read "
                  f"from the session record - inspect it directly: {spath}",
                  flush=True)
        try:
            stats = _usage.read(_upath, _umark)
            if stats:
                console.print(f"[dim]{_usage.footer(stats, G)}[/]")
        except Exception:                 # noqa: BLE001 - a meter must never
            pass                          # cost a reply
    return reply


def _is_too_long(exc: OSError) -> bool:
    """Is this the OS refusing an over-long command line?

    Windows raises `FileNotFoundError` - a subclass of OSError - with
    `winerror` 206, "The filename or extension is too long", which names
    neither the argument nor the length. POSIX raises `E2BIG`. Matched on
    the error CODE, never its text, which is localised.
    """
    import errno

    if getattr(exc, "winerror", None) == 206:
        return True
    return getattr(exc, "errno", None) == errno.E2BIG


#: How long a build turn may produce NOTHING before the harness ends it.
#: Not a cap on a turn's length - a turn that is working stays alive, and
#: the call budget already bounds how much work one can do. This bounds
#: SILENCE, which is the failure that has no other limit: measured, a turn
#: sat for 25.1 minutes while the provider retried and then answered
#: "[Assistant reply unavailable due to model error.]".
#:
#: 300s against a measured worst legitimate gap well under a minute. Set
#: `IOF_BUILD_STALL_S=0` to restore the old unbounded wait.
_STALL_DEFAULT_S = 300


def build_stall_timeout() -> float:
    raw = (os.environ.get("IOF_BUILD_STALL_S") or "").strip()
    if not raw:
        return float(_STALL_DEFAULT_S)
    try:
        return max(0.0, float(raw))
    except ValueError:
        return float(_STALL_DEFAULT_S)


def _spawn_turn(*, role, session_key, uid, message, cfg_path, repo, pulse,
                on_stall=None):
    """The subprocess path, extracted so its failure can be caught.

    Inline in `_one_turn` the call sat inside a `try/finally` that had no
    `except`, so an OSError from the spawn propagated straight out with the
    turn half-set-up. It is a function now so the caller can name the one
    failure it knows how to recover from and re-raise everything else.
    """
    from ioagentfarm.cli import _invoke_agent, _root

    return _invoke_agent(
        role=role,
        session_key=session_key,
        user_id=uid,
        root_path=_root(),
        message=message,
        config_path=cfg_path,
        # THE PLACEMENT GRANT. project_dir points the runtime's file tools
        # and the exec cwd at the repo - the same mechanism a workflow step
        # uses to write artifacts. Without it, "create a skill" scaffolds
        # into the agent's own workspace: the exact cwd trap found live on
        # a client VM.
        project_dir=repo,
        # Selects the streaming branch (byte-level CR/LF reader + rebrand);
        # the raw stream goes to forensics, never the screen.
        on_output=lambda _line: None,
        display_filter=lambda _line: None,
        heartbeat=pulse,
        stall_timeout=build_stall_timeout() or None,
        on_stall=on_stall,
    )
