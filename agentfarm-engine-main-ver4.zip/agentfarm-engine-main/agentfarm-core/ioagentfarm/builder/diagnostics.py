"""Compiler-grade feedback on a written file, in the same turn that wrote it.

THE GAP THIS FILLS. `verify.lint_targets` covers skills, agents, workflows and
swarms — the YAML and Markdown this platform defines. It returns ``[]`` for
"a file no linter covers (CORABUILD.md, a tool script, a data file)", and that
list is where the real code lives: `new-tool` scaffolds a **Python** script, a
workflow ships `metadata/catalog.yaml`, a pack ships `mcp.yaml`. A syntax error
in any of them is invisible until something runs it — which is a step failure,
three turns later, spending that step's attempts on `SyntaxError` — or never,
because the tool is only exercised on a pod.

So: after a successful write, parse what was written and hand the model the
error, with a line number, in the tool result it is already reading.

TWO TIERS, AND THE SPLIT IS THE POINT.

* **Baseline** — `compile()`, `yaml.safe_load`, `json.loads`, `tomllib`. No
  dependency, no subprocess, no configuration, runs everywhere. This is core's
  half, and it is domain-free: core cannot know what your quality bar is, but
  it does know that a file which does not parse is wrong.

* **Declared** — `ruff`, `pyright`, `mypy`. Run ONLY when the repository
  declares them (a `[tool.ruff]`, a `pyrightconfig.json`, a `[tool.mypy]`) AND
  the binary resolves on PATH. The repo declaring the checker IS the
  solution's half of the contract, exactly like `coverage:` in workflow.yaml:
  core runs what the solution declared and stays out of the judgement.

WHY AN ALLOWLIST AND NOT A `command:` FIELD. A manifest that named a shell
command to run after every write would be arbitrary code execution inside a
build session, which is the trust seam `installer: build` already has to sit
behind `--allow-build`. There is no such seam here and there does not need to
be one: the checkers are named in code, invoked with arguments this module
builds, and a repo can only turn them ON by configuring them, never point them
somewhere else. Adding a `command:` field would trade that for nothing.

A DIAGNOSTIC MUST NEVER COST THE USER A WRITE. Every path here is wrapped,
every subprocess is capped by a short timeout, and any failure degrades to
"no diagnostics" rather than an error. The write already succeeded; the file
is on disk either way.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

#: A checker gets this long, total. It runs on the write path — the model is
#: waiting — so the budget is small on purpose and a slow checker is simply
#: skipped rather than allowed to stall a turn.
CHECKER_TIMEOUT_S = float(os.environ.get("IOF_DIAGNOSTICS_TIMEOUT_S", "8"))

#: Files big enough that parsing them on every write is not free. Authored
#: content is never near this; a data file dropped into the repo can be.
MAX_BYTES = 2_000_000


@dataclass
class Diagnostic:
    """One problem with one file."""

    path: str
    line: int | None
    severity: str  # "error" | "warning"
    message: str
    source: str  # "syntax" | "ruff" | "pyright" | "mypy" | "yaml" | "json"

    def as_dict(self) -> dict:
        return {"path": self.path, "line": self.line,
                "severity": self.severity, "message": self.message,
                "source": self.source}


# ---------------------------------------------------------------------------
# Baseline: does it parse at all
# ---------------------------------------------------------------------------

def _python_syntax(path: Path, text: str) -> list[Diagnostic]:
    try:
        compile(text, str(path), "exec")
    except SyntaxError as exc:
        # `exc.msg` is the useful half; `str(exc)` repeats the filename and
        # line, which the caller already renders.
        return [Diagnostic(str(path), exc.lineno, "error",
                           f"{exc.msg}", "syntax")]
    except ValueError as exc:
        # e.g. source containing null bytes.
        return [Diagnostic(str(path), None, "error", str(exc), "syntax")]
    return []


def _yaml_parse(path: Path, text: str) -> list[Diagnostic]:
    try:
        import yaml
    except Exception:                                  # noqa: BLE001
        return []
    try:
        # `safe_load_all`: a workflow.yaml is one document, but a file with a
        # stray `---` is several, and load() would silently read only the
        # first — the same "loads clean, means something else" failure the
        # frontmatter bug is made of.
        list(yaml.safe_load_all(text))
    except yaml.MarkedYAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        line = (mark.line + 1) if mark is not None else None
        problem = getattr(exc, "problem", None) or str(exc)
        context = getattr(exc, "context", None)
        msg = f"{context}, {problem}" if context else problem
        return [Diagnostic(str(path), line, "error", msg, "yaml")]
    except yaml.YAMLError as exc:
        return [Diagnostic(str(path), None, "error", str(exc), "yaml")]
    return []


def _json_parse(path: Path, text: str) -> list[Diagnostic]:
    try:
        json.loads(text)
    except json.JSONDecodeError as exc:
        return [Diagnostic(str(path), exc.lineno, "error", exc.msg, "json")]
    return []


def _toml_parse(path: Path, text: str) -> list[Diagnostic]:
    try:
        import tomllib
    except Exception:                                  # noqa: BLE001
        return []
    try:
        tomllib.loads(text)
    except Exception as exc:                           # noqa: BLE001
        line = getattr(exc, "lineno", None)
        return [Diagnostic(str(path), line, "error", str(exc), "syntax")]
    return []


_BASELINE = {
    ".py": _python_syntax,
    ".pyi": _python_syntax,
    ".yaml": _yaml_parse,
    ".yml": _yaml_parse,
    ".json": _json_parse,
    ".toml": _toml_parse,
}


# ---------------------------------------------------------------------------
# Declared: the checkers a repository has configured
# ---------------------------------------------------------------------------

def _has_section(repo: Path, filename: str, section: str) -> bool:
    p = repo / filename
    if not p.is_file():
        return False
    try:
        return section in p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False


def declared_checkers(repo: Path) -> list[str]:
    """Which known checkers this repository has configured.

    Configuration is the DECLARATION — there is no separate manifest to keep
    in sync with the one a developer already maintains, and a repo that has
    not adopted a checker never has one run against it.
    """
    repo = Path(repo)
    out: list[str] = []
    if (repo / "ruff.toml").is_file() or (repo / ".ruff.toml").is_file() \
            or _has_section(repo, "pyproject.toml", "[tool.ruff"):
        out.append("ruff")
    if (repo / "pyrightconfig.json").is_file() \
            or _has_section(repo, "pyproject.toml", "[tool.pyright"):
        out.append("pyright")
    if (repo / "mypy.ini").is_file() or (repo / ".mypy.ini").is_file() \
            or _has_section(repo, "pyproject.toml", "[tool.mypy"):
        out.append("mypy")
    return out


def _which(name: str) -> str | None:
    import shutil
    return shutil.which(name)


def _run(argv: list[str], cwd: Path) -> tuple[int, str]:
    try:
        proc = subprocess.run(  # noqa: S603 - argv is built here, never parsed
            argv, cwd=str(cwd), capture_output=True, text=True,
            timeout=CHECKER_TIMEOUT_S,
            # A checker inherits the environment but must never inherit the
            # build session's guard flags - it is not a build tool, and a
            # stray IOF_BUILD_* in its env is one more thing to reason about.
            env={k: v for k, v in os.environ.items()
                 if not k.startswith("IOF_BUILD_")},
        )
        return proc.returncode, (proc.stdout or "") + (proc.stderr or "")
    except (subprocess.TimeoutExpired, OSError):
        return -1, ""


def _ruff(path: Path, repo: Path) -> list[Diagnostic]:
    exe = _which("ruff")
    if not exe:
        return []
    code, out = _run([exe, "check", "--output-format", "json", str(path)], repo)
    if code < 0 or not out.strip():
        return []
    try:
        items = json.loads(out)
    except json.JSONDecodeError:
        return []
    diags = []
    for it in items if isinstance(items, list) else []:
        loc = (it.get("location") or {})
        rule = it.get("code") or ""
        msg = it.get("message") or ""
        diags.append(Diagnostic(str(path), loc.get("row"), "warning",
                                f"{rule} {msg}".strip(), "ruff"))
    return diags


def _pyright(path: Path, repo: Path) -> list[Diagnostic]:
    exe = _which("pyright")
    if not exe:
        return []
    code, out = _run([exe, "--outputjson", str(path)], repo)
    if code < 0 or not out.strip():
        return []
    try:
        payload = json.loads(out)
    except json.JSONDecodeError:
        return []
    diags = []
    for it in payload.get("generalDiagnostics", []) or []:
        rng = (it.get("range") or {}).get("start") or {}
        sev = it.get("severity") or "error"
        diags.append(Diagnostic(
            str(path), (rng.get("line") or 0) + 1,
            "error" if sev == "error" else "warning",
            it.get("message") or "", "pyright"))
    return diags


def _mypy(path: Path, repo: Path) -> list[Diagnostic]:
    exe = _which("mypy")
    if not exe:
        return []
    code, out = _run([exe, "--no-error-summary", "--no-color-output",
                      str(path)], repo)
    if code < 0 or not out.strip():
        return []
    diags = []
    for line in out.splitlines():
        # path:line: severity: message
        parts = line.split(":", 3)
        if len(parts) < 4:
            continue
        try:
            lineno = int(parts[1])
        except ValueError:
            continue
        sev = parts[2].strip()
        if sev not in ("error", "warning", "note"):
            continue
        diags.append(Diagnostic(str(path), lineno,
                                "error" if sev == "error" else "warning",
                                parts[3].strip(), "mypy"))
    return diags


_CHECKERS = {"ruff": _ruff, "pyright": _pyright, "mypy": _mypy}

#: Which checkers apply to which suffixes. A YAML file has no type checker.
_CHECKER_SUFFIXES = {".py", ".pyi"}


# ---------------------------------------------------------------------------

def diagnose(path, repo, *, use_checkers: bool = True) -> list[Diagnostic]:
    """Every diagnostic for one written file. Never raises.

    The baseline runs always. Declared checkers run only when the repository
    configured them and the binary is on PATH, and only for a suffix they
    understand — and only when the baseline is CLEAN, because a file that
    does not parse produces a torrent of downstream noise from a type checker
    and the one line that matters is the syntax error.
    """
    try:
        p = Path(path)
        if not p.is_absolute():
            p = Path(repo) / p
        if not p.is_file():
            return []
        try:
            if p.stat().st_size > MAX_BYTES:
                return []
        except OSError:
            return []

        handler = _BASELINE.get(p.suffix.lower())
        if handler is None:
            return []
        try:
            text = p.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return []

        diags = handler(p, text)
        if diags or not use_checkers or p.suffix.lower() not in _CHECKER_SUFFIXES:
            return diags

        for name in declared_checkers(Path(repo)):
            fn = _CHECKERS.get(name)
            if fn is None:
                continue
            try:
                diags.extend(fn(p, Path(repo)))
            except Exception:                          # noqa: BLE001
                continue
        return diags
    except Exception:                                  # noqa: BLE001
        return []


def _rel(path, repo) -> str:
    try:
        return str(Path(path).resolve().relative_to(Path(repo).resolve())
                   ).replace("\\", "/")
    except (OSError, ValueError):
        return str(path)


def verdict_text(paths, repo, *, cap: int = 6) -> str:
    """The lines to append to a write's tool result, or "" when clean.

    SILENCE ON SUCCESS. A verdict printed after every write trains the model
    to skim past it, and the lint verdict beside it already carries the
    "I ran and found nothing" signal. This speaks only when something is
    wrong.
    """
    seen: set[str] = set()
    lines: list[str] = []
    for raw in paths:
        p = Path(raw)
        if not p.is_absolute():
            p = Path(repo) / p
        key = str(p.resolve()) if p.exists() else str(p)
        if key in seen:
            continue
        seen.add(key)

        diags = diagnose(p, repo)
        if not diags:
            continue
        errors = [d for d in diags if d.severity == "error"]
        where = _rel(p, repo)
        src = diags[0].source
        lines.append(f"[diagnostics] {where}: {len(errors)} error(s), "
                     f"{len(diags) - len(errors)} warning(s) ({src})")
        for d in (errors + [d for d in diags if d.severity != "error"])[:cap]:
            loc = where if d.line is None else f"{where}:{d.line}"
            lines.append(f"  {d.severity} {loc}: {d.message}")
        if len(diags) > cap:
            lines.append(f"  ... {len(diags) - cap} more")
    return "\n".join(lines)
