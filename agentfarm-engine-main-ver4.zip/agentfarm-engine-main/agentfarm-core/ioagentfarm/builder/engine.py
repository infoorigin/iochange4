"""The in-process turn engine for `aicore build`.

One AgentLoop, built once per REPL session on the served pool's proven
recipe (web/app.py AgentPool._init_shared + get), called per turn via
``process_direct``. What this buys over the subprocess spawn:

* the ~2-4s per-turn spawn tax is paid ONCE, at first turn;
* a PER-ACTION APPROVAL gate becomes possible - the mutating tools are
  wrapped in this process, so a y/n prompt can sit between the model's
  decision and its execution, which no subprocess boundary allows;
* cancel is a cancelled coroutine instead of a killed process.

What it deliberately does NOT change:

* the SESSION is the same JSONL - the engine passes the same
  ``<key>:u:<uid>`` the subprocess path passed, into a SessionManager over
  the same workspace, so conversations continue seamlessly across engine
  modes and the watcher, /transcript and /compact keep working unchanged;
* token streaming stays off - ``IOF_DISABLE_STREAMING`` is load-bearing for
  MiniMax reliability, and this engine respects it;
* one-shot ``--message``/``--json`` keep the subprocess path - the CI
  contract is untouched, and a one-shot pays the warmup either way
  (``IOF_BUILD_INPROCESS=1`` forces the engine there, for validation).

Fallback is structural: any construction failure surfaces to the caller,
which reports it and continues on the subprocess path - the feature
degrades to yesterday's behaviour, never to a broken session.
"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Callable, Optional

from loguru import logger

from ioagentfarm.builder.console import CompactLogHandler
from ioagentfarm.builder.logsink import (SessionLogFile, SinkHandler,
                                          session_log_name)

#: Tools whose execution mutates something the user owns - the approval
#: gate wraps exactly these. Read-only tools never prompt.
#: What an approved `pip install` / `npm install` needs from the shell it
#: was typed in, and did not get. The runtime hands an exec'd child a
#: stripped environment plus `allowed_env_keys`; the build session added
#: only the IOF_* keys, so a private index (`PIP_INDEX_URL` - the ONLY way
#: the scaffold docs say a pack reaches the org's `agentfarm-core`), a
#: corporate proxy and a CA bundle were all dropped on the way to pip.
#: `PIP_NO_INPUT` is set by `set_install_gate` and rides along.
INSTALL_ENV_KEYS = (
    "PIP_INDEX_URL", "PIP_EXTRA_INDEX_URL", "PIP_CONFIG_FILE", "PIP_CERT",
    "PIP_TRUSTED_HOST", "PIP_NO_INPUT", "PIP_FIND_LINKS",
    "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY",
    "http_proxy", "https_proxy", "no_proxy",
    "REQUESTS_CA_BUNDLE", "SSL_CERT_FILE", "CURL_CA_BUNDLE",
    "NPM_CONFIG_REGISTRY", "NODE_EXTRA_CA_CERTS", "VIRTUAL_ENV",
)

MUTATING_TOOLS = ("exec", "write_file", "apply_patch", "edit_file")

#: Read tools gated for CREDENTIAL FILES ONLY (`read_denial`). Ordinary reads
#: stay ungated - a build session reads constantly - but `.env`/keys are the
#: one read the exec guard already refuses as physics, and the tool is its
#: second door.
READ_TOOLS = ("read_file",)

#: The gates live in `builder/gates.py` - ONE implementation, armed here for
#: the in-process engine and by the `build_write_gates` runtime patch for
#: every subprocess turn. Imported, never re-defined, so the two arming
#: points cannot diverge.
from ioagentfarm.builder.gates import (placement_denial,  # noqa: E402,F401
                                       read_denial, secret_denial)


def make_gated_execute(orig, tool_name: str, gate: Callable[[str, dict], bool]):
    """Wrap one tool's execute with a user gate. Pure enough to test.

    ``gate(tool_name, kwargs) -> bool``; False returns a denial AS THE TOOL
    RESULT, so the model reads it and adapts instead of retrying blind.
    """
    async def gated(self, *args, **kwargs):
        if not gate(tool_name, kwargs):
            return ("[approval] denied by the user - do not retry the same "
                    "action; explain what you intended and ask how to "
                    "proceed.")
        return await orig(self, *args, **kwargs)
    return gated


#: How long any one teardown step may take. Leaving must be bounded: a
#: server that will not answer its close, or a task that swallows its
#: cancellation, must not keep the user at a blank screen.
_TEARDOWN_S = 5.0


async def _ask_gate(gate, kind: str, kwargs: dict) -> bool:
    """Ask a y/n gate WITHOUT stopping the event loop.

    The gates block on the keyboard. Called directly from a tool
    coroutine - as they were - that block froze the loop: exec-session
    pipes filled, MCP receive loops starved, and wall-clock deadlines
    expired against a loop that never ran (backlog H16). With the input
    hub running, the gate waits on the hub's queue from a WORKER thread
    while the loop keeps draining; Ctrl+C cancels through the hub's
    prompt token, and the worker returns without consuming a line - the
    orphan-reader theft that sank the thread-per-prompt design cannot
    happen, because the hub's single reader never abandons stdin.
    Without the hub (non-tty, disabled), the old direct call remains.
    """
    from ioagentfarm.builder import input_hub
    if input_hub.running():
        return await asyncio.to_thread(gate, kind, kwargs)
    return gate(kind, kwargs)


async def _sweep_exec_sessions(loop) -> None:
    """Reap idle-EXPIRED exec sessions at the turn boundary (backlog H17).

    The manager's own sweep runs only inside its next session call, so a
    `yield_time_ms` child nobody polled again outlived its idle timeout
    indefinitely. Same lock, same `_cleanup_locked` its own callers use;
    only sessions past `idle_timeout` (default 1800s) go, so one the
    model means to poll next turn is untouched.
    """
    try:
        mgr = getattr(loop, "_exec_session_manager", None)
        if mgr is None or getattr(mgr, "_closed", False):
            return
        async with mgr._lock:
            if not getattr(mgr, "_closed", False):
                await mgr._cleanup_locked()
    except Exception:                      # noqa: BLE001 - a sweep is upkeep
        logger.debug("exec-session sweep failed", exc_info=True)


def _bounded(aloop, aw, timeout: float, what: str) -> None:
    """Run *aw* on *aloop* with a deadline; log and move on if it misses.

    Catches **BaseException**, not Exception, and that is the whole point.
    Closing is called from the Ctrl+C handler, and two of the things it can
    raise are not Exceptions: `close_mcp` collects its cleanup failures with
    `except BaseException` and RE-RAISES them, so a cancelled cleanup comes
    back as a bare `CancelledError` or a `BaseExceptionGroup`; and a user
    who presses Ctrl+C a second time while teardown runs raises
    `KeyboardInterrupt` inside `run_until_complete`. Either escaped
    `reset()`, escaped the `except KeyboardInterrupt` that called it,
    escaped `dispatch_guarded` (Exception too) and ended the REPL with a
    traceback - losing the conversation. Leaving is not a failure mode.
    """
    try:
        aloop.run_until_complete(asyncio.wait_for(aw, timeout=timeout))
    except BaseException as exc:              # noqa: BLE001 - see docstring
        logger.debug("engine teardown: {} did not finish cleanly ({}: {})",
                     what, type(exc).__name__, exc)


class BuildEngine:
    """One in-process agent for one (role, repo) build REPL."""

    def __init__(self, role: str, repo: Path, cfg_path=None):
        self.role = role
        self.repo = Path(repo)
        self.cfg_path = cfg_path
        self._loop = None
        #: THE ASYNCIO LOOP IS SESSION-SCOPED, NOT TURN-SCOPED, and that is
        #: load-bearing - see `run_turn`. It may only ever be closed
        #: together with `_loop`.
        self._aloop = None
        self._gate: Optional[Callable[[str, dict], bool]] = None
        #: Asked for ENVIRONMENT-CHANGING commands even when the general
        #: gate is off - installs are consequential enough to confirm
        #: every time, and cheap enough to confirm once.
        self._install_gate: Optional[Callable[[str, dict], bool]] = None
        self._turn_task = None

    # ── construction ─────────────────────────────────────────────────────
    #: The sink id, so it can be released. An open loguru file handle is
    #: not free on Windows: it kept `rm -rf` of the state directory failing
    #: with "Device or resource busy" for as long as any session had ever
    #: run - a build session must never be the reason a user cannot delete
    #: their own folder.
    _log_sink_id = None
    #: The stdlib-logging handlers, tracked so both are removed on release.
    _std_handlers: list = []
    #: THE ONE FILE SINK both halves write through - see `logsink.py`. Two
    #: handles on one file is what made loguru's size rotation fail on
    #: Windows and print every record to the console for the rest of the
    #: session (`[WinError 32]` on the rename), so there is exactly one.
    _file_log: Optional[SessionLogFile] = None

    @classmethod
    def _sink_for(cls, log_file) -> SessionLogFile:
        """The sink for *log_file* - shared by both halves, made once.

        Same path, same object: the stdlib and loguru halves are installed
        from one `quiet_runtime_logs` call with one path, so they share a
        handle. A different path (a test, or a re-quiet after a partial
        release) gets its own sink rather than writing into a stranger's.
        """
        sink = cls._file_log
        if sink is None or sink.closed or Path(log_file) != sink.path:
            sink = cls._file_log = SessionLogFile(log_file)
        return sink

    @classmethod
    def _quiet_stdlib_logs(cls, log_file) -> None:
        """Quiet STDLIB logging too - loguru is only half the problem.

        `quiet_runtime_logs` removed loguru's sinks and stopped there,
        which was correct for the runtime's own logs and blind to the
        providers: `vendored/azure_openai_chat_provider.py` and
        `vendored/genai_bedrock_provider.py` report an upstream failure on
        a `logging.getLogger(...)` logger with `exc_info=True`. Nothing in
        this process configures stdlib logging, so `logging.lastResort`
        fired - bare message, no level, no logger name, full traceback,
        straight to stderr and into the middle of the conversation. The
        format is exactly why it did not look like a log line at all.

        Two handlers on the root logger fix it without losing anything:
        the file keeps DEBUG and every traceback, the console gets ERROR
        as one red line. Adding ANY handler is also what stops lastResort,
        so a provider that logs from a thread we never see is covered too.
        """
        import logging

        if cls._std_handlers:
            return
        root = logging.getLogger()
        handlers: list = []

        def _swallow(self, record):       # noqa: ARG001 - Handler.handleError
            """A failed log write must never print.

            `logging.raiseExceptions` is True by default, so a handler that
            cannot write puts `--- Logging error ---` and a traceback on
            stderr - the very output this whole change exists to remove,
            reappearing in the fix. `delay=True` makes that reachable: the
            file is opened on the FIRST record, long after the directory
            was checked, and the user may have deleted it by then.
            """

        # The file half is optional - see `_log_file`. With no writable
        # directory the console half still installs, which is what keeps
        # a traceback off the screen on a read-only box. It writes through
        # the SAME sink loguru writes through - never a `FileHandler` of
        # its own on the same path; that second handle is the defect.
        sink = None
        if log_file is not None:
            try:
                sink = cls._sink_for(log_file)
                fh = SinkHandler(sink, level=logging.DEBUG)
                fh.setFormatter(logging.Formatter(
                    "%(asctime)s %(levelname)s %(name)s: %(message)s"))
                handlers.append(fh)
            except Exception:             # noqa: BLE001 - never block a turn
                pass

        class _Compact(logging.Handler):
            def emit(self, record):       # noqa: D102 - see CompactLogHandler
                CompactLogHandler.render(
                    record,
                    log_path=(sink.current if sink is not None else log_file))

            handleError = _swallow

        try:
            handlers.append(_Compact(level=logging.ERROR))
        except Exception:                 # noqa: BLE001
            pass

        for h in handlers:
            root.addHandler(h)
        # The root default is WARNING, which would drop the DEBUG records
        # the file exists to keep; the console handler has its own ERROR
        # level, so lowering this does not make the console noisier.
        if root.level > logging.DEBUG:
            root.setLevel(logging.DEBUG)
        cls._std_handlers = handlers

    @classmethod
    def _release_stdlib_logs(cls) -> None:
        """Remove the stdlib handlers, closing the file handle with them."""
        if not cls._std_handlers:
            return
        import logging
        root = logging.getLogger()
        for h in cls._std_handlers:
            try:
                root.removeHandler(h)
                h.close()
            except Exception:             # noqa: BLE001
                pass
        cls._std_handlers = []

    #: atexit is registered once, whether or not either half succeeded.
    _atexit_done = False

    @classmethod
    def _log_file(cls):
        """This session's log file, or None if the directory cannot be made.

        One file PER SESSION (`build_engine.<time>.<pid>.log`), never one
        shared `build_engine.log`: a shared file is what a second session,
        an editor or an older process can hold open, and a held file is
        what a size rotation cannot rename on Windows. Nothing here ever
        renames; see `logsink.py` for how the file rolls and ages out.

        Returning None rather than raising is what lets the CONSOLE half
        install anyway: a read-only or unwritable state directory should
        cost the user their log file, not put a traceback back on screen.
        """
        try:
            from ioagentfarm.cli import _root
            log_dir = Path(_root()) / "build_logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            return log_dir / session_log_name()
        except Exception:                     # noqa: BLE001
            return None

    @classmethod
    def quiet_runtime_logs(cls) -> None:
        """Send the runtime's log output to a FILE, not this console.

        In-process, iobot's own sink writes INFO/DEBUG straight to our
        stderr - which buried the build console under tool-call and
        token-usage lines and undid the whole quiet-console design the
        moment the engine landed. The subprocess path never had this: the
        child's stream was filtered at the reader. The records still exist,
        one file under the state directory, so nothing becomes
        undiagnosable.

        The handle is released by :meth:`release_logs`, which the CLI calls
        on the way out - and the sink opens its file on the FIRST record,
        not at install, so a session that never runs a turn leaves no
        handle at all.

        **The two halves are independent, deliberately.** The runtime logs
        through loguru and the providers log through stdlib logging, and
        the first cut of the stdlib half sat INSIDE the loguru try block,
        after `_lg.add` - so a state directory that could not be created,
        or any loguru error at all, was swallowed by one `except` and left
        stdlib logging unhandled, which is the traceback-on-screen defect
        returning silently. That is the `sitecustomize` coupling this
        repository has already paid for once: a thing wired inside a
        condition it has nothing to do with. Each half now fails alone.
        """
        log_file = cls._log_file()
        cls._quiet_stdlib_logs(log_file)      # providers - stdlib logging
        cls._quiet_loguru(log_file)           # the runtime - loguru
        if not cls._atexit_done:
            # Released at process exit whichever way the command leaves -
            # one-shot return, /exit, EOF or an unhandled error. Registering
            # here rather than at each exit point means a new return path
            # cannot silently reintroduce the held handle.
            import atexit
            atexit.register(cls.release_logs)
            cls._atexit_done = True

    @classmethod
    def _quiet_loguru(cls, log_file) -> None:
        """Repoint the runtime's loguru output at *log_file*.

        The sink is OUR object, not a path: a path would make loguru open
        a second handle and run its own rename-based rotation, and any
        error inside loguru's file sink is printed to stderr by its
        `catch` - which is exactly the flood this replaces. Our sink never
        raises, so loguru never has anything to print.
        """
        if cls._log_sink_id is not None or log_file is None:
            return
        try:
            from loguru import logger as _lg
            _lg.remove()
            cls._log_sink_id = _lg.add(
                cls._sink_for(log_file), level="DEBUG",
                colorize=False, enqueue=False)
        except Exception:                     # noqa: BLE001 - never block
            pass

    @classmethod
    def release_logs(cls) -> None:
        """Close the log sink so nothing holds the state directory open."""
        cls._release_stdlib_logs()
        if cls._log_sink_id is not None:
            try:
                from loguru import logger as _lg
                _lg.remove(cls._log_sink_id)   # -> sink.stop() -> close
            except Exception:                 # noqa: BLE001
                pass
            finally:
                cls._log_sink_id = None
        sink, cls._file_log = cls._file_log, None
        if sink is not None:
            sink.close()

    def close(self) -> None:
        """Drop the loop and release the log handle. Idempotent."""
        self.reset()
        self.release_logs()

    def _close_aloop(self) -> None:
        """Close the session's asyncio loop. ONLY from `reset`.

        Closing it while ``_loop`` still exists is the whole bug this
        machinery exists to prevent, so there is no other caller.
        """
        aloop, self._aloop = self._aloop, None
        if aloop is None or aloop.is_closed():
            return
        asyncio.set_event_loop(aloop)
        # 0. THE TURN STOPS BEFORE ANYTHING ELSE RUNS. Ctrl+C out of
        #    `run_until_complete` cancels nothing, so the turn task is
        #    still pending - and every step below resumes the loop, which
        #    RESUMES THAT TASK. Measured consequence: for up to
        #    `_TEARDOWN_S` a cancelled turn kept executing, so a
        #    `write_file` already in flight landed on disk AFTER the
        #    harness had printed "turn cancelled", and its tool line
        #    printed after the next prompt was drawn. Cancelling first
        #    makes the message true.
        try:
            # an open y/n prompt dies with the turn: the waiting gate
            # worker returns without consuming a line
            from ioagentfarm.builder import input_hub
            input_hub.cancel_prompt()
        except Exception:                 # noqa: BLE001 - teardown only
            pass
        turn = getattr(self, '_turn_task', None)
        self._turn_task = None
        if turn is not None and not turn.done():
            turn.cancel()
            _bounded(aloop, asyncio.gather(turn, return_exceptions=True),
                     _TEARDOWN_S, "cancel the turn")
        # 1. MCP first, from its OWNING task. Each server connection is
        #    held open by a task the runtime parks inside the MCP SDK's
        #    `stdio_client` async generator, which holds an anyio cancel
        #    scope - and anyio refuses to exit a scope from a task other
        #    than the one that entered it. `shutdown_asyncgens()` closes
        #    every generator from a NEW task, so with the connection still
        #    parked it raised, and the console printed "an error occurred
        #    during closing of asynchronous generator <stdio_client>
        #    (RuntimeError)" after every Ctrl+C. `close_mcp()` sets the
        #    owner's close event and awaits it; the owner then closes its
        #    own stack, which is the one order that works.
        loop = self._loop
        if loop is not None and hasattr(loop, "close_mcp"):
            _bounded(aloop, loop.close_mcp(), _TEARDOWN_S, "close_mcp")
        # 2. Whatever the cancelled turn left pending - the turn task
        #    itself (Ctrl+C out of `run_until_complete` cancels NOTHING; the
        #    task stays pending) and any helper it spawned.
        try:
            pending = [tk for tk in asyncio.all_tasks(aloop) if not tk.done()]
        except Exception:                     # noqa: BLE001
            pending = []
        for tk in pending:
            tk.cancel()
        if pending:
            _bounded(aloop, asyncio.gather(*pending, return_exceptions=True),
                     _TEARDOWN_S, "pending tasks")
        # 3. Now the generators are all finalized or owned by nobody.
        _bounded(aloop, aloop.shutdown_asyncgens(), _TEARDOWN_S,
                 "shutdown_asyncgens")
        try:
            _bounded(aloop, aloop.shutdown_default_executor(), _TEARDOWN_S,
                     "shutdown_default_executor")
        except Exception:                     # noqa: BLE001 - py<3.9 shape
            pass
        try:
            aloop.close()
        except Exception:                     # noqa: BLE001
            pass
        finally:
            try:
                asyncio.set_event_loop(None)
            except Exception:                 # noqa: BLE001
                pass

    def build(self) -> None:
        """Construct the runtime now. Idempotent; raises what it cannot do.

        The public name exists so a caller can pay the cost - and see the
        failure - at ATTACH time rather than inside the first turn.
        """
        if self._loop is None:
            self._build()

    def _build(self):
        import sys

        self.quiet_runtime_logs()

        from iobot.agent.loop import AgentLoop
        from iobot.bus import MessageBus
        from iobot.config.loader import load_config, set_config_path
        from iobot.config.schema import MCPServerConfig, ToolsConfig
        from iobot.providers.factory import make_provider
        from iobot.session.manager import SessionManager

        from ioagentfarm.cli import _root
        from ioagentfarm.engine.iobot_config import PASSTHROUGH_ENV_KEYS
        from ioagentfarm.engine.workspaces import iobot_agent_workspace

        # The exec tool strips its subprocess PATH; the venv's binaries must
        # be findable, same as the pool.
        venv_bin = str(Path(sys.executable).parent)
        if venv_bin not in os.environ.get("PATH", "").split(os.pathsep):
            os.environ["PATH"] = venv_bin + os.pathsep + os.environ["PATH"]
        os.environ["IOF_ROOT"] = str(_root())
        # The write grant for the repo, consumed by the fs-tool patch at
        # construction time - the same mechanism the pod uses.
        extra = os.environ.get("IOF_IOBOT_EXTRA_ALLOWED_DIRS", "")
        if str(self.repo) not in extra.split(os.pathsep):
            os.environ["IOF_IOBOT_EXTRA_ALLOWED_DIRS"] = (
                (extra + os.pathsep if extra else "") + str(self.repo))

        if self.cfg_path and Path(self.cfg_path).is_file():
            set_config_path(Path(self.cfg_path))
            config = load_config(Path(self.cfg_path))
        else:
            config = load_config(None)

        workspace = iobot_agent_workspace(self.role)
        config.agents.defaults.workspace = str(workspace)
        provider = make_provider(config)

        # THE CEILING FITS THE COMMANDS THE SESSION PRESCRIBES. The exec
        # default is 60s, and the builder's own charter tells the model to
        # run `aicore agent-chat` (an LLM call - minutes on this model),
        # and the install gate exists so the user can approve
        # `pip install -e .` (rarely under 60s cold). Both were approved
        # and then KILLED at 60s with their output discarded. 600 is the
        # runtime's own per-call cap, and the user holds Ctrl+C. A config
        # that says 0 (no limit) is left saying it.
        _exec_t = int(getattr(config.tools.exec, "timeout", 60) or 0)
        exec_cfg = config.tools.exec.model_copy(update={
            "timeout": _exec_t if _exec_t == 0 else max(_exec_t, 600),
            "allowed_env_keys": sorted(set(
                list(config.tools.exec.allowed_env_keys or [])
                + list(PASSTHROUGH_ENV_KEYS)
                + list(INSTALL_ENV_KEYS)))})
        tools_cfg = ToolsConfig(
            web=config.tools.web,
            exec=exec_cfg,
            restrict_to_workspace=config.tools.restrict_to_workspace,
            mcp_servers=config.tools.mcp_servers,
        )

        # THE TIER MERGE, NOT JUST THE MACHINE CONFIG. This read
        # `config.tools.mcp_servers`, which is `~/.iobot/config.json` and
        # NOTHING ELSE - so a build session could not see a server declared
        # by the pack it is editing (`new-mcp-server`) or by the workspace
        # (`mcp-add --workspace`). Found live: Cora declared a server, then
        # could not call a single one of its tools in the same session, and
        # having no signal to the contrary reported it as a configuration
        # problem. Runs never had this bug - `create_instance_config` has
        # always merged - so it was a build-session-only blind spot.
        # `merged_mcp_servers` applies pack -> global -> workspace, honours
        # `enabled: false`, and drops an unset-${VAR} server loudly.
        try:
            from ioagentfarm.engine.iobot_config import merged_mcp_servers
            declared = merged_mcp_servers()
        except Exception as exc:                # noqa: BLE001 - degrade, say so
            logger.warning("build engine: could not merge MCP tiers ({}) - "
                           "falling back to the machine config", exc)
            declared = dict(config.tools.mcp_servers or {})

        mcp: dict = {}
        for name, spec in (declared or {}).items():
            try:
                mcp[name] = spec if isinstance(spec, MCPServerConfig) \
                    else MCPServerConfig.model_validate(spec)
            except Exception as exc:            # noqa: BLE001
                logger.warning("build engine: MCP server {} invalid ({}) - "
                               "skipped", name, exc)

        loop = AgentLoop(
            bus=MessageBus(),
            provider=provider,
            workspace=workspace,
            model=config.agents.defaults.model,
            max_iterations=config.agents.defaults.max_tool_iterations,
            context_window_tokens=config.agents.defaults.context_window_tokens,
            tools_config=tools_cfg,
            session_manager=SessionManager(workspace),
            channels_config=config.channels,
            mcp_servers=mcp,
        )
        for name in ("message", "spawn"):
            if loop.tools.has(name):
                loop.tools.unregister(name)

        # THE PLACEMENT GRANT, in-process: the exec tool's default cwd is the
        # AGENT workspace; a build turn's commands must run in the REPO -
        # the exact trap found live on a client VM, closed here at the tool.
        grant_repo_placement(loop, self.repo)

        self._wrap_gate(loop)
        self._loop = loop
        return loop

    def _wrap_gate(self, loop) -> None:
        gate_ref = self

        for name in MUTATING_TOOLS:
            if not loop.tools.has(name):
                continue
            tool = loop.tools.get(name)
            orig = type(tool).execute

            def _bind(orig_fn, tool_name):
                async def gated(tself, *a, **k):
                    deny = placement_denial(tool_name, k, gate_ref.repo)
                    if deny:
                        return deny
                    leak = secret_denial(tool_name, k)
                    if leak:
                        return leak
                    ask = install_prompt(tool_name, k)
                    if ask is not None:
                        g = gate_ref._install_gate
                        if g is None:
                            return ("[install] refused: this session has no "
                                    "way to ask the user (it is not an "
                                    "interactive terminal). Say which "
                                    "install is needed and why, and let "
                                    "them run it.")
                        if not await _ask_gate(g, "install",
                                               {"command": ask}):
                            return ("[install] declined by the user - do not "
                                    "retry it; say what needed installing "
                                    "and why, and continue without it.")
                    g = gate_ref._gate
                    if g is not None and not await _ask_gate(g, tool_name, k):
                        return ("[approval] denied by the user - do not "
                                "retry the same action; explain what you "
                                "intended and ask how to proceed.")
                    # The harness's own lint of what this write produced is
                    # appended by the `build_write_gates` PATCH, which wraps
                    # the tool CLASS and so covers the one-shot subprocess
                    # path as well as this one. Doing it here too would
                    # append the verdict twice on the in-process path.
                    return await orig_fn(tself, *a, **k)
                return gated

            # instance-level bind so only THIS loop's tools are gated
            import types
            tool.execute = types.MethodType(_bind(orig, name), tool)

        # The read gate is separate and NARROW: it refuses a credential file
        # and nothing else, so it does not carry the install/approval prompts
        # a write does. Ordinary reads are never touched.
        for name in READ_TOOLS:
            if not loop.tools.has(name):
                continue
            tool = loop.tools.get(name)
            orig = type(tool).execute

            def _bind_read(orig_fn, tool_name):
                async def gated(tself, *a, **k):
                    leak = read_denial(tool_name, k)
                    if leak:
                        return leak
                    return await orig_fn(tself, *a, **k)
                return gated

            import types
            tool.execute = types.MethodType(_bind_read(orig, name), tool)

    # ── the public surface ───────────────────────────────────────────────
    def set_install_gate(self, gate) -> None:
        """The channel installs are confirmed through. Independent of the
        general gate, which the user may have turned off.

        Setting it also tells the HARNESS-level guard that this process has
        someone to ask, so it stops refusing installs outright and leaves
        the decision to the prompt. Cleared when there is no channel, which
        is what keeps a one-shot or a CI run refusing as before.
        """
        self._install_gate = gate
        if gate is None:
            os.environ.pop("IOF_BUILD_APPROVAL", None)
        else:
            os.environ["IOF_BUILD_APPROVAL"] = "1"
            # An approved install must FAIL, never ASK: the child inherits
            # this console, and a credential prompt from pip (a private
            # index with a username and no password) reads the keyboard
            # through msvcrt - past the DEVNULL stdin, past the captured
            # pipe, invisible on a screen the spinner owns. Forwarded to
            # the child through INSTALL_ENV_KEYS.
            os.environ.setdefault("PIP_NO_INPUT", "1")

    def set_gate(self, gate: Optional[Callable[[str, dict], bool]]) -> None:
        """None = auto (no prompts). The gate runs in the console thread."""
        self._gate = gate

    def reset(self) -> None:
        """Drop the loop (after a cancelled turn); next turn rebuilds.

        THE TWO LOOPS DIE TOGETHER. The provider's HTTP client is bound to
        the asyncio loop it first ran in, so an AgentLoop that outlives its
        asyncio loop is exactly the failure in `run_turn`'s docstring - and
        an asyncio loop that outlives a cancelled AgentLoop holds that
        loop's half-finished tasks. Neither survives the other.
        """
        # ORDER MATTERS: the AgentLoop holds the MCP connections, and only
        # it can close them on the task that opened them. It used to be
        # dropped FIRST, so `_close_aloop` never saw it and the loop was
        # shut with the connections still parked - see `_close_aloop`.
        self._close_aloop()
        self._loop = None

    def run_turn(self, message: str, full_session_key: str,
                 on_event=None) -> str | None:
        """One turn, on THE session's event loop. The sync entry point.

        WHY THIS IS NOT ``asyncio.run(engine.turn(...))``, which is what it
        replaced. ``asyncio.run`` builds a new event loop per call and
        CLOSES it on return, while ``_loop`` - the AgentLoop, its provider
        and that provider's ``httpx.AsyncClient`` - is deliberately built
        once and cached for the whole session. A pooled keep-alive
        connection belongs to the loop that opened it, so the second turn
        reached into a closed loop and the SDK reported the RuntimeError as
        a network failure::

            AzureOpenAIChat upstream LLM call failed:
            type=APIConnectionError status=None msg=Connection error.
              ...
              File "asyncio/base_events.py", in _check_closed
                raise RuntimeError('Event loop is closed')

        Which read as "the gateway is unreachable" and is nothing of the
        kind - the request never left the machine. It alternated, too, and
        that is the tell: the failure handler calls `reset`, so turn 3
        rebuilt and worked, turn 4 failed, turn 5 worked. A cache whose
        lifetime is longer than the loop it is bound to has to own that
        loop, so the engine owns it here.
        """
        import asyncio

        if self._aloop is None or self._aloop.is_closed():
            self._aloop = asyncio.new_event_loop()
        # Libraries that reach for the ambient loop (`get_event_loop`) must
        # find THIS one, the same as they would under `asyncio.run`.
        asyncio.set_event_loop(self._aloop)
        task = self._aloop.create_task(
            self.turn(message, full_session_key, on_event=on_event))
        self._turn_task = task
        try:
            return self._aloop.run_until_complete(task)
        finally:
            if task.done():
                self._turn_task = None

    async def turn(self, message: str, full_session_key: str,
                   on_event=None) -> str | None:
        """One turn. *full_session_key* already carries ``:u:<uid>``.

        *on_event(kind, payload)* receives display events from the runtime's
        NATIVE progress channel - prose, tool starts, write previews. This
        replaces the session-file watcher in-process, and had to: the
        watcher held a read handle on the JSONL while the SessionManager
        renamed its temp file over it, which on Windows is
        ``PermissionError: [WinError 5]`` - a crash that killed the whole
        REPL on turn 2 of the first long live session. The native channel
        is also better: real-time instead of polled, and it carries the tool
        arguments directly rather than reconstructing them from a
        checkpoint.
        """
        # The task is kept so teardown can CANCEL it: a KeyboardInterrupt
        # out of `run_until_complete` leaves this task pending, and
        # `_close_aloop` has no other way to name it.
        if self._loop is None:
            self._build()

        async def _progress(text: str = "", **kw):
            if on_event is not None:
                map_progress_event(text, kw, on_event)

        out = await self._loop.process_direct(
            content=message, session_key=full_session_key,
            on_progress=_progress)
        await _sweep_exec_sessions(self._loop)
        return out.content if out is not None else None


def map_progress_event(text: str, kw: dict, on_event) -> None:
    """The native progress channel -> display events. Pure, so testable.

    Forwards tool STARTS, tool ENDS (with the result - every call must
    visibly land; calls-without-results read as dead air, the biggest
    measured distance to the Claude Code feel), tool ERRORS, and prose.
    Reasoning chunks are thinking and are never shown - the subprocess
    path's display contract, kept identical here.
    """
    if kw.get("reasoning") or kw.get("reasoning_end"):
        return
    for ev in (kw.get("tool_events") or []):
        phase = (ev or {}).get("phase")
        name = ev.get("name") or "tool"
        if phase == "start":
            on_event("tool", (name, ev.get("arguments") or {}))
        elif phase == "end":
            on_event("result", (name, ev.get("result")))
        elif phase == "error":
            on_event("error", f"{name}: {ev.get('error') or 'failed'}")
    if text and not kw.get("tool_hint"):
        on_event("prose", text)


def bind_repo_relative_paths(tool, repo) -> bool:
    """Make ONE filesystem tool read the relative paths the agent means.

    THE TWO HALVES OF THE SESSION DISAGREED ABOUT WHAT `agents/x` MEANS.
    `exec` runs in the repo, so `aicore new-agent market_researcher` printed
    "Created agents/market_researcher" - repo-relative, and true. But
    `_FsTool` resolves a relative path against the tool's WORKSPACE
    (`security/workspace_policy.resolve_path`), which is the agent's own
    identity home, so the very next call read
    `~/.iobot/agents/cora_build/workspace/agents/market_researcher/...` and
    reported `File not found`. The scaffold had worked; the reader was
    looking somewhere else, and told the model the command had lied.

    The WRITE half is worse than the read half and is why this is a bug
    rather than a preference: `placement_denial` above already resolves a
    relative write against the repo (`Path(repo) / target`), approves it as
    in-repo - and the tool then wrote it into the agent workspace. The one
    thing that guard exists to prevent, passing through the guard.

    `IOBOT_WORKSPACE`, which `cli._invoke_agent` still sets for the
    subprocess path with the comment that it "controls where iobot's
    native file tools resolve relative paths", is READ BY NOTHING in iobot
    0.3.0 - grep it. The subprocess path gets its cwd right and its file
    tools wrong for the same reason this one did.

    Done by wrapping the resolvers rather than by repointing `_workspace`,
    which was the shorter edit and takes two invariants with it: the
    memory-write guard in `_iobot_patches` derives the protected
    `MEMORY.md` from `_workspace`, and `skills/<name>` maps onto the
    runtime's builtin skills. Both keep working untouched.

    Returns True when the tool was bound, so a caller can count them.
    """
    import types
    from pathlib import Path

    if not (hasattr(tool, "_resolve_read") and hasattr(tool, "_resolve_write")):
        return False

    root = Path(repo)
    ws = getattr(tool, "_workspace", None)
    orig_read = tool._resolve_read
    orig_write = tool._resolve_write

    def _repo_path(path):
        """The repo-relative reading of *path*, or None if it is absolute."""
        try:
            p = Path(str(path)).expanduser()
        except (OSError, ValueError):
            return None
        return None if p.is_absolute() else root / p

    def _read(_self, path):
        # Repo first. The FALLBACK is deliberate and read-only: an agent
        # reading `skills/…` or `memory/…` means its own workspace, and
        # only the file's existence can tell the two apart. Writes get no
        # such fallback - a new file has nothing to exist yet, and guessing
        # would put authored content back in the workspace.
        cand = _repo_path(path)
        if cand is not None and not cand.exists() and ws is not None:
            try:
                if (Path(ws) / str(path)).exists():
                    return orig_read(path)
            except (OSError, ValueError):
                pass
        return orig_read(str(cand)) if cand is not None else orig_read(path)

    def _write(_self, path):
        cand = _repo_path(path)
        return orig_write(str(cand)) if cand is not None else orig_write(path)

    # Instance-level, so only THIS session's tools move.
    tool._resolve_read = types.MethodType(_read, tool)
    tool._resolve_write = types.MethodType(_write, tool)
    tool._resolve = types.MethodType(_read, tool)
    return True


def grant_repo_placement(loop, repo) -> None:
    """Point every tool of *loop* at *repo* - exec cwd AND file paths."""
    for tool in loop.tools._tools.values():
        if hasattr(tool, "working_dir"):
            tool.working_dir = str(repo)
        bind_repo_relative_paths(tool, repo)


#: Commands that CHANGE THE ENVIRONMENT. These are not refused - a build
#: session legitimately needs a new console script on PATH after
#: `new-tool` - but they are never silent either: the user is asked every
#: time, even with the general approval gate off, which is the Claude Code
#: shape. The harness used to deny them outright, so the assistant printed
#: an instruction and the user ran it in another terminal.
_INSTALL_RE = (
    # The anchor keeps `echo "pip install ..."` from prompting, but it also
    # meant a PREFIXED form slipped past: `sudo npm install` matched the
    # one-shot refusal (which uses \b) and not this prompt, so the one
    # context that can ask was the one that ran it silently. Prefixes that
    # merely wrap the real command are stepped over.
    r"(^|[;&|]\s*)(sudo\s+|env\s+\S+=\S+\s+)*("
    r"pip\s+(install|uninstall)"
    r"|python\s+-m\s+pip\s+(install|uninstall)"
    r"|uv\s+pip\s+(install|uninstall)"
    r"|npm\s+(install|i|ci|link)"
    # The pnpm/yarn lines used to end in a LITERAL BACKSPACE byte - a
    # \b resolved into 0x08 on its way into the raw string - so the
    # pattern required a backspace after "install" and those two
    # package managers were never prompted at all.
    r"|pnpm\s+(add|install)"
    r"|yarn\s+(add|install)"
    r"|uv\s+(add|sync|remove|tool\s+install)"
    r"|poetry\s+(add|install|remove)"
    r"|pipx\s+(install|uninstall)"
    r"|conda\s+(install|remove)"
    r")")


def install_prompt(name: str, kwargs: dict) -> str | None:
    """The command to confirm, or None when nothing is being installed."""
    import re
    if name != "exec":
        return None
    cmd = str(kwargs.get("command") or kwargs.get("cmd") or "")
    return cmd if re.search(_INSTALL_RE, cmd, re.IGNORECASE) else None
