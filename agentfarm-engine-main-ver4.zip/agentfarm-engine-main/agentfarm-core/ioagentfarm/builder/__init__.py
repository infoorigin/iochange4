"""`aicore build` - an interactive build session with the platform builder.

The desk-side authoring loop: you talk, the assistant designs solution
content AND places it, by running the same scaffold commands a person would
(`new-solution`, `new-agent`, `new-skill`, `new-workflow`) and then writing
the real content into the files those commands created. Local only - this
spawns the agent on this machine, in this directory, and never contacts a
server.

WHY THIS IS THIN. Every load-bearing piece already exists and is already
proven on another path:

* **The session is the agent's own JSONL.** A session key is stable across
  invocations, so the runtime's native session store IS the conversation -
  nothing new persists anything. The key includes a digest of the repo path,
  so each project gets its own continuing conversation and switching
  directories switches context.
* **The spawn is ``cli._invoke_agent``** - the same one every workflow step
  goes through, with the byte-level CR/LF reader, the rebrand and the
  venv-first PATH. ``project_dir=<repo>`` is the standard mechanism by which
  step agents read and write project files; it is the write grant, not a new
  hole.
* **The instance config** is the ad-hoc one the chat path builds, so the
  assistant's own tools (`aicore new-skill`, `lint-workflow`, `git status`)
  inherit IOF_ROOT and the database exactly as they do in a run.

The judgement lives in the assistant's ``solution_builder`` skill, which the
first turn of a session instructs her to load: scaffold with the named
command and never hand-create its files; write content only into files the
scaffold just made; never ``--force``; install only with the user's yes at
the prompt; lint what changed; end with ``git status``. Git is the undo.

Deliberately NOT here: the served path. A pod's agents have no repo
and is shared by a team; this command exists so that placement happens where
the files are - at a desk, in a working tree the user can see.

THE LAYOUT. One module per concern, because ``cli_build.py`` reached 1,400
lines of which a single function was 493:

===================  ====================================================
``session.py``       state file, session key, the JSONL, the preamble
``console.py``       the glyph set and a console that cannot crash
``events.py``        session record -> display events for the live view
``checkpoints.py``   per-turn git checkpoints: capture, diff, undo
``refs.py``          ``@file``, repo macros, transcript, CORABUILD.md memory
``turn.py``          one turn (spawn or in-process) + prompt wrappers
``engine.py``        the in-process turn engine
``repl.py``          the command: options, slash commands, the loop
===================  ====================================================
"""
from __future__ import annotations

from ioagentfarm.builder.repl import register_commands

__all__ = ["register_commands"]
