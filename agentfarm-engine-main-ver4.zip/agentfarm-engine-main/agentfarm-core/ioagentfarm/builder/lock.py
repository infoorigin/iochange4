"""One conversation, one writer.

The runtime session store REWRITES the whole JSONL from memory on every
save, and the build state is merged per-conversation-name - so two build
sessions holding the same conversation silently overwrite each other's
turns, and on Windows they fight over one ``.jsonl.tmp`` (`WinError 32`
per tool call). Nothing locked anything.

This module is the lock: one file per (repo digest, conversation suffix)
under ``<IOF_ROOT>/build_sessions/``, created with ``O_EXCL``, carrying
the holder's pid and host. A lock whose holder is dead on THIS host is
stale and replaced. Two conversations in one repository stay independent
- ``aicore build --session other`` in a second terminal is the supported
parallel shape, exactly as two Claude Code sessions in one checkout are.

Liveness on Windows deliberately avoids ``os.kill(pid, 0)``: on Windows
``os.kill`` does not probe - anything but the two CTRL events calls
``TerminateProcess``. ``OpenProcess`` + ``GetExitCodeProcess`` asks
without touching.
"""
from __future__ import annotations

import json
import os
import socket
import time
from pathlib import Path

from loguru import logger

STILL_ACTIVE = 259


def _alive(pid: int) -> bool:
    """Is *pid* a running process on this host? Conservative: unsure = yes."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            handle = k32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED
            if not handle:
                return False
            try:
                code = ctypes.c_ulong()
                if k32.GetExitCodeProcess(handle, ctypes.byref(code)):
                    return code.value == STILL_ACTIVE
                return True
            finally:
                k32.CloseHandle(handle)
        except Exception:                  # noqa: BLE001 - unsure = alive
            return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return True


class ConversationLock:
    """The exclusive right to write one conversation's record."""

    def __init__(self, root: Path, digest: str, suffix: str):
        safe = "".join(c if c.isalnum() or c in "-_." else "_"
                       for c in str(suffix)) or "main"
        self.path = Path(root) / "build_sessions" / f"{digest}.{safe}.lock"
        self.held = False

    # ── reading ──────────────────────────────────────────────────────────
    def holder(self) -> dict | None:
        """Who holds it - ``{pid, host, since}`` - or None."""
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else None
        except (OSError, ValueError):
            return None

    def _stale(self, data: dict | None) -> bool:
        """A lock is stale when its holder is provably gone.

        A holder on ANOTHER host is never provable from here, so it is
        never stale - the conservative direction for a lock whose job is
        stopping silent data loss.
        """
        if not data:
            return True                    # unreadable = a torn write
        if str(data.get("host") or "") != socket.gethostname():
            return False
        return not _alive(data.get("pid"))

    # ── taking and releasing ─────────────────────────────────────────────
    def acquire(self) -> bool:
        """Take the lock. False means a LIVE peer holds it."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps({
            "pid": os.getpid(), "host": socket.gethostname(),
            "since": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })
        for attempt in (1, 2):
            try:
                fd = os.open(str(self.path),
                             os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    fh.write(payload)
                self.held = True
                return True
            except FileExistsError:
                data = self.holder()
                if (data and str(data.get("host") or "")
                        == socket.gethostname()
                        and int(data.get("pid") or 0) == os.getpid()):
                    # RE-ENTRANT within one process: a wrapper that drives
                    # several one-shot turns (or a test harness invoking
                    # the CLI in-process) is one writer, not two.
                    self.held = True
                    return True
                if not self._stale(data):
                    return False
                # a dead holder's lock: take it over, once
                try:
                    self.path.unlink()
                except OSError:
                    return False
            except OSError:
                # a filesystem that cannot lock must not block the session
                logger.debug("conversation lock unavailable", exc_info=True)
                return True
        return False

    def release(self) -> None:
        """Let go - only of a lock this object took."""
        if not self.held:
            return
        self.held = False
        try:
            data = self.holder()
            if data and int(data.get("pid") or 0) == os.getpid():
                self.path.unlink()
        except (OSError, ValueError):
            logger.debug("conversation lock release failed", exc_info=True)


def acquire_conversation(s) -> bool:
    """Point the session's lock at its ACTIVE conversation.

    Releases whatever it held before, so `/new`, `/switch` and `/compact`
    re-lock by calling this again. Returns False - with the holder printed
    - when a live peer owns the conversation; the caller decides whether
    to divert or refuse.
    """
    old = getattr(s, "lock", None)
    if old is not None:
        old.release()
    _, sess = s.active()
    lock = ConversationLock(s.root, s.digest, sess.get("suffix") or "main")
    if lock.acquire():
        s.lock = lock
        return True
    s.lock = None
    return False


def holder_line(s) -> str:
    """One line naming who holds the active conversation."""
    _, sess = s.active()
    data = ConversationLock(s.root, s.digest,
                            sess.get("suffix") or "main").holder() or {}
    pid = data.get("pid", "?")
    since = data.get("since", "?")
    return f"pid {pid}, since {since}"
