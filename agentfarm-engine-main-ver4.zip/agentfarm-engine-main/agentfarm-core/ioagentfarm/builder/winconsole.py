"""QuickEdit off for the session, back on at exit (backlog H18).

On conhost, selecting text with the mouse - QuickEdit mode, ON by default
- BLOCKS every write to the console until the selection is dismissed.
The chain under a build turn: Rich's refresh thread blocks mid-write
holding the console lock, the ticker blocks behind it, and anything else
that wants the screen queues up - to the user it is indistinguishable
from a model stall, and it is triggered by a reflex (drag to copy an
error message).

The render path no longer lets a stuck console reach the event loop (the
turn's display is producer/consumer now), so a selection freezes only
the DISPLAY. This module removes the trigger too: the session clears
ENABLE_QUICK_EDIT_MODE on its console and restores the exact prior mode
on exit. Windows Terminal ignores the flag (it has no blocking
QuickEdit), which makes this a no-op there - the correct behaviour.

``IOF_BUILD_QUICKEDIT=keep`` leaves the console untouched for anyone who
wants mouse-select during a session more than they mind the freeze.
"""
from __future__ import annotations

import os

STD_INPUT_HANDLE = -10
ENABLE_QUICK_EDIT_MODE = 0x0040
ENABLE_EXTENDED_FLAGS = 0x0080


def _kernel32():
    """Separate for tests: a fake with GetStdHandle/GetConsoleMode/
    SetConsoleMode stands in for the real DLL."""
    import ctypes
    return ctypes.windll.kernel32


def disable_quickedit() -> int | None:
    """Turn QuickEdit off. Returns the PRIOR mode as the restore token,
    or None when nothing was changed (not Windows, opted out, no console,
    or QuickEdit already off) - and None means `restore` does nothing."""
    if os.name != "nt":
        return None
    if os.environ.get("IOF_BUILD_QUICKEDIT", "").strip().lower() == "keep":
        return None
    try:
        import ctypes
        k32 = _kernel32()
        handle = k32.GetStdHandle(STD_INPUT_HANDLE)
        if not handle:
            return None
        mode = ctypes.c_ulong()
        if not k32.GetConsoleMode(handle, ctypes.byref(mode)):
            return None                    # not a real console (redirected)
        if not (mode.value & ENABLE_QUICK_EDIT_MODE):
            return None                    # already off - nothing to restore
        new = (mode.value | ENABLE_EXTENDED_FLAGS) & ~ENABLE_QUICK_EDIT_MODE
        if not k32.SetConsoleMode(handle, new):
            return None
        return int(mode.value)
    except Exception:                      # noqa: BLE001 - a convenience,
        return None                        # never a startup failure


def restore(token: int | None) -> None:
    """Put the console mode back exactly as it was. Token None = no-op."""
    if token is None or os.name != "nt":
        return
    try:
        k32 = _kernel32()
        handle = k32.GetStdHandle(STD_INPUT_HANDLE)
        if handle:
            k32.SetConsoleMode(handle, int(token))
    except Exception:                      # noqa: BLE001 - leaving
        pass
