"""The build session's log file: one handle, one file per session, silent.

`aicore build` sends everything the runtime and the providers log to a file
under the state directory so the console stays quiet. This is the sink both
halves write through - loguru (the runtime) via the stream protocol
(`write` / `flush` / `stop`), stdlib logging (the providers) via
:class:`SinkHandler`. Three properties, each the fix for a defect that put a
traceback on the user's screen:

* **One handle per file.** The first version opened the SAME file twice - a
  stdlib ``FileHandler`` and a loguru file sink - and gave loguru a size
  rotation. On Windows a rename of a file with any other open handle fails
  (``[WinError 32]``), and loguru retries the rename on EVERY record once
  the file is past its size, printing ``--- Logging error in Loguru
  Handler #1 ---`` plus the record plus the traceback each time, straight
  onto the console, for the rest of the session. Deterministic once the log
  passed 5 MB, and it read like a flood of old errors when every one was a
  live record that could not be written.
* **Rolling opens a NEW file; nothing is ever renamed.** A file another
  handle holds - a second session in the same directory, an editor, an
  older process - can be left alone; the writer just moves on to a sibling.
  Retention deletes the oldest siblings and SKIPS any it cannot delete.
* **No path prints.** Every operation is wrapped; a write that cannot happen
  drops the record and the next one retries the open. The log is a file
  the user opens if they want it, never something the console shows.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Optional


def session_log_name(prefix: str = "build_engine", now: Optional[float] = None,
                     pid: Optional[int] = None) -> str:
    """``build_engine.20260819-012535.24700.log`` - time then pid.

    Time first so a directory listing reads chronologically; the pid so
    two sessions started in the same second never share a file.
    """
    stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(now))
    return f"{prefix}.{stamp}.{pid if pid is not None else os.getpid()}.log"


class SessionLogFile:
    """A file sink that never raises and never renames.

    ``path`` is this session's file. When it grows past :attr:`max_bytes`
    the writer closes it and opens a numbered sibling
    (``<stem>-2.log``, ``-3`` ...); the earlier parts stay where they are.
    :attr:`keep` bounds how many ``<prefix>*.log`` files the directory holds
    across sessions - older ones are pruned at open and at each roll, and a
    file that refuses deletion (held open elsewhere) is left for next time.
    """

    #: Roll to a new part once the current file passes this many bytes.
    max_bytes = 5 * 1024 * 1024
    #: Files kept per directory (newest by mtime), this session's included.
    keep = 10
    #: The deletion primitive - a seam for tests; retention must skip a file
    #: it cannot delete rather than report it.
    _remove = staticmethod(os.remove)

    def __init__(self, path) -> None:
        self.path = Path(path)
        #: loguru and stdlib each serialize on their OWN handler lock, so a
        #: runtime thread and a provider thread can enter `write` together;
        #: without this both would open the file and one handle would leak.
        self._lock = threading.RLock()
        self._file = None
        self._current: Optional[Path] = None
        self._size = 0
        self._part = 1
        self.closed = False

    # ── what loguru's StreamSink and our SinkHandler call ────────────────
    def write(self, text: str) -> None:
        """Append *text*. Never raises; a failed write drops the record."""
        try:
            with self._lock:
                if self._file is None and not self._open(self._next_path()):
                    return
                if self._size > self.max_bytes:
                    self._roll()
                    if self._file is None:
                        return
                self._file.write(text)
                self._size += len(text)
        except Exception:                 # noqa: BLE001 - see module doc
            self._drop()

    def flush(self) -> None:
        try:
            with self._lock:
                if self._file is not None:
                    self._file.flush()
        except Exception:                 # noqa: BLE001
            self._drop()

    def stop(self) -> None:
        """loguru calls this on `logger.remove(id)`."""
        self.close()

    def close(self) -> None:
        """Release the handle. Idempotent; a later write reopens."""
        with self._lock:
            self._drop()
            self.closed = True

    @property
    def current(self) -> Path:
        """The file records go to right now - the base path until one opens."""
        return self._current or self.path

    # ── internals ────────────────────────────────────────────────────────
    def _next_path(self) -> Path:
        if self._part == 1:
            return self.path
        return self.path.with_name(
            f"{self.path.stem}-{self._part}{self.path.suffix}")

    def _open(self, path: Path) -> bool:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            self._file = open(path, "a", encoding="utf-8", errors="replace",
                              buffering=1)
            self._current = path
            self.closed = False
            try:
                self._size = path.stat().st_size
            except OSError:
                self._size = 0
            self._prune()
            return True
        except Exception:                 # noqa: BLE001
            self._drop()
            return False

    def _roll(self) -> None:
        self._drop()
        self._part += 1
        self._open(self._next_path())

    def _drop(self) -> None:
        with self._lock:
            f, self._file = self._file, None
        if f is not None:
            try:
                f.close()
            except Exception:             # noqa: BLE001
                pass

    def _prune(self) -> None:
        """Keep the newest :attr:`keep` files of this prefix; skip the stuck.

        Newest by mtime, so a live file - which is being appended to - stays
        near the top whichever session owns it. Old-scheme files
        (``build_engine.log`` and loguru's own renamed rotations) match the
        same glob and age out the same way.
        """
        try:
            prefix = self.path.name.split(".", 1)[0]
            files = [p for p in self.path.parent.glob(f"{prefix}*.log")
                     if p != self._current]
            files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            for old in files[max(self.keep - 1, 0):]:
                try:
                    self._remove(old)
                except OSError:
                    pass                  # held elsewhere - next time
        except Exception:                 # noqa: BLE001
            pass


class SinkHandler(logging.Handler):
    """Stdlib records into the same :class:`SessionLogFile` - no second handle.

    `handleError` is replaced because `logging.raiseExceptions` is on by
    default and the stdlib version prints ``--- Logging error ---`` and a
    traceback to stderr - the output this file exists to remove.
    """

    def __init__(self, sink: SessionLogFile, level=logging.DEBUG) -> None:
        super().__init__(level)
        self.sink = sink

    def emit(self, record) -> None:      # noqa: D102
        try:
            self.sink.write(self.format(record) + "\n")
        except Exception:                 # noqa: BLE001
            self.handleError(record)

    def flush(self) -> None:            # noqa: D102
        self.sink.flush()

    def handleError(self, record) -> None:   # noqa: ARG002, N802
        """A failed log write must never print."""
