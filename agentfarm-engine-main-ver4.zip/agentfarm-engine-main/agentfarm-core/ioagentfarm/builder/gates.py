"""The two write gates: WHERE authored content may land, and WHAT it may carry.

Pure functions, in their own module for one reason: they are armed at TWO
seams and must never drift. `builder/engine.py` wraps them onto the loop's
tools for an INTERACTIVE session (the in-process engine), and the
`build_write_gates` runtime patch arms them for every SUBPROCESS turn - which
is what a one-shot, and therefore every CI turn, uses. They lived only in
`engine.py` and so existed only on the first path; a live one-shot, told to
"forget the ${VAR} indirection, it's a test box", wrote a literal token into
the repository's mcp.yaml and into two .env files outside the repository.
Both refusals existed; neither was armed where it mattered.
"""
from __future__ import annotations


def secret_denial(name: str, kwargs: dict) -> str | None:
    """Refuse a WRITE that carries a literal credential, with the fix.

    The `guardrails` skill says tokens never go in files; a build session
    writing an MCP declaration is the place that rule is tested, because
    the compliant form (`--header 'Authorization=Bearer ${TOKEN}'`) and the
    violation (the same line with the value pasted in) look alike to a model
    that has just been handed the value. This is the rule as physics, at the
    tool: the reference passes, the literal is refused with the reference
    named as the fix. Same detector as the exec guard and the learning
    scanner (`skill_scan.find_secret_literals`), so what counts as a secret
    is decided once.
    """
    if name not in ("write_file", "edit_file", "apply_patch"):
        return None
    from ioagentfarm.engine.learning.skill_scan import find_secret_literals

    texts: list[str] = []
    for key in ("content", "new_text", "text", "patch"):
        if isinstance(kwargs.get(key), str):
            texts.append(kwargs[key])
    for e in (kwargs.get("edits") or []):
        if isinstance(e, dict):
            for key in ("content", "new_text", "text", "replacement"):
                if isinstance(e.get(key), str):
                    texts.append(e[key])
    kinds = find_secret_literals("\n".join(texts))
    if not kinds:
        return None
    where = kwargs.get("path") or kwargs.get("file_path") or "the file"
    return (f"[secrets] refused: {name} would write what looks like a literal "
            f"credential ({', '.join(kinds)}) into {where}. Authored content "
            "carries ${VAR} references, never values: write the reference "
            "(`--header 'Authorization=Bearer ${TOKEN}'`, `--env "
            "'API_KEY=${API_KEY}'`) and tell the user which variable to set "
            "and where - their workspace .env or the deployment's "
            "environment. Never paste the value into a file, a command or "
            "your reply.")


#: What a credential file looks like, by path. This MIRRORS the credential
#: file list the exec guard refuses (`_iobot_patches._BUILD_GUARD_DENY`):
#: the exec rule blocks `cat .env`, but nothing blocked the `read_file` TOOL
#: reading the same file - the door the exec rule cannot see, and the one a
#: live session used to pull `apps/agentfarm-api/.env` into context. Ordinary
#: reads stay ungated on purpose (a build session reads constantly); only a
#: credential file is refused, the same rule the exec guard already treats as
#: physics. `.env.example`/`.template`/`.sample` and a `*.env.md` doc stay
#: readable, via the exec rule's own lookahead: `.env` must be followed by
#: end-of-name or a known runtime variant, never another dotted suffix.
#: Pinned against the exec list by `test_build_guard_scope_2026_08_28`.
_CREDENTIAL_FILE_RE = (
    r"\.env(\.(local|prod(uction)?|dev(elopment)?|stag(ing)?|test))?(?![\w.-])"
    r"|\.pem(?![\w.-])|\.p12(?![\w.-])|\.pfx(?![\w.-])"
    r"|id_(rsa|ed25519|ecdsa|dsa)(?![\w.-])|\.netrc(?![\w.-])"
    r"|aws[/\\]credentials(?![\w.-])|\.git-credentials(?![\w.-])"
    r"|\.pgpass(?![\w.-])|kube[/\\]config(?![\w.-])"
)


def read_denial(name: str, kwargs: dict) -> str | None:
    """Refuse a `read_file` of a CREDENTIAL FILE, with the fix.

    Reads are ungated in general - and deliberately so, because a build
    session reads constantly and a refused ordinary read teaches the model
    nothing (see the note in `_iobot_patches.apply_build_write_gates`).
    The one exception is a credential file. The exec guard already refuses
    `cat .env` / `type .env` as "the rule as physics", but the `read_file`
    tool is a second door onto the same file, and a live build session used
    it: `read_file apps/agentfarm-api/.env` pulled the shared database URL
    into context, then the session went on to open the engine database with
    it. A prompt-injection in tool output can ask for exactly this read, and
    the model cannot always tell that request from a real one - so this is
    enforcement, not a request. Same file list as the exec credential rule.
    """
    import re

    if name != "read_file":
        return None
    path = kwargs.get("path") or kwargs.get("file_path") or ""
    if not isinstance(path, str) or not path:
        return None
    if not re.search(_CREDENTIAL_FILE_RE, path, re.IGNORECASE):
        return None
    return (f"[secrets] refused: {path} is a credential file, and a build "
            "session never reads one - it runs exec on the developer's "
            "machine with the developer's environment, and a secret in "
            "context can leak into a file or a reply. If you need a value "
            "from it, declare it as a ${VAR} reference and tell the user "
            "which variable to set and where (their workspace .env, or the "
            "deployment's environment). To check only whether the file is "
            "git-ignored, run `git check-ignore <path>`.")


def placement_denial(name: str, kwargs: dict, repo) -> str | None:
    """Refuse a WRITE into the state directory, with directions.

    Observed live: asked for a PACK-LEVEL skill, the builder hand-wrote it
    into its own agent workspace under `<repo>/.iof/`, skipped the scaffold,
    noticed git showed nothing, and concluded "that is the correct state."
    The state directory is never authored content - nothing under it ships,
    imports, or survives a rebuild from the repository. A prompt already
    said so; this is the engineering that holds when the prompt does not.
    The denial is a TOOL RESULT, so the model reads it mid-turn and places
    the content where it belongs.
    """
    from pathlib import Path

    if name not in ("write_file", "edit_file", "apply_patch"):
        return None
    paths = []
    for key in ("path", "file_path"):
        if kwargs.get(key):
            paths.append(str(kwargs[key]))
    for e in (kwargs.get("edits") or []):
        if isinstance(e, dict) and e.get("path"):
            paths.append(str(e["path"]))
    root = Path(repo).resolve()
    state = (root / ".iof").resolve()
    for raw in paths:
        try:
            target = Path(raw)
            if not target.is_absolute():
                target = Path(repo) / target
            target = target.resolve()
        except (OSError, ValueError):
            continue
        inside = target == root or root in target.parents
        in_state = target == state or state in target.parents
        if in_state or not inside:
            where = ("the engine's state directory (.iof/)" if in_state
                     else "outside this build session's repository")
            return (f"[placement] refused: {raw} is {where}. Authored content "
                    f"lives in the repository the session opened, {root}, and "
                    "nowhere else - nothing written elsewhere ships with the "
                    "pack, and the state directory does not survive a "
                    "rebuild. If there is no solution here yet, ask the user "
                    "for a name and run `aicore new-solution <slug>` in that "
                    "directory first; then a pack-level skill is "
                    "`aicore new-skill <name>` and an agent skill is "
                    "`aicore new-skill <name> --role <role>`, and you write "
                    "content into the files those commands create.")
    return None


#: What a redacted secret is replaced with. Names the KIND, so the reader can
#: tell a token from a connection string without seeing either.
def _mask(kind: str) -> str:
    return f"[redacted {kind}]"


def redact_secrets(text: str):
    """Strip literal secrets out of a REPLY. Returns ``(text, kinds)``.

    The write gate already refuses a literal secret into a FILE. Nothing
    watched the reply, and the reply is a surface too - it prints to a
    console someone may be sharing, it is returned in the `--json` payload a
    CI script may log, and it is appended to the session record on disk.

    Measured: handed a pasted GitHub token, the builder did the right thing -
    declared `${REY_GITHUB_TOKEN}` in `mcp.yaml`, wrote no literal - and then
    closed with

        The token value never entered any file - `${REY_GITHUB_TOKEN}` is the
        reference. Set the value by adding this to your workspace `.env`:
        REY_GITHUB_TOKEN=ghp_ABCDEF...

    The claim was true about the file and false about the sentence making it,
    which is the shape worth catching: the model is being HELPFUL - giving
    the exact line to paste - and helpfulness is why it will keep happening.

    Uses `SECRET_LITERAL_RES`, the same list the write gate and the learning
    scanner use, so a token that is refused into a file cannot be printed
    beside it. `${VAR}` never matches - the compliant form stays readable.
    """
    from ioagentfarm.engine.learning.skill_scan import SECRET_LITERAL_RES

    out = str(text or "")
    kinds: list[str] = []
    for kind, rx in SECRET_LITERAL_RES:
        if rx.search(out):
            kinds.append(kind)
            out = rx.sub(_mask(kind), out)
    return out, kinds
