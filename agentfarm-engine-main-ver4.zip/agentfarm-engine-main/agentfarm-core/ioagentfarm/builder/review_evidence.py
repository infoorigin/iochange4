"""Hand the reviewer the facts, instead of asking it to go and get them.

THE INCIDENT. A review turn declared an existing, lint-clean directory
nonexistent. The fix at the time was EVIDENCE RULES in the charter: state
facts about the repository only from what you observed; quote a failed
command verbatim; never translate a tool refusal into a claim about the tree;
"before claiming any path is missing, list its parent directory and quote what
you saw."

Every one of those is a REQUEST, and this repository has measured what a
request is worth twice over. The sleep-poll ban lived in an `always: true`
skill AND in the user's own prompt, was verifiably injected at 9.4k
characters, and was ignored - enforcing it in `build_exec_guard` took the same
request from 55 tool calls to 7. The charter is the same shape: it asks the
model to spend a tool call proving a negative, and the failure mode it guards
is precisely a model that thinks it already knows.

So this module does the listing the charter asks for, before the turn starts,
and puts the answer in the prompt. A reviewer cannot claim a directory is
missing when its contents are printed above the diff. That is prevention.

The second half is detection, and it belongs here for the same reason
`_CLAIMS_CLEAN` lives beside the lint verdict: a reply that contradicts the
harness is contradicted BY NAME, so a wrong finding costs the reviewer its
credibility rather than costing the user an afternoon.

WHAT THIS IS NOT. It is not a second reviewer, and it does not judge. It
reports what is on disk, what the linters say, and what does not parse -
facts the harness already computes for the write path. The judgement stays
with the model; only the ground truth is taken away from it.
"""
from __future__ import annotations

import re
from pathlib import Path

#: `diff --git a/<path> b/<path>` - the paths a diff touches. Read from the
#: header rather than the +++/--- lines because those carry /dev/null for an
#: add or a delete, and a review of a NEW file is exactly when the reviewer
#: is most likely to guess about its surroundings.
_DIFF_PATH = re.compile(r"^diff --git a/(.+?) b/(.+?)$", re.M)

#: How many siblings to print for one directory. A scaffolded agent
#: workspace is small; a `node_modules` is not, and the point is to answer
#: "does this exist and what is beside it", not to paste a tree.
_MAX_SIBLINGS = 25

#: How many touched paths get the full treatment.
_MAX_PATHS = 20


def touched_paths(diff: str) -> list[str]:
    """Repo-relative paths the diff names, in order, without duplicates."""
    seen: dict[str, None] = {}
    for a, b in _DIFF_PATH.findall(diff or ""):
        for p in (a, b):
            p = p.strip()
            if p and p != "/dev/null":
                seen.setdefault(p, None)
    return list(seen)


def _listing(directory: Path, repo: Path) -> list[str]:
    try:
        names = sorted(p.name + ("/" if p.is_dir() else "")
                       for p in directory.iterdir())
    except OSError:
        return []
    return names[:_MAX_SIBLINGS]


def evidence_block(repo, diff: str) -> str:
    """The facts about every path this diff touches, as the reviewer's prompt.

    Returns "" when there is nothing to say, so a review of a diff that
    touches no resolvable path is not padded with an empty section.
    """
    repo = Path(repo)
    paths = touched_paths(diff)[:_MAX_PATHS]
    if not paths:
        return ""

    lines: list[str] = []
    listed: set[str] = set()

    for rel in paths:
        p = (repo / rel)
        exists = p.exists()
        lines.append(f"  {rel}: {'EXISTS' if exists else 'ABSENT'}")

        # The parent listing is the exact command the charter asks the model
        # to run before claiming a path is missing. Printed once per parent.
        parent = p.parent
        try:
            parent_rel = str(parent.relative_to(repo)).replace("\\", "/")
        except ValueError:
            continue
        if parent_rel in listed:
            continue
        listed.add(parent_rel)
        if not parent.is_dir():
            lines.append(f"    parent {parent_rel}/ does not exist")
            continue
        names = _listing(parent, repo)
        shown = ", ".join(names) if names else "(empty)"
        lines.append(f"    {parent_rel}/ contains: {shown}")

    verdicts = _lint_and_diagnostics(repo, paths)
    if verdicts:
        lines.append("")
        lines.extend(verdicts)

    return ("[evidence] The harness observed the following on disk BEFORE this "
            "review. These are facts, not claims; a finding that contradicts "
            "them is wrong and will be reported as such.\n"
            + "\n".join(lines))


def _lint_and_diagnostics(repo: Path, paths: list[str]) -> list[str]:
    """What the linters and the parsers already say about these files.

    The same code the write path runs, so the reviewer sees exactly the
    verdict the author saw - and cannot report a lint failure the harness
    does not have, or miss one it does.
    """
    out: list[str] = []
    try:
        from ioagentfarm.builder import verify as _verify
        for v in _verify.verify_paths(paths, repo):
            out.append("  " + v["text"].replace("\n", "\n  "))
    except Exception:                                  # noqa: BLE001
        pass
    try:
        from ioagentfarm.builder import diagnostics as _diag
        said = _diag.verdict_text(paths, repo)
        if said:
            out.append("  " + said.replace("\n", "\n  "))
    except Exception:                                  # noqa: BLE001
        pass
    return out


#: A reviewer asserting absence. Deliberately narrow: it must match a CLAIM
#: about the tree, not an ordinary sentence containing the word "missing"
#: ("the docstring is missing a line" is a legitimate finding about content).
_CLAIMS_ABSENT = re.compile(
    r"(?:does not exist|doesn'?t exist|no such (?:file|directory)|"
    r"is not present|was not found|not found in the repo(?:sitory)?|"
    r"never created|does not appear to exist)",
    re.I)

#: A path-shaped token in the same sentence as the claim.
_PATH_TOKEN = re.compile(r"[\w./\\-]*[/\\][\w./\\-]+|\b[\w-]+\.(?:md|ya?ml|py|json|toml)\b")


def contradictions(repo, reply: str) -> list[str]:
    """Claims of absence in *reply* that the repository disproves.

    Sentence-scoped: a claim and the path it names have to appear together,
    or a reply that mentions twelve files and one absence would attribute the
    claim to all twelve.
    """
    repo = Path(repo)
    found: list[str] = []
    seen: set[str] = set()
    for sentence in re.split(r"(?<=[.;:\n])\s+", reply or ""):
        if not _CLAIMS_ABSENT.search(sentence):
            continue
        for token in _PATH_TOKEN.findall(sentence):
            rel = token.strip("`'\"()[],").replace("\\", "/")
            if not rel or rel in seen:
                continue
            candidate = repo / rel
            if candidate.exists():
                seen.add(rel)
                kind = "directory" if candidate.is_dir() else "file"
                found.append(
                    f"the reply says {rel} does not exist; the harness sees "
                    f"that {kind} on disk")
    return found
