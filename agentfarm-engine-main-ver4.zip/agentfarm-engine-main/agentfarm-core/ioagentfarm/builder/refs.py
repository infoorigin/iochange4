"""@file references, repo macros, transcript tail and CORABUILD.md memory."""
from __future__ import annotations

import json
from pathlib import Path

from ioagentfarm.builder.console import _glyphs, bracket


_FILE_REF = None                          # compiled lazily; see below
_REF_MAX_BYTES = 8_192
_REF_MAX_FILES = 3


def _inside(repo: Path, path: Path) -> bool:
    """Is *path* under *repo* once symlinks and `..` are resolved?

    Resolved on BOTH sides, because the check is worthless otherwise: the
    reference is written relative to the repo, so `../` walks out of it by
    construction, and a symlink inside the repo can point anywhere.
    Unresolvable (a path the OS refuses to stat) counts as outside - the
    fail-closed direction for a read that leaves the session's scope.
    """
    try:
        base = repo.resolve()
        target = path.resolve()
    except (OSError, ValueError, RuntimeError):
        return False
    return target == base or base in target.parents


def _expand_file_refs(repo: Path, text: str, console=None) -> str:
    """`@relative/path` pulls the file into the message, fenced and capped.

    The precision feature: "fix @skills/x/SKILL.md" hands the builder the
    exact bytes instead of hoping it reads the right file. Deterministic and
    harness-side - the expansion happens before the model sees anything.
    Unknown paths stay literal with a console warning; binary-ish or
    oversized content is truncated at the cap so one @ cannot flood a turn.
    """
    import re
    global _FILE_REF
    if _FILE_REF is None:
        _FILE_REF = re.compile(r"@([A-Za-z0-9_./\\-]+)")
    hits = 0

    def _sub(m):
        nonlocal hits
        rel = m.group(1).rstrip(".,;:")
        p = repo / rel
        if not _inside(repo, p):
            # THE SESSION IS SCOPED TO ITS REPOSITORY, and this was the one
            # hole in that. `placement_denial` already refuses a WRITE
            # outside the repo; the read side inlined anything the pattern
            # matched, so `@../secret.env` or a relative walk up to
            # `~/.iobot/config.json` put the file - the provider API key
            # included - into the message, and from there into the model's
            # context, with no warning and nothing on screen to say it had
            # left the repository.
            if console is not None:
                console.print(f"[yellow]@{rel}: outside this session's "
                              "repository - not inlined. A build session "
                              "reads only files under the repo it opened; "
                              "copy it in if the builder needs it.[/]")
            return m.group(0)
        if not p.is_file():
            if console is not None:
                console.print(f"[yellow]@{rel}: no such file - left as "
                              "written[/]")
            return m.group(0)
        if hits >= _REF_MAX_FILES:
            # Silence here would read as "resolved"; the cap has to announce
            # itself or the turn quietly sees fewer files than was typed.
            if console is not None:
                console.print(f"[yellow]@{rel}: not inlined - at most "
                              f"{_REF_MAX_FILES} files per message[/]")
            return m.group(0)
        raw = p.read_bytes()[:_REF_MAX_BYTES]
        if b"\x00" in raw:
            # A NUL cannot appear in text, so this is a binary file, and
            # inlining it spends 8KB of the turn's context on replacement
            # characters that tell the model nothing. Named, not silent -
            # the point of @ is knowing what went in.
            if console is not None:
                console.print(f"[yellow]@{rel}: looks binary - not inlined[/]")
            return m.group(0)
        hits += 1
        body = raw.decode("utf-8", errors="replace")
        # TWO forms, and they are not interchangeable. The MESSAGE gets the
        # plain marker (the model reads text). The CONSOLE gets the escaped
        # one: Rich reads `[truncated]` as a style tag, finds no such
        # style, and drops it - so the marker the client documentation
        # promises by name was never once shown to a user, and an @file cut
        # at 8KB looked identical to one that fitted.
        big = p.stat().st_size > _REF_MAX_BYTES
        clipped = " [truncated]" if big else ""
        shown = " " + bracket("truncated") if big else ""
        if console is not None:
            # SUCCESS IS ALSO FEEDBACK. Only failures spoke before, so a
            # reference that worked looked identical to one nobody read -
            # and the whole point of @ is knowing the file went in.
            n = len(body.splitlines())
            console.print(f"[dim]@{rel} {_glyphs(console)['arrow']} {n} line(s) inlined{shown}[/]")
        return (f"the file `{rel}`{clipped}:\n```\n{body}\n```")

    return _FILE_REF.sub(_sub, text)


def _repo_macro(repo: Path, name: str) -> str | None:
    """`.aicore/commands/<name>.md` as a repo-local slash command.

    The per-repo custom-command pattern: a team checks in its recurring
    prompts once, and `/release-notes` works for everyone who clones. The
    file body IS the message; anything typed after the command is appended.
    """
    if not name or "/" in name or "\\" in name or name.startswith("."):
        return None
    f = repo / ".aicore" / "commands" / f"{name}.md"
    try:
        return f.read_text(encoding="utf-8").strip() if f.is_file() else None
    except OSError:
        return None


def _transcript_tail(session_path: Path | None, limit: int):
    """(who, text) pairs for the session's last *limit* conversational
    entries - user and assistant text only; tool traffic stays in the
    record."""
    if session_path is None or not session_path.is_file():
        return []
    rows = []
    try:
        for line in session_path.read_text(encoding="utf-8").splitlines():
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            who = d.get("role")
            if who not in ("user", "assistant"):
                continue
            c = d.get("content")
            if isinstance(c, list):
                c = " ".join(str(b.get("text", "")) for b in c
                             if isinstance(b, dict))
            if isinstance(c, str) and c.strip():
                rows.append((who, c.strip()))
    except OSError:
        return []
    return rows[-limit:]


# ── repo memory: CORABUILD.md is the standing-instructions file ──────────

#: The durable instruction file, read at the start of every session.
#:
#: NOT `BUILD.md`, which is one of the most collided-with names in software:
#: Bazel and Buck give it a defined meaning, and this product's own solution
#: scaffold writes one containing the engine pod's Dockerfile and entrypoint.
#: So `/remember` was appending a session's standing instructions into a
#: build document - two unrelated files under one name, in the repositories
#: we generate ourselves. A distinct name cannot collide with either.
MEMORY_FILE = "CORABUILD.md"

_MEMORY_HEADER = """\
# CORABUILD

Standing instructions for this repository, read at the start of every build
session. What belongs here: conventions to follow, decisions already taken
and the constraint behind them, and anything that must not be done again.
What does not: transcripts, status, or anything true only today.

"""


def memory_path(repo: Path) -> Path:
    return Path(repo) / MEMORY_FILE


def _remember(repo: Path, note: str) -> Path:
    """Append a note to the repository's `CORABUILD.md`, harness-written.

    The builder reads it at session start, so a note recorded today shapes
    every future session in this repository. The file is the builder's to
    maintain: it may reorganise and condense what is there, which is why
    the notes go under one heading rather than being appended to the end
    of whatever the file happens to contain.
    """
    f = memory_path(repo)
    text = f.read_text(encoding="utf-8") if f.is_file() else _MEMORY_HEADER
    if "## Notes" not in text:
        text = text.rstrip() + "\n\n## Notes\n"
    text = text.rstrip() + f"\n- {note.strip()}\n"
    f.write_text(text, encoding="utf-8")
    return f
