"""What points at what, so a rename cannot leave half a repository behind.

A pack is a graph held together by NAMES. A workflow step says
``role: rey``; a swarm roster says ``agents: [rey]``; a role's ``skills:``
filter names skills; ``pyproject.toml`` names packages and the
``aicore.packs`` entry point. None of those is a path, so nothing on disk
breaks when the thing they name goes away - the YAML still parses, the
linter still passes, and the failure waits for a run.

Measured. Told to rename an agent and then revert, a build turn left
``contract_nina`` on disk with ``contract_ida`` gone, and every reference
still pointing at the name that no longer existed. Separately, a scenario
that deleted the agents directory left six workflows and two swarms naming
agents that were not there - and the corpus went on for thirteen more
scenarios without anything saying so.

The builder has `grep`, and used it SEVEN times across a whole corpus run
against 114 `read_file` calls. Asking it to sweep is a request; computing
the answer is not.
"""
from __future__ import annotations

import re
from pathlib import Path

#: Where a name is referenced, and which inventory kind it must resolve to.
#: Matched on the YAML key rather than parsed, deliberately: a workflow that
#: does not parse still has references worth reporting, and this runs on
#: half-finished trees by design.
_REFERENCE_RES = (
    # The `-?` matters: a step written as a LIST ITEM is `- role: scout`,
    # and without it the sweep found nothing in exactly the file shape the
    # scaffold generates. Caught by a test that disagreed with a corpus
    # file, where the steps happened to be a mapping.
    ("agents", re.compile(
        r"^\s*-?\s*(?:role|meta_agent)\s*:\s*[\"']?([a-z][\w-]*)", re.M)),
    ("agents", re.compile(r"^\s*-?\s*agents\s*:\s*\[([^\]]*)\]", re.M)),
    ("skills", re.compile(r"^\s*skills\s*:\s*\[([^\]]*)\]", re.M)),
)

#: Files that hold the graph. `.iof` and the venv are never authored content.
_SKIP = {".iof", ".git", ".venv", "node_modules", "__pycache__", "build",
         "dist", ".eggs", "tests"}

#: Names that are roles but never live in this repository - the platform
#: ships them, so a workflow naming one is correct and must not be reported.
#: `system` is the exec-step default; the rest are the platform-shared
#: agents every workspace has.
_PLATFORM_ROLES = {
    "system", "project_lead", "analyst", "developer", "reviewer",
    "strategist", "jarvis", "queryngine", "cora_build", "domain_consultant",
}


#: The pack MANIFEST is not part of the graph. Its `roots:` block reads
#: `agents: [agents]` and `skills: [skills]` - those are DIRECTORY names,
#: not references, and scanning them reported every repository as having a
#: dangling agent called "agents". The one file where these keys mean
#: something else is the one file to skip.
_MANIFESTS = {"aicore.solution.yaml", "agentfarm.solution.yaml"}


def _yaml_files(repo: Path):
    # PRUNED DURING DESCENT. `rglob` filtered results but still WALKED
    # .git, .venv and node_modules - measured at ~1.5s per call on this
    # repository, paid once per lint target on every write.
    import os as _os
    for base, dirs, files in _os.walk(repo):
        dirs[:] = [d for d in dirs if d not in _SKIP]
        for name in files:
            if name in _MANIFESTS:
                continue
            if name.endswith((".yml", ".yaml")):
                yield Path(base) / name


def _rel(path: Path, repo: Path) -> str:
    try:
        return str(path.resolve().relative_to(Path(repo).resolve())
                   ).replace("\\", "/")
    except (OSError, ValueError):
        return str(path)


#: repo -> (monotonic stamp, result). One `apply_patch` call can carry 20
#: edits and the verdict swept the tree once PER TARGET; within a call the
#: tree cannot change between targets, so a 2-second memo turns 20 walks
#: into 1 without ever serving a stale sweep across turns.
_SWEEP_MEMO: dict = {}
_SWEEP_TTL_S = 2.0


def reset_reference_memo() -> None:
    _SWEEP_MEMO.clear()


def find_references(repo) -> list[dict]:
    """Every name this repository's YAML points at.

    ``[{kind, name, file, line}]``. Deliberately over-inclusive: a name it
    reports that turns out to be fine costs a reader one glance, and a name
    it misses is the one that breaks a run.
    """
    import time as _time
    repo = Path(repo)
    memo_key = str(repo.resolve())
    hit = _SWEEP_MEMO.get(memo_key)
    if hit and _time.monotonic() - hit[0] < _SWEEP_TTL_S:
        return hit[1]
    out: list[dict] = []
    for path in _yaml_files(repo):
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rel = _rel(path, repo)
        for kind, rx in _REFERENCE_RES:
            for m in rx.finditer(text):
                line = text[:m.start()].count("\n") + 1
                for raw in m.group(1).split(","):
                    name = raw.strip().strip("\"'")
                    if name:
                        out.append({"kind": kind, "name": name,
                                    "file": rel, "line": line})
    _SWEEP_MEMO.clear()
    _SWEEP_MEMO[memo_key] = (_time.monotonic(), out)
    return out


def dangling(repo) -> list[dict]:
    """References whose target is not in this repository.

    Platform-shared roles are excluded - a workflow naming `project_lead` or
    `jarvis` is correct, and reporting them would make the check noise. So
    are SDK skills, which arrive in a wheel and are never on disk here.
    """
    from ioagentfarm.builder import inventory as _inv

    have = _inv.locate(repo)
    known_agents = set(have.get("agents") or {}) | _PLATFORM_ROLES
    known_skills = set(have.get("skills") or {})
    out = []
    for ref in find_references(repo):
        if ref["kind"] == "agents" and ref["name"] not in known_agents:
            out.append(ref)
        elif ref["kind"] == "skills" and known_skills and \
                ref["name"] not in known_skills:
            # Only when the repo HAS skills of its own: a pack whose skills
            # all come from the SDK would otherwise report every one.
            out.append(ref)
    return out


def referrers(repo, name: str, *, kind: str = "") -> list[dict]:
    """Everything that points AT *name*. The question a rename must ask.

    `dangling` is the post-mortem - it says what broke once the rename is
    finished. This is the answer BEFORE: three workflows name this agent, so
    renaming it is three edits, not one.

    Delivered where the model is already looking. It rides on the lint
    verdict for a target, so editing `agents/rey/workspace/SOUL.md` reports
    both that the agent lints clean and that four things depend on it -
    which is the fact a rename needs and the one `grep` would have told it,
    had it asked. Measured: the builder used `grep` SEVEN times across a
    whole corpus run against 114 `read_file` calls.
    """
    if not name:
        return []
    return [r for r in find_references(repo)
            if r["name"] == name and (not kind or r["kind"] == kind)]


def referrers_line(name: str, refs: list[dict], *, cap: int = 4) -> str:
    """The one line appended to a target's lint verdict; "" when nothing
    points at it."""
    if not refs:
        return ""
    where = ", ".join(f"{r['file']}:{r['line']}" for r in refs[:cap])
    more = f" (+{len(refs) - cap} more)" if len(refs) > cap else ""
    return (f"[refs] {len(refs)} reference(s) to '{name}': {where}{more} - "
            f"renaming or removing it means editing these too.")


def dangling_line(refs: list[dict], *, cap: int = 6) -> str:
    """The one block a turn prints and carries forward; "" when clean."""
    if not refs:
        return ""
    lines = [f"[refs] {len(refs)} reference(s) point at content that is not "
             f"in this repository:"]
    for r in refs[:cap]:
        lines.append(f"  {r['file']}:{r['line']} names {r['kind'][:-1]} "
                     f"'{r['name']}'")
    if len(refs) > cap:
        lines.append(f"  ... {len(refs) - cap} more")
    return "\n".join(lines)
