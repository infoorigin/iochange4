"""The harness verifies what the model writes; the model does not self-report.

Lint used to be a REQUEST: the charter told the agent to run `aicore
lint-<kind>` after writing and to report only what the linter confirmed.
Nothing in the harness ran a linter, so "lint clean" in a reply was a claim
until the model chose to make it true - and five of the corpus's failures
were replies that claimed it unverified.

Two seams use this module:

* **At the tool** (`engine.py`): after a successful `write_file`,
  `edit_file` or `apply_patch`, the matching linter runs in-process and its
  verdict is appended to the TOOL RESULT - the channel the model already
  reads, in the same call, before it has reported anything. A write that
  broke a skill's frontmatter is answered "lint-skill ...: 1 error" where
  the model cannot miss it.
* **After the turn** (`session_state.py`): every path the turn wrote is
  re-linted, the verdict goes beside the reply on the console and into the
  JSON, a reply that claims clean while the harness found errors is
  contradicted by name, and the measured state is carried into the next
  turn as an observation.

Linting is in-process and reads a handful of small files, so it costs
nothing a subprocess would not cost a hundred times over.
"""
from __future__ import annotations

import re
from pathlib import Path

#: Directories no authored content lives under.
_SKIP = {".iof", ".git", ".venv", "node_modules", "__pycache__", "build",
         "dist", ".eggs"}

#: Agent identity files. A write to one re-lints the AGENT; a skill under
#: the agent's workspace re-lints the skill AND the agent, because the
#: agent rule that matters most - exactly one output contract - is a
#: property of the set of skills it carries, not of any one file.
_AGENT_FILES = {"SOUL.md", "TOOLS.md", "AGENTS.md"}


def _skip(path: Path, repo: Path) -> bool:
    try:
        rel = path.resolve().relative_to(Path(repo).resolve())
    except (OSError, ValueError):
        return True
    return any(part in _SKIP for part in rel.parts)


def _walk_up(start: Path, repo: Path, marker: str) -> Path | None:
    """The nearest ancestor (inclusive) holding *marker*, inside the repo."""
    root = Path(repo).resolve()
    cur = start.resolve()
    while True:
        if (cur / marker).is_file():
            return cur
        if cur == root or root not in cur.parents:
            return None
        cur = cur.parent


def lint_targets(path, repo) -> list[tuple[str, Path]]:
    """Which linters, over which directories, cover a written file.

    Returns ``[(kind, directory), ...]`` in the order they should run, or
    ``[]`` for a file no linter covers (CORABUILD.md, a tool script, a data
    file). Kinds match the CLI: ``skill``, ``agent``, ``workflow``, ``swarm``.
    """
    p = Path(path)
    if not p.is_absolute():
        p = Path(repo) / p
    if _skip(p, repo):
        return []
    out: list[tuple[str, Path]] = []
    parent = p.parent

    if p.name == "SKILL.md":
        out.append(("skill", parent))
    wf = _walk_up(parent, repo, "workflow.yaml")
    if wf is not None:
        out.append(("workflow", wf))
    sw = _walk_up(parent, repo, "swarm.yaml")
    if sw is not None:
        out.append(("swarm", sw))

    # agents/<role>/workspace/... -> the agent is <role>'s directory
    parts = p.resolve().parts
    for i, part in enumerate(parts):
        if part == "workspace" and i >= 2 and parts[i - 2] == "agents":
            agent_dir = Path(*parts[:i])
            under = parts[i + 1:]
            is_identity = len(under) == 1 and under[0] in _AGENT_FILES
            is_skill = p.name == "SKILL.md" and under[:1] == ("skills",)
            if is_identity or is_skill:
                out.append(("agent", agent_dir))
            break
    return out


def run_lint(kind: str, target: Path):
    """The in-process linter for *kind*; a ``LintResult``."""
    if kind == "skill":
        from ioagentfarm.engine.content_lint import lint_skill_dir
        return lint_skill_dir(target)
    if kind == "agent":
        from ioagentfarm.engine.content_lint import lint_agent_dir
        return lint_agent_dir(target)
    if kind == "workflow":
        from ioagentfarm.engine.workflow_lint import lint_workflow_dir
        return lint_workflow_dir(target)
    if kind == "swarm":
        from ioagentfarm.engine.swarm_lint import lint_swarm_dir
        return lint_swarm_dir(target)
    raise ValueError(kind)


def _rel(target: Path, repo) -> str:
    try:
        return str(Path(target).resolve().relative_to(Path(repo).resolve())
                   ).replace("\\", "/")
    except (OSError, ValueError):
        return str(target)


def verdict(kind: str, target: Path, result, repo, *, cap: int = 6) -> dict:
    """One target's verdict, as data and as the lines the model reads."""
    errors = list(getattr(result, "errors", []) or [])
    warnings = list(getattr(result, "warnings", []) or [])
    where = _rel(target, repo)
    head = (f"[lint] lint-{kind} {where}: {len(errors)} error(s), "
            f"{len(warnings)} warning(s)")
    lines = [head]
    shown = 0
    for f in errors + warnings:
        if shown >= cap:
            lines.append(f"  ... {len(errors) + len(warnings) - shown} more")
            break
        line = getattr(f, "line", None)
        loc = f.where if line is None else f"{f.where}:{line}"
        lines.append(f"  {f.severity} {loc}: {f.message}")
        if getattr(f, "fix", ""):
            lines.append(f"    fix: {f.fix}")
        shown += 1
    return {"kind": kind, "target": where, "errors": len(errors),
            "warnings": len(warnings), "text": "\n".join(lines)}


def verify_paths(paths, repo, *, cap: int = 6) -> list[dict]:
    """Lint every target the given written paths map onto, each once."""
    seen: set[tuple[str, str]] = set()
    out: list[dict] = []
    for raw in paths:
        for kind, target in lint_targets(raw, repo):
            key = (kind, str(Path(target).resolve()))
            if key in seen:
                continue
            seen.add(key)
            try:
                result = run_lint(kind, target)
            except Exception as exc:                  # noqa: BLE001
                out.append({"kind": kind, "target": _rel(target, repo),
                            "errors": 0, "warnings": 0,
                            "text": f"[lint] lint-{kind} {_rel(target, repo)}: "
                                    f"could not run ({exc})"})
                continue
            out.append(verdict(kind, target, result, repo, cap=cap))
    return out


#: apply_patch names its files inside the patch text, not in an argument.
_PATCH_FILE = re.compile(r"^\*\*\* (?:Update|Add) File: (.+)$", re.M)


def written_by(tool_name: str, kwargs: dict, repo) -> list[str]:
    """Repo-relative paths a write tool targeted - `events.written_paths`
    plus the files an `apply_patch` body names."""
    from ioagentfarm.builder.events import written_paths
    out = list(written_paths(tool_name, kwargs, repo))
    if tool_name == "apply_patch":
        body = str(kwargs.get("patch") or kwargs.get("input") or "")
        out += [m.strip() for m in _PATCH_FILE.findall(body)]
    return out


def tool_verdict(tool_name: str, kwargs: dict, repo) -> str:
    """The text to append to a successful write's tool result.

    The lint verdict for every target the write touched, and WHAT POINTS AT
    each one. The second half is the answer a rename needs BEFORE it starts:
    editing `agents/rey/workspace/SOUL.md` reports that the agent lints
    clean and that four things depend on it, so renaming it is four edits
    rather than one. The dangling-reference sweep is the post-mortem of the
    same question; this is the version that arrives in time to be used.
    """
    paths = written_by(tool_name, kwargs, repo)
    if not paths:
        return ""
    parts: list[str] = []

    # DIAGNOSTICS FIRST, and for a different set of files than the linters.
    # `lint_targets` covers the content this platform DEFINES and returns []
    # for "a tool script, a data file" - which is where the actual code is:
    # `new-tool` scaffolds Python, a workflow ships metadata/catalog.yaml. A
    # file that does not parse was invisible here until something ran it,
    # which is a step failure three turns later spending that step's attempts
    # on a SyntaxError. It goes first because a parse error outranks
    # everything below it: the linters may well also be complaining, and
    # about the same broken bytes.
    try:
        from ioagentfarm.builder import diagnostics as _diag
        said = _diag.verdict_text(paths, repo)
        if said:
            parts.append(said)
    except Exception:                              # noqa: BLE001
        pass

    for v in verify_paths(paths, repo):
        parts.append(v["text"])
        try:
            from ioagentfarm.builder import references as _refs
            name = Path(v["target"]).name
            said = _refs.referrers_line(name, _refs.referrers(repo, name))
            if said:
                parts.append(said)
        except Exception:                          # noqa: BLE001
            pass
    return "\n".join(parts)


def append_to_result(result, text: str):
    """Append *text* to a tool result, keeping its type and error flag."""
    if not text:
        return result
    try:
        from iobot.agent.tools.base import ToolResult
    except Exception:                                  # noqa: BLE001
        ToolResult = None                              # type: ignore[assignment]
    joined = f"{result}\n{text}"
    if ToolResult is not None and isinstance(result, ToolResult):
        return ToolResult(joined, is_error=bool(getattr(result, "is_error", False)))
    return joined


#: The reply's own claim of cleanliness, in the spellings seen live.
_CLAIMS_CLEAN = re.compile(
    r"lint[- ]clean|0 errors|zero errors|no errors|"
    r"lints? (?:is|are|passes|passed) clean",
    re.I)


def contradiction(reply: str, verdicts: list[dict]) -> str | None:
    """A reply claiming clean while the harness found errors - named."""
    bad = [v for v in verdicts if v.get("errors")]
    if not bad or not reply or not _CLAIMS_CLEAN.search(reply):
        return None
    names = ", ".join(f"{v['kind']} {v['target']} ({v['errors']})" for v in bad)
    return (f"the reply claims lint clean; the harness found errors in "
            f"{names}")


def observation(*, changed: list[dict], inventory_line: str,
                verdicts: list[dict], tool_calls: int | None,
                tests: dict | None = None, refs: list | None = None,
                goal: str = "", left: list | None = None,
                cap: int = 12) -> str:
    """The measured end-state of a turn, for the NEXT turn's context.

    The model describes the tree it intended. This is the tree as it is,
    stated by the harness in a few hundred bytes, so the next turn starts
    from a measurement instead of spending its first calls taking one.
    """
    lines = ["[harness observation - the repository at the end of your "
             "previous turn, measured]"]
    if changed:
        shown = [f"{c.get('status', '?')} {c.get('path', '')}"
                 for c in changed[:cap]]
        more = f" (+{len(changed) - cap} more)" if len(changed) > cap else ""
        lines.append("changed: " + ", ".join(shown) + more)
    else:
        lines.append("changed: nothing")
    if inventory_line:
        lines.append(f"now in this repo: {inventory_line}")
    if verdicts:
        bits = []
        for v in verdicts:
            if v.get("errors"):
                bits.append(f"{v['kind']} {v['target']}: {v['errors']} error(s)")
            elif v.get("warnings"):
                bits.append(f"{v['kind']} {v['target']}: clean, "
                            f"{v['warnings']} warning(s)")
            else:
                bits.append(f"{v['kind']} {v['target']}: clean")
        lines.append("harness lint: " + "; ".join(bits))
    if refs:
        # The next turn is where a dangling reference gets fixed, and it is
        # the one thing here the model cannot see by looking at what it just
        # wrote - the broken file is somewhere else entirely.
        shown = "; ".join(f"{r['file']}:{r['line']} -> '{r['name']}'"
                          for r in refs[:4])
        more = f" (+{len(refs) - 4} more)" if len(refs) > 4 else ""
        lines.append(f"dangling references: {shown}{more}")
    if tests:
        # Carried forward because a failing pack test is usually about the
        # ENVIRONMENT - a pack nobody installed - and the NEXT turn is where
        # that gets acted on, not the one that happened to write a file.
        mark = "pass" if tests.get("ok") else "FAIL"
        lines.append(f"pack tests: {mark} - {tests.get('summary', '')}")
        if tests.get("detail"):
            lines.append("  " + str(tests["detail"]).splitlines()[0])
    if tool_calls is not None:
        lines.append(f"tool calls that turn: {tool_calls}")
    # INTENT, after the measurements. A conversation drifts because each
    # turn re-derives what it is doing from the transcript; the harness
    # knows the request that opened it and never said so. The model's own
    # "not done" line rides beside it - the charter already requires that
    # sentence, and lifting it turns something the user might skim into
    # state the next turn is handed.
    if goal:
        lines.append(f"this conversation opened with: {goal[:240]}")
    for item in (left or [])[:3]:
        lines.append(f"you said was NOT done: {item}")
    return "\n".join(lines)


#: How long the pack's own tests may take before the harness stops waiting.
#: Generous - these are import-and-manifest checks, not a suite - and
#: bounded because a build turn must not hang on somebody's slow conftest.
_TEST_TIMEOUT_S = 120


def _test_root(repo) -> "Path | None":
    """The pack's own tests, if it ships any."""
    d = Path(repo) / "tests"
    if not d.is_dir():
        return None
    return d if any(d.glob("test_*.py")) else None


def run_pack_tests(repo, *, timeout: int | None = None) -> dict | None:
    """Run the pack's own tests and summarise. ``None`` when it ships none.

    LINT PROVES A FILE PARSES; THE PACK TEST PROVES IT LOADS. Two different
    questions, and only one was being asked: across 141 exec calls in a
    corpus run the builder ran `pytest` exactly zero times, while every
    scaffolded pack ships tests guarding the five things that fail SILENTLY
    - the `aicore.packs` entry point, the package-data globs, the agent's
    `output_protocol`, the manifest. Each of those is invisible to a linter
    and fatal at run time.

    A REPORT, never a gate. A failing pack test is often about the
    ENVIRONMENT rather than the content - a pack that is not pip-installed
    fails `test_every_declared_pack_is_importable_and_registered` no matter
    how good the authoring is - and refusing a turn for that would punish
    the builder for the sandbox it was handed. Saying so is what is useful:
    the model then knows the install step is outstanding, which is exactly
    what it otherwise discovers when a run fails.
    """
    root = _test_root(repo)
    if root is None:
        return None
    import subprocess
    import sys
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", str(root), "-q", "--no-header",
             "-p", "no:cacheprovider"],
            cwd=str(repo), capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=timeout or _TEST_TIMEOUT_S)
    except subprocess.TimeoutExpired:
        return {"ok": False, "summary": f"timed out after "
                                        f"{timeout or _TEST_TIMEOUT_S}s",
                "detail": "", "timed_out": True}
    except OSError as exc:                       # noqa: BLE001
        return {"ok": False, "summary": f"could not run ({exc})",
                "detail": "", "timed_out": False}
    out = f"{proc.stdout}\n{proc.stderr}"
    tail = [ln for ln in out.splitlines() if ln.strip()]
    summary = next((ln for ln in reversed(tail)
                    if " passed" in ln or " failed" in ln or "error" in ln.lower()),
                   "(no summary)")
    named = [ln for ln in tail if ln.startswith(("FAILED", "ERROR"))][:4]
    return {"ok": proc.returncode == 0, "summary": summary.strip(),
            "detail": "\n".join(named), "timed_out": False}


def tests_key(result: dict | None) -> str:
    """A stable identity for a test verdict - what it SAYS, not how long.

    The summary carries its own duration ("2 failed, 3 passed in 0.25s"), so
    comparing raw summaries never matched: every run differed in the
    hundredths, and the "say it once" rule repeated the same standing
    failure after every scaffold. Which is the exact noise the rule exists
    to stop.
    """
    if not result:
        return ""
    summary = re.sub(r"\s+in\s+[\d.]+s\b", "", str(result.get("summary", "")))
    return f"{bool(result.get('ok'))}|{summary.strip()}"


def tests_line(result: dict | None) -> str:
    """The one line a turn prints and carries forward."""
    if not result:
        return ""
    mark = "pass" if result.get("ok") else "FAIL"
    line = f"[tests] pack tests {mark}: {result.get('summary', '')}"
    if result.get("detail"):
        line += "\n" + "\n".join(f"  {d}" for d in
                                 str(result["detail"]).splitlines())
    return line


#: How the charter's Reporting standard asks a turn to close: "Caveats, and
#: anything not done." These are the openings that survive it in practice,
#: collected from live replies rather than invented.
_OUTSTANDING_MARKERS = (
    "not done:", "not done -", "still to do", "outstanding:", "remaining:",
    "what is left", "what's left", "i did not", "i have not", "yet to",
    "next step:", "next steps:",
)


def outstanding(reply: str, *, cap: int = 3) -> list[str]:
    """What the turn itself said it had NOT finished.

    THE CHARTER ALREADY REQUIRES THIS LINE - "anything not done" is item 6
    of the Reporting standard, and it is described there as the part most
    often omitted and the part that costs most. Extracting it costs nothing
    and turns a sentence the user might skim into state the NEXT turn is
    handed.

    Deliberately shallow: it lifts the line, it does not parse a plan. A
    line the model wrote about its own work is worth more than a structure
    inferred from it, and there is nothing here to drift out of date.
    """
    out: list[str] = []
    for raw in str(reply or "").splitlines():
        line = raw.strip().lstrip("*-# ").strip()
        low = line.lower()
        if any(low.startswith(m) or f" {m}" in low
               for m in _OUTSTANDING_MARKERS):
            if len(line) > 4:
                out.append(line[:200])
        if len(out) >= cap:
            break
    return out
