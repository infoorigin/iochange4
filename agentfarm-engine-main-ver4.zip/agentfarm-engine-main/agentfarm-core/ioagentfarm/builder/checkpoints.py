"""Per-turn checkpoints over git plumbing: capture, diff, undo.

A throwaway index means the working tree and the real index are never
touched - the user's staged work survives a checkpoint.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from loguru import logger


# Before every mutating turn the harness snapshots the ENTIRE working tree as
# a git tree object - plumbing only, the worktree and the user's index are
# never touched. /undo restores the tree exactly as it stood when the turn
# began; /diff shows precisely what a turn changed. Deterministic by
# construction: no dependence on the model reporting what it did, and the
# blobs live in the repo's own object store, garbage-collected like any
# other unreachable object.
#
# `.iof` and `.venv` are excluded from BOTH capture and restore with the
# same pathspec, so an /undo can never rewrite the state database or the
# virtualenv out from under the session that is running it.

_CP_EXCLUDES = (":(exclude).iof", ":(exclude).venv", ":(exclude).git")

#: Applied to EVERY git call here, not only the capture.
#:
#: `core.quotePath` defaults to TRUE, so git renders any path outside ASCII
#: as C-style escapes - `"caf\303\251.md"`, quotes included. Every consumer
#: in this module treats that string as a filename: `/diff` printed the
#: escaped form, and `_undo_to_tree` built `repo / '"caf\303\251.md"'`,
#: which does not exist, so the unlink failed, the restore failed, and undo
#: reported "nothing reverted" while the file sat on disk. Measured: an
#: added file survived undo and a modified file kept its new content, in
#: silence. Any team whose filenames carry an accent - which is most teams
#: outside English - had no working undo at all.
_QUOTE_OFF = ("-c", "core.quotePath=false",
              # macOS stores filenames DECOMPOSED (NFD): `café.md` typed as
              # one codepoint is `e` + a combining acute on disk. git's
              # default is to precompose back to NFC when reading the
              # worktree, and this pins it on rather than trusting the
              # repository's own config - a `core.precomposeunicode=false`
              # in someone's ~/.gitconfig would otherwise hand us NFD paths
              # that no attributed string can match. Set on every call, for
              # the same reason quotePath is: the comparison must not
              # depend on how the host happens to be configured.
              "-c", "core.precomposeunicode=true")

#: git's constant for the empty tree - the baseline a repository with
#: no commit is diffed against. Same value in every git repository.
_EMPTY_TREE = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"


def _git(repo: Path, *args: str, env: dict | None = None,
         binary: bool = False):
    """(rc, output). Never raises; rc != 0 means git said no."""
    import subprocess
    e = os.environ.copy()
    if env:
        e.update(env)
    try:
        r = subprocess.run(["git", *_QUOTE_OFF, *args], cwd=str(repo), env=e,
                           capture_output=True, timeout=120)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 1, b"" if binary else str(exc)
    if binary:
        return r.returncode, r.stdout
    out = r.stdout.decode("utf-8", errors="replace")
    if r.returncode != 0:
        # The reason lives on stderr; a failure that reports only stdout
        # reports nothing, which is how a live capture failed traceless.
        out = (out + "\n" + r.stderr.decode("utf-8", errors="replace")).strip()
    return r.returncode, out


def _is_git_repo(repo: Path) -> bool:
    rc, out = _git(repo, "rev-parse", "--is-inside-work-tree")
    return rc == 0 and str(out).strip() == "true"


def _capture_tree(repo: Path) -> str | None:
    """Snapshot the worktree (tracked + untracked, excludes applied) as a
    tree object, via a THROWAWAY index so the user's staging area is never
    disturbed."""
    import tempfile
    fd, tmp = tempfile.mkstemp(prefix="build-index-")
    os.close(fd)
    # git refuses a zero-byte index file as corrupt; it must NOT exist yet.
    os.unlink(tmp)
    exc = tmp + ".exclude"
    # OUR excludes PLUS the user's global ones. Overriding
    # `core.excludesFile` with a two-line file DISABLED the developer's
    # own global ignore for the capture, so a `~/.gitignore_global` with
    # `node_modules/` in it was hashed into the throwaway index - hundreds
    # of MB of loose objects - on every single turn.
    exc_lines = [".iof/", ".venv/"]
    rc_x, out_x = _git(repo, "config", "--path", "--get",
                       "core.excludesFile")
    cand = (out_x or "").strip() if rc_x == 0 else ""
    if not cand:
        xdg = os.environ.get("XDG_CONFIG_HOME") or str(Path.home()
                                                       / ".config")
        cand = str(Path(xdg) / "git" / "ignore")
    try:
        userfile = Path(cand).expanduser()
        if userfile.is_file():
            exc_lines += userfile.read_text(
                encoding="utf-8", errors="replace").splitlines()
    except OSError:
        pass
    Path(exc).write_text("\n".join(exc_lines) + "\n", encoding="utf-8")
    try:
        env = {
            "GIT_INDEX_FILE": tmp,
            # The protected paths must be excluded DURING the add, not
            # stripped after: before a scaffold writes the repo's .gitignore,
            # `git add -A` physically scans `.iof`, and its agent-workspace
            # paths cross Windows' 260-char limit - rc 128, "Filename too
            # long", no checkpoint, found live on the FIRST turn of every
            # fresh repo. Per-command config, because a pathspec exclude of
            # an already-gitignored path exits 1 with advice (the earlier
            # live failure), and this fires whether or not .gitignore exists.
            "GIT_CONFIG_COUNT": "2",
            "GIT_CONFIG_KEY_0": "core.excludesFile",
            "GIT_CONFIG_VALUE_0": exc,
            "GIT_CONFIG_KEY_1": "core.longpaths",
            "GIT_CONFIG_VALUE_1": "true",
        }
        rc, out = _git(repo, "add", "-A", env=env)
        if rc != 0:
            # ONE UNADDABLE PATH MUST NOT COST THE SESSION ITS CHECKPOINTS.
            # `git add -A` is all-or-nothing: a single embedded repository
            # with no commit yet - `error: 'vendor/' does not have a commit
            # checked out` - fails the whole add with rc 128, so /undo and
            # /diff were dead for the ENTIRE session and only a log line
            # said why. A client repo holds those routinely: a half-cloned
            # dependency, a `git init` someone ran in a subfolder, a
            # scaffolded sub-project. `--ignore-errors` indexes everything
            # it can and skips what it cannot, which is the right
            # degradation: a checkpoint covering all the rest beats none.
            rc2, _ = _git(repo, "add", "-A", "--ignore-errors", env=env)
            first = "; ".join(str(out).strip().splitlines()[:1])[:200]
            # DEBUG, not warning: this is a HANDLED condition with a
            # recovery that works, and the level is what decides whether it
            # can ever reach a user. Only a failed write-tree below is
            # worth a warning - that is when the session really loses its
            # checkpoint.
            logger.debug("build checkpoint: git add rc={} ({}); retried "
                         "with --ignore-errors rc={} - the tree write "
                         "below decides", rc, first, rc2)
            # rc2 is 1 whenever anything was skipped, which is the expected
            # outcome here; write-tree is what says whether we have a
            # usable snapshot, so fall through to it rather than judging.
        _git(repo, "rm", "--cached", "-r", "-q", "--ignore-unmatch",
             "--", ".iof", ".venv", env=env)
        rc, out = _git(repo, "write-tree", env=env)
        if rc != 0:
            logger.warning("build checkpoint capture failed: write-tree rc={} {}",
                           rc, str(out).strip()[:300])
            return None
        return str(out).strip()
    finally:
        try:
            os.unlink(exc)
        except OSError:
            pass
        try:
            os.unlink(tmp)
        except OSError:
            pass


def cp_tree(entry) -> str:
    """The tree sha of a checkpoint.

    A checkpoint is `{"tree": sha, "written": [repo-relative paths]}`. It
    used to be the bare sha, and state files written by older builds still
    hold that shape - so every reader goes through here rather than
    subscripting, and an upgrade does not strand a session mid-flight.
    """
    return entry["tree"] if isinstance(entry, dict) else entry


def cp_written(entry) -> set[str]:
    """Repo-relative paths the harness OBSERVED the agent write during the
    turn this checkpoint opened.

    This is `/undo`'s attribution set, and it has to be persisted for the
    same reason the tree is: `BuildSession.written` is rebuilt empty on
    every start, so a `/undo` in a LATER invocation used to find nothing
    attributed, class every file the builder itself had written as the
    user's own work, and - non-interactive, where the prompt cannot be
    answered - revert nothing at all. A legacy bare-sha checkpoint has no
    record and yields the empty set, which is the old behaviour exactly.
    """
    return set(entry.get("written") or ()) if isinstance(entry, dict) else set()


def cp_created(entry) -> set[str]:
    """Repo-relative directories of content this turn brought into being.

    The scaffold commands create content through `exec`, which names no
    path, so none of it reaches `cp_written` - and `/undo` therefore
    offered every file `aicore new-agent` had just produced back to the
    user as their own edit, and non-interactively left it all in place
    while reporting success. Content that did not exist before the turn is
    the builder's: the user did not create an agent while waiting for one.

    Only NEW content. A directory that already existed and was edited stays
    ambiguous, which is what the consent prompt is for.
    """
    return set(entry.get("created") or ()) if isinstance(entry, dict) else set()


def cp_provisional(entry) -> bool:
    """Was this checkpoint opened by a turn that never finished?

    Through a helper for the same reason every other field is: a checkpoint
    written by an older build is a BARE SHA STRING, and `entry.get(...)` on
    one raises `AttributeError: 'str' object has no attribute 'get'`. Which
    is what it did - five undo tests, the moment this field was added.
    """
    return bool(entry.get("provisional")) if isinstance(entry, dict) else False


def cp_inv_before(entry):
    """The inventory taken before a provisional turn, or None.

    A cancelled turn has no attribution - nothing was written, so `written`
    is empty and `created` is unanswerable - and this is what lets `/undo`
    work out afterwards what that turn brought into being.
    """
    return entry.get("inv_before") if isinstance(entry, dict) else None


def under_created(path: str, created) -> bool:
    """Is *path* inside one of the directories the turn created?

    Compared on path SEGMENTS, not string prefixes: `agents/rey_old/x`
    starts with `agents/rey` as text and is a different directory. The
    created entry can also be a FILE (the `mcp.yaml` a server was declared
    in), which matches itself and nothing else.
    """
    p = str(path or "").replace("\\", "/").strip("/")
    for base in created:
        b = str(base or "").replace("\\", "/").strip("/")
        if not b:
            continue
        if p == b or p.startswith(b + "/"):
            return True
    return False


def tree_exists(repo: Path, tree: str) -> bool:
    """Is *tree* still in the object store?

    A checkpoint is a bare sha, and the objects behind it are UNREACHABLE
    by design - nothing refs them - so `git gc --prune=now`, a re-`git init`,
    or a repo copied without its objects takes them away. Every reader here
    then computed "no differences" and said so in the user's language:
    `/diff` printed "no changes since the last turn began" and `/undo`
    printed "the last turn changed nothing - checkpoint dropped" AND
    dropped it. Both are indistinguishable from a genuinely clean tree, so
    a session whose history had silently evaporated reported success. An
    absent baseline is not a clean tree, and the two must never render the
    same.
    """
    if not tree:
        return False
    rc, _ = _git(repo, "cat-file", "-e", f"{tree}^{{tree}}")
    return rc == 0


def _turn_changes(repo: Path, tree: str) -> list[tuple[str, str]]:
    """(status, path) pairs for what changed since *tree* - A added, M
    modified, D deleted - computed tree-to-tree so the exclusion semantics
    are identical on both sides.

    Callers that must not confuse "nothing changed" with "the baseline is
    gone" ask :func:`tree_exists` first; this returns the empty list for
    both, as it always has.
    """
    now = _capture_tree(repo)
    if not now or now == tree:
        return []
    # `-z` - NUL-SEPARATED, SO GIT NEVER QUOTES. `core.quotePath=false`
    # only stops the escaping of NON-ASCII bytes; a path holding a
    # backslash, a double quote or a control character is still returned
    # C-quoted (`"we\\ird.md"`, quotes included) on every platform. On
    # Windows that shape is unreachable - those characters cannot be in a
    # filename - so it surfaced only on Linux, where `/undo` compared
    # git's quoted string against the plain one attribution had recorded,
    # found no match, and silently left the builder's own file in place.
    # Asking git not to quote beats unquoting it afterwards: one flag,
    # and the whole class goes away rather than the members we thought of.
    rc, out = _git(repo, "diff-tree", "-r", "--name-status", "-z", tree, now)
    if rc != 0:
        return []
    fields = [f for f in str(out).split("\0") if f]
    pairs = []
    for i in range(0, len(fields) - 1, 2):
        pairs.append((fields[i].strip()[:1], fields[i + 1]))
    return pairs


def _key(path) -> str:
    """One comparable form for a repo-relative path.

    git speaks forward slashes on every platform, so the only side that
    can carry a backslash SEPARATOR is a caller passing a Windows path -
    and only there does swapping them mean anything. ON POSIX A BACKSLASH
    IS AN ORDINARY FILENAME CHARACTER: `a\\b.md` is one file, not a
    directory `a` holding `b.md`, so rewriting it makes the attributed
    path stop matching the one git reported and `/undo` silently skips
    that file - the fail-safe direction, still wrong.

    UNICODE IS NORMALISED FOR THE SAME REASON, and it is macOS that needs
    it: APFS and HFS+ store filenames DECOMPOSED, so `café.md` written as
    one codepoint comes back off the filesystem as `e` plus a combining
    acute. The two strings are not equal, so an attributed path built from
    a tool argument (composed, as typed) never matched the one read back
    from disk - the same failure as the quoting and the backslash, in a
    third disguise. Both sides are composed here, which is what git's
    `core.precomposeunicode` already does on its side.
    """
    import os as _os
    import unicodedata
    text = str(path)
    if _os.sep == "\\":
        text = text.replace("\\", "/")
    return unicodedata.normalize("NFC", text)


def make_writable(path) -> None:
    """Give the owner write permission on *path*, keeping everything else.

    ON POSIX, `os.chmod(p, stat.S_IWRITE)` DOES NOT MEAN "also allow
    writing" - chmod REPLACES the mode, and `S_IWRITE` is `0o200`, so a
    file that was `0o644` becomes write-only: the owner can no longer READ
    it and a `0o755` script is no longer executable. On Windows the same
    call is the documented way to clear the read-only attribute, because
    only that one bit is modelled, which is why it reads as correct and is
    not. `/undo` calls this on files it must delete or overwrite, so the
    POSIX version would have quietly stripped read permission from the
    user's own files as it reverted them.

    Widening the existing mode is the portable form: it clears the
    Windows read-only attribute (that bit IS `S_IWRITE`) and on POSIX adds
    exactly one bit to whatever was there.
    """
    import stat
    try:
        mode = os.stat(path).st_mode
    except OSError:
        mode = 0o600                      # gone or unstattable; ask for little
    os.chmod(path, stat.S_IMODE(mode) | stat.S_IWUSR)


def _force_writable(func, path, _exc):
    """shutil.rmtree onerror: clear the read-only bit and try once more.

    A DIRECTORY needs the write bit too before its entries can be
    unlinked - on POSIX permission to delete a file lives on the parent
    directory, not the file.
    """
    try:
        make_writable(path)
        parent = os.path.dirname(str(path))
        if parent:
            make_writable(parent)
        func(path)
    except OSError:
        pass


def _rmtree(target: Path) -> None:
    """rmtree with the read-only recovery, on any Python we support.

    `onerror` is deprecated from 3.12 and `onexc` does not exist before
    it, so the call is chosen at runtime rather than pinned to one.
    """
    import shutil
    import sys
    if sys.version_info >= (3, 12):
        shutil.rmtree(target, onexc=lambda f, p, e: _force_writable(f, p, e))
    else:
        shutil.rmtree(target, onerror=_force_writable)


def _remove(target: Path) -> None:
    """Delete a file the turn created, read-only bit or not.

    Windows refuses to unlink a read-only file, and a client repo is full
    of them: anything checked out with the attribute set, anything a tool
    marked, anything an editor holds. The failure raised out of `/undo`,
    which nothing guards. On POSIX the same shape appears as a read-only
    PARENT directory, which `make_writable` covers from `_force_writable`.
    """
    try:
        target.unlink()
    except PermissionError:
        make_writable(target)
        try:
            target.unlink()
        except PermissionError:
            # POSIX: the right to unlink lives on the DIRECTORY.
            make_writable(target.parent)
            target.unlink()
    except IsADirectoryError:
        _rmtree(target)
    except OSError:
        if target.is_dir():               # POSIX raises OSError(EISDIR)
            _rmtree(target)
        else:
            raise


def _write_bytes(target: Path, blob: bytes) -> None:
    """Restore a file's bytes, clearing a read-only bit if one blocks it."""
    try:
        target.write_bytes(blob)
    except PermissionError:
        make_writable(target)
        target.write_bytes(blob)


def _blob_for_worktree(repo: Path, tree: str, path: str):
    """The checkpointed file AS THE WORKTREE SHOULD HOLD IT.

    `cat-file blob` returns the object as `git add` stored it - CLEANED:
    CRLF normalised away under `core.autocrlf`/`text=auto`, and a git-LFS
    file reduced to its pointer. Restoring those bytes over the worktree
    flipped every CRLF file to LF (invisible to `/diff`, which
    re-normalises on capture, and visible to everything else) and wrote a
    130-byte LFS pointer over a real asset. `--filters` runs the SMUDGE
    side, which is the write-to-worktree conversion. Older gits without it
    fall back to the raw blob - the old behaviour, not a new failure.
    """
    rc, blob = _git(repo, "cat-file", "--filters", f"{tree}:{path}",
                    binary=True)
    if rc == 0:
        return rc, blob
    return _git(repo, "cat-file", "blob", f"{tree}:{path}", binary=True)


def _undo_to_tree(repo: Path, tree: str, only=None,
                  failed: list | None = None) -> list[str]:
    """Restore the worktree to *tree*. Returns the paths touched.

    *only* restricts the revert to those repo-relative paths. Without it
    the whole checkpoint diff is reverted, which includes anything the
    USER changed while the turn ran - see `_cmd_undo`, which is what
    decides.

    Added-since files are deleted, modified and deleted-since files are
    restored byte-exact from the tree's blobs. Anything under the excluded
    paths cannot appear in either tree, so it is structurally untouchable.

    NOTHING HERE MAY RAISE. `/undo` is dispatched straight from the input
    loop, which guards nothing, so an OSError on one path used to end the
    session with a traceback - measured with a read-only file (Windows
    refuses to open it for writing) and with a directory standing where a
    file was. Both are ordinary in a client repo. Paths that cannot be
    restored are collected into *failed* - a caller passing a list gets
    them back to show the user - and logged either way.
    """
    failed = failed if failed is not None else []
    touched = []
    keep = None if only is None else {_key(p) for p in only}
    for st, path in _turn_changes(repo, tree):
        if keep is not None and _key(path) not in keep:
            continue
        target = repo / path
        if st == "A":                     # created since the checkpoint
            try:
                _remove(target)
                touched.append(path)
            except OSError as exc:
                failed.append((path, str(exc)))
            # Prune parents the deletion emptied. Git tracks files, so a
            # reverted new-file leaves its directory behind - content-exact
            # to the checkpoint, but an `ls` shows a directory the turn
            # created and the undo appeared to miss. Stop at the first
            # non-empty parent or the repo root.
            parent = target.parent
            while parent != repo:
                try:
                    parent.rmdir()        # refuses unless empty
                except OSError:
                    break
                parent = parent.parent
        else:                             # M or D: restore from the tree
            rc, blob = _blob_for_worktree(repo, tree, path)
            if rc != 0:
                failed.append((path, "the checkpoint has no copy of it"))
                continue
            try:
                if target.is_dir():
                    # The turn replaced a file with a DIRECTORY. Writing
                    # bytes over it raises PermissionError on Windows and
                    # IsADirectoryError on POSIX; either escaped `/undo`,
                    # which no caller guards, so the traceback killed the
                    # whole REPL.
                    import shutil
                    shutil.rmtree(target, onerror=_force_writable)
                target.parent.mkdir(parents=True, exist_ok=True)
                _write_bytes(target, blob)
                touched.append(path)
            except OSError as exc:
                failed.append((path, str(exc)))
    if failed:
        logger.warning("build undo could not restore {} path(s): {}",
                       len(failed), "; ".join(f"{p}: {e}"
                                              for p, e in failed)[:400])
    return touched


def _review_diff(repo: Path, base_tree: str | None) -> str | None:
    """The patch to put in front of the reviewer.

    Against the last turn checkpoint when one exists - "review what the
    builder just did" - else against HEAD, "review my working tree". Capped:
    a reviewer drowning in 200KB of diff misses everything.
    """
    if base_tree:
        now = _capture_tree(repo)
        if not now:
            return None
        rc, out = _git(repo, "diff-tree", "-r", "-p", base_tree, now)
    else:
        # AGAINST HEAD, BUT THROUGH A CAPTURED TREE - never `git diff HEAD`.
        #
        # `git diff HEAD` does not show UNTRACKED files, and every single
        # thing this builder produces is untracked: a new agent, a new
        # skill, a new workflow are all new files nobody has added yet. So
        # a session that built a solution and ran `/review` before
        # committing was told "nothing to review - no changes found", with
        # the whole solution sitting in front of it. Measured on a repo
        # holding one new skill: the review returned no diff at all.
        #
        # Capturing the worktree first gives the same semantics `/diff`
        # already has - tracked edits AND untracked additions, minus the
        # protected paths - so the reviewer sees what the user sees.
        now = _capture_tree(repo)
        if not now:
            return None
        rc, head = _git(repo, "rev-parse", "HEAD^{tree}")
        # No HEAD at all - `git init` and then work, the state every new
        # repository is in on day one - reads against the empty tree, so
        # everything present is an addition. That is what a first review
        # should see, rather than the refusal `diff HEAD` produces there.
        base = str(head).strip() if rc == 0 else _EMPTY_TREE
        rc, out = _git(repo, "diff-tree", "-r", "-p", base, now)
    if rc != 0:
        return None
    text = str(out)
    if len(text) > 60_000:
        text = text[:60_000] + "\n... [diff truncated at 60KB]"
    return text if text.strip() else None
