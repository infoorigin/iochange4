# Step: perform the rulebook's action per its delivery contract

Print at least one line of text immediately BEFORE every tool call.

Your tool list holds exactly the tools this deployment declares for case
deliveries (`iof-case deliveries`); the engine narrowed it to those. The ctx
bundle names the one to call for THIS action (`pending_action_meta.tool`).
If that tool is not in your list, report `STATUS: failed` with
`OUTPUT: delivery tool unavailable` and do nothing else. NEVER fabricate a
tool's result — every call is ledgered.

**Tool allowlist for this step: the declared delivery tools, plus — only
when the contract carries a `verification` object — the tool that object
names.** Calling any other MCP tool is a violation.

## 1. Read the decision and its delivery contract

The goal names the action: it contains `action:<action_name>`. Read
`{{output_dir}}/case_ctx.json`. It carries everything you need — this
workflow serves EVERY case play, so nothing here is play-specific:

- `case_id`, `item_ref` (the item, e.g. a territory), `group_ref`,
  `state`, `sla_days`, `params` (the play's role names and windows),
  `history`
- **`pending_action_meta` — the action's DELIVERY CONTRACT** from the
  rulebook: `delivery` (email / monitoring_task / open_play / workflow),
  `tool` (the deployment's tool for that delivery, resolved by ctx — call
  this one, never another), `to_param` / `cc_param`
  (WHICH param names the recipient / CC roles), `subject_hint` (subject
  skeleton; substitute `<item>` with `item_ref`), `brief` (what the body
  must convey), `task_kind` (monitoring task to create, if any).

The DECISION IS ALREADY MADE by the case rulebook, and so is the delivery
contract. You compose the words; the contract decides everything else.
If the goal's action does not equal the ctx bundle's `pending_action`,
report `STATUS: failed` with `OUTPUT: action mismatch` — do not deliver.

## 2. Execute the contract

**Email** — only when the contract has a `to_param`:
- to_role = `params[to_param]`.
- **cc_role is decided by `cc_policy`, and by nothing else:**
  - `"cc_policy": "exclusive"` → **cc_role = "" — send NO copy recipient.**
    This is a compliance instruction from the business, not a stylistic
    default. Adding a copy here sends reviewed regulatory correspondence
    to someone the business excluded on purpose.
  - any other value → that value is a PARAM NAME; cc_role =
    `params[cc_policy]`.
  - Never carry a copy recipient over from a previous message in the
    ladder. Each action's contract stands alone.
- Subject from `subject_hint` with `<item>` substituted. When the
  contract names no `subject_hint`, compose one in the business's own
  language — what the recipient needs to see in an inbox — and NEVER
  the action's identifier: `escalate_to_brand_lead: <item>` is a
  machine name in a person's inbox, and it was sent to a Brand Lead
  once because this line did not say so.
- Body — two modes, decided by the contract:
  - **`approved_text` present: use it VERBATIM.** It is pre-approved
    language (MLR-reviewed); substitute only the `{placeholders}`
    (`{item}`, `{case_id}`, `{sla_days}`, any param name) from the case
    context. Do not rephrase, extend, soften or add a single sentence —
    an edited approved text is unapproved text.
  - No `approved_text`: compose — short, professional, under 120 words,
    conveying the `brief`, grounded ONLY in the case context (case_id,
    item, group, window `sla_days` business days). Never invent facts.
- Call the tool the bundle names (`pending_action_meta.tool`) with the
  recipient role, the copy role, the subject, the body and the item — its
  schema says how it spells them.

**Monitoring task** — only when the contract has a `task_kind`:
- Call the tool the bundle names (`pending_action_meta.tool`) with kind =
  `task_kind`, the account/group = `group_ref`, and a detail naming the
  `case_id` and the window (`sla_days` business days).

**Write the outcome to the system of record** — only when the contract's
`delivery` is `"system_of_record"`:
- Call the tool the bundle names (`pending_action_meta.tool`) with the
  identifiers the case carries (`case_id`, `item_ref`, `group_ref`) and the
  outcome the rulebook reached — its schema says how it spells them.
- **The decision is the EVENT's, not yours.** Pass what the case decided and
  the reason recorded with it; never a judgement of your own, and never a
  decision the ledger does not carry.
- The receipt (step 3) is the tool's own identifier or its answer. A write
  that reports nothing written is a FAILURE, not a quiet success: report
  `STATUS: failed` with the tool's answer verbatim.
- **An error is never a receipt.** A tool result carrying `error`, an
  exception text, or `written: 0` must NOT be passed to `record-action` —
  recording it marks the decision DELIVERED and nothing will ever retry it.
  Seen live: a constraint-violation string travelled into the case ledger
  as `DELIVERED [ERROR: ...]` and the write-back it stood for had not
  happened. Report `STATUS: failed`; the harness retries, the ledger stays
  honest.

**A workflow delivery can still carry `verification`** — commissioning the
run does NOT discharge it. Seen twice: the act step commissioned the
workflow, mentioned the verification in its own plan, and never called the
tool - the certification the contract demanded silently did not happen and
nothing downstream could tell. When `pending_action_meta.verification`
names a tool, CALL IT in this same step and put its receipt beside the
run receipt in `action_receipt.json` - a contract with a verification and
a receipt without one is a FAILED delivery, report `STATUS: failed`.

**Open a child play** — only when the contract's `delivery` is
`"open_play"`:
- The ctx bundle's `goal_items` lists the children to open (the meta
  agent put them in the goal from the triggering event). If `goal_items`
  is empty, report `STATUS: failed` with `OUTPUT: no items to open` —
  never invent children.
- Print a line of text, then run via exec:

      iof-case open-children --case <case_id> --items "<goal_items, comma-joined>" --out "{{output_dir}}" --root-hint "{{output_dir}}"

- The command opens the children, links them to this case, and records
  the delivery on the ledger ITSELF — do NOT also run `record-action`
  for this mode. The receipt for step 4 is the command's receipt line
  (`children:...`). A REFUSED output is a verdict: report it verbatim.

**Commission a workflow** — only when the contract's `delivery` is
`"workflow"`:
- The rulebook has already named the workflow (`pending_action_meta.
  workflow`) and the ctx bundle carries the run's goal, rendered
  deterministically (`workflow_goal`). You compose nothing.
- Print a line of text, then run via exec:

      iof-case commission --case <case_id> --out "{{output_dir}}" --root-hint "{{output_dir}}"

- The command starts the run non-blocking, links it to this case and
  records the delivery on the ledger ITSELF — do NOT also run
  `record-action`, and do NOT wait for the run: its completion reaches the
  case as the contract's `completion_event` through the scheduler. The
  receipt for step 4 is the command's `run:<id>` receipt. A REFUSED
  output is a verdict: report it verbatim.

**Outcome verification** — only when the contract has a `verification`
object:
- Its `tool` names the MCP tool that reads the GROUND TRUTH in the system
  of record. Call exactly that tool, with the case context (the item, the
  group/account). It must be in your tool list; if it is not, report
  `STATUS: failed` with `OUTPUT: verification tool unavailable` — never
  substitute another tool or your own reasoning for the read.
- The receipt (step 3) is the tool's result, prefixed `verified:` —
  e.g. `verified:{"rep": "Jordan Blake"}`. Record what the system said,
  not what the event claimed: if the read CONTRADICTS the claimed outcome,
  still record it verbatim and say so in your OUTPUT — a recorded
  contradiction is the entire point of this contract.

No `to_param`, no `task_kind`, no `workflow`, no `system_of_record` and no
`verification` = nothing external to do; still record (step 3) with receipt
`internal`.

If a tool returns an error or `sent`/`task_id` absent, retry once; then
report `STATUS: failed` with the tool's error verbatim.

## 3. Record the action on the case ledger

Print a line of text, then run via exec:

    iof-case record-action --case <case_id> --action <action> --receipt <email receipt_id or task_id> --root-hint "{{output_dir}}"

## 4. Write the receipt

Write `{{output_dir}}/action_receipt.json`:

```json
{"case_id": "...", "action": "...", "item": "...",
 "email_receipt": "... or null", "task_id": "... or null"}
```

## 5. Report

`STATUS: done` and `OUTPUT: <case_id>: <action> performed
(<email receipt / task id>)`.
