# Step: match the business text to this workspace's capabilities

Print at least one line of text immediately BEFORE every tool call.

You are doing ONE thing: reading a business playbook the way a domain expert
who also knows this deployment would, and writing down - requirement by
requirement - which of the workspace's capabilities serves each one. You are
NOT drafting rules, states or contracts; the draft is the next step's job,
and it is bound by what you write here.

This exists as its own step because matching done as a side effect of
drafting is matching done shallowly: watched live, a draft translated "take
that from the knowledge base itself rather than from the assessment's account
of its own work" into a polite sentence in an email brief, because the
drafter's attention was on states and windows. Your whole attention is on
the matching.

## Read, in this order

1. `{{output_dir}}/workflow_catalog.json` - every workflow this workspace can
   commission, WITH its description. The description is what you match
   against: what the workflow actually does, produces and refuses.
2. `{{output_dir}}/deliveries_catalog.json` - how an action can reach the
   world here: the delivery kinds and their tools, the roles an email may
   address, and under `verification` the RECORDS a claimed outcome can be
   checked against. Where an entry carries a `means:`, that is its meaning;
   where it does not, the tool name is what you have.
3. `{{output_dir}}/plays_catalog.json` - the OPERATIONAL plays already
   installed here, each with its goal. This is where an `open_play` match
   gets its name: a sentence that hands the matter to another team's own
   process matches a play whose goal says it IS that process.
4. `{{output_dir}}/compile_history.json` - every recent compilation in
   this workspace with each rejection's reason. A rejection that names a
   MATCH - "X was a stretch", "Y should have been verification" - is
   binding on your map, whatever template id that round used.
5. The source text (in the goal below).

## The matching discipline

- **Match on what a capability DOES, never on shared words.** A workflow
  whose description says it reads unread sources and records signals serves
  "read everything unread and record what each source said" even though no
  word overlaps; a workflow that shares three words with the sentence but
  does a different job serves nothing.
- **A demand for confirmation is not always phrased as one.** "Take it from
  the record, not from the summary", "state it from the system itself",
  "keep the answer with the register" - where the text says a fact must
  come from a RECORD rather than from whoever reports it, and a
  `verification` record holds that fact, that is a match.
- **An outcome someone must SEE is a delivery.** Telling a role is `email`;
  making a wait visible and owned is `monitoring_task`; putting a decision
  where the business reads it - a register, a system of record - is
  `system_of_record` where declared.
- **Structure the rulebook itself provides is `flow`, and names nothing.**
  A branch ("the barrier's category decides which chain reviews it"), a
  window someone owns, an escalation rung ("if Level 1 does not answer,
  Level 2 decides"), a matter that stays open for a late answer - these
  are STATES, EVENTS and RULES of the machine being compiled. They are
  requirements (cover them, the draft must contain them), but they consume
  no capability: type `flow`, name `null`. Do not reach for `open_play` or
  `none` for them - `none` means "a capability is MISSING", and flow is
  not missing anything.
- **`open_play` is only for OPENING SEPARATE CHILD MATTERS.** "Open one
  counter-case per eroding account", "spawn a per-site review case" -
  where the text opens NEW matters, each with its own life, under another
  play. Routing one matter down a branch is `flow`, never `open_play`.
  Put the child play's id in `name` from `plays_catalog.json`; a child
  play the catalog does not hold is a `none` row (a capability request).
- **Prefer `none` over a stretch.** A requirement no capability genuinely
  serves is mapped to `none` and becomes a capability request - that is a
  result, and it is how the business learns what to build. A stretched match
  is worse than a gap: it compiles into a step that silently does less than
  the text asked.
- **Say why, every time.** One sentence per row: what about the capability's
  description earned the match. A row you cannot justify is a row to remap.

## Write

**`{{output_dir}}/capability_map.json`** - a JSON list, one row per
requirement you found in the text:

```json
[{"requirement": "<the requirement, in one plain sentence>",
  "quoted": "<the source sentence(s), verbatim>",
  "capability": {"type": "workflow" | "email" | "monitoring_task" |
                          "system_of_record" | "verification" |
                          "open_play" | "flow" | "none",
                 "name": "<exactly as the catalog spells it, or null>"},
  "why": "<one sentence: what about this capability earned the match>"}]
```

Cover every requirement the text states - the work to run, every notice,
every window someone owns, every check against a record, every write-back,
every mandated sentence. Background prose (why the procedure exists) is not
a requirement and does not get a row. Do not pad: a text usually has between
five and fifteen requirements.

The next step drafts UNDER this map, and the stage validator refuses a draft
that is inconsistent with it - a workflow mapped here and commissioned by no
rule, a verification record mapped here and carried by no contract, a `none`
row with no capability request. Your map is a contract, not a note.

## Report

`STATUS: done` and `OUTPUT: mapped <N> requirement(s): <count by type,
e.g. 2 workflow, 3 email, 1 verification, 1 none>`.
