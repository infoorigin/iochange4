# Step: compile the business playbook into its executable form

Print at least one line of text immediately BEFORE every tool call.

The goal contains a BUSINESS PLAYBOOK written in prose (steps, roles,
windows, escalation etiquette). Your job is translation, not invention:
every rule you emit must trace to a sentence in the prose, and every
assumption you are forced to make must be written down. You write FIVE
files into `{{output_dir}}` and nothing else — you never run `iof-plays
put`, `iof-case rulebook put`, or any staging command; a separate
deterministic step validates your drafts and a HUMAN approves them.

## 0. FIRST — read every prior rejection of this play

Before drafting anything, run:

```bash
Read "{{output_dir}}/compile_history.json" - every recent compilation with each rejection's reason, whatever id that round chose
```

If it reports round 1, continue. Otherwise **every reason listed is a
binding constraint on this draft**, including ones an earlier round
already satisfied.

Satisfy them ALL AT ONCE. Fixing only the newest complaint is how a
correction round destroys an earlier one: observed live, round 1 got the
three routing owners right and the event lexicon wrong; the reviewer
rejected it naming the lexicon; round 2 fixed the lexicon and collapsed
all three routing recipients onto a single role, undoing the entire
purpose of the play. Nothing but the reviewer's memory caught it.

In `compile_notes.md`, state for each prior rejection which decision in
THIS draft answers it. A reviewer comparing rounds must not have to
re-derive that from the rule table.

## 1. `source_playbook.md`

The business playbook text from the goal, copied VERBATIM (drop only the
leading instruction words before the playbook itself, if any). This is
what the reviewer reads beside your rule table — altering it corrupts the
review.

## 2. `draft_rulebook.json` — the rulebook document

Exact shape (all keys shown are required unless marked optional):

```json
{
  "template_id": "TPL-<SHORT-SLUG>",
  "title": "<short name>",
  "description": "<one sentence>",
  "initial_state": "NEW",
  "open_event": "case_opened",
  "states": ["NEW", "...", "CLOSED"],
  "events": ["case_opened", "..."],
  "terminal_states": ["CLOSED"],
  "role_params": ["owner_role", "..."],
  "default_params": {"owner_role": "<from prose>", "<window>_days": 2},
  "wildcard_rules": [
    {"event": "...", "rule_id": "...", "action": "...",
     "to_state": "...", "sla_param": null}
  ],
  "rules": [
    {"from_state": "NEW", "event": "case_opened", "rule_id": "X01",
     "action": "...", "to_state": "...", "sla_param": "<window>_days"}
  ],
  "actions": {
    "<action_name>": {"side_effects": true, "delivery": "email",
                      "to_param": "owner_role", "cc_param": "cc_role",
                      "subject_hint": "... — <item>",
                      "brief": "<what the message must convey>",
                      "task_kind": "<window>_days-matching kind"},
    "<run_something>": {"side_effects": true, "delivery": "workflow",
                        "workflow": "<a name from workflow_catalog.json>",
                        "goal_hint": "<one line: what the run must establish, with <item> and <group>>",
                        "completion_event": "<the event its result arrives as>"}
  }
}
```

Translation rules — each exists because a violation executes wrongly:

- **Every prose step becomes rule row(s)** with a rule_id (X01, X02, ...
  in prose order). A step that applies "at any step" is a
  `wildcard_rules` entry, not N copies.
- **Events are the playbook's inbound signals, typed minimally**: what
  the monitoring process reports (`sla_breach`, `snooze_expired`), what
  people send back (name them from the prose, e.g. `reschedule_agreed`),
  plus `case_opened` and `system_error` if the prose has error handling.
  Never invent an event the prose does not imply.
- **Terminal states accept nothing**: no rule may have a terminal
  `from_state`. A "close" instruction — the matter is finished, there is
  nothing left to do — means `to_state` = a terminal state.
- **"STOP" IS NOT "CLOSE", AND CONFUSING THEM LOSES THE MATTER.** Prose
  like "stop chasing", "do not keep escalating", "leave it for a person
  to pick up" means the AUTOMATION stops, not that the matter is over.
  Encode it by giving that state no further rule: the ladder exhausts,
  the case parks where it is, and it stays on someone's list to pick up.
  Sending it to a terminal state instead makes it disappear from open
  work, so the person the prose asked to pick it up never sees it. If the
  prose says stop, the last rung has `"sla_param": null` and no rule
  consumes a further expiry from it.
- **`system_error` IS NOT A BUSINESS OUTCOME.** It reports that a delivery
  or a tool failed — the platform's problem, not the matter's. Never route
  it to a terminal state: a transient failure would terminally close a
  live case, and the work it was tracking is gone. If the prose says
  nothing about tool failure, write no rule for it at all and let the
  refusal be recorded for a person.
- **Windows go in `default_params`** (integers, `<name>_days`), and the
  rule that starts a window names it in `sla_param`. A rule that starts
  no clock has `"sla_param": null`.
- **A WINDOW IS WIRED TO THE STATE IT RUNS IN, NOT THE ONE IT WAS SET
  FROM.** This is the single easiest rule to get wrong, and it fails
  silently. When a rule moves the case to state `S` and names a
  `sla_param`, the clock runs WHILE THE CASE IS IN `S`, and its expiry
  arrives as `sla_breach` **from `S`**. So the rule that handles the
  expiry has `"from_state": "S"`.

  ```jsonc
  // the case is in AWAITING_REPLY while the 3-day window runs
  {"from_state": "NEW", "event": "case_opened", "rule_id": "X01",
   "action": "notify_owner", "to_state": "AWAITING_REPLY",
   "sla_param": "reply_days"},
  // WRONG - keyed to NEW, which the case left the moment X01 fired.
  // The window expires, nothing matches, and the escalation never happens.
  {"from_state": "NEW", "event": "sla_breach", ...},
  // RIGHT - keyed to the state the case is actually in when it expires
  {"from_state": "AWAITING_REPLY", "event": "sla_breach", "rule_id": "X02",
   "action": "escalate", "to_state": "ESCALATED", "sla_param": null}
  ```

  Check every rule that names a `sla_param`: its `to_state` must appear as
  the `from_state` of a rule handling that window's expiry — unless the
  prose says to stop there, in which case the window itself belongs in the
  rung before. A window with nothing listening for it is refused at
  install, and the message names the rule.
- **Delivery contracts** (`actions` map) — one entry for EVERY action
  named by any rule:
  - email: `to_param`/`cc_param` name PARAMS (e.g. `"owner_role"`),
    never literal people. **If the prose says "directly", "exclusively"
    or names no CC — OMIT `cc_param` entirely.** `subject_hint` uses
    `<item>` as the placeholder.

    **CHECK THIS BEFORE YOU STAGE.** Every `to_param` and `cc_param` value
    must appear as a key in `default_params`. Read your own actions map and
    confirm it, one action at a time. This rule is stated below as well and
    has still been got wrong: the prose names a person or a job title, and
    it is easy to write that title straight into `to_param` because it
    reads correctly. It is not correct — a title in `to_param` resolves to
    nothing, and changing who is notified then means editing the rulebook
    rather than a parameter, which is the whole thing this design avoids.

    ```jsonc
    // WRONG - a job title where a parameter belongs
    "cd_notify": {"to_param": "Commercial Director"}
    // RIGHT - the title lives in default_params under this key
    "cd_notify": {"to_param": "commercial_director_role"}
    ```
  - a monitoring window being started = `task_kind` (name it after the
    window).
  - `side_effects`: true for anything that reaches an external system
    (email, CRM, task); false ONLY for pure internal state moves.
- **Never invent a pseudo-state.** A rule that leaves the case where it is
  names that state in `to_state` (a self-transition). Names like `_SELF`,
  `SAME` or `CURRENT` are not states, and a case sent to one is stranded.
  Where a step says "extend the current window", emit one rule per state
  the extension can apply from, each returning to that same state.
- **Thresholds become EVENTS, never conditions.** A rule fires on
  (state, event); there is no branching on a value. Prose like "if the
  discrepancy exceeds 50 units, escalate directly" is two typed events
  (`discrepancy_major` / `discrepancy_minor`) with the numeric boundary
  stated in `event_rubrics`, so the threshold is applied ONCE at intake —
  by the emitter or the classifier — and the ladder stays a table a
  reviewer can read. Never encode a threshold as a pseudo-state, as prose
  inside an action `brief`, or as an instruction the act step must obey.
- **`to_param` / `cc_param` name PARAMETERS, never people or role
  literals.** `"to_param": "escalation_role"` is correct;
  `"to_param": "Patient Access Director"` is a defect — put the literal in
  `default_params` and name the parameter.
- **Mandated wording is not optional.** If the prose quotes exact wording
  for a communication, that wording MUST appear as the action's
  `approved_text`, with `{item}` / `{case_id}` / `{sla_days}` /
  `{prior_sla_days}` / parameter names as its only substitutions.
  Composing a paraphrase of quoted wording is a compilation defect.
- **MANDATED WORDING GOES ON EXACTLY ONE ACTION — THE ONE THE PROSE
  DESCRIBES.** Read the sentence that introduces the quote and honour its
  scope: "when we write to X **about a missed deadline**" is one specific
  message, not every message that ever reaches X. Putting approved language
  on a second action because it shares a recipient delivers a sentence that
  was true at the rung it was written for and false at this one.

  Observed live: wording approved for the escalation — "This matter is now
  with you" — was copied onto the stop-chasing rung as well, so the same
  person was told a second time that a matter was now theirs at the exact
  point the business had decided to stop pursuing it. Both actions emailed
  the same recipient, which is what made it look reasonable.

  For every `approved_text` you write, name the sentence in the source that
  mandates it and the single rule that fires it. If two rules would carry
  the same quote, at most one of them is right; the other needs its own
  `brief` and no approved text.
- **Two window placeholders, and choosing wrong states a falsehood.**
  `{sla_days}` is the window the action STARTS. `{prior_sla_days}` is the
  window that just EXPIRED. Escalation language almost always means the
  second: "the window of {sla_days} days has now expired" quotes the
  length of the NEXT window while claiming it is the one that ended.
  Observed live — approved compliance wording told an executive a
  45-business-day window had expired when the expired window was 5. The
  validator refuses this; get it right in the draft.
- **An action name states what it does.** A `close_*` action must reach a
  terminal state; a state a case can be woken from is NOT terminal.
- **Core lexicon — use these exact names for platform events**:
  `case_opened` (open), `sla_breach` (any window expiring),
  `snooze_expired` (a pause ending), `system_error`. Domain events
  (what people send back) are yours to name from the prose — but never
  coin a variant of a core name (`sla_expired`, `pause_over`): the
  monitoring integration and cross-play analytics key on the core names.
- **Style**: `template_id` is `TPL-` + UPPER-KEBAB; params are
  `snake_case` ending `_days` for windows; rule ids are one letter +
  two digits in prose order.
- **`event_rubrics`** (optional map event -> one sentence): for every
  DOMAIN event that a human's free-text reply must be classified into,
  write the classification criterion from the prose ("classify as X
  when ..."). Monitoring events need no rubric.
- **`invariants`** (optional list): when the prose states a compliance
  property ("the administrator is only reached after the full ladder",
  "a confirmed assignment always closes the case"), declare it:
  `{"kind": "action_only_from", "action": A, "states": [...],
  "except_events": [...]}` or `{"kind": "event_always_closes",
  "event": E}`. **These two kinds are the ENTIRE vocabulary — never
  coin a new kind.** A property that fits neither goes in TWO places:
  `compile_notes.md` as prose for this reviewer, AND the top-level
  `wanted_invariants` list — `[{"property": "<one sentence>", "source":
  "<the prose line it came from>"}]`. That list is advisory (no
  validator enforces it; the review renders it as "reviewed as prose"),
  and it is how the platform team measures which new invariant kinds
  the playbooks actually demand. Declared invariants are machine-checked
  on every future revision — they are the property the business is
  actually approving.
- **`approved_text`** (optional, per action): when the prose supplies or
  mandates exact wording for a communication, put it in the action's
  contract with `{item}`/`{case_id}`/`{sla_days}`/param placeholders —
  the action step then uses it verbatim instead of composing.
- **Declare the ENDS, not just the means** (optional keys, from the prose
  only): `goal` — the playbook's objective, one sentence, from its Goal
  section verbatim or near-verbatim. `success_events` — the events whose
  close means the objective was MET (a resolution, a confirmed
  assignment). `abandonment_events` — the events whose close means it was
  given up (a snooze expiring, a stop instruction). Both lists may only
  name events every handling rule routes to a terminal state — an event
  that moves the case along is progress, not an end, and the validator
  refuses it. KPI reports the play against these declarations.
- **A goal deadline is a case-level window, not another rung.** When the
  prose bounds the WHOLE situation ("must be resolved within 30 business
  days", "coverage restored within the quarter"), put the window in
  `default_params` and name it in top-level `goal_sla_param`; declare
  `goal_overdue` in events and write the rule(s) that handle it (usually
  a wildcard). It is opened once at case creation and never reset by rung
  transitions. NEVER invent a goal window the prose does not state — a
  per-step window is `sla_param`, not this.
- **You draft UNDER the capability map.** The step before you read the
  source against the catalogs and wrote
  `{{output_dir}}/capability_map.json` — one row per requirement, each
  matched to a workflow, a delivery kind, a verification record, or `none`.
  Read it FIRST. Every row is binding: a workflow the map names must be
  commissioned by a rule, a verification record carried by a contract, a
  delivery kind delivered by, and every `none` row recorded in
  `capability_requests.json` — the stage validator refuses a draft that is
  inconsistent with its own map. Where you believe a row is WRONG, do not
  silently diverge: say so in `compile_notes.md` and draft what the source
  actually asks; the reviewer sees both.
- **The catalogs are how things are SPELLED.** `deliveries_catalog.json`
  carries the only `delivery` values available here, the exact `recipients`
  an email may address, and the declared `verification.tools`;
  `workflow_catalog.json` the commissionable workflows. Name anything not
  in them and the draft is refused.
- **Work the platform already performs.** When the prose says to RUN,
  PRODUCE or ESTABLISH something — an analysis, a ranking, a report —
  read `{{output_dir}}/workflow_catalog.json` (written by the step before
  you): it lists every workflow this workspace can commission, with what
  each does. Where one does that job, the rule's action carries
  `"delivery": "workflow"`, `"workflow": "<its name, exactly as listed>"`
  and a `goal_hint` (one line, with `<item>` and `<group>` placeholders),
  the run's result arrives at the case as the action's `completion_event`
  (declare it in `events`, and write the rule that consumes it FROM THE
  STATE the commissioning rule moves to — the validator refuses a run that
  finishes into nothing), and `system_error` is declared in `events` too:
  a run can fail. A window on that state (`sla_param`) is how the prose
  bounds the wait. **NEVER name a workflow the catalog does not list.** If
  the prose asks for work no listed workflow performs, compile that step
  as a notification to the role who would do it by hand, and record the
  gap in BOTH `compile_notes.md` and `capability_requests.json` as a
  capability this workspace does not have — handing the work to a person
  is what you did INSTEAD of delivering it, never evidence that it was
  delivered. That record is how the business learns what to build next.
- **Composition: a play that opens other plays.** When the prose says
  "open/launch a per-X response for each Y" (a war room spawning
  account-level counter-plays, a review loop spawning per-site cases),
  the ordering rule's action carries `"delivery": "open_play"` and
  `"play": "<the child play id>"`. The child play is its OWN compiled,
  approved play — never inline a child ladder into the parent's states.
  The child play id must be real at delivery time; naming a play that is
  not in the catalog is refused when the action runs, not silently
  skipped. Composition that cycles (a descendant opening an ancestor's
  play) is refused by the platform.
- **Verification of a claimed outcome.** When the prose demands
  confirmation from the system of record ("verify the assignment in the
  CRM before closing", "confirm the recount was filed"), the success
  rule's action carries `"verification": {"tool": "<the reading tool>"}`
  beside its other contract fields. The capability map is where such a
  demand is recognised; where the map names a verification record, the
  contract is not optional — the act step calls exactly that tool
  and records its result as the receipt, so the ledger holds the ground
  truth beside the claim. Only when the prose asks for it.
- **Never silently guess.** A missing window, an unnamed recipient, a
  contradiction in the prose: choose the STRICTER reading, and record
  every such decision in `compile_notes.md`. An unstated detail that you
  invented without a note is a compilation defect.

## 3. `draft_play.json` — the play document

```json
{
  "play_id": "PLAY-<SLUG>-001",
  "name": "<the playbook's name>",
  "trigger_type": "<the short phrase a trigger message will contain>",
  "goal": "<one sentence, from the prose's goal>",
  "policy": {"species": "case", "template": "<same template_id>",
             "trigger_synonyms": ["<short phrases a requester would actually say>"],
             "<param>": "<override ONLY where the prose differs from the template defaults you set>"},
  "workflow_generate": "case_action",
  "workflow_deliver": null,
  "params_needed": ["group_ref", "items"],
  "body_md": "<the source playbook prose, verbatim>"
}
```

`workflow_generate` is ALWAYS `"case_action"` — the shared generic action
workflow; case plays never get their own.

## 4. `compile_notes.md`

Your assumptions, one bullet each: every default you chose that the prose
did not state, every ambiguity and which reading you took, anything the
reviewer should question. If the prose was complete, say so in one line.

## 5. `capability_requests.json` — what the workspace cannot deliver yet

A JSON list, written even when empty (`[]`). One entry for EVERY sentence
of the source marked `[capability request]`, and one for every step where
the prose asks the PLATFORM to do work — rank these, score those, produce
that — which no listed workflow performs, whichever way you compiled it.
Compiling such a step as a notification to the role who would do it by
hand does NOT make it mapped: that notification is the workaround, and
this file is where the gap it works around is recorded. Each entry:

```json
{"need": "<what the business asked for, in their words>",
 "quoted": "<the sentence from the source, verbatim>",
 "compiled_as": "<what the draft does instead - usually a notification to the role who would do it by hand>"}
```

Never drop a marked sentence: the stage validator counts the markers in
the source and refuses a draft that records fewer. A request recorded here
is what the business learns it lacks; one dropped here is never built.

## 6. Stage it (the deterministic validator decides)

Print a line of text, then run via exec:

    iof-plays compile-stage --source "{{output_dir}}/source_playbook.md" --rulebook "{{output_dir}}/draft_rulebook.json" --play "{{output_dir}}/draft_play.json" --notes "{{output_dir}}/compile_notes.md" --requests "{{output_dir}}/capability_requests.json" --map "{{output_dir}}/capability_map.json" --run-id "{{run_id}}" --out "{{output_dir}}"

- Exit 0: staged for human approval — done.
- REFUSED with ERROR lines: each names an exact defect in YOUR draft.
  Fix the named defects in the draft files and run compile-stage again
  (up to 3 rounds). Never argue with the validator, never work around
  it, never edit the source playbook to make a defect disappear.
- WARNING lines stage fine — they are for the reviewer, leave them.

## 7. Report

`STATUS: done` and `OUTPUT: compiled <template_id> (<N> rules) + <play_id>
— staged <compile_id>, <M> assumption(s) noted, <K> capability request(s)`.
