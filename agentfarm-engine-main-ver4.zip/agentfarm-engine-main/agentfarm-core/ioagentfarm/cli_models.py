"""``aicore models`` — the model registry as a person reads it.

    aicore models list  [--workspace CODE] [--json]   # the resolved registry
    aicore models check [--workspace CODE] [--json]   # default + every workflow's roles
    aicore models show <model> [--workspace CODE] [--json]

The registry is ``models.yaml`` resolved in tiers (``IOF_MODELS``, the
workspace's ``~/.iobot/workspaces/<code>/models.yaml``, the packs'). No file
in any tier means no registry, and every command says so and exits 0:
nothing is enforced on a deployment that never wrote one.

``check`` exits 0 when clean, 3 when it has findings (a retired or unlisted
model somewhere, a deprecated one, an unusable ``default:``), 1 when the
registry itself cannot be read. Console output is ASCII.

Heavy imports (yaml, the engine) happen inside the commands, so registering
the sub-app costs the CLI's startup nothing.
"""
from __future__ import annotations

import json
import os
from typing import Optional

import typer
from rich import box
from rich.console import Console
from rich.markup import escape
from rich.table import Table

models_app = typer.Typer(
    name="models",
    help="Model registry: which models this deployment allows a step to run on (models.yaml).",
    no_args_is_help=True,
)

_console = Console()

_WS = typer.Option(None, "--workspace", "-w",
                   help="Workspace code (default: the selection in force).")
_JSON = typer.Option(False, "--json", help="Machine-readable output.")

EXIT_CLEAN = 0
EXIT_ERROR = 1
EXIT_FINDINGS = 3


def _select(workspace: Optional[str]) -> Optional[str]:
    """The workspace code the registry resolves against; a bare
    ``--workspace`` also becomes the ambient selection so the workflow
    enumeration below reads the same tenant."""
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace
    from ioagentfarm.engine.model_registry import _workspace_code
    return _workspace_code(workspace)


def _load(workspace: Optional[str], as_json: bool):
    """``(registry | None, code)``; a malformed registry exits 1 with the
    reason, because "unreadable" must never print as "no registry"."""
    from ioagentfarm.engine import model_registry as mr
    code = _select(workspace)
    try:
        return mr.load_registry(code), code
    except mr.RegistryError as exc:
        if as_json:
            typer.echo(json.dumps({"error": str(exc)}, indent=2))
        else:
            _console.print(f"[red]model registry is unreadable:[/red] {exc}")
        raise typer.Exit(code=EXIT_ERROR)


def _no_registry_note(code: Optional[str]) -> str:
    from ioagentfarm.engine import model_registry as mr
    where = [f"{mr.ENV_VAR} (unset)"]
    if code:
        where.append(str(mr.workspace_models_path(code)))
    else:
        where.append("~/.iobot/workspaces/<code>/models.yaml (no workspace selected)")
    where.append("the installed packs' models.yaml")
    return ("no model registry resolves - every model is allowed. Looked in: "
            + "; ".join(where))


def _workflow_roles(code: Optional[str]) -> list[tuple[str, list]]:
    """``[(workflow_name, [Role, ...]), ...]`` for every installed workflow
    the selected workspace can run. A workflow that fails to load is
    reported by name with an empty roster rather than aborting the check."""
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    loader = WorkflowLoader()
    out: list[tuple[str, list]] = []
    try:
        names = sorted(loader.list_workflows(workspace=code))
    except Exception:  # noqa: BLE001 - no packs, no workflows: nothing to check
        return out
    for name in names:
        try:
            wf = loader.load(name, workspace=code)
            out.append((name, list(wf.roles.values())))
        except Exception:  # noqa: BLE001 - an unloadable workflow is lint's problem
            out.append((name, []))
    return out


@models_app.command("list")
def list_models(workspace: Optional[str] = _WS, as_json: bool = _JSON) -> None:
    """List the resolved model registry: model, status, version, deprecation date, source tier."""
    registry, code = _load(workspace, as_json)
    if registry is None:
        if as_json:
            typer.echo(json.dumps({"registry": None, "note": _no_registry_note(code)},
                                  indent=2))
        else:
            _console.print(f"[yellow]{_no_registry_note(code)}[/yellow]")
        return
    if as_json:
        typer.echo(json.dumps(registry.describe(), indent=2))
        return
    table = Table(title=f"Model registry ({escape(registry.location())})", box=box.ASCII)
    table.add_column("model", style="cyan")
    table.add_column("status")
    table.add_column("version")
    table.add_column("deprecated_after")
    table.add_column("source", style="dim")
    for entry in registry.models.values():
        flags = []
        if entry.deprecated_on():
            flags.append("deprecated")
        if registry.default == entry.name:
            flags.append("default")
        status = entry.status + (f" ({', '.join(flags)})" if flags else "")
        table.add_row(escape(entry.name), status, escape(entry.version) or "-",
                      entry.deprecated_after.isoformat() if entry.deprecated_after else "-",
                      registry.source)
    _console.print(table)
    if registry.default:
        _console.print(f"default: {escape(registry.default)}")


@models_app.command("show")
def show_model(model: str = typer.Argument(..., help="provider/model-name"),
               workspace: Optional[str] = _WS, as_json: bool = _JSON) -> None:
    """Show one model's registry entry and whether a step may run on it."""
    registry, code = _load(workspace, as_json)
    if registry is None:
        payload = {"model": model, "allowed": True, "entry": None,
                   "note": _no_registry_note(code)}
        if as_json:
            typer.echo(json.dumps(payload, indent=2))
        else:
            _console.print(f"{model}: allowed - {_no_registry_note(code)}")
        return
    verdict = registry.allows(model)
    entry = registry.models.get(model)
    payload = {"model": model, "allowed": verdict.ok, "deprecated": verdict.deprecated,
               "reason": verdict.reason, "suggestion": verdict.suggestion,
               "entry": entry.as_dict() if entry else None,
               "registry": registry.location()}
    if as_json:
        typer.echo(json.dumps(payload, indent=2))
    else:
        colour = "green" if verdict.ok and not verdict.deprecated else (
            "yellow" if verdict.ok else "red")
        _console.print(f"[{colour}]{'allowed' if verdict.ok else 'refused'}[/{colour}]: "
                       f"{escape(verdict.reason)}")
        if verdict.suggestion:
            _console.print(f"did you mean: {escape(verdict.suggestion)}")
        if entry:
            for k, v in entry.as_dict().items():
                if k != "model":
                    _console.print(f"  {k}: {escape(str(v)) if v not in (None, '') else '-'}")
        _console.print(f"registry: {escape(registry.location())}")
    if not verdict.ok:
        raise typer.Exit(code=EXIT_FINDINGS)


@models_app.command("check")
def check_models(workspace: Optional[str] = _WS, as_json: bool = _JSON) -> None:
    """Check the deployment default and every installed workflow's role models against the registry.

    Exit 0 when clean, 3 when there are findings, 1 when the registry cannot be read.
    """
    from ioagentfarm.engine import model_registry as mr
    registry, code = _load(workspace, as_json)
    if registry is None:
        if as_json:
            typer.echo(json.dumps({"registry": None, "findings": [],
                                   "note": _no_registry_note(code)}, indent=2))
        else:
            _console.print(f"[yellow]{_no_registry_note(code)}[/yellow]")
        return
    rows: list[dict] = []
    for f in mr.check_default(registry):
        rows.append({"scope": "registry", "severity": f.severity, "where": f.where,
                     "model": f.model, "message": f.message, "fix": f.fix})
    for f in mr.check_deployment_default(registry=registry):
        rows.append({"scope": "deployment", "severity": f.severity, "where": f.where,
                     "model": f.model, "message": f.message, "fix": f.fix})
    checked = 0
    for name, roles in _workflow_roles(code):
        checked += 1
        # check_role_models re-checks `default:`; it is reported once, above.
        for f in mr.check_role_models(roles, registry=registry):
            if f.index is None:
                continue
            rows.append({"scope": f"workflow:{name}", "severity": f.severity,
                         "where": f.where, "model": f.model, "message": f.message,
                         "fix": f.fix})
    default_model = mr.deployment_default_model()
    if as_json:
        typer.echo(json.dumps({
            "registry": registry.location(),
            "deployment_default": default_model,
            "workflows_checked": checked,
            "findings": rows,
        }, indent=2))
    else:
        _console.print(f"registry: {escape(registry.location())}")
        _console.print(f"deployment default: {escape(default_model or '(not configured)')}")
        _console.print(f"workflows checked: {checked}")
        if not rows:
            _console.print("[green]clean: every model in use is allowed[/green]")
        else:
            table = Table(title="Model registry findings", box=box.ASCII)
            table.add_column("severity")
            table.add_column("scope", style="dim")
            table.add_column("where")
            table.add_column("model", style="cyan")
            table.add_column("message")
            for r in rows:
                style = "red" if r["severity"] == mr.ERROR else "yellow"
                table.add_row(f"[{style}]{r['severity']}[/{style}]", escape(r["scope"]),
                              escape(r["where"]), escape(r["model"] or "-"),
                              escape(r["message"]))
            _console.print(table)
            for r in rows:
                _console.print(f"  fix ({escape(r['where'])}): {escape(r['fix'])}")
    if rows:
        raise typer.Exit(code=EXIT_FINDINGS)
