"""OIDC bearer verification — the inbound trust boundary, IdP-agnostic.

The engine web API had **no authentication at all**: anything that could reach
port 8111 created runs in any workspace and spent money doing it (backlog I1 /
D1). This module is the verifier that closes it, and it is deliberately NOT an
engine-only thing — the Studio API needs the identical decision for its own
Entra pass-through seam, and two verifiers drift.

WHAT IS VERIFIED, AND WHY EACH CHECK EXISTS
-------------------------------------------
Every one of these has a named failure mode. None is decoration.

``alg`` **allowlist, checked against the token's own header.**
    A token's header is attacker-controlled. ``alg: none`` and the RS→HS
    confusion attack (hand the verifier a symmetric MAC computed with the
    PUBLIC key as the secret) both live here. We pin asymmetric algorithms and
    never accept an HMAC on this path — this module verifies tokens minted by
    an *external* IdP, and an external IdP never shares a symmetric secret
    with us.

``kid`` **→ JWKS, fetched from the IdP, cached, refreshed on an unknown kid.**
    IdPs rotate signing keys on their own schedule and announce it only by
    signing with a new ``kid``. A cache with a TTL and no refresh-on-miss is a
    scheduled outage: every token fails from the moment the IdP rolls until the
    TTL happens to lapse. Refresh-on-miss is rate-limited (see
    :data:`_MIN_FORCED_REFRESH_S`) so an attacker cannot turn a stream of
    junk ``kid`` values into a DoS against the IdP *or* against us.

``iss`` **exact match against a configured allowlist.**
    Anything else means any IdP on the internet can mint tokens for us.

``aud`` **pinned — and this is the one that gets skipped.**
    Without it, a token minted for ANY OTHER application in the same directory
    is accepted here. In a large Entra tenant that is every internal app: the
    token your colleague's service already holds becomes a key to the engine.
    Audience is what makes a token *for us* rather than *from our IdP*. PyJWT
    enforces it, and :func:`verify` additionally refuses to run with an empty
    audience list rather than silently disabling the check.

``exp`` / ``iat`` / ``nbf`` with bounded leeway.
    Clock skew between the minting and verifying hosts is real; unbounded
    leeway is a token that never expires.

``tid`` (**Entra only, optional**).
    A *multi-tenant* Entra app registration is reachable by every Microsoft
    directory in the world. Pinning ``tid`` says which directory's users are
    ours. Ignored when unset, and unset is correct for a single-tenant app
    whose issuer already carries the tenant id.

Scopes / app roles.
    The last check, and an authorization one rather than an authentication
    one: a verified token still has to be entitled to this API.

THE TWO IdPs, AND WHY NOTHING BELOW IS VENDOR CODE
--------------------------------------------------
Production is **Microsoft Entra ID**; the platform is also expected to run
against **Okta**. Both are ordinary OIDC providers, so the difference is a
claim-name table, not a code path:

===============  ==========================================  ========================================
                 Entra ID (v2.0)                             Okta
===============  ==========================================  ========================================
issuer           ``https://login.microsoftonline.com/        ``https://<org>.okta.com/oauth2/<id>``
                 <tenant>/v2.0``
discovery        ``<issuer>/.well-known/openid-              ``<issuer>/.well-known/openid-
                 configuration``                             configuration``
client id claim  ``azp`` (v2.0) / ``appid`` (v1.0)           ``cid``
delegated perms  ``scp`` (space-delimited)                   ``scp`` (array) / ``scope``
app perms        ``roles`` (array)                           ``scp`` on a client-credentials token
user identity    ``preferred_username`` / ``upn`` / ``oid``  ``sub`` / ``email``
===============  ==========================================  ========================================

:func:`_claim_scopes`, :func:`_claim_roles` and :func:`_claim_subject` read
BOTH spellings of each, so one configuration shape covers either IdP and a
third one is a row in that table rather than a branch.

**Entra v1.0 tokens are a separate issuer**, ``https://sts.windows.net/
<tenant>/``, and an access token for a ``api://`` resource is frequently v1.0
even when you asked a v2.0 endpoint for it. That is why :class:`OidcConfig`
takes a LIST of issuers: pinning only the v2.0 spelling is the single most
common way an Entra integration fails at the last mile, and it fails as
"invalid issuer" against a token that is entirely genuine.

WHAT THIS MODULE DOES NOT DO
----------------------------
No token *minting* (that is :mod:`ioagentfarm.security.tokens`), no session
handling, no authorization policy beyond the scope/role gate. It turns a
string into a :class:`Principal` or raises. Callers decide what a principal is
allowed to do.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Iterable

logger = logging.getLogger(__name__)

#: Asymmetric only. See the module docstring: this path verifies tokens from an
#: external IdP, which never shares a symmetric secret with us, so accepting an
#: HMAC here could only ever be the algorithm-confusion attack succeeding.
DEFAULT_ALGORITHMS: tuple[str, ...] = ("RS256", "RS384", "RS512",
                                       "ES256", "ES384", "PS256")

#: Algorithms that must NEVER appear, whatever a caller configures. ``none`` is
#: the classic unsigned-token hole; the HS family is the confusion attack.
_FORBIDDEN_ALGORITHMS = frozenset({"none", "HS256", "HS384", "HS512"})

#: How long a fetched JWKS is served without re-asking the IdP.
DEFAULT_JWKS_TTL_S = 600

#: Floor between two FORCED refreshes (an unknown ``kid``). Without it, a
#: stream of tokens carrying junk kids is an amplified DoS: one cheap forged
#: header per outbound HTTPS request to the IdP.
_MIN_FORCED_REFRESH_S = 30

#: Network budget for discovery and JWKS. Short on purpose — this sits on the
#: request path, and an IdP that is hanging must not hang us with it.
_HTTP_TIMEOUT_S = 5.0

#: Clock-skew tolerance. Bounded: see the module docstring.
DEFAULT_LEEWAY_S = 60


class OidcConfigError(ValueError):
    """A configuration that cannot be safe, named at load time rather than
    discovered as a 401 in production."""


class TokenRejected(Exception):
    """Verification failed.

    The message is for the SERVER LOG. Callers must answer a generic 401: a
    prober that can tell 'expired' from 'bad signature' from 'wrong audience'
    is being handed a tuning oracle for free.
    """

    def __init__(self, reason: str, *, status: int = 401) -> None:
        super().__init__(reason)
        self.reason = reason
        self.status = status


@dataclass(frozen=True)
class Principal:
    """A verified caller. Never constructed from unverified input."""

    #: ``sub`` — stable per (user|service, issuer). The audit-trail identity.
    subject: str
    #: ``"service"`` for a client-credentials token (no user behind it),
    #: ``"user"`` for a delegated one. Decided by :func:`_principal_kind`.
    kind: str
    issuer: str
    #: The OAuth client that presented the token (``azp``/``appid``/``cid``).
    client_id: str = ""
    scopes: frozenset[str] = field(default_factory=frozenset)
    roles: frozenset[str] = field(default_factory=frozenset)
    #: Best-available human identity; empty for a pure service principal.
    email: str = ""
    #: Entra ``tid``. Empty on IdPs that do not have the concept.
    tenant_id: str = ""
    claims: dict[str, Any] = field(default_factory=dict)
    #: How the caller authenticated — ``"oidc"`` here, ``"apikey"`` when a
    #: caller was admitted by the shared-secret path instead. Callers log it.
    method: str = "oidc"
    #: An end user this service principal is acting FOR. Only ever set from a
    #: delegation header on an already-authenticated service call — see
    #: ``ioagentfarm.web.auth``. Never read from the token itself.
    actor: str = ""

    def label(self) -> str:
        """One-line identity for logs and audit records."""
        who = self.email or self.client_id or self.subject or "?"
        if self.actor:
            return f"{who} (for {self.actor})"
        return who


@dataclass(frozen=True)
class OidcConfig:
    """Everything needed to verify a token, with the unsafe defaults absent.

    Deliberately has NO default for ``issuers`` or ``audiences``: a config
    object that verifies nothing must be impossible to construct by omission.
    """

    #: Every issuer whose tokens we accept. A LIST because Entra mints both
    #: ``.../v2.0`` and ``https://sts.windows.net/<tid>/`` for one app — see
    #: the module docstring.
    issuers: tuple[str, ...]
    #: What the token must be FOR. Empty is refused, not treated as "any".
    audiences: tuple[str, ...]
    #: Explicit JWKS endpoint. Empty means discover it from the first issuer's
    #: ``/.well-known/openid-configuration``, which is what both IdPs publish.
    jwks_uri: str = ""
    algorithms: tuple[str, ...] = DEFAULT_ALGORITHMS
    #: Entra ``tid`` pin. Empty = no check (correct for single-tenant apps).
    tenant_id: str = ""
    #: ALL of these must be present. Empty = no scope requirement.
    required_scopes: tuple[str, ...] = ()
    #: ANY of these is enough. Empty = no role requirement.
    required_roles: tuple[str, ...] = ()
    leeway_s: int = DEFAULT_LEEWAY_S
    jwks_ttl_s: int = DEFAULT_JWKS_TTL_S

    def __post_init__(self) -> None:
        if not self.issuers or not all(i.strip() for i in self.issuers):
            raise OidcConfigError(
                "at least one issuer is required — without it any IdP on the "
                "internet can mint tokens this deployment accepts")
        if not self.audiences or not all(a.strip() for a in self.audiences):
            raise OidcConfigError(
                "at least one audience is required — without it a token "
                "minted for ANY other application in the same directory "
                "authenticates here (see the module docstring)")
        bad = _FORBIDDEN_ALGORITHMS.intersection(self.algorithms)
        if bad:
            raise OidcConfigError(
                f"refusing algorithms {sorted(bad)}: 'none' is the unsigned-"
                "token hole and the HS family is the RS→HS confusion attack. "
                f"Use any of {list(DEFAULT_ALGORITHMS)}.")
        if not self.algorithms:
            raise OidcConfigError("algorithms must not be empty")
        if self.leeway_s < 0 or self.leeway_s > 300:
            raise OidcConfigError(
                f"leeway {self.leeway_s}s is outside 0–300s; a large leeway is "
                "a token that outlives its own expiry")

    def describe(self) -> dict[str, Any]:
        """Non-secret summary, safe to log at startup and to serve from a
        status endpoint. There are no secrets in an OIDC verifier config —
        every value here is public by construction — but keep it explicit so
        nobody adds one later and leaks it through this."""
        return {
            "issuers": list(self.issuers),
            "audiences": list(self.audiences),
            "jwks_uri": self.jwks_uri or "(discovered)",
            "algorithms": list(self.algorithms),
            "tenant_id": self.tenant_id or "(any)",
            "required_scopes": list(self.required_scopes),
            "required_roles": list(self.required_roles),
        }


# ── JWKS: fetch, cache, rotate ───────────────────────────────────────────────

class JwksCache:
    """The IdP's signing keys, cached with rotation handled.

    Thread-safe and shared per issuer: a FastAPI app serves requests on many
    threads and each would otherwise fetch its own copy.

    THE ROTATION RULE. A ``kid`` we do not hold is the ONLY signal an IdP gives
    that it has rolled a key, so an unknown kid forces one refresh — but no
    more often than :data:`_MIN_FORCED_REFRESH_S`, or a stream of forged
    headers becomes an outbound request amplifier.
    """

    def __init__(self, jwks_uri: str, *, ttl_s: int = DEFAULT_JWKS_TTL_S,
                 http_timeout_s: float = _HTTP_TIMEOUT_S) -> None:
        self._uri = jwks_uri
        self._ttl_s = ttl_s
        self._timeout_s = http_timeout_s
        self._lock = threading.Lock()
        self._keys: dict[str, Any] = {}
        self._fetched_at = 0.0
        self._last_forced = 0.0

    @property
    def uri(self) -> str:
        return self._uri

    def key_for(self, kid: str) -> Any:
        """The verification key for *kid*, refreshing across a rotation.

        Raises :class:`TokenRejected` when the key is genuinely not published —
        which is what a token signed by someone else looks like.
        """
        key = self._lookup(kid)
        if key is not None:
            return key
        # Unknown kid: either a rotation we have not seen, or a forgery.
        # One rate-limited refresh distinguishes them.
        if self._force_refresh():
            key = self._lookup(kid)
            if key is not None:
                logger.info("JWKS rotation picked up from %s (kid=%s)",
                            self._uri, kid)
                return key
        raise TokenRejected(
            f"no published signing key for kid={kid!r} at {self._uri}")

    def _lookup(self, kid: str) -> Any:
        with self._lock:
            fresh = (time.time() - self._fetched_at) < self._ttl_s
            if fresh and kid in self._keys:
                return self._keys[kid]
            stale = not fresh
        if stale:
            self._refresh(forced=False)
            with self._lock:
                return self._keys.get(kid)
        return None

    def _force_refresh(self) -> bool:
        with self._lock:
            if (time.time() - self._last_forced) < _MIN_FORCED_REFRESH_S:
                return False
            self._last_forced = time.time()
        return self._refresh(forced=True)

    def _refresh(self, *, forced: bool) -> bool:
        try:
            document = _http_get_json(self._uri, self._timeout_s)
        except Exception as exc:  # noqa: BLE001 — any failure is "not now"
            # Do NOT clear the cache. A momentary IdP blip must not invalidate
            # keys we already hold and are still within TTL for; serving from a
            # slightly stale cache is strictly better than refusing every
            # request while the IdP is unreachable.
            logger.warning("JWKS refresh from %s failed (%s: %s) — serving the "
                           "cached keys", self._uri, type(exc).__name__, exc)
            return False
        keys = _parse_jwks(document)
        if not keys:
            logger.warning("JWKS at %s published no usable keys", self._uri)
            return False
        with self._lock:
            self._keys = keys
            self._fetched_at = time.time()
        logger.info("JWKS %s from %s: %d key(s)",
                    "force-refreshed" if forced else "loaded",
                    self._uri, len(keys))
        return True

    def prime(self) -> bool:
        """Fetch now, so a misconfigured issuer fails at STARTUP rather than
        on a user's first request. Returns False without raising — a boot that
        happens before the IdP is reachable must still come up."""
        return self._refresh(forced=False)


def _http_get_json(url: str, timeout_s: float) -> dict:
    import httpx

    with httpx.Client(timeout=timeout_s) as client:
        response = client.get(url, headers={"Accept": "application/json"})
    response.raise_for_status()
    return response.json()


def _parse_jwks(document: Any) -> dict[str, Any]:
    """JWKS JSON → {kid: verification key}.

    Signing keys only: a JWKS legitimately carries encryption keys too
    (``use: "enc"``), and accepting one as a signature key is a category error
    that some IdPs will happily let you make.
    """
    from jwt import PyJWK

    keys: dict[str, Any] = {}
    for entry in (document or {}).get("keys", []) or []:
        if not isinstance(entry, dict):
            continue
        if entry.get("use") not in (None, "sig"):
            continue
        kid = entry.get("kid")
        if not kid:
            continue
        try:
            keys[str(kid)] = PyJWK.from_dict(entry).key
        except Exception as exc:  # noqa: BLE001 — one bad key is not fatal
            logger.debug("skipping unusable JWKS entry kid=%s: %s", kid, exc)
    return keys


#: One cache per JWKS URI, process-wide. Verification happens on every request
#: on many threads; a per-request cache is no cache.
_caches: dict[str, JwksCache] = {}
_caches_lock = threading.Lock()


def jwks_cache_for(config: OidcConfig) -> JwksCache:
    uri = config.jwks_uri or discover_jwks_uri(config.issuers[0])
    with _caches_lock:
        cache = _caches.get(uri)
        if cache is None or cache._ttl_s != config.jwks_ttl_s:
            cache = JwksCache(uri, ttl_s=config.jwks_ttl_s)
            _caches[uri] = cache
        return cache


def reset_jwks_caches() -> None:
    """Drop every cached JWKS (tests, and a forced re-discovery)."""
    with _caches_lock:
        _caches.clear()
    _discovery.clear()


#: issuer → jwks_uri, resolved once. Discovery is a second network round trip
#: and the answer does not change between key rotations.
_discovery: dict[str, str] = {}


def discover_jwks_uri(issuer: str) -> str:
    """The issuer's ``jwks_uri``, from its OIDC discovery document.

    Both Entra and Okta publish ``<issuer>/.well-known/openid-configuration``.
    Falling back to a GUESSED path would be wrong in a way that is hard to
    see — it would work for one IdP and 404 for the next — so a failure here
    raises and names the URL it tried.
    """
    base = issuer.rstrip("/")
    cached = _discovery.get(base)
    if cached:
        return cached
    url = f"{base}/.well-known/openid-configuration"
    try:
        document = _http_get_json(url, _HTTP_TIMEOUT_S)
    except Exception as exc:  # noqa: BLE001
        raise OidcConfigError(
            f"OIDC discovery failed for issuer {issuer!r} at {url}: "
            f"{type(exc).__name__}: {exc}. Set the JWKS endpoint explicitly "
            "if this deployment cannot reach discovery.") from exc
    uri = str(document.get("jwks_uri") or "").strip()
    if not uri:
        raise OidcConfigError(
            f"discovery document at {url} carries no 'jwks_uri'")
    # The document's own issuer must agree with the one we asked about, or
    # discovery has redirected us to a different IdP's keys.
    published = str(document.get("issuer") or "").rstrip("/")
    if published and published != base:
        raise OidcConfigError(
            f"discovery at {url} declares issuer {published!r}, not {base!r} — "
            "refusing to trust its keys")
    _discovery[base] = uri
    return uri


# ── claim reading: the whole IdP-specific surface, in three functions ────────

def _claim_scopes(claims: dict) -> frozenset[str]:
    """Delegated permissions, whichever spelling the IdP uses.

    ``scp`` is a space-delimited STRING on Entra and frequently a LIST on
    Okta; ``scope`` is the RFC 8693 spelling. Reading only one of them is how
    a scope gate silently passes nothing.
    """
    found: set[str] = set()
    for name in ("scp", "scope", "scopes"):
        value = claims.get(name)
        if isinstance(value, str):
            found.update(value.split())
        elif isinstance(value, (list, tuple)):
            found.update(str(v) for v in value)
    return frozenset(found)


def _claim_roles(claims: dict) -> frozenset[str]:
    """APPLICATION ROLES only — ``roles`` / ``role``, never ``groups``.

    ``groups`` used to be unioned in here, and the documentation sells
    ``IOF_ENGINE_OIDC_REQUIRED_ROLES`` as *"any one of these APP ROLES must be
    present"*. Those are not the same authority. An app role is granted by an
    administrator consenting to this application; a directory group is
    frequently self-service, and where a tenant configures
    ``groupMembershipClaims`` to emit NAMES rather than object ids, anyone who
    can create or join a group called ``Engine.Invoke`` clears the gate
    without the role ever being consented. A validator demonstrated it: a
    token whose only relevant claim was ``groups: ["Engine.Invoke"]`` passed.

    A deployment that genuinely wants to gate on groups can name them in
    ``IOF_ENGINE_OIDC_REQUIRED_SCOPES``-style fashion in future; conflating
    the two silently is what had to stop.
    """
    found: set[str] = set()
    for name in ("roles", "role"):
        value = claims.get(name)
        if isinstance(value, str):
            found.add(value)
        elif isinstance(value, (list, tuple)):
            found.update(str(v) for v in value)
    return frozenset(found)


def _claim_client_id(claims: dict) -> str:
    for name in ("azp", "appid", "cid", "client_id"):
        value = claims.get(name)
        if value:
            return str(value)
    return ""


def _claim_email(claims: dict) -> str:
    for name in ("preferred_username", "upn", "email", "unique_name"):
        value = claims.get(name)
        if value and "@" in str(value):
            return str(value).strip().lower()
    return ""


def _principal_kind(claims: dict) -> str:
    """Service principal or human?

    A client-credentials token has no user behind it. Entra marks this with
    ``idtyp: "app"``, and independently such a token carries ``oid == sub``
    with no user-shaped claim. Okta's client-credentials tokens carry ``cid``
    and no ``uid``. Getting this wrong is not a security hole — both are
    verified — but it decides what the audit record says a run was created BY,
    so it is worth reading properly rather than guessing.
    """
    if str(claims.get("idtyp") or "").lower() == "app":
        return "service"
    if _claim_email(claims):
        return "user"
    if claims.get("uid") or claims.get("oid") not in (None, claims.get("sub")):
        return "user"
    return "service"


# ── the verification itself ──────────────────────────────────────────────────

def verify(token: str, config: OidcConfig, *,
           cache: JwksCache | None = None) -> Principal:
    """Verify *token* against *config*; return a :class:`Principal` or raise.

    Raises :class:`TokenRejected` for every failure mode. Callers must NOT
    forward the reason to the client — see :class:`TokenRejected`.
    """
    import jwt

    raw = (token or "").strip()
    if not raw:
        raise TokenRejected("empty token")

    # 1. The header, unverified — read ONLY to choose a key and to refuse an
    #    algorithm. Nothing here is trusted for any other purpose.
    try:
        header = jwt.get_unverified_header(raw)
    except Exception as exc:  # noqa: BLE001
        raise TokenRejected(f"unreadable token header: {exc}") from exc

    alg = str(header.get("alg") or "")
    if alg not in config.algorithms:
        # Named explicitly in the log because a genuine IdP misconfiguration
        # (an app registration issuing ES256 into an RS256-only allowlist)
        # is otherwise indistinguishable from an attack.
        raise TokenRejected(
            f"algorithm {alg!r} is not accepted (allowed: {list(config.algorithms)})")

    kid = str(header.get("kid") or "")
    if not kid:
        raise TokenRejected("token header carries no kid")

    jwks = cache if cache is not None else jwks_cache_for(config)
    key = jwks.key_for(kid)

    # 2. Signature + the registered claims, all in one call so none is
    #    forgotten. `require` is what makes an ABSENT claim a failure rather
    #    than a skipped check — the difference that turns `aud` from a
    #    guarantee into a suggestion.
    try:
        claims = jwt.decode(
            raw,
            key=key,
            algorithms=list(config.algorithms),
            audience=list(config.audiences),
            issuer=list(config.issuers) if len(config.issuers) > 1
            else config.issuers[0],
            leeway=config.leeway_s,
            options={
                "require": ["exp", "iat", "iss", "aud"],
                "verify_signature": True,
                "verify_exp": True,
                "verify_iat": True,
                "verify_nbf": True,
                "verify_aud": True,
                "verify_iss": True,
            },
        )
    except jwt.ExpiredSignatureError as exc:
        raise TokenRejected("token expired") from exc
    except jwt.InvalidAudienceError as exc:
        raise TokenRejected(
            f"audience mismatch (expected one of {list(config.audiences)})") from exc
    except jwt.InvalidIssuerError as exc:
        raise TokenRejected(
            f"issuer mismatch (expected one of {list(config.issuers)})") from exc
    except jwt.InvalidTokenError as exc:
        raise TokenRejected(f"invalid token: {type(exc).__name__}: {exc}") from exc

    # 3. Entra directory pin.
    if config.tenant_id:
        tid = str(claims.get("tid") or "")
        if tid != config.tenant_id:
            raise TokenRejected(
                f"tenant {tid!r} is not the configured directory "
                f"{config.tenant_id!r}")

    scopes = _claim_scopes(claims)
    roles = _claim_roles(claims)

    # 4. Entitlement. ALL scopes (a scope is a capability the caller needs),
    #    ANY role (a role is a hat the caller wears).
    missing = [s for s in config.required_scopes if s not in scopes]
    if missing:
        raise TokenRejected(
            f"token is missing required scope(s) {missing} "
            f"(carries {sorted(scopes)})", status=403)
    if config.required_roles and not roles.intersection(config.required_roles):
        raise TokenRejected(
            f"token carries none of the required app role(s) "
            f"{list(config.required_roles)} (carries {sorted(roles)})",
            status=403)

    return Principal(
        subject=str(claims.get("sub") or ""),
        kind=_principal_kind(claims),
        issuer=str(claims.get("iss") or ""),
        client_id=_claim_client_id(claims),
        scopes=scopes,
        roles=roles,
        email=_claim_email(claims),
        tenant_id=str(claims.get("tid") or ""),
        claims=claims,
        method="oidc",
    )


# ── configuration from the environment ───────────────────────────────────────

def _split(value: str) -> tuple[str, ...]:
    """Comma- or whitespace-separated list, empties dropped."""
    return tuple(part for part in
                 (p.strip() for p in (value or "").replace("\n", ",").split(","))
                 if part)


def entra_issuers(tenant_id: str) -> tuple[str, ...]:
    """Both issuer spellings for one Entra directory.

    An access token for an ``api://`` resource is often v1.0 even when
    requested from a v2.0 endpoint, so pinning only the v2.0 issuer refuses
    genuine tokens. Emitting both is what makes ``IOF_ENGINE_OIDC_TENANT_ID``
    alone a working configuration.
    """
    tid = tenant_id.strip()
    if not tid:
        return ()
    return (f"https://login.microsoftonline.com/{tid}/v2.0",
            f"https://sts.windows.net/{tid}/")


def config_from_env(prefix: str, env: dict[str, str] | None = None
                    ) -> OidcConfig | None:
    """Build an :class:`OidcConfig` from ``<prefix>_*`` variables, or None.

    None means "not configured" — the caller decides whether that is allowed.
    A PARTIAL configuration raises :class:`OidcConfigError` instead: half a
    verifier is the state where someone believes the port is protected.

    Variables (``prefix`` is e.g. ``IOF_ENGINE_OIDC``):

    ``<prefix>_ISSUER``       one or more issuer URLs (comma-separated).
    ``<prefix>_TENANT_ID``    an Entra directory id. On its own it is enough:
                              both Entra issuer spellings are derived from it,
                              and it is also pinned as ``tid``.
    ``<prefix>_AUDIENCE``     required. What tokens must be FOR — the Entra
                              Application ID URI (``api://…``) or client id,
                              or the Okta authorization-server audience.
    ``<prefix>_JWKS_URI``     override discovery (air-gapped deployments).
    ``<prefix>_ALGORITHMS``   override the algorithm allowlist.
    ``<prefix>_REQUIRED_SCOPES`` all must be present.
    ``<prefix>_REQUIRED_ROLES``  any one is enough.
    ``<prefix>_LEEWAY_S`` / ``<prefix>_JWKS_TTL_S``
    """
    src = os.environ if env is None else env

    def get(name: str) -> str:
        return (src.get(f"{prefix}_{name}", "") or "").strip()

    issuers = _split(get("ISSUER"))
    tenant_id = get("TENANT_ID")
    audiences = _split(get("AUDIENCE"))

    if not issuers and not tenant_id and not audiences:
        return None  # genuinely not configured

    if tenant_id and not issuers:
        issuers = entra_issuers(tenant_id)

    if not issuers:
        raise OidcConfigError(
            f"{prefix}_AUDIENCE is set but no issuer is: set {prefix}_ISSUER "
            f"(any OIDC provider) or {prefix}_TENANT_ID (Entra, which derives "
            "both the v1.0 and v2.0 issuer spellings)")
    if not audiences:
        raise OidcConfigError(
            f"{prefix}_ISSUER is set but {prefix}_AUDIENCE is not. Without an "
            "audience a token minted for any other application in the same "
            "directory authenticates here — this is refused, not defaulted.")

    algorithms = _split(get("ALGORITHMS")) or DEFAULT_ALGORITHMS

    def as_int(name: str, default: int) -> int:
        raw = get(name)
        if not raw:
            return default
        try:
            return int(raw)
        except ValueError as exc:
            raise OidcConfigError(
                f"{prefix}_{name} must be an integer (got {raw!r})") from exc

    return OidcConfig(
        issuers=issuers,
        audiences=audiences,
        jwks_uri=get("JWKS_URI"),
        algorithms=algorithms,
        tenant_id=tenant_id,
        required_scopes=_split(get("REQUIRED_SCOPES")),
        required_roles=_split(get("REQUIRED_ROLES")),
        leeway_s=as_int("LEEWAY_S", DEFAULT_LEEWAY_S),
        jwks_ttl_s=as_int("JWKS_TTL_S", DEFAULT_JWKS_TTL_S),
    )


def iter_bearer(authorization: str | None) -> Iterable[str]:
    """The token from an ``Authorization`` header, if it is a bearer one.

    A generator so a caller can write ``for token in iter_bearer(...)`` and
    treat "no bearer" as "no iterations" rather than as a None to forget.
    """
    value = (authorization or "").strip()
    if len(value) > 7 and value[:7].lower() == "bearer ":
        token = value[7:].strip()
        if token:
            yield token
