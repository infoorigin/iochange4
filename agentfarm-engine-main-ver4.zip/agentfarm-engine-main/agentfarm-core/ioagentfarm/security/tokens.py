"""Outbound service credentials — the caller's half of the trust boundary.

:mod:`ioagentfarm.security.oidc` decides whether an inbound token is real.
This module ACQUIRES one, for a service calling another service: the Studio
API calling the engine, and anything else that later needs to prove it is a
known workload rather than merely a reachable one.

TWO MECHANISMS, AND WHEN EACH IS RIGHT
--------------------------------------
**OAuth 2.0 client credentials** (:class:`ClientCredentialsSource`) is the
enterprise answer and the default for a real deployment. The caller is a
registered application in the directory — an Entra app registration, an Okta
service app — and the token it presents is short-lived, signed by the IdP,
scoped by an app role, and revocable centrally by disabling the registration.
Nothing long-lived crosses the wire, and the receiving side verifies it with
the same JWKS machinery it uses for a human.

**A shared API key** (:class:`ApiKeySource`) is the fallback, and it is a real
one rather than a token gesture: an air-gapped install with no reachable IdP,
a local developer stack, a smoke test. It is honest about what it is — a
bearer secret with no expiry and no central revocation — which is exactly why
the engine's startup banner names the mode it is running in.

THE RENEWAL PROPERTY IS THE POINT
---------------------------------
A statically-configured JWT works until its ``exp`` and then stops, because
nothing renews it. Measured elsewhere in this platform, that is a scheduled
outage with no alert attached: the credential was valid when it was
configured, valid when it was tested, and dead at 3am some weeks later. A
source that mints holds the renewal itself, re-minting before expiry, so the
capability does not lapse.

The one-401-retry matters for the same reason from the other end: a signing
key rotation or a revoked-and-reissued grant invalidates a cached token
mid-flight. One re-mint and one replay turns that from an incident into a
sub-second hiccup; a second 401 is the server's real answer and passes
through, because retrying past that is how a client turns its own
misconfiguration into a lockout.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger(__name__)

#: Re-mint this many seconds before expiry. A token that expires between the
#: check and the request is the exact failure this margin exists to remove.
_RENEW_SKEW_S = 60

#: Network budget for the token endpoint. Generous relative to a JWKS fetch —
#: this is a credential exchange and IdPs are slower at it — but bounded.
_TOKEN_TIMEOUT_S = 20.0

#: A token endpoint that answers without an expiry gets this. One hour is the
#: near-universal default and being wrong SHORT is harmless (we re-mint), while
#: being wrong long is the lapse described above.
_ASSUMED_LIFETIME_S = 3600.0


class CredentialError(RuntimeError):
    """The credential cannot be produced. Named at the earliest moment —
    configuration load where possible, acquisition otherwise."""


@runtime_checkable
class CredentialSource(Protocol):
    """What every outbound credential can do.

    Deliberately tiny: callers want headers to attach and a name to log. A
    caller that reaches past this for the token STRING is a caller that will
    end up logging it.
    """

    def headers(self) -> dict[str, str]:
        """Headers to attach to an outbound request. May acquire/renew."""

    def describe(self) -> str:
        """Non-secret one-liner naming the mechanism, for logs and status."""

    def invalidate(self) -> None:
        """Forget any cached credential — the peer just rejected it."""


class NullSource:
    """No credential. Explicit, so 'unauthenticated' is a thing a deployment
    STATES rather than a thing it forgets."""

    def headers(self) -> dict[str, str]:
        return {}

    def describe(self) -> str:
        return "none (unauthenticated rail)"

    def invalidate(self) -> None:
        return None


class ApiKeySource:
    """A shared secret presented in a named header.

    The header is configurable because the two sensible choices are not
    interchangeable. ``Authorization: Bearer <key>`` collides with a real
    OAuth token if a deployment ever runs both, and it invites an intermediary
    to treat the key as a JWT; a dedicated ``X-IOF-Engine-Key`` cannot be
    confused with one and lets the receiving side accept BOTH mechanisms at
    once during a migration.
    """

    def __init__(self, key: str, header: str = "X-IOF-Engine-Key") -> None:
        if not (key or "").strip():
            raise CredentialError("API key mode selected but the key is empty")
        self._key = key.strip()
        self._header = header

    def headers(self) -> dict[str, str]:
        return {self._header: self._key}

    def describe(self) -> str:
        # NEVER the key, and never a prefix of it either: a few leading
        # characters of a shared secret are a meaningful head start, and this
        # string goes to logs that leave the pod.
        return f"api key (header {self._header}, {len(self._key)} chars)"

    def invalidate(self) -> None:
        return None  # nothing cached; the key is the key


class ClientCredentialsSource:
    """Mints and RENEWS an OAuth 2.0 client-credentials access token.

    Thread-safe and shared per configuration: a FastAPI app makes concurrent
    outbound calls and they should mint once between them, not once each. The
    lock is held across the check and released across the HTTP call, so a
    slow IdP does not serialise every request behind it — at the cost of two
    concurrent mints on a cold cache, which is harmless and strictly better
    than the alternative.
    """

    def __init__(self, *, token_url: str, client_id: str, client_secret: str,
                 scope: str = "", audience: str = "",
                 timeout_s: float = _TOKEN_TIMEOUT_S) -> None:
        missing = [name for name, value in
                   (("token_url", token_url), ("client_id", client_id),
                    ("client_secret", client_secret)) if not (value or "").strip()]
        if missing:
            raise CredentialError(
                "client-credentials mode is missing " + ", ".join(missing))
        if not token_url.startswith(("http://", "https://")):
            raise CredentialError(
                f"token_url must be an http(s) URL (got {token_url!r})")
        self._token_url = token_url.strip()
        self._client_id = client_id.strip()
        self._client_secret = client_secret
        self._scope = (scope or "").strip()
        self._audience = (audience or "").strip()
        self._timeout_s = timeout_s
        self._lock = threading.Lock()
        self._token = ""
        self._expires_at = 0.0

    # -- acquisition -------------------------------------------------------

    def _form(self) -> dict[str, str]:
        form = {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
        }
        # Entra wants `scope` (…/.default); several other providers — Auth0,
        # some Okta authorization servers — want `audience`. Sending whichever
        # is configured, and both when both are, is what makes one config
        # shape work across them: a provider ignores a parameter it does not
        # use, so there is no cost to the one that is not needed.
        if self._scope:
            form["scope"] = self._scope
        if self._audience:
            form["audience"] = self._audience
        return form

    def _cached(self) -> str:
        if self._token and time.time() < self._expires_at - _RENEW_SKEW_S:
            return self._token
        return ""

    def token(self) -> str:
        """A valid access token, minting or renewing as needed."""
        with self._lock:
            cached = self._cached()
        if cached:
            return cached

        import httpx

        try:
            with httpx.Client(timeout=self._timeout_s) as client:
                response = client.post(self._token_url, data=self._form())
        except Exception as exc:  # noqa: BLE001
            raise CredentialError(
                f"token endpoint {self._token_url} unreachable: "
                f"{type(exc).__name__}: {exc}") from exc

        if response.status_code >= 400:
            # The BODY of an OAuth error is the diagnosis — `invalid_client`,
            # `invalid_scope`, `unauthorized_client` each name a different
            # mistake in the app registration. It carries no secret (the
            # request did; the response does not), so surfacing it turns a
            # day of guessing into a one-line fix.
            raise CredentialError(
                f"token endpoint {self._token_url} refused the "
                f"client-credentials grant (HTTP {response.status_code}): "
                f"{response.text[:400]}")

        try:
            payload: dict[str, Any] = response.json()
        except ValueError as exc:
            raise CredentialError(
                f"token endpoint {self._token_url} returned a non-JSON body"
            ) from exc

        token = str(payload.get("access_token") or "")
        if not token:
            raise CredentialError(
                f"token endpoint {self._token_url} returned no access_token")
        try:
            lifetime = float(payload.get("expires_in") or _ASSUMED_LIFETIME_S)
        except (TypeError, ValueError):
            lifetime = _ASSUMED_LIFETIME_S

        with self._lock:
            self._token = token
            self._expires_at = time.time() + lifetime
        logger.info("minted a service token from %s (expires in %ds, scope=%s)",
                    self._token_url, int(lifetime), self._scope or "(none)")
        return token

    # -- CredentialSource --------------------------------------------------

    def headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.token()}"}

    def describe(self) -> str:
        return (f"oauth2 client_credentials (client {self._client_id}, "
                f"token endpoint {self._token_url}, "
                f"scope {self._scope or '(none)'})")

    def invalidate(self) -> None:
        with self._lock:
            self._token, self._expires_at = "", 0.0


def entra_token_url(tenant_id: str) -> str:
    """Entra's v2.0 token endpoint for a directory."""
    return (f"https://login.microsoftonline.com/{tenant_id.strip()}"
            "/oauth2/v2.0/token")


def default_scope_for(audience: str) -> str:
    """``<audience>/.default`` — the client-credentials scope Entra requires.

    Entra rejects a client-credentials request that asks for individual
    scopes: app permissions are consented in the directory, not per request,
    so the ONLY valid scope value is the resource's ``/.default``. Getting
    this wrong produces ``AADSTS1002012``, whose text does not obviously say
    "use /.default", which is why it is derived here rather than typed.
    """
    base = audience.strip().rstrip("/")
    if not base:
        return ""
    return base if base.endswith("/.default") else f"{base}/.default"


def source_from_env(prefix: str, env: dict[str, str] | None = None,
                    *, api_key_header: str = "X-IOF-Engine-Key"
                    ) -> CredentialSource:
    """Build the outbound credential from ``<prefix>_*`` variables.

    ``<prefix>_MODE``  ``off`` | ``apikey`` | ``oauth``. Unset is inferred
                       from what else is present, so a deployment that sets
                       the OAuth variables does not ALSO have to remember to
                       flip a mode switch — a two-step configuration where
                       step two is silently optional is how a rail ends up
                       anonymous while its operator believes otherwise.

    ``apikey`` mode:   ``<prefix>_API_KEY``.

    ``oauth`` mode:    ``<prefix>_CLIENT_ID``, ``<prefix>_CLIENT_SECRET``,
                       and either ``<prefix>_TENANT_ID`` (Entra — the token
                       endpoint is derived) or ``<prefix>_TOKEN_URL`` (any
                       provider). ``<prefix>_SCOPE`` defaults to
                       ``<prefix>_AUDIENCE`` + ``/.default``.
    """
    src = os.environ if env is None else env

    def get(name: str) -> str:
        return (src.get(f"{prefix}_{name}", "") or "").strip()

    mode = get("MODE").lower()
    api_key = get("API_KEY")
    client_id = get("CLIENT_ID")

    if not mode:
        # Inferred, most specific first.
        mode = "oauth" if client_id else ("apikey" if api_key else "off")

    if mode in ("off", "none", "0", "false"):
        return NullSource()

    if mode == "apikey":
        return ApiKeySource(api_key, header=api_key_header)

    if mode == "oauth":
        tenant_id = get("TENANT_ID")
        token_url = get("TOKEN_URL") or (
            entra_token_url(tenant_id) if tenant_id else "")
        if not token_url:
            raise CredentialError(
                f"{prefix}_MODE=oauth needs {prefix}_TOKEN_URL, or "
                f"{prefix}_TENANT_ID to derive Entra's token endpoint")
        audience = get("AUDIENCE")
        scope = get("SCOPE") or default_scope_for(audience)
        return ClientCredentialsSource(
            token_url=token_url,
            client_id=client_id,
            client_secret=get("CLIENT_SECRET"),
            scope=scope,
            audience=get("OAUTH_AUDIENCE"),
        )

    raise CredentialError(
        f"{prefix}_MODE={mode!r} is not a mode; use off | apikey | oauth")
