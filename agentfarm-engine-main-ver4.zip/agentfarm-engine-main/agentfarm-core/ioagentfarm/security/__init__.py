"""Platform security primitives shared by the engine and the Studio API.

ONE verifier, two consumers — that is the whole point of this package living
in core rather than beside either caller. The engine (``ioagentfarm serve``)
and the Studio API both have to decide whether a bearer token is real, and
they must decide it the SAME way: an issuer the engine trusts and the API does
not is a deployment that authenticates differently depending on which door you
knock on, and nobody discovers that until an audit.

Contents:

* :mod:`ioagentfarm.security.oidc` — OpenID Connect / OAuth 2.0 bearer
  verification (RS256/ES256 against the IdP's published JWKS), built against
  the two IdPs this platform is deployed with: **Microsoft Entra ID** and
  **Okta**. Nothing in it is vendor-specific beyond a claim-name table.
* :mod:`ioagentfarm.security.tokens` — the outbound half: acquiring and
  RENEWING an OAuth 2.0 client-credentials token for service-to-service calls.
"""

from __future__ import annotations

__all__ = ["oidc", "tokens"]
