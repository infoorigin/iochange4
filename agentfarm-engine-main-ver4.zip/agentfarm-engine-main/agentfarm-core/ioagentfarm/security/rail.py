"""The rail credential — what a caller presents to the engine web API.

There are three callers of the engine's HTTP surface and they must all present
the SAME credential, resolved the SAME way:

* the **Studio API pod** (``app/engine_routing.engine_json`` and the handful of
  direct ``httpx`` calls beside it);
* the **CLI**, chiefly ``aicore agent-chat``, which posts a follow-up to
  ``/api/run/{id}/message`` on whatever engine ``IOF_RUN_API_URL`` names;
* anything an operator runs by hand — ``curl``, a notebook, a smoke test.

Before this module the answer was "nothing", because the engine asked for
nothing. Now that it asks, the resolution belongs in ONE place: a rail whose
API pod authenticates and whose CLI does not is a rail that works in the
Studio and 401s from the terminal, and the person hitting that has no way to
tell a broken credential from a broken deployment.

CONFIGURATION — ``IOF_ENGINE_CRED_*``
-------------------------------------
Named for what it is (the CREDENTIAL a caller presents) rather than for who
presents it, because the same variables serve all three callers and a
``.env`` both sides read is the whole point.

Microsoft Entra ID (production)::

    IOF_ENGINE_CRED_MODE=oauth
    IOF_ENGINE_CRED_TENANT_ID=<directory (tenant) id>
    IOF_ENGINE_CRED_CLIENT_ID=<the CALLER's app registration>
    IOF_ENGINE_CRED_CLIENT_SECRET=<its secret, from the workspace .env>
    IOF_ENGINE_CRED_AUDIENCE=api://<the ENGINE's application id uri>
    # scope defaults to <audience>/.default, which is the only value Entra
    # accepts for a client-credentials grant

Okta (or any OIDC provider)::

    IOF_ENGINE_CRED_MODE=oauth
    IOF_ENGINE_CRED_TOKEN_URL=https://<org>.okta.com/oauth2/<id>/v1/token
    IOF_ENGINE_CRED_CLIENT_ID=...
    IOF_ENGINE_CRED_CLIENT_SECRET=...
    IOF_ENGINE_CRED_SCOPE=engine.invoke

Shared secret (air-gapped, local, smoke tests)::

    IOF_ENGINE_CRED_MODE=apikey
    IOF_ENGINE_CRED_API_KEY=<one of the engine's IOF_ENGINE_API_KEYS>

Unset: no credential is sent, which is correct against an engine running
``IOF_ENGINE_AUTH=off`` and is what every existing local stack does.

WHY THE SOURCE IS CACHED ON THE ENV VALUE, NOT JUST CREATED ONCE
----------------------------------------------------------------
The token cache lives inside the source object, so building a new one per call
would re-mint per call — a directory round trip on every catalog read, and
Entra rate-limits. But a process-lifetime singleton is wrong in the other
direction: tests repoint the variables, and a singleton keyed on nothing
serves the first test's credential to all of them. Keyed on the resolved env
VALUES, both properties hold — and the key deliberately excludes the secret,
so the map cannot become somewhere a credential is readable.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading

from ioagentfarm.security.tokens import (ApiKeySource, CredentialError,
                                         CredentialSource, NullSource,
                                         source_from_env)

logger = logging.getLogger(__name__)

#: The env prefix every caller reads. See the module docstring.
ENV_PREFIX = "IOF_ENGINE_CRED"

#: Header the shared-secret mode uses. Must match ``web/auth.API_KEY_HEADER``;
#: pinned equal by a test rather than by hope.
API_KEY_HEADER = "X-IOF-Engine-Key"

#: Every variable that changes what credential is produced. The cache key is a
#: DIGEST of their values, so the secret itself is never a dict key.
_KEYED_ON = ("MODE", "API_KEY", "CLIENT_ID", "CLIENT_SECRET", "TENANT_ID",
             "TOKEN_URL", "AUDIENCE", "SCOPE", "OAUTH_AUDIENCE")

_cache: dict[str, CredentialSource] = {}
_cache_lock = threading.Lock()


def _fingerprint(env: dict[str, str]) -> str:
    raw = "\x00".join(f"{name}={env.get(f'{ENV_PREFIX}_{name}', '')}"
                      for name in _KEYED_ON)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def engine_credential(env: dict[str, str] | None = None) -> CredentialSource:
    """The credential this process presents to the engine.

    Never raises for "not configured" — that is :class:`NullSource`, and it is
    a legitimate deployment. A *malformed* configuration DOES raise
    :class:`CredentialError`, because half a credential is the state where a
    rail is anonymous and its operator believes otherwise.
    """
    src = os.environ if env is None else env
    key = _fingerprint(src)
    with _cache_lock:
        existing = _cache.get(key)
        if existing is not None:
            return existing
    made = source_from_env(ENV_PREFIX, env=src, api_key_header=API_KEY_HEADER)
    with _cache_lock:
        _cache[key] = made
    if not isinstance(made, NullSource):
        logger.info("engine rail credential: %s", made.describe())
    return made


def engine_auth_headers(env: dict[str, str] | None = None) -> dict[str, str]:
    """Headers proving who is calling the engine, or ``{}`` when unconfigured.

    FAIL-OPEN ON ACQUISITION FAILURE, deliberately, and this is the one place
    in this package that does. If the IdP is unreachable we return no header
    rather than raising, so the caller's own error path runs: the engine then
    answers 401 with ``WWW-Authenticate``, which is a diagnosable refusal
    naming the rail, instead of a 502 from the caller naming the token
    endpoint. Both are failures; only one tells the operator which side is
    broken. The exception is logged with its full detail either way.
    """
    source = engine_credential(env)
    try:
        return source.headers()
    except CredentialError as exc:
        logger.error("could not acquire the engine rail credential (%s) — "
                     "calling anonymously; expect 401 from the engine", exc)
        return {}


def describe_credential(env: dict[str, str] | None = None) -> str:
    """Non-secret one-liner for ``aicore current`` and status endpoints."""
    try:
        return engine_credential(env).describe()
    except CredentialError as exc:
        return f"MISCONFIGURED: {exc}"


def reset() -> None:
    """Forget every cached credential (tests, and a forced re-mint)."""
    with _cache_lock:
        _cache.clear()


def invalidate() -> None:
    """Tell every cached source its token was just rejected."""
    with _cache_lock:
        sources = list(_cache.values())
    for source in sources:
        try:
            source.invalidate()
        except Exception:  # noqa: BLE001 — best effort
            logger.debug("invalidate() failed on %r", source, exc_info=True)


__all__ = ["ENV_PREFIX", "API_KEY_HEADER", "ApiKeySource", "engine_credential",
           "engine_auth_headers", "describe_credential", "reset", "invalidate"]
