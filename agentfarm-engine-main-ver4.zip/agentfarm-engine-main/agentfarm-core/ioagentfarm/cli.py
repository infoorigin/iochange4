from __future__ import annotations

import difflib
import getpass
import io
import json
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import uuid
import warnings
from pathlib import Path
from typing import Any, Callable, Dict, List

# Force UTF-8 stdout/stderr on Windows (avoids cp1252 UnicodeEncodeError
# when iobot outputs Unicode characters like â†³, â–¶, ðŸˆ, etc.)
# RECONFIGURE IN PLACE - never rebind sys.stdout to a new wrapper here.
# The old form (`sys.stdout = io.TextIOWrapper(sys.stdout.buffer, ...)`)
# borrowed the CURRENT stream's buffer, and whoever owned that stream could
# later rebind sys.stdout back (pytest's capture plugin does exactly this
# around every test): the orphaned wrapper is then garbage-collected and
# TextIOWrapper.__del__ CLOSES the borrowed buffer - pytest's capture
# tmpfile - killing every later capture read in the process with
# "ValueError: I/O operation on closed file". Any test that imported this
# module in-process under capture (e.g. `forensics explain`'s lazy import)
# poisoned its whole shard. reconfigure() mutates the existing object, so
# there is nothing to orphan and nothing gets closed.
if sys.platform == "win32" and not os.environ.get("PYTHONIOENCODING"):
    for _std_stream in (sys.stdout, sys.stderr):
        try:
            if (getattr(_std_stream, "encoding", "") or "").lower() \
                    .replace("-", "") != "utf8":
                _std_stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            # A stream that cannot be reconfigured (no .reconfigure, or a
            # capture stand-in) is left alone: mojibake on exotic consoles
            # beats closing a stream we do not own.
            pass
    del _std_stream

# Suppress Windows asyncio ProactorEventLoop ResourceWarning on subprocess
# cleanup. Fires when iobot subprocess pipes are garbage-collected after
# process exit — benign, no data loss, pure noise in CLI output.
if sys.platform == "win32":
    warnings.filterwarnings("ignore", category=ResourceWarning, module="asyncio")

# ABOVE THE DOTENV BLOCK ON PURPOSE. Importing this captures the REAL
# environment before any file is read; a snapshot taken afterwards contains
# everything those files injected, and a workspace's own .env can then no
# longer override the machine's — which is the whole point of per-workspace
# settings. (Observed exactly that: the workspace file loaded and the repo's
# production database URL still won.)
from ioagentfarm.engine import workspace_env as _ws_env  # noqa: E402
from ioagentfarm.engine.workspace_env import (  # noqa: E402
    load_workspace_env, loaded_env, workspace_env_path,
)

# ENVIRONMENT FILES ARE PER WORKSPACE. The only file this CLI reads is
# `~/.iobot/workspaces/<workspace>/.env`, loaded by `workspace_env.load_workspace_env`
# once the target workspace is known. Anything else comes from the
# environment itself, which always takes precedence.
#
# No file is loaded at import time. Four locations previously were, and each
# applied to commands that had not named the workspace they belonged to:
#
#   ~/.env                the upward search from the working directory
#                         reaches it from most paths on Windows, where
#                         project and temporary directories are located
#                         under the home directory. This supplied a
#                         production database URL to commands run in a
#                         temporary directory, with nothing identifying the
#                         source.
#   ~/.iobot/.env         machine-wide by design, and therefore shared by
#                         every workspace on the machine.
#   <package>/../.env     for an editable install this is the checkout the
#                         CLI was installed from, so one developer's database
#                         setting applied to every directory on the machine.
#
# Existing files in those locations are reported by `aicore current` rather
# than ignored silently, so that an installation whose settings have stopped
# applying is told where to move them.
#
# `/app/.env` IS STILL READ, and is not an exception to the rule so much as a
# different mechanism. The agent runtime restricts the environment of an
# exec'd tool subprocess to HOME, LANG and TERM, so a tool the agent runs --
# `iof-query`, `iof-s3`, `vectorfs`, or a nested CLI call -- starts with no
# configuration at all. `entrypoint.sh` writes the container's injected
# variables to that path for those subprocesses to recover. The path is
# absolute and exists only inside the image, a pod serves exactly one
# workspace, and the values are the ones the deployment supplied, so it
# cannot carry another tenant's settings.
try:
    from dotenv import find_dotenv, load_dotenv

    def _load_recorded(path) -> None:
        """Load *path* and record which keys it supplied.

        Provenance is the point: `aicore current` reports the file that set
        the database URL. Reporting only whether the workspace had a file of
        its own printed "(none)" while a different file supplied a
        production database.
        """
        if not path:
            return
        try:
            from dotenv import dotenv_values
            before = set(os.environ)
            load_dotenv(path)
            _ws_env.record_provenance(
                path, [k for k in dotenv_values(path) if k not in before])
        except Exception:
            load_dotenv(path)

    _state_dir = ((os.getenv("IOF_STATE_DIR_NAME") or ".iobot").strip()
                  or ".iobot")
    # The WORKING DIRECTORY and its parents are searched too -- not to load
    # anything, but so that a file sitting there is REPORTED. A workspace repo
    # scaffolds a `.env.example` whose first line says "copy to .env", and a
    # reader who does that got no error, no effect, and no mention of the file
    # anywhere. Silence there is worse than for the home-directory files,
    # because this one the reader created on purpose.
    _seen: list[Path] = []
    try:
        _cwd = Path.cwd()
        _seen = [p / ".env" for p in (_cwd, *_cwd.parents)]
    except OSError:                         # pragma: no cover - defensive
        _seen = []
    for _legacy in (Path.home() / ".env",
                    Path.home() / _state_dir / ".env",
                    Path(__file__).resolve().parent.parent / ".env",
                    *_seen):
        try:
            if _legacy.is_file():
                _ws_env.note_ignored_env(_legacy)
        except OSError:                     # unreadable path: nothing to report
            pass
    try:
        if Path("/app/.env").is_file():
            _load_recorded(Path("/app/.env"))
    except OSError:                         # pragma: no cover - defensive
        pass
except ImportError:
    pass

import typer
from rich.console import Console
from rich.table import Table

from ioagentfarm.engine.workflow_loader import WorkflowLoader
from ioagentfarm.engine.store import Store
from ioagentfarm.engine.db import make_adapter
from ioagentfarm.engine.workspaces import (
    SkillDeclarationError, ensure_iobot_agent, persist_agent_memory)
from ioagentfarm.engine.protocol import parse_key_value_protocol
from ioagentfarm.engine.runtime_bin import runtime_bin_available
from ioagentfarm.engine.branding import rebrand as _rebrand
from ioagentfarm.engine.log_redaction import redact_line as _redact_log_line

app = typer.Typer(no_args_is_help=True)
console = Console()
logger = logging.getLogger("ioagentfarm")


#: The IMPORT packages that make up an installed SDK, and the distribution to
#: name when this environment cannot say which one provides each. `iobot` is
#: pulled in by the engine and is worth printing because it is a PEP 440 LOCAL
#: version that exists on no public index — "which iobot am I on" is otherwise
#: a `pip show` away.
#:
#: DERIVED, NOT NAMED. An organisation that republishes the SDK under its own
#: name has `ai-core-harness-engine` installed and nothing called
#: `agentfarm-core`, so a hardcoded list printed "agentfarm-core (not
#: installed)" beside a working engine — the one output whose whole job is to
#: answer "what have I got".
#: ``(import package, aicore.packs entry-point name or None, fallback)``.
#: The skills wheel is anchored on its ENTRY POINT because nothing imports
#: `agentfarm_skills` by name — see `cli_scaffold._SDK_ANCHORS` for why that
#: distinction matters and where the two wheels differ.
_SDK_PACKAGES = (("ioagentfarm", None, "agentfarm-core"),
                 ("agentfarm_skills", "skills", "agentfarm-skills"),
                 ("iobot", None, "iobot"))


def _sdk_distributions() -> list[str]:
    """The SDK's distributions, cheaply.

    `_dist_providing` walks EVERY installed distribution's metadata to find
    which one supplies an import package - the right question for an
    organisation that republished the SDK under its own name, and a 2s
    answer three times over on every `aicore --version`. The shipped name
    is a single metadata lookup; ask that first and scan only when it is
    not installed here.
    """
    from importlib.metadata import PackageNotFoundError, version as _v
    from ioagentfarm.cli_scaffold import _dist_providing
    out: list[str] = []
    for import_pkg, entry_point, fallback in _SDK_PACKAGES:
        try:
            _v(fallback)
            dist = fallback
        except PackageNotFoundError:
            dist = _dist_providing(import_pkg, entry_point) or fallback
        if dist not in out:
            out.append(dist)
    return out


def _version_text() -> str:
    from importlib.metadata import PackageNotFoundError, version as _v
    lines = []
    for dist in _sdk_distributions():
        try:
            lines.append(f"{dist} {_v(dist)}")
        except PackageNotFoundError:
            lines.append(f"{dist} (not installed)")
    return "\n".join(lines)


def _version_callback(value: bool) -> None:
    if value:
        console.print(_version_text())
        raise typer.Exit()


@app.callback()
def _root(
    version: bool = typer.Option(
        False, "--version", "-V", callback=_version_callback, is_eager=True,
        help="Print the installed SDK versions and exit."),
) -> None:
    """AI Core - build, run and operate multi-agent solutions.

    Use `--version` to report which SDK versions this environment is running;
    it is the first thing to establish in any support conversation.
    """

# Mount the forensics sub-app: `aicore forensics show <run_id>` etc.
# Defined in cli_forensics.py to keep this file from growing further.
from ioagentfarm.cli_forensics import forensics_app, forensics_watch  # noqa: E402
app.add_typer(forensics_app, name="forensics")

# WATCHING A RUN IS NOT FORENSICS. Forensics is postmortem - what happened,
# from the record, after the fact. This streams the agent's own output while
# it works, which is the live counterpart of what an attached `aicore run`
# prints. Filing it under `forensics` sent somebody looking for a debugger
# when what they wanted was to see the work. Registered at the top level as
# `aicore watch <run_id>`; it stays under `forensics` too, because a command
# that moves is a command somebody's runbook can no longer find.
app.command("watch")(forensics_watch)

# Deterministic capability router: `aicore route "<query>"` - which agent's
# DECLARED scope (its A2A card) matches, explained per term; no model call.
# Top level like `watch`: a single command, not a group. engine/router.py.
from ioagentfarm.cli_route import route as _route_command  # noqa: E402
app.command("route")(_route_command)

# Learning-governance review CLI: `aicore learning pending|approve|reject`.
from ioagentfarm.cli_learning import learning_app  # noqa: E402
app.add_typer(learning_app, name="learning")

# Content drafts, desktop half: `aicore drafts list|show|diff|apply|migrate`.
from ioagentfarm.cli_drafts import drafts_app  # noqa: E402
app.add_typer(drafts_app, name="drafts")

# Workspace memory — the durable context every agent of a workspace shares,
# reviewed by a steward. See engine/memory/ and docs/reference/workspace-memory.md.
from ioagentfarm.cli_memory import memory_app  # noqa: E402
app.add_typer(memory_app, name="memory")

# Chat guardrails: `aicore guardrails show|check` - the policy in force and
# what it does to one message. See engine/guardrails.py, docs/reference/guardrails.md.
from ioagentfarm.cli_guardrails import app as guardrails_app  # noqa: E402
app.add_typer(guardrails_app, name="guardrails")

# Data retention: `aicore retention show|prune`. A policy file per workspace
# (or IOF_RETENTION); no file means prune refuses without --older-than.
# See engine/retention.py and docs/reference/retention.md.
from ioagentfarm.cli_retention import retention_app  # noqa: E402
app.add_typer(retention_app, name="retention")

# End-user feedback on chat replies (`aicore feedback list|export`) and the
# offline eval runner (`aicore eval run|record|list|show`). See
# docs/reference/eval-and-feedback.md; engine/feedback.py and engine/eval/.
from ioagentfarm.cli_feedback import feedback_app  # noqa: E402
app.add_typer(feedback_app, name="feedback")
from ioagentfarm.cli_eval import eval_app  # noqa: E402
app.add_typer(eval_app, name="eval")

# Model registry: which models a step may run on (models.yaml, by tier).
# `aicore models list|check|show`. See engine/model_registry.py and
# docs/reference/model-registry.md.
from ioagentfarm.cli_models import models_app  # noqa: E402
app.add_typer(models_app, name="models")

# Telemetry: is export configured, and does a span actually arrive. Every
# other answer about observability is inferred, and export failures never
# break a run - so without this the first symptom is an empty dashboard.
from ioagentfarm.cli_otel import app as otel_app  # noqa: E402
app.add_typer(otel_app, name="otel")

# Tenant workspaces + solution-repo bridge: `aicore workspace push` etc.
from ioagentfarm.cli_workspace import workspace_app  # noqa: E402
app.add_typer(workspace_app, name="workspace")

# Studio API authentication: `ioagentfarm login|logout|whoami|token`. Top-level
# rather than under a `auth` sub-app because `login` is the first command a new
# reader runs and nesting it makes it something they have to be told about.
from ioagentfarm import cli_auth  # noqa: E402
cli_auth.register(app)

# Domain-repo scaffold: `aicore new-solution <name>`.
from ioagentfarm import cli_scaffold  # noqa: E402
cli_scaffold.register(app)

# Growing a pack that already exists: `new-workflow`, `new-agent`, `new-skill`.
# Separate module, same templates — `new-solution` gives you one of each and
# these are the only way to get a second without hand-writing YAML whose
# mistakes the loader forgives silently.
from ioagentfarm import cli_pack  # noqa: E402
cli_pack.register(app)


def _setup_logging(verbose: bool = False) -> None:
    """Configure logging for ioagentfarm. Called once at CLI entry."""
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


#: The agent that DRIVES a run rather than appearing in it. Alex is spawned by
#: name in three places and is in no workflow's `roles:`, which is exactly how
#: his workspace came to be the one nobody seeded — a literal in one place is
#: a literal the next caller forgets.
ORCHESTRATOR_ROLE = "project_lead"


def _default_user_id() -> str:
    """Default user_id for CLI usage: cli:<os_username>."""
    return f"cli:{getpass.getuser()}"


def _load_workspace_env_for(explicit: str | None) -> None:
    """Load ``~/.iobot/workspaces/<code>/.env`` for a command that opens NO
    store.

    The store resolvers adopt the workspace env on the way to a database;
    a command that only reads declaration files (`mcp-list`, `a2a-list`)
    never passed through one, so a `${VAR}` written into the very file
    `mcp-add` named came back "unset" (walked 2026-09-02). The real
    environment still outranks the file. No workspace selected is not an
    error here - the command says so itself.
    """
    try:
        code = explicit or None
        if not code:
            from ioagentfarm.engine.workspaces import resolved_workspace_code
            code = resolved_workspace_code()
        from ioagentfarm.engine.workspace_env import load_workspace_env
        load_workspace_env(code)
    except Exception:  # noqa: BLE001 - nothing selected, or no file: fine
        return


def _workspace_code(explicit: str | None = None, *,
                    required: bool = False, write: bool = False) -> str:
    """Resolve the active tenant workspace code — never inventing one.

    ``write=True`` is for commands that CREATE something in a tenant (`run`,
    `run-swarm`, `follow-up`). For those, a ``--workspace`` that disagrees
    with the activation (`IOF_WORKSPACE` or `workspace use`) is REFUSED, not
    warned about (docs/one-truth-content-model.md s4.4): activation is the one
    way to choose the tenant a write goes to, and "which workspace did I just
    write into?" must never have two answers. Reads keep the warning - looking
    at another tenant is harmless.

    Precedence lives in ONE place — :func:`engine.workspaces.
    selected_workspace`: ``--workspace`` > ``IOF_WORKSPACE`` >
    ``<IOF_ROOT>/active_workspace``. There is NO fallback tier: the
    resolver returns what was selected or, with ``required=True``,
    refuses. The old bottom rung — ``"default"`` — is retired: it was
    where every unselected command's work silently landed, which made
    "which workspace served this?" unanswerable.

    THIS FUNCTION USED TO READ THE FILE FIRST while the engine read the
    environment first, and nothing reconciled them — so one `aicore run`
    resolved two different tenants depending on which layer asked. The
    earlier file-first rule was answering a real complaint (an invisible
    variable beating a visible `workspace use`), but the staleness runs
    both ways, so the fix is to make a disagreement LOUD rather than to
    choose a different silent winner. A conflict now warns, naming the
    loser and how to clear it.

    A MALFORMED code is a hard error, not a degradation: a typo must never
    quietly become a different workspace. A RETIRED code (``default``) is a
    hard error naming the adoption path. ``required=False`` returns ``""``
    when nothing is selected — for the reporting commands (`current`,
    `local`, `config-check`) that must describe the unselected state rather
    than refuse in it.
    """
    from ioagentfarm.engine.workspaces import (RETIRED_WORKSPACE_CODES,
                                               selected_workspace)
    code, source, shadowed = selected_workspace(explicit)
    if write and shadowed and source == "--workspace":
        raise typer.BadParameter(
            f"active workspace is {shadowed!r}; this command writes into a "
            f"workspace, so it acts on the ACTIVE one only. Run "
            f"`{prog()} workspace use {code}` first (or unset IOF_WORKSPACE) "
            f"instead of passing --workspace {code}.")
    if shadowed and source != "--workspace":
        # LOUD, NOT SILENT — but only for the AMBIENT signals. Naming
        # `--workspace` is the operator being unambiguous for this one
        # command; warning there would fire on every invocation of the
        # documented workaround. Whichever signal loses, the operator must be
        # told: work landing in a tenant nobody selected is the failure
        # class this whole resolution path exists to prevent, and a stale
        # selector is stale in both directions.
        typer.secho(
            f"warning: workspace {code!r} (from {source}); the stored "
            f"selection is {shadowed!r} and was NOT used. Clear one: "
            f"`unset IOF_WORKSPACE` or `{prog()} workspace use {code}`.",
            err=True, fg=typer.colors.YELLOW)
    from ioagentfarm.engine.workspaces import WORKSPACE_CODE_RE
    if code and not WORKSPACE_CODE_RE.match(code):
        raise typer.BadParameter(
            f"invalid workspace code {code!r}. Codes are 2-41 chars: a "
            "lowercase letter, then lowercase letters, digits, '-' or '_'. "
            "A malformed code is refused rather than reinterpreted - a typo "
            "must never land work in a workspace you did not name.")
    if code in RETIRED_WORKSPACE_CODES:
        raise typer.BadParameter(
            "the 'default' workspace is retired: it existed only as a "
            "silent fallback, which made it impossible to tell which "
            "workspace served which answer. Create a named workspace and "
            "adopt any existing data:\n"
            f"    {prog()} workspace create <code>\n"
            f"    {prog()} workspace rename default <code>")
    if not code and required:
        # NOTHING IS SET, AND THIS COMMAND ACTS ON A TENANT. The old contract
        # fell through to `default`, which is what a run of defects had in
        # common: work recorded against a workspace nobody was looking at and
        # reported as success.
        #
        # `local`, `current` and `config-check` are exempt: local mode is
        # step one, before any workspace exists, and the other two are the
        # commands that TELL you nothing is set.
        raise typer.BadParameter(
            "no workspace is selected.\n"
            "  set one first:\n"
            f"    {prog()} workspace create <code>   # creates it and selects it\n"
            f"    {prog()} workspace use <code>      # selects an existing one\n"
            "  or name it for this command only with --workspace <code>.\n"
            f"  `{prog()} current` reports what is selected now.")
    # DELIBERATELY NOT WRITING os.environ HERE. Syncing the variable from the
    # resolver looked tidy and mutated global process state on every lookup,
    # which leaks between in-process callers -- one test's CLI invocation left
    # IOF_WORKSPACE set for the next, and the failure surfaced only when the
    # suites ran concurrently. `_activate_workspace` sets it for the commands
    # that actually spawn children, which is the only place it is needed.
    if code:
        load_workspace_env(code)
    return code


# NOTE: run attribution needs no resolver any more. Every run-creating
# command resolves its workspace with ``required=True``, so the executing
# workspace IS the attribution — there is no unselected state left to
# attribute, and ``resolve_owning_workspace``'s guess-the-owner pass with
# its silent ``default`` endpoints is gone with it.


def _workspace_is_selected(explicit: str | None = None) -> bool:
    """Was a workspace actually chosen?

    For the reporting commands (`current`, `local`, `config-check`) that
    must describe the unselected state rather than refuse in it.
    """
    if (explicit or "").strip():
        return True
    try:
        if (_root() / "active_workspace").read_text(encoding="utf-8").strip():
            return True
    except OSError:
        pass
    return bool((os.getenv("IOF_WORKSPACE") or "").strip())


def _select_workspace(code: str) -> bool:
    """Record *code* as the selected workspace. Returns whether it was written.

    The same pointer ``workspace use`` and ``workspace create`` write, so a
    command that NAMES a workspace makes it the selection and every later
    command runs bare. Failure is reported by the caller, never raised: the
    command's real work has already succeeded by the time this runs, and a
    read-only state directory should not turn that into an error.
    """
    try:
        root = _root()
        root.mkdir(parents=True, exist_ok=True)
        (root / "active_workspace").write_text(code, encoding="utf-8")
        return True
    except OSError:                            # pragma: no cover - defensive
        return False


def _activate_workspace(code: str, root_path: Path) -> None:
    """Make *code* the process-wide tenant workspace before agents are seeded.

    Points ``IOF_AGENT_HOME`` at the tenant's isolated agent home (identity +
    skills + MEMORY.md per tenant) for EVERY workspace — the old
    ``code != "default"`` carve-out left one workspace's agent home to
    ambient resolution, which is the split-brain the explicit-workspace rule
    exists to end. Subprocess env is a full ``os.environ`` copy, so every
    spawned agent inherits both. An explicitly pre-set ``IOF_AGENT_HOME`` is
    respected.
    """
    os.environ["IOF_WORKSPACE"] = code
    if not os.getenv("IOF_AGENT_HOME", "").strip():
        os.environ["IOF_AGENT_HOME"] = str(
            root_path / "workspaces" / code / "agents")


def _workspace_display_name(code: str) -> str:
    return code.replace("_", " ").title()


def _iobot_bin() -> str:
    """Resolve the agent-runtime binary. See engine/runtime_bin.py.

    Thin alias kept because this name is referenced throughout this module; the
    logic lives in ONE place so a future rename is a one-line change rather than
    a hunt through three copies.
    """
    from ioagentfarm.engine.runtime_bin import runtime_bin
    return runtime_bin()


#: Above this many characters a step prompt is handed to the agent as a FILE
#: rather than as an argv value. Windows' own ceiling is 32,767 for the WHOLE
#: command line; this leaves room for the rest of it and for a shell that
#: quotes generously, because the failure mode above the line is a silent,
#: retrying run rather than an error anyone can read.
_MESSAGE_ARG_MAX = 12000


def _resolve_session_file(workspace: Path, session_key: str) -> Optional[Path]:
    """Find the runtime's session JSONL for *session_key*, or None.

    THE NAME IS NOT THE KEY. iobot stores a session at
    ``sessions/<urlsafe_b64(key) without padding>.jsonl``
    (``session/manager.py:_storage_key``); the ``key.replace(':','_')``
    spelling is its LEGACY convention. We derived the legacy name, so the
    file was never found — and both the post-exit snapshot and the 30s
    inflight ticks failed SILENTLY. The visible symptom was
    ``tool_calls_total: 0`` on runs whose agents had plainly made tool
    calls; the real cost was that `narrative` had nothing to replay and
    `parse_session_failure` — the input Fix-6 retries on — had nothing to
    classify.

    The runtime also APPENDS a per-user suffix (``:u:<user_id>``) to the
    key it was given, so an exact-name lookup misses even with the right
    encoding. Hence the final tier: decode each stem and accept the
    session whose key is ours or extends it.

    Order: exact b64 -> legacy name -> decoded-stem match (longest first,
    so the most specific session wins when several extend the same key).
    """
    import base64

    sessions = Path(workspace) / "sessions"
    if not sessions.is_dir():
        return None

    def _b64(key: str) -> str:
        return base64.urlsafe_b64encode(key.encode()).decode().rstrip("=")

    for candidate in (sessions / f"{_b64(session_key)}.jsonl",
                      sessions / f"{session_key.replace(':', '_').replace('/', '_')}.jsonl"):
        if candidate.exists():
            return candidate

    matches: list[tuple[int, Path]] = []
    for path in sessions.glob("*.jsonl"):
        stem = path.stem
        try:
            decoded = base64.urlsafe_b64decode(
                stem + "=" * (-len(stem) % 4)).decode("utf-8")
        except Exception:
            continue
        if decoded == session_key or decoded.startswith(session_key + ":"):
            matches.append((len(decoded), path))
    if matches:
        # Longest decoded key wins - the most specific session (ties broken
        # by path name for determinism). max() on the (len, path) tuple is
        # that; sorted()[0] was its inverse and picked the SHORTEST.
        return max(matches)[1]
    return None


def _invoke_agent(
    *,
    role: str,
    session_key: str,
    message: str,
    user_id: str = "",
    root_path: Path | None = None,
    config_path: Path | None = None,
    workspace_override: Path | None = None,
    project_dir: Path | None = None,
    on_output: Callable[[str], None] | None = None,
    forensics_dir: Path | None = None,
    heartbeat: Callable[[], None] | None = None,
    display_filter: Callable[[str], str | None] | None = None,
    stall_timeout: float | None = None,
    on_stall: Callable[[int], None] | None = None,
) -> None:
    """Invoke an agent via iobot as a blocking subprocess.

    When *heartbeat* is provided, it is called once immediately and then
    every ~30s from a daemon thread for as long as the subprocess is being
    awaited (run supervisor liveness - run_step passes a closure that
    touches ``steps.heartbeat_at`` in the store). Exceptions from the
    callback are swallowed: a heartbeat must never break the run.

    Uses iobot's multi-instance support (v0.1.5+):
    - ``--config`` points to a per-run instance config (MCP servers, logs, cron)
    - ``--workspace`` points to the per-role agent workspace (identity, memory, sessions)

    When *workspace_override* is provided (e.g. a filtered workspace with only
    workflow-specific skills), it is used instead of the default iobot workspace.

    When *project_dir* is provided, ``IOBOT_WORKSPACE`` is set to the project
    directory so agents can read input files and write artifacts there.  Without
    this, iobot defaults to the identity workspace which is the wrong location
    for project work.  Sandboxing (``tools.restrictToWorkspace``) is only enabled
    when ``IOF_SANDBOX=true`` is set - agents need project directory access by
    default.

    When *root_path* is provided, sets IOF_ROOT so sub-commands find the
    correct state directory regardless of iobot's working directory.

    When the ``IOF_PROGRESS_FILE`` environment variable is set (propagated from
    a parent ``_invoke_agent_with_progress`` call), output is **teed** to both
    stdout and the progress file so the parent can tail it for live display.
    """
    from ioagentfarm.engine.workspaces import iobot_agent_workspace

    workspace = workspace_override or iobot_agent_workspace(role)

    env = os.environ.copy()
    # IOBOT_WORKSPACE controls where iobot's native file tools resolve
    # relative paths.  Point it at the project directory so agents can read
    # input files and write code artifacts there.  Falls back to identity
    # workspace if no project_dir is provided.
    env["IOBOT_WORKSPACE"] = str(project_dir) if project_dir else str(workspace)
    # Only sandbox when explicitly requested via IOF_SANDBOX=true.
    # Agents need project directory access by default (to read input files,
    # run code, etc.).  Sandboxing confines all tools to IOBOT_WORKSPACE.
    if os.environ.get("IOF_SANDBOX", "").lower() == "true":
        env["IOBOT_TOOLS__RESTRICT_TO_WORKSPACE"] = "true"
    if root_path:
        env["IOF_ROOT"] = str(root_path)

    # THE WORKSPACE HAS TO TRAVEL AS A VARIABLE, because the child cannot
    # discover it any other way. Selection normally lives in
    # `<IOF_ROOT>/active_workspace`, which the CLI finds relative to the
    # directory YOU are standing in — and this subprocess runs in the AGENT'S
    # workspace, so that file is not on its path. `IOF_ROOT` alone is not
    # enough: it locates the state directory, not which tenant inside it.
    #
    # It matters twice over. The agent's own exec'd tools inherit only the
    # allowlisted variables, and an allowlist can forward only what EXISTS —
    # so an unset IOF_WORKSPACE here silently strips the tenant from every
    # command the agent runs. That is how `forensics explain`, asked by the
    # Core Assistant about a run the CLI could see perfectly well, came back
    # "db: unavailable": no selected workspace, so the lookup raised and the
    # caller reported the degraded view.
    try:
        from ioagentfarm.engine.workspaces import maybe_workspace_code
        _ws = maybe_workspace_code()
        if _ws:
            env["IOF_WORKSPACE"] = _ws
    except Exception:                        # noqa: BLE001 - never block a spawn
        pass

    # Ensure iobot subprocess handles Unicode output on Windows
    env.setdefault("PYTHONIOENCODING", "utf-8")

    # Prepend venv bin dir to PATH so iobot's exec tool finds the correct
    # ioagentfarm (venv-local) instead of a stale system-level installation.
    venv_bin = str(Path(sys.executable).parent)
    env["PATH"] = venv_bin + os.pathsep + env.get("PATH", "")

    # STREAMING IS DECIDED BY THE PATH, NOT BY CONFIGURATION.
    #
    # This function IS the workflow path: a step agent spawned as its own
    # subprocess. Streaming was measured to hurt exactly here - it doubled
    # wall-clock, tripled tool calls, and grew stall durations three- to
    # six-fold - so the path turns it off FOR ITSELF, unconditionally,
    # rather than inheriting an operator's setting that may or may not be
    # present. A deployment can no longer half-configure this: a workflow
    # step is non-streaming because it is a workflow step.
    #
    # The other path is the always-on agents, which run IN-PROCESS through
    # `process_direct` and are never spawned here. Nothing disables
    # streaming there, so they stream - which is what a person watching a
    # Studio conversation needs: measured against this engine, non-streaming
    # cost 27-60 seconds before the first character appeared and produced
    # single gaps of 60 seconds mid-answer, because a call that takes 100
    # seconds shows nothing until it returns.
    #
    # `IOF_DISABLE_STREAMING` still works as a global override for an
    # operator who wants everything non-streaming; it is simply no longer
    # required for the workflow path to behave correctly, and setting it
    # deployment-wide now also silences the conversation path.
    env["IOF_DISABLE_STREAMING"] = "1"

    # Non-streaming request timeout (default 180s). Without this, a hung
    # MiniMax API call blocks the subprocess forever. The timeout is read
    # by _add_request_timeout() in __init__.py which wraps chat() with
    # asyncio.wait_for(). On timeout, returns an error LLMResponse that
    # Fix 6 detects and retries.
    request_timeout = os.environ.get("IOF_REQUEST_TIMEOUT_S", "180")
    env["IOF_REQUEST_TIMEOUT_S"] = request_timeout

    # Forensic Gap E: HTTP-level visibility into LLM provider responses.
    #
    # iobot's LLM client uses httpx (via the anthropic SDK). httpx logs
    # requests and responses through Python stdlib's `logging` module under
    # the loggers `httpx`, `httpcore`, `httpcore.http11`, etc. To capture
    # these, we need `logging.basicConfig(level=DEBUG)` to be called in
    # Python code BEFORE iobot imports httpx. Setting an env var alone
    # does NOT work — httpx does not honor `HTTPX_LOG_LEVEL` (verified by
    # reading httpx source: only `getLogger("httpx")` exists, no env var).
    #
    # Approach: write a small `sitecustomize.py` to a directory and inject
    # that directory into PYTHONPATH for the iobot subprocess. Python's
    # `site` module imports `sitecustomize` automatically at interpreter
    # startup, BEFORE any user code (including httpx) runs. The
    # sitecustomize reads `IOF_HTTP_LOG_FILE` from env and configures
    # stdlib logging to write httpx/httpcore debug output there.
    #
    # Result: when iobot's LLM call fails with a generic "Error calling
    # LLM" message, the actual httpx request URL, headers, body, and response
    # — plus any underlying connection-class exception — will be in
    # `forensics/attempts/<step>.<attempt>/http.log`. Operators can then
    # see exactly what HTTP traffic preceded the failure.
    #
    # Disable via IOF_DISABLE_HTTP_FORENSICS=1 if too noisy.
    # THE SHIM CARRIES THE RUNTIME PATCHES, NOT JUST THE LOGGING. It is the
    # only thing that applies them inside the subprocess — the provider swaps
    # (Azure chat-completions, GenAI Bedrock), the MiniMax tool-id dedup,
    # disable-streaming, the agency-tool restriction and the filesystem
    # allowed-dirs fix. Without it the agent runs on stock iobot.
    #
    # So it is injected ALWAYS, and only the log FILE is conditional. It used
    # to be inside the `forensics_dir is not None` branch together with
    # IOF_HTTP_LOG_FILE, which coupled two unrelated things and cost twice:
    #
    #   * a spawn with no forensics dir — `agent-chat` without a run — got no
    #     patches, so an Azure tenant on the classic /chat/completions surface
    #     was answered by the bundled provider aiming at the v1 Responses
    #     preview, and failed auth against a gateway the patched provider
    #     talks to fine;
    #   * IOF_DISABLE_HTTP_FORENSICS=1, whose name promises quieter logs,
    #     silently changed which LLM provider class every step agent ran.
    #
    # Neither announces itself. The failure surfaces as a provider error far
    # from the flag that caused it.
    try:
        # Under the run's instance dir when there is one — same content for
        # every attempt, so we write once and reuse. Otherwise under the state
        # dir, because a spawn without a run still needs the patches.
        if forensics_dir is not None:
            _inject_dir = forensics_dir.parent.parent / "_iof_logging_inject"
        else:
            _inject_dir = Path(root_path or _root()) / "_iof_logging_inject"
        _inject_dir.mkdir(parents=True, exist_ok=True)
        from ioagentfarm._iobot_patches import write_sitecustomize
        # Shared shim (also injected for the run driver by
        # web/spawn.spawn_run) — single source, no content drift.
        write_sitecustomize(_inject_dir)
        # Prepend the inject dir to PYTHONPATH so Python finds
        # sitecustomize.py at startup. Python's `site` module then
        # imports it automatically, configuring our loggers BEFORE
        # iobot imports httpx.
        env["PYTHONPATH"] = str(_inject_dir) + os.pathsep + env.get("PYTHONPATH", "")
    except Exception:
        logger.debug("Failed to inject the iobot patch shim", exc_info=True)

    if (
        forensics_dir is not None
        and os.environ.get("IOF_DISABLE_HTTP_FORENSICS", "").lower() not in ("1", "true", "yes")
    ):
        try:
            env["IOF_HTTP_LOG_FILE"] = str(forensics_dir / "http.log")
            # Native token capture: the sitecustomize above imports ioagentfarm,
            # which registers the AgentHook (apply_usage_capture). Point it at the
            # run-scoped usage file so every delegated step's LLM calls are
            # recorded (one JSONL line per call, tagged with the step's session).
            # forensics_dir = instances/<run_id>/forensics/attempts/<step>.<attempt>
            # -> parents[2] = instances/<run_id>.
            env["IOF_USAGE_FILE"] = str(forensics_dir.parents[2] / "usage.jsonl")
            # OTel: the step span's traceparent plus the model and agent
            # names, so the child's gen_ai spans join this run's trace under
            # the right step. forensics_dir.name is `<folded step>.<attempt>`.
            # No-op (env untouched) when export is off.
            try:
                from ioagentfarm.engine import otel_export as _otel
                if _otel.enabled():
                    _sk, _, _at = forensics_dir.name.rpartition(".")
                    _model = ""
                    try:
                        _cfg = json.loads(Path(config_path).read_text(encoding="utf-8")) if config_path else {}
                        _model = str((((_cfg.get("agents") or {}).get("defaults") or {}).get("model")) or "")
                    except Exception:
                        pass
                    # `_root()` adopts local mode before reading IOF_ROOT; a
                    # bare environ read here is a deciding-variable read the
                    # local-mode sweep refuses (and rightly: the child's
                    # trace root must be the one this process resolved to).
                    _otel.child_env(
                        env, root_path or _root(),
                        forensics_dir.parents[2].name, _sk,
                        int(_at) if _at.isdigit() else None,
                        IOF_OTEL_MODEL=_model, IOF_OTEL_AGENT=role,
                        IOF_RUN_ID=forensics_dir.parents[2].name, IOF_STEP_KEY=_sk)
            except Exception:
                logger.debug("otel child env failed", exc_info=True)
        except Exception:
            logger.debug("Failed to set up HTTP forensic injection", exc_info=True)

    # Per-user conversation isolation
    if user_id:
        session_key = f"{session_key}:u:{user_id}"

    # Sandbox session isolation — scope sessions by sandbox name so
    # agents in different workflow sandboxes don't share session history.
    # Prevents information leakage across workflow boundaries.
    sandbox_id = os.environ.get("IOF_SANDBOX_ID")
    sandbox_name = os.environ.get("IOF_SANDBOX_NAME", "")
    if sandbox_id and sandbox_name:
        session_key = f"{session_key}:sb:{sandbox_name}"

    cmd = [
        _iobot_bin(), "agent",
        "--no-markdown",  # suppress Rich Live rendering — prevents duplicate
                          # lines when stdout is piped and captured for messages table
        "--session", session_key,
        "--workspace", str(workspace),
    ]

    if config_path:
        cmd.extend(["--config", str(config_path)])

    # THE COMMAND LINE HAS A CEILING AND A STEP PROMPT CAN EXCEED IT. Passing
    # the message as a list item avoids cmd.exe's 8K limit, which is what the
    # comment here used to say and where it stopped: CreateProcess itself caps
    # a Windows command line at 32,767 characters, and a `playbook_compile`
    # prompt measured 35.7 KB. The spawn then fails with WinError 206 ("The
    # filename or extension is too long") - and in a DETACHED run nobody sees
    # it: the step stays `running` with empty logs, the supervisor reaps it,
    # and the next attempt fails identically until the hard cap.
    #
    # Over the threshold the prompt travels as a FILE and the child reads it
    # (the `message_from_file` runtime patch). The agent's task is unchanged;
    # only the crossing is. The file is left in place - it is the exact text
    # the agent was given, which is worth having beside the run.
    if len(message) > _MESSAGE_ARG_MAX:
        from ioagentfarm._iobot_patches import MESSAGE_FILE_PREFIX
        _pdir = (Path(config_path).parent if config_path
                 else Path(workspace)) / "prompts"
        _pdir.mkdir(parents=True, exist_ok=True)
        _pfile = _pdir / f"message-{uuid.uuid4().hex[:12]}.txt"
        _pfile.write_text(message, encoding="utf-8")
        cmd.extend(["--message", f"{MESSAGE_FILE_PREFIX}{_pfile}"])
    else:
        cmd.extend(["--message", message])

    # Wrap command for sandbox execution if IOF_RUNNER=sandbox
    from ioagentfarm.engine.sandbox import sandbox_wrap_cmd, should_sandbox, make_sandbox_env
    cmd = sandbox_wrap_cmd(cmd)
    # If sandbox-wrapped, filter env and set anti-spoof token
    if should_sandbox():
        env = make_sandbox_env(env)
    # Set subprocess cwd to project_dir so all agent operations (write_file,
    # exec, etc.) happen in the project directory.  This ensures deliverable
    # artifacts end up where the user expects them.
    agent_cwd = str(project_dir) if project_dir else None

    progress_file = os.environ.get("IOF_PROGRESS_FILE")
    # When on_output or progress_file is set, stream stdout line-by-line
    needs_streaming = progress_file or on_output

    # Forensic capture (Phases 1 & 2). When the caller passes a per-attempt
    # `forensics_dir`, every blob is written there so failed runs can be
    # reconstructed after the fact:
    #
    #   forensics_dir/
    #     stderr.log              â† raw iobot stderr (was previously
    #                                truncated on each retry under runs/)
    #     stdout.log              â† raw bytes from iobot stdout (we
    #                                already process them for the messages
    #                                table; this preserves the original
    #                                stream including \r and ANSI codes
    #                                so terminal-control bugs are visible)
    #     prompt.txt              â† the rendered step prompt (the
    #                                --message arg) so we know exactly
    #                                what the agent was told
    #     env-snapshot.json       â† env vars at spawn time, filtered by
    #                                the secret allowlist below
    #     exit.json               â† {exit_code, duration_s, started_at,
    #                                ended_at, signal_killed}
    #     session-snapshot.jsonl  â† copy of iobot's session JSONL after
    #                                the subprocess exits, before any
    #                                next attempt overwrites it
    #
    # Callers that don't pass `forensics_dir` (e.g. run_task) get the
    # legacy stderr-under-runs behavior so we don't break unrelated paths.
    if forensics_dir is not None:
        forensics_dir.mkdir(parents=True, exist_ok=True)
        stderr_log_path = forensics_dir / "stderr.log"

        # Phase 2: write the rendered step prompt — this is what the agent
        # actually saw, including all template substitutions.
        try:
            (forensics_dir / "prompt.txt").write_text(message, encoding="utf-8")
        except Exception:
            logger.debug("Failed to write forensics prompt.txt", exc_info=True)

        # Phase 2: write filtered env snapshot. Strict secret allowlist —
        # we never write credentials/tokens/keys/passwords/database URLs to
        # the forensics dir (which gets pushed to S3). The allowlist keeps
        # only operationally-useful vars.
        try:
            _ALLOW_PREFIXES = (
                # Tenant identity — which workspace and agent home this step
                # actually resolved. Omitting it made a scoped run's snapshot
                # indistinguishable from a default one, so "did isolation
                # reach the step agent?" could not be answered from forensics.
                "IOF_WORKSPACE", "IOF_AGENT_HOME",
                "IOF_ROOT", "IOF_RUNNER", "IOF_STORAGE", "IOF_S3_BUCKET",
                "IOF_S3_PREFIX", "IOF_S3_REGION", "IOF_S3_ENDPOINT",
                "IOF_PROGRESS_FILE", "IOF_SANDBOX",
                # The reliability toggles. Their absence here made the most
                # important question a postmortem can ask - "was this step
                # running the configuration we think it was?" - unanswerable
                # from the snapshot, so it had to be inferred from HTTP
                # content-types in http.log. A run whose streaming setting had
                # silently reverted looked identical to one where it had not.
                "IOF_DISABLE_STREAMING", "IOF_REQUEST_TIMEOUT_S",
                "IOF_STALL_MAX_RETRIES", "IOF_HARD_ATTEMPT_CAP_MULTIPLIER",
                "IOF_LEARNING_V2", "IOF_EXEC_STEP_TIMEOUT_S",
                "IOBOT_WORKSPACE", "IOBOT_TOOLS",
                "VECTORFS_STORE", "VECTORFS_COLLECTION",
                "PYTHONIOENCODING", "PYTHONUNBUFFERED",
                "PATH", "HOME", "USERPROFILE", "USERNAME",
                "LANG", "TERM", "TZ",
            )
            _DENY_SUBSTRINGS = (
                "_KEY", "_TOKEN", "_SECRET", "_PASSWORD", "_PASS",
                "_CREDENTIAL", "_API_KEY", "DATABASE_URL",
            )
            def _safe_env_value(k: str, v: str) -> bool:
                ku = k.upper()
                if any(d in ku for d in _DENY_SUBSTRINGS):
                    return False
                # Drop URLs containing user:pass@ inline credentials
                if "://" in v and "@" in v.split("://", 1)[1].split("/", 1)[0]:
                    return False
                return True
            filtered_env = {
                k: v for k, v in env.items()
                if any(k.upper().startswith(p) for p in _ALLOW_PREFIXES)
                and _safe_env_value(k, v)
            }
            (forensics_dir / "env-snapshot.json").write_text(
                json.dumps(filtered_env, indent=2, sort_keys=True),
                encoding="utf-8",
            )
        except Exception:
            logger.debug("Failed to write forensics env-snapshot.json", exc_info=True)
    elif root_path:
        # Legacy stderr destination for non-forensics callers (run_task etc).
        # This is overwritten on each call — that's the bug Phase 1 fixes for
        # run_step, but other callers don't have an attempt concept yet.
        stderr_log_dir = root_path / "runs" / session_key.replace(":", "_").replace("/", "_")
        stderr_log_dir.mkdir(parents=True, exist_ok=True)
        stderr_log_path = stderr_log_dir / "iobot_stderr.log"
    else:
        stderr_log_path = None
    stderr_fh = open(stderr_log_path, "w", encoding="utf-8") if stderr_log_path else subprocess.DEVNULL

    # Run-supervisor heartbeat: tick the provided callback every ~30s while
    # we are blocked on the subprocess (same cadence as the inflight forensic
    # snapshot). Runs regardless of streaming mode. If this process dies with
    # the subprocess, beats stop and the supervisor reaps the step.
    _hb_stop = None
    if heartbeat is not None:
        import threading as _hb_threading
        try:
            heartbeat()  # immediate first beat so heartbeat_at is never NULL
        except Exception:
            logger.debug("heartbeat callback failed (initial)", exc_info=True)
        _hb_stop = _hb_threading.Event()

        def _heartbeat_loop() -> None:
            while not _hb_stop.wait(30.0):
                try:
                    heartbeat()
                except Exception:
                    logger.debug("heartbeat callback failed", exc_info=True)

        _hb_threading.Thread(
            target=_heartbeat_loop,
            name=f"iof-heartbeat-{session_key[:24]}",
            daemon=True,
        ).start()

    try:
        if needs_streaming:
            # Stream mode: pipe stdout as RAW BYTES and interpret as a terminal
            # stream (not as universal-newline text).
            #
            # Why bytes, not text mode?
            #   iobot uses Rich Live (auto_refresh=False) to stream LLM
            #   output. On every token delta it redraws the entire buffer.
            #   Rich's Console is created with force_terminal=True, so even
            #   when stdout is piped, Rich emits terminal control sequences.
            #
            #   On Linux, Rich uses CSI sequences (\x1b[A cursor up + \x1b[K
            #   clear line) — no bare \r — so each visual line gets exactly
            #   one \n in the stream and Python's universal newlines iteration
            #   works fine.
            #
            #   On Windows (Git Bash / mintty), Rich falls back to bare \r
            #   carriage returns to rewind the current line. Python's
            #   universal newlines translates every \r into \n, so each
            #   Live refresh of a single visual line produces multiple
            #   "lines" in text-mode iteration — and they are the progressive
            #   buildup of the same content. That's what caused the
            #   messages-table duplication on Windows while pods stayed clean.
            #
            # The fix: read bytes, maintain a current-line buffer, reset on
            # \r (cursor return), emit on \n, and strip ANSI escape sequences
            # before emit. This is how a real terminal interprets the stream
            # and produces the correct "one emit per visual line" behavior
            # on both platforms.
            import re as _re
            _ANSI_RE = _re.compile(rb"\x1b\[[0-?]*[ -/]*[@-~]")

            env["PYTHONUNBUFFERED"] = "1"
            import time as _time
            _spawn_started_at = _time.time()
            proc = subprocess.Popen(
                cmd, env=env, cwd=agent_cwd,
                stdout=subprocess.PIPE, stderr=stderr_fh,
                bufsize=0,
            )
            # Python 3.14: bufsize=0 returns unbuffered FileIO which lacks read1.
            # Wrap in BufferedReader so the read1() call below works.
            import io
            proc.stdout = io.BufferedReader(proc.stdout)
            pf = open(progress_file, "a", encoding="utf-8") if progress_file else None
            # Phase 1: tee raw stdout bytes to forensics/stdout.log so we can
            # see exactly what iobot emitted (including \r and ANSI codes)
            # — useful for diagnosing terminal-control / stream-encoding bugs.
            #
            # Forensic Gap A fix: open with buffering=0 (unbuffered binary)
            # so each chunk write hits disk immediately. The default Python
            # binary buffering (~8KB) caused the on-disk stdout.log to lag
            # the live messages table by tens of seconds during long runs —
            # operators reading stdout.log mid-run saw stale data and
            # couldn't correlate it with what the agent was actually doing.
            _stdout_blob = (
                open(forensics_dir / "stdout.log", "wb", buffering=0)
                if forensics_dir is not None else None
            )

            # Fix 5: in-flight session snapshot daemon thread.
            #
            # iobot writes the per-step session JSONL atomically (rewrite-
            # in-place at every checkpoint), so the file is always either
            # the previous full state or the latest full state — never
            # mid-write. We can copy it any time without locking.
            #
            # We launch a daemon thread that copies the session JSONL every
            # 30s while the subprocess is alive, into:
            #
            #   forensics_dir / inflight / session-<HHMMSS>.jsonl
            #
            # This gives us a checkpoint trail for in-progress steps. If the
            # subprocess hangs, we can see exactly what state it was in at
            # each 30s tick — what tool calls had been made, what the LLM
            # was responding with, whether it was waiting on a tool result.
            # The post-exit session-snapshot.jsonl (also written by Phase 1)
            # is the FINAL state; the inflight snapshots are the journey.
            import threading as _threading
            _inflight_stop = _threading.Event()
            def _inflight_session_snapshot_loop() -> None:
                if forensics_dir is None:
                    return
                inflight_dir = forensics_dir / "inflight"
                try:
                    inflight_dir.mkdir(parents=True, exist_ok=True)
                except Exception:
                    return
                tick = 0
                last_digest = None
                while not _inflight_stop.wait(30.0):
                    tick += 1
                    try:
                        # Resolved EVERY tick, not once: the file does not
                        # exist until the agent's first turn is persisted,
                        # so a path computed before the loop started was
                        # permanently wrong for the whole run.
                        session_src = _resolve_session_file(
                            workspace, session_key)
                        if session_src is not None:
                            # UNCHANGED SESSION, NO COPY. Measured on one
                            # run: 151 snapshots, 88% byte-identical to the
                            # previous one - a stall is precisely the time
                            # nothing changes, so the evidence ballooned
                            # exactly when it mattered (42 files, 2 distinct).
                            # The post-exit session-snapshot.jsonl is the
                            # final state either way.
                            import hashlib as _hl
                            digest = _hl.sha1(session_src.read_bytes()).hexdigest()
                            if digest == last_digest:
                                continue
                            last_digest = digest
                            from datetime import datetime as _dt
                            ts = _dt.utcnow().strftime("%H%M%S")
                            dst = inflight_dir / f"session-{ts}.jsonl"
                            import shutil as _sh
                            _sh.copy2(str(session_src), str(dst))
                    except Exception:
                        # Silent — never break the run for a snapshot failure
                        pass
            _inflight_thread = _threading.Thread(
                target=_inflight_session_snapshot_loop,
                name=f"inflight-snapshot-{session_key[:20]}",
                daemon=True,
            )
            _inflight_thread.start()

            _cur = bytearray()

            def _emit_line() -> None:
                if not _cur:
                    return
                # Strip ANSI escape codes, decode, and dispatch.
                clean = _ANSI_RE.sub(b"", bytes(_cur)).decode("utf-8", errors="replace")
                # Present the runtime as `iobot` — the vendored CLI prints a
                # "iobot" banner and loguru stamps module names, both of which
                # land in the workflow developer's terminal and the Studio
                # messages table.
                #
                # Applied HERE and only here: on decoded text, after ANSI
                # stripping, at emit time. Never on the raw byte buffer — the
                # CR/LF state machine above (bare \r = cursor rewind, _saw_cr
                # spanning chunk boundaries) is load-bearing, and touching the
                # bytes would reintroduce the multi-line duplication bug on
                # Windows. forensics/stdout.log is teed separately from the raw
                # bytes, so the evidence stays pristine.
                clean = _rebrand(clean)
                # The runtime logs both halves of every turn at INFO. In-process
                # that is redacted by the loguru patcher; a subprocess's output
                # never passes through it, so the same rule is applied here or a
                # run's console and log would carry what `serve` no longer does.
                clean = _redact_log_line(clean)
                # Re-add newline for downstream consumers that expect it.
                payload = clean + "\n"
                # display_filter shapes what the USER sees, and only that:
                # the progress file and on_output still receive every line,
                # because they feed forensics and the Studio, where "the
                # console was quiet" must never mean "the record is missing".
                shown = clean if display_filter is None else display_filter(clean)
                if shown is not None:
                    out = shown + "\n"
                    try:
                        sys.stdout.write(out)
                    except UnicodeEncodeError:
                        sys.stdout.write(out.encode("ascii", errors="replace").decode("ascii"))
                    sys.stdout.flush()
                if pf:
                    pf.write(payload)
                    pf.flush()
                if on_output:
                    on_output(payload)

            # State for CR/LF handling. Must span chunk boundaries because a
            # \r at the end of one chunk and \n at the start of the next is
            # still a valid CRLF pair.
            _saw_cr = False
            # THE STALL WATCHDOG. `proc.stdout.read()` blocks, so a child
            # that has stopped producing output blocks it forever - and
            # nothing above bounds that. Measured in a build session: a turn
            # sat here for 25.1 minutes while the provider retried, then
            # answered "[Assistant reply unavailable due to model error.]".
            # The corpus only escaped because ITS harness kills at 600s; a
            # scripted `aicore build --message` has no such rescue and an
            # interactive user has only Ctrl+C.
            #
            # OPT-IN, and off for a run: a workflow step legitimately goes
            # quiet for minutes and the run engine's own recovery is built
            # to absorb that. Only `aicore build` passes a value.
            _last_chunk = [_time.monotonic()]
            _stalled = [False]
            _stall_stop = _threading.Event()

            def _stall_watch() -> None:
                while not _stall_stop.wait(1.0):
                    if _time.monotonic() - _last_chunk[0] < stall_timeout:
                        continue
                    _stalled[0] = True
                    logger.warning(
                        "build turn stalled: no output for {}s - ending it",
                        int(stall_timeout))
                    if on_stall is not None:
                        try:
                            on_stall(int(_time.monotonic() - _last_chunk[0]))
                        except Exception:      # noqa: BLE001
                            logger.debug("on_stall raised", exc_info=True)
                    try:
                        proc.kill()
                    except Exception:          # noqa: BLE001
                        logger.debug("could not kill a stalled child",
                                     exc_info=True)
                    return

            _stall_thread = None
            if stall_timeout:
                _stall_thread = _threading.Thread(target=_stall_watch,
                                                 daemon=True,
                                                 name="build-stall-watch")
                _stall_thread.start()
            try:
                while True:
                    # `read1`, NOT `read`. `read(4096)` blocks until it has
                    # 4096 bytes or EOF, so a child producing output slowly
                    # is indistinguishable from one producing none - and the
                    # stall watchdog below would kill a turn that was
                    # working. `read1` returns whatever has arrived, which
                    # is what a streaming reader wants regardless: the
                    # byte-level CR/LF handling already spans chunk
                    # boundaries, so smaller chunks change nothing about it.
                    # Caught by the test for the case that must NOT fire.
                    chunk = proc.stdout.read1(4096) if proc.stdout else b""
                    _last_chunk[0] = _time.monotonic()
                    if not chunk:
                        break
                    # Tee raw bytes to forensics blob BEFORE byte-level
                    # processing so we capture the original stream including
                    # \r, ANSI codes, and anything else stripped downstream.
                    if _stdout_blob is not None:
                        try:
                            _stdout_blob.write(chunk)
                        except Exception:
                            logger.debug("Failed to write forensics stdout chunk", exc_info=True)
                    for b in chunk:
                        if _saw_cr:
                            _saw_cr = False
                            if b == 0x0A:  # \r\n — CRLF line ending: emit
                                _emit_line()
                                _cur.clear()
                                continue
                            # Bare \r (Rich Live cursor return on Windows):
                            # discard the current visual line so the next
                            # render overwrites it. Then fall through to
                            # process the current byte normally.
                            _cur.clear()
                        if b == 0x0D:
                            _saw_cr = True
                            continue
                        if b == 0x0A:  # bare \n — Unix LF line ending: emit
                            _emit_line()
                            _cur.clear()
                            continue
                        _cur.append(b)
                # At EOF, a trailing bare \r means the buffer was reset and
                # nothing followed — drop it. Otherwise, flush any final line.
                if _saw_cr:
                    _cur.clear()
                if _cur:
                    _emit_line()
            finally:
                if pf:
                    pf.close()
                if _stdout_blob is not None:
                    try:
                        _stdout_blob.close()
                    except Exception:
                        pass
                # Fix 5: stop the in-flight snapshot daemon. The post-exit
                # session-snapshot.jsonl is written below, so the daemon's
                # job is done as soon as proc.wait() returns.
                _inflight_stop.set()
                # And the stall watchdog: its job ends the moment the child
                # is done, and a live timer past that would kill the NEXT
                # process to reuse the handle.
                _stall_stop.set()
            # EOF on the child's stdout. The loop above ends HERE, and only then
            # do we wait() - so any delay after this point is the child lingering
            # with its work finished, not the child working.
            #
            # Recorded because the distinction was invisible and I got it wrong
            # reasoning from what WAS visible: the session file stops changing
            # while a tool call is in flight, so an unchanged session reads as
            # "idle" when it means "no completed turn". Measuring stdout EOF
            # against exit separates the two without inference.
            _spawn_eof_at = _time.time()
            rc = proc.wait()
            _spawn_ended_at = _time.time()

            # Phase 1: write exit.json so post-mortem can distinguish
            # "exited cleanly with no OUTPUT.md" (rc=0, missing protocol)
            # from "subprocess crashed" (rc!=0) from "killed by signal"
            # (rc<0 on POSIX) etc.
            if forensics_dir is not None:
                try:
                    exit_info = {
                        "exit_code": rc,
                        "started_at": _spawn_started_at,
                        "ended_at": _spawn_ended_at,
                        "duration_s": round(_spawn_ended_at - _spawn_started_at, 3),
                        # stdout closed here; the gap to ended_at is the child
                        # holding on after it had nothing left to say. Emitted
                        # in the step.subprocess_exited payload (this dict IS
                        # that payload), so it is queryable per run rather than
                        # reconstructed from file mtimes afterwards.
                        "stdout_eof_at": _spawn_eof_at,
                        "stdout_eof_s": round(_spawn_eof_at - _spawn_started_at, 3),
                        "reap_lag_s": round(_spawn_ended_at - _spawn_eof_at, 3),
                        "signal_killed": (rc is not None and rc < 0),
                        "signal_number": (-rc if (rc is not None and rc < 0) else None),
                    }
                    (forensics_dir / "exit.json").write_text(
                        json.dumps(exit_info, indent=2), encoding="utf-8",
                    )
                except Exception:
                    logger.debug("Failed to write forensics exit.json", exc_info=True)

                # Phase 1: snapshot the iobot session JSONL after the
                # subprocess exits, BEFORE any next attempt overwrites it.
                # Snapshotting gives us the full LLM/tool dialog for this
                # attempt even if the same session_key gets reused on retry.
                try:
                    session_src = _resolve_session_file(workspace, session_key)
                    if session_src is not None:
                        import shutil as _shutil
                        _shutil.copy2(
                            str(session_src),
                            str(forensics_dir / "session-snapshot.jsonl"),
                        )
                    else:
                        # LOUD, not silent: this file is the richest forensic
                        # artifact (tool counts, narrative replay, and the
                        # failure classification Fix-6 retries on), and its
                        # absence used to look like "the agent made 0 tool
                        # calls" rather than "we looked in the wrong place".
                        logger.warning(
                            "no session file found for key %r under %s - "
                            "session-snapshot.jsonl will be missing and "
                            "tool counts/narrative/failure-classification "
                            "degrade for this attempt",
                            session_key, workspace / "sessions")
                except Exception:
                    logger.debug("Failed to snapshot session JSONL", exc_info=True)

                # NOTE: OUTPUT.md snapshot is taken by the caller (run_step)
                # which knows the actual per-step OUTPUT.md path under
                # .iof/runs/<run_id>/steps/<step_key>/OUTPUT.md. _invoke_agent
                # doesn't know step_key directly, so it can't compute that path.

            if rc != 0:
                console.print(
                    f"\n[red bold]Agent ({role}) exited with code {rc}.[/red bold] "
                    f"[dim]Possible cause: maxToolIterations or exec timeout reached.[/dim]"
                )
        else:
            result = subprocess.run(cmd, env=env, cwd=agent_cwd,
                                    stderr=stderr_fh)
            if result.returncode != 0:
                msg = f"\n[red bold]Agent ({role}) exited with code {result.returncode}.[/red bold] "
                if stderr_log_path:
                    msg += f"[dim]See stderr: {stderr_log_path}[/dim]"
                else:
                    msg += f"[dim]Possible cause: maxToolIterations or exec timeout reached.[/dim]"
                console.print(msg)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
    finally:
        if _hb_stop is not None:
            _hb_stop.set()
        if stderr_log_path and hasattr(stderr_fh, "close"):
            try:
                stderr_fh.close()
            except Exception:
                pass


def _launch_detached(cmd: list[str], env: dict | None = None, log_file: Path | None = None) -> None:
    """Launch a subprocess detached from the current terminal.

    The child process runs independently and survives if the parent exits.
    When *log_file* is provided, stdout/stderr go to that file (diagnosable).
    Otherwise they are discarded.
    """
    # Wrap command for sandbox execution if IOF_RUNNER=sandbox
    from ioagentfarm.engine.sandbox import sandbox_wrap_cmd, should_sandbox, make_sandbox_env
    cmd = sandbox_wrap_cmd(cmd)
    if should_sandbox():
        env = make_sandbox_env(env or os.environ.copy())

    if log_file:
        # Open log file for the child process. The parent closes its handle
        # after Popen inherits it — the child keeps writing to the file.
        log_fh = open(log_file, "a", encoding="utf-8")
        kwargs: dict[str, Any] = {
            "stdout": log_fh,
            "stderr": log_fh,
            "stdin": subprocess.DEVNULL,
        }
    else:
        kwargs = {
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
            "stdin": subprocess.DEVNULL,
        }
    if env:
        kwargs["env"] = env

    if platform.system() == "Windows":
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        DETACHED_PROCESS = 0x00000008
        kwargs["creationflags"] = CREATE_NEW_PROCESS_GROUP | DETACHED_PROCESS
        # Ensure file handles (log file) are inherited by the child
        kwargs["close_fds"] = False
    else:
        kwargs["start_new_session"] = True

    subprocess.Popen(cmd, **kwargs)

    # Close parent's copy of the log file handle — child has its own via inheritance
    if log_file and log_fh:
        log_fh.close()


def _AGENT_NAMES() -> Dict[str, str]:  # noqa: N802 – kept as pseudo-constant
    """Dynamic role->name mapping from bundled SOUL.md files."""
    from ioagentfarm.engine.workspaces import _agent_names
    return _agent_names()


def _match_step_key(partial: str, step_info: Dict[str, dict]) -> str:
    """Match a potentially truncated step key against known keys.

    iobot truncates long tool args (e.g. ``assess`` -> ``ass``).
    Prefix-match against known step keys to recover the full key.
    """
    if partial in step_info:
        return partial
    for key in step_info:
        if key.startswith(partial):
            return key
    return partial


def _is_noise(line: str) -> bool:
    """Return True if *line* is a noise/protocol line that should not be shown to the user."""
    s = line.strip()
    if not s:
        return True
    if s.startswith("STATUS:") or s.startswith("OUTPUT:"):
        return True
    if "write_file" in s and ("STATUS:" in s or "OUTPUT" in s):
        return True
    if "(io) iobot" in s:  # runtime header/footer
        return True
    return False


def _start_tailer(
    progress_file: str,
    console: Console,
    lock,  # threading.Lock
    step_info: Dict[str, dict],
    total_steps: int,
) -> tuple:
    """Start a daemon thread that tails *progress_file* and prints output.

    Handles three kinds of content in the progress file:

    - ``IOF_STEP_START:<key>:<role>`` - prints a ``â-¶ Step N/M`` banner
    - ``IOF_STEP_END:<key>:<role>``   - prints a ``âœ" done [Xs]`` completion line
    - Regular lines                    - prints filtered sub-agent thinking (dim)

    Returns ``(stop_event, thread)`` - call ``stop_event.set()`` then
    ``thread.join(timeout)`` to shut down.
    """
    import threading
    import time

    stop_event = threading.Event()
    step_start_time: list[float | None] = [None]  # mutable container for closure

    def _tail() -> None:
        pos = 0
        while not stop_event.is_set():
            try:
                with open(progress_file, "r", encoding="utf-8") as f:
                    f.seek(pos)
                    new = f.read()
                    if new:
                        pos = f.tell()  # use tell() for accurate position on Windows
                        for ln in new.splitlines():
                            if ln.startswith("IOF_STEP_START:"):
                                _, key, role = ln.strip().split(":", 2)
                                info = step_info.get(key, {})
                                seq = info.get("seq", "?")
                                name = _AGENT_NAMES().get(role, role)
                                with lock:
                                    console.print(
                                        f"\n  [cyan]> Step {seq}/{total_steps}:[/cyan] "
                                        f"[bold]{key}[/bold] [dim]({role})[/dim] - handing off to {name}..."
                                    )
                                step_start_time[0] = time.time()
                            elif ln.startswith("IOF_STEP_END:"):
                                _, key, role = ln.strip().split(":", 2)
                                elapsed = time.time() - step_start_time[0] if step_start_time[0] else 0
                                with lock:
                                    console.print(f"  [green]+[/green] {key} [dim]({role})[/dim] done [{elapsed:.1f}s]")
                                step_start_time[0] = None
                            elif not _is_noise(ln):
                                # Agent stream content is UNTRUSTED for Rich markup:
                                # bracket sequences in LLM output (e.g. "[/dim italic]")
                                # raise MarkupError and kill the run driver mid-run.
                                from rich.markup import escape as _rich_escape

                                with lock:
                                    console.print(f"    [dim]{_rich_escape(ln.rstrip())}[/dim]")
            except FileNotFoundError:
                pass
            stop_event.wait(0.3)

    t = threading.Thread(target=_tail, daemon=True)
    t.start()
    return stop_event, t


def _invoke_agent_with_progress(
    *,
    role: str,
    session_key: str,
    message: str,
    user_id: str = "",
    root_path: Path | None = None,
    config_path: Path | None = None,
    step_info: Dict[str, dict],
    total_steps: int,
) -> None:
    """Invoke an agent via iobot with demo-friendly progress output.

    Intercepts iobot's streaming output and transforms raw tool-call lines
    into clean progress display.  Two mechanisms work together:

    **Main thread** - processes Alex's (project_lead) stdout line by line:
    - Detects ``step-complete`` for inline steps -> shows ``â-¶`` banner + ``âœ" done``
    - Suppresses noise (``next-step``, ``run-step``, ``write_file STATUS:``)
    - Passes through Alex's narration and iobot header/footer

    **Tailer thread** - reads the progress file side channel:
    - Detects ``IOF_STEP_START``/``IOF_STEP_END`` markers written by ``run-step``
    - Shows ``â-¶`` banner and ``âœ" done [Xs]`` for delegated steps
    - Shows sub-agent thinking as dim indented lines

    This avoids depending on iobot's tool-call output format for step detection.
    """
    import re
    import tempfile
    import threading

    from ioagentfarm.engine.workspaces import iobot_agent_workspace

    workspace = iobot_agent_workspace(role)

    env = os.environ.copy()
    env["IOBOT_WORKSPACE"] = str(workspace)
    if root_path:
        env["IOF_ROOT"] = str(root_path)
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env["PYTHONUNBUFFERED"] = "1"

    # Prepend venv bin dir to PATH so iobot's exec tool finds the correct
    # ioagentfarm (venv-local) instead of a stale system-level installation.
    venv_bin = str(Path(sys.executable).parent)
    env["PATH"] = venv_bin + os.pathsep + env.get("PATH", "")

    # Native token capture for the orchestrator's OWN driving calls. Unlike
    # delegated run-step subprocesses (which get a sitecustomize inject that
    # imports ioagentfarm), the orchestrator (project_lead / Alex) runs as a bare
    # `iobot agent` subprocess — nothing imports ioagentfarm to register the
    # usage AgentHook. Give it a minimal sitecustomize (`import ioagentfarm` ->
    # apply_all -> apply_usage_capture + dedup) on a dedicated inject dir, and
    # point IOF_USAGE_FILE at the SAME run-scoped usage file the delegated steps
    # append to (each line is tagged with its session, so `forensics tokens`
    # still splits orchestrator vs per-step). The hook fires for streaming AND
    # non-streaming; we DROP IOF_DISABLE_STREAMING here so the orchestrator keeps
    # its current streaming behavior (only the delegated steps run non-streaming).
    try:
        _parts = session_key.split(":")
        _rid = _parts[1] if len(_parts) > 1 else None
        if root_path is not None and _rid:
            _run_dir = root_path / "instances" / _rid
            _oinj = _run_dir / "forensics" / "_iof_orchestrate_inject"
            _oinj.mkdir(parents=True, exist_ok=True)
            _osc = _oinj / "sitecustomize.py"
            if not _osc.exists():
                _osc.write_text(
                    "import ioagentfarm  # noqa: F401 — registers the usage AgentHook\n",
                    encoding="utf-8",
                )
            env["PYTHONPATH"] = str(_oinj) + os.pathsep + env.get("PYTHONPATH", "")
            env["IOF_USAGE_FILE"] = str(_run_dir / "usage.jsonl")
            env.pop("IOF_DISABLE_STREAMING", None)  # keep orchestrator streaming
    except Exception:
        logger.debug("Failed to set up orchestrator usage capture", exc_info=True)

    # Create progress file for sub-agent streaming side channel
    progress_fd, progress_path = tempfile.mkstemp(prefix="iof_progress_", suffix=".log")
    os.close(progress_fd)
    env["IOF_PROGRESS_FILE"] = progress_path

    if user_id:
        session_key = f"{session_key}:u:{user_id}"

    cmd = [
        _iobot_bin(), "agent",
        "--message", message,
        "--session", session_key,
        "--workspace", str(workspace),
    ]
    if config_path:
        cmd.extend(["--config", str(config_path)])

    # Thread-safe console output
    print_lock = threading.Lock()

    # State tracking for the main thread (inline steps only)
    suppressing = False            # suppress continuation lines of multi-line tool calls
    shown_steps: set[str] = set()  # dedup — only show â–¶ banner once per step

    # Start tailer thread — handles delegated step banners + sub-agent thinking
    tailer_stop, tailer_thread = _start_tailer(
        progress_path, console, print_lock, step_info, total_steps,
    )

    try:
        proc = subprocess.Popen(
            cmd, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", bufsize=1,
        )

        for line in proc.stdout:  # type: ignore[union-attr]
            stripped = line.rstrip("\n\r")

            # --- Multi-line suppression state machine ---
            # The runtime marks new output entries with the \u21b3 marker or its banner.
            # Continuation lines (no marker) after a suppressed tool call
            # are also suppressed until the next new entry.
            is_new_entry = "\u21b3" in stripped or "(io) iobot" in stripped
            if is_new_entry:
                suppressing = False
            elif suppressing:
                continue  # skip continuation of suppressed tool call

            # --- Suppress run-step lines (banners handled by tailer) ---
            if 'ioagentfarm run-step' in stripped:
                suppressing = True
                continue

            # --- Detect step-complete (inline step done) ---
            m = re.search(r'ioagentfarm step-complete --step-key ([\w:]+)', stripped)
            if m:
                step_key = _match_step_key(m.group(1), step_info)
                info = step_info.get(step_key, {})
                r = info.get("role", "unknown")
                seq = info.get("seq", "?")
                name = _AGENT_NAMES().get(r, r)
                # Show â–¶ banner for inline steps that haven't been shown yet
                if step_key not in shown_steps:
                    shown_steps.add(step_key)
                    with print_lock:
                        console.print(
                            f"\n  [cyan]> Step {seq}/{total_steps}:[/cyan] "
                            f"[bold]{step_key}[/bold] [dim]({r})[/dim] - {name} is working..."
                        )
                with print_lock:
                    console.print(f"  [green]+[/green] {step_key} [dim]({r})[/dim] done")
                suppressing = True  # suppress the exec result lines
                continue

            # --- Suppress next-step noise ---
            if 'ioagentfarm next-step' in stripped:
                suppressing = True
                continue

            # --- Suppress write_file for protocol output ---
            if 'write_file' in stripped and 'STATUS:' in stripped:
                suppressing = True
                continue

            # --- Suppress Alex's tool calls (not narration) ---
            # Tool calls: â†³ tool_name("arg...") — identifier + opening paren
            # Narration:  â†³ I'll drive this workflow... — prose text
            if re.match(r'\s*\u21b3\s+\w+\(', stripped):
                suppressing = True
                continue

            # --- Pass through everything else (Alex's narration, the runtime's
            # header/footer) ---
            #
            # Rebranded here for the same reason `_invoke_agent` does it, and
            # this reader once did not: a log record stamped with the engine's
            # own import package (`ioagentfarm...`) is rewritten to the product
            # name at DISPLAY time. Step agents went through the other reader
            # and the orchestrator came through here, in the very first line
            # of every `ioagentfarm run`.
            line = _rebrand(line)
            line = _redact_log_line(line)
            with print_lock:
                try:
                    sys.stdout.write(line)
                except UnicodeEncodeError:
                    sys.stdout.write(line.encode("ascii", errors="replace").decode("ascii"))
                sys.stdout.flush()

        rc = proc.wait()
        if rc != 0:
            with print_lock:
                console.print(
                    f"\n[red bold]Agent process exited with code {rc}.[/red bold] "
                    f"[dim]Possible cause: maxToolIterations or exec timeout reached.[/dim]"
                )

    except KeyboardInterrupt:
        proc.terminate()  # type: ignore[possibly-undefined]
        console.print("\n[yellow]Interrupted.[/yellow]")
    finally:
        # Give tailer a moment to flush final lines, then stop it
        import time
        time.sleep(0.5)
        tailer_stop.set()
        tailer_thread.join(timeout=2.0)
        # Clean up temp file
        try:
            os.unlink(progress_path)
        except OSError:
            pass


# THE THREE RESOLVERS BELOW ARE WHERE ENVIRONMENT BECOMES A DATABASE, and
# each one adopts local mode before it reads a thing.
#
# It used to be adopted EAGERLY, by whichever command remembered to call
# `local_mode()`. Five did; fifty opened a store. `aicore local on` was
# therefore honoured by `run` and REPORTED by `current`, while `status`,
# `next-step`, `step-complete`, `resume`, `agent-chat` and the forensics
# commands read the shared database the workspace's own .env named — so an
# operator in local mode was shown another deployment's runs and could not
# see their own. See `workspace_env.adopt_if_declared` for the measurement.
#
# Doing it here instead of in `_workspace_code` is deliberate: a command
# cannot open a store without passing through these, so there is no ordering
# to get right and nothing for the fifty-first command to remember. Pinned by
# tests/test_local_mode_is_not_optional.py, which fails if a fourth resolver
# appears without it.

def _root() -> Path:
    _ws_env.adopt_if_declared()
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve()

def _current_workspace_code_quietly() -> Optional[str]:
    """The selected workspace, or None if one cannot be resolved.

    Used to SCOPE reads. Quiet because a read that cannot name its tenant
    must not fail - it must simply not pretend the rows it found are the
    caller's. Returning None keeps the old unscoped behaviour for the paths
    that legitimately have no selection.
    """
    try:
        from ioagentfarm.engine.workspaces import resolved_workspace_code
        return resolved_workspace_code()
    except Exception:  # noqa: BLE001
        return None


def _store(root_path: Path) -> Store:
    _ws_env.adopt_if_declared()
    # EVERY command that opens a database says which one. See
    # `announce_target_once` - this is the seam, so there is nothing for a new
    # command to remember.
    announce_target_once()
    root_path.mkdir(parents=True, exist_ok=True)
    db_url = os.getenv("IOF_DATABASE_URL", "")
    if not db_url:
        db_url = f"sqlite:///{root_path / 'state.db'}"
    adapter = make_adapter(db_url)
    store = Store(adapter)
    store.init()
    return store


def _learning_lifecycle(root_path: Path) -> "LearningLifecycle":
    """Create a LearningLifecycle sharing the same database as the main Store."""
    from ioagentfarm.engine.learning import LearningLifecycle
    _ws_env.adopt_if_declared()
    db_url = os.getenv("IOF_DATABASE_URL", "")
    if not db_url:
        db_url = f"sqlite:///{root_path / 'state.db'}"
    ll = LearningLifecycle(make_adapter(db_url))
    ll.init()
    return ll

def _installed_workflows_dir(root_path: Path) -> Path:
    d = root_path / "workflows"
    d.mkdir(parents=True, exist_ok=True)
    return d

def _step_stale_seconds() -> float:
    """The supervisor's own staleness threshold - never a second opinion."""
    from ioagentfarm.engine.supervisor import _step_stale_s
    return _step_stale_s()


def _step_heartbeat_is_stale(step: dict) -> bool:
    """Has this running step actually gone quiet?

    Mirrors the supervisor's rule exactly, including the longer grace for rows
    with NO heartbeat (legacy rows and code paths that never write one -
    judging those on the short threshold would call healthy long exec steps
    stalled). Used by `aicore status` so the field an operator reads first
    agrees with the machinery that acts on it, instead of flagging every
    running step and meaning nothing.
    """
    from datetime import datetime, timezone

    from ioagentfarm.engine.supervisor import _no_heartbeat_grace_s, _step_stale_s

    stamp = step.get("heartbeat_at") or step.get("updated_at")
    if not stamp:
        return False                      # nothing to judge on - say nothing
    limit = _step_stale_s() if step.get("heartbeat_at") else _no_heartbeat_grace_s()
    try:
        t = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        if t.tzinfo is None:
            t = t.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - t).total_seconds() > limit
    except (TypeError, ValueError):
        return False                      # unparseable: not evidence of a stall


def _get_run_or_exit(store: Store, run_id: str, *, json_mode: bool = False) -> dict:
    """Get a run by ID or exit 3 - NOT 1. A script polling `status`/`watch`
    could not tell a mistyped id from a failed pipeline (novice, round 6).
    Under --json the answer is JSON, like every other error on that path."""
    try:
        return store.get_run(run_id)
    except KeyError:
        if json_mode:
            print(json.dumps({"error": "run not found", "run_id": run_id,
                              "hint": "aicore status lists recent runs"}))
        else:
            console.print(f"No run '{run_id}' in this database. `aicore status` lists recent runs.",
                          markup=False)
        raise typer.Exit(code=3)


def _resolve_run_id(store: Store, root_path: Path, explicit_run_id: str | None, user_id: str = "") -> str | None:
    """Resolve run ID from: explicit param > user_context DB > .iof/active_run > latest active run."""
    if explicit_run_id:
        return explicit_run_id
    # Per-user active run from DB
    if user_id:
        saved = store.get_user_active_run(user_id)
        if saved:
            return saved
    # Fallback: global file (backward compat)
    active_file = root_path / "active_run"
    if active_file.exists():
        saved = active_file.read_text(encoding="utf-8").strip()
        if saved:
            return saved
    run = store.get_latest_active_run(user_id=user_id)
    return run["id"] if run else None


def _resolve_own_run_id(store: Store, explicit_run_id: str | None, user_id: str) -> tuple[str | None, str | None]:
    """Resolve a run to MUTATE (step-retry / step-skip), scoped to the caller.

    Returns ``(run_id, None)`` or ``(None, reason)``. Explicit wins. Otherwise
    ONLY the caller's own active run - their per-user pointer (if still
    running) or their user-scoped latest. It never reads the global
    ``active_run`` file and never falls back to the global latest, because a
    step-retry/step-skip with ``--run-id`` omitted then reached whatever run
    last wrote that file - on a shared database, another user's live run
    (novice finding, round 8: the one tired omission that crosses a user
    boundary). A resolved run whose ``user_id`` is not the caller's is
    refused as a final guard.
    """
    if explicit_run_id:
        return explicit_run_id, None
    if user_id:
        saved = store.get_user_active_run(user_id)
        if saved:
            try:
                if (store.get_run(saved) or {}).get("status") == "running":
                    return saved, None
            except Exception:  # noqa: BLE001
                pass
        run = store.get_latest_active_run(user_id=user_id)
        if run and run.get("user_id") in (None, "", user_id):
            return run["id"], None
    return None, (f"no active run of your own to act on (user {user_id or '?'}); "
                  "pass --run-id explicitly. An omitted --run-id must never reach "
                  "another user's run.")


def _set_active_run(root_path: Path, run_id: str, *, store: Store | None = None, user_id: str = "") -> None:
    """Persist active run context. Uses per-user DB when user_id is provided,
    plus the global file for backward compatibility."""
    if user_id and store:
        store.set_user_active_run(user_id, run_id)
    (root_path / "active_run").write_text(run_id, encoding="utf-8")

def _build_prior_run_summary(store: Store, run_id: str) -> str:
    """Build a concise summary of a prior run's outputs for follow-up context."""
    steps = store.list_steps(run_id)
    lines = ["### Prior run step outputs"]
    for s in steps:
        if s["status"] == "done" and s.get("output_text"):
            output_preview = s["output_text"][:500]
            lines.append(f"\n**{s['step_key']}** ({s['role']}):")
            lines.append(output_preview)
            if len(s["output_text"]) > 500:
                lines.append("... (truncated)")
    return "\n".join(lines)

@app.command("init-home")
def init_home():
    """Create `~/.iobot/` with a config.json and .env to fill in.

    THE FIRST COMMAND, before `init`. The runtime reads its model provider from
    `~/.iobot/config.json` at a fixed path, and nothing created it - the guide
    answered that with a JSON blob to copy out of the docs by hand, which is
    how a reader ends up with a config wrong in the one field that matters.

    Templates, not prompts: you open the files and fill in your key and URL. A
    wizard would need to know every provider's shape, and a `--api-key` flag
    puts a credential in shell history.

    `.env` is where this machine's settings live - `IOF_ROOT`,
    `IOF_DATABASE_URL`, the rest. Every command reads it, so there is nothing
    to `source` and nothing to re-export in a new terminal.
    """
    from ioagentfarm.engine import home_bootstrap

    results = home_bootstrap.bootstrap_home()
    for r in results:
        if r["action"] == home_bootstrap.FAILED:
            console.print(f"  [red]{r['path']}[/red] - {r['error']}")
        elif r["action"] == home_bootstrap.KEPT:
            # Never overwritten, and there is no flag that would. The file may
            # hold a live API key or this machine's database; say plainly that
            # it was left alone, so nobody assumes the template landed.
            console.print(f"  [yellow]{r['path']}[/yellow] - ALREADY EXISTS, "
                          "left untouched")
        else:
            console.print(f"  [green]{r['path']}[/green] - written")
    if any(r["action"] == home_bootstrap.KEPT for r in results):
        console.print("[dim]  nothing was overwritten. To start from the "
                      "template again, delete the file first.[/dim]")

    cfg = home_bootstrap.describe_config()
    if cfg.get("configured"):
        console.print(f"\n[green]provider configured[/green] - model "
                      f"{cfg['model']}, maxTokens {cfg['max_tokens']}")
    else:
        # DO NOT SEND THEM TO `~/.iobot/.env` FOR CLI SETTINGS. That file is
        # written here for the tools an agent runs -- the runtime strips a tool
        # subprocess to {HOME, LANG, TERM} and they read it back themselves --
        # and the CLI stopped reading it when settings became workspace-scoped.
        # This message told a reader to put IOF_ROOT and IOF_DATABASE_URL in a
        # file `aicore current` reports as IGNORED, which is how a walkthrough
        # ends up with one database per directory and a workspace that seems to
        # vanish between steps.
        console.print(f"\n[yellow]Next:[/yellow] edit "
                      f"{home_bootstrap.iobot_home() / 'config.json'} - set "
                      "your model and API key.\n      Check it with "
                      f"[bold]{prog()} config-check[/bold].")
        console.print(f"[dim]      State and database need no setup for a "
                      f"first run: `{prog()} local on` keeps both in the "
                      "directory you work in.[/dim]")


@app.command("config-check")
def config_check():
    """Report this machine's setup, without printing any key.

    Replaces the Python heredoc the guide asked readers to paste. The state
    that matters is "placeholders still in place" - a config that exists and
    looks fine and fails at the first generation call.

    It reports the SETTINGS as well as the provider, because once those moved
    out of the shell and into `~/.iobot/.env` there was nothing that answered
    "did my edits take, and where is this machine actually writing?" without
    writing something. `init` names the state directory and the database, but
    it creates them; nothing at all named the agent home. A plain
    `python -c "... agent_home_root()"` cannot answer it either - that file is
    read by the CLI, so an interpreter reports the machine-global default and
    is believed.
    """
    from ioagentfarm.engine import home_bootstrap
    from ioagentfarm.engine.db import describe_db_target
    from ioagentfarm.engine.workspaces import (WorkspaceNotSelected,
                                               WorkspaceRetired,
                                               agent_home_root)

    # NAME THE FILE THAT IS READ, and call the other one what it is. This
    # printed `settings: ~/.iobot/.env` -- a file this CLI stopped reading when
    # settings became workspace-scoped. The two commands the guide tells you to
    # run back to back then labelled one file oppositely: `config-check` called
    # it the settings, `current` called it ignored. Same wording as `current`
    # now, and the workspace's own file is the one reported as settings.
    # DO NOT NAME `default` WHEN NOTHING IS SELECTED. Printing it, and the
    # path to a settings file it does not have, describes a workspace the
    # reader did not choose and that every tenant command now refuses to act
    # on -- so it reads as "you are in `default`" when the truth is "you are
    # nowhere yet". Say that, and say how to fix it.
    if _workspace_is_selected():
        ws = _workspace_code(None, required=False)
        ws_env = _ws_env.workspace_env_path(ws)
        console.print(f"[dim]settings:[/dim] {ws_env}"
                      + ("" if ws_env.is_file() else
                         "  [yellow](not found)[/yellow]"), soft_wrap=True)
        console.print(f"  workspace  {ws}", soft_wrap=True)
    else:
        ws = _workspace_code(None, required=False)
        console.print("[yellow]settings:[/yellow] no workspace selected",
                      soft_wrap=True)
        console.print(f"  [dim]select one:[/dim]  {prog()} workspace create "
                      "<code>   [dim]# creates it and selects it[/dim]",
                      soft_wrap=True)
        console.print(f"               {prog()} workspace use <code>      "
                      "[dim]# selects an existing one[/dim]", soft_wrap=True)
    home_env = home_bootstrap.iobot_home() / ".env"
    if home_env.is_file():
        console.print(f"[dim] ignored :[/dim] {home_env}  [dim](credentials "
                      "for agent tool subprocesses (legacy home bootstrap); "
                      "this CLI does not read it)[/dim]", soft_wrap=True)
    console.print(f"  state dir  {_root()}", soft_wrap=True)
    # A DIAGNOSTIC MUST NOT CRASH. `agent_home_root()` resolves a workspace and
    # RAISES when none is selected, so this line turned the whole command into
    # a traceback in exactly the state it exists to describe -- and the block
    # above had already reported that state calmly, two lines earlier. It is
    # the first verification step the getting-started guides tell a reader to
    # run, so it landed as a crash at the moment they can least tell "the guide
    # is wrong" from "my install is broken".
    try:
        _agent_home = str(agent_home_root())
    except (WorkspaceNotSelected, WorkspaceRetired):
        _agent_home = "[dim](none - depends on the workspace you select)[/dim]"
    console.print(f"  agent home {_agent_home}", soft_wrap=True)
    # describe_db_target redacts the password; the host and database name are
    # the whole point of printing it — "which database am I about to write to"
    # is the question every wrong-environment incident starts with.
    console.print(f"  database   {describe_db_target(_root())}", soft_wrap=True)

    cfg = home_bootstrap.describe_config()
    console.print(f"\n[dim]config:[/dim] {cfg['path']}", soft_wrap=True)
    if not cfg["exists"]:
        console.print("[yellow]not found[/yellow] - run "
                      f"[bold]{prog()} init-home[/bold]")
        raise typer.Exit(code=1)
    if cfg.get("error"):
        console.print(f"[red]unreadable[/red] - {cfg['error']}")
        raise typer.Exit(code=1)
    console.print(f"  model     {cfg['model']}")
    console.print(f"  maxTokens {cfg['max_tokens']}")
    for p in cfg["providers"]:
        mark = "[green]key set[/green]" if p["has_key"] else "[yellow]no key[/yellow]"
        console.print(f"  provider  {p['name']:<14} {mark}  {p['api_base'] or ''}")
    # NOT A HARD BOUND, and not applied to every provider. The ceiling is the
    # ANTHROPIC SDK's arithmetic (3600 * max_tokens / 128000 > 600 seconds ->
    # it raises "Streaming is required"), so it constrains `anthropic` and the
    # Bedrock wrapper that subclasses it, and means nothing to an Azure or
    # OpenAI endpoint. This refused a working Azure config outright -- 125000
    # tokens against a /chat/completions route, which has no such rule -- and
    # a check that fails a correct setup is worse than no check, because the
    # next real finding gets ignored too. Advisory, and only where it applies.
    if isinstance(cfg["max_tokens"], int) \
            and cfg["max_tokens"] > home_bootstrap.MAX_TOKENS_NON_STREAMING \
            and home_bootstrap.uses_anthropic_sdk(cfg.get("provider")):
        console.print(f"\n[yellow]maxTokens is above "
                      f"{home_bootstrap.MAX_TOKENS_NON_STREAMING}[/yellow] on "
                      f"provider `{cfg.get('provider')}`, which routes through "
                      "the Anthropic SDK.\n      That SDK refuses a "
                      "non-streaming request above it and the engine runs "
                      "non-streaming, so\n      generations fail while cheap "
                      "reads succeed - it presents as a flaky model rather "
                      "than a setting.")
    # A key the runtime does not define is FATAL to every agent call, and the
    # rejection surfaces nowhere near here: it arrives at the first call as a
    # validation dump followed by a message about tool iterations, which is not
    # the cause. This command is the one the guides say to trust, so it has to
    # be the one that catches it. Notes belong in `config.README.md`, written
    # beside the file for exactly this reason.
    if cfg.get("unknown_keys"):
        names = ", ".join(f"`{k}`" for k in cfg["unknown_keys"])
        console.print(f"\n[red]unknown top-level key(s)[/red]: {names}\n"
                      "      The agent runtime refuses a key it does not "
                      "define, so every agent call fails while this command\n"
                      "      and the file itself look correct. Remove them "
                      f"from {cfg['path']}.\n"
                      "      Notes go in config.README.md beside it; JSON "
                      "carries no comments, which is how these arrive.")
        raise typer.Exit(code=1)
    if not cfg["configured"]:
        console.print("\n[yellow]placeholders still in place[/yellow] - edit "
                      f"{cfg['path']} before running a workflow")
        raise typer.Exit(code=1)
    console.print("\n[green]ready[/green]")


@app.command()
def init(root: str = typer.Option(None, help="Root directory for state; default .iof")):
    """Create the state directory and its database. Idempotent.

    The only command in the list with no help text of its own, which read as a
    placeholder rather than as the first command a new machine runs.
    """
    # Resolve the workspace FIRST: `_workspace_code` is what loads the
    # workspace .env, and without it this command ensured tables in a
    # default SQLite under the cwd while the selected workspace's Postgres
    # - the database every other command was using - stayed unprovisioned.
    _workspace_code(required=False)
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    _installed_workflows_dir(root_path)
    platform = _ensure_platform_tables(store)
    console.print(f"[green]Initialized[/green] {root_path}", soft_wrap=True)
    # The state directory and the database can be two different places without
    # a word of warning — see engine.db.describe_db_target for the case that
    # found this. Name the target in the first command anybody runs.
    from ioagentfarm.engine.db import describe_db_target
    # soft_wrap: rich hard-wraps at the console width, and the guide asks the
    # reader to compare this path against the line above it. Two paths broken
    # across six fragments are materially harder to compare by eye.
    console.print(f"[dim]database:[/dim] {describe_db_target(root_path)}",
                  soft_wrap=True)
    count, failed = platform
    if count is not None:
        console.print(f"[dim]tables:[/dim] {count} platform table(s) present",
                      soft_wrap=True)
    # NAMED, not counted. "The platform tables could not be created" sends an
    # operator looking at all of them; a deployment where the app user has
    # rights to some schemas and not others is real, and eleven tiers of
    # twelve is strictly better than none - but only if it says which one is
    # missing.
    if failed:
        console.print(
            f"[yellow]warning[/yellow] {len(failed)} tier(s) could not be "
            f"created: {', '.join(failed)}. What they carry will be missing "
            f"at runtime, not at startup. Run "
            f"`python scripts/schema_doctor.py` for the reason, or hand "
            f"`scripts/setup_schema.sql` to a DBA where the app user has no "
            f"CREATE.", soft_wrap=True)


def _ensure_platform_tables(store) -> "tuple[int | None, list[str]]":
    """Create every platform tier on the store's own connection.

    ON THE STORE'S CONNECTION, deliberately. Several provisioners can resolve
    a database of their own - `workspace_sync.connect()` reads `IOF_ROOT`,
    the case and play tiers infer a root from hints - so handing them the
    adapter this command already resolved is what stops `init --root X` from
    provisioning a DIFFERENT database than the one it reports. Two databases
    and no warning is the failure `describe_db_target` exists for.

    Returns ``(tables_present, failed_tier_labels)``; ``(None, [...])`` when
    the connection itself could not be opened. Never raises: `init` must
    still create the state directory on a database it cannot alter.
    """
    from ioagentfarm.engine import platform_schema

    try:
        with store._tx_pair() as (con, cur):
            is_pg = store._db.placeholder() == "%s"
            _ok, failed = platform_schema.ensure_all(store._db, con)
            try:
                con.commit()
            except Exception:  # noqa: BLE001 - autocommit connections
                pass
            # TABLES ARE HALF THE JOB. `CREATE TABLE IF NOT EXISTS` does
            # nothing to a table that already exists, so a column added in a
            # later release never arrives - which is what makes `init` an
            # install command rather than an upgrade one. Measured: nine
            # columns dropped across nine tiers, a second `init`, four back.
            added, refused = platform_schema.reconcile_columns(store._db, con)
            if added:
                console.print(
                    f"[dim]columns:[/dim] added {len(added)} missing "
                    f"column(s): {', '.join(added[:6])}"
                    + (" ..." if len(added) > 6 else ""), soft_wrap=True)
            if refused:
                # NAMED. A column that cannot be added is one an INSERT will
                # fail on, and saying so here is cheaper than finding out
                # from a stack trace in a pod.
                console.print(
                    f"[yellow]warning[/yellow] {len(refused)} column(s) could "
                    f"not be added: {', '.join(refused[:4])}"
                    + (" ..." if len(refused) > 4 else "")
                    + ". A NOT NULL column with no DEFAULT cannot be added to "
                      "a table that has rows - that is a migration, and a "
                      "decision.", soft_wrap=True)
            return platform_schema.present(cur, is_pg), failed
    except Exception:  # noqa: BLE001 - reported by the caller, never fatal
        logger.debug("init: platform schema provisioning failed", exc_info=True)
        return None, ["(could not open the database)"]


@app.command("list-agents")
def list_agents(
    workspace: str = typer.Option(None, "--workspace", help="Workspace code (default: the active one)"),
    as_json: bool = typer.Option(False, "--json", help="Machine-readable"),
    scope: bool = typer.Option(False, "--scope", help="Also show the DECLARED scope a router matches on - the A2A card's description, skill ids and tags, and whether the role is exposed (card `expose: true` or IOF_ALWAYS_ON_AGENTS)"),
):
    """List the agents a workflow in this workspace may name as a `role`.

    The roles resolve from the installed packs of the workspace's family
    plus the platform's shared roles - the same lookup a run performs. A
    novice engineer had no way to answer "which agents exist here?" short
    of a failed run: the client doc named agents this deployment does not
    ship, and `workspace show` counted zero.
    """
    import json as _json
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace
    from ioagentfarm.engine.workspaces import (
        PLATFORM_SHARED_ROLES, get_agent_name, list_bundled_agents)
    rows = []
    for role in sorted(set(list_bundled_agents())):
        try:
            name = get_agent_name(role)
        except Exception:  # noqa: BLE001 - a name is a courtesy
            name = ""
        rows.append({"role": role, "name": name,
                     "tier": "platform" if role in PLATFORM_SHARED_ROLES else "pack"})
    # A direct Python call (the test suite does this) passes no `scope`, and
    # typer's OptionInfo default is truthy - only a real True opts in.
    scope = scope is True
    if scope:
        # THE SAME LOADER THE SERVED CARD USES (`web.a2a.build_agent_card`),
        # so this listing cannot disagree with what
        # GET /a2a/<role>/.well-known/agent-card.json answers.
        from ioagentfarm.engine.discovery import agent_scope
        ws_code = _workspace_code(workspace, required=False)
        if not ws_code and not os.environ.get("IOF_AGENT_HOME", "").strip():
            # The card loader reads the agent's HOME first, and a home lives
            # inside a workspace - the same refusal every other home-reading
            # command makes, said here instead of as a per-row error.
            console.print("[red]--scope reads each agent's card from its home "
                          "inside a workspace, and none is selected[/red]",
                          soft_wrap=True)
            console.print(f"  [dim]select one:[/dim]  {prog()} workspace use "
                          "<code>   (or pass --workspace)", soft_wrap=True)
            raise typer.Exit(code=1)
        for r in rows:
            r.update(agent_scope(r["role"], ws_code))
    if as_json:
        print(_json.dumps({"agents": rows}, indent=2))
        return
    if not rows:
        console.print("[yellow]No agents resolve here - is the solution installed in "
                      "this environment (`pip install -e .`)?[/yellow]")
        return
    table = Table(title="Agents in scope")
    table.add_column("role", style="cyan")
    table.add_column("name")
    table.add_column("tier", style="dim")
    if scope:
        table.add_column("exposed", no_wrap=True)
        table.add_column("card skills")
        table.add_column("tags")
        table.add_column("description")
    for r in rows:
        cells = [r["role"], r["name"], r["tier"]]
        if scope:
            from rich.markup import escape as _esc
            from ioagentfarm.engine.discovery import ascii_only
            exposed = "[green]yes[/green]" if r.get("exposed") else "no"
            if r.get("exposure"):
                exposed += f" [dim]({r['exposure']})[/dim]"
            cells += [exposed,
                      _esc(", ".join(r.get("skills") or [])),
                      _esc(", ".join(r.get("tags") or [])),
                      _esc(ascii_only(r.get("error") or r.get("description"))[:80])]
        table.add_row(*cells)
    console.print(table)


@app.command("list-skills")
def list_skills(
    role: str = typer.Option(None, "--role", help="Narrow to what this agent's workspace actually LOADS - the runtime loader's verdict per skill (injected / listed / dropped, with the reason)"),
    workspace: str = typer.Option(None, "--workspace", help="Workspace code (default: the active one)"),
    as_json: bool = typer.Option(False, "--json", help="Machine-readable"),
):
    """The skills the installed packs ship - the catalog a step's `skills:` resolves from.

    "Which skills exist here?" had two answers, both indirect: `GET
    /api/catalog/skills` (needs a running engine) and `context-report
    <role>` (one agent at a time). This reads the source the `pack_skills`
    mirror is built from. `carrier` says WHERE a skill ships - `shared` (a
    pack's skills root), `agent:<role>` (one agent's workspace) or
    `inject:<x>` - and `always` is what the FILE declares, not what any
    agent does with it.

    `--role` asks the runtime's own loader through the same code as
    `context-report`: a pack skill the agent does not carry reads `dropped
    / not-carried`, and an always-on skill whose binary is missing reads
    `listed` with the loader's reason rather than `injected`.
    """
    import json as _json
    # Direct Python calls pass no value and typer's OptionInfo default is
    # truthy - a string is a role, anything else is "not given".
    role = role if isinstance(role, str) and role.strip() else None
    workspace = workspace if isinstance(workspace, str) else None
    as_json = as_json is True
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace
    from ioagentfarm.engine import discovery
    from ioagentfarm.engine.workspaces import (WorkspaceNotSelected,
                                               WorkspaceRetired)
    view = None
    if role:
        try:
            view = discovery.skill_rows_for_role(role)
        except (WorkspaceNotSelected, WorkspaceRetired) as exc:
            console.print("[red]--role resolves the agent's home inside a "
                          f"workspace, and none is selected[/red] ({exc})",
                          soft_wrap=True)
            console.print(f"  [dim]select one:[/dim]  {prog()} workspace use "
                          "<code>   (or pass --workspace)", soft_wrap=True)
            raise typer.Exit(code=1)
        rows = view["skills"]
    else:
        rows = discovery.skill_rows()

    if as_json:
        payload: dict = {"skills": rows}
        if view is not None:
            payload.update(role=view["role"], workspace=view["workspace"],
                           materialized=view["materialized"])
        print(_json.dumps(payload, indent=2))
        return
    if view is not None and not view["materialized"]:
        # Every row would read `dropped / not-carried` about an agent that
        # has simply never been seeded - a narrowing that widens into a
        # false answer. Say what is true and stop.
        console.print(f"[yellow]no agent home for '{role}'[/yellow] at "
                      f"{view['workspace']} - it is materialized on the "
                      "first run or chat, so nothing has loaded yet. Without "
                      "--role this command lists what the packs ship.",
                      soft_wrap=True)
        raise typer.Exit(code=1)
    if not rows:
        console.print("[yellow]No skills resolve here - is the solution installed "
                      "in this environment (`pip install -e .`)?[/yellow]")
        _warn_uninstalled_local_pack()
        return

    from rich.markup import escape as _esc
    table = Table(title="Skills in scope"
                  + (f" - as loaded by '{role}'" if view else ""))
    table.add_column("name", style="cyan")
    table.add_column("pack", style="dim")
    table.add_column("carrier")
    table.add_column("always", no_wrap=True)
    if view:
        table.add_column("loaded", no_wrap=True)
        table.add_column("why")
    table.add_column("description")
    modes = {"injected": "[green]injected[/green]", "listed": "[cyan]listed[/cyan]",
             "dropped": "[yellow]dropped[/yellow]"}
    for r in rows:
        cells = [_esc(r["name"]), _esc(r["pack"]), _esc(r["carrier"]),
                 {True: "yes", False: "no"}.get(r["always"], "-")]
        if view:
            cells += [modes.get(r["loaded"], r["loaded"]),
                      _esc(discovery.ascii_only(r.get("detail") or r.get("reason"))[:60])]
        cells.append(_esc(discovery.ascii_only(r["description"])[:60]))
        table.add_row(*cells)
    console.print(table)
    if view:
        counts = {m: sum(1 for r in rows if r["loaded"] == m) for m in modes}
        console.print(f"[dim]{counts['injected']} injected, {counts['listed']} "
                      f"listed (on demand), {counts['dropped']} dropped - "
                      f"workspace: {view['workspace']}[/dim]", soft_wrap=True)
    _warn_uninstalled_local_pack()


def _warn_uninstalled_local_pack() -> None:
    """Say when the listing you just printed cannot include this repo's pack.

    `new-agent` shouts REINSTALL REQUIRED; the LISTINGS said nothing and
    printed other packs' content instead, so a confused first-timer read a
    confident table as complete and concluded their own workflow was in it
    (confused-novice round, finding 2). Whatever knows how to diagnose this
    should say it wherever the absence shows.
    """
    try:
        from ioagentfarm.cli_scaffold import invocation, uninstalled_local_packs
        missing = uninstalled_local_packs()
        if not missing:
            return
        console.print("")
        console.print(
            f"[yellow]NOT LISTED:[/] this directory declares "
            f"{', '.join(missing)}, which is not installed in this "
            "environment - its agents, skills and workflows CANNOT appear "
            "above, and nothing else here will say so.")
        # markup=False on BOTH lines: a Windows path is full of backslashes
        # and rich ate the executable, printing `fix:` with nothing after it -
        # a fix line missing its command is worse than no fix line.
        console.print(f'  fix: "{sys.executable}" -m pip install -e .'
                      '    # then re-run this command', markup=False)
        console.print(f"  check: {invocation()} list-workflows", markup=False)
    except Exception:                   # noqa: BLE001 - a hint, never a failure
        pass


@app.command("list-workflows")
def list_workflows(
    workspace: str = typer.Option(
        None, "--workspace",
        help="Tenant workspace code (default: the selected workspace; refused when none is selected)"),
):
    """Workflows this environment can resolve, for one workspace.

    THE FLAG IS NOT COSMETIC. A tenant's workflows live in its own
    ``studio_workflow_defs`` rows and materialise into a per-workspace
    override tree, so without a code this listed the DEFAULT workspace and
    printed an empty table for anyone working in a tenant. That is the
    command the loader's own 'no workflow named X' error tells you to run -
    it has to be able to answer for the workspace you are actually in, or
    the trail goes cold exactly where a reader needs it most.
    """
    ws_code = _workspace_code(workspace, required=True)
    loader = WorkflowLoader()
    names = loader.list_workflows(workspace=ws_code)
    table = Table(title=f"Workflows (bundled + installed) - workspace: {ws_code}")
    table.add_column("name")
    table.add_column("description")
    for n in names:
        try:
            wf = loader.load(n, workspace=ws_code)
            table.add_row(n, wf.description or "")
        except Exception as exc:
            # A definition that will not load is still a workflow that
            # EXISTS; dropping it here would make the listing disagree with
            # the resolver that found it.
            table.add_row(n, f"[red](failed to load: {exc})[/red]")
    console.print(table)
    _warn_uninstalled_local_pack()
    if not names:
        console.print(
            f"[yellow]No workflows resolve for workspace '{ws_code}'.[/]")
        # REINSTALL FIRST, workspace second. Both produce an identical empty
        # listing, but only one of them is silent: a workflow just written
        # into a solution whose entry point pip has not registered is
        # invisible with no error anywhere. There is no database tier to
        # push into any more - a workflow comes from the installed pack, so
        # the second question is whether THIS venv resolves for the
        # workspace the caller meant (docs/one-truth-content-model.md 3.2).
        console.print(
            "[dim]Two causes, and this is the order to check them:[/]")
        console.print(
            "[dim]  1. a new solution or tool adds an entry point, and pip "
            "registers it only on install - from the repo:[/]")
        console.print('       pip install -e ".[dev]"', markup=False)
        console.print(
            "[dim]  2. workflows resolve from the installed pack, per "
            "workspace; check which pack this venv sees and which workspace "
            "is selected:[/]")
        console.print(f"       {prog()} current", markup=False)


def _print_lint_result(result, *, show_ok: bool = True) -> None:
    """Render one LintResult. Errors red, warnings yellow, fix indented.

    Every interpolated string is escaped: a finding's ``where`` is a path like
    ``steps[2].requires_artifact`` and rich reads ``[2]`` as a markup tag, so
    unescaped it prints as ``steps`` and the reader loses the location.
    """
    from rich.markup import escape
    from ioagentfarm.engine.workflow_lint import ERROR

    label = escape(result.name or result.path)
    path = escape(result.path)
    if not result.findings:
        if show_ok:
            console.print(f"[green]OK[/green]  {label}  [dim]{path}[/dim]")
        return
    console.print(f"\n[bold]{label}[/bold]  [dim]{path}[/dim]")
    for f in result.findings:
        colour = "red" if f.severity == ERROR else "yellow"
        loc = f"line {f.line}" if f.line is not None else "-"
        console.print(
            f"  [{colour}]{f.severity.upper():7}[/{colour}] [dim]{loc:>8}[/dim]  "
            f"[cyan]{escape(f.where)}[/cyan]", soft_wrap=True)
        console.print(f"           {escape(f.message)}", soft_wrap=True)
        if f.fix:
            console.print(f"           [green]fix:[/green] {escape(f.fix)}",
                          soft_wrap=True)


def _dry_run_lint(name: str, workspace: str | None) -> None:
    """Advisory lint appended to ``run --dry-run``. FAIL-OPEN by default.

    ``--dry-run`` is the studio's save gate (``studio._dry_run`` shells out to
    it and reads the exit code), so it is the cheapest place to put the linter
    in front of an author - the findings land in the ``dry_run`` text the
    studio already shows.

    It does NOT change the exit code. Every workflow that saves today would
    keep saving; a linter that starts REFUSING content people have already
    shipped is a worse bug than the one it was written to catch, and warnings
    are advisory by definition. Set ``IOF_LINT_STRICT=1`` to make lint errors
    (never warnings) fail the dry run - the opt-in for a team that wants the
    gate.
    """
    from ioagentfarm.engine.workflow_lint import (
        lint_workflow_dir, resolve_workflow_dir)

    try:
        base = resolve_workflow_dir(name, workspace)
        if base is None:
            # The loader found it (we are past load()) but the linter could
            # not reach a real directory. That is a linter limitation, not
            # something to report at the author.
            return
        result = lint_workflow_dir(base)
    except Exception:
        logger.debug("lint skipped for %r", name, exc_info=True)
        return
    if not result.findings:
        return

    console.print(f"\n[bold]Lint[/bold] [dim](advisory - see `{prog()} "
                  "lint-workflow` for detail)[/dim]")
    _print_lint_result(result, show_ok=False)

    strict = os.getenv("IOF_LINT_STRICT", "").lower() in ("1", "true", "yes")
    if strict and result.errors:
        console.print("[red]IOF_LINT_STRICT=1 and the workflow has lint "
                      "errors - failing the dry run.[/red]")
        raise typer.Exit(code=1)
    if result.errors:
        console.print("[yellow]the lint errors above did not fail this dry "
                      "run - set IOF_LINT_STRICT=1 to exit non-zero on them "
                      "(CI).[/yellow]")


@app.command("lint-workflow")
def lint_workflow_cmd(
    target: str = typer.Argument(None, help="Workflow name, or a path to a workflow directory / workflow.yaml"),
    all_workflows: bool = typer.Option(False, "--all", help="Lint every discoverable workflow"),
    strict: bool = typer.Option(False, "--strict", help="Exit non-zero on warnings too"),
    json_mode: bool = typer.Option(False, "--json", help="Machine-readable findings"),
    workspace: str = typer.Option(None, "--workspace", help="Tenant workspace code (default: the selected workspace; refused when none is selected)"),
):
    """Check a workflow.yaml for the mistakes the loader forgives.

    The loader reads every field with ``data.get(...)``, so a key it does not
    recognise is not rejected - it is never read. ``requires_artifact`` (no
    's') loads clean and silently disables the fail-closed artifact gate;
    ``skilz`` loads clean and the role runs with every skill instead of your
    filter. This reports those, plus the things the loader cannot know:
    prompt files that are not on disk, a fan-out with nothing to fan out
    into, and a ``learning:`` value neither of its two call sites honours.

    Exit codes: 0 clean, 1 errors found (a workflow that cannot be resolved is
    itself an error), or warnings found with --strict; 2 nothing to lint.
    """
    from ioagentfarm.engine.workflow_lint import lint_workflow, ERROR

    ws_code = _workspace_code(workspace, required=True)
    if not all_workflows and not target:
        console.print("[red]Give a workflow name or path, or pass --all.[/red]")
        raise typer.Exit(code=2)

    if all_workflows:
        names = WorkflowLoader().list_workflows(workspace=ws_code)
        if target:
            names = [n for n in names if n == target] or [target]
    else:
        names = [target]

    results = [lint_workflow(n, workspace=ws_code) for n in names]

    if json_mode:
        print(json.dumps({
            "workflows": [
                {"name": r.name, "path": r.path, "ok": r.ok,
                 "findings": [{"severity": f.severity, "where": f.where,
                               "line": f.line, "message": f.message,
                               "fix": f.fix} for f in r.findings]}
                for r in results
            ],
            "errors": sum(len(r.errors) for r in results),
            "warnings": sum(len(r.warnings) for r in results),
        }, indent=2))
    else:
        for r in results:
            _print_lint_result(r)
        n_err = sum(len(r.errors) for r in results)
        n_warn = sum(len(r.warnings) for r in results)
        summary = f"\n{len(results)} workflow(s): {n_err} error(s), {n_warn} warning(s)"
        console.print(summary if n_err else f"[green]{summary}[/green]")

    n_err = sum(len(r.errors) for r in results)
    n_warn = sum(len(r.warnings) for r in results)
    if n_err or (strict and n_warn):
        raise typer.Exit(code=1)


def _lint_target(kind: str, target) -> Path:
    """Accept what a person actually types, not only the canonical directory.

    Both linters took the DIRECTORY, and the two obvious invocations - the
    `SKILL.md` a previous command just printed the path of, and an agent's
    ROLE NAME - each produced a confusing error with a nonsense fix
    (`create SKILL.md/SKILL.md`). A validator whose own interface has to be
    guessed at teaches the wrong lesson; the canonical form is unchanged and
    anything unrecognised is passed through so the real check still reports.
    """
    p = Path(target)

    if kind == "skill":
        if p.is_file() and p.name == "SKILL.md":
            return p.parent
        if not p.exists():
            # A bare skill name, from anywhere in the repo.
            hits = sorted(q.parent for q in Path.cwd().rglob(f"{p.name}/SKILL.md")
                          if ".iof" not in q.parts and "build" not in q.parts)
            if len(hits) == 1:
                return hits[0]
        return p

    # agent
    if p.is_dir() and p.name == "workspace":
        return p.parent
    if not p.exists():
        hits = sorted(q.parent for q in Path.cwd().rglob(f"{p.name}/workspace")
                      if q.is_dir() and ".iof" not in q.parts
                      and "build" not in q.parts)
        if len(hits) == 1:
            return hits[0]
    return p


def _lint_content(kind: str, targets: list, json_mode: bool, strict: bool):
    """Shared body for lint-skill and lint-agent.

    One implementation because the two differ only in what they scan for -
    and the whole reason these commands exist is that a gap in the pattern
    gets guessed at. Two near-copies would grow their own asymmetries.
    """
    from ioagentfarm.engine.content_lint import (lint_agent_dir,
                                                 lint_skill_dir)

    lint = lint_skill_dir if kind == "skill" else lint_agent_dir
    if not targets:
        console.print(f"[red]Give a {kind} path, or pass --all from inside a "
                      "solution repository.[/red]")
        raise typer.Exit(code=2)
    results = [lint(_lint_target(kind, t)) for t in targets]

    if json_mode:
        print(json.dumps({
            f"{kind}s": [
                {"name": r.name, "path": r.path, "ok": r.ok,
                 "findings": [{"severity": f.severity, "where": f.where,
                               "line": f.line, "message": f.message,
                               "fix": f.fix} for f in r.findings]}
                for r in results],
            "errors": sum(len(r.errors) for r in results),
            "warnings": sum(len(r.warnings) for r in results),
        }, indent=2))
    else:
        for r in results:
            _print_lint_result(r)
        n_err = sum(len(r.errors) for r in results)
        n_warn = sum(len(r.warnings) for r in results)
        summary = (f"\n{len(results)} {kind}(s): {n_err} error(s), "
                   f"{n_warn} warning(s)")
        console.print(summary if n_err else f"[green]{summary}[/green]")

    n_err = sum(len(r.errors) for r in results)
    n_warn = sum(len(r.warnings) for r in results)
    if n_err or (strict and n_warn):
        raise typer.Exit(code=1)


def _discover(pattern: str) -> list:
    """Every matching directory under the pack rooted at the cwd."""
    root = Path.cwd()
    return sorted({p.parent for p in root.rglob(pattern)
                   if ".iof" not in p.parts and "build" not in p.parts})


@app.command("lint-skill")
def lint_skill_cmd(
    target: str = typer.Argument(None, help="Path to a skill directory (the one containing SKILL.md)"),
    all_skills: bool = typer.Option(False, "--all", help="Lint every skill under the current directory"),
    strict: bool = typer.Option(False, "--strict", help="Exit non-zero on warnings too"),
    json_mode: bool = typer.Option(False, "--json", help="Machine-readable findings"),
):
    """Check a SKILL.md for the mistakes that make a skill unreachable.

    A skill's ``description`` is the ONLY text an agent matches a job
    against. An unquoted value containing ``": "`` is parsed by YAML as a
    mapping, so the skill loads with no description and is never selected -
    it ships, it is advertised, and no agent ever opens it. This reports
    that, the ``<<`` merge-key trap, a name that disagrees with the
    directory, a non-boolean ``always:``, a ``roles:`` key that no longer
    gates anything, and a skill with frontmatter and no content.

    Exit codes: 0 clean, 1 errors (or warnings with --strict), 2 nothing to
    lint.
    """
    targets = _discover("SKILL.md") if all_skills else ([target] if target
                                                        else [])
    _lint_content("skill", targets, json_mode, strict)


@app.command("lint-agent")
def lint_agent_cmd(
    target: str = typer.Argument(None, help="Path to an agent directory (the one containing workspace/)"),
    all_agents: bool = typer.Option(False, "--all", help="Lint every agent under the current directory"),
    strict: bool = typer.Option(False, "--strict", help="Exit non-zero on warnings too"),
    json_mode: bool = typer.Option(False, "--json", help="Machine-readable findings"),
):
    """Check an agent workspace for what stops it working, silently.

    The expensive one is a missing ``output_protocol``: the agent emits no
    ``STATUS:``/``OUTPUT:``, so every step it runs is marked failed and
    retried to the attempt cap having done the work correctly every time.
    Also reports a missing or empty SOUL.md, an ``a2a-card.yaml`` that does
    not parse (the served card silently falls back to a minimal auto-card),
    and every finding from linting the skills the agent carries - an agent
    is only as loadable as its skills.

    Exit codes: 0 clean, 1 errors (or warnings with --strict), 2 nothing to
    lint.
    """
    if all_agents:
        targets = [p.parent for p in _discover("SOUL.md")
                   if p.name == "workspace"]
    else:
        targets = [target] if target else []
    _lint_content("agent", targets, json_mode, strict)


@app.command("patches")
def patches_cmd(
    verify: bool = typer.Option(
        False, "--verify",
        help="Import the target modules and report live bind state. Without "
             "this, patches show ARMED: they apply on first runtime import, "
             "and this command does not force that import."),
):
    """List the iobot runtime patch inventory + live status.

    The registry in ``_iobot_patches.PATCHES`` is the source of truth; this
    shows each patch, whether it's ACTIVE (sentinel bound in this process),
    ARMED (applies on first runtime import — the default since 0.6.4), its
    toggle env var, and any deprecation. State reflects the current
    environment (e.g. disable_streaming is ACTIVE only when
    IOF_DISABLE_STREAMING is set). ``--verify`` imports the runtime so the
    sentinels can be read live — the pre-0.6.4 behaviour.
    """
    from ioagentfarm._iobot_patches import patch_inventory
    inv = patch_inventory(verify=verify)
    table = Table(title="iobot runtime patch inventory")
    table.add_column("patch", no_wrap=True)
    table.add_column("state", no_wrap=True)
    table.add_column("toggle env", no_wrap=True)
    table.add_column("added", no_wrap=True)
    table.add_column("what it fixes")
    for e in inv:
        if e["deprecated"]:
            state = "[dim]DEPRECATED[/dim]"
        elif e["active"] is True:
            state = "[green]ACTIVE[/green]"
        elif e.get("armed"):
            state = "[cyan]ARMED[/cyan]"
        elif e["active"] is False:
            state = "[yellow]inactive[/yellow]"
        else:
            state = "[dim]unknown[/dim]"
        table.add_row(e["name"], state, e["toggle_env"] or "-",
                      e["added"] or "-", e["summary"])
    console.print(table)
    if any(e.get("armed") for e in inv):
        console.print(
            "\n[dim]ARMED = applies automatically on first runtime import "
            "in a process. Run with --verify to import the runtime and "
            "report live bind state.[/dim]")
    dep = [e for e in inv if e["deprecated"]]
    if dep:
        console.print("\n[dim]Deprecated (kept for history - set deprecated=False to re-enable):[/dim]")
        for e in dep:
            console.print(f"  [dim]{e['name']}: {e['deprecated_reason']}[/dim]")


@app.command("context-report")
def context_report_cmd(
    role: str = typer.Argument(..., help="Agent role, e.g. jarvis"),
    workspace: str = typer.Option(
        None, "--workspace", help="Tenant workspace code"),
    path: str = typer.Option(
        None, "--path",
        help="Inspect this workspace directory directly instead of resolving "
             "the agent home (a per-run filtered workspace, or a pack source)."),
    json_out: bool = typer.Option(
        False, "--json", help="Machine-readable report"),
    all_files: bool = typer.Option(
        False, "--all", help="Every file, not just the findings"),
):
    """What actually reaches this agent's model, and what silently does not.

    MATERIALIZED IS NOT LOADED. A file can be in the right place, with the
    right bytes, carried by every sync, and still influence zero turns -
    that is on record here as a whole learning generation that was written,
    approved, injected, attributed, and never once read, because the writer
    used ``skills/<name>.md`` and the loader reads ``skills/<name>/SKILL.md``.

    This asks the runtime's OWN loaders - it does not re-derive their rules,
    because a second implementation of the discovery rule is exactly what the
    original defect was made of. Exit 0 clean, 3 when there are findings.
    """
    from ioagentfarm.engine import context_provenance as cp

    if path and workspace:
        console.print("[red]--path and --workspace are alternatives[/red] - "
                      "--path names a directory outright, so no workspace is "
                      "resolved.")
        raise typer.Exit(code=1)
    if workspace:
        os.environ["IOF_WORKSPACE"] = workspace

    report = cp.build_report(role, Path(path) if path else None)

    if json_out:
        console.print_json(data=report.as_dict())
        raise typer.Exit(code=3 if report.findings else 0)

    if not report.files:
        console.print(f"[yellow]nothing to report[/yellow] - no workspace at "
                      f"{report.workspace}", soft_wrap=True)
        raise typer.Exit(code=1)

    console.print(f"[dim]role     :[/dim] {report.role}")
    console.print(f"[dim]workspace:[/dim] {report.workspace}", soft_wrap=True)
    if report.gates.get("memory_gated"):
        console.print("[dim]gates    :[/dim] MEMORY.md is not loaded "
                      "(learning v2)", soft_wrap=True)

    shown = report.files if all_files else (
        [f for f in report.files if f.mode == cp.INJECTED] + report.findings)
    table = Table(title="what reaches the model")
    table.add_column("mode", no_wrap=True)
    table.add_column("kind", no_wrap=True)
    table.add_column("name", no_wrap=True)
    table.add_column("why not / note")
    for f in shown:
        mode = {cp.INJECTED: "[green]injected[/green]",
                cp.LISTED: "[cyan]listed[/cyan]",
                cp.DROPPED: "[yellow]dropped[/yellow]"}.get(f.mode, f.mode)
        table.add_row(mode, f.kind, f.name, f.detail or f.reason or "")
    console.print(table)

    if not all_files:
        console.print(f"[dim]{len(report.files)} files total; "
                      f"--all shows the on-demand listings too.[/dim]")

    if report.findings:
        console.print(f"\n[yellow]{len(report.findings)} finding(s)[/yellow] - "
                      "content that exists and does not do what its shape "
                      "suggests:", soft_wrap=True)
        for f in report.findings:
            console.print(f"  [yellow]{f.reason}[/yellow]  {f.name}",
                          soft_wrap=True)
            console.print(f"    [dim]{f.path}[/dim]", soft_wrap=True)
            if f.detail:
                console.print(f"    {f.detail}", soft_wrap=True)
        raise typer.Exit(code=3)
    console.print("\n[green]no findings[/green] - every file does what its "
                  "shape suggests.")


cli_hub_app = typer.Typer(
    no_args_is_help=True,
    help="Provision pack-declared CLI tools (setup-time validate-or-install). "
         "CLI tools only - NOT MCP servers (see mcp-add/mcp-list for those).",
)
app.add_typer(cli_hub_app, name="cli-hub")


def _load_tool_specs(only: str = None):
    """Pack-declared CLI-tool specs from the registry (+ optional name filter set)."""
    from ioagentfarm.packs import load_registry
    from ioagentfarm.tools_resolver import ToolSpec
    specs = [ToolSpec.from_dict(raw, pack=raw.get("_pack", "?"))
             for raw in load_registry().tools()]
    only_set = {s.strip() for s in only.split(",") if s.strip()} if only else None
    return specs, only_set


_TOOL_STATUS_STYLE = {
    "ready": "[green]ready[/green]",
    "installed": "[green]installed[/green]",
    "would-install": "[cyan]would-install[/cyan]",
    "gap": "[yellow]gap[/yellow]",
    "error": "[red]error[/red]",
}


def _render_tool_results(results, title: str) -> int:
    from ioagentfarm.tools_resolver import display_pack, exit_code
    table = Table(title=f"{title}  [dim](CLI tools - not MCP servers)[/dim]")
    table.add_column("cli tool", no_wrap=True)
    # `owner` and `installer` are gone: both spoke the platform's internal
    # vocabulary ("core", "build") to an operator who installed a
    # differently-named distribution, and neither answered a question the
    # reader was asking. What they need is the tool, whether it is present,
    # and what to do when it is not — which `detail` already carries,
    # including the build opt-in that `installer` used to hint at.
    table.add_column("declared by", no_wrap=True)
    table.add_column("status", no_wrap=True)
    table.add_column("detail")
    for r in results:
        table.add_row(r.spec.name, display_pack(r.spec.pack),
                      _TOOL_STATUS_STYLE.get(r.status, r.status), r.detail)
    console.print(table)
    code = exit_code(results)
    n_would = sum(1 for r in results if r.status == "would-install")
    if code == 0 and n_would:
        console.print(f"[cyan]{n_would} CLI tool(s) would be installed (dry-run - no changes made).[/cyan]")
    elif code == 0:
        n_opt = sum(1 for r in results
                    if r.status == "gap" and getattr(r.spec, "optional", False))
        if n_opt:
            # Say what is absent AND that it is not a failure. Silence here
            # would hide a real absence behind a green line; a red one would
            # cry wolf on every pip install.
            console.print(
                f"[green]All required CLI tools present.[/green] "
                f"[dim]{n_opt} optional tool(s) not installed - listed above, "
                f"not a failure.[/dim]")
        else:
            console.print("[green]All declared CLI tools present.[/green]")
    elif code == 3:
        console.print("[yellow]Gaps remain - some CLI tools missing (see above).[/yellow]")
    else:
        console.print("[red]Errors during CLI-tool provisioning (see above).[/red]")
    return code


@cli_hub_app.command("list")
def cli_hub_list(only: str = typer.Option(None, help="Comma-separated tool names to show")):
    """List the tools every installed pack declares, with current presence."""
    from ioagentfarm.tools_resolver import validate, ToolResult, READY, GAP
    specs, only_set = _load_tool_specs(only)
    if not specs:
        console.print("[dim]No packs declare any tools (tools.yaml).[/dim]")
        raise typer.Exit(code=0)
    results = []
    for s in specs:
        if only_set and s.name not in only_set:
            continue
        present = validate(s)
        status = READY if present is True else GAP
        detail = "present" if present is True else ("absent" if present is False else "not validatable")
        results.append(ToolResult(s, status, detail))
    _render_tool_results(results, "Pack-declared tools (presence check)")


@cli_hub_app.command("check")
def cli_hub_check(only: str = typer.Option(None, help="Comma-separated tool names")):
    """Validate-only pass (no install). Exit 0=all present, 3=gaps, 1=error.

    This is what a container / CI runs: tools are baked into the image, so this
    should be a fast no-op that fails loudly if the image is missing a tool."""
    from ioagentfarm.tools_resolver import resolve_all
    specs, only_set = _load_tool_specs(only)
    results = resolve_all(specs, check_only=True, only=only_set)
    raise typer.Exit(code=_render_tool_results(results, "Tool check (validate-only)"))


@cli_hub_app.command("install")
def cli_hub_install(
    check_only: bool = typer.Option(False, "--check-only", help="Validate only; never install (container/CI mode)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be installed; make no changes"),
    allow_build: bool = typer.Option(False, "--allow-build", help="Opt into installer:build (runs source build steps - trusted sources only)"),
    only: str = typer.Option(None, help="Comma-separated tool names to scope the run"),
):
    """Validate-or-install every CLI tool packs declare (setup-time provisioning).

    CLI tools ONLY - the shell executables agents call via `exec` (vectorfs,
    iof-query, deck deps). This is NOT for MCP servers; those are remote/launched
    tools with a different execution model (see `mcp-add`/`mcp-list`).

    Per tool: validate first (already on PATH -> no-op, the Docker baked-in case),
    then install only the gaps via the declared `installer` (pip/npm/npm-global/
    brew). Owner tiers: `core` is validate-only, `shared`/`domain` install the
    gap, `cli-hub` is tabled. Exit 0=all present, 3=gaps remain, 1=install error."""
    from ioagentfarm.tools_resolver import resolve_all
    specs, only_set = _load_tool_specs(only)
    if not specs:
        console.print("[dim]No packs declare any tools (tools.yaml) - nothing to do.[/dim]")
        raise typer.Exit(code=0)
    env_allow = os.environ.get("AGENTFARM_ALLOW_TOOL_BUILD", "").strip().lower() in ("1", "true", "yes")
    results = resolve_all(specs, check_only=check_only, dry_run=dry_run,
                          allow_build=allow_build or env_allow, only=only_set)
    verb = "check" if check_only else ("plan" if dry_run else "install")
    raise typer.Exit(code=_render_tool_results(results, f"cli-hub {verb}"))


@app.command("workflow-install")
def workflow_install(
    workflow: str = typer.Argument(..., help="Workflow id/name (e.g. feature_dev)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    force: bool = typer.Option(False, help="Overwrite if already installed"),
):
    """Install (copy) a bundled workflow into ${IOF_ROOT}/workflows/<id> so you can edit it locally.
    """
    root_path = Path(root).resolve() if root else _root()
    _store(root_path)  # ensure dirs exist
    dest = _installed_workflows_dir(root_path) / workflow

    if dest.exists():
        if not force:
            console.print(f"[yellow]Already installed[/yellow] at {dest}. Use --force to overwrite.")
            raise typer.Exit(code=1)
        shutil.rmtree(dest)

    # Source from packaged workflows in this repo install-time location
    # When running from source, workflows live next to this file under ioagentfarm/workflows
    here = Path(__file__).resolve().parent
    src = here / "workflows" / workflow
    if not src.is_dir():
        console.print(f"[red]Bundled workflow not found:[/red] {workflow}")
        raise typer.Exit(code=2)

    shutil.copytree(src, dest)
    console.print(f"[green]Installed workflow[/green] {workflow} -> {dest}")

@app.command("workflow-uninstall")
def workflow_uninstall(
    workflow: str = typer.Argument(..., help="Workflow id/name"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
):
    """Remove an installed workflow from ${IOF_ROOT}/workflows/<id>.
    """
    root_path = Path(root).resolve() if root else _root()
    dest = _installed_workflows_dir(root_path) / workflow
    if not dest.exists():
        console.print(f"[yellow]Not installed[/yellow]: {dest}")
        raise typer.Exit(code=1)
    shutil.rmtree(dest)
    console.print(f"[green]Removed workflow[/green] {workflow}")

# ---------------------------------------------------------------------------
# Project context: use-run / current / follow-up
# ---------------------------------------------------------------------------

@app.command("use-run")
def use_run(
    run_id: str = typer.Argument(..., help="Run ID to set as active context (or 'latest' for most recent)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
):
    """Set a run as the active project context. All subsequent commands will default to this run."""
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    if run_id == "latest":
        runs = store.list_runs(limit=1, user_id=uid)
        if not runs:
            console.print("[red]No runs found.[/red]")
            raise typer.Exit(code=1)
        run_id = runs[0]["id"]

    run = _get_run_or_exit(store, run_id)
    _set_active_run(root_path, run_id, store=store, user_id=uid)
    console.print(f"[green]Active context set to[/green] {run_id}")
    console.print(f"  workflow: {run['workflow_name']}")
    console.print(f"  goal: {run['goal'][:80]}")
    console.print(f"  status: {run['status']}")
    console.print(f"  project_dir: {run.get('project_dir', '')}")


@app.command("current")
def current(
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    workspace: str = typer.Option(
        None, "--workspace",
        help="Tenant workspace code (default: the selected workspace; refused when none is selected)"),
):
    """Show the currently active run context - and which mode you are in."""
    uid = user_id or _default_user_id()

    # WHICH SOURCE OF TRUTH IS IN FORCE, before anything else. This is the
    # command people run to orient themselves, and the two facts that decide
    # what a run will actually do are the mode and the database it targets.
    from ioagentfarm.engine.db import describe_db_target
    # SAME ORDER AS `run`: resolve the workspace (which loads its .env, where
    # the mode is persisted) BEFORE deciding the mode, or this reports the
    # state of a workspace whose settings have not been read yet.
    ws = _workspace_code(workspace, required=False)
    print_mode_banner(local_mode(code=ws), ws=ws, show_context=False)
    # SAY WHEN NOTHING IS SELECTED. This printed `workspace: default`, which
    # reads as "default is selected" when the truth is that nothing is -- and
    # every command that acts on a tenant now refuses in that state. Reporting
    # the fallback as though it were a choice is the failure this command
    # exists to prevent.
    if _workspace_is_selected(workspace):
        console.print(f"[dim]workspace:[/dim] {ws}")
    else:
        # NOT `default`. See config-check: naming the fallback describes a
        # workspace nobody chose and every tenant command refuses.
        console.print("[yellow]workspace:[/yellow] none selected "
                      "[dim]- commands that act on a workspace will refuse[/dim]")
        console.print(f"  [dim]select one:[/dim]  {prog()} workspace create "
                      "<code>   [dim]# creates it and selects it[/dim]",
                      soft_wrap=True)
        console.print(f"               {prog()} workspace use <code>      "
                      "[dim]# selects an existing one[/dim]", soft_wrap=True)
    # WHERE THE SETTINGS CAME FROM. A database you did not expect is almost
    # always a file you did not know was being read.
    env_file = loaded_env(ws)
    if env_file:
        console.print(f"[dim]env file :[/dim] {env_file}", soft_wrap=True)
    elif _workspace_is_selected(workspace):
        console.print("[dim]env file :[/dim] "
                      f"(none: {workspace_env_path(ws)} does not exist)",
                      soft_wrap=True)
    else:
        # A workspace has settings; nothing selected has none. Naming
        # `.../workspaces/default/.env` here sends the reader to create a file
        # for a workspace they did not choose.
        console.print("[dim]env file :[/dim] (none - a workspace has settings; "
                      "none is selected)", soft_wrap=True)
    # Name the OLD location when it is the one in use. Both paths work, and a
    # reader following current documentation would look in the other one.
    if env_file and Path(env_file).parent == _ws_env.legacy_workspace_home(ws):
        console.print(f"[dim]         [/dim] [dim](the earlier location; "
                      f"settings now belong in "
                      f"{_ws_env.workspace_home(ws) / '.env'} - move it when "
                      "convenient, both are read)[/dim]", soft_wrap=True)
    root_path = Path(root).resolve() if root else _root()
    # A DIAGNOSTIC MUST NOT CREATE STATE. `_store()` mkdirs IOF_ROOT and runs
    # `init()`, so merely ASKING what this directory is pointed at left a
    # `.iof/` behind -- and `new-workspace` then refuses to scaffold into a
    # directory that has one. Following the docs in order (page 02 says run
    # `current` before anything that writes; page 03 then scaffolds here) hit
    # exactly that, exit 2. The store is only needed to look up an active
    # run, and a directory with no state has none.
    # REPORT THE TARGET BEFORE TRYING TO REACH IT. `_store()` CONNECTS, so
    # with an unreachable or mistyped database this command printed the
    # banner and the env file, then died on OperationalError without ever
    # printing the `database :` line -- the one thing it exists to say, and
    # the check the documentation tells you to run before anything that
    # writes. "Where am I pointed?" must be answerable precisely when the
    # answer is somewhere wrong.
    console.print(f"[dim]database :[/dim] {describe_db_target(root_path)}",
                  soft_wrap=True)
    if not (os.getenv("IOF_DATABASE_URL") or "").strip():
        console.print("[yellow]           no IOF_DATABASE_URL is set for this workspace - "
                      "add one to its .env; the default sqlite is a per-machine "
                      "file, not a shared database[/yellow]", soft_wrap=True)
    try:
        from ioagentfarm.engine.content import stamp_line as _stamp_line
        console.print(f"[dim]content  :[/dim] {_stamp_line(packs_only=True) or '(no packs installed)'}",
                      soft_wrap=True)
    except Exception as _exc:  # pragma: no cover
        console.print(f"[dim]content  :[/dim] (stamp unavailable: {type(_exc).__name__})")
    store = None
    store_error: Exception | None = None
    if root_path.exists():
        try:
            store = _store(root_path)
        except Exception as exc:           # unreachable host, bad URL, no perms
            store_error = exc
    # WHO DECIDED THAT. The workspace's own file is one candidate among
    # several, and naming only it reported "(none)" while a HOME dotenv fed
    # every command a production database. The question a reader is asking
    # here is not "does my workspace have settings" but "why am I pointed
    # there", and only this line answers it.
    console.print(f"[dim]  set by :[/dim] "
                  f"{_ws_env.source_of('IOF_DATABASE_URL')}", soft_wrap=True)
    # A file that was found and not loaded is reported, so that its absence
    # from the resolved settings is explained rather than left to inference.
    # `~/.iobot/.env` IS NOT A STRAY FILE. `setup-agents` publishes it, for
    # the tools an agent runs: the runtime strips an exec'd subprocess to
    # HOME/LANG/TERM, and those tools read it back with dotenv themselves.
    # The CLI does not read it, so it still belongs in this list -- but
    # telling the reader to "move these settings" would send them to undo
    # something the product wrote on purpose.
    from ioagentfarm.engine import home_env as _home_env
    _published = str(_home_env.home_env_path())
    for ignored in _ws_env.IGNORED:
        if ignored == _published:
            console.print(f"[dim] ignored :[/dim] {ignored}  [dim](credentials "
                          "for agent tool subprocesses, written by "
                          "setup-agents; this CLI does not read it)[/dim]",
                          soft_wrap=True)
        else:
            # `workspace_home(ws)`, NOT `workspace_env_path(ws)`: the latter
            # falls back to the pre-`workspaces/` location when that is the
            # only file present, so for the one reader who still has the old
            # file this advised moving settings INTO the deprecated path,
            # two lines after reporting that it is the earlier location.
            # WHERE TO MOVE IT depends on a workspace existing. With none
            # selected, naming `.../workspaces/default/.env` tells the reader
            # to populate a workspace they did not choose and that every
            # tenant command refuses to act on.
            _dest = (f"{_ws_env.workspace_home(ws) / '.env'}"
                     if _workspace_is_selected(workspace)
                     else "the settings of the workspace you select")
            console.print(f"[dim] ignored :[/dim] {ignored}  [dim](not read - "
                          f"move these settings to {_dest})[/dim]",
                          soft_wrap=True)

    if store_error is not None:
        # The database is named above; this says it could not be reached, and
        # exits 1 because that IS the answer to "can I write here".
        console.print(f"[red]  status :[/red] unreachable - "
                      f"{type(store_error).__name__}: "
                      f"{str(store_error).strip().splitlines()[0][:160]}",
                      soft_wrap=True)
        raise typer.Exit(code=1)
    if store is None:
        console.print("[dim]state    :[/dim] none here yet [dim](no "
                      f"{root_path.name}/ - the first command that runs "
                      "something creates it)[/dim]", soft_wrap=True)
        raise typer.Exit(code=0)

    # WHAT IS REGISTERED AS RUNNING HERE (One Truth model, docs/one-truth-
    # content-model.md §3.3): the latest boot registration for the active
    # workspace on THIS host, one line per content distribution. `serve`
    # writes it at boot; the CLI only reads. Reachable database, no row yet =
    # say so; anything failing (older schema, permissions) = skip silently --
    # this command must stay usable, and the lines above already answered
    # the question it exists for.
    if _workspace_is_selected(workspace):
        try:
            import socket as _socket
            from ioagentfarm.engine.content import Stamp
            from ioagentfarm.engine.registration import latest_registration
            _host = _socket.gethostname()
            _rows = latest_registration(store, ws, host=_host)
        except Exception:
            _rows = None
        if _rows is not None:
            if _rows:
                console.print("[dim]registered:[/dim]")
                for _r in _rows:
                    # The same text `Stamp.render()` prints everywhere else,
                    # rebuilt from the row so the two cannot drift.
                    _line = Stamp(pack=_r["pack"], dist=_r["dist"],
                                  version=_r["version"], source=_r.get("source"),
                                  root=_r.get("root"), sha=_r.get("git_sha"),
                                  dirty=bool(_r.get("dirty"))).render()
                    # '-' not a middle dot: console text must survive cp437
                    # (tests/test_console_output_is_ascii.py).
                    console.print(f"  {_line} [dim]- booted "
                                  f"{_r['booted_at']}[/dim]", soft_wrap=True)
            else:
                console.print("[dim]registered:[/dim] (none yet on this host "
                              "- serve writes it at boot)", soft_wrap=True)

    # Try per-user DB context first, then global file
    run_id = store.get_user_active_run(uid)
    if not run_id:
        active_file = root_path / "active_run"
        if active_file.exists():
            run_id = active_file.read_text(encoding="utf-8").strip()

    if not run_id:
        console.print("[yellow]No active context set.[/yellow] "
                      f"Use: {prog()} use-run <run_id>")
        raise typer.Exit(code=0)

    try:
        run = store.get_run(run_id)
    except KeyError:
        # A DANGLING POINTER IS NOT AN ERROR IN THIS COMMAND. `current` is the
        # thing a reader is told to run before anything that writes, so its
        # exit code answers "am I pointed at the right database". It answered
        # "no" for an unrelated reason: `workspace delete --force` purges the
        # run rows and leaves the active-run pointer behind, after which every
        # `current` in that directory exited 1 while reporting the correct
        # database on the line above.
        console.print(f"[dim]active run {run_id} is no longer in this "
                      "database (deleted with its workspace, or a different "
                      f"database) - clear it with `{prog()} use-run <run_id>`"
                      "[/dim]")
        raise typer.Exit(code=0)

    console.print(f"[cyan]Active run:[/cyan] {run_id}")
    console.print(f"  workflow: {run['workflow_name']}")
    console.print(f"  goal: {run['goal'][:120]}")
    console.print(f"  status: {run['status']}")
    console.print(f"  user: {run.get('user_id', '')}")
    console.print(f"  project_dir: {run.get('project_dir', '')}")
    parent = run.get("parent_run_id")
    if parent:
        console.print(f"  parent: {parent}")


@app.command("follow-up")
def follow_up(
    goal: str = typer.Option(..., help="Follow-up goal / request"),
    from_run: str = typer.Option(None, "--from", help="Prior run to continue from (default: active context)"),
    workflow: str = typer.Option(None, help="Workflow to use (default: feature_dev, from the devkit pack)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
    setup_mcp: bool = typer.Option(False, "--setup-mcp/--no-setup-mcp", help="Auto-configure MCP servers"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show step DAG without executing"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    workspace: str = typer.Option(None, "--workspace", help="Tenant workspace code (default: the selected workspace; refused when none is selected)"),
):
    """Start a new run that continues from a prior run's project.
    Inherits project_dir and injects prior run summary as context.

    Defaults to the ``feature_dev`` workflow (5 steps, token-efficient), which
    ships in the optional ``agentfarm-devkit`` pack. Deployments that install
    only core plus their own solution must pass ``--workflow <their-own>``."""
    _setup_logging(verbose)
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()
    ws_code = _workspace_code(workspace, required=True, write=True)

    # Resolve the prior run
    prior_run_id = _resolve_run_id(store, root_path, from_run, user_id=uid)
    if not prior_run_id:
        console.print("[red]No prior run found.[/red] Run a workflow first, or use --from <run_id>.")
        raise typer.Exit(code=1)

    prior_run = _get_run_or_exit(store, prior_run_id)
    prior_project_dir = prior_run.get("project_dir", "")
    follow_up_workflow = workflow or "feature_dev"

    # Load workflow. The default lives in the optional agentfarm-devkit pack,
    # so a core-only deployment must name its own workflow — say so plainly
    # rather than surfacing a bare "workflow not found".
    loader = WorkflowLoader()
    try:
        wf = loader.load(follow_up_workflow, workspace=ws_code)
    except FileNotFoundError:
        if workflow is None:
            console.print(
                "[red]Default follow-up workflow 'feature_dev' is not installed.[/red]\n"
                "It ships in the optional [cyan]agentfarm-devkit[/cyan] pack. Either "
                "pass [cyan]--workflow <name>[/cyan] (see `aicore list-workflows`) "
                "or install the pack: [cyan]pip install agentfarm-devkit[/cyan]")
            raise typer.Exit(code=1)
        raise


    # --dry-run: validate workflow and print step DAG, no execution
    if dry_run:
        console.print(f"[cyan]Workflow:[/cyan] {follow_up_workflow} ({len(wf.steps)} steps)")
        console.print(f"[cyan]Goal:[/cyan] {goal}")
        console.print(f"[cyan]Prior run:[/cyan] {prior_run_id}\n")
        for i, step in enumerate(wf.steps, 1):
            deps = ", ".join(step.deps) if step.deps else "(none)"
            console.print(f"  {i}. {step.key:20s} [{step.role}]  deps: {deps}",
                          markup=False)  # [role] is data, not Rich markup
            if step.per_item_steps:
                for tmpl in step.per_item_steps:
                    console.print(f"     +- :{tmpl.key_suffix:17s} [{tmpl.role}]  (per story)")
        return

    # Check iobot is available
    if not runtime_bin_available():
        console.print("[red]iobot CLI not found. Install with: pip install -e ./iobot[/red]")
        raise typer.Exit(code=2)

    # Build prior run summary
    prior_summary = _build_prior_run_summary(store, prior_run_id)

    # Compose augmented goal
    augmented_goal = (
        f"{goal}\n\n"
        f"## Prior run context\n"
        f"This is a follow-up to run {prior_run_id}.\n"
        f"Prior goal: {prior_run['goal']}\n"
        f"Prior status: {prior_run['status']}\n"
        f"Project directory: {prior_project_dir}\n\n"
        f"{prior_summary}"
    )

    project_path = Path(prior_project_dir) if prior_project_dir else Path.cwd()

    # Activate the tenant workspace BEFORE seeding agents (per-workspace home)
    _activate_workspace(ws_code, root_path)

    # Seed agent workspaces for the project.
    #
    # THE ORCHESTRATOR IS NOT A WORKFLOW ROLE, and seeding only `wf.roles` is
    # how it came to run with no identity at all. Alex drives every pipeline
    # but appears in no workflow's `roles:`, so his workspace was never
    # created — the runtime found an empty directory at launch, scaffolded its
    # own `SOUL.md` ("I am iobot, a personal AI assistant") and gave him none
    # of his skills: orchestrate, run_context, status_reports,
    # dynamic_tasks, output_protocol, ask_subagent.
    #
    # It survived because the task message restates enough of `orchestrate` to
    # carry a simple linear pipeline, so runs completed and looked right. What
    # it does not restate is the retry discipline, the hard attempt cap and the
    # recovery rules — the parts that only matter when something goes wrong.
    #
    # Worse, it is STICKY: once the runtime writes those files, `setup-agents`
    # without `--force` skips every one that already exists, so the default
    # persona survives every later attempt to seed properly.
    for role_name in (*wf.roles, ORCHESTRATOR_ROLE):
        try:
            ensure_iobot_agent(role_name)
        except FileNotFoundError as _e:
            # One sentence, not a 56-line traceback with no run id: the YAML
            # names a role no installed pack provides (novice finding).
            console.print(f"[red]{_e}[/red]")
            console.print(f"[dim]Agents in scope: `{prog()} list-agents`[/dim]")
            raise typer.Exit(code=1)

    # Attribution == execution: the workspace was explicitly resolved
    # (required=True), so the run belongs to it. No owner-guessing pass.
    attr_ws = ws_code
    ws_id = store.ensure_workspace(code=attr_ws, name=_workspace_display_name(attr_ws))

    # Lazily ensure workflow exists in DB and get its id.
    # team_json is passed for the same reason the web path passes it:
    # ensure_workflow UPDATES every column on an existing row, so OMITTING it
    # writes the default '[]' and BLANKS the roster the Studio reads. A CLI run
    # would quietly empty the session header of a workflow the web path had
    # just populated.
    wf_id = store.ensure_workflow(
        code=follow_up_workflow,
        workspace_code=attr_ws,
        name=follow_up_workflow.replace("_", " ").title(),
        description=wf.description,
        steps_json=json.dumps([s.key for s in wf.steps]),
        roles_json=json.dumps(list(wf.roles.keys())),
        team_json=json.dumps([{"role": m.role} for m in wf.team_roster]),
    )

    new_run_id = store.create_run(
        workflow_name=follow_up_workflow,
        goal=augmented_goal,
        project_dir=str(project_path),
        parent_run_id=prior_run_id,
        user_id=uid,
        workflow_id=wf_id,
        workspace_id=ws_id,
    )
    # A follow-up run is a run: same opening boundary event + provenance
    # record every other creation path writes (this site was the one that
    # did not, so follow-up runs had no run.created and no content stamp).
    _emit_run_created(root_path, new_run_id, follow_up_workflow, "workflow",
                      augmented_goal, workspace_code=ws_code)
    loader.snapshot_workflow(follow_up_workflow, new_run_id, root=root_path,
                             workspace=ws_code)
    store.materialize_steps(new_run_id, wf)

    # Create per-run instance config (MCP servers, logs, cron isolated per run)
    from ioagentfarm.engine.iobot_config import create_instance_config, get_run_output_dir
    instance_config = create_instance_config(root_path, new_run_id, str(project_path))
    run_output_dir = get_run_output_dir(root_path, new_run_id)
    run_output_dir.mkdir(parents=True, exist_ok=True)

    # Update active context
    _set_active_run(root_path, new_run_id, store=store, user_id=uid)

    # Build step lookup for progress display
    steps = store.list_steps(new_run_id)
    step_info = {s["step_key"]: {"role": s["role"], "seq": s["seq"]} for s in steps}

    console.print(f"[cyan]Follow-up run[/cyan] {new_run_id} (from {prior_run_id})")
    console.print(f"  workflow: {follow_up_workflow} ({len(steps)} steps)")
    console.print(f"  content: {_content_line()}", soft_wrap=True)
    console.print(f"  source_dir: {project_path}")
    console.print(f"  output_dir: {run_output_dir}\n")

    task_msg = (
        f"IMPORTANT: A run has already been created for you. Do NOT create another run.\n\n"
        f"Run ID: {new_run_id}\n"
        f"Workflow: {follow_up_workflow}\n"
        f"Goal: {augmented_goal}\n"
        f"Source directory: {project_path}\n"
        f"Output directory: {run_output_dir}\n"
        f"User ID: {uid}\n\n"
        f"Drive this run to completion by looping:\n"
        f"1. `ioagentfarm next-step --run-id {new_run_id} --user-id {uid}` - get next step\n"
        f"2. If role=project_lead, execute inline:\n"
        f"   a. Write your output to a file using an ABSOLUTE path (e.g. /tmp/iof_output.txt). Must contain STATUS: done/failed and OUTPUT: <detailed result>\n"
        f"   b. `ioagentfarm step-complete --step-key <key> --run-id {new_run_id} --output-file /tmp/iof_output.txt --user-id {uid}`\n"
        f"3. If role is ANYTHING ELSE (not project_lead): you MUST delegate it — `ioagentfarm run-step --step-key <key> --run-id {new_run_id} --user-id {uid}`. Do NOT do the step's work yourself, and do NOT call step-complete for it (step-complete is REJECTED for non-project_lead steps; only run-step runs them in the right agent).\n"
        f"4. Repeat until next-step returns done=true.\n"
        f"\nIMPORTANT: Do NOT create or modify project files. You are the project lead - you plan and delegate, never implement.\n"
    )

    _invoke_agent_with_progress(
        role="project_lead",
        session_key=f"iof:{new_run_id}:orchestrate",
        user_id=uid,
        root_path=root_path,
        config_path=instance_config,
        message=task_msg,
        step_info=step_info,
        total_steps=len(steps),
    )

    # Report final status
    final_run = store.get_run(new_run_id)
    final_steps = store.list_steps(new_run_id)
    done_count = sum(1 for s in final_steps if s["status"] == "done")
    failed_count = sum(1 for s in final_steps if s["status"] == "failed")
    if final_run["status"] == "done":
        console.print(f"\n[green][ok] Pipeline complete[/green] - {done_count}/{len(final_steps)} steps done")
    elif failed_count:
        console.print(f"\n[red][x] Pipeline failed[/red] - {done_count} done, {failed_count} failed")
    else:
        console.print(f"\n[red]Follow-up run {new_run_id} finished with status: {final_run['status']}[/red]")


# ---------------------------------------------------------------------------
# Direct execution
# ---------------------------------------------------------------------------

def _content_stamp() -> dict | None:
    """The installed-content stamp (``engine.content.stamp_dict``), or
    ``None`` — FAIL-OPEN, logged at WARNING. Provenance is a record, never a
    gate: a git hiccup must not refuse a run or take a header down."""
    try:
        from ioagentfarm.engine.content import stamp_dict
        return stamp_dict()
    except Exception:
        logger.warning("content stamp unavailable", exc_info=True)
        return None


def _content_line() -> str:
    """One-line content provenance for run headers / --json output."""
    stamp = _content_stamp()
    return stamp["line"] if stamp else "(stamp unavailable)"


def _recorded_content_line(root_path: Path, run_id: str) -> str:
    """The content line AS RECORDED in the run's provenance.json — what the
    header prints must be what the record says. Falls back to a fresh stamp
    only when the record could not be written (fail-open, never raises)."""
    try:
        from ioagentfarm.engine.content import read_run_provenance
        doc = read_run_provenance(root_path, run_id) or {}
        content = doc.get("content")
        if isinstance(content, dict) and content.get("line"):
            return content["line"]
    except Exception:
        logger.debug("provenance unreadable for run %s", run_id, exc_info=True)
    return _content_line()


def _emit_run_created(root_path: Path, run_id: str, workflow_name: str,
                      kind: str, goal: str,
                      workspace_code: str | None = None,
                      draft: dict | None = None) -> None:
    """Record that a run was created: the ``run.created`` boundary event AND
    the run's ``provenance.json`` (fail-open, like every emit).

    THE ONE SEAM EVERY CREATION PATH REACHES — `run`, `run-swarm`,
    `follow-up`, `POST /api/run`, `POST /api/swarms/{name}/run` — which is
    why the provenance record lives here rather than beside any one of
    them: written here, no path can skip it. Both carry the same content
    stamp (docs/one-truth-content-model.md section 3.3): the event's payload
    for cross-run SQL, ``provenance.json`` for `forensics explain` and for a
    run whose database is gone.

    The opening anchor of a run's forensic timeline — `forensics explain`
    and cross-run SQL both key on run boundaries existing.
    """
    content = _content_stamp()
    try:
        from ioagentfarm.engine.content import write_run_provenance
        write_run_provenance(root_path, run_id, workspace_code=workspace_code,
                             content=content, draft=draft)
    except Exception:
        logger.warning("could not record provenance for run %s", run_id,
                       exc_info=True)
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO
        payload = {"kind": kind, "workflow": workflow_name,
                   "goal": goal[:300]}
        if content:
            payload["content"] = content["line"]
        # A draft run's event names the author + items: a fleet query that
        # cannot tell draft runs from pack runs would blame the pack for an
        # overlay's behaviour.
        if draft:
            payload["draft"] = draft
        get_forensics(root_path).emit(
            run_id=run_id, event_type="run.created", severity=SEVERITY_INFO,
            message=f"{kind} run created for {workflow_name}",
            payload=payload,
        )
    except Exception:
        logger.debug("Failed to emit run.created", exc_info=True)


@app.command()
def run(
    workflow: str = typer.Argument(..., help="Workflow name (e.g. feature_dev)"),
    goal: str = typer.Option(None, help="High-level goal / request"),
    goal_file: str = typer.Option(
        None, "--goal-file",
        help="Read the goal from this file (UTF-8) instead of --goal. For a "
             "goal longer than a command line - a whole business playbook "
             "handed to `playbook_compile` - argv is the wrong vehicle: "
             "Windows caps the command line at 32,767 characters and the "
             "failure is a spawn error, not a clear refusal."),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    project_dir: str = typer.Option(None, help="Target project directory where agents work. Defaults to cwd."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
    setup_mcp: bool = typer.Option(False, "--setup-mcp/--no-setup-mcp", help="Auto-configure MCP servers for project access"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show step DAG without executing"),
    allow_concurrent: bool = typer.Option(False, "--allow-concurrent", help="Start even while a workflow named in `depends_on_runs:` is still running. The consumer then works from a PARTIAL corpus - intended only when that is what you want."),
    json_mode: bool = typer.Option(False, "--json", help="Return JSON and spawn execution in background (for agents/integrations). Replaces start-run."),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    var: List[str] = typer.Option([], "--var", help="Override workflow vars: KEY=VALUE (repeatable). E.g. --var docs_dir=/path --var schema=msa"),
    workspace: str = typer.Option(None, "--workspace", help="Tenant workspace code (default: the selected workspace; refused when none is selected)"),
    local: bool = typer.Option(
        None, "--local/--no-local",
        # NOT "run from your files instead of the database": there is no
        # database content tier left to opt out of. Content always resolves
        # from the installed solution; this flag moves STATE, not content.
        help="LOCAL MODE: keep state and the database in this directory, with "
             "no server. Content always resolves from the installed solution. "
             "Persist it with `aicore local on`."),
    driver: str = typer.Option(
        "agent", "--driver",
        help="WHO DECIDES THE STEP ORDER. 'agent' (default): project_lead "
             "drives, choosing the next step each cycle. 'code': the DAG "
             "drives - no model in the control plane, independent steps run "
             "in parallel. Either way each step still runs whatever the "
             "workflow says, agents included."),
    follow: bool = typer.Option(
        False, "--follow",
        help="(code driver) stream each step's live NARRATION - agent "
             "thoughts, tool lines, exec output - to the console as it "
             "happens, every line prefixed [step_key] so parallel steps stay "
             "readable. Runtime log records are filtered out of the view; "
             "the run's per-step log files keep the complete raw stream. "
             "Default off: the console shows only started/finished progress "
             "lines."),
):
    """Run a workflow end-to-end. Alex (project_lead) drives the pipeline via iobot.

    Default: blocking with rich progress output (for humans at CLI).
    With --json: creates run, spawns background execution, returns JSON immediately (for agents/Teams).
    """
    _setup_logging(verbose)
    if bool(goal) == bool(goal_file):
        typer.echo("ERROR: pass exactly one of --goal or --goal-file",
                   err=True)
        raise typer.Exit(2)
    if goal_file:
        try:
            goal = Path(goal_file).read_text(encoding="utf-8")
        except OSError as e:
            typer.echo(f"ERROR: cannot read --goal-file {goal_file!r}: {e}",
                       err=True)
            raise typer.Exit(2)
        if not goal.strip():
            typer.echo(f"ERROR: --goal-file {goal_file!r} is empty",
                       err=True)
            raise typer.Exit(2)
    # Refuse a driver name we do not have, by name — a typo would otherwise
    # fall through to the agent driver and silently run the pipeline the way
    # the flag was passed to avoid.
    driver = (driver or "agent").strip().lower()
    if driver not in ("agent", "code"):
        console.print(f"[red]Unknown --driver '{driver}'.[/red] "
                      f"Use 'agent' (project_lead drives) or 'code' (the DAG "
                      f"drives).")
        raise typer.Exit(2)
    # ORDER IS LOAD-BEARING. The workspace's own .env (where `aicore local on`
    # persists the mode) and the localisation it implies must both happen
    # BEFORE `_root()` and `_store()`: those resolve the state directory and
    # open the database, so doing it the other way round meant a "local" run
    # had already pointed at whatever an inherited file named.
    ws_code = _workspace_code(workspace, required=True, write=True)
    _on_local = local_mode(local, code=ws_code)
    root_path = Path(root).resolve() if root else _root()
    uid = user_id or _default_user_id()

    loader = WorkflowLoader()

    def _would_not_load(name: str, exc: BaseException, as_json: bool) -> None:
        """One line on both paths. A YAML syntax error and a per-item step
        without `prompt:` were still ~100-line tracebacks, and `--json`
        answered a load error in prose (novice finding, round 3)."""
        if as_json:
            typer.echo(json.dumps({"error": "workflow would not load", "workflow": name,
                                   "detail": str(exc), "lint": f"aicore lint-workflow {name}"}))
            raise typer.Exit(1)
        console.print(f"[red]Workflow '{name}' would not load:[/red]")
        console.print(f"  {exc}", markup=False, highlight=False)
        console.print(f"  [dim]aicore lint-workflow {name}   # every finding, with line numbers[/dim]")
        raise typer.Exit(1)

    try:
        wf = loader.load(workflow, workspace=ws_code)
    except ValueError as _e:
        # A workflow that EXISTS and fails validation is not "not found" -
        # reported that way, with a did-you-mean offering the same name back,
        # it was a dead end. Say what the loader said.
        _would_not_load(workflow, _e, json_mode)
    except FileNotFoundError as _e:
        if "not found." not in str(_e):
            # The workflow EXISTS; a file it names does not (a missing prompt
            # file) - that is a load error, and "not found ... did you mean
            # <the same name>" was a dead end (novice finding, twice).
            _would_not_load(workflow, _e, json_mode)
        if json_mode:
            typer.echo(json.dumps({"error": "workflow not found", "workflow": workflow,
                                   "workspace": ws_code}))
            raise typer.Exit(1)
        # A NAME THAT DOES NOT RESOLVE IS A USER MISTAKE, not a crash. This
        # surfaced as a raw Rich traceback ending in "Workflow 'x' not
        # found." — twenty lines of engine internals for a typo, and no word
        # about the two things that actually decide resolution: which
        # workspace, and whether the pack is installed HERE.
        console.print(f"[red]No workflow named '{workflow}' in workspace "
                      f"'{ws_code}'.[/red]")
        known = []
        try:
            known = loader.list_workflows(workspace=ws_code)
        except Exception:
            pass
        if known:
            near = difflib.get_close_matches(workflow, known, n=3, cutoff=0.5)
            if near:
                console.print("Did you mean: "
                              + ", ".join(f"[cyan]{n}[/cyan]" for n in near))
            console.print(f"[dim]available here: {', '.join(known)}[/dim]",
                          soft_wrap=True)
        else:
            console.print(
                f"[dim]No workflows resolve for '{ws_code}' at all. A "
                "workflow comes from an installed pack - check `pip install -e .` "
                "ran in THIS venv and that this workspace has that pack in scope "
                f"(`aicore current` shows the installed content)[/dim]",
                soft_wrap=True)
        console.print(f"[dim]list them: aicore list-workflows --workspace "
                      f"{ws_code}[/dim]")
        raise typer.Exit(code=1)
    except Exception as _e:  # noqa: BLE001 - a YAML error, a KeyError: still a load error
        _would_not_load(workflow, _e, json_mode)

    # Parse --var KEY=VALUE overrides
    var_overrides: Dict[str, str] = {}
    for kv in (var or []):
        if "=" in kv:
            k, v = kv.split("=", 1)
            var_overrides[k.strip()] = v.strip()
        else:
            # a typo in the separator was a warning while a typo in the key
            # was a refusal (novice, round 6); both are exit 2 now
            console.print(f"[red]--var '{kv}' is not KEY=VALUE - nothing can be applied from it "
                          "(quote a value that contains spaces).[/red]")
            raise typer.Exit(code=2)
    _declared_vars = set((getattr(wf, "vars", None) or {}).keys())
    _unknown_vars = sorted(k for k in var_overrides if k not in _declared_vars)
    if _unknown_vars:
        # a misspelled override was silently ignored (novice finding, round 3)
        console.print(f"[red]--var names {_unknown_vars}, which this workflow does not "
                      f"declare under `vars:` (declared: {sorted(_declared_vars) or 'none'}).[/red]")
        raise typer.Exit(code=2)

    # An exec-only pipeline run under the DEFAULT agent driver spends model
    # calls to order a DAG that is already fixed - the operator who forgot
    # `--driver code` pays for nothing (novice finding, round 8). Said here,
    # before the dry-run return, so a careful operator sees it first; scoped
    # to the exact case (every step a command, no agent) so a real agent
    # pipeline is never nagged.
    if driver != "code":
        try:
            _exec_only = bool(wf.steps) and all(
                s.runs_command and not (s.per_item_steps or []) for s in wf.steps)
        except Exception:  # noqa: BLE001
            _exec_only = False
        if _exec_only:
            console.print(
                "[yellow]note: every step here is a command with no agent, but this run "
                "uses the default agent driver, which spends model calls to decide the "
                "order. `--driver code` runs the same steps deterministically, with no "
                "model in the control plane and no spend.[/yellow]")

    # --dry-run: validate workflow and print step DAG, no execution
    if dry_run:
        console.print(f"[cyan]Workflow:[/cyan] {workflow} ({len(wf.steps)} steps)")
        console.print(f"[cyan]Goal:[/cyan] {goal}")
        # Which content this dry run validated — the same stamp a real run
        # records in provenance.json (docs/one-truth-content-model.md 3.3).
        console.print(f"[cyan]content:[/cyan] {_content_line()}\n", soft_wrap=True)
        for i, step in enumerate(wf.steps, 1):
            deps = ", ".join(step.deps) if step.deps else "(none)"
            console.print(f"  {i}. {step.key:20s} [{step.role}]  deps: {deps}",
                          markup=False)  # [role] is data, not Rich markup
            if step.per_item_steps:
                for tmpl in step.per_item_steps:
                    console.print(f"     +- :{tmpl.key_suffix:17s} [{tmpl.role}]  (per story)")
        _dry_run_lint(workflow, ws_code)
        return

    # Check iobot is available
    if not runtime_bin_available():
        console.print("[red]iobot CLI not found. Install with: pip install -e ./iobot[/red]")
        raise typer.Exit(code=2)

    store = _store(root_path)
    project_path = Path(project_dir).resolve() if project_dir else Path.cwd()
    if project_dir and not project_path.exists():
        # a mistyped --project-dir became a new working directory nobody
        # asked for, in silence (novice, round 6)
        console.print(f"[yellow]note: --project-dir {project_path} did not exist - created it.[/yellow]")
    project_path.mkdir(parents=True, exist_ok=True)

    # Activate the tenant workspace BEFORE seeding agents so identity/memory
    # land in the per-workspace agent home for non-default tenants.
    _activate_workspace(ws_code, root_path)
    print_mode_banner(_on_local, ws=ws_code, to_stderr=json_mode)

    # Seed agent workspaces for all roles in the workflow, PLUS the
    # orchestrator — which is in no workflow's `roles:` and was therefore the
    # one agent nobody seeded. See the identical loop on the follow-up path.
    #
    # EXCEPT a role only `exec` steps use. An exec step runs a command and
    # never opens an agent, and the loader gives one that declares no role
    # the placeholder `system` — which no pack ships. So an all-exec
    # pipeline died HERE, before its first step, demanding an agent it was
    # never going to invoke. Scoped to roles used by nothing else on
    # purpose: a role declared for a dynamic task appears in `roles:` and in
    # no step at all, and must still be seeded.
    _exec_only = {s.role for s in wf.steps if s.runs_command} - (
        {s.role for s in wf.steps if not s.runs_command}
        | {t.role for s in wf.steps for t in (s.per_item_steps or [])})
    for role_name in (*wf.roles, ORCHESTRATOR_ROLE):
        if role_name in _exec_only:
            continue
        try:
            ensure_iobot_agent(role_name)
        except FileNotFoundError as _e:
            console.print(f"[red]{_e}[/red]")
            console.print(f"[dim]Agents in scope: `{prog()} list-agents`[/dim]")
            raise typer.Exit(code=1)

    # A workflow that CONSUMES what another produces may not start while that
    # other one is still producing. Between steps this ordering is `deps:` and
    # the scheduler enforces it; between RUNS nothing expressed it, so nothing
    # stopped both starting at once and the consumer working from half its
    # input - output that is not wrong so much as founded on less evidence than
    # it appears to be, with every gate green. Refuses rather than waits:
    # blocking the CLI is what `run_ops` forbids, and it would make the
    # caller's timeout the run's timeout. See engine/run_deps.py.
    if not allow_concurrent:
        from ioagentfarm.engine import run_deps
        _names = list(run_deps.declared(wf))
        if run_deps.single_active(wf):
            # A workflow that consumes its OWN queue must not race itself: the
            # domain's `processed` flag is set when a batch finishes, so two
            # runs starting together both select the same rows and neither can
            # see the other.
            _names.append(workflow)
        _blocking = run_deps.blocking_runs(
            store, _names, workspace_code=ws_code)
        if _blocking:
            typer.secho(run_deps.refusal(_blocking, workflow,
                                         run_deps.driver_notes(store, _blocking)),
                        err=True, fg=typer.colors.RED)
            raise typer.Exit(code=4)

    # Attribution == execution: the workspace was explicitly resolved
    # (required=True), so the run belongs to it. No owner-guessing pass.
    attr_ws = ws_code
    ws_id = store.ensure_workspace(code=attr_ws, name=_workspace_display_name(attr_ws))

    # Lazily ensure workflow exists in DB and get its id. team_json is not
    # optional here — see the note on the follow-up path: ensure_workflow
    # updates every column, so omitting it blanks the stored roster.
    wf_id = store.ensure_workflow(
        code=workflow,
        workspace_code=attr_ws,
        name=workflow.replace("_", " ").title(),
        description=wf.description,
        steps_json=json.dumps([s.key for s in wf.steps]),
        roles_json=json.dumps(list(wf.roles.keys())),
        team_json=json.dumps([{"role": m.role} for m in wf.team_roster]),
    )


    # Fail-fast disk guard: a run started on a nearly-full state volume dies
    # late with corrupt artifacts. Named refusal now beats forensics later.
    from ioagentfarm.engine.guards import ensure_free_disk, DiskSpaceError
    try:
        ensure_free_disk(root_path)
    except DiskSpaceError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=3)

    # Two concurrent runs pointed at ONE project directory lost each other's
    # writes and both went green (novice finding, round 5). Nothing forbids
    # it - a shared directory can be intended - but nothing said it either.
    _sharing, _sharing_dead = [], []
    try:
        from ioagentfarm.engine.supervisor import driver_state as _drv_state
        for _r in store.list_active_runs():
            if str(_r.get("project_dir") or "") != str(project_path):
                continue
            # A run left `running` by a dead driver counted as "active in
            # this directory" for ever, and the count disagreed with the
            # three ids printed (novice, round 6).
            try:
                _dead = bool(_drv_state(_r, store.list_steps(_r["id"]))["stale"])
            except Exception:  # noqa: BLE001
                _dead = False
            (_sharing_dead if _dead else _sharing).append(_r["id"])
    except Exception:  # noqa: BLE001
        _sharing, _sharing_dead = [], []

    def _ids(xs):
        return ", ".join(xs[:3]) + (f", +{len(xs) - 3} more" if len(xs) > 3 else "")
    run_id = store.create_run(workflow_name=workflow, goal=goal, project_dir=str(project_path), user_id=uid, workflow_id=wf_id, workspace_id=ws_id)
    # Under --json these two lines go to STDERR: printed on stdout ahead of
    # the JSON, the warning made `run --json` unparseable for exactly the
    # integrations the flag exists for (a guide's json.load failed on it,
    # 2026-09-02). The text is unchanged; only the stream moves.
    _notes = _stderr_console if json_mode else console
    if _sharing_dead:
        _notes.print(f"[dim]note: {len(_sharing_dead)} run(s) recorded as running in this project "
                     f"directory have no live driver ({_ids(_sharing_dead)}) - "
                     "`aicore cancel <id>` or `aicore resume <id>` settles each.[/dim]")
    if _sharing:
        _notes.print(f"[yellow]warning: {len(_sharing)} other run(s) are active in this project "
                     f"directory ({_ids(_sharing)}); runs sharing a directory can "
                     "overwrite each other's files - use a separate --project-dir unless "
                     "that is intended.[/yellow]")
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
            get_forensics(root_path).emit(
                run_id=run_id, event_type="run.shared_project_dir", severity=SEVERITY_WARN,
                step_key=None, role=None,
                message=(f"{len(_sharing)} other active run(s) share this project directory: "
                         f"{', '.join(_sharing[:5])} - concurrent writes can be lost"),
                payload={"project_dir": str(project_path), "runs": _sharing[:20]})
        except Exception:  # noqa: BLE001
            pass
    store.set_run_driver(run_id, driver)

    # RE-CHECK AFTER INSERTING. The guard above is a read, and the write
    # happens here — so two launches a fraction of a second apart both read
    # "nothing active" and both created a run. Measured: two signal_detection
    # runs 417ms apart, on a workflow that declares single_active_run
    # BECAUSE two consumers over one queue produced 104 and 30 signals from
    # the same fifty notes. The check was written after that incident and
    # cannot prevent the instant-collision case it describes.
    #
    # Now the row is the claim. Both racers insert, then both look again;
    # whichever run_id sorts EARLIER keeps its run and the other withdraws.
    # Run ids are timestamp-prefixed, so "earlier id" is "started first" and
    # both processes reach the same verdict without coordinating. This needs
    # no schema change and no DB-specific upsert, which matters because the
    # store backs onto both SQLite and PostgreSQL.
    from ioagentfarm.engine import run_deps as _run_deps
    if not allow_concurrent and _run_deps.single_active(wf):
        rivals = [r for r in _run_deps.blocking_runs(store, [workflow],
                                                     workspace_code=ws_code)
                  if (r.get("id") or "") and r.get("id") != run_id]
        earlier = [r for r in rivals if (r.get("id") or "") < run_id]
        if earlier:
            # No steps exist yet (materialize_steps runs below), so failing
            # the row is the whole withdrawal.
            with store._tx() as _cur:
                _cur.execute(
                    store._q("UPDATE runs SET status='failed', updated_at=? "
                             "WHERE id=?"),
                    (store._now(), run_id))
            _rival = earlier[0].get("id")
            _hint = f"Watch it: aicore status --run-id {_rival}"
            try:
                from ioagentfarm.engine.supervisor import driver_state
                _rv = store.get_run(_rival)
                _ds = driver_state(_rv, store.list_steps(_rival))
                if _ds["stale"]:
                    _a = _ds["heartbeat_age_s"]
                    _hint = (f"Its driver is GONE (no heartbeat for "
                             f"{'ever' if _a is None else f'{_a:.0f}s'}) - it will hold the "
                             f"queue until something restarts it: aicore resume {_rival}; "
                             f"a service under `aicore serve`/`supervise` does that on its own")
            except Exception:  # noqa: BLE001
                pass
            typer.secho(
                f"refusing to start: {_rival} is already "
                f"running {workflow}, which declares single_active_run "
                f"(it consumes its own queue, so two runs would both select "
                f"the same unprocessed rows). This run ({run_id}) withdrew. {_hint}.",
                err=True, fg=typer.colors.RED)
            raise typer.Exit(code=4)

    _emit_run_created(root_path, run_id, workflow, "workflow", goal,
                      workspace_code=ws_code)
    loader.snapshot_workflow(workflow, run_id, root=root_path, workspace=ws_code)

    # Persist var overrides into instance dir so scheduler picks them up
    if var_overrides:
        vars_file = root_path / "instances" / run_id / "workflow_vars.json"
        vars_file.parent.mkdir(parents=True, exist_ok=True)
        vars_file.write_text(json.dumps(var_overrides), encoding="utf-8")

    store.materialize_steps(run_id, wf)
    _set_active_run(root_path, run_id, store=store, user_id=uid)

    _execute_created_run(store=store, root_path=root_path, run_id=run_id,
                         workflow=workflow, goal=goal,
                         project_path=project_path, uid=uid, ws_code=ws_code,
                         json_mode=json_mode, verbose=verbose, driver=driver,
                         follow=follow)


def _report_final(store, run_id: str, run_output_dir) -> None:
    # Whoever drove this run has stopped by the time the final report
    # prints; say so on the row (see Store.clear_driver_heartbeat).
    try:
        store.clear_driver_heartbeat(run_id)
    except Exception:  # noqa: BLE001
        pass
    """The run's closing verdict. Shared by both drivers, so they cannot
    report the same outcome two different ways."""
    final_run = store.get_run(run_id)
    final_steps = store.list_steps(run_id)
    done_count = sum(1 for s in final_steps if s["status"] == "done")
    failed_count = sum(1 for s in final_steps if s["status"] == "failed")
    if final_run["status"] == "done":
        _closed = sum(1 for s in final_steps if s["status"] == "done"
                      and str(s.get("output_text") or "").startswith("(closed"))
        _note = f" ({_closed} closed by a route, never ran)" if _closed else ""
        console.print(f"\n[green][ok] Pipeline complete[/green] - {done_count}/{len(final_steps)} steps done{_note}")
        console.print(f"  [dim]Output artifacts: {run_output_dir}[/dim]")
        # A green run can still deserve a second look; explain knew, the
        # console did not (novice finding). Same words, on the screen.
        try:
            from ioagentfarm.cli_forensics import _build_explain
            _warns = _build_explain(run_id).get("warnings") or []
        except Exception:  # noqa: BLE001 - a report, never a gate
            _warns = []
        for _w in _warns:
            console.print("  warning: " + str(_w), markup=False, style="yellow")
        return
    if failed_count:
        console.print(f"\n[red][x] Pipeline failed[/red] - {done_count} done, {failed_count} failed")
    else:
        console.print(f"\n[red]Run {run_id} finished with status: {final_run['status']}[/red]")
    console.print(f"  [dim]Diagnose: aicore forensics explain {run_id}   |   "
                  f"a step's own output: aicore status --run-id {run_id} --step <key>[/dim]")
    console.print(f"  [dim]Retry a step: aicore step-retry --run-id {run_id} --step-key <key>, "
                  f"then aicore resume {run_id} (re-spawns the run's own driver)[/dim]")
    # THE EXIT CODE IS THE VERDICT. A failed pipeline exited 0, so a script
    # or a CI job that checked only the code saw success.
    raise typer.Exit(1)


def _execute_created_run(*, store, root_path: Path, run_id: str,
                         workflow: str, goal: str, project_path: Path,
                         uid: str, ws_code: str, json_mode: bool,
                         verbose: bool, driver: str = "agent",
                         follow: bool = False) -> None:
    """Execute an already-created run: --json spawn, or the blocking driver.

    Shared by `run` (workflows) and `run-swarm` (compiled swarms) — by the
    time this is called the two are indistinguishable: run row, snapshot,
    materialized steps. Everything below (driver loop, supervisor sweep,
    respawn budget, final report) is kind-blind on purpose.
    """
    steps = store.list_steps(run_id)
    first = steps[0] if steps else None

    # --json mode: spawn background execution and return JSON immediately
    if json_mode:
        from ioagentfarm.web.spawn import spawn_run
        try:
            spawn_run(
                run_id=run_id,
                workflow=workflow,
                goal=goal,
                project_dir=str(project_path),
                user_id=uid,
                root_path=root_path,
                detach=True,
                workspace=ws_code,
                driver=driver,
            )
        except Exception as _e:  # noqa: BLE001
            # The run row exists and nothing drives it. Say the id, mark it,
            # record why - a traceback with no run id left an orphan the
            # launcher could not `resume` (novice finding, round 4).
            try:
                store.set_run_status(run_id, "failed")
                from ioagentfarm.engine.forensics import get_forensics, SEVERITY_ERROR
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="run.spawn_failed", severity=SEVERITY_ERROR,
                    step_key=None, role=None,
                    message=f"the driver could not be started: {type(_e).__name__}: {_e}",
                    payload={"error": str(_e)[:500]})
            except Exception:  # noqa: BLE001
                pass
            typer.echo(json.dumps({
                "run_id": run_id, "workflow": workflow, "driver": driver,
                "execution": "failed_to_spawn", "error": f"{type(_e).__name__}: {_e}",
                "retry": f"aicore resume {run_id} --force",
            }))
            raise typer.Exit(code=1)
        result = {
            "run_id": run_id,
            "workflow": workflow,
            "driver": driver,
            "goal": goal,
            "total_steps": len(steps),
            "execution": "spawned",
            "content": _recorded_content_line(root_path, run_id),
            # A detached run emits nothing, so the caller is handed an id and
            # silence. `forensics watch` existed and nothing pointed at it -
            # a build session handed back a run id and went quiet for
            # thirty-eight minutes with a live narration one command away.
            "watch": f"aicore watch {run_id}",
        }
        if first:
            result["first_step_key"] = first["step_key"]
            result["first_role"] = first["role"]
        print(json.dumps(result, indent=2))
        return

    # --- Blocking (interactive) mode below ---

    # Create per-run instance config (MCP servers, logs, cron isolated per run)
    from ioagentfarm.engine.iobot_config import create_instance_config, get_run_output_dir
    instance_config = create_instance_config(root_path, run_id, str(project_path))
    run_output_dir = get_run_output_dir(root_path, run_id)
    run_output_dir.mkdir(parents=True, exist_ok=True)
    if verbose:
        console.print(f"  [dim]Instance config: {instance_config}[/dim]")
        console.print(f"  [dim]Output dir: {run_output_dir}[/dim]")

    # Build step lookup for progress display
    step_info = {s["step_key"]: {"role": s["role"], "seq": s["seq"]} for s in steps}

    # The run id is the handle for everything afterwards - `forensics
    # explain`, `run-output`, `step-retry` - so it is stated once, plainly,
    # at the top. It was previously a single line that scrolled past behind
    # provider chatter; with that silenced this is the first thing printed,
    # and the output directory is named here rather than only at the end.
    console.print(f"[cyan]Run started[/cyan] [bold]{run_id}[/bold]")
    console.print(f"  workflow: {workflow} ({len(steps)} steps)")
    # WHICH content this run runs — read back from the provenance.json the
    # creation seam just wrote, so the header and the record cannot disagree.
    console.print(f"  content:  {_recorded_content_line(root_path, run_id)}",
                  soft_wrap=True)
    console.print(f"  output:   {run_output_dir}\n")

    # `--driver code`: the ORDER comes from the DAG instead of from an agent.
    # Every step still runs whatever the workflow says it runs; this replaces
    # the scheduler and nothing else. See engine/code_driver.py.
    if driver == "code":
        from ioagentfarm.engine.code_driver import drive, STALL_S
        console.print("[cyan]Driver: code[/cyan] - the DAG decides the order; "
                      "steps still run their own agents")
        # Say WHICH steps still use a model, rather than refusing them: a
        # pipeline with agentic leaves is the target architecture, not a
        # misuse of the flag.
        try:
            _wf = WorkflowLoader().load(workflow, run_id=run_id, root=root_path)
            agentic = [s.key for s in _wf.steps if not s.runs_command]
            agentic += [f"{s.key}:{t.key_suffix}" for s in _wf.steps
                        for t in (s.per_item_steps or [])]
        except Exception:  # noqa: BLE001 - the note is a courtesy, not a gate
            agentic = []
        if agentic:
            shown = ", ".join(agentic[:4]) + (" ..." if len(agentic) > 4 else "")
            console.print(f"  [dim]{len(agentic)} step(s) run an agent: {shown}[/dim]")
        console.print("")
        try:
            why = drive(root_path=root_path, run_id=run_id, uid=uid,
                        workspace=ws_code, follow=follow,
                        on_event=lambda m: console.print(f"  [dim]{m}[/dim]"))
        except KeyboardInterrupt:
            # the record could not tell an operator's interrupt from a crash
            # from a kill - none wrote an event (novice finding, round 7)
            try:
                from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="run.interrupted", severity=SEVERITY_WARN,
                    step_key=None, role=None,
                    message=f"the foreground driver was interrupted (Ctrl+C) by {uid}; "
                            f"its running step(s) died with it - `aicore resume {run_id}` continues",
                    payload={"by": uid})
                store.clear_driver_heartbeat(run_id)
            except Exception:  # noqa: BLE001
                pass
            console.print(f"\n[yellow]Interrupted.[/yellow] The run is recorded as interrupted; "
                          f"continue it with: aicore resume {run_id}")
            raise typer.Exit(code=130)
        if why == "failed":
            console.print(f"\n[red]Driver stopped: a step failed on its last "
                          f"attempt and nothing else can run.[/red] Diagnose with: "
                          f"aicore forensics explain {run_id}; retry with: aicore "
                          f"step-retry --step-key <key> --run-id {run_id}, then "
                          f"aicore resume {run_id}")
        if why == "stalled":
            console.print(f"\n[yellow]Driver stopped: no step could start for "
                          f"{STALL_S:.0f}s. Diagnose with: aicore forensics "
                          f"explain {run_id}[/yellow]")
        _report_final(store, run_id, run_output_dir)
        return

    task_msg = (
        f"IMPORTANT: A run has already been created for you. Do NOT create another run.\n\n"
        f"Run ID: {run_id}\n"
        f"Workflow: {workflow}\n"
        f"Goal: {goal}\n"
        f"Source directory: {project_path}\n"
        f"Output directory: {run_output_dir}\n"
        f"User ID: {uid}\n\n"
        f"Drive this run to completion by looping:\n"
        f"1. `ioagentfarm next-step --run-id {run_id} --user-id {uid}` - get next step\n"
        f"2. If role=project_lead, execute inline:\n"
        f"   a. Write your output to a file using an ABSOLUTE path (e.g. /tmp/iof_output.txt). Must contain STATUS: done/failed and OUTPUT: <detailed result>\n"
        f"   b. `ioagentfarm step-complete --step-key <key> --run-id {run_id} --output-file /tmp/iof_output.txt --user-id {uid}`\n"
        f"3. If role is ANYTHING ELSE (not project_lead): you MUST delegate it — `ioagentfarm run-step --step-key <key> --run-id {run_id} --user-id {uid}`. Do NOT do the step's work yourself, and do NOT call step-complete for it (step-complete is REJECTED for non-project_lead steps; only run-step runs them in the right agent).\n"
        f"4. Repeat until next-step returns done=true.\n"
        f"\nIMPORTANT: Do NOT create or modify project files. You are the project lead - you plan and delegate, never implement.\n"
    )

    # Orchestrator resilience + STATELESS DRIVE CYCLES.
    #
    # All orchestration state lives in the store (steps table); the driver's
    # conversation adds nothing `next-step` doesn't already say. Historically
    # one session drove the whole pipeline, so its transcript compounded
    # (~27K tokens by step 39) and every multi-minute step wait outlived the
    # provider's 5-min prompt-cache TTL — re-billing the whole transcript as
    # cache-write on the next call (measured ~3.7M/run, ~95K/step, half of it
    # TTL re-writes). Stateless mode (IOF_ORCH_STEPS_PER_CYCLE > 0, default 5)
    # asks the driver to advance at most N steps per session and exit; the
    # loop below respawns a FRESH session (per-cycle session_key) until the
    # run converges. Transcript stays near boot size; a productive cycle exit
    # is expected behaviour, not a failure, and does not consume the respawn
    # budget. Premature no-progress exits (the dominant v0.2.x failure shape)
    # stay capped by IOF_ORCHESTRATOR_RESPAWNS. Legacy single-session mode:
    # IOF_ORCH_STEPS_PER_CYCLE=0.
    import time

    steps_per_cycle = int(os.environ.get("IOF_ORCH_STEPS_PER_CYCLE", "5"))
    stateless = steps_per_cycle > 0
    cycle_msg = (
        f"\nSESSION BUDGET: advance AT MOST {steps_per_cycle} steps in this "
        f"session (one next-step -> execute-or-delegate -> completion cycle "
        f"each; a run-step that fans out stories counts as one). After the "
        f"{steps_per_cycle}th step completes — or when next-step returns "
        f"done=true — reply with a one-paragraph progress summary and END "
        f"YOUR SESSION. A fresh orchestrator session is spawned automatically "
        f"to continue; all run state lives in the database (`next-step` tells "
        f"the new session everything), NOT in your conversation. Do not "
        f"exceed the budget.\n"
    ) if stateless else ""
    max_respawns = int(os.environ.get("IOF_ORCHESTRATOR_RESPAWNS", "3"))
    respawn_msg_extra = (
        f"\nNOTE: You are CONTINUING an in-progress run (a previous orchestrator "
        f"session ended). Start with `ioagentfarm next-step --run-id {run_id} "
        f"--user-id {uid}`. If a step shows as still running, poll until it "
        f"completes (or apply crash recovery per your orchestrate skill) — do "
        f"not restart completed work.\n"
    )
    spawn = 0
    stalls = 0
    completed_before = sum(
        1 for s in steps if s["status"] in ("done", "skipped"))
    while True:
        # Driver heartbeat: this loop IS the driver. Touch on every
        # drive-cycle iteration so the run supervisor never mistakes a live
        # blocking `run` for a dead driver (next-step/step-complete calls
        # from Alex also beat mid-session).
        store.touch_driver_heartbeat(run_id)
        session_key = f"iof:{run_id}:orchestrate" + (
            f":c{spawn}" if stateless else "")
        _invoke_agent_with_progress(
            role="project_lead",
            session_key=session_key,
            user_id=uid,
            root_path=root_path,
            config_path=instance_config,
            message=(task_msg + cycle_msg if spawn == 0
                     else task_msg + cycle_msg + respawn_msg_extra),
            step_info=step_info,
            total_steps=len(steps),
        )
        # Self-supervision (single-run scope, driver resume OFF — this loop
        # is the driver and respawns Alex itself below). Reaps any step left
        # 'running' by a silently-dead run-step subprocess so the next
        # orchestrator session finds it pending instead of polling forever.
        try:
            from ioagentfarm.engine.supervisor import supervise_once
            _sup_actions = supervise_once(
                store, root_path, run_id=run_id, resume_drivers=False)
            for _a in _sup_actions:
                console.print(
                    f"[yellow]Supervisor: {_a['action']} "
                    f"{_a.get('step_key', '')} (run {run_id})[/yellow]")
        except Exception:
            logger.debug("run-loop supervise_once failed", exc_info=True)
        store.touch_driver_heartbeat(run_id)
        current = store.get_run(run_id)
        steps_now = store.list_steps(run_id)
        open_steps = [
            s for s in steps_now if s["status"] not in ("done", "skipped")
        ]
        if current["status"] != "running" or not open_steps:
            break
        completed_now = sum(
            1 for s in steps_now if s["status"] in ("done", "skipped"))
        made_progress = completed_now > completed_before
        completed_before = completed_now
        if made_progress:
            stalls = 0  # productive cycle — expected in stateless mode
        else:
            stalls += 1
            if stalls > max_respawns:
                console.print(
                    f"\n[yellow]Orchestrator exited {max_respawns + 1}x with no "
                    f"progress and {len(open_steps)} step(s) still open - giving "
                    f"up on auto-resume. Diagnose first (aicore forensics "
                    f"explain {run_id}), then continue with: aicore resume "
                    f"{run_id} - or step by step: next-step --run-id {run_id} "
                    f"/ run-step --step-key <key> --run-id {run_id}[/yellow]"
                )
                # LEAVE A DIAGNOSABLE RECORD. Found by chaos-proxy testing:
                # under a total provider outage the driver cannot make its
                # own LLM calls, so no step ever starts and this loop gives
                # up - leaving the run 'running' with ONE event
                # (run.created) and nothing to explain it. `forensics
                # explain` could only report "status: running", which is the
                # one answer a postmortem must never give. The event names
                # the shape (driver exited N times with no progress) so the
                # diagnosis path has something real to work from.
                try:
                    from ioagentfarm.engine.forensics import (get_forensics,
                                                              SEVERITY_FATAL)
                    get_forensics(root_path).emit(
                        run_id=run_id,
                        event_type="run.driver_gave_up",
                        severity=SEVERITY_FATAL,
                        message=(f"driver exited {max_respawns + 1}x with no "
                                 f"progress; {len(open_steps)} step(s) never "
                                 "completed - the run did not converge"),
                        payload={"respawns": max_respawns + 1,
                                 "open_steps": [s["step_key"]
                                                for s in open_steps]},
                    )
                except Exception:
                    logger.debug("give-up event emit failed", exc_info=True)
                break
        spawn += 1
        if made_progress:
            console.print(
                f"\n[cyan]Drive cycle {spawn} complete "
                f"({completed_now}/{len(steps_now)} steps done) - spawning "
                f"fresh orchestrator session...[/cyan]"
            )
        else:
            delay = min(30, 5 * stalls)
            console.print(
                f"\n[yellow]Orchestrator exited without progress; run {run_id} "
                f"still has {len(open_steps)} open step(s) - respawning "
                f"({stalls}/{max_respawns}) in {delay}s...[/yellow]"
            )
            time.sleep(delay)

    _report_final(store, run_id, run_output_dir)


@app.command("_drive", hidden=True)
def _drive(
    run_id: str = typer.Option(..., "--run-id"),
    user_id: str = typer.Option(None, "--user-id"),
    root: str = typer.Option(None, "--root"),
):
    """Internal: the code driver's loop for an already-created run. What
    `spawn_run` starts when the run's driver is `code` - the detached (--json),
    resumed and supervisor-resurrected forms of `aicore run --driver code`."""
    from ioagentfarm.engine.code_driver import drive
    from ioagentfarm.engine.iobot_config import get_run_output_dir
    root_path = Path(root).resolve() if root else _root()
    uid = user_id or _default_user_id()
    store = _store(root_path)
    ws = os.environ.get("IOF_WORKSPACE") or None
    why = drive(root_path=root_path, run_id=run_id, uid=uid, workspace=ws,
                on_event=lambda m: print(f"  {m}", flush=True))
    print(f"driver stopped: {why}", flush=True)
    _report_final(store, run_id, get_run_output_dir(root_path, run_id))


@app.command("run-swarm")
def run_swarm(
    swarm_name: str = typer.Argument(..., help="Swarm name (e.g. portfolio_review)"),
    goal: str = typer.Option(..., help="The goal this swarm run pursues"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    project_dir: str = typer.Option(None, help="Target project directory. Defaults to cwd."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show the roster + compiled shape without executing"),
    json_mode: bool = typer.Option(False, "--json", help="Return JSON and spawn execution in background"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    var: List[str] = typer.Option([], "--var", help="Override swarm vars: KEY=VALUE (repeatable)"),
    workspace: str = typer.Option(None, "--workspace", help="Tenant workspace code (default: the selected workspace; refused when none is selected)"),
    local: bool = typer.Option(None, "--local/--no-local",
                               help="LOCAL MODE: state and database in this directory, no server (see `aicore run --help`)"),
):
    """Run a swarm: a meta-agent pursues the goal with its declared roster.

    The swarm compiles into a one-step run at creation, so it inherits the
    workflow pipeline's whole resilience stack - retries, forensics, the
    fail-closed deliverable gate, the attempt cap, supervisor recovery.
    """
    _setup_logging(verbose)
    # Same load-bearing order as `run`: workspace env + local mode BEFORE the
    # state root and store resolve.
    ws_code = _workspace_code(workspace, required=True, write=True)
    _on_local = local_mode(local, code=ws_code)
    root_path = Path(root).resolve() if root else _root()
    uid = user_id or _default_user_id()

    from ioagentfarm.engine.swarms import SwarmLoader, compile_swarm, compiled_skills
    loader = SwarmLoader()
    try:
        swarm = loader.load(swarm_name, root=root_path)
    except FileNotFoundError:
        console.print(f"[red]No swarm named '{swarm_name}'.[/red]")
        known = sorted(loader.list_swarms(root=root_path))
        if known:
            near = difflib.get_close_matches(swarm_name, known, n=3, cutoff=0.5)
            if near:
                console.print("Did you mean: "
                              + ", ".join(f"[cyan]{n}[/cyan]" for n in near))
            console.print(f"[dim]available here: {', '.join(known)}[/dim]",
                          soft_wrap=True)
        else:
            console.print(
                "[dim]No swarms resolve at all. A swarm comes from an "
                "installed pack's swarms/ directory - check `pip install "
                "-e .` ran in THIS venv, or create one: aicore new-swarm "
                "<name>[/dim]", soft_wrap=True)
        console.print("[dim]list them: aicore list-swarms[/dim]")
        raise typer.Exit(code=1)
    except ValueError as exc:
        console.print(f"[red]Swarm '{swarm_name}' failed to load: {exc}[/red]")
        console.print(f"[dim]lint it: aicore lint-swarm {swarm_name}[/dim]")
        raise typer.Exit(code=1)

    if dry_run:
        console.print(f"[cyan]Swarm:[/cyan] {swarm.name}")
        console.print(f"[cyan]Goal:[/cyan] {goal}")
        console.print(f"  meta-agent   : {swarm.role}")
        agents_desc = ("all registered" if swarm.agents is None
                       else ", ".join(swarm.agents) or "(none)")
        mcp_desc = ("all declared tiers" if swarm.mcp_servers is None
                    else ", ".join(swarm.mcp_servers) or "(none)")
        console.print(f"  A2A agents   : {agents_desc}")
        console.print(f"  MCP servers  : {mcp_desc}")
        console.print(f"  skills       : {', '.join(compiled_skills(swarm))}")
        console.print(f"  deliverable  : {swarm.deliverable} (fail-closed)")
        if swarm.budget:
            budget_bits = []
            if swarm.budget.tool_calls is not None:
                budget_bits.append(f"tool_calls={max(20, swarm.budget.tool_calls)} (hard)")
            if swarm.budget.consults is not None:
                budget_bits.append(f"consults={swarm.budget.consults} (briefing contract)")
            if budget_bits:
                console.print(f"  budget       : {', '.join(budget_bits)}")
        # Same fail-open advisory contract as workflow --dry-run.
        from ioagentfarm.engine.swarm_lint import lint_swarm_dir
        try:
            if swarm.base_dir is not None and isinstance(swarm.base_dir, Path):
                res = lint_swarm_dir(swarm.base_dir)
                if res.findings:
                    _print_lint_result(res)
                    if res.errors and os.environ.get("IOF_LINT_STRICT") == "1":
                        raise typer.Exit(code=1)
        except typer.Exit:
            raise
        except Exception:
            logger.debug("swarm dry-run lint failed", exc_info=True)
        return

    if not runtime_bin_available():
        console.print("[red]iobot CLI not found. Install with: pip install -e ./iobot[/red]")
        raise typer.Exit(code=2)

    store = _store(root_path)
    project_path = Path(project_dir).resolve() if project_dir else Path.cwd()
    if project_dir and not project_path.exists():
        # a mistyped --project-dir became a new working directory nobody
        # asked for, in silence (novice, round 6)
        console.print(f"[yellow]note: --project-dir {project_path} did not exist - created it.[/yellow]")
    project_path.mkdir(parents=True, exist_ok=True)

    _activate_workspace(ws_code, root_path)
    print_mode_banner(_on_local, ws=ws_code, to_stderr=json_mode)

    for role_name in (swarm.role, ORCHESTRATOR_ROLE):
        ensure_iobot_agent(role_name)

    ws_id = store.ensure_workspace(code=ws_code,
                                   name=_workspace_display_name(ws_code))
    # Deliberately NO ensure_workflow: a swarm is not a workflow-catalog row.
    # runs.kind='swarm' carries the distinction; the run's workflow_name is
    # the swarm's name.

    var_overrides: Dict[str, str] = {}
    for kv in (var or []):
        if "=" in kv:
            k, v = kv.split("=", 1)
            var_overrides[k.strip()] = v.strip()
        else:
            # a typo in the separator was a warning while a typo in the key
            # was a refusal (novice, round 6); both are exit 2 now
            console.print(f"[red]--var '{kv}' is not KEY=VALUE - nothing can be applied from it "
                          "(quote a value that contains spaces).[/red]")
            raise typer.Exit(code=2)

    from ioagentfarm.engine.guards import ensure_free_disk, DiskSpaceError
    try:
        ensure_free_disk(root_path)
    except DiskSpaceError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=3)

    run_id = store.create_run(workflow_name=swarm.name, goal=goal,
                              project_dir=str(project_path), user_id=uid,
                              workflow_id=None, workspace_id=ws_id,
                              kind="swarm")
    _emit_run_created(root_path, run_id, swarm.name, "swarm", goal,
                      workspace_code=ws_code)
    # COMPILE IS THE SNAPSHOT: written before anything else touches the run,
    # so every later snapshot_workflow call early-returns on it.
    compile_swarm(swarm, run_id, root_path)

    if var_overrides:
        vars_file = root_path / "instances" / run_id / "workflow_vars.json"
        vars_file.parent.mkdir(parents=True, exist_ok=True)
        vars_file.write_text(json.dumps(var_overrides), encoding="utf-8")

    # Loading through the REAL workflow loader proves the compile in the same
    # breath as using it: this is the object the scheduler will re-derive.
    compiled_wf = WorkflowLoader().load(swarm.name, run_id=run_id,
                                        root=root_path)
    store.materialize_steps(run_id, compiled_wf)
    _set_active_run(root_path, run_id, store=store, user_id=uid)

    _execute_created_run(store=store, root_path=root_path, run_id=run_id,
                         workflow=swarm.name, goal=goal,
                         project_path=project_path, uid=uid, ws_code=ws_code,
                         json_mode=json_mode, verbose=verbose)


@app.command("list-swarms")
def list_swarms_cmd(
    root: str = typer.Option(None, help="State root directory; default .iof"),
):
    """List every swarm resolvable here (override tree + installed packs)."""
    from ioagentfarm.engine.swarms import SwarmLoader
    root_path = Path(root).resolve() if root else _root()
    swarms = SwarmLoader().list_swarms(root=root_path)
    if not swarms:
        console.print("[dim]No swarms found.[/dim]")
        console.print("A swarm comes from an installed pack's swarms/ "
                      "directory. Create one: aicore new-swarm <name>")
        return
    for name in sorted(swarms):
        s = swarms[name]
        console.print(f"  [cyan]{name}[/cyan] [dim]({s.role})[/dim]  "
                      f"{s.description or '(no description)'}")


@app.command("lint-swarm")
def lint_swarm_cmd(
    target: str = typer.Option(None, "--name", help="Swarm name or path (positional also accepted)"),
    name_arg: str = typer.Argument(None, metavar="[NAME-OR-PATH]"),
    all_swarms: bool = typer.Option(False, "--all", help="Lint every resolvable swarm"),
    strict: bool = typer.Option(False, "--strict", help="Warnings also fail the exit code"),
    json_out: bool = typer.Option(False, "--json", help="Machine-readable findings"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
):
    """Validate swarm definitions - unknown keys, bad rosters, compile errors."""
    from ioagentfarm.engine.swarm_lint import lint_swarm, lint_swarm_dir
    from ioagentfarm.engine.swarms import SwarmLoader
    root_path = Path(root).resolve() if root else _root()

    results = []
    if all_swarms:
        loader = SwarmLoader()
        for name, s in sorted(loader.list_swarms(root=root_path).items()):
            if isinstance(s.base_dir, Path):
                results.append(lint_swarm_dir(s.base_dir))
            else:
                results.append(lint_swarm(name, root=root_path))
    else:
        chosen = target or name_arg
        if not chosen:
            console.print("[red]Name a swarm (or pass --all).[/red]")
            raise typer.Exit(code=2)
        results.append(lint_swarm(chosen, root=root_path))

    if json_out:
        payload = {
            "swarms": [{
                "name": r.name, "path": r.path,
                "ok": r.ok and (not strict or not r.warnings),
                "findings": [{
                    "severity": f.severity, "where": f.where,
                    "line": f.line, "message": f.message, "fix": f.fix,
                } for f in r.findings],
            } for r in results],
            "errors": sum(len(r.errors) for r in results),
            "warnings": sum(len(r.warnings) for r in results),
        }
        print(json.dumps(payload, indent=2))
    else:
        clean = 0
        for r in results:
            if r.findings:
                _print_lint_result(r)
            else:
                clean += 1
        if clean:
            console.print(f"[green]{clean} swarm(s) clean[/green]")

    has_errors = any(r.errors for r in results)
    has_warnings = any(r.warnings for r in results)
    if not results:
        raise typer.Exit(code=2)
    if has_errors or (strict and has_warnings):
        raise typer.Exit(code=1)


def _engine_auth_summary() -> dict:
    """One-line auth posture for the serve banner. Never raises, never leaks.

    A banner that can crash the command it decorates is worse than no banner,
    so a broken configuration degrades to 'OFF' here — `assert_safe_to_serve`
    has already refused the genuinely unsafe case by the time this runs.
    """
    try:
        from ioagentfarm.web.auth import load_config
        cfg = load_config()
    except Exception:  # noqa: BLE001 — see the docstring
        return {"enabled": False, "mechanisms": [], "detail": ""}
    if not cfg.enabled:
        return {"enabled": False, "mechanisms": [], "detail": ""}
    bits: list[str] = []
    if cfg.oidc_config is not None:
        bits.append(f"issuer {cfg.oidc_config.issuers[0]}")
        bits.append(f"audience {cfg.oidc_config.audiences[0]}")
    if cfg.api_keys:
        # The count. Never a key, never a prefix of one.
        bits.append(f"{len(cfg.api_keys)} shared key(s)")
    return {"enabled": True, "mechanisms": sorted(cfg.mechanisms),
            "detail": ("\n         " + "\n         ".join(bits)) if bits else ""}


@app.command("serve")
def serve(
    workspace: str = typer.Option(
        None, "--workspace",
        help="Workspace this engine serves (one engine, one workspace). "
             "Wins over IOF_WORKSPACE and the stored selection. Two engines "
             "on one machine each name their own - the env var cannot live "
             "in the workspace .env, because it is what selects that file."),
    host: str = typer.Option("0.0.0.0", help="Bind address"),
    port: int = typer.Option(
        8111,
        help="Port. 8111 is what agent-chat defaults to, what "
             "entrypoint.sh sets GATEWAY_PORT to, and what the "
             "deployment manifests EXPOSE - serve defaulted to 8000, "
             "so `serve` then `agent-chat` with no flags could not "
             "reach each other."),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    concurrency: int = typer.Option(
        None, "--concurrency",
        help="Max concurrent LLM requests per agent (serve default: 10, "
             "0=unlimited). Also settable via IOBOT_MAX_CONCURRENT_REQUESTS (upstream env name).",
    ),
):
    """Start the ioagentfarm web API server (FastAPI + uvicorn).

    Hybrid architecture:
    - Workflow runs spawn as independent OS processes (full concurrency)
    - Follow-up messages go to an always-on agent pool (in-process,
      instant response via process_direct - no subprocess overhead)

    Install with: pip install ioagentfarm[web,iobot]
    """
    try:
        import uvicorn
    except ImportError:
        console.print("[red]uvicorn not found. Install with: pip install ioagentfarm[web][/red]")
        raise typer.Exit(code=2)

    # RESOLVE THE WORKSPACE BEFORE THE STORE. `_workspace_code()` is what loads
    # `~/.iobot/workspaces/<code>/.env`, and that file is where IOF_DATABASE_URL
    # lives. Fifteen other commands resolve through it; `serve` did not, and the
    # consequence was silent and expensive: `web/app.py:_store()` reads the bare
    # environment variable and falls back to `sqlite:///<IOF_ROOT>/state.db` when
    # it is unset, so an engine started with only IOF_WORKSPACE wrote every run,
    # message and thought into a local SQLite while the Studio API read the
    # workspace's PostgreSQL. Nothing errored — the Studio simply showed no
    # agent reasoning, because the reader and the writer were different
    # databases. `aicore current` reported the PostgreSQL URL as resolved
    # throughout, which is what made it hard to see.
    #
    # required=False: a deployment that exports IOF_DATABASE_URL itself (the
    # pod, where entrypoint.sh injects it) must keep starting. The web app's own
    # lifespan already fails fast when no workspace can be resolved, so this
    # adds the env load without taking over that decision.
    #
    # --workspace lands in the ENVIRONMENT, not a local variable, and before
    # anything resolves: serve spawns run subprocesses that resolve their own
    # workspace from IOF_WORKSPACE, so a flag the server honoured but the
    # children could not see would split the deployment in two. Every other
    # workspace-scoped command already takes --workspace; serve was the one
    # exception, and the cost was a `set` incantation per engine terminal.
    if workspace:
        prior = os.environ.get("IOF_WORKSPACE", "")
        if prior and prior != workspace:
            console.print(f"[yellow]--workspace {workspace} overrides "
                          f"IOF_WORKSPACE={prior}[/yellow]")
        os.environ["IOF_WORKSPACE"] = workspace
    _workspace_code(None, required=False)

    # THE STARTUP RULE — refuse to serve an EXPOSED port with no authentication.
    #
    # Placed after `_workspace_code()` because that is what loads
    # `~/.iobot/workspaces/<code>/.env`, and IOF_ENGINE_AUTH belongs in it like
    # every other per-deployment setting; checking before the load would read
    # an unconfigured environment and refuse a correctly-configured engine.
    #
    # Loopback is untouched — laptops, tests and client_simulation keep working
    # with zero configuration. A non-loopback bind (which INCLUDES this
    # command's own 0.0.0.0 default, so containers are covered) must either
    # configure a mechanism or carry an explicit IOF_ENGINE_AUTH=off. The
    # message names every way to satisfy it.
    #
    # This is a deliberate hard failure on upgrade for any deployment that was
    # serving 0.0.0.0 unauthenticated: that is the exact population this
    # exists to reach, the fix is one line, and a start that fails loudly at
    # boot is strictly better than one that silently keeps the port open.
    from ioagentfarm.web.auth import EngineAuthError, assert_safe_to_serve
    try:
        assert_safe_to_serve(host)
        # Tell the application what we bound, so the lifespan can re-check.
        # The command's own check stays: it fails BEFORE a port is taken and
        # before two model calls of agent warmup are paid for.
        try:
            from ioagentfarm.web.app import app as _engine_app
            _engine_app.state.bind_host = host
        except Exception:  # noqa: BLE001
            pass
    except EngineAuthError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2)

    root_path = Path(root).resolve() if root else _root()
    _store(root_path)  # ensure DB exists
    os.environ["IOF_ROOT"] = str(root_path)

    # Concurrency ceiling for BUS-dispatched agent turns. Raised from
    # iobot's default of 3, which was tuned for a runtime that no longer
    # exists: 0.3.0 removed AgentLoop's global `_processing_lock` in favour of
    # per-session locks, so turns that used to serialize anyway now genuinely
    # overlap.
    #
    # IMPORTANT — this does NOT bound the always-on agent pool. The semaphore
    # is acquired in `AgentLoop._dispatch` (the bus path) only; `process_direct`
    # takes the per-session lock and no gate. Every always-on surface we run —
    # the Studio chat proxy, A2A, Teams — calls `process_direct`, so it is
    # UNBOUNDED by this setting. Measured, not assumed: 6 concurrent requests
    # across 6 sessions took 4.2s against a 12.4s serial estimate, and capping
    # this to 2 changed nothing (3.8s). Backpressure for that path, if we want
    # it, has to be ours — see the agent pool in web/app.py.
    #
    # Precedence: explicit --concurrency > inherited env > our default.
    if concurrency is not None:
        os.environ["IOBOT_MAX_CONCURRENT_REQUESTS"] = str(concurrency)
    elif not os.environ.get("IOBOT_MAX_CONCURRENT_REQUESTS"):
        os.environ["IOBOT_MAX_CONCURRENT_REQUESTS"] = "10"

    # Seed agent workspaces so the agent pool has identity + tools.
    # PER-ROLE fail-open: one broken agent directory (an adopted tree can
    # carry shells with no SOUL.md, no DB row and no pack template) must not
    # kill the server — found live when a stray 'aria' dir took serve down
    # at startup. The broken role is named loudly and skipped; every healthy
    # agent still seeds.
    from ioagentfarm.engine.workspaces import ensure_iobot_agent, list_bundled_agents
    for role in list_bundled_agents():
        try:
            ensure_iobot_agent(role)
        except Exception as exc:
            console.print(
                f"[yellow]! skipping agent '{role}': {exc}[/yellow]\n"
                f"[dim]  remove the broken directory or import the agent "
                f"(`{prog()} workspace show <code>`), then restart[/dim]")

    console.print("[cyan]Starting the engine web server[/cyan]")
    console.print(f"  http://{host}:{port}")
    console.print(f"  state: {root_path}")
    # WHAT IS ACTUALLY PRE-WARMED, not a guess. This line was the fixed string
    # "project_lead always-on, others on demand" — so an operator who had just
    # set IOF_ALWAYS_ON_AGENTS read a startup banner contradicting the step
    # they had performed one command earlier, and naming a role the variable
    # does not default to. A status line that ignores the configuration it
    # reports on is worse than no status line.
    from ioagentfarm.engine.always_on import describe_pool
    console.print("  agent pool: " + describe_pool())
    # The auth posture is stated on EVERY start, in the operator's own
    # terminal. A control nobody can see is a control nobody notices the loss
    # of: this is the line that makes "we turned it off for the demo and
    # forgot" a thing you read rather than a thing you discover.
    _auth_cfg = _engine_auth_summary()
    if _auth_cfg["enabled"]:
        console.print(f"  [green]auth: {'+'.join(_auth_cfg['mechanisms'])}"
                      f"[/green]{_auth_cfg['detail']}")
    else:
        console.print("  [red]auth: OFF[/red][dim] - anything that reaches "
                      "this port can create runs in any workspace "
                      "(see IOF_ENGINE_AUTH)[/dim]")
    console.print("[dim]Press Ctrl+C to stop[/dim]\n")

    # Drop uvicorn access-log lines for high-frequency polling endpoints so the
    # deploy logs stay readable (SSE status polls + chat message history).
    import logging as _logging

    class _SuppressPollingPaths(_logging.Filter):
        _SUPPRESSED = (
            "/api/chat/aria/messages",
            "/api/chat/queryngine/messages",
            "/api/run/",  # SSE status polls
            "/health",
        )

        def filter(self, record: "_logging.LogRecord") -> bool:
            msg = record.getMessage()
            return not any(p in msg for p in self._SUPPRESSED)

    _logging.getLogger("uvicorn.access").addFilter(_SuppressPollingPaths())
    uvicorn.run("ioagentfarm.web.app:app", host=host, port=port, log_level="info")


@app.command("supervise")
def supervise(
    once: bool = typer.Option(False, "--once", help="Run a single sweep and exit (for cron)"),
    interval: int = typer.Option(None, "--interval", help="Seconds between sweeps (default: IOF_SUPERVISOR_INTERVAL_S or 60)"),
    run_id: str = typer.Option(None, "--run-id", help="Scope to a single run (default: all running runs)"),
    no_resume: bool = typer.Option(False, "--no-resume", help="Only reap stale steps; never resurrect drivers"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
):
    """Run the run supervisor - self-healing for stuck runs.

    Sweeps all status='running' runs: reaps 'running' steps whose executor
    heartbeat went stale (same transition as `step-retry --crash-recovery`),
    and resurrects a dead driver when runnable steps are waiting (bounded by
    IOF_SUPERVISOR_MAX_RESUMES; beyond it the run fails with reason
    supervisor_gave_up). `ioagentfarm serve` runs this automatically as a
    lifespan task - this command is for CLI-only / cron deployments.

    Examples:
      ioagentfarm supervise --once            # one sweep (cron-friendly)
      ioagentfarm supervise --interval 30     # loop forever, sweep every 30s
    """
    import time as _time
    from datetime import datetime, timezone
    from ioagentfarm.engine.supervisor import (SupervisorRunNotFound,
                                              supervise_once)

    root_path = Path(root).resolve() if root else _root()
    # RESOLVE THE WORKSPACE BEFORE BUILDING THE STORE. `_store` reads
    # IOF_DATABASE_URL from the environment and falls back to a local SQLite
    # file when it is unset — and that variable lives in the workspace's own
    # .env, which only `_workspace_code` loads. Without this line the
    # supervisor opened an EMPTY local database, found zero active runs, and
    # printed `{"actions": []}` — byte-identical to a healthy sweep. So the
    # self-healing sweep was a silent no-op on precisely the deployments its
    # own help text names ("CLI-only / cron"), which are the ones with runs in
    # Postgres and no `serve` lifespan to do it instead. Found by a machine
    # restart leaving a run stuck: this command reported nothing to do while
    # the orphaned step's heartbeat was 88 minutes past a 180-second threshold.
    _workspace_code(required=True)
    store = _store(root_path)
    interval_s = interval if interval is not None else int(
        os.environ.get("IOF_SUPERVISOR_INTERVAL_S", "60"))

    def _sweep() -> list:
        actions = supervise_once(
            store, root_path, run_id=run_id, resume_drivers=not no_resume)
        # flush=True: redirected to a file and killed by a `timeout`, the
        # loop's per-sweep lines sat in the buffer and the operator saw a
        # banner and nothing else (novice finding, round 7)
        print(json.dumps({
            "ts": datetime.now(timezone.utc).isoformat(),
            "actions": actions,
        }), flush=True)
        return actions

    if once:
        try:
            _sweep()
        except SupervisorRunNotFound as exc:
            # Never print an empty action list for a run we cannot see —
            # that is the reading which hid this bug for weeks.
            console.print(f"[red]{exc}[/red]")
            raise typer.Exit(2)
        return
    console.print(
        f"[cyan]Run supervisor[/cyan] - sweeping every {interval_s}s "
        f"(Ctrl+C to stop)")
    try:
        while True:
            try:
                _sweep()
            except SupervisorRunNotFound as exc:
                # Configuration fault, not a transient: looping on it would
                # print the same error every interval forever.
                console.print(f"[red]{exc}[/red]")
                raise typer.Exit(2)
            except Exception as exc:
                console.print(f"[red]supervisor sweep error: {exc}[/red]")
            _time.sleep(interval_s)
    except KeyboardInterrupt:
        console.print("\n[yellow]Supervisor stopped.[/yellow]")


@app.command("start-gateway")
def start_gateway(
    project_dir: str = typer.Option(None, help="Project directory for agent working context"),
    channel: str = typer.Option(
        "email",
        help="INFORMATIONAL ONLY - does not select the channel; the iobot "
             "config does (email, msteams, cli)",
    ),
    root: str = typer.Option(None, help="State root directory; default .iof"),
):
    """Launch Alex (project_lead) in iobot gateway mode.

    Gateway mode is the primary async execution path.  Alex runs as a long-lived
    iobot gateway agent with:
    - Heartbeat ticks for workflow advancement
    - Channel support (email, MS Teams, CLI) for receiving user requests
    - Native spawn for delegating to sub-agents
    - Full MCP tool access

    ``--channel`` IS INFORMATIONAL. It is printed, and it guards the removed
    ``web`` value, but it is never passed to the ``iobot gateway`` subprocess
    (that command gets only ``--workspace`` and ``--config``). The channels that
    actually start come from ``channels`` in the iobot config. The signature
    implies otherwise, which is worth an afternoon of someone's time if left
    unsaid.

    Available backends are whatever iobot vendors - currently **email** and
    **msteams** only. Telegram and 14 other backends were removed with the fork;
    see iobot/PROVENANCE.md.

    This is the 'thin orchestration on rich runtime' mode - Alex uses iobot's
    native features and calls ioagentfarm CLI commands for state management.

    The ``web`` channel was REMOVED. Use ``ioagentfarm serve`` for an HTTP
    surface - it has run-scoped SSE, workspace tenancy, auth and A2A, none of
    which a chat channel can express."""
    from ioagentfarm.engine.workspaces import iobot_agent_workspace

    if channel == "web":
        # Removed 2026-07 alongside the iobot 0.3.0 upgrade. The in-tree
        # WebChannel was a BaseChannel adapter routing every request through
        # AgentLoop, already deprecated in favour of `serve`. Deleted rather
        # than ported because BOTH of its justifications are gone: the
        # global-lock problem it was blamed for no longer exists upstream
        # (0.3.0 locks per session), and everything a caller actually wants
        # from a web surface — run-scoped SSE, tenancy, auth, A2A — lives in
        # `serve`, which a chat channel has no structure to express.
        console.print(
            "[red]The 'web' channel was removed.[/red] Use [cyan]ioagentfarm serve[/cyan] "
            "- run-scoped SSE, workspace tenancy, auth and the A2A surface."
        )
        raise typer.Exit(code=2)

    if not runtime_bin_available():
        console.print("[red]iobot CLI not found. Install with: pip install -e ./iobot[/red]")
        raise typer.Exit(code=2)

    root_path = Path(root).resolve() if root else _root()
    _store(root_path)  # ensure DB exists

    # Seed all agent workspaces
    from ioagentfarm.engine.workspaces import list_bundled_agents
    for role in list_bundled_agents():
        ensure_iobot_agent(role)

    # Alex's workspace
    alex_ws = iobot_agent_workspace("project_lead")

    # Create per-gateway instance config if project_dir provided
    gateway_config: Path | None = None
    if project_dir:
        from ioagentfarm.engine.iobot_config import create_instance_config
        gateway_config = create_instance_config(
            root_path, "gateway", str(Path(project_dir).resolve()),
        )

    console.print(f"[cyan]Starting Alex (project_lead) in gateway mode[/cyan]")
    console.print(f"  workspace: {alex_ws}")
    console.print(f"  channel: {channel}")
    if project_dir:
        console.print(f"  project_dir: {Path(project_dir).resolve()}")
    if gateway_config:
        console.print(f"  config: {gateway_config}")

    # Set env for sub-processes spawned by Alex
    os.environ["IOBOT_WORKSPACE"] = str(alex_ws)
    os.environ["IOF_ROOT"] = str(root_path)

    # Subprocess launch: delegate to iobot CLI for native channels
    env = os.environ.copy()
    cmd = [
        _iobot_bin(), "gateway",
        "--workspace", str(alex_ws),
    ]
    if gateway_config:
        cmd.extend(["--config", str(gateway_config)])

    console.print(f"\n[green]Launching iobot gateway...[/green]")
    console.print("[dim]Press Ctrl+C to stop[/dim]\n")

    try:
        proc = subprocess.run(cmd, env=env)
        raise typer.Exit(code=proc.returncode)
    except KeyboardInterrupt:
        console.print("\n[yellow]Gateway stopped.[/yellow]")


@app.command("setup-agents")
def setup_agents(
    project_dir: str = typer.Option(None, help="(deprecated, no-op) Previously used for MCP filesystem setup"),
    roles: str = typer.Option(
        None,
        help="Comma-separated agent roles to seed (default: all bundled agents)",
    ),
    force: bool = typer.Option(False, "--force", help="REFRESH: drop the materialized copy of pack content so the next run/chat re-reads it from the installed pack (memory and sessions are kept)"),
    skip_tools: bool = typer.Option(False, "--skip-tools", help="Skip the pack-declared tool validate/install pass"),
    check_tools_only: bool = typer.Option(False, "--check-tools-only", help="Validate pack tools but never install them (container/CI)"),
    workspace: str = typer.Option(None, "--workspace", help="Seed a TENANT's agent home (<IOF_ROOT>/workspaces/<code>/agents) instead of the shared ~/.iobot home"),
    no_home_env: bool = typer.Option(False, "--no-home-env", help="Do NOT publish the current directory's .env to the home directory (agent tool subprocesses then have no credentials)"),
    root: str = typer.Option(None, help="State directory root (default: IOF_ROOT or .iof)"),
):
    """Kept for compatibility - a no-op that says so. Exits 0, writes nothing.

    Content is read from the installed pack: a run or a chat resolves the
    agent it needs directly, and `serve` prepares the host at boot (declared
    CLI tools, always-on agent homes, the content registration). There is
    nothing left for a separate seeding step to do, so this command prints
    its context and one sentence and returns - a runbook or entrypoint that
    still calls it keeps working, and its operator still learns what
    happened (docs/one-truth-content-model.md section 4.5).

    Every option is accepted and ignored so existing invocations do not
    break - EXCEPT `--force`, which still does one thing: it drops the
    materialized copy of pack content so the next run or chat re-reads it from
    the installed pack. That is the remedy when an edit to an installed
    solution does not appear.

    Otherwise it does NOT seed agent homes, sync a catalog, publish a home
    .env, or run the tools resolver - `aicore cli-hub check` is the
    tools check when you want one by hand."""
    # Resolve the workspace exactly as before so the context line names the
    # tenant, its database and the installed content - the three facts the
    # operator was running this to establish. Refuses without a selection,
    # as every workspace-scoped command does.
    ws_code = _workspace_code(workspace, required=True)
    console.print(context_line(ws_code), soft_wrap=True)
    if force:
        dropped = _invalidate_materialized_content(ws_code, roles)
        if dropped:
            console.print(
                f"setup-agents --force: dropped {len(dropped)} materialized item(s); "
                "the next run or chat re-reads them from the installed pack.",
                soft_wrap=True)
            for line in dropped[:12]:
                console.print(f"  {line}", soft_wrap=True)
            if len(dropped) > 12:
                console.print(f"  ... and {len(dropped) - 12} more", soft_wrap=True)
        else:
            console.print("setup-agents --force: nothing materialized to drop.",
                          soft_wrap=True)
        return
    console.print(_SETUP_AGENTS_NOOP, soft_wrap=True)


#: EXACTLY the items a refresh may drop - an ALLOW-list, not a deny-list.
#:
#: The first cut listed what to KEEP and deleted the rest, which took out the
#: agent workspace's ``.git`` directory on its first run. That repo is what
#: the build REPL's ``/diff`` and ``/undo`` operate on, so a "refresh" would
#: have silently destroyed the session's undo history. A deny-list deletes
#: whatever nobody thought to name; for a destructive operation the safe
#: construction is the other way round, and anything new the runtime starts
#: writing here is then kept by default rather than removed by surprise.
#:
#: Not listed, deliberately: ``memory/`` (accumulated runtime state the
#: database does not hold), ``sessions/`` (the conversation record),
#: ``AGENTS.md`` (generated per host, not shipped), and
#: ``.skills-assigned.json`` (the assignment record - dropping it sends the
#: agent back through the legacy default-assignment rule and silently loses a
#: Studio removal).
_REFRESH_DROP = ("SOUL.md", "TOOLS.md", "skills")


def _invalidate_materialized_content(ws_code: str, roles: str | None) -> list[str]:
    """Delete the materialized COPY of pack content; keep everything else.

    Under the One Truth model the installed pack is the only content truth and
    an agent workspace on disk is a CACHE of it, filled on first use. But
    ``ensure_agent_workspace`` only ever fills a MISSING file - it never
    replaces one - so an SDK upgrade was invisible to any workspace that had
    already run once, and this command (a no-op since One Truth landed) still
    advertised ``--force`` as an overwrite. An operator ran the documented
    command, got exit 0, and believed content had refreshed.

    Invalidating the cache is the refresh that fits the model: nothing is
    written here, the pack stays the only source, and materialize-on-use
    repopulates from it on the next run or chat.
    """
    import shutil

    from ioagentfarm.engine.workspaces import agent_home_root

    wanted = {r.strip() for r in (roles or "").split(",") if r.strip()}
    root = agent_home_root()
    if not root.exists():
        return []

    dropped: list[str] = []
    for agent_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        if wanted and agent_dir.name not in wanted:
            continue
        ws = agent_dir / "workspace"
        if not ws.is_dir():
            continue
        for name in _REFRESH_DROP:
            item = ws / name
            if not item.exists():
                continue
            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
            except OSError as exc:                       # noqa: PERF203
                dropped.append(f"{agent_dir.name}/{item.name}  (FAILED: {exc})")
                continue
            dropped.append(f"{agent_dir.name}/{item.name}")
    return dropped


#: The one sentence `setup-agents` prints. ASCII only (a non-UTF-8 Windows
#: console raises on a glyph) and a module constant so the test that pins the
#: contract and the command cannot drift.
_SETUP_AGENTS_NOOP = (
    "setup-agents: nothing to do - content is read from the installed pack; "
    "runs and chats resolve it directly, and `serve` prepares the host at boot.")


#: Values that mean "on" for the local-mode env var.
_TRUTHY = ("1", "true", "yes", "on")


def local_mode(explicit: bool | None = None, root: Path | None = None,
               code: str | None = None) -> bool:
    """LOCAL MODE - the whole isolation, not a hint. Returns whether it is on.

    ON when: ``--local`` on this command, or ``IOF_LOCAL`` truthy (which is
    how ``aicore local on`` persists it, in the workspace's own .env), or
    hydration already switched off by hand. ``--no-local`` forces it off for
    one command.

    When on it localises everything a run touches - content, database, state
    root, agent home - so there is nothing to export. Turning off hydration
    alone left a "local" run writing into a shared database and somebody
    else's agent tree, which is local content with remote consequences.
    """
    if explicit is False:
        # RECORDED AS "0", NOT DELETED. Adoption is lazy now (see
        # `workspace_env.adopt_if_declared`), so a deleted variable is not a
        # refusal — it is silence, and `declared_local()` would fall through
        # to the DIRECTORY MARKER and re-enable the mode this flag just turned
        # off. An explicit no has to be representable to survive.
        os.environ["IOF_LOCAL"] = "0"
        return False
    # THE DIRECTORY MARKER COUNTS TOO. `aicore local on` records the switch
    # against this directory when no workspace has been selected yet -- which
    # is the normal case, because local mode is what makes the workspace you
    # create next a local one. Reading only the workspace's `.env` here would
    # mean the very first command could not take effect.
    on = (bool(explicit)
          or os.getenv("IOF_LOCAL", "").strip().lower() in _TRUTHY
          or os.getenv("IOF_HYDRATION", "1").strip().lower() in ("0", "false", "off")
          or _ws_env.directory_local())
    if on:
        os.environ["IOF_LOCAL"] = "1"
        _ws_env.localise(root, code or None)
    return on


def prog() -> str:
    """The command name this CLI was invoked as.

    ONE implementation, in `cli_scaffold`, because the scaffold's "Next"
    hints and this module's guidance must agree on what to call the binary.
    Two copies drifted apart the first time one was edited.
    """
    from ioagentfarm.cli_scaffold import _prog
    return _prog()


def mode_banner(on: bool) -> str:
    """The banner text, as rich markup. ASCII ONLY - see below.

    NO GLYPHS. A dot or a check renders fine here and raises
    UnicodeEncodeError on a non-UTF-8 Windows console - the same failure that
    made the runtime's cat emoji become ``(io)``. Colour survives everywhere
    (rich enables VT processing on Windows and strips styling when the output
    is not a terminal), so the badge carries the signal and the characters
    stay in the 7-bit range. Pinned by
    ``tests/test_console_output_is_ascii.py`` - which did not exist when this
    docstring first claimed it did.
    """
    if on:
        # RELATIVE when it is under the working directory: an absolute
        # Windows temp path wraps over three lines and the signal — that this
        # is local — gets lost in its own evidence.
        root = Path(os.getenv("IOF_ROOT", ".iof"))
        try:
            shown = root.relative_to(Path.cwd())
        except ValueError:
            shown = root
        # "NOTHING SHARED" IS A CLAIM, AND IT CAN BE FALSE. An exported
        # IOF_DATABASE_URL outranks the mode by design -- local files against
        # a shared database is a documented combination. The banner said
        # "nothing shared" anyway, so exporting a production URL produced a
        # safety badge asserting the opposite of the truth. When the real
        # environment supplies the database, the badge says so instead.
        if "IOF_DATABASE_URL" in _ws_env.REAL_ENV:
            return ("[bold black on yellow] LOCAL MODE [/]  content is read "
                    "from this directory [dim]- IOF_DATABASE_URL is set in "
                    "the environment, so the database is NOT local[/]")
        return ("[bold black on yellow] LOCAL MODE [/]  content is read from "
                f"this directory [dim]- SQLite database at {shown}[/]")
    return ("[bold white on blue] DATABASE [/]  content is read from the "
            f"configured database [dim]- `{prog()} local on` to work from "
            "this directory[/]")


def _short_db_target(root_path: Path | None = None) -> str:
    """The database, compact and credential-free, for the context line.

    A missing ``IOF_DATABASE_URL`` is named LOUDLY, not rendered as a plain
    default: a workspace without its own ``.env`` silently fell back to a local
    SQLite while its owner believed it was on Postgres (2026-08-15) - two
    databases holding the same catalog, disagreeing, and nothing on any
    command's output saying which one it was talking to. See
    docs/one-truth-content-model.md section 5.
    """
    # This RESOLVES the database in order to describe it, so it adopts like
    # every other resolver. A context line that names the shared database
    # while the mode says local is the contradiction this whole change is
    # about - and this is the line an operator is told to trust.
    _ws_env.adopt_if_declared()
    url = (os.getenv("IOF_DATABASE_URL") or "").strip()
    if not url:
        return ("[yellow]default sqlite - no IOF_DATABASE_URL set for this "
                "workspace[/yellow]")
    if url.startswith("sqlite"):
        from ioagentfarm.engine.db import describe_db_target
        return describe_db_target(root_path, url=url).replace(" (default sqlite)", "")
    try:
        from urllib.parse import urlparse
        u = urlparse(url)
        db = (u.path or "").lstrip("/")
        schema = (os.getenv("IOF_DB_SCHEMA") or "").strip()
        return f"{u.scheme.split('+')[0]}@{u.hostname}/{db}" + (f" ({schema})" if schema else "")
    except Exception:  # pragma: no cover - never let the banner die on a URL
        return "database (unparsed URL)"


def context_line(ws: str | None, root_path: Path | None = None) -> str:
    """workspace / database / installed content - the first line of every
    workspace-scoped command (docs/one-truth-content-model.md section 4.4).

    The three facts a person needs before reading anything else a command
    prints: which tenant this acts on, which database it reaches, and which
    pack version and commit is installed here. Fail-open on the content
    stamp - a git hiccup must not take the whole CLI down.
    """
    try:
        from ioagentfarm.engine.content import stamp_line
        content = stamp_line(packs_only=True) or "(no packs installed)"
    except Exception as exc:  # pragma: no cover
        content = f"(stamp unavailable: {type(exc).__name__})"
    return (f"[dim]workspace:[/dim] {ws or '[yellow]none selected[/yellow]'} "
            f"[dim]- db:[/dim] {_short_db_target(root_path)} "
            f"[dim]- content:[/dim] {content}")


#: Set once the mode has been stated on this process's output, so the seam
#: below does not repeat what a command already printed in long form.
_MODE_ANNOUNCED = False

#: A console that writes to STDERR. The seam announcement must not land in
#: stdout: `aicore status --json` and `aicore run --json` are parsed by
#: agents and by the Studio, and a banner in the payload breaks them. This is
#: the same split the existing `--json` paths already rely on.
_stderr_console = Console(stderr=True)


def announce_target_once(ws: str | None = None) -> None:
    """State the mode and the database, ONCE, on stderr - from the resolver.

    THE ASK THIS ANSWERS: "in a long chain of commands I may forget local mode
    is on while expecting the data to land in the shared database, or the
    reverse." Both directions cost something, which is why this is not
    conditional on being local: out of local mode your own unpublished edit is
    the thing that is invisible.

    `print_mode_banner` has said "ALWAYS, not only when local" in its docstring
    since it was written, and was wired into FOUR commands - `current`, `run`,
    `run-swarm` and `local` itself. Everything else opened a database in
    silence. That is the same shape as the leak this change fixes: an intent
    stated in one place and delivered by whoever remembered.

    So it fires from the SEAM instead - `_store()`, which every command that
    touches a database goes through. There is nothing to wire into a new
    command and nothing to forget.

    Quiet when: a command already printed the banner itself (no double line),
    when `IOF_NO_MODE_BANNER` is set (a tool exec'ing this thousands of times
    in a loop), or when it has already fired in this process.
    """
    global _MODE_ANNOUNCED
    if _MODE_ANNOUNCED or os.getenv("IOF_NO_MODE_BANNER", "").strip():
        return
    _MODE_ANNOUNCED = True
    try:
        on = _ws_env.declared_local() is True
        target = _short_db_target()
        # The MODE first, because that is the word the reader is scanning for,
        # then the database, because that is the fact they would check next.
        badge = ("[black on green] LOCAL [/black on green]" if on
                 else "[black on yellow] SHARED [/black on yellow]")
        where = "this directory" if on else "the configured database"
        _stderr_console.print(
            f"{badge} [dim]writing to[/dim] {where} [dim]-[/dim] {target}",
            soft_wrap=True)
    except Exception:  # noqa: BLE001
        # A banner that can break the command it decorates is worse than no
        # banner. Every value above is derived from the environment and could
        # in principle raise; none of it is worth an exit code.
        pass


def print_mode_banner(on: bool, ws: str | None = None,
                      show_context: bool = True,
                      to_stderr: bool = False) -> None:
    """Say which source of truth is in force. ALWAYS, not only when local.

    A mode you cannot see is a mode you forget you are in - and both
    directions cost something: in local mode a colleague's pushed change is
    invisible to you; out of it, your own unpublished edit is.

    Sets the once-per-process flag so `announce_target_once` - which fires
    from the resolver for every OTHER command - does not print a second,
    shorter version of what this just said at length.

    Followed by the context line (workspace / db / installed content) unless
    the caller prints those facts itself (`current` does, in long form).
    """
    global _MODE_ANNOUNCED
    _MODE_ANNOUNCED = True
    # `to_stderr` is what makes `--json` parseable. `run --json` and
    # `run-swarm --json` are the documented spawn path "for agents/Teams", and
    # they printed this banner and the context line to STDOUT, ahead of the
    # JSON - so the payload every one of those callers parses began with two
    # lines of prose. Nothing caught it because the human path looks right and
    # the machine path is read by a machine that simply failed.
    out = _stderr_console if to_stderr else console
    out.print(mode_banner(on))
    if show_context:
        out.print(context_line(ws), soft_wrap=True)


@app.command("local")
def local_cmd(
    state: str = typer.Argument(
        None, help="on | off | (omit to show the current state)"),
    workspace: str = typer.Option(
        None, "--workspace",
        help="Tenant workspace code (default: the selected workspace; refused when none is selected)"),
):
    """Turn LOCAL MODE on or off for a workspace, durably.

    A MODE, NOT A FLAG YOU REPEAT. Once on, every command runs from your
    files against a local SQLite under your own state directory - no
    environment variables, nothing to remember, and nothing that can reach a
    shared database or another workspace's agent tree.

    Persisted as ``IOF_LOCAL`` in the workspace's own ``.env``, which is
    already loaded on every command and already reported by ``aicore
    current`` - one concept instead of two, and a line you can read.

    A single command can still override it: ``--local`` / ``--no-local``.
    """
    ws = _workspace_code(workspace, required=False)
    if state is None:
        print_mode_banner(local_mode())
        console.print(f"[dim]workspace:[/dim] {ws or '(none selected)'}")
        # NOT `--workspace`. Local mode applies to the directory now, and
        # `local on` printed exactly that two lines earlier -- so this hint
        # contradicted the command's own output and taught a form the
        # documented flow no longer uses.
        console.print(f"[dim]set with :[/dim] {prog()} local on")
        return
    want = state.strip().lower()
    if want not in ("on", "off"):
        raise typer.BadParameter("say `on` or `off` (or omit to show state)")
    # LOCAL MODE COMES BEFORE A WORKSPACE EXISTS. It is what guarantees the
    # workspace you create next is created locally rather than in a shared
    # database, so requiring one here would have meant naming a workspace
    # that does not exist yet -- and every later command repeating the flag.
    # The switch is recorded against THIS DIRECTORY; `workspace create` and
    # `workspace use` copy it into that workspace's own settings, which is
    # where `aicore current` reports it from and where a pod reads it.
    #
    # ...BUT `--workspace` NAMES ONE WORKSPACE, AND MEANT ALL OF THEM. The
    # directory marker was written unconditionally, and `declared_local()`
    # falls back to it for any workspace whose own `.env` is silent - so
    # `aicore local on --workspace scratch` also sent every OTHER workspace
    # used from this directory to a local SQLite. Measured: with the marker
    # present, `aicore current --workspace <tenant>` reported the local file
    # for a workspace whose `.env` names a production PostgreSQL; removing
    # the marker restored it. Writes never left the local file, so what broke
    # was the instrument a person reads before deciding anything.
    #
    # An EXPLICIT `--workspace` therefore records the switch on that
    # workspace only. With no flag the directory marker is still written,
    # which is the case the design exists for.
    explicit = bool((workspace or "").strip())
    named = explicit or _workspace_is_selected()
    path = None
    if not explicit:
        path = _ws_env.set_directory_local(want == "on")
    if named:                     # explicit implies named, so `path` is set
        path = _ws_env.set_persistent_local(ws, want == "on")
    if want == "on":
        selected = _select_workspace(ws) if named else False
        moved = _ws_env.localise(code=ws)
        console.print(mode_banner(True))
        if selected:
            console.print(f"[dim]active workspace: {ws} - later commands use "
                          "it with no flag (`aicore workspace use <other>` to "
                          "switch)[/dim]")
        elif not named:
            console.print("[dim]no workspace selected yet - the one you create "
                          "next is created locally, and inherits this[/dim]")
        # WHAT IS PERSISTED IS THE SWITCH, NOT THESE VALUES. The file records
        # `IOF_LOCAL=1`; the four settings below are DERIVED from the working
        # directory on every command, so they follow you if you run from
        # somewhere else. Printing them above a bare "persisted in <file>"
        # read as though the paths themselves had been written down, which
        # invites the reader to trust a path that will not be the same one
        # next time.
        for key, value in sorted(moved.items()):
            console.print(f"  [dim]{key:<18}[/dim] {value}", soft_wrap=True)
        console.print(f"[dim]{path} records IOF_LOCAL=1 - the switch. The "
                      "settings above are derived from the current directory "
                      "each time a command runs.[/dim]", soft_wrap=True)
        console.print("[dim]every command in this workspace is local now - "
                      "`aicore local off` to stop[/]")
    else:
        for key in _ws_env._LOCALISED:
            if key not in _ws_env.REAL_ENV:
                os.environ.pop(key, None)
        # AND SAY SO EXPLICITLY, for the rest of this process. Clearing the
        # derived values is not enough now that adoption is lazy: the next
        # `_store()` would consult `declared_local()`, find the variable
        # merely absent, fall through to the directory marker — which this
        # command has just removed, but only on disk — and in the same
        # process re-localise what was being switched off.
        os.environ["IOF_LOCAL"] = "0"
        console.print(mode_banner(False))
        console.print(f"[dim]removed from {path}[/dim]", soft_wrap=True)


@app.command("sync")
def sync_catalog(
    agents: bool = typer.Option(True, "--agents/--no-agents",
                                help="sync agent rows (display + pack provenance)"),
    skills: bool = typer.Option(True, "--skills/--no-skills",
                                help="sync the pack skill catalog (pack_skills)"),
    workflows: bool = typer.Option(True, "--workflows/--no-workflows",
                                   help="sync workflow rows (run registry + "
                                        "the Studio catalog, per workspace)"),
    prune_agents: bool = typer.Option(
        False, "--prune-agents",
        help="also DELETE agents rows whose role is gone from every installed "
             "pack (only rows attributed to a pack this environment has - "
             "blank/unknown provenance is never pruned)"),
):
    """Kept for compatibility - a no-op that says so. Exits 0, writes nothing.

    There is no content catalog to sync any more: content is read from the
    installed pack, by the run or chat that needs it, and `serve` registers
    what a host is running at boot. This command used to rewrite the
    `agents`, `pack_skills`, `workflows` and `studio_workflow_defs` tables
    from the installed packs; nothing resolves from those tables now
    (docs/one-truth-content-model.md section 4.5), so it prints its context
    and one sentence and returns. Every option is accepted and ignored so a
    runbook or entrypoint that still calls it keeps working.
    """
    # The workspace is resolved only for the context line - a selection is
    # not required to say "nothing to do", and refusing here would turn a
    # compatibility no-op into a new failure for an entrypoint that never
    # passed one.
    ws_code = _workspace_code(None, required=False)
    console.print(context_line(ws_code or None), soft_wrap=True)
    console.print(_SYNC_NOOP, soft_wrap=True)


#: The one sentence `sync` prints. ASCII only; a constant so the pinning test
#: and the command cannot drift.
_SYNC_NOOP = (
    "sync: nothing to do - there is no content catalog to sync; content is "
    "read from the installed pack.")


def _parse_kv_pairs(pairs: list[str], flag: str) -> dict:
    """``K=V`` (or ``K: V``) strings -> dict, refusing malformed entries."""
    out: dict = {}
    for raw in pairs or []:
        sep = "=" if "=" in raw else (":" if ":" in raw else None)
        if sep is None:
            raise typer.BadParameter(
                f"{flag} expects K=V (got {raw!r})")
        key, _, value = raw.partition(sep)
        if not key.strip():
            raise typer.BadParameter(
                f"{flag} expects K=V (got {raw!r})")
        out[key.strip()] = value.strip()
    return out


@app.command("mcp-list")
def mcp_list(
    workspace: str = typer.Option("", "--workspace", help="Workspace code for the workspace tier (default: the selected workspace)"),
    probe: bool = typer.Option(False, "--probe", help="Also CONTACT each remote server and report what it answered (a credential the server rejects is invisible without this)"),
    tools: bool = typer.Option(False, "--tools", help="Also ASK each server which tools it offers (initialize, notifications/initialized, tools/list) and list them under its row - the names an agent sees as mcp_<server>_<tool>"),
    timeout: float = typer.Option(6.0, "--probe-timeout", help="Seconds to wait for each probed or tool-listed server"),
):
    """The effective MCP server view a run would get: pack -> global -> workspace.

    WITHOUT --probe this reads files only: what is declared, which tier won,
    and which ``${VAR}`` is unset. It cannot tell you whether the far end
    ACCEPTS the credential - and a server that rejects every request printed
    exactly like a working one, which is how a rejected token reached
    production looking healthy. `--probe` makes one real request per remote
    server and reports the status it got back.
    """
    from ioagentfarm.engine.iobot_config import effective_mcp_servers
    from ioagentfarm.engine.workspaces import (WorkspaceNotSelected,
                                               WorkspaceRetired)
    tools = tools is True      # direct calls pass none; OptionInfo is truthy
    # REPORT WHAT CAN BE REPORTED. Two of the three tiers do not depend on a
    # workspace, so refusing the whole answer until one is selected turned a
    # diagnostic into a traceback while the pack and global tiers sat right
    # there. The run path keeps the fail-closed default; only this listing
    # degrades, and it says which tier is missing so the view is never
    # mistaken for the complete one.
    partial = False
    try:
        # The workspace .env is what `mcp-add` told the user to fill in;
        # read it before deciding a ${VAR} is unset (walked 2026-09-02).
        _load_workspace_env_for(workspace)
        servers = effective_mcp_servers(workspace or None)
    except (WorkspaceNotSelected, WorkspaceRetired):
        partial = True
        servers = effective_mcp_servers(include_workspace_tier=False)
        console.print("[yellow]no workspace selected[/yellow] - showing the "
                      "pack and machine tiers only; a workspace may add or "
                      "override entries.", soft_wrap=True)
        console.print(f"  [dim]select one:[/dim]  {prog()} workspace use "
                      "<code>", soft_wrap=True)
    if not servers and partial:
        console.print("[dim]No MCP servers declared by any installed pack or "
                      "by this machine.[/dim]")
        return
    if not servers:
        console.print("[dim]No MCP servers declared at any tier.[/dim]")
        console.print("Use: aicore mcp-add <name> --command ... | --url ...")
        return
    for name in sorted(servers):
        info = servers[name]
        spec = info["spec"]
        target = spec.get("command") or spec.get("url") or "?"
        if spec.get("args"):
            target += " " + " ".join(str(a) for a in spec["args"])
        transport = spec.get("type") or ("stdio" if spec.get("command") else "streamableHttp/sse")
        line = (f"  [cyan]{name}[/cyan] [dim]({transport}, {info['tier']})[/dim]: "
                f"{target}")
        if info["status"] == "disabled":
            line += "  [yellow]disabled[/yellow]"
        elif info["status"] == "dropped":
            line += (f"  [red]dropped - unset env: "
                     f"{', '.join(info['missing'])}[/red]")
        console.print(line)
        if info["status"] == "disabled" or not (probe or tools):
            continue
        from ioagentfarm.engine.mcp_probe import OK, SKIPPED, advice
        from ioagentfarm.engine.mcp_probe import probe as probe_one
        # THE AUTH BLOCK IS STRIPPED FROM `spec` (it is ours, not iobot's),
        # so it has to be handed over explicitly or the probe authenticates
        # anonymously and reports `unauthorized` about a server the agent
        # connects to perfectly well.
        probed = dict(spec)
        if info.get("auth"):
            probed["auth"] = info["auth"]      # see mcp_probe.probe_entries
        if probe:
            result = probe_one(probed, timeout=timeout)
            colour = {OK: "green", SKIPPED: "dim"}.get(result["status"], "red")
            console.print(f"      [{colour}]{result['status']}[/] "
                          f"[dim]{result['detail']}[/]", soft_wrap=True)
            hint = advice(result)
            if hint:
                console.print(f"      [dim]-> {hint}[/]", soft_wrap=True)
        if tools:
            # PRESENTATION ONLY - the protocol lives in `mcp_probe.list_tools`.
            from rich.markup import escape as _esc
            from ioagentfarm.engine.discovery import ascii_only
            from ioagentfarm.engine.mcp_probe import list_tools
            listed = list_tools(probed, timeout=timeout)
            if listed["status"] != OK or listed["tools"] is None:
                console.print("      tools: [red](unavailable: "
                              f"{_esc(ascii_only(listed['detail']))})[/red]",
                              soft_wrap=True)
                hint = advice(listed)
                if hint:
                    console.print(f"      [dim]-> {hint}[/]", soft_wrap=True)
                continue
            if not listed["tools"]:
                console.print("      tools: [dim](none - the server answered "
                              "tools/list with an empty list)[/dim]")
                continue
            console.print(f"      tools ({len(listed['tools'])}, reached as "
                          f"mcp_{_esc(name)}_<tool>):")
            for t in listed["tools"]:
                desc = ascii_only(t.get("description")).strip()
                first = desc.splitlines()[0].strip() if desc else ""
                console.print(f"        [cyan]{_esc(t['name'])}[/cyan]"
                              + (f"  [dim]{_esc(first[:100])}[/dim]" if first else ""),
                              soft_wrap=True)


def _auth_block_or_refuse(auth_type, token_url, client_id, client_secret,
                          scope, audience):
    """`build_auth_block`, with its refusal as a CLI error not a traceback.

    A half-written `--auth-*` set is an ordinary user mistake; showing a
    Python traceback for it buries the one sentence that says which flag is
    missing.
    """
    from ioagentfarm.engine.iobot_config import build_auth_block
    try:
        return build_auth_block(
            auth_type=auth_type, token_url=token_url, client_id=client_id,
            client_secret=client_secret, scope=scope, audience=audience)
    except ValueError as exc:
        raise typer.BadParameter(str(exc))


@app.command("mcp-add")
def mcp_add(
    name: str = typer.Argument(..., help="MCP server name (e.g. github)"),
    command: str = typer.Option("", help="Stdio: command to run (e.g. npx)"),
    args: str = typer.Option("", help="Comma-separated args (e.g. '-y,@modelcontextprotocol/server-github')"),
    url: str = typer.Option("", help="Remote: sse/streamableHttp endpoint URL"),
    server_type: str = typer.Option("", "--type", help="stdio | sse | streamableHttp (auto-detected when omitted)"),
    header: list[str] = typer.Option([], "--header", help="HTTP header K=V for remote servers (repeatable; ${VAR} refs stay unexpanded)"),
    env: list[str] = typer.Option([], "--env", help="Env var K=V for stdio servers (repeatable; ${VAR} refs stay unexpanded)"),
    cwd: str = typer.Option("", help="Stdio: working directory"),
    tool_timeout: int = typer.Option(0, help="Per-tool-call timeout in seconds (0 = runtime default)"),
    enabled_tools: str = typer.Option("", help="Comma-separated tool allowlist (default: all tools + resources + prompts)"),
    workspace: str = typer.Option("", "--workspace", help="Write the WORKSPACE tier (~/.iobot/workspaces/<code>/mcp.yaml) instead of the global config"),
    auth_type: str = typer.Option("", "--auth-type", help="OAuth grant: oauth2_client_credentials. The runtime mints and RENEWS the token itself - use this instead of a static header when the server issues short-lived tokens"),
    auth_token_url: str = typer.Option("", "--auth-token-url", help="OAuth token endpoint"),
    auth_client_id: str = typer.Option("", "--auth-client-id", help="OAuth client id as ${VAR} (the value belongs in the workspace .env)"),
    auth_client_secret: str = typer.Option("", "--auth-client-secret", help="OAuth client secret as ${VAR} (never the value itself)"),
    auth_scope: str = typer.Option("", "--auth-scope", help="OAuth scope"),
    auth_audience: str = typer.Option("", "--auth-audience", help="OAuth audience, when the server wants one"),
):
    """Add or update an MCP server (global config, or a workspace's mcp.yaml)."""
    from ioagentfarm.engine.iobot_config import (build_auth_block,
                                                   configure_mcp_server)
    if bool(command) == bool(url):
        raise typer.BadParameter("exactly one of --command (stdio) or --url "
                                 "(sse/streamableHttp) is required")
    arg_list = [a.strip() for a in args.split(",") if a.strip()] if args else []
    tools_list = ([t.strip() for t in enabled_tools.split(",") if t.strip()]
                  if enabled_tools else None)
    modified = configure_mcp_server(
        name=name,
        command=command or None,
        args=arg_list or None,
        env=_parse_kv_pairs(env, "--env") or None,
        url=url or None,
        server_type=server_type or None,
        headers=_parse_kv_pairs(header, "--header") or None,
        cwd=cwd or None,
        tool_timeout=tool_timeout or None,
        enabled_tools=tools_list,
        auth=_auth_block_or_refuse(
            auth_type, auth_token_url, auth_client_id, auth_client_secret,
            auth_scope, auth_audience),
        workspace=workspace or None,
    )
    where = f"workspace {workspace}" if workspace else "global config"
    if modified:
        console.print(f"[green]Configured MCP server:[/green] {name} [dim]({where})[/dim]")
        # Same rule as `new-mcp-server`: name the variables, stub the file a
        # PERSON fills, never handle a value. See engine/env_template.py for
        # why the stub is commented rather than an empty assignment.
        from ioagentfarm.engine.env_template import refs_in, workspace_env_stub
        # THE AUTH BLOCK COUNTS TOO. Scanning only headers and env meant
        # `--auth-client-id '${VAR}'` produced no placeholder and no
        # `needs env:` line - the operator was told nothing about the two
        # variables the grant cannot work without, while `new-mcp-server`
        # (which scans the whole entry) told them. One command's silence is
        # worse than neither's, because it reads as "nothing to set".
        refs = sorted(refs_in({
            "headers": _parse_kv_pairs(header, "--header"),
            "env": _parse_kv_pairs(env, "--env"),
            "auth": _auth_block_or_refuse(
                auth_type, auth_token_url, auth_client_id, auth_client_secret,
                auth_scope, auth_audience) or {}}))
        if refs:
            console.print(f"[dim]needs env: {', '.join(refs)}[/dim]")
            code = workspace or _workspace_code("", required=False) or ""
            ws_path, added = workspace_env_stub(code, refs, f"MCP server '{name}'")
            if added:
                console.print(f"fill in: {ws_path}", markup=False)
                console.print(f"[dim]uncomment {added[0]}= and put the value "
                              "after the '='. Until then the server is "
                              "dropped from configs, loudly.[/dim]")
        if not workspace:
            console.print("[dim]Tip: --workspace <code> scopes a server to one "
                          "workspace; the workspace tier overrides this "
                          "entry by name.[/dim]")
    else:
        console.print(f"[dim]MCP server '{name}' unchanged ({where})[/dim]")


@app.command("mcp-remove")
def mcp_remove(
    name: str = typer.Argument(..., help="MCP server name to remove"),
    workspace: str = typer.Option("", "--workspace", help="Remove from the workspace tier instead of the global config"),
):
    """Remove an MCP server declaration from one tier."""
    from ioagentfarm.engine.iobot_config import remove_mcp_server
    where = f"workspace {workspace}" if workspace else "global config"
    if remove_mcp_server(name, workspace=workspace or None):
        console.print(f"[green]Removed MCP server:[/green] {name} [dim]({where})[/dim]")
    else:
        console.print(f"[yellow]MCP server '{name}' not found in {where}[/yellow]")
        console.print("[dim]A lower tier's server is suppressed by adding an "
                      "override entry with enabled: false, not by remove.[/dim]")


# ---------------------------------------------------------------------------
# External A2A agents (workspace registry; called via iof-consult)
# ---------------------------------------------------------------------------

@app.command("a2a-add")
def a2a_add(
    name: str = typer.Argument(..., help="External agent name (e.g. partner-insights)"),
    url: str = typer.Argument(..., help="A2A JSON-RPC endpoint URL (${VAR} refs allowed, expanded at dispatch time)"),
    description: str = typer.Option("", help="What the agent answers - the line routing decisions match against"),
    tag: list[str] = typer.Option([], "--tag", help="Routing tag (repeatable)"),
    example: list[str] = typer.Option([], "--example", help="Example question this agent answers (repeatable)"),
    header: list[str] = typer.Option([], "--header", help="HTTP header K=V (repeatable). Write secrets as ${VAR} - the value lives in the workspace .env, never in this registry"),
    workspace: str = typer.Option("", "--workspace", help="Workspace code (default: the selected workspace; with nothing selected the command refuses)"),
):
    """Register an EXTERNAL A2A agent for this workspace.

    Registered agents are materialized into agent workspaces as
    metadata/external_agents.yaml; any agent assigned the a2a_consult skill
    routes to them via iof-consult. Always-on agents pick the change up at
    the next warmup or run.
    """
    from ioagentfarm.engine.a2a_registry import (add_external_agent,
                                                 unresolved_header_vars)
    # RESOLVE THE WAY THE LISTING DOES. `a2a-list` reads the workspace
    # `.env`; this checked the process environment only, so it warned
    # `env var(s) not currently set` about a value already written into
    # that file - and its own advice ("put the value in the workspace
    # .env") did not silence it. A reader who follows the hint, re-runs,
    # and sees the same warning concludes the file is not read at all
    # (walked 2026-09-03).
    _load_workspace_env_for(workspace)
    path = add_external_agent(
        name=name, a2a_url=url, description=description,
        tags=tag, examples=example,
        headers=_parse_kv_pairs(header, "--header") or None,
        code=workspace or None,
    )
    console.print(f"[green]Registered external agent:[/green] {name}")
    console.print(f"  registry : {path}")
    entry = {"a2a_url": url,
             "headers": _parse_kv_pairs(header, "--header") or {}}
    unset = unresolved_header_vars(entry)
    if unset:
        console.print(f"  [yellow]! env var(s) not currently set: "
                      f"{', '.join(unset)}[/yellow]")
        console.print("[dim]  Put the value in the workspace .env "
                      "(~/.iobot/workspaces/<code>/.env) - iof-consult loads "
                      "it at dispatch time.[/dim]")
    if not description:
        console.print("[dim]  No --description: routing matches against "
                      "description/tags/examples, so an empty one makes this "
                      "agent nearly unroutable.[/dim]")


@app.command("a2a-list")
def a2a_list(
    workspace: str = typer.Option("", "--workspace", help="Workspace code (default: the selected workspace; with nothing selected the command refuses)"),
):
    """List this workspace's registered external A2A agents."""
    from ioagentfarm.engine.a2a_registry import (external_agents_path,
                                                 read_external_agents,
                                                 unresolved_header_vars)
    # READ THE FILE THIS COMMAND DIRECTS THE USER TO. `a2a-add` says "fill
    # in: ~/.iobot/workspaces/<code>/.env"; a-2a-list then reported the
    # variable UNSET after it was written there, because only the store
    # resolvers adopt the workspace env and this command opens no store
    # (walked 2026-09-02). Values are never printed - only resolvability.
    _load_workspace_env_for(workspace)
    agents = read_external_agents(workspace or None)
    if not agents:
        console.print("[dim]No external A2A agents registered.[/dim]")
        console.print("Use: aicore a2a-add <name> <url> --description ...")
        return
    console.print(f"[dim]{external_agents_path(workspace or None)}[/dim]")
    for entry in agents:
        line = f"  [cyan]{entry.get('name', '?')}[/cyan]: {entry.get('a2a_url', '?')}"
        if entry.get("tags"):
            line += f"  [dim][{', '.join(entry['tags'])}][/dim]"
        console.print(line)
        # Resolvability, never values: whether each ${VAR} would expand today.
        unset = unresolved_header_vars(entry)
        if unset:
            console.print(f"    [yellow]! unset env var(s): "
                          f"{', '.join(unset)}[/yellow]")


@app.command("a2a-remove")
def a2a_remove(
    name: str = typer.Argument(..., help="External agent name to remove"),
    workspace: str = typer.Option("", "--workspace", help="Workspace code (default: the selected workspace; with nothing selected the command refuses)"),
):
    """Remove a registered external A2A agent from this workspace."""
    from ioagentfarm.engine.a2a_registry import remove_external_agent
    if remove_external_agent(name, workspace or None):
        console.print(f"[green]Removed external agent:[/green] {name}")
        console.print("[dim]Materialized copies in agent workspaces refresh "
                      "at the next warmup or run.[/dim]")
    else:
        console.print(f"[yellow]External agent '{name}' not found[/yellow]")


# ---------------------------------------------------------------------------
# Agent metadata configuration (always-on agents)
# ---------------------------------------------------------------------------

@app.command("configure-agent")
def configure_agent(
    role: str = typer.Argument(..., help="Agent role (e.g. queryngine, analyst)"),
    metadata_dir: str = typer.Argument(..., help="Path to metadata directory (catalog.yaml, databases.yml, vectorfs.yaml, data/)"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing metadata"),
):
    """Configure an always-on agent with domain-specific metadata.

    Copies catalog/database/vectorfs configs and data files into the agent's
    workspace, links .env so dotenv-using tools find credentials, and embeds
    catalog.yaml + vectorfs.yaml content into the relevant SKILL.md files so
    the agent has them in its system prompt with no read_file round-trip.

    Examples:
      ioagentfarm configure-agent queryngine ioagentfarm/workflows/test_queryngine/metadata
      ioagentfarm configure-agent queryngine /data/my-client/metadata --force
    """
    import shutil
    from ioagentfarm.engine.workspaces import iobot_agent_workspace, get_agent_name

    src = Path(metadata_dir).resolve()
    if not src.is_dir():
        console.print(f"[red]Error:[/red] {metadata_dir} is not a directory")
        raise typer.Exit(1)

    catalog = src / "catalog.yml"
    if not catalog.exists():
        catalog = src / "catalog.yaml"
    if not catalog.exists():
        console.print(f"[yellow]Warning:[/yellow] No catalog.yml found in {metadata_dir}")

    ws = iobot_agent_workspace(role)
    dest = ws / "metadata"

    if dest.exists() and not force:
        console.print(f"[yellow]Metadata already exists at {dest}[/yellow]")
        console.print("Use --force to overwrite, or remove it manually.")
        raise typer.Exit(1)

    if dest.exists():
        shutil.rmtree(dest)

    shutil.copytree(src, dest)

    # Link .env into workspace so exec'd tools (vectorfs, iof-query) can
    # load credentials via dotenv from cwd. Prefer symlink (single source
    # of truth); fall back to copy on Windows without admin privileges.
    env_dest = ws / ".env"
    if env_dest.exists() or env_dest.is_symlink():
        env_dest.unlink()
    for env_candidate in [Path(".env").resolve(), (src.parent / ".env").resolve()]:
        if env_candidate.is_file():
            try:
                env_dest.symlink_to(env_candidate)
                console.print(f"  [cyan].env[/cyan] -> {env_candidate}")
            except OSError:
                shutil.copy2(env_candidate, env_dest)
                console.print(f"  [cyan].env[/cyan] copied from {env_candidate}")
            break

    # Embed catalog.yaml / vectorfs.yaml into the matching skills so they ride
    # in the system prompt. ONE implementation, shared with the identity
    # refresh (engine/agent_metadata.py): the refresh rewrites skills/*/SKILL.md
    # from the pack on every use, then re-derives this embed from metadata/,
    # so what configure-agent embeds today is exactly what survives tomorrow.
    from ioagentfarm.engine.agent_metadata import embed_metadata_into_skills
    for _skill in embed_metadata_into_skills(ws):
        console.print(f"  [cyan]metadata[/cyan] embedded in {_skill} skill")

    agent_name = get_agent_name(role)
    console.print(f"[green]Configured {agent_name} ({role}) metadata:[/green] {dest}")

    for f in sorted(dest.rglob("*")):
        if f.is_file():
            rel = f.relative_to(dest)
            console.print(f"  {rel}")

    # Validate the catalog against actual data sources (fix #1)
    if catalog.exists():
        console.print()
        console.print("[bold]Validating catalog against data sources...[/bold]")
        _validate_catalog(catalog, dest)


def _validate_catalog(catalog_path: Path, metadata_dir: Path) -> None:
    """Validate that databases and entities declared in catalog.yaml actually exist.

    Performs lightweight connectivity + schema checks:
      - For duckdb entities with source_path, verifies the CSV/parquet file exists
        and has the declared dimension columns.
      - For vectorfs databases, checks the Qdrant collection is reachable and
        reports point count.
      - For postgres/mysql databases, logs that full validation requires a live
        connection (does not fail).

    Warnings are printed but do not abort - the agent may still work for
    questions that don't touch the invalid entity.
    """
    import yaml as _yaml

    try:
        cat = _yaml.safe_load(catalog_path.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        console.print(f"  [red]catalog parse error:[/red] {exc}")
        return

    databases = cat.get("databases") or {}
    entities = cat.get("entities") or []

    # A MAPPING-SHAPED CATALOG IS A SHAPE ERROR, NOT A CRASH. `entities:`
    # written as a name -> spec map (the other obvious way to write it) made
    # the loop below do `"vendors".get("name")` and raise
    # `AttributeError: 'str' object has no attribute 'get'` - a raw traceback,
    # AFTER the copy had already landed, with nothing naming the file or the
    # expected shape. The chat certification's novice recovered only by
    # hunting a shipped sample. Accept the mapping (it is unambiguous) and
    # refuse anything else by name.
    if isinstance(entities, dict):
        entities = [{"name": k, **(v if isinstance(v, dict) else {})}
                    for k, v in entities.items()]
    elif not isinstance(entities, list):
        raise typer.BadParameter(
            f"catalog.yaml: `entities:` must be a list of entity mappings "
            f"(or a name -> spec mapping), not {type(entities).__name__}.")
    _bad = [e for e in entities if not isinstance(e, dict)]
    if _bad:
        raise typer.BadParameter(
            f"catalog.yaml: {len(_bad)} entry under `entities:` is not a "
            f"mapping (first: {_bad[0]!r}). Each entity is a mapping with at "
            "least `name:`; a bare list of names is not enough.")

    warnings = 0
    checks = 0

    # Check each duckdb entity's source_path exists and has declared columns
    for ent in entities:
        name = ent.get("name", "<unnamed>")
        db_name = ent.get("database")
        db = databases.get(db_name, {})
        db_type = db.get("type")

        if db_type == "duckdb":
            src = ent.get("source_path")
            if not src:
                continue
            checks += 1
            full = (metadata_dir.parent / src) if not Path(src).is_absolute() else Path(src)
            # `metadata_dir / src` FIRST: it is the layout the data-catalog
            # reference documents and the one iof-query's own resolver reads
            # (source_path is catalog-relative). It was missing here, so the
            # validator printed `source_path data/spend.csv not found` directly
            # under the line saying it had copied data\spend.csv - a false
            # alarm on the documented layout (walked 2026-09-02). The older
            # resolutions stay for catalogs written against them.
            for candidate in [metadata_dir / src, metadata_dir.parent / src,
                              metadata_dir / Path(src).name, Path(src)]:
                if candidate.exists():
                    full = candidate
                    break
            if not full.exists():
                console.print(f"  [yellow]![/yellow] entity [cyan]{name}[/cyan]: source_path {src} not found")
                warnings += 1
                continue

            # Check declared dimension columns exist in the file header
            dims = {d.get("name") for d in ent.get("dimensions") or [] if d.get("name")}
            if dims and full.suffix.lower() == ".csv":
                try:
                    import csv as _csv
                    with full.open("r", encoding="utf-8") as f:
                        header = next(_csv.reader(f), [])
                    missing = dims - set(header)
                    if missing:
                        console.print(f"  [yellow]![/yellow] entity [cyan]{name}[/cyan]: CSV missing columns {sorted(missing)}")
                        warnings += 1
                    else:
                        console.print(f"  [green]OK[/green] entity [cyan]{name}[/cyan]: {full.name} has all {len(dims)} declared dimensions")
                except Exception as exc:
                    console.print(f"  [yellow]![/yellow] entity [cyan]{name}[/cyan]: could not read CSV header: {exc}")
                    warnings += 1

        elif db_type == "vectorfs":
            # Checked once per database below
            pass
        elif db_type in ("postgres", "mysql"):
            console.print(f"  [dim]-[/dim] entity [cyan]{name}[/cyan]: {db_type} - full check requires live connection")

    # Check each vectorfs database — ping the collection
    for db_name, db in databases.items():
        if db.get("type") != "vectorfs":
            continue
        checks += 1
        backend = db.get("backend", "qdrant")
        collection = db.get("collection")
        if not collection:
            console.print(f"  [yellow]![/yellow] database [cyan]{db_name}[/cyan]: no collection name declared")
            warnings += 1
            continue
        if backend != "qdrant":
            console.print(f"  [dim]-[/dim] database [cyan]{db_name}[/cyan]: backend {backend} - validation not implemented")
            continue
        try:
            import os as _os
            from dotenv import load_dotenv as _load
            _load(metadata_dir.parent / ".env", override=False)
            _load(".env", override=False)
            url = _os.getenv("QDRANT_URL", "http://localhost:6333")
            api_key = _os.getenv("QDRANT_API_KEY")
            from qdrant_client import QdrantClient as _QC
            client = _QC(url=url, api_key=api_key, timeout=5)
            info = client.get_collection(collection)
            count = getattr(info, "points_count", None) or "?"
            console.print(f"  [green]OK[/green] database [cyan]{db_name}[/cyan]: qdrant collection '{collection}' reachable ({count} points)")
        except ImportError:
            console.print(f"  [dim]-[/dim] database [cyan]{db_name}[/cyan]: qdrant-client not installed - skipping")
        except Exception as exc:
            console.print(f"  [yellow]![/yellow] database [cyan]{db_name}[/cyan]: qdrant collection '{collection}' unreachable: {exc}")
            warnings += 1

    if warnings:
        console.print(f"\n[yellow]Validation complete: {warnings} warning(s) across {checks} check(s). Agent may still work for queries that don't touch the flagged entities.[/yellow]")
    elif checks:
        console.print(f"\n[green]Validation passed: {checks} check(s) OK.[/green]")
    else:
        console.print("\n[dim]No validatable sources in catalog (skipped).[/dim]")


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Sandbox management
# ---------------------------------------------------------------------------

@app.command("sandbox-list")
def sandbox_list():
    """List sandbox configuration for all workflows.

    Shows each workflow's sandbox policy, prewarm status, pool assignment,
    and current sandbox name (if IOF_RUNNER=sandbox and manager is active).

    Examples:
      ioagentfarm sandbox-list
    """
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    from ioagentfarm.engine.sandbox_manager import get_sandbox_manager

    loader = WorkflowLoader()
    mgr = get_sandbox_manager()
    runner_mode = os.environ.get("IOF_RUNNER", "local").lower()

    table = Table(title="Workflow Sandbox Configuration")
    table.add_column("Workflow", style="cyan")
    table.add_column("Policy", style="green")
    table.add_column("Prewarm", style="yellow")
    table.add_column("Idle (s)")
    table.add_column("Pool", style="blue")
    table.add_column("Sandbox", style="magenta")

    for name in loader.list_workflows():
        wf = loader.load(name)
        if wf.sandbox:
            sb_name = ""
            if mgr:
                sb_name = mgr.resolve_sandbox_name(name) or "(not created)"
            elif runner_mode != "sandbox":
                sb_name = "(IOF_RUNNER=local)"

            table.add_row(
                name,
                wf.sandbox.policy,
                "yes" if wf.sandbox.prewarm else "no",
                str(wf.sandbox.idle_timeout),
                wf.sandbox.pool or "-",
                sb_name,
            )
        else:
            table.add_row(name, "-", "-", "-", "-", "(no sandbox)")

    console.print(table)

    if runner_mode != "sandbox":
        console.print(
            "\n[dim]Sandbox mode is not active. Set IOF_RUNNER=sandbox to enable.[/dim]"
        )


@app.command("sandbox-status")
def sandbox_status():
    """Show active sandbox instances and their status.

    Only works when IOF_RUNNER=sandbox. Shows sandbox names, policies,
    workflows, and idle state.

    Examples:
      ioagentfarm sandbox-status
    """
    from ioagentfarm.engine.sandbox import get_sandbox_client
    from ioagentfarm.engine.sandbox_manager import get_sandbox_manager

    runner_mode = os.environ.get("IOF_RUNNER", "local").lower()
    if runner_mode != "sandbox":
        console.print("[yellow]Sandbox mode not active (IOF_RUNNER={}).[/yellow]".format(runner_mode))
        console.print("[dim]Set IOF_RUNNER=sandbox to enable sandbox execution.[/dim]")
        return

    client = get_sandbox_client()
    console.print(f"Sandbox client: [cyan]{type(client).__name__}[/cyan]")
    console.print(f"OpenShell available: [cyan]{client.is_available()}[/cyan]")

    mgr = get_sandbox_manager()
    if not mgr:
        console.print("[dim]SandboxManager not initialized (start the web server to activate).[/dim]")
        return

    sandboxes = mgr.list_sandboxes()
    if not sandboxes:
        console.print("[dim]No active sandboxes.[/dim]")
        return

    table = Table(title="Active Sandboxes")
    table.add_column("Name", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Workflow", style="yellow")
    table.add_column("Pool", style="blue")

    for sb in sandboxes:
        table.add_row(sb.name, sb.status, sb.workflow or "-", sb.pool or "-")

    console.print(table)


@app.command("policy-validate")
def policy_validate(
    policy_name: str = typer.Argument(None, help="Policy name to validate (e.g. 'developer'). Omit to validate all."),
):
    """Validate sandbox policy YAML files for correctness.

    Checks:
    - YAML syntax
    - Required sections (version, filesystem_policy, network_policies)
    - deny-all catch-all rule present
    - No dangerous endpoints allowed (metadata, gateway)
    - Policy name format

    Examples:
      ioagentfarm policy-validate                # validate all policies
      ioagentfarm policy-validate developer      # validate one policy
    """
    import yaml
    from ioagentfarm.engine.sandbox import validate_policy_name

    policies_dir = Path(__file__).parent / "engine" / "sandbox_policies"
    if not policies_dir.exists():
        console.print("[red]Policy directory not found:[/red] {}".format(policies_dir))
        raise typer.Exit(code=1)

    if policy_name:
        if not validate_policy_name(policy_name):
            console.print(f"[red]Invalid policy name:[/red] '{policy_name}'")
            raise typer.Exit(code=1)
        files = [policies_dir / f"{policy_name}.yaml"]
    else:
        files = sorted(policies_dir.glob("*.yaml"))

    errors_total = 0

    for path in files:
        name = path.stem
        errors = []

        if not path.exists():
            console.print(f"[red]Not found:[/red] {path}")
            errors_total += 1
            continue

        # Parse YAML
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
        except yaml.YAMLError as exc:
            console.print(f"[red]{name}:[/red] YAML parse error: {exc}")
            errors_total += 1
            continue

        if not isinstance(data, dict):
            errors.append("Root is not a mapping")
        else:
            # Required sections
            if "version" not in data:
                errors.append("Missing 'version' field")
            if "filesystem_policy" not in data:
                errors.append("Missing 'filesystem_policy' section")
            if "network_policies" not in data:
                errors.append("Missing 'network_policies' section")

            # Check for deny-all catch-all
            policies = data.get("network_policies", {})
            has_deny_all = False
            for pname, pdata in policies.items():
                if pname in ("deny_all", "catch_all"):
                    has_deny_all = True
            if not has_deny_all:
                errors.append("Missing deny-all catch-all rule (policy named 'deny_all')")

            # Check for gateway block
            has_gateway_block = any(
                p in policies for p in ("block_gateway", "gateway_block")
            )
            if not has_gateway_block:
                errors.append("Missing gateway block rule (policy named 'block_gateway')")

            # Check for metadata block
            has_metadata_block = any(
                p in policies for p in ("block_metadata", "metadata_block")
            )
            if not has_metadata_block:
                errors.append("Missing metadata block rule (policy named 'block_metadata')")

            # Check filesystem deny
            fs = data.get("filesystem_policy", {})
            if "deny" not in fs:
                errors.append("Missing filesystem deny list (should block /proc/1, docker.sock)")

        if errors:
            console.print(f"[red]{name}:[/red]")
            for e in errors:
                console.print(f"  - {e}")
            errors_total += len(errors)
        else:
            console.print(f"[green]{name}:[/green] OK")

    if errors_total:
        console.print(f"\n[red]{errors_total} error(s) found.[/red]")
        raise typer.Exit(code=1)
    else:
        console.print(f"\n[green]All policies valid.[/green]")


# ---------------------------------------------------------------------------
# Heartbeat observability (reads iobot-native heartbeat log)
# ---------------------------------------------------------------------------

@app.command("heartbeat-log")
def heartbeat_log(
    lines: int = typer.Option(20, "--lines", "-n", help="Number of recent entries to show"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Watch for new entries (tail -f style)"),
):
    """Show heartbeat tick log written by Alex in gateway mode.

    Alex appends to heartbeat.log in his iobot workspace on every
    heartbeat tick.  This command reads that native log file.

    Examples:
      ioagentfarm heartbeat-log              # last 20 entries
      ioagentfarm heartbeat-log --lines 50   # last 50 entries
      ioagentfarm heartbeat-log --json       # machine-readable
      ioagentfarm heartbeat-log --follow     # watch mode
    """
    from ioagentfarm.engine.workspaces import iobot_agent_workspace
    import time
    import re

    log_path = iobot_agent_workspace("project_lead") / "heartbeat.log"

    if not log_path.exists():
        console.print(f"[dim]No heartbeat log found at {log_path}[/dim]")
        console.print("[dim]The log is created when the orchestrator runs in "
                      f"gateway mode ({prog()} start-gateway).[/dim]")
        return

    def _read_entries(path: Path, n: int) -> list[str]:
        """Read last N non-empty lines from the log file."""
        text = path.read_text(encoding="utf-8")
        all_lines = [l for l in text.splitlines() if l.strip()]
        return all_lines[-n:] if n > 0 else all_lines

    def _parse_entry(line: str) -> dict:
        """Parse a heartbeat log line into structured data."""
        m = re.match(r"\[(.+?)\]\s+TICK\s+(\S+)\s*\|\s*(.*)", line)
        if m:
            return {"timestamp": m.group(1), "action": m.group(2), "details": m.group(3).strip()}
        return {"timestamp": "", "action": "unknown", "details": line.strip()}

    if follow:
        console.print(f"[cyan]Watching[/cyan] {log_path} (Ctrl+C to stop)\n")
        seen = 0
        try:
            while True:
                if log_path.exists():
                    all_lines = _read_entries(log_path, 0)
                    for entry_line in all_lines[seen:]:
                        console.print(entry_line)
                    seen = len(all_lines)
                time.sleep(5)
        except KeyboardInterrupt:
            console.print("\n[yellow]Stopped.[/yellow]")
        return

    entries = _read_entries(log_path, lines)

    if as_json:
        parsed = [_parse_entry(e) for e in entries]
        print(json.dumps({"entries": parsed, "count": len(parsed), "log_file": str(log_path)}, indent=2))
        return

    if not entries:
        console.print("[dim]Heartbeat log is empty.[/dim]")
        return

    console.print(f"[cyan]Heartbeat log[/cyan] ({log_path})\n")
    for entry in entries:
        console.print(entry)


# ---------------------------------------------------------------------------
# Task tracking (ad-hoc spawn tracking for concurrent requests)
# ---------------------------------------------------------------------------

@app.command("task-create")
def task_create(
    role: str = typer.Option(..., help="Target agent role (developer/analyst/reviewer)"),
    title: str = typer.Option(..., help="Short task title"),
    body: str = typer.Option(..., help="Full task description / prompt for the agent"),
    run_id: str = typer.Option(None, "--run-id", help="Link to a run (optional)"),
    auto_start: bool = typer.Option(False, "--auto-start", help="Create in 'running' state (skip pending->running step)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
):
    """Create a tracked ad-hoc task. Returns JSON with task_id for spawn correlation."""
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()
    task_id = store.create_task(role=role, title=title, body=body, run_id=run_id, user_id=uid)
    task_status = "pending"
    if auto_start:
        store.mark_task_spawned(task_id)
        task_status = "running"
    print(json.dumps({"task_id": task_id, "role": role, "title": title, "status": task_status}))


@app.command("task-update")
def task_update(
    task_id: str = typer.Option(..., help="Task ID to update"),
    status: str = typer.Option(..., help="New status: running|done|failed|notified"),
    output_file: str = typer.Option(None, help="Path to output file (for done/failed)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
):
    """Update task status. Use 'running' after spawn, 'done'/'failed' after completion, 'notified' after user reply."""
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)

    if status == "running":
        store.mark_task_spawned(task_id)
        print(json.dumps({"task_id": task_id, "status": "running"}))
    elif status in ("done", "failed"):
        output_text = ""
        parsed_status = status
        if output_file:
            p = Path(output_file).resolve()
            if p.exists():
                raw = p.read_text(encoding="utf-8")
                # Parse protocol to extract STATUS and OUTPUT
                kv, _, _ = parse_key_value_protocol(raw)
                parsed_status = (kv.get("STATUS") or status).strip().lower()
                if parsed_status not in ("done", "failed"):
                    parsed_status = "failed"
                output_text = raw
                # Persist agent memory from task workspace (paused under v2 —
                # same rule as the step path: v2 replaces MEMORY.md growth).
                task = store.get_task(task_id)
                if task:
                    from ioagentfarm.engine.learning.hooks import memory_paused
                    persist_agent_memory(task["role"], p.parent,
                                         learning_disabled=memory_paused())
        store.complete_task(task_id, status=parsed_status, output_text=output_text)
        output_preview = (kv.get("OUTPUT", output_text) if output_file else "")[:200] if output_text else ""
        print(json.dumps({"task_id": task_id, "status": parsed_status, "output_preview": output_preview}))
    elif status == "notified":
        store.mark_task_notified(task_id)
        print(json.dumps({"task_id": task_id, "status": "notified"}))
    else:
        print(json.dumps({"error": f"Invalid status: {status}. Use running|done|failed|notified"}))
        raise typer.Exit(code=1)


@app.command("task-list")
def task_list(
    status: str = typer.Option(None, help="Filter by status (pending|running|done|failed|notified)"),
    run_id: str = typer.Option(None, "--run-id", help="Filter by run ID"),
    limit: int = typer.Option(20, help="Max tasks to return"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    show_all: bool = typer.Option(False, "--all", help="Show all users' tasks (skip user filter)"),
):
    """List tracked ad-hoc tasks. JSON output for LLM agents."""
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = None if show_all else (user_id or _default_user_id())
    tasks = store.list_tasks(status=status, run_id=run_id, user_id=uid, limit=limit)
    result = []
    for t in tasks:
        entry = {
            "task_id": t["task_id"],
            "role": t["role"],
            "title": t["title"],
            "status": t["status"],
        }
        if t["status"] in ("done", "failed") and t.get("output_text"):
            entry["output_preview"] = (t["output_text"] or "")[:200]
        result.append(entry)
    print(json.dumps({"tasks": result, "count": len(result)}, indent=2))


@app.command("run-task")
def run_task(
    role: str = typer.Option(..., help="Agent role (developer/analyst/reviewer)"),
    goal: str = typer.Option(..., help="What the agent should do"),
    run_id: str = typer.Option(None, "--run-id", help="Link to a run (optional)"),
    background: bool = typer.Option(False, "--background", help="Run in background (fire-and-forget for gateway mode)"),
    task_id_override: str = typer.Option(None, "--task-id", help="Reuse existing task ID (used by --background child process)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
):
    """Run a single agent task directly via iobot. Tracked in the task store.

    In sync mode (default): blocks until the agent finishes.
    In background mode (--background): launches a detached process and returns immediately.

    Forensics: with --run-id, the agent's blobs (prompt, session snapshot,
    exit.json, http.log) land at instances/<run_id>/forensics/tasks/<task_id>.1
    and resolve via `forensics blob <run_id> task:<task_id>`. Without a run
    to anchor them, no blobs are captured (today's documented boundary).

    Examples:
      ioagentfarm run-task --role reviewer --goal "Validate login handles expired tokens"
      ioagentfarm run-task --role analyst --goal "Find all usages of deprecated API"
      ioagentfarm run-task --role developer --goal "Add input validation to signup form"
      ioagentfarm run-task --role analyst --goal "Investigate bug" --background  # gateway mode
    """
    if not runtime_bin_available():
        console.print("[red]iobot CLI not found. Install with: pip install -e ./iobot[/red]")
        raise typer.Exit(code=2)

    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    # Seed the agent's workspace
    ensure_iobot_agent(role)

    # Reuse parent's task_id (background child) or create a new one
    if task_id_override:
        task_id = task_id_override
    else:
        task_id = store.create_task(role=role, title=goal[:80], body=goal, run_id=run_id, user_id=uid)
        store.mark_task_spawned(task_id)

    # --- Background mode: create task in DB, spawn child, return immediately ---
    # Uses the same runner.spawn() mechanism as the web API's /task endpoint.
    # Child runs run-task WITHOUT --background (sync mode) with --task-id to
    # reuse the same task. All the heavy work (S3 pull, enrichment, agent
    # invocation) happens in the child — parent does nothing beyond this point.
    if background:
        from ioagentfarm.web.runner import get_runner

        venv_bin = str(Path(sys.executable).parent)
        suffix = ".exe" if sys.platform == "win32" else ""
        iof_bin = str(Path(venv_bin) / f"ioagentfarm{suffix}")

        cmd = [
            iof_bin, "run-task",
            "--role", role,
            "--goal", goal,
            "--user-id", uid,
            "--root", str(root_path),
            "--task-id", task_id,
        ]
        if run_id:
            cmd += ["--run-id", run_id]

        env = os.environ.copy()
        env["IOF_ROOT"] = str(root_path)
        env["PYTHONUNBUFFERED"] = "1"
        env["FORCE_COLOR"] = "0"
        env["TERM"] = "dumb"
        env["NO_COLOR"] = "1"

        task_log_dir = root_path / "instances" / (run_id or "no_run") / "task_logs" / task_id
        task_log_dir.mkdir(parents=True, exist_ok=True)

        runner = get_runner()
        runner.spawn(
            run_id=f"task:{task_id}",
            cmd=cmd,
            env=env,
            cwd=str(root_path),
            log_dir=task_log_dir,
        )

        print(json.dumps({
            "spawned": True,
            "task_id": task_id,
            "role": role,
        }, indent=2))
        return

    # --- Resolve instance config + run context ---
    instance_config: Path | None = None
    enriched_message = goal
    agent_project_dir: Path | None = None
    task_output_path: Path | None = None

    if run_id:
        from ioagentfarm.engine.iobot_config import (
            get_instance_config_path, get_run_output_dir, create_instance_config,
        )

        # Pod recovery: pull from S3 if instance dir missing
        instance_dir = root_path / "instances" / run_id
        try:
            from ioagentfarm.web.storage import get_storage
            cloud = get_storage()
            if not instance_dir.exists():
                logger.info("Instance dir missing for task run_id=%s — attempting S3 pull", run_id)
                cloud.pull(run_id, instance_dir, sub_prefix="instances")
        except Exception as exc:
            logger.error("S3 pull failed for task run_id=%s: %s", run_id, exc)

        instance_config = get_instance_config_path(root_path, run_id)

        # Recreate instance config if still missing
        run = store.get_run(run_id)
        if not run:
            console.print(f"[red]Run {run_id} not found[/red]")
            raise typer.Exit(code=1)
        if not instance_config:
            logger.info("Recreating instance config for task run_id=%s", run_id)
            instance_config = create_instance_config(root_path, run_id, run.get("project_dir", ""))

        # Compute output dir and ensure it exists
        run_output_dir = get_run_output_dir(root_path, run_id)
        run_output_dir.mkdir(parents=True, exist_ok=True)

        # Task-specific output path
        task_output_dir = run_output_dir / "tasks" / task_id
        task_output_dir.mkdir(parents=True, exist_ok=True)
        task_output_path = task_output_dir / "OUTPUT.md"
        if not task_output_path.exists():
            task_output_path = task_output_dir / "OUTPUT.txt"  # backwards compat

        # Build enriched goal with run context + prior step outputs
        step_outputs = store.get_step_outputs_map(run_id)
        context_lines = [
            "## Run context\n",
            f"- **Workflow:** {run['workflow_name']}",
            f"- **Original goal:** {run['goal']}",
            f"- **Run ID:** {run_id}",
        ]
        if step_outputs:
            context_lines.append("\n### Prior step outputs\n")
            for key, output_text in step_outputs.items():
                snippet = (output_text or "").strip()[:500]
                if snippet:
                    context_lines.append(f"**{key}:**\n{snippet}\n")

        enriched_goal = "\n".join(context_lines) + f"\n\n## Your task\n\n{goal}"

        from ioagentfarm.engine.workspaces import build_task_prompt
        enriched_message = build_task_prompt(
            step_prompt=enriched_goal,
            output_path=str(task_output_path),
            project_dir=run.get("project_dir", ""),
            output_dir=str(run_output_dir),
        )
        agent_project_dir = run_output_dir

    console.print(f"[cyan]Task[/cyan] {task_id} - {role} is working on it")
    if run_id:
        console.print(f"  [dim]run: {run_id} | task: {task_id} | output: {agent_project_dir}[/dim]")

    # Stream agent output to messages table (same as run-step does)
    from ioagentfarm.cli_orchestration import _is_noise
    from ioagentfarm.engine.workspaces import get_agent_name
    # Bind task_id into a local for the closure to capture unambiguously
    _task_id_for_messages = task_id

    def _on_task_output(line: str) -> None:
        text = line.rstrip("\n")
        stripped = text.strip()
        if not stripped or _is_noise(stripped):
            return
        if run_id:
            store.insert_message(
                run_id=run_id,
                task_id=_task_id_for_messages,
                role=role,
                agent_name=get_agent_name(role),
                source="agent",
                content=stripped,
                msg_type="thought",
            )

    # Forensic blobs for the task — only when a run anchors the path.
    # _invoke_agent writes every blob (prompt, stdout, session snapshot,
    # exit.json, http.log) once given the dir; the whole change is naming.
    task_forensics_dir = None
    if run_id:
        task_forensics_dir = (
            root_path / "instances" / run_id / "forensics"
            / "tasks" / f"{task_id}.1"
        )

    # Invoke the agent via iobot — always mark task complete/failed afterward
    try:
        _invoke_agent(
            role=role,
            session_key=f"iof:task:{task_id}",
            user_id=uid,
            root_path=root_path,
            config_path=instance_config,
            message=enriched_message,
            project_dir=agent_project_dir,
            on_output=_on_task_output,
            forensics_dir=task_forensics_dir,
        )

        # Read structured output if task wrote OUTPUT.txt (run-context tasks)
        task_output_text = f"Agent completed task: {goal[:200]}"
        task_status = "done"
        if task_output_path and task_output_path.exists():
            raw = task_output_path.read_text(encoding="utf-8")
            from ioagentfarm.engine.protocol import parse_key_value_protocol
            kv, _, _ = parse_key_value_protocol(raw)
            task_status = (kv.get("STATUS") or "done").strip().lower()
            task_output_text = kv.get("OUTPUT", raw)
    except Exception as exc:
        task_status = "failed"
        task_output_text = f"Agent crashed: {exc}"
        logger.error("Task %s agent crashed: %s", task_id, exc)

    store.complete_task(task_id, status=task_status, output_text=task_output_text[:2000])
    if task_status == "failed":
        console.print(f"\n[red]Failed[/red] task {task_id}")
    else:
        console.print(f"\n[green]Done[/green] task {task_id}")


@app.command()
def status(
    run_id: str = typer.Option(None, help="Run ID (omit to show recent runs)"),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON (machine-readable, includes stall detection)"),
    stories: bool = typer.Option(False, "--stories", help="Show story status (JSON output)"),
    story_id: str = typer.Option(None, "--story-id", help="Filter by story ID (use with --stories)"),
    team: bool = typer.Option(False, "--team", help="Show per-role team activity (JSON output)"),
    role: str = typer.Option(None, "--role", help="Filter by role (use with --team)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    show_all: bool = typer.Option(False, "--all", help="Show all users' runs (skip user filter)"),
    step: str = typer.Option(None, "--step", help="Show output for a specific step (e.g. analyze_data)"),
):
    """Show recent runs, run detail, stories, or team activity.

    Examples:
      ioagentfarm status                        # recent runs table
      ioagentfarm status --run-id <id>          # step table for a run
      ioagentfarm status --run-id <id> --step analyze_data  # step output
      ioagentfarm status --json                  # active run detail (JSON)
      ioagentfarm status --stories               # story progress (JSON)
      ioagentfarm status --stories --story-id s1 # single story detail
      ioagentfarm status --team                  # per-role summary (JSON)
      ioagentfarm status --team --role developer # role detail with outputs
    """

    # Resolve the workspace BEFORE building the store — that is what loads
    # `~/.iobot/workspaces/<code>/.env` and therefore IOF_DATABASE_URL.
    # Without it `status` read the DEFAULT local sqlite while a run created
    # under the active workspace lived in that workspace's database, so the
    # first command an operator runs during an incident answered
    # "Run not found" about a run that was executing normally (2026-08-16).
    # NO --workspace here either: run/step commands always follow activation.
    # A read flag that can point elsewhere is what an LLM operator generalises
    # onto a WRITE command; the context line already names the active workspace.
    _workspace_code(None, required=True)
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = None if show_all else (user_id or _default_user_id())

    # --- Step output mode ---
    if step:
        resolved = run_id
        if not resolved:
            resolved = _resolve_run_id(store, root_path, None, user_id=uid)
            if not resolved:
                console.print("[red]No active run found.[/red] Use --run-id to specify.")
                raise typer.Exit(1)
        run = _get_run_or_exit(store, resolved, json_mode=as_json)
        # Read OUTPUT.md (or OUTPUT.txt for backwards compat) from the step directory
        step_dir = root_path / "runs" / resolved / "steps" / step.replace(":", "_")
        output_file = step_dir / "OUTPUT.md"
        if not output_file.exists():
            output_file = step_dir / "OUTPUT.txt"
        if not output_file.exists():
            # Check if the step exists at all
            steps = store.list_steps(resolved)
            step_keys = [s["step_key"] for s in steps]
            if step not in step_keys:
                console.print(f"[red]Step '{step}' not found.[/red] Available: {', '.join(step_keys)}")
            else:
                console.print(f"[yellow]Step '{step}' has no output yet[/yellow] (status may be pending/running).")
            raise typer.Exit(1)
        content = output_file.read_text(encoding="utf-8")
        # Strip the STATUS: line for cleaner display
        lines = content.splitlines()
        if lines and lines[0].startswith("STATUS:"):
            lines = lines[1:]
        if lines and lines[0].startswith("OUTPUT:"):
            lines[0] = lines[0][len("OUTPUT:"):].lstrip()
        from rich.markdown import Markdown
        # the STEP's status - this line printed the RUN's, so a done step
        # under a failed run read `Status failed` (novice finding, round 7)
        _srow = next((s for s in store.list_steps(resolved) if s["step_key"] == step), None)
        console.print(f"[bold]Run[/bold] {resolved} ({run['status']})  [bold]Step[/bold] {step}  "
                      f"[bold]Status[/bold] {(_srow or {}).get('status', '?')}\n")
        # The step's record, verbatim: a Markdown render ate the backslash
        # in a Windows path (`novice.iof`) and re-flowed a tool's output
        # (novice finding, rounds 4-5). Bytes, not a rendering.
        console.print("\n".join(lines), markup=False, highlight=False)
        return

    # --- Stories mode ---
    if stories:
        resolved = run_id
        if not resolved:
            resolved = _resolve_run_id(store, root_path, None, user_id=uid)
            if not resolved:
                print(json.dumps({"error": "No active runs"}))
                return

        all_stories = store.list_stories(resolved)

        if story_id:
            match = [s for s in all_stories if s["story_id"] == story_id]
            if not match:
                print(json.dumps({"error": f"Story '{story_id}' not found"}))
                return
            story = match[0]
            steps = store.list_steps(resolved)
            story_steps = [
                {
                    "step_key": s["step_key"],
                    "role": s["role"],
                    "status": s["status"],
                    "attempt": s["attempt"],
                    "max_attempts": s["max_attempts"],
                }
                for s in steps
                if s["step_key"].startswith(f"story:{story_id}:")
            ]
            print(json.dumps({
                "run_id": resolved,
                "story_id": story["story_id"],
                "title": story["title"],
                "status": story["status"],
                "steps": story_steps,
            }, indent=2))
        else:
            summary = [{"story_id": s["story_id"], "title": s["title"], "status": s["status"]} for s in all_stories]
            counts = store.story_counts(resolved)
            print(json.dumps({
                "run_id": resolved,
                "stories_done": counts["done"],
                "stories_total": counts["total"],
                "stories": summary,
            }, indent=2))
        return

    # --- Team mode ---
    if team:
        resolved = run_id
        if not resolved:
            resolved = _resolve_run_id(store, root_path, None, user_id=uid)
            if not resolved:
                print(json.dumps({"error": "No active runs"}))
                return

        if role:
            steps = store.list_steps(resolved)
            role_steps = []
            for s in steps:
                if s["role"] != role:
                    continue
                entry = {
                    "step_key": s["step_key"],
                    "status": s["status"],
                    "attempt": s["attempt"],
                    "max_attempts": s["max_attempts"],
                }
                if s["status"] == "done" and s.get("output_text"):
                    entry["output_preview"] = s["output_text"][:300]
                role_steps.append(entry)
            print(json.dumps({"run_id": resolved, "role": role, "steps": role_steps}, indent=2))
        else:
            summary = store.role_summary(resolved)
            print(json.dumps({"run_id": resolved, "team": summary}, indent=2))
        return

    # --- JSON mode ---
    if as_json:
        resolved = run_id
        if not resolved:
            resolved = _resolve_run_id(store, root_path, None, user_id=uid)
            if not resolved:
                print(json.dumps({"error": "No active runs found"}))
                return

        run = _get_run_or_exit(store, resolved, json_mode=as_json)
        steps = store.list_steps(resolved)
        story_counts = store.story_counts(resolved)

        step_list = []
        stalled = []
        for s in steps:
            entry = {
                "step_key": s["step_key"],
                "role": s["role"],
                "status": s["status"],
                "attempt": s["attempt"],
                "max_attempts": s["max_attempts"],
            }
            step_list.append(entry)
            # STALLED MEANS STALE, NOT MERELY RUNNING. This used to flag every
            # `running` step, so a step one second old was reported as stalled
            # and `stalled_steps` said nothing beyond "something is running".
            # A build session read that field, reported "story:G01:detect is
            # listed as a stalled step", and was right to - it quoted the tool
            # faithfully. The tool was wrong. `aicore forensics is-recovering`
            # said `subprocess_running` about the same step at the same moment:
            # two core commands disagreeing, and the one an operator reaches
            # for first was the misleading one.
            #
            # The supervisor already defines staleness (a running step whose
            # heartbeat_at is older than IOF_SUPERVISOR_STEP_STALE_S, and rows
            # with NO heartbeat get a longer grace). Reusing its threshold
            # rather than inventing a second meaning is the point: the two must
            # not be able to disagree about the same step.
            if s["status"] == "running" and _step_heartbeat_is_stale(s):
                stalled.append({"step_key": s["step_key"], "role": s["role"],
                                "attempt": s["attempt"],
                                "heartbeat_at": s.get("heartbeat_at"),
                                "why": "no heartbeat within "
                                       f"{_step_stale_seconds()}s"})

        counts = {
            "pending": sum(1 for s in steps if s["status"] == "pending"),
            "running": sum(1 for s in steps if s["status"] == "running"),
            "done": sum(1 for s in steps if s["status"] == "done"),
            "failed": sum(1 for s in steps if s["status"] == "failed"),
        }

        # Read last heartbeat from iobot-native log
        from ioagentfarm.engine.workspaces import iobot_agent_workspace
        import re as _re
        hb_path = iobot_agent_workspace("project_lead") / "heartbeat.log"
        last_hb = None
        if hb_path.exists():
            hb_lines = [l for l in hb_path.read_text(encoding="utf-8").splitlines() if l.strip()]
            if hb_lines:
                m = _re.match(r"\[(.+?)\]\s+TICK\s+(\S+)\s*\|\s*(.*)", hb_lines[-1])
                if m:
                    last_hb = {"timestamp": m.group(1), "action": m.group(2), "details": m.group(3).strip()}

        result = {
            "run_id": resolved,
            "workflow": run["workflow_name"],
            "goal": run["goal"],
            "run_status": run["status"],
            "stories": story_counts,
            "step_counts": counts,
            "steps": step_list,
        }
        if stalled:
            result["stalled_steps"] = stalled
        if last_hb:
            result["last_heartbeat"] = last_hb

        print(json.dumps(result, indent=2))
        return

    # --- Table mode (human-readable) ---
    if run_id:
        run = _get_run_or_exit(store, run_id)
        steps = store.list_steps(run_id)
        console.print(f"[bold]Run[/bold] {run_id}  status={run['status']}  workflow={run['workflow_name']}")
        if run.get("status") == "running":
            try:
                from ioagentfarm.engine.supervisor import driver_state
                _ds = driver_state(run, steps)
                if _ds["stale"]:
                    _age = _ds["heartbeat_age_s"]
                    console.print(
                        f"  [red]driver: GONE[/red] - no heartbeat for "
                        f"{'ever' if _age is None else f'{_age:.0f}s'} (stale after "
                        f"{_ds['threshold_s']:.0f}s); nothing will move. "
                        f"Restart it: aicore resume {run_id}")
            except Exception:  # noqa: BLE001
                pass
        table = Table(title="Steps")
        table.add_column("seq")
        table.add_column("step_key")
        table.add_column("role")
        table.add_column("status")
        table.add_column("attempt")
        for s in steps:
            # THE DENOMINATOR IS NOT THE BOUND. `max_attempts` is the number
            # `step-retry` increments, so after the cap fired a step read
            # `3/4` - "one attempt left" - when 3 was the ceiling and nothing
            # would run again (driver round 6). When a declared value has
            # been stamped, the effective ceiling is shown beside it.
            _cell = f"{s['attempt']}/{s['max_attempts']}"
            try:
                _meta = json.loads(s.get("meta_json") or "{}") if isinstance(s, dict) else {}
            except Exception:  # noqa: BLE001
                _meta = {}
            if _meta.get("reset_by"):
                # `3/2` on a step an on_fail gate sent back reads as an
                # overrun; resets do not count against the budget.
                _cell += f" (reset by {_meta['reset_by']}; resets are free)"
            _declared = _meta.get("declared_max_attempts")
            if isinstance(_declared, int) and _declared > 0:
                try:
                    _mult = int(os.environ.get(
                        "IOF_HARD_ATTEMPT_CAP_MULTIPLIER", "2"))
                except (TypeError, ValueError):
                    _mult = 2
                _ceiling = _declared * _mult + 1
                _cell += (f" [cap {_ceiling}]" if int(s["attempt"]) < _ceiling
                          else f" [CAP {_ceiling} reached - no further attempts]")
            table.add_row(str(s["seq"]), s["step_key"], s["role"], s["status"], _cell)
        console.print(table)
        return

    # SCOPED TO THE SELECTED WORKSPACE. Without this, two tenants sharing one
    # database got a byte-identical run list - and every row in it belonged to
    # the other tenant, after which `forensics explain` read their goal text,
    # steps, token usage and cost. Invisible on local SQLite, where each
    # workspace resolves its own state file and the scoping is an accident of
    # file layout; on one shared PostgreSQL the accident stops holding.
    _ws_scope = _current_workspace_code_quietly()
    runs = store.list_runs(limit=10, user_id=uid, workspace_code=_ws_scope)
    table = Table(title="Recent runs"
                  + (f" - workspace {_ws_scope}" if _ws_scope else ""))
    table.add_column("run_id", no_wrap=True)
    table.add_column("workflow")
    table.add_column("status")
    table.add_column("project_dir")
    table.add_column("parent")
    table.add_column("created_at")
    for r in runs:
        proj = r.get("project_dir", "")
        proj_short = ("..." + proj[-30:]) if len(proj) > 33 else proj
        parent = r.get("parent_run_id") or ""
        parent_short = parent[:20] + "..." if len(parent) > 23 else parent
        table.add_row(r["id"], r["workflow_name"], r["status"], proj_short, parent_short, r["created_at"])
    console.print(table)
    # `aicore status` is user-scoped, so the FIRST thing a paged operator
    # types shows an empty table when the runs belong to a service
    # (`web:default`) or another person - and nothing said `--all` exists
    # (novice finding, round 8). Only when the table is empty AND runs exist
    # for someone else: one line, one extra cheap query.
    if not runs and not show_all:
        try:
            if store.list_runs(limit=1, user_id=None,
                               workspace_code=_ws_scope):
                console.print(
                    f"[dim]No runs for this user ({uid}). Other users (a service, "
                    f"a teammate) have runs here - `{prog()} status --all` shows them.[/dim]")
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Savant sync command
# ---------------------------------------------------------------------------

# (sync-products / upload-datasets removed with session mode — the Savant
# Strategy Lab product catalog is not part of the workflow-driven solution.)


# ---------------------------------------------------------------------------
# Orchestration & recovery commands (in cli_orchestration.py)
# ---------------------------------------------------------------------------

from ioagentfarm.cli_orchestration import register_commands as _register_orchestration
_register_orchestration(app)

from ioagentfarm.builder import register_commands as _register_build
_register_build(app)


if __name__ == "__main__":  # `python -m ioagentfarm.cli` (used by _launch_detached)
    app()
