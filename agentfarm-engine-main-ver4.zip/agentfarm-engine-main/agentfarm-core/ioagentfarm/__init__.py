"""ioagentfarm package bootstrap — runs before any other module or stdlib call.

Windows env recovery
--------------------
iobot's ExecTool intentionally strips the subprocess environment to
{HOME, LANG, TERM} for security (prevents LLM-generated commands from
accessing secrets via env vars). That 3-var allowlist was designed for
Linux containers where HOME is sufficient for Python's stdlib.

On Windows + Git Bash, Python's stdlib expects different env vars:
  - ``pathlib.Path.home()`` / ``os.path.expanduser('~')`` → ``USERPROFILE``
    (falls through to ``HOMEDRIVE+HOMEPATH``, then ``HOME``)
  - ``getpass.getuser()`` → ``USERNAME`` / ``USER`` / ``LOGNAME`` / ``LNAME``
    (falls back to ``import pwd`` which doesn't exist on Windows)

When ``ioagentfarm`` runs as a nested subprocess (web server → Alex's
iobot → Alex's exec tool → ``ioagentfarm run-step`` → iobot agent for
Analyst), the env strip cascades. Without USERPROFILE and USERNAME, any
stdlib call trying to resolve user identity crashes with
``RuntimeError: Could not determine home directory`` or
``ModuleNotFoundError: No module named 'pwd'``, before any real work
begins. On Linux this isn't a problem because HOME alone is sufficient.

The fix: on Windows, if we detect a stripped env missing the critical
Windows-native vars, derive them from HOME before any other code runs.
This function is idempotent and a no-op on Linux.

IOF_ROOT recovery
-----------------
iobot v0.1.5 also strips IOF_ROOT from the subprocess env. When the
``ioagentfarm run-step`` subprocess starts, ``Path(os.getenv("IOF_ROOT", ".iof")).resolve()``
falls back to ``.iof`` resolved from whatever CWD bash inherited — typically
the agent's iobot workspace, not the project root. The result:
``metadata_dir = root / "instances" / run_id / "workflow" / "metadata"``
points at a directory that doesn't exist, the template variable resolves
to an empty string, and step prompts render bogus paths like
``/data/purchase_orders.csv``. Agents then either fail outright or invent
synthetic data.

The fix: derive IOF_ROOT from the package install location at import time.
For an editable install (``pip install -e .``), the package is in the source
tree and ``Path(__file__).resolve().parent.parent`` is the project root, which
contains ``.iof/``. We set IOF_ROOT to that absolute path so every nested
ioagentfarm subprocess sees the correct root regardless of CWD or env strip.
On Linux pods with non-editable installs the package lives in site-packages,
so this auto-derivation is skipped and IOF_ROOT must come from the deploy
env (K8s ConfigMap, .env file, etc.) — same as it does today on release/dev.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

__all__ = ["__version__"]
__version__ = "0.6.9"


def _recover_windows_env() -> None:
    """Derive USERPROFILE and USERNAME from HOME when missing (Windows only).

    iobot's exec tool strips env to HOME/LANG/TERM. Python's Windows stdlib
    needs USERPROFILE (for Path.home / expanduser) and USERNAME (for
    getpass.getuser). Both can be derived from HOME, which bash propagates.
    """
    if sys.platform != "win32":
        return

    if not os.environ.get("USERPROFILE"):
        home = os.environ.get("HOME")
        if home:
            # Git Bash gives HOME as /c/Users/Foo; Python on Windows wants C:\Users\Foo
            if len(home) >= 3 and home.startswith("/") and home[2] == "/":
                drive = home[1].upper()
                rest = home[3:].replace("/", "\\")
                os.environ["USERPROFILE"] = f"{drive}:\\{rest}"
            else:
                os.environ["USERPROFILE"] = home

    if not os.environ.get("USERNAME"):
        userprofile = os.environ.get("USERPROFILE")
        if userprofile:
            os.environ["USERNAME"] = os.path.basename(userprofile.rstrip("\\/"))


def _recover_iof_root() -> None:
    """Derive IOF_ROOT from the package install location when missing.

    Only applies for editable installs where the package lives in the project
    source tree. For site-packages installs (production pods), the package
    lives elsewhere and IOF_ROOT must come from the deploy env, so we leave
    it alone. Idempotent — never overrides an existing IOF_ROOT.
    """
    if os.environ.get("IOF_ROOT"):
        return

    # Walk up from this file: ioagentfarm/__init__.py → ioagentfarm/ → project root
    pkg_root = Path(__file__).resolve().parent.parent

    # An explicit IOF_ROOT in the project .env beats the heuristic below.
    # This runs at package import — BEFORE cli.py's load_dotenv(), which uses
    # override=False and therefore cannot repair a value the heuristic already
    # set. Without this read, a split-repo deployment that sets IOF_ROOT in
    # the engine repo's .env (the CLIENT_SETUP.md layout) silently gets
    # <engine>/.iof instead the moment anything creates that directory.
    env_file = pkg_root / ".env"
    if env_file.exists():
        try:
            from dotenv import dotenv_values

            explicit = (dotenv_values(env_file) or {}).get("IOF_ROOT")
            if explicit:
                os.environ["IOF_ROOT"] = explicit
                return
        except ImportError:
            pass

    # Heuristic: this looks like an editable install if the project root
    # contains a pyproject.toml AND a .iof directory. Both must be true,
    # otherwise we're likely a site-packages install on a pod.
    if (pkg_root / "pyproject.toml").exists() and (pkg_root / ".iof").is_dir():
        os.environ["IOF_ROOT"] = str(pkg_root / ".iof")


# NOTE: Streaming disable (patch #3) and request timeout (patch #5) are
# NOT here. They live in the sitecustomize.py that _invoke_agent injects
# via PYTHONPATH into the iobot subprocess. __init__.py only runs when
# ioagentfarm is imported — but the iobot subprocess ('iobot agent')
# never imports ioagentfarm, so patches here never reach it. The
# sitecustomize.py approach runs at Python interpreter startup, BEFORE
# iobot loads — the patches are in place when iobot instantiates its
# provider classes. See cli.py:_invoke_agent and docs/monkey-patches.md.


def _patch_iobot_extra_allowed_dirs() -> None:
    """Inject extra allowed directories into iobot's filesystem sandbox.

    iobot's ``_FsTool`` (Read/Write/Edit/ListDir) sandbox restricts file
    operations to the agent's workspace via a Python-level ``allowed_dir``
    check. With ``exec_config.sandbox=True`` (bwrap on, the production
    config), iobot's ``loop._register_default_tools`` activates this
    restriction for symmetry with the bwrap exec sandbox.

    Our Savant session model writes artifacts (signals.json,
    intelligence_brief.md, strategy.json, narrative.md, score.json) to a
    SHARED per-session workspace at ``/app/.iof/savant/<sid>/`` — outside
    every agent's iobot workspace. The engine writes these directly via
    Python ``Path.write_text()`` (trusted, bypasses the tool sandbox), but
    Analyst writes ``signals.json`` + ``intelligence_brief.md`` via the
    ``write_file`` LLM tool, which goes through ``_FsTool`` and gets
    rejected with::

      Path /app/.iof/savant/<sid>/analyst/output/signals.json is outside
      allowed directory /root/.iobot/agents/analyst/workspace

    iobot's loop calls ``cls(workspace=…, allowed_dir=…)`` for
    Write/Edit/ListDir tools (loop.py:259-260) — it never passes
    ``extra_allowed_dirs`` even though ``_FsTool.__init__`` accepts it.
    There is no config flag, env var, or extension hook to override this
    behavior — only ``ReadFileTool`` gets ``extra_allowed_dirs`` (for the
    builtin skills dir).

    This patch wraps ``_FsTool.__init__`` so every filesystem-tool
    instantiation appends our session-root path(s) to its
    ``extra_allowed_dirs`` list. Subsequent ``_resolve_path`` calls accept
    writes anywhere under those roots.

    Scope: every path that imports ioagentfarm. That is the in-process
    always-on agents (Jarvis, Quinn, and the Savant session agents
    Analyst/Strategist/Reviewer/POD — all via ``process_direct()`` in the
    FastAPI server process) AND the ``iobot agent`` subprocesses spawned by
    ``cli.py:_invoke_agent`` / ``web/spawn.py``, whose generated
    ``sitecustomize.py`` calls this function by name. (It used to carry its
    own inlined copy of this logic, which double-wrapped the ctor; the shim
    now delegates here so there is ONE implementation to keep correct.)

    iobot 0.3.0 compatibility
    ---------------------------
    0.3.0 split the old read+write ``extra_allowed_dirs`` into a READ-ONLY
    legacy alias plus an explicit ``extra_write_allowed_dirs``
    (``filesystem.py``: *"Legacy alias: extra_allowed_dirs is read-only.
    Write-capable tools must opt in via extra_write_allowed_dirs."*). Feeding
    only the legacy list there would leave agents able to READ the injected
    roots but not WRITE to them — silently breaking every artifact write
    under the sandbox. So the injected paths go into BOTH lists whenever the
    ctor accepts the newer parameter, and into the single list otherwise.
    The wrapper also forwards arguments positionally-or-by-keyword via
    ``Signature.bind_partial``, so it survives the ctor gaining parameters
    (0.3.0 added ``file_states``, ``restrict_to_workspace``,
    ``sandbox_restricts_workspace``, ``extra_read_allowed_*``).

    Toggle: ``IOF_IOBOT_EXTRA_ALLOWED_DIRS`` — colon-separated absolute
    paths (PATH-style). Typical production value is the savant root, e.g.
    ``IOF_IOBOT_EXTRA_ALLOWED_DIRS=/app/.iof/savant``. Unset → no patch
    applied → original behavior preserved (failing writes, fallback
    migration kicks in via ``_load_session_from_db`` / engine.run_briefing
    fallback path).

    See ``docs/monkey-patches.md`` patch #6 for the full evidence trail
    (sv_d75ea42fe265, sv_0fdc3e269033) and clean-alternatives review.
    """
    extra_paths_raw = os.environ.get("IOF_IOBOT_EXTRA_ALLOWED_DIRS", "")
    if not extra_paths_raw:
        return

    paths = []
    for p in extra_paths_raw.split(os.pathsep):
        p = p.strip()
        if not p:
            continue
        try:
            paths.append(Path(p).expanduser().resolve())
        except (OSError, RuntimeError):
            continue
    if not paths:
        return

    try:
        from iobot.agent.tools.filesystem import _FsTool
    except ImportError:
        # iobot not installed (e.g., test harness without iobot extra) —
        # skip silently; nothing to patch.
        return

    # Idempotency: don't double-wrap if the patch already ran.
    if getattr(_FsTool.__init__, "_iof_extra_allowed_dirs_patched", False):
        return

    import inspect

    original_init = _FsTool.__init__
    sig = inspect.signature(original_init)
    # iobot >=0.3.0 only. On 0.2.x the single list still carried writes.
    has_write_param = "extra_write_allowed_dirs" in sig.parameters

    def _merge(existing):
        merged = list(existing or [])
        for p in paths:
            if p not in merged:
                merged.append(p)
        return merged

    def patched_init(self, *args, **kwargs):
        bound = sig.bind_partial(self, *args, **kwargs)
        bound.arguments["extra_allowed_dirs"] = _merge(
            bound.arguments.get("extra_allowed_dirs")
        )
        if has_write_param:
            bound.arguments["extra_write_allowed_dirs"] = _merge(
                bound.arguments.get("extra_write_allowed_dirs")
            )
        original_init(*bound.args, **bound.kwargs)

    patched_init._iof_extra_allowed_dirs_patched = True  # type: ignore[attr-defined]
    _FsTool.__init__ = patched_init  # type: ignore[method-assign]


def _load_project_dotenv() -> None:
    """Load .env from the project root at import time.

    Bash/shell sourcing of .env is fragile: passwords or tokens containing
    literal ``$`` are treated as variable expansions and silently turned into
    empty strings, breaking DB auth. Loading the file directly via python-dotenv
    sidesteps that. No-op if python-dotenv is not installed or the file is
    absent. Never overrides env vars that are already set.
    """
    pkg_root = Path(__file__).resolve().parent.parent
    env_path = pkg_root / ".env"
    if not env_path.is_file():
        return          # nothing to load: do not pay for the import
    try:
        from dotenv import load_dotenv  # type: ignore
    except ImportError:
        return
    load_dotenv(env_path, override=False)


def _apply_iobot_patches() -> None:
    """Arm (default) or apply (``IOF_EAGER_PATCHES=1``) the runtime patches.

    Arming registers post-import hooks so each patch applies the moment the
    module it targets is first imported — see ``_iobot_patches.arm_all``.
    A process that never loads the runtime — ``aicore --help``, the scaffold
    commands, the ``iof-*`` data tools an agent execs mid-run — no longer
    pays the runtime's import cost (~4s measured on Windows, ~2.3s of it the
    ``openai`` SDK behind the Azure swap, imported for a backend most
    deployments never select). Processes that DO load the runtime get the
    patches at first iobot import, before any code can see an unpatched
    module.

    ``IOF_EAGER_PATCHES=1`` restores full application at import time — the
    pre-0.6.4 behaviour — and is also the fallback if arming itself fails.
    """
    eager = os.environ.get("IOF_EAGER_PATCHES", "").strip().lower() in (
        "1", "true", "yes")
    try:
        from ioagentfarm._iobot_patches import apply_all, arm_all
    except Exception:
        return
    if not eager:
        try:
            arm_all()
            return
        except Exception as e:
            print(f"[aicore patches] arming failed ({e}) - falling back to "
                  f"eager application", file=sys.stderr, flush=True)
    try:
        apply_all()
        _patch_iobot_extra_allowed_dirs()
        _install_log_rebranding()
    except Exception:
        # Patch failures should never block ioagentfarm import. The
        # individual patches are guarded internally; this is a final
        # safety net so a transient iobot internals refactor can't
        # take the whole package down.
        pass


def _install_log_rebranding() -> None:
    """Present in-process runtime logs as ``iobot`` (the `serve` path).

    Subprocess output is rebranded in ``cli.py:_invoke_agent``; `serve` runs
    agents in-process, so its loguru records would otherwise reach the console
    stamped ``iobot.agent.loop``. Best-effort — see engine/branding.py.
    """
    try:
        from ioagentfarm.engine.branding import install_log_rebranding
        install_log_rebranding()
    except Exception:
        pass


_recover_windows_env()
_recover_iof_root()
_load_project_dotenv()
# Arms the patch registry by default (patches fire on first iobot import);
# the filesystem allowed-dirs injection and the loguru rebranding ride the
# same trigger. IOF_EAGER_PATCHES=1 applies everything here instead.
_apply_iobot_patches()
