"""Setup-time resolver for pack-declared **CLI tools**.

Scope — CLI tools ONLY, not MCP tools
-------------------------------------
This resolver is exclusively about the shell/CLI executables an agent invokes
through iobot's ``exec`` tool (``vectorfs``, ``iof-query``, the deck-export
Node deps, …). It has **nothing to do with MCP servers** — those are wired
per-run in ``engine/iobot_config.py`` (``mcp-add``/``mcp-list``) and follow a
completely separate lifecycle. A CLI tool must resolve on ``PATH``; an MCP tool
is a server the runtime launches. Do not route MCP servers through here.

Ownership tiers (mirrors the 3-tier skills model)
-------------------------------------------------
Just like skills, a CLI tool comes from one of four places — the ``owner`` field:

  core     shipped inside the engine distribution itself (AI Core team). Expected
           present with the core wheel → validate only; a miss is a core
           packaging bug. (e.g. ``iof-query``)
  shared   a separate shared-tools dependency the AI Core team publishes and
           versions independently (the tools analogue of the ``agentfarm-skills``
           wheel — e.g. a shared ``@ts-tools/*`` npm bundle). A domain gets it by
           depending on it; validate-first, install the gap via ``installer``.
  domain   owned by / bundled in the domain pack's own repo (e.g. a
           domain-specific CLI, or a script that ships as pack data). Validate,
           install the gap via ``installer`` if one is declared.
  cli-hub  downloaded from the org CLI hub (``AGENTFARM_CLI_HUB_URL``) — the
           registry entry maps to an ecosystem installer. Not wired yet (tabled
           with on-demand install); reported as a gap with guidance.

The ``installer`` field is the *mechanism* used to fill a gap (orthogonal to the
tier): ``pip`` | ``npm`` | ``npm-global`` | ``brew`` | ``build``. Omit it for
tools that are baked in / bundled and only need validation (``owner: core`` and
many ``domain``/``shared`` tools in a prebuilt container).

``installer: build`` — build-from-source (for tools with no registry artifact)
------------------------------------------------------------------------------
Some shared tools (e.g. ``@ts-tools/vectorfs``) are not published to any
registry — they exist as source and are compiled + linked. For these, declare a
``build`` recipe instead of a ``package``::

    installer: build
    bin: vectorfs
    build:
      repo: "git+https://<org-git>/agentfarm/ts-skills.git"   # git URL or local path
      ref: "v0.2.0"                                            # tag/branch (optional)
      subdir: "."                                              # where to run steps (optional)
      steps:
        - "npm install"
        - "npx turbo build --filter=@ts-tools/vectorfs"
        - "npm link -w vectorfs"

Source resolution order: ``AGENTFARM_TOOLS_SRC_ROOT`` (dev: a local checkout) →
``build.repo`` as a local path → ``build.repo`` git-cloned into the tool-src
cache (``$IOF_ROOT/tool-src/<name>``) → (owner ``cli-hub``) the recipe is served
by the hub. The **executor is identical** regardless of where the recipe/source
came from — this is how a cli-hub-served tool builds locally when Docker didn't
provide it.

SECURITY: build steps run arbitrary shell = remote code execution. Building is
**opt-in** (``--allow-build`` / ``AGENTFARM_ALLOW_TOOL_BUILD=1``) and should only
target trusted org-internal sources. This is the trust/provenance seam that a
signed cli-hub + sandbox policy must eventually gate (see the clawhub notes).

Why setup-time, not agent-runtime
---------------------------------
Validate-first, install-the-gaps runs once at setup: in the container it's a
fast no-op (tools baked into the image by the Dockerfile), on a fresh
``pip install`` dev box it fills the gaps. On-demand per-task install
(CLI-Anything style) is a tabled future enhancement.

Core stays domain-free: it iterates whatever packs declare, exactly like
``domain_skill_injections()`` reads ``inject.yaml`` — it never names a tool.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Aggregate exit codes (preflight semantics, mirrors CLI-Hub's matrix preflight).
EXIT_READY = 0   # every tool present (validated or installed)
EXIT_ERROR = 1   # an installer failed / a resolver errored
EXIT_GAPS = 3    # tools remain missing (check-only, or unresolvable)

_OWNERS = {"core", "shared", "domain", "cli-hub"}
_INSTALLERS = {"pip", "npm", "npm-global", "brew"}


@dataclass(frozen=True)
class ToolSpec:
    """One CLI tool a pack requires. Parsed from a ``tools.yaml`` entry."""

    name: str
    owner: str = "domain"              # core | shared | domain | cli-hub
    installer: Optional[str] = None    # pip | npm | npm-global | brew | build (gap-fill)
    bin: Optional[str] = None          # what must resolve on PATH (validate probe)
    package: Optional[str] = None      # install spec (space-separated allowed for multi)
    check: Optional[str] = None        # explicit validation command (rc 0 == present)
    build: Optional[dict] = None       # {repo, ref?, subdir?, steps[]} for installer: build
    pack: str = "?"                    # provenance (declaring pack), for reporting only
    #: Its absence is reported, never fatal. For a tool THE DECLARING INSTALL
    #: CANNOT DELIVER: `vectorfs` has no registry artifact, so a plain
    #: `pip install` of the SDK can never satisfy it, and a strict boot gate
    #: turned that into "a fresh install cannot start" for every deployment,
    #: including the ones that never use it. A console script riding the wheel
    #: is the opposite case - absent means the install is broken, and boot
    #: SHOULD refuse. Optional is that distinction, declared rather than
    #: guessed at. It never changes what `cli-hub check`/`list` report.
    optional: bool = False

    @classmethod
    def from_dict(cls, d: dict, pack: str = "?") -> "ToolSpec":
        # Back-compat: accept `source` as an alias for `installer`.
        installer = d.get("installer") or d.get("source")
        installer = str(installer).strip().lower() if installer else None
        owner = str(d.get("owner") or "domain").strip().lower()
        build = d.get("build")
        return cls(
            name=str(d.get("name") or d.get("bin") or "?"),
            owner=owner,
            installer=installer,
            bin=d.get("bin"),
            package=d.get("package"),
            check=d.get("check"),
            build=build if isinstance(build, dict) else None,
            pack=pack,
            optional=bool(d.get("optional", False)),
        )


# Result statuses.
READY = "ready"                  # validated already present → no-op
INSTALLED = "installed"          # was missing, installed successfully
WOULD_INSTALL = "would-install"  # --dry-run: missing, resolver known
GAP = "gap"                      # missing and not installed (check-only / unresolvable)
ERROR = "error"                  # installer/resolver failed


@dataclass
class ToolResult:
    spec: ToolSpec
    status: str
    detail: str = ""


#: The core pack's internal identity. Catalog scoping and collision
#: detection key on this string, so it must never change — but it is a
#: package name the reader never types, and on a deployment that
#: republishes the SDK it is not even the name they installed under.
CORE_PACK = "core"


def display_pack(pack: str) -> str:
    """What to CALL a pack on screen, in the reader's own vocabulary.

    For the core pack, resolved from the INSTALLED distribution that ships
    the import package — so the answer is whatever this machine actually
    has, not the name this source tree publishes under. A solution pack's
    own name is already the right one and passes through.

    Display only. Callers that scope a catalog or detect a collision must
    keep using ``spec.pack``; two packs are the same pack when their
    identities match, never when their labels do.
    """
    if pack != CORE_PACK:
        return pack
    try:
        import importlib.metadata as _md
        dists = _md.packages_distributions().get("ioagentfarm") or []
        if dists:
            return sorted(set(dists))[0]
    except Exception:                    # noqa: BLE001 - a label is never fatal
        pass
    return "engine"


def validate(spec: ToolSpec) -> Optional[bool]:
    """True if present, False if provably absent, None if not validatable
    (no ``bin`` and no ``check`` — a manifest gap)."""
    if spec.check:
        try:
            rc = subprocess.run(
                spec.check, shell=True, capture_output=True, timeout=60
            ).returncode
            return rc == 0
        except Exception:  # pragma: no cover - defensive
            logger.debug("check command failed for %s", spec.name, exc_info=True)
            return False
    if spec.bin:
        if shutil.which(spec.bin) is not None:
            return True
        # PATH misses console scripts when the venv is not activated (the
        # normal state for `.venv\Scripts\ioagentfarm setup-agents` and any
        # subprocess-spawned CLI). The running interpreter's own scripts
        # directory is authoritative for pip-installed entry points — check
        # it before declaring a gap, or every venv install reports its own
        # sibling tools as "missing".
        scripts_dir = Path(sys.executable).resolve().parent
        return shutil.which(spec.bin, path=str(scripts_dir)) is not None
    return None


def _installer_cmd(spec: ToolSpec) -> Optional[list[str]]:
    """The argv that would install ``spec`` via its ``installer``, or None if it
    can't install here (no installer / no package / manager absent)."""
    pkg = (spec.package or "").split()
    if not spec.installer or not pkg:
        return None
    if spec.installer == "pip":
        return [sys.executable, "-m", "pip", "install", *pkg]
    if spec.installer in ("npm", "npm-global"):
        return ["npm", "install", "-g", *pkg] if shutil.which("npm") else None
    if spec.installer == "brew":
        return ["brew", "install", *pkg] if shutil.which("brew") else None
    return None


def _gap_guidance(spec: ToolSpec) -> str:
    """Owner-aware message for a tool that's missing and can't be auto-installed."""
    if spec.owner == "core":
        # NAME THE LIKELY CAUSE AND THE REMEDY. "core packaging bug" is
        # accurate and leaves the reader nothing to do. The overwhelmingly
        # common case is a VERSION SKEW rather than a broken build: this
        # tool is declared in the installed wheel's tools.yaml, but that
        # wheel predates the console-script entry point that creates the
        # binary, so the declaration ships without the launcher. Upgrading
        # the engine distribution fixes it; nothing local can.
        return ("declared by the installed engine but its command is not on "
                "PATH — usually an engine version whose tools.yaml is ahead "
                "of its entry points; upgrade the engine distribution "
                "(pip install --upgrade), and if it persists after an "
                "upgrade the published wheel is inconsistent")
    if spec.owner == "shared":
        return "expected from the shared-tools dependency; add/upgrade it (or declare an 'installer')"
    if spec.owner == "cli-hub":
        # DO NOT NAME AN UNWIRED VARIABLE TO AN OPERATOR. This printed
        # `AGENTFARM_CLI_HUB_URL=unset` at a reader who has no such
        # variable and could not make it work by setting one - the hub
        # client does not exist. Tell them the only thing that is true:
        # this tool has to be installed by hand (reported by a customer
        # reading our output, 2026-09-03).
        return (f"no source for {spec.name!r} on this host - install it "
                f"manually so {spec.bin or spec.name!r} is on PATH")
    # domain
    if spec.installer and spec.installer in _INSTALLERS and not spec.package:
        return f"declare a 'package' for installer '{spec.installer}'"
    if spec.installer in ("npm", "npm-global") and not shutil.which("npm"):
        return "npm not on PATH — install Node.js/npm first"
    if spec.installer == "brew" and not shutil.which("brew"):
        return "brew not on PATH"
    return "bundled/domain tool missing and no installer declared (build the pack's tool, or add 'installer')"


def _tool_src_cache() -> Path:
    root = Path(os.environ.get("IOF_ROOT", ".iof")) / "tool-src"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _resolve_build_src(spec: ToolSpec) -> Optional[str]:
    """Locate the source tree to build in, or None if unavailable.

    Order: AGENTFARM_TOOLS_SRC_ROOT (dev local checkout) → ``build.repo`` as a
    local path → ``build.repo`` git-cloned into the tool-src cache."""
    recipe = spec.build or {}
    env_root = os.environ.get("AGENTFARM_TOOLS_SRC_ROOT")
    if env_root and os.path.isdir(env_root):
        return env_root
    repo = str(recipe.get("repo") or "").strip()
    if not repo:
        return None
    # A SHIPPED RECIPE MUST NOT NAME OUR GIT SERVER. `repo:` may be an
    # environment reference so each deployment points the build at its own
    # mirror; an unset reference resolves to nothing rather than cloning a
    # host the client cannot reach (a customer found our internal GitLab
    # URL baked into the wheel, 2026-09-03).
    from ioagentfarm.engine.env_template import ENV_REF

    def _expand(m):
        name, _, default = m.group(0)[2:-1].partition(":-")
        return os.environ.get(name, default)

    if ENV_REF.search(repo):
        repo = ENV_REF.sub(_expand, repo).strip()
        if not repo:
            return None
    is_git = repo.startswith(("git+", "http://", "https://", "ssh://", "git@"))
    if not is_git and os.path.isdir(repo):
        return repo
    if is_git:
        if not shutil.which("git"):
            return None
        url = repo[4:] if repo.startswith("git+") else repo
        dest = _tool_src_cache() / spec.name
        if (dest / ".git").is_dir():
            return str(dest)  # reuse an existing clone
        cmd = ["git", "clone", "--depth", "1"]
        ref = recipe.get("ref")
        if ref:
            cmd += ["--branch", str(ref)]
        cmd += [url, str(dest)]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        except Exception:  # pragma: no cover - defensive
            return None
        return str(dest) if proc.returncode == 0 else None
    return None


def _build_install(spec: ToolSpec, allow_build: bool) -> ToolResult:
    recipe = spec.build or {}
    steps = [str(s) for s in (recipe.get("steps") or [])]
    if not steps:
        return ToolResult(spec, GAP, "installer: build but no build.steps declared")
    if not allow_build:
        return ToolResult(spec, GAP,
                          "build required — re-run with --allow-build (runs source build steps)")
    src = _resolve_build_src(spec)
    if src is None:
        if spec.owner == "cli-hub":
            return ToolResult(spec, GAP,
                              f"no build recipe for {spec.name!r} on this host - "
                              "set AGENTFARM_TOOLS_SRC_ROOT to a local checkout, "
                              "or install the tool manually")
        from ioagentfarm.engine.env_template import ENV_REF
        _refs = sorted({m.group(1) for m in
                        ENV_REF.finditer(str(recipe.get("repo") or ""))
                        if not os.environ.get(m.group(1))})
        _hint = (f"set {' or '.join(_refs)} to your own mirror, or "
                 if _refs else "")
        return ToolResult(spec, GAP,
                          f"no build source — {_hint}"
                          "set AGENTFARM_TOOLS_SRC_ROOT to a local checkout")
    workdir = src
    sub = str(recipe.get("subdir") or "").strip()
    if sub and sub != ".":
        workdir = os.path.join(src, sub)
    for step in steps:
        try:
            proc = subprocess.run(step, shell=True, cwd=workdir,
                                  capture_output=True, text=True, timeout=1800)
        except Exception as e:  # pragma: no cover - defensive
            return ToolResult(spec, ERROR, f"build step raised: {e}")
        if proc.returncode != 0:
            tail = (proc.stderr or proc.stdout or "").strip().splitlines()[-1:] or [""]
            return ToolResult(spec, ERROR, f"build step failed [{step}]: {tail[0]}")
    if validate(spec) is True:
        return ToolResult(spec, INSTALLED, f"built from source ({workdir}) and validated")
    return ToolResult(spec, GAP, "build steps ran but tool still not detected on PATH")


def _plan(spec: ToolSpec) -> Optional[str]:
    """What --dry-run would do for this spec, or None if not installable here."""
    if spec.installer == "build":
        steps = [str(s) for s in ((spec.build or {}).get("steps") or [])]
        return "build: " + " && ".join(steps) if steps else None
    cmd = _installer_cmd(spec)
    return " ".join(cmd) if cmd else None


def _install(spec: ToolSpec, allow_build: bool = False) -> ToolResult:
    if spec.installer == "build":
        return _build_install(spec, allow_build)
    cmd = _installer_cmd(spec)
    if cmd is None:
        return ToolResult(spec, GAP, _gap_guidance(spec))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    except Exception as e:  # pragma: no cover - defensive
        return ToolResult(spec, ERROR, f"installer raised: {e}")
    if proc.returncode != 0:
        tail = (proc.stderr or proc.stdout or "").strip().splitlines()[-1:] or [""]
        return ToolResult(spec, ERROR, f"{' '.join(cmd[:3])}… exited {proc.returncode}: {tail[0]}")
    if validate(spec) is True:
        return ToolResult(spec, INSTALLED, "installed and validated")
    return ToolResult(spec, GAP, "installer succeeded but tool still not detected")


def resolve_all(
    specs: list[ToolSpec],
    *,
    check_only: bool = False,
    dry_run: bool = False,
    allow_build: bool = False,
    only: Optional[set[str]] = None,
) -> list[ToolResult]:
    """Validate each spec; install the gaps unless ``check_only``/``dry_run``.

    ``allow_build`` opts into ``installer: build`` (running source build steps)."""
    results: list[ToolResult] = []
    for spec in specs:
        if only and spec.name not in only:
            continue
        present = validate(spec)
        if present is True:
            results.append(ToolResult(spec, READY, "already present"))
            continue
        if present is None:
            results.append(ToolResult(spec, GAP, "not validatable (declare 'bin' or 'check')"))
            continue
        if check_only:
            results.append(ToolResult(spec, GAP, "missing (check-only, not installed)"))
        elif dry_run:
            plan = _plan(spec)
            if plan is None:
                results.append(ToolResult(spec, GAP, _gap_guidance(spec)))
            elif spec.installer == "build" and not allow_build:
                results.append(ToolResult(spec, WOULD_INSTALL, f"[--allow-build] {plan}"))
            else:
                results.append(ToolResult(spec, WOULD_INSTALL, plan))
        else:
            results.append(_install(spec, allow_build=allow_build))
    return results


def exit_code(results: list[ToolResult]) -> int:
    """0 all present, 3 gaps, 1 error - an OPTIONAL gap is not a gap.

    `optional` was added so a tool the install cannot deliver would not refuse
    the boot, and the boot gate honoured it while THIS did not. `vectorfs` is
    published to no registry, so on every pip install `cli-hub check` printed
    a yellow "Gaps remain" and exited 3, permanently, for a tool that is
    working as designed - and both walkthroughs record the green line. A check
    that is always yellow is a check nobody reads, which is the opposite of
    what it is for.

    The gap is still REPORTED in the table; it just does not fail the command.
    """
    if any(r.status == ERROR for r in results):
        return EXIT_ERROR
    if any(r.status == GAP and not r.spec.optional for r in results):
        return EXIT_GAPS
    return EXIT_READY
