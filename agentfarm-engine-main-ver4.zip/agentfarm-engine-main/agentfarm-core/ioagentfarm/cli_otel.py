"""``aicore otel`` — is telemetry actually arriving?

Every other answer about observability is inferred. An operator sets
``OTEL_EXPORTER_OTLP_ENDPOINT``, runs a workflow, sees nothing in their
backend, and has no way to tell which of six things is wrong: the variable is
not reaching the process, the SDK extra is not installed, the URL is a base
where a full path was wanted (or the reverse), the credential header is
missing or misspelled, the backend rejects the payload, or the network does
not allow it. Each of those fails in a different place and none of them
reaches the console, because export failures deliberately never break a run.

``aicore otel check`` reads the configuration the way the exporter will read
it, prints the URL that will actually be POSTed, and — with ``--send`` —
posts one real span and reports the outcome, including the HTTP status the
backend returned. That turns "nothing appeared in Phoenix" into one line.
"""
from __future__ import annotations

import logging
import os
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(help="Telemetry export: what is configured, and does it arrive.")
console = Console()


def _mask(value: str) -> str:
    """Enough to tell one value from another, never any of the secret.

    This used to print the first and last four characters. For
    `OTEL_EXPORTER_OTLP_HEADERS` the leading characters are the header NAME
    (`Authorization=Bearer …`), which is not secret and is worth seeing — but
    the trailing four are the end of the credential itself, and a diagnostic
    labelled "values masked" should not emit any of it. The length and a short
    digest distinguish two values and identify a rotation without carrying a
    fragment of the key into a terminal, a screenshot or a support ticket.
    """
    import hashlib

    v = value.strip()
    if not v:
        return "(empty)"
    # Split the header NAME from its value: the name is routing and is worth
    # showing, the value is the credential. The length and digest describe the
    # VALUE - reporting the length of the whole `name=value` pair, as this
    # first did, reads as a fact about the secret and is not one.
    name, sep, secret = v.partition("=") if "=" in v[:40] else ("", "", v)
    digest = hashlib.sha256(secret.encode("utf-8", "replace")).hexdigest()[:6]
    return f"{name}{sep}<{len(secret)} chars, sha256:{digest}>"


def _adopt_workspace_env() -> None:
    """Read the workspace's own ``.env`` before reporting on the environment.

    A command that only reads ``os.environ`` answers about the SHELL, while
    the engine answers about the workspace file — so this reported "export is
    OFF" about a workspace whose ``.env`` configures it, which is worse than
    no answer. The workspace resolver is what loads that file, and every
    command that opens a store passes through it; this one opens nothing, so
    it has to ask.
    """
    try:
        from ioagentfarm.cli import _workspace_code
        _workspace_code(required=False)
    except Exception:  # noqa: BLE001 - a diagnostic must still run unconfigured
        pass


class _Capture(logging.Handler):
    """Collect what the OTLP exporter logs — that is where the status is."""

    def __init__(self) -> None:
        super().__init__(level=logging.DEBUG)
        self.records: list[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.records.append(record.getMessage())
        except Exception:  # noqa: BLE001
            pass


@app.command("check")
def check(
    send: bool = typer.Option(
        True, "--send/--no-send",
        help="Post one real test span and report what the backend answered."),
    timeout: int = typer.Option(20, "--timeout", help="Seconds to wait for the export."),
):
    """Report the telemetry configuration, and prove a span reaches the backend."""
    _adopt_workspace_env()
    from ioagentfarm.engine import otel_export as otel

    table = Table(show_header=False, box=None)

    if not otel.available():
        console.print("[red]The OpenTelemetry SDK is not installed.[/red]")
        # `markup=False`: Rich reads `[otel]` as a style tag and DELETES it,
        # so this printed `pip install 'agentfarm-core'` - an instruction to
        # install what the reader already has, with the only part that fixes
        # anything removed. A remediation line that is silently edited by the
        # renderer is worse than none.
        console.print("  fix: pip install 'agentfarm-core[otel]'  "
                      "(use the engine distribution name your organisation "
                      "publishes)", markup=False)
        raise typer.Exit(code=1)

    kind = otel.exporter_kind()
    if not kind:
        console.print("[yellow]Telemetry export is OFF.[/yellow]")
        console.print("  Set OTEL_EXPORTER_OTLP_ENDPOINT to the base URL of your "
                      "collector to turn it on, e.g.")
        console.print("    OTEL_EXPORTER_OTLP_ENDPOINT=https://your-phoenix-host")
        console.print("  The engine reads it from the workspace's own .env "
                      "(`aicore current` names the file), the process "
                      "environment, or the container's configuration.")
        raise typer.Exit(code=2)

    table.add_row("export", f"[green]on[/green] ({kind})")
    table.add_row("service.name", os.environ.get("OTEL_SERVICE_NAME") or "aicore")

    traces_ep, traces_note = otel.resolved_endpoint("traces")
    if kind == "otlp":
        table.add_row("traces ->", traces_ep or "(unresolved)")
        if otel.metrics_enabled():
            m_ep, _ = otel.resolved_endpoint("metrics")
            table.add_row("metrics ->", m_ep or "(unresolved)")
        else:
            table.add_row("metrics", "off (OTEL_METRICS_EXPORTER=none)")
        names = otel.configured_header_names()
        table.add_row("headers", ", ".join(names) if names else "[dim]none[/dim]")

    console.print(table)

    if traces_note:
        console.print()
        console.print(f"[yellow]note[/yellow] {traces_note}")

    if kind != "otlp":
        console.print()
        console.print(f"Exporter '{kind}' writes locally; nothing is sent to a backend.")
        raise typer.Exit(code=0)

    if not send:
        raise typer.Exit(code=0)

    # ---- actually send one span -------------------------------------------
    console.print()
    console.print(f"Sending one test span to {traces_ep} …")

    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

    cap = _Capture()
    exporter_log = logging.getLogger("opentelemetry.exporter.otlp.proto.http.trace_exporter")
    root_otel = logging.getLogger("opentelemetry")
    for lg in (exporter_log, root_otel):
        lg.addHandler(cap)
        lg.setLevel(logging.DEBUG)

    ok = False
    try:
        exporter = OTLPSpanExporter(endpoint=traces_ep, timeout=timeout)
        provider = TracerProvider(
            resource=Resource.create({
                "service.name": os.environ.get("OTEL_SERVICE_NAME") or "aicore"}),
            shutdown_on_exit=False)
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        tracer = provider.get_tracer("aicore.otel.check")
        with tracer.start_as_current_span("aicore.otel.check") as span:
            span.set_attribute("aicore.check", True)
            span.set_attribute("openinference.span.kind", "CHAIN")
        ok = provider.force_flush(timeout_millis=timeout * 1000)
        provider.shutdown()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]send failed[/red] {type(exc).__name__}: {exc}")
        _advise(cap.records, traces_ep)
        raise typer.Exit(code=1)
    finally:
        for lg in (exporter_log, root_otel):
            lg.removeHandler(cap)

    failures = [r for r in cap.records
                if "Failed to export" in r or "failed" in r.lower() or "error" in r.lower()]
    if failures or not ok:
        console.print("[red]The span was NOT accepted.[/red]")
        for line in failures[:4]:
            console.print(f"  {line}")
        _advise(cap.records, traces_ep)
        raise typer.Exit(code=1)

    # Plain text on purpose: with markup=False the tags printed LITERALLY -
    # `[green]Accepted.[/green] One span named ...` reached the operator
    # verbatim (seen while walking the tracing guide, 2026-09-02).
    console.print("Accepted. One span named `aicore.otel.check` was "
                  "delivered - look for it in your backend to confirm the "
                  "project and credentials are the ones you expect.",
                  markup=False)

    # SAY WHETHER MESSAGE BODIES ARE LEAVING. This command is documented as
    # "report the telemetry configuration" and said nothing about the one
    # switch with a disclosure consequence: a deployment could be shipping
    # customer text to a vendor and every diagnostic here looked identical.
    # A validator had to decode the wire to find out.
    from ioagentfarm.engine.otel_export import content_enabled
    if content_enabled():
        console.print(
            "[yellow]IOF_OTEL_CONTENT is ON: message bodies, tool arguments "
            "and tool results are exported to this endpoint. Turn it off "
            "unless your deployment has agreed to send customer text to this "
            "backend.[/yellow]")
    else:
        console.print(
            "[dim]Content export is OFF (the default): lengths and digests "
            "only, no message bodies. IOF_OTEL_CONTENT=1 opts in.[/dim]")

    # AND WHETHER METRICS GO SOMEWHERE ELSE. The check probes TRACES only, so
    # a broken metrics endpoint got a clean bill from the command whose own
    # troubleshooting names that failure.
    try:
        from ioagentfarm.engine.otel_export import metrics_enabled, resolved_endpoint
        if metrics_enabled():
            m_ep, _ = resolved_endpoint("metrics")
            if m_ep and m_ep != traces_ep:
                console.print(
                    f"[dim]Metrics go to a different endpoint ({m_ep}) and "
                    f"were NOT probed by this check. Set "
                    f"OTEL_METRICS_EXPORTER=none if this deployment sends "
                    f"traces only.[/dim]")
    except Exception:  # noqa: BLE001 - a report must not fail the check
        pass


def _advise(records: list[str], endpoint: Optional[str]) -> None:
    """Turn the backend's answer into the next thing to do."""
    blob = " ".join(records).lower()
    console.print()
    if "404" in blob:
        console.print("[yellow]404[/yellow] — the collector has no route at that URL.")
        console.print("  Most often the endpoint carries the signal path twice. "
                      "OTEL_EXPORTER_OTLP_ENDPOINT is a BASE; the exporter "
                      "appends /v1/traces itself.")
    elif "401" in blob or "403" in blob:
        console.print("[yellow]401/403[/yellow] — reached the collector, credential refused.")
        dropped = _headers_that_do_not_parse()
        if dropped:
            # THE FIRST THING TO CHECK, because it presents as a bad key.
            console.print(
                "  [red]OTEL_EXPORTER_OTLP_HEADERS is set and parses to "
                "NOTHING[/red], so every span was sent with no credential at "
                "all. Values are URL-encoded: a literal space makes the SDK "
                "reject the whole string.")
            console.print(
                "    write  Authorization=Bearer%20<token>   (%20, not a space)")
        else:
            console.print("  Set OTEL_EXPORTER_OTLP_HEADERS, e.g. "
                          "`api_key=<key>` (Phoenix) or "
                          "`Authorization=Bearer%20<token>` — the value is "
                          "URL-ENCODED, so the space after `Bearer` is `%20`; "
                          "written literally the header is dropped in full. "
                          "Names are backend-specific and case-sensitive.")
    elif "422" in blob or "415" in blob:
        console.print("[yellow]415/422[/yellow] — the collector refused the payload "
                      "shape. This exporter speaks OTLP/HTTP protobuf; check "
                      "the endpoint is the OTLP route and not a UI URL.")
    elif "timeout" in blob or "timed out" in blob:
        console.print("[yellow]timeout[/yellow] — nothing answered. Check egress "
                      "from this host, and that the host name resolves here.")
    elif "name or service not known" in blob or "getaddrinfo" in blob or "nodename" in blob:
        console.print("[yellow]DNS[/yellow] — the host name does not resolve from this machine.")
    else:
        console.print("The backend did not accept the span. The exporter's own "
                      "lines are above; they carry the HTTP status.")
    if endpoint:
        console.print(f"  endpoint tried: {endpoint}")


@app.command("env")
def env():
    """Show the OTEL_* configuration in force for this workspace, values masked."""
    # THE SAME ADOPTION `check` DOES, for the same reason and one it learned
    # the hard way: without it this command reads the SHELL while the engine
    # reads the workspace's `.env`, so on a correctly configured workspace it
    # reported "No OTEL_* variables are set" while `otel check`, run in the
    # same shell one line later, reported export ON. Two diagnostics
    # contradicting each other is worse than either being absent - the reader
    # cannot tell which to believe, and the one that is wrong is the one that
    # says nothing is configured.
    _adopt_workspace_env()
    rows = sorted((k, v) for k, v in os.environ.items() if k.startswith("OTEL_"))
    if not rows:
        console.print("[yellow]No OTEL_* variables are set in this process.[/yellow]")
        console.print("  A variable set in a shell does not reach a service started "
                      "elsewhere; `aicore current` names the .env this workspace reads.")
        raise typer.Exit(code=2)
    t = Table(show_header=True, header_style="bold")
    t.add_column("variable")
    t.add_column("value")
    for k, v in rows:
        t.add_row(k, _mask(v) if "HEADER" in k or "KEY" in k or "TOKEN" in k else v)
    console.print(t)


def _headers_that_do_not_parse() -> str | None:
    """The raw value when it is set and yields no headers, else None.

    Returns the RAW STRING rather than a bool so a caller could show it - it
    is a header name plus a token, and printing a credential is never worth
    it, so no caller does. The distinction that matters is set-and-empty
    versus not-set: unset is a deployment with no credential, which is a
    different conversation.
    """
    import os

    raw = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS") or ""
    if not raw.strip():
        return None
    try:
        from opentelemetry.util.re import parse_env_headers
    except Exception:  # noqa: BLE001 - the SDK is an extra
        return None
    try:
        parsed = parse_env_headers(raw)
    except Exception:  # noqa: BLE001 - a refusal IS the finding
        return raw
    return None if parsed else raw

