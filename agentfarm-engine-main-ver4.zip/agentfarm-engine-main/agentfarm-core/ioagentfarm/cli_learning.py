"""Learning-governance CLI — the interim steward review workflow.

The learning pipeline is draft-inert: an agent-authored skill is a DRAFT until
a human approves it, and only an approved skill ever reaches another agent. The
enforcement was always there; this is the surface a reviewer uses to exercise
it, until the enterprise steward console lands. Mounted at::

    aicore learning pending                 # the review queue
    aicore learning show <id>               # full body + evidence + scan
    aicore learning approve <id> --as <who> [--commit]
    aicore learning reject  <id> --as <who> --reason "..."
    aicore learning audit                   # the decision trail

Backend-agnostic (stub files or the temp_hub http endpoints). Every decision is
appended to ``hub_audit.jsonl``; a DANGEROUS skill cannot be approved. Point
``IOF_LEARNING_INBOX_DIR`` at a git checkout and pass ``--commit`` to make each
approval a reviewed commit / PR — an audit trail with an approver identity.
"""
from __future__ import annotations

import json
import os

import typer
from rich.console import Console
from rich.table import Table



class _LazyGovernance:
    """`governance` on first use - it costs ~110ms to import and only the
    learning subcommands need it, yet every `aicore` invocation paid it."""

    def __getattr__(self, name: str):
        from ioagentfarm.engine.learning import governance
        return getattr(governance, name)


gov = _LazyGovernance()

learning_app = typer.Typer(
    name="learning",
    help="Review, approve and reject agent-authored learning drafts.",
    no_args_is_help=True,
)

_console = Console()


def _default_approver() -> str:
    # A best-effort identity so the audit trail is never blank; --as overrides.
    return (os.environ.get("IOF_REVIEWER") or os.environ.get("USERNAME")
            or os.environ.get("USER") or "unknown")


def _verdict_style(v: str) -> str:
    return {"dangerous": "bold red", "caution": "yellow", "clean": "green"}.get(v, "white")


@learning_app.command("pending")
def pending(as_json: bool = typer.Option(False, "--json", help="machine-readable")):
    """List every draft awaiting a decision."""
    drafts = gov.pending()
    if as_json:
        print(json.dumps([d.to_dict() for d in drafts], default=str))
        return
    if not drafts:
        _console.print("[green]No drafts pending review.[/green] "
                       "Nothing is waiting to reach an agent.")
        return
    t = Table(title=f"Learning drafts pending review ({len(drafts)})")
    t.add_column("id", style="cyan", no_wrap=True)
    t.add_column("skill")
    t.add_column("type")
    t.add_column("scope")
    t.add_column("evidence")
    t.add_column("scan")
    for d in drafts:
        ev = d.evidence or {}
        apps = ev.get("applications", 0)
        rate = ev.get("completion_rate")
        ev_s = f"{apps} appl" + (f", {rate:.0%}" if isinstance(rate, (int, float)) else "")
        t.add_row(d.ident, d.skill_name, d.skill_type,
                  f"{d.scope_role}::{d.scope_workflow}", ev_s or "-",
                  f"[{_verdict_style(d.security_scan.get('verdict','?'))}]"
                  f"{d.security_scan.get('verdict','?')}[/]")
    _console.print(t)
    _console.print("\nReview one:  [cyan]aicore learning show <id>[/cyan]   "
                   "then  [cyan]approve <id> --as <you>[/cyan]  or  "
                   "[cyan]reject <id> --as <you> --reason ...[/cyan]")


@learning_app.command("show")
def show(ident: str = typer.Argument(..., help="draft id from `pending`")):
    """Show a draft's full body, why it was authored, its measured evidence
    and its security-scan findings — everything needed to decide."""
    d = gov.show(ident)
    if d is None:
        _console.print(f"[red]No pending draft addressed by {ident!r}.[/red]")
        raise typer.Exit(1)
    _console.print(f"[bold]{d.skill_name}[/bold]  ({d.skill_type}, {d.action})")
    _console.print(f"scope   : {d.scope_role}::{d.scope_workflow}")
    if d.thoughts:
        _console.print(f"why     : {d.thoughts}")
    ev = d.evidence or {}
    if ev:
        _console.print(f"evidence: {json.dumps(ev)}")
    v = d.security_scan.get("verdict", "?")
    _console.print(f"scan    : [{_verdict_style(v)}]{v}[/]")
    for f in d.security_scan.get("findings", []):
        _console.print(f"          - {f.get('severity')}: {f.get('category')} "
                       f"[{f.get('excerpt','')}]")
    if v == "dangerous":
        _console.print("[bold red]This draft is DANGEROUS and cannot be "
                       "approved. Reject it.[/bold red]")
    _console.print("\n[dim]--- SKILL.md ---[/dim]")
    _console.print(d.skill_md)


@learning_app.command("approve")
def approve(
    ident: str = typer.Argument(..., help="draft id from `pending`"),
    approver: str = typer.Option(None, "--as", help="who is approving (audit)"),
    commit: bool = typer.Option(False, "--commit",
                                help="git-commit the approval (git-backed inbox)"),
    note: str = typer.Option("", "--note", help="reviewer note (audited)"),
):
    """Approve a draft so agents in its scope receive it. Refused if the
    security scan is DANGEROUS."""
    who = approver or _default_approver()
    try:
        res = gov.approve(ident, approver=who, commit=commit, note=note)
    except gov.ReviewError as exc:
        _console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)
    line = f"[green]APPROVED[/green] {ident} by {who}"
    if res.get("skill_id"):
        line += f"  -> {res['skill_id']}"
    if res.get("commit"):
        line += f"  (committed {res['commit'][:9]})"
    _console.print(line)
    if res.get("backend") == "stub" and not res.get("commit"):
        _console.print("[dim]Approved into the inbox. It reaches agents on "
                       "their next run/warmup.[/dim]")


@learning_app.command("reject")
def reject(
    ident: str = typer.Argument(..., help="draft id from `pending`"),
    approver: str = typer.Option(None, "--as", help="who is rejecting (audit)"),
    reason: str = typer.Option("", "--reason", help="why (audited)"),
):
    """Reject a draft. It never reaches an agent; the decision is audited."""
    who = approver or _default_approver()
    try:
        gov.reject(ident, approver=who, reason=reason)
    except gov.ReviewError as exc:
        _console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)
    _console.print(f"[yellow]REJECTED[/yellow] {ident} by {who}"
                   + (f"  ({reason})" if reason else ""))


@learning_app.command("distill", hidden=True)
def distill(job: str = typer.Argument(..., help="job file written by the finalizer")):
    """Internal: author a learned method from a job file (detached from a run)."""
    from ioagentfarm.engine.learning.hooks import author_from_job
    n = author_from_job(job)
    print(json.dumps({"job": job, "submitted": n}))


@learning_app.command("audit")
def audit(limit: int = typer.Option(30, "--limit"),
          as_json: bool = typer.Option(False, "--json")):
    """The approval/rejection trail — who decided what, and when."""
    rows = gov.audit_log(limit=limit)
    if as_json:
        print(json.dumps(rows, default=str))
        return
    if not rows:
        _console.print("[dim]No review decisions recorded yet.[/dim]")
        return
    t = Table(title=f"Learning review audit (last {len(rows)})")
    t.add_column("at", style="dim", no_wrap=True)
    t.add_column("event")
    t.add_column("skill")
    t.add_column("by")
    t.add_column("detail")
    for r in rows:
        detail = r.get("skill_id") or r.get("reason") or r.get("commit") or ""
        ev = r.get("event", "")
        style = {"approve": "green", "reject": "yellow",
                 "approve_refused": "red"}.get(ev, "white")
        t.add_row(str(r.get("at", ""))[:19], f"[{style}]{ev}[/]",
                  r.get("skill_name", ""), r.get("approver", ""), str(detail))
    _console.print(t)
