"""Document extractor for contract ingestion pipeline.

Two modes:

  --scan        Discover documents under --docs-dir, infer doc_type per file,
                write docs_manifest.json, and print STORIES_JSON for the
                ioagentfarm story-loop engine.  NO LLM call.

  --finalize-dir  Collect per-document *_extracted.json files written by
                  doc_ingestor story steps, apply type coercion, and write
                  wide-row CSVs per schema.  NO LLM call.

Architecture note: LLM reasoning for field extraction is done by the
doc_ingestor iobot agent inside per-story steps (story:*:extract).
This CLI is a pure data tool — file I/O, type coercion, CSV assembly only.

Supports 5 document types:
  msa        -> contract_master table (framework contracts)
  sow        -> contract_master table (statements of work)
  work_order -> execution_documents table (work orders)
  po         -> execution_documents table (purchase orders)
  paybill    -> paybill_records table (payment records)
  auto       -> infer from filename prefix (default)
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

# .env loading — walk up from CWD so tool finds project .env regardless of
# what directory iobot sets as the agent's working directory.
load_dotenv(override=False)
_p = Path.cwd()
while True:
    _candidate = _p / ".env"
    if _candidate.is_file():
        load_dotenv(str(_candidate), override=False)
        break
    _parent = _p.parent
    if _parent == _p:
        break
    _p = _parent
# ~/.iobot/.env first, then the legacy ~/.env, then the pod's /app/.env.
# override=False, so the first hit wins and precedence is unchanged.
from ioagentfarm.engine.home_env import home_env_candidates
for _candidate in home_env_candidates():
    if _candidate.exists():
        load_dotenv(_candidate, override=False)


# ---------------------------------------------------------------------------
# Schema → expected CSV columns
# ---------------------------------------------------------------------------
CONTRACT_MASTER_COLUMNS = [
    "contract_id", "vendor", "document_type", "parent_contract_id",
    "clause_overrides",
    "contract_intent", "extraction_insight", "contract_status", "contract_type",
    "effective_date", "end_date", "tcv_usd", "currency",
    "sourcing_category", "sub_category", "vendor_tier", "preferred_vendor_status",
    "sourcing_method", "contract_owner", "bu", "region",
    "payment_terms_net", "liability_cap_usd", "liability_cap_type",
    "early_termination_fee_usd", "price_escalation_clause", "price_escalation_pct",
    "most_favored_nation_clause", "volume_discount_tiers", "rebate_pct",
    "invoice_dispute_window_days", "edp_commitment_total_usd",
    "indemnity_cap_usd", "consequential_damages_exclusion",
    "governing_law", "jurisdiction", "dispute_resolution", "arbitration_venue",
    "force_majeure_clause", "change_of_control_clause", "assignment_restriction",
    "entire_agreement_clause", "insurance_minimum_usd",
    "termination_notice_days", "termination_notice_type",
    "auto_renewal", "auto_renewal_notice_days",
    "survival_period_years", "reverse_transition_days",
    "data_protection_term_years", "data_residency_countries",
    "security_framework", "audit_notice_days",
    "has_right_to_audit", "penetration_test_required",
    "non_solicitation_period_months", "key_personnel_clause", "dedicated_fte_count",
    "sla_uptime_pct", "sla_response_time_hours", "sla_resolution_time_hours",
    "sla_credit_pct", "source_code_escrow", "offboarding_timeline_days",
    "rate_card_count", "avg_rate_usd",
    "has_ai_council_clause", "has_gxp_clause", "has_data_sovereignty_clause",
    "has_ip_assignment", "has_non_solicitation", "has_exclusivity",
    # SaaS / Commercial pricing
    "pricing_lock_in_clause", "line_item_pricing", "price_hold_future_products",
    "pricing_metric_change_protection", "bundling_protection", "exchange_rights",
    "variable_pricing_model", "pricing_metric", "renewal_price_cap_pct",
    "innovation_index_fee_pct", "payment_holiday_days", "sandbox_fee_charged",
    # SaaS / Commercial usage & storage
    "storage_reporting_required", "storage_limit_gb", "usage_reporting_frequency",
    # Payment & dispute
    "suspension_dispute_protection",
    # Data governance
    "data_confidentiality_clause", "oss_disclosure_required", "oss_license_types",
    "breach_notification_hours", "data_access_post_termination_days",
    "subprocessor_list_disclosed", "subprocessor_change_notice_days",
    "supply_chain_audit_right", "data_destruction_confirmation",
    "portability_api_required", "data_return_window_days", "data_return_format",
    "hipaa_baa_included", "gdpr_dpa_included",
    # SLA / Operations
    "termination_for_sla_miss", "sla_scheduled_downtime_excluded",
    "escalation_process_defined", "bcp_required",
    "disaster_recovery_rto_hours", "disaster_recovery_rpo_hours", "dr_test_frequency_months",
    "service_credit_proactive", "service_credit_cap_pct", "service_credit_claim_window_days",
    "sla_reporting_frequency", "dedicated_support_engineer", "support_hours_type",
    # Governance & oversight
    "qbr_required", "qbr_frequency_months", "subcontractor_approval_required",
    "client_local_software_dependency", "url_terms_protection", "functionality_locked",
    "regulatory_change_cost_allocation", "notice_method", "provider_renewal_notice_days",
    # Warranty
    "warranty_fitness_for_purpose", "warranty_non_infringement",
    "backward_compatibility_required", "warranty_period_months", "warranty_remedy_type",
    # API lifecycle
    "api_deprecation_notice_months", "min_version_support_months",
    "benchmarking_right", "benchmarking_frequency",
    # Insurance (extended)
    "cyber_insurance_usd", "professional_indemnity_usd",
    # Liability (extended)
    "liability_uncapped_ip_breach", "liability_uncapped_confidentiality",
    "liability_uncapped_fraud", "liability_cap_mutual", "force_majeure_excludes_sla",
    # Extraction metadata
    "source_file", "extraction_confidence", "extracted_at",
]

EXECUTION_DOCUMENTS_COLUMNS = [
    "doc_id", "vendor", "document_type", "parent_contract_id",
    "scope_summary", "total_value_usd", "start_date", "end_date",
    "resource_count", "rate_usd", "status",
    "source_file", "extraction_confidence", "extracted_at",
]

PAYBILL_RECORDS_COLUMNS = [
    "paybill_id", "vendor", "contract_id", "sow_id",
    "invoice_date", "payment_date", "amount_usd",
    "invoice_number", "po_reference", "payment_status",
    "source_file", "extraction_confidence", "extracted_at",
]

SCHEMA_COLUMNS: Dict[str, List[str]] = {
    "contract_master": CONTRACT_MASTER_COLUMNS,
    "execution_documents": EXECUTION_DOCUMENTS_COLUMNS,
    "paybill_records": PAYBILL_RECORDS_COLUMNS,
}

# ---------------------------------------------------------------------------
# Type coercion maps — DB schema types per column
# Agents often return "thirty (30) days" or "$1,500,000" — coerce before write.
# ---------------------------------------------------------------------------

# INTEGER columns
_INT_COLUMNS: set = {
    "payment_terms_net", "volume_discount_tiers", "invoice_dispute_window_days",
    "termination_notice_days", "auto_renewal_notice_days", "reverse_transition_days",
    "audit_notice_days", "non_solicitation_period_months", "dedicated_fte_count",
    "sla_response_time_hours", "sla_resolution_time_hours", "offboarding_timeline_days",
    "rate_card_count", "resource_count",
}

# DECIMAL / FLOAT columns
_DECIMAL_COLUMNS: set = {
    "tcv_usd", "liability_cap_usd", "early_termination_fee_usd", "price_escalation_pct",
    "rebate_pct", "edp_commitment_total_usd", "indemnity_cap_usd", "insurance_minimum_usd",
    "survival_period_years", "data_protection_term_years", "sla_uptime_pct",
    "sla_credit_pct", "avg_rate_usd", "total_value_usd", "amount_usd",
    "rate_usd", "extraction_confidence",
}

# BOOLEAN columns
_BOOL_COLUMNS: set = {
    "price_escalation_clause", "most_favored_nation_clause", "consequential_damages_exclusion",
    "force_majeure_clause", "change_of_control_clause", "assignment_restriction",
    "entire_agreement_clause", "auto_renewal", "has_right_to_audit",
    "penetration_test_required", "key_personnel_clause", "source_code_escrow",
    "has_ai_council_clause", "has_gxp_clause", "has_data_sovereignty_clause",
    "has_ip_assignment", "has_non_solicitation", "has_exclusivity",
}

_TRUTHY = {"true", "yes", "1", "y", "t"}
_FALSY = {"false", "no", "0", "n", "f"}


def _extract_first_number(val: str) -> Optional[str]:
    """Pull first integer or decimal from a string like 'thirty (30) days' -> '30'."""
    m = re.search(r"[\d,]+(?:\.\d+)?", val.replace(",", ""))
    return m.group(0).replace(",", "") if m else None


def coerce_row_types(row: Dict[str, Any]) -> Dict[str, Any]:
    """Coerce extracted field values to DB-compatible types.

    Handles common agent output patterns:
    - "thirty (30) days"  -> 30          (INTEGER)
    - "$1,500,000"        -> 1500000.0   (DECIMAL)
    - "yes" / "true"      -> True        (BOOLEAN)
    - ""                  -> None        (any)
    """
    out = {}
    for col, val in row.items():
        if val is None or val == "":
            out[col] = None
            continue

        if col in _INT_COLUMNS:
            if isinstance(val, bool):
                out[col] = None  # boolean in int column — bad extraction
            elif isinstance(val, int):
                out[col] = val
            elif isinstance(val, float):
                out[col] = int(val)
            else:
                n = _extract_first_number(str(val))
                out[col] = int(float(n)) if n is not None else None

        elif col in _DECIMAL_COLUMNS:
            if isinstance(val, bool):
                out[col] = None
            elif isinstance(val, (int, float)):
                out[col] = float(val)
            else:
                s = re.sub(r"[^\d.]", "", str(val).replace(",", ""))
                try:
                    out[col] = float(s) if s else None
                except ValueError:
                    out[col] = None

        elif col in _BOOL_COLUMNS:
            if isinstance(val, bool):
                out[col] = val
            elif isinstance(val, int):
                out[col] = bool(val)
            else:
                s = str(val).strip().lower()
                if s in _TRUTHY:
                    out[col] = True
                elif s in _FALSY:
                    out[col] = False
                else:
                    out[col] = None  # "not mentioned" / ambiguous

        else:
            out[col] = val

    return out


# Doc type -> canonical schema
# Amendments modify framework contracts (MSA/SOW terms) → contract_master, not execution_documents
DOC_TYPE_SCHEMA: Dict[str, str] = {
    "msa": "contract_master",
    "sow": "contract_master",
    "amendment": "contract_master",   # amendments modify framework contract terms
    "work_order": "execution_documents",
    "po": "execution_documents",
    "paybill": "paybill_records",
}

# Filename prefix hints for auto doc-type detection.
# Evaluated after delimiter normalization (hyphens/spaces → underscores).
DOC_TYPE_PREFIXES = [
    ("paybill",    "paybill"),
    ("amendment",  "amendment"),           # full word — must precede msa/sow
    ("amendment",  "_amd"),                # AMD abbreviation: WD-MSA-2024-001-AMD-001
    ("amendment",  "_amend"),              # amend variant
    ("work_order", "work_order"),
    ("work_order", "wo_"),
    ("po",         "purchase_order"),
    ("po",         "po_"),
    ("sow",        "sow_"),                # matches -sow- after hyphen normalization
    ("sow",        "statement_of_work"),
    ("msa",        "msa_"),                # matches -msa- after hyphen normalization
    ("msa",        "master_service"),
    ("msa",        "master_subscription"),
    ("msa",        "enterprise_agreement"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def slugify(name: str) -> str:
    s = name.lower().strip()
    s = re.sub(r"[&]+", "and", s)
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s


def infer_doc_type(filename: str) -> str:
    # Normalize delimiters so hyphen-separated names (WD-SOW-2024-001)
    # match the same underscore-based prefixes as underscore-separated names.
    stem = filename.lower().replace("-", "_").replace(" ", "_")
    for doc_type, prefix in DOC_TYPE_PREFIXES:
        if stem.startswith(prefix) or prefix in stem:
            return doc_type
    return "msa"  # default fallback for unknown


def _extract_version(filename: str) -> str:
    """Extract version tag from filename, e.g. 'msa_v2.pdf' -> 'v2'."""
    m = re.search(r"[_\-\.]v(\d+(?:\.\d+)?)", filename.lower())
    return f"v{m.group(1)}" if m else ""


def make_contract_id(vendor_slug: str, source_file: str, content: str = "") -> str:
    """Stable contract_id derived from vendor + filename + version + content hash.

    Same vendor + same filename + same version + same content -> same ID -> upsert no-op.
    New version OR changed content -> new ID -> new row inserted.
    """
    fname = Path(source_file).name
    version = _extract_version(fname)
    content_hash = hashlib.sha1(content.encode(errors="replace")).hexdigest()[:8] if content else "00000000"
    payload = f"{vendor_slug}::{fname}::{version}::{content_hash}"
    return "cid-" + hashlib.sha1(payload.encode()).hexdigest()[:16]


def story_id_for(filename: str) -> str:
    """Deterministic story_id from filename: 'doc_' + sha1(filename)[:8]."""
    return "doc_" + hashlib.sha1(filename.encode()).hexdigest()[:8]


def find_documents(docs_dir: Path, only_slugs: Optional[List[str]] = None) -> List[Path]:
    """Find all supported documents under docs_dir, optionally filtered by vendor slug."""
    supported = {".docx", ".pdf", ".txt"}
    docs = []
    for p in sorted(docs_dir.rglob("*")):
        if p.is_file() and p.suffix.lower() in supported:
            if only_slugs:
                stem_lower = p.stem.lower()
                if not any(slug in stem_lower for slug in only_slugs):
                    continue
            docs.append(p)
    return docs


# ---------------------------------------------------------------------------
# Row assembly
# ---------------------------------------------------------------------------
def assemble_row(
    extracted: Dict[str, Any],
    schema: str,
    doc_type: str,
    source_file: str,
    vendor_slug: str,
    content: str = "",
) -> Dict[str, Any]:
    """Merge extracted fields with computed fields. Returns wide-row dict."""
    from datetime import datetime, timezone

    columns = SCHEMA_COLUMNS[schema]
    row: Dict[str, Any] = {col: None for col in columns}

    # Overlay extracted fields
    for col in columns:
        val = extracted.get(col)
        if val is not None:
            row[col] = val

    # Always-populated computed fields
    row["source_file"] = source_file
    row["extracted_at"] = datetime.now(timezone.utc).isoformat()

    if not row.get("vendor"):
        row["vendor"] = vendor_slug

    # Normalize vendor to slug
    if row.get("vendor"):
        row["vendor"] = slugify(str(row["vendor"]))

    # Stable ID generation if not extracted
    if schema == "contract_master":
        row["document_type"] = doc_type
        if not row.get("contract_id"):
            row["contract_id"] = make_contract_id(row["vendor"] or vendor_slug, source_file, content=content)
    elif schema == "execution_documents":
        row["document_type"] = doc_type
        if not row.get("doc_id"):
            row["doc_id"] = make_contract_id(row["vendor"] or vendor_slug, source_file, content=content)
    elif schema == "paybill_records":
        if not row.get("paybill_id"):
            row["paybill_id"] = make_contract_id(row["vendor"] or vendor_slug, source_file, content=content)

    # Confidence default
    if row.get("extraction_confidence") is None:
        row["extraction_confidence"] = 0.5

    # Coerce types to match DB schema (int/decimal/bool) before serializing.
    row = coerce_row_types(row)

    # Serialize list/dict values to JSON strings for CSV
    for col in columns:
        val = row.get(col)
        if isinstance(val, (list, dict)):
            row[col] = json.dumps(val)

    return row


# ---------------------------------------------------------------------------
# Scan mode — discover docs, write manifest, output STORIES_JSON
# ---------------------------------------------------------------------------
def cmd_scan(args: argparse.Namespace) -> None:
    """Scan docs_dir, write docs_manifest.json, print STORIES_JSON for story-loop engine."""
    docs_dir = Path(args.docs_dir)
    if not docs_dir.is_dir():
        print(json.dumps({"success": False, "error": f"docs-dir not found: {args.docs_dir}"}))
        sys.exit(1)

    only_slugs = [s.strip() for s in args.only.split(",")] if args.only else None
    documents = find_documents(docs_dir, only_slugs)

    if not documents:
        print(json.dumps({
            "success": True,
            "docs_found": 0,
            "stories": [],
            "note": "No supported documents found under docs-dir.",
        }))
        sys.exit(0)

    output_dir = Path(args.output_dir) if args.output_dir else Path(".")
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest: Dict[str, Any] = {}
    stories: List[Dict[str, Any]] = []

    for doc_path in documents:
        filename = doc_path.name
        doc_type = (
            args.doc_type if args.doc_type != "auto" else infer_doc_type(doc_path.stem)
        )
        schema = DOC_TYPE_SCHEMA.get(doc_type, "contract_master")
        vendor_slug = slugify(doc_path.stem.split("_")[0])
        sid = story_id_for(filename)

        manifest[sid] = {
            "story_id": sid,
            "source_file": str(doc_path).replace("\\", "/"),
            "filename": filename,
            "doc_type": doc_type,
            "schema": schema,
            "vendor_slug": vendor_slug,
        }

        stories.append({
            "id": sid,
            "title": f"Extract {filename}",
            "details": f"{doc_type} document at {doc_path.as_posix()}",
            "acceptance_criteria": [
                f"Extraction JSON written to <output_dir>/{sid}_extracted.json",
                f"All critical fields extracted or set to null (never fabricated)",
                f"extraction_confidence set between 0.0 and 1.0",
            ],
        })

    # Write manifest for story extract steps to read
    manifest_path = output_dir / "docs_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"  manifest: {manifest_path}", file=sys.stderr)

    result = {
        "success": True,
        "docs_found": len(documents),
        "manifest": str(manifest_path).replace("\\", "/"),
        "stories": stories,
    }
    print(json.dumps(result))
    sys.exit(0)


# ---------------------------------------------------------------------------
# Finalize mode — collect *_extracted.json, coerce types, write CSVs
# ---------------------------------------------------------------------------
def cmd_finalize(args: argparse.Namespace) -> None:
    """Read *_extracted.json files from --finalize-dir, assemble into schema CSVs."""
    finalize_dir = Path(args.finalize_dir)
    if not finalize_dir.is_dir():
        print(json.dumps({"success": False, "error": f"finalize-dir not found: {args.finalize_dir}"}))
        sys.exit(1)

    output_dir = Path(args.output_dir) if args.output_dir else finalize_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    # Find all *_extracted.json (skip docs_manifest.json itself)
    extracted_files = sorted(
        p for p in finalize_dir.glob("*_extracted.json")
        if p.name != "docs_manifest.json"
    )

    if not extracted_files:
        print(json.dumps({
            "success": True,
            "docs_found": 0,
            "rows_written": 0,
            "note": "No *_extracted.json files found in finalize-dir.",
        }))
        sys.exit(0)

    print(f"  found {len(extracted_files)} extraction file(s) in {finalize_dir}", file=sys.stderr)

    # Group rows by schema
    from collections import defaultdict as _defaultdict
    schema_rows: Dict[str, List[Dict[str, Any]]] = _defaultdict(list)
    errors: List[str] = []
    confidence_dist = {"high": 0, "medium": 0, "low": 0}

    for ef in extracted_files:
        try:
            data = json.loads(ef.read_text(encoding="utf-8"))
        except Exception as e:
            msg = f"Failed to read {ef.name}: {e}"
            print(f"  error: {msg}", file=sys.stderr)
            errors.append(msg)
            continue

        # _iof_meta carries doc metadata written by story extract step
        meta = data.pop("_iof_meta", {})
        source_file = meta.get("source_file", str(ef))
        doc_type = meta.get("doc_type", "msa")
        schema = meta.get("schema") or DOC_TYPE_SCHEMA.get(doc_type, "contract_master")
        vendor_slug = meta.get("vendor_slug", "unknown")

        try:
            row = assemble_row(
                extracted=data,
                schema=schema,
                doc_type=doc_type,
                source_file=source_file,
                vendor_slug=vendor_slug,
                content="",  # content hash not available at finalize time; ID uses filename-only hash
            )
            conf = float(row.get("extraction_confidence") or 0.5)
            if conf >= 0.8:
                confidence_dist["high"] += 1
            elif conf >= 0.5:
                confidence_dist["medium"] += 1
            else:
                confidence_dist["low"] += 1

            schema_rows[schema].append(row)
            rid = row.get("contract_id") or row.get("doc_id") or row.get("paybill_id")
            print(
                f"  ok: {ef.name} -> {schema}/{rid} (confidence={conf})",
                file=sys.stderr,
            )
        except Exception as e:
            msg = f"Failed to assemble row from {ef.name}: {e}"
            print(f"  error: {msg}", file=sys.stderr)
            errors.append(msg)

    if not schema_rows:
        print(json.dumps({
            "success": False,
            "error": "No rows assembled. Check extraction JSON files.",
            "errors": errors,
        }))
        sys.exit(1)

    # Write one CSV per schema
    schema_output_map = {
        "contract_master": "extracted_contract_master.csv",
        "execution_documents": "extracted_execution_documents.csv",
        "paybill_records": "extracted_paybill_records.csv",
    }

    rows_written = 0
    outputs: Dict[str, str] = {}

    for schema_name, rows in schema_rows.items():
        csv_name = schema_output_map.get(schema_name, f"extracted_{schema_name}.csv")
        out_path = output_dir / csv_name
        columns = SCHEMA_COLUMNS[schema_name]
        with open(out_path, "w", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
                rows_written += 1
        outputs[schema_name] = str(out_path).replace("\\", "/")
        print(f"  wrote {len(rows)} row(s) -> {out_path}", file=sys.stderr)

    result: Dict[str, Any] = {
        "success": True,
        "docs_found": len(extracted_files),
        "rows_written": rows_written,
        "outputs": outputs,
        "confidence": confidence_dist,
    }
    if errors:
        result["errors"] = errors
        result["success"] = len(errors) < len(extracted_files)
    print(json.dumps(result))
    sys.exit(0 if result["success"] else 1)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Document extractor for contract ingestion pipeline. "
            "Pure data tool — no LLM calls. "
            "Use --scan to discover docs and generate story backlog; "
            "use --finalize-dir to assemble doc_ingestor outputs into CSVs."
        ),
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument(
        "--scan",
        action="store_true",
        help="Scan --docs-dir, write docs_manifest.json, print STORIES_JSON for story-loop engine.",
    )
    mode.add_argument(
        "--finalize-dir",
        metavar="DIR",
        help=(
            "Directory containing *_extracted.json files written by doc_ingestor story steps. "
            "Reads those files, applies type coercion, writes per-schema CSVs to --output-dir."
        ),
    )

    # --scan args
    parser.add_argument("--docs-dir", default=None,
                        help="Directory containing PDF/DOCX files to ingest (required for --scan)")
    parser.add_argument("--doc-type", default="auto",
                        choices=["auto", "msa", "sow", "amendment", "work_order", "po", "paybill"],
                        help="Document type override (default: auto-detect from filename)")
    parser.add_argument("--only", default=None,
                        help="Comma-separated vendor slugs to restrict (e.g. microsoft,sap)")

    # Shared / --finalize-dir args
    parser.add_argument("--output-dir", default=None,
                        help="Output directory for CSVs (finalize) or manifest (scan)")

    args = parser.parse_args()

    if args.scan:
        if not args.docs_dir:
            print(json.dumps({"success": False, "error": "--docs-dir is required for --scan"}))
            sys.exit(1)
        cmd_scan(args)
    else:
        cmd_finalize(args)


if __name__ == "__main__":
    main()
