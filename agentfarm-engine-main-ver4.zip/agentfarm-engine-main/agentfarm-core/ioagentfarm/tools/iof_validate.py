"""DEPRECATED (2026-07-25): pharma domain logic stranded in core. Superseded by
solutions/pharma barrier_signal tools (iof-barrier-assess). Console entry removed;
file retained one release for reference, then deleted.
"""
"""iof-validate — traceability chain validator for pharma_goal deliverables.

Regex-parses intelligence_report.md and strategy_plan.md for SIG-XX,
BAR-XX, PLAY-XX, R-XX references. Builds the trace chain graph.
Reports gaps: orphan signals, orphan barriers, incomplete R-XX traces.

The reviewer agent calls this as its FIRST tool call to get an automated
traceability check, then focuses review time on clinical/financial/
feasibility lenses instead of manually walking chains.

Usage:
    iof-validate traceability \
      --intelligence-report intelligence_report.md \
      --strategy-plan strategy_plan.md \
      --output-dir /path/to/output

Output: JSON to stdout.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Set


# ---------------------------------------------------------------------------
# Reference extractors
# ---------------------------------------------------------------------------

_SIG_PAT = re.compile(r"SIG-[A-Z]{2}-\d{2}")
_BAR_PAT = re.compile(r"BAR-\d{2}")
_PLAY_PAT = re.compile(r"PLAY-[A-Z]{2}-\d{2}")
_R_PAT = re.compile(r"\bR-\d{2}\b")


def _extract_ids(text: str, pattern: re.Pattern) -> List[str]:
    """Extract all unique IDs matching pattern, in order of first appearance."""
    seen: set = set()
    result: list = []
    for m in pattern.finditer(text):
        val = m.group()
        if val not in seen:
            seen.add(val)
            result.append(val)
    return result


def _read_file(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------------------
# Traceability analysis
# ---------------------------------------------------------------------------

def analyze_traceability(
    intelligence_text: str,
    strategy_text: str,
) -> Dict[str, Any]:
    """Build the trace chain and report gaps."""

    # Extract all IDs from each document
    report_sigs = _extract_ids(intelligence_text, _SIG_PAT)
    report_bars = _extract_ids(intelligence_text, _BAR_PAT)
    strategy_sigs = _extract_ids(strategy_text, _SIG_PAT)
    strategy_bars = _extract_ids(strategy_text, _BAR_PAT)
    strategy_plays = _extract_ids(strategy_text, _PLAY_PAT)
    strategy_rs = _extract_ids(strategy_text, _R_PAT)

    # All unique IDs across both docs
    all_sigs = sorted(set(report_sigs + strategy_sigs))
    all_bars = sorted(set(report_bars + strategy_bars))
    all_plays = sorted(set(strategy_plays))
    all_rs = sorted(set(strategy_rs))

    # Orphan analysis
    # Signals in report but not referenced in strategy
    orphan_signals = [s for s in report_sigs if s not in set(strategy_sigs)]

    # Barriers in report but not referenced in strategy
    orphan_barriers = [b for b in report_bars if b not in set(strategy_bars)]

    # Plays in strategy with no signal or barrier backing
    # (harder to detect precisely — we check if the play appears near a SIG or BAR)
    plays_with_signal = set()
    for play in all_plays:
        # Check if any SIG appears within 500 chars of the play mention in strategy
        for m in re.finditer(re.escape(play), strategy_text):
            context = strategy_text[max(0, m.start() - 500):m.end() + 500]
            if _SIG_PAT.search(context) or _BAR_PAT.search(context):
                plays_with_signal.add(play)
                break
    orphan_plays = [p for p in all_plays if p not in plays_with_signal]

    # R-XX trace completeness: for each R-XX, check if SIG + BAR + PLAY
    # appear within 1000 chars context in the strategy
    trace_chains = []
    for r in all_rs:
        matches = list(re.finditer(re.escape(r), strategy_text))
        if not matches:
            trace_chains.append({
                "r": r, "sig": None, "bar": None, "play": None,
                "status": "NOT_FOUND"
            })
            continue

        # Use the first substantial mention (look for the largest context)
        best_context = ""
        for m in matches:
            ctx = strategy_text[max(0, m.start() - 1000):m.end() + 1500]
            if len(ctx) > len(best_context):
                best_context = ctx

        found_sigs = _extract_ids(best_context, _SIG_PAT)
        found_bars = _extract_ids(best_context, _BAR_PAT)
        found_plays = _extract_ids(best_context, _PLAY_PAT)

        has_sig = len(found_sigs) > 0
        has_bar = len(found_bars) > 0
        has_play = len(found_plays) > 0

        if has_sig and has_bar and has_play:
            status = "COMPLETE"
        elif has_sig and has_play and not has_bar:
            status = "MISSING_BAR"
        elif has_sig and has_bar and not has_play:
            status = "MISSING_PLAY"
        elif has_play and not has_sig:
            status = "MISSING_SIG"
        else:
            status = "INCOMPLETE"

        trace_chains.append({
            "r": r,
            "sig": found_sigs[:3] if found_sigs else None,
            "bar": found_bars[:3] if found_bars else None,
            "play": found_plays[:3] if found_plays else None,
            "status": status,
        })

    # Summary counts
    complete = sum(1 for t in trace_chains if t["status"] == "COMPLETE")
    incomplete = sum(1 for t in trace_chains if t["status"] != "COMPLETE")

    # Verdict
    if incomplete == 0 and not orphan_signals and not orphan_barriers:
        verdict = "PASS — all chains complete, no orphans"
    elif incomplete > 0:
        verdict = f"FAIL — {incomplete} incomplete trace chain(s)"
    else:
        verdict = f"WARN — chains complete but {len(orphan_signals)} orphan signal(s), {len(orphan_barriers)} orphan barrier(s)"

    return {
        "success": True,
        "summary": {
            "signals_in_report": len(report_sigs),
            "barriers_in_report": len(report_bars),
            "plays_in_strategy": len(all_plays),
            "recommendations": len(all_rs),
            "complete_chains": complete,
            "incomplete_chains": incomplete,
            "orphan_signals": len(orphan_signals),
            "orphan_barriers": len(orphan_barriers),
            "orphan_plays": len(orphan_plays),
        },
        "verdict": verdict,
        "trace_chains": trace_chains,
        "orphan_signals": orphan_signals,
        "orphan_barriers": orphan_barriers,
        "orphan_plays": orphan_plays,
        "all_ids": {
            "signals": all_sigs,
            "barriers": all_bars,
            "plays": all_plays,
            "recommendations": all_rs,
        },
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Validate traceability chains across pharma_goal deliverables.",
    )
    sub = parser.add_subparsers(dest="command")

    tp = sub.add_parser("traceability", help="Check SIG→BAR→PLAY→R-XX chain completeness")
    tp.add_argument("--intelligence-report", required=True,
                    help="Path to intelligence_report.md")
    tp.add_argument("--strategy-plan", required=True,
                    help="Path to strategy_plan.md")
    tp.add_argument("--output-dir", default=None,
                    help="Output directory (for future use)")

    args = parser.parse_args()

    if args.command == "traceability":
        ir_text = _read_file(Path(args.intelligence_report))
        sp_text = _read_file(Path(args.strategy_plan))

        if not ir_text:
            print(json.dumps({"success": False, "error": f"Cannot read {args.intelligence_report}"}))
            sys.exit(1)
        if not sp_text:
            print(json.dumps({"success": False, "error": f"Cannot read {args.strategy_plan}"}))
            sys.exit(1)

        result = analyze_traceability(ir_text, sp_text)
        print(json.dumps(result, indent=2))
        sys.exit(0 if "PASS" in result["verdict"] else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
