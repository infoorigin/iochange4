"""The case tier, split by concern (store / rulebook / analysis / commands).

The public surface is the `ioagentfarm.tools.case_store` facade — import from there.
"""
