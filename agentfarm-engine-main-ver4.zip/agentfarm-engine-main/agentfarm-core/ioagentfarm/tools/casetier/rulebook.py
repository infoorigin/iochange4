"""casetier.rulebook — the DB-resident rulebook engine (pure).

Seeded specs, document validation (incl. declared invariants and
structural warnings), the generic decide(), delivery-contract lookup,
simulation walks, and the single save/load path. Nothing here opens a
connection — cursors come in as arguments.
"""
from __future__ import annotations

import re
import json

from ioagentfarm.tools.casetier.store import _now, _workspace



# ------------------------------------------------ seeded rulebook specs
#
# Seeds are starting content, not the contract: they land only when the
# template_id is absent, so a tenant's revised rulebook always wins.

_OSVAC_SPEC = {
    "template_id": "TPL-OS-VACANCY",
    "title": "Open-Seat Vacancy Escalation",
    "description": (
        "Territory vacancy: notify the owner, remind, escalate up the "
        "field hierarchy, snooze after exhaustion. One case per territory."),
    # The declared ENDS. The ladder is the means; these say what counts as
    # the objective being met vs abandoned, so kpi reports against a
    # declaration instead of inferring from event-name conventions.
    "goal": ("Restore field coverage for the vacant territory; escalate "
             "with defined windows and know when to stop."),
    "success_events": ["assignment_confirmed"],
    "abandonment_events": ["snooze_expired"],
    "initial_state": "NEW",
    "open_event": "case_opened",
    "states": ["NEW", "OWNER_NOTIFIED", "OWNER_REMINDED", "ESCALATED",
               "ESCALATION_REMINDED", "SNOOZED", "CLOSED"],
    "events": ["case_opened", "case_opened_no_owner", "sla_breach",
               "backfill_received", "dismiss_received",
               "assignment_confirmed", "system_error", "snooze_expired"],
    "terminal_states": ["CLOSED"],
    "role_params": ["owner_role", "cc_role", "escalation_role", "admin_role"],
    "default_params": {
        "owner_role": "DM", "cc_role": "RBC", "escalation_role": "Field Ops",
        "admin_role": "AA", "owner_sla_days": 2, "extension_sla_days": 4,
        "escalation_sla_days": 2, "snooze_days": 30,
    },
    # Any-state rules — highest precedence (playbook steps 9-11 + error
    # handling). Never applied to a terminal state.
    # The DELIVERY CONTRACT per action — data, not a prompt table. The
    # generic case_action workflow reads this from the ctx bundle: which
    # role gets the email (to_param resolves through the case params), who
    # is CC'd (NO cc_param = nobody, structurally — "directly and
    # exclusively" is a field, not a plea), the subject skeleton, and
    # which monitoring-task kind to create. side_effects is the retry
    # contract: a delivered email survives a failed run; re-commissioning
    # on failure alone double-sends.
    "actions": {
        "notify_owner": {
            "side_effects": True, "delivery": "email",
            "to_param": "owner_role", "cc_param": "cc_role",
            "subject_hint": "Coverage assignment needed — <item>",
            "brief": "vacancy detected; request coordination with the "
                     "regional coordinator to assign secondary coverage "
                     "within the window",
            "task_kind": "owner_sla"},
        "remind_owner": {
            "side_effects": True, "delivery": "email",
            "to_param": "owner_role", "cc_param": "cc_role",
            "subject_hint": "Reminder: coverage assignment pending — <item>",
            "brief": "professional reminder; name the new window",
            "task_kind": "owner_sla"},
        "notify_escalation": {
            "side_effects": True, "delivery": "email",
            "to_param": "escalation_role", "cc_param": "cc_role",
            "subject_hint": "Escalation: coverage unassigned — <item>",
            "brief": "state that the owner window(s) expired without "
                     "assignment",
            "task_kind": "escalation_sla"},
        "remind_escalation": {
            "side_effects": True, "delivery": "email",
            "to_param": "escalation_role", "cc_param": "cc_role",
            "subject_hint": "Reminder: escalated coverage gap — <item>",
            "brief": "professional reminder on the escalated gap",
            "task_kind": "escalation_sla"},
        "notify_admin_and_snooze": {
            # A PAUSE EXPIRING IS NOT A BREACH. Undeclared, this window fired
            # `sla_breach` into SNOOZED, which only ever handled
            # `snooze_expired` -- so the 30-day pause the approved text
            # promises the recipient never ended, and nothing in the platform
            # emits that event by itself. The case parked forever.
            "expiry_event": "snooze_expired",
            "side_effects": True, "delivery": "email",
            "to_param": "admin_role",
            "subject_hint": "Manual intervention required — <item>",
            "brief": "the ladder is exhausted; the item snoozes for the "
                     "window; manual intervention required",
            # MLR-approved language: when approved_text exists the act
            # step uses it VERBATIM with slot substitution — free
            # composition is only for actions without one.
            "approved_text": (
                "This is an automated field-coverage notification. "
                "Territory {item} (case {case_id}) remains without "
                "coverage after the full escalation sequence. Manual "
                "intervention is required. The case is paused for "
                "{sla_days} business days. For internal use only."),
            "task_kind": "snooze"},
        # No email — but a monitoring task in the external system is a
        # delivery too.
        "extend_sla": {"side_effects": True, "delivery": "monitoring_task",
                       "task_kind": "extension_sla"},
        "snooze": {"expiry_event": "snooze_expired",
                   "side_effects": True, "delivery": "monitoring_task",
                   "task_kind": "snooze"},
        "close": {"side_effects": False},
    },
    # The playbook's own compliance properties, machine-checked on every
    # put — the generalization of the hand-written admin-unreachable
    # graph proof.
    "invariants": [
        {"kind": "action_only_from", "action": "notify_admin_and_snooze",
         "states": ["ESCALATION_REMINDED"],
         "except_events": ["system_error"]},
        {"kind": "event_always_closes", "event": "assignment_confirmed"},
    ],
    # Classification rubrics: how a free-text reply becomes a typed event.
    # Judgement stays with the classifier, the CRITERIA are the play's.
    "event_rubrics": {
        "backfill_received": (
            "the responder is actively working coverage — interviewing, "
            "reassigning, a candidate pending approval, asking for more "
            "time WITH a concrete step in motion"),
        "dismiss_received": (
            "the responder declines to act or says to stand down — no "
            "coverage step is in motion"),
        "assignment_confirmed": (
            "coverage is IN PLACE: a named person is assigned or the "
            "seat is filled; a promise to assign later is backfill, not "
            "assignment"),
    },
    "wildcard_rules": [
        {"event": "assignment_confirmed", "rule_id": "R09",
         "action": "close", "to_state": "CLOSED", "sla_param": None},
        {"event": "dismiss_received", "rule_id": "R10",
         "action": "snooze", "to_state": "SNOOZED",
         "sla_param": "snooze_days"},
        {"event": "system_error", "rule_id": "R11",
         "action": "notify_admin_and_snooze", "to_state": "SNOOZED",
         "sla_param": "snooze_days"},
    ],
    # The playbook's 11 steps as rows, parameterized by the play (roles and
    # windows live in params, not here). R02 is the no-owner OPEN variant —
    # an ordinary rule on its own open event, not an engine special case.
    "rules": [
        {"from_state": "NEW", "event": "case_opened", "rule_id": "R01",
         "action": "notify_owner", "to_state": "OWNER_NOTIFIED",
         "sla_param": "owner_sla_days"},
        {"from_state": "NEW", "event": "case_opened_no_owner",
         "rule_id": "R02", "action": "notify_escalation",
         "to_state": "ESCALATED", "sla_param": "escalation_sla_days"},
        {"from_state": "OWNER_NOTIFIED", "event": "backfill_received",
         "rule_id": "R03", "action": "extend_sla",
         "to_state": "OWNER_NOTIFIED", "sla_param": "extension_sla_days"},
        {"from_state": "OWNER_NOTIFIED", "event": "sla_breach",
         "rule_id": "R04", "action": "remind_owner",
         "to_state": "OWNER_REMINDED", "sla_param": "owner_sla_days"},
        {"from_state": "OWNER_REMINDED", "event": "backfill_received",
         "rule_id": "R05", "action": "extend_sla",
         "to_state": "OWNER_REMINDED", "sla_param": "extension_sla_days"},
        {"from_state": "OWNER_REMINDED", "event": "sla_breach",
         "rule_id": "R06", "action": "notify_escalation",
         "to_state": "ESCALATED", "sla_param": "escalation_sla_days"},
        {"from_state": "ESCALATED", "event": "sla_breach", "rule_id": "R07",
         "action": "remind_escalation", "to_state": "ESCALATION_REMINDED",
         "sla_param": "escalation_sla_days"},
        {"from_state": "ESCALATION_REMINDED", "event": "sla_breach",
         "rule_id": "R08", "action": "notify_admin_and_snooze",
         "to_state": "SNOOZED", "sla_param": "snooze_days"},
        {"from_state": "SNOOZED", "event": "snooze_expired",
         "rule_id": "R12", "action": "close", "to_state": "CLOSED",
         "sla_param": None},
    ],
}

_SAMPLE_SPEC = {
    "template_id": "TPL-SAMPLE-DISCREPANCY",
    "title": "Sample Inventory Discrepancy",
    "description": (
        "PDMA sample count mismatch: ask the rep to recount, remind, "
        "escalate to compliance review, snooze after exhaustion. One case "
        "per rep x audit period."),
    "goal": ("Resolve the sample-count discrepancy, or place it under "
             "compliance control."),
    "success_events": ["discrepancy_resolved"],
    "abandonment_events": ["snooze_expired"],
    "initial_state": "NEW",
    "open_event": "case_opened",
    "states": ["NEW", "REP_NOTIFIED", "REP_REMINDED", "COMPLIANCE_REVIEW",
               "SNOOZED", "CLOSED"],
    "events": ["case_opened", "sla_breach", "count_submitted",
               "discrepancy_resolved", "compliance_flag", "system_error",
               "snooze_expired"],
    "terminal_states": ["CLOSED"],
    "role_params": ["owner_role", "cc_role", "escalation_role", "admin_role"],
    "default_params": {
        "owner_role": "Sales Rep", "cc_role": "DM",
        "escalation_role": "Compliance", "admin_role": "Compliance Ops",
        "rep_sla_days": 3, "review_sla_days": 5, "snooze_days": 15,
    },
    "actions": {
        "notify_rep": {
            "side_effects": True, "delivery": "email",
            "to_param": "owner_role", "cc_param": "cc_role",
            "subject_hint": "Sample count discrepancy — recount required "
                            "— <item>",
            "brief": "a sample inventory discrepancy was detected; a "
                     "recount and submission is required within the window",
            "task_kind": "rep_sla"},
        "remind_rep": {
            "side_effects": True, "delivery": "email",
            "to_param": "owner_role", "cc_param": "cc_role",
            "subject_hint": "Reminder: sample recount pending — <item>",
            "brief": "professional reminder; name the window",
            "task_kind": "rep_sla"},
        "escalate_to_compliance": {
            "side_effects": True, "delivery": "email",
            "to_param": "escalation_role", "cc_param": "cc_role",
            "subject_hint": "Compliance review: sample discrepancy — <item>",
            "brief": "the rep window expired or a flag was raised; "
                     "compliance review required",
            "task_kind": "review_sla"},
        "verify_count": {
            "side_effects": True, "delivery": "monitoring_task",
            "task_kind": "review_sla"},
        "notify_admin_and_snooze": {
            # A PAUSE EXPIRING IS NOT A BREACH. Undeclared, this window fired
            # `sla_breach` into SNOOZED, which only ever handled
            # `snooze_expired` -- so the 30-day pause the approved text
            # promises the recipient never ended, and nothing in the platform
            # emits that event by itself. The case parked forever.
            "expiry_event": "snooze_expired",
            "side_effects": True, "delivery": "email",
            "to_param": "admin_role",
            "subject_hint": "Manual intervention: sample discrepancy — "
                            "<item>",
            "brief": "review window exhausted; the case snoozes for the "
                     "window",
            "task_kind": "snooze"},
        "close": {"side_effects": False},
    },
    "wildcard_rules": [
        {"event": "discrepancy_resolved", "rule_id": "S08",
         "action": "close", "to_state": "CLOSED", "sla_param": None},
        {"event": "compliance_flag", "rule_id": "S09",
         "action": "escalate_to_compliance", "to_state": "COMPLIANCE_REVIEW",
         "sla_param": "review_sla_days"},
        {"event": "system_error", "rule_id": "S10",
         "action": "notify_admin_and_snooze", "to_state": "SNOOZED",
         "sla_param": "snooze_days"},
    ],
    "rules": [
        {"from_state": "NEW", "event": "case_opened", "rule_id": "S01",
         "action": "notify_rep", "to_state": "REP_NOTIFIED",
         "sla_param": "rep_sla_days"},
        {"from_state": "REP_NOTIFIED", "event": "count_submitted",
         "rule_id": "S02", "action": "verify_count",
         "to_state": "COMPLIANCE_REVIEW", "sla_param": "review_sla_days"},
        {"from_state": "REP_NOTIFIED", "event": "sla_breach",
         "rule_id": "S03", "action": "remind_rep",
         "to_state": "REP_REMINDED", "sla_param": "rep_sla_days"},
        {"from_state": "REP_REMINDED", "event": "count_submitted",
         "rule_id": "S04", "action": "verify_count",
         "to_state": "COMPLIANCE_REVIEW", "sla_param": "review_sla_days"},
        {"from_state": "REP_REMINDED", "event": "sla_breach",
         "rule_id": "S05", "action": "escalate_to_compliance",
         "to_state": "COMPLIANCE_REVIEW", "sla_param": "review_sla_days"},
        {"from_state": "COMPLIANCE_REVIEW", "event": "sla_breach",
         "rule_id": "S06", "action": "notify_admin_and_snooze",
         "to_state": "SNOOZED", "sla_param": "snooze_days"},
        {"from_state": "SNOOZED", "event": "snooze_expired",
         "rule_id": "S07", "action": "close", "to_state": "CLOSED",
         "sla_param": None},
    ],
}

_SEED_SPECS = (_OSVAC_SPEC, _SAMPLE_SPEC)


# ------------------------------------------------ the generic rule engine

_SPEC_REQUIRED = ("template_id", "title", "initial_state", "states",
                  "events", "terminal_states", "rules", "default_params")


#: A sentence claiming a window has ALREADY ended. Narrow on purpose: it
#: must not fire on "respond within {sla_days} business days", which is the
#: ordinary and correct use of the placeholder.
_EXPIRY_LANGUAGE = re.compile(
    r"\b(?:has|have|had)\s+(?:now\s+)?"
    r"(?:expired|elapsed|lapsed|passed|closed|ended)\b"
    r"|\b(?:expired|elapsed|lapsed)\s+(?:on|at|without)\b"
    r"|\bdeadline\s+(?:has|had)\s+passed\b",
    re.I)


def validate_spec(spec: dict) -> list[str]:
    """Structural validation for a rulebook document. Returns error strings;
    empty means the spec is safe to run. Everything a rule references must
    be declared — a typo'd state or event must fail at put time, not
    surface as an eternal UNMATCHED at execution time."""
    errs: list[str] = []
    if not isinstance(spec, dict):
        return ["spec must be a JSON object"]
    for k in _SPEC_REQUIRED:
        if k not in spec:
            errs.append(f"missing required key: {k}")
    if errs:
        return errs
    states, events = set(spec["states"]), set(spec["events"])
    terminal = set(spec["terminal_states"])
    params = spec["default_params"]
    if spec["initial_state"] not in states:
        errs.append(f"initial_state {spec['initial_state']!r} not in states")
    if not terminal <= states:
        errs.append(f"terminal_states not all in states: "
                    f"{sorted(terminal - states)}")
    open_event = spec.get("open_event", "case_opened")
    if open_event not in events:
        errs.append(f"open_event {open_event!r} not in events")
    else:
        # A rulebook whose open event matches no rule can never open a
        # case — found live: a compiled draft opened on sla_breach rules
        # only, and every `open` would have been refused.
        opens = any(r.get("from_state") == spec["initial_state"]
                    and r.get("event") == open_event
                    for r in spec["rules"])
        opens = opens or any(w.get("event") == open_event
                             for w in spec.get("wildcard_rules", []))
        if not opens:
            errs.append(
                f"no rule matches (initial_state={spec['initial_state']!r},"
                f" open_event={open_event!r}) — no case could ever open")
    seen_pairs: set = set()
    for r in spec["rules"]:
        rid = r.get("rule_id", "?")
        for k in ("rule_id", "action", "from_state", "event", "to_state"):
            if not r.get(k):
                errs.append(f"rule {rid}: missing {k}")
        if r.get("from_state") and r["from_state"] not in states:
            errs.append(f"rule {rid}: from_state {r['from_state']!r} "
                        f"not declared in states")
        if r.get("from_state") in terminal:
            errs.append(f"rule {rid}: from_state {r['from_state']!r} is "
                        f"terminal — a terminal state accepts nothing")
        if r.get("to_state") and r["to_state"] not in states:
            errs.append(f"rule {rid}: to_state {r['to_state']!r} "
                        f"not declared in states")
        if r.get("event") and r["event"] not in events:
            errs.append(f"rule {rid}: event {r['event']!r} "
                        f"not declared in events")
        if r.get("sla_param") and r["sla_param"] not in params:
            errs.append(f"rule {rid}: sla_param {r['sla_param']!r} "
                        f"not in default_params")
        pair = (r.get("from_state"), r.get("event"))
        if pair in seen_pairs:
            errs.append(f"rule {rid}: duplicate (state, event) pair {pair} "
                        f"— the rulebook must be unambiguous")
        seen_pairs.add(pair)
    seen_wild: set = set()
    for w in spec.get("wildcard_rules", []):
        rid = w.get("rule_id", "?")
        for k in ("rule_id", "action", "event", "to_state"):
            if not w.get(k):
                errs.append(f"wildcard {rid}: missing {k}")
        if w.get("to_state") and w["to_state"] not in states:
            errs.append(f"wildcard {rid}: to_state {w['to_state']!r} "
                        f"not declared in states")
        if w.get("event") and w["event"] not in events:
            errs.append(f"wildcard {rid}: event {w['event']!r} "
                        f"not declared in events")
        if w.get("sla_param") and w["sla_param"] not in params:
            errs.append(f"wildcard {rid}: sla_param {w['sla_param']!r} "
                        f"not in default_params")
        if w.get("event") in seen_wild:
            errs.append(f"wildcard {rid}: duplicate wildcard event "
                        f"{w['event']!r}")
        seen_wild.add(w.get("event"))
    for rp in spec.get("role_params", []):
        if rp not in params:
            errs.append(f"role_params entry {rp!r} not in default_params")
    actions = spec.get("actions", {})
    if not isinstance(actions, dict):
        errs.append("actions must be a map of action name -> metadata")
    else:
        for name, meta in actions.items():
            if not isinstance(meta, dict):
                errs.append(f"actions[{name!r}] must be a metadata object")
    for ev in (spec.get("event_rubrics") or {}):
        if ev not in events:
            errs.append(f"event_rubrics names undeclared event {ev!r}")
    if "wanted_invariants" in spec \
            and not isinstance(spec["wanted_invariants"], list):
        errs.append("wanted_invariants must be a list (of objects with "
                    "`property` and `source`, or plain strings)")
    # APPROVED WORDING MUST NOT QUOTE A WINDOW THE RULE DECLINES TO SET.
    # `{sla_days}` resolves from the case row, which a rule with no
    # sla_param leaves empty — so reviewed regulatory text promising review
    # "within {sla_days} business days" is delivered with a blank. The
    # feature's whole premise is that approved language is never altered.
    ordered_by = {}
    for rule in (list(spec.get("rules") or [])
                 + list(spec.get("wildcard_rules") or [])):
        if isinstance(rule, dict) and rule.get("action"):
            ordered_by.setdefault(rule["action"], []).append(rule)
    for name, meta in (actions if isinstance(actions, dict) else {}).items():
        text = isinstance(meta, dict) and meta.get("approved_text") or ""
        if "{sla_days}" not in str(text):
            continue
        for rule in ordered_by.get(name, []):
            if not rule.get("sla_param"):
                errs.append(
                    f"actions[{name!r}].approved_text quotes {{sla_days}}, "
                    f"but rule {rule.get('rule_id')!r} orders it with no "
                    f"sla_param — the window would render empty in text a "
                    f"reviewer approved. Set an sla_param on that rule, or "
                    f"use {{prior_sla_days}} if the sentence means the "
                    f"window that just expired")

    # AND IT MUST NOT QUOTE THE WRONG WINDOW. The blank case above is the
    # visible half; this is the half that reads correctly and is false.
    # `{sla_days}` is the window the action STARTS, so escalation language
    # saying "the window of {sla_days} days has now expired" states the
    # length of the NEXT window while claiming it is the one that just
    # ended. Live: an executive received approved compliance wording
    # asserting a 45-business-day window had expired when the window that
    # expired was 5 - through the feature whose premise is that reviewed
    # language is never altered. `{prior_sla_days}` is the expired one.
    for name, meta in (actions if isinstance(actions, dict) else {}).items():
        text = str(isinstance(meta, dict) and meta.get("approved_text") or "")
        if "{sla_days}" not in text:
            continue
        for sentence in re.split(r"(?<=[.!?])\s+", text):
            if "{sla_days}" not in sentence:
                continue
            if not _EXPIRY_LANGUAGE.search(sentence):
                continue
            errs.append(
                f"actions[{name!r}].approved_text says a window has expired "
                f"and quotes {{sla_days}}, which is the window this action "
                f"STARTS - not the one that ended. The reader is told the "
                f"wrong number in language nobody may rephrase. Use "
                f"{{prior_sla_days}} for the expired window, or reword the "
                f"sentence to describe the window now beginning "
                f"(sentence: {sentence.strip()[:80]!r})")
            break

    for name, meta in (actions if isinstance(actions, dict) else {}).items():
        if not isinstance(meta, dict):
            continue
        for key in ("to_param", "cc_param"):
            pname = meta.get(key)
            if not pname or pname not in params:
                continue
            if isinstance(params[pname], (list, tuple, set, dict)):
                errs.append(
                    f"actions[{name!r}].{key} names {pname!r}, whose value "
                    f"is a list. One delivery addresses ONE role: a list is "
                    f"silently truncated at the send and the case still "
                    f"records success. Give each recipient its own action, "
                    f"or name a single role")
        ver = meta.get("verification")
        if ver is not None and (not isinstance(ver, dict)
                                or not str(ver.get("tool") or "").strip()):
            errs.append(
                f"actions[{name!r}].verification must be an object naming "
                f"its `tool` — the act step calls exactly that tool to read "
                f"the ground truth, and an unnamed one leaves the claim "
                f"unverified while the contract says it was checked")
        # PLAY COMPOSITION: the contract must say WHICH play it opens, and
        # opening cases is a side effect by definition — a retry decision
        # that believes otherwise re-opens children on every failure.
        if meta.get("delivery") == "open_play":
            if not str(meta.get("play") or "").strip():
                errs.append(
                    f"actions[{name!r}] has delivery 'open_play' but names "
                    f"no `play` — the child play id is the whole contract")
            if meta.get("side_effects") is False:
                errs.append(
                    f"actions[{name!r}]: opening cases IS a side effect — "
                    f"side_effects must not be false on an open_play action")
        # WORKFLOW COMMISSIONING: the contract must say WHICH workflow, and
        # a run is a side effect (it costs, it writes, and a retry that
        # believes otherwise commissions it twice). Its completion and
        # failure arrive as TYPED EVENTS the rulebook must declare - the
        # run finishing is what advances the case, so an undeclared event
        # is a run whose result can never be applied.
        if meta.get("delivery") == "workflow":
            if not str(meta.get("workflow") or "").strip():
                errs.append(
                    f"actions[{name!r}] has delivery 'workflow' but names "
                    f"no `workflow` — the workflow to commission is the "
                    f"whole contract")
            if meta.get("side_effects") is False:
                errs.append(
                    f"actions[{name!r}]: commissioning a run IS a side "
                    f"effect — side_effects must not be false on a "
                    f"workflow action")
            for _key, _default in (("completion_event", WORKFLOW_COMPLETED),
                                   ("failure_event", WORKFLOW_FAILED)):
                _ev = meta.get(_key) or _default
                if _ev not in events:
                    errs.append(
                        f"actions[{name!r}] commissions a workflow whose "
                        f"{_key} is {_ev!r}, which is not declared in "
                        f"events — declare it: the run's outcome arrives "
                        f"as that event and an undeclared event is refused "
                        f"at intake")

    # THE DECLARED ENDS. success/abandonment_events are the closing-event
    # taxonomy kpi reports against — a declaration, not the event-name
    # convention it replaces. A "success" that leaves the case open is a
    # progress event mislabeled: the taxonomy only classifies closes.
    all_rules = (list(spec.get("rules") or [])
                 + list(spec.get("wildcard_rules") or []))
    success = list(spec.get("success_events") or [])
    abandon = list(spec.get("abandonment_events") or [])
    for label, declared in (("success_events", success),
                            ("abandonment_events", abandon)):
        for ev in declared:
            if ev not in events:
                errs.append(f"{label} names undeclared event {ev!r}")
                continue
            for r in all_rules:
                if r.get("event") == ev \
                        and r.get("to_state") not in terminal:
                    errs.append(
                        f"{label}: {r.get('rule_id')} handles {ev!r} but "
                        f"goes to {r.get('to_state')!r}, not a terminal "
                        f"state — an end must close the case; an event "
                        f"that moves it along is progress, not an end")
    for ev in sorted(set(success) & set(abandon)):
        errs.append(f"event {ev!r} is declared both a success and an "
                    f"abandonment — the kpi cannot count it as either")

    # THE GOAL CLOCK. One case-level window opened at creation and never
    # reset by rung transitions; its expiry is an ordinary typed event
    # decided by the same engine. Everything it references must exist —
    # a clock firing an event no rule handles parks every case at an
    # eternal UNMATCHED refusal.
    gparam = (spec.get("goal_sla_param") or "").strip()
    if gparam:
        if gparam not in params:
            errs.append(f"goal_sla_param {gparam!r} not in default_params")
        else:
            try:
                int(params[gparam])
            except (TypeError, ValueError):
                errs.append(f"goal_sla_param {gparam!r} = "
                            f"{params[gparam]!r} is not a number of days")
        gev = spec.get("goal_event") or "goal_overdue"
        if gev not in events:
            errs.append(f"the goal clock fires {gev!r}, which is not "
                        f"declared in events")
        elif not any(r.get("event") == gev for r in all_rules):
            errs.append(f"the goal clock fires {gev!r} but no rule handles "
                        f"it — every case would park at an UNMATCHED "
                        f"refusal when its goal window expires")
    # A WINDOW NOTHING LISTENS FOR — the SLA clock's version of the
    # goal-clock check directly above, which was never applied to it.
    #
    # `sla_param` arms a durable clock, and the scheduler delivers its expiry
    # as `sla_breach` INTO THE STATE THE RULE MOVED TO. Where no rule consumes
    # `sla_breach` from that state the clock fires into nothing: the case parks
    # and the escalation the window exists to trigger never happens.
    #
    # An ERROR, not a warning, because no reading of it is correct. Arming a
    # clock declares that something must happen when it expires; if nothing
    # can, either the rule is wired to the wrong state or the window was never
    # meant.
    #
    # Found live, and the reason this exists. A playbook compiled from business
    # prose put its escalation on `from_state: NEW` when the case is in
    # `AWAITING_RM_RESPONSE` by the time the window runs — the state it was in
    # when the clock was SET, not the state it is in when the clock EXPIRES.
    # The draft validated with zero errors AND zero warnings, its rule table
    # read correctly to a reviewer, and the most important sentence of the
    # source ("if we do not hear back, it goes to the Commercial Director")
    # silently never executed. Only the exhaust trace showed it, and only to a
    # reader who knew to run one.
    from ioagentfarm.tools.casetier.timers import expiry_event
    for r in all_rules:
        if not isinstance(r, dict) or not r.get("sla_param"):
            continue
        dest, rid = r.get("to_state"), r.get("rule_id")
        # WHICH event this particular clock fires is declared, not assumed: a
        # pause expiring is not a breach. Asking `expiry_event` rather than
        # hardcoding 'sla_breach' is the difference between a check and a
        # guess -- the first cut assumed the breach event and refused both
        # shipped seeds, whose snooze windows are meant to fire elsewhere.
        fires = expiry_event(spec, r.get("action"))
        _consumers = {x.get("from_state") for x in spec.get("rules", [])
                      if isinstance(x, dict) and x.get("event") == fires}
        _wildcard = any(w.get("event") == fires
                        for w in (spec.get("wildcard_rules") or [])
                        if isinstance(w, dict))
        if dest in terminal:
            # Deliberately silent. A clock armed into a terminal state is
            # dead, but nothing wrong HAPPENS: the state accepts no events,
            # so `decide` refuses once, the occurrence is consumed and it is
            # never re-offered - one wasted sweep, not a broken ladder. It
            # was briefly a warning and earned nothing but noise against
            # rulebooks deliberately shaped that way. The branch below is the
            # severe one: a LIVE case whose escalation silently never comes.
            continue
        if dest in states and not _wildcard and dest not in _consumers:
            errs.append(
                f"rule {rid!r} starts a {r['sla_param']!r} window and moves "
                f"to {dest!r}, but no rule consumes {fires!r} from {dest!r} "
                f"— the clock fires into nothing and the case parks instead "
                f"of advancing. Add a rule with from_state={dest!r} and "
                f"event={fires!r}, declare a different expiry_event on the "
                f"{r.get('action')!r} action, or clear sla_param if no "
                f"window was intended")

    # A RUN THAT FINISHES INTO NOTHING. The sibling of the window check
    # above: a rule whose action commissions a workflow moves the case to
    # a state where the run's completion arrives as an event. If no rule
    # consumes that event there, the analysis completes, the ledger records
    # UNMATCHED, and the case parks with its result in hand and nowhere to
    # put it - correct by the letter, and exactly the "playbook runs the
    # solution" story failing silently.
    for r in all_rules:
        if not isinstance(r, dict):
            continue
        _meta = (spec.get("actions") or {}).get(r.get("action"))
        if not isinstance(_meta, dict) or _meta.get("delivery") != "workflow":
            continue
        dest, rid = r.get("to_state"), r.get("rule_id")
        done_ev = _meta.get("completion_event") or WORKFLOW_COMPLETED
        _consumers = {x.get("from_state") for x in spec.get("rules", [])
                      if isinstance(x, dict) and x.get("event") == done_ev}
        _wildcard = any(w.get("event") == done_ev
                        for w in (spec.get("wildcard_rules") or [])
                        if isinstance(w, dict))
        if dest in terminal or dest not in states:
            continue
        if not _wildcard and dest not in _consumers:
            errs.append(
                f"rule {rid!r} commissions workflow "
                f"{_meta.get('workflow')!r} and moves to {dest!r}, but no "
                f"rule consumes {done_ev!r} from {dest!r} — the run "
                f"finishes into nothing and the case parks with its result "
                f"in hand. Add a rule with from_state={dest!r} and "
                f"event={done_ev!r}, or declare a different "
                f"completion_event on the {r.get('action')!r} action")

    # A RECIPIENT THAT IS NOT A PARAMETER. `to_param`/`cc_param` name a key
    # in `default_params`; the case resolves it when the action is
    # commissioned. A job title written straight into the field reads
    # perfectly and resolves to nothing, and changing who is notified then
    # means editing the rulebook instead of a parameter - which is the one
    # thing this design exists to avoid.
    #
    # The compile prompt has said this for a long time, in two places, with a
    # worked counter-example. A draft still wrote `"to_param": "Commercial
    # Director"` and installed clean. A rule stated to a model is a request:
    # this one has to be enforced, because it must never fail.
    for _name, _meta in (spec.get("actions") or {}).items():
        if not isinstance(_meta, dict):
            continue
        for _field in ("to_param", "cc_param"):
            _val = _meta.get(_field)
            if _val and _val not in params:
                _suggest = (re.sub(r"[^a-z0-9]+", "_", str(_val).lower())
                            .strip("_") + "_role")
                errs.append(
                    f"action {_name!r} names {_field}={_val!r}, which is not "
                    f"a key in default_params — recipients are parameters the "
                    f"case resolves, never literal people or job titles. Add "
                    f"{_val!r} to default_params under a key such as "
                    f"{_suggest!r}, and name that key here. "
                    f"Declared: {sorted(params)}")

    errs += check_invariants(spec)
    return errs


#: Declared-invariant kinds. An invariant is the playbook's own compliance
#: property written as DATA and machine-checked on every put — the
#: generalization of the hand-written "admin unreachable before the ladder
#: is exhausted" proof to every template.
_INVARIANT_KINDS = ("action_only_from", "event_always_closes")


def check_invariants(spec: dict) -> list[str]:
    """Violations of the spec's DECLARED invariants — errors, never saved."""
    errs: list[str] = []
    terminal = set(spec.get("terminal_states", ()))
    for i, inv in enumerate(spec.get("invariants", []) or []):
        kind = inv.get("kind")
        if kind not in _INVARIANT_KINDS:
            errs.append(f"invariant #{i + 1}: unknown kind {kind!r} "
                        f"(known: {', '.join(_INVARIANT_KINDS)})")
            continue
        if kind == "action_only_from":
            action = inv.get("action")
            allowed = set(inv.get("states", ()))
            except_ev = set(inv.get("except_events", ()))
            for r in spec.get("rules", []):
                if r.get("action") == action \
                        and r.get("event") not in except_ev \
                        and r.get("from_state") not in allowed:
                    errs.append(
                        f"invariant violated: {r.get('rule_id')} fires "
                        f"{action!r} from {r.get('from_state')!r} — allowed "
                        f"only from {sorted(allowed)}")
            for w in spec.get("wildcard_rules", []):
                if w.get("action") == action \
                        and w.get("event") not in except_ev:
                    errs.append(
                        f"invariant violated: wildcard {w.get('rule_id')} "
                        f"fires {action!r} from ANY state (event "
                        f"{w.get('event')!r} is not excepted)")
        elif kind == "event_always_closes":
            ev = inv.get("event")
            for r in (list(spec.get("rules", []))
                      + list(spec.get("wildcard_rules", []))):
                if r.get("event") == ev and r.get("to_state") not in terminal:
                    errs.append(
                        f"invariant violated: {r.get('rule_id')} handles "
                        f"{ev!r} but goes to {r.get('to_state')!r}, not a "
                        f"terminal state")
    return errs


def validate_spec_warnings(spec: dict) -> list[str]:
    """Structural WARNINGS — worth a reviewer's eye, never a refusal:
    states no event path can reach, and (when the spec has no wildcard
    rules) non-terminal states with no way out."""
    warns: list[str] = []
    # THE GOAL NOTICE IS A REPORT, NOT A RUNG. A rule consuming the spec's
    # own goal_event that MOVES the case, opens a window, or fires as a
    # wildcard turns "tell someone the target was missed" into an extra
    # escalation step - the matter is dragged to a new state and its
    # running rung clock is displaced by a date passing. Watched recur
    # FOUR times across differently-worded rejections of one playbook, so
    # it is arithmetic now. It stays a warning, not a refusal: a source
    # that genuinely says "after N days move it to the review board" is a
    # legitimate exception, and the reviewer sees the warning beside the
    # sentence that would justify it.
    if spec.get("goal_sla_param"):
        gev = (spec.get("goal_event") or "goal_overdue").strip()
        for r in spec.get("wildcard_rules") or []:
            if r.get("event") == gev:
                warns.append(
                    f"rule {r.get('rule_id')} consumes the goal event "
                    f"{gev!r} as a WILDCARD, moving any state to "
                    f"{r.get('to_state')!r} - if the source says the matter "
                    f"stays where it is when the target is missed, write "
                    f"one rule per live state returning to itself, with no "
                    f"window")
        for r in spec.get("rules") or []:
            if r.get("event") != gev:
                continue
            moved = r.get("to_state") != r.get("from_state")
            windowed = bool(r.get("sla_param"))
            if moved or windowed:
                what = " and ".join(w for w, on in
                                    (("moves the case to "
                                      + repr(r.get("to_state")), moved),
                                     ("opens a window "
                                      + repr(r.get("sla_param")), windowed))
                                    if on)
                warns.append(
                    f"rule {r.get('rule_id')} consumes the goal event "
                    f"{gev!r} and {what} - a missed target is a fact to "
                    f"report; if the source does not say the matter moves, "
                    f"the rule returns to {r.get('from_state')!r} with no "
                    f"window")
    # A LADDER WITH NO CLOCK. Windows are declared as parameters and
    # attached per rule via sla_param; a spec whose rules carry NONE runs
    # no timer at all, so every sla_breach rule is dead code and nothing
    # ever escalates. Watched happen while a drafter over-applied "the
    # goal rules carry no window" to every rule in the book.
    if (spec.get("rules") or []) and not any(
            r.get("sla_param") for r in spec["rules"]):
        breach_rules = sum(1 for r in (spec.get("rules") or [])
                           if r.get("event") == "sla_breach") +                        sum(1 for r in (spec.get("wildcard_rules") or [])
                           if r.get("event") == "sla_breach")
        if breach_rules:
            warns.append(
                f"no rule carries an sla_param, so no window ever starts "
                f"and no clock ever runs - the {breach_rules} sla_breach "
                f"rule(s) are unreachable. Give each waiting state's "
                f"arriving rule the window the source states")
    # EVERY DECLARED END COUNTS AS SUCCESS. A spec that declares
    # success_events and no abandonment_events reports 100% forever - the
    # register can never say how often the matter was not worth pursuing,
    # which is usually the number the business eventually asks for.
    if spec.get("success_events") and not spec.get("abandonment_events"):
        warns.append("success_events is declared and abandonment_events is "
                     "empty - every close will count as success; if the "
                     "source describes a decision NOT to act, declare its "
                     "closing event as an abandonment")
    # SILENCE DECIDING THE CASE. A rule that consumes sla_breach and lands
    # in a TERMINAL state closes a matter because nobody answered - the
    # first constraint this workspace's compile history ever recorded
    # (CMP-0001: "silence is not acceptance"), back seventeen rounds later
    # as "breach closes as rejected", against the source's own "do not
    # close a matter nobody has answered". A warning, not a refusal: a
    # playbook whose matters genuinely EXPIRE ("the offer lapses unclaimed
    # after N days") legitimately closes on a breach, and only the source
    # says which kind this is.
    terminal = set(spec.get("terminal_states") or [])
    for r in (spec.get("rules") or []) + (spec.get("wildcard_rules") or []):
        if (isinstance(r, dict) and r.get("event") == "sla_breach"
                and r.get("to_state") in terminal):
            warns.append(
                f"rule {r.get('rule_id')!r} closes the case on sla_breach "
                f"(-> terminal {r.get('to_state')!r}) - silence decides "
                f"the matter; correct only if the source says matters "
                f"EXPIRE, wrong wherever it says an unanswered matter "
                f"stays open")
    # THE SAME APPROVED WORDING ON MORE THAN ONE ACTION. Quoted language is
    # mandated for a specific message - "when we write to X about a missed
    # deadline" is one rung, not every message that ever reaches X. Copied
    # onto a second action it delivers a sentence that was true where it was
    # written and false where it lands.
    #
    # Observed live: wording approved for the escalation - "This matter is
    # now with you" - was also put on the stop-chasing rung, so the same
    # person was told a matter was now theirs at the moment the business had
    # decided to stop pursuing it. Both actions emailed the same recipient,
    # which is what made it look reasonable.
    #
    # A warning, not a refusal: two rungs legitimately sending one approved
    # notice is possible, and the reviewer is the right judge of which.
    _by_text: dict = {}
    for _n, _m in (spec.get("actions") or {}).items():
        if isinstance(_m, dict) and _m.get("approved_text"):
            _by_text.setdefault(_m["approved_text"].strip(), []).append(_n)
    for _text, _acts in _by_text.items():
        if len(_acts) > 1:
            warns.append(
                f"the same approved wording is carried by {len(_acts)} "
                f"actions ({', '.join(sorted(_acts))}): mandated language is "
                f"written for ONE message, and at most one of these is the "
                f"one the source describes. Check which rung the source "
                f"scopes it to; the others need their own brief and no "
                f"approved text. Wording: {_text[:70]!r}...")


    # A WILDCARD MAKES EVERY SPECIFIC RULE ON THAT EVENT DEAD CODE.
    # `decide` scans wildcards first and returns on the first event match,
    # unconditionally — so a rule the author believes handles that event
    # can never fire. Found live and it is not rare: a compiler encoded
    # every window expiry as `snooze_expired`, and its own
    # `ANY + snooze_expired -> close_case` wildcard then shadowed the
    # triage rule, so an untriaged barrier would have CLOSED ITSELF. The
    # rule table read plausibly; only the exhaust simulation exposed it,
    # and a reviewer without platform knowledge would have approved it.
    # Two of sixteen installed rulebooks carry such a rule today.
    _wild_events = {w.get("event") for w in (spec.get("wildcard_rules") or [])
                    if isinstance(w, dict)}
    for r in (spec.get("rules") or []):
        if isinstance(r, dict) and r.get("event") in _wild_events:
            warns.append(
                f"rule {r.get('rule_id')!r} ({r.get('from_state')} + "
                f"{r.get('event')}) can NEVER fire: a wildcard rule on "
                f"{r.get('event')!r} is matched first, from every state. "
                f"Either drop the wildcard, or use an event only this "
                f"rule handles")
    states = set(spec.get("states", ()))
    terminal = set(spec.get("terminal_states", ()))
    wildcards = spec.get("wildcard_rules", []) or []
    out_by_state: dict = {s: [] for s in states}
    for r in spec.get("rules", []):
        if r.get("from_state") in out_by_state:
            out_by_state[r["from_state"]].append(r)
    # reachability from initial_state (wildcards reach every non-terminal)
    reached = {spec.get("initial_state")}
    frontier = [spec.get("initial_state")]
    wild_targets = [w.get("to_state") for w in wildcards]
    while frontier:
        s = frontier.pop()
        nxt = [r.get("to_state") for r in out_by_state.get(s, [])]
        if s not in terminal:
            nxt += wild_targets
        for t in nxt:
            if t in states and t not in reached:
                reached.add(t)
                frontier.append(t)
    for s in sorted(states - reached):
        warns.append(f"state {s!r} is unreachable from "
                     f"{spec.get('initial_state')!r} — dead weight or a "
                     f"missing rule")
    # WHERE THE LADDER ENDS. A state with no rule leaving it is where a case
    # comes to rest, and the two readings of that are structurally identical:
    # a playbook that says "stop chasing and leave it for a person" compiles
    # to exactly the same shape as one missing a rule. The check cannot tell
    # them apart, so it must not assert which it is looking at.
    #
    # It used to say "a case there is stranded forever". That reads as a
    # defect, and a deliberate park is not one - it is the playbook working.
    # Naming the fact and both readings lets the reviewer decide, which is
    # the only place the decision can be made.
    if not wildcards:
        for s in sorted(states - terminal):
            if s in reached and not out_by_state.get(s):
                warns.append(
                    f"state {s!r} is where the ladder ends: non-terminal, "
                    f"reachable, and no rule leaves it, so a case there "
                    f"waits for a person and no clock will move it. Correct "
                    f"if the playbook says to stop and leave the matter for "
                    f"someone to pick up; a gap if a rule is missing. Check "
                    f"which the source says")
    # An action with a delivery contract that no rule ever names is DEAD:
    # it will never be commissioned, so whatever it carries — including
    # wording the business mandated — is silently never delivered. Found
    # live: a compiler put approved language on an action it then wired to
    # nothing, and the draft validated because the language existed.
    fired = {r.get("action") for r in spec.get("rules", [])}
    fired |= {w.get("action") for w in wildcards}
    for name in sorted((spec.get("actions") or {}).keys() - fired):
        meta = spec["actions"][name] or {}
        extra = (" — it carries approved_text, so wording the business "
                 "mandated would never be sent"
                 if meta.get("approved_text") else "")
        warns.append(f"action {name!r} is declared but no rule fires it; "
                     f"it can never be commissioned{extra}")
    # The declared-ends taxonomy, reviewer-side. A declared end no rule
    # handles means no case can ever finish that way; a closing event
    # outside the taxonomy means kpi will count that close as
    # unclassified — both are worth a reviewer's eye, neither is a
    # refusal (a spec with no taxonomy declares nothing and warns never).
    all_rules = (list(spec.get("rules") or []) + list(wildcards))
    success = set(spec.get("success_events") or ())
    abandon = set(spec.get("abandonment_events") or ())
    declared = success | abandon
    if declared:
        handled = {r.get("event") for r in all_rules}
        for ev in sorted(declared - handled):
            label = "success" if ev in success else "abandonment"
            warns.append(f"{label} event {ev!r} is declared but no rule "
                         f"handles it — no case can ever end that way")
        closing = {r.get("event") for r in all_rules
                   if r.get("to_state") in terminal}
        for ev in sorted(closing - declared):
            warns.append(f"closing event {ev!r} is neither a success nor "
                         f"an abandonment — kpi will count its closes as "
                         f"unclassified")
    if spec.get("goal_event") and not (spec.get("goal_sla_param")
                                       or "").strip():
        warns.append("goal_event is declared but goal_sla_param is not — "
                     "the platform will never raise this event on its own; "
                     "only an external emitter can")
    # (Ends WITHOUT a clock is not warned here: a goal can be non-temporal
    # - "every vacancy ends filled or withdrawn" declares ends that
    # classify closes with no deadline at all, and the os-vacancy seed is
    # exactly that shape. The defect is dropping a clock the SOURCE
    # states, and only the stage validator can read the source - the
    # check lives in playbook_store's source cross-check.)
    return warns


def simulate_walk(spec: dict, events: list[str],
                  open_event: str | None = None) -> list[dict]:
    """Pure walk of a rulebook — what the business reviews and what
    `simulate` prints. No database, no side effects: the same decide()
    the live engine runs, over a hypothetical event sequence."""
    steps: list[dict] = []
    state = spec["initial_state"]
    seq = [open_event or spec.get("open_event", "case_opened")] + list(events)
    for ev in seq:
        verdict = decide(spec, state, ev)
        if verdict is None:
            steps.append({"state": state, "event": ev, "verdict": "REFUSED",
                          "note": ("terminal state accepts nothing"
                                   if state in set(
                                       spec.get("terminal_states", ()))
                                   else "no rule — surfaces UNMATCHED")})
            continue
        rule_id, action, to_state, sla_param = verdict
        steps.append({"state": state, "event": ev, "rule_id": rule_id,
                      "action": action, "to_state": to_state,
                      "window": sla_param})
        state = to_state
    return steps


def exhaust_walk(spec: dict, breach_event: str = "sla_breach",
                 cap: int = 20) -> list[dict]:
    """The trace every reviewer should read: nobody ever responds — only
    the clock fires. Walks breach events until the case parks or nothing
    matches."""
    from ioagentfarm.tools.casetier.timers import expiry_event
    steps = simulate_walk(spec, [])
    state = steps[-1].get("to_state", spec["initial_state"])
    # WHICH event the next expiry produces is a property of the action that
    # armed the window, not a constant. Walking a fixed `sla_breach` made the
    # trace disagree with the runtime wherever an action declares its own
    # expiry event: a pause that the platform ends correctly was drawn as a
    # parked ladder. A trace a reviewer is told to trust must show what will
    # actually happen.
    last_action = steps[-1].get("action") if steps else None
    for _ in range(cap):
        breach_event = expiry_event(spec, last_action) or breach_event
        verdict = decide(spec, state, breach_event)
        if verdict is None:
            steps.append({"state": state, "event": breach_event,
                          "verdict": "REFUSED",
                          "note": "ladder exhausted — case parked; only a "
                                  "different typed event moves it"})
            break
        rule_id, action, to_state, sla_param = verdict
        steps.append({"state": state, "event": breach_event,
                      "rule_id": rule_id, "action": action,
                      "to_state": to_state, "window": sla_param})
        last_action = action if sla_param else None
        if to_state == state:
            steps.append({"state": state, "event": breach_event,
                          "verdict": "LOOP",
                          "note": f"{rule_id} re-fires from {state!r} on "
                                  f"every further breach"})
            break
        state = to_state
        if state in set(spec.get("terminal_states", ())):
            break
    return steps


def action_meta(spec: dict, action: str | None) -> dict | None:
    """Side-effect profile for an action. FAIL-CLOSED: an action the spec
    does not declare is treated as side-effecting — the safe assumption for
    retry decisions is 'it may already have been delivered'."""
    if not action:
        return None
    meta = (spec.get("actions") or {}).get(action)
    if meta is None:
        return {"side_effects": True, "declared": False}
    out = {**meta, "declared": True}
    # A null cc_param means the same thing as an absent one: no copy
    # recipient. Normalize HERE so the contract handed to an action
    # workflow never carries an ambiguous null for a prompt to interpret
    # — "directly and exclusively" must be structural in both spellings.
    if out.get("cc_param") is None:
        out.pop("cc_param", None)
    # State the copy decision AFFIRMATIVELY. Absence is a weak signal: a
    # reader that has just sent three notices carrying a copy recipient
    # can read a missing key as "unspecified" and carry the habit over.
    # Observed live — a regulatory notice the contract marked exclusive
    # went out with a copy recipient. An explicit value is harder to
    # overlook than an absent one.
    if out.get("delivery") == "email":
        out["cc_policy"] = ("exclusive" if "cc_param" not in out
                            else out["cc_param"])
    # A workflow contract carries its events RESOLVED, so the settler and
    # the act step read one value, never a default they might spell
    # differently.
    if out.get("delivery") == "workflow":
        out["completion_event"] = out.get("completion_event") \
            or WORKFLOW_COMPLETED
        out["failure_event"] = out.get("failure_event") or WORKFLOW_FAILED
    return out


#: The events a commissioned run's outcome arrives as, unless the action
#: declares its own (`completion_event` / `failure_event`). `system_error`
#: is the failure default on purpose: the compile rules already make it
#: "the platform's problem, not the matter's", which is what a failed run
#: is.
WORKFLOW_COMPLETED = "workflow_completed"
WORKFLOW_FAILED = "system_error"


def commissioned_workflows(spec: dict) -> list[tuple[str, dict]]:
    """``[(action_name, contract)]`` for every action that commissions a
    workflow - the reviewer's list, and the resolution check's."""
    return [(n, m) for n, m in sorted((spec.get("actions") or {}).items())
            if isinstance(m, dict) and m.get("delivery") == "workflow"]


def _resolvable_workflows_from_loader(workspace: str | None = None) -> set[str]:
    from ioagentfarm.engine.workflow_loader import resolvable_workflow_names
    names = set(resolvable_workflow_names(workspace))
    # UNION THE DECLARED TIER, like the play store's copy - and this WAS
    # the copy trap this repo keeps finding: the union landed in the play
    # store's resolver, this byte-identical twin kept answering
    # loader-only, and the stage validator refused a compile-only draft's
    # `workflow: signal_detection` while the catalog handed to the same
    # compiler listed it. The compiler believed the validator (correctly)
    # and downgraded three declared workflows to capability requests.
    try:
        from ioagentfarm.tools.playbook_store import declared_workflows
        names |= set(declared_workflows(workspace))
    except ValueError:
        raise
    except Exception:           # noqa: BLE001 - declaration is optional
        pass
    return names


#: The seam tests pin (the meta suite's conftest pins it beside the play
#: store's, to the same catalog).
_resolvable_workflows = _resolvable_workflows_from_loader


def delivery_tool_resolution_errors(spec: dict,
                                    workspace: str | None = None) -> list[str]:
    """An action that delivers by a kind this deployment has declared no
    tool for installs clean and fails at act time ("MCP tools unavailable")
    - after a case is open and a person is owed the notice. Refuse at the
    write path instead: "every system a playbook reaches must resolve to an
    asset the workspace holds" is a check now, not a slide. `verification`
    names its tool in the contract; that tool must be one the deployment
    declares for verification."""
    from ioagentfarm.engine.deliveries import (ENV_VAR, TOOL_KINDS,
                                               describe_deliveries)
    actions = spec.get("actions") or {}
    needs = [(n, m) for n, m in actions.items() if isinstance(m, dict)
             and (m.get("delivery") in TOOL_KINDS
                  or isinstance(m.get("verification"), dict))]
    if not needs:
        return []
    try:
        declared, source = describe_deliveries(workspace)
    except ValueError as e:
        return [f"cannot read the declared deliveries ({e}) - nothing can be "
                f"checked, so nothing is saved"]
    where = (f"declare it in the workspace's deliveries.yaml, the pack's "
             f"deliveries.yaml, or {ENV_VAR}")
    errs: list[str] = []
    kinds = ", ".join(sorted(k for k in declared if k in TOOL_KINDS)) or "none"
    for name, meta in needs:
        kind = meta.get("delivery")
        if kind in TOOL_KINDS and not (declared.get(kind) or {}).get("tool"):
            errs.append(f"actions[{name!r}] delivers by {kind!r}, but this "
                        f"workspace declares no tool for it ({source}: "
                        f"declared kinds: {kinds}) - {where}")
        ver = meta.get("verification")
        if isinstance(ver, dict) and ver.get("tool"):
            allowed = [str(t) for t in
                       ((declared.get("verification") or {}).get("tools")
                        or [])]
            if str(ver["tool"]) not in allowed:
                errs.append(
                    f"actions[{name!r}].verification.tool {ver['tool']!r} is "
                    f"not a tool this workspace declares for verification "
                    f"(declared: {', '.join(allowed) or 'none'}) - {where}")
    errs += recipient_resolution_errors(spec, declared)
    return errs


def declared_recipients(declared: dict) -> list[str]:
    """The roles this workspace can notify, when it says so
    (``email: {recipients: [...]}``). Empty = not declared = any role
    accepted; the template then tells the author so."""
    return [str(r) for r in
            ((declared.get("email") or {}).get("recipients") or [])]


def recipient_resolution_errors(spec: dict, declared: dict,
                                overrides: dict | None = None) -> list[str]:
    """A role a rulebook addresses must be one the workspace can notify,
    WHEN the workspace declares its recipients. A job title that reads
    perfectly and resolves to nobody is the recipient defect one level
    up from "the recipient must be a parameter"."""
    recipients = declared_recipients(declared)
    if not recipients:
        return []
    import difflib
    errs: list[str] = []
    params = spec.get("default_params") or {}
    values = {rp: params.get(rp) for rp in (spec.get("role_params") or [])}
    for rp, val in (overrides or {}).items():
        values[rp] = val
    for rp, val in values.items():
        if val is None or str(val) in recipients:
            continue
        near = difflib.get_close_matches(str(val), recipients, n=2,
                                         cutoff=0.6)
        hint = (f" - did you mean {', '.join(repr(n) for n in near)}?"
                if near else "")
        errs.append(f"{rp} = {val!r} is not a role this workspace can "
                    f"notify{hint}; declared recipients: "
                    f"{', '.join(recipients)}")
    return errs


def capability_resolution_errors(spec: dict,
                                 workspace: str | None = None) -> list[str]:
    """Everything a rulebook reaches must resolve HERE: the workflows its
    actions commission and the tools its deliveries go through. One call
    for the write path, `validate`, compile-stage and compile-approve."""
    return (workflow_delivery_resolution_errors(spec, workspace)
            + delivery_tool_resolution_errors(spec, workspace))


def workflow_delivery_resolution_errors(spec: dict,
                                        workspace: str | None = None
                                        ) -> list[str]:
    """A rulebook action that commissions a workflow which does not
    resolve installs clean and fails when the rule fires - after a case is
    open and a person is waiting on the result. Refuse at the write path
    instead, the standard the play's own `workflow_generate` is held to
    (`playbook_store.workflow_resolution_errors`). Environment-dependent by
    design, so it is NOT part of `validate_spec`: it runs where a rulebook
    is SAVED (`save_rulebook`), at `rulebook validate`, and at
    compile-stage/approve."""
    wanted = commissioned_workflows(spec)
    if not wanted:
        return []
    try:
        known = _resolvable_workflows(workspace)
    except Exception as e:      # noqa: BLE001 - a broken install is refused, not skipped
        return [f"cannot enumerate the installed workflows "
                f"({type(e).__name__}: {e}) - nothing can be checked, so "
                f"nothing is saved"]
    import difflib
    errs: list[str] = []
    legal = ", ".join(sorted(known)) or "(none installed)"
    for action, meta in wanted:
        name = str(meta.get("workflow") or "").strip()
        if not name or name in known:
            continue
        near = difflib.get_close_matches(name, sorted(known), n=3, cutoff=0.6)
        hint = (f" - did you mean {', '.join(repr(n) for n in near)}?"
                if near else "")
        # No "; " inside: `rulebook put` joins errors on it and splits
        # them back for printing, so one would read as two.
        errs.append(f"actions[{action!r}].workflow {name!r} does not "
                    f"resolve to an installed workflow{hint} - workflows "
                    f"that do: {legal}")
    return errs


def save_rulebook(cur, ph: str, spec: dict, who: str) -> int:
    """Validated upsert of a rulebook document — the ONE write path, shared
    by the CLI and the compile-approval flow so they cannot diverge.
    Raises ValueError (joined error strings) on an invalid spec; the caller
    commits. Returns the new revision."""
    errs = validate_spec(spec) + capability_resolution_errors(spec)
    if errs:
        raise ValueError("; ".join(errs))
    from ioagentfarm.tools.casetier import repo as _repo
    tid = spec["template_id"]
    row = _repo.rulebook_revision(cur, ph, tid)
    body = {k: v for k, v in spec.items() if k != "_revision"}
    if row:
        rev = row["revision"] + 1
        _repo.update_rulebook(cur, ph, tid, spec["title"],
                              json.dumps(body, indent=2), rev, who)
    else:
        rev = 1
        _repo.insert_rulebook(cur, ph, tid, spec["title"],
                              json.dumps(body, indent=2), rev, who)
    return rev


def cases_a_revision_strands(cur, ph: str, spec: dict) -> list[dict]:
    """Open cases the given spec could not decide: their current state is
    not one of its `states`.

    A rulebook is live for every FUTURE transition, so installing one over
    open cases is a migration, not an edit. A revision that renames or
    drops a state leaves every case sitting in it unreachable - `decide`
    answers None for a state it has never heard of, and the refusal reads
    as a wrong EVENT ("no rule for state=TRIAGE event=...") rather than as
    a rulebook that moved under the case. Found while re-walking the
    brand-marketing playbook, whose review step invites approving a
    freshly compiled draft that names its states differently, with a case
    already open on the installed one.

    Callers WARN and save anyway: a rename with a migration behind it is
    legitimate, and refusing would make the emergency fix the hard path.
    """
    from ioagentfarm.tools.casetier import repo as _repo
    tid = spec.get("template_id")
    fresh = set(spec.get("states") or ())
    live = load_rulebook(cur, ph, tid) or {}
    settled = set(live.get("terminal_states") or ())
    out = []
    for row in _repo.list_cases(cur, ph):
        if row["template"] != tid:
            continue
        state = row["state"]
        if state in fresh or state in settled:
            continue
        out.append({"case_id": row["case_id"], "state": state})
    return out


def warn_about_stranded_cases(stranded: list[dict], template_id: str,
                              rev: int) -> None:
    """One spelling of the warning, shared by `rulebook put` and
    `compile-approve` - the two ways a revision reaches a live tenant."""
    if not stranded:
        return
    import sys as _sys
    states = sorted({row["state"] for row in stranded})
    print(f"WARNING: {len(stranded)} open case(s) are in a state "
          f"{template_id} rev {rev} does not define ({', '.join(states)}) "
          f"- no event can move them, and the refusal will read as a "
          f"wrong event:", file=_sys.stderr)
    for row in stranded[:10]:
        print(f"  {row['case_id']}  [{row['state']}]", file=_sys.stderr)
    if len(stranded) > 10:
        print(f"  ... and {len(stranded) - 10} more", file=_sys.stderr)
    print("  fix: install a revision that keeps those state names, or "
          "close those cases under the previous one first", file=_sys.stderr)


def load_rulebook(cur, ph: str, template_id: str) -> dict | None:
    from ioagentfarm.tools.casetier import repo as _repo
    row = _repo.rulebook_spec(cur, ph, template_id)
    if not row:
        return None
    spec = json.loads(row["spec_json"])
    spec["_revision"] = row["revision"]
    return spec


def decide(spec: dict, state: str, event: str) -> tuple | None:
    """The generic rule engine. Same (spec, state, event) in, same answer
    out, every time. None = unmatched (terminal state, or no rule row).
    Wildcard (any-state) rules take precedence; a terminal state accepts
    nothing."""
    if state in set(spec.get("terminal_states", ())):
        return None
    for w in spec.get("wildcard_rules", []):
        if w["event"] == event:
            return (w["rule_id"], w["action"], w["to_state"],
                    w.get("sla_param"))
    for r in spec["rules"]:
        if r["from_state"] == state and r["event"] == event:
            return (r["rule_id"], r["action"], r["to_state"],
                    r.get("sla_param"))
    return None
