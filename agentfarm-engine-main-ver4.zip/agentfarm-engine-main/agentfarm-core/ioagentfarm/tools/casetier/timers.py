"""casetier.timers — the durable clock store and its lifecycle.

The case tier never counts time. It records, transactionally, that a clock
is running; an emitter decides when that clock is due and calls back with
a typed event. This module owns the record and the selection, never the
decision.

Three properties are load-bearing and each exists because of a specific
failure:

* **A timer row is written in the SAME transaction as the transition that
  starts the window.** An emitter that is down at that instant loses
  nothing, and no transition depends on an emitter being reachable.
* **The superseded row is cancelled in that same transaction.** Prevention:
  most stale triggers are never fired at all.
* **Selection excludes clocks already applied.** Suppression is recorded
  in the ledger, which is correct evidence for a human retry and ruinous
  on an interval — three emitters sweeping every sixty seconds against a
  parked case would write thousands of suppression rows a day. Dedup at
  SELECTION makes the steady state zero attempts; intake suppression stays
  as the safety net for external callers and genuine races.
"""
from __future__ import annotations

import json
import os
import time

from ioagentfarm.tools.casetier.store import _now, _workspace
from ioagentfarm.tools.casetier import calendar as cal
from ioagentfarm.tools.casetier import repo as _repo

#: Outcomes of applying a timer trigger. Exactly ONE is retryable; a
#: caller that retries any other hammers a case that is behaving
#: correctly.
OUTCOME_FIRED = "fired"              # a rule matched; the case advanced
OUTCOME_SUPPRESSED = "suppressed"    # this occurrence was already applied
OUTCOME_FENCED = "fenced"            # names a clock that is no longer current
OUTCOME_UNMATCHED = "unmatched"      # the rulebook has no rule for it
OUTCOME_SKIPPED = "skipped"          # the window's own notice never went out
OUTCOME_ERROR = "error"              # THE ONLY RETRYABLE OUTCOME

#: SETTLED FOR THE CALLER — an emitter that receives any of these has
#: finished its job and must not retry. `skipped` belongs here: retrying
#: it would hammer a case whose delivery a person must fix first.
TERMINAL_OUTCOMES = (OUTCOME_FIRED, OUTCOME_SUPPRESSED, OUTCOME_FENCED,
                     OUTCOME_UNMATCHED, OUTCOME_SKIPPED)

#: CONSUMES THE CLOCK — a narrower set. `skipped` is deliberately absent:
#: the window really did expire, and the only reason it was not applied is
#: an undelivered notice that a person is expected to resolve. Consuming
#: the timer there would DROP the deadline, leaving the case with no clock
#: at all — silently stalled, which is worse than escalating. The row
#: stays pending, remains visible in `due` as blocked, and fires once the
#: delivery is recorded. Re-attempting costs nothing: the undelivered
#: check returns before any ledger write.
CONSUMING_OUTCOMES = (OUTCOME_FIRED, OUTCOME_SUPPRESSED, OUTCOME_FENCED,
                      OUTCOME_UNMATCHED)


#: The GOAL clock's sentinel sequence. Rung clocks are fenced by the
#: case's monotonic clock_seq (>= 1) and superseded on every transition;
#: the goal clock is raised against the CASE, survives every rung move,
#: and is therefore exempt from the fence. 0 is unreachable for a rung.
GOAL_CLOCK_SEQ = 0


def clock_key(case_id: str, clock_seq: int, deadline: str) -> str:
    """The idempotency key for one clock instance. Derived from the case's
    own recorded clock rather than from the moment of firing, so any two
    emitters naming the same clock collide by construction."""
    return f"clock:{case_id}:{clock_seq}:{deadline}"


def goal_event(spec: dict) -> str:
    """The typed event the goal window's expiry produces."""
    return spec.get("goal_event") or "goal_overdue"


def expiry_event(spec: dict, action: str | None) -> str:
    """Which typed event a window's expiry produces. Declared by the
    action's contract (a pause expiring is not a breach), falling back to
    the rulebook's default and then to the platform's core lexicon."""
    meta = (spec.get("actions") or {}).get(action or "") or {}
    return (meta.get("expiry_event")
            or spec.get("breach_event")
            or "sla_breach")


def case_holidays(cur, ph: str, spec: dict) -> frozenset:
    region = (spec.get("calendar") or "").strip()
    return cal.load_holidays(cur, ph, _workspace(), region)


def deadline_for(case: dict, spec: dict, holidays=()) -> str | None:
    """The deadline of the case's running clock, honouring the rulebook's
    business-day declaration."""
    return cal.compute_deadline(
        case.get("sla_started_at"), case.get("sla_days"),
        business=bool(spec.get("business_days", True)),
        holidays=holidays)


def cancel_pending(cur, ph: str, case_id: str, reason: str = "superseded",
                   include_goal: bool = False):
    """Cancel a case's pending RUNG timers. Called inside the transition
    transaction, so a clock that has been replaced cannot fire. The goal
    clock is deliberately excluded by default — it measures total elapsed
    time toward the objective and must survive every rung move; only a
    terminal transition takes it too (include_goal=True)."""
    _repo.cancel_pending_timers(
        cur, ph, case_id, reason,
        keep_clock_seq=None if include_goal else GOAL_CLOCK_SEQ)


def schedule(cur, ph: str, case: dict, spec: dict, holidays=()) -> dict | None:
    """Record the clock the case is now running. No row when the case
    carries no window or has reached a terminal state — there is nothing
    to fire."""
    state = case.get("state")
    if state in set(spec.get("terminal_states", ("CLOSED",))):
        return None
    if case.get("sla_days") in (None, ""):
        return None
    deadline = deadline_for(case, spec, holidays)
    if not deadline:
        return None
    seq = int(case.get("clock_seq") or 1)
    event = expiry_event(spec, case.get("sla_kind"))
    key = clock_key(case["case_id"], seq, deadline)
    _repo.insert_timer(cur, ph, case["case_id"], seq, case.get("sla_kind"),
                       event, deadline, key)
    return {"case_id": case["case_id"], "clock_seq": seq, "event": event,
            "deadline": deadline, "idem_key": key}


def schedule_goal(cur, ph: str, case_id: str, opened_at: str, spec: dict,
                  params: dict, holidays=()) -> dict | None:
    """Record the case's ONE goal clock, at open time only. No row when
    the rulebook declares no goal window. One-shot by design: the goal
    deadline is total-elapsed-time, so nothing ever restarts it, and its
    idem key carries no clock_seq — it is not a rung."""
    param = (spec.get("goal_sla_param") or "").strip()
    if not param:
        return None
    days = params.get(param)
    deadline = cal.compute_deadline(
        opened_at, days, business=bool(spec.get("business_days", True)),
        holidays=holidays)
    if not deadline:
        return None
    event = goal_event(spec)
    key = f"goal:{case_id}:{deadline}"
    _repo.insert_timer(cur, ph, case_id, GOAL_CLOCK_SEQ, "goal", event,
                       deadline, key)
    _repo.set_goal_deadline(cur, ph, case_id, deadline)
    return {"case_id": case_id, "event": event, "deadline": deadline,
            "idem_key": key}


def due(cur, ph: str, now: str | None = None, limit: int = 500) -> list[dict]:
    """Pending clocks whose deadline has passed, excluding any whose key
    is already in the ledger — the selection-time deduplication that keeps
    the steady state at zero attempts."""
    return _repo.due_timers(cur, ph, now or _now(), limit)


def lease(cur, ph: str, rows: list[dict], holder: str,
          seconds: int = 120) -> list[dict]:
    """Claim due rows for one emitter. Cluster safety without leader
    election: a row already leased and unexpired is left alone, and the
    fence refuses anything that slips through anyway."""
    if not rows:
        return []
    until = time.strftime("%Y-%m-%dT%H:%M:%S",
                          time.localtime(time.time() + seconds))
    claimed = []
    for r in rows:
        if _repo.lease_timer(cur, ph, r["id"], holder, until):
            claimed.append(r)
    return claimed


def complete(cur, ph: str, timer_id: int, outcome: str) -> None:
    """Close out a timer. Every outcome except an error is terminal: a
    fenced, unmatched or suppressed trigger is finished work, not a
    failure to retry."""
    status = "fired" if outcome in CONSUMING_OUTCOMES else "pending"
    _repo.complete_timer(cur, ph, timer_id, status, outcome)


def hold(cur, ph: str, timer_id: int, outcome: str) -> None:
    """Record an attempt without consuming the clock or spending the
    retry budget. Used where the platform decided correctly not to apply
    a deadline and a person must clear the condition before it can fire."""
    _repo.hold_timer(cur, ph, timer_id, outcome)


def max_attempts() -> int:
    try:
        return max(1, int(os.environ.get("IOF_TIMER_MAX_ATTEMPTS", "5")))
    except ValueError:
        return 5


def give_up(cur, ph: str, timer_id: int, outcome: str) -> None:
    _repo.fail_timer(cur, ph, timer_id, outcome)
