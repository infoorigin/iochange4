"""casetier.store — database plumbing for the case tier.

Root inference, adapter, schema + additive columns, tenancy scoping,
connection (seeds applied lazily from .rulebook to avoid a cycle), and
the two row helpers every command shares.
"""
from __future__ import annotations

import json
import os
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ------------------------------------------------------------------ db

def _infer_root(*hints: str) -> Path | None:
    for hint in hints:
        if not hint:
            continue
        p = Path(hint).resolve()
        for parent in (p, *p.parents):
            if parent.name == "instances" and parent.parent.name:
                return parent.parent
    return None


def _db_url(*hints: str) -> str:
    url = (os.environ.get("IOF_DATABASE_URL") or "").strip()
    if url:
        return url
    env_root = (os.environ.get("IOF_ROOT") or "").strip()
    root = Path(env_root).resolve() if env_root else (_infer_root(*hints)
                                                     or Path(".iof").resolve())
    root.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{root / 'state.db'}"


def _adapter(*hints: str):
    from ioagentfarm.engine.db import make_adapter
    return make_adapter(_db_url(*hints))


_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS meta_rulebooks (
        template_id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        spec_json TEXT NOT NULL,
        revision INTEGER NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS meta_cases (
        case_id TEXT PRIMARY KEY,
        play_id TEXT NOT NULL,
        template TEXT NOT NULL,
        group_ref TEXT NOT NULL,
        item_ref TEXT NOT NULL,
        state TEXT NOT NULL,
        sla_kind TEXT,
        sla_days TEXT,
        sla_started_at TEXT,
        params_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS meta_case_events (
        id {auto_id},
        case_id TEXT NOT NULL,
        event TEXT NOT NULL,
        detail TEXT,
        rule_id TEXT,
        action TEXT,
        from_state TEXT,
        to_state TEXT,
        idem_key TEXT,
        rulebook_revision INTEGER,
        created_at TEXT NOT NULL
    )""",
    # The durable clock store. A scheduler holds NOTHING of its own: it
    # rebuilds its entire working set from this table on every start, so
    # losing the scheduler cannot lose a clock. Rows are written in the
    # SAME transaction as the transition that starts a window, and the
    # superseded row is cancelled in that same transaction.
    """CREATE TABLE IF NOT EXISTS meta_case_timers (
        id {auto_id},
        case_id TEXT NOT NULL,
        workspace_code TEXT,
        clock_seq INTEGER NOT NULL,
        sla_kind TEXT,
        event TEXT NOT NULL,
        deadline TEXT NOT NULL,
        idem_key TEXT NOT NULL,
        status TEXT NOT NULL,
        leased_by TEXT,
        leased_until TEXT,
        attempts INTEGER NOT NULL DEFAULT 0,
        last_outcome TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""",
    # A run a case COMMISSIONED: one row per workflow delivery, written in
    # the same transaction as the delivery record. The scheduler settles
    # it - reads the engine's `runs` row and applies the declared
    # completion or failure event through `apply_timer_event`, the single
    # path every emitter uses - so a finished analysis reaches the case
    # without anyone relaying it. Holds nothing the `runs` table does not
    # already know; it is the LINK, and the idempotency of settling it.
    """CREATE TABLE IF NOT EXISTS meta_case_runs (
        id {auto_id},
        case_id TEXT NOT NULL,
        workspace_code TEXT,
        action TEXT NOT NULL,
        workflow TEXT NOT NULL,
        run_id TEXT NOT NULL,
        clock_seq INTEGER,
        completion_event TEXT NOT NULL,
        failure_event TEXT NOT NULL,
        status TEXT NOT NULL,
        outcome TEXT,
        run_status TEXT,
        kind TEXT,
        attempts INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        settled_at TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS meta_calendars (
        region TEXT NOT NULL,
        workspace_code TEXT,
        holidays_json TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""",
]

#: Additive columns for databases created before v2 — mirrors the
#: engine's _ensure_column pattern: ALTER is attempted once per connect
#: and silently skipped where the column already exists.
_ENSURE_COLUMNS = [
    ("meta_case_events", "idem_key", "TEXT"),
    # The engine status the link was settled on (done/failed). A run the
    # engine marked failed can be retried back to done by its driver; the
    # settler keeps watching a link settled on `failed` for exactly that.
    ("meta_case_runs", "run_status", "TEXT"),
    # 'workflow' = a run a rule commissioned (its outcome is an event);
    # 'delivery' = a case_action run delivering a decision (its claim is
    # what stops two runs sending the same notice).
    ("meta_case_runs", "kind", "TEXT"),
    ("meta_case_events", "rulebook_revision", "INTEGER"),
    ("meta_cases", "workspace_code", "TEXT"),
    ("meta_rulebooks", "workspace_code", "TEXT"),
    # The FENCE. A monotonic counter bumped on every transition: a timer
    # carries the sequence it was scheduled against, and a trigger naming
    # a superseded clock is refused. A deadline would nearly always work
    # and has a coincidence case (a clock restarted at the same instant
    # with an identical window); an integer has none.
    ("meta_cases", "clock_seq", "INTEGER"),
    # The GOAL deadline: one case-level window opened at creation and
    # never reset by rung transitions — every rung clock is per-window,
    # so a case whose ladder keeps legitimately extending has no bound on
    # total elapsed time toward the objective without this.
    ("meta_cases", "goal_deadline", "TEXT"),
    # PLAY COMPOSITION: a case opened by another case's open_play action
    # carries its parent durably. The parent's ledger holds the claim
    # (action_completed naming the children); this column is the truth
    # side, and what explain's children view and the cycle guard read.
    ("meta_cases", "parent_case_id", "TEXT"),
]

#: Indexes applied per connect. The unique one is the last-resort tiebreak
#: under a true race: two emitters that both pass the duplicate lookup
#: before either writes. Partial (idem_key IS NOT NULL) so the many rows
#: written without a key — human transitions, action receipts — are
#: unaffected.
_INDEXES = [
    # Scoped to rows that CONSUME an occurrence — a decision or a refusal.
    # A DUPLICATE_SUPPRESSED row records that an occurrence arrived again
    # and is evidence, not consumption; including it here would make the
    # second arrival of a key crash instead of being suppressed.
    ("uq_meta_case_events_idem",
     "CREATE UNIQUE INDEX IF NOT EXISTS uq_meta_case_events_idem "
     "ON meta_case_events(case_id, idem_key) WHERE idem_key IS NOT NULL "
     "AND action <> 'DUPLICATE_SUPPRESSED'"),
    ("ix_meta_case_timers_due",
     "CREATE INDEX IF NOT EXISTS ix_meta_case_timers_due "
     "ON meta_case_timers(status, deadline)"),
]


def _workspace() -> str:
    """The tenancy stamp for meta-tier rows. Empty = unscoped (single-
    tenant/dev, and every test): no filtering happens. When set, writes
    stamp it and ENUMERATION surfaces (list/audit/kpi/rulebook list)
    filter to it plus legacy/shared blank rows. Id-addressed reads
    (show/ctx/history/explain by case id) stay unscoped — a case id is
    globally unique and the view surfaces are where tenancy leaks."""
    return (os.environ.get("IOF_WORKSPACE") or "").strip()


def _scope_sql(ph: str, column: str = "workspace_code"):
    """(clause, params) to append with AND for a scoped enumeration."""
    ws = _workspace()
    if not ws:
        return "", ()
    return (f" AND ({column} = {ph} OR {column} IS NULL "
            f"OR {column} = '')", (ws,))


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


#: Databases whose schema this process has already ensured, by URL. The
#: DDL is idempotent, but it is ~15 statements, and a scheduler pass opens
#: many connections; on RDS that was seconds of nothing per pass.
_ENSURED: set[str] = set()


def _guarded(cur, sql: str, params=()) -> bool:
    """Run one statement that may legitimately fail (a column that exists,
    an index over duplicate rows) WITHOUT aborting the transaction. On
    Postgres a failed statement poisons the transaction until a rollback;
    a SAVEPOINT confines the failure to the statement. SQLite honours the
    same SAVEPOINT syntax, so one code path serves both."""
    cur.execute("SAVEPOINT guarded")
    try:
        cur.execute(sql, params)
        cur.execute("RELEASE SAVEPOINT guarded")
        return True
    except Exception:       # noqa: BLE001 - the statement was optional
        cur.execute("ROLLBACK TO SAVEPOINT guarded")
        cur.execute("RELEASE SAVEPOINT guarded")
        return False


def _column_exists(cur, ph: str, table: str, col: str) -> bool:
    """Portable probe: SELECT the column from an empty result."""
    return _guarded(cur, f"SELECT {col} FROM {table} LIMIT 0")


def reset_schema_memo() -> None:
    """Tests that point one process at several databases."""
    _ENSURED.clear()


def _connect(adapter):
    con = adapter.connect()
    adapter.init_connection(con)
    key = getattr(adapter, "_dsn", None) or getattr(adapter, "_path", None) \
        or repr(adapter)
    if str(key) in _ENSURED:
        return con
    cur = con.cursor()
    # `auto_id` is the adapter's spelling of an auto-increment primary key:
    # SQLite wants INTEGER PRIMARY KEY AUTOINCREMENT, PostgreSQL wants SERIAL
    # PRIMARY KEY and rejects the SQLite form as a syntax error. Both were
    # hardcoded to the SQLite spelling here, so meta_case_events and
    # meta_case_timers - the ledger and the durable clock - could not be
    # created on PostgreSQL at all, and this loop is not guarded, so every
    # iof-case command died at connect. Seven other modules in core already
    # go through auto_id(); this one did not.
    for ddl in _SCHEMA:
        cur.execute(ddl.format(auto_id=adapter.auto_id()))
    ph = adapter.placeholder()
    for table, col, typ in _ENSURE_COLUMNS:
        if not _column_exists(cur, ph, table, col):
            _guarded(cur, f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
    for _name, ddl in _INDEXES:
        # A pre-existing database may hold duplicate (case_id, idem_key)
        # pairs written before the index existed; the unique index then
        # cannot be created. Suppression still works through the lookup —
        # the index is the race tiebreak, not the mechanism — so this must
        # not stop the tool, and must not poison the transaction either.
        _guarded(cur, ddl)
    # Lazy: .rulebook imports _now from here; seeds only exist at connect
    # time, so the cycle never materializes.
    from ioagentfarm.tools.casetier.rulebook import _SEED_SPECS
    for spec in _SEED_SPECS:
        cur.execute(f"SELECT 1 FROM meta_rulebooks WHERE template_id = {ph}",
                    (spec["template_id"],))
        if not cur.fetchone():
            cur.execute(
                f"""INSERT INTO meta_rulebooks (template_id, title,
                    spec_json, revision, updated_at, updated_by)
                    VALUES ({ph},{ph},{ph},{ph},{ph},{ph})""",
                (spec["template_id"], spec["title"],
                 json.dumps(spec, indent=2), 1, _now(), "seed"))
    con.commit()
    _ENSURED.add(str(key))
    return con


# ------------------------------------------------------------- commands

def _as_dict(cur, row):
    """One fetched row as a dict on BOTH drivers. The Postgres adapter's
    cursor already yields dicts (RealDictCursor); zipping column names over
    one of those iterates its KEYS and corrupts every value - which is how
    `rulebook list` on RDS printed the column names as data (2026-08-25).
    SQLite yields tuples, which need the zip."""
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    if hasattr(row, "keys"):            # sqlite3.Row and other mappings
        return {k: row[k] for k in row.keys()}
    cols = [d[0] for d in cur.description]
    return dict(zip(cols, row))


def _one(cur) -> dict | None:
    """`fetchone()` as a dict, or None. Access rows by NAME, never by
    position: a positional index works on SQLite's tuples and raises
    KeyError on Postgres's dicts."""
    return _as_dict(cur, cur.fetchone())


def _rows(cur) -> list[dict]:
    return [_as_dict(cur, r) for r in cur.fetchall()]


def _ledger(cur, ph, case_id, event, detail, rule_id, action, frm, to,
            idem_key=None, revision=None):
    """One ledger row. The statement lives in `casetier.repo` with every
    other one; this name stays because the commands, the play store and the
    tests all reach the ledger through it."""
    from ioagentfarm.tools.casetier.repo import insert_event
    insert_event(cur, ph, case_id, event, detail, rule_id, action, frm, to,
                 idem_key=idem_key, revision=revision)


# -------------------------------------------------------------- session

@dataclass
class Session:
    """One open connection and what every repository call needs from it.
    `discard()` turns the commit at exit into a rollback - for a command
    that wrote something and then refused (a second item that already
    exists, a rulebook with no rule for the open event), which must leave
    nothing behind, exactly as closing the connection uncommitted did."""
    con: Any
    cur: Any
    ph: str
    adapter: Any
    _commit: bool = field(default=True, repr=False)

    def discard(self) -> None:
        self._commit = False


@contextmanager
def _run_session(adapter, con):
    """The lifecycle behind `session()`, shared with the play store: commit
    on a normal exit (rollback after `discard()`), roll back on an
    exception, and ALWAYS return the connection."""
    s = Session(con=con, cur=con.cursor(), ph=adapter.placeholder(),
                adapter=adapter)
    try:
        yield s
    except BaseException:
        try:
            con.rollback()
        except Exception:       # noqa: BLE001 - the error in flight matters more
            pass
        con.close()
        raise
    try:
        if s._commit:
            con.commit()
        else:
            con.rollback()
    finally:
        con.close()


@contextmanager
def session(*hints):
    """`with session(*hints) as s:` - the ONE way a command opens the case
    tier's database. `s.cur`/`s.ph` go to the repository functions; the
    connection is committed and closed for the caller."""
    adapter = _adapter(*hints)
    with _run_session(adapter, _connect(adapter)) as s:
        yield s
