"""casetier.analysis — ledger interpretation (pure).

The ONE decision-delivery analysis both ctx and explain/audit read, and
the SLA posture reader. No database access.
"""
from __future__ import annotations

import time



def surviving_pending(spec: dict, state: str, pending):
    """The pending action once the case's state is taken into account.

    A terminal case accepts no NEW work — that is what nulling this out
    was written for, and it is right. But it also erased a delivery the
    CLOSING transition itself had ordered. Found live: a rulebook ordered
    legally-mandated verbatim wording to a compliance lead and closed the
    case in the same rule; `explain` listed the message PENDING, `ctx`
    offered nothing to commission, and `audit` called the case healthy.
    The message could never have been sent, and the surface an operator
    watches said everything was fine.

    The first instinct was to refuse such a rulebook at install. That was
    wrong: SIX of sixteen installed rulebooks order a closing
    notification, written independently from independent prose, so
    "notify and close" is the normal business shape and the platform was
    refusing to serve it.

    So: a real delivery survives the close and stays commissionable; a
    bookkeeping close action does not become work. Shared by ctx and
    audit deliberately — a reader and its fleet view disagreeing about
    what is owed is how this defect stayed invisible.
    """
    from ioagentfarm.tools.casetier.rulebook import action_meta
    if not pending:
        return None
    if state not in set(spec.get("terminal_states") or ["CLOSED"]):
        return pending
    meta = action_meta(spec, pending) or {}
    if meta.get("delivery") and meta.get("side_effects", True):
        return pending
    return None


def prior_window(history: list[dict], spec: dict, params: dict):
    """The SLA window that JUST EXPIRED — not the one now starting.

    `sla_days` on the case row is the window the newest decision OPENED.
    Approved language about an escalation almost always refers to the
    window that ran out, and those are different numbers: a live case
    delivered reviewed regulatory wording asserting "the escalation window
    of 45 business days has now expired" when the window that expired was
    5. The compiler had been telling reviewers the wrong one, through the
    feature whose entire premise is that approved language is never
    altered.

    Returns None when the case has made only one decision (nothing has
    expired yet) or the prior rung carried no window — callers must render
    an absent value as absent, never as zero.
    """
    rules = {}
    for r in (spec.get("rules") or []) + (spec.get("wildcard_rules") or []):
        if isinstance(r, dict) and r.get("rule_id"):
            rules[r["rule_id"]] = r
    # history arrives newest-first; the newest decision opened the window
    # now running, so the one before it is the window that expired.
    decisions = [h for h in history
                 if h.get("rule_id") and h.get("to_state")]
    if len(decisions) < 2:
        return None
    rule = rules.get(decisions[1].get("rule_id"))
    if not rule:
        return None
    name = rule.get("sla_param")
    return (params or {}).get(name) if name else None


def analyze_history(history: list[dict]) -> dict:
    """Decision-delivery analysis over a case's ledger (rows NEWEST FIRST).

    The ONE implementation both `ctx` (pending-action guard) and `explain`
    (postmortem) read — a reader pair sharing its discovery code cannot
    disagree about what is pending. Classifies every rule decision as
    delivered (an action_completed for the same action exists NEWER than
    it), pending (newest decision, undelivered) or superseded (older
    undelivered decision — a later event replaced it before delivery; its
    output must NOT be delivered). UNMATCHED rows are refusal records,
    never work.
    """
    completed_newer: set = set()
    receipts: dict = {}
    decisions: list[dict] = []
    unmatched: list[dict] = []
    for h in history:
        ev = h.get("event")
        if ev == "action_completed":
            completed_newer.add(h.get("action"))
            receipts.setdefault(h.get("action"), h.get("detail"))
            continue
        act = h.get("action")
        if act == "UNMATCHED":
            unmatched.append(h)
            continue
        if act == "DUPLICATE_SUPPRESSED":
            continue        # intake-idempotency record, never work
        if not act:
            continue
        delivered = act in completed_newer
        decisions.append({**h, "delivered": delivered,
                          "receipt": receipts.get(act) if delivered
                          else None})
    pending = None
    for i, d in enumerate(decisions):
        d["superseded"] = i > 0 and not d["delivered"]
    if decisions and not decisions[0]["delivered"]:
        pending = decisions[0]["action"]
    return {"pending": pending, "decisions": decisions,
            "unmatched": unmatched}


# --------------------------------------------------- case forensics

def _sla_posture(case: dict, spec: dict | None = None,
                 holidays=()) -> dict:
    """SLA clock reading from the case row. Reports; never synthesizes an
    event — the monitoring system owns the clocks.

    The deadline MUST be computed the same way the timer computes it. It
    was not: the timer moved to business days while this reader stayed on
    calendar arithmetic, so `explain` showed an operator a deadline
    eighteen days earlier than the one the platform would actually act on.
    A reporting surface that disagrees with execution is worse than either
    being wrong alone — it is the surface an auditor trusts.
    """
    from ioagentfarm.tools.casetier import calendar as _cal
    out = {"sla_kind": case.get("sla_kind"), "sla_days": case.get("sla_days"),
           "sla_started_at": case.get("sla_started_at"),
           "deadline": None, "appears_expired": None}
    deadline = _cal.compute_deadline(
        case.get("sla_started_at"), case.get("sla_days"),
        business=bool((spec or {}).get("business_days", True)),
        holidays=holidays)
    if not deadline:
        return out
    out["deadline"] = deadline
    try:
        out["appears_expired"] = time.time() > time.mktime(
            time.strptime(deadline, "%Y-%m-%dT%H:%M:%S"))
    except Exception:                     # noqa: BLE001
        pass
    return out
