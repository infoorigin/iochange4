"""casetier.repo — every SQL statement of the case tier, in one place.

One statement per function; the SQL beside it as a module-level `SQL_*`
constant so a grammar test can enumerate every template this tier ships
(`tests_meta/test_sql_parses_as_postgres.py`), and a count pin can assert
that no `cur.execute(` exists anywhere else in the tier
(`tests_meta/test_sql_lives_in_the_repo.py`). A database change fails
HERE, in one module, not across the command surface.

Conventions, all of them load-bearing on PostgreSQL:

* Placeholders are `{ph}` and are formatted at call time from the
  adapter (`?` on SQLite, `%s` on psycopg2). Never a literal.
* `{scope}` is the tenancy clause `store._scope_sql` produces (empty when
  no workspace is selected); its parameters ride behind the statement's
  own.
* Rows come back as dicts through `store._one` / `store._rows` and are
  read by COLUMN NAME. The Postgres adapter yields dicts already; a
  positional index raises KeyError there and silently worked on SQLite.
* A statement that may legitimately fail (a table another tier owns) is
  fenced by a SAVEPOINT: on Postgres a failed statement poisons the
  transaction until a rollback.

Every function takes `(cur, ph, ...)`: the cursor and placeholder of the
session the caller holds (`store.session()`), or of a connection a test
opened by hand.
"""
from __future__ import annotations

import json

from ioagentfarm.tools.casetier.store import (_now, _one, _rows, _scope_sql,
                                               _workspace)


def _fmt(sql: str, ph: str, scope: str = "") -> str:
    return sql.format(ph=ph, scope=scope)


# ------------------------------------------------------------- the ledger

SQL_INSERT_EVENT = """INSERT INTO meta_case_events (case_id, event, detail,
    rule_id, action, from_state, to_state, idem_key, rulebook_revision,
    created_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_event(cur, ph, case_id, event, detail, rule_id, action, frm, to,
                 idem_key=None, revision=None) -> None:
    cur.execute(_fmt(SQL_INSERT_EVENT, ph),
                (case_id, event, detail, rule_id, action, frm, to, idem_key,
                 revision, _now()))


SQL_EVENT_WITH_KEY_EXISTS = """SELECT 1 AS present FROM meta_case_events
    WHERE case_id = {ph} AND idem_key = {ph}"""


def event_with_key_exists(cur, ph, case_id: str, idem_key: str) -> bool:
    cur.execute(_fmt(SQL_EVENT_WITH_KEY_EXISTS, ph), (case_id, idem_key))
    return _one(cur) is not None


SQL_CASE_HISTORY_DESC = """SELECT event, detail, rule_id, action, from_state,
    to_state, rulebook_revision, created_at
    FROM meta_case_events WHERE case_id = {ph} ORDER BY id DESC"""


def case_history_desc(cur, ph, case_id: str) -> list[dict]:
    """Newest first - the order `analyze_history` reads."""
    cur.execute(_fmt(SQL_CASE_HISTORY_DESC, ph), (case_id,))
    return _rows(cur)


SQL_CASE_HISTORY = """SELECT event, detail, rule_id, action, from_state,
    to_state, rulebook_revision, created_at
    FROM meta_case_events WHERE case_id = {ph} ORDER BY id"""


def case_history(cur, ph, case_id: str) -> list[dict]:
    """Oldest first - the order `history` prints."""
    cur.execute(_fmt(SQL_CASE_HISTORY, ph), (case_id,))
    return _rows(cur)


SQL_CASE_EVENTS_FOR_KPI = """SELECT event, rule_id, action, to_state,
    created_at FROM meta_case_events WHERE case_id = {ph} ORDER BY id"""


def case_events_for_kpi(cur, ph, case_id: str) -> list[dict]:
    cur.execute(_fmt(SQL_CASE_EVENTS_FOR_KPI, ph), (case_id,))
    return _rows(cur)


SQL_LATEST_DELIVERY_RECEIPT = """SELECT detail FROM meta_case_events
    WHERE case_id = {ph} AND event = 'action_completed' AND action = {ph}
    ORDER BY id DESC LIMIT 1"""


def latest_delivery_receipt(cur, ph, case_id: str, action: str) -> dict | None:
    cur.execute(_fmt(SQL_LATEST_DELIVERY_RECEIPT, ph), (case_id, action))
    return _one(cur)


# --------------------------------------------------------------- the cases

SQL_GET_CASE = "SELECT * FROM meta_cases WHERE case_id = {ph}"


def get_case(cur, ph, case_id: str) -> dict | None:
    cur.execute(_fmt(SQL_GET_CASE, ph), (case_id,))
    return _one(cur)


SQL_CASE_EXISTS = "SELECT 1 AS present FROM meta_cases WHERE case_id = {ph}"


def case_exists(cur, ph, case_id: str) -> bool:
    cur.execute(_fmt(SQL_CASE_EXISTS, ph), (case_id,))
    return _one(cur) is not None


SQL_CASE_STATE = "SELECT state FROM meta_cases WHERE case_id = {ph}"


def case_state(cur, ph, case_id: str) -> dict | None:
    cur.execute(_fmt(SQL_CASE_STATE, ph), (case_id,))
    return _one(cur)


SQL_CASE_FOR_TRANSITION = """SELECT state, params_json, item_ref, template,
    clock_seq FROM meta_cases WHERE case_id = {ph}"""


def case_for_transition(cur, ph, case_id: str) -> dict | None:
    cur.execute(_fmt(SQL_CASE_FOR_TRANSITION, ph), (case_id,))
    return _one(cur)


SQL_CASE_WORKSPACE = "SELECT workspace_code FROM meta_cases WHERE case_id={ph}"


def case_workspace(cur, ph, case_id: str) -> dict | None:
    cur.execute(_fmt(SQL_CASE_WORKSPACE, ph), (case_id,))
    return _one(cur)


SQL_CASE_CLAIM_FIELDS = """SELECT clock_seq, play_id, workspace_code
    FROM meta_cases WHERE case_id={ph}"""


def case_claim_fields(cur, ph, case_id: str) -> dict | None:
    cur.execute(_fmt(SQL_CASE_CLAIM_FIELDS, ph), (case_id,))
    return _one(cur)


SQL_INSERT_CASE = """INSERT INTO meta_cases (case_id, play_id, template,
    group_ref, item_ref, state, sla_kind, sla_days, sla_started_at,
    params_json, workspace_code, parent_case_id, created_at, updated_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_case(cur, ph, case_id, play_id, template, group, item, state,
                sla_kind, sla_days, sla_started_at, params_json,
                parent_case_id, stamp) -> None:
    cur.execute(_fmt(SQL_INSERT_CASE, ph),
                (case_id, play_id, template, group, item, state, sla_kind,
                 sla_days, sla_started_at, params_json, _workspace(),
                 parent_case_id, stamp, stamp))


SQL_RESET_CLOCK_SEQ = "UPDATE meta_cases SET clock_seq=1 WHERE case_id={ph}"


def reset_clock_seq(cur, ph, case_id: str) -> None:
    cur.execute(_fmt(SQL_RESET_CLOCK_SEQ, ph), (case_id,))


SQL_APPLY_TRANSITION = """UPDATE meta_cases SET state={ph}, sla_kind={ph},
    sla_days={ph}, sla_started_at={ph}, clock_seq={ph}, updated_at={ph}
    WHERE case_id={ph}"""


def apply_transition(cur, ph, case_id, to_state, action, sla_days,
                     next_seq) -> None:
    cur.execute(_fmt(SQL_APPLY_TRANSITION, ph),
                (to_state, action, sla_days, _now(), next_seq, _now(),
                 case_id))


SQL_SET_GOAL_DEADLINE = ("UPDATE meta_cases SET goal_deadline={ph} "
                         "WHERE case_id={ph}")


def set_goal_deadline(cur, ph, case_id: str, deadline: str) -> None:
    cur.execute(_fmt(SQL_SET_GOAL_DEADLINE, ph), (deadline, case_id))


SQL_LIST_CASES = """SELECT case_id, play_id, template, group_ref, item_ref,
    state, sla_kind, sla_days, updated_at FROM meta_cases
    WHERE 1=1{scope} ORDER BY case_id"""


def list_cases(cur, ph) -> list[dict]:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_LIST_CASES, ph, clause), params)
    return _rows(cur)


SQL_ALL_CASES = "SELECT * FROM meta_cases WHERE 1=1{scope} ORDER BY case_id"


def all_cases(cur, ph) -> list[dict]:
    """Every case in scope, full rows - the dispatcher's and the audit's."""
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_ALL_CASES, ph, clause), params)
    return _rows(cur)


SQL_CASES_FOR_KPI = ("SELECT * FROM meta_cases WHERE 1=1{scope} "
                     "ORDER BY play_id, case_id")
SQL_CASES_FOR_KPI_BY_PLAY = ("SELECT * FROM meta_cases WHERE 1=1{scope} "
                             "AND play_id = {ph} ORDER BY play_id, case_id")


def cases_for_kpi(cur, ph, play_id: str = "") -> list[dict]:
    clause, params = _scope_sql(ph)
    if play_id:
        cur.execute(_fmt(SQL_CASES_FOR_KPI_BY_PLAY, ph, clause),
                    (*params, play_id))
    else:
        cur.execute(_fmt(SQL_CASES_FOR_KPI, ph, clause), params)
    return _rows(cur)


SQL_CHILD_CASES = """SELECT case_id, play_id, state FROM meta_cases
    WHERE parent_case_id = {ph} ORDER BY case_id"""


def child_cases(cur, ph, case_id: str) -> list[dict]:
    cur.execute(_fmt(SQL_CHILD_CASES, ph), (case_id,))
    return _rows(cur)


# ---------------------------------------------------------- the play store
#
# Read-only lookups into the play catalog the play store owns. `open` may
# run against a database where that tier has never connected, so the
# policy lookup is fenced: on Postgres an unknown table aborts the
# transaction and everything after it.

SQL_PLAY_POLICY = "SELECT policy_json FROM meta_playbooks WHERE play_id = {ph}"


def play_policy(cur, ph, play_id: str) -> dict:
    """The play's policy, or {} when the play (or the table) is absent."""
    cur.execute("SAVEPOINT play_policy")
    try:
        cur.execute(_fmt(SQL_PLAY_POLICY, ph), (play_id,))
        row = _one(cur)
        cur.execute("RELEASE SAVEPOINT play_policy")
    except Exception:       # noqa: BLE001 - no play store here
        cur.execute("ROLLBACK TO SAVEPOINT play_policy")
        cur.execute("RELEASE SAVEPOINT play_policy")
        return {}
    if not row:
        return {}
    try:
        return json.loads(row["policy_json"])
    except Exception:       # noqa: BLE001 - an unreadable policy is no policy
        return {}


SQL_PLAY_POLICY_AND_STATUS = """SELECT policy_json, status FROM meta_playbooks
    WHERE play_id = {ph}"""


def play_policy_and_status(cur, ph, play_id: str) -> dict | None:
    cur.execute(_fmt(SQL_PLAY_POLICY_AND_STATUS, ph), (play_id,))
    return _one(cur)


SQL_PLAY_ACTION_WORKFLOW = """SELECT workflow_generate FROM meta_playbooks
    WHERE play_id = {ph}"""


def play_action_workflow(cur, ph, play_id: str) -> str:
    """The play's action workflow; `case_action` when the play names none
    (or is not there)."""
    cur.execute(_fmt(SQL_PLAY_ACTION_WORKFLOW, ph), (play_id,))
    row = _one(cur)
    return (row["workflow_generate"] if row and row.get("workflow_generate")
            else "case_action")


# ---------------------------------------------------------------- the runs

SQL_INSERT_CASE_RUN = """INSERT INTO meta_case_runs (case_id, workspace_code,
    action, workflow, run_id, clock_seq, completion_event, failure_event,
    status, kind, created_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_case_run(cur, ph, case_id, workspace, action, workflow, run_id,
                    clock_seq, completion_event, failure_event, status,
                    kind) -> None:
    cur.execute(_fmt(SQL_INSERT_CASE_RUN, ph),
                (case_id, workspace, action, workflow, run_id, clock_seq,
                 completion_event, failure_event, status, kind, _now()))


SQL_LATEST_CASE_RUN = """SELECT action, workflow, run_id, status FROM
    meta_case_runs WHERE case_id = {ph} ORDER BY id DESC LIMIT 1"""


def latest_case_run(cur, ph, case_id: str) -> dict | None:
    cur.execute(_fmt(SQL_LATEST_CASE_RUN, ph), (case_id,))
    return _one(cur)


SQL_UNSETTLED_RUNS = """SELECT * FROM meta_case_runs
    WHERE (status = 'running'
           OR (status = 'settled' AND run_status = 'failed')){scope}
    ORDER BY id"""


def unsettled_runs(cur, ph) -> list[dict]:
    """Links still open, PLUS links settled on a FAILURE: the harness may
    retry that run back to done."""
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_UNSETTLED_RUNS, ph, clause), params)
    return _rows(cur)


SQL_LIST_CASE_RUNS = """SELECT case_id, action, workflow, run_id, status,
    outcome, run_status, kind, created_at, settled_at FROM meta_case_runs
    WHERE 1=1{scope} ORDER BY id DESC"""


def list_case_runs(cur, ph) -> list[dict]:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_LIST_CASE_RUNS, ph, clause), params)
    return _rows(cur)


SQL_MARK_RUN_STALE = """UPDATE meta_case_runs SET status='failed',
    outcome='stale', settled_at={ph} WHERE id={ph}"""


def mark_run_stale(cur, ph, link_id: int) -> None:
    cur.execute(_fmt(SQL_MARK_RUN_STALE, ph), (_now(), link_id))


SQL_SETTLE_DELIVERY_RUN = """UPDATE meta_case_runs SET status={ph}, outcome={ph},
    run_status={ph}, attempts = attempts + 1, settled_at={ph}
    WHERE id = {ph}"""


def settle_delivery_run(cur, ph, link_id: int, status: str, outcome: str,
                        run_status: str) -> None:
    cur.execute(_fmt(SQL_SETTLE_DELIVERY_RUN, ph),
                (status, outcome, run_status, _now(), link_id))


SQL_MARK_RUN_SETTLED = """UPDATE meta_case_runs SET status='settled',
    outcome={ph}, run_status={ph}, attempts = attempts + 1, settled_at={ph}
    WHERE id = {ph}"""


def mark_run_settled(cur, ph, link_id: int, outcome: str,
                     run_status: str) -> None:
    cur.execute(_fmt(SQL_MARK_RUN_SETTLED, ph),
                (outcome, run_status, _now(), link_id))


SQL_MARK_RUN_FAILED = """UPDATE meta_case_runs SET status='failed',
    outcome={ph}, run_status={ph}, attempts = attempts + 1, settled_at={ph}
    WHERE id = {ph}"""


def mark_run_failed(cur, ph, link_id: int, outcome: str,
                    run_status: str) -> None:
    cur.execute(_fmt(SQL_MARK_RUN_FAILED, ph),
                (outcome, run_status, _now(), link_id))


SQL_RECORD_RUN_ATTEMPT = """UPDATE meta_case_runs SET outcome={ph},
    attempts = attempts + 1 WHERE id = {ph}"""


def record_run_attempt(cur, ph, link_id: int, outcome: str) -> None:
    cur.execute(_fmt(SQL_RECORD_RUN_ATTEMPT, ph), (outcome, link_id))


SQL_LATEST_DELIVERY_CLAIM = """SELECT id, run_id, status, created_at
    FROM meta_case_runs
    WHERE case_id={ph} AND action={ph} AND clock_seq={ph}
    AND kind='delivery' ORDER BY id DESC LIMIT 1"""


def latest_delivery_claim(cur, ph, case_id: str, action: str,
                          clock_seq: int) -> dict | None:
    cur.execute(_fmt(SQL_LATEST_DELIVERY_CLAIM, ph),
                (case_id, action, int(clock_seq)))
    return _one(cur)


SQL_DELIVERY_CLAIMS = """SELECT run_id, status FROM meta_case_runs
    WHERE case_id={ph} AND action={ph} AND clock_seq={ph}
    AND kind='delivery' ORDER BY id DESC"""


def delivery_claims(cur, ph, case_id: str, action: str,
                    clock_seq: int) -> list[dict]:
    cur.execute(_fmt(SQL_DELIVERY_CLAIMS, ph),
                (case_id, action, int(clock_seq)))
    return _rows(cur)


# ------------------------------------------------- the engine's own tables
#
# A commissioned run is read from the engine's `runs`/`steps` in the same
# database. Both probes are fenced: a database from before
# `driver_heartbeat_at` still answers status and updated_at, and a
# tool-only database has no `runs` table at all - neither may poison the
# transaction for the next row.

SQL_ENGINE_RUN = """SELECT status, updated_at, driver_heartbeat_at FROM runs
    WHERE id = {ph}"""
SQL_ENGINE_RUN_LEGACY = "SELECT status, updated_at FROM runs WHERE id = {ph}"
SQL_ENGINE_LAST_STEP_OUTPUT = """SELECT output_text FROM steps
    WHERE run_id = {ph} AND status = {ph} ORDER BY seq DESC LIMIT 1"""


def engine_run_outcome(cur, ph, run_id: str):
    """``(row, text, error)``: the run's ``{status, updated_at,
    driver_heartbeat_at}`` and its last step's OUTPUT once finished; ``row``
    is None with ``error`` naming why when the run cannot be read."""
    cur.execute("SAVEPOINT run_probe")
    try:
        try:
            cur.execute("SAVEPOINT run_probe_cols")
            cur.execute(_fmt(SQL_ENGINE_RUN, ph), (run_id,))
            row = _one(cur)
            cur.execute("RELEASE SAVEPOINT run_probe_cols")
        except Exception:       # noqa: BLE001 - an older runs table
            cur.execute("ROLLBACK TO SAVEPOINT run_probe_cols")
            cur.execute(_fmt(SQL_ENGINE_RUN_LEGACY, ph), (run_id,))
            row = _one(cur)
            if row:
                row["driver_heartbeat_at"] = None
        if not row:
            cur.execute("RELEASE SAVEPOINT run_probe")
            return None, "", f"run {run_id!r} is not in this database"
        text = ""
        if row["status"] in ("done", "failed"):
            cur.execute(_fmt(SQL_ENGINE_LAST_STEP_OUTPUT, ph),
                        (run_id, row["status"]))
            r = _one(cur)
            text = (r["output_text"] or "") if r else ""
        cur.execute("RELEASE SAVEPOINT run_probe")
        return row, text, None
    except Exception as e:      # noqa: BLE001 - no runs table here
        cur.execute("ROLLBACK TO SAVEPOINT run_probe")
        return None, "", f"cannot read the engine's runs table ({e})"


# -------------------------------------------------------------- the timers

SQL_CANCEL_PENDING_RUNG_TIMERS = """UPDATE meta_case_timers SET
    status='cancelled', last_outcome={ph}, updated_at={ph}
    WHERE case_id={ph} AND status='pending' AND clock_seq <> {ph}"""
SQL_CANCEL_PENDING_TIMERS = """UPDATE meta_case_timers SET
    status='cancelled', last_outcome={ph}, updated_at={ph}
    WHERE case_id={ph} AND status='pending'"""


def cancel_pending_timers(cur, ph, case_id: str, reason: str,
                          keep_clock_seq: int | None = None) -> None:
    """Cancel the case's pending timers; with `keep_clock_seq` the row on
    that sequence (the goal clock's sentinel) is left running."""
    if keep_clock_seq is None:
        cur.execute(_fmt(SQL_CANCEL_PENDING_TIMERS, ph),
                    (reason, _now(), case_id))
    else:
        cur.execute(_fmt(SQL_CANCEL_PENDING_RUNG_TIMERS, ph),
                    (reason, _now(), case_id, int(keep_clock_seq)))


SQL_INSERT_TIMER = """INSERT INTO meta_case_timers (case_id, workspace_code,
    clock_seq, sla_kind, event, deadline, idem_key, status,
    attempts, created_at, updated_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},'pending',0,{ph},{ph})"""


def insert_timer(cur, ph, case_id, clock_seq, sla_kind, event, deadline,
                 idem_key) -> None:
    cur.execute(_fmt(SQL_INSERT_TIMER, ph),
                (case_id, _workspace(), clock_seq, sla_kind, event, deadline,
                 idem_key, _now(), _now()))


SQL_DUE_TIMERS = """SELECT t.* FROM meta_case_timers t
    WHERE t.status = 'pending' AND t.deadline <= {ph}{scope}
    AND NOT EXISTS (SELECT 1 FROM meta_case_events e
         WHERE e.case_id = t.case_id AND e.idem_key = t.idem_key)
    ORDER BY t.deadline LIMIT {ph}"""


def due_timers(cur, ph, now: str, limit: int) -> list[dict]:
    """Pending clocks past their deadline whose key is not yet in the
    ledger - selection-time deduplication."""
    clause, params = _scope_sql(ph, "t.workspace_code")
    cur.execute(_fmt(SQL_DUE_TIMERS, ph, clause), (now, *params, int(limit)))
    return _rows(cur)


SQL_LEASE_TIMER = """UPDATE meta_case_timers SET leased_by={ph},
    leased_until={ph}, updated_at={ph}
    WHERE id={ph} AND status='pending'
    AND (leased_until IS NULL OR leased_until < {ph})"""


def lease_timer(cur, ph, timer_id: int, holder: str, until: str) -> bool:
    """True when this holder took the lease (the row was free)."""
    cur.execute(_fmt(SQL_LEASE_TIMER, ph),
                (holder, until, _now(), timer_id, _now()))
    return bool(cur.rowcount)


SQL_COMPLETE_TIMER = """UPDATE meta_case_timers SET status={ph},
    last_outcome={ph}, attempts = attempts + 1, leased_by=NULL,
    leased_until=NULL, updated_at={ph} WHERE id={ph}"""


def complete_timer(cur, ph, timer_id: int, status: str, outcome: str) -> None:
    cur.execute(_fmt(SQL_COMPLETE_TIMER, ph),
                (status, outcome, _now(), timer_id))


SQL_HOLD_TIMER = """UPDATE meta_case_timers SET last_outcome={ph},
    leased_by=NULL, leased_until=NULL, updated_at={ph} WHERE id={ph}"""


def hold_timer(cur, ph, timer_id: int, outcome: str) -> None:
    cur.execute(_fmt(SQL_HOLD_TIMER, ph), (outcome, _now(), timer_id))


SQL_FAIL_TIMER = """UPDATE meta_case_timers SET status='failed',
    last_outcome={ph}, leased_by=NULL, leased_until=NULL, updated_at={ph}
    WHERE id={ph}"""


def fail_timer(cur, ph, timer_id: int, outcome: str) -> None:
    cur.execute(_fmt(SQL_FAIL_TIMER, ph), (outcome, _now(), timer_id))


# ----------------------------------------------------------- the rulebooks

SQL_RULEBOOK_REVISION = ("SELECT revision FROM meta_rulebooks "
                         "WHERE template_id = {ph}")


def rulebook_revision(cur, ph, template_id: str) -> dict | None:
    cur.execute(_fmt(SQL_RULEBOOK_REVISION, ph), (template_id,))
    return _one(cur)


SQL_UPDATE_RULEBOOK = """UPDATE meta_rulebooks SET title={ph}, spec_json={ph},
    revision={ph}, updated_at={ph}, updated_by={ph}
    WHERE template_id={ph}"""


def update_rulebook(cur, ph, template_id, title, spec_json, revision,
                    who) -> None:
    cur.execute(_fmt(SQL_UPDATE_RULEBOOK, ph),
                (title, spec_json, revision, _now(), who, template_id))


SQL_INSERT_RULEBOOK = """INSERT INTO meta_rulebooks (template_id, title,
    spec_json, revision, updated_at, updated_by, workspace_code)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_rulebook(cur, ph, template_id, title, spec_json, revision,
                    who) -> None:
    cur.execute(_fmt(SQL_INSERT_RULEBOOK, ph),
                (template_id, title, spec_json, revision, _now(), who,
                 _workspace()))


SQL_RULEBOOK_SPEC = """SELECT spec_json, revision FROM meta_rulebooks
    WHERE template_id = {ph}"""


def rulebook_spec(cur, ph, template_id: str) -> dict | None:
    cur.execute(_fmt(SQL_RULEBOOK_SPEC, ph), (template_id,))
    return _one(cur)


SQL_LIST_RULEBOOKS = """SELECT template_id, title, revision, updated_at,
    updated_by FROM meta_rulebooks WHERE 1=1{scope} ORDER BY template_id"""


def list_rulebooks(cur, ph) -> list[dict]:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_LIST_RULEBOOKS, ph, clause), params)
    return _rows(cur)


# ----------------------------------------------------------- the calendars

SQL_HOLIDAYS = """SELECT holidays_json FROM meta_calendars
    WHERE region = {ph} AND (workspace_code = {ph}
          OR workspace_code IS NULL OR workspace_code = '')
    ORDER BY workspace_code DESC"""


def holidays_json(cur, ph, workspace: str, region: str) -> dict | None:
    cur.execute(_fmt(SQL_HOLIDAYS, ph), (region, workspace or ""))
    return _one(cur)
