"""casetier.calendar — business-day arithmetic for case windows (pure).

Every pharma playbook onboarded so far states its windows in BUSINESS days.
Calendar arithmetic (`started + days * 86400`) puts a two-day window opened
Thursday afternoon due on Saturday. While nothing fires automatically that
only mis-colours a report; the moment a timer acts on it the platform
escalates over a weekend and reaches an administrator two days early, in
plays whose entire purpose is a defensible escalation record.

Holidays are DATA, not code: one deployment serves several regions and a
calendar compiled into the wheel cannot be corrected by the team that owns
the procedure. A rulebook declares `business_days` (default true) and an
optional `calendar` region; the holiday set for that region lives in
`meta_calendars`, keyed by workspace.
"""
from __future__ import annotations

from datetime import datetime, timedelta

_FMT = "%Y-%m-%dT%H:%M:%S"


def parse(ts: str) -> datetime | None:
    try:
        return datetime.strptime(ts, _FMT)
    except Exception:
        return None


def fmt(dt: datetime) -> str:
    return dt.strftime(_FMT)


def is_business_day(d: datetime, holidays) -> bool:
    """Monday-Friday and not a declared holiday."""
    if d.weekday() >= 5:            # 5 = Saturday, 6 = Sunday
        return False
    return d.strftime("%Y-%m-%d") not in (holidays or ())


def add_business_days(start: datetime, days: int, holidays=()) -> datetime:
    """`days` business days after `start`, preserving the time of day.

    The start day itself is never counted: a one-day window opened Friday
    at 14:00 is due Monday at 14:00, which is what "one business day to
    respond" means to the person who has to respond.
    """
    d, remaining = start, int(days)
    while remaining > 0:
        d = d + timedelta(days=1)
        if is_business_day(d, holidays):
            remaining -= 1
    return d


def add_calendar_days(start: datetime, days: int) -> datetime:
    return start + timedelta(days=int(days))


def compute_deadline(started_at: str, days, business: bool = True,
                     holidays=()) -> str | None:
    """The deadline string for a case's running clock, or None when the
    case carries no window."""
    start = parse(started_at or "")
    if start is None or days in (None, ""):
        return None
    try:
        n = int(days)
    except (TypeError, ValueError):
        return None
    end = (add_business_days(start, n, holidays) if business
           else add_calendar_days(start, n))
    return fmt(end)


def load_holidays(cur, ph: str, workspace: str, region: str) -> frozenset:
    """Holiday dates for a workspace and region. An absent calendar means
    weekends only — never an error: a deployment must run before anyone
    has loaded a holiday set, and weekends-only is the safe reading."""
    if not region:
        return frozenset()
    from ioagentfarm.tools.casetier import repo as _repo
    try:
        row = _repo.holidays_json(cur, ph, workspace, region)
    except Exception:
        return frozenset()
    if not row:
        return frozenset()
    import json
    try:
        return frozenset(json.loads(row["holidays_json"]) or ())
    except Exception:
        return frozenset()
