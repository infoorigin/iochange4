"""casetier.commands — the iof-case CLI surface."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import re
import sys
import textwrap
import time
from pathlib import Path

from ioagentfarm.tools.casetier.store import (
    _infer_root, _ledger, _now, _workspace, session)
from ioagentfarm.tools.casetier import repo as _repo
from ioagentfarm.tools.casetier import rulebook as _rulebook
from ioagentfarm.tools.casetier.rulebook import (
    capability_resolution_errors, cases_a_revision_strands,
    action_meta, decide, exhaust_walk, load_rulebook, save_rulebook,
    simulate_walk, validate_spec, validate_spec_warnings,
    warn_about_stranded_cases)
from ioagentfarm.tools.casetier.analysis import (_sla_posture,
                                                 analyze_history,
                                                 prior_window,
                                                 surviving_pending)
from ioagentfarm.tools.casetier import timers as _timers


_CASE_RE = re.compile("CASE-[A-Za-z0-9-]+-[A-Za-z0-9_]+")

#: Outcome-classification strings shared by cmd_transition (which prints
#: them) and apply_timer_event (which matches on them). ONE spelling:
#: rewording a transition message must not silently reclassify a settled
#: outcome as `error` — the only retryable one.
_MSG_DUPLICATE_SUPPRESSED = "duplicate delivery suppressed"
_MSG_NO_RULE = "no rule for state"


def cmd_open(args) -> int:
    """Open one case per item (e.g. one per territory). The open-time rule
    is an ordinary rulebook row on the spec's open_event; per-item variant
    events (e.g. case_opened_no_owner) route through the same engine."""
    items = [x.strip() for x in (args.items or "").split(",") if x.strip()]
    if not items:
        print("REFUSED: --items is empty", file=sys.stderr)
        return 1
    with session(args.out) as s:
        cur, ph = s.cur, s.ph
        # Template comes from the play's policy (the UC4 artifact names its
        # template family), or explicitly via --template. Never guessed.
        template = (args.template or "").strip()
        policy = _repo.play_policy(cur, ph, args.play)
        if not template:
            template = (policy.get("template") or "").strip()
        if not template:
            print(f"REFUSED: play {args.play!r} names no template and "
                  f"--template was not given — a case must belong to a "
                  f"rulebook family", file=sys.stderr)
            return 1
        spec = load_rulebook(cur, ph, template)
        if spec is None:
            print(f"REFUSED: no rulebook for template {template!r} — "
                  f"`iof-case rulebook list` shows what exists",
                  file=sys.stderr)
            return 1
        # Params: play policy overrides the template defaults key-by-key.
        params = dict(spec["default_params"])
        for k in spec["default_params"]:
            if k in policy:
                params[k] = policy[k]
        # Per-item open events: --open-event-for "item=event" (repeatable),
        # plus --no-owner as sugar for the OS-vacancy variant.
        open_event_for: dict[str, str] = {}
        for pair in (args.open_event_for or []):
            item, _, ev = pair.partition("=")
            open_event_for[item.strip()] = ev.strip()
        for item in [x.strip() for x in (args.no_owner or "").split(",")
                     if x.strip()]:
            open_event_for.setdefault(item, "case_opened_no_owner")
        default_open = spec.get("open_event", "case_opened")
        holidays = _timers.case_holidays(cur, ph, spec)
        opened = []
        for item in items:
            case_id = f"CASE-{args.group}-{item}".replace(" ", "_")
            if _repo.case_state(cur, ph, case_id):
                print(f"REFUSED: case {case_id} already exists",
                      file=sys.stderr)
                s.discard()
                return 1
            open_event = open_event_for.get(item, default_open)
            try:
                opened.append(_open_case(cur, ph, args.play, args.group,
                                         item, template, spec, params,
                                         open_event, holidays))
            except ValueError as e:
                print(f"REFUSED: {e}", file=sys.stderr)
                s.discard()
                return 1
    result = {"opened": opened, "group": args.group, "play": args.play,
              "template": template, "params": params}
    if args.out:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        (out / "cases_opened.json").write_text(json.dumps(result, indent=2),
                                               encoding="utf-8")
    print("STATUS: done")
    print("OUTPUT: opened " + "; ".join(
        f"{o['case_id']} -> {o['state']} ({o['rule_id']}: {o['action']}, "
        f"SLA {o['sla_days']}d)" for o in opened))
    return 0



def _open_case(cur, ph, play_id: str, group: str, item: str, template: str,
               spec: dict, params: dict, open_event: str, holidays=(),
               parent_case_id: str | None = None) -> dict:
    """Open ONE case: decide the open rule, insert the row (with its
    parent link when composed), ledger the decision, arm the rung and
    goal clocks. The ONE implementation behind `open` and
    `open-children` — two opens with separate code is how their
    semantics drift. The caller has checked the case does not already
    exist and owns the transaction. Raises ValueError when the rulebook
    has no rule for the open event."""
    case_id = f"CASE-{group}-{item}".replace(" ", "_")
    initial = spec["initial_state"]
    verdict = decide(spec, initial, open_event)
    if verdict is None:
        raise ValueError(f"rulebook {template} has no rule for "
                         f"({initial}, {open_event}) — cannot open "
                         f"{case_id}")
    rule_id, action, to_state, sla_param = verdict
    sla_days = params.get(sla_param) if sla_param else None
    stamp = _now()
    _repo.insert_case(cur, ph, case_id, play_id, template, group, item,
                      to_state, action,
                      str(sla_days) if sla_days is not None else None,
                      stamp, json.dumps(params), parent_case_id, stamp)
    _ledger(cur, ph, case_id, open_event, "", rule_id, action,
            initial, to_state, revision=spec.get("_revision"))
    _repo.reset_clock_seq(cur, ph, case_id)
    _rearm(cur, ph, case_id, spec)
    # The goal clock: once, at open, never reset by a rung transition.
    goal = _timers.schedule_goal(cur, ph, case_id, stamp, spec, params,
                                 holidays)
    return {"case_id": case_id, "item": item, "rule_id": rule_id,
            "action": action, "state": to_state, "sla_days": sla_days,
            "goal_deadline": goal["deadline"] if goal else None}


def _rearm(cur, ph, case_id: str, spec: dict) -> dict | None:
    """Cancel the case's pending RUNG timer and record the clock it is on
    now. Called inside the transition transaction, so a clock can never be
    replaced without its timer being replaced with it. The goal clock is
    untouched by rung moves — it measures total elapsed time toward the
    objective — and is cancelled only when the case reaches a terminal
    state, where the objective question is settled."""
    _timers.cancel_pending(cur, ph, case_id)
    case = _repo.get_case(cur, ph, case_id)
    if not case:
        return None
    if case.get("state") in set(spec.get("terminal_states", ("CLOSED",))):
        _timers.cancel_pending(cur, ph, case_id, reason="case_closed",
                               include_goal=True)
        return None
    holidays = _timers.case_holidays(cur, ph, spec)
    return _timers.schedule(cur, ph, case, spec, holidays)


def cmd_transition(args) -> int:
    with session(args.out) as s:
        cur, ph = s.cur, s.ph
        row = _repo.case_for_transition(cur, ph, args.case)
        if not row:
            print(f"REFUSED: no case {args.case!r}", file=sys.stderr)
            return 1
        state, item, template = row["state"], row["item_ref"], row["template"]
        clock_seq = int(row["clock_seq"] or 1)
        params = json.loads(row["params_json"])
        # THE FENCE. An emitter states which clock it acted on; a trigger
        # naming a superseded clock is refused. Without this, a scheduler
        # holding a job from before a reply arrived escalates a person who
        # answered moments ago — every component behaving correctly, about
        # a clock that no longer exists.
        # Clock 0 is the GOAL clock's sentinel (timers.GOAL_CLOCK_SEQ): it
        # is raised against the case, not a rung, so it is exempt from the
        # fence.
        if args.expect_clock not in (None, "", 0, "0"):
            if int(args.expect_clock) != clock_seq:
                print(f"FENCED: {args.case} is on clock {clock_seq}; the "
                      f"trigger names clock {args.expect_clock} — the "
                      f"window it refers to has been superseded",
                      file=sys.stderr)
                return 3
        spec = load_rulebook(cur, ph, template)
        if spec is None:
            print(f"REFUSED: case {args.case} belongs to template "
                  f"{template!r} which has no rulebook", file=sys.stderr)
            return 1
        if args.event not in spec["events"]:
            print(f"REFUSED: unknown event {args.event!r} — {template}'s "
                  f"typed events are: {', '.join(spec['events'])}",
                  file=sys.stderr)
            return 1
        # Idempotent intake: a retried delivery of the SAME occurrence
        # (same key — e.g. clock id + deadline from the monitoring system)
        # must not fire a second rule. Without this, a duplicated
        # sla_breach webhook legitimately matches the NEXT rung and
        # escalates a case early.
        if args.key and _repo.event_with_key_exists(cur, ph, args.case,
                                                    args.key):
            _ledger(cur, ph, args.case, args.event, args.detail, None,
                    "DUPLICATE_SUPPRESSED", state, state,
                    idem_key=args.key, revision=spec.get("_revision"))
            print(f"{_MSG_DUPLICATE_SUPPRESSED}: {args.case} already "
                  f"processed key {args.key!r} — state unchanged ({state})")
            return 0
        verdict = decide(spec, state, args.event)
        if verdict is None:
            # The key rides the refusal. A refusal CONSUMES the occurrence:
            # without the key here, a case parked at an unmatched breach is
            # re-selected and re-attempted on every sweep, forever.
            _ledger(cur, ph, args.case, args.event, args.detail, None,
                    "UNMATCHED", state, state, idem_key=args.key or None,
                    revision=spec.get("_revision"))
            # A state the CURRENT revision has never heard of is not a
            # wrong event, and reading it as one costs an afternoon: the
            # rulebook was replaced under an open case. Say which it is.
            moved = ("" if state in set(spec.get("states") or ()) else
                     f" — and {template} rev {spec.get('_revision')} does "
                     f"not define state {state!r} at all: this case was "
                     f"opened under a revision that did, so NO event can "
                     f"move it until one naming that state is installed")
            print(f"REFUSED: {_MSG_NO_RULE}={state} event={args.event} on "
                  f"{args.case}{moved} — the rulebook never guesses; "
                  "surfaced to the event ledger for a human to review",
                  file=sys.stderr)
            return 1
        rule_id, action, to_state, sla_param = verdict
        sla_days = params.get(sla_param) if sla_param else None
        # A RULE THAT CHANGES NEITHER THE STATE NOR THE WINDOW IS A NOTICE.
        # It reports something - an objective clock expiring, a receipt
        # arriving - and leaves the matter exactly where it was. Re-arming
        # for it CANCELS the rung clock the case is actually running and
        # schedules nothing in its place, which silently disarms the whole
        # escalation ladder: found by firing a goal_overdue rule at a case
        # with four days left on its execution window, and watching that
        # window disappear. The decision still goes on the ledger, which is
        # where the dispatcher reads what is owed.
        notice_only = (to_state == state and sla_param is None)
        if not notice_only:
            next_seq = clock_seq + 1
            _repo.apply_transition(
                cur, ph, args.case, to_state, action,
                str(sla_days) if sla_days is not None else None, next_seq)
        _ledger(cur, ph, args.case, args.event, args.detail, rule_id,
                action, state, to_state, idem_key=args.key or None,
                revision=spec.get("_revision"))
        if not notice_only:
            # The clock the case was on is gone: cancel its timer and record
            # the new one, both inside this transaction. Cancellation is
            # prevention; the fence above is detection for whatever was
            # already in flight.
            _rearm(cur, ph, args.case, spec)
    result = {"case_id": args.case, "item": item, "event": args.event,
              "rule_id": rule_id, "action": action, "from_state": state,
              "to_state": to_state, "sla_days": sla_days,
              "rulebook_revision": spec.get("_revision"),
              "roles": {k: params[k]
                        for k in spec.get("role_params", [])
                        if k in params}}
    if args.out:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        (out / "transition.json").write_text(json.dumps(result, indent=2),
                                             encoding="utf-8")
    print("STATUS: done")
    print(f"OUTPUT: {args.case}: {state} + {args.event} -> {rule_id} "
          f"{action} -> {to_state}"
          + (f" (SLA {sla_days}d)" if sla_days is not None else
             " (a notice: state and window unchanged)" if notice_only else ""))
    return 0


def cmd_open_children(args) -> int:
    """Deliver an open_play action: open the child cases the parent's
    rulebook ordered, each carrying parent_case_id, and record the
    delivery on the parent's ledger with the child ids as the receipt —
    ONE transaction, so a crash mid-delivery retries the whole thing and
    double-opens nothing. Fail-closed at every seam: the parent's pending
    action must BE an undelivered open_play (the ctx guard's sibling),
    the child play must exist and be operational, and a composition that
    cycles or nests past depth 5 is refused."""
    items = [x.strip() for x in (args.items or "").split(",") if x.strip()]
    if not items:
        print("REFUSED: --items is empty", file=sys.stderr)
        return 1
    with session(args.out, args.root_hint) as s:
        cur, ph = s.cur, s.ph
        parent = _repo.get_case(cur, ph, args.case)
        if not parent:
            print(f"REFUSED: no case {args.case!r}", file=sys.stderr)
            return 1
        pspec = load_rulebook(cur, ph, parent["template"])
        if pspec is None:
            print(f"REFUSED: parent template {parent['template']!r} has no "
                  f"rulebook", file=sys.stderr)
            return 1
        pending = surviving_pending(
            pspec, parent["state"],
            analyze_history(_repo.case_history_desc(cur, ph, args.case))
            ["pending"])
        meta = action_meta(pspec, pending)
        child_group = (args.group or "").strip() or parent["group_ref"]
        if not pending or not meta or meta.get("delivery") != "open_play":
            # A settled retry is not an error: the delivery was recorded
            # and every requested child exists.
            existing = 0
            for item in items:
                cid = f"CASE-{child_group}-{item}".replace(" ", "_")
                existing += 1 if _repo.case_exists(cur, ph, cid) else 0
            if pending is None and existing == len(items):
                print(f"already delivered: every requested child of "
                      f"{args.case} exists and no open_play action is "
                      f"pending")
                return 0
            print(f"REFUSED: {args.case}'s pending action is "
                  f"{pending!r} — open-children only delivers an "
                  f"undelivered open_play action; `iof-case explain "
                  f"{args.case}` says what is actually owed",
                  file=sys.stderr)
            return 1
        child_play_id = meta.get("play")
        prow = _repo.play_policy_and_status(cur, ph, child_play_id)
        if not prow:
            print(f"REFUSED: child play {child_play_id!r} does not exist — "
                  f"put it (rulebook first) before this action can deliver",
                  file=sys.stderr)
            return 1
        policy, status = json.loads(prow["policy_json"]), prow["status"]
        if status != "operational":
            print(f"REFUSED: child play {child_play_id!r} is '{status}' — "
                  f"only an operational play may be opened", file=sys.stderr)
            return 1
        template = (policy.get("template") or "").strip()
        cspec = load_rulebook(cur, ph, template) if template else None
        if cspec is None:
            print(f"REFUSED: child play {child_play_id!r} names no rulebook "
                  f"template (or it is missing) — composition opens CASE "
                  f"plays", file=sys.stderr)
            return 1
        # The cycle/depth guard: walk the parent chain. A composed play
        # whose descendants open it again recurses forever; a chain past
        # depth 5 is a design smell refused loudly rather than discovered
        # in production.
        seen_plays, depth, node = {parent["play_id"]}, 1, parent
        while node.get("parent_case_id") and depth <= 10:
            up = _repo.get_case(cur, ph, node["parent_case_id"])
            if not up:
                break
            node = up
            seen_plays.add(node["play_id"])
            depth += 1
        if child_play_id in seen_plays:
            print(f"REFUSED: opening {child_play_id!r} from {args.case} "
                  f"would CYCLE — that play is already an ancestor of this "
                  f"case", file=sys.stderr)
            return 1
        if depth >= 5:
            print(f"REFUSED: this case is already {depth} levels deep — "
                  f"composition past depth 5 is refused", file=sys.stderr)
            return 1
        cparams = dict(cspec["default_params"])
        for k in cspec["default_params"]:
            if k in policy:
                cparams[k] = policy[k]
        holidays = _timers.case_holidays(cur, ph, cspec)
        open_event = cspec.get("open_event", "case_opened")
        opened, skipped = [], []
        for item in items:
            cid = f"CASE-{child_group}-{item}".replace(" ", "_")
            if _repo.case_exists(cur, ph, cid):
                skipped.append(cid)
                continue
            try:
                opened.append(_open_case(cur, ph, child_play_id,
                                         child_group, item, template, cspec,
                                         cparams, open_event, holidays,
                                         parent_case_id=parent["case_id"]))
            except ValueError as e:
                print(f"REFUSED: {e}", file=sys.stderr)
                s.discard()
                return 1
        receipt = "children:" + ";".join(o["case_id"] for o in opened)
        if skipped:
            receipt += " already-open:" + ";".join(skipped)
        _ledger(cur, ph, parent["case_id"], "action_completed", receipt,
                None, pending, None, None)
    result = {"parent": parent["case_id"], "action": pending,
              "child_play": child_play_id, "opened": opened,
              "already_open": skipped, "receipt": receipt}
    if args.out:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        (out / "children_opened.json").write_text(
            json.dumps(result, indent=2), encoding="utf-8")
    print("STATUS: done")
    print(f"OUTPUT: {parent['case_id']}: {pending} delivered — opened "
          f"{len(opened)} child case(s) of {child_play_id}"
          + (f", {len(skipped)} already open" if skipped else ""))
    return 0


def render_workflow_goal(case: dict, meta: dict) -> str:
    """The goal a commissioned run receives: the contract's `goal_hint`
    with the case's placeholders substituted, prefixed with the case id so
    the run is attributable from its own record. Deterministic - no model
    composes it."""
    hint = str(meta.get("goal_hint") or "").strip() or \
        f"{meta.get('workflow')} for <item> in <group>"
    filled = (hint.replace("<item>", str(case.get("item_ref") or ""))
                  .replace("<group>", str(case.get("group_ref") or ""))
                  .replace("<case_id>", str(case.get("case_id") or "")))
    return f"case:{case.get('case_id')} — {filled}"


def _spawn_run(workflow: str, goal: str, workspace: str | None,
               root_hint: str = "") -> str:
    """Start a run NON-BLOCKING and return its id - `aicore run --json`
    creates the run, spawns execution in the background and answers with
    the id, which is the only thing the case needs to hold. A seam: tests
    replace it."""
    exe = shutil.which("aicore") or shutil.which("ioagentfarm")
    if exe:
        cmd = [exe, "run", workflow, "--goal", goal, "--json"]
    else:
        cmd = [sys.executable, "-c", "from ioagentfarm.cli import app; app()",
               "run", workflow, "--goal", goal, "--json"]
    if workspace:
        cmd += ["--workspace", workspace]
    env = dict(os.environ)
    if not env.get("IOF_ROOT") and not env.get("IOF_DATABASE_URL"):
        root = _infer_root(root_hint)
        if root is not None:
            env["IOF_ROOT"] = str(root)
    proc = subprocess.run(cmd, capture_output=True, text=True, env=env,
                          timeout=180)
    if proc.returncode != 0:
        raise RuntimeError(f"`aicore run {workflow}` exited "
                           f"{proc.returncode}: "
                           f"{(proc.stderr or proc.stdout).strip()[-600:]}")
    m = re.search(r'"run_id"\s*:\s*"([^"]+)"', proc.stdout)
    if not m:
        raise RuntimeError(f"`aicore run {workflow} --json` answered "
                           f"without a run_id: {proc.stdout.strip()[-300:]}")
    return m.group(1)


def cmd_commission(args) -> int:
    """Deliver a `workflow` action: commission the run the rulebook named,
    link it to the case, and record the delivery on the ledger with the
    run id as the receipt - ONE transaction around the record, so a crash
    after the spawn is the one gap (an orphan run, never a double
    delivery). Fail-closed at every seam: the pending action must BE an
    undelivered workflow delivery, the workflow must resolve here, and a
    second commission of the same decision is answered, not repeated.
    `--run-id` attaches a run that already exists (the Meta Agent started
    the analysis before opening the case) instead of spawning one."""
    with session(args.out, args.root_hint) as s:
        cur, ph = s.cur, s.ph
        case = _repo.get_case(cur, ph, args.case)
        if not case:
            print(f"REFUSED: no case {args.case!r}", file=sys.stderr)
            return 1
        spec = load_rulebook(cur, ph, case["template"])
        if spec is None:
            print(f"REFUSED: template {case['template']!r} has no rulebook",
                  file=sys.stderr)
            return 1
        pending = surviving_pending(
            spec, case["state"],
            analyze_history(_repo.case_history_desc(cur, ph, args.case))
            ["pending"])
        meta = action_meta(spec, pending)
        if not pending or not meta or meta.get("delivery") != "workflow":
            prior = _repo.latest_case_run(cur, ph, args.case)
            if pending is None and prior:
                print(f"already delivered: {args.case}'s {prior['action']} "
                      f"was commissioned as run {prior['run_id']} "
                      f"({prior['workflow']}, {prior['status']}) and "
                      f"nothing is pending")
                return 0
            print(f"REFUSED: {args.case}'s pending action is {pending!r} — "
                  f"commission only delivers an undelivered workflow "
                  f"action; `iof-case explain {args.case}` says what is "
                  f"actually owed", file=sys.stderr)
            return 1
        workflow = str(meta.get("workflow") or "").strip()
        workspace = case.get("workspace_code") or _workspace() or None
        try:
            # Through the MODULE attribute, not a name bound at import: the
            # seam tests pin (and a deployment could swap) lives on
            # rulebook.
            known = _rulebook._resolvable_workflows(workspace)
        except Exception as e:      # noqa: BLE001
            known = None
            enumerate_err = f"{type(e).__name__}: {e}"
        if known is not None and workflow not in known:
            print(f"REFUSED: action {pending!r} names workflow "
                  f"{workflow!r}, which does not resolve here; workflows "
                  f"that do: "
                  f"{', '.join(sorted(known)) or '(none installed)'}",
                  file=sys.stderr)
            return 1
        if known is None:
            print(f"REFUSED: cannot enumerate the installed workflows "
                  f"({enumerate_err})", file=sys.stderr)
            return 1
        case["params"] = json.loads(case.pop("params_json"))
        goal = render_workflow_goal(case, meta)
    run_id = (args.run_id or "").strip()
    if not run_id:
        try:
            run_id = _spawn_run(workflow, goal, workspace, args.root_hint)
        except Exception as e:      # noqa: BLE001 - the run did not start
            print(f"REFUSED: could not commission {workflow!r}: {e}",
                  file=sys.stderr)
            return 1
    receipt = f"run:{run_id}"
    with session(args.out, args.root_hint) as s:
        _repo.insert_case_run(s.cur, s.ph, args.case, workspace, pending,
                              workflow, run_id,
                              int(case.get("clock_seq") or 1),
                              meta["completion_event"], meta["failure_event"],
                              "running", "workflow")
        _ledger(s.cur, s.ph, args.case, "action_completed", receipt, None,
                pending, None, None)
    result = {"case_id": args.case, "action": pending, "workflow": workflow,
              "run_id": run_id, "goal": goal, "receipt": receipt,
              "completion_event": meta["completion_event"],
              "failure_event": meta["failure_event"],
              "attached": bool(args.run_id)}
    if args.out:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        (out / "commission_receipt.json").write_text(
            json.dumps(result, indent=2), encoding="utf-8")
    print("STATUS: done")
    print(f"OUTPUT: {args.case}: {pending} delivered — "
          f"{'attached' if args.run_id else 'commissioned'} {workflow} as "
          f"run {run_id}; {meta['completion_event']!r} will be applied "
          f"when it finishes")
    return 0


def _run_outcome(cur, ph, run_id: str):
    """(status, text, quiet_for_s) for a commissioned run, read from the
    ENGINE's own tables in the same database: ``done``/``failed`` with the
    last step's OUTPUT, another status while it runs, or (None, why, None)
    when the run is not there to be read. ``quiet_for_s`` is how long the
    run and its driver have been silent (the newer of ``updated_at`` and
    ``driver_heartbeat_at``); unparseable stamps read as very old. A
    SAVEPOINT guards the probe (in the repository): on PostgreSQL a failed
    statement aborts the transaction and everything after it."""
    row, text, err = _repo.engine_run_outcome(cur, ph, run_id)
    if row is None:
        return None, err, None
    return (row["status"], text,
            _quiet_for_s(row["updated_at"], row.get("driver_heartbeat_at")))


def _quiet_for_s(*stamps) -> float:
    """Seconds since the newest of the given ISO stamps; a stamp that does
    not parse is ignored, and no parseable stamp at all reads as very old
    (so a failure with no evidence of life is settled, not held forever)."""
    from datetime import datetime, timezone
    newest = None
    for s in stamps:
        if not s:
            continue
        try:
            t = datetime.fromisoformat(str(s))
        except ValueError:
            continue
        if t.tzinfo is None:
            t = t.astimezone()          # engine stamps are aware; ours local
        newest = t if newest is None or t > newest else newest
    if newest is None:
        return float("inf")
    return (datetime.now(timezone.utc) - newest).total_seconds()


def failure_grace_s() -> float:
    """How long a `failed` run must be quiet before it is applied as the
    contract's failure event. Found live: the engine marked a run failed at
    16:27:37, the settler applied system_error at 16:27:52, the driver
    retried at 16:28:00 and attempt 4 finished the analysis at 16:28:50 -
    fifty-eight seconds after the case had been told it could not be
    produced. `run.failed` is a state the harness retries out of (Fix-6,
    step-retry, supervisor resume) up to its hard cap, not a verdict."""
    try:
        return max(0.0, float(os.environ.get("IOF_CASE_RUN_FAILURE_GRACE_S",
                                             "900")))
    except ValueError:
        return 900.0


def settle_runs(now: str | None = None, verbose: bool = False) -> list[dict]:
    """Apply the outcome of every commissioned run that has finished, as
    the typed event its contract declared, through `apply_timer_event` -
    the single path every emitter uses, so a run's completion gets the
    same idempotency and refusal semantics as a clock. Called on every
    scheduler pass and by `iof-case runs --settle`; holds nothing of its
    own, so a lost sweeper loses nothing."""
    findings = []
    with session() as s:
        # Links still open, PLUS links settled on a FAILURE: the harness
        # may retry that run back to done, and its completion still belongs
        # to the case (the rulebook decides what a late finding means
        # there).
        for r in _repo.unsettled_runs(s.cur, s.ph):
            status, text, quiet = _run_outcome(s.cur, s.ph, r["run_id"])
            findings.append((r, status, text, quiet))
    applied = []
    grace = failure_grace_s()
    for r, status, text, quiet in findings:
        if (status is None and r.get("kind") == "delivery"
                and r.get("status") == "running"
                and _age_s(r.get("created_at")) > grace):
            # A claim whose run the engine cannot see, older than the
            # grace window: stale. Frees the decision for the dispatcher.
            with session() as s:
                _repo.mark_run_stale(s.cur, s.ph, r["id"])
            applied.append({"case_id": r["case_id"], "run_id": r["run_id"],
                            "run_status": None, "event": None,
                            "outcome": "stale claim"})
            continue
        if status not in ("done", "failed"):
            continue
        if r.get("kind") == "delivery":
            # A delivery run records its own delivery (record-action);
            # the link only closes. A failure that has gone quiet frees
            # the claim so the dispatcher may try again, bounded.
            if status == "failed" and quiet is not None and quiet < grace:
                continue
            with session() as s:
                _repo.settle_delivery_run(
                    s.cur, s.ph, r["id"],
                    "settled" if status == "done" else "failed",
                    f"run_{status}", status)
            applied.append({"case_id": r["case_id"], "run_id": r["run_id"],
                            "run_status": status, "event": None,
                            "outcome": f"delivery run {status}"})
            continue
        if status == "failed":
            if r.get("status") == "settled":
                continue                    # applied already; watching for done
            if quiet is not None and quiet < grace:
                continue                    # the harness may still retry it
        if status == "done" and r.get("run_status") == "done":
            continue
        event = r["completion_event"] if status == "done" else r["failure_event"]
        summary = " ".join(str(text or "").split())[:600]
        detail = (f"run:{r['run_id']} {status}"
                  + (" (after an earlier failure was applied)"
                     if status == "done" and r.get("status") == "settled"
                     else "")
                  + (f" — {summary}" if summary else ""))
        res = apply_timer_event(r["case_id"], event, None,
                                f"run:{r['run_id']}:{status}", detail,
                                undelivered_block=False)
        with session() as s:
            if res["outcome"] in _timers.TERMINAL_OUTCOMES:
                _repo.mark_run_settled(s.cur, s.ph, r["id"], res["outcome"],
                                       status)
            elif int(r.get("attempts") or 0) + 1 >= _timers.max_attempts():
                _repo.mark_run_failed(s.cur, s.ph, r["id"], res["outcome"],
                                      status)
            else:
                _repo.record_run_attempt(s.cur, s.ph, r["id"],
                                         res["outcome"])
        applied.append({"case_id": r["case_id"], "run_id": r["run_id"],
                        "run_status": status, "event": event,
                        "outcome": res["outcome"]})
        if verbose:
            print(f"{r['case_id']:<38} run {r['run_id']} {status:<7} "
                  f"-> {event} -> {res['outcome']}")
    return applied


def cmd_deliveries(args) -> int:
    """What this deployment declares for deliveries, and where it came from
    - the answer to "which tool sends the email here?"."""
    from ioagentfarm.engine.deliveries import (TOKEN, delivery_tools,
                                               describe_deliveries)
    try:
        declared, source = describe_deliveries(
            (args.workspace or "").strip() or None)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    tools = delivery_tools(declared)
    payload = {"source": source, "deliveries": declared, "tools": tools,
               # STRUCTURAL kinds - built into the case tier, no declared
               # tool behind them, available in every deployment. Listed so
               # the COMPILER is told they exist: a playbook whose matter
               # branches to another team's own process needs `open_play`,
               # and until this entry existed the match step could not map
               # that sentence onto anything - composition was invisible to
               # the one reader deciding what the workspace can do.
               "structural": {
                   "open_play": {
                       "means": "a rule opens CHILD cases of another play, "
                                "one per item, each carrying the parent's "
                                "id; the child play's params (its roles) "
                                "override the shared template's - how one "
                                "review process serves many owner "
                                "hierarchies"},
                   "workflow": {
                       "means": "a rule commissions one of the workflows in "
                                "workflow_catalog.json and the case waits "
                                "on its completion event"}}}
    if getattr(args, "out", ""):
        # THE COMPILER MAPS AGAINST THIS. `playbook_compile` writes it beside
        # the workflow catalog so a draft names a delivery kind, a recipient
        # role and a verification record this deployment actually declares -
        # produced by the same resolver `rulebook put` refuses against, so
        # the catalog and the refusal cannot disagree.
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    if args.json or getattr(args, "out", ""):
        print(json.dumps(payload, indent=2))
        return 0
    print(f"source: {source}")
    if not declared:
        print("no deliveries declared - a rulebook delivering by email or "
              "monitoring_task is refused here until one is")
        return 0
    for kind, entry in declared.items():
        names = entry.get("tools") if kind == "verification" \
            else [entry.get("tool")]
        print(f"  {kind:<18} {', '.join(str(n) for n in (names or []))}")
    print(f"{TOKEN} expands to: {', '.join(tools) or '(nothing)'}")
    return 0


def cmd_runs(args) -> int:
    """Runs cases have commissioned, and (--settle) one settling pass."""
    applied = settle_runs(verbose=not args.json) if args.settle else []
    with session() as s:
        rows = _repo.list_case_runs(s.cur, s.ph)
    if args.json:
        print(json.dumps({"runs": rows, "settled": applied}, indent=2))
        return 0
    if not rows:
        print("no commissioned runs")
        return 0
    print(f"{'case':<38} {'action':<24} {'workflow':<24} {'run':<14} "
          f"{'kind':<9} {'status':<8} {'run':<7} outcome")
    for r in rows:
        print(f"{r['case_id']:<38} {r['action']:<24} {r['workflow']:<24} "
              f"{r['run_id']:<14} {r.get('kind') or 'workflow':<9} "
              f"{r['status']:<8} {r.get('run_status') or '-':<7} "
              f"{r['outcome'] or '-'}")
    return 0


def _run_id_from_hint(hint: str) -> str | None:
    """``<IOF_ROOT>/instances/<run_id>/...`` -> the run id, or None."""
    if not hint:
        return None
    parts = Path(hint).resolve().parts
    for i, part in enumerate(parts):
        if part == "instances" and i + 1 < len(parts):
            return parts[i + 1]
    return None


def _play_action_workflow(cur, ph, play_id: str) -> str:
    return _repo.play_action_workflow(cur, ph, play_id)


def claim_delivery(case_id: str, action: str, clock_seq: int,
                   run_id: str | None, play_id: str | None,
                   workspace: str | None) -> dict:
    """Register ``run_id`` as the run delivering this decision, or refuse
    when another live run already holds it. A claim whose run has ended
    (done, or failed and quiet) is stale and may be taken over. Without a
    run id (a person running ctx by hand) nothing is claimed."""
    if not run_id:
        return {"claimed": False}
    with session() as s:
        cur, ph = s.cur, s.ph
        row = _repo.latest_delivery_claim(cur, ph, case_id, action,
                                          clock_seq)
        if row and row["run_id"] == run_id:
            return {"claimed": True, "run_id": run_id}
        if row and row["status"] == "running":
            status, _text, quiet = _run_outcome(cur, ph, row["run_id"])
            grace = failure_grace_s()
            if status is None:
                # The engine cannot see that run (a hand-made id, another
                # database): the claim holds until IT is older than the
                # grace window, then it is stale.
                alive = _age_s(row["created_at"]) < grace
            elif status == "done":
                alive = False
            elif status == "failed":
                alive = quiet is not None and quiet < grace
            else:
                alive = True
            if alive:
                return {"refused": f"another run ({row['run_id']}) is "
                                   f"delivering {action!r} for {case_id} — "
                                   f"a second delivery of one decision is "
                                   f"a second notice; let that run finish "
                                   f"(`iof-case runs`)"}
            _repo.mark_run_stale(cur, ph, row["id"])
        workflow = _play_action_workflow(cur, ph, play_id or "")
        _repo.insert_case_run(cur, ph, case_id, workspace or None, action,
                              workflow, run_id, int(clock_seq), "", "",
                              "running", "delivery")
        return {"claimed": True, "run_id": run_id}


def dispatch_after_s() -> float:
    """How old a decision must be before the scheduler dispatches its
    delivery - room for a Meta Agent that commissions the action the
    moment it opens the case to claim it first. The claim is the guard;
    this is only courtesy."""
    try:
        return max(0.0, float(os.environ.get("IOF_CASE_DISPATCH_AFTER_S",
                                             "30")))
    except ValueError:
        return 30.0


def dispatch_max_age_s() -> float:
    """How old a decision may be and still be delivered automatically.
    Found live: the first sweep of a workspace with weeks-old demo cases
    started a notice for every one of them. A decision nobody delivered
    for days is not a notice to send at three in the morning without a
    person looking; the dry run lists it as owed and says why it waits."""
    try:
        return max(0.0, float(os.environ.get("IOF_CASE_DISPATCH_MAX_AGE_S",
                                             str(3 * 24 * 3600))))
    except ValueError:
        return 3 * 24 * 3600.0


def dispatch_max_attempts() -> int:
    try:
        return max(1, int(os.environ.get("IOF_CASE_DISPATCH_MAX_ATTEMPTS",
                                         "3")))
    except ValueError:
        return 3


def _age_s(stamp: str | None) -> float:
    """Seconds since one of OUR local-naive stamps (`_now()`)."""
    from datetime import datetime
    if not stamp:
        return float("inf")
    try:
        return (datetime.now() - datetime.fromisoformat(str(stamp))).total_seconds()
    except ValueError:
        return float("inf")


def dispatch_pending(dry_run: bool = False, verbose: bool = False) -> list[dict]:
    """Commission the action workflow for every decision that is pending,
    undelivered and side-effecting - the notice a clock-fired escalation is
    owed at three in the morning, which nothing sent before this existed:
    the scheduler recorded the decision, the undelivered-notice block held
    the next clock, and the notice waited for a person to ask. One dispatch
    per decision (the claim), bounded retries, and nothing sent when the
    play's action workflow cannot be started. Called on every scheduler
    pass and by `iof-case dispatch`."""
    plan = []
    with session() as s:
        cur, ph = s.cur, s.ph
        for case in _repo.all_cases(cur, ph):
            spec = load_rulebook(cur, ph, case.get("template", ""))
            if spec is None:
                continue
            # A terminal case is NOT skipped here. The CLOSING transition
            # may itself have ordered a delivery ("record and close" is a
            # normal business shape — the write-back that puts the
            # decision into the system of record rides the same rule that
            # closes the case), and a private terminal skip orphaned
            # exactly that action: decided, owed, dispatched by nobody,
            # while `scheduler --once` said "nothing due". The question
            # "does this pending action survive the close?" already has
            # ONE shared answer — `surviving_pending`, written when ctx
            # and audit disagreed about the same shape — and this pass
            # was a third reader answering it privately. It asks the
            # shared function now, like the other two.
            history = _repo.case_history_desc(cur, ph, case["case_id"])
            analysis = analyze_history(history)
            pending = surviving_pending(spec, case.get("state"),
                                        analysis["pending"])
            meta = action_meta(spec, pending)
            if not pending or not meta or meta.get("side_effects") is False:
                continue
            decision = next((d for d in analysis["decisions"]
                             if d.get("action") == pending), None)
            clock_seq = int(case.get("clock_seq") or 1)
            claims = _repo.delivery_claims(cur, ph, case["case_id"], pending,
                                           clock_seq)
            if claims and claims[0]["status"] == "running":
                continue                                   # in flight
            if len(claims) >= dispatch_max_attempts():
                plan.append({"case_id": case["case_id"], "action": pending,
                             "dispatched": False,
                             "why": f"gave up after {len(claims)} delivery "
                                    f"run(s); `iof-case explain` says what "
                                    f"is owed"})
                continue
            age = _age_s(decision.get("created_at") if decision else None)
            if age > dispatch_max_age_s():
                if dry_run:
                    plan.append({"case_id": case["case_id"],
                                 "action": pending, "dispatched": False,
                                 "why": f"owed, but decided "
                                        f"{age / 86400:.1f} days ago - "
                                        f"older than "
                                        f"IOF_CASE_DISPATCH_MAX_AGE_S; a "
                                        f"person decides (`iof-case "
                                        f"explain`)"})
                continue
            if age < dispatch_after_s():
                # Give whoever opened the case room to commission the first
                # notice themselves; the claim is the real guard. A dry run
                # still SAYS it is owed - that is the operator's question.
                if dry_run:
                    plan.append({"case_id": case["case_id"],
                                 "action": pending, "dispatched": False,
                                 "why": f"owed; decided {age:.0f}s ago - "
                                        f"the scheduler waits "
                                        f"{dispatch_after_s():.0f}s for a "
                                        f"commissioner before dispatching"})
                continue
            workflow = _play_action_workflow(cur, ph,
                                             case.get("play_id") or "")
            goal = (f"case:{case['case_id']} action:{pending} — dispatched "
                    f"by the scheduler: "
                    f"{decision.get('rule_id') if decision else '?'} "
                    f"decided at "
                    f"{decision.get('created_at') if decision else '?'}")
            if meta.get("delivery") == "open_play":
                # An open_play delivery opens ONE child per item, and the
                # items live in the detail of the event that fired the rule
                # ("routed ... items:market_access"). `ctx` parses
                # `items:` from the commissioning goal, so forward them -
                # without this the scheduler-dispatched run reaches the act
                # step with goal_items empty and opens nothing, while a
                # Meta-Agent-commissioned run of the SAME decision works.
                im = re.search(r"items:([^\s]+)",
                               str((decision or {}).get("detail") or ""))
                if not im:
                    plan.append({"case_id": case["case_id"],
                                 "action": pending, "dispatched": False,
                                 "why": "open_play decision carries no "
                                        "`items:` in its firing event's "
                                        "detail - a person or the Meta "
                                        "Agent must commission it naming "
                                        "the children"})
                    continue
                goal += f" items:{im.group(1)}"
            plan.append({"case_id": case["case_id"], "action": pending,
                         "workflow": workflow, "goal": goal,
                         "attempt": len(claims) + 1, "dispatched": False})
    if dry_run:
        for p in plan:
            if verbose:
                print(f"{p['case_id']:<38} {p['action']:<26} "
                      + (f"would run {p['workflow']} (attempt {p['attempt']})"
                         if "workflow" in p else p["why"]))
        return plan
    out = []
    for p in plan:
        if "workflow" not in p:
            out.append(p)
            continue
        with session() as s:
            r = _repo.case_workspace(s.cur, s.ph, p["case_id"])
            workspace = ((r["workspace_code"] if r else None)
                         or _workspace() or None)
        try:
            run_id = _spawn_run(p["workflow"], p["goal"], workspace, "")
        except Exception as e:      # noqa: BLE001 - not started: nothing claimed
            out.append({**p, "dispatched": False, "why": f"could not start "
                        f"{p['workflow']}: {e}"})
            if verbose:
                print(f"{p['case_id']:<38} {p['action']:<26} NOT dispatched: {e}")
            continue
        with session() as s:
            c = _repo.case_claim_fields(s.cur, s.ph, p["case_id"])
        claim_delivery(p["case_id"], p["action"], int(c["clock_seq"] or 1),
                       run_id, c["play_id"], c["workspace_code"])
        try:
            from pathlib import Path as _P
            import os as _os
            from ioagentfarm.engine.otel_export import case_dispatched
            case_dispatched(_P(_os.environ.get("IOF_ROOT", ".iof")),
                            case_id=p["case_id"], action=p["action"],
                            play_id=str(c["play_id"] or ""), workflow=p["workflow"],
                            run_id=run_id, attempt=int(p["attempt"]))
        except Exception:  # noqa: BLE001 - observability never blocks a delivery
            pass
        out.append({**p, "dispatched": True, "run_id": run_id})
        if verbose:
            print(f"{p['case_id']:<38} {p['action']:<26} -> {p['workflow']} "
                  f"run {run_id} (attempt {p['attempt']})")
    return out


def cmd_dispatch(args) -> int:
    """Deliver what is owed: commission the action workflow for every
    undelivered decision (--dry-run: say what would be dispatched)."""
    res = dispatch_pending(dry_run=args.dry_run, verbose=not args.json)
    if args.json:
        print(json.dumps({"dispatch": res, "dry_run": bool(args.dry_run)},
                         indent=2))
        return 0
    if not res:
        print("nothing owed: every pending decision has a delivery in "
              "flight or none is pending")
    return 0


def cmd_record_action(args) -> int:
    with session(args.root_hint) as s:
        cur, ph = s.cur, s.ph
        if not _repo.case_state(cur, ph, args.case):
            print(f"REFUSED: no case {args.case!r}", file=sys.stderr)
            return 1
        # Idempotent for the SAME receipt: `commission` records its
        # delivery itself, and an act step that runs record-action anyway
        # (seen live, against the prompt) must not write the delivery
        # twice.
        _last = _repo.latest_delivery_receipt(cur, ph, args.case,
                                              args.action)
        if _last is not None and (_last.get("detail") or "") == \
                (args.receipt or ""):
            print(f"already recorded: {args.case} {args.action} with "
                  f"receipt {args.receipt!r} - not written twice")
            return 0
        _ledger(cur, ph, args.case, "action_completed", args.receipt, None,
                args.action, None, None)
    print(f"recorded {args.action} on {args.case} (receipt {args.receipt})")
    return 0


def cmd_ctx(args) -> int:
    case_id = (args.case or "").strip()
    if not case_id and args.goal:
        m = _CASE_RE.search(args.goal)
        if m:
            case_id = m.group(0)
    if not case_id:
        print("REFUSED: no case id — pass --case, or --goal containing "
              "CASE-<group>-<item>", file=sys.stderr)
        return 1
    with session(args.out) as s:
        case = _repo.get_case(s.cur, s.ph, case_id)
        if not case:
            print(f"REFUSED: no case {case_id!r}", file=sys.stderr)
            return 1
        history = _repo.case_history_desc(s.cur, s.ph, case_id)
        spec = load_rulebook(s.cur, s.ph, case.get("template", "")) or {}
    case["params"] = json.loads(case.pop("params_json"))
    case["history"] = history
    # The rulebook's PENDING action = the newest rule DECISION whose action
    # has not been delivered yet. A delegation must carry that decision
    # verbatim: observed live, the meta agent transitioned a case correctly
    # (R05 extend_sla) and then commissioned remind_owner — a mislabeled
    # delegation the rulebook never ordered. Also observed live: an action
    # delivered once being redispatched hours later — with the completion
    # receipt newest, pending is None and the duplicate is refused too.
    pending = analyze_history(history)["pending"]
    # A terminal case has nothing to deliver — a close decision is executed
    # by the transition itself, and no delegation may follow it.
    pending = surviving_pending(spec, case.get("state"), pending)
    case["pending_action"] = pending
    # The retry contract rides the bundle: an action workflow (and the meta
    # agent reading its output) sees whether the pending action is
    # side-effecting BEFORE any delivery attempt.
    case["pending_action_meta"] = action_meta(spec, pending)
    # The window that EXPIRED, beside the one now running. Approved
    # language about an escalation refers to the former; the case row
    # only carries the latter, and delivering the wrong one put a
    # false window length into a reviewed regulatory notice.
    case["prior_sla_days"] = prior_window(history, spec,
                                          case["params"])
    # For an open_play delivery the goal names the children to open:
    # "... items:MEM-004,MEM-007 ..." — parsed HERE so the act step reads
    # a list from the bundle instead of re-parsing prose.
    gi = re.search(r"items:([^\s]+)", args.goal or "")
    case["goal_items"] = ([x.strip() for x in gi.group(1).split(",")
                           if x.strip()] if gi else [])
    # For a workflow delivery the run's goal is rendered HERE, from the
    # contract's goal_hint and the case's own fields, so the act step
    # (and `commission`) hand a deterministic goal to `aicore run` instead
    # of composing one.
    _pm = case.get("pending_action_meta") or {}
    if _pm.get("delivery") == "workflow":
        case["workflow_goal"] = render_workflow_goal(case, _pm)
    # The TOOL a tool-delivered action goes through is the deployment's
    # declaration, resolved here - the act step calls what the bundle names
    # and names nothing itself. Absent (a rulebook installed before the
    # declaration existed) the act step fails closed on it.
    from ioagentfarm.engine.deliveries import TOOL_KINDS, declared_deliveries
    if _pm.get("delivery") in TOOL_KINDS:
        try:
            _decl = declared_deliveries(case.get("workspace_code") or None)
        except ValueError as e:
            _decl = {}
            _pm["deliveries_error"] = str(e)
        _pm["tool"] = (_decl.get(_pm["delivery"]) or {}).get("tool")
        case["pending_action_meta"] = _pm
    # THE CLAIM. A delivery run announces itself here, at the one point
    # every case_action run passes through: (case, action, clock_seq) is
    # this run's, and a second run arriving for the same decision while
    # the first is alive is REFUSED before it can send anything. This is
    # what lets the scheduler dispatch deliveries and the Meta Agent
    # commission them immediately without the two ever double-sending.
    if pending and (case.get("pending_action_meta") or {}).get(
            "side_effects", True):
        _claim = claim_delivery(case_id, pending,
                                int(case.get("clock_seq") or 1),
                                _run_id_from_hint(args.out),
                                case.get("play_id"),
                                case.get("workspace_code"))
        if _claim.get("refused"):
            print(f"REFUSED: {_claim['refused']}", file=sys.stderr)
            return 1
    goal_action = None
    if args.goal:
        gm = re.search(r"action:([a-z_]+)", args.goal)
        if gm:
            goal_action = gm.group(1)
    if goal_action and pending is None:
        print(f"REFUSED: the goal names action {goal_action!r} but "
              f"{case_id} has no pending action — the newest rulebook "
              f"decision was already delivered (or none exists); nothing "
              f"to commission", file=sys.stderr)
        return 1
    if goal_action and pending and goal_action != pending:
        print(f"REFUSED: the goal names action {goal_action!r} but the "
              f"rulebook's pending action for {case_id} is {pending!r} — a "
              "delegation must carry the rulebook's decision verbatim",
              file=sys.stderr)
        return 1
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "case_ctx.json").write_text(json.dumps(case, indent=2),
                                       encoding="utf-8")
    print("STATUS: done")
    print(f"OUTPUT: context for {case_id} (state {case['state']}, "
          f"{len(history)} event(s))")
    return 0


def cmd_list(args) -> int:
    with session() as s:
        rows = _repo.list_cases(s.cur, s.ph)
    if args.json:
        print(json.dumps({"cases": rows}, indent=2))
    else:
        for r in rows:
            sla = f"  SLA {r['sla_days']}d ({r['sla_kind']})" if r["sla_days"] else ""
            print(f"{r['case_id']:<34} {r['state']:<20}{sla}")
        if not rows:
            print("no cases")
    return 0


def cmd_show(args) -> int:
    with session() as s:
        r = _repo.get_case(s.cur, s.ph, args.case_id)
    if not r:
        print(f"no case {args.case_id!r}", file=sys.stderr)
        return 1
    r["params"] = json.loads(r.pop("params_json"))
    print(json.dumps(r, indent=2))
    return 0


def cmd_history(args) -> int:
    with session() as s:
        rows = _repo.case_history(s.cur, s.ph, args.case_id)
    for r in rows:
        arrow = (f"{r['from_state']} -> {r['to_state']}"
                 if r["from_state"] else "")
        rev = (f"  (rev {r['rulebook_revision']})"
               if r.get("rulebook_revision") else "")
        print(f"{r['created_at']}  {r['event']:<22} "
              f"{r['rule_id'] or '-':<5} {r['action'] or '-':<26} {arrow}"
              + (f"  [{r['detail']}]" if r["detail"] else "") + rev)
    if not rows:
        print("no events")
    return 0


def cmd_explain(args) -> int:
    """Deterministic case postmortem — the case-tier counterpart of
    `aicore forensics explain`. A case is not a run: the questions are
    which rule fired, whether the decided action was DELIVERED, what was
    refused, and whether re-commissioning is safe given side effects."""
    with session() as s:
        cur, ph = s.cur, s.ph
        case = _repo.get_case(cur, ph, args.case_id)
        if not case:
            print(f"no case {args.case_id!r}", file=sys.stderr)
            return 1
        history = _repo.case_history_desc(cur, ph, args.case_id)
        spec = load_rulebook(cur, ph, case["template"]) or {}
        children = _repo.child_cases(cur, ph, args.case_id)
        # Holidays are read while the connection is still open.
        # load_holidays degrades any cursor error to "no holidays", so
        # reading them after close() silently dropped the calendar and
        # explain's deadline disagreed with the timer's on every
        # calendar-declaring rulebook.
        holidays = _timers.case_holidays(cur, ph, spec)
    params = json.loads(case["params_json"])
    analysis = analyze_history(history)
    terminal = case["state"] in set(spec.get("terminal_states", ("CLOSED",)))
    pending = surviving_pending(spec, case["state"], analysis["pending"])
    meta = action_meta(spec, pending)
    sla = _sla_posture(case, spec, holidays)
    goal = None
    if case.get("goal_deadline") or spec.get("goal_sla_param"):
        overdue = None
        if case.get("goal_deadline"):
            try:
                overdue = time.time() > time.mktime(time.strptime(
                    case["goal_deadline"], "%Y-%m-%dT%H:%M:%S"))
            except Exception:                     # noqa: BLE001
                pass
        goal = {"goal": spec.get("goal"),
                "deadline": case.get("goal_deadline"),
                "appears_overdue": overdue}

    verdict: list[str] = []
    look_next: list[str] = []
    # THE VERDICT MUST CARRY THE BODY'S OWN FINDINGS. Terminal used to
    # short-circuit the chain, so a case whose closing rule ordered a
    # mandated notice printed "PENDING — not delivered" a few rows above a
    # verdict that said only "CLOSED". The verdict is the part an operator
    # reads; a finding that appears in the body and not the summary is a
    # finding that gets missed.
    if terminal:
        verdict.append(
            "CLOSED — terminal state; the rulebook accepts no further "
            "events for this case." + (
                f" The closing rule ordered {pending!r}, which is STILL "
                f"UNDELIVERED — closing the case did not send it."
                if pending else ""))
    if pending:
        se = meta and meta.get("side_effects", True)
        verdict.append(
            f"PENDING ACTION: {pending!r} (rule "
            f"{analysis['decisions'][0].get('rule_id')}) is decided but not "
            f"delivered.")
        if se:
            delivery = (meta or {}).get("delivery", "external system")
            declared = "declared" if (meta or {}).get("declared") else \
                "UNDECLARED — treated as side-effecting (fail-closed)"
            verdict.append(
                f"RETRY IS NOT FREE: {pending!r} reaches an external "
                f"system ({delivery}; {declared}). If a commissioning run "
                f"failed, the delivery may still have happened — verify the "
                f"receipt/ledger BEFORE re-commissioning; a completion "
                f"without a record double-sends on retry.")
            look_next.append(
                f"check the delivery ledger/receipt for {pending!r}; if "
                f"delivered, `iof-case record-action --case {case['case_id']}"
                f" --action {pending} --receipt <r>` and stop")
            look_next.append(
                f"if genuinely undelivered, commission exactly "
                f"`action:{pending}` — the ctx guard enforces the verbatim "
                f"name")
        else:
            verdict.append(f"{pending!r} is an internal state action "
                           f"(no external side effect) — safe to "
                           f"(re)commission.")
            look_next.append(f"commission exactly `action:{pending}`")
    elif not terminal:
        verdict.append("NO PENDING ACTION — the newest rulebook decision "
                       "was delivered (or none exists). Do not redispatch; "
                       "await the next typed event.")
    if analysis["unmatched"]:
        u = analysis["unmatched"][0]
        verdict.append(
            f"{len(analysis['unmatched'])} event(s) REFUSED as UNMATCHED "
            f"(latest: {u['event']} at {u['created_at']}) — the rulebook "
            f"never guesses; a human must review. Never improvise a "
            f"transition around a refusal.")
        look_next.append(f"review the refused event(s) in "
                         f"`iof-case history {case['case_id']}`")
    if sla.get("appears_expired") and not terminal:
        verdict.append(
            f"SLA WINDOW APPEARS EXPIRED (deadline {sla['deadline']}, "
            f"{case['sla_days']}d {case['sla_kind']}) — expect a typed "
            f"event from the monitoring system; do not synthesize one.")
    if goal and goal.get("appears_overdue") and not terminal:
        verdict.append(
            f"GOAL WINDOW EXPIRED (deadline {goal['deadline']}) — the case "
            f"is still open past the play's declared objective window. "
            f"Every rung can be green while the objective is unmet; this "
            f"line is what says so.")

    superseded = [d for d in analysis["decisions"] if d.get("superseded")]
    result = {
        "case_id": case["case_id"], "template": case["template"],
        "rulebook_revision": spec.get("_revision"),
        "state": case["state"], "play_id": case["play_id"],
        "group": case["group_ref"], "item": case["item_ref"],
        "roles": {k: params[k] for k in spec.get("role_params", [])
                  if k in params},
        "sla": sla, "goal": goal, "pending_action": pending,
        "pending_action_meta": meta,
        "children": children,
        "decisions": analysis["decisions"],
        "unmatched": analysis["unmatched"],
        "verdict": verdict, "look_next": look_next,
    }
    if args.json:
        print(json.dumps(result, indent=2))
        return 0
    print(f"{case['case_id']} — {case['template']} "
          f"rev {spec.get('_revision', '?')}  [{case['state']}]")
    print(f"  play {case['play_id']}  group {case['group_ref']}  "
          f"item {case['item_ref']}")
    if result["roles"]:
        print("  roles: " + ", ".join(f"{k}={v}"
                                      for k, v in result["roles"].items()))
    if sla.get("deadline"):
        exp = "EXPIRED" if sla["appears_expired"] else "running"
        print(f"  SLA: {case['sla_days']}d ({case['sla_kind']}) since "
              f"{case['sla_started_at']} -> deadline {sla['deadline']} "
              f"({exp})")
    if goal and (goal.get("deadline") or goal.get("goal")):
        # THE OBJECTIVE IS WHAT THE CASE IS FOR, and this is the first
        # command anyone runs on a case. It carried the sentence in --json
        # and printed only the date, which tells a reader that something is
        # due without ever saying what.
        if goal.get("goal"):
            for i, line in enumerate(textwrap.wrap(goal["goal"], 70)):
                print(("  goal: " if i == 0 else "        ") + line)
        if goal.get("deadline"):
            # A terminal case's objective clock is not "running": it stopped
            # when the case did, whichever way it ended.
            g = ("case closed" if terminal else
                 "OVERDUE" if goal["appears_overdue"] else "running")
            lead = "        by " if goal.get("goal") else "  goal: deadline "
            print(f"{lead}{goal['deadline']} ({g})")
    if children:
        print(f"  children ({len(children)}): " + ", ".join(
            f"{c['case_id']} [{c['state']}]" for c in children))
    print("decisions (newest first):")
    for d in analysis["decisions"]:
        status = ("DELIVERED" + (f" [{d['receipt']}]" if d.get("receipt")
                                 else "")) if d["delivered"] else (
            "SUPERSEDED — never delivered; do not deliver"
            if d.get("superseded") else "PENDING — not delivered")
        print(f"  {d['created_at']}  {d.get('rule_id') or '-':<5} "
              f"{d['action']:<26} {status}")
    if not analysis["decisions"]:
        print("  (none)")
    for u in analysis["unmatched"]:
        print(f"refused: {u['created_at']}  {u['event']}  "
              f"[{u.get('detail') or ''}]")
    print("VERDICT:")
    for v in verdict:
        print(f"  - {v}")
    if look_next:
        print("NEXT:")
        for n in look_next:
            print(f"  - {n}")
    return 0


def cmd_audit(args) -> int:
    """Fleet view: every case with its health flags — the cross-case
    counterpart of the run-fleet queries."""
    specs: dict = {}
    report = []
    with session() as s:
        cur, ph = s.cur, s.ph
        for c in _repo.all_cases(cur, ph):
            t = c["template"]
            if t not in specs:
                specs[t] = load_rulebook(cur, ph, t) or {}
            analysis = analyze_history(
                _repo.case_history_desc(cur, ph, c["case_id"]))
            terminal = c["state"] in set(specs[t].get("terminal_states",
                                                      ("CLOSED",)))
            pending = surviving_pending(specs[t], c["state"],
                                        analysis["pending"])
            meta = action_meta(specs[t], pending)
            flags = []
            if pending:
                flags.append("PENDING-UNDELIVERED"
                             + (":side-effects"
                                if meta and meta.get("side_effects", True)
                                else ""))
            if analysis["unmatched"]:
                flags.append(f"UNMATCHED x{len(analysis['unmatched'])}")
            sla = _sla_posture(c, specs[t],
                               _timers.case_holidays(cur, ph, specs[t]))
            if sla.get("appears_expired") and not terminal:
                flags.append("SLA-EXPIRED")
            # The fleet-level answer to "every gate green, objective
            # unmet": ISO timestamps compare lexicographically.
            if c.get("goal_deadline") and not terminal \
                    and str(c["goal_deadline"]) <= _now():
                flags.append("GOAL-OVERDUE")
            report.append({"case_id": c["case_id"], "template": t,
                           "state": c["state"],
                           "pending_action": pending,
                           "flags": flags})
    if args.json:
        print(json.dumps({"cases": report}, indent=2))
        return 0
    for r in report:
        print(f"{r['case_id']:<34} {r['state']:<20} "
              f"{','.join(r['flags']) or 'healthy'}")
    if not report:
        print("no cases")
    return 0


def cmd_simulate(args) -> int:
    """Walk a rulebook over a hypothetical event sequence — no database
    writes, no side effects. Default (no --events): the exhaust trace,
    'nobody ever responds, only the clock fires' — the path a business
    reviewer most needs to see before approving."""
    with session() as s:
        spec = load_rulebook(s.cur, s.ph, args.template_id)
    if spec is None:
        print(f"no rulebook {args.template_id!r}", file=sys.stderr)
        return 1
    if args.events:
        events = [e.strip() for e in args.events.split(",") if e.strip()]
        unknown = [e for e in events if e not in spec["events"]]
        if unknown:
            print(f"REFUSED: unknown event(s) {', '.join(unknown)} — "
                  f"{args.template_id}'s typed events are: "
                  f"{', '.join(spec['events'])}", file=sys.stderr)
            return 1
        steps = simulate_walk(spec, events,
                              open_event=args.open_event or None)
        title = "declared sequence"
    else:
        steps = exhaust_walk(spec)
        title = "exhaust trace: nobody responds, only the clock fires"
    if args.json:
        print(json.dumps({"template_id": args.template_id,
                          "revision": spec.get("_revision"),
                          "mode": title, "steps": steps}, indent=2))
        return 0
    params = spec.get("default_params", {})
    print(f"{args.template_id} rev {spec.get('_revision', '?')} — {title}")
    for s in steps:
        if s.get("verdict"):
            print(f"  {s['state']} + {s['event']} -> {s['verdict']}: "
                  f"{s['note']}")
            continue
        w = s.get("window")
        wtxt = f"  (window {w}={params.get(w)}d)" if w else ""
        print(f"  {s['state']} + {s['event']} -> {s['rule_id']} "
              f"{s['action']} -> {s['to_state']}{wtxt}")
    return 0


def cmd_kpi(args) -> int:
    """Is the playbook WORKING? Ledger-derived effectiveness per play:
    case counts and states, time-to-close, how cases close, and the rule
    heatmap (what share of cases ever needed each rung — a ladder whose
    last rung fires often is a window set too tight)."""
    specs: dict = {}
    plays: dict = {}
    with session() as s:
        cur, ph = s.cur, s.ph
        for c in _repo.cases_for_kpi(cur, ph, args.play or ""):
            t = c["template"]
            if t not in specs:
                specs[t] = load_rulebook(cur, ph, t) or {}
            terminal = set(specs[t].get("terminal_states", ("CLOSED",)))
            evs = _repo.case_events_for_kpi(cur, ph, c["case_id"])
            pl = plays.setdefault(c["play_id"], {
                "template": t, "goal": specs[t].get("goal"),
                "total": 0, "states": {}, "closed": 0,
                "close_days": [], "closing_events": {}, "rules": {},
                "unmatched": 0, "closed_success": 0, "closed_abandoned": 0,
                "closed_unclassified": 0, "closed_within_goal": 0,
                "closed_after_goal": 0})
            success = set(specs[t].get("success_events") or ())
            abandon = set(specs[t].get("abandonment_events") or ())
            pl["total"] += 1
            pl["states"][c["state"]] = pl["states"].get(c["state"], 0) + 1
            fired: set = set()
            gev = (_timers.goal_event(specs[t])
                   if specs[t].get("goal_sla_param") else None)
            goal_missed = bool(gev) and any(e.get("event") == gev
                                            for e in evs)
            for e in evs:
                if e.get("action") == "UNMATCHED":
                    pl["unmatched"] += 1
                if e.get("rule_id"):
                    fired.add((e["rule_id"], e.get("action")))
                if e.get("to_state") in terminal and pl is not None \
                        and c["state"] in terminal:
                    pl["closing_events"][e["event"]] = \
                        pl["closing_events"].get(e["event"], 0) + 1
                    # Against the DECLARED ends, not event-name
                    # conventions: did the goal get met, and inside its
                    # window?
                    if success or abandon:
                        if e["event"] in success:
                            pl["closed_success"] += 1
                        elif e["event"] in abandon:
                            pl["closed_abandoned"] += 1
                        else:
                            pl["closed_unclassified"] += 1
                    if c.get("goal_deadline"):
                        # THE LEDGER BEATS THE ARITHMETIC. When the case's
                        # own record holds the goal event, the objective
                        # was missed - whoever raised it said so, and a
                        # date comparison that disagrees is inferring
                        # against evidence. (They agree in production and
                        # diverge the moment a clock is fired by hand.)
                        kind = ("closed_after_goal" if goal_missed else
                                "closed_within_goal"
                                if str(e["created_at"])
                                <= str(c["goal_deadline"])
                                else "closed_after_goal")
                        pl[kind] += 1
                    try:
                        t0 = time.mktime(time.strptime(
                            c["created_at"], "%Y-%m-%dT%H:%M:%S"))
                        t1 = time.mktime(time.strptime(
                            e["created_at"], "%Y-%m-%dT%H:%M:%S"))
                        pl["close_days"].append((t1 - t0) / 86400.0)
                    except Exception:
                        pass
            if c["state"] in terminal:
                pl["closed"] += 1
            for key in fired:
                pl["rules"][key] = pl["rules"].get(key, 0) + 1
    report = []
    for play_id, pl in sorted(plays.items()):
        days = pl.pop("close_days")
        pl["avg_days_to_close"] = round(sum(days) / len(days), 2) \
            if days else None
        pl["max_days_to_close"] = round(max(days), 2) if days else None
        pl["rule_heatmap"] = [
            {"rule_id": rid, "action": act, "cases": n,
             "pct_of_cases": round(100.0 * n / pl["total"], 1)}
            for (rid, act), n in sorted(pl["rules"].items())]
        pl.pop("rules")
        report.append({"play_id": play_id, **pl})
    if args.json:
        print(json.dumps({"plays": report}, indent=2))
        return 0
    for pl in report:
        print(f"{pl['play_id']}  ({pl['template']})  cases {pl['total']}  "
              f"closed {pl['closed']}"
              + (f"  avg close {pl['avg_days_to_close']}d" if
                 pl["avg_days_to_close"] is not None else "")
              + (f"  UNMATCHED {pl['unmatched']}" if pl["unmatched"]
                 else ""))
        print(f"  states: " + ", ".join(f"{k}={v}" for k, v in
                                        sorted(pl["states"].items())))
        if pl["closing_events"]:
            print(f"  closed by: " + ", ".join(
                f"{k}={v}" for k, v in sorted(pl["closing_events"].items())))
        if pl["closed_success"] or pl["closed_abandoned"] \
                or pl["closed_unclassified"]:
            print(f"  vs declared ends: success={pl['closed_success']}  "
                  f"abandoned={pl['closed_abandoned']}  "
                  f"unclassified={pl['closed_unclassified']}")
        if pl["closed_within_goal"] or pl["closed_after_goal"]:
            total_g = pl["closed_within_goal"] + pl["closed_after_goal"]
            print(f"  within the goal window: "
                  f"{pl['closed_within_goal']} of {total_g}")
        for r in pl["rule_heatmap"]:
            print(f"    {r['rule_id']:<6} {r['action']:<28} "
                  f"{r['cases']:>3} case(s)  {r['pct_of_cases']:>5}%")
    if not report:
        print("no cases")
    return 0



# ------------------------------------------------------ timer surfaces

def _undelivered_block(cur, ph, case_id: str, spec: dict):
    """Escalating a person who was never contacted is indefensible in the
    audit these plays exist to produce. When the window's own notice is a
    decided-but-undelivered side-effecting action, the clock is not fired
    — it is surfaced instead."""
    analysis = analyze_history(_repo.case_history_desc(cur, ph, case_id))
    pending = analysis["pending"]
    if not pending:
        return None
    meta = action_meta(spec, pending)
    if meta and meta.get("side_effects", True):
        return pending
    return None


def cmd_due(args) -> int:
    """Clocks that have expired and have not been applied. The operator
    view of what the platform is waiting on, and the selection an emitter
    consumes."""
    out = []
    with session() as s:
        cur, ph = s.cur, s.ph
        for t in _timers.due(cur, ph, now=args.now or None):
            case = _repo.get_case(cur, ph, t["case_id"])
            if not case:
                continue
            spec = load_rulebook(cur, ph, case["template"]) or {}
            blocked = _undelivered_block(cur, ph, t["case_id"], spec)
            out.append({
                "timer_id": t["id"], "case_id": t["case_id"],
                "event": t["event"], "clock_seq": t["clock_seq"],
                "deadline": t["deadline"], "idem_key": t["idem_key"],
                "state": case["state"], "template": case["template"],
                "blocked_on_undelivered": blocked,
            })
    if args.json:
        print(json.dumps({"due": out}, indent=2))
        return 0
    for d in out:
        flag = (f"  BLOCKED: {d['blocked_on_undelivered']} never delivered"
                if d["blocked_on_undelivered"] else "")
        print(f"{d['case_id']:<38} {d['event']:<18} due {d['deadline']}"
              f"  clock {d['clock_seq']}{flag}")
    if not out:
        print("nothing due")
    return 0


def apply_timer_event(case_id: str, event: str, clock_seq, idem_key: str,
                      detail: str = "", *,
                      undelivered_block: bool = True) -> dict:
    """Apply one timer trigger and report WHAT HAPPENED. The single path
    every emitter uses — the scheduler in-process, an external system over
    HTTP, or a person at a terminal — so the guarantees cannot differ by
    caller.

    Exactly one outcome is retryable. A caller that retries any other
    hammers a case that is behaving correctly.
    """
    # Its OWN connection, closed before `cmd_transition` opens another:
    # this is the shared emitter path, and the transition must see a
    # committed, unlocked database.
    with session() as s:
        cur, ph = s.cur, s.ph
        case = _repo.get_case(cur, ph, case_id)
        if not case:
            return {"outcome": _timers.OUTCOME_ERROR,
                    "detail": f"no case {case_id!r}"}
        spec = load_rulebook(cur, ph, case["template"])
        if spec is None:
            return {"outcome": _timers.OUTCOME_ERROR,
                    "detail": f"no rulebook for {case['template']!r}"}
        # ORDER MATTERS. An occurrence that was already applied is
        # SUPPRESSED, whatever the case has since done: by definition the
        # case has moved on, so a fence check first would report the
        # far less informative "fenced", and an undelivered check first
        # would report "skipped" for work that is in fact complete.
        if idem_key and _repo.event_with_key_exists(cur, ph, case_id,
                                                    idem_key):
            return {"outcome": _timers.OUTCOME_SUPPRESSED,
                    "detail": f"{case_id} already applied occurrence "
                              f"{idem_key!r}", "state": case["state"]}
        current = int(case.get("clock_seq") or 1)
        # 0 = the goal clock's sentinel: case-scoped, exempt from the fence.
        if clock_seq not in (None, "", 0, "0") \
                and int(clock_seq) != current:
            return {"outcome": _timers.OUTCOME_FENCED,
                    "detail": f"case is on clock {current}, trigger names "
                              f"{clock_seq}", "state": case["state"]}
        # The block protects a PERSON from a clock: never escalate someone
        # whose own notice never went out. A run's outcome is not an
        # escalation - a finding arriving while a notice is undelivered
        # fires the rule for it, whose decision supersedes the undelivered
        # one with a fuller notice - so the settler asks to skip the block.
        blocked = (_undelivered_block(cur, ph, case_id, spec)
                   if undelivered_block else None)
        if blocked:
            return {"outcome": _timers.OUTCOME_SKIPPED,
                    "detail": f"{blocked!r} was decided but never "
                              f"delivered; escalating now would penalise "
                              f"a person who was never contacted",
                    "state": case["state"]}

    class _Args:
        pass

    a = _Args()
    a.case, a.event, a.detail = case_id, event, detail
    a.key, a.expect_clock, a.out = idem_key, clock_seq, ""
    import io as _io
    import contextlib as _ctx
    buf, err = _io.StringIO(), _io.StringIO()
    with _ctx.redirect_stdout(buf), _ctx.redirect_stderr(err):
        rc = cmd_transition(a)
    text = (buf.getvalue() + err.getvalue()).strip()
    if rc == 0 and _MSG_DUPLICATE_SUPPRESSED in text:
        return {"outcome": _timers.OUTCOME_SUPPRESSED, "detail": text}
    if rc == 0:
        return {"outcome": _timers.OUTCOME_FIRED, "detail": text}
    if rc == 3:
        return {"outcome": _timers.OUTCOME_FENCED, "detail": text}
    if _MSG_NO_RULE in text:
        return {"outcome": _timers.OUTCOME_UNMATCHED, "detail": text}
    return {"outcome": _timers.OUTCOME_ERROR, "detail": text}


def cmd_fire(args) -> int:
    """The listener's local twin: apply one trigger, answer with the
    outcome. Exit 0 for every settled outcome, 2 for the retryable one."""
    res = apply_timer_event(args.case, args.event,
                            args.clock_seq or None, args.key,
                            args.detail)
    print(json.dumps(res, indent=2))
    return 0 if res["outcome"] in _timers.TERMINAL_OUTCOMES else 2


def cmd_scheduler(args) -> int:
    """Drain the durable timer store: lease what is due, apply it, record
    the outcome. Holds NOTHING of its own — every start rebuilds from the
    table, so losing this process cannot lose a clock."""
    import uuid
    holder = args.holder or f"sched-{uuid.uuid4().hex[:8]}"
    passes, applied = 0, []
    while True:
        # Commissioned runs first: a run that finished is an event the
        # case is waiting on, and it is settled through the same path a
        # clock is.
        for a in settle_runs(verbose=not args.json):
            applied.append({**a, "kind": "run"})
        for d in dispatch_pending(verbose=not args.json):
            applied.append({**d, "kind": "dispatch"})
        with session() as s:
            rows = _timers.due(s.cur, s.ph, now=args.now or None)
            claimed = _timers.lease(s.cur, s.ph, rows, holder)
        for t in claimed:
            res = apply_timer_event(
                t["case_id"], t["event"], t["clock_seq"], t["idem_key"],
                args.detail or f"Scheduler: {t['event']} at "
                               f"{t['deadline']}")
            with session() as s:
                cur, ph = s.cur, s.ph
                if res["outcome"] in _timers.CONSUMING_OUTCOMES:
                    _timers.complete(cur, ph, t["id"], res["outcome"])
                elif res["outcome"] == _timers.OUTCOME_SKIPPED:
                    # The window expired; only an undelivered notice
                    # stopped it being applied. Keep the clock so
                    # resolving the delivery lets it fire, and do not
                    # spend the retry budget on a condition only a person
                    # can clear.
                    _timers.hold(cur, ph, t["id"], res["outcome"])
                elif int(t["attempts"] or 0) + 1 >= _timers.max_attempts():
                    _timers.give_up(cur, ph, t["id"], res["outcome"])
                else:
                    _timers.complete(cur, ph, t["id"], res["outcome"])
            applied.append({"case_id": t["case_id"], "event": t["event"],
                            "outcome": res["outcome"]})
            if not args.json:
                print(f"{t['case_id']:<38} {t['event']:<18} "
                      f"-> {res['outcome']}")
        passes += 1
        if args.once or passes >= max(1, int(args.passes or 1)):
            break
        time.sleep(max(1, int(args.interval)))
    if args.json:
        print(json.dumps({"holder": holder, "applied": applied}, indent=2))
    elif not applied:
        print("nothing due")
    return 0


# ------------------------------------------------- rulebook admin surface

def cmd_rulebook(args) -> int:
    with session() as s:
        cur, ph = s.cur, s.ph
        if args.rb_command == "list":
            for r in _repo.list_rulebooks(cur, ph):
                print(f"{r['template_id']:<26} rev {r['revision']:<3} "
                      f"{r['title']}  (updated {r['updated_at']} "
                      f"by {r['updated_by'] or '-'})")
            return 0
        if args.rb_command == "show":
            spec = load_rulebook(cur, ph, args.template_id)
            if spec is None:
                print(f"no rulebook {args.template_id!r}", file=sys.stderr)
                return 1
            print(json.dumps(spec, indent=2))
            return 0
        if args.rb_command == "validate":
            spec = json.loads(Path(args.file).read_text(encoding="utf-8"))
            errs = validate_spec(spec) + capability_resolution_errors(spec)
            if errs:
                for e in errs:
                    print(f"ERROR: {e}", file=sys.stderr)
                return 1
            print(f"OK: {spec['template_id']} — {len(spec['rules'])} rule(s), "
                  f"{len(spec.get('wildcard_rules', []))} wildcard(s), "
                  f"{len(spec['states'])} state(s), "
                  f"{len(spec['events'])} event(s)")
            return 0
        if args.rb_command == "put":
            spec = json.loads(Path(args.file).read_text(encoding="utf-8"))
            who = args.as_user or os.environ.get("IOF_REVIEWER") or "cli"
            # Read the live cases BEFORE the write: the answer depends on
            # the revision this one replaces.
            stranded = cases_a_revision_strands(cur, ph, spec)
            try:
                rev = save_rulebook(cur, ph, spec, who)
            except ValueError as e:
                for line in str(e).split("; "):
                    print(f"ERROR: {line}", file=sys.stderr)
                print("REFUSED: the rulebook was not saved — a spec that "
                      "fails validation must never decide a live case",
                      file=sys.stderr)
                return 1
            print(f"saved {spec['template_id']} rev {rev} "
                  f"({len(spec['rules'])} rule(s), "
                  f"{len(spec['states'])} state(s)) — live for every future "
                  f"transition, no code change")
            warn_about_stranded_cases(stranded, spec["template_id"], rev)
            return 0
        print(f"unknown rulebook command {args.rb_command!r}",
              file=sys.stderr)
        return 1


def main(argv: list[str] | None = None) -> int:
    # SURVIVE A LEGACY CONSOLE. The ledger prints DATA - transition
    # details carry whatever the model or a person wrote, and a finding
    # with an arrow in it crashed `iof-case history` outright on a cp1252
    # Windows console (UnicodeEncodeError mid-listing). The build console
    # learned this first; a CLI must degrade a character, never die on it.
    import sys as _sys
    for _stream in (_sys.stdout, _sys.stderr):
        try:
            _stream.reconfigure(errors="replace")
        except (AttributeError, ValueError, OSError):
            pass
    # THE WORKSPACE'S OWN `.env` IS WHERE THE DEPLOYMENT'S SETTINGS LIVE, and
    # this CLI never read it. `aicore` loads it; `iof-consult` loads it; the
    # case tier did not - so anything configured there was simply absent from
    # this process. It cost the one span that answers "which runs did this
    # case cause": `dispatch_pending` calls `case_dispatched`, which asks
    # `otel_export.enabled()`, which reads `OTEL_EXPORTER_OTLP_ENDPOINT` - set
    # in the workspace `.env` and therefore unset here. The runs the
    # dispatcher STARTED were traced (each `aicore run` subprocess loads the
    # file itself), so the backend showed the effects with the cause missing,
    # and nothing anywhere reported a problem. Measured: 0 dispatch spans
    # without this, 1 fully-attributed span with it.
    try:
        import os as _os
        _code = (_os.environ.get("IOF_WORKSPACE") or "").strip()
        if _code:
            from ioagentfarm.engine.workspace_env import load_workspace_env
            load_workspace_env(_code)
    except Exception:  # noqa: BLE001 - configuration is best-effort here
        pass

    p = argparse.ArgumentParser(prog="iof-case",
                                description="case tier: durable case records "
                                            "+ DB-resident rulebooks")
    sub = p.add_subparsers(dest="command", required=True)

    op = sub.add_parser("open")
    op.add_argument("--play", required=True)
    op.add_argument("--group", required=True)
    op.add_argument("--items", required=True,
                    help='comma-separated, e.g. "Denver,Phoenix,Los Angeles"')
    op.add_argument("--template", default="",
                    help="rulebook family; defaults to the play's template")
    op.add_argument("--open-event-for", action="append", default=[],
                    metavar="ITEM=EVENT",
                    help="per-item open variant event (repeatable)")
    op.add_argument("--no-owner", default="",
                    help="sugar: items opened with case_opened_no_owner")
    op.add_argument("--out", default="")
    op.set_defaults(func=cmd_open)

    tr = sub.add_parser("transition")
    tr.add_argument("--case", required=True)
    tr.add_argument("--event", required=True)
    tr.add_argument("--detail", default="")
    tr.add_argument("--expect-clock", default="", dest="expect_clock",
                    help="the clock sequence this trigger was raised "
                         "against; the transition is refused when the "
                         "case has since moved to another clock")
    tr.add_argument("--key", default="",
                    help="idempotency key of this occurrence (e.g. clock id"
                         " + deadline); a retried delivery with the same "
                         "key is suppressed, never re-fired")
    tr.add_argument("--out", default="")
    tr.set_defaults(func=cmd_transition)

    ra = sub.add_parser("record-action")
    ra.add_argument("--case", required=True)
    ra.add_argument("--action", required=True)
    ra.add_argument("--receipt", default="")
    ra.add_argument("--root-hint", default="")
    ra.set_defaults(func=cmd_record_action)

    oc = sub.add_parser("open-children",
                        help="deliver a pending open_play action: open the "
                             "ordered child cases (linked by parent) and "
                             "record the delivery on the parent's ledger")
    oc.add_argument("--case", required=True,
                    help="the PARENT case whose pending action is open_play")
    oc.add_argument("--items", required=True,
                    help='comma-separated child items, e.g. "MEM-004,MEM-007"')
    oc.add_argument("--group", default="",
                    help="children's group_ref; defaults to the parent's")
    oc.add_argument("--out", default="")
    oc.add_argument("--root-hint", default="")
    oc.set_defaults(func=cmd_open_children)

    cm = sub.add_parser("commission",
                        help="deliver a pending workflow action: start the "
                             "run the rulebook named (or attach --run-id), "
                             "link it to the case, record the delivery")
    cm.add_argument("--case", required=True)
    cm.add_argument("--run-id", dest="run_id", default="",
                    help="attach a run that already exists instead of "
                         "starting one")
    cm.add_argument("--out", default="")
    cm.add_argument("--root-hint", default="")
    cm.set_defaults(func=cmd_commission)

    dv = sub.add_parser("deliveries",
                        help="the tools this deployment declares for case "
                             "deliveries (email, monitoring_task, "
                             "system_of_record, verification), and where "
                             "they come from")
    dv.add_argument("--workspace", default="")
    dv.add_argument("--json", action="store_true")
    dv.add_argument("--out", default="",
                    help="write the declaration here as JSON - what "
                         "`playbook_compile` maps a draft against")
    dv.set_defaults(func=cmd_deliveries)

    dp = sub.add_parser("dispatch",
                        help="deliver what is owed: commission the action "
                             "workflow for every undelivered decision "
                             "(the scheduler does this on every pass)")
    dp.add_argument("--dry-run", dest="dry_run", action="store_true",
                    help="say what would be dispatched; start nothing")
    dp.add_argument("--json", action="store_true")
    dp.set_defaults(func=cmd_dispatch)

    rn = sub.add_parser("runs",
                        help="runs cases have commissioned; --settle "
                             "applies the outcome of every finished one")
    rn.add_argument("--settle", action="store_true")
    rn.add_argument("--json", action="store_true")
    rn.set_defaults(func=cmd_runs)

    cx = sub.add_parser("ctx")
    cx.add_argument("--case", default="")
    cx.add_argument("--goal", default="")
    cx.add_argument("--out", required=True)
    cx.set_defaults(func=cmd_ctx)

    ls = sub.add_parser("list"); ls.add_argument("--json", action="store_true")
    ls.set_defaults(func=cmd_list)

    sh = sub.add_parser("show"); sh.add_argument("case_id")
    sh.set_defaults(func=cmd_show)

    hi = sub.add_parser("history"); hi.add_argument("case_id")
    hi.set_defaults(func=cmd_history)

    ex = sub.add_parser("explain",
                        help="deterministic case postmortem (delivery "
                             "status, SLA posture, retry guidance)")
    ex.add_argument("case_id")
    ex.add_argument("--json", action="store_true")
    ex.set_defaults(func=cmd_explain)

    au = sub.add_parser("audit", help="fleet health view across all cases")
    au.add_argument("--json", action="store_true")
    au.set_defaults(func=cmd_audit)

    sim = sub.add_parser("simulate",
                         help="walk a rulebook over hypothetical events — "
                              "no writes; default: the exhaust trace")
    sim.add_argument("template_id")
    sim.add_argument("--events", default="",
                     help='comma-separated, e.g. "sla_breach,'
                          'backfill_received"')
    sim.add_argument("--open-event", default="")
    sim.add_argument("--json", action="store_true")
    sim.set_defaults(func=cmd_simulate)

    dz = sub.add_parser("due",
                        help="clocks whose window has expired and which "
                             "have not been applied")
    dz.add_argument("--now", default="")
    dz.add_argument("--json", action="store_true")
    dz.set_defaults(func=cmd_due)

    fr = sub.add_parser("fire",
                        help="apply one timer trigger and report the "
                             "outcome (the listener's local twin)")
    fr.add_argument("--case", required=True)
    fr.add_argument("--event", required=True)
    fr.add_argument("--clock-seq", dest="clock_seq", default="")
    fr.add_argument("--key", required=True)
    fr.add_argument("--detail", default="")
    fr.set_defaults(func=cmd_fire)

    sc = sub.add_parser("scheduler",
                        help="drain the durable timer store: lease, "
                             "apply, record")
    sc.add_argument("--once", action="store_true")
    sc.add_argument("--passes", default="1")
    sc.add_argument("--interval", default="60")
    sc.add_argument("--holder", default="")
    sc.add_argument("--now", default="")
    sc.add_argument("--detail", default="")
    sc.add_argument("--json", action="store_true")
    sc.set_defaults(func=cmd_scheduler)

    kp = sub.add_parser("kpi",
                        help="ledger-derived play effectiveness: states, "
                             "time-to-close, closing events, rule heatmap")
    kp.add_argument("--play", default="")
    kp.add_argument("--json", action="store_true")
    kp.set_defaults(func=cmd_kpi)

    rb = sub.add_parser("rulebook",
                        help="the DB-resident rulebook admin surface")
    rbs = rb.add_subparsers(dest="rb_command", required=True)
    rbs.add_parser("list")
    rbsh = rbs.add_parser("show"); rbsh.add_argument("template_id")
    rbv = rbs.add_parser("validate"); rbv.add_argument("--file", required=True)
    rbp = rbs.add_parser("put")
    rbp.add_argument("--file", required=True)
    rbp.add_argument("--as", dest="as_user", default="")
    for sp in (rbs.choices["list"], rbsh, rbv, rbp):
        sp.set_defaults(func=cmd_rulebook)

    args = p.parse_args(argv)
    return args.func(args)
