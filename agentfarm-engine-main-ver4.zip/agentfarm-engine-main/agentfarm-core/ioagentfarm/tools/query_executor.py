"""SQL query executor CLI — safe SELECT-only execution against configured databases.

Called by the data_analyst agent via exec/shell to run validated SQL queries.
Reads database configs from metadata/databases.yml in the specified metadata directory.

Usage:
    python query_executor.py --db <name> --sql "SELECT ..." --metadata-dir /path/to/metadata
    python query_executor.py --db <name> --sql-file query.sql --metadata-dir /path/to/metadata
    python query_executor.py --db <name> --sql-stdin --metadata-dir /path/to/metadata < query.sql
    echo 'SELECT ...' | python query_executor.py --db <name> --sql-stdin --metadata-dir /path/to/metadata
    python query_executor.py --list-databases --metadata-dir /path/to/metadata

Output: JSON to stdout.

Credentials: Auto-loads .env from the project directory (parent of --metadata-dir),
             the metadata directory itself, or the current directory — whichever is found first.
             Override with --env-file. databases.yml supports ${ENV_VAR} substitution.
"""

import argparse
import json
import os
import re
import sys
from abc import ABC, abstractmethod
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# JSON serialization helpers
# ---------------------------------------------------------------------------

class ResultEncoder(json.JSONEncoder):
    """Handle date, datetime, Decimal, and bytes in query results."""

    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, bytes):
            return obj.decode("utf-8", errors="replace")
        return super().default(obj)


# ---------------------------------------------------------------------------
# Database configuration (reads metadata/databases.yml)
# ---------------------------------------------------------------------------

class _UnsetRef:
    """A ``${VAR}`` in databases.yml whose variable is not set.

    NOT an error yet. A placeholder is required only by the backend that reads
    the key: the pharma hub declaration carries ``schema: ${BARRIER_SIGNAL_DB_SCHEMA}``
    for its Postgres deployments - deliberately without a default, so a hub
    can never fall back to ``public`` in silence - and a developer's SQLite
    hub (``type: ${BARRIER_SIGNAL_DB_TYPE:-postgres}`` set to ``sqlite``) never
    reads a schema at all. Failing at substitution time made every agent
    query on a SQLite hub die with "BARRIER_SIGNAL_DB_SCHEMA not set", and the
    agent then reached for ad-hoc Python against the file (2026-09-05). The
    failure now happens where the key is read, with the same message.
    """

    def __init__(self, env_var: str, db_name: str, key: str):
        self.env_var, self.db_name, self.key = env_var, db_name, key

    def __str__(self) -> str:
        return "${" + self.env_var + "}"

    __repr__ = __str__

    def fail(self) -> None:
        _fail(f"Environment variable {self.env_var} not set "
              f"(required by databases.yml for {self.db_name}.{self.key})")


#: Which databases.yml keys each backend READS. A ``${VAR}`` on any other key
#: is never required (a sqlite hub's ``schema``); one on these keys is, and
#: ``--list-databases`` says so up front, as it always did.
_KEYS_READ_BY = {
    "mysql": {"host", "user", "password", "database", "port", "pool_size"},
    "postgres": {"url", "schema", "host", "user", "password", "database", "port"},
    "postgresql": {"url", "schema", "host", "user", "password", "database", "port"},
    "redshift": {"url", "schema", "sslmode", "driver", "host", "user", "password",
                 "database", "port"},
    "duckdb": {"path", "s3_region", "s3_endpoint"},
    "sqlite": {"path"},
}


def _first_required_unset(cfg: Dict[str, Any]) -> "_UnsetRef | None":
    """The first unset placeholder the declared backend would read, or None."""
    db_type = cfg.get("type")
    if isinstance(db_type, _UnsetRef):
        return db_type
    keys = _KEYS_READ_BY.get(str(db_type or "").lower())
    for key, value in cfg.items():
        if isinstance(value, _UnsetRef) and (keys is None or key in keys):
            return value
    return None


class _Cfg(dict):
    """One database's config; reading a key whose placeholder is unset fails
    with the message the substitution step used to raise up front."""

    def __getitem__(self, key):
        value = dict.__getitem__(self, key)
        if isinstance(value, _UnsetRef):
            value.fail()
        return value

    def get(self, key, default=None):
        value = dict.get(self, key, default)
        if isinstance(value, _UnsetRef):
            value.fail()
        return value


def load_database_configs(metadata_dir: str) -> Dict[str, Dict[str, Any]]:
    """Load database configurations from databases.yml.

    Supports ${ENV_VAR} substitution in values, and ${ENV_VAR:-default} for
    settings that have a sensible fallback (the engine schema, say). Plain
    ${ENV_VAR} stays required — an unset one is still a hard error, so an
    absent credential fails loudly instead of connecting to the wrong place.
    """
    try:
        import yaml
    except ImportError:
        _fail("pyyaml is required: pip install pyyaml")

    config_path = Path(metadata_dir) / "databases.yml"
    if not config_path.exists():
        _fail(f"Database config not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not data or "databases" not in data:
        _fail(f"Invalid databases.yml — missing 'databases' key in {config_path}")

    configs = data["databases"]

    # Resolve ${ENV_VAR} references in string values
    for db_name, db_cfg in configs.items():
        for key, val in list(db_cfg.items()):
            if isinstance(val, str) and val.startswith("${") and val.endswith("}"):
                env_var, sep, default = val[2:-1].partition(":-")
                resolved = os.environ.get(env_var)
                if sep:
                    # ${VAR:-default} — unset OR empty falls back, as in a shell.
                    if not resolved:
                        resolved = default
                elif resolved is None:
                    # Required only if the backend reads it - see _UnsetRef.
                    resolved = _UnsetRef(env_var, db_name, key)
                db_cfg[key] = resolved

    # A RELATIVE FILE PATH BELONGS TO THE CATALOG, NOT TO THE CALLER'S CWD.
    #
    # `databases.yml` says `path: metadata/commercial.duckdb`, and that used to
    # resolve against the working directory of whatever ran the query. Two
    # consequences, both silent. `aicore configure-agent` copies the database
    # INTO the agent's workspace beside the catalog that names it — and the
    # copy was never read: the agent's query resolved back to whatever
    # directory the service happened to start in, so the command's whole
    # purpose was defeated wherever those two differed. And run from anywhere
    # else, the same declaration produced an unhandled `_duckdb.IOException`
    # traceback rather than the JSON error every other failure returns.
    #
    # Resolved against the metadata directory FIRST, falling back to the
    # cwd-relative path when that is the one that exists — so a deployment
    # relying on the old behaviour is untouched, and a catalog that ships its
    # data beside itself now works from any directory.
    base = Path(metadata_dir).resolve()
    for db_name, db_cfg in configs.items():
        if str(db_cfg.get("type", "")).lower() not in ("duckdb", "sqlite"):
            continue
        raw = db_cfg.get("path")
        if not isinstance(raw, str) or not raw or raw == ":memory:":
            continue
        if Path(raw).is_absolute():
            continue
        # Three bases, first that EXISTS wins: beside the catalog (what
        # `configure-agent` produces), one level up (`metadata/x.duckdb`
        # written from the repository root, the shape the catalog authoring
        # docs use), and the working directory (the old behaviour). Anything
        # that resolves nowhere is left alone so the error below can name it.
        for candidate in (base / raw, base.parent / raw, Path(raw).resolve()):
            if candidate.exists():
                db_cfg["path"] = str(candidate)
                break

    return configs


# ---------------------------------------------------------------------------
# Query validation
# ---------------------------------------------------------------------------

#: A bare SQL identifier — see PostgresAdapter.connect() for why this is a
#: validation rather than an escape.
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

_DANGEROUS_KEYWORDS = [
    r"\bINSERT\b", r"\bUPDATE\b", r"\bDELETE\b", r"\bDROP\b",
    r"\bCREATE\b", r"\bALTER\b", r"\bTRUNCATE\b", r"\bEXEC\b",
    r"\bEXECUTE\b", r"\bGRANT\b", r"\bREVOKE\b",
    r"\bCOPY\b", r"\bINSTALL\b", r"\bLOAD\b",  # DuckDB: no file writes or extensions
]


def validate_select_query(query: str) -> Tuple[bool, str]:
    """Validate that query is a SELECT (or CTE starting with WITH)."""
    clean = query.strip()
    clean = re.sub(r"--.*$", "", clean, flags=re.MULTILINE)
    clean = re.sub(r"/\*.*?\*/", "", clean, flags=re.DOTALL)
    clean = clean.strip()

    if not re.match(r"^\s*(WITH|SELECT)\b", clean, re.IGNORECASE):
        return False, "Only SELECT statements (and CTEs starting with WITH) are allowed"

    for kw in _DANGEROUS_KEYWORDS:
        if re.search(kw, clean, re.IGNORECASE):
            return False, f"Dangerous SQL keyword detected: {kw.strip(chr(92)).strip('b')}"

    return True, ""


def add_limit_if_missing(query: str, limit: int = 200) -> str:
    """Add LIMIT clause if missing. Strips trailing semicolons."""
    q = query.rstrip()
    while q.endswith(";"):
        q = q[:-1].rstrip()

    if re.search(r"\bLIMIT\b", q, re.IGNORECASE):
        return q

    # Skip LIMIT for complex queries (CTE/UNION)
    if re.search(r"\bWITH\b|\bUNION\b|\bINTERSECT\b|\bEXCEPT\b", q, re.IGNORECASE):
        return q

    return f"{q}\nLIMIT {limit}"


# ---------------------------------------------------------------------------
# Catalog-driven view registration (DuckDB only)
# ---------------------------------------------------------------------------
#
# When a workflow ships a `catalog.yaml` alongside `databases.yml`, every
# entity declared there becomes a DuckDB VIEW named after the entity, pointing
# at the resolved data file. Agents then write natural SQL:
#
#     SELECT * FROM tremfya_patient_flow_funnel WHERE segment='PsO'
#
# instead of hardcoding read_csv('...csv') paths in every query. Path
# resolution lives here, not in the skill files.
#
# Resolution priority for each entity's source_path:
#   1. <cwd>/input_data/<brand_relative>   — S3-seeded or fallback-seeded
#   2. <metadata_dir>/<source_path>        — bundled workflow snapshot
#
# Non-breaking: if catalog.yaml is absent or malformed, registration silently
# returns 0 and the agent's raw read_csv() SQL keeps working (procurement).

_SAFE_IDENT = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def _resolve_entity_source(source_path: str, metadata_dir: Path) -> Optional[Path]:
    """Resolve an entity source_path to an actual file on disk.

    Handles both catalog conventions:
      - 'metadata/data/<brand>/<entity>.csv'  (pharma_goal style, full path from pkg root)
      - 'data/<brand>/<entity>.csv'           (shorter, metadata_dir relative)
      - '<table>.csv'                          (flat catalog, procurement style)
    """
    sp = source_path.replace("\\", "/").lstrip("./")

    # Strip leading 'metadata/' — metadata_dir already points at metadata/
    rel = sp[len("metadata/"):] if sp.startswith("metadata/") else sp

    # Brand-relative path for input_data/ lookup (strip 'data/' too)
    brand_rel = rel[len("data/"):] if rel.startswith("data/") else rel

    # 1) cwd/input_data/<brand_rel> — overrides bundled data when present
    cwd_input = Path.cwd() / "input_data" / brand_rel
    if cwd_input.exists():
        return cwd_input

    # 2) <metadata_dir>/<rel> — bundled workflow snapshot
    bundled = metadata_dir / rel
    if bundled.exists():
        return bundled

    return None


def register_catalog_views(con, db_name: str, metadata_dir: Path) -> int:
    """Register a DuckDB view for each entity in catalog.yaml matching db_name.

    Best-effort. Invalid or unresolvable entities are silently skipped so that
    one broken row cannot block the whole query.
    """
    catalog_path = metadata_dir / "catalog.yaml"
    if not catalog_path.exists():
        return 0

    try:
        import yaml
    except ImportError:
        return 0

    try:
        with open(catalog_path, "r", encoding="utf-8") as f:
            catalog = yaml.safe_load(f) or {}
    except Exception:
        return 0

    entities = normalized_entities(catalog)

    count = 0
    for entity in entities:
        if not isinstance(entity, dict):
            continue
        # Unlike the schema map, this REGISTERS a view from a file, so an
        # entity that names no database is not this database's business.
        if entity.get("database") != db_name:
            continue
        name = entity.get("name")
        source_path = entity.get("source_path")
        if not name or not source_path:
            continue
        if not _SAFE_IDENT.match(str(name)):
            continue

        resolved = _resolve_entity_source(str(source_path), metadata_dir)
        if resolved is None:
            continue

        esc_path = str(resolved).replace("'", "''")
        try:
            con.execute(
                f"CREATE OR REPLACE VIEW {name} AS "
                f"SELECT * FROM read_csv_auto('{esc_path}')"
            )
            count += 1
        except Exception:
            continue

    return count


# ---------------------------------------------------------------------------
# Error classification
# ---------------------------------------------------------------------------


def normalized_entities(catalog: Dict[str, Any]) -> list:
    """Every entity in the catalog, as a list of dicts, whichever shape it uses.

    TWO SHAPES ARE IN THE WILD and only one used to be read. The programmatic
    form is a LIST::

        entities:
          - name: rx_monthly
            database: commercial
            dimensions: [{name: month}, ...]
            measures:   [{name: total_nbrx, sql: "SUM(nbrx)"}]

    while the form people actually write - and the form an agent reads as
    prose through `catalog_reader` - is a MAPPING keyed by entity name, with
    `columns:`::

        entities:
          rx_monthly:
            description: ...
            columns:  {month: {type: date, description: ...}}
            measures: {total_nbrx: "SUM(nbrx)"}

    A mapping was rejected by `isinstance(entities, list)` and every
    programmatic consumer then behaved as though the catalog were EMPTY, with
    no error anywhere: `--list-entities` answered `[]`, `configure-agent`
    reported "No validatable sources in catalog (skipped)", and - the one that
    costs something - `augment_not_found_error` stopped adding `catalog_schema`
    and `did_you_mean`, which is the anti-hallucination net that lets an agent
    recover from a wrong column name in one round instead of five. The agent
    kept answering correctly because it reads the file as prose, so nothing
    looked wrong.

    Accepting both is the fix: the mapping is a legitimate way to write a
    catalog, and a reader that silently ignores half its input is worse than
    one that refuses it.
    """
    entities = catalog.get("entities")
    if isinstance(entities, list):
        return [e for e in entities if isinstance(e, dict)]
    if not isinstance(entities, dict):
        return []

    out = []
    for name, body in entities.items():
        if not isinstance(body, dict):
            continue
        entry = dict(body)
        entry.setdefault("name", name)
        # `columns:` (mapping or list) is the mapping form's `dimensions:`.
        if "dimensions" not in entry:
            cols = body.get("columns")
            if isinstance(cols, dict):
                entry["dimensions"] = [{"name": c} for c in cols]
            elif isinstance(cols, list):
                entry["dimensions"] = [
                    c if isinstance(c, dict) else {"name": c} for c in cols]
        m = entry.get("measures")
        if isinstance(m, dict):
            entry["measures"] = [{"name": k, "sql": v} for k, v in m.items()]
        out.append(entry)
    return out


def load_catalog_schema(db_name: str, metadata_dir: Path) -> Dict[str, Any]:
    """Return a compact schema map for every entity in `db_name` from catalog.yaml.

    Shape: {"entities": {<entity>: {"columns": [...], "measures": [...]}}}
    Returns empty dict when the catalog is absent or unreadable.

    Used to augment error responses so the LLM sees the full available schema
    when it hallucinates a column/table name — DuckDB's native 'Candidate
    bindings' list is capped at ~5 edit-distance nearest names and can miss
    the semantically-correct column.
    """
    try:
        import yaml  # type: ignore
    except ImportError:
        return {}
    catalog_path = metadata_dir / "catalog.yaml"
    if not catalog_path.exists():
        return {}
    try:
        with open(catalog_path, "r", encoding="utf-8") as f:
            catalog = yaml.safe_load(f) or {}
    except Exception:
        return {}
    entities = normalized_entities(catalog)
    out: Dict[str, Any] = {}
    for e in entities:
        if not isinstance(e, dict):
            continue
        # A catalog that names no database describes THE one it sits beside -
        # the single-database case, which is what the mapping form is usually
        # written for. Requiring the key there excluded every such entity.
        declared = e.get("database")
        if declared is not None and declared != db_name:
            continue
        name = e.get("name")
        if not name:
            continue
        cols = [str(d.get("name")) for d in (e.get("dimensions") or []) if isinstance(d, dict) and d.get("name")]
        measures = [str(m.get("name")) for m in (e.get("measures") or []) if isinstance(m, dict) and m.get("name")]
        out[name] = {"columns": cols, "measures": measures}
    return {"entities": out} if out else {}


def augment_coverage_hint(result: Dict[str, Any], sql: str, adapter) -> Dict[str, Any]:
    """Add `_coverage_hint` for sparse-data queries against contract_entities.

    When Quinn queries `contract_entities` with a `clause_type` filter but
    no vendor filter, we compute how many vendors are covered vs total and
    emit a hint telling her NOT to explore vectorfs if the clause is sparse
    — the absence IS the data.

    Only fires for successful queries against contract_entities where the
    user hasn't scoped to specific vendors. Adds zero cost (one tiny
    secondary COUNT query) when it doesn't apply.
    """
    if not result.get("success") or not result.get("rows"):
        return result
    sql_lower = sql.lower()
    if "contract_entities" not in sql_lower:
        return result
    # Detect clause_type filter — equality or IN
    if not re.search(r"clause_type\s*(=|in\s*\()", sql_lower):
        return result
    # Skip when SQL already scopes to specific vendors — hint isn't meaningful
    if re.search(r"\bvendor\s*(=|in\s*\()", sql_lower):
        return result
    # Count vendors in result
    vendors_covered = {
        r.get("vendor") for r in result["rows"]
        if isinstance(r, dict) and r.get("vendor")
    }
    if not vendors_covered:
        return result
    # Count total vendors in the table — one cheap query
    try:
        total_result = adapter.execute_select(
            "SELECT COUNT(DISTINCT vendor) AS n FROM contract_entities"
        )
        total_vendors = int(total_result["rows"][0]["n"]) if total_result.get("success") and total_result.get("rows") else None
    except Exception:
        total_vendors = None
    if not total_vendors or len(vendors_covered) >= total_vendors:
        return result
    # Extract clause_type literal(s) from SQL for the hint message
    ct_match = re.search(r"clause_type\s*(?:=|in)\s*[\('\"]([^\)'\"]+)", sql, re.IGNORECASE)
    clause_literal = ct_match.group(1).strip() if ct_match else "the queried clause_type"
    missing = total_vendors - len(vendors_covered)
    result["_coverage_hint"] = {
        "clause_type_queried": clause_literal,
        "vendors_covered": len(vendors_covered),
        "total_vendors_in_table": total_vendors,
        "note": (
            f"'{clause_literal}' is present for {len(vendors_covered)} of "
            f"{total_vendors} vendors in contract_entities. The other {missing} "
            f"vendors do NOT have this clause extracted — this IS the "
            f"authoritative data state, not a gap to fill from vectorfs. "
            f"Report the absence explicitly in your answer (e.g., 'X has no "
            f"Y clause'); do NOT run additional vectorfs greps trying to "
            f"hunt for the missing values. If the user needs commercial "
            f"totals for non-covered vendors, aggregate spend_cube.Payment "
            f"Amount via iof-query instead. "
            f"ENVELOPE SHAPE: do NOT build a multi-vendor pivot table in "
            f"data.rows with synthesized cells for the non-covered vendors "
            f"— the envelope validator rejects cells not verbatim in a "
            f"tool_result and retry will fail. For sparse-coverage "
            f"comparisons, emit data as EITHER the covered rows verbatim "
            f"(data.type=\"table\" with only the {len(vendors_covered)} "
            f"covered vendors) OR data=null, with the cross-vendor prose "
            f"comparison entirely in `insight`. Caveats[] names each "
            f"non-covered vendor and what model they use instead."
        ),
    }
    return result


def augment_not_found_error(result: Dict[str, Any], db_name: str, metadata_dir: Path) -> Dict[str, Any]:
    """If the query failed with a column/table-not-found error, add full catalog
    schema and a fuzzy 'did you mean' suggestion so the caller can recover in
    one round instead of iterating.
    """
    if result.get("success"):
        return result
    err = str(result.get("error", ""))
    etype = str(result.get("error_type", ""))
    is_binder = "Binder Error" in err or "binder error" in err.lower()
    is_not_found = etype in ("COLUMN_NOT_FOUND", "TABLE_NOT_FOUND") or is_binder
    if not is_not_found:
        return result
    schema = load_catalog_schema(db_name, metadata_dir)
    if not schema:
        return result
    result["catalog_schema"] = schema
    # Extract the offending name from DuckDB Binder Error message
    import re as _re
    m = _re.search(r'Referenced (?:column|table) ["\']([^"\']+)["\']', err)
    bad = m.group(1) if m else None
    if bad:
        import difflib as _difflib
        pool: List[str] = []
        for ent in (schema.get("entities") or {}).values():
            pool.extend(ent.get("columns") or [])
            pool.extend(ent.get("measures") or [])
            pool.extend([e for e in (schema.get("entities") or {}).keys()])
        uniq = list(dict.fromkeys(pool))  # dedupe, preserve order
        matches = _difflib.get_close_matches(bad, uniq, n=3, cutoff=0.4)
        if matches:
            result["did_you_mean"] = matches
    return result


def classify_error(message: str) -> str:
    """Classify a database error for actionable feedback."""
    msg = message.lower()
    # The column test runs FIRST. DuckDB's binder says `Referenced column
    # "x" not found in FROM clause`, which the table test also matches on
    # "not found" - so every column error was labelled TABLE_NOT_FOUND and
    # the column branch below was unreachable for DuckDB (found by walking
    # the structured-connectors guide, 2026-09-02).
    if "unknown column" in msg or ("column" in msg and "not found" in msg):
        return "COLUMN_NOT_FOUND"
    if "doesn't exist" in msg or "not found" in msg or "no such table" in msg:
        return "TABLE_NOT_FOUND"
    if "syntax error" in msg or "you have an error" in msg:
        return "SYNTAX_ERROR"
    if "group" in msg and ("not in" in msg or "not found" in msg):
        return "GROUP_BY_ERROR"
    if "ambiguous" in msg:
        return "AMBIGUOUS_COLUMN"
    if "timeout" in msg or "timed out" in msg:
        return "QUERY_TIMEOUT"
    if "access denied" in msg or "permission" in msg:
        return "PERMISSION_DENIED"
    if "connection" in msg and ("refused" in msg or "reset" in msg or "lost" in msg):
        return "CONNECTION_ERROR"
    return "UNKNOWN_ERROR"


# ---------------------------------------------------------------------------
# Database adapters
# ---------------------------------------------------------------------------

class DatabaseAdapter(ABC):
    """Abstract base for database adapters."""

    def __init__(self):
        self._connected = False

    @abstractmethod
    def connect(self) -> None:
        ...

    @abstractmethod
    def disconnect(self) -> None:
        ...

    @abstractmethod
    def execute_select(self, query: str) -> Dict[str, Any]:
        ...

    @abstractmethod
    def list_schemas(self) -> Dict[str, Any]:
        """Return tables and their columns for schema discovery."""
        ...


class MySQLAdapter(DatabaseAdapter):
    """MySQL adapter with lazy connection."""

    def __init__(self, host: str, user: str, password: str, database: str,
                 port: int = 3306, pool_size: int = 5):
        super().__init__()
        self.config = dict(host=host, user=user, password=password,
                           database=database, port=port)
        self.pool_size = pool_size
        self.pool = None
        self.connection = None

    def connect(self) -> None:
        if self._connected:
            return
        import mysql.connector
        from mysql.connector import pooling
        self.pool = pooling.MySQLConnectionPool(
            pool_name="data_analyst_pool",
            pool_size=self.pool_size,
            pool_reset_session=True,
            **self.config,
        )
        self.connection = self.pool.get_connection()
        self._connected = True

    def disconnect(self) -> None:
        if self.connection:
            self.connection.close()
            self.connection = None
        self._connected = False

    def execute_select(self, query: str) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description] if cursor.description else []
            cursor.close()
            return dict(success=True, rows=rows, row_count=len(rows),
                        columns=columns, database=self.config["database"])
        except Exception as e:
            return dict(success=False, error=str(e),
                        error_type=classify_error(str(e)),
                        rows=[], row_count=0, columns=[])

    def list_schemas(self) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(
                "SELECT table_name, column_name, data_type "
                "FROM information_schema.columns "
                "WHERE table_schema = DATABASE() "
                "ORDER BY table_name, ordinal_position"
            )
            rows = cursor.fetchall()
            cursor.close()
            tables = {}
            for row in rows:
                t = row["table_name"]
                if t not in tables:
                    tables[t] = []
                tables[t].append({"column": row["column_name"], "type": row["data_type"]})
            return dict(success=True, tables=tables, database=self.config["database"])
        except Exception as e:
            return dict(success=False, error=str(e), error_type=classify_error(str(e)), tables={})


class PostgresAdapter(DatabaseAdapter):
    """PostgreSQL adapter with lazy connection. Accepts a URL or individual params."""

    def __init__(self, url: Optional[str] = None, host: str = "", user: str = "",
                 password: str = "", database: str = "", port: int = 5432,
                 schema: str = ""):
        super().__init__()
        self.url = url
        self.schema = schema        # optional: SET search_path on connect
        self.config = dict(host=host, user=user, password=password,
                           database=database, port=port) if not url else {}
        self.connection = None

    def _open_connection(self):
        """Open the DB-API connection. The one seam a wire-compatible
        subclass (Redshift) overrides; everything above it is shared."""
        import psycopg2
        if self.url:
            return psycopg2.connect(self.url)
        return psycopg2.connect(**self.config)

    def connect(self) -> None:
        if self._connected:
            return
        self.connection = self._open_connection()
        self.connection.autocommit = True
        if self.schema:
            # The name reaches us from databases.yml (so, from the environment)
            # and search_path takes no bind parameter. Quoting alone is not
            # enough — an embedded double quote would close the identifier and
            # let the rest run as SQL — so validate before interpolating.
            if not _IDENT_RE.match(self.schema):
                _fail(
                    f"schema {self.schema!r} is not a valid SQL identifier "
                    "(letters, digits and underscore only, not starting with a digit)"
                )
            # Explicit close rather than a `with` block: redshift_connector's
            # cursor is DB-API 2 but not every driver's cursor is a context
            # manager, and this path is shared with the Redshift subclass.
            _c = self.connection.cursor()
            try:
                _c.execute('SET search_path TO "%s", public' % self.schema)
            finally:
                _c.close()
        self._connected = True

    @property
    def listed_schema(self) -> str:
        """The schema `--list-schemas` describes: the configured one, else public."""
        return self.schema or "public"

    def disconnect(self) -> None:
        if self.connection:
            self.connection.close()
            self.connection = None
        self._connected = False

    def execute_select(self, query: str) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        try:
            cursor = self.connection.cursor()
            cursor.execute(query)
            columns = [d[0] for d in cursor.description] if cursor.description else []
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            cursor.close()
            db_name = self.config.get("database", "") if self.config else "postgres"
            return dict(success=True, rows=rows, row_count=len(rows),
                        columns=columns, database=db_name)
        except Exception as e:
            # Rollback to clear the failed transaction state
            if self.connection:
                self.connection.rollback()
            return dict(success=False, error=str(e),
                        error_type=classify_error(str(e)),
                        rows=[], row_count=0, columns=[])

    def list_schemas(self) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        # THE SCHEMA LISTED IS THE SCHEMA CONFIGURED. This used to hardcode
        # `table_schema = 'public'`, so a databases.yml saying `schema:
        # analytics` connected with search_path on analytics, queried
        # analytics, and then DESCRIBED public - an empty listing for a
        # warehouse whose every table lives in the configured schema. The
        # answer names the schema it describes so a reader can tell.
        schema = self.listed_schema
        try:
            cursor = self.connection.cursor()
            cursor.execute(
                "SELECT table_name, column_name, data_type "
                "FROM information_schema.columns "
                "WHERE table_schema = %s "
                "ORDER BY table_name, ordinal_position",
                (schema,),
            )
            columns = [d[0] for d in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            cursor.close()
            tables = {}
            for row in rows:
                t = row["table_name"]
                if t not in tables:
                    tables[t] = []
                tables[t].append({"column": row["column_name"], "type": row["data_type"]})
            db_name = self.config.get("database", "") if self.config else "postgres"
            return dict(success=True, tables=tables, database=db_name, schema=schema)
        except Exception as e:
            if self.connection:
                self.connection.rollback()
            return dict(success=False, error=str(e), error_type=classify_error(str(e)),
                        tables={}, schema=schema)


# Redshift speaks the PostgreSQL wire protocol; these are the two drivers
# `type: redshift` can go through. psycopg2 is the default because it is
# already a hard dependency of the engine; redshift_connector is Amazon's own
# driver and is used only when databases.yml names it AND it is installed.
_REDSHIFT_DRIVERS = ("psycopg2", "redshift_connector")
_REDSHIFT_DEFAULT_PORT = 5439


def _url_with_default_sslmode(url: str, sslmode: str = "require") -> str:
    """Add `sslmode=<x>` to a libpq connection string that names none.

    Handles both forms psycopg2 accepts - a `postgresql://` URI and a
    `key=value` DSN. One that already carries an sslmode is returned
    byte-for-byte unchanged, so an operator's `verify-full` is never
    downgraded and nothing else in the string is re-encoded.
    """
    if "://" in url:
        from urllib.parse import parse_qsl, urlsplit
        parts = urlsplit(url)
        if any(k.lower() == "sslmode" for k, _ in parse_qsl(parts.query, keep_blank_values=True)):
            return url
        return url + ("&" if parts.query else "?") + f"sslmode={sslmode}"
    if re.search(r"(^|\s)sslmode\s*=", url):
        return url
    return url.rstrip() + f" sslmode={sslmode}"


def _split_pg_url(url: str) -> Dict[str, Any]:
    """Break a `postgresql://` URI into DB-API keyword arguments.

    Only the redshift_connector path needs this: unlike psycopg2 it takes no
    connection string. Query parameters ride along as extra keys.
    """
    from urllib.parse import parse_qsl, unquote, urlsplit
    parts = urlsplit(url)
    kw: Dict[str, Any] = {
        "host": parts.hostname or "",
        "port": parts.port or _REDSHIFT_DEFAULT_PORT,
        "database": unquote(parts.path.lstrip("/")),
        "user": unquote(parts.username or ""),
        "password": unquote(parts.password or ""),
    }
    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        kw[key.lower()] = value
    return kw


class RedshiftAdapter(PostgresAdapter):
    """Amazon Redshift, over the PostgreSQL wire protocol.

    Redshift is Postgres on the wire, so the SELECT-only guard, the LIMIT
    rule, `SET search_path` and the information_schema listing are inherited
    unchanged. What is Redshift-specific:

    * **TLS is on by default.** A Redshift cluster refuses a plaintext
      connection unless its `require_SSL` parameter was turned off, and
      libpq's own default (`prefer`) does not ask for one, so a URL or a
      discrete config that names no `sslmode` gets `sslmode=require`. One
      that names any sslmode - `verify-full`, or `disable` for a cluster
      that allows it - is left exactly as written.
    * **Port 5439**, not 5432, when the discrete keys omit `port`.
    * **`driver:`** selects the DB-API driver: `psycopg2` (default; already
      installed with the engine) or `redshift_connector` (Amazon's driver,
      installed separately). Either takes a `url:` or the discrete
      `host/port/database/user/password` keys, with `${VAR}` references
      resolved by `load_database_configs` like every other type.
    """

    def __init__(self, url: Optional[str] = None, host: str = "", user: str = "",
                 password: str = "", database: str = "",
                 port: int = _REDSHIFT_DEFAULT_PORT, schema: str = "",
                 sslmode: str = "", driver: str = "psycopg2"):
        super().__init__(url=url, host=host, user=user, password=password,
                         database=database, port=port, schema=schema)
        self.driver = (driver or "psycopg2").lower()
        if self.url:
            self.url = _url_with_default_sslmode(self.url, sslmode or "require")
        else:
            self.config["sslmode"] = sslmode or "require"

    def _open_connection(self):
        if self.driver == "psycopg2":
            return super()._open_connection()
        if self.driver != "redshift_connector":
            _fail(f"Unknown driver '{self.driver}' for redshift. "
                  f"Supported: {', '.join(_REDSHIFT_DRIVERS)}")
        import redshift_connector
        kw = _split_pg_url(self.url) if self.url else dict(self.config)
        # libpq's sslmode vocabulary maps onto redshift_connector's two knobs:
        # `ssl` (on/off) and `sslmode` (`verify-ca` | `verify-full`, its only
        # two values - there is no unverified-TLS mode, so `require`,
        # `prefer` and `allow` all become verified TLS, never plaintext).
        mode = str(kw.pop("sslmode", "require")).lower()
        if mode == "disable":
            kw["ssl"] = False
        else:
            kw["ssl"] = True
            kw["sslmode"] = "verify-full" if mode == "verify-full" else "verify-ca"
        kw["port"] = int(kw.get("port") or _REDSHIFT_DEFAULT_PORT)
        return redshift_connector.connect(**kw)

    def execute_select(self, query: str) -> Dict[str, Any]:
        result = super().execute_select(query)
        if result.get("database") == "postgres":
            result["database"] = "redshift"
        return result

    def list_schemas(self) -> Dict[str, Any]:
        result = super().list_schemas()
        if result.get("database") == "postgres":
            result["database"] = "redshift"
        return result


class DuckDBAdapter(DatabaseAdapter):
    """DuckDB adapter for querying Parquet, CSV, and file-based data sources.

    Supports in-memory queries, persistent .duckdb files, and S3/local file reads
    via read_parquet(), read_csv(), read_json() in SQL.
    """

    def __init__(self, path: str = ":memory:", s3_region: str = "",
                 s3_endpoint: str = ""):
        super().__init__()
        self.path = path
        self.s3_region = s3_region
        self.s3_endpoint = s3_endpoint
        self.connection = None

    def connect(self) -> None:
        if self._connected:
            return
        import duckdb
        self.connection = duckdb.connect(self.path)
        # S3 credentials come from env (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
        # — DuckDB reads them automatically. We only configure region/endpoint.
        if self.s3_region:
            self.connection.execute(f"SET s3_region='{self.s3_region}'")
        if self.s3_endpoint:
            self.connection.execute(f"SET s3_endpoint='{self.s3_endpoint}'")
        self._connected = True

    def disconnect(self) -> None:
        if self.connection:
            self.connection.close()
            self.connection = None
        self._connected = False

    def execute_select(self, query: str) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        try:
            result = self.connection.execute(query)
            columns = [d[0] for d in result.description] if result.description else []
            rows = [dict(zip(columns, row)) for row in result.fetchall()]
            return dict(success=True, rows=rows, row_count=len(rows),
                        columns=columns, database=self.path)
        except Exception as e:
            return dict(success=False, error=str(e),
                        error_type=classify_error(str(e)),
                        rows=[], row_count=0, columns=[])

    def list_schemas(self) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        try:
            result = self.connection.execute(
                "SELECT table_name, column_name, data_type "
                "FROM information_schema.columns "
                "ORDER BY table_name, ordinal_position"
            )
            columns = [d[0] for d in result.description]
            rows = [dict(zip(columns, row)) for row in result.fetchall()]
            tables = {}
            for row in rows:
                t = row["table_name"]
                if t not in tables:
                    tables[t] = []
                tables[t].append({"column": row["column_name"], "type": row["data_type"]})
            return dict(success=True, tables=tables, database=self.path)
        except Exception as e:
            return dict(success=False, error=str(e), error_type=classify_error(str(e)), tables={})


class SqliteAdapter(DatabaseAdapter):
    """SQLite adapter (stdlib, zero extra deps) for file-based operational stores.

    Opened in READ-ONLY URI mode: iof-query stays a pure read surface even at
    the file level — no write can slip through regardless of SQL validation.
    ``path`` comes from databases.yml (supports ${ENV_VAR} substitution);
    relative paths resolve against the process cwd.
    """

    def __init__(self, path: str):
        super().__init__()
        self.path = path
        self.connection = None

    def connect(self) -> None:
        if self._connected:
            return
        import sqlite3
        from pathlib import Path as _Path
        p = _Path(self.path).expanduser()
        if not p.is_file():
            raise FileNotFoundError(
                f"SQLite database not found: {p} (cwd: {_Path.cwd()})"
            )
        self.connection = sqlite3.connect(f"file:{p.as_posix()}?mode=ro", uri=True)
        self._connected = True

    def disconnect(self) -> None:
        if self.connection:
            self.connection.close()
            self.connection = None
        self._connected = False

    def execute_select(self, query: str) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        try:
            cursor = self.connection.execute(query)
            columns = [d[0] for d in cursor.description] if cursor.description else []
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return dict(success=True, rows=rows, row_count=len(rows),
                        columns=columns, database=self.path)
        except Exception as e:
            return dict(success=False, error=str(e),
                        error_type=classify_error(str(e)),
                        rows=[], row_count=0, columns=[])

    def list_schemas(self) -> Dict[str, Any]:
        if not self._connected:
            self.connect()
        try:
            cursor = self.connection.execute(
                "SELECT m.name AS table_name, p.name AS column_name, "
                "p.type AS data_type "
                "FROM sqlite_master m JOIN pragma_table_info(m.name) p "
                "WHERE m.type = 'table' AND m.name NOT LIKE 'sqlite_%' "
                "ORDER BY m.name, p.cid"
            )
            columns = [d[0] for d in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            tables = {}
            for row in rows:
                t = row["table_name"]
                if t not in tables:
                    tables[t] = []
                tables[t].append({"column": row["column_name"], "type": row["data_type"]})
            return dict(success=True, tables=tables, database=self.path)
        except Exception as e:
            return dict(success=False, error=str(e), error_type=classify_error(str(e)), tables={})


# ---------------------------------------------------------------------------
# Adapter factory
# ---------------------------------------------------------------------------

# The `type:` values databases.yml may declare, in the order the error names
# them. `postgresql` is accepted as a spelling of `postgres`.
SUPPORTED_DB_TYPES = ("mysql", "postgres", "redshift", "duckdb", "sqlite")


def create_adapter(db_name: str, configs: Dict[str, Dict[str, Any]]) -> DatabaseAdapter:
    """Create a database adapter from config."""
    cfg = configs.get(db_name)
    if cfg is None:
        _fail(f"Database '{db_name}' not found in databases.yml. "
              f"Available: {', '.join(sorted(configs.keys()))}")
    cfg = _Cfg(cfg)

    db_type = cfg.get("type", "").lower()

    if db_type == "mysql":
        try:
            import mysql.connector  # noqa: F401
        except ImportError:
            _fail("mysql-connector-python is required for MySQL: pip install mysql-connector-python")
        return MySQLAdapter(
            host=cfg["host"], user=cfg["user"], password=cfg["password"],
            database=cfg["database"], port=cfg.get("port", 3306),
            pool_size=cfg.get("pool_size", 5),
        )

    if db_type in ("postgres", "postgresql"):
        try:
            import psycopg2  # noqa: F401
        except ImportError:
            _fail("psycopg2 is required for PostgreSQL: pip install psycopg2-binary")
        if "url" in cfg:
            return PostgresAdapter(url=cfg["url"], schema=cfg.get("schema", ""))
        return PostgresAdapter(
            host=cfg["host"], user=cfg["user"], password=cfg["password"],
            database=cfg["database"], port=cfg.get("port", 5432),
            schema=cfg.get("schema", ""),
        )

    if db_type == "redshift":
        driver = str(cfg.get("driver") or "psycopg2").lower()
        if driver not in _REDSHIFT_DRIVERS:
            _fail(f"Unknown driver '{driver}' for redshift database '{db_name}'. "
                  f"Supported: {', '.join(_REDSHIFT_DRIVERS)} (omit `driver` for psycopg2)")
        if driver == "redshift_connector":
            try:
                import redshift_connector  # noqa: F401
            except ImportError:
                _fail(f"redshift_connector is required because databases.yml declares "
                      f"`driver: redshift_connector` for '{db_name}': "
                      f"pip install redshift_connector (or omit `driver` to use psycopg2)")
        else:
            try:
                import psycopg2  # noqa: F401
            except ImportError:
                _fail("psycopg2 is required for Redshift: pip install psycopg2-binary")
        common = dict(schema=cfg.get("schema", ""), sslmode=str(cfg.get("sslmode") or ""),
                      driver=driver)
        if "url" in cfg:
            return RedshiftAdapter(url=cfg["url"], **common)
        missing = [k for k in ("host", "user", "password", "database") if not cfg.get(k)]
        if missing:
            _fail(f"redshift database '{db_name}' needs a `url` or the keys "
                  f"host, user, password, database in databases.yml; missing: "
                  f"{', '.join(missing)} (supports ${{ENV_VAR}} substitution)")
        return RedshiftAdapter(
            host=cfg["host"], user=cfg["user"], password=cfg["password"],
            database=cfg["database"], port=cfg.get("port", _REDSHIFT_DEFAULT_PORT),
            **common,
        )

    if db_type == "duckdb":
        try:
            import duckdb  # noqa: F401
        except ImportError:
            _fail("duckdb is required: pip install duckdb")
        _p = cfg.get("path", ":memory:")
        if _p != ":memory:" and not Path(_p).exists():
            # A MISSING FILE IS A JSON ERROR, like every other failure here.
            # duckdb raises IOException from `connect`, which reached the
            # caller as an unhandled traceback on stdout - unparseable by the
            # agent that runs this, and alarming to a person.
            _fail(f"duckdb database '{db_name}' file not found: {_p}. "
                  f"The `path` in databases.yml is resolved beside the "
                  f"catalog, one level above it, then against the working "
                  f"directory; none of those exist.")
        return DuckDBAdapter(
            path=_p,
            s3_region=cfg.get("s3_region", ""),
            s3_endpoint=cfg.get("s3_endpoint", ""),
        )

    if db_type == "sqlite":
        path = cfg.get("path") or ""
        if not path:
            _fail(f"sqlite database '{db_name}' needs a 'path' in databases.yml "
                  "(supports ${ENV_VAR} substitution)")
        return SqliteAdapter(path=path)

    _fail(f"Unsupported database type '{db_type}' for '{db_name}'. "
          f"Supported: {', '.join(SUPPORTED_DB_TYPES)}")


# ---------------------------------------------------------------------------
# CLI helpers
# ---------------------------------------------------------------------------

def _fail(message: str):
    """Print error as JSON and exit."""
    print(json.dumps({"success": False, "error": message}))
    sys.exit(1)


def _output(data: dict):
    """Print result as JSON and exit with a code that matches the payload.

    THE EXIT CODE USED TO CONTRADICT THE PAYLOAD. This always exited 0, while
    `_fail` exits 1 — so the same class of failure reported `success: false`
    and 1 down one path and `success: false` and 0 down another. An unknown
    database name and a query refused by the row guard both exited 0.

    The agent is unaffected: it reads the JSON. What is affected is anything
    checking the process — a `type: exec` workflow step, a shell pipeline, a
    health script — for which a failed query looked like a successful one.
    """
    print(json.dumps(data, cls=ResultEncoder))
    sys.exit(0 if data.get("success", True) else 1)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Execute validated SELECT queries against configured databases.",
    )
    # Per-deployment flag hiding: if `<metadata-dir>/.no_discovery` exists,
    # the --list-databases and --list-entities flags are not registered
    # (and the CLI will reject them as "unrecognized arguments"). Used by
    # Quinn (queryngine) where the catalog is embedded in the agent's system
    # prompt, so discovery-via-CLI is redundant and wastes an LLM round per
    # call. Other agents (analyst, data_analyst, edi_*) leave the marker
    # absent and keep the flags.
    def _discovery_disabled() -> bool:
        try:
            if "--metadata-dir" in sys.argv:
                i = sys.argv.index("--metadata-dir")
                mdir = Path(sys.argv[i + 1])
                return (mdir / ".no_discovery").exists()
        except (ValueError, IndexError, OSError):
            pass
        return False

    _hide_discovery = _discovery_disabled()

    parser.add_argument("--db", help="Database name from databases.yml")
    parser.add_argument("--sql", help="SQL SELECT query to execute")
    parser.add_argument("--sql-file", help="Read SQL from a file instead of --sql")
    parser.add_argument("--scratch", default=None,
                        help="Per-session scratch directory (tool-call budget, render-guidance "
                             "marker). With --sql-file it defaults to that file's directory; "
                             "with an inline --sql, pass it so the budget still applies.")
    parser.add_argument("--sql-stdin", action="store_true",
                        help="Read SQL from stdin (use with heredoc or pipe; avoids shell-quoting of identifiers)")
    parser.add_argument("--metadata-dir", required=True,
                        help="Path to metadata directory containing databases.yml")
    parser.add_argument("--limit", type=int, default=200,
                        help="Default LIMIT to add if missing (default: 200)")
    if not _hide_discovery:
        parser.add_argument("--list-databases", action="store_true",
                            help="List available databases and exit")
    parser.add_argument("--list-schemas", action="store_true",
                        help="List tables and columns for a database and exit")
    if not _hide_discovery:
        parser.add_argument("--list-entities", action="store_true",
                            help="List catalog entities with row counts and query mode (raw_ok / aggregate_only)")
    parser.add_argument("--max-rows", type=int, default=50,
                        help="Max rows before the query is rejected with a suggestion "
                             "to use GROUP BY (default: 50). Set to 0 to disable.")
    parser.add_argument("--env-file", default=None,
                        help="Path to .env file for credentials (default: .env in cwd)")
    args = parser.parse_args()

    # Per-session tool-call budget check. Orchestrator (adhoc_chat) writes
    # <scratch>/tool_budget.json with {used, limit}. <scratch> is `--scratch`
    # when given, else the --sql-file's directory (the pre-2026-09 shape, when
    # every query went through a file). An inline `--sql` with no `--scratch`
    # is outside the budget - which is why the injected prompt names both.
    # If the budget is exhausted, emit an explicit refusal marker and exit
    # without running the query. See vectorfs --scratch for the parallel
    # mechanism.
    _scratch = (Path(args.scratch).resolve() if args.scratch
                else Path(args.sql_file).resolve().parent if args.sql_file else None)
    if _scratch is not None:
        try:
            scratch_dir = _scratch
            budget_path = scratch_dir / "tool_budget.json"
            if budget_path.is_file():
                with open(budget_path, "r", encoding="utf-8") as _bf:
                    _bdata = json.load(_bf)
                _used = int(_bdata.get("used", 0))
                _limit = int(_bdata.get("limit", 10**9))
                if _used >= _limit:
                    print(
                        "(orchestrator: tool-call budget exhausted for this "
                        "request - no more iof-query or vectorfs calls will "
                        "be honored. Compose the envelope now with data you "
                        "already have; add a caveat about incomplete coverage.)"
                    )
                    sys.exit(0)
        except Exception:
            # Fail-open on any budget-file parse error — orchestrator absence
            # or file-format drift shouldn't break the tool.
            pass

    # Load .env for credential resolution (${ENV_VAR} in databases.yml)
    # Auto-searches: explicit --env-file > metadata-dir parent > metadata-dir > cwd
    try:
        from dotenv import load_dotenv
        if args.env_file:
            load_dotenv(args.env_file, override=False)
        else:
            metadata_path = Path(args.metadata_dir).resolve()
            # A domain pack may declare its own config home via a top-level
            # `env_file:` in databases.yml (e.g. ~/.barrier_signal/.env). Core
            # stays domain-agnostic — it honors whatever path the domain names.
            # This matters because iobot strips the exec'd subprocess env, so
            # unqualified env vars don't propagate to agent-invoked tools.
            domain_env = None
            try:
                import yaml as _yaml
                _raw = _yaml.safe_load((metadata_path / "databases.yml").read_text(encoding="utf-8"))
                if isinstance(_raw, dict) and _raw.get("env_file"):
                    domain_env = Path(str(_raw["env_file"])).expanduser()
            except Exception:
                pass
            # The workspace's own file. `IOF_WORKSPACE` is in
            # PASSTHROUGH_ENV_KEYS, so it is one of the few things that
            # survives the exec strip - which is exactly how `iof-consult`
            # finds this file, and this tool did not.
            workspace_env = None
            try:
                _ws = (os.environ.get("IOF_WORKSPACE") or "").strip()
                if _ws:
                    from ioagentfarm.engine.workspace_env import (
                        workspace_env_path as _ws_env_path)
                    workspace_env = _ws_env_path(_ws)
            except Exception:
                pass
            from ioagentfarm.engine.home_env import (
                home_env_candidates as _home_env_candidates)
            # THE WORKSPACE OUTRANKS THE DOMAIN HOME, and that ordering is the
            # point rather than an accident. `env_file:` in databases.yml names
            # a MACHINE-WIDE path (`~/.barrier_signal/.env`) shared by every
            # workspace, every checkout and every tenant on the host; the
            # workspace file belongs to one deployment. Letting the shared file
            # win is the precise failure this repo already removed once, when
            # three ambient `.env` files were dropped from the CLI's load path
            # because one of them fed a production database URL to commands run
            # in a scratch directory.
            #
            # Observed here: the domain home carried a stale
            # `BARRIER_SIGNAL_DB_URL` pointing at a local SQLite hub, so a
            # workflow declaring `type: postgres` handed psycopg2 a Windows
            # file path. The tenant's own file had the right URL and could not
            # be heard. The domain home keeps its real job - supplying what the
            # workspace does not declare - which is what makes a pack usable
            # with no per-workspace setup at all.
            candidates = [
                workspace_env,                    # ~/.iobot/workspaces/<code>/.env - this deployment
                domain_env,                       # domain-declared config home (databases.yml env_file)
                metadata_path.parent / ".env",    # project root (parent of metadata/)
                metadata_path / ".env",           # inside metadata dir
                Path.cwd() / ".env",              # current working directory
                # ~/.iobot/.env, legacy ~/.env, then the pod's /app/.env
                *_home_env_candidates(),
            ]
            # EVERY candidate, not the first one that exists. These are
            # different TIERS, not the same file at different depths, so
            # stopping at the first means a tier that defines SOME of the
            # keys silently prevents any other tier from supplying the rest.
            # That is not hypothetical: a domain declaring
            # `env_file: ~/.barrier_signal/.env` which carried
            # BARRIER_SIGNAL_DB_URL but not BARRIER_SIGNAL_DB_SCHEMA made
            # `schema: ${BARRIER_SIGNAL_DB_SCHEMA}` resolve to empty on every
            # agent query, and no other file could ever fill it in. The agent
            # then reported that the hub "requires credentials", which reads
            # as a broken deployment rather than one missing key.
            #
            # `override=False` keeps precedence intact: the first file to
            # define a KEY still wins, so the domain home remains
            # authoritative for everything it actually declares. This is the
            # same layering `iof_store` and `iof_api` already do - this tool
            # was the one that broke out of the loop.
            for candidate in candidates:
                if candidate and candidate.is_file():
                    load_dotenv(str(candidate), override=False)
    except ImportError:
        pass  # dotenv not required if env vars are already set

    # Load database configs
    configs = load_database_configs(args.metadata_dir)

    # --list-databases mode (flag may be hidden when .no_discovery marker present)
    if getattr(args, "list_databases", False):
        db_list = {}
        for name, cfg in configs.items():
            unset = _first_required_unset(cfg)
            if unset is not None:
                unset.fail()
            info = {"type": cfg.get("type", "unknown")}
            if "url" in cfg:
                info["connection"] = "url"
            else:
                info["host"] = cfg.get("host", "")
                info["database"] = cfg.get("database", "")
            db_list[name] = info
        _output({"success": True, "databases": db_list})

    # --list-entities mode (flag may be hidden when .no_discovery marker present)
    if getattr(args, "list_entities", False):
        if not args.db:
            _fail("--db is required with --list-entities")
        adapter = create_adapter(args.db, configs)
        try:
            _register_views_if_duckdb(adapter, args.db, args.metadata_dir)
            if not isinstance(adapter, DuckDBAdapter):
                _fail("--list-entities is only supported for DuckDB databases with catalog.yaml")
            adapter.connect()
            # Read catalog to get entity names + semantics
            import yaml
            catalog_path = Path(args.metadata_dir) / "catalog.yaml"
            if not catalog_path.exists():
                _fail(f"No catalog.yaml found at {catalog_path}")
            catalog = yaml.safe_load(catalog_path.read_text(encoding="utf-8")) or {}
            entities_out = []
            max_rows = args.max_rows if args.max_rows > 0 else 50
            for entity in normalized_entities(catalog):
                # A catalog that names no database describes the one it sits
                # beside. Requiring the key here made `--list-entities` answer
                # `[]` for a catalog full of entities, with `success: true`.
                declared = entity.get("database")
                if declared is not None and declared != args.db:
                    continue
                name = entity.get("name", "")
                try:
                    result = adapter.connection.execute(f"SELECT COUNT(*) AS n FROM {name}")
                    row_count = result.fetchone()[0]
                except Exception:
                    row_count = -1
                query_mode = "aggregate_only" if row_count > max_rows else "raw_ok"
                entities_out.append({
                    "name": name,
                    "rows": row_count,
                    "query_mode": query_mode,
                    "semantic": (entity.get("semantic") or "")[:120],
                    "grain": entity.get("grain", ""),
                })
            _output({"success": True, "database": args.db, "entities": entities_out,
                     "row_limit": max_rows,
                     "note": "aggregate_only entities MUST use GROUP BY / COUNT / AVG. "
                             "Raw SELECT * will be rejected by the row guard."})
        finally:
            adapter.disconnect()

    # --list-schemas mode
    if args.list_schemas:
        if not args.db:
            _fail("--db is required with --list-schemas")
        adapter = create_adapter(args.db, configs)
        try:
            _register_views_if_duckdb(adapter, args.db, args.metadata_dir)
            _output(adapter.list_schemas())
        finally:
            adapter.disconnect()

    # Validate required args for query execution
    if not args.db:
        _fail("--db is required (database name from databases.yml)")

    # Get SQL from --sql, --sql-file, or --sql-stdin
    sql = args.sql
    if args.sql_file:
        sql_path = Path(args.sql_file)
        if not sql_path.exists():
            _fail(f"SQL file not found: {args.sql_file}")
        sql = sql_path.read_text(encoding="utf-8").strip()
    elif args.sql_stdin:
        sql = sys.stdin.read().strip()

    if not sql:
        _fail("--sql, --sql-file, or --sql-stdin is required")

    # Validate query safety
    is_valid, error_msg = validate_select_query(sql)
    if not is_valid:
        _fail(error_msg)

    # Add LIMIT if missing
    sql = add_limit_if_missing(sql, args.limit)

    # Create adapter and execute
    adapter = create_adapter(args.db, configs)
    try:
        _register_views_if_duckdb(adapter, args.db, args.metadata_dir)
        result = adapter.execute_select(sql)

        # Augment not-found errors with full catalog schema + fuzzy suggestions
        # so the LLM can recover in one round instead of iterating via
        # distinct-value discovery queries (see issue: MiniMax hallucinated
        # "Category" -> 7 rounds of recovery because DuckDB's Candidate
        # Bindings list is capped at ~5 edit-distance nearest names).
        result = augment_not_found_error(result, args.db, Path(args.metadata_dir))

        # Coverage hint for sparse-data queries on contract_entities. When
        # Quinn queries a clause_type that only exists for some vendors, the
        # tool output tells her explicitly so she doesn't spiral into vectorfs
        # trying to fill the gap. Authoritative absence is data, not a gap.
        # See docs/forensics.md X7 failure pattern.
        result = augment_coverage_hint(result, sql, adapter)

        # Row guard: reject large result sets that would bloat the LLM session.
        # Agents should use GROUP BY on patient-level entities, not SELECT *.
        max_rows = args.max_rows
        if max_rows > 0 and result.get("success") and result.get("row_count", 0) > max_rows:
            _output({
                "success": False,
                "error": (
                    f"Query returned {result['row_count']} rows (limit: {max_rows}). "
                    f"Use GROUP BY, COUNT, AVG, or SUM to aggregate. "
                    f"Raw patient-level dumps bloat the LLM session context and "
                    f"cause provider stream stalls. "
                    f"Override with --max-rows 0 if you genuinely need all rows."
                ),
                "error_type": "ROW_LIMIT_EXCEEDED",
                "row_count": result["row_count"],
                "limit": max_rows,
                "columns": result.get("columns", []),
            })

        # Render guidance: emit ONCE per session (marker in scratch dir) only
        # when we return structured rows that could tempt a pivot. Prevents
        # the composer-pivot failure mode where Quinn builds a derived
        # comparison table in data.rows that the envelope validator rejects
        # as fabrication (cells don't match tool_result verbatim). Putting
        # the guidance in tool output beats a skill rule — Quinn sees it
        # inline at the moment of decision.
        if (_scratch is not None and result.get("success")
                and result.get("row_count", 0) > 0):
            try:
                scratch_dir = _scratch
                marker = scratch_dir / ".render_guidance_seen"
                if not marker.exists():
                    result["_render_guidance"] = (
                        "Emit these rows in data.rows with the column names shown and cell values verbatim — "
                        "no reformatting, no pivoting, no currency-formatting ($3.5M), no composed date ranges, "
                        "no concatenations. For side-by-side comparisons, pivot tables, or formatted values, "
                        "use the `insight` field (prose), not data.rows. The envelope validator will reject any "
                        "cell in data.rows that does not appear verbatim in the raw rows above. "
                        "This guidance is shown once per session."
                    )
                    marker.touch()
            except Exception:
                pass

        _output(result)
    finally:
        adapter.disconnect()


def _register_views_if_duckdb(adapter, db_name: str, metadata_dir: str) -> None:
    """Best-effort entity view registration for DuckDB adapters only.

    Silent on any error — procurement's raw read_csv() SQL stays functional
    whether or not catalog.yaml exists or views registered successfully.
    """
    if not isinstance(adapter, DuckDBAdapter):
        return
    try:
        adapter.connect()
        register_catalog_views(adapter.connection, db_name, Path(metadata_dir))
    except Exception:
        pass


if __name__ == "__main__":
    main()
