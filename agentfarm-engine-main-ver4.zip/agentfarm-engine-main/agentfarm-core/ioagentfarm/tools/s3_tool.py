#!/usr/bin/env python3
"""iof-s3 — S3 file access for ioagentfarm agents.

Downloads are saved to the run's project/input/ directory.
Credentials are resolved via boto3 default chain (env vars, IAM role, ~/.aws/).

Usage:
    iof-s3 list     --bucket <name> --prefix <path/>
    iof-s3 download --bucket <name> --key <full-key>
    iof-s3 download --bucket <name> --prefix <path/>
    iof-s3 upload   --bucket <name> --key <full-key> --file <local-path>
"""

import argparse
import json
import os
import sys
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()  # CWD (workspace)
    _app_env = Path("/app/.env")
    if _app_env.exists():
        load_dotenv(_app_env, override=False)
except ImportError:
    pass


def _s3_client():
    """Create S3 client using boto3 default credential chain."""
    import boto3

    kwargs = {}
    region = os.getenv("IOF_S3_REGION") or os.getenv("AWS_DEFAULT_REGION")
    endpoint = os.getenv("IOF_S3_ENDPOINT")
    if region:
        kwargs["region_name"] = region
    if endpoint:
        kwargs["endpoint_url"] = endpoint
    return boto3.client("s3", **kwargs)


def _resolve_input_dir() -> Path:
    """Resolve the project/input directory for downloads.

    Checks (in order):
    1. IOBOT_WORKSPACE/input/ (agent's working directory)
    2. IOF_OUTPUT_DIR/input/ (run-scoped output dir)
    3. ./input/ (fallback to cwd)
    """
    # Prefer IOBOT_WORKSPACE (set by _invoke_agent to the run's output dir)
    ws = os.getenv("IOBOT_WORKSPACE", "")
    if ws and Path(ws).is_dir():
        input_dir = Path(ws) / "input"
        input_dir.mkdir(parents=True, exist_ok=True)
        return input_dir

    # Fallback to cwd/input
    input_dir = Path.cwd() / "input"
    input_dir.mkdir(parents=True, exist_ok=True)
    return input_dir


def cmd_list(args):
    """List files in an S3 prefix."""
    s3 = _s3_client()
    prefix = args.prefix or ""
    if prefix and not prefix.endswith("/"):
        prefix += "/"

    files = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=args.bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                files.append({
                    "key": obj["Key"],
                    "size": obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                })
    except Exception as exc:
        print(json.dumps({"error": str(exc), "bucket": args.bucket, "prefix": prefix}))
        sys.exit(1)

    print(json.dumps({"bucket": args.bucket, "prefix": prefix, "count": len(files), "files": files}, indent=2))


def cmd_download(args):
    """Download file(s) from S3 to project/input/."""
    s3 = _s3_client()
    input_dir = _resolve_input_dir()
    downloaded = []

    if args.key:
        # Single file download
        filename = Path(args.key).name
        dest = input_dir / filename
        try:
            s3.download_file(args.bucket, args.key, str(dest))
            size = dest.stat().st_size
            downloaded.append({"key": args.key, "file": filename, "saved_to": str(dest), "size": size})
        except Exception as exc:
            print(json.dumps({"error": str(exc), "key": args.key}))
            sys.exit(1)

    elif args.prefix:
        # Download all files under prefix
        prefix = args.prefix
        if not prefix.endswith("/"):
            prefix += "/"

        try:
            paginator = s3.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=args.bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    filename = Path(key).name
                    if not filename:
                        continue
                    dest = input_dir / filename
                    s3.download_file(args.bucket, key, str(dest))
                    size = dest.stat().st_size
                    downloaded.append({"key": key, "file": filename, "saved_to": str(dest), "size": size})
        except Exception as exc:
            print(json.dumps({"error": str(exc), "prefix": prefix}))
            sys.exit(1)
    else:
        print(json.dumps({"error": "Provide --key or --prefix"}))
        sys.exit(1)

    print(json.dumps({
        "downloaded": len(downloaded),
        "input_dir": str(input_dir),
        "files": downloaded,
    }, indent=2))


def cmd_upload(args):
    """Upload a local file to S3."""
    s3 = _s3_client()
    file_path = Path(args.file)

    if not file_path.exists():
        print(json.dumps({"error": f"File not found: {args.file}"}))
        sys.exit(1)

    try:
        extra = {}
        if args.content_type:
            extra["ContentType"] = args.content_type

        s3.upload_file(
            Filename=str(file_path),
            Bucket=args.bucket,
            Key=args.key,
            ExtraArgs=extra or None,
        )
        size = file_path.stat().st_size
        print(json.dumps({
            "uploaded":     True,
            "bucket":       args.bucket,
            "key":          args.key,
            "size":         size,
            "content_type": args.content_type,
        }))
    except Exception as exc:
        print(json.dumps({"error": str(exc), "bucket": args.bucket, "key": args.key}))
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(prog="iof-s3", description="S3 file access for ioagentfarm agents")
    sub = parser.add_subparsers(dest="command")

    # list
    p_list = sub.add_parser("list", help="List files in S3")
    p_list.add_argument("--bucket", required=True, help="S3 bucket name")
    p_list.add_argument("--prefix", default="", help="S3 key prefix (folder path)")

    # download
    p_dl = sub.add_parser("download", help="Download file(s) from S3")
    p_dl.add_argument("--bucket", required=True, help="S3 bucket name")
    p_dl.add_argument("--key", help="Full S3 key to download (single file)")
    p_dl.add_argument("--prefix", help="S3 prefix to download (all files under path)")

    # upload
    p_ul = sub.add_parser("upload", help="Upload a local file to S3")
    p_ul.add_argument("--bucket",       required=True, help="S3 bucket name")
    p_ul.add_argument("--key",          required=True, help="Full S3 key (destination path)")
    p_ul.add_argument("--file",         required=True, help="Local file path to upload")
    p_ul.add_argument("--content-type", default="application/octet-stream",
                      help="MIME content-type (default: application/octet-stream)")

    args = parser.parse_args()

    if args.command == "list":
        cmd_list(args)
    elif args.command == "download":
        cmd_download(args)
    elif args.command == "upload":
        cmd_upload(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
