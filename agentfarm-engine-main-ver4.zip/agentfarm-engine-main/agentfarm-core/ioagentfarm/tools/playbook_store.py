"""iof-plays — the platform play catalog and HITL staging store.

The meta-agent database: business-owned playbooks (goal + policy + body,
authored in business language, human-approved to 'operational') and the
staging rows that implement a playbook's human-validation gate. Deterministic
by design — every decision this tool makes (matching, routing, gating) is
code, so playbook execution never depends on a model re-reading prose.

Commands (all read/write the ORCHESTRATION database — IOF_DATABASE_URL, else
sqlite under IOF_ROOT, the same resolution as iof-recall):

  seed-summary              insert/refresh the Intelligent Orchestration
                            Summary playbook (operational)
  seed-brand-campaign       insert/refresh the Brand Campaign Adjustment
                            playbook (operational)
  list [--json]             operational playbooks
  show <play_id>            one playbook, full body
  amend <play_id> --set K=V [--add-synonym S] [--remove-synonym S] [--as who]
                            value-level amendment (windows, roles, synonyms);
                            structure still travels through the compile path
  match --trigger "..."     deterministic trigger -> playbook match [--json];
                            a MISS is recorded (--no-record to probe silently)
  workflows [--json] [--out f] the workflows a playbook may commission, with
                            descriptions - the catalog the compiler is handed
  template [--json] [--out f] the AUTHORING template: what this workspace can
                            deliver, in business language, for a domain
                            expert to write a playbook into
  capability-requests [--json] [--all] [--resolve ID --as who]
                            what playbooks asked for that this workspace
                            cannot deliver yet - recorded at compile-stage
  unmatched [--json] [--limit N]
                            requests that matched no play, grouped by text:
                            what was asked for and not covered, which is the
                            input to the next playbook
  prep-brands --trigger-file f --out d    brand fan-out manifest (stories)
  stage --summary f --verdict f --trigger f --run-id id --out d
                            FAIL-CLOSED staging: refuses missing artifacts or
                            a non-compliant verdict; writes staging_receipt.json
                            and a hitl_pending row
  pending [--json]          stagings awaiting human validation
  approve <staging_id> --as reviewer      the ONLY path to 'approved'
  reject  <staging_id> --as reviewer --reason "..."
  route --goal "..." --out d              REFUSES unless approved; writes
                            routing.json with the persona->CRM decision
  mark-delivered --staging id --receipt r
  status [--json]           store overview (plays + staging counts)

Persona routing is a table here, not prose: FRM -> WithMe; OS, MSL, OCE, KAM,
PMAM, UBAM, TLL -> iConnect.
"""
from __future__ import annotations

import argparse
import difflib
import json
import os
import re
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from ioagentfarm.tools import plays_repo as _repo
from ioagentfarm.tools.casetier.store import (_rows, _run_session,  # noqa: F401
                                               session as _case_session)

PERSONA_CRM = {
    "FRM": "WithMe",
    "OS": "iConnect", "MSL": "iConnect", "OCE": "iConnect", "KAM": "iConnect",
    "PMAM": "iConnect", "UBAM": "iConnect", "TLL": "iConnect",
}

_STG_RE = re.compile(r"\bSTG-\d{4,}\b")


def _infer_root(*hints: str) -> Path | None:
    """Recover IOF_ROOT from an engine-templated path.

    Exec steps run with a stripped environment, so IOF_ROOT/IOF_DATABASE_URL
    may be absent — but every ``{{output_dir}}`` the engine hands a step lives
    under ``<IOF_ROOT>/instances/<run_id>/...``. Walking up from such a path to
    the parent of ``instances`` recovers the root deterministically, which
    keeps this tool writing the SAME database the engine reads (the stray
    ``.iof`` split-brain observed live on 2026-08-12).
    """
    for hint in hints:
        if not hint:
            continue
        p = Path(hint).resolve()
        for parent in (p, *p.parents):
            if parent.name == "instances" and parent.parent.name:
                return parent.parent
    return None


def _db_url(*hints: str) -> str:
    url = (os.environ.get("IOF_DATABASE_URL") or "").strip()
    if url:
        return url
    env_root = (os.environ.get("IOF_ROOT") or "").strip()
    root = Path(env_root).resolve() if env_root else (_infer_root(*hints)
                                                     or Path(".iof").resolve())
    root.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{root / 'state.db'}"


def _adapter(*hints: str):
    from ioagentfarm.engine.db import make_adapter
    return make_adapter(_db_url(*hints))


_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS meta_playbooks (
        play_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        trigger_type TEXT NOT NULL,
        goal TEXT NOT NULL,
        policy_json TEXT NOT NULL,
        body_md TEXT NOT NULL,
        workflow_generate TEXT NOT NULL,
        workflow_deliver TEXT,
        status TEXT NOT NULL,
        version INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS meta_stagings (
        staging_id TEXT PRIMARY KEY,
        play_id TEXT NOT NULL,
        run_id TEXT,
        account_id TEXT,
        persona TEXT,
        brands TEXT,
        summary_json TEXT NOT NULL,
        verdict_json TEXT NOT NULL,
        status TEXT NOT NULL,
        reviewer TEXT,
        reason TEXT,
        receipt TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS meta_compilations (
        compile_id TEXT PRIMARY KEY,
        template_id TEXT NOT NULL,
        play_id TEXT NOT NULL,
        source_md TEXT NOT NULL,
        rulebook_json TEXT NOT NULL,
        play_json TEXT NOT NULL,
        review_md TEXT NOT NULL,
        notes_md TEXT,
        run_id TEXT,
        status TEXT NOT NULL,
        reviewer TEXT,
        reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""",
    # A request that matched NO play. `match` used to answer with the known
    # triggers and forget the question - and the question is the single
    # best signal for which playbook to write next. `{auto_id}` is the
    # adapter's spelling of an auto-increment key (the case tier's lesson:
    # the SQLite literal is a syntax error on PostgreSQL).
    # What a playbook asked for that this workspace cannot deliver yet. The
    # author marks it in the text (CAPABILITY_MARKER), the compiler records
    # it, compile-stage refuses a draft that dropped a marked one, and the
    # list is the other half of "what to build next" beside unmatched.
    """CREATE TABLE IF NOT EXISTS meta_capability_requests (
        id {auto_id},
        workspace_code TEXT,
        compile_id TEXT NOT NULL,
        play_id TEXT NOT NULL,
        template_id TEXT,
        need TEXT NOT NULL,
        quoted TEXT,
        compiled_as TEXT,
        status TEXT NOT NULL,
        resolved_by TEXT,
        reason TEXT,
        created_at TEXT NOT NULL,
        resolved_at TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS meta_unmatched_requests (
        id {auto_id},
        workspace_code TEXT,
        trigger_text TEXT NOT NULL,
        known_triggers_json TEXT NOT NULL,
        requested_by TEXT,
        requested_at TEXT NOT NULL
    )""",
]


#: Additive tenancy columns for pre-v2 databases (see case_store's
#: _workspace for the semantics: unset env = unscoped, blank rows shared).
_ENSURE_COLUMNS = [
    ("meta_playbooks", "workspace_code", "TEXT"),
    ("meta_playbooks", "updated_by", "TEXT"),
    ("meta_compilations", "workspace_code", "TEXT"),
    ("meta_stagings", "workspace_code", "TEXT"),
]


#: Databases whose schema this process has already ensured (see the case
#: tier's `_ENSURED`): the DDL is idempotent but not free, and on Postgres
#: a bare failed ALTER used to poison the transaction for every statement
#: after it - proven on RDS 2026-08-25: `iof-plays status` died on its
#: first call.
_ENSURED: set[str] = set()


def reset_schema_memo() -> None:
    _ENSURED.clear()


def _connect(adapter):
    con = adapter.connect()
    adapter.init_connection(con)
    key = getattr(adapter, "_dsn", None) or getattr(adapter, "_path", None) \
        or repr(adapter)
    if str(key) in _ENSURED:
        return con
    _repo.ensure_schema(con.cursor(), adapter.placeholder(),
                        adapter.auto_id(), _SCHEMA, _ENSURE_COLUMNS)
    con.commit()
    _ENSURED.add(str(key))
    return con


@contextmanager
def session(*hints):
    """`with session(*hints) as s:` - the ONE way a command opens the play
    store. Same lifecycle as the case tier's (`casetier.store.session`):
    commit on a normal exit, rollback on an exception or after
    `s.discard()`, and the connection is always returned."""
    adapter = _adapter(*hints)
    with _run_session(adapter, _connect(adapter)) as s:
        yield s


def _workspace() -> str:
    from ioagentfarm.tools.case_store import _workspace as ws
    return ws()


def _scope_sql(ph: str, column: str = "workspace_code"):
    from ioagentfarm.tools.case_store import _scope_sql as scope
    return scope(ph, column)


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


#: Derived ids and the SAVEPOINT-guarded insert live in the repository
#: with the statements they run; these names stay for the tests that pin
#: the gap and collision behaviour.
_next_staging_id = _repo.next_staging_id
_next_compile_id = _repo.next_compile_id
_insert_with_fresh_id = _repo.insert_with_fresh_id


# ------------------------------------------------------------------ seeds

_SUMMARY_PLAY = {
    "play_id": "PLAY-SUMMARY-001",
    "name": "Intelligent Orchestration Summary",
    "trigger_type": "Get Super Summary",
    "goal": "Deliver a compliant, role-appropriate call summary to the "
            "aligned representative's CRM for the triggering account.",
    "policy": {
        "lookback_days": 90,
        "tool_retry_limit": 2,
        "compliance_regenerate_limit": 2,
        "manual_validation_required": True,
        "persona_crm_routing": PERSONA_CRM,
        "no_data_behavior": "stop the engagement and report the named reason; "
                            "no recommendations on failure",
    },
    "workflow_generate": "super_summary_generate",
    "workflow_deliver": "super_summary_deliver",
    "params_needed": ["account_id", "brands", "persona"],
    "body_md": """# Playbook: Intelligent Orchestration Summary

## Goal
Deliver a compliant, role-appropriate call summary to the aligned
representative's CRM for the triggering account.

## Trigger Information
Trigger Type: Intelligent Orchestration Summary
Detection Signal: Get Super Summary

## Operational Rules
- For every step, evaluate available tools and use the specified one in the flow.
- Steps should be followed in sequence.
- If any of the tool fails, then retry for 2 times only. If the issue still
  persists immediately stop the complete workflow and return it as a final
  response.
- Do not provide any recommendations or suggestions in case of tool failure.

## Resolution Workflow
1. Retrieve call summary details for the account with 90 days look back.
   If there is no call summary data available for that account, stop.
2. Retrieve account information for the full "and" separated brand.
3. Retrieve representative alignment details, each brand separately.
4. Role-based summarization with the appropriate prompt for the given role.
   If no summary is generated, stop.
5. Summary compliance check. If non-compliant, pass the critique back and
   regenerate; at most two times, then stop.
6. Store summary and pause the workflow for manual validation.
7. After validation: send the summary to the aligned representative in the
   CRM system. Persona FRM receives CRM summaries only in WithMe; other
   personas (OS, MSL, OCE, KAM, PMAM, UBAM, TLL) only in iConnect.
""",
}

_BRAND_PLAY = {
    "play_id": "PLAY-BRANDCAMP-001",
    "name": "Brand Campaign Adjustment",
    "trigger_type": "Campaign Underperformance",
    "goal": "Diagnose an underperforming brand campaign and publish an "
            "approved, brand-compliant adjustment.",
    "policy": {
        "tool_retry_limit": 2,
        "brand_compliance_required": True,
        "manual_validation_required": True,
        "diagnosis_is_judgement": True,
        "no_data_behavior": "stop the engagement and report the named reason",
    },
    "workflow_generate": "brand_campaign_adjust",
    "workflow_deliver": "brand_campaign_publish",
    "params_needed": ["campaign_id", "brand"],
    "body_md": """# Playbook: Brand Campaign Adjustment

## Goal
Diagnose an underperforming brand campaign and publish an approved,
brand-compliant adjustment.

## Trigger Information
Trigger Type: Campaign Underperformance
Detection Signal: campaign KPI below threshold for the reporting period

## Operational Rules
- Steps should be followed in sequence; tools retried at most twice.
- The diagnosis and the recommended adjustment are judgement — ground both in
  the retrieved metrics and market context, never in assumptions.
- No adjustment is published without brand-compliance approval AND marketing
  manager validation.

## Resolution Workflow
1. Retrieve campaign performance metrics for the campaign and period.
   If the campaign is unknown, stop with the named reason.
2. Retrieve market and competitor context for the brand.
3. Diagnose the underperformance and recommend one concrete adjustment
   (audience, message, channel or cadence), grounded in the data.
4. Check the recommended creative/message against brand compliance. If
   non-compliant, revise with the critique; at most two times, then stop.
5. Stage the adjustment and pause for marketing manager validation.
6. After validation: publish the campaign update to the execution channel.
""",
}


_PLAY_REQUIRED = ("play_id", "name", "trigger_type", "goal", "policy",
                  "params_needed", "body_md")


def validate_play(play: dict) -> list[str]:
    """Structural validation for a play document. A play is DATA — this is
    what stands between a typo and a live engagement, so everything the
    runtime will read must be present and coherent at put time."""
    errs: list[str] = []
    if not isinstance(play, dict):
        return ["play must be a JSON object"]
    for k in _PLAY_REQUIRED:
        if k not in play:
            errs.append(f"missing required key: {k}")
    if errs:
        return errs
    if not isinstance(play["policy"], dict):
        errs.append("policy must be an object")
        return errs
    if not isinstance(play["params_needed"], list):
        errs.append("params_needed must be a list")
    syn = play["policy"].get("trigger_synonyms", [])
    if not isinstance(syn, list) or any(not isinstance(s, str) or not s
                                        for s in syn):
        errs.append("policy.trigger_synonyms must be a list of non-empty "
                    "strings")
    species = play["policy"].get("species", "pipeline")
    if species == "case":
        if not play["policy"].get("template"):
            errs.append("a case-species play must name policy.template "
                        "(its rulebook family)")
        if not (play.get("workflow_generate")
                or play["policy"].get("workflow_action")):
            errs.append("a case-species play must name its action workflow "
                        "(workflow_generate or policy.workflow_action)")
    else:
        if not play.get("workflow_generate"):
            errs.append("a pipeline play must name workflow_generate")
    return errs


def _action_workflow(play: dict) -> str | None:
    """The workflow this play commissions, under either spelling.

    `validate_play` accepts a case play that names its action workflow in
    `policy.workflow_action` INSTEAD of top-level `workflow_generate`, and
    `_AMEND_RESERVED` protects that key — but the column is NOT NULL and
    nothing resolved the one spelling to the other, so the accepted branch
    validated clean and then died on an IntegrityError at insert. Resolve it
    here, where both writers pass.
    """
    direct = play.get("workflow_generate")
    if direct:
        return direct
    policy = play.get("policy")
    return policy.get("workflow_action") if isinstance(policy, dict) else None


def declared_workflows(workspace: str | None = None) -> dict[str, str]:
    """``~/.iobot/workspaces/<code>/workflows.yaml`` — workflows DECLARED by
    name and description, beside the workspace's ``deliveries.yaml`` and
    with the same philosophy: for a COMPILE-ONLY deployment that cannot
    install the workspace repo, the compiler maps against what the
    deployment declares, and a draft naming a declared workflow validates.
    Nothing here makes a workflow RUNNABLE — dispatch still needs the repo
    installed, which a compile demo never reaches.

    Shape: ``{name: description}`` (or ``{name: {description: ...}}``).
    Missing file = ``{}``; a malformed file raises — a deployment that
    tried to declare and failed must be refused, not read as silence.
    """
    code = workspace
    if not code:
        try:
            from ioagentfarm.engine.workspaces import maybe_workspace_code
            code = maybe_workspace_code()
        except Exception:       # noqa: BLE001 - no selection is fine here
            code = None
    if not code:
        return {}
    from ioagentfarm.engine.workspace_env import workspace_home
    path = workspace_home(code) / "workflows.yaml"
    if not path.is_file():
        return {}
    import yaml
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as e:      # noqa: BLE001
        raise ValueError(f"{path} is unreadable ({e})") from e
    if not isinstance(data, dict):
        raise ValueError(f"{path} must be a mapping of workflow name to "
                         f"description")
    out: dict[str, str] = {}
    for name, entry in data.items():
        if isinstance(entry, dict):
            out[str(name)] = str(entry.get("description") or "")
        else:
            out[str(name)] = str(entry or "")
    return out


def _resolvable_workflows_from_loader(workspace: str | None = None) -> set[str]:
    """Every workflow name a run could resolve here: the installed packs plus
    the workspace's own override tree, enumerated by the loader `run` uses,
    so this answers about the tree that would actually execute — UNION the
    workspace's DECLARED workflows (workflows.yaml), so a compile-only
    deployment without the repo still compiles and stages against its own
    declaration."""
    from ioagentfarm.engine.workflow_loader import resolvable_workflow_names
    names = set(resolvable_workflow_names(workspace))
    try:
        names |= set(declared_workflows(workspace))
    except ValueError:
        raise
    except Exception:           # noqa: BLE001 - declaration is optional
        pass
    return names


#: The seam tests pin. The meta suite names `case_action`, which ships in a
#: SOLUTION pack CI does not install; the suite pins the catalog it assumes
#: and the loader-backed resolver is covered on its own.
_resolvable_workflows = _resolvable_workflows_from_loader


def workflow_resolution_errors(play: dict,
                               workspace: str | None = None) -> list[str]:
    """Refuse a play whose workflow does not RESOLVE, not merely one that
    does not name it. `validate_play` checked presence only, so a play
    pointing at `no_such_workflow_anywhere` installed clean, reported
    operational, and failed at run time - after a case was open and
    somebody was waiting. The rulebook half of the same document was
    already held to the stronger standard (a missing `policy.template` is
    refused at put); the two halves now agree. Error style: name the
    workflows that DO resolve, with a near-match first."""
    # Name the key the author actually wrote: a case play may spell its
    # action workflow `policy.workflow_action`, and an error about a key
    # that is not in the document sends the reader to the wrong line.
    action_key = ("workflow_generate" if play.get("workflow_generate")
                  else "policy.workflow_action")
    wanted = [(k, v) for k, v in (
        (action_key, _action_workflow(play)),
        ("workflow_deliver", play.get("workflow_deliver"))) if v]
    if not wanted:
        return []
    try:
        known = _resolvable_workflows(workspace)
    except Exception as e:      # noqa: BLE001 - a broken install is refused, not skipped
        return [f"cannot enumerate the installed workflows "
                f"({type(e).__name__}: {e}) - nothing can be checked, so "
                f"nothing is saved"]
    errs: list[str] = []
    legal = ", ".join(sorted(known)) or "(none installed)"
    for key, name in wanted:
        if name in known:
            continue
        near = difflib.get_close_matches(name, sorted(known), n=3, cutoff=0.6)
        hint = (f" - did you mean {', '.join(repr(n) for n in near)}?"
                if near else "")
        errs.append(f"{key} {name!r} does not resolve to an installed "
                    f"workflow{hint}; workflows that do: {legal}")
    return errs


def _upsert_play(play: dict, status: str = "operational",
                 verb: str = "seeded") -> None:
    body = play["body_md"]
    policy = json.dumps({**play["policy"],
                         "params_needed": play["params_needed"]})
    with session() as s:
        row = _repo.play_version(s.cur, s.ph, play["play_id"])
        if row:
            version = int(row["version"]) + 1
            _repo.update_play(s.cur, s.ph, play["play_id"], play["name"],
                              play["trigger_type"], play["goal"], policy,
                              body, _action_workflow(play),
                              play.get("workflow_deliver"), status, version)
        else:
            version = 1
            _repo.insert_play(s.cur, s.ph, play["play_id"], play["name"],
                              play["trigger_type"], play["goal"], policy,
                              body, _action_workflow(play),
                              play.get("workflow_deliver"), status, version)
    print(f"{verb} {play['play_id']} ({play['name']}) v{version} "
          f"status={status}")


def cmd_put(args) -> int:
    """Create or amend a play from a JSON document — the whole playbook
    lifecycle as data. With hundreds of plays there is no per-play code:
    a new play is `rulebook put` (its transitions, when case-species) +
    `plays put` (its identity, trigger, policy, body), and it is live."""
    try:
        play = json.loads(Path(args.file).read_text(encoding="utf-8"))
    except Exception as e:
        print(f"ERROR: cannot read {args.file}: {e}", file=sys.stderr)
        return 1
    errs = validate_play(play)
    if not errs and play["policy"].get("species") == "case":
        # Fail-closed: a case play without its rulebook cannot run — the
        # rulebook goes in FIRST (`iof-case rulebook put`), then the play.
        template = play["policy"]["template"]
        with session() as s:
            try:
                if not _repo.rulebook_exists(s.cur, s.ph, template):
                    errs.append(
                        f"policy.template {template!r} has no rulebook — "
                        f"put the rulebook first: iof-case rulebook put "
                        f"--file <spec.json>")
            except Exception:
                s.discard()
                errs.append(
                    f"policy.template {template!r} has no rulebook (no "
                    f"meta_rulebooks table yet) — put the rulebook first: "
                    f"iof-case rulebook put --file <spec.json>")
    if not errs:
        errs += workflow_resolution_errors(play, _workspace())
    if errs:
        for e in errs:
            print(f"ERROR: {e}", file=sys.stderr)
        print("REFUSED: the play was not saved", file=sys.stderr)
        return 1
    _upsert_play(play, status=args.status, verb="saved")
    return 0


#: Keys `amend` refuses BY NAME: identity, structure and routing live in
#: the compile path (draft -> validate -> human approval), never in a
#: value edit. trigger_synonyms has its own flags so additions are
#: explicit, not a JSON splice.
_AMEND_RESERVED = ("species", "template", "workflow_action", "params_needed",
                   "trigger_synonyms", "persona_crm_routing")


def cmd_amend(args) -> int:
    """The small-amendment path: change a VALUE the play already owns — a
    window, a role name, a trigger synonym — without recompiling and
    without touching structure. The business tunes what the kpi heatmap
    told them; the ladder itself still travels through compile + human
    approval. Amendments apply to cases opened FROM NOW ON — in-flight
    cases keep the params frozen at their open (by design; see the
    effective-immediately item in the backlog)."""
    with session() as sess:
        row = _repo.play_for_amend(sess.cur, sess.ph, args.play_id)
        if not row:
            print(f"no playbook {args.play_id!r}", file=sys.stderr)
            return 1
        name, trigger_type, goal = row["name"], row["trigger_type"], row["goal"]
        body_md, version = row["body_md"], row["version"]
        wf_gen, wf_del = row["workflow_generate"], row["workflow_deliver"]
        policy = json.loads(row["policy_json"])
        # For a case play the template's default_params define which
        # absent keys may be introduced as overrides, and what TYPE each
        # one has.
        spec = None
        if policy.get("species") == "case" and policy.get("template"):
            from ioagentfarm.tools import case_store
            with _case_session() as cs:
                spec = case_store.load_rulebook(cs.cur, cs.ph,
                                                policy["template"])
        defaults = (spec or {}).get("default_params", {})
        role_params = set((spec or {}).get("role_params", ()))

        changes: list[str] = []
        for pair in (args.sets or []):
            k, sep, raw = pair.partition("=")
            k = k.strip()
            if not sep or not k:
                print(f"REFUSED: --set takes KEY=VALUE, got {pair!r}",
                      file=sys.stderr)
                return 1
            if k in _AMEND_RESERVED:
                print(f"REFUSED: {k!r} is identity/structure — it changes "
                      f"what the play IS, and that travels through the "
                      f"compile path and its human gate, never a value "
                      f"edit", file=sys.stderr)
                return 1
            # The TARGET decides the type: an existing policy value, else
            # the template default this key would override. A key neither
            # owns is refused — amend never introduces vocabulary.
            if k in policy:
                target = policy[k]
            elif k in defaults:
                target = defaults[k]
            else:
                known = sorted((set(policy) | set(defaults))
                               - set(_AMEND_RESERVED))
                print(f"REFUSED: {k!r} is not a key this play or its "
                      f"template declares. Amendable keys: "
                      f"{', '.join(known)}", file=sys.stderr)
                return 1
            if isinstance(target, (list, dict)):
                print(f"REFUSED: {k!r} holds a {type(target).__name__} — "
                      f"amend edits scalar values; structured changes "
                      f"travel through the compile path", file=sys.stderr)
                return 1
            raw = raw.strip()
            try:
                if isinstance(target, bool):
                    if raw.lower() not in ("true", "false"):
                        raise ValueError(raw)
                    value = raw.lower() == "true"
                elif isinstance(target, int):
                    value = int(raw)
                elif isinstance(target, float):
                    value = float(raw)
                else:
                    if not raw:
                        raise ValueError("empty")
                    value = raw
            except ValueError:
                kind = ("true/false" if isinstance(target, bool)
                        else "a number" if isinstance(target, (int, float))
                        else "a non-empty value")
                print(f"REFUSED: {k!r} takes {kind}; got {raw!r}",
                      file=sys.stderr)
                return 1
            if k in role_params and not str(value).strip():
                print(f"REFUSED: role param {k!r} cannot be blank",
                      file=sys.stderr)
                return 1
            old = policy.get(k, defaults.get(k))
            policy[k] = value
            changes.append(f"{k}: {old!r} -> {value!r}")

        syn = list(policy.get("trigger_synonyms", []))
        for s in (args.add_syn or []):
            s = s.strip()
            if s and s not in syn:
                syn.append(s)
                changes.append(f"synonym added: {s!r}")
        for s in (args.rm_syn or []):
            if s in syn:
                syn.remove(s)
                changes.append(f"synonym removed: {s!r}")
            else:
                print(f"note: synonym {s!r} was not on the play",
                      file=sys.stderr)
        if syn or "trigger_synonyms" in policy:
            policy["trigger_synonyms"] = syn

        if not changes:
            print("REFUSED: nothing to amend — pass --set, --add-synonym or "
                  "--remove-synonym", file=sys.stderr)
            return 1

        # The amended document must still be a valid play, whole.
        play = {"play_id": args.play_id, "name": name,
                "trigger_type": trigger_type, "goal": goal,
                "policy": policy,
                "params_needed": policy.get("params_needed", []),
                "body_md": body_md, "workflow_generate": wf_gen,
                "workflow_deliver": wf_del}
        errs = validate_play(play)
        if errs:
            for e in errs:
                print(f"ERROR: {e}", file=sys.stderr)
            print("REFUSED: the amendment was not saved", file=sys.stderr)
            return 1
        who = args.as_user or os.environ.get("IOF_REVIEWER") or "cli"
        _repo.amend_play_policy(sess.cur, sess.ph, args.play_id,
                                json.dumps(policy), int(version) + 1, who)
    print(f"amended {args.play_id} v{int(version) + 1} (by {who}):")
    for c in changes:
        print(f"  - {c}")
    print("applies to cases opened from now on; in-flight cases keep the "
          "parameters frozen at their open")
    return 0


# ------------------------------------- playbook compilation (HITL-gated)
#
# The business authors a playbook in PROSE; an agent drafts the executable
# form (rulebook spec + play document); this surface is what stands between
# the draft and the catalog. Staging is fail-closed (an invalid draft
# cannot even be staged), a human approval is the ONLY path to
# rulebook/play put, and approval RE-validates both documents at decision
# time — the learning-inbox precedent applied to plays.

#: What an author writes beside a sentence the workspace cannot deliver yet.
#: The template says so; compile-stage counts them and refuses a draft that
#: records fewer requests than the author marked - a prompt can drop one, a
#: count cannot.
CAPABILITY_MARKER = "[capability request]"

#: The six headings the reference playbooks use and the compiler reads
#: best. A shape, not a form: the text under them stays business language.
AUTHORING_HEADINGS = ("Goal", "Situation that starts it", "What happens",
                      "Windows and escalation", "Compliance property",
                      "Closing conditions")


def read_capability_requests(path) -> tuple[list[dict], list[str]]:
    """``(requests, errors)`` from the compiler's ``capability_requests.json``
    - a JSON list of ``{need, quoted, compiled_as}``. Shape errors are
    refusals: a malformed record is a request that would be lost."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as e:      # noqa: BLE001
        return [], [f"capability requests: cannot read {path}: {e}"]
    if not isinstance(data, list):
        return [], ["capability requests: the file must be a JSON list "
                    "(empty when the playbook asked for nothing the "
                    "workspace lacks)"]
    out, errs = [], []
    for i, r in enumerate(data):
        if not isinstance(r, dict) or not str(r.get("need") or "").strip():
            errs.append(f"capability requests: entry #{i + 1} must be an "
                        f"object with a non-empty `need`")
            continue
        out.append({"need": str(r["need"]).strip(),
                    "quoted": str(r.get("quoted") or "").strip(),
                    "compiled_as": str(r.get("compiled_as") or "").strip()})
    return out, errs


def _compile_validate(spec: dict, play: dict) -> list[str]:
    """Every error across both documents plus their cross-checks, at once."""
    from ioagentfarm.tools import case_store
    errs = [f"rulebook: {e}" for e in case_store.validate_spec(spec)]
    errs += [f"play: {e}" for e in validate_play(play)]
    if errs:
        return errs
    errs += [f"play: {e}"
             for e in workflow_resolution_errors(play, _workspace())]
    errs += [f"rulebook: {e}"
             for e in case_store.capability_resolution_errors(
                 spec, _workspace())]
    policy = play["policy"]
    # A role the PLAY overrides must be one the workspace can notify too.
    try:
        from ioagentfarm.engine.deliveries import describe_deliveries
        _declared, _ = describe_deliveries(_workspace() or None)
        _over = {rp: policy[rp] for rp in (spec.get("role_params") or [])
                 if rp in policy}
        errs += [f"cross-check: policy {e}" for e in
                 case_store.recipient_resolution_errors(spec, _declared,
                                                        _over)]
    except ValueError:
        pass        # the rulebook check above already refused it
    if policy.get("species") == "case":
        if policy.get("template") != spec.get("template_id"):
            errs.append(
                f"cross-check: play names template "
                f"{policy.get('template')!r} but the rulebook draft is "
                f"{spec.get('template_id')!r}")
        window_params = [r.get("sla_param") for r in spec.get("rules", [])
                         if r.get("sla_param")]
        if spec.get("goal_sla_param"):
            window_params.append(spec["goal_sla_param"])
        for k in window_params:
            if k in policy and not isinstance(policy[k], (int, float)):
                errs.append(f"cross-check: policy override {k!r} is not "
                            f"a number")
    return errs


#: Phrases a business author uses when dictating exact wording. Compliance
#: language must reach an action's approved_text verbatim; a compiler that
#: paraphrases it produces unapproved language that reads correct. Observed
#: twice on one playbook, including after explicit reviewer feedback — so
#: the check is machine-side, not another instruction.
_MANDATED_WORDING_MARKERS = (
    "exactly this wording", "exact wording", "must use exactly",
    "verbatim", "using exactly this", "this exact text",
    "approved wording", "must read exactly",
)


def source_cross_check(spec: dict, source_md: str) -> list[str]:
    """Warnings from comparing the DRAFT against the source prose — the
    class of defect a spec-only validator cannot see because the draft is
    internally consistent and simply omits something the business wrote."""
    warns: list[str] = []
    low = source_md.lower()
    if any(m in low for m in _MANDATED_WORDING_MARKERS):
        carriers = [n for n, m in (spec.get("actions") or {}).items()
                    if m.get("approved_text")]
        if not carriers:
            warns.append(
                "the source playbook dictates exact wording for a "
                "communication, but no action carries approved_text — the "
                "draft would compose a paraphrase of language the business "
                "mandated. Confirm which action it belongs to before "
                "approving.")
    # A DEADLINE THE SOURCE STATES MUST COMPILE TO A CLOCK. Watched live:
    # "within five business days" in the goal paragraph compiled to
    # declared success/abandonment ends and NO goal_sla_param - ends with
    # no clock, no goal_deadline on the case, no goal_overdue ever raised,
    # and the day-five notice's action orphaned with no rule to fire it.
    # A spec-only warning cannot fire here because ends-without-a-clock is
    # a legitimate shape for a NON-temporal goal (the os-vacancy seed);
    # only the source says whether time was part of the objective.
    if (re.search(r"within\s+(?:\w+|\d+)\s+(?:business\s+)?days?", low)
            and not (spec.get("goal_sla_param") or "").strip()):
        warns.append(
            "the source states a deadline ('within N business days') but "
            "the draft declares no goal_sla_param - the objective has ends "
            "and no clock: no goal_deadline, no goal_overdue, and 'within "
            "the goal window' can never be reported")
    return warns


def _map_consistency_errors(cap_map: list, spec: dict,
                            requests: list) -> list[str]:
    """The draft must be consistent with its own capability map.

    The MAP is the semantic match - a model reading the business text
    against the catalogs' descriptions, which no arithmetic can do. THIS is
    the arithmetic that makes the match binding: a workflow the map names
    must be commissioned by a rule, a verification record must be carried
    by a contract, a delivery kind must be delivered by, and a requirement
    mapped to nothing must be a capability request. Without it the map is
    a note; with it, a draft that quietly does less than its own matching
    said is refused before a reviewer ever sees it.
    """
    errs: list[str] = []
    if not isinstance(cap_map, list) or not cap_map:
        return ["capability_map.json must be a non-empty JSON list - the "
                "match step writes it, requirement by requirement"]
    foot = _draft_capabilities(spec)
    kinds_used = set(foot["delivery kind(s)"])
    wf_used = set(foot["workflow(s)"])
    ver_used = set(foot["verification record(s)"])
    none_rows = 0
    for i, row in enumerate(cap_map):
        if not isinstance(row, dict) or not isinstance(
                row.get("capability"), dict):
            errs.append(f"capability_map[{i}] is not "
                        f"{{requirement, quoted, capability{{type, name}}}}")
            continue
        req = str(row.get("requirement") or f"row {i}")[:70]
        ctype = (row["capability"].get("type") or "").strip()
        name = row["capability"].get("name")
        if ctype == "workflow":
            if name not in wf_used:
                errs.append(f"the map matches {req!r} to workflow {name!r} "
                            f"and no rule commissions it")
        elif ctype == "verification":
            if name not in ver_used:
                errs.append(f"the map matches {req!r} to verification "
                            f"record {name!r} and no action carries "
                            f"`verification: {{\"tool\": ...}}` naming it")
        elif ctype in ("email", "monitoring_task", "system_of_record",
                       "open_play"):
            if ctype not in kinds_used:
                errs.append(f"the map matches {req!r} to delivery kind "
                            f"{ctype!r} and no action delivers by it")
        elif ctype == "flow":
            # Served by the rulebook itself - a branch, a window, an
            # escalation rung, a stay-open rule. A requirement, but not a
            # capability: there is nothing external to bind it to, so
            # nothing to check here. Added when the first branching
            # playbook's matcher, with no word for flow, spelled the
            # branch/escalation/stay-open rows as `open_play` - which the
            # binding arithmetic then dutifully turned into a demand for
            # composition the business never asked for.
            continue
        elif ctype == "none":
            none_rows += 1
        else:
            errs.append(f"capability_map[{i}].capability.type {ctype!r} is "
                        f"not workflow/email/monitoring_task/"
                        f"system_of_record/verification/open_play/flow/none")
    if none_rows > len(requests or []):
        errs.append(f"the map has {none_rows} requirement(s) matched to "
                    f"NOTHING and capability_requests.json records "
                    f"{len(requests or [])} - every unmatched requirement "
                    f"is a capability request; that is how the business "
                    f"learns what to build")
    return errs


def _kind_count_gaps(cap_map: list, spec: dict) -> list[str]:
    """Per-kind arithmetic between the map and the draft's contracts.

    `_map_consistency_errors` checks PRESENCE - a kind the map names must be
    delivered by at least one action - and presence is what let a register
    ship as a monitoring task: the map named `email` for four requirements,
    the draft carried three email contracts plus the register mis-typed as
    `monitoring_task`, and every presence check passed. Two reviewers then
    missed it, and the case LEDGER caught it in production (`MON-...` as the
    receipt of a send). The counts are pure set facts, so say them: fewer
    contracts of a kind than the map has requirements of it means either two
    requirements deliberately share one action, or a contract has the wrong
    kind. A warning, not a refusal - sharing is legitimate and common."""
    if not isinstance(cap_map, list):
        return []
    acts = spec.get("actions") or {}
    out: list[str] = []
    for kind in ("email", "monitoring_task", "system_of_record",
                 "open_play"):
        mapped = sum(1 for r in cap_map if isinstance(r, dict)
                     and isinstance(r.get("capability"), dict)
                     and r["capability"].get("type") == kind)
        carried = sum(1 for m in acts.values() if isinstance(m, dict)
                      and (m.get("delivery") == kind
                           or (kind == "monitoring_task"
                               and (m.get("task_kind") or "").strip())))
        if mapped > carried:
            out.append(
                f"the map holds {mapped} requirement(s) delivered by "
                f"{kind!r} and the draft carries {carried} {kind} "
                f"contract(s) - if two requirements share one action, say "
                f"so in compile_notes.md; if not, an action's `delivery:` "
                f"has the wrong kind (this exact arithmetic would have "
                f"caught a register shipped as a monitoring task)")
    return out


def _draft_capabilities(spec: dict) -> dict:
    """One draft's capability FOOTPRINT - which delivery kinds, workflows,
    verification records and declared ends it reaches for. Set facts read
    from the spec alone; the prose is never consulted."""
    acts = spec.get("actions") or {}
    # A monitoring task that rides another action's contract (task_kind on
    # a register email) IS the monitoring_task kind in use. Counting only
    # `delivery:` values put the map and the reviewer at war: the review
    # ordered the task onto the email's contract, the map truthfully said
    # monitoring_task serves a requirement, and the binding arithmetic then
    # refused the draft for having no action DELIVERED by monitoring_task.
    # The agent diagnosed it live and stopped rather than fudge its map.
    kinds = {m.get("delivery") for m in acts.values()
             if isinstance(m, dict) and m.get("delivery")}
    if any(isinstance(m, dict) and (m.get("task_kind") or "").strip()
           for m in acts.values()):
        kinds.add("monitoring_task")
    return {
        "delivery kind(s)": sorted(kinds),
        "workflow(s)": sorted({m.get("workflow") for m in acts.values()
                               if isinstance(m, dict) and m.get("workflow")}),
        "verification record(s)": sorted(
            {(m.get("verification") or {}).get("tool")
             for m in acts.values() if isinstance(m, dict)
             and isinstance(m.get("verification"), dict)
             and (m.get("verification") or {}).get("tool")}),
        "success end(s)": sorted(spec.get("success_events") or []),
        "abandonment end(s)": sorted(spec.get("abandonment_events") or []),
    }


def _unused_capabilities(spec: dict) -> list[str]:
    """What this workspace declares that the draft never reaches for.

    SET ARITHMETIC, NOT JUDGEMENT - computed against the same resolvers the
    validators refuse against, and the prose is never read, so the report
    holds for every author's wording. The alternative was teaching the
    compile prompt each new phrasing of each requirement, which is a rule
    per author's idiom, forever; measured live before this existed, a draft
    dropped a declared verification record, a second workflow and one of
    two declared ends in a single round and nothing said so. Unused is not
    wrong; unexamined is."""
    from ioagentfarm.engine.deliveries import (TOOL_KINDS,
                                               declared_deliveries)
    foot = _draft_capabilities(spec)
    out: list[str] = []
    try:
        declared = declared_deliveries(_workspace() or None) or {}
    except ValueError:
        declared = {}
    for kind, entry in declared.items():
        if kind in TOOL_KINDS and kind not in foot["delivery kind(s)"]:
            out.append(f"delivery kind `{kind}` (tool "
                       f"`{(entry or {}).get('tool')}`) - no action "
                       f"delivers by it")
    for tool in (declared.get("verification") or {}).get("tools") or []:
        if tool not in foot["verification record(s)"]:
            out.append(f"verification record `{tool}` - no action checks a "
                       f"claimed outcome against it before the matter "
                       f"closes")
    for name in sorted(_resolvable_workflows(_workspace() or None)):
        if name in _NOT_COMMISSIONABLE:
            continue
        if name not in foot["workflow(s)"]:
            out.append(f"workflow `{name}` - no rule commissions it")
    return out


def _regressions_from(prior_spec: dict, spec: dict) -> list[dict]:
    """What the PREVIOUS draft of this template reached for that this one
    does not - ``[{"what": category, "lost": [names]}]``. The rejection
    banner already tells the compiler not to fix the newest complaint by
    undoing an earlier fix; this is that sentence as arithmetic, because
    it was watched happening anyway: one round dropped a second workflow,
    a verification record and one of two declared ends while fixing the
    complaint it was rejected for, and nothing said so."""
    before = _draft_capabilities(prior_spec)
    now = _draft_capabilities(spec)
    out: list[dict] = []
    for key, had in before.items():
        lost = sorted(set(had) - set(now[key]))
        if lost:
            out.append({"what": key, "lost": lost})
    return out


def _render_review(spec: dict, play: dict, source_md: str,
                   notes_md: str = "", requests: list | None = None,
                   cap_map: list | None = None,
                   unused: list[str] | None = None,
                   regressions: list[dict] | None = None,
                   prior_id: str | None = None) -> str:
    """Deterministic review rendering — the human approves from THIS, a
    rule table beside the business prose, never from raw JSON."""
    lines = [f"# Compilation review: {play['name']}", ""]
    lines += [f"- play: {play['play_id']}  trigger: "
              f"\"{play['trigger_type']}\"",
              f"- template: {spec['template_id']} "
              f"({len(spec['rules'])} rule(s), "
              f"{len(spec.get('wildcard_rules', []))} wildcard(s), "
              f"{len(spec['states'])} state(s))",
              f"- action workflow: {_action_workflow(play)}"
              + (f"  (delivery: {play['workflow_deliver']})"
                 if play.get("workflow_deliver") else ""),
              f"- params_needed: {', '.join(play['params_needed'])}", ""]
    params = spec["default_params"]
    merged = {**params, **{k: v for k, v in play["policy"].items()
                           if k in params}}
    lines += ["## Roles and windows (play policy over template defaults)",
              ""]
    for k in sorted(merged):
        note = "" if merged[k] == params[k] else \
            f"  (template default: {params[k]})"
        lines.append(f"- {k}: {merged[k]}{note}")
    # THE DECLARED ENDS, when the draft states them. The ladder below is
    # the means; this is what the business owner is saying the play is FOR,
    # and it is what kpi will score the play against. A reviewer approving
    # a ladder without seeing its success definition is approving mechanics
    # with the objective left implicit.
    if spec.get("goal") or spec.get("success_events") \
            or spec.get("abandonment_events") or spec.get("goal_sla_param"):
        lines += ["", "## The objective, and what counts as reaching it", ""]
        if spec.get("goal"):
            lines.append(f"- goal: {spec['goal']}")
        if spec.get("success_events"):
            lines.append("- the objective is MET when a case closes on: "
                         + ", ".join(spec["success_events"]))
        if spec.get("abandonment_events"):
            lines.append("- the objective is ABANDONED when a case closes "
                         "on: " + ", ".join(spec["abandonment_events"]))
        gp = spec.get("goal_sla_param")
        if gp:
            lines.append(
                f"- goal window: {gp} = {merged.get(gp)} business day(s) "
                f"from case open, never reset by a rung — expiry raises "
                f"`{spec.get('goal_event') or 'goal_overdue'}` through the "
                f"same rules as any other event")
    lines += ["", "## Rules", "",
              "| rule | when (state + event) | action | next state | window |",
              "|---|---|---|---|---|"]
    for r in spec["rules"]:
        w = r.get("sla_param") or "-"
        lines.append(f"| {r['rule_id']} | {r['from_state']} + {r['event']} "
                     f"| {r['action']} | {r['to_state']} | {w} |")
    for w in spec.get("wildcard_rules", []):
        lines.append(f"| {w['rule_id']} | ANY STATE + {w['event']} "
                     f"| {w['action']} | {w['to_state']} "
                     f"| {w.get('sla_param') or '-'} |")
    acts = spec.get("actions", {})
    if acts:
        lines += ["", "## Delivery contracts", "",
                  "| action | delivery | to | cc | task | side effects "
                  "| approved language |",
                  "|---|---|---|---|---|---|---|"]
        for name in sorted(acts):
            m = acts[name]
            lines.append(
                f"| {name} | {m.get('delivery', '-')} "
                f"| {m.get('to_param', '-')} "
                f"| {m.get('cc_param') or 'NONE (exclusive)'} "
                f"| {m.get('task_kind', '-')} "
                f"| {'yes' if m.get('side_effects', True) else 'no'} "
                f"| {'yes (verbatim)' if m.get('approved_text') else '-'} |")
        verified = {n: m["verification"]["tool"]
                    for n, m in sorted(acts.items())
                    if isinstance(m.get("verification"), dict)
                    and m["verification"].get("tool")}
        if verified:
            lines += ["", "Outcome verification — the act step calls the "
                          "named tool and records its result as the "
                          "receipt, so the ledger holds the ground truth "
                          "beside the claim:", ""]
            for n, tool in verified.items():
                lines.append(f"- {n}: `{tool}`")
        composed = {n: m.get("play") for n, m in sorted(acts.items())
                    if isinstance(m, dict)
                    and m.get("delivery") == "open_play"}
        if composed:
            lines += ["", "Play composition — approving this play "
                          "AUTHORIZES it to open cases of the plays below "
                          "(each child runs its own approved rulebook, "
                          "linked to the ordering case):", ""]
            for n, p in composed.items():
                lines.append(f"- {n} -> opens `{p}`")
        commissioned = [(n, m) for n, m in sorted(acts.items())
                        if isinstance(m, dict)
                        and m.get("delivery") == "workflow"]
        if commissioned:
            lines += ["", "Commissioned workflows — approving this play "
                          "AUTHORIZES it to run the workflows below when "
                          "the rule fires; the run's result arrives at the "
                          "case as the event shown:", ""]
            for n, m in commissioned:
                lines.append(
                    f"- {n} -> runs `{m.get('workflow')}` "
                    f"(completion: {m.get('completion_event') or 'workflow_completed'}"
                    f", failure: {m.get('failure_event') or 'system_error'})"
                    + (f" — goal: {m['goal_hint']}" if m.get("goal_hint")
                       else ""))
    # THE APPROVED WORDING, IN FULL. Rendering it as a bare "yes
    # (verbatim)" asked a reviewer to sign off on language they could not
    # see — and a substitution defect that put a false window length into
    # a regulatory notice survived review for exactly that reason. The
    # text is the thing being approved; show it.
    verbatim = {n: m.get("approved_text") for n, m in sorted(acts.items())
                if m.get("approved_text")}
    if verbatim:
        lines += ["", "## Approved wording, delivered verbatim", "",
                  "Substitution is limited to the placeholders shown. "
                  "`{sla_days}` is the window the action STARTS; where the "
                  "sentence refers to a window that has just expired, use "
                  "`{prior_sla_days}`.", ""]
        for name, text in verbatim.items():
            quoted = "\n".join("> " + ln for ln in str(text).splitlines())
            lines += [f"**{name}**", "", quoted, ""]

    # The trace a business owner should actually approve: what happens
    # when nobody responds and only the clock fires — plus the declared
    # invariants and any structural warnings, all machine-derived.
    from ioagentfarm.tools import case_store
    lines += ["", "## Simulated: nobody responds, only the clock fires", ""]
    for s in case_store.exhaust_walk(spec):
        if s.get("verdict"):
            lines.append(f"- {s['state']} + {s['event']}: {s['verdict']} — "
                         f"{s['note']}")
        else:
            w = s.get("window")
            wtxt = (f" (window {w}={spec['default_params'].get(w)}d)"
                    if w else "")
            lines.append(f"- {s['state']} + {s['event']} -> "
                         f"{s['rule_id']} {s['action']} -> "
                         f"{s['to_state']}{wtxt}")
    invs = spec.get("invariants", [])
    if invs:
        lines += ["", "## Declared invariants (machine-checked on every "
                      "revision)", ""]
        for inv in invs:
            lines.append(f"- {json.dumps(inv)}")
    # Properties the closed vocabulary cannot yet express. Rendered so the
    # reviewer knows these are REVIEWED AS PROSE, not enforced — and so
    # recurring entries become the demand signal for a new invariant kind.
    wanted = spec.get("wanted_invariants") or []
    if wanted:
        lines += ["", "## Stated properties the machine cannot check yet",
                  "",
                  "No validator enforces these — they hold only as long as "
                  "people honour them. Recurring entries across playbooks "
                  "are the case for a new machine-checked invariant kind.",
                  ""]
        for w in wanted:
            prop = w.get("property") if isinstance(w, dict) else str(w)
            src = (w.get("source") or "") if isinstance(w, dict) else ""
            lines.append(f"- {prop}" + (f"  (from: {src!r})" if src else ""))
    # The classification criteria are a DECISION RULE the business is
    # approving: they decide which rule a person's free-text reply fires.
    # A reviewer who cannot see them is approving the ladder without the
    # judgement boundary that feeds it.
    rubrics = spec.get("event_rubrics") or {}
    if rubrics:
        lines += ["", "## How a written reply becomes an event", "",
                  "| event | classify a reply as this when |",
                  "|---|---|"]
        for ev in sorted(rubrics):
            lines.append(f"| {ev} | {rubrics[ev]} |")
    warns = (case_store.validate_spec_warnings(spec)
             + source_cross_check(spec, source_md))
    if cap_map:
        lines += ["", "## The matching, requirement by requirement", "",
                  "The match step's reading of the source against the "
                  "catalogs. The validator has already checked the draft "
                  "against every row; what a reviewer judges here is the "
                  "READING - whether each requirement was understood, and "
                  "whether a `none` should have matched.", "",
                  "| requirement | matched to | why |", "|---|---|---|"]
        for row in cap_map:
            cap = row.get("capability") or {}
            to = (f"{cap.get('type')} `{cap.get('name')}`"
                  if cap.get("name") else str(cap.get("type")))
            lines.append(f"| {row.get('requirement', '')} | {to} | "
                         f"{row.get('why', '')} |")
    if unused is not None:
        lines += ["", "## Capabilities this draft does not use", ""]
        if unused:
            lines.append("Unused is not wrong; unexamined is. \"owned\" "
                         "means the compiler's notes name it.")
            lines.append("")
            for u in unused:
                name = u.split("`")[1] if "`" in u else u
                owned = name and name in (notes_md or "")
                lines.append(f"- {u} — "
                             + ("owned in the notes" if owned else
                                "NOT MENTIONED in the notes"))
        else:
            lines.append("- None: every capability this workspace declares "
                         "is reached by some rule or contract.")
    if regressions:
        lines += ["", f"## Dropped from the previous draft"
                      + (f" ({prior_id})" if prior_id else ""), "",
                  "Each drop below is OWNED - the compiler's notes name "
                  "it, or the stage would have refused. The review judges "
                  "the reasons, not the arithmetic.", ""]
        for r in regressions:
            lines.append(f"- {r['what']}: "
                         + ", ".join(f"`{x}`" for x in r["lost"]))
    # ALWAYS RENDERED, INCLUDING WHEN EMPTY. The section used to appear
    # only when something was found, so a reviewer reading a report that
    # renders assumptions, invariants and a simulation reasonably took the
    # absence of warnings to mean "none found" rather than "not a field
    # this report has". Say which.
    lines += ["", "## Warnings for the reviewer (not refusals)", ""]
    if warns:
        for w in warns:
            lines.append(f"- {w}")
    else:
        lines.append("- None. The structural checks found nothing to "
                     "raise; this is a checked result, not an omitted "
                     "section.")
    syn = play["policy"].get("trigger_synonyms", [])
    if syn:
        lines += ["", "## Trigger synonyms", ""]
        lines += [f"- {s}" for s in syn]
    if notes_md.strip():
        lines += ["", "## Compiler notes and assumptions", "",
                  notes_md.strip()]
    # WHAT THE PLAYBOOK ASKED FOR THAT THIS WORKSPACE CANNOT DELIVER YET.
    # Rendered even when empty: an absent section reads as "not checked",
    # and this is the list the business learns what to build next from.
    lines += ["", "## Capability requests (this workspace cannot deliver "
                  "these yet)", ""]
    if requests:
        for r in requests:
            lines.append(f"- **{r['need']}**"
                         + (f" — the text says: \"{r['quoted']}\""
                            if r.get("quoted") else "")
                         + (f" — compiled for now as: {r['compiled_as']}"
                            if r.get("compiled_as") else ""))
    else:
        lines.append("- None recorded. Every step maps to something this "
                     "workspace can deliver.")
    lines += ["", "---", "", "## Source playbook (business-authored)", "",
              source_md.strip(), ""]
    return "\n".join(lines)


def cmd_compile_stage(args) -> int:
    """Validate a compiled draft and stage it for human approval. Nothing
    reaches the catalog from here — an approved compilation is the only
    path."""
    try:
        source = Path(args.source).read_text(encoding="utf-8")
        spec = json.loads(Path(args.rulebook).read_text(encoding="utf-8"))
        play = json.loads(Path(args.play).read_text(encoding="utf-8"))
        notes = (Path(args.notes).read_text(encoding="utf-8")
                 if args.notes else "")
    except Exception as e:
        print(f"REFUSED: cannot read draft inputs: {e}", file=sys.stderr)
        return 1
    errs = _compile_validate(spec, play)
    # The capability requests the compiler recorded, cross-checked against
    # the author's own markers: a draft that records fewer than the author
    # marked has DROPPED one, and a request dropped at compile time is a
    # capability the business never hears it lacks.
    requests: list[dict] = []
    req_path = (args.requests or "").strip()
    if not req_path and args.out and (Path(args.out)
                                      / "capability_requests.json").is_file():
        req_path = str(Path(args.out) / "capability_requests.json")
    if req_path:
        requests, req_errs = read_capability_requests(req_path)
        errs += req_errs
    marked = source.count(CAPABILITY_MARKER)
    if marked > len(requests):
        errs.append(
            f"capability requests: the source playbook marks {marked} "
            f"sentence(s) {CAPABILITY_MARKER} but the draft records "
            f"{len(requests)} - every marked sentence must appear in "
            f"capability_requests.json (need, quoted, compiled_as)")
    # The capability MAP - the match step's semantic reading of the source
    # against the catalogs - made binding: a draft inconsistent with its
    # own map is refused here, in-session, where the compiler can fix it.
    cap_map: list = []
    map_path = (getattr(args, "map", "") or "").strip()
    if not map_path and args.out and (Path(args.out)
                                      / "capability_map.json").is_file():
        map_path = str(Path(args.out) / "capability_map.json")
    if map_path:
        try:
            cap_map = json.loads(Path(map_path).read_text(encoding="utf-8"))
        except Exception as e:                       # noqa: BLE001
            errs.append(f"capability_map.json is unreadable: {e}")
        else:
            errs += _map_consistency_errors(cap_map, spec, requests)
    # A LOOPING LADDER NEVER REACHES A REVIEWER. The exhaust trace is
    # already computed for the review page; a walk that ends in LOOP means
    # a breach rule returns to a state it can breach from again, so the
    # escalation chases forever - wrong in EVERY playbook, because breaches
    # recur by construction. This was round one's fatal defect and it came
    # back in round eight wearing a wildcard; a deterministic verdict the
    # page merely displayed is a refusal now.
    try:
        from ioagentfarm.tools.case_store import exhaust_walk
        _walk = exhaust_walk(spec)
        if _walk and _walk[-1].get("verdict") == "LOOP":
            _last = _walk[-1]
            errs.append(
                f"the exhaust trace ends in LOOP: rule "
                f"{_last.get('rule_id')} re-fires from "
                f"{_last.get('from_state')!r} on every further breach - "
                f"the ladder must end parked (a last rung with no breach "
                f"rule out of it), never cycling")
    except Exception:                                # noqa: BLE001
        pass
    if errs:
        for e in errs:
            print(f"ERROR: {e}", file=sys.stderr)
        print("REFUSED: the draft was NOT staged — fix the draft and "
              "re-stage; an invalid document must never reach a reviewer "
              "as approvable", file=sys.stderr)
        return 1
    from ioagentfarm.tools import case_store
    warnings = (case_store.validate_spec_warnings(spec)
                + source_cross_check(spec, source)
                + _kind_count_gaps(cap_map, spec))
    # Declared-but-unused capabilities: put to the COMPILER, in-session -
    # use each, or own the choice in compile_notes.md by name. The review
    # renders every one either way, marked owned or unexamined.
    unused = _unused_capabilities(spec)
    for u in unused:
        warnings.append(f"declared but unused: {u} - use it, or say why "
                        f"not in compile_notes.md (the review names it "
                        f"either way)")
    with session(args.out) as s:
        cur, ph = s.cur, s.ph
        # A PHANTOM CHILD IS SAID AT STAGE, NOT DISCOVERED AT DELIVERY.
        # Watched live: a draft's open_play actions named barrier_review_l1
        # and barrier_review_l2 - plays that existed nowhere - and the
        # review sheet offered to AUTHORIZE opening them without a word.
        # The delivery refuses a missing play, but a reviewer approving an
        # authorization over a phantom deserves better than an eventual
        # runtime refusal. A warning, not an error: a bundle whose child is
        # approved minutes after its parent stages is legitimate.
        _ops = {p.get("play_id") for p in _repo.list_plays(cur, ph)
                if p.get("status") == "operational"}
        for aname, m in (spec.get("actions") or {}).items():
            if (isinstance(m, dict) and m.get("delivery") == "open_play"
                    and m.get("play") not in _ops):
                warnings.append(
                    f"actions[{aname!r}] opens child play {m.get('play')!r} "
                    f"which is NOT an operational play in this workspace - "
                    f"approving authorizes opening a play that does not "
                    f"exist; the delivery will refuse until it does")
        for w in warnings:
            print(f"WARNING: {w}")
        # A DRAFT MAY NOT SILENTLY DO LESS THAN ITS PREDECESSOR. Watched
        # live: a round fixed the complaint it was rejected for and dropped
        # a second workflow, a verification record and one of two declared
        # ends, and nothing said so. A drop the notes own BY NAME reaches
        # the reviewer as a stated decision; one they do not is treated as
        # the model forgetting and refused here, where it can be fixed.
        prior = _repo.latest_prior_draft(cur, ph, spec["template_id"])
        regressions: list[dict] = []
        if prior and prior.get("rulebook_json"):
            try:
                regressions = _regressions_from(
                    json.loads(prior["rulebook_json"]), spec)
            except Exception:                        # noqa: BLE001
                regressions = []
        unowned = [(r["what"], x) for r in regressions
                   for x in r["lost"] if x not in (notes or "")]
        if unowned:
            for what, x in unowned:
                print(f"ERROR: the previous draft "
                      f"({prior['compile_id']}) reached for {what[:-3]} "
                      f"`{x}` and this one does not, and compile_notes.md "
                      f"does not name the drop", file=sys.stderr)
            print("REFUSED: the draft was NOT staged — restore each item "
                  "above, or state in compile_notes.md BY NAME why the "
                  "drop is deliberate. A capability this workspace lacks "
                  "belongs in capability_requests.json instead.",
                  file=sys.stderr)
            return 1
        review = _render_review(spec, play, source, notes, requests,
                                cap_map=cap_map, unused=unused,
                                regressions=regressions,
                                prior_id=(prior or {}).get("compile_id"))
        # A RESTAGE supersedes its predecessor. The compile step validates
        # in-session and re-stages after fixing a refusal; a second
        # SUCCESSFUL stage in the same run would otherwise leave the
        # reviewer two pending compilations for one play, with nothing to
        # say which is current (observed live: one run staged twice).
        # Scoped to the same run: two DIFFERENT runs compiling the same
        # play are genuine alternatives and both stay pending for a person
        # to choose between.
        superseded = []
        if args.run_id:
            superseded = _repo.pending_compilations_for_run(
                cur, ph, args.run_id, play["play_id"])
            for cid in superseded:
                _repo.supersede_compilation(
                    cur, ph, cid,
                    "superseded by a re-stage in the same compile run")
                # Its capability requests go with it: the re-stage records
                # its own. Seen live - one compile run staged twice and the
                # same need was listed open twice.
                _repo.supersede_capability_requests(
                    cur, ph, cid,
                    "superseded by a re-stage in the same compile run")

        def _ins(c, cid):
            _repo.insert_compilation(
                c, ph, cid, spec["template_id"], play["play_id"], source,
                json.dumps(spec, indent=2), json.dumps(play, indent=2),
                review, notes, args.run_id or None, "hitl_pending")

        compile_id = _insert_with_fresh_id(cur, _next_compile_id, _ins)
        for r in requests:
            _repo.insert_capability_request(
                cur, ph, compile_id, play["play_id"], spec["template_id"],
                r["need"], r["quoted"], r["compiled_as"])
    receipt = {"compile_id": compile_id, "status": "hitl_pending",
               "template_id": spec["template_id"],
               "play_id": play["play_id"],
               "capability_requests": len(requests),
               "next": f"a human reviews with `iof-plays compile-show "
                       f"{compile_id}` and decides with `iof-plays "
                       f"compile-approve {compile_id} --as <name>` or "
                       f"`compile-reject`"}
    if args.out:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        (out / "compile_receipt.json").write_text(
            json.dumps(receipt, indent=2), encoding="utf-8")
    print(f"staged {compile_id}: {play['play_id']} + "
          f"{spec['template_id']} -> hitl_pending (validated clean; a "
          f"human must approve before anything reaches the catalog)"
          + (f"; {len(requests)} capability request(s) recorded"
             if requests else "")
          + (f"; superseded {', '.join(superseded)} from this run"
             if superseded else ""))
    return 0


def cmd_capability_requests(args) -> int:
    """What playbooks asked for that this workspace cannot deliver yet -
    the other half of "what to build next" beside `unmatched`. Open by
    default; --resolve closes one with a name and a reason."""
    with session() as s:
        if args.resolve:
            who = args.as_user or os.environ.get("IOF_REVIEWER") or "cli"
            row = _repo.capability_request_status(s.cur, s.ph,
                                                  int(args.resolve))
            if not row:
                print(f"no capability request #{args.resolve}",
                      file=sys.stderr)
                return 1
            _repo.resolve_capability_request(s.cur, s.ph, int(args.resolve),
                                             who, args.reason or "")
            print(f"resolved capability request #{args.resolve} by {who}"
                  + (f": {args.reason}" if args.reason else ""))
            return 0
        rows = _repo.list_capability_requests(s.cur, s.ph,
                                              include_resolved=bool(args.all))
    if args.json:
        print(json.dumps({"capability_requests": rows}, indent=2))
        return 0
    if not rows:
        print("no open capability requests - every compiled playbook maps "
              "to what this workspace can deliver")
        return 0
    print(f"{'id':>4}  {'play':<28} {'status':<9} need")
    for r in rows:
        print(f"{r['id']:>4}  {r['play_id']:<28} {r['status']:<9} "
              f"{r['need']}")
        if r.get("quoted"):
            print(f"{'':>4}  {'':<28} {'':<9}   text: \"{r['quoted']}\"")
    return 0


def _template_facts() -> dict:
    """Everything the authoring template says, as data - the same
    resolutions the compiler and the validator use, so what the author is
    told is what would install."""
    from ioagentfarm.engine.deliveries import describe_deliveries
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    import yaml
    ws = _workspace() or None
    try:
        declared, source = describe_deliveries(ws)
    except ValueError as e:
        declared, source = {}, f"error: {e}"
    loader = WorkflowLoader()
    workflows = []
    try:
        names = sorted(_resolvable_workflows(ws))
    except Exception:       # noqa: BLE001 - the template still renders
        names = []
    for name in names:
        if name in _NOT_COMMISSIONABLE:
            continue
        desc = ""
        try:
            d = loader._workflow_dir(name)
            if d is not None:
                doc = yaml.safe_load(
                    (d / "workflow.yaml").read_text(encoding="utf-8")) or {}
                desc = " ".join(str(doc.get("description") or "").split())
        except Exception:       # noqa: BLE001
            desc = ""
        workflows.append({"name": name, "description": desc})
    return {
        "workspace": ws,
        "deliveries_source": source,
        "notifications": bool((declared.get("email") or {}).get("tool")),
        "recipients": [str(r) for r in
                       ((declared.get("email") or {}).get("recipients")
                        or [])],
        "monitoring_tasks": bool((declared.get("monitoring_task") or {})
                                 .get("tool")),
        "verification_records": [str(t) for t in
                                 ((declared.get("verification") or {})
                                  .get("tools") or [])],
        "write_back": bool((declared.get("system_of_record") or {})
                           .get("tool")),
        "workflows": workflows,
        "marker": CAPABILITY_MARKER,
        "headings": list(AUTHORING_HEADINGS),
    }


def render_template(f: dict) -> str:
    """The authoring template, in business language. What the workspace can
    deliver is the first thing on the page; the shape is the last."""
    where = f"the {f['workspace']} workspace" if f["workspace"]         else "this workspace"
    L = [f"# Writing a playbook for {where}", "",
         "What you write here is compiled into a procedure the platform "
         "runs, and a named person approves it before it runs. Write in "
         "your own language. This page says what the platform can already "
         "deliver in this workspace, so that what you ask for is executable "
         "when it is approved.", "",
         "## What this workspace can deliver", "",
         "### Telling people", ""]
    if f["notifications"] and f["recipients"]:
        L.append("- Notify one of these roles by email: "
                 + ", ".join(f["recipients"]) + ". Name them exactly as "
                 "written here; a step addressed to any other role cannot "
                 "be compiled.")
    elif f["notifications"]:
        L.append("- Notify a role by email. Name the role by its job title "
                 "(for example \"the Brand Lead\"); the platform resolves "
                 "who that is.")
    else:
        L.append("- This workspace has not declared how it sends "
                 "notifications. A step that tells someone cannot be "
                 "compiled until it does.")
    if f["monitoring_tasks"]:
        L.append("- Open a monitoring task for a window, so that the wait "
                 "is visible and owned.")
    if f.get("write_back"):
        # An outcome that reaches nobody's system is an outcome only this
        # platform knows about. Say the workspace can write one back, or an
        # author has no way to ask for it.
        L.append("- Write an outcome back into the system your teams read, "
                 "so a decision this procedure reaches is visible where "
                 "they work and not only on its own record.")
    L += ["", "### Work the platform can do for you", ""]
    if f["workflows"]:
        L.append("Ask for any of these by describing the work; the compiler "
                 "maps it to the one that does it.")
        L.append("")
        for w in f["workflows"]:
            L.append(f"- **{w['name']}**"
                     + (f" — {w['description']}" if w["description"] else ""))
    else:
        L.append("- Nothing yet. No analysis or report can be run from a "
                 "playbook in this workspace.")
    L += ["", "### Records a step can be checked against", ""]
    if f["verification_records"]:
        L.append("Ask for a claimed outcome to be confirmed against one of "
                 "these before the matter closes:")
        L.append("")
        L += [f"- {t}" for t in f["verification_records"]]
    else:
        L.append("- None declared. A step cannot be verified against a "
                 "system of record in this workspace yet.")
    L += ["", "### Time", "",
          "- Windows are counted in business days. Give every wait a length, "
          "and say what happens when it passes.",
          "", "### The ladder", "",
          "- Escalation: say who is told next, and how long they have.",
          "- Stopping is not closing. \"Stop chasing and leave it for a "
          "person\" parks the matter for someone to pick up; \"close\" ends "
          "it. Say which you mean.",
          "- A decision not to act is a decision: say what is recorded and "
          "that the matter closes.",
          "- Mandated wording: quote it — \"the message must say exactly: "
          "…\". Quoted wording is delivered word for word; anything else is "
          "composed to meet the intent you state.",
          "- Anything you have not written a rule for is refused and written "
          "down, never guessed at.",
          "", "## When you need something not listed", "",
          f"Write the step anyway and put `{f['marker']}` at the end of the "
          f"sentence. It is kept when the playbook is compiled: the reviewer "
          f"sees it, it is recorded as a capability this workspace does not "
          f"have yet, and the compiled procedure hands that step to the role "
          f"who would do it by hand until it does.",
          "", "## The shape", "",
          "Use these headings; write freely under them.", "",
          "```", "# <Playbook name>", ""]
    for h in f["headings"]:
        L += [f"## {h}", ""]
    L += ["```", ""]
    return "\n".join(L)


def cmd_template(args) -> int:
    facts = _template_facts()
    text = render_template(facts)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(text if not args.json
                                  else json.dumps(facts, indent=2),
                                  encoding="utf-8")
    if args.json:
        # --json is a machine surface: the facts go to stdout either way.
        print(json.dumps(facts, indent=2))
    elif args.out:
        # The author opens the file; dumping the template as well buries
        # the one line that says where it was written.
        print(f"wrote {args.out} - the authoring template for this "
              f"workspace. Write the playbook under its headings.")
    else:
        print(text)
    return 0


def cmd_compile_pending(args) -> int:
    with session() as s:
        rows = _repo.pending_compilations(s.cur, s.ph)
    if args.json:
        print(json.dumps({"pending": rows}, indent=2))
        return 0
    for r in rows:
        print(f"{r['compile_id']}  {r['play_id']:<22} {r['template_id']:<26}"
              f" staged {r['created_at']}")
    if not rows:
        print("no pending compilations")
    return 0


def cmd_compile_history(args) -> int:
    """Every prior compilation of a template, with each rejection's REASON.

    THE RECOMPILE USED TO START COLD. `compile-reject --reason` wrote to
    `meta_compilations.reason` and nothing ever read it back — no SELECT
    in this module touched the column — so each round began from the prose
    plus whatever the reviewer happened to restate. That is not merely
    lossy, it REGRESSES: observed live, round 1 got three routing owners
    right and the event lexicon wrong; the reviewer rejected it naming the
    lexicon; round 2 fixed the lexicon and silently collapsed all three
    routing recipients onto one role, undoing the entire purpose of the
    play. It was caught only because that reviewer had read round 1 and
    said so by hand.

    So corrections are cumulative and must be carried: this is the channel
    the compile step reads before drafting, and every listed reason is a
    binding constraint, including ones already satisfied.
    """
    with session() as s:
        rows = (_repo.compilation_history(s.cur, s.ph, args.target)
                if (args.target or "").strip()
                else _repo.all_compilations(s.cur, s.ph))
    if getattr(args, "out", ""):
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(
            json.dumps({"target": args.target or "(all)",
                        "compilations": rows}, indent=2), encoding="utf-8")
    if args.json:
        print(json.dumps({"target": args.target, "compilations": rows},
                         indent=2))
        return 0
    if not rows:
        print(f"no prior compilations of {args.target} - this is round 1")
        return 0
    rejected = [r for r in rows if r["status"] == "rejected"]
    for r in rows:
        print(f"{r['compile_id']}  {r['status']:<13} {r['created_at']}"
              + (f"  by {r['reviewer']}" if r.get("reviewer") else ""))
        if r.get("reason"):
            print(f"    reason: {r['reason']}")
    if rejected:
        print()
        print(f"{len(rejected)} rejection(s) above are BINDING CONSTRAINTS "
              f"on the next draft.")
        print("Satisfy every one of them AT ONCE. A later round that fixes "
              "the newest complaint while undoing an earlier fix is the "
              "failure this list exists to prevent.")
    return 0


def _print_model_text(text: str) -> None:
    """Print text a MODEL authored (review bodies, notes). A legacy console
    code page (cp1252/cp437) raises UnicodeEncodeError on characters we do
    not control — degrade the character, never crash the review surface."""
    enc = getattr(sys.stdout, "encoding", None) or "utf-8"
    sys.stdout.write(text.encode(enc, errors="replace").decode(enc, "replace")
                     + "\n")


def cmd_compile_show(args) -> int:
    with session() as s:
        r = _repo.get_compilation(s.cur, s.ph, args.compile_id)
    if not r:
        print(f"no compilation {args.compile_id!r}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(r, indent=2))
        return 0
    print(f"[{r['status']}] {r['compile_id']}"
          + (f"  reviewer {r['reviewer']}" if r["reviewer"] else ""))
    print()
    _print_model_text(r["review_md"])
    return 0


def cmd_compile_approve(args) -> int:
    """The human gate. Approval RE-validates both documents at decision
    time, then lands the rulebook (via case_store's single write path)
    and the play. Anything invalid at this moment is refused, whatever
    the staging said."""
    with session() as s:
        row = _repo.compilation_for_approval(s.cur, s.ph, args.compile_id)
        if not row:
            print(f"no compilation {args.compile_id!r}", file=sys.stderr)
            return 1
        status = row["status"]
        if status != "hitl_pending":
            print(f"REFUSED: {args.compile_id} is '{status}' — only a "
                  f"pending compilation can be decided", file=sys.stderr)
            return 1
        spec = json.loads(row["rulebook_json"])
        play = json.loads(row["play_json"])
        errs = _compile_validate(spec, play)
        if errs:
            for e in errs:
                print(f"ERROR: {e}", file=sys.stderr)
            print("REFUSED: approval re-validation failed — the stored "
                  "draft is no longer sound; reject it and re-compile",
                  file=sys.stderr)
            return 1
        who = args.as_user or os.environ.get("IOF_REVIEWER") or "cli"
        # Rulebook first (a play without its rulebook is refused elsewhere;
        # the reverse order could strand a live play with no rules).
        from ioagentfarm.tools import case_store
        from ioagentfarm.tools.casetier import rulebook as _rb
        with _case_session() as cs:
            # A draft that renames its states is approvable and still
            # strands every case open under the revision it replaces.
            stranded = _rb.cases_a_revision_strands(cs.cur, cs.ph, spec)
            rev = case_store.save_rulebook(cs.cur, cs.ph, spec, who)
        _upsert_play(play, status=args.status, verb="approved+saved")
        _repo.approve_compilation(s.cur, s.ph, args.compile_id, who,
                                  args.reason or "")
    print(f"approved {args.compile_id} by {who}: rulebook "
          f"{spec['template_id']} rev {rev} + play {play['play_id']} "
          f"status={args.status} — live, no code change")
    _rb.warn_about_stranded_cases(stranded, spec["template_id"], rev)
    return 0


def cmd_compile_reject(args) -> int:
    with session() as s:
        row = _repo.compilation_status(s.cur, s.ph, args.compile_id)
        if not row:
            print(f"no compilation {args.compile_id!r}", file=sys.stderr)
            return 1
        if row["status"] != "hitl_pending":
            print(f"REFUSED: {args.compile_id} is '{row['status']}'",
                  file=sys.stderr)
            return 1
        who = args.as_user or os.environ.get("IOF_REVIEWER") or "cli"
        _repo.reject_compilation(s.cur, s.ph, args.compile_id, who,
                                 args.reason or "")
    print(f"rejected {args.compile_id} by {who} — nothing reached the "
          f"catalog" + (f" ({args.reason})" if args.reason else ""))
    return 0


_OSVAC_PLAY = {
    "play_id": "PLAY-OSVAC-001",
    "name": "OS Vacancy During Roster Check",
    "trigger_type": "Coverage Assignment Not Available",
    "goal": "Restore field coverage for every vacant territory: escalate "
            "DM -> Field Ops -> AA with the defined windows, and close or "
            "snooze each territory per policy.",
    "policy": {
        # CASE-species play: executed by the case tier (iof-case), one case
        # per territory, rulebook TPL-OS-VACANCY (R01-R12).
        "species": "case",
        "template": "TPL-OS-VACANCY",
        "trigger_synonyms": ["OS Vacancy", "vacant territory",
                             "open seat vacancy", "no coverage assigned"],
        "owner_role": "DM", "cc_role": "RBC",
        "escalation_role": "Field Ops", "admin_role": "AA",
        "owner_sla_days": 2, "extension_sla_days": 4,
        "escalation_sla_days": 2, "snooze_days": 30,
        "sla_authority": "the monitoring process owns every clock; never "
                         "decide a breach yourself",
        "no_data_behavior": "stop the engagement and report the named reason",
    },
    "workflow_generate": "case_action",
    "workflow_deliver": None,
    "params_needed": ["group_ref", "territories"],
    "body_md": """# Playbook: OS Vacancy During Roster Check

## Goal
Restore field coverage for every vacant territory; escalate respectfully
through DM -> Field Ops -> AA with defined windows; know when to stop.

## Trigger Information
Trigger Type: Coverage Assignment Not Available
Detection Signal: vacant OS territories detected during roster/coverage checks

## Operational Rules
- If SLA is there in the step then only create monitoring task.
- After SLA monitoring assignment task, strictly wait for the monitoring
  process to reply before proceeding as per workflow sequence.
- Do not set or decide the SLA breach time unless the monitoring process
  explicitly tells you.

## Resolution Workflow (runs as rulebook TPL-OS-VACANCY, one case/territory)
1. If DM details are present: notify DM to assign coverage (RBC in CC),
   create monitoring task. SLA: 2 business days. [R01]
   If no DM details: notify Field Ops directly. [R02]
2. Backfill input during a DM window: extend the SLA to 4 business days,
   monitoring task. [R03/R05]
3. DM window expires without assignment: send reminder to DM (RBC in CC),
   new 2-business-day window. [R04]
4. Reminder window expires: notify Field Ops (RBC in CC), 2-business-day
   window. [R06] Field Ops window expires: reminder to Field Ops. [R07]
5. Field Ops reminder expires: notify AA directly and exclusively for
   manual intervention; territory snoozes 30 days. [R08]
6. OS assigned/available at ANY step: close the territory's case
   immediately. [R09]
7. Dismiss input from DM or Field Ops at any step: snooze 30 days. [R10]
8. System-level error at any step: error email to AA, snooze 30 days. [R11]
9. Snooze expires: stop (close). [R12]
""",
}


def cmd_seed_summary(args) -> int:
    _upsert_play(_SUMMARY_PLAY)
    return 0


def cmd_seed_brand(args) -> int:
    _upsert_play(_BRAND_PLAY)
    return 0


def cmd_seed_os_vacancy(args) -> int:
    _upsert_play(_OSVAC_PLAY)
    return 0


# ------------------------------------------------------------------ reads
#
# Rows come back as dicts through `casetier.store._rows` on BOTH drivers.
# The copy that lived here zipped column names over each row - which, on
# the Postgres adapter's dict rows, iterates the KEYS and corrupts every
# value (`iof-plays status` died with KeyError: 0 on RDS, 2026-08-25).

def cmd_list(args) -> int:
    with session() as s:
        rows = _repo.list_plays(s.cur, s.ph)
    if getattr(args, "out", ""):
        # THE COMPILER MAPS AGAINST THIS TOO. A parent playbook that
        # branches ("the barrier type determines which team reviews it")
        # compiles to an `open_play` action naming a CHILD play - and until
        # this file rode beside the workflow and deliveries catalogs, the
        # installed plays were invisible to the match step, so composition
        # could only be mapped to a play id the model remembered or made up.
        # Only operational plays are listed: a draft or retired play is
        # refused at delivery, so offering it to the matcher would compile
        # in a refusal.
        ops = [r for r in rows if r.get("status") == "operational"]
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps({"plays": ops}, indent=2),
                       encoding="utf-8")
        print(f"wrote {args.out} - {len(ops)} operational play(s)")
        return 0
    if args.json:
        print(json.dumps({"playbooks": rows}, indent=2))
    else:
        for r in rows:
            print(f"{r['play_id']}  v{r['version']}  [{r['status']}]  "
                  f"{r['name']}  (trigger: {r['trigger_type']})")
        if not rows:
            print("no playbooks — run seed-summary / seed-brand-campaign")
    return 0


def cmd_show(args) -> int:
    with session() as s:
        r = _repo.get_play(s.cur, s.ph, args.play_id)
    if not r:
        print(f"no playbook {args.play_id!r}", file=sys.stderr)
        return 1
    r["policy"] = json.loads(r.pop("policy_json"))
    print(json.dumps(r, indent=2))
    return 0


def cmd_match(args) -> int:
    """Deterministic trigger match over trigger_type PLUS each play's
    declared trigger_synonyms (case-insensitive substring). Exactly ONE
    match wins; several matches return `ambiguous` with the candidates —
    the caller must ask, never guess: with hundreds of plays, silently
    picking the first would execute the wrong governed procedure
    perfectly. Zero matches return the known triggers so an LLM caller
    can restate the user's paraphrase as a canonical phrase and re-run —
    the RESOLUTION stays deterministic and recorded."""
    text = (args.trigger or "").lower()
    with session() as s:
        rows = _repo.operational_plays(s.cur, s.ph)
    hits = []
    for r in rows:
        policy = json.loads(r["policy_json"])
        phrases = [r["trigger_type"]] + list(
            policy.get("trigger_synonyms", []))
        hit = next((p for p in phrases if p and p.lower() in text), None)
        if hit:
            hits.append((r, policy, hit))
    if len(hits) == 1:
        r, policy, hit = hits[0]
        r.pop("policy_json")
        out = {"matched": True, **r, "policy": policy,
               "matched_on": hit,
               "params_needed": policy.get("params_needed", [])}
        print(json.dumps(out, indent=2))
        return 0
    if len(hits) > 1:
        print(json.dumps({
            "matched": False, "ambiguous": True,
            "candidates": [{"play_id": r["play_id"], "name": r["name"],
                            "trigger_type": r["trigger_type"],
                            "matched_on": hit}
                           for r, _, hit in hits],
            "resolution": "the trigger text names more than one play — "
                          "ask the requester which applies; never pick "
                          "one silently"}, indent=2))
        return 0
    known = [r["trigger_type"] for r in rows]
    out = {"matched": False, "known_triggers": known, "recorded": False}
    if not getattr(args, "no_record", False):
        out["recorded"] = True
        out["times_asked"] = _record_unmatched(
            args.trigger or "", known, getattr(args, "requester", "") or "")
    print(json.dumps(out, indent=2))
    return 0


#: Platform machinery a rulebook action must never commission: the
#: compiler itself, and the action workflow that would be commissioning.
_NOT_COMMISSIONABLE = frozenset({"playbook_compile", "case_action"})


def cmd_workflows(args) -> int:
    """The workflows a playbook may commission, with their descriptions -
    the catalog `playbook_compile` is handed by its deterministic first
    step, so the compiler maps "run the share analysis" to a workflow that
    EXISTS and never invents one. The same resolver `put` refuses against,
    so what the compiler is offered is exactly what would install."""
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    import yaml
    ws = _workspace() or None
    loader = WorkflowLoader()
    try:
        declared = declared_workflows(ws)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    out = []
    for name in sorted(_resolvable_workflows(ws)):
        if name in _NOT_COMMISSIONABLE:
            continue
        desc = ""
        try:
            d = loader._workflow_dir(name)
            if d is not None:
                doc = yaml.safe_load(
                    (d / "workflow.yaml").read_text(encoding="utf-8")) or {}
                desc = " ".join(str(doc.get("description") or "").split())
        except Exception:       # noqa: BLE001 - a description is a courtesy
            desc = ""
        if not desc and name in declared:
            # A declared-only workflow has no workflow.yaml on this host;
            # its description is the declaration's - that text is what the
            # compiler matches against, so it is not optional courtesy here.
            desc = " ".join(declared[name].split())
        out.append({"name": name, "description": desc})
    payload = {"workspace": ws, "workflows": out}
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(payload, indent=2),
                                  encoding="utf-8")
    if args.json or args.out:
        print(json.dumps(payload, indent=2))
        return 0
    if not out:
        print("no commissionable workflows resolve here")
        return 0
    for w in out:
        print(f"{w['name']:<28} {w['description'][:90]}")
    return 0


def _record_unmatched(text: str, known: list[str], requester: str) -> int:
    """Write the request that no play covered, and return how many times
    this text (case-insensitive) has now been asked in this scope. Its own
    connection: the caller has already closed the read."""
    with session() as s:
        _repo.insert_unmatched(s.cur, s.ph, text, json.dumps(known),
                               requester or None)
        return _repo.count_unmatched_text(s.cur, s.ph, text.lower())


def cmd_unmatched(args) -> int:
    """What was asked for and not covered, grouped by text, most asked
    first. This list is the natural input to the next `playbook_compile`:
    the Meta Agent could say what it CAN do and never what it was asked
    for, because the miss was discarded at the moment it appeared."""
    with session() as s:
        rows = _repo.unmatched_grouped(s.cur, s.ph, int(args.limit))
    if args.json:
        print(json.dumps({"unmatched": rows}, indent=2))
        return 0
    if not rows:
        print("no unmatched requests recorded")
        return 0
    print(f"{'times':>5}  {'last asked':<19}  request")
    for r in rows:
        print(f"{r['times']:>5}  {r['last_at']:<19}  {r['text']}")
    return 0


# ------------------------------------------------------- pipeline helpers

def cmd_prep_brands(args) -> int:
    trigger = Path(args.trigger_file)
    if not trigger.is_file():
        print(f"trigger file not found: {trigger}", file=sys.stderr)
        return 1
    data = json.loads(trigger.read_text(encoding="utf-8"))
    brands = [b.strip().upper() for b in data.get("brands", []) if b.strip()]
    if not brands:
        print(f"trigger file has no brands: {trigger}", file=sys.stderr)
        return 1
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    manifest = {"stories": [{"id": b} for b in brands], "source": str(trigger)}
    (out / "brand_manifest.json").write_text(json.dumps(manifest, indent=2),
                                             encoding="utf-8")
    print(f"STATUS: done")
    print(f"OUTPUT: {len(brands)} brand(s) fanned out: {', '.join(brands)}")
    return 0


def cmd_stage(args) -> int:
    """Fail-closed staging. Refuses: missing files, empty summary, a verdict
    that is not compliant. Success = hitl_pending row + staging_receipt.json."""
    summary_p, verdict_p = Path(args.summary), Path(args.verdict)
    checks = [(summary_p, "summary"), (verdict_p, "verdict")]
    trigger_p = Path(args.trigger) if args.trigger else None
    if trigger_p is not None:
        checks.append((trigger_p, "trigger"))
    for p, label in checks:
        if not p.is_file():
            print(f"REFUSED: {label} artifact missing: {p}", file=sys.stderr)
            return 1
    summary = json.loads(summary_p.read_text(encoding="utf-8"))
    verdict = json.loads(verdict_p.read_text(encoding="utf-8"))
    # Trigger metadata may ride the payload itself (plays that have no
    # account/persona shape — e.g. campaign plays).
    trigger = (json.loads(trigger_p.read_text(encoding="utf-8"))
               if trigger_p is not None else
               {k: summary.get(k) for k in ("account_id", "persona", "brands")})
    if not (summary.get("summary") or "").strip():
        print("REFUSED: summary artifact has no 'summary' text", file=sys.stderr)
        return 1
    if verdict.get("compliant") is not True:
        print("REFUSED: compliance verdict is not compliant: "
              f"{verdict.get('critique_reasoning', '')}", file=sys.stderr)
        return 1
    with session(args.out, args.summary) as s:
        ph = s.ph

        def _ins(c, sid):
            _repo.insert_staging(
                c, ph, sid, args.play_id, args.run_id,
                trigger.get("account_id"), trigger.get("persona"),
                json.dumps(trigger.get("brands", [])), json.dumps(summary),
                json.dumps(verdict), "hitl_pending")

        staging_id = _insert_with_fresh_id(s.cur, _next_staging_id, _ins)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    receipt = {"staging_id": staging_id, "status": "hitl_pending",
               "play_id": args.play_id, "run_id": args.run_id,
               "account_id": trigger.get("account_id"),
               "persona": trigger.get("persona")}
    (out / "staging_receipt.json").write_text(json.dumps(receipt, indent=2),
                                              encoding="utf-8")
    print("STATUS: done")
    print(f"OUTPUT: staged {staging_id} (hitl_pending) — human validation is "
          "the only path to delivery")
    return 0


def cmd_pending(args) -> int:
    with session() as s:
        rows = _repo.pending_stagings(s.cur, s.ph)
    if args.json:
        print(json.dumps({"pending": rows}, indent=2))
    else:
        for r in rows:
            print(f"{r['staging_id']}  {r['play_id']}  acct={r['account_id']} "
                  f"persona={r['persona']}  run={r['run_id']}")
        if not rows:
            print("nothing pending")
    return 0


def _set_status(staging_id: str, expect: str, to: str, reviewer: str,
                reason: str = "", receipt: str = "", root_hint: str = "") -> int:
    with session(root_hint) as s:
        row = _repo.staging_status(s.cur, s.ph, staging_id)
        if not row:
            print(f"no staging {staging_id!r}", file=sys.stderr)
            return 1
        if row["status"] != expect:
            print(f"REFUSED: {staging_id} is '{row['status']}', not "
                  f"'{expect}'", file=sys.stderr)
            return 1
        _repo.set_staging_status(s.cur, s.ph, staging_id, to, reviewer,
                                 reason, receipt)
    print(f"{staging_id} -> {to}" + (f" (by {reviewer})" if reviewer else ""))
    return 0


def cmd_approve(args) -> int:
    return _set_status(args.staging_id, "hitl_pending", "approved",
                       args.reviewer)


def cmd_reject(args) -> int:
    return _set_status(args.staging_id, "hitl_pending", "rejected",
                       args.reviewer, reason=args.reason)


def cmd_route(args) -> int:
    """Deterministic persona -> CRM routing for an APPROVED staging only."""
    m = _STG_RE.search(args.goal or "")
    if not m:
        print("REFUSED: no staging id (STG-XXXX) in the goal text",
              file=sys.stderr)
        return 1
    staging_id = m.group(0)
    with session(args.out) as s:
        row = _repo.staging_for_route(s.cur, s.ph, staging_id)
    if not row:
        print(f"REFUSED: no staging {staging_id!r}", file=sys.stderr)
        return 1
    status, persona, account_id = row["status"], row["persona"], \
        row["account_id"]
    summary_json, brands = row["summary_json"], row["brands"]
    if status != "approved":
        print(f"REFUSED: {staging_id} is '{status}' — only an approved "
              "staging may be routed for delivery", file=sys.stderr)
        return 1
    crm = PERSONA_CRM.get((persona or "").strip().upper())
    if crm is None:
        print(f"REFUSED: unknown persona {persona!r} — no CRM route",
              file=sys.stderr)
        return 1
    summary = json.loads(summary_json)
    routing = {"staging_id": staging_id, "crm": crm, "persona": persona,
               "account_id": account_id, "brands": json.loads(brands or "[]"),
               "reps": summary.get("reps", []),
               "summary": summary.get("summary", "")}
    targets = [Path(args.out)]
    if args.shared:
        targets.append(Path(args.shared))
    for t in targets:
        t.mkdir(parents=True, exist_ok=True)
        (t / "routing.json").write_text(json.dumps(routing, indent=2),
                                        encoding="utf-8")
    print("STATUS: done")
    print(f"OUTPUT: {staging_id} routed — persona {persona} -> {crm}")
    return 0


def cmd_release(args) -> int:
    """Generic approval gate: materialize an APPROVED staging's payload for a
    deliver/publish workflow. No persona routing — the play's own deliver
    steps decide what to do with the payload; this command only enforces that
    a human opened the gate."""
    m = _STG_RE.search(args.goal or "")
    if not m:
        print("REFUSED: no staging id (STG-XXXX) in the goal text",
              file=sys.stderr)
        return 1
    staging_id = m.group(0)
    with session(args.out) as s:
        row = _repo.staging_for_release(s.cur, s.ph, staging_id)
    if not row:
        print(f"REFUSED: no staging {staging_id!r}", file=sys.stderr)
        return 1
    status, play_id, ref = row["status"], row["play_id"], row["account_id"]
    summary_json, verdict_json = row["summary_json"], row["verdict_json"]
    if status != "approved":
        print(f"REFUSED: {staging_id} is '{status}' — only an approved "
              "staging may be released", file=sys.stderr)
        return 1
    release = {"staging_id": staging_id, "play_id": play_id, "ref": ref,
               "payload": json.loads(summary_json),
               "verdict": json.loads(verdict_json)}
    targets = [Path(args.out)]
    if args.shared:
        targets.append(Path(args.shared))
    for t in targets:
        t.mkdir(parents=True, exist_ok=True)
        (t / "release.json").write_text(json.dumps(release, indent=2),
                                        encoding="utf-8")
    print("STATUS: done")
    print(f"OUTPUT: {staging_id} released for delivery (play {play_id})")
    return 0


def cmd_mark_delivered(args) -> int:
    return _set_status(args.staging, "approved", "delivered", "",
                       receipt=args.receipt, root_hint=args.root_hint)


def cmd_status(args) -> int:
    with session() as s:
        plays = _repo.count_operational_plays(s.cur, s.ph)
        stagings = _repo.staging_counts(s.cur, s.ph)
        unmatched = _repo.count_unmatched(s.cur, s.ph)
    out = {"operational_playbooks": plays, "stagings": stagings,
           "unmatched_requests": unmatched}
    print(json.dumps(out, indent=2) if args.json else out)
    return 0


def main(argv: list[str] | None = None) -> int:
    # SURVIVE A LEGACY CONSOLE. The ledger prints DATA - transition
    # details carry whatever the model or a person wrote, and a finding
    # with an arrow in it crashed `iof-case history` outright on a cp1252
    # Windows console (UnicodeEncodeError mid-listing). The build console
    # learned this first; a CLI must degrade a character, never die on it.
    import sys as _sys
    for _stream in (_sys.stdout, _sys.stderr):
        try:
            _stream.reconfigure(errors="replace")
        except (AttributeError, ValueError, OSError):
            pass
    # THE WORKSPACE'S OWN `.env` IS WHERE THE DEPLOYMENT'S SETTINGS LIVE, and
    # this CLI never read it. `aicore` loads it; `iof-consult` loads it; the
    # case tier did not - so anything configured there was simply absent from
    # this process. It cost the one span that answers "which runs did this
    # case cause": `dispatch_pending` calls `case_dispatched`, which asks
    # `otel_export.enabled()`, which reads `OTEL_EXPORTER_OTLP_ENDPOINT` - set
    # in the workspace `.env` and therefore unset here. The runs the
    # dispatcher STARTED were traced (each `aicore run` subprocess loads the
    # file itself), so the backend showed the effects with the cause missing,
    # and nothing anywhere reported a problem. Measured: 0 dispatch spans
    # without this, 1 fully-attributed span with it.
    try:
        import os as _os
        _code = (_os.environ.get("IOF_WORKSPACE") or "").strip()
        if _code:
            from ioagentfarm.engine.workspace_env import load_workspace_env
            load_workspace_env(_code)
    except Exception:  # noqa: BLE001 - configuration is best-effort here
        pass

    p = argparse.ArgumentParser(prog="iof-plays",
                                description="platform play catalog + HITL staging store")
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("seed-summary").set_defaults(func=cmd_seed_summary)
    sub.add_parser("seed-brand-campaign").set_defaults(func=cmd_seed_brand)
    sub.add_parser("seed-os-vacancy").set_defaults(func=cmd_seed_os_vacancy)

    pu = sub.add_parser("put",
                        help="create or amend a play from a JSON document "
                             "— no code, no seed")
    pu.add_argument("--file", required=True)
    pu.add_argument("--status", default="operational",
                    choices=["operational", "draft", "retired"])
    pu.set_defaults(func=cmd_put)

    am = sub.add_parser("amend",
                        help="change a VALUE the play already owns — a "
                             "window, a role, a synonym; never structure")
    am.add_argument("play_id")
    am.add_argument("--set", dest="sets", action="append", default=[],
                    metavar="KEY=VALUE",
                    help="policy value to change (repeatable); the key must "
                         "already exist on the play or in its template's "
                         "default_params")
    am.add_argument("--add-synonym", dest="add_syn", action="append",
                    default=[], metavar="PHRASE")
    am.add_argument("--remove-synonym", dest="rm_syn", action="append",
                    default=[], metavar="PHRASE")
    am.add_argument("--as", dest="as_user", default="")
    am.set_defaults(func=cmd_amend)

    cs = sub.add_parser("compile-stage",
                        help="validate a compiled playbook draft "
                             "(rulebook + play) and stage it for human "
                             "approval")
    cs.add_argument("--source", required=True,
                    help="the business playbook prose (md file)")
    cs.add_argument("--rulebook", required=True)
    cs.add_argument("--play", required=True)
    cs.add_argument("--notes", default="",
                    help="compiler assumptions/notes (md file)")
    cs.add_argument("--requests", default="",
                    help="capability_requests.json (defaults to the one in "
                         "--out when present)")
    cs.add_argument("--map", default="",
                    help="capability_map.json - the match step's semantic "
                         "reading of the source against the catalogs; the "
                         "draft is refused if inconsistent with it "
                         "(defaults to the one in --out when present)")
    cs.add_argument("--run-id", default="")
    cs.add_argument("--out", default="")
    cs.set_defaults(func=cmd_compile_stage)

    tp = sub.add_parser("template",
                        help="the authoring template: what this workspace "
                             "can deliver, in business language, for a "
                             "domain expert to write a playbook into")
    tp.add_argument("--json", action="store_true")
    tp.add_argument("--out", default="", help="also write it to this file")
    tp.set_defaults(func=cmd_template)

    cq = sub.add_parser("capability-requests",
                        help="what playbooks asked for that this workspace "
                             "cannot deliver yet (recorded at compile-stage)")
    cq.add_argument("--json", action="store_true")
    cq.add_argument("--all", action="store_true",
                    help="include resolved ones")
    cq.add_argument("--resolve", default="", help="id to mark resolved")
    cq.add_argument("--as", dest="as_user", default="")
    cq.add_argument("--reason", default="")
    cq.set_defaults(func=cmd_capability_requests)

    cp = sub.add_parser("compile-pending")
    cp.add_argument("--json", action="store_true")
    cp.set_defaults(func=cmd_compile_pending)

    csh = sub.add_parser("compile-show")
    csh.add_argument("compile_id")
    csh.add_argument("--json", action="store_true")
    csh.set_defaults(func=cmd_compile_show)

    ca = sub.add_parser("compile-approve")
    ca.add_argument("compile_id")
    ca.add_argument("--as", dest="as_user", default="")
    ca.add_argument("--reason", default="")
    ca.add_argument("--status", default="operational",
                    choices=["operational", "draft"])
    ca.set_defaults(func=cmd_compile_approve)

    ch = sub.add_parser("compile-history",
                        help="prior compilations of a template/play, with "
                             "each rejection's reason (binding on the next "
                             "draft)")
    ch.add_argument("target", nargs="?", default="",
                    help="template_id or play_id; omitted = every recent "
                         "compilation in the workspace (drafts choose their "
                         "own ids, and a thread looked up by one id misses "
                         "the others' rejections)")
    ch.add_argument("--out", default="",
                    help="write the history here as JSON - what the "
                         "compile pipeline is handed")
    ch.add_argument("--json", action="store_true")
    ch.set_defaults(func=cmd_compile_history)

    cr = sub.add_parser("compile-reject")
    cr.add_argument("compile_id")
    cr.add_argument("--as", dest="as_user", default="")
    cr.add_argument("--reason", default="")
    cr.set_defaults(func=cmd_compile_reject)

    ls = sub.add_parser("list"); ls.add_argument("--json", action="store_true")
    ls.add_argument("--out", default="", help="write the operational-plays "
                    "catalog for the compiler (JSON)")
    ls.set_defaults(func=cmd_list)

    sh = sub.add_parser("show"); sh.add_argument("play_id")
    sh.set_defaults(func=cmd_show)

    ma = sub.add_parser("match")
    ma.add_argument("--trigger", required=True)
    ma.add_argument("--json", action="store_true")
    ma.add_argument("--requester", default="",
                    help="who asked (recorded with a miss; free text)")
    ma.add_argument("--no-record", action="store_true",
                    help="probe only: do not record a miss")
    ma.set_defaults(func=cmd_match)

    wl = sub.add_parser("workflows",
                        help="the workflows a playbook may commission, "
                             "with descriptions (the compiler's catalog)")
    wl.add_argument("--json", action="store_true")
    wl.add_argument("--out", default="",
                    help="also write the catalog to this file")
    wl.set_defaults(func=cmd_workflows)

    un = sub.add_parser("unmatched",
                        help="requests that matched no play, grouped by "
                             "text - the input to the next playbook")
    un.add_argument("--json", action="store_true")
    un.add_argument("--limit", type=int, default=50)
    un.set_defaults(func=cmd_unmatched)

    pb = sub.add_parser("prep-brands")
    pb.add_argument("--trigger-file", required=True)
    pb.add_argument("--out", required=True)
    pb.set_defaults(func=cmd_prep_brands)

    st = sub.add_parser("stage")
    st.add_argument("--summary", required=True)
    st.add_argument("--verdict", required=True)
    st.add_argument("--trigger", default="")
    st.add_argument("--run-id", default="")
    st.add_argument("--play-id", default="PLAY-SUMMARY-001")
    st.add_argument("--out", required=True)
    st.set_defaults(func=cmd_stage)

    pe = sub.add_parser("pending"); pe.add_argument("--json", action="store_true")
    pe.set_defaults(func=cmd_pending)

    ap = sub.add_parser("approve")
    ap.add_argument("staging_id"); ap.add_argument("--as", dest="reviewer",
                                                   required=True)
    ap.set_defaults(func=cmd_approve)

    rj = sub.add_parser("reject")
    rj.add_argument("staging_id"); rj.add_argument("--as", dest="reviewer",
                                                   required=True)
    rj.add_argument("--reason", default="")
    rj.set_defaults(func=cmd_reject)

    ro = sub.add_parser("route")
    ro.add_argument("--goal", required=True)
    ro.add_argument("--out", required=True)
    ro.add_argument("--shared", default="")
    ro.set_defaults(func=cmd_route)

    rl = sub.add_parser("release")
    rl.add_argument("--goal", required=True)
    rl.add_argument("--out", required=True)
    rl.add_argument("--shared", default="")
    rl.set_defaults(func=cmd_release)

    md = sub.add_parser("mark-delivered")
    md.add_argument("--staging", required=True)
    md.add_argument("--receipt", default="")
    md.add_argument("--root-hint", default="",
                    help="any engine path (e.g. the step output dir) used to "
                         "locate the orchestration database when env is stripped")
    md.set_defaults(func=cmd_mark_delivered)

    su = sub.add_parser("status"); su.add_argument("--json", action="store_true")
    su.set_defaults(func=cmd_status)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
