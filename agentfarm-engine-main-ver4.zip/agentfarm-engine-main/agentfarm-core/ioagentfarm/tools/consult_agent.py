"""iof-consult — A2A JSON-RPC client for sub-agent dispatch (parallel fan-out).

Two modes:

  Single-target (A2A):
    iof-consult --url http://localhost:8000/a2a/agent_a \
                --nlq "totals for Mango last 6 months" \
                --output rx_result.json \
                --mode a2a \
                --context-id abc123:agent_a \
                --timeout 300

  Batch (parallel A2A dispatch):
    iof-consult --batch dispatch.json \
                --output results.json \
                --timeout 300

  dispatch.json format:
    [
      {"id": "agent_a", "url": "http://localhost:8000/a2a/agent_a",
       "nlq": "...", "context_id": "hash:agent_a",
       "headers": {"Authorization": "Bearer ${PARTNER_TOKEN}"}},
      ...
    ]

  `headers` is optional, per entry. Values may reference environment
  variables bash-style (${VAR} / ${VAR:-default}); they are expanded HERE at
  dispatch time — never write a resolved token into dispatch.json. A header
  whose variable is unset (and has no default) is dropped with a warning
  rather than sent half-formed ("Bearer " authenticates as nothing and gets
  a confusing 401/403 instead of a diagnosable message).

  results.json format:
    {"results": [
      {"id": "agent_a", "ok": true, "envelope": {...}},
      {"id": "agent_b", "ok": false, "error": "timeout"}
    ]}

Exit 0 always in batch mode (partial failures captured in results.json).
Exit 0/1 in single-target mode.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
from pathlib import Path

# Status lines below print unicode checkmarks (✓/✗). On Windows, stdout's
# default console codepage (cp1252/cp437) raises UnicodeEncodeError on these
# — crashing before results.json is written and forcing the caller into
# repeated retries with chcp/PYTHONIOENCODING workarounds. Force UTF-8 so
# this succeeds regardless of the console codepage.
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


# ---------------------------------------------------------------------------
# Envelope extraction
# ---------------------------------------------------------------------------

_FENCE_RE = re.compile(r"```json\s*\n([\s\S]+?)\n\s*```", re.MULTILINE)


def _traceparent():
    """This process's W3C traceparent (the calling step's, via the SDK or
    the exec env), so the consulted agent's turn is a child of ours."""
    try:
        from ioagentfarm.sdk import obs
        return obs.traceparent()
    except Exception:  # noqa: BLE001
        return os.environ.get("TRACEPARENT") or None


def _extract_envelope(text: str) -> dict | list | None:
    """Extract the first fenced JSON block from agent text response.

    Falls back to parsing the whole text as bare JSON if there's no fenced
    block — a safety net against un-fenced LLM output drift. Result may be
    a dict (v1 envelope agents) or a list (card-array agents like
    agent_a/agent_b, whose real cards document a bare JSON array
    output).
    """
    m = _FENCE_RE.search(text)
    candidate = m.group(1) if m else text.strip()
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        return None


# ---------------------------------------------------------------------------
# A2A JSON-RPC helpers
# ---------------------------------------------------------------------------

_ENV_REF_RE = re.compile(r"\$\{(\w+)(?::-([^}]*))?\}")


def _expand_env_str(value: str) -> str:
    """Expand ${VAR:-default} and ${VAR} bash-style env references in a string."""
    def _sub(m: re.Match) -> str:
        var, default = m.group(1), m.group(2) or ""
        return os.environ.get(var, default)

    return _ENV_REF_RE.sub(_sub, value)


# URLs and header values expand through the same rule; the old name stays as
# the URL call-site spelling.
_expand_url = _expand_env_str


def _expand_headers(headers: dict | None) -> dict:
    """Expand env refs in header VALUES, dropping unresolvable headers loudly.

    A header whose ${VAR} has no value and no default is skipped with a
    stderr warning — sending "Bearer " authenticates as nobody and returns a
    401/403 that reads like a server problem, while the warning names the
    variable to set.
    """
    out: dict = {}
    for key, value in (headers or {}).items():
        value = str(value)
        unset = [m.group(1) for m in _ENV_REF_RE.finditer(value)
                 if m.group(2) is None and m.group(1) not in os.environ]
        if unset:
            print(f"[iof-consult] WARN: header {key!r} references unset env "
                  f"var(s) {', '.join(unset)} - header not sent",
                  file=sys.stderr, flush=True)
            continue
        out[str(key)] = _expand_env_str(value)
    return out


def _build_a2a_request(nlq: str, context_id: str | None) -> dict:
    # A2A v1.0 wire format: PascalCase `SendMessage`, `ROLE_USER`, member-based
    # text part (no `kind`), `contextId` lives INSIDE the message object.
    from uuid import uuid4

    message: dict = {
        "role": "ROLE_USER",
        "parts": [{"text": nlq}],
        "messageId": f"msg-{uuid4().hex[:12]}",
    }
    if context_id:
        message["contextId"] = context_id
    return {"jsonrpc": "2.0", "method": "SendMessage", "id": 1, "params": {"message": message}}


def _extract_a2a_result(response: dict) -> tuple[str, dict | str]:
    """Pull the response artifact from an A2A v1.0 JSON-RPC response.

    Returns ("envelope", dict) when the agent replied with a structured
    DataPart (member `data`), or ("text", str) when it replied with a
    TextPart (e.g. a fenced ```json block). v1.0 wraps the Task under
    `result.task`; we fall back to bare `result` for resilience.
    """
    result = response.get("result") or {}
    task = result.get("task") or result
    artifacts = task.get("artifacts") or []
    text = ""
    for artifact in artifacts:
        for part in artifact.get("parts") or []:
            if isinstance(part.get("data"), dict):
                return ("envelope", part["data"])
            if isinstance(part.get("text"), str) and part["text"]:
                text = part["text"]
    return ("text", text)


# ---------------------------------------------------------------------------
# Single-target dispatch
# ---------------------------------------------------------------------------

async def _dispatch_one_a2a(
    url: str,
    nlq: str,
    context_id: str | None,
    timeout: float,
    headers: dict | None = None,
) -> dict:
    """Call one A2A sub-agent. Returns {'ok': bool, 'envelope': dict | None, 'error': str | None}."""
    url = _expand_url(url)
    import httpx

    body = _build_a2a_request(nlq, context_id)
    # Caller headers (auth for external agents) layer OVER the base pair —
    # values env-expanded at send time so tokens never sit in dispatch.json.
    send_headers = {"Content-Type": "application/json", "A2A-Version": "1.0"}
    _tp = _traceparent()
    if _tp:
        send_headers["traceparent"] = _tp   # the callee's turn joins this trace
    send_headers.update(_expand_headers(headers))
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                url,
                json=body,
                # A2A-Version is required by spec-strict external agents — some
                # reject the request as "version 0.3" without it (default assumed
                # when the header is absent).
                headers=send_headers,
            )
    except httpx.TimeoutException as exc:
        return {"ok": False, "envelope": None, "error": f"Timeout after {timeout}s: {exc}"}
    except httpx.HTTPError as exc:
        return {"ok": False, "envelope": None, "error": f"HTTP error: {exc}"}
    except Exception as exc:
        return {"ok": False, "envelope": None, "error": f"Unexpected: {exc}"}

    if resp.status_code != 200:
        return {"ok": False, "envelope": None, "error": f"HTTP {resp.status_code}: {resp.text[:300]}"}

    try:
        rpc_resp = resp.json()
    except Exception as exc:
        return {"ok": False, "envelope": None, "error": f"Invalid JSON response: {exc}"}

    if "error" in rpc_resp:
        err = rpc_resp["error"]
        return {"ok": False, "envelope": None, "error": f"JSON-RPC error {err.get('code')}: {err.get('message')}"}

    kind, payload = _extract_a2a_result(rpc_resp)
    if kind == "envelope":
        # Agent replied with a structured DataPart — the envelope is the data.
        return {"ok": True, "envelope": payload, "error": None}

    text = payload
    if not text:
        return {"ok": False, "envelope": None, "error": "No artifact in A2A response"}

    envelope = _extract_envelope(text)
    if envelope is None:
        return {"ok": False, "envelope": None, "error": f"No fenced JSON block in agent response: {text[:200]}"}

    return {"ok": True, "envelope": envelope, "error": None}


def _dispatch_rest(url: str, nlq: str, timeout: float, out_path: Path) -> None:
    """Legacy REST mode — POST {'nlq': nlq}, write raw response JSON."""
    import httpx

    try:
        with httpx.Client(timeout=timeout) as client:
            resp = client.post(url, json={"nlq": nlq}, headers={"Content-Type": "application/json"})
    except httpx.TimeoutException as exc:
        _fail(out_path, f"Timeout after {timeout}s calling {url}: {exc}", rest=True)
    except httpx.HTTPError as exc:
        _fail(out_path, f"HTTP error calling {url}: {exc}", rest=True)
    except Exception as exc:
        _fail(out_path, f"Unexpected error: {exc}", rest=True)

    if resp.status_code != 200:
        _fail(out_path, f"Domain engine returned HTTP {resp.status_code}: {resp.text[:500]}", rest=True)

    try:
        data = resp.json()
    except Exception as exc:
        _fail(out_path, f"Invalid JSON from domain engine: {exc}", rest=True)

    out_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[iof-consult] {url} -> {len(data.get('rows', []))} rows -> {out_path}", flush=True)
    sys.exit(0)


# ---------------------------------------------------------------------------
# Batch dispatch
# ---------------------------------------------------------------------------

def _restore_registry_headers(dispatch: list[dict]) -> None:
    """Fill missing auth headers from the workspace's external-agent registry.

    The dispatch file is authored by an LLM following the a2a_consult skill,
    and models sometimes omit the catalog entry's ``headers`` — observed
    live: the same swarm's supply-watch consult 401'd or succeeded depending
    on whether that copy happened. Auth must not depend on transcription
    luck: for any entry with NO headers whose ``id`` (or exact ``url``)
    matches a registered external agent that HAS headers, the registry's
    headers are restored. Entries that carry their own headers are never
    touched, and everything here is best-effort — outside a workspace this
    is a no-op.
    """
    if not any(isinstance(e, dict) and not e.get("headers") for e in dispatch):
        return
    code = os.environ.get("IOF_WORKSPACE", "").strip()
    try:
        from ioagentfarm.engine.a2a_registry import read_external_agents
        registered = read_external_agents(code or None)
    except Exception:
        return
    by_name = {a.get("name"): a for a in registered if a.get("headers")}
    by_url = {a.get("a2a_url"): a for a in registered if a.get("headers")}
    for entry in dispatch:
        if not isinstance(entry, dict) or entry.get("headers"):
            continue
        match = by_name.get(entry.get("id")) or by_url.get(entry.get("url"))
        if match:
            entry["headers"] = dict(match["headers"])
            print(f"[iof-consult] restored auth headers for "
                  f"{entry.get('id')!r} from the workspace registry",
                  file=sys.stderr, flush=True)


async def _dispatch_batch(dispatch: list[dict], timeout: float, out_path: Path) -> None:
    """Run all entries in dispatch list concurrently.

    Per-agent result files are written immediately when each sub-agent responds:
      <out_dir>/<id>_result.json  — written as soon as that agent completes
      <out_path>                  — combined {"results": [...]} written when ALL complete
    """
    out_dir = out_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)

    async def _run_one(entry: dict) -> dict:
        result = await _dispatch_one_a2a(
            url=entry["url"],
            nlq=entry["nlq"],
            context_id=entry.get("context_id"),
            timeout=timeout,
            headers=entry.get("headers"),
        )
        combined_entry = {"id": entry["id"], **result}
        # Write per-agent file immediately so the orchestrator agent can stream progress as responses arrive
        per_agent_path = out_dir / f"{entry['id']}_result.json"
        per_agent_path.write_text(
            json.dumps(combined_entry, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        status = "✓" if result["ok"] else "✗"
        rows = 0
        if result["ok"] and result.get("envelope"):
            env = result["envelope"]
            if isinstance(env, list):
                rows = len(env)  # bare array of insight cards - one "row" per card
            elif isinstance(env, dict):
                rows = len((env.get("data") or {}).get("rows") or [])
        print(f"[iof-consult] [{entry['id']}] {status} {rows} rows -> {per_agent_path}", flush=True)
        return combined_entry

    results = await asyncio.gather(*[_run_one(e) for e in dispatch], return_exceptions=False)

    combined = {"results": list(results)}
    out_path.write_text(json.dumps(combined, ensure_ascii=False, indent=2), encoding="utf-8")

    ok_count = sum(1 for r in results if r.get("ok"))
    print(
        f"[iof-consult] batch: {ok_count}/{len(results)} OK -> {out_path}",
        flush=True,
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="iof-consult",
        description="Dispatch sub-queries to A2A agents (parallel fan-out) or legacy REST.",
    )

    # Mutually exclusive: single-target vs batch
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--url", help="Single sub-agent A2A endpoint URL (or legacy REST URL)")
    group.add_argument("--batch", metavar="DISPATCH_FILE", help="Path to dispatch.json for parallel batch mode")

    parser.add_argument("--nlq", help="Natural language query (required for single-target mode)")
    parser.add_argument("--nlq-file", dest="nlq_file", help="Path to a file containing the NLQ (alternative to --nlq; avoids shell-escaping issues with large JSON payloads)")
    parser.add_argument("--output", required=True, help="Path to write the response JSON")
    parser.add_argument(
        "--mode",
        choices=["a2a", "rest"],
        default="a2a",
        help="Protocol: a2a (JSON-RPC 2.0, default) or rest (legacy domain engine)",
    )
    parser.add_argument("--context-id", dest="context_id", help="A2A contextId for multi-turn session continuity")
    parser.add_argument(
        "--header",
        action="append",
        default=[],
        metavar="'K: V'",
        help="HTTP header for the target (repeatable; 'K: V' or K=V). Values "
             "may reference env vars as ${VAR} / ${VAR:-default} - expanded "
             "at send time, so tokens stay out of shell history and files. "
             "Single-target mode only; batch entries carry their own "
             "'headers' object.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=300.0,
        help="HTTP timeout in seconds per call (default: 300)",
    )
    args = parser.parse_args()

    # An agent's exec subprocess is stripped to {HOME, LANG, TERM} + the
    # allowlisted keys — IOF_WORKSPACE passes through, arbitrary token vars do
    # not. Loading the workspace's own .env here is what makes ${VAR} refs in
    # headers resolvable from inside a step. Best-effort: this binary must
    # keep working outside any workspace.
    ws_code = os.environ.get("IOF_WORKSPACE", "").strip()
    if ws_code:
        try:
            from ioagentfarm.engine.workspace_env import load_workspace_env
            load_workspace_env(ws_code)
        except Exception:
            pass

    cli_headers: dict = {}
    for raw in args.header:
        # Whichever separator appears FIRST wins — presence-based preference
        # for ":" mis-split K=V headers whose VALUE contains a colon
        # (`X-Callback=https://…`, `Auth=Bearer ${VAR:-x}`), turning the key
        # into `X-Callback=https`. Header names cannot contain ":" or "=",
        # so the first occurrence of either is always the separator.
        found = [(i, s) for i, s in ((raw.find(":"), ":"), (raw.find("="), "="))
                 if i >= 0]
        sep = min(found)[1] if found else None
        key, _, value = raw.partition(sep) if sep else (raw, "", "")
        if not sep or not key.strip():
            parser.error(f"--header expects 'K: V' or K=V (got {raw!r})")
        cli_headers[key.strip()] = value.strip()

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import httpx  # noqa: F401
    except ImportError:
        _fail(out_path, "httpx not installed — run: pip install httpx")

    # ---- Batch mode --------------------------------------------------------
    if args.batch:
        batch_path = Path(args.batch)
        if not batch_path.exists():
            _fail(out_path, f"Dispatch file not found: {batch_path}")
        try:
            # utf-8-sig: identical to utf-8 for BOM-less files, and accepts
            # the BOM PowerShell's `Out-File -Encoding utf8` prepends — a
            # Windows-authored dispatch file must not kill the whole batch.
            dispatch = json.loads(batch_path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            _fail(out_path, f"Invalid dispatch.json: {exc}")
        if not isinstance(dispatch, list) or not dispatch:
            _fail(out_path, "dispatch.json must be a non-empty JSON array")

        _restore_registry_headers(dispatch)
        asyncio.run(_dispatch_batch(dispatch, args.timeout, out_path))
        sys.exit(0)

    # ---- Single-target mode ------------------------------------------------
    if args.nlq_file:
        try:
            args.nlq = Path(args.nlq_file).read_text(encoding="utf-8")
        except Exception as exc:
            parser.error(f"Cannot read --nlq-file: {exc}")
    if not args.nlq:
        parser.error("--nlq or --nlq-file is required when using --url")

    if args.mode == "rest":
        _dispatch_rest(args.url, args.nlq, args.timeout, out_path)
        return  # _dispatch_rest calls sys.exit internally

    # A2A single-target
    result = asyncio.run(
        _dispatch_one_a2a(args.url, args.nlq, args.context_id, args.timeout,
                          headers=cli_headers or None)
    )

    if not result["ok"]:
        _fail(out_path, result["error"])

    out_path.write_text(
        json.dumps(result["envelope"], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    envelope = result["envelope"]
    if isinstance(envelope, list):
        rows = len(envelope)
    elif isinstance(envelope, dict):
        rows = len((envelope.get("data") or {}).get("rows") or [])
    else:
        rows = 0
    print(f"[iof-consult] {args.url} -> {rows} rows -> {out_path}", flush=True)
    sys.exit(0)


def _fail(out_path: Path, message: str, rest: bool = False) -> None:
    if rest:
        payload = {"error": "consult_failed", "message": message, "columns": [], "rows": [], "row_count": 0, "caveats": [message]}
    else:
        payload = {"error": "consult_failed", "message": message, "ok": False}
    try:
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    print(f"[iof-consult] ERROR: {message}", file=sys.stderr, flush=True)
    sys.exit(1)


if __name__ == "__main__":
    main()
