"""iof-run-audit - deterministic run-forensics analytics for agentfarm runs.

Answers cost/health/behaviour questions about workflow runs from three
existing deterministic sources - NO LLM calls, NO raw session dumps:

1. ``.iof/instances/<run_id>/usage.jsonl`` - one line per LLM call, written
   by the ``apply_usage_capture`` iobot hook.  Keys: ``t`` (epoch), ``iter``,
   ``session``, ``in``, ``out``, ``cr`` (cache read), ``cw`` (cache write).
   CRITICAL SEMANTICS: ``in`` is INCLUSIVE of ``cr`` + ``cw``.
     true total   = in + out
     uncached in  = in - cr - cw
   Provider note: on Anthropic-compatible providers (MiniMax, Claude) both
   ``cr`` and ``cw`` are populated; on OpenAI-compatible providers (Azure
   OpenAI client deployments) only a normalised ``cached_tokens`` maps into
   ``cr`` and ``cw`` is always 0.  Missing keys are treated as 0 everywhere.

2. ``.iof/instances/<run_id>/forensics/attempts/<step>.<n>/`` - per-attempt
   blobs: ``exit.json`` (duration_s), ``session-snapshot.jsonl`` (dialog -
   read ONLY to derive compact counters, never echoed), ``stall_attempt_<i>/``
   (preserved Fix-6 auto-retry blobs).

3. The IOF store DB (``IOF_DATABASE_URL``; read-only SELECTs) - runs/steps
   status + attempts.  Every subcommand degrades gracefully to
   filesystem-only mode when the DB is unreachable.

Subcommands (each prints a human markdown report; ``--json`` for machines):

  summary      --run-id R              per-session + per-step cost table
  bottlenecks  --run-id R [--top N]    top token/duration/retry offenders
  spirals      --run-id R              rogue/spiral flags with evidence
  budget       --run-id R [--total-limit N] [--per-step-limit N]
  cost         --run-id R [...] [--card NAME] [--*-rate overrides]
               dollar what-if re-pricing via run_audit_price_cards.yaml;
               repeat --run-id for a lifecycle total
  compare      --run-id A --run-id B   per-stage regression deltas
  list-runs    [--limit N]             recent runs with totals

Billed-equivalent estimate = uncached + 0.1*cache_read + 1.25*cache_write
+ out.  The weights are Anthropic-style cache pricing - the figure is a
PROVIDER-DEPENDENT ESTIMATE and is omitted when the provider reports no
cache split at all.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# .env loading - same chain as all iof-* tools
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv

    load_dotenv(override=False)
    # AMBIENT FILES MAY SUPPLY CREDENTIALS, NEVER A STATE ROOT.
    # `~/.iobot/.env` is one of the three ambient files the CLI deliberately
    # stopped reading, and this tool still read it - so on a machine that had
    # ever served another deployment, `iof-run-audit` inherited that
    # deployment's IOF_ROOT and reported `run dir not found: <a path from
    # somewhere else>` for a run sitting in the current folder. Worse, the
    # same file commonly holds a production database URL.
    #
    # The env recovery itself must stay: the agent runtime strips an exec'd
    # subprocess to HOME/LANG/TERM, so without it every agent tool call
    # starts unconfigured. What is dropped is the ONE key that decides which
    # deployment's state this tool reads.
    from ioagentfarm.engine.home_env import home_env_candidates
    _root_before = os.environ.get("IOF_ROOT")
    for _candidate in home_env_candidates():
        if _candidate.exists():
            load_dotenv(_candidate, override=False)
    if _root_before is None and os.environ.get("IOF_ROOT") is not None:
        del os.environ["IOF_ROOT"]
    # dev/editable install: the repo root (which holds .env + .iof) is an
    # ancestor of this file — covers agent exec calls whose cwd is the agent
    # WORKSPACE (e.g. Jarvis), not the project dir.
    for _parent in Path(__file__).resolve().parents:
        if (_parent / ".env").exists():
            load_dotenv(_parent / ".env", override=False)
            break
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Roots + benchmarks
# ---------------------------------------------------------------------------
def _root() -> Path:
    """Resolve the .iof state root, robust to agent-workspace CWDs.

    Order: ./".iof" -> $IOF_ROOT -> first ``.iof`` dir found walking up from
    the installed package (editable/dev repo root). Always-on agents (Jarvis)
    exec tools from ``~/.iobot/agents/<role>/workspace`` with a stripped
    env, so the relative default never resolves there — the package-ancestor
    walk does.

    **A `.iof` IN THE CURRENT DIRECTORY WINS over the environment**, which is
    the reverse of what it was. A state root is a fact about WHERE YOU ARE,
    and an inherited one silently answers about a different deployment: a
    validator standing in a workspace whose run had just finished was told
    `run dir not found` and given a path belonging to another install.
    """
    cwd_iof = Path(".iof")
    if cwd_iof.is_dir():
        return cwd_iof.resolve()
    env_root = os.getenv("IOF_ROOT")
    if env_root:
        return Path(env_root).resolve()
    for parent in Path(__file__).resolve().parents:
        cand = parent / ".iof"
        if cand.is_dir():
            return cand
    return cwd_iof.resolve()


def _run_dir(run_id: str) -> Path:
    return _root() / "instances" / run_id


def _load_benchmarks() -> Dict[str, Any]:
    """Load the checked-in benchmarks file (per-workflow expected totals)."""
    p = Path(__file__).parent / "run_audit_benchmarks.yaml"
    try:
        import yaml

        with open(p, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return data
    except Exception:
        return {}


def _bm_default(bm: Dict[str, Any], key: str, fallback: Any) -> Any:
    return (bm.get("defaults") or {}).get(key, fallback)


# ---------------------------------------------------------------------------
# usage.jsonl
# ---------------------------------------------------------------------------
def load_usage(run_id: str) -> List[Dict[str, Any]]:
    """Read usage.jsonl rows.  Malformed lines skipped; missing cr/cw -> 0."""
    path = _run_dir(run_id) / "usage.jsonl"
    rows: List[Dict[str, Any]] = []
    if not path.is_file():
        return rows
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            rows.append(
                {
                    "t": float(d.get("t", 0) or 0),
                    "iter": d.get("iter"),
                    "session": str(d.get("session") or "?"),
                    "in": int(d.get("in", 0) or 0),
                    "out": int(d.get("out", 0) or 0),
                    "cr": int(d.get("cr", 0) or 0),
                    "cw": int(d.get("cw", 0) or 0),
                }
            )
    return rows


def parse_step_key(session: str, run_id: str) -> str:
    """``iof:<run_id>:<step_key>:u:<user>`` -> ``<step_key>``.

    step_key itself may contain colons (``story:G01:discover``,
    ``orchestrate:c0``), so strip the fixed prefix and the ``:u:`` suffix
    rather than splitting blindly.
    """
    s = session or "?"
    prefix = f"iof:{run_id}:"
    if s.startswith(prefix):
        s = s[len(prefix):]
    if ":u:" in s:
        s = s.split(":u:", 1)[0]
    return s or session


def stage_of(step_key: str) -> str:
    """Normalise a step key to a comparable stage name.

    orchestrate / orchestrate:cN -> orchestrate;
    story:<id>:<suffix> -> story:*:<suffix>; anything else unchanged.
    """
    if step_key == "orchestrate" or step_key.startswith("orchestrate:"):
        return "orchestrate"
    if step_key.startswith("story:"):
        parts = step_key.split(":")
        if len(parts) >= 3:
            return f"story:*:{parts[-1]}"
    return step_key


def aggregate_sessions(rows: List[Dict[str, Any]], run_id: str) -> "OrderedDict[str, Dict[str, Any]]":
    """Per-session (= per step_key) aggregation, insertion-ordered."""
    agg: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
    for r in rows:
        key = parse_step_key(r["session"], run_id)
        a = agg.setdefault(
            key,
            {"calls": 0, "in": 0, "out": 0, "cr": 0, "cw": 0, "max_in": 0,
             "first_t": r["t"], "last_t": r["t"]},
        )
        a["calls"] += 1
        a["in"] += r["in"]
        a["out"] += r["out"]
        a["cr"] += r["cr"]
        a["cw"] += r["cw"]
        a["max_in"] = max(a["max_in"], r["in"])
        a["first_t"] = min(a["first_t"], r["t"])
        a["last_t"] = max(a["last_t"], r["t"])
    for a in agg.values():
        a["uncached"] = a["in"] - a["cr"] - a["cw"]
        a["total"] = a["in"] + a["out"]
    return agg


def totals_of(agg: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    t = {"calls": 0, "in": 0, "out": 0, "cr": 0, "cw": 0, "max_in": 0}
    for a in agg.values():
        for k in ("calls", "in", "out", "cr", "cw"):
            t[k] += a[k]
        t["max_in"] = max(t["max_in"], a["max_in"])
    t["uncached"] = t["in"] - t["cr"] - t["cw"]
    t["total"] = t["in"] + t["out"]
    return t


def billed_equivalent(t: Dict[str, Any]) -> Optional[int]:
    """Anthropic-style cache-priced estimate; None when no cache split exists."""
    if (t["cr"] + t["cw"]) <= 0:
        return None
    return int(round(t["uncached"] + 0.1 * t["cr"] + 1.25 * t["cw"] + t["out"]))


BILLED_NOTE = (
    "billed-equivalent = uncached + 0.1*cache_read + 1.25*cache_write + out "
    "(Anthropic-style cache pricing weights; provider-dependent ESTIMATE)"
)
NO_CACHE_NOTE = (
    "provider reported no cache split (cr/cw all 0) - billed-equivalent "
    "estimate omitted; total = in + out"
)


# ---------------------------------------------------------------------------
# Workflow snapshot budgets ("Target budget: **12 tool calls**")
# ---------------------------------------------------------------------------
_BUDGET_RE = re.compile(r"target budget[^\n]*", re.IGNORECASE)


def _budget_from_md(md_path: Path) -> Optional[int]:
    try:
        text = md_path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None
    m = _BUDGET_RE.search(text)
    if not m:
        return None
    nums = [int(n) for n in re.findall(r"\d+", m.group(0))]
    return max(nums) if nums else None


def load_budgets(run_id: str) -> Dict[str, Any]:
    """Parse the run's workflow SNAPSHOT for declared per-step call budgets.

    Returns {"steps": {step_key: budget}, "suffixes": {key_suffix: budget},
             "workflow_name": str}.
    """
    wf_dir = _run_dir(run_id) / "workflow"
    out: Dict[str, Any] = {"steps": {}, "suffixes": {}, "workflow_name": ""}
    wf_yaml = wf_dir / "workflow.yaml"
    if not wf_yaml.is_file():
        return out
    try:
        import yaml

        wf = yaml.safe_load(wf_yaml.read_text(encoding="utf-8", errors="replace")) or {}
    except Exception:
        return out
    out["workflow_name"] = str(wf.get("name") or "")
    for step in wf.get("steps") or []:
        key = step.get("key")
        prompt = step.get("prompt")
        if key and prompt:
            b = _budget_from_md(wf_dir / prompt)
            if b:
                out["steps"][key] = b
        for sub in step.get("per_item_steps") or []:
            suffix = sub.get("key_suffix")
            sprompt = sub.get("prompt")
            if suffix and sprompt:
                b = _budget_from_md(wf_dir / sprompt)
                if b:
                    out["suffixes"][suffix] = b
    return out


def budget_for(step_key: str, budgets: Dict[str, Any], bm: Dict[str, Any]) -> Tuple[Optional[int], str]:
    """(budget, source) for a step key; orchestrate budget comes from benchmarks.

    Only per-cycle orchestrator sessions (``orchestrate:cN``, stateless Alex)
    get the per-cycle budget; a bare monolithic ``orchestrate`` session
    (pre-cycle runs) spans the whole pipeline and has no meaningful per-cycle
    budget.
    """
    if step_key.startswith("orchestrate:"):
        return (
            int(_bm_default(bm, "orchestrate_calls_per_cycle", 15)),
            "benchmarks: orchestrate_calls_per_cycle",
        )
    if step_key == "orchestrate":
        return None, ""
    if step_key in budgets["steps"]:
        return budgets["steps"][step_key], "step prompt"
    if step_key.startswith("story:"):
        suffix = step_key.split(":")[-1]
        if suffix in budgets["suffixes"]:
            return budgets["suffixes"][suffix], "step prompt (per-item)"
    return None, ""


# ---------------------------------------------------------------------------
# Forensics attempts (exit.json, stall dirs, session-snapshot counters)
# ---------------------------------------------------------------------------
def _attempts_root(run_id: str) -> Path:
    return _run_dir(run_id) / "forensics" / "attempts"


def step_dir_prefix(step_key: str) -> str:
    return step_key.replace(":", "_")


def attempt_dirs_for(run_id: str, step_key: str) -> List[Tuple[int, Path]]:
    """Sorted [(attempt_n, dir)] for a step key."""
    root = _attempts_root(run_id)
    prefix = step_dir_prefix(step_key)
    found: List[Tuple[int, Path]] = []
    if not root.is_dir():
        return found
    for d in root.iterdir():
        if not d.is_dir():
            continue
        name = d.name
        if not name.startswith(prefix + "."):
            continue
        tail = name[len(prefix) + 1:]
        if tail.isdigit():
            found.append((int(tail), d))
    return sorted(found)


def all_attempt_dirs(run_id: str) -> List[Tuple[str, int, Path]]:
    """[(step_dirname, attempt_n, dir)] for every attempt dir in the run."""
    root = _attempts_root(run_id)
    out: List[Tuple[str, int, Path]] = []
    if not root.is_dir():
        return out
    for d in sorted(root.iterdir()):
        if not d.is_dir() or "." not in d.name:
            continue
        stem, _, tail = d.name.rpartition(".")
        if tail.isdigit():
            out.append((stem, int(tail), d))
    return out


def read_exit(d: Path) -> Dict[str, Any]:
    try:
        return json.loads((d / "exit.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def stall_dirs(d: Path) -> List[Path]:
    return sorted(p for p in d.glob("stall_attempt_*") if p.is_dir())


def failure_reason(session_snapshot: Path) -> Optional[str]:
    """Deterministic failure classification via the engine's own parser."""
    try:
        from ioagentfarm.engine.forensics import parse_session_failure

        info = parse_session_failure(session_snapshot)
        return info["reason"] if info else None
    except Exception:
        return None


# Tools whose consecutive streaks indicate re-derivation instead of trusting
# precomputed slices/manifests.
_REDERIVE_TOOLS = ("read_file", "exec:iof-query")

_SHELL_NOISE = {"cd", "export", "set", "source", "echo", "pushd"}


def _effective_exec_tool(cmd: str) -> str:
    """Real tool behind an exec command: skip ``cd X &&`` / env-var prefixes.

    ``cd /run && iof-query -f q.sql`` -> ``iof-query``;
    ``FOO=1 python x.py`` -> ``python``.
    """
    if not cmd:
        return "?"
    for seg in re.split(r"&&|;|\|\|", cmd):
        toks = seg.strip().split()
        # drop leading VAR=value env assignments
        while toks and "=" in toks[0] and not toks[0].startswith(("-", "/")):
            toks = toks[1:]
        if not toks:
            continue
        head = Path(toks[0]).name
        if head.lower() in _SHELL_NOISE:
            continue
        return head
    return Path(cmd.split()[0]).name


def snapshot_counters(path: Path) -> Dict[str, Any]:
    """Compact behavioural counters from a session snapshot.

    Reads the dialog line-by-line and keeps ONLY counters - the raw dialog is
    never returned (context-blowout guard).
    """
    c: Dict[str, Any] = {
        "assistant_turns": 0,
        "tool_calls": 0,
        "no_text_tool_turns": 0,
        "validator_rejects": 0,
        "max_same_tool_streak": 0,
        "max_same_tool_name": "",
        "max_rederive_streak": 0,
        "top_tools": [],
    }
    if not path.is_file():
        return c
    tool_counts: Counter = Counter()
    cur_tool, cur_streak = None, 0
    rederive_streak = 0
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                role = obj.get("role")
                if role == "assistant":
                    c["assistant_turns"] += 1
                    tcs = obj.get("tool_calls") or []
                    text = (obj.get("content") or "").strip()
                    if tcs and not text:
                        c["no_text_tool_turns"] += 1
                    for tc in tcs:
                        fn = (tc.get("function") or {})
                        name = fn.get("name") or "?"
                        eff = name
                        if name == "exec":
                            try:
                                args = json.loads(fn.get("arguments") or "{}")
                                cmd = str(args.get("command") or "").strip()
                                eff = "exec:" + _effective_exec_tool(cmd)
                            except Exception:
                                eff = "exec:?"
                        tool_counts[eff] += 1
                        c["tool_calls"] += 1
                        if eff == cur_tool:
                            cur_streak += 1
                        else:
                            cur_tool, cur_streak = eff, 1
                        if cur_streak > c["max_same_tool_streak"]:
                            c["max_same_tool_streak"] = cur_streak
                            c["max_same_tool_name"] = eff
                        if eff in _REDERIVE_TOOLS or eff.startswith("exec:iof-query"):
                            rederive_streak += 1
                            c["max_rederive_streak"] = max(c["max_rederive_streak"], rederive_streak)
                        else:
                            rederive_streak = 0
                elif role == "tool":
                    content = obj.get("content")
                    if isinstance(content, str):
                        low = content.lower()
                        if (
                            '"success": false' in low
                            or '"valid": false' in low
                            or '"status": "rejected"' in low
                            or "validation failed" in low
                            or "rejected:" in low
                            or "refused" in low
                        ):
                            c["validator_rejects"] += 1
    except Exception:
        pass
    c["top_tools"] = [f"{k} x{v}" for k, v in tool_counts.most_common(3)]
    return c


# ---------------------------------------------------------------------------
# Store DB (read-only, fail-soft)
# ---------------------------------------------------------------------------
def try_store():
    """(store, error).  Read-only SELECT usage; no schema init is performed."""
    try:
        os.environ.setdefault("IOF_PG_POOL_MIN", "1")
        os.environ.setdefault("IOF_PG_CONNECT_TIMEOUT", "8")
        from ioagentfarm.engine.db import make_adapter
        from ioagentfarm.engine.store import Store

        db_url = os.getenv("IOF_DATABASE_URL", "")
        if not db_url:
            db_url = f"sqlite:///{_root() / 'state.db'}"
        return Store(make_adapter(db_url)), None
    except Exception as e:  # pragma: no cover - env-dependent
        return None, f"{type(e).__name__}: {e}"


def db_steps(run_id: str) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    store, err = try_store()
    if store is None:
        return [], err
    try:
        return store.list_steps(run_id), None
    except Exception as e:
        return [], f"{type(e).__name__}: {str(e)[:120]}"


def db_run(run_id: str) -> Optional[Dict[str, Any]]:
    store, _ = try_store()
    if store is None:
        return None
    try:
        return store.get_run(run_id)
    except Exception:
        return None


def db_runs(limit: int) -> Dict[str, Dict[str, Any]]:
    store, _ = try_store()
    if store is None:
        return {}
    try:
        return {r["id"]: r for r in store.list_runs(limit=limit)}
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# Rendering helpers
# ---------------------------------------------------------------------------
def fmt(n: Any) -> str:
    if isinstance(n, (int, float)) and not isinstance(n, bool):
        return f"{int(n):,}"
    return str(n)


def md_table(headers: List[str], rows: List[List[Any]]) -> str:
    lines = ["| " + " | ".join(headers) + " |",
             "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        lines.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(lines)


def _echo(s: str = "") -> None:
    print(s)


def _die(msg: str) -> None:
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(1)


def _require_usage(run_id: str) -> List[Dict[str, Any]]:
    if not _run_dir(run_id).is_dir():
        _die(f"run dir not found: {_run_dir(run_id)}")
    rows = load_usage(run_id)
    if not rows:
        _die(
            f"no usage.jsonl for {run_id} (runs before the usage-capture "
            "hook have none)"
        )
    return rows


# ---------------------------------------------------------------------------
# Retry / stall inventory (shared by bottlenecks + spirals)
# ---------------------------------------------------------------------------
def retry_inventory(run_id: str, agg: Dict[str, Dict[str, Any]], rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Per step with >1 attempts or stall dirs: reasons + estimated retry cost."""
    out: List[Dict[str, Any]] = []
    seen: set = set()
    for step_key in list(agg.keys()):
        if step_key.startswith("orchestrate"):
            continue
        dirs = attempt_dirs_for(run_id, step_key)
        if not dirs:
            continue
        seen.add(step_dir_prefix(step_key))
        stalls: List[str] = []
        for _, d in dirs:
            for sd in stall_dirs(d):
                reason = failure_reason(sd / "session-snapshot.jsonl") or "unclassified"
                stalls.append(reason)
        entry: Dict[str, Any] = {
            "step_key": step_key,
            "attempts": len(dirs),
            "stall_retries": len(stalls),
            "stall_reasons": stalls,
            "attempt_fail_reasons": [],
            "retry_cost_tokens": 0,
        }
        if len(dirs) > 1:
            # failure reason of every non-final attempt
            for n, d in dirs[:-1]:
                reason = failure_reason(d / "session-snapshot.jsonl") or "unclassified"
                entry["attempt_fail_reasons"].append(f"attempt {n}: {reason}")
        if len(dirs) > 1 or stalls:
            # Retry cost, call-exact: every agent (re)spawn resets ``iter`` to
            # 0 in usage.jsonl, so tokens in every window AFTER the first
            # spawn are re-work caused by step retries / Fix-6 auto-retries.
            sess_rows = [r for r in rows
                         if parse_step_key(r["session"], run_id) == step_key]
            resets = [i for i, r in enumerate(sess_rows) if r.get("iter") == 0 or r.get("iter") == 0.0]
            if len(resets) > 1:
                entry["retry_cost_tokens"] = sum(
                    r["in"] + r["out"] for r in sess_rows[resets[1]:])
        if entry["attempts"] > 1 or entry["stall_retries"] > 0:
            out.append(entry)
    # attempt dirs with no usage session (e.g. failed before any LLM call)
    for stem, n, d in all_attempt_dirs(run_id):
        if stem in seen:
            continue
        seen.add(stem)
        dirs = [t for t in all_attempt_dirs(run_id) if t[0] == stem]
        stalls = [sd for _, _, dd in dirs for sd in stall_dirs(dd)]
        if len(dirs) > 1 or stalls:
            out.append({
                "step_key": stem, "attempts": len(dirs),
                "stall_retries": len(stalls),
                "stall_reasons": [], "attempt_fail_reasons": [],
                "retry_cost_tokens": 0,
            })
    return out


# ---------------------------------------------------------------------------
# summary
# ---------------------------------------------------------------------------
def cmd_summary(args: argparse.Namespace) -> None:
    run_id = args.run_id
    rows = _require_usage(run_id)
    agg = aggregate_sessions(rows, run_id)
    tot = totals_of(agg)
    est = billed_equivalent(tot)

    steps, db_err = db_steps(run_id)
    step_rows: List[Dict[str, Any]] = []
    for s in steps:
        dirs = attempt_dirs_for(run_id, s["step_key"])
        dur = 0.0
        stalls = 0
        for _, d in dirs:
            dur += float(read_exit(d).get("duration_s") or 0)
            stalls += len(stall_dirs(d))
            for sd in stall_dirs(d):
                dur += float(read_exit(sd).get("duration_s") or 0)
        step_rows.append({
            "step_key": s["step_key"], "role": s["role"], "status": s["status"],
            "attempt": s["attempt"], "max_attempts": s["max_attempts"],
            "duration_s": round(dur, 1), "stall_retries": stalls,
        })

    stages: "OrderedDict[str, Dict[str, int]]" = OrderedDict()
    for k, v in agg.items():
        s = stages.setdefault(stage_of(k), {"sessions": 0, "calls": 0, "total": 0})
        s["sessions"] += 1
        s["calls"] += v["calls"]
        s["total"] += v["total"]

    payload = {
        "run_id": run_id,
        "totals": {**tot, "billed_equivalent_est": est,
                   "billed_note": BILLED_NOTE if est is not None else NO_CACHE_NOTE},
        "stages": [{"stage": k, **v} for k, v in
                   sorted(stages.items(), key=lambda kv: -kv[1]["total"])],
        "sessions": [
            {"session": k, **{x: v[x] for x in ("calls", "in", "out", "cr", "cw", "uncached", "total", "max_in")}}
            for k, v in agg.items()
        ],
        "steps": step_rows,
        "db": "ok" if not db_err and steps else (db_err or "no step rows"),
        "semantics": "in is INCLUSIVE of cr+cw; total = in + out; uncached = in - cr - cw",
    }
    if args.json:
        _echo(json.dumps(payload, indent=2))
        return

    _echo(f"# Run audit summary - {run_id}\n")
    _echo("## Per-stage rollup\n")
    _echo(md_table(
        ["stage", "sessions", "calls", "total(in+out)"],
        [[k, v["sessions"], v["calls"], fmt(v["total"])]
         for k, v in sorted(stages.items(), key=lambda kv: -kv[1]["total"])]))
    _echo()
    _echo("## Per-session token usage (session = step key)\n")
    sess_rows = [
        [k, v["calls"], fmt(v["total"]), fmt(v["in"]), fmt(v["out"]),
         fmt(v["cr"]), fmt(v["cw"]), fmt(v["uncached"]), fmt(v["max_in"])]
        for k, v in sorted(agg.items(), key=lambda kv: -kv[1]["total"])
    ]
    _echo(md_table(
        ["session", "calls", "total(in+out)", "in", "out", "cache_read",
         "cache_write", "uncached_in", "max_in/call"],
        sess_rows))
    _echo()
    if step_rows:
        _echo("## Steps (store DB + forensics)\n")
        _echo(md_table(
            ["step", "role", "status", "attempt", "duration_s", "stall_retries"],
            [[s["step_key"], s["role"], s["status"],
              f'{s["attempt"]}/{s["max_attempts"]}', s["duration_s"],
              s["stall_retries"]] for s in step_rows]))
        _echo()
    elif db_err:
        _echo(f"_step table unavailable (DB: {db_err}) - token data above is filesystem-truth_\n")
    _echo("## Run totals\n")
    _echo(f"- LLM calls: {fmt(tot['calls'])}")
    _echo(f"- total tokens (in+out): {fmt(tot['total'])}   [in is inclusive of cache read+write]")
    _echo(f"- input: {fmt(tot['in'])} = {fmt(tot['uncached'])} uncached + {fmt(tot['cr'])} cache-read + {fmt(tot['cw'])} cache-write")
    _echo(f"- output: {fmt(tot['out'])}")
    _echo(f"- max context on a single call: {fmt(tot['max_in'])}")
    if est is not None:
        _echo(f"- billed-equivalent ESTIMATE: {fmt(est)}   ({BILLED_NOTE})")
    else:
        _echo(f"- {NO_CACHE_NOTE}")


# ---------------------------------------------------------------------------
# bottlenecks
# ---------------------------------------------------------------------------
def cmd_bottlenecks(args: argparse.Namespace) -> None:
    run_id = args.run_id
    top_n = args.top
    rows = _require_usage(run_id)
    agg = aggregate_sessions(rows, run_id)
    tot = totals_of(agg)

    top_sessions = sorted(agg.items(), key=lambda kv: -kv[1]["total"])[:top_n]
    durations = []
    for stem, n, d in all_attempt_dirs(run_id):
        ex = read_exit(d)
        if ex.get("duration_s") is not None:
            durations.append((f"{stem}.{n}", float(ex["duration_s"]), len(stall_dirs(d))))
    durations.sort(key=lambda x: -x[1])
    retries = retry_inventory(run_id, agg, rows)
    cache_share = []
    for k, v in agg.items():
        if v["calls"] >= 3 and v["in"] > 0 and (v["cr"] + v["cw"]) > 0:
            cache_share.append((k, v["cw"] / v["in"], v["cw"], v["calls"]))
    cache_share.sort(key=lambda x: -x[1])

    payload = {
        "run_id": run_id,
        "top_sessions_by_tokens": [
            {"session": k, "calls": v["calls"], "total": v["total"],
             "out": v["out"], "max_in": v["max_in"]}
            for k, v in top_sessions
        ],
        "top_steps_by_duration": [
            {"attempt": a, "duration_s": round(dur, 1), "stall_retries": st}
            for a, dur, st in durations[:top_n]
        ],
        "retries": retries,
        "cache_write_share": [
            {"session": k, "cw_share_of_in": round(sh, 3), "cache_write": cw, "calls": c}
            for k, sh, cw, c in cache_share[:top_n]
        ],
        "max_context_per_call": tot["max_in"],
    }
    if args.json:
        _echo(json.dumps(payload, indent=2))
        return

    _echo(f"# Bottlenecks - {run_id}\n")
    _echo(f"## Top {len(top_sessions)} sessions by tokens\n")
    _echo(md_table(
        ["session", "calls", "total(in+out)", "out", "max_in/call"],
        [[k, v["calls"], fmt(v["total"]), fmt(v["out"]), fmt(v["max_in"])]
         for k, v in top_sessions]))
    _echo()
    if durations:
        _echo(f"## Top steps by duration\n")
        _echo(md_table(
            ["step.attempt", "duration_s", "stall_retries"],
            [[a, round(dur, 1), st] for a, dur, st in durations[:top_n]]))
        _echo()
    if retries:
        _echo("## Retry / stall events\n")
        for r in retries:
            bits = [f"{r['attempts']} attempt(s)", f"{r['stall_retries']} stall auto-retr{'y' if r['stall_retries']==1 else 'ies'}"]
            if r["attempt_fail_reasons"]:
                bits.append("; ".join(r["attempt_fail_reasons"]))
            if r["stall_reasons"]:
                bits.append("stall reasons: " + ", ".join(r["stall_reasons"]))
            if r["retry_cost_tokens"]:
                bits.append(f"retry cost ~{fmt(r['retry_cost_tokens'])} tokens")
            _echo(f"- {r['step_key']} - " + "; ".join(bits))
        _echo()
    else:
        _echo("## Retry / stall events\n\n- none detected\n")
    if cache_share:
        _echo("## Cache-write share per session (TTL-expiry waste indicator)\n")
        _echo(md_table(
            ["session", "cache_write/in", "cache_write", "calls"],
            [[k, f"{sh:.1%}", fmt(cw), c] for k, sh, cw, c in cache_share[:top_n]]))
        _echo()
    _echo(f"Max context on a single call: {fmt(tot['max_in'])} tokens")


# ---------------------------------------------------------------------------
# spirals
# ---------------------------------------------------------------------------
def cmd_spirals(args: argparse.Namespace) -> None:
    run_id = args.run_id
    rows = _require_usage(run_id)
    agg = aggregate_sessions(rows, run_id)
    budgets = load_budgets(run_id)
    bm = _load_benchmarks()
    overrun_ratio = float(_bm_default(bm, "overrun_call_ratio", 1.5))
    streak_flag = int(_bm_default(bm, "streak_flag_threshold", 5))
    notext_flag = int(_bm_default(bm, "no_text_flag_threshold", 5))

    flags: List[Dict[str, Any]] = []
    for step_key, v in agg.items():
        budget, src = budget_for(step_key, budgets, bm)
        evidence: List[str] = []
        kinds: List[str] = []
        if budget and v["calls"] > budget * overrun_ratio:
            kinds.append("BUDGET_OVERRUN")
            evidence.append(
                f"{v['calls']} calls vs budget {budget} "
                f"({v['calls'] / budget:.1f}x; {src})"
            )
        counters = None
        dirs = attempt_dirs_for(run_id, step_key)
        if dirs:
            best = {"max_same_tool_streak": 0, "max_rederive_streak": 0,
                    "no_text_tool_turns": 0, "validator_rejects": 0,
                    "tool_calls": 0, "top_tools": [], "max_same_tool_name": ""}
            for _, d in dirs:
                c = snapshot_counters(d / "session-snapshot.jsonl")
                if c["max_rederive_streak"] > best["max_rederive_streak"]:
                    best["max_rederive_streak"] = c["max_rederive_streak"]
                if c["max_same_tool_streak"] > best["max_same_tool_streak"]:
                    best["max_same_tool_streak"] = c["max_same_tool_streak"]
                    best["max_same_tool_name"] = c["max_same_tool_name"]
                best["no_text_tool_turns"] += c["no_text_tool_turns"]
                best["validator_rejects"] += c["validator_rejects"]
                best["tool_calls"] += c["tool_calls"]
                if c["top_tools"]:
                    best["top_tools"] = c["top_tools"]
            counters = best
            if best["max_rederive_streak"] > streak_flag:
                kinds.append("REDERIVE_STREAK")
                evidence.append(
                    f"{best['max_rederive_streak']}-call read/query streak "
                    "(re-deriving instead of trusting slices/manifests; "
                    f"top tools: {', '.join(best['top_tools'])})"
                )
            elif best["max_same_tool_streak"] > streak_flag:
                kinds.append("SAME_TOOL_STREAK")
                evidence.append(
                    f"{best['max_same_tool_streak']} consecutive "
                    f"{best['max_same_tool_name']} calls"
                )
            if best["no_text_tool_turns"] >= notext_flag:
                kinds.append("NO_TEXT_TURNS")
                evidence.append(
                    f"{best['no_text_tool_turns']} tool-call turns without "
                    "leading text (stream-consumer risk)"
                )
            if best["validator_rejects"] >= 2:
                kinds.append("VALIDATOR_REJECTS")
                evidence.append(
                    f"{best['validator_rejects']} validator/store reject "
                    "markers in tool results (heuristic count)"
                )
        if kinds:
            flags.append({
                "session": step_key, "kinds": kinds, "calls": v["calls"],
                "budget": budget, "tokens": v["total"],
                "evidence": "; ".join(evidence),
                "counters": counters,
            })

    retries = retry_inventory(run_id, agg, rows)
    retry_flags = []
    for r in retries:
        if r["attempts"] > 1:
            bits = "; ".join(r["attempt_fail_reasons"]) or "reason unclassified"
            cost = f"; retry cost ~{fmt(r['retry_cost_tokens'])} tokens" if r["retry_cost_tokens"] else ""
            retry_flags.append({
                "session": r["step_key"], "kinds": ["STEP_RETRY"],
                "evidence": f"{r['attempts']} attempts ({bits}){cost}",
            })
        elif r["stall_retries"]:
            retry_flags.append({
                "session": r["step_key"], "kinds": ["STALL_AUTORETRY"],
                "evidence": (
                    f"{r['stall_retries']} Fix-6 auto-retr{'y' if r['stall_retries']==1 else 'ies'}"
                    + (f" ({', '.join(r['stall_reasons'])})" if r["stall_reasons"] else "")
                ),
            })

    payload = {"run_id": run_id, "spiral_flags": flags, "retry_flags": retry_flags,
               "thresholds": {"overrun_call_ratio": overrun_ratio,
                              "streak_flag_threshold": streak_flag,
                              "no_text_flag_threshold": notext_flag}}
    if args.json:
        for f in payload["spiral_flags"]:
            f.pop("counters", None)
        _echo(json.dumps(payload, indent=2))
        return

    _echo(f"# Spiral / rogue-behaviour audit - {run_id}\n")
    if not flags and not retry_flags:
        _echo("No spiral flags. All sessions within declared budgets and "
              "behavioural thresholds.")
        return
    if flags:
        _echo("## Spiral flags\n")
        for f in flags:
            _echo(f"- [{'/'.join(f['kinds'])}] {f['session']} - {f['evidence']} "
                  f"(session total {fmt(f['tokens'])} tokens)")
        _echo()
    if retry_flags:
        _echo("## Retry flags\n")
        for f in retry_flags:
            _echo(f"- [{'/'.join(f['kinds'])}] {f['session']} - {f['evidence']}")


# ---------------------------------------------------------------------------
# budget
# ---------------------------------------------------------------------------
def cmd_budget(args: argparse.Namespace) -> None:
    run_id = args.run_id
    rows = _require_usage(run_id)
    agg = aggregate_sessions(rows, run_id)
    tot = totals_of(agg)
    budgets = load_budgets(run_id)
    bm = _load_benchmarks()
    tolerance = float(_bm_default(bm, "total_tolerance_ratio", 1.3))
    overrun_ratio = float(_bm_default(bm, "overrun_call_ratio", 1.5))
    wf_name = budgets["workflow_name"] or "?"

    expected: Optional[int] = None
    profile = ""
    wf_bm = (bm.get("workflows") or {}).get(wf_name) or {}
    if args.total_limit:
        expected = args.total_limit
        profile = "--total-limit"
    elif "expected_total_tokens" in wf_bm:
        expected = int(wf_bm["expected_total_tokens"])
        profile = "benchmark"
    elif "profiles" in wf_bm:
        story_sessions = sum(1 for k in agg if k.startswith("story:"))
        thresh = int(_bm_default(bm, "fresh_story_threshold", 6))
        profile = "fresh" if story_sessions > thresh else "incremental"
        prof = (wf_bm["profiles"] or {}).get(profile) or {}
        if "expected_total_tokens" in prof:
            expected = int(prof["expected_total_tokens"])

    total_flag = None
    if expected:
        limit = int(expected * tolerance) if profile != "--total-limit" else expected
        total_flag = {
            "expected": expected, "limit": limit, "actual": tot["total"],
            "profile": profile, "overrun": tot["total"] > limit,
        }

    per_step_flags = []
    for step_key, v in agg.items():
        if args.per_step_limit:
            limit, src = args.per_step_limit, "--per-step-limit"
            over = v["calls"] > limit
            ratio_txt = f"{v['calls']}/{limit}"
        else:
            b, src = budget_for(step_key, budgets, bm)
            if not b:
                continue
            limit = b
            over = v["calls"] > b * overrun_ratio
            ratio_txt = f"{v['calls']} vs budget {b} ({v['calls']/b:.1f}x)"
        if over:
            per_step_flags.append({
                "session": step_key, "calls": v["calls"], "limit": limit,
                "source": src, "tokens": v["total"], "detail": ratio_txt,
            })

    payload = {
        "run_id": run_id, "workflow": wf_name,
        "provider_note": bm.get("provider_note", ""),
        "total": total_flag or {"actual": tot["total"], "expected": None,
                                "note": "no benchmark for this workflow; pass --total-limit"},
        "per_step_overruns": per_step_flags,
    }
    if args.json:
        _echo(json.dumps(payload, indent=2))
        return

    _echo(f"# Budget audit - {run_id} (workflow: {wf_name})\n")
    if total_flag:
        verdict = "OVERRUN" if total_flag["overrun"] else "PASS"
        _echo(f"- Run total: {fmt(tot['total'])} tokens vs "
              f"{fmt(total_flag['limit'])} limit "
              f"(expected ~{fmt(expected)}, profile: {profile}) -> **{verdict}**")
    else:
        _echo(f"- Run total: {fmt(tot['total'])} tokens - no benchmark for "
              f"workflow '{wf_name}'; pass --total-limit to enforce one")
    if bm.get("provider_note"):
        _echo(f"- Note: {bm['provider_note']}")
    _echo()
    if per_step_flags:
        _echo("## Per-step call-budget overruns\n")
        for f in per_step_flags:
            _echo(f"- [OVERRUN] {f['session']} - {f['detail']} "
                  f"({fmt(f['tokens'])} tokens; budget source: {f['source']})")
    else:
        _echo("## Per-step call-budget overruns\n\n- none")


# ---------------------------------------------------------------------------
# cost
# ---------------------------------------------------------------------------
def _load_price_cards() -> Dict[str, Any]:
    p = Path(__file__).parent / "run_audit_price_cards.yaml"
    try:
        import yaml

        with open(p, "r", encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}
    except Exception:
        return {}


def cmd_cost(args: argparse.Namespace) -> None:
    run_ids = args.run_id or []
    if not run_ids:
        _die("cost needs at least one --run-id")
    cards_cfg = _load_price_cards()
    card_name = args.card or cards_cfg.get("default_card") or "opus-4.8"
    card = (cards_cfg.get("cards") or {}).get(card_name)
    if card is None and not (args.in_rate is not None and args.out_rate is not None):
        known = ", ".join(sorted((cards_cfg.get("cards") or {}).keys()))
        _die(f"unknown price card '{card_name}' (known: {known}); "
             "or pass --in-rate/--out-rate overrides")
    per_m = (card or {}).get("per_million") or {}

    # Resolve rates: CLI overrides > card values > null-fallbacks.
    in_rate = args.in_rate if args.in_rate is not None else per_m.get("input")
    out_rate = args.out_rate if args.out_rate is not None else per_m.get("output")
    if in_rate is None or out_rate is None:
        _die(f"price card '{card_name}' has no input/output rates set "
             "(placeholder card?) - fill run_audit_price_cards.yaml or pass "
             "--in-rate/--out-rate")
    cr_rate = args.cache_read_rate if args.cache_read_rate is not None else per_m.get("cache_read")
    cw_rate = args.cache_write_rate if args.cache_write_rate is not None else per_m.get("cache_write")
    # Null semantics: unpriced cache tiers bill at the input rate
    # (Azure/OpenAI-style: cached-input discount optional, no cache-write premium).
    cr_fallback = cr_rate is None
    cw_fallback = cw_rate is None
    if cr_fallback:
        cr_rate = in_rate
    if cw_fallback:
        cw_rate = in_rate
    overridden = any(x is not None for x in
                     (args.in_rate, args.out_rate, args.cache_read_rate, args.cache_write_rate))

    runs_out: List[Dict[str, Any]] = []
    life = {"calls": 0, "in": 0, "out": 0, "cr": 0, "cw": 0, "uncached": 0,
            "total": 0, "cost": 0.0, "c_unc": 0.0, "c_cr": 0.0, "c_cw": 0.0, "c_out": 0.0}
    for rid in run_ids:
        rows = _require_usage(rid)
        tot = totals_of(aggregate_sessions(rows, rid))
        c_unc = tot["uncached"] / 1e6 * in_rate
        c_cr = tot["cr"] / 1e6 * cr_rate
        c_cw = tot["cw"] / 1e6 * cw_rate
        c_out = tot["out"] / 1e6 * out_rate
        cost = c_unc + c_cr + c_cw + c_out
        runs_out.append({
            "run_id": rid, **{k: tot[k] for k in ("calls", "in", "out", "cr", "cw", "uncached", "total")},
            "cost_uncached_input": round(c_unc, 4), "cost_cache_read": round(c_cr, 4),
            "cost_cache_write": round(c_cw, 4), "cost_output": round(c_out, 4),
            "cost_total_usd": round(cost, 2),
            "no_cache_split": (tot["cr"] + tot["cw"]) == 0,
        })
        for k in ("calls", "in", "out", "cr", "cw", "uncached", "total"):
            life[k] += tot[k]
        life["cost"] += cost
        life["c_unc"] += c_unc; life["c_cr"] += c_cr
        life["c_cw"] += c_cw; life["c_out"] += c_out

    rates_used = {"input": in_rate, "output": out_rate,
                  "cache_read": cr_rate, "cache_write": cw_rate,
                  "cache_read_billed_at_input_rate": cr_fallback,
                  "cache_write_billed_at_input_rate": cw_fallback}
    payload = {
        "card": card_name if card else None,
        "card_description": (card or {}).get("description"),
        "card_source": (card or {}).get("source"),
        "card_as_of": (card or {}).get("as_of"),
        "rates_overridden": overridden,
        "rates_per_million_usd": rates_used,
        "runs": runs_out,
        "lifecycle_total_usd": round(life["cost"], 2),
        "note": ("Deterministic re-pricing of recorded token usage at the card's "
                 "rates - a what-if figure, not a provider invoice."),
    }
    if args.json:
        _echo(json.dumps(payload, indent=2))
        return

    title = card_name if card else "custom rates"
    _echo(f"# Cost audit - card: {title}" + (" (with CLI rate overrides)" if overridden else ""))
    if card:
        _echo(f"_{card.get('description', '')} - source: {card.get('source', '?')}, "
              f"as of {card.get('as_of', '?')}_")
    _echo(f"_Rates USD/M tokens: input {in_rate}, output {out_rate}, "
          f"cache-read {cr_rate}{' (=input rate; card has none)' if cr_fallback else ''}, "
          f"cache-write {cw_rate}{' (=input rate; card has none)' if cw_fallback else ''}_\n")
    _echo(md_table(
        ["run_id", "calls", "uncached_in", "cache_read", "cache_write", "out",
         "$ uncached", "$ cache_rd", "$ cache_wr", "$ out", "$ TOTAL"],
        [[r["run_id"], r["calls"], fmt(r["uncached"]), fmt(r["cr"]), fmt(r["cw"]),
          fmt(r["out"]), f"{r['cost_uncached_input']:.2f}", f"{r['cost_cache_read']:.2f}",
          f"{r['cost_cache_write']:.2f}", f"{r['cost_output']:.2f}",
          f"{r['cost_total_usd']:.2f}"] for r in runs_out]
        + ([["LIFECYCLE TOTAL", life["calls"], fmt(life["uncached"]), fmt(life["cr"]),
             fmt(life["cw"]), fmt(life["out"]), f"{life['c_unc']:.2f}",
             f"{life['c_cr']:.2f}", f"{life['c_cw']:.2f}", f"{life['c_out']:.2f}",
             f"{life['cost']:.2f}"]] if len(runs_out) > 1 else [])))
    for r in runs_out:
        if r["no_cache_split"]:
            _echo(f"\nNote: {r['run_id']} has no cache split reported (cr/cw all 0) "
                  "- its entire input is billed at the input rate.")
    _echo(f"\nThis is a what-if re-pricing of recorded usage at the stated rates, "
          "not a provider invoice.")


# ---------------------------------------------------------------------------
# compare
# ---------------------------------------------------------------------------
def cmd_compare(args: argparse.Namespace) -> None:
    run_ids = args.run_id or []
    if len(run_ids) != 2:
        _die("compare needs exactly two --run-id values (A then B)")
    a_id, b_id = run_ids
    a_rows, b_rows = _require_usage(a_id), _require_usage(b_id)
    bm = _load_benchmarks()
    reg_ratio = float(_bm_default(bm, "regression_ratio", 1.25))
    reg_abs = int(_bm_default(bm, "regression_min_tokens", 50000))

    def stage_agg(rows: List[Dict[str, Any]], rid: str) -> Dict[str, Dict[str, int]]:
        st: Dict[str, Dict[str, int]] = {}
        for k, v in aggregate_sessions(rows, rid).items():
            s = st.setdefault(stage_of(k), {"calls": 0, "total": 0, "sessions": 0})
            s["calls"] += v["calls"]
            s["total"] += v["total"]
            s["sessions"] += 1
        return st

    a_st, b_st = stage_agg(a_rows, a_id), stage_agg(b_rows, b_id)
    stages = sorted(set(a_st) | set(b_st),
                    key=lambda s: -(b_st.get(s, {}).get("total", 0) + a_st.get(s, {}).get("total", 0)))
    table_rows, regressions = [], []
    for s in stages:
        a = a_st.get(s, {"calls": 0, "total": 0, "sessions": 0})
        b = b_st.get(s, {"calls": 0, "total": 0, "sessions": 0})
        delta = b["total"] - a["total"]
        pct = (delta / a["total"] * 100) if a["total"] else (100.0 if b["total"] else 0.0)
        regressed = b["total"] > a["total"] * reg_ratio and delta > reg_abs
        if regressed:
            regressions.append({
                "stage": s, "a_total": a["total"], "b_total": b["total"],
                "delta": delta, "a_calls": a["calls"], "b_calls": b["calls"],
            })
        table_rows.append([s, a["calls"], fmt(a["total"]), b["calls"],
                           fmt(b["total"]), ("+" if delta >= 0 else "") + fmt(delta),
                           f"{pct:+.0f}%", "REGRESSION" if regressed else ""])

    a_tot, b_tot = totals_of(aggregate_sessions(a_rows, a_id)), totals_of(aggregate_sessions(b_rows, b_id))
    payload = {
        "run_a": a_id, "run_b": b_id,
        "totals": {"a": a_tot["total"], "b": b_tot["total"],
                   "delta": b_tot["total"] - a_tot["total"]},
        "stages": [
            {"stage": r[0], "a_calls": r[1], "a_total": a_st.get(r[0], {}).get("total", 0),
             "b_calls": r[3], "b_total": b_st.get(r[0], {}).get("total", 0),
             "regression": r[7] == "REGRESSION"}
            for r in table_rows
        ],
        "regressions": regressions,
    }
    if args.json:
        _echo(json.dumps(payload, indent=2))
        return

    _echo(f"# Run comparison - A={a_id}  B={b_id}\n")
    _echo(md_table(
        ["stage", "A calls", "A tokens", "B calls", "B tokens", "delta", "delta%", "flag"],
        table_rows))
    _echo()
    d = b_tot["total"] - a_tot["total"]
    _echo(f"Run totals: A={fmt(a_tot['total'])}  B={fmt(b_tot['total'])}  "
          f"delta={('+' if d >= 0 else '')}{fmt(d)}")
    if regressions:
        _echo("\n## Regressions (B worse than A)\n")
        for r in regressions:
            _echo(f"- {r['stage']} - {fmt(r['a_total'])} -> {fmt(r['b_total'])} tokens "
                  f"(+{fmt(r['delta'])}); calls {r['a_calls']} -> {r['b_calls']}")
    else:
        _echo("\nNo stage regressions (threshold: "
              f">{reg_ratio:.2f}x and >{fmt(reg_abs)} tokens).")


# ---------------------------------------------------------------------------
# list-runs
# ---------------------------------------------------------------------------
def cmd_list_runs(args: argparse.Namespace) -> None:
    inst = _root() / "instances"
    if not inst.is_dir():
        # Fresh install: no run has ever executed, so instances/ doesn't exist
        # yet. That's an empty listing, not an error — CLIENT_SETUP.md uses
        # this command as the post-setup smoke test before any run exists.
        _echo(f"no runs yet (instances dir not created: {inst})")
        return
    # Strict run-id pattern - stray dirs like "run_<garbage>" must not pollute
    # the listing (they would sort above real runs and shift "the last N").
    run_pat = re.compile(r"^run_\d{8}_\d{6}_\d+$")
    run_dirs = sorted(
        (d for d in inst.iterdir() if d.is_dir() and run_pat.match(d.name)),
        key=lambda d: d.name, reverse=True)[: args.limit]
    db = db_runs(limit=max(200, args.limit * 4))

    out_rows = []
    for d in run_dirs:
        rid = d.name
        rows = load_usage(rid)
        tot = totals_of(aggregate_sessions(rows, rid)) if rows else None
        wf = ""
        wf_yaml = d / "workflow" / "workflow.yaml"
        if wf_yaml.is_file():
            try:
                m = re.search(r"^name:\s*(\S+)", wf_yaml.read_text(encoding="utf-8", errors="replace"), re.M)
                wf = m.group(1) if m else ""
            except Exception:
                pass
        meta = db.get(rid) or {}
        out_rows.append({
            "run_id": rid, "workflow": wf or meta.get("workflow_name", "?"),
            "status": meta.get("status", "?"),
            "calls": tot["calls"] if tot else 0,
            "total_tokens": tot["total"] if tot else 0,
            "has_usage": bool(rows),
        })

    if args.json:
        _echo(json.dumps({"runs": out_rows}, indent=2))
        return
    _echo("# Recent runs\n")
    _echo(md_table(
        ["run_id", "workflow", "status", "LLM calls", "total tokens"],
        [[r["run_id"], r["workflow"], r["status"],
          r["calls"] if r["has_usage"] else "-",
          fmt(r["total_tokens"]) if r["has_usage"] else "-"]
         for r in out_rows]))
    _echo("\n('-' = run predates the usage-capture hook; "
          "status '?' = store DB unreachable or run not in DB)")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        prog="iof-run-audit",
        description=(
            "Deterministic run-forensics analytics: token cost, bottlenecks, "
            "spiral/rogue flags, budget overruns, run-vs-run regressions. "
            "Reads usage.jsonl + forensics blobs + store DB (read-only). "
            "Token semantics: 'in' is INCLUSIVE of cache read+write; "
            "total = in + out; uncached = in - cr - cw."
        ),
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    def add_common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--json", action="store_true", help="machine-readable JSON output")

    p = sub.add_parser("summary", help="per-session + per-step cost and status table")
    p.add_argument("--run-id", required=True)
    add_common(p)
    p.set_defaults(fn=cmd_summary)

    p = sub.add_parser("bottlenecks", help="top sessions by tokens, steps by duration, retries, cache-write waste")
    p.add_argument("--run-id", required=True)
    p.add_argument("--top", type=int, default=10)
    add_common(p)
    p.set_defaults(fn=cmd_bottlenecks)

    p = sub.add_parser("spirals", help="rogue/spiral flags: budget overruns, re-derivation streaks, retries")
    p.add_argument("--run-id", required=True)
    add_common(p)
    p.set_defaults(fn=cmd_spirals)

    p = sub.add_parser("budget", help="overrun flags vs benchmarks or explicit limits")
    p.add_argument("--run-id", required=True)
    p.add_argument("--total-limit", type=int, default=None, help="hard run-total token limit")
    p.add_argument("--per-step-limit", type=int, default=None, help="hard per-session LLM-call limit")
    add_common(p)
    p.set_defaults(fn=cmd_budget)

    p = sub.add_parser("cost", help="dollar cost of run(s) at a named rate card (what-if re-pricing)")
    p.add_argument("--run-id", action="append", help="repeatable - multiple runs get a lifecycle total")
    p.add_argument("--card", default=None, help="price card name from run_audit_price_cards.yaml (default: opus-4.8)")
    p.add_argument("--in-rate", type=float, default=None, help="override: USD per 1M uncached input tokens")
    p.add_argument("--out-rate", type=float, default=None, help="override: USD per 1M output tokens")
    p.add_argument("--cache-read-rate", type=float, default=None, help="override: USD per 1M cache-read tokens")
    p.add_argument("--cache-write-rate", type=float, default=None, help="override: USD per 1M cache-write tokens")
    add_common(p)
    p.set_defaults(fn=cmd_cost)

    p = sub.add_parser("compare", help="per-stage delta table between two runs")
    p.add_argument("--run-id", action="append", help="pass twice: A then B")
    add_common(p)
    p.set_defaults(fn=cmd_compare)

    p = sub.add_parser("list-runs", help="recent runs with status + total tokens")
    p.add_argument("--limit", type=int, default=15)
    add_common(p)
    p.set_defaults(fn=cmd_list_runs)

    args = parser.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
