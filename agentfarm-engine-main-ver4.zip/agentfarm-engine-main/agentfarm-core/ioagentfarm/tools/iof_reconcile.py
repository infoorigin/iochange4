"""DEPRECATED (2026-07-25): pharma domain logic stranded in core. Superseded by
solutions/pharma barrier_signal tools (iof-barrier-assess). Console entry removed;
file retained one release for reference, then deleted.
"""
"""iof-reconcile — arithmetic cross-checker for strategy plan financials.

Regex-extracts dollar amounts and percentage claims from the strategy
plan, checks internal consistency: scenario sums vs per-play components,
headline vs computed totals.

Usage:
    iof-reconcile --strategy-plan strategy_plan.md

Output: JSON to stdout with pass/fail per check.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Dollar + percentage extractors
# ---------------------------------------------------------------------------

# Match patterns like "$600M", "$3.3B", "$12.1M", "$180M"
_DOLLAR_PAT = re.compile(r"\$(\d+(?:\.\d+)?)\s*([BMK])", re.IGNORECASE)

# Match patterns like "confidence 0.85", "confidence: 0.75"
_CONFIDENCE_PAT = re.compile(r"confidence[:\s]+(\d\.\d{1,2})")

# Match patterns like "+10 pp", "+10–15 pp", "10 percentage point"
_PP_PAT = re.compile(r"[+]?(\d+(?:\.\d+)?)\s*(?:–|-)\s*(\d+(?:\.\d+)?)\s*pp|[+]?(\d+(?:\.\d+)?)\s*pp")


def _parse_dollars(text: str) -> List[Tuple[float, str, str]]:
    """Extract all dollar amounts as (value_in_millions, raw_match, context)."""
    results = []
    for m in _DOLLAR_PAT.finditer(text):
        num = float(m.group(1))
        unit = m.group(2).upper()
        if unit == "B":
            val_m = num * 1000
        elif unit == "K":
            val_m = num / 1000
        else:
            val_m = num
        context = text[max(0, m.start() - 40):m.end() + 40].replace("\n", " ").strip()
        results.append((val_m, m.group(0), context))
    return results


def _find_scenario_amounts(text: str) -> Dict[str, Optional[float]]:
    """Try to find conservative / expected / upside headline amounts."""
    scenarios = {"conservative": None, "expected": None, "upside": None}
    for label in scenarios:
        # Look for "conservative: $XXM" or "Conservative $XXM" patterns
        pat = re.compile(
            rf"{label}[:\s]*\$(\d+(?:\.\d+)?)\s*([BMK])",
            re.IGNORECASE
        )
        m = pat.search(text)
        if m:
            num = float(m.group(1))
            unit = m.group(2).upper()
            scenarios[label] = num * 1000 if unit == "B" else (num / 1000 if unit == "K" else num)
    return scenarios


def _find_per_play_amounts(text: str) -> List[Dict[str, Any]]:
    """Extract per-play dollar amounts from tables or structured listings."""
    plays = []
    # Look for PLAY-XX with nearby dollar amounts
    for m in re.finditer(r"(PLAY-[A-Z]{2}-\d{2})", text):
        play_id = m.group(1)
        context = text[m.start():min(len(text), m.end() + 300)]
        dollars = _DOLLAR_PAT.findall(context)
        if dollars:
            amounts = []
            for num_str, unit in dollars:
                num = float(num_str)
                val = num * 1000 if unit.upper() == "B" else (num / 1000 if unit.upper() == "K" else num)
                amounts.append(val)
            plays.append({"play": play_id, "amounts_m": amounts})
    return plays


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------

def check_scenario_sums(text: str) -> Dict[str, Any]:
    """Check if stated scenario totals match sum of per-play amounts."""
    scenarios = _find_scenario_amounts(text)
    per_play = _find_per_play_amounts(text)

    if not any(scenarios.values()):
        return {"name": "scenario_sum", "status": "SKIPPED",
                "reason": "Could not extract scenario headline amounts"}

    if not per_play:
        return {"name": "scenario_sum", "status": "SKIPPED",
                "reason": "Could not extract per-play amounts"}

    # Take the median amount per play as "expected"
    play_expected = []
    for p in per_play:
        if len(p["amounts_m"]) >= 2:
            play_expected.append(sorted(p["amounts_m"])[len(p["amounts_m"]) // 2])
        elif p["amounts_m"]:
            play_expected.append(p["amounts_m"][0])

    computed_sum = sum(play_expected)
    stated = scenarios.get("expected")

    if stated is None:
        return {"name": "scenario_sum", "status": "SKIPPED",
                "reason": "Expected scenario amount not found"}

    delta_pct = abs(computed_sum - stated) / stated * 100 if stated > 0 else 0

    return {
        "name": "scenario_sum",
        "stated_expected_m": stated,
        "computed_sum_m": round(computed_sum, 1),
        "delta_pct": round(delta_pct, 1),
        "plays_found": len(per_play),
        "status": "PASS" if delta_pct <= 5 else ("WARN" if delta_pct <= 15 else "FAIL"),
    }


def check_dollar_consistency(text: str) -> Dict[str, Any]:
    """Check for internal dollar-amount contradictions."""
    all_dollars = _parse_dollars(text)
    if len(all_dollars) < 3:
        return {"name": "dollar_consistency", "status": "SKIPPED",
                "reason": f"Only {len(all_dollars)} dollar amounts found"}

    # Group by approximate value — flag if the same number appears with
    # different contexts that suggest different meanings
    issues = []
    values = [d[0] for d in all_dollars]

    # Simple check: if the same dollar value appears in contradictory
    # contexts (e.g., "$600M expected" and "$600M conservative")
    seen_values: Dict[float, List[str]] = {}
    for val, raw, ctx in all_dollars:
        key = round(val)
        if key not in seen_values:
            seen_values[key] = []
        seen_values[key].append(ctx)

    return {
        "name": "dollar_consistency",
        "status": "PASS",
        "total_dollar_mentions": len(all_dollars),
        "unique_values": len(seen_values),
        "largest_amount_m": max(values) if values else 0,
    }


def check_confidence_range(text: str) -> Dict[str, Any]:
    """Check that all confidence scores are in [0.0, 1.0]."""
    scores = [float(m.group(1)) for m in _CONFIDENCE_PAT.finditer(text)]
    if not scores:
        return {"name": "confidence_range", "status": "SKIPPED",
                "reason": "No confidence scores found"}

    out_of_range = [s for s in scores if s < 0.0 or s > 1.0]
    return {
        "name": "confidence_range",
        "scores_found": len(scores),
        "min": min(scores),
        "max": max(scores),
        "mean": round(sum(scores) / len(scores), 2),
        "out_of_range": out_of_range,
        "status": "PASS" if not out_of_range else "FAIL",
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Check arithmetic consistency in strategy plan financials.",
    )
    parser.add_argument("--strategy-plan", required=True,
                        help="Path to strategy_plan.md")
    parser.add_argument("--intelligence-report", default=None,
                        help="Path to intelligence_report.md (optional, for cross-doc checks)")

    args = parser.parse_args()

    sp_text = Path(args.strategy_plan).read_text(encoding="utf-8", errors="replace") \
        if Path(args.strategy_plan).exists() else ""
    ir_text = Path(args.intelligence_report).read_text(encoding="utf-8", errors="replace") \
        if args.intelligence_report and Path(args.intelligence_report).exists() else ""

    if not sp_text:
        print(json.dumps({"success": False, "error": f"Cannot read {args.strategy_plan}"}))
        sys.exit(1)

    combined = ir_text + "\n" + sp_text

    checks = [
        check_scenario_sums(sp_text),
        check_dollar_consistency(sp_text),
        check_confidence_range(combined),
    ]

    fails = sum(1 for c in checks if c["status"] == "FAIL")
    warns = sum(1 for c in checks if c["status"] == "WARN")

    if fails > 0:
        verdict = f"FAIL — {fails} check(s) failed"
    elif warns > 0:
        verdict = f"WARN — {warns} check(s) need review"
    else:
        verdict = "PASS — all checks passed"

    result = {
        "success": True,
        "checks": checks,
        "verdict": verdict,
    }
    print(json.dumps(result, indent=2))
    sys.exit(0 if fails == 0 else 1)


if __name__ == "__main__":
    main()
