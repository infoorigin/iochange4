"""``iof-recall`` — cross-run recall over what this workspace's runs produced.

The Hermes capability (FTS session search) grounded in RUN ARTIFACTS instead
of agent memory: the corpus is step outputs — durable, attributable to a run
and step, and never a pollution channel because nothing here feeds a prompt
automatically. An agent (or Jarvis, or a human) ASKS, reads the hits, and
decides.

Scope-isolated by (role, workflow): one agent's history never leaks into
another's answers.

Usage:
  iof-recall "vendor concentration arithmetic" --role v2check_analyst --workflow deep_brief
  iof-recall --reindex            # backfill the index from the steps table
  iof-recall "..." --any-scope    # search across every scope (diagnostics)

Environment: IOF_DATABASE_URL (default: sqlite under $IOF_ROOT/state.db).
Indexing also happens incrementally at step finalize when learning v2 is
active, so --reindex is a backfill for pre-existing history, not a ritual.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def _db_url() -> str:
    url = (os.environ.get("IOF_DATABASE_URL") or "").strip()
    if url:
        return url
    root = Path(os.environ.get("IOF_ROOT", ".iof")).resolve()
    return f"sqlite:///{root / 'state.db'}"


def _fts():
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.learning.recall_fts import FtsRecall
    fts = FtsRecall(make_adapter(_db_url()))
    fts.init()
    return fts


def _reindex(fts) -> int:
    """Backfill: every done step's output, scoped role::workflow."""
    from ioagentfarm.engine.db import make_adapter
    adapter = make_adapter(_db_url())
    with adapter.connect() as con:
        adapter.init_connection(con)
        cur = con.cursor()
        ph = adapter.placeholder()
        cur.execute(
            "SELECT s.run_id, s.step_key, s.role, r.workflow_name, "
            "COALESCE(s.output_text,'') AS output_text "
            "FROM steps s JOIN runs r ON r.id = s.run_id "
            f"WHERE s.status = {ph}", ("done",))
        rows = cur.fetchall()
    n = 0
    for row in rows:
        d = dict(row)
        content = (d.get("output_text") or "").strip()
        if not content:
            continue
        fts.index(f"{d['run_id']}:{d['step_key']}",
                  f"{d['role']}::{d['workflow_name']}", content[:4000])
        n += 1
    return n


def main() -> None:
    ap = argparse.ArgumentParser(
        prog="iof-recall",
        description="Search prior runs' step outputs (scope-isolated FTS).")
    ap.add_argument("query", nargs="?", default="", help="free-text query")
    ap.add_argument("--role", default="", help="scope: agent role")
    ap.add_argument("--workflow", default="", help="scope: workflow name")
    ap.add_argument("--any-scope", action="store_true",
                    help="search across all scopes (diagnostics)")
    ap.add_argument("--limit", type=int, default=8)
    ap.add_argument("--json", action="store_true", dest="as_json",
                    help="machine-readable output")
    ap.add_argument("--reindex", action="store_true",
                    help="backfill the index from the steps table")
    args = ap.parse_args()

    fts = _fts()

    if args.reindex:
        n = _reindex(fts)
        print(f"indexed {n} step output(s) from {_db_url()}")
        if not args.query:
            return

    if not args.query:
        ap.error("a query is required unless --reindex is given")

    if args.any_scope:
        # Deliberately explicit: cross-scope search is a diagnostic, not the
        # default - scope isolation is the contract.
        hits = []
        from ioagentfarm.engine.db import make_adapter
        adapter = make_adapter(_db_url())
        with adapter.connect() as con:
            adapter.init_connection(con)
            cur = con.cursor()
            try:
                cur.execute("SELECT DISTINCT scope_key FROM recall_fts")
            except Exception:
                cur.execute("SELECT DISTINCT scope_key FROM recall_docs")
            scopes = [r[0] for r in cur.fetchall()]
        for sk in scopes:
            for h in fts.search(sk, args.query, args.limit):
                h["scope"] = sk
                hits.append(h)
        hits = sorted(hits, key=lambda h: h.get("rank") or 0)[: args.limit]
    else:
        if not (args.role and args.workflow):
            ap.error("--role and --workflow are required (or --any-scope)")
        hits = fts.search(f"{args.role}::{args.workflow}", args.query,
                          args.limit)

    if args.as_json:
        print(json.dumps(hits, default=str))
        return
    if not hits:
        print("no matches")
        return
    for h in hits:
        print(f"-- {h.get('doc_id')}" +
              (f"  [{h['scope']}]" if "scope" in h else ""))
        print((h.get("content") or "")[:500].strip())
        print()


if __name__ == "__main__":
    sys.exit(main())
