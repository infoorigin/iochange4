"""DEPRECATED (2026-07-25): pharma domain logic stranded in core. Superseded by
solutions/pharma barrier_signal tools (iof-barrier-assess). Console entry removed;
file retained one release for reference, then deleted.
"""
"""iof-assess — algorithmic confidence scoring + deterministic barrier ID assignment.

Agents call this tool via exec to get computed confidence scores and
sequential barrier IDs instead of self-assessing (which LLMs do poorly).

Usage:
    iof-assess barrier \
      --category ADHERENCE --sub-type early_dropoff \
      --evidence-sources "prescription_claims,qual_research" \
      --threshold "30d_disc >= 0.25" \
      --actual-value 0.243 \
      --sample-size 300 \
      --qual-confirms yes \
      --signals "SIG-AD-01,SIG-AD-03" \
      --blocks-primary-goal yes \
      --output-dir /path/to/output

    iof-assess list --output-dir /path/to/output

Output: JSON to stdout.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional


# ---------------------------------------------------------------------------
# Confidence scoring algorithm
# ---------------------------------------------------------------------------

def compute_confidence(
    evidence_sources: list[str],
    actual_value: Optional[float],
    threshold_value: Optional[float],
    sample_size: int,
    qual_confirms: Optional[str],  # "yes" | "no" | "neutral" | None
    signal_count: int,
) -> Dict[str, Any]:
    """Compute a deterministic confidence score from evidence dimensions.

    Returns a dict with the total confidence (0.0-1.0) and per-component
    breakdown so the agent can include it in the barrier record.
    """
    components = {}

    # Source diversity (quant+qual cross-method = bonus)
    n_sources = len(evidence_sources)
    has_qual = qual_confirms in ("yes", "no", "neutral")
    has_quant = any(s not in ("qual_research", "qualitative") for s in evidence_sources)
    if n_sources >= 3:
        components["source_diversity"] = 0.25
    elif n_sources == 2 and has_qual and has_quant:
        components["source_diversity"] = 0.20
    elif n_sources == 2:
        components["source_diversity"] = 0.15
    elif n_sources == 1:
        components["source_diversity"] = 0.10
    else:
        components["source_diversity"] = 0.05

    # Threshold proximity
    if actual_value is not None and threshold_value is not None and threshold_value > 0:
        ratio = actual_value / threshold_value
        if ratio >= 1.0:
            components["threshold_proximity"] = 0.30
        elif ratio >= 0.80:
            components["threshold_proximity"] = 0.25
        elif ratio >= 0.50:
            components["threshold_proximity"] = 0.15
        else:
            components["threshold_proximity"] = 0.05
    else:
        components["threshold_proximity"] = 0.10  # no threshold data

    # Sample size
    if sample_size > 300:
        components["sample_size_factor"] = 0.20
    elif sample_size > 100:
        components["sample_size_factor"] = 0.15
    elif sample_size > 30:
        components["sample_size_factor"] = 0.10
    else:
        components["sample_size_factor"] = 0.05

    # Qualitative alignment
    if qual_confirms == "yes":
        components["qual_alignment"] = 0.15
    elif qual_confirms == "neutral":
        components["qual_alignment"] = 0.05
    elif qual_confirms == "no":
        components["qual_alignment"] = -0.10
    else:
        components["qual_alignment"] = 0.00

    # Signal count
    if signal_count >= 3:
        components["signal_count_factor"] = 0.15
    elif signal_count == 2:
        components["signal_count_factor"] = 0.10
    elif signal_count == 1:
        components["signal_count_factor"] = 0.05
    else:
        components["signal_count_factor"] = 0.00

    total = max(0.0, min(1.0, sum(components.values())))
    return {"confidence": round(total, 2), "components": components}


# ---------------------------------------------------------------------------
# Severity derivation
# ---------------------------------------------------------------------------

def derive_severity(
    confidence: float,
    signal_count: int,
    blocks_primary_goal: bool,
) -> Dict[str, str]:
    """Derive severity from confidence + signal count + goal impact."""
    if confidence >= 0.80 and signal_count >= 2 and blocks_primary_goal:
        return {"severity": "CRITICAL",
                "rationale": f"confidence {confidence} >= 0.80 AND {signal_count} signals AND blocks primary goal"}
    if confidence >= 0.70 and (signal_count >= 2 or blocks_primary_goal):
        return {"severity": "HIGH",
                "rationale": f"confidence {confidence} >= 0.70 AND ({signal_count} signals OR blocks goal)"}
    if confidence >= 0.50:
        return {"severity": "MEDIUM",
                "rationale": f"confidence {confidence} >= 0.50"}
    return {"severity": "LOW",
            "rationale": f"confidence {confidence} < 0.50"}


# ---------------------------------------------------------------------------
# Barrier ID counter (file-based, deterministic)
# ---------------------------------------------------------------------------

_COUNTER_FILE = "_barrier_counter.json"


def _load_counter(output_dir: Path) -> Dict[str, Any]:
    counter_path = output_dir / _COUNTER_FILE
    if counter_path.exists():
        try:
            return json.loads(counter_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"next_id": 1, "assigned": {}}


def _save_counter(output_dir: Path, counter: Dict[str, Any]) -> None:
    counter_path = output_dir / _COUNTER_FILE
    counter_path.write_text(json.dumps(counter, indent=2), encoding="utf-8")


def assign_barrier_id(output_dir: Path, category: str, sub_type: str) -> str:
    """Assign the next sequential BAR-XX ID and persist the counter."""
    counter = _load_counter(output_dir)
    barrier_id = f"BAR-{counter['next_id']:02d}"
    counter["assigned"][barrier_id] = f"{category}/{sub_type}"
    counter["next_id"] += 1
    _save_counter(output_dir, counter)
    return barrier_id


# ---------------------------------------------------------------------------
# Tool-generated inventory file — the INTERFACE artifact
# ---------------------------------------------------------------------------
# The agent cannot produce this file without calling the tool. This makes
# iof-pharma-assess an INTERFACE (like iof-query for data) rather than
# just a computation aid the agent can bypass.

_INVENTORY_FILE = "_barrier_inventory_tool.md"
_SECTION_FILE = "_analyze_section_07_barrier_inventory.md"
_INVENTORY_HEADER = (
    "| BAR-ID | Category/sub_type | Severity | Confidence | Signals | Root cause hint |\n"
    "|--------|-------------------|----------|------------|---------|----------------|"
)


def _append_inventory_row(
    output_dir: Path, barrier_id: str, category: str, sub_type: str,
    severity: str, confidence: float, signals: list, root_cause_hint: str = "",
) -> None:
    """Append one row to the tool-generated inventory markdown table.

    This file accumulates as the agent calls the tool for each barrier.
    The agent's skill tells it to cat this file and paste it as the
    canonical barrier summary table — the agent cannot fabricate this
    file without calling the tool for each barrier.
    """
    inv_path = output_dir / _INVENTORY_FILE
    if not inv_path.exists():
        inv_path.write_text(_INVENTORY_HEADER + "\n", encoding="utf-8")
    sig_str = ", ".join(signals) if signals else "—"
    hint = root_cause_hint[:60].replace("|", "/") if root_cause_hint else "—"
    row = f"| {barrier_id} | {category}/{sub_type} | {severity} | {confidence} | {sig_str} | {hint} |"
    with open(inv_path, "a", encoding="utf-8") as f:
        f.write(row + "\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _output(data: dict):
    print(json.dumps(data, indent=2))
    sys.exit(0)


def _fail(message: str):
    print(json.dumps({"success": False, "error": message}))
    sys.exit(1)


def cmd_barrier(args):
    """Assess a barrier: compute confidence, derive severity, assign ID."""
    evidence_sources = [s.strip() for s in (args.evidence_sources or "").split(",") if s.strip()]
    signals = [s.strip() for s in (args.signals or "").split(",") if s.strip()]

    conf = compute_confidence(
        evidence_sources=evidence_sources,
        actual_value=args.actual_value,
        threshold_value=args.threshold_value,
        sample_size=args.sample_size or 0,
        qual_confirms=args.qual_confirms,
        signal_count=len(signals),
    )

    sev = derive_severity(
        confidence=conf["confidence"],
        signal_count=len(signals),
        blocks_primary_goal=(args.blocks_primary_goal or "").lower() in ("yes", "true", "1"),
    )

    output_dir = Path(args.output_dir) if args.output_dir else Path.cwd()
    barrier_id = assign_barrier_id(output_dir, args.category, args.sub_type)

    # Write to the tool-generated inventory file (the interface artifact)
    _append_inventory_row(
        output_dir=output_dir,
        barrier_id=barrier_id,
        category=args.category,
        sub_type=args.sub_type,
        severity=sev["severity"],
        confidence=conf["confidence"],
        signals=signals,
        root_cause_hint=args.threshold or "",
    )

    _output({
        "success": True,
        "barrier_id": barrier_id,
        "category": args.category,
        "sub_type": args.sub_type,
        "severity": sev["severity"],
        "severity_rationale": sev["rationale"],
        "confidence": conf["confidence"],
        "confidence_components": conf["components"],
        "signals": signals,
        "evidence_sources": evidence_sources,
        "sample_size": args.sample_size,
        "blocks_primary_goal": (args.blocks_primary_goal or "").lower() in ("yes", "true", "1"),
    })


def cmd_parse(args):
    """Post-process the agent's barrier markdown — assign IDs + compute confidence."""
    import re

    input_path = Path(args.input)
    if not input_path.exists():
        _fail(f"Input file not found: {args.input}")
    text = input_path.read_text(encoding="utf-8", errors="replace")
    output_dir = Path(args.output_dir) if args.output_dir else input_path.parent

    sig_pat = re.compile(r"SIG-[A-Z]{2}-\d{2}")
    sev_pat = re.compile(r"\b(CRITICAL|HIGH|MEDIUM|MODERATE|LOW)\b", re.IGNORECASE)

    # Category keywords mapping — used for both heading detection and body fallback
    cat_keywords = {
        "ADHERENCE": ["adherence", "discontinuation", "persistence", "drop-off", "dropout", "refill"],
        "ACCESS": ["access", "prior auth", "pa ", "step-edit", "formulary", "payer"],
        "REIMBURSEMENT": ["reimbursement", "oop", "cost", "copay", "pap", "affordability"],
        "AWARENESS": ["awareness", "education", "hcp", "physician", "knowledge"],
        "CLINICAL": ["clinical", "ae ", "adverse", "somnolence", "side effect", "tolerability"],
        "COMPETITIVE": ["competitive", "switching", "competitor", "class pull"],
    }

    # ---------------------------------------------------------------------------
    # Flexible barrier heading detection — accepts ANY format the agent produces:
    #   ### ADHERENCE — Early discontinuation        (triple hash)
    #   ## ADHERENCE — Early discontinuation         (double hash)
    #   # ADHERENCE — Early discontinuation          (single hash)
    #   **ADHERENCE** — Early discontinuation        (bold, no hash)
    #   ADHERENCE: Early discontinuation             (bare category + colon)
    #   ### BAR-01: ADHERENCE — ...                  (with existing BAR-XX)
    #
    # Strategy: find lines that look like barrier headings (contain a category
    # keyword in a prominent position), split text at those lines, and extract
    # one barrier per section. This avoids hardcoding markdown heading level.
    # ---------------------------------------------------------------------------

    # Pattern: line starts with optional markdown heading (#...) or bold (**),
    # then contains a category keyword or BAR-XX pattern
    _cat_names = "|".join(cat_keywords.keys())
    # Use raw string without f-string for the hash quantifier part,
    # then combine with the category names
    _heading_prefix = r"^(?:#{1,4}\s+|\*\*)?\s*(?:BAR(?:RIER)?[-_]?\d+\s*[:—–\-]\s*)?"
    heading_re = re.compile(
        _heading_prefix + rf"({_cat_names})\b",
        re.MULTILINE | re.IGNORECASE,
    )

    # Find all heading positions
    heading_positions = [(m.start(), m) for m in heading_re.finditer(text)]

    # Also catch BAR-XX headings that don't start with a category keyword
    bar_heading_re = re.compile(
        r"^(?:#{1,4}\s+|\*\*)?\s*BAR(?:RIER)?[-_]?\d+\b",
        re.MULTILINE | re.IGNORECASE,
    )
    for m in bar_heading_re.finditer(text):
        if not any(abs(m.start() - pos) < 5 for pos, _ in heading_positions):
            heading_positions.append((m.start(), m))

    heading_positions.sort(key=lambda x: x[0])

    # Split text into sections at heading boundaries
    barriers_found = []
    for i, (pos, match) in enumerate(heading_positions):
        end = heading_positions[i + 1][0] if i + 1 < len(heading_positions) else len(text)
        section = text[pos:end]

        first_line = section.split("\n")[0]
        heading_upper = first_line.upper()

        # Skip non-barrier headings (summary tables, "Barrier Confidence Summary", etc.)
        skip_phrases = ["SUMMARY", "CONFIDENCE SUMMARY", "BARRIER ID", "| BAR"]
        if any(sp in heading_upper for sp in skip_phrases) and \
           not any(cat in heading_upper for cat in cat_keywords):
            continue

        # Detect category from HEADING (most reliable — agent names it)
        category = "UNKNOWN"
        sub_type = "unclassified"
        for cat in cat_keywords:
            if cat in heading_upper:
                category = cat
                # Extract sub-type from the part after the category name
                # Handle various separators: —, –, -, :, whitespace
                after_cat = re.split(rf"(?i){cat}", first_line, maxsplit=1)[-1]
                after_cat = re.sub(r"^[\s\*#—–:\-]+", "", after_cat).strip()
                if after_cat:
                    sub_type = re.sub(r"[^a-zA-Z0-9_ ]", "", after_cat)[:40].strip().lower().replace(" ", "_")
                break
        # Fallback to body keywords if heading didn't match a category
        if category == "UNKNOWN":
            section_lower = section.lower()
            for cat, keywords in cat_keywords.items():
                if any(kw in section_lower[:300] for kw in keywords):
                    category = cat
                    sub_type = keywords[0].replace(" ", "_")
                    break

        # Extract signals
        signals = list(set(sig_pat.findall(section)))

        # Detect severity from content
        sev_matches = sev_pat.findall(section[:300])
        severity_hint = sev_matches[0].upper() if sev_matches else "MEDIUM"
        if severity_hint == "MODERATE":
            severity_hint = "MEDIUM"

        # Count evidence sources (entity references)
        evidence_sources = []
        for entity_ref in re.findall(r"caplyta_\w+|rybrevant_\w+|tremfya_\w+|talvey_\w+", section):
            if entity_ref not in evidence_sources:
                evidence_sources.append(entity_ref)
        qual_refs = len(re.findall(r"QR-\d+|qual", section, re.IGNORECASE))
        has_qual = qual_refs > 0

        # Count patient numbers as proxy for sample size
        patient_nums = re.findall(r"(\d+)\s*(?:patients?|pts?|cohort)", section, re.IGNORECASE)
        sample_size = max((int(n) for n in patient_nums), default=100)

        barriers_found.append({
            "heading": first_line.strip()[:80],
            "category": category,
            "sub_type": sub_type,
            "signals": signals,
            "evidence_sources": evidence_sources,
            "has_qual": has_qual,
            "sample_size": sample_size,
            "severity_hint": severity_hint,
            "blocks_goal": severity_hint == "CRITICAL",
        })

    # Now assign IDs + compute confidence for each
    results = []
    for b in barriers_found:
        # In parse mode, use agent's severity hint as a proxy for threshold
        # proximity (the agent already assessed the data — we trust the
        # direction, just compute a reproducible score from evidence density)
        sev_proxy = {"CRITICAL": 0.30, "HIGH": 0.25, "MEDIUM": 0.15, "LOW": 0.05}
        threshold_boost = sev_proxy.get(b["severity_hint"], 0.15)

        conf = compute_confidence(
            evidence_sources=b["evidence_sources"] + (["qual_research"] if b["has_qual"] else []),
            actual_value=0.9,  # proxy: threshold breached (agent already assessed)
            threshold_value=1.0,
            sample_size=b["sample_size"],
            qual_confirms="yes" if b["has_qual"] else None,
            signal_count=len(b["signals"]),
        )
        # Add severity-hint boost (the agent's assessment is signal, not noise)
        conf["confidence"] = round(min(1.0, conf["confidence"] + threshold_boost), 2)

        sev = derive_severity(
            confidence=conf["confidence"],
            signal_count=len(b["signals"]),
            blocks_primary_goal=b["blocks_goal"],
        )
        barrier_id = assign_barrier_id(output_dir, b["category"], b["sub_type"])
        _append_inventory_row(
            output_dir=output_dir,
            barrier_id=barrier_id,
            category=b["category"],
            sub_type=b["sub_type"],
            severity=sev["severity"],
            confidence=conf["confidence"],
            signals=b["signals"],
            root_cause_hint=b["heading"],
        )
        results.append({
            "barrier_id": barrier_id,
            "original_heading": b["heading"],
            "category": b["category"],
            "sub_type": b["sub_type"],
            "severity": sev["severity"],
            "confidence": conf["confidence"],
            "signals": b["signals"],
        })

    # Write the section file — this IS section 07 of the assembled report.
    # Without this tool call, the file doesn't exist and the report has a gap.
    section_path = output_dir / _SECTION_FILE
    section_lines = ["## Barrier Inventory\n"]
    for r in results:
        sig_str = ", ".join(r["signals"]) if r["signals"] else "—"
        # Strip category prefix from original heading to avoid duplication
        heading_text = r["original_heading"].lstrip("#").strip()
        # Remove "CATEGORY — " or "CATEGORY - " prefix if present
        for cat in ("ADHERENCE", "ACCESS", "REIMBURSEMENT", "AWARENESS", "CLINICAL", "COMPETITIVE"):
            if heading_text.upper().startswith(cat):
                heading_text = re.sub(rf"^{cat}\s*[—–\-:]+\s*", "", heading_text, flags=re.IGNORECASE).strip()
                break
        section_lines.append(
            f"### {r['barrier_id']}: {r['category']} — {heading_text}\n"
        )
        # Pull the body from the draft (everything after the heading, before next ###)
        for section in re.split(r"(?=^###\s+)", text, flags=re.MULTILINE):
            if section.strip().startswith("###") and r["original_heading"].rstrip() in section.split("\n")[0]:
                body_lines = section.split("\n")[1:]
                body = "\n".join(body_lines).strip()
                if body:
                    section_lines.append(body + "\n")
                break
        section_lines.append(
            f"**Confidence:** {r['confidence']} ({r['severity']}) | **Signals:** {sig_str}\n"
        )
        section_lines.append("---\n")

    # Append summary table
    section_lines.append("\n### Barrier Confidence Summary\n")
    section_lines.append(
        "| Barrier ID | Category | Severity | Confidence | Signals |\n"
        "|-----------|----------|----------|------------|--------|\n"
    )
    for r in results:
        sig_str = ", ".join(r["signals"]) if r["signals"] else "—"
        section_lines.append(
            f"| {r['barrier_id']} | {r['category']} | {r['severity']} "
            f"| {r['confidence']} | {sig_str} |\n"
        )

    section_path.write_text("".join(section_lines), encoding="utf-8")

    _output({
        "success": True,
        "barriers_parsed": len(results),
        "barriers": results,
        "section_file": str(section_path),
        "inventory_file": str(output_dir / _INVENTORY_FILE),
    })


def cmd_list(args):
    """List all assigned barrier IDs for this run."""
    output_dir = Path(args.output_dir) if args.output_dir else Path.cwd()
    counter = _load_counter(output_dir)
    _output({
        "success": True,
        "barriers": counter["assigned"],
        "next_id": counter["next_id"],
        "total": counter["next_id"] - 1,
    })


def main():
    parser = argparse.ArgumentParser(
        description="Algorithmic confidence scoring + barrier ID assignment.",
    )
    sub = parser.add_subparsers(dest="command", help="Sub-commands")

    # --- barrier sub-command ---
    bp = sub.add_parser("barrier", help="Assess a barrier: confidence + severity + ID")
    bp.add_argument("--category", required=True,
                    help="Barrier category (ACCESS, REIMBURSEMENT, AWARENESS, ADHERENCE, CLINICAL, COMPETITIVE)")
    bp.add_argument("--sub-type", required=True,
                    help="Barrier sub-type (e.g., early_dropoff, prior_auth)")
    bp.add_argument("--evidence-sources", default="",
                    help="Comma-separated entity names used as evidence")
    bp.add_argument("--threshold", default=None,
                    help="Human-readable threshold description (for documentation)")
    bp.add_argument("--actual-value", type=float, default=None,
                    help="The actual metric value observed")
    bp.add_argument("--threshold-value", type=float, default=None,
                    help="The threshold value that defines 'active'")
    bp.add_argument("--sample-size", type=int, default=0,
                    help="Number of observations behind the evidence")
    bp.add_argument("--qual-confirms", default=None,
                    choices=["yes", "no", "neutral"],
                    help="Does qualitative research confirm this barrier?")
    bp.add_argument("--signals", default="",
                    help="Comma-separated SIG-XX IDs that triggered this barrier")
    bp.add_argument("--blocks-primary-goal", default="no",
                    help="Does this barrier directly block the primary goal metric? (yes/no)")
    bp.add_argument("--output-dir", default=None,
                    help="Directory for barrier counter file (default: cwd)")

    # --- parse sub-command (post-processor) ---
    pp = sub.add_parser("parse", help="Post-process agent's barrier markdown — assign IDs + compute confidence")
    pp.add_argument("--input", required=True,
                    help="Path to the agent's barrier inventory markdown file")
    pp.add_argument("--output-dir", default=None,
                    help="Directory for output files (default: same as input)")

    # --- list sub-command ---
    lp = sub.add_parser("list", help="List all assigned barrier IDs")
    lp.add_argument("--output-dir", default=None,
                    help="Directory with barrier counter file (default: cwd)")

    args = parser.parse_args()
    if args.command == "barrier":
        cmd_barrier(args)
    elif args.command == "parse":
        cmd_parse(args)
    elif args.command == "list":
        cmd_list(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
