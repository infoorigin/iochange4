"""plays_repo — every SQL statement of the play store, in one place.

The play store's counterpart of `casetier.repo`, under the same rules: one
statement per function, the SQL beside it as a module-level `SQL_*`
constant a grammar test enumerates, `{ph}` placeholders formatted at call
time, `{scope}` for the tenancy clause, rows read by column name through
`casetier.store._one` / `_rows`, and a SAVEPOINT around anything that may
legitimately fail. `playbook_store.py` holds no `cur.execute(` of its own.
"""
from __future__ import annotations

import time

from ioagentfarm.tools.casetier.store import (_column_exists, _guarded, _one,
                                               _rows, _scope_sql, _workspace)


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _fmt(sql: str, ph: str, scope: str = "") -> str:
    return sql.format(ph=ph, scope=scope)


# --------------------------------------------------------------- schema

def ensure_schema(cur, ph: str, auto_id: str, schema: list[str],
                  ensure_columns: list[tuple[str, str, str]]) -> None:
    """The play store's DDL: create-if-missing, then the additive columns,
    each probed first and fenced by a SAVEPOINT so a column that already
    exists cannot poison the transaction on Postgres."""
    for ddl in schema:
        cur.execute(ddl.format(auto_id=auto_id))
    for table, col, typ in ensure_columns:
        if not _column_exists(cur, ph, table, col):
            _guarded(cur, f"ALTER TABLE {table} ADD COLUMN {col} {typ}")


# ---------------------------------------------------------- derived ids

SQL_STAGING_IDS = "SELECT staging_id FROM meta_stagings"
SQL_COMPILE_IDS = "SELECT compile_id FROM meta_compilations"


def _max_suffix(values, prefix: str) -> int:
    """Highest numeric suffix among PREFIX-NNNN ids. MAX-based rather than
    COUNT(*)-based: a count collides with an existing id as soon as the
    sequence has a gap (a row inserted by another writer, a hand-loaded
    fixture) — the id it derives is 'one past how many', not 'one past
    the highest'."""
    best = 0
    for val in values:
        sval = str(val or "")
        tail = sval.rsplit("-", 1)[-1]
        if sval.startswith(prefix) and tail.isdigit():
            best = max(best, int(tail))
    return best


def next_staging_id(cur) -> str:
    cur.execute(SQL_STAGING_IDS)
    n = _max_suffix((r["staging_id"] for r in _rows(cur)), "STG-")
    return f"STG-{n + 1:04d}"


def next_compile_id(cur) -> str:
    cur.execute(SQL_COMPILE_IDS)
    n = _max_suffix((r["compile_id"] for r in _rows(cur)), "CMP-")
    return f"CMP-{n + 1:04d}"


def insert_with_fresh_id(cur, next_id, insert, attempts: int = 5) -> str:
    """Insert a row whose primary key is derived from the table's current
    contents. Two concurrent writers can derive the same id; the loser's
    insert violates the PK. Retry with a recomputed id inside a SAVEPOINT
    — Postgres aborts the whole transaction on any failed statement, and
    prior work in it (a re-stage's supersede updates) must survive."""
    last: Exception | None = None
    for _ in range(max(1, attempts)):
        new_id = next_id(cur)
        cur.execute("SAVEPOINT fresh_id")
        try:
            insert(cur, new_id)
        except Exception as e:      # noqa: BLE001 — adapter-specific PK error
            last = e
            cur.execute("ROLLBACK TO SAVEPOINT fresh_id")
            continue
        cur.execute("RELEASE SAVEPOINT fresh_id")
        return new_id
    raise last  # type: ignore[misc]


# ---------------------------------------------------------------- plays

SQL_PLAY_VERSION = "SELECT version FROM meta_playbooks WHERE play_id = {ph}"


def play_version(cur, ph, play_id: str) -> dict | None:
    cur.execute(_fmt(SQL_PLAY_VERSION, ph), (play_id,))
    return _one(cur)


SQL_UPDATE_PLAY = """UPDATE meta_playbooks SET name={ph}, trigger_type={ph},
    goal={ph}, policy_json={ph}, body_md={ph},
    workflow_generate={ph}, workflow_deliver={ph}, status={ph},
    version={ph}, updated_at={ph} WHERE play_id={ph}"""


def update_play(cur, ph, play_id, name, trigger_type, goal, policy_json,
                body_md, workflow_generate, workflow_deliver, status,
                version) -> None:
    cur.execute(_fmt(SQL_UPDATE_PLAY, ph),
                (name, trigger_type, goal, policy_json, body_md,
                 workflow_generate, workflow_deliver, status, version,
                 _now(), play_id))


SQL_INSERT_PLAY = """INSERT INTO meta_playbooks (play_id, name, trigger_type,
    goal, policy_json, body_md, workflow_generate, workflow_deliver,
    status, version, workspace_code, created_at, updated_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_play(cur, ph, play_id, name, trigger_type, goal, policy_json,
                body_md, workflow_generate, workflow_deliver, status,
                version) -> None:
    cur.execute(_fmt(SQL_INSERT_PLAY, ph),
                (play_id, name, trigger_type, goal, policy_json, body_md,
                 workflow_generate, workflow_deliver, status, version,
                 _workspace(), _now(), _now()))


SQL_RULEBOOK_EXISTS = """SELECT 1 AS present FROM meta_rulebooks
    WHERE template_id = {ph}"""


def rulebook_exists(cur, ph, template_id: str) -> bool:
    """Raises when the case tier has never created its tables here - the
    caller words that refusal."""
    cur.execute(_fmt(SQL_RULEBOOK_EXISTS, ph), (template_id,))
    return _one(cur) is not None


SQL_PLAY_FOR_AMEND = """SELECT name, trigger_type, goal, policy_json, body_md,
    workflow_generate, workflow_deliver, version
    FROM meta_playbooks WHERE play_id = {ph}"""


def play_for_amend(cur, ph, play_id: str) -> dict | None:
    cur.execute(_fmt(SQL_PLAY_FOR_AMEND, ph), (play_id,))
    return _one(cur)


SQL_AMEND_PLAY_POLICY = """UPDATE meta_playbooks SET policy_json={ph},
    version={ph}, updated_at={ph}, updated_by={ph} WHERE play_id={ph}"""


def amend_play_policy(cur, ph, play_id, policy_json, version, who) -> None:
    cur.execute(_fmt(SQL_AMEND_PLAY_POLICY, ph),
                (policy_json, version, _now(), who, play_id))


SQL_LIST_PLAYS = """SELECT play_id, name, trigger_type, goal,
    workflow_generate, workflow_deliver, status, version FROM meta_playbooks
    WHERE 1=1{scope} ORDER BY play_id"""


def list_plays(cur, ph) -> list[dict]:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_LIST_PLAYS, ph, clause), params)
    return _rows(cur)


SQL_GET_PLAY = "SELECT * FROM meta_playbooks WHERE play_id = {ph}"


def get_play(cur, ph, play_id: str) -> dict | None:
    cur.execute(_fmt(SQL_GET_PLAY, ph), (play_id,))
    return _one(cur)


SQL_OPERATIONAL_PLAYS = """SELECT play_id, name, trigger_type, goal,
    policy_json, workflow_generate, workflow_deliver FROM meta_playbooks
    WHERE status = 'operational'{scope} ORDER BY play_id"""


def operational_plays(cur, ph) -> list[dict]:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_OPERATIONAL_PLAYS, ph, clause), params)
    return _rows(cur)


SQL_COUNT_OPERATIONAL_PLAYS = """SELECT COUNT(*) AS n FROM meta_playbooks
    WHERE status='operational'{scope}"""


def count_operational_plays(cur, ph) -> int:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_COUNT_OPERATIONAL_PLAYS, ph, clause), params)
    return _one(cur)["n"]


# --------------------------------------------------------- compilations

SQL_PENDING_COMPILATIONS_FOR_RUN = """SELECT compile_id FROM meta_compilations
    WHERE status = 'hitl_pending' AND run_id = {ph}
    AND play_id = {ph}"""


def pending_compilations_for_run(cur, ph, run_id: str,
                                 play_id: str) -> list[str]:
    cur.execute(_fmt(SQL_PENDING_COMPILATIONS_FOR_RUN, ph), (run_id, play_id))
    return [r["compile_id"] for r in _rows(cur)]


SQL_SUPERSEDE_COMPILATION = """UPDATE meta_compilations SET status='superseded',
    reason={ph}, updated_at={ph} WHERE compile_id={ph}"""


def supersede_compilation(cur, ph, compile_id: str, reason: str) -> None:
    cur.execute(_fmt(SQL_SUPERSEDE_COMPILATION, ph),
                (reason, _now(), compile_id))


SQL_SUPERSEDE_CAPABILITY_REQUESTS = """UPDATE meta_capability_requests
    SET status='superseded', reason={ph}, resolved_at={ph}
    WHERE compile_id={ph} AND status='open'"""


def supersede_capability_requests(cur, ph, compile_id: str,
                                  reason: str) -> None:
    cur.execute(_fmt(SQL_SUPERSEDE_CAPABILITY_REQUESTS, ph),
                (reason, _now(), compile_id))


SQL_INSERT_COMPILATION = """INSERT INTO meta_compilations (compile_id,
    template_id, play_id, source_md, rulebook_json, play_json, review_md,
    notes_md, run_id, status, workspace_code, created_at, updated_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_compilation(cur, ph, compile_id, template_id, play_id, source_md,
                       rulebook_json, play_json, review_md, notes_md,
                       run_id, status) -> None:
    cur.execute(_fmt(SQL_INSERT_COMPILATION, ph),
                (compile_id, template_id, play_id, source_md, rulebook_json,
                 play_json, review_md, notes_md, run_id, status,
                 _workspace(), _now(), _now()))


SQL_PENDING_COMPILATIONS = """SELECT compile_id, template_id, play_id, run_id,
    created_at FROM meta_compilations
    WHERE status = 'hitl_pending'{scope} ORDER BY compile_id"""


def pending_compilations(cur, ph) -> list[dict]:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_PENDING_COMPILATIONS, ph, clause), params)
    return _rows(cur)


SQL_COMPILATIONS_BY_PLAY = """SELECT compile_id, template_id, play_id, status,
    reviewer, reason, created_at FROM meta_compilations
    WHERE play_id = {ph}{scope} ORDER BY compile_id"""
SQL_COMPILATIONS_BY_TEMPLATE = """SELECT compile_id, template_id, play_id,
    status, reviewer, reason, created_at FROM meta_compilations
    WHERE template_id = {ph}{scope} ORDER BY compile_id"""
SQL_LATEST_PRIOR_DRAFT = """SELECT compile_id, status, rulebook_json
    FROM meta_compilations WHERE template_id = {ph}{scope}
    ORDER BY compile_id DESC LIMIT 1"""
SQL_ALL_COMPILATIONS = """SELECT compile_id, template_id, play_id, status,
    reviewer, reason, created_at FROM meta_compilations WHERE 1=1{scope}
    ORDER BY compile_id DESC LIMIT 50"""


def all_compilations(cur, ph) -> list[dict]:
    """Every recent compilation in this workspace, newest first - what the
    compile pipeline is HANDED so the binding-constraints thread survives a
    draft inventing a fresh template id. Measured across seven rounds of
    one playbook: the self-chosen ids drifted (TPL-BARRIER-FIELD,
    TPL-barrier-field, TPL-BARRIERS-FIELD), and a history looked up by any
    one of them missed the others' rejections."""
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_ALL_COMPILATIONS, ph, clause), params)
    return _rows(cur)


def latest_prior_draft(cur, ph, template_id: str):
    """The most recent draft of a template, whatever became of it - what a
    NEW draft is diffed against so a regression is a review line rather
    than a memory test. Called before the new row is inserted."""
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_LATEST_PRIOR_DRAFT, ph, clause),
                (template_id, *params))
    rows = _rows(cur)
    return rows[0] if rows else None


def compilation_history(cur, ph, target: str) -> list[dict]:
    """Every compilation of a play (PLAY-...) or a template, oldest first."""
    clause, params = _scope_sql(ph)
    if str(target).startswith("PLAY-"):
        cur.execute(_fmt(SQL_COMPILATIONS_BY_PLAY, ph, clause),
                    (target, *params))
    else:
        cur.execute(_fmt(SQL_COMPILATIONS_BY_TEMPLATE, ph, clause),
                    (target, *params))
    return _rows(cur)


SQL_GET_COMPILATION = "SELECT * FROM meta_compilations WHERE compile_id = {ph}"


def get_compilation(cur, ph, compile_id: str) -> dict | None:
    cur.execute(_fmt(SQL_GET_COMPILATION, ph), (compile_id,))
    return _one(cur)


SQL_COMPILATION_FOR_APPROVAL = """SELECT status, rulebook_json, play_json
    FROM meta_compilations WHERE compile_id = {ph}"""


def compilation_for_approval(cur, ph, compile_id: str) -> dict | None:
    cur.execute(_fmt(SQL_COMPILATION_FOR_APPROVAL, ph), (compile_id,))
    return _one(cur)


SQL_COMPILATION_STATUS = """SELECT status FROM meta_compilations
    WHERE compile_id = {ph}"""


def compilation_status(cur, ph, compile_id: str) -> dict | None:
    cur.execute(_fmt(SQL_COMPILATION_STATUS, ph), (compile_id,))
    return _one(cur)


SQL_APPROVE_COMPILATION = """UPDATE meta_compilations SET status='approved',
    reviewer={ph}, reason={ph}, updated_at={ph} WHERE compile_id={ph}"""


def approve_compilation(cur, ph, compile_id, who, reason) -> None:
    cur.execute(_fmt(SQL_APPROVE_COMPILATION, ph),
                (who, reason, _now(), compile_id))


SQL_REJECT_COMPILATION = """UPDATE meta_compilations SET status='rejected',
    reviewer={ph}, reason={ph}, updated_at={ph} WHERE compile_id={ph}"""


def reject_compilation(cur, ph, compile_id, who, reason) -> None:
    cur.execute(_fmt(SQL_REJECT_COMPILATION, ph),
                (who, reason, _now(), compile_id))


# -------------------------------------------------- capability requests

SQL_INSERT_CAPABILITY_REQUEST = """INSERT INTO meta_capability_requests
    (workspace_code, compile_id, play_id, template_id, need, quoted,
    compiled_as, status, created_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_capability_request(cur, ph, compile_id, play_id, template_id,
                              need, quoted, compiled_as) -> None:
    cur.execute(_fmt(SQL_INSERT_CAPABILITY_REQUEST, ph),
                (_workspace() or None, compile_id, play_id, template_id,
                 need, quoted or None, compiled_as or None, "open", _now()))


SQL_CAPABILITY_REQUEST_STATUS = """SELECT status FROM meta_capability_requests
    WHERE id = {ph}"""


def capability_request_status(cur, ph, request_id: int) -> dict | None:
    cur.execute(_fmt(SQL_CAPABILITY_REQUEST_STATUS, ph), (int(request_id),))
    return _one(cur)


SQL_RESOLVE_CAPABILITY_REQUEST = """UPDATE meta_capability_requests
    SET status='resolved', resolved_by={ph}, reason={ph}, resolved_at={ph}
    WHERE id = {ph}"""


def resolve_capability_request(cur, ph, request_id: int, who: str,
                               reason: str) -> None:
    cur.execute(_fmt(SQL_RESOLVE_CAPABILITY_REQUEST, ph),
                (who, reason, _now(), int(request_id)))


SQL_LIST_CAPABILITY_REQUESTS = """SELECT id, play_id, template_id, compile_id,
    need, quoted, compiled_as, status, resolved_by, reason, created_at,
    resolved_at FROM meta_capability_requests
    WHERE 1=1{scope} ORDER BY id DESC"""
SQL_LIST_OPEN_CAPABILITY_REQUESTS = """SELECT id, play_id, template_id,
    compile_id, need, quoted, compiled_as, status, resolved_by, reason,
    created_at, resolved_at FROM meta_capability_requests
    WHERE 1=1 AND status = 'open'{scope} ORDER BY id DESC"""


def list_capability_requests(cur, ph, include_resolved: bool) -> list[dict]:
    clause, params = _scope_sql(ph)
    if include_resolved:
        cur.execute(_fmt(SQL_LIST_CAPABILITY_REQUESTS, ph, clause), params)
    else:
        cur.execute(_fmt(SQL_LIST_OPEN_CAPABILITY_REQUESTS, ph, clause),
                    params)
    return _rows(cur)


# ------------------------------------------------------------ unmatched

SQL_INSERT_UNMATCHED = """INSERT INTO meta_unmatched_requests (workspace_code,
    trigger_text, known_triggers_json, requested_by, requested_at)
    VALUES ({ph},{ph},{ph},{ph},{ph})"""


def insert_unmatched(cur, ph, text: str, known_json: str,
                     requester: str | None) -> None:
    cur.execute(_fmt(SQL_INSERT_UNMATCHED, ph),
                (_workspace() or None, text, known_json, requester or None,
                 _now()))


SQL_COUNT_UNMATCHED_TEXT = """SELECT COUNT(*) AS n FROM meta_unmatched_requests
    WHERE lower(trigger_text) = {ph}{scope}"""


def count_unmatched_text(cur, ph, text_lower: str) -> int:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_COUNT_UNMATCHED_TEXT, ph, clause),
                (text_lower, *params))
    return int(_one(cur)["n"])


SQL_UNMATCHED_GROUPED = """SELECT MIN(trigger_text) AS trigger_text,
           COUNT(*) AS times, MIN(requested_at) AS first_at,
           MAX(requested_at) AS last_at
    FROM meta_unmatched_requests WHERE 1=1{scope}
    GROUP BY lower(trigger_text)
    ORDER BY COUNT(*) DESC, MAX(requested_at) DESC
    LIMIT {ph}"""


def unmatched_grouped(cur, ph, limit: int) -> list[dict]:
    """Misses grouped by text, most asked first: ``{text, times, first_at,
    last_at}``."""
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_UNMATCHED_GROUPED, ph, clause),
                (*params, int(limit)))
    return [{"text": r["trigger_text"], "times": int(r["times"]),
             "first_at": r["first_at"], "last_at": r["last_at"]}
            for r in _rows(cur)]


SQL_COUNT_UNMATCHED = """SELECT COUNT(*) AS n FROM meta_unmatched_requests
    WHERE 1=1{scope}"""


def count_unmatched(cur, ph) -> int:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_COUNT_UNMATCHED, ph, clause), params)
    return int(_one(cur)["n"])


# ------------------------------------------------------------- stagings

SQL_INSERT_STAGING = """INSERT INTO meta_stagings (staging_id, play_id, run_id,
    account_id, persona, brands, summary_json, verdict_json,
    status, workspace_code, created_at, updated_at)
    VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"""


def insert_staging(cur, ph, staging_id, play_id, run_id, account_id, persona,
                   brands_json, summary_json, verdict_json, status) -> None:
    cur.execute(_fmt(SQL_INSERT_STAGING, ph),
                (staging_id, play_id, run_id, account_id, persona,
                 brands_json, summary_json, verdict_json, status,
                 _workspace(), _now(), _now()))


SQL_PENDING_STAGINGS = """SELECT staging_id, play_id, run_id, account_id,
    persona, status, created_at FROM meta_stagings
    WHERE status = 'hitl_pending'{scope} ORDER BY staging_id"""


def pending_stagings(cur, ph) -> list[dict]:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_PENDING_STAGINGS, ph, clause), params)
    return _rows(cur)


SQL_STAGING_STATUS = "SELECT status FROM meta_stagings WHERE staging_id = {ph}"


def staging_status(cur, ph, staging_id: str) -> dict | None:
    cur.execute(_fmt(SQL_STAGING_STATUS, ph), (staging_id,))
    return _one(cur)


SQL_SET_STAGING_STATUS = """UPDATE meta_stagings SET status={ph}, reviewer={ph},
    reason={ph}, receipt={ph}, updated_at={ph} WHERE staging_id={ph}"""


def set_staging_status(cur, ph, staging_id, to, reviewer, reason,
                       receipt) -> None:
    cur.execute(_fmt(SQL_SET_STAGING_STATUS, ph),
                (to, reviewer, reason, receipt, _now(), staging_id))


SQL_STAGING_FOR_ROUTE = """SELECT status, persona, account_id, summary_json,
    brands FROM meta_stagings WHERE staging_id = {ph}"""


def staging_for_route(cur, ph, staging_id: str) -> dict | None:
    cur.execute(_fmt(SQL_STAGING_FOR_ROUTE, ph), (staging_id,))
    return _one(cur)


SQL_STAGING_FOR_RELEASE = """SELECT status, play_id, account_id, summary_json,
    verdict_json FROM meta_stagings WHERE staging_id = {ph}"""


def staging_for_release(cur, ph, staging_id: str) -> dict | None:
    cur.execute(_fmt(SQL_STAGING_FOR_RELEASE, ph), (staging_id,))
    return _one(cur)


SQL_STAGING_COUNTS = """SELECT status, COUNT(*) AS n FROM meta_stagings
    WHERE 1=1{scope} GROUP BY status"""


def staging_counts(cur, ph) -> dict:
    clause, params = _scope_sql(ph)
    cur.execute(_fmt(SQL_STAGING_COUNTS, ph, clause), params)
    return {r["status"]: r["n"] for r in _rows(cur)}
