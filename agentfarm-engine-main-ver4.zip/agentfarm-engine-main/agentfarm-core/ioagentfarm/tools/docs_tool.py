"""``iof-docs`` — live search over the AI Core documentation.

The documentation is the source of truth; this tool reads it AT QUERY TIME, so
it is always in sync with whatever markdown is on disk. Nothing is embedded in
an agent skill and nothing is pre-indexed — edit the docs and the next query
sees the change. Jarvis (or any agent) execs this to answer a user's "how do
I…" / "where in the docs…" / "I'm stuck" question and cite the exact page.

Docs directory resolution, most explicit first:
  1. ``--docs-dir`` argument;
  2. ``AICORE_DOCS_DIR`` environment variable (what a deployment sets, pointing
     at the mounted/synced doc set);
  3. an ``aicore_docusaurus`` directory found by walking up from the current
     directory (developer checkout);
  4. a copy bundled with the package, if present.

Usage:
  iof-docs "how do I create a workflow"        # ranked sections + page paths
  iof-docs --map                                # the table of contents
  iof-docs "connect an mcp server" --json       # machine-readable
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

#: Printed under human-readable output. A reader-facing reminder that costs one
#: line — and the only thing that reliably stopped an agent inventing a CLI
#: name. Told 13 times in its own instructions that the command is ``aicore``,
#: it still wrote ``aio`` twice: a generative prior can outweigh instruction,
#: but not a fact sitting in the tool output it just read. Suppressed in
#: --json, which is parsed rather than read.
_CLI_FOOTER = ("[the CLI is `aicore` — use the commands exactly as the pages "
               "show them; do not abbreviate or reconstruct them]")

_TOKEN = re.compile(r"[A-Za-z0-9_]+")
_H2 = re.compile(r"^##\s+(.+?)\s*$", re.M)
_FENCE = re.compile(r"```.*?```", re.S)


def _resolve_docs_dir(explicit: Optional[str]) -> Optional[Path]:
    if explicit:
        p = Path(explicit).expanduser()
        return p if p.is_dir() else None
    env = (os.environ.get("AICORE_DOCS_DIR") or "").strip()
    if env:
        p = Path(env).expanduser()
        if p.is_dir():
            return p
    # walk up from cwd looking for aicore_docusaurus
    here = Path.cwd()
    for base in [here, *here.parents]:
        cand = base / "aicore_docusaurus"
        if cand.is_dir():
            return cand
    # bundled copy beside the package (optional)
    bundled = Path(__file__).resolve().parent.parent / "docs_site"
    return bundled if bundled.is_dir() else None


def _frontmatter(text: str) -> Tuple[Dict[str, str], str]:
    """Return (frontmatter dict, body). Tolerates a BOM."""
    t = text.lstrip("﻿")
    if not t.startswith("---"):
        return {}, t
    parts = t.split("---", 2)
    if len(parts) < 3:
        return {}, t
    fm: Dict[str, str] = {}
    for line in parts[1].splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            fm[k.strip()] = v.strip().strip('"').strip("'")
    return fm, parts[2]


def _tokens(text: str) -> List[str]:
    return [w.lower() for w in _TOKEN.findall(text or "")]


class Section:
    __slots__ = ("page", "title", "heading", "body", "tokens")

    def __init__(self, page: str, title: str, heading: str, body: str) -> None:
        self.page = page
        self.title = title
        self.heading = heading
        self.body = body
        self.tokens = _tokens(f"{title} {heading} {body}")


def _load_sections(docs_dir: Path) -> List[Section]:
    """Split every published page into its ## sections."""
    sections: List[Section] = []
    for md in sorted(docs_dir.rglob("*.md")):
        if md.name.startswith("_"):
            continue
        raw = md.read_text(encoding="utf-8", errors="replace")
        fm, body = _frontmatter(raw)
        title = fm.get("title") or md.stem
        rel = md.relative_to(docs_dir).as_posix()
        body_nocode = _FENCE.sub(" ", body)
        # split on H2 headings; the preamble before the first H2 is its own section
        parts = _H2.split(body_nocode)
        # parts = [preamble, head1, text1, head2, text2, ...]
        preamble = parts[0].strip()
        if preamble:
            sections.append(Section(rel, title, "(intro)", preamble))
        for i in range(1, len(parts), 2):
            head = parts[i].strip()
            txt = parts[i + 1].strip() if i + 1 < len(parts) else ""
            sections.append(Section(rel, title, head, txt))
    return sections


def _score(sec: Section, q_tokens: List[str]) -> float:
    if not q_tokens:
        return 0.0
    qset = set(q_tokens)
    title_t = set(_tokens(sec.title))
    head_t = set(_tokens(sec.heading))
    body_t = set(sec.tokens)
    # weighted overlap: title and heading matches count more than body
    s = 0.0
    s += 4.0 * len(qset & title_t)
    s += 3.0 * len(qset & head_t)
    s += 1.0 * sum(sec.tokens.count(t) for t in qset)
    return s


def _snippet(body: str, q_tokens: List[str], width: int = 240) -> str:
    low = body.lower()
    for t in q_tokens:
        i = low.find(t)
        if i >= 0:
            start = max(0, i - width // 3)
            return " ".join(body[start:start + width].split())
    return " ".join(body[:width].split())


def cmd_map(docs_dir: Path, as_json: bool) -> None:
    """Print the table of contents: section folders -> pages -> titles."""
    pages: List[Tuple[str, str, str]] = []
    for md in sorted(docs_dir.rglob("*.md")):
        if md.name.startswith("_"):
            continue
        fm, _ = _frontmatter(md.read_text(encoding="utf-8", errors="replace"))
        rel = md.relative_to(docs_dir).as_posix()
        pages.append((rel, fm.get("title") or md.stem, fm.get("description") or ""))
    if as_json:
        print(json.dumps([{"page": p, "title": t, "description": d}
                          for p, t, d in pages], ensure_ascii=False))
        return
    section = None
    for rel, title, desc in pages:
        top = rel.split("/")[0]
        if top != section:
            section = top
            print(f"\n{section}")
        indent = "  " * rel.count("/")
        print(f"{indent}- {title}  [{rel}]")
        if desc:
            print(f"{indent}    {desc}")


def cmd_page(docs_dir: Path, page: str, as_json: bool) -> int:
    """Print one page in full.

    Search returns SNIPPETS, and a snippet is enough to locate an answer but
    not to state a procedure: asked how to create a workflow, an agent with
    only snippets invented a CLI name (`aio` for `aicore`) to fill the gap it
    could not read. Its own reasoning said "the docs tool doesn't have a
    --read option" — so this is that option. Search to find the page, read the
    page to answer from it.
    """
    target = (docs_dir / page).resolve()
    try:
        target.relative_to(docs_dir.resolve())
    except ValueError:
        print(f"{page!r} is outside the documentation set.", file=sys.stderr)
        return 2
    if not target.is_file():
        alt = target.with_suffix(".md")
        if alt.is_file():
            target = alt
        else:
            print(f"No such page: {page}. Use `iof-docs --map` to list pages.",
                  file=sys.stderr)
            return 2
    text = target.read_text(encoding="utf-8", errors="replace")
    if as_json:
        print(json.dumps({"page": page, "content": text}, ensure_ascii=False))
    else:
        print(text)
        print(_CLI_FOOTER)
    return 0


def cmd_search(docs_dir: Path, query: str, limit: int, as_json: bool) -> None:
    q_tokens = _tokens(query)
    sections = _load_sections(docs_dir)
    scored = [(_score(s, q_tokens), s) for s in sections]
    scored = [(sc, s) for sc, s in scored if sc > 0]
    scored.sort(key=lambda x: -x[0])
    hits = scored[:limit]
    if as_json:
        print(json.dumps([{
            "page": s.page, "title": s.title, "heading": s.heading,
            "score": sc, "snippet": _snippet(s.body, q_tokens),
        } for sc, s in hits], ensure_ascii=False))
        return
    if not hits:
        print(f"No documentation section matches {query!r}. "
              f"Try `iof-docs --map` for the table of contents.")
        return
    print(f"Documentation matches for {query!r}:\n")
    for sc, s in hits:
        print(f"  {s.title} -> {s.heading}")
        print(f"    page: {s.page}")
        print(f"    {_snippet(s.body, q_tokens)}")
        print()
    print(_CLI_FOOTER)


def _utf8_stdout() -> None:
    """Doc content carries em-dashes and smart quotes; printing them to a
    non-UTF-8 Windows console raises UnicodeEncodeError. Reconfigure the
    existing streams in place (never rebind — that closes a borrowed buffer)
    with errors='replace' so a snippet can never crash the tool an agent execs.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            if (getattr(stream, "encoding", "") or "").lower().replace("-", "") != "utf8":
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> None:
    _utf8_stdout()
    ap = argparse.ArgumentParser(
        prog="iof-docs",
        description="Live search over the AI Core documentation (always in "
                    "sync — reads the markdown at query time).")
    ap.add_argument("query", nargs="?", default="", help="what to look up")
    ap.add_argument("--map", action="store_true",
                    help="print the table of contents instead of searching")
    ap.add_argument("--page", default=None, metavar="PATH",
                    help="print one page in full, by the path search reports "
                         "(e.g. 07-reference/02-workflow-yaml.md)")
    ap.add_argument("--limit", type=int, default=6, help="max results")
    ap.add_argument("--json", action="store_true", dest="as_json")
    ap.add_argument("--docs-dir", default=None,
                    help="override the documentation directory")
    args = ap.parse_args()

    docs_dir = _resolve_docs_dir(args.docs_dir)
    if docs_dir is None:
        print("Documentation directory not found. Set AICORE_DOCS_DIR to the "
              "aicore_docusaurus folder, or pass --docs-dir.", file=sys.stderr)
        raise SystemExit(2)

    if args.map:
        cmd_map(docs_dir, args.as_json)
        return
    if args.page:
        raise SystemExit(cmd_page(docs_dir, args.page, args.as_json))
    if not args.query:
        ap.error("a query is required unless --map or --page is given")
    cmd_search(docs_dir, args.query, args.limit, args.as_json)


if __name__ == "__main__":
    sys.exit(main())
