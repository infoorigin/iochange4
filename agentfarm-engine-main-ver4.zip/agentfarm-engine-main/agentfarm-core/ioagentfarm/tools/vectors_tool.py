"""``iof-vectors`` - a local, serverless vector index and the engine's own
embedding surface.

The harness could QUERY five enterprise vector stores through ``vectorfs``
(read-only by construction) with one query-side embedder living in the
TypeScript tool, and nothing in it could embed or index a document. This
tool is the INDEX half: one SQLite file, no server, chunk + embed + store +
search, so "index a folder of documents and retrieve from it" works on a
laptop with no key and on a pod with an OpenAI-compatible endpoint.

Store: ``--store <path>`` (default ``$IOF_VECTORS_STORE``, else
``./metadata/vectors.db`` when ``./metadata`` exists, else ``./vectors.db``).
Two tables - ``documents`` and ``chunks`` - and every chunk records the
embedder model and dimension it was produced with, because vectors from two
models are not comparable and ``search`` refuses to pretend otherwise.

Embedders (``--embedder`` or ``EMBEDDING_PROVIDER``):

* ``openai`` - any OpenAI-compatible ``/v1/embeddings`` endpoint. Reads the
  SAME variables as ``vectorfs``'s query-side embedder so one configuration
  serves both tools: ``EMBEDDING_API_KEY``, ``EMBEDDING_MODEL``,
  ``EMBEDDING_BASE_URL``. Requests are batched; the dimension is taken from
  the response, never inferred from the model name.
* ``hash`` - a deterministic OFFLINE embedder: hashed bag-of-words into N
  dimensions, unit-normalised. It is LEXICAL, not semantic - two passages
  score close when they share words, not when they mean the same thing. It
  exists for tests and key-less demos; say so wherever its results are shown.

Commands: ``index``, ``search``, ``embed``, ``status``, ``delete``,
``reindex``. Every command honours ``--json`` so an agent can parse the
result; notices go to stderr so the JSON on stdout stays clean.

Pure standard library plus ``sqlite3``; ``httpx`` only for the ``openai``
embedder; ``numpy`` is used for the similarity scan when it is importable and
never required.
"""
from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import io
import json
import math
import os
import re
import sqlite3
import struct
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------

DEFAULT_CHUNK = 800
DEFAULT_OVERLAP = 100
DEFAULT_HASH_DIMS = 256
DEFAULT_OPENAI_MODEL = "text-embedding-3-small"
DEFAULT_OPENAI_BASE = "https://api.openai.com/v1"
OPENAI_BATCH = 64
STORE_ENV = "IOF_VECTORS_STORE"
PROVIDER_ENV = "EMBEDDING_PROVIDER"

HASH_NOTICE = ("embedder: hash - LEXICAL, not semantic (hashed bag-of-words); "
               "for tests and key-less demos only")

#: Files never indexed even when a glob or directory walk reaches them.
_SKIP_NAMES = {"vectors.db", "vectors.db-journal", "vectors.db-wal"}

_SCHEMA = """
CREATE TABLE IF NOT EXISTS documents(
    doc_id      TEXT PRIMARY KEY,
    path        TEXT NOT NULL,
    title       TEXT,
    meta_json   TEXT NOT NULL DEFAULT '{}',
    indexed_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chunks(
    chunk_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_id      TEXT NOT NULL REFERENCES documents(doc_id) ON DELETE CASCADE,
    ordinal     INTEGER NOT NULL,
    text        TEXT NOT NULL,
    embedding   BLOB NOT NULL,
    model       TEXT NOT NULL,
    dims        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS chunks_doc ON chunks(doc_id, ordinal);
"""


class VectorsError(Exception):
    """A refusal or a failure the user can act on; the message is the answer."""


# ---------------------------------------------------------------------------
# vectors as bytes
# ---------------------------------------------------------------------------

def encode_vector(vec: list[float]) -> bytes:
    """float32, little-endian, fixed byte order so a store moves between hosts."""
    return struct.pack(f"<{len(vec)}f", *vec)


def decode_vector(blob: bytes) -> list[float]:
    n = len(blob) // 4
    return list(struct.unpack(f"<{n}f", blob))


def normalise(vec: list[float]) -> list[float]:
    norm = math.sqrt(sum(x * x for x in vec))
    if norm == 0.0:
        return list(vec)
    return [x / norm for x in vec]


def cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity, pure Python. Stored vectors are unit-normalised, so
    with a normalised query this is a plain dot product."""
    if len(a) != len(b):
        raise VectorsError(
            f"cannot compare a {len(a)}-dim vector with a {len(b)}-dim one")
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / (na * nb)


# ---------------------------------------------------------------------------
# embedders
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"[a-z0-9]+")


class HashEmbedder:
    """Deterministic feature-hashing bag-of-words. LEXICAL, NOT SEMANTIC.

    Each token lands in a bucket chosen by sha256 (never Python's salted
    ``hash``), with a sign bit from the same digest so collisions partly
    cancel; term frequency is sublinear; the result is unit-normalised.
    """

    kind = "hash"

    def __init__(self, dims: int = DEFAULT_HASH_DIMS):
        if dims < 8:
            raise VectorsError("--dims must be at least 8 for the hash embedder")
        self.dims = dims
        self.model = f"hash-bow-{dims}"

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._one(t) for t in texts]

    def _one(self, text: str) -> list[float]:
        counts: dict[str, int] = {}
        for tok in _TOKEN_RE.findall(text.lower()):
            if len(tok) < 2:
                continue
            counts[tok] = counts.get(tok, 0) + 1
        vec = [0.0] * self.dims
        for tok, n in counts.items():
            digest = hashlib.sha256(tok.encode("utf-8")).digest()
            bucket = int.from_bytes(digest[:4], "little") % self.dims
            sign = 1.0 if digest[4] & 1 else -1.0
            vec[bucket] += sign * (1.0 + math.log(n))
        return normalise(vec)


class OpenAIEmbedder:
    """Any OpenAI-compatible ``POST {base}/embeddings``.

    The dimension is what the endpoint RETURNS - the TypeScript embedder
    inferred it from the model name, which is wrong for every model that is
    not one of the two it knew about.
    """

    kind = "openai"

    def __init__(self, model: str, base_url: str, api_key: str,
                 batch: int = OPENAI_BATCH, transport=None, timeout: float = 60.0):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.batch = max(1, batch)
        self.dims: int | None = None
        self._transport = transport
        self._timeout = timeout

    def _client(self):
        try:
            import httpx
        except ImportError as e:  # pragma: no cover - httpx is a core dep
            raise VectorsError("the openai embedder needs httpx installed") from e
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        kw = {"headers": headers, "timeout": self._timeout}
        if self._transport is not None:
            kw["transport"] = self._transport
        return httpx.Client(**kw)

    def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        out: list[list[float]] = []
        with self._client() as client:
            for start in range(0, len(texts), self.batch):
                batch = texts[start:start + self.batch]
                resp = client.post(f"{self.base_url}/embeddings",
                                   json={"model": self.model, "input": batch})
                if resp.status_code != 200:
                    raise VectorsError(
                        f"embeddings endpoint {self.base_url}/embeddings answered "
                        f"{resp.status_code}: {resp.text[:300]}")
                data = resp.json().get("data") or []
                if len(data) != len(batch):
                    raise VectorsError(
                        f"embeddings endpoint returned {len(data)} vectors for "
                        f"{len(batch)} inputs")
                rows = sorted(data, key=lambda d: d.get("index", 0))
                for row in rows:
                    vec = [float(x) for x in row["embedding"]]
                    if self.dims is None:
                        self.dims = len(vec)
                    elif len(vec) != self.dims:
                        raise VectorsError(
                            f"embeddings endpoint returned {len(vec)}-dim and "
                            f"{self.dims}-dim vectors in one response")
                    out.append(normalise(vec))
        return out


def resolve_provider(explicit: str | None) -> str:
    """``--embedder`` > ``EMBEDDING_PROVIDER`` > openai when a key is set >
    hash. Never silent: the caller prints which one was chosen."""
    # Literal names at the read sites: scripts/gen_env_example.py discovers
    # variables from `os.environ.get("<literal>")`, so a constant here would
    # leave them out of the generated reference.
    kind = (explicit or os.environ.get("EMBEDDING_PROVIDER", "") or "").strip().lower()
    if not kind:
        kind = "openai" if os.environ.get("EMBEDDING_API_KEY", "").strip() else "hash"
    if kind not in ("openai", "hash"):
        raise VectorsError(
            f"unknown embedder {kind!r} - legal values: openai, hash")
    return kind


#: Test seam: an httpx transport handed to every OpenAIEmbedder built here.
_TRANSPORT = None


def make_embedder(kind: str, model: str | None = None, dims: int | None = None):
    if kind == "hash":
        return HashEmbedder(dims or DEFAULT_HASH_DIMS)
    return OpenAIEmbedder(
        model=model or os.environ.get("EMBEDDING_MODEL", "").strip()
        or DEFAULT_OPENAI_MODEL,
        base_url=os.environ.get("EMBEDDING_BASE_URL", "").strip()
        or DEFAULT_OPENAI_BASE,
        api_key=os.environ.get("EMBEDDING_API_KEY", "").strip(),
        transport=_TRANSPORT,
    )


# ---------------------------------------------------------------------------
# chunking + loading
# ---------------------------------------------------------------------------

def chunk_text(text: str, size: int = DEFAULT_CHUNK,
               overlap: int = DEFAULT_OVERLAP) -> list[str]:
    """Sliding window over characters that snaps each break to whitespace.

    ``overlap`` characters of the previous chunk lead the next one so a
    sentence cut at the boundary is whole in at least one chunk.
    """
    if size <= 0:
        raise VectorsError("--chunk must be positive")
    if overlap < 0 or overlap >= size:
        raise VectorsError("--overlap must be >= 0 and smaller than --chunk")
    text = text.strip()
    if not text:
        return []
    if len(text) <= size:
        return [text]
    chunks: list[str] = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + size, n)
        if end < n:
            # snap back to the last whitespace inside the window, if any
            cut = max(text.rfind("\n", start, end), text.rfind(" ", start, end))
            if cut > start + size // 2:
                end = cut
        piece = text[start:end].strip()
        if piece:
            chunks.append(piece)
        if end >= n:
            break
        nxt = end - overlap
        start = nxt if nxt > start else end
    return chunks


def _looks_binary(head: bytes) -> bool:
    return b"\x00" in head


def load_document_text(path: Path) -> str | None:
    """Text of a file, or ``None`` when it is binary. CSV rows become one
    ``header: value | ...`` line each so a row is retrievable as a unit."""
    raw = path.read_bytes()
    if not raw.strip():
        return ""
    if _looks_binary(raw[:8192]):
        return None
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        try:
            text = raw.decode("latin-1")
        except UnicodeDecodeError:
            return None
    if text.startswith("\ufeff"):
        text = text[1:]
    if path.suffix.lower() == ".csv":
        rows = list(csv.reader(io.StringIO(text)))
        if not rows:
            return ""
        header = [h.strip() for h in rows[0]]
        lines = []
        for row in rows[1:]:
            if not any(c.strip() for c in row):
                continue
            cells = []
            for i, cell in enumerate(row):
                name = header[i] if i < len(header) and header[i] else f"col{i + 1}"
                cells.append(f"{name}: {cell.strip()}")
            lines.append(" | ".join(cells))
        return "\n".join(lines)
    return text


def title_for(path: Path, text: str, mode: str) -> str:
    if mode == "heading":
        for line in text.splitlines():
            s = line.strip()
            if s.startswith("#"):
                return s.lstrip("#").strip() or path.stem
            if s:
                break
    return path.stem


def doc_id_for(path: Path) -> str:
    """Stable id for a file: a short digest of its resolved path. Printed
    beside the path everywhere, accepted by ``delete``."""
    return hashlib.sha256(str(path.resolve()).encode("utf-8")).hexdigest()[:16]


def expand_inputs(specs: list[str]) -> list[Path]:
    """Directories walk recursively; globs expand (``**`` honoured); a plain
    path is itself. Hidden entries and the store's own files are skipped."""
    found: list[Path] = []
    for spec in specs:
        p = Path(spec)
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.is_file() and not _hidden(f, p) and f.name not in _SKIP_NAMES:
                    found.append(f)
        elif any(ch in spec for ch in "*?["):
            for m in sorted(glob.glob(spec, recursive=True)):
                mp = Path(m)
                if mp.is_file() and mp.name not in _SKIP_NAMES:
                    found.append(mp)
        elif p.is_file():
            found.append(p)
        else:
            raise VectorsError(f"no such file, directory or glob match: {spec}")
    seen: set[str] = set()
    out: list[Path] = []
    for f in found:
        key = str(f.resolve())
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out


def _hidden(f: Path, root: Path) -> bool:
    try:
        rel = f.relative_to(root)
    except ValueError:
        rel = f
    return any(part.startswith(".") for part in rel.parts)


# ---------------------------------------------------------------------------
# the store
# ---------------------------------------------------------------------------

def default_store_path() -> Path:
    env = os.environ.get("IOF_VECTORS_STORE", "").strip()
    if env:
        return Path(env)
    meta = Path("metadata")
    if meta.is_dir():
        return meta / "vectors.db"
    return Path("vectors.db")


class VectorStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.con = sqlite3.connect(str(self.path))
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.executescript(_SCHEMA)

    def close(self) -> None:
        self.con.close()

    # -- documents ---------------------------------------------------------
    def document(self, doc_id: str) -> dict | None:
        row = self.con.execute(
            "SELECT doc_id, path, title, meta_json, indexed_at FROM documents "
            "WHERE doc_id = ?", (doc_id,)).fetchone()
        if not row:
            return None
        return {"doc_id": row[0], "path": row[1], "title": row[2],
                "meta": json.loads(row[3] or "{}"), "indexed_at": row[4]}

    def documents(self) -> list[dict]:
        rows = self.con.execute(
            "SELECT doc_id, path, title, meta_json, indexed_at FROM documents "
            "ORDER BY path").fetchall()
        return [{"doc_id": r[0], "path": r[1], "title": r[2],
                 "meta": json.loads(r[3] or "{}"), "indexed_at": r[4]}
                for r in rows]

    def models(self) -> list[dict]:
        rows = self.con.execute(
            "SELECT model, dims, COUNT(*) FROM chunks GROUP BY model, dims "
            "ORDER BY model").fetchall()
        return [{"model": r[0], "dims": r[1], "chunks": r[2]} for r in rows]

    def counts(self) -> tuple[int, int]:
        d = self.con.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        c = self.con.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        return d, c

    def replace_document(self, doc_id: str, path: str, title: str, meta: dict,
                         chunks: list[str], vectors: list[list[float]],
                         model: str, dims: int) -> None:
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with self.con:
            self.con.execute("DELETE FROM chunks WHERE doc_id = ?", (doc_id,))
            self.con.execute(
                "INSERT INTO documents(doc_id, path, title, meta_json, indexed_at) "
                "VALUES(?,?,?,?,?) ON CONFLICT(doc_id) DO UPDATE SET path=excluded.path, "
                "title=excluded.title, meta_json=excluded.meta_json, "
                "indexed_at=excluded.indexed_at",
                (doc_id, path, title, json.dumps(meta, sort_keys=True), now))
            self.con.executemany(
                "INSERT INTO chunks(doc_id, ordinal, text, embedding, model, dims) "
                "VALUES(?,?,?,?,?,?)",
                [(doc_id, i, t, encode_vector(v), model, dims)
                 for i, (t, v) in enumerate(zip(chunks, vectors))])

    def delete_document(self, doc_id: str) -> int:
        with self.con:
            n = self.con.execute("SELECT COUNT(*) FROM chunks WHERE doc_id = ?",
                                 (doc_id,)).fetchone()[0]
            self.con.execute("DELETE FROM chunks WHERE doc_id = ?", (doc_id,))
            cur = self.con.execute("DELETE FROM documents WHERE doc_id = ?",
                                   (doc_id,))
            if cur.rowcount == 0:
                raise VectorsError(f"no document with id {doc_id!r} in {self.path}")
        return n

    def chunk_texts(self, doc_id: str) -> list[str]:
        rows = self.con.execute(
            "SELECT text FROM chunks WHERE doc_id = ? ORDER BY ordinal",
            (doc_id,)).fetchall()
        return [r[0] for r in rows]

    # -- search ------------------------------------------------------------
    def search(self, query_vec: list[float], model: str, top: int,
               min_score: float) -> list[dict]:
        present = self.models()
        names = sorted({m["model"] for m in present})
        if not present:
            return []
        if len(names) > 1:
            raise VectorsError(
                "the index holds vectors from more than one model: "
                + ", ".join(names)
                + " - vectors from different models are not comparable. Run "
                "`iof-vectors reindex` to re-embed everything with one model.")
        if names[0] != model:
            raise VectorsError(
                f"the index was built with model {names[0]!r}; the query "
                f"embedder is {model!r} - vectors from different models are not "
                f"comparable. Query with the embedder that built the index, or "
                f"run `iof-vectors reindex` to re-embed the index with {model!r}.")
        stored_dims = present[0]["dims"]
        if stored_dims != len(query_vec):
            raise VectorsError(
                f"the index holds {stored_dims}-dim vectors and the query is "
                f"{len(query_vec)}-dim - run `iof-vectors reindex`.")
        q = normalise(query_vec)
        rows = self.con.execute(
            "SELECT c.chunk_id, c.doc_id, c.ordinal, c.text, c.embedding, "
            "d.path, d.title FROM chunks c JOIN documents d ON d.doc_id = c.doc_id"
        ).fetchall()
        scores = _score_rows(q, [r[4] for r in rows])
        hits = []
        for r, s in zip(rows, scores):
            if s < min_score:
                continue
            hits.append({"score": round(float(s), 4), "doc_id": r[1],
                         "title": r[6], "path": r[5], "ordinal": r[2],
                         "chunk_id": r[0], "text": r[3]})
        hits.sort(key=lambda h: (-h["score"], h["path"], h["ordinal"]))
        return hits[:top]


def _score_rows(q: list[float], blobs: list[bytes]) -> list[float]:
    """Dot products against every stored vector - numpy when importable,
    pure Python otherwise. Both give the same numbers."""
    if not blobs:
        return []
    try:
        import numpy as np  # noqa: WPS433 - optional fast path
        mat = np.frombuffer(b"".join(blobs), dtype="<f4").reshape(len(blobs), -1)
        return (mat @ np.asarray(q, dtype="<f4")).tolist()
    except ImportError:
        return [sum(a * b for a, b in zip(q, decode_vector(blob))) for blob in blobs]


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------

@dataclass
class Ctx:
    store: VectorStore
    embedder_kind: str
    model_override: str | None
    dims_override: int | None
    as_json: bool
    _embedder: object | None = None

    def embedder(self):
        if self._embedder is None:
            self._embedder = make_embedder(self.embedder_kind,
                                           self.model_override,
                                           self.dims_override)
            if self.embedder_kind == "hash":
                _note(HASH_NOTICE)
        return self._embedder


def _note(msg: str) -> None:
    print(msg, file=sys.stderr)


def _emit(ctx: Ctx, payload: dict, text_lines: list[str]) -> None:
    if ctx.as_json:
        print(json.dumps(payload, indent=2, default=str))
    else:
        for line in text_lines:
            print(line)


def _plan_file(ctx: Ctx, path: Path, size: int, overlap: int,
               title_mode: str, force: bool) -> dict:
    """Decide what one file needs - nothing is embedded here, so every file
    that needs vectors can go to the endpoint in ONE batch afterwards."""
    doc_id = doc_id_for(path)
    raw = path.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    existing = ctx.store.document(doc_id)
    text = load_document_text(path)
    if text is None:
        return {"path": str(path), "doc_id": doc_id, "action": "skipped",
                "reason": "binary"}
    if not text.strip():
        return {"path": str(path), "doc_id": doc_id, "action": "skipped",
                "reason": "empty"}
    emb = ctx.embedder()
    if existing and not force:
        same_bytes = existing["meta"].get("sha256") == sha
        same_model = existing["meta"].get("model") == emb.model
        same_shape = (existing["meta"].get("chunk") == size
                      and existing["meta"].get("overlap") == overlap)
        if same_bytes and same_model and same_shape:
            return {"path": str(path), "doc_id": doc_id, "action": "unchanged",
                    "chunks": existing["meta"].get("chunks", 0)}
    pieces = chunk_text(text, size, overlap)
    plan = {"path": str(path), "doc_id": doc_id, "action": "pending",
            "title": title_for(path, text, title_mode), "pieces": pieces,
            "existing": existing,
            "meta": {"sha256": sha, "bytes": len(raw), "chunk": size,
                     "overlap": overlap, "chunks": len(pieces)}}
    if existing and existing["meta"].get("model") != emb.model:
        plan["reason"] = f"model {existing['meta'].get('model')} -> {emb.model}"
    return plan


def _run_plans(ctx: Ctx, plans: list[dict]) -> list[dict]:
    """Embed every pending chunk in one pass (the embedder batches the
    request), then write each document. Returns the per-file results."""
    pending = [p for p in plans if p["action"] == "pending"]
    if pending:
        emb = ctx.embedder()
        all_pieces = [t for p in pending for t in p["pieces"]]
        vectors = emb.embed(all_pieces)
        if len(vectors) != len(all_pieces):
            raise VectorsError(
                f"embedder returned {len(vectors)} vectors for "
                f"{len(all_pieces)} chunks")
        pos = 0
        for p in pending:
            n = len(p["pieces"])
            vecs = vectors[pos:pos + n]
            pos += n
            dims = len(vecs[0]) if vecs else (getattr(emb, "dims", 0) or 0)
            meta = dict(p["meta"], embedder=emb.kind, model=emb.model, dims=dims)
            ctx.store.replace_document(p["doc_id"], p["path"], p["title"], meta,
                                       p["pieces"], vecs, emb.model, dims)
            p["action"] = "updated" if p["existing"] else "indexed"
            p["chunks"] = n
    results = []
    for p in plans:
        r = {k: p[k] for k in ("path", "doc_id", "action") if k in p}
        for k in ("chunks", "reason", "source"):
            if k in p:
                r[k] = p[k]
        results.append(r)
    return results


def cmd_index(ctx: Ctx, args) -> int:
    files = expand_inputs(args.paths)
    if not files:
        raise VectorsError("nothing to index: no files matched")
    plans = [_plan_file(ctx, f, args.chunk, args.overlap, args.title_from,
                        force=False) for f in files]
    return _report_index(ctx, _run_plans(ctx, plans))


def _report_index(ctx: Ctx, results: list[dict]) -> int:
    counts = {k: sum(1 for r in results if r["action"] == k)
              for k in ("indexed", "updated", "unchanged", "skipped")}
    chunks = sum(r.get("chunks", 0) for r in results
                 if r["action"] in ("indexed", "updated"))
    emb = ctx._embedder
    payload = {"store": str(ctx.store.path), "embedder": ctx.embedder_kind,
               "model": getattr(emb, "model", None),
               "dims": getattr(emb, "dims", None),
               **counts, "chunks_written": chunks, "files": results}
    lines = []
    for r in results:
        extra = f" ({r['reason']})" if r.get("reason") else ""
        n = f" {r['chunks']} chunk(s)" if "chunks" in r else ""
        lines.append(f"{r['action']:9} {r['doc_id']}  {r['path']}{n}{extra}")
    lines.append(f"store {ctx.store.path}: {counts['indexed']} indexed, "
                 f"{counts['updated']} updated, {counts['unchanged']} unchanged, "
                 f"{counts['skipped']} skipped; {chunks} chunk(s) written"
                 + (f" with {emb.model} ({emb.dims} dims)" if emb else ""))
    _emit(ctx, payload, lines)
    return 0


def cmd_reindex(ctx: Ctx, args) -> int:
    docs = ctx.store.documents()
    if not docs:
        raise VectorsError(f"nothing to reindex: {ctx.store.path} holds no documents")
    plans = []
    for d in docs:
        p = Path(d["path"])
        if p.is_file():
            plan = _plan_file(ctx, p, d["meta"].get("chunk", DEFAULT_CHUNK),
                              d["meta"].get("overlap", DEFAULT_OVERLAP),
                              "filename" if d["title"] == p.stem else "heading",
                              force=True)
            plan["source"] = "file"
        else:
            # The file is gone; re-embed the text the index already holds.
            texts = ctx.store.chunk_texts(d["doc_id"])
            plan = {"path": d["path"], "doc_id": d["doc_id"], "action": "pending",
                    "title": d["title"], "pieces": texts, "existing": d,
                    "meta": dict(d["meta"], chunks=len(texts)),
                    "source": "stored text"}
        plans.append(plan)
    results = _run_plans(ctx, plans)
    for r in results:
        if r["action"] == "indexed":
            r["action"] = "updated"
    return _report_index(ctx, results)


def cmd_search(ctx: Ctx, args) -> int:
    if not args.query.strip():
        raise VectorsError("search needs a query")
    docs, chunks = ctx.store.counts()
    if chunks == 0:
        raise VectorsError(f"{ctx.store.path} holds no chunks - run "
                           "`iof-vectors index <path>` first")
    emb = ctx.embedder()
    qvec = emb.embed([args.query])[0]
    hits = ctx.store.search(qvec, emb.model, args.top, args.min_score)
    payload = {"store": str(ctx.store.path), "query": args.query,
               "embedder": emb.kind, "model": emb.model, "dims": len(qvec),
               "top": args.top, "min_score": args.min_score,
               "hits": [{**h, "snippet": _snippet(h["text"])} for h in hits]}
    lines = []
    if not hits:
        lines.append(f"no chunk scored >= {args.min_score} for: {args.query}")
    for i, h in enumerate(hits, 1):
        lines.append(f"{i}. score {h['score']:.4f}  {h['title']}  "
                     f"(doc {h['doc_id']}, chunk {h['ordinal']})  {h['path']}")
        lines.append(f"   {_snippet(h['text'])}")
    _emit(ctx, payload, lines)
    return 0


def _snippet(text: str, width: int = 200) -> str:
    one = " ".join(text.split())
    return one if len(one) <= width else one[:width - 3] + "..."


def cmd_embed(ctx: Ctx, args) -> int:
    emb = ctx.embedder()
    vec = emb.embed([args.text])[0]
    payload = {"embedder": emb.kind, "model": emb.model, "dims": len(vec),
               "vector": vec}
    head = ", ".join(f"{x:.4f}" for x in vec[:8])
    lines = [f"model {emb.model}  dims {len(vec)}  embedder {emb.kind}",
             f"[{head}, ...]"]
    _emit(ctx, payload, lines)
    return 0


def cmd_status(ctx: Ctx, args) -> int:
    docs, chunks = ctx.store.counts()
    models = ctx.store.models()
    size = ctx.store.path.stat().st_size if ctx.store.path.exists() else 0
    payload = {"store": str(ctx.store.path), "bytes": size, "documents": docs,
               "chunks": chunks, "models": models,
               "documents_list": [{"doc_id": d["doc_id"], "path": d["path"],
                                   "title": d["title"],
                                   "chunks": d["meta"].get("chunks"),
                                   "model": d["meta"].get("model"),
                                   "indexed_at": d["indexed_at"]}
                                  for d in ctx.store.documents()]}
    lines = [f"store      {ctx.store.path} ({size} bytes)",
             f"documents  {docs}", f"chunks     {chunks}"]
    if not models:
        lines.append("model      (none - the index is empty)")
    for m in models:
        lines.append(f"model      {m['model']}  dims {m['dims']}  chunks {m['chunks']}")
    if len(models) > 1:
        lines.append("WARNING    more than one model present - search will "
                     "refuse until `iof-vectors reindex` unifies them")
    for d in payload["documents_list"]:
        lines.append(f"  {d['doc_id']}  {d['chunks']:>4} chunk(s)  {d['path']}")
    _emit(ctx, payload, lines)
    return 0


def cmd_delete(ctx: Ctx, args) -> int:
    target = args.doc_id
    if ctx.store.document(target) is None and Path(target).exists():
        target = doc_id_for(Path(target))
    n = ctx.store.delete_document(target)
    payload = {"store": str(ctx.store.path), "deleted": target, "chunks": n}
    _emit(ctx, payload, [f"deleted {target}: {n} chunk(s) removed"])
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _common(p: argparse.ArgumentParser, top: bool) -> None:
    """The shared options, accepted BEFORE or AFTER the subcommand. On the
    subparsers they default to SUPPRESS so they only override when given."""
    d = (lambda v: v) if top else (lambda v: argparse.SUPPRESS)
    p.add_argument("--store", default=d(None),
                   help=f"SQLite file (default: ${STORE_ENV}, else "
                        "./metadata/vectors.db when ./metadata exists, else ./vectors.db)")
    p.add_argument("--embedder", choices=["openai", "hash"], default=d(None),
                   help=f"embedder (default: ${PROVIDER_ENV}, else openai when "
                        "EMBEDDING_API_KEY is set, else hash). hash is LEXICAL, "
                        "not semantic - for tests and key-less demos")
    p.add_argument("--model", default=d(None),
                   help="openai model name (default: $EMBEDDING_MODEL or "
                        f"{DEFAULT_OPENAI_MODEL})")
    p.add_argument("--dims", type=int, default=d(None),
                   help=f"hash embedder dimensions (default {DEFAULT_HASH_DIMS})")
    p.add_argument("--json", action="store_true", dest="as_json",
                   default=d(False), help="machine-readable output on stdout")


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="iof-vectors",
        description="Local, serverless vector index (one SQLite file) and the "
                    "engine's embedding surface. Embedders: openai (any "
                    "OpenAI-compatible /v1/embeddings endpoint; EMBEDDING_API_KEY, "
                    "EMBEDDING_MODEL, EMBEDDING_BASE_URL) or hash (offline, "
                    "LEXICAL not semantic - tests and key-less demos).")
    _common(ap, top=True)
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("index", help="index files (text, markdown, CSV rows); "
                                     "unchanged files are a no-op")
    p.add_argument("paths", nargs="+", help="file, directory or glob")
    p.add_argument("--chunk", type=int, default=DEFAULT_CHUNK,
                   help=f"chunk size in characters (default {DEFAULT_CHUNK})")
    p.add_argument("--overlap", type=int, default=DEFAULT_OVERLAP,
                   help=f"overlap in characters (default {DEFAULT_OVERLAP})")
    p.add_argument("--title-from", choices=["filename", "heading"],
                   default="filename", help="document title source")
    _common(p, top=False)

    p = sub.add_parser("search", help="nearest chunks to a query")
    p.add_argument("query")
    p.add_argument("--top", type=int, default=5)
    p.add_argument("--min-score", type=float, default=0.0, dest="min_score",
                   help="drop hits below this cosine score")
    _common(p, top=False)

    p = sub.add_parser("embed", help="embed one text; prints model and dims")
    p.add_argument("text")
    _common(p, top=False)

    p = sub.add_parser("status", help="documents, chunks, model, dims, store path")
    _common(p, top=False)

    p = sub.add_parser("delete", help="remove a document and its chunks")
    p.add_argument("doc_id", help="doc_id (from status/search) or the file path")
    _common(p, top=False)

    p = sub.add_parser("reindex", help="re-embed every document with the "
                                       "current embedder (files re-read when present)")
    _common(p, top=False)
    return ap


_COMMANDS = {"index": cmd_index, "search": cmd_search, "embed": cmd_embed,
             "status": cmd_status, "delete": cmd_delete, "reindex": cmd_reindex}


def _load_workspace_env() -> None:
    """An agent's exec subprocess is stripped to HOME/LANG/TERM plus a short
    allowlist; the workspace's own .env is where EMBEDDING_* live. Best
    effort - the binary must keep working outside any workspace."""
    # RESOLVE THE WORKSPACE THE WAY THE CLI DOES. Reading only
    # IOF_WORKSPACE meant the file was skipped on the machine the
    # getting-started guide builds, where the workspace is SELECTED
    # (`<IOF_ROOT>/active_workspace`) and the variable is never exported.
    # The cost was silent: EMBEDDING_* sat unread in the workspace .env
    # and the tool fell back to the lexical hash embedder, so a reader
    # built a keyword index believing it was semantic (walked
    # 2026-09-03). `selected_workspace` is the one resolution order the
    # CLI, the engine and the other iof-* tools already share.
    ws = os.environ.get("IOF_WORKSPACE", "").strip()
    if not ws:
        try:
            from ioagentfarm.engine.workspaces import selected_workspace
            ws = (selected_workspace()[0] or "").strip()
        except Exception:  # noqa: BLE001 - best effort by design
            ws = ""
    if not ws:
        return
    try:
        from ioagentfarm.engine.workspace_env import load_workspace_env
        load_workspace_env(ws)
    except Exception:  # noqa: BLE001 - best effort by design
        pass


def main(argv: list[str] | None = None) -> int:
    ap = build_parser()
    args = ap.parse_args(argv)
    _load_workspace_env()
    as_json = bool(getattr(args, "as_json", False))
    try:
        kind = resolve_provider(args.embedder)
        store_path = Path(args.store) if args.store else default_store_path()
        # `embed` is the embedding surface and reads no index; opening the
        # store here created an empty vectors.db in the cwd for a command
        # that never touched it (walked 2026-09-02).
        store = None if args.command == "embed" else VectorStore(store_path)
        try:
            ctx = Ctx(store=store, embedder_kind=kind, model_override=args.model,
                      dims_override=args.dims, as_json=as_json)
            return _COMMANDS[args.command](ctx, args)
        finally:
            if store is not None:
                store.close()
    except VectorsError as e:
        if as_json:
            print(json.dumps({"error": str(e)}))
        else:
            print(f"iof-vectors: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
    except Exception as e:  # noqa: BLE001 - a CLI must not print a traceback
        # AN UNREACHABLE ENDPOINT IS AN ORDINARY MISTAKE, NOT A CRASH. The
        # commonest one - a wrong EMBEDDING_BASE_URL - produced eighty
        # lines of traceback through httpx, and the frames named the
        # publisher's own distribution and import package on a customer's
        # screen (walked 2026-09-03). Set IOF_VECTORS_TRACEBACK=1 to see
        # the frames while debugging.
        if os.environ.get("IOF_VECTORS_TRACEBACK", "").strip() not in ("", "0"):
            raise
        kind = type(e).__name__
        detail = str(e).strip() or kind
        hint = ""
        if "Connect" in kind or "Timeout" in kind or "ConnectionError" in kind:
            hint = (" - check EMBEDDING_BASE_URL and that the endpoint is "
                    "reachable from this machine")
        if as_json:
            print(json.dumps({"error": detail, "error_type": kind}))
        else:
            print(f"iof-vectors: {detail}{hint}", file=sys.stderr)
            print("iof-vectors: set IOF_VECTORS_TRACEBACK=1 for the frames",
                  file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
