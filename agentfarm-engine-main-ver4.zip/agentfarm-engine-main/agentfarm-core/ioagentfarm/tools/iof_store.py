"""DB upsert writer — writes structured JSON/CSV to any table.

Called by workflow store steps and doc_ingestion validate step to persist
extracted and synthesized data to procurement.* tables (or main schema tables).

Usage:
    iof-store --table procurement.intelligence_reports \\
              --input intelligence_output.json --metadata-dir /path/to/metadata

    iof-store --table contract_master \\
              --input output.csv --upsert-key contract_id \\
              --metadata-dir /path/to/metadata

    iof-store --table procurement.contract_risk_assessments \\
              --input cra.json --upsert-key contract_id \\
              --metadata-dir /path/to/metadata

Input format: JSON (list of objects or single object) or CSV (auto-detected by extension).
Output: JSON to stdout. {success, table, rows_written, upsert_key}

Database: IOF_DATABASE_URL env var. postgresql:// → psycopg2; anything else → sqlite3.
JSONB columns: dicts/lists in JSON input are serialized as JSON strings for both backends.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# .env loading — same chain as all iof-* tools
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv
    load_dotenv(override=False)
    # ~/.iobot/.env first, then the legacy ~/.env, then the pod's /app/.env.
    # override=False, so the first hit wins and precedence is unchanged.
    from ioagentfarm.engine.home_env import home_env_candidates
    for _candidate in home_env_candidates():
        if _candidate.exists():
            load_dotenv(_candidate, override=False)
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _fail(message: str) -> None:
    print(json.dumps({"success": False, "error": message}))
    sys.exit(1)


def _output(data: dict) -> None:
    print(json.dumps(data))
    sys.exit(0)


# ---------------------------------------------------------------------------
# Input loading
# ---------------------------------------------------------------------------
def load_input(input_path: str) -> List[Dict[str, Any]]:
    """Load JSON or CSV input file. Returns list of row dicts."""
    path = Path(input_path)
    if not path.exists():
        _fail(f"Input file not found: {input_path}")

    suffix = path.suffix.lower()
    if suffix == ".csv":
        rows = []
        with open(path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Convert empty strings to None for cleaner DB writes
                rows.append({k: (None if v == "" else v) for k, v in row.items()})
        return rows
    else:
        # Assume JSON
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return data
        elif isinstance(data, dict):
            # Single object — wrap in list
            return [data]
        else:
            _fail(f"JSON input must be a list of objects or a single object, got: {type(data).__name__}")


# ---------------------------------------------------------------------------
# Type coercion — match DB schema before write
# Mirrors iof_extract.coerce_row_types; kept here so iof-store is safe when
# called directly with a CSV that was not produced by iof-extract (e.g. manual
# exports, re-runs of old extracted.csv files).
# ---------------------------------------------------------------------------
_INT_COLUMNS: set = {
    "payment_terms_net", "volume_discount_tiers", "invoice_dispute_window_days",
    "termination_notice_days", "auto_renewal_notice_days", "reverse_transition_days",
    "audit_notice_days", "non_solicitation_period_months", "dedicated_fte_count",
    "sla_response_time_hours", "sla_resolution_time_hours", "offboarding_timeline_days",
    "rate_card_count", "resource_count",
    # SaaS / Commercial
    "payment_holiday_days",
    # Data governance
    "breach_notification_hours", "data_access_post_termination_days",
    "subprocessor_change_notice_days", "data_return_window_days",
    # SLA / Operations
    "disaster_recovery_rto_hours", "disaster_recovery_rpo_hours", "dr_test_frequency_months",
    "service_credit_claim_window_days",
    # Governance & oversight
    "qbr_frequency_months", "provider_renewal_notice_days",
    # Warranty
    "warranty_period_months",
    # API lifecycle
    "api_deprecation_notice_months", "min_version_support_months",
}
_DECIMAL_COLUMNS: set = {
    "tcv_usd", "liability_cap_usd", "early_termination_fee_usd", "price_escalation_pct",
    "rebate_pct", "edp_commitment_total_usd", "indemnity_cap_usd", "insurance_minimum_usd",
    "survival_period_years", "data_protection_term_years", "sla_uptime_pct",
    "sla_credit_pct", "avg_rate_usd", "total_value_usd", "amount_usd",
    "rate_usd", "extraction_confidence",
    # SaaS / Commercial
    "renewal_price_cap_pct", "innovation_index_fee_pct", "storage_limit_gb",
    # SLA / Operations
    "service_credit_cap_pct",
    # Insurance (extended)
    "cyber_insurance_usd", "professional_indemnity_usd",
}
_BOOL_COLUMNS: set = {
    "price_escalation_clause", "most_favored_nation_clause", "consequential_damages_exclusion",
    "force_majeure_clause", "change_of_control_clause", "assignment_restriction",
    "entire_agreement_clause", "auto_renewal", "has_right_to_audit",
    "penetration_test_required", "key_personnel_clause", "source_code_escrow",
    "has_ai_council_clause", "has_gxp_clause", "has_data_sovereignty_clause",
    "has_ip_assignment", "has_non_solicitation", "has_exclusivity",
    # SaaS / Commercial pricing
    "pricing_lock_in_clause", "line_item_pricing", "price_hold_future_products",
    "pricing_metric_change_protection", "bundling_protection", "exchange_rights",
    "sandbox_fee_charged",
    # SaaS / Commercial usage & storage
    "storage_reporting_required",
    # Payment & dispute
    "suspension_dispute_protection",
    # Data governance
    "data_confidentiality_clause", "oss_disclosure_required",
    "subprocessor_list_disclosed", "supply_chain_audit_right",
    "data_destruction_confirmation", "portability_api_required",
    "hipaa_baa_included", "gdpr_dpa_included",
    # SLA / Operations
    "termination_for_sla_miss", "sla_scheduled_downtime_excluded",
    "escalation_process_defined", "bcp_required", "service_credit_proactive",
    "dedicated_support_engineer",
    # Governance & oversight
    "qbr_required", "subcontractor_approval_required",
    "client_local_software_dependency", "url_terms_protection", "functionality_locked",
    # Warranty
    "warranty_fitness_for_purpose", "warranty_non_infringement",
    "backward_compatibility_required",
    # API lifecycle
    "benchmarking_right",
    # Liability (extended)
    "liability_uncapped_ip_breach", "liability_uncapped_confidentiality",
    "liability_uncapped_fraud", "liability_cap_mutual", "force_majeure_excludes_sla",
}
_TRUTHY = {"true", "yes", "1", "y", "t"}
_FALSY  = {"false", "no", "0", "n", "f"}

# TEXT[] array columns — plain strings are split on comma and passed as lists
# so psycopg2 serialises them correctly to PostgreSQL array literals.
_ARRAY_COLUMNS: set = {
    "data_residency_countries",
    "tags",
}

# CHECK-constrained enum columns — values outside the set → None (avoids constraint violations)
_ENUM_COLUMNS: dict = {
    "contract_status":         {"active", "expired", "pending_renewal", "terminated"},
    "contract_type":           {"t_and_m", "fixed_price", "retainer", "saas", "edp", "subscription"},
    "vendor_tier":             {"strategic", "leverage", "operational", "transactional"},
    "preferred_vendor_status": {"preferred", "approved", "conditional", "restricted"},
    "sourcing_method":         {"rfp", "sole_source", "negotiated", "competitive_bid"},
    "dispute_resolution":      {"arbitration", "litigation", "mediation"},
    "financial_health":        {"stable", "watch", "deteriorating", "critical"},
    "sanctions_status":        {"clear", "flagged", "sanctioned", "pending_review"},
    "country_risk":            {"low", "medium", "high", "critical"},
    "risk_level":              {"clean", "low", "medium", "high", "critical"},
    "assessment_source":       {"intake", "workflow"},
    "confidence_level":        {"high", "medium", "low"},
    "document_type":           {"msa", "sow", "amendment", "work_order", "po", "paybill"},
    "payment_status":          {"paid", "pending", "disputed", "partial"},
    # SaaS / Commercial
    "variable_pricing_model":  {"pay_as_you_go", "consumption", "true_up_down", "fixed"},
    "usage_reporting_frequency": {"monthly", "quarterly", "annually", "on_request"},
    # Data governance
    "data_return_format":      {"csv", "json", "xml", "native", "api", "other"},
    # SLA / Operations
    "sla_reporting_frequency": {"monthly", "quarterly", "on_request"},
    "support_hours_type":      {"24x7", "business_hours", "follow_the_sun", "scheduled"},
    # Governance & oversight
    "regulatory_change_cost_allocation": {"vendor", "shared", "customer"},
    "notice_method":           {"email", "certified_mail", "registered_post", "legal_notice"},
    # Warranty
    "warranty_remedy_type":    {"replacement", "refund", "repair"},
    # API lifecycle
    "benchmarking_frequency":  {"annual", "biennial", "on_demand"},
}


def _extract_first_number(s: str) -> Optional[str]:
    import re
    m = re.search(r"[\d]+(?:\.\d+)?", s.replace(",", ""))
    return m.group(0) if m else None


def _coerce_value(col: str, val: Any) -> Any:
    """Coerce a single value to the correct Python type for its DB column.

    For CHECK-constrained enum columns: if value not in allowed set → None.
    Prevents constraint violations from agent field-value mix-ups.
    """
    if val is None or val == "":
        return None
    # Enum guard — must come before other coercions so numeric/bool values
    # in enum columns (e.g. 0.75 in contract_status) are also caught.
    if col in _ENUM_COLUMNS:
        s = str(val).strip().lower()
        return s if s in _ENUM_COLUMNS[col] else None
    if col in _INT_COLUMNS:
        if isinstance(val, bool):
            return None
        if isinstance(val, int):
            return val
        if isinstance(val, float):
            return int(val)
        n = _extract_first_number(str(val))
        return int(float(n)) if n is not None else None
    if col in _DECIMAL_COLUMNS:
        if isinstance(val, bool):
            return None
        if isinstance(val, (int, float)):
            return float(val)
        import re
        s = re.sub(r"[^\d.]", "", str(val).replace(",", ""))
        try:
            return float(s) if s else None
        except ValueError:
            return None
    if col in _BOOL_COLUMNS:
        if isinstance(val, bool):
            return val
        if isinstance(val, int):
            return bool(val)
        s = str(val).strip().lower()
        if s in _TRUTHY:
            return True
        if s in _FALSY:
            return False
        return None
    if col in _ARRAY_COLUMNS:
        # Convert plain string "US,UK" or already-a-list → Python list for psycopg2
        if isinstance(val, list):
            return val
        s = str(val).strip()
        if not s:
            return None
        # Strip PostgreSQL array literal syntax if present (e.g. {US,UK})
        if s.startswith("{") and s.endswith("}"):
            s = s[1:-1]
        return [item.strip() for item in s.split(",") if item.strip()]
    return val


def _coerce_row(row: Dict[str, Any]) -> Dict[str, Any]:
    return {col: _coerce_value(col, val) for col, val in row.items()}


# ---------------------------------------------------------------------------
# Value serialization — dicts/lists → JSON strings for DB storage
# ---------------------------------------------------------------------------
def _serialize_value(val: Any, col: str = "") -> Any:
    """Serialize complex types for DB columns.

    - JSONB/TEXT columns: dicts → JSON strings; lists → JSON strings (unless the
      column is a TEXT[] array column, in which case the list is passed as-is so
      psycopg2 can use native array binding).
    - TEXT[] array columns: lists pass through unchanged.
    """
    if val is None:
        return None
    if isinstance(val, dict):
        return json.dumps(val)
    if isinstance(val, list):
        if col in _ARRAY_COLUMNS:
            return val  # let psycopg2 bind as a native PostgreSQL array
        return json.dumps(val)
    return val


# ---------------------------------------------------------------------------
# PostgreSQL write
# ---------------------------------------------------------------------------
def _parse_upsert_keys(upsert_key: Optional[str]) -> List[str]:
    """Parse upsert_key — supports single column or comma-separated composite keys."""
    if not upsert_key:
        return []
    return [k.strip() for k in upsert_key.split(",") if k.strip()]


def _get_postgres_columns(conn, table: str) -> Optional[List[str]]:
    """Return list of column names for a PostgreSQL table, or None on error."""
    try:
        cur = conn.cursor()
        # Handle schema-qualified names (e.g. "procurement.contract_master")
        if "." in table:
            schema, tbl = table.split(".", 1)
        else:
            schema, tbl = "public", table
        cur.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema = %s AND table_name = %s",
            (schema, tbl),
        )
        cols = [r[0] for r in cur.fetchall()]
        cur.close()
        return cols if cols else None
    except Exception:
        return None


def write_postgres(
    database_url: str,
    table: str,
    rows: List[Dict[str, Any]],
    upsert_key: Optional[str],
    skip_unknown_columns: bool = False,
) -> int:
    """Write rows to PostgreSQL. Returns rows_written count."""
    try:
        import psycopg2
    except ImportError:
        _fail("psycopg2-binary required for PostgreSQL: pip install psycopg2-binary")

    if not rows:
        return 0

    # Derive columns from first row (all rows share same schema)
    columns = list(rows[0].keys())

    if skip_unknown_columns:
        try:
            _conn = psycopg2.connect(database_url)
            known = _get_postgres_columns(_conn, table)
            _conn.close()
            if known:
                original_count = len(columns)
                columns = [c for c in columns if c in known]
                dropped = original_count - len(columns)
                if dropped:
                    import sys
                    print(
                        f"[iof-store] --skip-unknown-columns: dropped {dropped} unknown column(s) "
                        f"not present in {table}: "
                        + ", ".join(c for c in list(rows[0].keys()) if c not in known),
                        file=sys.stderr,
                    )
        except Exception:
            pass  # fall through — let the INSERT itself fail with a clear error
    col_list = ", ".join(f'"{c}"' for c in columns)
    placeholders = ", ".join("%s" for _ in columns)
    insert_sql = f'INSERT INTO {table} ({col_list}) VALUES ({placeholders})'

    upsert_keys = _parse_upsert_keys(upsert_key)
    if upsert_keys:
        conflict_cols = ", ".join(f'"{k}"' for k in upsert_keys)
        update_pairs = ", ".join(
            f'"{c}" = EXCLUDED."{c}"'
            for c in columns
            if c not in upsert_keys
        )
        if update_pairs:
            insert_sql += (
                f' ON CONFLICT ({conflict_cols}) DO UPDATE SET {update_pairs}'
            )
        else:
            insert_sql += f' ON CONFLICT ({conflict_cols}) DO NOTHING'

    try:
        conn = psycopg2.connect(database_url)
        cur = conn.cursor()
        written = 0
        for row in rows:
            row = _coerce_row(row)
            values = [_serialize_value(row.get(c), c) for c in columns]
            cur.execute(insert_sql, values)
            written += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 1
        conn.commit()
        cur.close()
        conn.close()
        return written
    except Exception as e:
        _fail(f"PostgreSQL write failed for table '{table}': {e}")


# ---------------------------------------------------------------------------
# SQLite write
# ---------------------------------------------------------------------------
def write_sqlite(
    db_path: str,
    table: str,
    rows: List[Dict[str, Any]],
    upsert_key: Optional[str],
) -> int:
    """Write rows to SQLite. Returns rows_written count."""
    import sqlite3

    if not rows:
        return 0

    columns = list(rows[0].keys())
    col_list = ", ".join(f'"{c}"' for c in columns)
    placeholders = ", ".join("?" for _ in columns)
    insert_sql = f'INSERT INTO {table} ({col_list}) VALUES ({placeholders})'

    upsert_keys = _parse_upsert_keys(upsert_key)
    if upsert_keys:
        conflict_cols = ", ".join(f'"{k}"' for k in upsert_keys)
        update_pairs = ", ".join(
            f'"{c}" = excluded."{c}"'
            for c in columns
            if c not in upsert_keys
        )
        if update_pairs:
            insert_sql += (
                f' ON CONFLICT({conflict_cols}) DO UPDATE SET {update_pairs}'
            )
        else:
            insert_sql += f' ON CONFLICT({conflict_cols}) DO NOTHING'

    # SQLite schema names (e.g. "procurement.table_name") — not supported;
    # use just the table name. Schemas are PostgreSQL-only.
    sqlite_table = table.split(".")[-1] if "." in table else table
    insert_sql = insert_sql.replace(f" {table} ", f" {sqlite_table} ", 1)

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        written = 0
        for row in rows:
            row = _coerce_row(row)
            # SQLite has no native array type — serialize arrays as JSON strings
            values = [
                json.dumps(v) if isinstance(v, list) else _serialize_value(row.get(c), c)
                for c, v in ((c, row.get(c)) for c in columns)
            ]
            cur.execute(insert_sql, values)
            written += 1
        conn.commit()
        cur.close()
        conn.close()
        return written
    except Exception as e:
        _fail(f"SQLite write failed for table '{table}': {e}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "DB upsert writer. Loads JSON/CSV and writes to any table. "
            "Uses IOF_DATABASE_URL (postgresql:// or sqlite path)."
        ),
    )
    parser.add_argument("--table", required=True,
                        help="Target table name. Supports schema-qualified names (e.g. procurement.intelligence_reports)")
    parser.add_argument("--input", required=True,
                        help="Input file path: .json (list of objects or single object) or .csv")
    parser.add_argument("--upsert-key", default=None,
                        help="Column name for ON CONFLICT DO UPDATE. Omit for INSERT-only.")
    parser.add_argument("--metadata-dir", default="",
                        help="Path to metadata or project directory (used for .env discovery). Optional — falls back to home dir and CWD walk.")
    parser.add_argument("--env-file", default=None,
                        help="Path to .env file for credentials (overrides auto-discovery)")
    parser.add_argument("--skip-unknown-columns", action="store_true",
                        help="Silently drop input columns not present in the target table schema. "
                             "Prevents failures when the LLM adds extra columns not in the DB schema.")
    args = parser.parse_args()

    # Load .env — broadened search so iof-store works regardless of CWD.
    # Agents run from iobot workspace dirs; the project .env may be far up
    # the tree. Search order: explicit --env-file > metadata-dir neighbours >
    # CWD walk-up > home dir > /app/.env.
    try:
        from dotenv import load_dotenv as _ld

        if args.env_file:
            _ld(args.env_file, override=False)
        else:
            candidates: list = []

            # 1. metadata-dir neighbours (if provided and non-empty)
            if args.metadata_dir:
                metadata_path = Path(args.metadata_dir).resolve()
                candidates += [
                    metadata_path.parent / ".env",
                    metadata_path / ".env",
                ]

            # 2. Walk up from CWD until filesystem root
            p = Path.cwd()
            while True:
                candidates.append(p / ".env")
                parent = p.parent
                if parent == p:
                    break
                p = parent

            # 3/4. The published .env (~/.iobot/.env), the legacy ~/.env and
            # the pod's /app/.env, in that order.
            from ioagentfarm.engine.home_env import home_env_candidates
            candidates.extend(home_env_candidates())

            for candidate in candidates:
                if candidate.is_file():
                    _ld(str(candidate), override=False)
                    if os.environ.get("IOF_DATABASE_URL"):
                        break  # stop as soon as we have the URL
    except ImportError:
        pass

    database_url = os.environ.get("IOF_DATABASE_URL", "")
    if not database_url:
        _fail(
            "IOF_DATABASE_URL not set. "
            "Set to a PostgreSQL connection string (postgresql://...) "
            "or a SQLite file path (e.g. .iof/state.db)"
        )

    rows = load_input(args.input)
    if not rows:
        _output({
            "success": True,
            "table": args.table,
            "rows_written": 0,
            "upsert_key": args.upsert_key,
            "note": "Input contained 0 rows — nothing written.",
        })

    if database_url.startswith("postgresql://") or database_url.startswith("postgres://"):
        rows_written = write_postgres(
            database_url, args.table, rows, args.upsert_key,
            skip_unknown_columns=args.skip_unknown_columns,
        )
    else:
        # Treat as SQLite file path
        rows_written = write_sqlite(database_url, args.table, rows, args.upsert_key)

    _output({
        "success": True,
        "table": args.table,
        "rows_written": rows_written,
        "upsert_key": args.upsert_key,
    })


if __name__ == "__main__":
    main()
