"""Generic REST API caller — reads any type:api endpoint from databases.yml.

Called by agents via exec/shell to call live REST APIs (iCertis, Coupa, SEC EDGAR, etc.).
Reads endpoint config from metadata/databases.yml. No hardcoded API knowledge —
the tool fires HTTP and returns raw JSON; the calling agent parses the response.
Adding a new REST API = one new type:api entry in databases.yml, zero tool code changes.

Usage:
    iof-api --endpoint icertis_live --path "/contracts/{id}" \\
            --path-params id=12345 \\
            --metadata-dir /path/to/metadata --scratch /path/to/scratch

    iof-api --endpoint coupa_live --path "/purchase_orders" \\
            --query-params status=pending --query-params limit=50 \\
            --metadata-dir /path/to/metadata --scratch /path/to/scratch --rate-limit 5

Output: JSON to stdout. {success, endpoint, path, url, status_code, data}

Auth types supported: oauth2_client_credentials, api_key, bearer.
OAuth2 tokens cached in <scratch>/tokens/<endpoint>.json with expiry check.

Credentials: Auto-loads .env from project root (parent of --metadata-dir),
             the metadata directory, or cwd. databases.yml supports ${ENV_VAR}.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# .env loading (same chain as all iof-* tools)
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv
    load_dotenv(override=False)
    # ~/.iobot/.env first, then the legacy ~/.env, then the pod's /app/.env.
    # override=False, so the first hit wins and precedence is unchanged.
    from ioagentfarm.engine.home_env import home_env_candidates
    for _candidate in home_env_candidates():
        if _candidate.exists():
            load_dotenv(_candidate, override=False)
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _fail(message: str) -> None:
    print(json.dumps({"success": False, "error": message}))
    sys.exit(1)


def _output(data: dict) -> None:
    print(json.dumps(data, default=_json_default))
    sys.exit(0)


def _json_default(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Not serializable: {type(obj)}")


# ---------------------------------------------------------------------------
# databases.yml loading — reuses same format as iof-query
# ---------------------------------------------------------------------------
def load_api_config(endpoint: str, metadata_dir: str) -> Dict[str, Any]:
    """Load a type:api endpoint config from databases.yml."""
    try:
        import yaml
    except ImportError:
        _fail("pyyaml is required: pip install pyyaml")

    config_path = Path(metadata_dir) / "databases.yml"
    if not config_path.exists():
        _fail(f"Config not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not data or "databases" not in data:
        _fail(f"Invalid databases.yml — missing 'databases' key in {config_path}")

    configs = data["databases"]
    cfg = configs.get(endpoint)
    if cfg is None:
        available = [k for k, v in configs.items() if isinstance(v, dict) and v.get("type") == "api"]
        _fail(
            f"Endpoint '{endpoint}' not found in databases.yml. "
            f"Available type:api endpoints: {', '.join(sorted(available)) or '(none defined yet)'}"
        )

    if cfg.get("type") != "api":
        _fail(f"Endpoint '{endpoint}' has type='{cfg.get('type')}', expected type='api'")

    # Resolve ${ENV_VAR} references in string values — supports both
    # whole-value ("${VAR}") and inline ("http://host:${PORT}/path") forms.
    def _resolve_env_refs(s: str, context: str) -> str:
        def _sub(m: "re.Match") -> str:
            var = m.group(1)
            val = os.environ.get(var)
            if val is None:
                _fail(f"Environment variable {var} not set (required by databases.yml for {context})")
            return val
        return re.sub(r"\$\{([^}]+)\}", _sub, s)

    for key, val in list(cfg.items()):
        if isinstance(val, str) and "${" in val:
            cfg[key] = _resolve_env_refs(val, f"{endpoint}.{key}")

    return cfg


# ---------------------------------------------------------------------------
# Budget check — read-only, same pattern as iof-query and vectorfs
# ---------------------------------------------------------------------------
def check_budget(scratch_dir: Optional[str]) -> None:
    """Refuse if session tool budget is exhausted. Fail-open on any error."""
    if not scratch_dir:
        return
    budget_path = Path(scratch_dir) / "tool_budget.json"
    try:
        if not budget_path.is_file():
            return
        with open(budget_path, "r", encoding="utf-8") as f:
            bdata = json.load(f)
        used = int(bdata.get("used", 0))
        limit = int(bdata.get("limit", 10 ** 9))
        if used >= limit:
            print(
                "(orchestrator: tool-call budget exhausted for this request - "
                "no more iof-api, iof-query, or vectorfs calls will be honored. "
                "Compose the envelope now with data you already have; add a caveat "
                "about incomplete API coverage if needed.)"
            )
            sys.exit(0)
    except Exception:
        pass  # fail-open: budget absence never breaks the tool


# ---------------------------------------------------------------------------
# OAuth2 token caching
# ---------------------------------------------------------------------------
def get_oauth2_token(cfg: Dict[str, Any], scratch_dir: Optional[str], endpoint: str) -> str:
    """Get a valid OAuth2 client_credentials token, cached in <scratch>/tokens/<endpoint>.json."""
    import httpx

    # Try cached token first
    if scratch_dir:
        token_path = Path(scratch_dir) / "tokens" / f"{endpoint}.json"
        if token_path.is_file():
            try:
                with open(token_path, "r", encoding="utf-8") as f:
                    cached = json.load(f)
                expires_at = cached.get("expires_at", 0)
                if time.time() < expires_at - 60:  # 60s safety margin
                    return cached["access_token"]
            except Exception:
                pass

    token_url = cfg.get("token_url")
    client_id = cfg.get("client_id")
    client_secret = cfg.get("client_secret")
    if not all([token_url, client_id, client_secret]):
        _fail(
            f"oauth2_client_credentials requires token_url, client_id, client_secret "
            f"in databases.yml for '{endpoint}'"
        )

    try:
        resp = httpx.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            },
            timeout=30.0,
        )
        resp.raise_for_status()
        token_data = resp.json()
        access_token = token_data.get("access_token")
        if not access_token:
            _fail(f"OAuth2 token response missing 'access_token': {resp.text[:200]}")
        expires_in = int(token_data.get("expires_in", 3600))

        if scratch_dir:
            token_dir = Path(scratch_dir) / "tokens"
            token_dir.mkdir(parents=True, exist_ok=True)
            with open(token_dir / f"{endpoint}.json", "w", encoding="utf-8") as f:
                json.dump({
                    "access_token": access_token,
                    "expires_at": time.time() + expires_in,
                }, f)

        return access_token
    except Exception as e:
        _fail(f"Failed to obtain OAuth2 token from {token_url}: {e}")


# ---------------------------------------------------------------------------
# HTTP request
# ---------------------------------------------------------------------------
def call_api(
    cfg: Dict[str, Any],
    path: str,
    path_params: Dict[str, str],
    query_params: Dict[str, str],
    scratch_dir: Optional[str],
    endpoint: str,
    rate_limit: Optional[float],
    method: str = "GET",
    body: Optional[str] = None,
) -> Dict[str, Any]:
    """Fire HTTP GET or POST to the configured endpoint. Returns raw response as dict."""
    import httpx

    base_url = cfg.get("base_url", "").rstrip("/")
    if not base_url:
        _fail(f"Endpoint '{endpoint}' missing 'base_url' in databases.yml")

    # Substitute {placeholders} in path from --path-params
    for key, val in path_params.items():
        path = path.replace(f"{{{key}}}", val)

    url = base_url + path
    auth_type = cfg.get("auth_type", "").lower()

    headers: Dict[str, str] = {}
    if auth_type == "oauth2_client_credentials":
        token = get_oauth2_token(cfg, scratch_dir, endpoint)
        headers["Authorization"] = f"Bearer {token}"
    elif auth_type == "api_key":
        auth_header = cfg.get("auth_header", "Authorization")
        auth_key = cfg.get("auth_key") or cfg.get("api_key")
        if not auth_key:
            _fail(f"auth_type=api_key requires 'auth_key' in config for '{endpoint}'")
        headers[auth_header] = auth_key
    elif auth_type == "bearer":
        bearer_token = cfg.get("token") or cfg.get("bearer_token")
        if not bearer_token:
            _fail(f"auth_type=bearer requires 'token' in config for '{endpoint}'")
        headers["Authorization"] = f"Bearer {bearer_token}"
    elif auth_type:
        _fail(
            f"Unsupported auth_type '{auth_type}' for '{endpoint}'. "
            f"Supported: oauth2_client_credentials, api_key, bearer"
        )

    # Rate limiting: sleep before call if --rate-limit set
    if rate_limit and rate_limit > 0:
        time.sleep(1.0 / rate_limit)

    parsed_body: Any = None
    if body:
        try:
            parsed_body = json.loads(body)
            headers.setdefault("Content-Type", "application/json")
        except json.JSONDecodeError:
            _fail(f"--body is not valid JSON: {body[:200]}")

    # Reuse the same slow-compose timeout knob iobot's own LLM calls use
    # (see _iobot_patches.py, IOF_REQUEST_TIMEOUT_S) rather than a second,
    # disconnected hardcoded number. Endpoints like queryngine can legitimately
    # take 60-230+s to compose a response (MiniMax non-streaming compose) —
    # a shorter client-side timeout here reads as "Quinn is unavailable" when
    # she's actually still working.
    _api_timeout_s = float(os.environ.get("IOF_REQUEST_TIMEOUT_S", "180"))
    try:
        with httpx.Client(timeout=_api_timeout_s) as client:
            http_method = method.upper()
            if http_method == "POST":
                resp = client.post(url, headers=headers, params=query_params,
                                   json=parsed_body)
            elif http_method == "PUT":
                resp = client.put(url, headers=headers, params=query_params,
                                  json=parsed_body)
            elif http_method == "PATCH":
                resp = client.patch(url, headers=headers, params=query_params,
                                    json=parsed_body)
            elif http_method == "DELETE":
                resp = client.delete(url, headers=headers, params=query_params)
            else:
                resp = client.get(url, headers=headers, params=query_params)
            resp.raise_for_status()
            try:
                data = resp.json()
            except Exception:
                data = resp.text
            return {
                "success": True,
                "endpoint": endpoint,
                "path": path,
                "url": url,
                "status_code": resp.status_code,
                "data": data,
            }
    except httpx.HTTPStatusError as e:
        return {
            "success": False,
            "endpoint": endpoint,
            "path": path,
            "url": url,
            "status_code": e.response.status_code,
            "error": f"HTTP {e.response.status_code}: {e.response.text[:500]}",
        }
    except Exception as e:
        return {
            "success": False,
            "endpoint": endpoint,
            "path": path,
            "url": url,
            "error": str(e),
        }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Generic REST API caller. Reads any type:api endpoint from databases.yml. "
            "Fires HTTP GET and returns raw JSON to stdout."
        ),
    )
    parser.add_argument("--endpoint", required=True,
                        help="Named endpoint from databases.yml (must have type: api)")
    parser.add_argument("--path", required=True,
                        help="URL path appended to base_url. Supports {param} substitution via --path-params")
    parser.add_argument("--path-params", action="append", default=[], metavar="KEY=VALUE",
                        help="Path variable substitutions (can repeat). Fills {key} in --path")
    parser.add_argument("--query-params", action="append", default=[], metavar="KEY=VALUE",
                        help="Query string parameters (can repeat). Appended as ?key=value")
    parser.add_argument("--metadata-dir", required=True,
                        help="Path to metadata directory containing databases.yml")
    parser.add_argument("--scratch", default=None,
                        help="Session scratch dir for tool_budget.json and OAuth2 token cache")
    parser.add_argument("--rate-limit", type=float, default=None,
                        help="Max requests/second (default: no limit). Use for rate-limited enterprise APIs.")
    parser.add_argument("--method", default="GET", choices=["GET", "POST", "PUT", "PATCH", "DELETE"],
                        help="HTTP method (default: GET). Use POST for chat/action endpoints like queryngine.")
    parser.add_argument("--body", default=None,
                        help="JSON body for POST/PUT/PATCH requests. Must be valid JSON string.")
    parser.add_argument("--env-file", default=None,
                        help="Path to .env file for credentials (overrides auto-discovery)")
    args = parser.parse_args()

    # Load .env — same search chain as iof-query
    try:
        from dotenv import load_dotenv as _ld
        if args.env_file:
            _ld(args.env_file, override=False)
        else:
            metadata_path = Path(args.metadata_dir).resolve()
            candidates = [
                metadata_path.parent / ".env",   # project root (parent of metadata/)
                metadata_path / ".env",           # inside metadata dir
                Path.cwd() / ".env",              # current working directory
                Path("/app/.env"),                # K8s pod
            ]
            for candidate in candidates:
                if candidate.is_file():
                    _ld(str(candidate), override=False)
                    break
    except ImportError:
        pass

    # Budget check before spending a call
    check_budget(args.scratch)

    # Parse key=value pairs
    def _parse_kv(pairs: List[str]) -> Dict[str, str]:
        result: Dict[str, str] = {}
        for pair in pairs:
            if "=" not in pair:
                _fail(f"Invalid key=value pair: {pair!r}. Use KEY=VALUE format.")
            k, v = pair.split("=", 1)
            result[k.strip()] = v.strip()
        return result

    path_params = _parse_kv(args.path_params)
    query_params = _parse_kv(args.query_params)

    cfg = load_api_config(args.endpoint, args.metadata_dir)

    result = call_api(
        cfg=cfg,
        path=args.path,
        path_params=path_params,
        query_params=query_params,
        scratch_dir=args.scratch,
        endpoint=args.endpoint,
        rate_limit=args.rate_limit,
        method=args.method,
        body=args.body,
    )

    _output(result)


if __name__ == "__main__":
    main()
