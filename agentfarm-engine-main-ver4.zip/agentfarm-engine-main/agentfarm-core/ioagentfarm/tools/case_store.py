"""iof-case — the case tier: durable case records + DB-resident rulebooks.

The execution substrate for CASE-species plays (weeks-long, event- and
timer-driven escalation ladders). A playbook's transitions run as DATA here:
the ENGINE is generic (states, events, wildcard precedence, terminal
refusal, unmatched refusal — template-agnostic), and each template family's
rulebook is a validated JSON document in the meta_rulebooks table,
parameterized by the play. A structural revision — a new step, a new role,
a removed rung — is a `rulebook put`, not a code change.

Division of labor (the target architecture, validated live 2026-08):
- The MONITORING SYSTEM (external) owns the clocks; it calls back with typed
  events. This tool only records which clock is conceptually running.
- The META AGENT receives events, relays typed ones here unchanged, routes
  free-text replies through a judgement step that emits a typed event, and
  commissions the ACTION the rulebook names — one delegation per event.
- THIS TOOL decides. Same (state, event) in -> same (rule, action, state)
  out, every time. An unmatched pair surfaces loudly and changes nothing.

Tables: meta_rulebooks (one row per template family; spec_json is the whole
rulebook, revision bumped on every put), meta_cases (one row per play-item,
e.g. barrier x territory) and meta_case_events (append-only ledger: event
in, rule fired, action, states).

Commands:
  open --play <id> --group <ref> --items "A,B,C" [--template <id>]
       [--open-event-for "B=case_opened_no_owner"] [--no-owner X] [--out d]
  transition --case <id> --event <event> [--detail "..."] [--out d]
  record-action --case <id> --action <name> --receipt <r>
  ctx --case <id> --out <dir>          context bundle for action workflows
  list [--json] / show <case_id> / history <case_id>
  explain <case_id> [--json]           case postmortem + retry guidance
  audit [--json]                       fleet health view across all cases
  rulebook list | show <template> | validate --file f | put --file f [--as w]

Seeded templates (INSERT-if-absent — a tenant revision is never overwritten):
TPL-OS-VACANCY (open-seat vacancy escalation, R01-R12) and
TPL-SAMPLE-DISCREPANCY (sample inventory discrepancy, S01-S10). Both are
instances; any pharma-commercial case family with typed events and
deterministic transitions is expressible as a spec document.
"""
from __future__ import annotations

# Facade over the casetier package — the module was split by concern at
# 1,665 lines (store / rulebook / analysis / commands). Every name that
# ever lived here is re-exported so the `iof-case` entry point, the play
# store, the workflows and the tests are unaffected. New code should
# import from ioagentfarm.tools.casetier.* directly.

from ioagentfarm.tools.casetier.store import (          # noqa: F401
    _SCHEMA, _ENSURE_COLUMNS, _adapter, _connect, _db_url, _infer_root,
    _ledger, _now, _rows, _scope_sql, _workspace)
from ioagentfarm.tools.casetier.rulebook import (       # noqa: F401
    _INVARIANT_KINDS, _OSVAC_SPEC, _SAMPLE_SPEC, _SEED_SPECS,
    _SPEC_REQUIRED, action_meta, capability_resolution_errors,
    check_invariants, commissioned_workflows, decide, declared_recipients,
    delivery_tool_resolution_errors, exhaust_walk, load_rulebook,
    recipient_resolution_errors, save_rulebook, simulate_walk,
    validate_spec, validate_spec_warnings,
    workflow_delivery_resolution_errors)
from ioagentfarm.tools.casetier.analysis import (       # noqa: F401
    _sla_posture, analyze_history)
from ioagentfarm.tools.casetier import calendar         # noqa: F401
from ioagentfarm.tools.casetier import timers           # noqa: F401
from ioagentfarm.tools.casetier.commands import (       # noqa: F401
    _CASE_RE, apply_timer_event, claim_delivery, cmd_audit, cmd_commission,
    cmd_ctx, cmd_deliveries, cmd_dispatch, cmd_due, cmd_explain, cmd_fire,
    cmd_history, cmd_kpi, cmd_list, dispatch_pending,
    cmd_open, cmd_record_action, cmd_rulebook, cmd_runs, cmd_scheduler,
    cmd_show, cmd_simulate, cmd_transition, failure_grace_s, main,
    render_workflow_goal, settle_runs)

if __name__ == "__main__":
    import sys
    sys.exit(main())
