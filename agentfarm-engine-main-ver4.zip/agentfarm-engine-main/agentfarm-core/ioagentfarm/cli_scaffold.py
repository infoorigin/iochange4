"""`aicore new-solution` — scaffold a domain solution repo.

The deployment model is a shared SDK plus one repo per business IT team: the
AI Core team publishes the engine + shared-skills wheels,
and each domain team owns a repo containing ONLY their pack, which plugs in
through the ``aicore.packs`` entry point with **zero core edits**.

Writing that repo by hand means getting five non-obvious things right, each of
which fails quietly rather than loudly:

1. **The entry point.** Without ``[project.entry-points."aicore.packs"]``
   the pack is installed and invisible — no error, just an empty catalog.
2. **``package-data`` globs.** Content lives as package data. Miss a glob and
   ``pip install .`` succeeds while the wheel contains no workflows; it only
   surfaces on a pod, never in the editable-install dev loop.
3. **``aicore.solution.yaml``.** Separate from the entry point and easy to
   confuse with it: the entry point serves the RUNTIME (in-process pack
   discovery), the manifest serves the IMPORTER (``workspace push``, which
   fills the Studio catalog). A repo needs both, and the API pod installs no
   packs at all — it reads the database, so a missing manifest means an empty
   Studio however correct the entry point is.
4. **A skill's ``roles:`` seeds who HOLDS it.** With no ``roles:`` key the
   skill starts out held by no agent — not an error, and easy to miss. It is
   not a gate: a workflow step may name any skill in the workspace catalog,
   and the Studio may give any skill to any agent.
5. **``output_protocol`` comes from the PLATFORM.** The engine requires it
   for every step and ships it, so a scaffolded agent carries no copy and
   resolves it from the shared skill sources.

The generated repo installs, imports, and runs as-is: one agent, one skill, one
two-step workflow, and a test that fails if the wheel would ship without its
content.

``--no-example`` DROPS THE THREE PIECES OF CONTENT AND NOTHING ELSE. It is the
opt-out for someone who came here to write their own agent, not to read
somebody else's — the example stays the default because it is the fastest way
to see the shape of a pack, but a reader who already knows it asked, verbatim,
"logistics_report who created this workflow". Everything in the list above
still ships: those are the parts that fail silently, which is the entire reason
this command exists, and none of them is example content. The empty
``agents/``/``skills/``/``workflows/`` roots ARE still created, each holding a
``.gitkeep`` — see ``_content_roots`` for why that is load-bearing and not
decoration.

THE TEMPLATES BELOW ARE ALSO THE GROW COMMANDS' TEMPLATES. ``cli_pack`` —
``new-workflow`` / ``new-agent`` / ``new-skill``, which add a second of each to
a pack that already exists — imports SOUL, TOOLS_MD, MEMORY_MD, ROLE_PROMPT,
CATALOG_YAML, ``render_workflow_yaml`` and ``step_output_block`` from here
rather than carrying its own copies. A second copy of a workflow skeleton is
the exact drift this repo keeps paying for: the copy that is not the one you
are reading goes stale, and it goes stale silently because the loader forgives
every key it does not recognise.
"""
from __future__ import annotations

import re
import shutil
import sys
import textwrap
from pathlib import Path
from typing import Any, Mapping, Sequence

import typer
from rich.console import Console

from ioagentfarm.solution_manifest import MANIFEST_NAME, find_manifest

console = Console()

#: The package-prefix rule. The SAME object `workspace create` applies to a
#: new code (engine.workspaces.NEW_WORKSPACE_CODE_RE), because
#: `new-workspace <code>` receives that code and it becomes a Python package
#: prefix - two regexes for one string is how `ab` was accepted by one
#: command and refused by the next.
from ioagentfarm.engine.workspaces import NEW_WORKSPACE_CODE_RE as SLUG_RE  # noqa: E402

#: How to find each SDK distribution in THIS environment, most load-bearing
#: anchor first: ``(import package, aicore.packs entry-point name, fallback
#: distribution)``.
#:
#: THE ANCHOR HAS TO BE SOMETHING THAT CANNOT QUIETLY BE RENAMED, and the two
#: wheels differ on what that is.
#:
#: * The engine is anchored on its IMPORT package. Every pack does
#:   ``from aicore.packs import Pack``, every console script points into
#:   it — rename it and nothing works, immediately and loudly.
#: * The shared-skills wheel is anchored on its ENTRY POINT. Nothing imports
#:   ``agentfarm_skills`` by name; it is discovered as
#:   ``aicore.packs -> skills``, which is the string the runtime keys on. An
#:   import-package-only lookup would fall back silently to the wrong name in a
#:   deployment that renamed the directory and its own entry-point value, since
#:   that combination keeps working. Anchoring on the entry point cannot: rename
#:   THAT and the shared skills vanish from every workspace first.
_SDK_ANCHORS = (
    ("ioagentfarm", None, "agentfarm-core"),
    ("agentfarm_skills", "skills", "agentfarm-skills"),
)


def _prog() -> str:
    """The command name this CLI was invoked as.

    The same program installs under more than one name (`aicore` and
    `ioagentfarm`), and a deployment may present only one of them to its
    users. A "Next" hint that names the other one tells the reader to run a
    command their installation does not provide.
    """
    name = Path(sys.argv[0]).name if sys.argv and sys.argv[0] else ""
    for suffix in (".exe", ".cmd", ".bat"):
        if name.lower().endswith(suffix):
            name = name[: -len(suffix)]
            break
    return name if name and not name.startswith("-") else "aicore"


def invocation() -> str:
    """A prefix the reader can actually PASTE, however the CLI was started.

    THE FIRST THING A NEW USER DOES, AND IT DID NOT RUN. `new-solution`
    closes with a "Next" block built as `"{bin_dir}/{_prog()}" <args>`. Under
    `python -m ioagentfarm.cli` - how anyone without the console script on
    PATH runs this, including every walkthrough on a fresh checkout -
    `sys.argv[0]` is the path to `cli.py`, so the block printed
    `"...\\.venv\\Scripts\\cli.py workspace create mysolution"`. The
    confused-novice round pasted it and got `No such file or directory`;
    the same wrong spelling recurs in `workspace use` and `list-workflows`
    error text. The product's own first instruction was unrunnable.

    So: when the CLI was invoked as a MODULE, print the module form; when it
    was invoked as a console script, print that script's full path (which is
    what makes the hint work from any directory and any venv).
    """
    name = _prog()
    if name.lower().endswith(".py") or name in ("__main__", "-c"):
        return f'"{sys.executable}" -m ioagentfarm.cli'
    return f'"{Path(sys.executable).resolve().parent / name}"'

#: The entry-point group the runtime discovers packs through, and the full set
#: it accepts. NOT renameable by a deployment: both sides of the lookup —
#: a pack's installed metadata and `packs.load_registry()` — must agree on a
#: literal, so the seam is this list, not a setting. One definition, in
#: `packs`, because a scaffold that writes a group the runtime does not read
#: produces a pack that installs and is invisible.
from ioagentfarm.packs import ENTRY_POINT_GROUP as PACK_ENTRY_POINT_GROUP
from ioagentfarm.packs import ENTRY_POINT_GROUPS as PACK_ENTRY_POINT_GROUPS


def _declared_pack_eps(project: Mapping[str, Any]) -> dict[str, str]:
    """Pack entry points a `pyproject.toml` declares, across accepted groups.

    A repo scaffolded before the rename declares the legacy group and is not
    wrong — its packs load. Merged current-group-last so a repo carrying both
    resolves to the current one.
    """
    eps = project.get("entry-points") or {}
    out: dict[str, str] = {}
    for group in reversed(PACK_ENTRY_POINT_GROUPS):
        out.update(eps.get(group) or {})
    return out


def _pack_ep_table(py_text: str) -> str:
    """The entry-point table header this pyproject actually uses.

    Text surgery has to append under the table that is THERE. Appending under
    the current name in a repo declaring the legacy one writes a second table,
    which parses fine and splits the pack's entry points across two groups.
    """
    for group in PACK_ENTRY_POINT_GROUPS:
        header = f'[project.entry-points."{group}"]'
        if header in py_text:
            return header
    return f'[project.entry-points."{PACK_ENTRY_POINT_GROUP}"]'


def _installed_pack_names() -> set[str]:
    """Entry-point names registered in THIS venv, across accepted groups."""
    from importlib.metadata import entry_points

    return {e.name
            for group in PACK_ENTRY_POINT_GROUPS
            for e in entry_points(group=group)}


def uninstalled_local_packs(start=None) -> list[str]:
    """Packs the repo under *start* DECLARES but this venv does not have.

    THE SILENT ABSENCE THE CONFUSED-NOVICE ROUND FOUND. `new-agent` shouts
    "REINSTALL REQUIRED - no error, just an empty catalog", and then
    `list-workflows` and `list-agents` print a long, confident listing of
    OTHER packs' content with the user's own solution simply not in it. The
    listing succeeded, so nothing looked wrong; the tester grepped the output,
    matched the table header, and concluded their workflow was there.

    The information was already available - the `agent-chat` error diagnoses
    exactly this and hands over the pip command - so the listings were the
    only place that knew and did not say. Returns [] on any doubt: a warning
    that fires wrongly on a healthy install would be worse than none.
    """
    from pathlib import Path as _P
    try:
        import yaml as _yaml
        root = _P(start) if start else _P.cwd()
        installed = _installed_pack_names()
        declared: list[str] = []
        for d in [root, *root.parents][:4]:
            f = find_manifest(d)
            if f is None:
                continue
            data = _yaml.safe_load(f.read_text(encoding="utf-8")) or {}
            for name in ([data.get("solution")]
                         + list((data.get("solutions") or {}).keys())):
                if isinstance(name, str) and name and name not in installed:
                    declared.append(name)
            break
        return sorted(set(declared))
    except Exception:                   # noqa: BLE001 - a hint, never a failure
        return []


def _dist_providing(import_pkg: str, entry_point: str | None) -> str | None:
    """Which installed distribution supplies this part of the SDK, or None."""
    from importlib.metadata import entry_points, packages_distributions

    if entry_point:
        try:
            for ep in entry_points(group=PACK_ENTRY_POINT_GROUP):
                if ep.name == entry_point:
                    name = getattr(getattr(ep, "dist", None), "name", None)
                    if name:
                        return name
        except Exception:               # pragma: no cover - defensive
            pass
    try:
        found = packages_distributions().get(import_pkg)
    except Exception:                   # pragma: no cover - defensive
        found = None
    return found[0] if found else None


#: An OPTIONAL manifest naming the SDK distributions a scaffolded pack should
#: depend on. `~/.iobot/sdk.json`, or `IOF_SDK_MANIFEST` pointing anywhere.
#:
#: Derivation (below) answers "which distribution is installed here", which is
#: right when the answer is discoverable and wrong when it is not: a machine
#: that scaffolds before installing, an air-gapped build, or an organisation
#: adding a third SDK wheel the anchors know nothing about. This file says it
#: outright and needs no inference.
#:
#: Two accepted shapes, because the short one is what people write::
#:
#:     {"dependencies": ["ai-core-harness-engine", "ai-core-harness-skills"]}
#:
#:     {"dependencies": [
#:         {"name": "ai-core-harness-engine", "version": ">=0.6,<0.7"},
#:         {"name": "ai-core-harness-skills"}
#:     ]}
#:
#: NO VERSION MEANS LATEST — the field is omitted from the requirement entirely
#: rather than defaulted to something, so a pack takes whatever the index
#: offers. A bare `0.6.2` becomes `==0.6.2`; anything starting with a
#: comparator is used verbatim.
SDK_MANIFEST_NAME = "sdk.json"


def sdk_manifest_path() -> Path:
    """Where the optional SDK manifest is read from."""
    import os
    override = (os.getenv("IOF_SDK_MANIFEST") or "").strip()
    if override:
        return Path(override)
    from ioagentfarm.engine.home_env import home_env_path
    return home_env_path().parent / SDK_MANIFEST_NAME


def _requirement(name: str, version: str = "") -> str:
    version = (version or "").strip()
    if not version:
        return name
    if version[0] in "<>=!~^":
        return f"{name}{version}"
    return f"{name}=={version}"


def _sdk_from_manifest() -> list[str] | None:
    """Requirement strings from :func:`sdk_manifest_path`, or None.

    A malformed file is REFUSED, not ignored. Falling back to derivation would
    silently write different dependencies than the file asks for, and the
    author would find out from a pod.
    """
    import json
    path = sdk_manifest_path()
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return None
    try:
        doc = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise typer.BadParameter(f"{path} is not valid JSON: {exc}") from exc

    deps = doc.get("dependencies") if isinstance(doc, dict) else doc
    if deps is None:
        return None
    if not isinstance(deps, list):
        raise typer.BadParameter(
            f"{path}: `dependencies` must be a list of names or "
            '{"name": ..., "version": ...} objects')

    out: list[str] = []
    for item in deps:
        if isinstance(item, str) and item.strip():
            out.append(item.strip())
        elif isinstance(item, dict) and str(item.get("name") or "").strip():
            out.append(_requirement(str(item["name"]).strip(),
                                    str(item.get("version") or "")))
        else:
            raise typer.BadParameter(
                f"{path}: every dependency needs a name; got {item!r}")
    return out or None


def sdk_distribution_names() -> list[str]:
    """Just the distribution NAMES from :func:`sdk_requirements`.

    For prose. The pyproject gets the full requirement lines; a README saying
    "pip install <name>" must not carry a version the reader then pins by
    copying. Resolved the same way, so a deployment that republishes the SDK
    sees its own names here too.
    """
    names = []
    for line in sdk_requirements():
        # sdk_requirements() yields TOML *array items* - indented, quoted and
        # comma-terminated - because that is what `__SDK_PINS__` is pasted
        # into. Strip the packaging before the specifier, or every name comes
        # back empty and the README says "the SDK ()".
        bare = line.strip().strip(",").strip('"').strip("'")
        name = re.split(r"[<>=!~ \[;]", bare, maxsplit=1)[0].strip()
        if name:
            names.append(name)
    return names


def sdk_requirements() -> list[str]:
    """The SDK requirement lines to write into a scaffolded pack's pyproject.

    READ FROM THIS ENVIRONMENT, never hardcoded. The IMPORT packages are fixed
    (`ioagentfarm`, `agentfarm_skills`) but the DISTRIBUTION names are whatever
    the index you installed from publishes - an organisation that republishes
    the SDK under its own name has `ai-core-harness-engine` on the index and
    nothing called `agentfarm-core` at all. A constant here put that constant
    into every pack the CLI generated, so `pip install -e .` failed on the one
    machine the whole exercise was for, with `No matching distribution found`
    - which reads as "the package is broken", not "the pyproject names a
    distribution your index has never heard of".

    Three layers, most explicit first:

    1. ``~/.iobot/sdk.json`` if it exists - see :data:`SDK_MANIFEST_NAME`. The
       only one that can name a distribution this environment has never
       installed, and the only one that can carry a version.
    2. What is installed here, by the anchors above.
    3. The shipped names, for a source checkout that was never pip-installed.

    NO VERSION SPECIFIER unless the manifest gives one. An SDK fix arrives as
    a new version and a pack should get it by reinstalling, not by editing a
    bound the scaffold guessed at scaffold time; a generated ceiling is also
    wrong the moment the next minor ships, refusing an upgrade nobody asked it
    to refuse, in a file nobody thinks to look in.
    """
    from_file = _sdk_from_manifest()
    if from_file is not None:
        return [f'    "{req}",' for req in from_file]
    return [f'    "{_dist_providing(pkg, ep) or fallback}",'
            for pkg, ep, fallback in _SDK_ANCHORS]

# ── templates ────────────────────────────────────────────────────────
# Placeholders are __TOKENS__, not str.format fields: workflow prompts are full
# of `{{step_output.x}}` templating that .format() would try to interpret.
#
# TOKEN VOCABULARY (shared with cli_pack):
#   __SLUG__ __PKG__ __DIST__ __SOLUTION__ __TITLE__  — the pack
#   __ROLE__       the agent's directory name / the name a step's `role:` uses
#   __AGENT_NAME__ the human name a person calls it ("Logistics Analyst")
#   __ROLE_WORD__  the last word of __ROLE__ ("analyst", "reviewer") — a SOUL
#                  that hardcoded "analyst" described every agent as an analyst
#                  the moment a pack grew a second one.

MANIFEST = """\
# Solution manifest - read by `aicore workspace attach / diff / pull <code>`
# (the review and promotion path) and by the `aicore new-*` grow commands, to
# find the directories that hold this solution's agents, skills, workflows
# and swarms.
#
# This is NOT the same as the `aicore.packs` entry point in pyproject.toml.
# The entry point serves the RUNTIME (in-process pack discovery - the copy a
# run or a chat resolves from is the installed pack). This manifest serves the
# REVIEW path: without it `attach` has nothing to bind to and `diff` nothing
# to classify, however correct the entry point is. A repo needs both.
#
# Paths are relative to this file and must stay inside the repo.
solution: __SOLUTION__
version: 1
roots:
  agents:
    - __PKG__/agents
  skills:
    - __PKG__/skills
  workflows:
    - __PKG__/workflows
  swarms:
    - __PKG__/swarms
"""

PYPROJECT = """\
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "__DIST__"
version = "0.1.0"
description = "__TITLE__ solution pack for AI Core Harness"
requires-python = ">=3.11"
dependencies = [
    # The SDK — a complete engine on its own; the runtime stack (the agent
    # runtime, fastapi/uvicorn, duckdb, the postgres driver) is a hard
    # dependency, no extras to remember.
    # Deliberately unpinned: an SDK fix arrives as a new version, and a pack
    # should get it by reinstalling rather than by editing a bound in here.
    # Add a specifier only when you have a reason to refuse a release, and put
    # the reason beside it. Never fork or edit the SDK.
    #
    # These NAMES are whatever the index you installed from publishes, read
    # from this environment when the repo was scaffolded — not a constant.
__SDK_PINS__
    "pyyaml",
]

[project.optional-dependencies]
dev = ["pytest"]

# THE PLUG-IN SEAM. Without this the pack installs and is invisible — no error,
# just an empty catalog. The value points at the zero-arg `pack()` callable.
[project.entry-points."aicore.packs"]
__SLUG__ = "__PKG__:pack"

# Deterministic CLI tools this pack's agents invoke via `exec`, if any.
# [project.scripts]
# iof-__SLUG__-prep = "__PKG__.tools.prep:main"

[tool.setuptools]
packages = ["__PKG__"]

# CONTENT SHIPS AS PACKAGE DATA. Miss a glob here and `pip install .` still
# succeeds while the wheel contains no workflows — invisible in an editable
# install, fatal on a pod. `tests/test_pack.py` fails if this drifts.
# Dotfiles need their own pattern: `**/*` does not match `.no_discovery`.
[tool.setuptools.package-data]
__PKG__ = [
    "agents/**/*",
    "skills/**/*",
    "workflows/**/*",
    "swarms/**/*",
    "metadata/**/*",
    "memory/**/*",
    "tools.yaml",
    "mcp.yaml",
    "deliveries.yaml",
]
"""

SWARM_YAML = """\
# A SWARM: a meta-agent pursues a goal with a declared roster of external
# A2A agents and MCP tools, deciding call order at runtime. The complement
# of a workflow (a fixed DAG). Compiled into a one-step run at creation -
# it inherits retries, forensics, the fail-closed deliverable gate, the
# attempt cap and supervisor recovery from the run pipeline.
name: __SWARM__
description: __DESCRIPTION__
role: __ROLE__
__ROSTER_BLOCK__
deliverable: swarm_report.md   # the run does not complete until this exists
max_attempts: 2
budget:
  tool_calls: 120   # HARD cap on the meta-agent's tool iterations
  consults: 8       # briefing contract: external dispatch allowance
"""

SWARM_META_MD = """\
<!-- OPTIONAL briefing override. DELETE THIS FILE to use the generated
     briefing, which already carries the goal, the roster, the budget, the
     _run_plan.md checkpoint discipline and the deliverable contract. Keep
     it only when this swarm needs domain-specific instructions, and keep
     the section shape below - each section exists for a reason. -->
# __SWARM_TITLE__

## Your goal

{{goal}}

## Your roster

<< Name the capabilities and what each is FOR - which agent answers which
kind of question, which mcp_<server>_* tools do what. The generated
briefing lists them mechanically; this override is where domain judgement
about them lives. >>

## Your discipline

Before your first capability call, write `_run_plan.md` in your working
directory: the parts of the goal as a checklist, updated after every
completed part. This is your checkpoint - a retried session resumes from
it instead of starting over. Work the plan; do not chase side-questions
the goal did not ask.

<< Add the domain rules: what must never be fabricated, what gets
attributed how, when to stop. >>

## Your deliverable

Write `swarm_report.md` in your working directory: findings first, every
figure attributed to its source capability, failed capabilities named. The
run does not complete until this file exists and is non-empty.
"""

SWARM_ROLE_MD = """\
# Swarm orchestrator - __SWARM__

You are the orchestrator of the `__SWARM__` swarm. __DESCRIPTION__

You are a PURE ORCHESTRATOR: you hold no data of your own. Every figure in
your deliverable comes from a capability in your roster and is attributed
to its source. You decide, at runtime, which capability answers which part
of the goal and in what order - that judgement is the reason you exist.

<< What this orchestrator specialises in, and what it refuses to do. Keep
the rules below - they are the contract the run pipeline verifies. >>

Operating rules:

- Route each part of the goal to the best-fit capability; skip capabilities
  the goal does not need.
- Never fabricate a number, and never guess at data a capability failed to
  return. A failed capability is named in the deliverable.
- Attribute every externally-sourced figure to the agent or tool it came
  from.
- Parts of the goal no capability covers are answered honestly.
"""

PACK_INIT = '''\
"""__TITLE__ — an AI Core Harness domain pack.

Contributes content to the runtime through the ``aicore.packs`` entry point.
Core discovers this at startup and merges the content in, so nothing in the
SDK needs to change for this solution to exist.
"""

from importlib.resources import files

__version__ = "0.1.0"

#: Optional tool-name -> UI-label overrides shown in the run/thought stream.
_LABELS = {
    "data_query": "\\U0001F50D Querying __TITLE__ data",
}


def pack():
    # Imported inside the function so this module stays importable (and the
    # distribution stays introspectable) even where core is not installed.
    from aicore.packs import Pack, load_deliveries, load_mcp_servers

    root = files("__PKG__")
    return Pack(
        # THE WORKSPACE this content belongs to — not this package's name.
        # If this repo later splits into several distributions, they all
        # declare the SAME workspace; that is what merges them into one
        # catalog rather than unrelated packs. (`name=` is the old spelling.)
        workspace="__SOLUTION__",
        agents=root / "agents",
        skills=root / "skills",
        workflows=root / "workflows",
        swarms=root / "swarms",
        # Curated workspace memory: Markdown under memory/, routed by path,
        # injected into every agent as background context. See
        # memory/workspace/_example.md.
        memory=root / "memory",
        labels=_LABELS,
        tools=_cli_tools(),
        # WITHOUT THIS LINE `mcp.yaml` IS A FILE NOTHING READS. `new-mcp-server`
        # writes it and reports success, the wheel ships it, and the pack tier
        # of the merge stays permanently empty — so a run gets no servers and
        # still reports done, with the agent noting the tools were unavailable.
        # It fails GREEN, which is why it went unnoticed.
        mcp_servers=load_mcp_servers("__PKG__"),
        # The tools case actions go through HERE (email, monitoring_task,
        # verification) - `deliveries.yaml`. The platform's `case_action`
        # names no tool; a rulebook delivering by a kind this declares no
        # tool for is refused at install.
        deliveries=load_deliveries("__PKG__"),
    )


def _cli_tools() -> list[dict]:
    """CLI tools (shell executables agents `exec`) declared in tools.yaml.

    NOT MCP servers — those are wired in core's iobot_config and have a
    different execution model entirely. Returning [] is fine; the file is
    optional.
    """
    import yaml

    f = files("__PKG__") / "tools.yaml"
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except (FileNotFoundError, OSError, yaml.YAMLError):
        return []
    tools = data.get("tools") or []
    return [t for t in tools if isinstance(t, dict)]
'''

DELIVERIES_YAML = """\
# The tools this workspace sends CASE ACTIONS through, by delivery kind.
#
# A rulebook says HOW an action reaches the world ("delivery": "email");
# this file says WHICH tool does it here. The platform's `case_action`
# workflow names no tool: the engine narrows its act step to exactly these,
# `iof-case ctx` hands it the one for the action, and `iof-case rulebook
# put` refuses a rulebook whose delivery kind has no tool declared.
#
# A workspace's own ~/.iobot/workspaces/<code>/deliveries.yaml, or
# IOF_CASE_DELIVERIES (a JSON object), outranks this file.
# `iof-case deliveries` shows what resolves. Tool names are the MCP tool
# names as the runtime exposes them (`mcp_<server>_<tool>`).
#
# email:
#   tool: mcp_<server>_send_email
# monitoring_task:
#   tool: mcp_<server>_create_task
# verification:
#   tools: [mcp_<server>_read_record]
"""

MEMORY_EXAMPLE_MD = """\
# Curated workspace memory

Markdown files in this directory are carried WHOLE into the workspace's
memory and injected into every agent of the workspace as background
context. Route a file by its path:

    memory/<anything>.md              -> every agent (workspace scope)
    memory/workspace/**.md            -> every agent (workspace scope)
    memory/solution/<code>/**.md      -> agents running that solution's workflows
    memory/role/<role>/**.md          -> one agent role
    memory/user/<id>/**.md            -> one user (chat turns only)

Write what stays true across runs: how the data is organised and what it
lacks, systems and their quirks, conventions, owners, deadlines. Never
results computed from data - those belong in a run's deliverable.

A file whose name starts with `_` or `.` (this one) is never injected.
Verify with `aicore memory sync` then `aicore memory render --role <role>`.
"""

TOOLS_YAML = """\
# CLI tools this pack's agents invoke via `exec` — validated by `serve` at
# boot and by `aicore cli-hub check`; `aicore cli-hub install` validates each
# first and only fills genuine gaps.
#
# CLI TOOLS ONLY. An MCP server is a different execution model and must never
# be declared here.
#
# owner: domain  -> ships with this pack
# installer: pip | npm | npm-global | brew | build
tools: []
# tools:
#   - name: iof-__SLUG__-prep
#     owner: domain
#     bin: iof-__SLUG__-prep     # console-script from this wheel -> validate only
"""

# SOUL is the agent's IDENTITY, and the scaffold used to assume every agent
# was a SQL analyst: the one template told it to read a catalog, show SQL and
# quote row counts. A client reviewing a generated agent put it plainly -
# "by default the generated agent picks the catalogue-reader mode, means by
# default it is the NLQ to SQL, we may not want that".
#
# They were right. A default is a claim about the common case, and most agents
# are not query engines. `SOUL` is now generic - the grounding discipline
# without the database - and the analyst identity is `SOUL_DATA`, chosen with
# `new-agent --kind data`.
SOUL = """\
# SOUL — __AGENT_NAME__

You are __AGENT_NAME__, the __TITLE__ __ROLE_WORD__.

You do the work you are asked for and say plainly what you did. You would
rather report a gap than fill it with something plausible.

## How you work

- Every claim you make traces to something you actually read, ran or were
  told. You name the source.
- When you cannot answer something, you say so in those words, and say what
  would let you answer it. You never present a guess as a finding.
- You ask when a question is genuinely ambiguous, and get on with it when it
  is not.
- Dates are computed against today, never against a date you remember.

## Boundaries

- You do not modify a system of record.
- You do not act on behalf of a person without being asked to.

<!-- Replace the sections above with what THIS agent is for. Identity is not
     templated at runtime, so this file is read exactly as written. -->
"""

#: The analyst identity the scaffold used to give everybody. Opt in with
#: `aicore new-agent <role> --kind data`.
SOUL_DATA = """\
# SOUL — __AGENT_NAME__

You are __AGENT_NAME__, the __TITLE__ __ROLE_WORD__.

You answer questions about __TITLE__ data with figures you have actually
queried. You would rather report a gap than fill it with something plausible.

## How you work

- Read the catalog before you query. You do not guess column or entity names.
- Every figure you state traces to a query you ran — name the entity, show the
  SQL, give the row count.
- When the data cannot answer something, you say so in those words: "not
  available in `<entity>`". You never estimate it and present the estimate as a
  finding.
- Compute recency against today's date, never against a date you remember.

## Boundaries

- You do not modify source data.
- You do not act on behalf of a person without being asked to.
"""

# TOOLS.md is read by nobody at runtime (`aicore context-report <role>` says
# so) - it is a note to whoever maintains the agent. It named `iof-query`
# unconditionally, for the same reason SOUL assumed a database.
TOOLS_MD = """\
# Tools

List what this agent is expected to reach for, and when. This file is
documentation for a maintainer, not a grant: what an agent can actually run
comes from its skills and the deployment's declared CLI tools.

- `exec` — shell, when the agent has a reason to have one. Prefer a script
  over a prompt whenever the correct behaviour can be written down
  deterministically.
"""

TOOLS_MD_DATA = """\
# Tools

- `iof-query` — structured queries over the catalogued datasets. Start with the
  catalog; the CLI's NOT_FOUND errors carry the schema and fuzzy suggestions,
  so a wrong column name is one round to fix, not five.
- `exec` — shell. Prefer a script over a prompt whenever the correct behaviour
  can be written down deterministically.
"""

MEMORY_MD = """\
# Memory

Method, not findings. Record how to work in this domain — query patterns that
worked, joins that are subtly wrong, aggregations that keep sessions small.

Never record conclusions from a specific dataset (figures, names, rates). They
go stale, and the next run anchors on them and reports them as current.
"""

A2A_CARD = """\
# Public Agent Card — served at /a2a/__ROLE__/.well-known/agent-card.json
# when this agent is exposed on the A2A surface.
#
# `expose: true` IS the exposure switch: `aicore serve` mounts every
# workspace agent whose card declares it — no deployment change needed.
# Set it to false (or delete this file) to withdraw the agent.
#
# The description and examples are what an external caller's routing
# matches against — write them in the terms a question would use.
expose: true
name: "__AGENT_NAME__"
description: >-
  Answers __TITLE__ questions from catalogued data, with every figure
  traced to a query it ran. Replace this with one sentence an external
  caller would match a task against.
version: "1.0.0"
skills:
  - id: general
    name: "__TITLE__ questions"
    description: >-
      The job an external caller would send this agent. Replace with the
      real capability.
    tags: [__ROLE_WORD__]
    examples:
      - "Replace with a question this agent answers well."
"""

HOUSE_SKILL = """\
---
name: __SLUG___house_style
description: How __TITLE__ deliverables are written — structure, evidence, and tone.
roles: [__ROLE__]
---

# __TITLE__ house style

ASSIGNMENT IS EXPLICIT. The `roles:` key above is what places this skill in an
agent's workspace: remove it and no agent starts out holding it — not an error,
just silence. Use `roles: all` only when you genuinely mean every agent.

It is an ASSIGNMENT, not a permission. A workflow step names the skills that
JOB needs and they are resolved from the whole workspace catalog, so a step can
name this skill for an agent that does not hold it and get it.

## Structure

Lead with the answer. Then the evidence. Then the caveats. A reader who stops
after the first paragraph should still have the finding.

## Evidence

Every number carries its source: the entity it came from and the filter that
produced it. A number without a source is a claim, and claims do not ship.

## Tone

Plain sentences. No hedging stacks ("it may potentially be possible that").
State what is true, state what is unknown, and keep the two apart.
"""

CATALOG_YAML = """\
# The dataset catalog this workflow's steps read BEFORE querying anything.
#
# WHY IT SHIPS EVEN WHILE IT IS EMPTY. `{{metadata_dir}}` resolves to the
# workflow's own `metadata/` directory, and to the EMPTY STRING when there
# isn't one — so a step prompt saying "read the catalog in `{{metadata_dir}}`"
# rendered as "read the catalog in ``" and the agent spent its first several
# turns searching the filesystem for a directory that was never going to exist.
# A catalog that is present and honestly empty is a fact the agent can act on;
# an empty path is not.
#
# The catalog is the agent's ONLY source of entity and column names — it does
# not guess them, and `iof-query` returns the schema plus fuzzy suggestions on
# any not-found error, so one wrong name costs one round rather than five.
#
# Put real numbers in `description`: cardinality, ranges, totals, value
# distributions. They are what let the agent choose the right entity without a
# discovery query. Do NOT add example queries or from-clauses — they bias the
# shape of every answer.

entities: []

# Replace the line above with your datasets, e.g.:
#
# entities:
#   - name: deliveries
#     database: logistics                 # a database declared in databases.yml
#     source_path: "data/deliveries.csv"  # a bundled CSV; registered as a view named `deliveries`
#     grain: "One row per delivery leg"
#     semantic: >
#       2024-01-01..today, ~1.4M rows.
#       `on_time` is NULL for legs still in transit (~3%).
#     dimensions:
#       - {name: carrier_id,   type: string,    description: "FK to carriers.id; 42 distinct"}
#       - {name: promised_at,  type: timestamp, description: "delivery window close, UTC"}
#       - {name: delivered_at, type: timestamp, description: "actual arrival, UTC; NULL if in transit"}
#     measures:
#       - {name: on_time,      type: boolean,   description: "delivered_at <= promised_at"}
"""

# ── workflow.yaml, built rather than templated ───────────────────────
#
# `new-solution` emits exactly one workflow and `new-workflow` emits any shape
# the author asks for, so the skeleton cannot be a fixed string in both places
# — and two strings would drift. It is assembled here instead, from blocks that
# are each written once. The COMMENTS are the load-bearing part: they are what
# a reader has in front of them when they add a third step by hand, and they
# are why this is string assembly and not `yaml.dump` (which discards every
# comment and reorders keys into whatever the dict iteration gives).

_WF_HEAD = """\
name: __NAME__
description: >-
__DESCRIPTION__

protocol:
  required_keys: ["STATUS", "OUTPUT"]

# Learning is governed by the platform's learning system (methods distilled
# from completed steps, human-approved, outcomes measured). To opt THIS
# workflow out of learning entirely, uncomment:
# learning: disabled

"""

#: Shown commented-out when the workflow declares no variables of its own.
#: An unused `vars:` entry would be worse than a comment: every `{{var}}` that
#: names nothing renders as the empty string, so a stale variable is invisible
#: in the prompt the agent actually receives.
_WF_VARS_HINT = """\
# Per-workflow variables, readable from every step prompt as `{{window_days}}`.
# Values must be quoted strings — `Workflow.vars` is Dict[str, str] and pydantic
# refuses the whole workflow otherwise.
# vars:
#   window_days: "180"

"""

_WF_ROLES_HEAD = """\
roles:
  # `skills:` is the EXACT set this role runs the job with. Any always:true
  # skill you do not name here is DROPPED by create_filtered_workspace.
  # THE ONE EXCEPTION is output_protocol, which is added unconditionally --
  # without it the step cannot report success, so a list cannot drop it.
  # It also ADDS: a name is resolved from the whole workspace catalog, so you
  # may name a skill this agent does not hold.
"""

#: Emitted in place of a `skills:` list. Naming a filter here would mean
#: guessing the agent's always:true skills from the repo alone — and the repo
#: cannot see the shared SDK skills seeding gives it, so the guess would be
#: short and would silently DROP the ones it missed. Omitting the key loads all
#: of them, which is the safe direction.
_WF_ROLE_NO_SKILLS = """\
    # No `skills:` key, so every skill this agent carries loads.
    # Add one only when this job needs a narrower set. It drops every
    # always:true skill it does not name, EXCEPT output_protocol, which
    # create_filtered_workspace adds unconditionally.
    # skills:
    #   - <a skill this job needs>
"""

#: Every role after the first. The explanation above is worth reading once and
#: is wallpaper by the third repeat, but the commented stub still has to be
#: there — it is what a reader edits.
_WF_ROLE_NO_SKILLS_BRIEF = """\
    # skills:
    #   - output_protocol
"""

_WF_GATE_COMMENT = """\
    # Fail-closed gate: even on STATUS: done, a missing or empty file flips the
    # step to failed and retries. This is what stops a broken handoff from
    # becoming a fabricated downstream section.
"""


def render_workflow_yaml(
    *,
    name: str,
    description: str,
    roles: Sequence[Mapping[str, Any]],
    steps: Sequence[Mapping[str, Any]],
    variables: Mapping[str, str] | None = None,
) -> str:
    """Assemble a ``workflow.yaml`` the project's own linter accepts.

    *roles* entries: ``{"name": str, "skills": list[str] | None}`` - ``None``
    omits the filter. *steps* entries: ``{"key", "title", "role", "deps",
    "requires_artifacts"}``.

    ``name`` MUST equal the directory the file is written into. Everything that
    addresses a workflow uses the directory name; ``name:`` only feeds
    ``Workflow.name``, which the scheduler hands to ``snapshot_workflow()`` -
    on a mismatch that raises FileNotFoundError, the scheduler swallows it at
    debug level, and ``{{metadata_dir}}`` quietly falls off this workflow's own
    catalog. Both callers derive the two from one value for that reason.
    """
    out = _WF_HEAD.replace("__NAME__", name).replace(
        "__DESCRIPTION__",
        # 78, not 79: the description is the one field an author edits in place,
        # and a fold that lands one character short of the margin survives a
        # word being swapped without re-wrapping the paragraph.
        "\n".join(textwrap.wrap(" ".join(description.split()), width=78,
                                initial_indent="  ", subsequent_indent="  ")))

    if variables:
        out += "vars:\n"
        out += "".join(f'  {k}: "{v}"\n' for k, v in variables.items()) + "\n"
    else:
        out += _WF_VARS_HINT

    out += "team:\n" + "".join(f"  - role: {r['name']}\n" for r in roles) + "\n"

    blocks = []
    explained = False
    for r in roles:
        b = f"  - name: {r['name']}\n    prompt: roles/{r['name']}.md\n"
        skills = r.get("skills")
        if skills is None:
            b += _WF_ROLE_NO_SKILLS if not explained else _WF_ROLE_NO_SKILLS_BRIEF
            explained = True
        else:
            b += "    skills:\n" + "".join(f"      - {s}\n" for s in skills)
        blocks.append(b.rstrip("\n"))
    out += _WF_ROLES_HEAD + "\n\n".join(blocks) + "\n\n"

    # The gate comment goes on the LAST gated step: it explains a rule that
    # applies to all of them, and the final deliverable is the one a reader is
    # looking at when they wonder why a "successful" run produced no file.
    last_gated = max((i for i, s in enumerate(steps)
                      if s.get("requires_artifacts")), default=-1)
    blocks = []
    for i, s in enumerate(steps):
        b = (f"  - key: {s['key']}\n"
             f"    title: {s['title']}\n"
             f"    role: {s['role']}\n"
             f"    prompt: steps/{s['key']}.md\n")
        if s.get("deps"):
            b += f"    deps: [{', '.join(s['deps'])}]\n"
        b += f"    max_attempts: {s.get('max_attempts', 2)}\n"
        if s.get("requires_artifacts"):
            if i == last_gated:
                b += _WF_GATE_COMMENT
            b += f"    requires_artifacts: [{', '.join(s['requires_artifacts'])}]\n"
        blocks.append(b.rstrip("\n"))
    out += "steps:\n" + "\n\n".join(blocks) + "\n"
    return out


ROLE_PROMPT = """\
You are __AGENT_NAME__, the __TITLE__ __ROLE_WORD__.

Work from data you have queried. Name the entity and show the SQL behind every
figure. Where the data cannot answer, say "not available in `<entity>`" rather
than estimating.
"""

def step_output_block(summary: str, *, explain: bool) -> str:
    """The protocol contract every step prompt ends with.

    Shared because it is the one part of a step prompt that is not the author's
    to vary: without `STATUS:`/`OUTPUT:` in OUTPUT.md the protocol parser finds
    nothing, the step is marked failed, and it is retried to the hard attempt
    cap having done the work correctly every time.

    *explain* carries the reason for the text-before-tool-call rule. It is
    stated in full ONCE, in the first step of a workflow, and abbreviated after
    that: repeating a five-line rationale at the bottom of every step prompt is
    how a prompt stops being read.
    """
    why = (
        "Print at least one line of text immediately BEFORE every tool call. The\n"
        "orchestrator's stream consumer requires every assistant turn to contain a text\n"
        "block before any tool_use block; turns that open with a tool call are a known\n"
        "cause of dropped responses.\n"
        if explain else
        "Print at least one line of text immediately BEFORE every tool call.\n"
    )
    return (
        "## Output\n"
        "\n"
        f"{why}"
        "\n"
        "Write `{{output_dir}}/OUTPUT.md` starting with exactly these two lines:\n"
        "\n"
        "```\n"
        "STATUS: done\n"
        f"OUTPUT: {summary}\n"
        "```\n"
    )


STEP_ANALYZE = """\
# Gather findings

Goal: {{goal}}

Look back {{window_days}} days from today.

## What to do

1. Read `{{metadata_dir}}/catalog.yaml` before querying anything. Do not guess
   entity or column names.
2. **If it declares no entities** (a scaffolded solution starts that way), stop
   there. Do NOT search the filesystem for data — write `findings.md` saying
   the catalog lists no datasets yet, name `{{metadata_dir}}/catalog.yaml` as
   the file to fill in, and report `STATUS: done`. An empty catalog is a
   finding, not a failure, and hunting for data nobody catalogued is how a run
   ends up reporting numbers from an unrelated file.
3. Otherwise run the queries that answer the goal. Keep each result small —
   aggregate in SQL, not in your head.
4. Write `{{output_dir}}/findings.md`: one finding per section, each with the
   entity, the SQL, the row count, and what it means.
5. State gaps explicitly. A gap is a finding.

""" + step_output_block("<one-line summary of what you found>", explain=True)

def sectioned_write_note(step_key: str, artifact: str) -> str:
    """The sectioned-composition rule, as one numbered-list item.

    A function and not a template string because the step key appears inside a
    filename prefix (`_<step>_section_NN_...`), where a `__TOKEN__` would sit
    against the surrounding underscores and become unreadable.

    The rule itself is not style advice. A single large `write_file` is the
    failure mode that produced "stream stalled for more than 90 seconds" for
    months; several small writes never reproduced it. Shared with cli_pack's
    generic final-step prompt, which composes a deliverable the same way.
    """
    return (f"Write each section as its own file first\n"
            f"   (`_{step_key}_section_NN_<name>.md`), then assemble with a single\n"
            f"   `exec cat _{step_key}_section_*.md > {artifact}`. One large write is the\n"
            f"   single most common way this step stalls; several small ones do not.\n")


STEP_COMPOSE = """\
# Compose the report

Goal: {{goal}}

Findings from the previous step:

{{step_output.analyze}}

## What to do

1. Read `{{output_dir}}/findings.md` — it is the only source for this report.
   Do not introduce a figure that is not in it. If it reports that the catalog
   is empty, say exactly that and name the file to fill in; do not invent a
   report to have something to hand over.
2. Write `{{output_dir}}/report.md` in the house style: answer first, then
   evidence, then caveats.
3. """ + sectioned_write_note("compose", "report.md") + """
""" + step_output_block("<one-line summary of the report>", explain=False)

TEST_PACK = '''\
"""The pack contract — these are the failures that are silent in dev.

Every assertion here corresponds to something that installs cleanly, raises no
error, and produces an empty catalog on a pod.

THE CONTENT TESTS DISCOVER, THEY DO NOT ASSUME. This file used to name the
scaffold's example — `<slug>_report`, `<slug>_analyst`, `<slug>_house_style` —
so a pack scaffolded with `--no-example`, or one whose author renamed anything,
failed its own packaging test on the first run. Everything below that is about
CONTENT is parametrised over what is actually in the pack and skips when there
is none of that kind yet.

What that must never become is a suite that passes because it found nothing.
The four PACKAGING tests — entry point, declared roots, solution manifest,
package-data coverage — take no parameters and always run. They are the ones
worth having: each failure they catch installs cleanly, raises nothing, and
shows up as an empty catalog on a pod that nobody can explain.
"""
from __future__ import annotations

import tomllib
from glob import glob
from pathlib import Path

import pytest
import yaml

import __PKG__

#: The repo, from this file. `pyproject.toml` and `aicore.solution.yaml` are
#: repo files, not package data — they are not reachable through `pack()`.
REPO = Path(__file__).resolve().parents[1]
PKG_DIR = REPO / "__PKG__"

_PACK = __PKG__.pack()


def _content(root, *marker: str) -> list:
    """`<name>/` dirs under *root* carrying *marker* — the engine's own test.

    Every core scanner decides what a directory IS by the file inside it
    (`workflow.yaml`, `workspace/SOUL.md`, `SKILL.md`), never by the directory
    name, so discovery here matches what would actually be loaded. A root that
    does not exist yields nothing rather than raising: three of them are empty
    in a pack scaffolded with `--no-example`, and a wheel cannot carry an empty
    directory at all.
    """
    try:
        entries = list(root.iterdir())
    except (OSError, TypeError, AttributeError):
        return []
    out = []
    for d in entries:
        probe = d
        for part in marker:
            probe = probe / part
        try:
            if probe.is_file():
                out.append(d)
        except (OSError, TypeError):
            continue
    return sorted(out, key=lambda d: d.name)


WORKFLOWS = _content(_PACK.workflows, "workflow.yaml")
AGENTS = _content(_PACK.agents, "workspace", "SOUL.md")
#: Both placements, because they are the same thing to a workflow step: a skill
#: under an agent's workspace is ASSIGNED to that agent by its location, one at
#: pack level is held by nobody until a step names it, and a step resolves
#: either by name from the whole catalog.
SKILLS = _content(_PACK.skills, "SKILL.md") + [
    s for a in AGENTS for s in _content(a / "workspace" / "skills", "SKILL.md")]

_WF_IDS = [d.name for d in WORKFLOWS]
_AGENT_IDS = [d.name for d in AGENTS]
_SKILL_IDS = [d.name for d in SKILLS]


# ── packaging: unconditional, and silent in dev when broken ─────────

def test_entry_point_is_registered():
    """Without this the pack is installed and INVISIBLE — no error, no warning,
    just an empty catalog."""
    from importlib.metadata import entry_points

    assert "__SLUG__" in {e.name for e in entry_points(group="aicore.packs")}, (
        "this pack is not installed in the environment running the tests, or "
        'pyproject.toml lost its [project.entry-points."aicore.packs"] block')


def test_pack_declares_its_content_roots():
    """`pack()` is what the entry point resolves to, and the only thing the
    runtime reads content through. A root it returns None for is content the
    engine will never look for, however correct the directory is.

    EXISTENCE IS DELIBERATELY NOT ASSERTED. An empty content root is a real
    state — `--no-example` produces three of them — a wheel cannot ship an
    empty directory in any case, and every core scanner already tolerates a
    root that is not there. Asserting `is_dir()` here would fail a bare pack
    for something that is not a defect.
    """
    assert _PACK.name == "__SOLUTION__"
    for kind in ("agents", "skills", "workflows", "swarms"):
        assert getattr(_PACK, kind) is not None, f"pack() declares no {kind}"


def test_the_manifest_declares_the_same_content_roots():
    """`aicore.solution.yaml` serves the IMPORTER; the entry point serves
    the RUNTIME. The Studio API pod installs no packs and reads only the
    database, so a missing manifest is an empty Studio however correct the
    entry point is — and a root left undeclared here is content that imports as
    nothing, silently, the day somebody adds it.

    The root must EXIST as well as be declared: `load_manifest` is fail-closed
    and rejects the whole manifest over one missing directory, so `workspace
    import` would refuse this repo outright.
    """
    data = yaml.safe_load(
        (REPO / "aicore.solution.yaml").read_text(encoding="utf-8"))
    assert data["solution"] == "__SOLUTION__"
    roots = data.get("roots") or {}
    for kind in ("agents", "skills", "workflows", "swarms"):
        assert roots.get(kind), f"the manifest declares no {kind} root"
        for rel in roots[kind]:
            assert (REPO / rel).is_dir(), (
                f"roots.{kind} names {rel}, which is not a directory — the "
                "importer rejects the ENTIRE manifest for one missing root")


def test_package_data_globs_cover_every_file_that_is_not_python():
    """A missing glob is invisible in an editable install and fatal in a wheel:
    `pip install .` succeeds and the wheel contains no workflows.

    Expanded with the same recursive `glob` setuptools' own `build_py` uses, so
    this is what a `pip wheel` would actually have shipped — no build backend,
    no network.
    """
    data = tomllib.loads((REPO / "pyproject.toml").read_text(encoding="utf-8"))
    patterns = ((data.get("tool") or {}).get("setuptools") or {}) \\
        .get("package-data", {}).get("__PKG__", [])
    assert patterns, (
        "no [tool.setuptools.package-data] for __PKG__ — a wheel would contain "
        "the Python files and none of the content")

    shipped = set()
    for pat in patterns:
        for hit in glob(pat, root_dir=str(PKG_DIR), recursive=True):
            shipped.add(Path(hit).as_posix())

    missing = sorted(
        f.relative_to(PKG_DIR).as_posix()
        for f in PKG_DIR.rglob("*")
        if f.is_file() and f.suffix != ".py"
        and "__pycache__" not in f.parts
        # `.gitkeep` holds an EMPTY content root open in git, which cannot
        # track a directory on its own. A wheel cannot carry an empty directory
        # either, and does not need to — nothing is in it. Dotfiles are NOT
        # otherwise exempt: `**/*` does not match a leading dot, so a real one
        # (`metadata/.no_discovery`) needs its own pattern, and this is the
        # test that says so.
        and f.name != ".gitkeep"
        and f.relative_to(PKG_DIR).as_posix() not in shipped)
    assert not missing, (
        "these files are in the package but no package-data glob matches "
        f"them, so a wheel would not contain them: {missing}")


# ── content: parametrised over what is actually here ────────────────

@pytest.mark.parametrize("agent", AGENTS, ids=_AGENT_IDS)
def test_an_agents_output_protocol_copy_is_optional_and_never_empty(agent):
    """The PLATFORM supplies `output_protocol`: the engine requires it for
    every step and ships it, so an agent that carries no copy resolves it
    from the shared skill sources. Carrying one is a deliberate override -
    and an EMPTY one is the failure this still catches, because it wins
    over the platform's copy and emits no contract at all."""
    skill = agent / "workspace" / "skills" / "output_protocol" / "SKILL.md"
    if not skill.is_file():
        return                      # supplied by the platform - correct
    assert skill.read_text(encoding="utf-8").strip(), (
        f"{agent.name}: output_protocol is empty and overrides the "
        "platform's copy")


@pytest.mark.parametrize("skill", SKILLS, ids=_SKILL_IDS)
def test_every_skill_has_frontmatter_that_can_be_resolved(skill):
    """The frontmatter is how a skill is ADDRESSED: `name` is what a workflow
    step's `skills:` list matches, `description` is what the agent reads to
    decide the skill applies. An unquoted description containing ": " parses as
    a mapping rather than a string, so the skill silently has neither — and a
    `name` that disagrees with the directory cannot be named by a step at all.

    NO `roles:` REQUIREMENT, deliberately. It used to be an eligibility gate
    and is not one any more: skills are open, and a step resolves a skill by
    name from the whole workspace catalog. What survives is a starting
    assignment for a workspace that does not exist yet — so demanding it here
    would fail every skill `aicore new-skill` writes.
    """
    text = (skill / "SKILL.md").read_text(encoding="utf-8")
    assert text.startswith("---"), f"{skill.name}: no frontmatter"
    meta = yaml.safe_load(text.split("---", 2)[1])
    assert isinstance(meta, dict), f"{skill.name}: frontmatter is not a mapping"
    assert meta.get("name") == skill.name, (
        f"{skill.name}: frontmatter name is {meta.get('name')!r} — a step's "
        "`skills:` list matches the frontmatter, so this skill cannot be named")
    assert str(meta.get("description") or "").strip(), (
        f"{skill.name}: no description — it is what the agent matches against "
        "the job in front of it")


@pytest.mark.parametrize("wf", WORKFLOWS, ids=_WF_IDS)
def test_every_workflow_ships_the_prompt_files_its_yaml_names(wf):
    """`prompt:` paths are resolved against the workflow directory AT RUN TIME.
    A prompt that is in the repo but not in the wheel fails there and only
    there, so this is where the globs and the YAML are made to agree."""
    data = yaml.safe_load((wf / "workflow.yaml").read_text(encoding="utf-8"))
    assert data.get("name") == wf.name, (
        "`name:` must equal the directory name — everything that ADDRESSES a "
        "workflow uses the directory, and on a mismatch the scheduler's "
        "snapshot lookup fails silently and {{metadata_dir}} falls off this "
        "workflow's own catalog")
    for section in ("roles", "steps"):
        for item in data.get(section) or []:
            label = item.get("name") or item.get("key")
            rel = item.get("prompt")
            # A `type: exec` step runs a command and has no prompt at all.
            if not rel and section == "steps" and item.get("command"):
                continue
            assert rel, f"{wf.name}: {section} entry {label!r} names no prompt"
            assert (wf / rel).is_file(), f"{wf.name}: {rel} is not in the repo"


@pytest.mark.parametrize("wf", WORKFLOWS, ids=_WF_IDS)
def test_a_workflow_whose_prompts_read_a_catalog_ships_one(wf):
    """`{{metadata_dir}}` resolves to THIS workflow's metadata/ — and to the
    EMPTY STRING when it has none, so "read the catalog in `{{metadata_dir}}`"
    renders as "read the catalog in ``" and the agent spends its first turns
    hunting the filesystem for a directory that will never exist."""
    reads = [p for p in sorted((wf / "steps").glob("*.md"))
             if "{{metadata_dir}}" in p.read_text(encoding="utf-8")]
    if not reads:
        pytest.skip("no step prompt in this workflow reads {{metadata_dir}}")
    assert (wf / "metadata").is_dir(), (
        f"{wf.name}: {reads[0].name} reads {{{{metadata_dir}}}} but the "
        "workflow ships no metadata/ — the path renders empty")


@pytest.mark.parametrize("wf", WORKFLOWS, ids=_WF_IDS)
def test_a_workflow_skills_filter_keeps_output_protocol(wf):
    """`skills:` is the EXACT set for that job — any always:true skill it does
    not name is dropped by create_filtered_workspace, output_protocol included,
    and the step then cannot report success at all."""
    data = yaml.safe_load((wf / "workflow.yaml").read_text(encoding="utf-8"))
    for role in data.get("roles") or []:
        skills = role.get("skills")
        if skills is None:
            continue     # no filter = every skill the agent carries loads
        assert "output_protocol" in skills, (
            f"{wf.name}/{role['name']}: the filter drops output_protocol")
'''

#: The README's develop loop, in the two states the repo can be scaffolded in.
#: Split because the example variant's very first instruction — `list-workflows`,
#: expect `<slug>_report` — is a WRONG instruction in a repo that was asked not
#: to have one: it prints nothing, and the reader's first act is to debug a
#: working install. The bare variant is the same loop with the three commands
#: that produce the content put in front of it.
_DEVELOP_EXAMPLE = """\
$E/ioagentfarm workspace create __SOLUTION__   # once; later `workspace use __SOLUTION__`
$E/ioagentfarm list-workflows              # expect __SLUG___report
$E/ioagentfarm run __SLUG___report --goal "..." --dry-run
$E/ioagentfarm run __SLUG___report --goal "..."\
"""

_DEVELOP_BARE = """\
# This pack ships no agents, skills or workflows — these three write them.
$E/ioagentfarm new-agent __SLUG___analyst
$E/ioagentfarm new-skill <name>            # --role __SLUG___analyst to give it to one
$E/ioagentfarm new-workflow __SLUG___report --role __SLUG___analyst

$E/ioagentfarm workspace create __SOLUTION__   # once; later `workspace use __SOLUTION__`
$E/ioagentfarm list-workflows              # expect __SLUG___report
$E/ioagentfarm run __SLUG___report --goal "..." --dry-run\
"""

README = """\
# __TITLE__ — an AI Core Harness solution

This repo is a **domain pack**. It contains the __TITLE__ agents, skills and
workflows, and nothing else. The runtime, CLI, engine API and the shared
always-on agents — the Core Assistant (`cora`), the Project Lead
(`project_lead`, Alex) and the Queryngine (`queryngine`, Quinn) — arrive as
the **AI Core Harness SDK** (__SDK_NAMES__).

You never fork or edit core. A core fix or a shared-skill improvement ships as
a new wheel version; you get it by bumping the pin in `pyproject.toml`.

## Install

One virtualenv holds the SDK, this pack, and nothing you did not ask for:

```bash
python -m venv .venv
source .venv/Scripts/activate          # POSIX: source .venv/bin/activate
pip install -e ".[dev]"
```

`pyproject.toml` pins `agentfarm-core`, so that one command pulls the SDK from
whatever index pip is configured for. If yours is a private one, point pip at
it first — `PIP_INDEX_URL`, or your own `pip.conf` / `pip.ini`. A bare install
goes to PyPI and answers `No matching distribution found for agentfarm-core`,
which reads as "no such package" when it means "wrong index".

**ONE VIRTUALENV, and it is this one.** Entry-point discovery is
per-environment: a pack installed anywhere other than where the engine runs is
invisible to it — no error, just an empty catalog. So the venv you install this
into is the venv you run `ioagentfarm` from, engine included.

## Two files make this repo work, and they are not the same file

| File | Serves | If it is wrong |
|---|---|---|
| `pyproject.toml` -> `[project.entry-points."aicore.packs"]` | the **runtime** — in-process pack discovery; every run, chat and Studio view resolves content from the installed pack | pack installs and is invisible; no error |
| `aicore.solution.yaml` | the **review path** — `workspace attach / diff / pull`, and the `new-*` grow commands, find this solution's content roots through it | `attach` has nothing to bind to, `diff` nothing to classify, and a Studio draft has no promotion target |

## Layout

```
__PKG__/
  __init__.py            pack() — the entry point's target
  tools.yaml             CLI tools your agents exec (NOT MCP servers)
  agents/<role>/workspace/
    SOUL.md              identity; never templated
    skills/output_protocol/SKILL.md   REQUIRED — not injected from core
  skills/                shared skills; `roles:` seeds who holds them
  workflows/<name>/
    workflow.yaml        steps, deps, per-role skill filters
    roles/*.md  steps/*.md
```

## Develop

Run everything below from this repo, with the ENGINE venv's binaries — write
`E=<engine>/.venv/Scripts` (POSIX: `<engine>/.venv/bin`) once and reuse it.

```bash
$E/pip install -e ".[dev]"
$E/pytest                                  # the packaging contract
__DEVELOP__
```

`--dry-run` validates the YAML and prints the step graph without spending a
token. Use it on every workflow edit.

A run needs a model provider in `~/.iobot/config.json` — `--dry-run` does
not. See the engine's CLIENT_SETUP.md §5d; `maxTokens` must be `21333` or
every generation call is rejected.

## See it in the Studio

There is no load step. The Studio shows what the engine serving a workspace
is running, and the engine reads this pack from its own venv - so once
`pip install -e .` has run in the engine's venv and `ioagentfarm serve` is up
for the workspace, the agents, skills and workflows here are in the Studio.
Bind the repo so the Studio has a promotion target for its drafts:

```bash
aicore workspace create __SOLUTION__              # the tenant row — attach needs it
aicore workspace attach __SOLUTION__ --url .      # local checkout, or a git URL
aicore workspace diff   __SOLUTION__              # review - what the Studio holds vs. this repo
```

A Studio edit is a **draft**: it resolves only in its author's sessions until
it is promoted, which opens a pull request onto this repo. To bring Studio
content back into the working tree by hand, use `workspace pull`, which
writes files and never commits.

## Build the pod

See `BUILD.md`.

## Conventions worth not re-learning the hard way

- **`roles:` seeds who HOLDS a skill.** No `roles:` key means no agent starts
  out with it. `roles: all` only when you mean every agent. It is an
  assignment, not a permission — nothing refuses a skill to an agent.
- **A workflow `skills:` list is the EXACT set for that job.** Any
  `always: true` skill you do not name is dropped, EXCEPT `output_protocol`,
  which is added unconditionally — and a name you DO list is resolved from the
  whole workspace catalog, so it may be a skill the agent does not hold.
- **If a step's correct behaviour can be written as a script, write a script.**
  Use a `type: exec` step: no agent, no LLM turns, deterministic.
- **`requires_artifacts` is the fail-closed gate.** A step that reports done
  but wrote no file is flipped to failed and retried, which is what stops a
  broken handoff from becoming a fabricated downstream section.
- **Memory holds method, not findings.** Conclusions go stale and the next run
  anchors on them.
"""

#: The standing-instructions file a build session reads first.
#:
#: Scaffolded EMPTY OF ADVICE on purpose. A template full of plausible
#: example rules is worse than no file: the builder reads it at the start of
#: every session and cannot tell an example from a decision, so invented
#: conventions get followed and real ones are never written down. What ships
#: is the shape - what belongs here, what does not - and nothing to obey.
CORABUILD_MD = """\
# CORABUILD

Standing instructions for the __TITLE__ workspace, read at the start of
every build session.

What belongs here:

- conventions this repository follows that a newcomer would not guess
- decisions already taken, with the constraint that forced each one
- anything that must not be done again, and why

What does not: transcripts, status, task lists, or anything true only today.
Keep it short enough to be read in full at the start of every session.

`aicore build` maintains this file. `/remember <note>` appends to **Notes**
below; the builder also rewrites entries here when one is superseded, rather
than leaving two that disagree.

## Notes
"""


BUILD_MD = """\
# Building the __TITLE__ engine pod

This repo builds the **engine pod**: workflows, always-on agents, and the
engine web API (`ioagentfarm serve`). The SDK is not in this repo — it comes
from the internal index via the dependency pins in `pyproject.toml`.

## Dockerfile

```dockerfile
FROM python:3.12-slim

ARG PIP_INDEX_URL
ENV PIP_INDEX_URL=${PIP_INDEX_URL}

WORKDIR /app
COPY . /app

# No -e: an editable install points at the build tree, which is a layer, not a
# runtime path. agentfarm-core + agentfarm-skills resolve from the index.
RUN pip install --no-cache-dir .

COPY entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh

ENV IOF_ROOT=/data/.iof
EXPOSE 8111
ENTRYPOINT ["/entrypoint.sh"]
```

## entrypoint.sh — order matters

Pods are ephemeral: `~/.iobot` is empty on every restart, so the provider
config is written at container start, not at build time. `serve` does the
rest at boot: validates the declared CLI tools, materialises the always-on
agent homes and registers the installed pack. There is no seed or sync step -
content is read from the pack `pip install` put in this image.

```bash
#!/usr/bin/env bash
set -e

# 1. Provider config — MUST exist before serve.
#    maxTokens 21333 is the SDK's non-streaming ceiling. Above it EVERY
#    generation call is rejected ("streaming is required for operations that
#    may take longer than 10 minutes"); reads still succeed, so it presents as
#    a flaky model rather than a config error. Do not raise it.
mkdir -p ~/.iobot
cat > ~/.iobot/config.json <<EOF
{
  "agents": { "defaults": { "model": "azure/${AZURE_DEPLOYMENT}", "maxTokens": 21333 } },
  "providers": {
    "azureOpenai": {
      "apiKey": "${AZURE_API_KEY}",
      "apiBase": "${AZURE_API_BASE}",
      "apiVersion": "${AZURE_API_VERSION}"
    }
  }
}
EOF

# 2. The tenant this pod serves. `serve` refuses to start without one, and
#    every command it runs acts on it. `create` is idempotent; `attach` binds
#    the repo as the Studio's promotion target and refuses a workspace row
#    that does not exist yet.
: "${IOF_WORKSPACE:?set IOF_WORKSPACE to the tenant this pod serves}"
aicore workspace create "${IOF_WORKSPACE}" || true
aicore workspace attach "${IOF_WORKSPACE}" --url /app || true

# 3. Authentication. `serve` binds 0.0.0.0 here and REFUSES an exposed port
#    with no authentication unless the deployment says so in as many words,
#    so this line is not optional - it is where the posture is stated.
#      Entra ID: IOF_ENGINE_AUTH=oidc + IOF_ENGINE_OIDC_TENANT_ID
#                + IOF_ENGINE_OIDC_AUDIENCE=api://<engine app id uri>
#      Okta:     IOF_ENGINE_AUTH=oidc + IOF_ENGINE_OIDC_ISSUER
#                + IOF_ENGINE_OIDC_AUDIENCE
#      secret:   IOF_ENGINE_AUTH=apikey + IOF_ENGINE_API_KEYS (32+ chars)
export IOF_ENGINE_AUTH="${IOF_ENGINE_AUTH:-off}"

# 4. Serve. Content is resolved from the installed pack on use - nothing to
#    seed, sync or push first.
exec ioagentfarm serve --port 8111
```

There is no post-start sync: the Studio reads the catalog from the engine
serving this workspace, so what the pod runs is what the Studio shows.

## Runtime environment

| Var | Notes |
|---|---|
| `IOF_WORKSPACE` | the tenant this pod serves (`__SOLUTION__`); `serve` refuses to start without it |
| `IOF_ENGINE_AUTH` | `oidc` (Entra ID / Okta) or `apikey`. **`serve` refuses an exposed port without one**, unless set to `off` explicitly. See `docs/engine-authentication.md` |
| `IOF_DATABASE_URL` | engine schema |
| `IOF_DB_SCHEMA` | **must match the API pod exactly**; a mismatch does not error — each process quietly uses its own schema and the UI shows no runs |
| `IOF_ROOT` | `/data/.iof`, pod-local volume, absolute |
| `AZURE_API_KEY` / `AZURE_API_BASE` / `AZURE_API_VERSION` / `AZURE_DEPLOYMENT` | from Secret |
| `IOBOT_MAX_CONCURRENT_REQUESTS` | `10` under demo load (default 3) |

## One-time database init (NOT in the pod)

```bash
ioagentfarm init
python -m ioagentfarm.scripts.apply_sql <schema> setup_schema.sql
```

## Smoke

- `GET :8111/health` -> 200 (the probes answer without a credential)
- `GET :8111/api/whoami` -> 401 when auth is on, and 200 with a principal
  when the caller presents one - the cheapest proof the guard is installed
- `python -c "from ioagentfarm.packs import load_registry; print([p.name for p in load_registry().packs])"`
  -> includes `__SOLUTION__`
"""

GITIGNORE = """\
__pycache__/
*.py[cod]
*.egg-info/
build/
dist/
.venv/
.env
.iof/
.pytest_cache/
"""

ENV_EXAMPLE = """\
# Settings for this workspace. COPY THIS TO
# ~/.iobot/workspaces/__ENVWS__/.env
# -- not to a .env beside this file, which is NOT read.
#
#   Windows    copy .env.example %USERPROFILE%\\.iobot\\workspaces\\__ENVWS__\\.env
#   macOS      cp .env.example ~/.iobot/workspaces/__ENVWS__/.env
#   Linux      cp .env.example ~/.iobot/workspaces/__ENVWS__/.env
#
# Settings are per workspace so that two workspaces on one machine cannot
# read each other's credentials or write to each other's database. A file in
# any other location -- here, your home directory, ~/.iobot/.env -- applies to
# commands that never named the workspace it belongs to, so none of them are
# read. A byte-order mark is tolerated, so it does not matter which
# Windows tool writes this file.
# `aicore current --workspace __ENVWS__` reports the file in force
# and names any it found and did not read.
#
# NEVER commit the filled-in file.
#
# To develop against your own files and a local database instead, run
# `aicore local on --workspace __ENVWS__` and set nothing here.

IOF_DATABASE_URL=postgresql://user:pass@host:5432/aicore
IOF_DB_SCHEMA=iof

AZURE_API_KEY=
AZURE_API_BASE=
AZURE_API_VERSION=2024-10-21
AZURE_DEPLOYMENT=
"""


def _write(path: Path, text: str, subs: dict[str, str]) -> None:
    for token, value in subs.items():
        text = text.replace(token, value)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _content_roots(pkg_dir: Path) -> None:
    """Create the three empty content roots, each holding a ``.gitkeep``.

    NOT decoration, and not a signpost - the alternative was omitting them, and
    it does not work. ``aicore.solution.yaml`` declares all three roots, and
    ``solution_manifest.load_manifest`` is FAIL-CLOSED on a declared root that
    is not a directory: one missing root rejects the WHOLE manifest, so
    ``workspace diff`` and ``workspace push`` refuse a content-free repo
    outright. Declaring fewer roots instead would be worse - the day the author
    runs ``new-agent``, the agent lands in a directory the importer was never
    told about and imports as nothing, with no error.

    ``.gitkeep`` is what makes that survive a clone: git does not track an empty
    directory, so without it the roots exist on the scaffolding machine and are
    gone for everyone else - the manifest rejection would then reproduce only
    for the second person. It is deliberately NOT added to the package-data
    globs: a wheel cannot ship an empty directory in any case, nothing is in it,
    and every core scanner already tolerates a root that is not there.
    """
    for kind in ("agents", "skills", "workflows", "swarms"):
        (pkg_dir / kind).mkdir(parents=True, exist_ok=True)
        (pkg_dir / kind / ".gitkeep").write_text("", encoding="utf-8")


def new_solution(
    name: str = typer.Argument(
        ..., help="Solution slug - lowercase, e.g. 'procurement'."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="Where to create the repo (default: the current directory)."),
    title: str = typer.Option(
        None, "--title", help="Human title (default: derived from the slug)."),
    solution_code: str = typer.Option(
        None, "--code",
        help="Workspace/solution code - the tenant `workspace create` / "
             "`use` names and the manifest declares (default: the slug)."),
    example: bool = typer.Option(
        True, "--example/--no-example",
        help="Include a worked example - one agent, one skill, one two-step "
             "workflow. --no-example writes the packaging only (entry point, "
             "manifest, package-data globs, tests) and leaves the content to "
             "`new-agent`, `new-skill` and `new-workflow`."),
    force: bool = typer.Option(
        False, "--force", help="Write into a non-empty directory."),
) -> None:
    """Scaffold a new domain solution repo that installs, imports and runs.

    The example is the DEFAULT because it is the fastest way to see the shape
    of a pack. Pass --no-example when you came to write your own: the repo is
    then packaging only, and `new-agent` / `new-skill` / `new-workflow` fill it
    in. Everything that fails silently when hand-written still ships either way
    - the entry point, the manifest, the package-data globs and the tests that
    fail when one of them drifts.
    """
    slug = name.strip().lower().replace("-", "_")
    if not SLUG_RE.match(slug):
        raise typer.BadParameter(
            f"{name!r} must match ^[a-z][a-z0-9_]{{2,30}}$ — it becomes a "
            "Python package name")

    # NO `agentfarm_` PREFIX. The package is the team's own — it carries their
    # domain content, lives in their repo, and the `aicore.packs` entry
    # point names the module explicitly, so nothing in the runtime derives the
    # name or pattern-matches it. `cli_pack.py` still strips the old prefix
    # when it derives a title, which keeps already-scaffolded packs working.
    pkg = slug
    dist = slug.replace("_", "-")
    solution = (solution_code or slug).strip()
    human = title or slug.replace("_", " ").title()
    analyst = f"{slug}_analyst"
    analyst_name = human.split()[0] + " Analyst"

    # THE CURRENT DIRECTORY, not a subdirectory of it. The old default made
    # `./<slug>-solution`, which nests the repo one level below the directory
    # the author just made and put their virtualenv in — so every later shell
    # activates the environment in one place and works in another. Scaffolding
    # where you already are is what people do, and `--dir` is still there for
    # the case that wants a subdirectory.
    root = Path(directory) if directory else Path.cwd()

    # INSIDE A WORKSPACE REPO this command grows the workspace instead: a new
    # workflows-only package, wired into pyproject + the manifest's
    # `solutions:` map. Agents/skills/tools stay in the shared pack — that is
    # the workspace contract — so none of the standalone flags (--example,
    # --code) apply here and the example content is deliberately not written.
    ws_root = _enclosing_workspace(root)
    if ws_root is not None:
        _grow_workspace_solution(ws_root, slug, human)
        return

    # THE DOUBLED-NAME TRAP, refused rather than created. The standalone
    # layout is repo-root + a `<slug>/` package inside it, so running this
    # inside a directory ALREADY named `<slug>` writes `<slug>/<slug>/agents/`
    # - the exact `solutions/ainf2/ainf2` nesting that "cost a session to
    # unpick", and the one a client hit: a `pharma_brand_marketer` agent
    # landed at `solutions/ai_core_ainf/ai_core_ainf/agents/`. A build agent
    # reads that as correct and carries on, so this is a REFUSAL, not a
    # warning - it holds when the prompt does not. `--dir` names the escape
    # for the rare deliberate `foo/foo` repo, and the message names the two
    # real intents: run it from the parent (one standalone repo), or make the
    # monorepo a workspace so solutions live under `solutions/<slug>/` with
    # agents/skills shared at the top - which is almost certainly what
    # someone standing in a `solutions/` folder meant.
    rroot = root.resolve()
    if rroot.name == pkg and not directory:
        in_monorepo = rroot.parent.name == "solutions"
        parent = rroot.parent
        hint = (
            "\nThis looks like a monorepo (you are inside a `solutions/` "
            "folder). For several solutions that SHARE agents and skills, "
            "make the repo a workspace once at its root — `aicore "
            "new-workspace <name>` — and then `aicore new-solution "
            f"{slug}` grows it cleanly as `solutions/{slug}/` (agents and "
            "skills stay shared at the top, no repeated name)."
            if in_monorepo else
            f"\nFor one standalone repo, run it from the parent instead:\n"
            f"  cd {parent}\n  aicore new-solution {slug}\n"
            f"— that makes `{slug}/` the repo with the `{slug}/` package "
            "inside it, named once.")
        raise typer.BadParameter(
            f"you are inside a directory already named `{pkg}`, so "
            f"`new-solution {slug}` here would create `{pkg}/{pkg}/` — the "
            "package nested under a same-named folder, which reads as a "
            f"repeated name (`{pkg} > {pkg} > agents > ...`) and is the "
            "nesting trap this command exists to avoid." + hint +
            "\n(If you truly want a nested `foo/foo`, pass `--dir .`.)")

    # A virtualenv, an env file or a git repo do NOT make a directory "already
    # in use". They are exactly what is there when someone has followed the
    # install page: create a directory, put a venv in it, install the SDK,
    # scaffold. Counting them meant --force on the ordinary path, which trains
    # people to pass a flag whose whole purpose is to make them stop and think.
    # `.iof` belongs here for the same reason as `.venv`: it is GENERATED
    # ENGINE STATE, never content anybody authored. Leaving it out made the
    # ordinary documented path fail -- `local on` and `workspace create` both
    # create it, so scaffolding after either one refused with "already
    # contains .iof" and demanded --force on a first run in an empty folder.
    # A walkthrough stopped there. `__pycache__` and `.pytest_cache` are the
    # same category and appear as soon as anything has been run.
    _NOT_CONTENT = {".venv", "venv", ".git", ".env", "env.sh", ".gitignore",
                    ".python-version", "state", ".iof", "__pycache__",
                    ".pytest_cache"}
    occupied = ([p for p in root.iterdir() if p.name not in _NOT_CONTENT]
                if root.exists() else [])
    if occupied and not force:
        raise typer.BadParameter(
            f"{root} already contains {', '.join(sorted(p.name for p in occupied)[:4])}"
            f"{' …' if len(occupied) > 4 else ''} — pass --force to write into it, "
            f"or --dir to scaffold somewhere else")

    subs = {
        "__SLUG__": slug,
        "__PKG__": pkg,
        "__DIST__": dist,
        "__SDK_PINS__": "\n".join(sdk_requirements()),
        "__SDK_NAMES__": " + ".join(f"`{n}`" for n in sdk_distribution_names()),
        "__SOLUTION__": solution,
    "__ENVWS__": solution,
        "__TITLE__": human,
        "__ROLE__": analyst,
        "__AGENT_NAME__": analyst_name,
        "__ROLE_WORD__": analyst.rsplit("_", 1)[-1],
        # Substituted here rather than left to `_write`: token replacement runs
        # in dict order, so a block inserted last would keep its own `__SLUG__`
        # verbatim — order-dependence that reads as correct and is not.
        "__DEVELOP__": (_DEVELOP_EXAMPLE if example
                        else _DEVELOP_BARE).replace("__SLUG__", slug)
                                            .replace("__SOLUTION__", solution),
    }

    p = root / pkg
    ws = p / "agents" / analyst / "workspace"
    wf = p / "workflows" / f"{slug}_report"

    _write(root / MANIFEST_NAME, MANIFEST, subs)
    _write(root / "pyproject.toml", PYPROJECT, subs)
    _write(root / "README.md", README, subs)
    _write(root / "BUILD.md", BUILD_MD, subs)
    _write(root / "CORABUILD.md", CORABUILD_MD, subs)
    _write(root / ".gitignore", GITIGNORE, subs)
    _write(root / ".env.example", ENV_EXAMPLE, subs)

    _write(p / "__init__.py", PACK_INIT, subs)
    _write(p / "tools.yaml", TOOLS_YAML, subs)
    _write(p / "deliveries.yaml", DELIVERIES_YAML, subs)

    # Every declared root must EXIST regardless of the example: the manifest
    # is fail-closed on a declared-but-missing directory, and the example
    # writes content into only SOME of the roots (there is no example swarm),
    # so relying on content creation left `swarms/` undeclared-on-disk and
    # `workspace push` rejecting the whole repo. Idempotent beside real
    # content.
    _content_roots(p)

    if example:
        _write(ws / "SOUL.md", SOUL, subs)
        _write(ws / "TOOLS.md", TOOLS_MD, subs)
        _write(ws / "memory" / "MEMORY.md", MEMORY_MD, subs)
        # Curated workspace memory: an explanatory file that is never injected
        # (its name starts with `_`), so the layout is discoverable in place.
        _write(p / "memory" / "workspace" / "_example.md", MEMORY_EXAMPLE_MD, subs)
        _write(p / "skills" / f"{slug}_house_style" / "SKILL.md", HOUSE_SKILL,
               subs)

        # `{{metadata_dir}}` resolves to the workflow's OWN metadata/ — and to ""
        # when there is none, which is how the analyze step came to say "read the
        # catalog in ``". Ship the directory so the reference is always real.
        _write(wf / "metadata" / "catalog.yaml", CATALOG_YAML, subs)
        # Built by the same function `new-workflow` uses, so the two skeletons
        # cannot drift apart. `name:` and the directory are one value here for the
        # reason given in render_workflow_yaml's docstring.
        (wf / "workflow.yaml").write_text(render_workflow_yaml(
            name=f"{slug}_report",
            description=f"Two-step {human} report: the analyst gathers grounded "
                        "findings, then composes them into a deliverable.",
            variables={"window_days": "180"},
            roles=[{"name": analyst,
                    "skills": ["output_protocol", f"{slug}_house_style"]}],
            steps=[
                {"key": "analyze", "title": "Gather findings", "role": analyst,
                 "requires_artifacts": ["findings.md"]},
                {"key": "compose", "title": "Compose the report", "role": analyst,
                 "deps": ["analyze"], "requires_artifacts": ["report.md"]},
            ],
        ), encoding="utf-8")
        _write(wf / "roles" / f"{analyst}.md", ROLE_PROMPT, subs)
        _write(wf / "steps" / "analyze.md", STEP_ANALYZE, subs)
        _write(wf / "steps" / "compose.md", STEP_COMPOSE, subs)

    # (the roots themselves are written above for BOTH branches — the
    # --no-example repo is complete without an agent, and the example repo
    # still needs the roots its content does not populate.)

    _write(root / "tests" / "test_pack.py", TEST_PACK, subs)

    console.print(f"[bold green]Created[/] {root}")
    console.print(f"  distribution : {dist}")
    console.print(f"  package      : {pkg}")
    console.print(f"  entry point  : {PACK_ENTRY_POINT_GROUP} -> {slug} = {pkg}:pack")
    console.print(f"  solution code: {solution}")
    if not example:
        console.print("  content      : none (--no-example) - empty agents/, "
                      "skills/, workflows/")


    # The venv running this command IS the engine's, and the pack must install
    # into it — entry-point discovery is per-environment. Printing the concrete
    # path removes the step where the reader has to work out which venv is
    # meant. (The earlier text said `python -m venv .venv && pip install -e .`,
    # which fails today with "No matching distribution found for
    # agentfarm-core": the SDK is a checkout, not a published wheel.)
    import sys as _sys
    bin_dir = Path(_sys.executable).resolve().parent
    #
    # markup=False: rich reads "[dev]" as a style tag and eats it, so the very
    # first command the reader copies used to print as `pip install -e "."` —
    # no pytest, and the `pytest` line below then fails for no visible reason.
    # bin_dir comes from sys.executable, so these paths name THE VENV THAT RAN
    # THIS COMMAND — which is the right one by construction. The old wording
    # called it "the engine venv", a second thing to go and find; it is the
    # same venv, and saying so removes the step where somebody goes looking for
    # a framework checkout they do not have.
    console.print("\n[bold]Next[/] [dim](this venv - a pack installed in any "
                  "other one is invisible to the engine)[/]")
    # ONLY WHEN IT IS A MOVE. The scaffold writes into the CURRENT
    # directory, and printing `cd <where you already are>` directly
    # contradicts the guide's "no cd afterwards" paragraph -- and now
    # that the package is named after the slug, an obeyed `cd` lands
    # INSIDE the package, where the next command cannot find
    # pyproject.toml.
    if Path.cwd().resolve() != Path(root).resolve():
        console.print(f"  cd {root}", markup=False)
    console.print(f'  "{bin_dir / "pip"}" install -e ".[dev]"', markup=False)
    console.print(f'  "{bin_dir / "pytest"}"                      '
                  "# packaging contract", markup=False)
    # THE TENANT, THEN THE RUN. Content is read from the pack just installed -
    # there is no seed, sync or push between `pip install` and `run`; what
    # every later command needs is a selected workspace, and `create` both
    # creates and selects it (`use` selects an existing one).
    console.print(f'  {invocation()} workspace create {solution}   '
                  "# the tenant - creates it and selects it", markup=False)
    if example:
        console.print(f'  {invocation()} list-workflows  '
                      f"# expect {slug}_report", markup=False)
        console.print(f'  {invocation()} run {slug}_report '
                      '--goal "..." --dry-run', markup=False)
    else:
        # Naming the three commands is the whole point of the flag. Without
        # them the reader is looking at a directory with no agents, no skills
        # and no workflows, and nothing on screen says that is the finished
        # state or what turns it into a working pack.
        console.print(f'  {invocation()} new-agent '
                      f"{slug}_analyst", markup=False)
        console.print(f'  {invocation()} new-skill <name>'
                      f'          # --role {slug}_analyst gives it to that '
                      "agent", markup=False)
        console.print(f'  {invocation()} new-workflow '
                      f"{slug}_report --role {slug}_analyst", markup=False)


# ── the WORKSPACE repo: one family, many solutions ───────────────────
#
# `new-workspace` scaffolds the shape `solutions/pharma` reached by hand: a
# SHARED package carrying the family's agents, skills and CLI tools, plus one
# workflows-only package per solution — all declaring the same `Pack.name`
# (the family code), each solution package setting `Pack.solution`. ONE
# distribution, several entry points: the simplest layout that satisfies
# "agents are workspace-level, workflows are solution-level". A team that
# later wants independently-versioned solution wheels splits packages into
# sibling distributions; `find_pack` reads both shapes.

WS_MANIFEST = """\
# Workspace manifest — one FAMILY, many solutions.
#
# Same file a classic single-solution repo has, plus the `solutions:` mapping.
# Family-level content (agents, skills, tools) is declared ONCE under `roots`
# and shared by every solution; each solution names only its workflow roots.
# An older platform ignores the `solutions:` key entirely and reads this as
# one solution — nothing breaks, only the per-solution attribution is lost.
#
# Read by `aicore workspace attach / diff / pull <code>` (the review and
# promotion path) and by the `aicore new-*` grow commands; the entry points in
# pyproject.toml serve the RUNTIME. A repo needs both.
# Paths are relative to this file and must stay inside the repo.
solution: __CODE__
version: 1
roots:
  agents:
    - __SHARED_PKG__/agents
  skills:
    - __SHARED_PKG__/skills
__SOLUTIONS_BLOCK__
"""

_WS_SOLUTIONS_EMPTY = """\
# No solutions yet — `aicore new-solution <name>` (run inside this repo)
# adds a workflows-only package and lists it here.
solutions: {}
"""

WS_PYPROJECT = """\
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "__DIST__"
version = "0.1.0"
description = "__TITLE__ workspace for AI Core Harness"
requires-python = ">=3.11"
dependencies = [
    # The SDK — see the note in any solution repo's pyproject: names come from
    # the index this environment installed from, deliberately unpinned.
__SDK_PINS__
    "pyyaml",
]

[project.optional-dependencies]
dev = ["pytest"]

# THE PLUG-IN SEAM — one entry point per package. The shared package carries
# the family's agents/skills/tools; each solution package carries only its
# workflows. Every `pack()` returns the SAME `Pack.name` (the family code):
# that is what merges them into one catalog family instead of unrelated packs.
[project.entry-points."aicore.packs"]
__SHARED_SLUG__ = "__SHARED_PKG__:pack"
__SOLUTION_EPS__
[tool.setuptools]
packages = [__PACKAGES__]

# CONTENT SHIPS AS PACKAGE DATA — per package. Miss a glob and `pip install .`
# still succeeds while the wheel ships no content; tests/test_workspace.py
# fails if this drifts.
[tool.setuptools.package-data]
__SHARED_PKG__ = [
    "agents/**/*",
    "skills/**/*",
    "memory/**/*",
    "tools.yaml",
    "mcp.yaml",
    "deliveries.yaml",
]
__SOLUTION_DATA__
"""

WS_SHARED_INIT = '''\
"""__TITLE__ — the workspace's SHARED pack (family-level content).

Carries what every solution of this workspace shares: the agents, the skills
and the CLI tools. It deliberately ships NO workflows — those are
solution-level and live one package per solution, each declaring the same
``Pack.name`` so the runtime merges the family into one catalog entry.
"""

from importlib.resources import files

__version__ = "0.1.0"


def pack():
    from aicore.packs import Pack, load_deliveries, load_mcp_servers

    root = files("__SHARED_PKG__")
    return Pack(
        # THE WORKSPACE CODE — every package of this workspace declares the
        # same one. Role/skill/tool names must be unique across the
        # workspace; this package is their only carrier.
        workspace="__CODE__",
        agents=root / "agents",
        skills=root / "skills",
        # Curated workspace memory (memory/ at the repo root, routed by
        # path) — background context every agent of the workspace receives.
        memory=root / "memory",
        tools=_cli_tools(),
        # Declared servers are shared by the whole family, like agents and
        # skills. Omit this and `mcp.yaml` ships in the wheel and is never
        # read — the run reports success with no servers attached.
        mcp_servers=load_mcp_servers("__SHARED_PKG__"),
        # The tools case actions go through HERE - `deliveries.yaml`, beside
        # tools.yaml and mcp.yaml. See `iof-case deliveries`.
        deliveries=load_deliveries("__SHARED_PKG__"),
    )


def _cli_tools() -> list[dict]:
    """CLI tools (shell executables agents `exec`) declared in tools.yaml."""
    import yaml

    f = files("__SHARED_PKG__") / "tools.yaml"
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except (FileNotFoundError, OSError, yaml.YAMLError):
        return []
    return [t for t in (data.get("tools") or []) if isinstance(t, dict)]
'''

WS_SOLUTION_INIT = '''\
"""__SOL_TITLE__ — a solution of the __CODE__ workspace (workflows only).

Agents, skills and tools come from the workspace's shared package
(`__SHARED_PKG__`); this package must never grow its own — a duplicate name
across the family resolves install-order-first and the linter flags it.
"""

from importlib.resources import files

__version__ = "0.1.0"


def pack():
    from ioagentfarm.packs import Pack

    root = files("__SOL_PKG__")
    return Pack(
        workspace="__CODE__",         # the WORKSPACE code — same as every package
        solution="__SOL__",           # what the catalog attributes these to
        workflows=root / "workflows",
        swarms=root / "swarms",
    )
'''

TEST_WORKSPACE = '''\
"""The workspace contract — one family, shared content, per-solution workflows.

Same spirit as a solution repo's test_pack.py: every assertion corresponds to
something that installs cleanly, raises nothing, and produces a wrong or empty
catalog on a pod. Content is DISCOVERED from pyproject + manifest, never
assumed, so renaming or adding a solution does not break this file.
"""
from __future__ import annotations

import importlib
import tomllib
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
_DATA = tomllib.loads((REPO / "pyproject.toml").read_text(encoding="utf-8"))
_EPS = _DATA["project"]["entry-points"]["aicore.packs"]

#: {slug: Pack} for every entry point this repo declares.
PACKS = {slug: importlib.import_module(target.split(":")[0]).pack()
         for slug, target in _EPS.items()}
_SHARED = [p for p in PACKS.values() if p.workflows is None]
_SOLUTIONS = [p for p in PACKS.values() if p.workflows is not None]


def test_every_entry_point_returns_a_pack():
    from ioagentfarm.packs import Pack
    assert PACKS, "pyproject declares no aicore.packs entry points"
    for slug, p in PACKS.items():
        assert isinstance(p, Pack), f"{slug} did not return a Pack"


def test_one_family_one_name():
    """Every package returns the SAME Pack.name — that is what merges them
    into one catalog family instead of unrelated packs."""
    names = {p.name for p in PACKS.values()}
    assert len(names) == 1, f"packages disagree on the family code: {names}"


def test_exactly_one_shared_package():
    assert len(_SHARED) == 1, (
        "a workspace has ONE shared package (agents+skills+tools, no "
        f"workflows); found {len(_SHARED)}")


def test_shared_package_shape():
    (shared,) = _SHARED
    assert shared.agents is not None and shared.skills is not None
    assert shared.solution is None


def test_solution_packages_carry_only_workflows():
    for p in _SOLUTIONS:
        assert p.solution, (
            f"solution package of family {p.name} sets no Pack.solution — "
            "the catalog cannot attribute its workflows")
        assert p.agents is None and p.skills is None, (
            f"solution `{p.solution}` ships agents or skills — family-level "
            "content belongs in the shared package")


def test_manifest_loads_and_matches():
    from ioagentfarm.solution_manifest import load_manifest
    m = load_manifest(REPO)
    assert m.solution == next(iter(PACKS.values())).name
    declared = set(m.solutions)
    packaged = {p.solution for p in _SOLUTIONS}
    assert declared == packaged, (
        f"manifest solutions {sorted(declared)} != packaged {sorted(packaged)}")


def test_registered_in_this_venv():
    """`pip install -e .` ran in THIS venv — entry points are per-environment
    and a pack in any other venv is invisible to the engine, with no error."""
    from importlib.metadata import entry_points
    installed = {e.name for e in entry_points(group="aicore.packs")}
    missing = set(_EPS) - installed
    assert not missing, (
        f"entry points not registered in this venv: {sorted(missing)} — run "
        "`pip install -e .` here")
'''


# ── the FLAT workspace layout (the default) ──────────────────────────
#
# Content dirs live at the repo ROOT on the import path (git -> `workspace
# import` -> DB -> the engine materializes); solutions are plain workflow
# folders under solutions/. The ONE packaged thing is `tools/` — console
# scripts must be pip-installed — package-dir-mapped so the directory stays
# `tools/` while the import name is `<code>_tools`. The workspace prefix
# exists ONLY inside pyproject.toml. Verified end to end (editable install,
# wheel install, engine scanners, manifest) before this shipped.

WS_MANIFEST_FLAT = """\
# Workspace manifest — one FAMILY, many solutions, FLAT layout.
#
# Read by `aicore workspace attach / diff / pull __CODE__` (the review and
# promotion path) and by the `aicore new-*` grow commands, to find this
# workspace's content roots. The engine reads the SAME directories through
# the pyproject package-dir mapping (`pip install -e .`), so a run or a chat
# resolves your files directly - nothing is pushed. Paths are relative to
# this file and must stay inside the repo.
solution: __CODE__
version: 1
roots:
  agents: [agents]
  skills: [skills]
__SOLUTIONS_BLOCK__
"""

WS_PYPROJECT_FLAT = """\
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "__DIST__"
version = "0.1.0"
description = "__TITLE__ workspace for AI Core Harness"
requires-python = ">=3.11"
dependencies = [
    # The SDK — names come from the index this environment installed from,
    # deliberately unpinned. Add your tools' pip dependencies here too: a
    # skill-embedded script or CLI tool importing pillow/pandas/... needs the
    # pod venv to actually have it.
__SDK_PINS__
    "pyyaml",
]

[project.optional-dependencies]
dev = ["pytest"]

# THE PLUG-IN SEAM. One entry point for the workspace's shared content
# (agents + skills + tools) and one per solution (its workflows). Every
# pack() returns the SAME Pack.name — the family code — which is what merges
# them into one catalog entry instead of unrelated packs.
[project.entry-points."aicore.packs"]
__CODE__ = "__TOOLS_PKG__:pack"
__SOLUTION_EPS__
# Deterministic CLI tools this workspace's agents run via `exec`.
# [project.scripts]
# iof-__CODE__-prep = "__TOOLS_PKG__.prep:main"

# FLAT ON DISK, PACKAGED FOR THE ENGINE. The directories stay `agents/`,
# `skills/`, `tools/`, `solutions/<name>/` — the unique import names exist
# only in this mapping. That is what lets the engine READ YOUR FILES: in an
# editable install `files("__CONTENT_PKG__")` resolves to the source tree, so
# an edit is live immediately, with no build step and nothing to push.
[tool.setuptools]
packages = [__PACKAGES__]

[tool.setuptools.package-dir]
__TOOLS_PKG__ = "tools"
__CONTENT_PKG__ = "agents"
__SKILLS_PKG__ = "skills"
# Curated workspace memory (memory/ at the repo root, routed by path) —
# background context every agent of this workspace receives. Mapped like
# agents/ and skills/ so the wheel ships it and `files()` can resolve it.
__MEMORY_PKG__ = "memory"
__SOLUTION_DIRS__
[tool.setuptools.package-data]
__TOOLS_PKG__ = ["tools.yaml", "mcp.yaml", "deliveries.yaml"]
# Dotfiles need their own pattern: `**/*` does not match `.no_discovery`.
__CONTENT_PKG__ = ["**/*", "**/.no_discovery"]
__SKILLS_PKG__ = ["**/*"]
__MEMORY_PKG__ = ["**/*"]
__SOLUTION_DATA__"""

WS_TOOLS_INIT_FLAT = '''\
"""__TITLE__ workspace — the shared pack (agents, skills, CLI tools).

YOUR FILES ARE THE SOURCE OF TRUTH. The engine resolves agents and skills
from the installed pack, and in an editable install (`pip install -e .`)
`files()` points at THIS SOURCE TREE — so an edit to a SOUL.md or a SKILL.md
is live on the next run or chat, with no build step and nothing to push.

`workspace diff` / `pull` are the review path (what the Studio holds against
this repo), not a prerequisite of testing your own work.

On disk the directories are `agents/`, `skills/`, `tools/`; they install
under unique import names via the pyproject package-dir mapping — the
workspace prefix lives there and nowhere else.
"""

from importlib.resources import files

__version__ = "0.1.0"


def pack():
    from aicore.packs import Pack, content_root, load_deliveries, load_mcp_servers
    return Pack(
        # The WORKSPACE code — every pack in this repo declares the same one.
        workspace="__CODE__",
        agents=files("__CONTENT_PKG__"),
        skills=files("__SKILLS_PKG__"),
        # Curated workspace memory: Markdown under memory/, routed by path,
        # injected into every agent of this workspace as background context.
        # WITHOUT THIS LINE the directory the scaffold creates - and the
        # instructions in memory/workspace/_example.md - do nothing: `memory
        # sync` reports 0 added and says nothing is wrong.
        #
        # `content_root`, not `files()`: memory is OPTIONAL, and `files()`
        # RAISES for a mapped directory that is absent from disk. Every root
        # here is resolved in this one call, so that exception took the
        # agents, skills and tools with it - a client saw
        # "NotADirectoryError: MultiplexedPath only supports directories"
        # and then, further down, "No installed pack provides an agent named
        # 'chat_advisor'". Both from a deleted `memory/`.
        memory=content_root("__MEMORY_PKG__"),
        tools=_cli_tools(),
        # `mcp.yaml` sits beside `tools.yaml` in the packaged tools package.
        # Without this it ships and is never read: the run reports success
        # with no servers attached.
        mcp_servers=load_mcp_servers("__TOOLS_PKG__"),
        # The tools case actions go through HERE - `deliveries.yaml`, beside
        # tools.yaml and mcp.yaml. See `iof-case deliveries`.
        deliveries=load_deliveries("__TOOLS_PKG__"),
    )


def _cli_tools() -> list[dict]:
    import yaml

    f = files("__TOOLS_PKG__") / "tools.yaml"
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except (FileNotFoundError, OSError, yaml.YAMLError):
        return []
    return [t for t in (data.get("tools") or []) if isinstance(t, dict)]
'''

WS_SOLUTION_INIT_FLAT = '''\
"""__SOL__ — a solution of the __CODE__ workspace (workflows only).

Agents, skills and tools come from the workspace's shared pack; this package
exists so the engine can READ THESE WORKFLOW FILES directly. Never grow
agents or skills here — they are workspace-level, shared by every solution.
"""

from importlib.resources import files

__version__ = "0.1.0"


def pack():
    from ioagentfarm.packs import Pack
    return Pack(
        workspace="__CODE__",       # the WORKSPACE code — same for every pack
        solution="__SOL__",         # what the catalog attributes these to
        workflows=files("__SOL_PKG__") / "workflows",
        swarms=files("__SOL_PKG__") / "swarms",
    )
'''


TEST_WORKSPACE_FLAT = '''\
"""The FLAT workspace contract.

Content at the root on the import path; solutions are workflow folders; the
tools package is the only pip-delivered thing. Every assertion corresponds
to a failure that is silent in dev: a manifest that stops loading refuses
`workspace diff`, an unregistered entry point hides tools.yaml from the
resolver, a solutions entry pointing at nothing resolves as nothing.
"""
from __future__ import annotations

import pathlib
import tomllib
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
_DATA = tomllib.loads((REPO / "pyproject.toml").read_text(encoding="utf-8"))


def test_manifest_loads():
    from ioagentfarm.solution_manifest import load_manifest
    m = load_manifest(REPO)
    assert m.agents_roots and m.skills_roots


def test_solutions_map_matches_the_directories():
    from ioagentfarm.solution_manifest import load_manifest
    m = load_manifest(REPO)
    for code, roots in m.solutions.items():
        for r in roots:
            assert r.is_dir(), f"solutions.{code} points at nothing: {r}"


def test_every_content_dir_is_mapped():
    """FLAT ON DISK, MAPPED FOR THE ENGINE. The engine resolves agents,
    skills and workflows from pack sources, so every content dir needs an
    import name — otherwise nothing here is readable from files and no run
    or chat can resolve it. The DIRECTORIES stay flat; only pyproject knows
    the prefixed names."""
    st = _DATA["tool"]["setuptools"]
    mapping = st["package-dir"]
    assert set(st["packages"]) == set(mapping), (
        "every declared package must be mapped to a flat directory")
    dirs = set(mapping.values())
    assert {"tools", "agents", "skills"} <= dirs, (
        f"content dirs missing from package-dir: {dirs}")
    for pkg, d in mapping.items():
        assert (REPO / d).is_dir(), f"{pkg} maps to {d}, which does not exist"


def _declared_packs() -> dict:
    """Every pack this repo declares.

    THERE IS MORE THAN ONE as soon as a solution exists: the workspace pack
    carries agents/skills/tools, and each solution adds its own workflows
    entry point. Nothing here may assume a single entry point -- a test that
    unpacked one was red on every workspace scaffolded with a solution.
    """
    return _DATA["project"]["entry-points"]["aicore.packs"]


def test_the_workspace_is_readable_from_files():
    """The property the flat layout exists for: an editable install lets the
    engine read THIS TREE, so an edit is live without a build step. If this
    fails, the engine has silently stopped reading your files."""
    import importlib
    roots = []
    for slug, target in _declared_packs().items():
        pack = importlib.import_module(target.split(":")[0]).pack()
        if pack.agents is not None:
            roots.append((slug, pathlib.Path(str(pack.agents)).resolve()))
    assert roots, (
        "no declared pack exposes an agents root, so the engine cannot read "
        "this repo's agents from files at all")
    for slug, root in roots:
        assert root == (REPO / "agents").resolve(), (
            f"{slug}'s agents root is {root}, not this repo's agents/ -- is "
            "the install editable? (pip install -e .)")


def test_every_declared_pack_is_importable_and_registered():
    """Declared in pyproject AND visible to the engine are two different
    facts. Entry points are read from installed metadata, so adding a
    solution to pyproject changes nothing until the repo is reinstalled --
    the pack is then invisible with no error anywhere."""
    import importlib
    from importlib.metadata import entry_points

    from ioagentfarm.packs import Pack

    declared = _declared_packs()
    assert declared, "this workspace declares no packs"
    installed = {e.name for e in entry_points(group="aicore.packs")}
    for slug, target in declared.items():
        mod = importlib.import_module(target.split(":")[0])
        assert isinstance(mod.pack(), Pack), (
            f"{slug}: {target} did not return a Pack")
        assert slug in installed, (
            f"entry point {slug!r} is declared in pyproject.toml but not "
            "registered in this venv -- run `pip install -e .` here. (A new "
            "solution or tool adds an entry point, and pip only sees it on "
            "reinstall.)")
'''


def _ws_flat_solutions_block(sols: list[str]) -> str:
    if not sols:
        return ("# No solutions yet — `aicore new-solution <name>` (run "
                "inside this repo)\n# adds solutions/<name>/workflows/ and "
                "lists it here.\nsolutions: {}\n")
    lines = ["# Each solution is a folder of workflows and swarms —",
             "# agents/skills/tools above are workspace-level, shared by",
             "# every solution.",
             "solutions:"]
    for s in sols:
        lines += [f"  {s}:", "    workflows:",
                  f"      - solutions/{s}/workflows",
                  "    swarms:",
                  f"      - solutions/{s}/swarms"]
    return "\n".join(lines) + "\n"


#: The import name a solution's workflows package installs under. The
#: DIRECTORY stays `solutions/<sol>/`; this exists only in pyproject.
#:
#: `<sol>_sol`, matching the `pharma_comm_sol` / `pharma_intel_sol` packages
#: already shipping. The suffix is the point: it says what the package IS at
#: the end of the name, where it is read, rather than burying it mid-string.
#:
#: KNOWN COST, accepted deliberately. Import names are global to a virtual
#: environment, and one engine venv holds every workspace it serves - ten
#: packs in this repo's own today. Two workspaces that each have a solution
#: called `reporting` now both want `reporting_sol`: pip installs one, and
#: the loser's entry point resolves to the winner's package. That failure is
#: SILENT - the pack installs, the catalog is simply someone else's - which
#: is the exact shape `packs.py` calls "installs and is invisible". The
#: family prefix used to make the name unique and no longer does.
#:
#: `detect_collisions()` warns on duplicate CONTENT names across packs, not
#: on two distributions claiming one import name, so nothing catches this
#: today. Where one venv will hold two workspaces, keep the solution names
#: distinct between them, or give the package an explicit name in pyproject.
def _flat_sol_pkg(family: str, sol: str) -> str:
    return f"{sol}_sol"


def _flat_content_marker(path: Path, what: str) -> None:
    """Package marker for a package-dir-mapped CONTENT directory.

    Nothing imports these modules - the engine reads the directory. The file
    exists because setuptools ships packages, not loose folders, and that is
    what makes the content readable from a wheel as well as from the tree.
    """
    _write(path / "__init__.py",
           f'"""{what} — content, package-dir-mapped so the engine can read\n'
           f'it from the source tree (editable install) and from a wheel\n'
           f'(a pod).\n\nNothing imports this module."""\n', {})


def _scaffold_flat_workspace(root: Path, slug: str, human: str,
                             tools_pkg: str, sols: list[str],
                             on_scaffolded=None) -> None:
    """The FLAT workspace: flat on disk, mapped so the engine reads files.

    *on_scaffolded* runs after the files and the commit, BEFORE the summary -
    it is where the tenant is registered, so its lines do not land under the
    "Next" steps as though they were one of them.
    """
    content_pkg = f"{slug}_agents"
    skills_pkg = f"{slug}_skills"
    memory_pkg = f"{slug}_memory"
    sol_pkgs = {x: _flat_sol_pkg(slug, x) for x in sols}
    subs = {
        "__CODE__": slug,
        "__ENVWS__": slug,
        "__DIST__": slug.replace("_", "-") + "-workspace",
        "__TITLE__": human,
        "__TOOLS_PKG__": tools_pkg,
        "__CONTENT_PKG__": content_pkg,
        "__SKILLS_PKG__": skills_pkg,
        "__MEMORY_PKG__": memory_pkg,
        "__SDK_PINS__": "\n".join(sdk_requirements()),
        "__SDK_NAMES__": " + ".join(f"`{n}`" for n in sdk_distribution_names()),
        "__SOLUTIONS_BLOCK__": _ws_flat_solutions_block(sols),
        "__PACKAGES__": ", ".join(
            f'"{p}"' for p in [tools_pkg, content_pkg, skills_pkg, memory_pkg,
                               *sol_pkgs.values()]),
        "__SOLUTION_EPS__": "".join(
            f'{x} = "{p}:pack"\n' for x, p in sol_pkgs.items()),
        "__SOLUTION_DIRS__": "".join(
            f'{p} = "solutions/{x}"\n' for x, p in sol_pkgs.items()),
        "__SOLUTION_DATA__": "".join(
            f'{p} = ["workflows/**/*", "workflows/**/.no_discovery", '
            f'"swarms/**/*"]\n'
            for p in sol_pkgs.values()),
    }

    _write(root / MANIFEST_NAME, WS_MANIFEST_FLAT, subs)
    _write(root / "pyproject.toml", WS_PYPROJECT_FLAT, subs)
    _write(root / "CORABUILD.md", CORABUILD_MD, subs)
    _write(root / ".gitignore", GITIGNORE, subs)
    _write(root / ".env.example", ENV_EXAMPLE, subs)
    _write(root / "tests" / "test_workspace.py", TEST_WORKSPACE_FLAT, subs)

    # MEMORY IS IN THIS LIST, and it was not. `pyproject.toml` maps all
    # THREE onto import names, but only two got a package marker - so
    # `<ws>_memory` was a NAMESPACE package while its siblings were regular
    # ones, and `files()` returns a `MultiplexedPath` for a namespace
    # package. That type RAISES when a portion is missing or is not a
    # directory, with text naming neither: "MultiplexedPath only supports
    # directories". Every root is resolved in one `pack()` call, so the
    # whole pack died - a client following walkthrough 1 lost every agent,
    # skill and tool to it, and was then told by a second message to install
    # a pack they had installed correctly.
    #
    # A marker makes it a regular package, so `files()` returns a plain path
    # and this failure cannot arise. `content_root()` in the template is the
    # belt to this braces, for a tree where the directory is removed later.
    for kind, what in (("agents", "Agent workspaces"), ("skills", "Skills"),
                       ("memory", "Curated workspace memory")):
        (root / kind).mkdir(parents=True, exist_ok=True)
        (root / kind / ".gitkeep").write_text("", encoding="utf-8")
        _flat_content_marker(root / kind, what)
    _write(root / "tools" / "__init__.py", WS_TOOLS_INIT_FLAT, subs)
    _write(root / "tools" / "tools.yaml", TOOLS_YAML,
           {**subs, "__SLUG__": slug, "__PKG__": tools_pkg})
    _write(root / "tools" / "deliveries.yaml", DELIVERIES_YAML, subs)
    _write(root / "memory" / "workspace" / "_example.md", MEMORY_EXAMPLE_MD, subs)
    for x in sols:
        _write_flat_solution_pkg(root, slug, x)


    if on_scaffolded is not None:
        on_scaffolded()

    import sys as _sys
    bin_dir = Path(_sys.executable).resolve().parent
    console.print(f"[bold green]Created[/] {root}  [dim](flat layout)[/]")
    console.print(f"  workspace    : {slug}")
    console.print("  content      : agents/  skills/  solutions/<name>/"
                  "workflows/  [dim]- flat on disk, mapped so the engine "
                  "reads YOUR FILES[/]")
    console.print(f"  tools pack   : tools/  [dim]installs as `{tools_pkg}`[/]")
    if sols:
        console.print(f"  solution     : solutions/{sols[0]}/")
    console.print("\n[bold]Next[/] [dim](this venv)[/]")
    # ONLY WHEN IT IS A MOVE. The scaffold writes into the CURRENT
    # directory, and printing `cd <where you already are>` directly
    # contradicts the guide's "no cd afterwards" paragraph -- and now
    # that the package is named after the slug, an obeyed `cd` lands
    # INSIDE the package, where the next command cannot find
    # pyproject.toml.
    if Path.cwd().resolve() != Path(root).resolve():
        console.print(f"  cd {root}", markup=False)
    console.print(f'  "{bin_dir / "pip"}" install -e ".[dev]"     '
                  "# editable: the engine then reads this tree", markup=False)
    console.print(f'  "{bin_dir / "aicore"}" new-agent <role>'
                  "             # lands in agents/", markup=False)
    if sols:
        console.print(f'  "{bin_dir / "aicore"}" new-workflow <name> '
                      f"--solution {sols[0]}", markup=False)
    else:
        console.print(f'  "{bin_dir / "aicore"}" new-solution <name>'
                      "          # adds solutions/<name>/", markup=False)
    # NOT `workspace create` any more - this command registered the tenant
    # itself. Leaving the line in told the reader to run a command that had
    # already run, which is how the two halves read as unrelated in the
    # first place.
    console.print(f'  "{bin_dir / "aicore"}" run <workflow> --goal "..."'
                  "     # runs from your files - nothing to push",
                  markup=False)
    console.print("[dim]  YOUR FILES ARE THE SOURCE OF TRUTH. An editable "
                  "install makes the engine read this tree, so an edit is "
                  "live on the next run or chat. `workspace attach` / `diff` "
                  "/ `pull` are the review path when the Studio is in "
                  "play; nothing is published by hand.[/]")


def _write_flat_solution_pkg(root: Path, family: str, sol: str) -> None:
    """One solution: workflows + swarms folders the engine reads from files."""
    d = root / "solutions" / sol
    for kind in ("workflows", "swarms"):
        (d / kind).mkdir(parents=True, exist_ok=True)
        (d / kind / ".gitkeep").write_text("", encoding="utf-8")
    _write(d / "__init__.py", WS_SOLUTION_INIT_FLAT,
           {"__CODE__": family, "__ENVWS__": family, "__SOL__": sol,
            "__SOL_PKG__": _flat_sol_pkg(family, sol)})


def _ws_solution_ep(sol: str) -> str:
    return f'{sol} = "{sol}:pack"'


def _ws_solution_data(sol: str) -> str:
    return (f'{sol} = [\n    "workflows/**/*",\n    "swarms/**/*",\n'
            '    "metadata/**/*",\n]')


def _ws_manifest_solutions_block(sols: list[str]) -> str:
    if not sols:
        return _WS_SOLUTIONS_EMPTY
    lines = ["# Each solution names ONLY its workflow and swarm roots —",
             "# agents/skills/tools stay above, shared by the whole family.",
             "solutions:"]
    for s in sols:
        lines += [f"  {s}:", "    workflows:", f"      - {s}/workflows",
                  "    swarms:", f"      - {s}/swarms"]
    return "\n".join(lines) + "\n"


def _would_move_the_database() -> bool:
    """Whether a later `local on` would repoint the database. Pure enough.

    Mirrors ``workspace_env.localise``'s own rule, which is the only thing
    that decides this: local mode leaves a value supplied by the REAL
    environment alone, so only a URL that came from a FILE moves. Already in
    local mode, nothing moves either - the destination is already local.
    """
    import os as _os

    if (_os.getenv("IOF_LOCAL") or "").strip().lower() in {
            "1", "true", "yes", "on"}:
        return False
    try:
        from ioagentfarm.engine import workspace_env as _we
        if "IOF_DATABASE_URL" in _we.REAL_ENV:
            return False
        return bool((_os.getenv("IOF_DATABASE_URL") or "").strip())
    except Exception:                       # noqa: BLE001 - advisory only
        return False


def _register_tenant(slug: str, human: str, register: bool,
                     member: list[str] | None, no_member: bool, yes: bool,
                     title_given: bool = False) -> None:
    """The TENANT half of `new-workspace`. Never fatal to the scaffold.

    The files are on disk by the time this runs, and a database that is
    unreachable, unconfigured or refused must not turn a successful scaffold
    into a failed command - the repo would be left behind by a non-zero exit
    that reads as "nothing happened". So the failure is reported with the one
    command that finishes the job by hand.
    """
    if not register:
        console.print(f"[dim]  tenant not registered (--no-register) - "
                      f"`{_prog()} workspace create {slug}` when you want "
                      "it[/dim]")
        return
    try:
        from ioagentfarm.cli_workspace import ensure_tenant_workspace
        _, existed = ensure_tenant_workspace(
            slug, name=human if title_given else "", member=member,
            no_member=no_member, yes=yes, rename=title_given)
        # THE ORDER MISTAKE, NAMED WHILE IT IS STILL CHEAP TO UNDO. `local
        # on` is documented as step one because it decides which database
        # the next workspace is created in. Run it the other way round and
        # the tenant is registered wherever the ambient URL pointed, and
        # `local on` then repoints - so the workspace created seconds ago
        # stops appearing in `workspace list`, with nothing linking the two.
        # Reproduced: "workspace 'psrev' ready (id=2)", then `local on`,
        # then an EMPTY list. Only worth saying when a row was actually
        # created and the URL came from a file, which is the only shape
        # `localise` can move - an exported one it deliberately leaves
        # alone, and a default local SQLite is already the destination.
        if not existed and _would_move_the_database():
            console.print(
                f"[yellow]  note: `{_prog()} local on` AFTER this would "
                f"repoint the database, and '{slug}' would no longer be "
                "listed - it stays in the one above[/yellow]")
            console.print(f"[dim]  local mode is meant to come FIRST; to "
                          f"move it now: `{_prog()} local on` then "
                          f"`{_prog()} workspace create {slug}`[/dim]")
    except (typer.Abort, typer.Exit):
        # The shared-database confirmation was declined, or membership was
        # rejected. Both already printed why; the repo stands.
        console.print(f"[yellow]  repo scaffolded; tenant '{slug}' NOT "
                      f"registered - `{_prog()} workspace create {slug}` "
                      "when you are ready[/yellow]")
    except Exception as exc:                # noqa: BLE001 - see docstring
        console.print(f"[yellow]  repo scaffolded, but registering the "
                      f"tenant failed ({type(exc).__name__}: "
                      f"{str(exc)[:160]})[/yellow]")
        console.print(f"[dim]  run `{_prog()} workspace create {slug}` once "
                      "the database is reachable[/dim]")


def new_workspace(
    code: str = typer.Argument(
        ..., help="Workspace family code - lowercase, e.g. 'pharma'."),
    layout: str = typer.Option(
        "flat", "--layout",
        help="'flat' (default): content dirs at the repo root on the import "
             "path (agents/, skills/, solutions/<name>/workflows/), tools "
             "the only pip-packaged thing. 'packaged': content inside "
             "wheel-shipped packages - for teams that deliver content as a "
             "built wheel rather than a git checkout installed editable."),
    first_solution: str = typer.Option(
        None, "--first-solution",
        help="Also scaffold the first solution."),
    shared_name: str = typer.Option(
        None, "--shared-name",
        help="Import name of the repo's ONE package - the tools package in "
             "the flat layout (default: <code>_tools), the shared content "
             "package in the packaged layout (default: <code>_shared). It "
             "shares the venv's top-level namespace with the SDK and every "
             "pip dependency, so generic names like 'agents' (the OpenAI "
             "Agents SDK's import name) or 'shared' are refused."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="Where to create the repo (default: the current directory)."),
    title: str = typer.Option(
        None, "--title", help="Human title (default: derived from the code)."),
    force: bool = typer.Option(
        False, "--force", help="Write into a non-empty directory."),
    register: bool = typer.Option(
        True, "--register/--no-register",
        help="Also create-or-reuse the TENANT workspace of the same code and "
             "select it (default). `--no-register` scaffolds only the files - "
             "for a checkout on a machine whose database you do not want to "
             "touch."),
    member: list[str] = typer.Option(
        None, "--member", "-m",
        help="Email to grant access to (repeatable). Defaults to "
             "$IOF_BOOTSTRAP_ADMIN. Only used when the tenant is created."),
    no_member: bool = typer.Option(
        False, "--no-member",
        help="Register the tenant and grant nobody access."),
    yes: bool = typer.Option(
        False, "--yes", "-y",
        help="Skip the confirmation shown when the tenant would be created "
             "in a shared database. Local mode never asks."),
) -> None:
    """Scaffold a WORKSPACE repo AND register the tenant it pairs with.

    One family, many solutions. The shared package carries what every solution
    uses - `new-agent`, `new-skill` and `new-tool` write into it - and each
    solution is a workflows-only package added by `new-solution` (run inside
    this repo). Use plain `new-solution` instead when one solution is the
    whole story; it can grow into this shape later.

    TWO THINGS SHARE THE WORD "WORKSPACE" and a client has to create both:
    the REPO (files) and the TENANT (a registry row and its state). They pair
    by code, nothing said so, and the split cost a live build session - it
    ran `new-workspace ps2` with tenant `ps2` already created and selected,
    because the scaffold consulted the directory and never the registry. So
    this command now does both halves, and `workspace create` remains for the
    tenant on its own.

    RE-RUNNABLE. A directory already holding this workspace's repo is left
    exactly as it is rather than refused, and an existing tenant is reported
    and reused. Running it twice is a no-op that tells you the state - which
    is the property the build agent needed and could not have.

    ORDER MATTERS ONE WAY: `aicore local on` FIRST if you want a local
    workspace. It is recorded against the DIRECTORY and decides which
    database the tenant registered here lands in; afterwards, the tenant has
    already been created wherever the ambient `IOF_DATABASE_URL` pointed.
    """
    slug = code.strip().lower().replace("-", "_")
    if not SLUG_RE.match(slug):
        raise typer.BadParameter(
            f"{code!r} must match ^[a-z][a-z0-9_]{{2,30}}$ — it becomes the "
            "family code and a Python package prefix")
    #: Package names that collide with the ecosystem or read as ambiguous.
    #: The venv is per-workspace, but it still holds the SDK and every pip
    #: dependency — `agents` is the OpenAI Agents SDK's import name.
    _RESERVED_PKG = {"agents", "skills", "workflows", "shared", "tools",
                     "common", "core", "app", "tests", "src",
                     "ioagentfarm", "agentfarm_skills", "iobot", "iobot",
                     # the platform's product name (AI Core Harness) — a
                     # workspace package by this name would read as the SDK's
                     "aicore", "ai_core"}

    if layout not in ("flat", "packaged"):
        raise typer.BadParameter(
            f"--layout must be 'flat' or 'packaged', got {layout!r}")

    default_pkg = f"{slug}_tools" if layout == "flat" else f"{slug}_shared"
    if shared_name:
        shared_pkg = shared_name.strip().lower().replace("-", "_")
        if not SLUG_RE.match(shared_pkg):
            raise typer.BadParameter(
                f"{shared_name!r} must match ^[a-z][a-z0-9_]{{2,30}}$ — it "
                "becomes a Python package name")
        if shared_pkg in _RESERVED_PKG:
            raise typer.BadParameter(
                f"`{shared_pkg}` collides with the ecosystem or reads as a "
                "content dir, not a package — pick something distinctive "
                f"(default: {default_pkg})")
    else:
        shared_pkg = default_pkg

    sol = None
    if first_solution:
        sol = first_solution.strip().lower().replace("-", "_")
        if not SLUG_RE.match(sol):
            raise typer.BadParameter(
                f"{first_solution!r} must match ^[a-z][a-z0-9_]{{2,30}}$")
        if sol == shared_pkg:
            raise typer.BadParameter(
                f"`{sol}` is the shared package's name - pick another")

    human = title or slug.replace("_", " ").title()
    root = Path(directory) if directory else Path.cwd()

    # `.iof` belongs here for the same reason as `.venv`: it is GENERATED
    # ENGINE STATE, never content anybody authored. Leaving it out made the
    # ordinary documented path fail -- `local on` and `workspace create` both
    # create it, so scaffolding after either one refused with "already
    # contains .iof" and demanded --force on a first run in an empty folder.
    # A walkthrough stopped there. `__pycache__` and `.pytest_cache` are the
    # same category and appear as soon as anything has been run.
    _NOT_CONTENT = {".venv", "venv", ".git", ".env", "env.sh", ".gitignore",
                    ".python-version", "state", ".iof", "__pycache__",
                    ".pytest_cache"}
    # ALREADY THIS WORKSPACE'S REPO -> re-run, not a collision. Without this
    # the second call refuses with "already contains pyproject.toml, …", and
    # the honest answer is that there is nothing to do. Note this is the
    # SAME code only: a directory holding a DIFFERENT workspace still trips
    # the guard below, because that is a genuine collision.
    existing_repo = workspace_repo_code(root) if root.exists() else None
    already_scaffolded = existing_repo == slug

    occupied = ([p for p in root.iterdir() if p.name not in _NOT_CONTENT]
                if root.exists() else [])
    if occupied and not force and not already_scaffolded:
        raise typer.BadParameter(
            f"{root} already contains "
            f"{', '.join(sorted(p.name for p in occupied)[:4])}"
            f"{' …' if len(occupied) > 4 else ''} — pass --force to write "
            "into it, or --dir to scaffold somewhere else"
            + (f" (it holds the workspace repo '{existing_repo}', not "
               f"'{slug}')" if existing_repo else ""))

    sols = [sol] if sol else []

    if already_scaffolded:
        console.print(f"[green]Found[/] {root}  [dim](workspace repo "
                      f"'{slug}' is already scaffolded - files "
                      "untouched)[/]")
        if sol:
            console.print(f"[yellow]  --first-solution {sol} ignored - add it "
                          f"with `{_prog()} new-solution {sol}` inside this "
                          "repo[/]")
        _register_tenant(slug, human, register, member, no_member, yes)
        return

    if layout == "flat":
        _scaffold_flat_workspace(
            root, slug, human, shared_pkg, sols,
            on_scaffolded=lambda: _register_tenant(
                slug, human, register, member, no_member, yes,
                title_given=bool(title)))
        return

    subs = {
        "__CODE__": slug,
        # `.env.example` is shared by all three scaffolds and each has its own
        # subs dict, so a token defined for one is silently literal in the
        # others. Pinned by tests/test_scaffold_leaves_no_placeholders.py.
        "__ENVWS__": slug,
        "__DIST__": slug.replace("_", "-") + "-workspace",
        "__TITLE__": human,
        "__SHARED_PKG__": shared_pkg,
        "__SHARED_SLUG__": shared_pkg,
        "__SDK_PINS__": "\n".join(sdk_requirements()),
        "__SDK_NAMES__": " + ".join(f"`{n}`" for n in sdk_distribution_names()),
        "__SOLUTIONS_BLOCK__": _ws_manifest_solutions_block(sols),
        "__SOLUTION_EPS__": "".join(_ws_solution_ep(s) + "\n" for s in sols),
        "__PACKAGES__": ", ".join(f'"{p}"' for p in [shared_pkg, *sols]),
        "__SOLUTION_DATA__": "".join(_ws_solution_data(s) + "\n"
                                     for s in sols),
    }

    _write(root / MANIFEST_NAME, WS_MANIFEST, subs)
    _write(root / "pyproject.toml", WS_PYPROJECT, subs)
    _write(root / "CORABUILD.md", CORABUILD_MD, subs)
    _write(root / ".gitignore", GITIGNORE, subs)
    _write(root / ".env.example", ENV_EXAMPLE, subs)
    _write(root / "tests" / "test_workspace.py", TEST_WORKSPACE, subs)

    p = root / shared_pkg
    _write(p / "__init__.py", WS_SHARED_INIT, subs)
    _write(p / "tools.yaml", TOOLS_YAML,
           {**subs, "__SLUG__": slug, "__PKG__": shared_pkg})
    _write(p / "deliveries.yaml", DELIVERIES_YAML, subs)
    for kind in ("agents", "skills"):
        (p / kind).mkdir(parents=True, exist_ok=True)
        (p / kind / ".gitkeep").write_text("", encoding="utf-8")

    if sol:
        _write_ws_solution_pkg(root, slug, shared_pkg, sol)

    _register_tenant(slug, human, register, member, no_member, yes,
                     title_given=bool(title))

    import sys as _sys
    bin_dir = Path(_sys.executable).resolve().parent
    console.print(f"[bold green]Created[/] {root}")
    console.print(f"  family       : {slug}  [dim](every package returns "
                  f"Pack.name='{slug}')[/]")
    console.print(f"  shared pack  : {shared_pkg}/  [dim]agents + skills + "
                  "tools - no workflows[/]")
    if sol:
        console.print(f"  solution     : {sol}/  [dim]workflows only[/]")
    console.print("\n[bold]Next[/] [dim](this venv - a pack installed in any "
                  "other one is invisible to the engine)[/]")
    # ONLY WHEN IT IS A MOVE. The scaffold writes into the CURRENT
    # directory, and printing `cd <where you already are>` directly
    # contradicts the guide's "no cd afterwards" paragraph -- and now
    # that the package is named after the slug, an obeyed `cd` lands
    # INSIDE the package, where the next command cannot find
    # pyproject.toml.
    if Path.cwd().resolve() != Path(root).resolve():
        console.print(f"  cd {root}", markup=False)
    console.print(f'  "{bin_dir / "pip"}" install -e ".[dev]"', markup=False)
    console.print(f'  "{bin_dir / "pytest"}"                      '
                  "# workspace contract", markup=False)
    console.print(f'  {invocation()} new-agent <role>'
                  "          # lands in the shared pack", markup=False)
    if sol:
        console.print(f'  {invocation()} new-workflow <name> '
                      f"--solution {sol}", markup=False)
    else:
        console.print(f'  {invocation()} new-solution <name>'
                      "        # adds a workflows-only package", markup=False)


def _write_ws_solution_pkg(root: Path, family: str, shared_pkg: str,
                           sol: str) -> None:
    """The workflows-only solution package - shared by new-workspace and the
    workspace-growing path of new-solution."""
    subs = {"__CODE__": family, "__SHARED_PKG__": shared_pkg,
            "__SOL_PKG__": sol, "__SOL__": sol,
            "__SOL_TITLE__": sol.replace("_", " ").title()}
    sp = root / sol
    _write(sp / "__init__.py", WS_SOLUTION_INIT, subs)
    for kind in ("workflows", "swarms"):
        (sp / kind).mkdir(parents=True, exist_ok=True)
        (sp / kind / ".gitkeep").write_text("", encoding="utf-8")


def workspace_repo_code(root: Path) -> str | None:
    """The family code of the workspace repo AT *root*, or None.

    The marker is the same one `_enclosing_workspace` reads - a manifest
    whose ``solutions:`` key is a mapping, which both layouts write as
    ``solutions: {}`` even with no solutions yet, so a freshly scaffolded
    repo is recognised. Unlike that function this does NOT walk up: the
    question here is "is THIS directory already the repo I was asked to
    create", and a parent answering it would make `new-workspace` a silent
    no-op run one level down inside an existing repo.
    """
    import yaml

    f = find_manifest(root)
    if f is None:
        return None
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except (yaml.YAMLError, OSError):
        return None
    if not isinstance(data.get("solutions"), dict):
        return None
    code = data.get("solution")
    return code.strip().lower() if isinstance(code, str) else None


def _enclosing_workspace(start: Path) -> Path | None:
    """The workspace repo *start* is inside, or None.

    A workspace is a manifest whose ``solutions:`` key is a mapping - the
    marker `new-workspace` writes. A classic manifest (no such key) means
    `new-solution` keeps its standalone behavior everywhere, including inside
    repos scaffolded before workspaces existed.
    """
    import yaml

    for d in [start.resolve(), *start.resolve().parents]:
        f = find_manifest(d)
        if f is None:
            continue
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            return None
        return d if isinstance(data.get("solutions"), dict) else None
    return None


def _grow_workspace_solution(root: Path, sol: str, human: str) -> None:
    """`new-solution <name>` inside a workspace repo: add a workflows-only
    package and wire it into pyproject + manifest. All three edits are
    text surgery followed by a parse that proves the entry landed - the same
    rule `new-tool` follows for files it did not write."""
    import tomllib

    import yaml as _yaml

    manifest_path = find_manifest(root) or (root / MANIFEST_NAME)
    data = _yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
    family = str(data.get("solution") or "")
    sols = data.get("solutions") or {}
    if sol in sols:
        raise typer.BadParameter(
            f"this workspace already has a solution `{sol}` — pick another "
            "name, or work in its package directly")

    # FLAT layout: a solution is a workflows folder plus a manifest line —
    # no package, no entry point, no pyproject edit at all. Detected the same
    # way find_pack classifies the repo: the content package IS the root.
    from ioagentfarm.cli_pack import find_pack
    if find_pack(root).pkg_dir == root.resolve():
        _write_flat_solution_pkg(root, family, sol)
        # A solution's workflows must be a MAPPED PACKAGE like the rest of
        # the content, or the engine cannot read them from files and every
        # local test needs `workspace push` first — the DB-first trap the
        # flat layout exists to avoid. Three pyproject edits, each verified
        # by re-parsing, with a printed manual step on any shape we did not
        # write ourselves.
        sol_pkg = _flat_sol_pkg(family, sol)
        py_path = root / "pyproject.toml"
        py_text = py_path.read_text(encoding="utf-8")
        new_py = _append_toml_table_line(
            py_text, _pack_ep_table(py_text),
            f'{sol} = "{sol_pkg}:pack"')
        if new_py is not None:
            from ioagentfarm.cli_pack import _insert_subpackage
            new_py = _insert_subpackage(new_py, sol_pkg)
        if new_py is not None:
            new_py = _append_toml_table_line(
                new_py, "[tool.setuptools.package-dir]",
                f'{sol_pkg} = "solutions/{sol}"')
        if new_py is not None:
            new_py = _append_toml_table_line(
                new_py, "[tool.setuptools.package-data]",
                f'{sol_pkg} = ["workflows/**/*", '
                '"workflows/**/.no_discovery", "swarms/**/*"]')
        py_ok = False
        if new_py is not None:
            try:
                after = tomllib.loads(new_py)
                eps = _declared_pack_eps(after.get("project") or {})
                st = ((after.get("tool") or {}).get("setuptools")) or {}
                py_ok = (eps.get(sol) == f"{sol_pkg}:pack"
                         and sol_pkg in (st.get("packages") or [])
                         and (st.get("package-dir") or {}).get(sol_pkg)
                         == f"solutions/{sol}")
            except tomllib.TOMLDecodeError:
                py_ok = False
        if py_ok:
            py_path.write_text(new_py, encoding="utf-8")
        else:
            console.print("[yellow]  ! pyproject.toml was NOT edited - add "
                          "these yourself, or the engine cannot read this "
                          "solution's workflows from files:[/]")
            console.print(f'    entry-points  ->  {sol} = "{sol_pkg}:pack"',
                          markup=False)
            console.print(f'    packages      ->  "{sol_pkg}"', markup=False)
            console.print(f'    package-dir   ->  {sol_pkg} = '
                          f'"solutions/{sol}"', markup=False)
        entry = (f"  {sol}:\n    workflows:\n"
                 f"      - solutions/{sol}/workflows\n"
                 f"    swarms:\n"
                 f"      - solutions/{sol}/swarms\n")
        m_text = manifest_path.read_text(encoding="utf-8")
        if re.search(r"^solutions:\s*\{\}\s*$", m_text, re.M):
            m_new = re.sub(r"^solutions:\s*\{\}\s*$", "solutions:\n" + entry,
                           m_text, count=1, flags=re.M)
        elif re.search(r"^solutions:\s*$", m_text, re.M):
            m_new = re.sub(r"^(solutions:\s*)$", r"\1" + "\n" + entry, m_text,
                           count=1, flags=re.M)
        else:
            m_new = None
        ok = False
        if m_new is not None:
            try:
                ok = sol in ((_yaml.safe_load(m_new) or {}
                              ).get("solutions") or {})
            except _yaml.YAMLError:
                ok = False
        if ok:
            manifest_path.write_text(m_new, encoding="utf-8")
        else:
            console.print(f"[yellow]  ! {manifest_path.name} was NOT "
                          "edited - add this under `solutions:` yourself:[/]")
            console.print("    " + entry.replace("\n", "\n    ").rstrip(),
                          markup=False)
        import sys as _sys
        bin_dir = Path(_sys.executable).resolve().parent
        console.print(f"[bold green]Added solution[/] solutions/{sol}/ to "
                      f"the `{family}` workspace  [dim]a workflows folder - "
                      "agents, skills and tools stay workspace-level[/]")
        # REINSTALL REQUIRED, and nothing else will ever say so. A solution
        # adds an `aicore.packs` entry point, and entry points are read
        # from INSTALLED metadata: until pip re-registers them the engine
        # iterates the group, does not find this solution, and reports an
        # empty catalog with no error to explain it. The previous message
        # said "no packaging involved" and sent the reader to new-workflow,
        # so the workflow was written, invisible, and blamed on the engine.
        # Same rule and same wording as `new-tool`, whose entry point has
        # exactly this problem.
        if sol not in _installed_pack_names():
            console.print(
                f"\n[yellow]REINSTALL REQUIRED - `{sol}` is declared in "
                "pyproject.toml but not registered in this venv. Entry "
                "points are read from installed metadata, so until you "
                "reinstall, the engine lists NO workflows from this "
                "solution and says nothing about why.[/]")
        console.print("\n[bold]Next[/]")
        console.print(f'  "{bin_dir / "pip"}" install -e ".[dev]"'
                      "          # registers the new entry point",
                      markup=False)
        console.print(f'  {invocation()} new-workflow '
                      f"{sol}_report --solution {sol}", markup=False)
        return

    # The shared package: the pyproject's first entry point whose package is
    # not a declared solution.
    py_path = root / "pyproject.toml"
    py_text = py_path.read_text(encoding="utf-8")
    try:
        pydata = tomllib.loads(py_text)
    except tomllib.TOMLDecodeError:
        raise typer.BadParameter(f"{py_path} is not valid TOML")
    eps = _declared_pack_eps(pydata.get("project") or {})
    shared_pkg = next(
        (str(t).split(":", 1)[0] for s, t in eps.items()
         if str(t).split(":", 1)[0] not in sols), f"{family}_shared")
    if sol in {str(t).split(":", 1)[0] for t in eps.values()}:
        raise typer.BadParameter(
            f"pyproject already declares a package `{sol}`")

    # 1. the package
    _write_ws_solution_pkg(root, family, shared_pkg, sol)

    # 2. pyproject: entry point + packages list + package-data table
    new_text = _append_toml_table_line(
        py_text, _pack_ep_table(py_text),
        _ws_solution_ep(sol))
    if new_text is not None:
        from ioagentfarm.cli_pack import _insert_subpackage
        new_text = _insert_subpackage(new_text, sol)
    if new_text is not None:
        new_text = _append_toml_table_line(
            new_text, "[tool.setuptools.package-data]",
            _ws_solution_data(sol))
    ok = False
    if new_text is not None:
        try:
            after = tomllib.loads(new_text)
            a_eps = _declared_pack_eps(after.get("project") or {})
            pkgs = (((after.get("tool") or {}).get("setuptools")) or {}
                    ).get("packages") or []
            ok = a_eps.get(sol) == f"{sol}:pack" and sol in pkgs
        except tomllib.TOMLDecodeError:
            ok = False
    if ok:
        py_path.write_text(new_text, encoding="utf-8")
    else:
        console.print("[yellow]  ! pyproject.toml was NOT edited - add these "
                      "yourself:[/]")
        console.print(f'    {_pack_ep_table(py_text)}  ->  '
                      f"{_ws_solution_ep(sol)}", markup=False)
        console.print(f'    [tool.setuptools] packages  ->  "{sol}"',
                      markup=False)
        console.print(f"    [tool.setuptools.package-data]  ->  {sol} = "
                      '["workflows/**/*", "metadata/**/*"]', markup=False)

    # 3. the manifest's solutions: entry
    m_text = manifest_path.read_text(encoding="utf-8")
    entry = (f"  {sol}:\n    workflows:\n      - {sol}/workflows\n"
             f"    swarms:\n      - {sol}/swarms\n")
    if re.search(r"^solutions:\s*\{\}\s*$", m_text, re.M):
        m_new = re.sub(r"^solutions:\s*\{\}\s*$", "solutions:\n" + entry,
                       m_text, count=1, flags=re.M)
    elif re.search(r"^solutions:\s*$", m_text, re.M):
        m_new = re.sub(r"^(solutions:\s*)$", r"\1" + "\n" + entry, m_text,
                       count=1, flags=re.M)
    else:
        m_new = None
    m_ok = False
    if m_new is not None:
        try:
            m_after = _yaml.safe_load(m_new) or {}
            m_ok = sol in (m_after.get("solutions") or {})
        except _yaml.YAMLError:
            m_ok = False
    if m_ok:
        manifest_path.write_text(m_new, encoding="utf-8")
    else:
        console.print(f"[yellow]  ! {manifest_path.name} was NOT edited - "
                      "add this under `solutions:` yourself:[/]")
        console.print("    " + entry.replace("\n", "\n    ").rstrip(),
                      markup=False)

    import sys as _sys
    bin_dir = Path(_sys.executable).resolve().parent
    console.print(f"[bold green]Added solution[/] {sol}/ to the "
                  f"`{family}` workspace  [dim]workflows only - agents, "
                  "skills and tools stay in the shared pack[/]")
    console.print("\n[bold]Next[/]")
    console.print(f'  "{bin_dir / "pip"}" install -e ".[dev]"   '
                  "# the new entry point needs a reinstall", markup=False)
    console.print(f'  {invocation()} new-workflow '
                  f"{sol}_report --solution {sol}", markup=False)


def _append_toml_table_line(text: str, header: str, line: str) -> str | None:
    """Insert *line* after the last KEY of the TOML table *header* opens.

    AFTER THE LAST KEY, not before the next ``[``. Scanning to the next real
    table put the entry beyond any COMMENTED-OUT header in between - and this
    scaffold ships one (``# [project.scripts]``). ``new-tool`` later
    uncomments it, which silently swallowed the line into the wrong table:
    a solution's entry point became a console script, valid TOML that means
    something else entirely.

    Only the shapes this scaffold writes are handled; anything else returns
    None and becomes a printed manual step.
    """
    key_re = re.compile(r"""^\s*(?:[A-Za-z0-9_.-]+|"[^"]*"|'[^']*')\s*=""")
    lines = text.splitlines(keepends=True)
    for i, raw in enumerate(lines):
        if raw.strip() != header:
            continue
        j = last_key = i + 1
        while j < len(lines):
            cur = lines[j]
            # A table header ends this table — but only at depth 0, since a
            # multi-line array's continuation lines legitimately start with
            # '[' and its ELEMENTS are quoted strings, not headers.
            if cur.lstrip().startswith("[") and key_re.match(cur) is None \
                    and cur.strip().endswith("]") and "=" not in cur:
                break
            if cur.lstrip().startswith("[") and "=" not in cur:
                break
            if key_re.match(cur):
                # a value may span lines: consume until brackets balance,
                # or the insert lands INSIDE the array and corrupts it
                depth = cur.count("[") - cur.count("]")
                while depth > 0 and j + 1 < len(lines):
                    j += 1
                    depth += lines[j].count("[") - lines[j].count("]")
                last_key = j + 1
            j += 1
        lines.insert(last_key,
                     line + ("\n" if not line.endswith("\n") else ""))
        return "".join(lines)
    return None


def _retired_new_workspace(
    ctx: typer.Context,
    args: list[str] = typer.Argument(None, hidden=True),
) -> None:
    """Retired spelling of `aicore workspace scaffold`.

    HIDDEN AND LOUD, which is the pattern this CLI already uses for a
    retired option: click renders an unknown command as a typo and suggests
    the nearest match, which reads as "you mis-typed" rather than "this
    moved", and the nearest match to `new-workspace` is `new-workflow` -
    a different command that would happily run.

    It moved because it was the one `new-*` command that touches the
    REGISTRY. Every other one writes files into a pack you are already in;
    this creates the container and registers a tenant, which is what the
    `workspace` sub-app is for - `workspace attach` already binds a repo,
    so that sub-app was never purely database operations.
    """
    rest = " ".join(ctx.args or list(args or []))
    console.print("[red]`aicore new-workspace` has moved to "
                  "`aicore workspace scaffold`.[/red]")
    console.print(f"[dim]  run: aicore workspace scaffold "
                  f"{rest}[/dim]".rstrip())
    console.print("[dim]  it takes the same arguments and does the same "
                  "two things - scaffolds the repo and registers the "
                  "tenant. `aicore workspace create` remains the tenant on "
                  "its own.[/dim]")
    raise typer.Exit(code=2)


def register(app: typer.Typer) -> None:
    app.command("new-solution")(new_solution)
    # THE SCAFFOLD LIVES WITH THE OTHER WORKSPACE VERBS. The line is not
    # files-versus-database - `new-solution` writes files and stays here -
    # it is whether the command touches the REGISTRY. This one does, and
    # was the only `new-*` that did.
    from ioagentfarm.cli_workspace import workspace_app
    workspace_app.command("scaffold")(new_workspace)
    app.command("new-workspace", hidden=True,
                context_settings={"ignore_unknown_options": True,
                                  "allow_extra_args": True})(
        _retired_new_workspace)
