"""Studio-created agents as a first-class engine pack (core built-in).

The Studio UI writes agent workspaces to ``~/.iobot/agents/<role>/workspace``
(the engine's *installed homes*). The engine, however, seeds workflow team
roles from *pack agent templates* (``load_registry().agent_sources()``), so a
Studio-created agent was historically not schedulable as a workflow role
(``ensure_agent_workspace`` raised ``FileNotFoundError``). The Studio API
mirrors every created/edited agent workspace into ``<IOF_ROOT>/studio/agents``;
this module contributes that directory as an agent-template source, so any
fresh engine process (run, run-step, dry-run validation) resolves the role
like any pack-bundled agent.

History: this began life as the separate ``agentfarm-studio-pack`` wheel
(apps/agentfarm-studio-pack) — authored through the public ``aicore.packs``
seam as the proof that content plugs in with zero core edits. It moved into
core because its function is platform (the engine consuming the platform's own
state directory), its only dependency was core, and as a separate wheel it was
one more artifact an SDK deployment could silently forget — the capability
simply vanishing with no error. The ``_template`` solution remains the
canonical example of the pack seam; this is not it.

Discovery is read-only by design: ``pack()`` contributes the directory only
when it exists and NEVER creates it. The old pack ``mkdir``-ed during
discovery, which meant a pure registry enumeration mutated the state dir —
that side effect is what armed the ``_recover_iof_root()`` editable-install
heuristic against an explicitly configured ``IOF_ROOT`` (see __init__.py).
The directory is created by the Studio API's mirror path, where the write
belongs.
"""
from __future__ import annotations

import os
from pathlib import Path


def studio_agents_root() -> Path:
    """The Studio agent-template root, resolved from the environment.

    ``AGENTFARM_STUDIO_AGENTS_DIR`` overrides; default is
    ``<IOF_ROOT>/studio/agents`` (IOF_ROOT defaulting to ``.iof`` exactly like
    the engine does). Resolved at call time so each engine subprocess honors
    the environment it was spawned with.
    """
    override = (os.getenv("AGENTFARM_STUDIO_AGENTS_DIR") or "").strip()
    if override:
        return Path(override).resolve()
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve() / "studio" / "agents"


def pack():
    """Entry point for the ``aicore.packs`` group.

    Contributes the studio agents directory only when it already exists —
    discovery observes, it does not mutate (see module docstring).
    """
    from ioagentfarm.packs import Pack

    root = studio_agents_root()
    if root.is_dir():
        return Pack(workspace="studio-agents", pack="studio-agents",
                    agents=root)
    return Pack(workspace="studio-agents", pack="studio-agents")
