"""`aicore drafts` — the DESKTOP half of draft promotion.

This module owns the CLI over :mod:`ioagentfarm.engine.drafts`: listing,
inspecting and diffing an author's content drafts against the INSTALLED pack
on this box, writing a draft's files into a checkout (`apply`), and migrating
the legacy studio-authored tenant rows into drafts (`migrate`). It owns no
draft logic of its own — the record, the overlay algebra and staleness live in
``engine/drafts.py``; the disk writer in ``engine/draft_files.py``; the
checkout layout in ``cli_pack.find_pack``. Nothing here is imported by the
Studio API.

Why a CLI is the promotion path at all: organisational policy is that the
ENGINE NEVER HAS GIT ACCESS, so the platform cannot open the pull request. A
draft becomes real content when a developer, in a checkout on their own
machine, runs ``aicore drafts apply <id>`` — the files land at the item's
pack-relative path, and the developer reviews, commits and opens the PR
themselves. This command never runs ``git commit`` or ``git push``; the only
git it touches is read-only (``status --porcelain`` to protect uncommitted
work, ``remote get-url`` to warn when the checkout is not the workspace's
attached repository).

Command discipline, same as the rest of the CLI:

* every command prints the context line first (workspace / db / content);
* READS (`list`, `show`, `diff`) may take ``--workspace``; WRITES (`apply`,
  `migrate`) act on the ACTIVE workspace and REFUSE a mismatched
  ``--workspace`` (``cli._workspace_code(write=True)`` — activation is the one
  way to choose the tenant a write goes to);
* console output is ASCII ONLY. Rich RAISES ``UnicodeEncodeError`` on a legacy
  Windows code page rather than substituting, so one glyph crashes the command
  after its work is done. Data rows and diffs go through ``typer.echo``
  besides — model- and file-derived text must not be parsed as Rich markup.
"""
from __future__ import annotations

import getpass
import socket
import subprocess
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from ioagentfarm.engine import drafts as D

drafts_app = typer.Typer(
    name="drafts",
    help="Content drafts: list, diff, apply into a checkout, migrate legacy rows.",
    no_args_is_help=True,
)

_console = Console()

#: Machine-generated files a legacy row may carry that must never travel into
#: a draft: `.studio-created` is the old tier's marker (and the migration
#: selector), `.skills-assigned.json` is per-host assignment state, AGENTS.md
#: is generated per host. Applying any of them into a checkout would commit
#: state that no repository is supposed to hold.
_GENERATED_KEYS = frozenset({".studio-created", ".skills-assigned.json",
                             "AGENTS.md"})

_MIGRATE_AUTHOR = "studio-migrated@local"


# ---------------------------------------------------------------------------
# shared plumbing
# ---------------------------------------------------------------------------

def _cli():
    """The main CLI module, imported at CALL time.

    ``cli.py`` imports this module while it is itself half-initialised, so a
    module-level ``from ioagentfarm.cli import ...`` here is a circular
    import. By the time a command body runs, ``cli`` is fully loaded.
    """
    from ioagentfarm import cli
    return cli


def _context(ws: str | None) -> None:
    cli = _cli()
    _console.print(cli.context_line(ws or None), soft_wrap=True)


def _store():
    cli = _cli()
    return cli._store(cli._root())


def _draft_store():
    return D.DraftStore(_store())


def _fail(message: str) -> None:
    typer.secho(message, err=True, fg=typer.colors.RED)
    raise typer.Exit(1)


def _check_kind(kind: str | None) -> str | None:
    if kind and kind not in D.KINDS:
        # The legal set is interpolated live, never restated: a stale list in
        # an error message teaches the caller a vocabulary the code no longer
        # accepts.
        raise typer.BadParameter(
            f"kind must be one of {', '.join(D.KINDS)}; got {kind!r}")
    return kind


def _get_draft_or_fail(draft_id: int) -> dict:
    d = _draft_store().get(draft_id)
    if d is None:
        _fail(f"no draft with id {draft_id}. `{_cli().prog()} drafts list` "
              "shows what exists in the active workspace.")
    return d


# ---------------------------------------------------------------------------
# the installed base — the bytes this machine would actually run
# ---------------------------------------------------------------------------

def _installed_item(kind: str, name: str,
                    workspace_code: str,
                    stamps: list | None = None) -> tuple[Path | None, dict, str]:
    """(dir, files, rendered stamp) of one item in the INSTALLED packs.

    Resolved through ``web/catalog.py`` — the same reader the engine's
    catalog API serves the Studio from, so `diff` and `stale` here answer
    about the identical bytes, not a second opinion. ``(None, {}, '')`` when
    no installed pack provides the name: the new-item case, where the draft
    has no base to be stale against.
    """
    from ioagentfarm.web import catalog as cat
    items = cat.stamps() if stamps is None else stamps
    entry_dir: Path | None = None
    if kind == "agent":
        for a in cat.pack_agents():
            if a["role"] == name:
                entry_dir = a["ws"]
                break
    elif kind == "skill":
        # pack_skills lists pack-level sources first, agent-local after —
        # first hit is the resolution order the catalog itself answers with.
        for s in cat.pack_skills():
            if s["name"] == name:
                entry_dir = s["dir"]
                break
    elif kind == "workflow":
        for w in cat.pack_workflows(workspace_code):
            if w["name"] == name:
                entry_dir = w["dir"]
                break
    if entry_dir is None:
        return None, {}, ""
    return (entry_dir, cat.read_tree(entry_dir),
            cat.render_stamp(entry_dir, items))


def _state_word(draft: dict, workspace_code: str,
                cache: dict | None = None,
                stamps: list | None = None) -> tuple[str, dict]:
    """One ASCII word for a draft's relationship to the running base.

    Returns ``(word, staleness_dict)``; *cache* keyed ``(kind, name)`` keeps a
    listing from re-reading one pack tree per draft row.
    """
    key = (draft["kind"], draft["name"])
    if cache is not None and key in cache:
        _dir, files, stamp = cache[key]
    else:
        _dir, files, stamp = _installed_item(
            draft["kind"], draft["name"], workspace_code, stamps)
        if cache is not None:
            cache[key] = (_dir, files, stamp)
    st = D.staleness(draft, stamp or None, files)
    if st["promoted"]:
        return "promoted", st
    if st["stale"]:
        return "stale", st
    return "-", st


# ---------------------------------------------------------------------------
# list / show / diff (reads)
# ---------------------------------------------------------------------------

@drafts_app.command("list")
def list_cmd(
    all_statuses: bool = typer.Option(
        False, "--all",
        help="Include promoted and discarded drafts (default: draft, applied)."),
    author: str = typer.Option(
        None, "--author", help="Only this author's drafts."),
    kind: str = typer.Option(
        None, "--kind", help="agent | skill | workflow."),
    workspace: str = typer.Option(
        None, "--workspace",
        help="Tenant workspace code (default: the active workspace)."),
) -> None:
    """List content drafts, with staleness computed against the installed pack."""
    cli = _cli()
    ws = cli._workspace_code(workspace, required=True)
    _context(ws)
    _check_kind(kind)
    rows = _draft_store().list(
        ws, author=author, kind=kind,
        statuses=None if all_statuses else D.OPEN_STATUSES)
    if not rows:
        scope = "any status" if all_statuses else "status draft or applied"
        typer.echo(f"no drafts in workspace '{ws}' ({scope})."
                   + ("" if all_statuses else " --all includes promoted "
                      "and discarded ones."))
        return
    from ioagentfarm.web import catalog as cat
    try:
        items = cat.stamps()
    except Exception:  # noqa: BLE001 - a stamp scan must not hide the listing
        items = []
    cache: dict = {}
    header = (f"{'id':>4}  {'kind':<8} {'name':<28} {'author':<28} "
              f"{'status':<9} {'stale':<9} updated")
    typer.echo(header)
    typer.echo("-" * len(header))
    for r in rows:
        word, _ = _state_word(r, ws, cache, items)
        typer.echo(
            f"{r['id']:>4}  {r['kind']:<8} {r['name']:<28} "
            f"{(r['author'] or '')[:28]:<28} {r['status']:<9} {word:<9} "
            f"{(r['updated_at'] or '')[:19]}")
    typer.echo(f"\n{len(rows)} draft(s). Inspect one: "
               f"{cli.prog()} drafts show <id>")


@drafts_app.command("show")
def show_cmd(
    draft_id: int = typer.Argument(..., help="Draft id from `drafts list`."),
    workspace: str = typer.Option(
        None, "--workspace",
        help="Tenant workspace code (default: the active workspace)."),
) -> None:
    """One draft's record: the files it touches, its base pin, its state."""
    cli = _cli()
    ws = cli._workspace_code(workspace, required=False)
    _context(ws)
    d = _get_draft_or_fail(draft_id)
    if ws and d["workspace_code"] != ws:
        typer.secho(
            f"note: draft {draft_id} belongs to workspace "
            f"'{d['workspace_code']}', not '{ws}'.", err=True,
            fg=typer.colors.YELLOW)
    word, st = _state_word(d, d["workspace_code"])
    typer.echo(f"draft {d['id']}: {d['kind']} {d['name']}")
    typer.echo(f"  author    : {d['author']}")
    typer.echo(f"  status    : {d['status']}")
    if d.get("note"):
        typer.echo(f"  note      : {d['note']}")
    typer.echo(f"  created   : {d['created_at']}")
    typer.echo(f"  updated   : {d['updated_at']}")
    if d.get("applied_at"):
        typer.echo(f"  applied   : {d['applied_at']} by {d['applied_by']} "
                   f"on {d['applied_host']}")
    if d.get("promoted_at"):
        typer.echo(f"  promoted  : {d['promoted_at']} {d.get('promoted_ref') or ''}".rstrip())
    typer.echo(f"  base stamp: {d['base_stamp'] or '(new item - no base)'}")
    typer.echo(f"  state     : {'current' if word == '-' else word}")
    if st["conflicts"]:
        typer.echo("  conflicts : " + ", ".join(st["conflicts"]))
    files = d["files"]
    paths = D.touched_paths(files)
    typer.echo(f"  files ({len(paths)}):")
    for p in paths:
        marker = "delete" if files.get(p) is None else "write "
        typer.echo(f"    {marker} {p}")
    carried = D.carried_skills(files)
    if carried is not None:
        typer.echo("  carriage  : skills = [" + ", ".join(carried) + "]")
    typer.echo(f"\nNext: {cli.prog()} drafts diff {d['id']}   |   "
               f"{cli.prog()} drafts apply {d['id']}")


@drafts_app.command("diff")
def diff_cmd(
    draft_id: int = typer.Argument(..., help="Draft id from `drafts list`."),
    workspace: str = typer.Option(
        None, "--workspace",
        help="Tenant workspace code (default: the active workspace)."),
) -> None:
    """Per-file unified diffs between the INSTALLED base and the draft.

    The base side is what this machine's packs contain right now - the same
    bytes a run here would resolve - not the base the draft was pinned to.
    A stale pin is called out so the reader knows the left side moved.
    """
    cli = _cli()
    ws = cli._workspace_code(workspace, required=False)
    _context(ws)
    d = _get_draft_or_fail(draft_id)
    _dir, base_files, stamp = _installed_item(
        d["kind"], d["name"], d["workspace_code"])
    st = D.staleness(d, stamp or None, base_files)
    typer.echo(f"draft {d['id']}: {d['kind']} {d['name']} by {d['author']}")
    typer.echo(f"base: {stamp or '(no installed pack provides this item)'}")
    if st["stale"]:
        typer.echo(f"note: STALE - the draft was pinned to "
                   f"'{d['base_stamp']}' and the installed base has moved."
                   + (" Conflicting paths: " + ", ".join(st["conflicts"])
                      if st["conflicts"] else ""))
    effective = D.overlay(base_files, d["files"])
    diffs = D.diff_files(base_files, effective)
    if not diffs:
        typer.echo("no differences - the installed base already equals "
                   "this draft.")
        return
    for entry in diffs:
        typer.echo(f"\n{entry['change']}: {entry['path']}")
        typer.echo(entry["diff"].rstrip("\n"))


# ---------------------------------------------------------------------------
# apply (WRITE) — files into the checkout, review stays with the developer
# ---------------------------------------------------------------------------

def _target_dir(pack, kind: str, name: str, solution: str | None) -> Path:
    """Where this item lives in the checkout — the same placement the
    ``new-agent`` / ``new-skill`` / ``new-workflow`` scaffolds decide.

    Agents and skills are FAMILY-level (the shared content package); a skill
    already carried agent-local is applied agent-local, because assignment is
    BY LOCATION and moving it to pack level would silently change who holds
    it. Workflows are SOLUTION-level: an existing directory wins, else the
    same resolver ``new-workflow`` uses (``--solution`` when ambiguous).
    """
    if kind == "agent":
        content = pack.for_content("an agent")
        return content.agents / name / "workspace"
    if kind == "skill":
        content = pack.for_content("a skill")
        pack_level = content.skills / name
        if pack_level.is_dir():
            return pack_level
        local = [content.agents / r / "workspace" / "skills" / name
                 for r in content.agent_roles()
                 if (content.agents / r / "workspace" / "skills" / name).is_dir()]
        if len(local) == 1:
            return local[0]
        if len(local) > 1:
            raise typer.BadParameter(
                f"skill '{name}' exists agent-local in more than one agent:\n"
                + "\n".join(f"  {pack.rel(p)}" for p in local)
                + "\nApply it by hand - this command cannot know which copy "
                "the draft edits.")
        return pack_level                      # a new skill lands pack-level
    if kind == "workflow":
        existing = [p.pkg_dir / "workflows" / name for p in pack.packages
                    if (p.pkg_dir / "workflows" / name).is_dir()]
        if existing:
            return existing[0]
        return pack.workflow_package(solution).pkg_dir / "workflows" / name
    raise typer.BadParameter(f"unknown draft kind {kind!r}")


def _git(repo_root: Path, *args: str) -> subprocess.CompletedProcess | None:
    """Run one read-only git command; ``None`` when git itself is unusable."""
    try:
        return subprocess.run(
            ["git", *args], cwd=str(repo_root), capture_output=True,
            text=True, timeout=30, encoding="utf-8", errors="replace")
    except (OSError, subprocess.TimeoutExpired):
        return None


def _refuse_dirty_target(repo_root: Path, target: Path, force: bool) -> None:
    """Fail closed on uncommitted changes under the target path.

    ``apply`` overwrites files; a developer's half-finished edit under the
    same path would be destroyed with nothing to recover it from. ``git
    status --porcelain`` is the arbiter; when git cannot answer (no binary,
    not a repository) the same fail-closed rule applies — we cannot PROVE the
    target is clean, so ``--force`` is the developer saying they checked.
    """
    try:
        rel = target.resolve().relative_to(repo_root.resolve()).as_posix()
    except ValueError:                         # pragma: no cover - defensive
        rel = str(target)
    res = _git(repo_root, "status", "--porcelain", "--", rel)
    if res is None or res.returncode != 0:
        if force:
            return
        why = ("git is not available on this machine"
               if res is None else
               f"git cannot answer here: {(res.stderr or '').strip()}")
        _fail(f"cannot verify the target is clean - {why}.\n"
              "Re-run with --force once you have checked "
              f"{rel} for uncommitted work yourself.")
    if res.stdout.strip():
        if force:
            typer.secho(
                f"warning: overwriting uncommitted changes under {rel} "
                "(--force).", err=True, fg=typer.colors.YELLOW)
            return
        _fail(f"the target has uncommitted changes:\n{res.stdout.rstrip()}\n"
              "Commit or stash them first, or pass --force to overwrite.")


def _warn_wrong_origin(repo_root: Path, workspace_code: str) -> None:
    """Warn when this checkout's `origin` is not the workspace's attached repo.

    The attached repository (``studio_workspace_repos``) is the promotion
    target the Studio names to authors; applying into a checkout of some
    other repository silently makes that concept decorative — the PR lands
    where nothing is watching for it.
    """
    try:
        from ioagentfarm.workspace_sync import get_repo
        row = get_repo(workspace_code)
    except Exception:  # noqa: BLE001 - a repo lookup failure must not block apply
        row = None
    if not row or not (row.get("repo_url") or "").strip():
        typer.secho(
            f"note: workspace '{workspace_code}' has no attached repository, "
            "so this checkout cannot be checked against the promotion "
            "target.", err=True, fg=typer.colors.YELLOW)
        return
    attached = row["repo_url"].strip()
    res = _git(repo_root, "remote", "get-url", "origin")
    if res is None or res.returncode != 0:
        return                    # the dirty-tree gate already reported git
    origin = res.stdout.strip()

    def _norm(url: str) -> str:
        return url.rstrip("/").removesuffix(".git").lower()

    if origin and _norm(origin) != _norm(attached):
        typer.secho(
            f"warning: this checkout's origin is\n    {origin}\n"
            f"but workspace '{workspace_code}' is attached to\n"
            f"    {attached}\n"
            "A PR from here will not land in the workspace's promotion "
            "target.", err=True, fg=typer.colors.YELLOW)


@drafts_app.command("apply")
def apply_cmd(
    draft_id: int = typer.Argument(..., help="Draft id from `drafts list`."),
    force: bool = typer.Option(
        False, "--force",
        help="Overwrite uncommitted changes under the target (or proceed "
             "when git cannot verify the target is clean)."),
    solution: str = typer.Option(
        None, "--solution",
        help="For a NEW workflow in a multi-solution workspace repo: which "
             "solution it belongs to."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The checkout (default: the current directory)."),
    workspace: str = typer.Option(
        None, "--workspace",
        help="Must match the active workspace - apply is a write."),
) -> None:
    """WRITE a draft's files into the checkout at the item's pack path.

    The developer then reviews, commits and opens the PR - this command
    never commits or pushes (the platform has no git authority; a person
    does).
    """
    cli = _cli()
    ws = cli._workspace_code(workspace, required=True, write=True)
    _context(ws)
    d = _get_draft_or_fail(draft_id)
    if d["workspace_code"] != ws:
        _fail(f"draft {draft_id} belongs to workspace "
              f"'{d['workspace_code']}'; the active workspace is '{ws}'. "
              f"Run `{cli.prog()} workspace use {d['workspace_code']}` first.")
    if d["status"] == "discarded":
        _fail(f"draft {draft_id} is discarded - there is nothing to apply.")
    if d["status"] == "promoted":
        typer.secho(
            f"note: draft {draft_id} already reads promoted (the installed "
            "base equals it); applying again is harmless but should be a "
            "no-op diff.", err=True, fg=typer.colors.YELLOW)

    from ioagentfarm.cli_pack import find_pack
    pack = find_pack(directory)
    target = _target_dir(pack, d["kind"], d["name"], solution)

    _refuse_dirty_target(pack.root, target, force)
    _warn_wrong_origin(pack.root, ws)

    from ioagentfarm.engine.draft_files import apply_overlay
    target.mkdir(parents=True, exist_ok=True)
    touched = apply_overlay(target, d["files"])

    rel = pack.rel(target)
    typer.echo(f"applied draft {draft_id} ({d['kind']} {d['name']} "
               f"by {d['author']}) into {rel}")
    for p in touched:
        word = "deleted" if d["files"].get(p) is None else "wrote  "
        typer.echo(f"  {word} {rel}/{p}")
    if not touched:
        typer.echo("  (no file changes - the overlay touches no files)")
    carried = D.carried_skills(d["files"])
    if carried is not None:
        # Carriage travels in the overlay but is not a file: in a repo,
        # carriage is BY LOCATION (agent-local skill dirs), so it cannot be
        # written mechanically without moving skills between packages.
        typer.echo("  note: the draft also declares skill carriage "
                   f"[{', '.join(carried)}] - place agent-local copies (or "
                   "remove them) by hand and include that in the same commit.")

    updated = _draft_store().set_status(
        draft_id, "applied",
        applied_by=getpass.getuser(), applied_host=socket.gethostname())
    typer.echo(f"draft {draft_id} marked applied "
               f"({updated['applied_by']}@{updated['applied_host']}).")

    typer.echo("\nNext steps - review and promote "
               "(this platform never commits or pushes):")
    typer.echo("  git diff                    # review what the draft changed")
    typer.echo(f"  git add {rel}")
    typer.echo("  git commit                  # your commit, your name")
    typer.echo("  open a pull request; after merge + deploy the draft reads "
               "promoted on its own.")


# ---------------------------------------------------------------------------
# migrate (WRITE) — legacy studio-authored rows become drafts
# ---------------------------------------------------------------------------

def _decode_files(raw_files: dict, skipped: list[str]) -> dict:
    """A legacy ``files_json`` map as a draft overlay: text only, generated
    files dropped. Binary payloads (the filecodec sentinel) are SKIPPED and
    named — a draft overlay is text by contract (``normalise_files``), and
    silently dropping a file is the failure mode this whole model replaces."""
    from ioagentfarm.engine import filecodec
    out: dict = {}
    for rel, value in (raw_files or {}).items():
        if rel in _GENERATED_KEYS:
            continue
        if not isinstance(value, str):
            skipped.append(rel)
            continue
        if filecodec.is_binary(value):
            skipped.append(rel)
            continue
        out[rel] = value
    return out


def _legacy_rows(store, workspace_code: str) -> list[dict]:
    """Every legacy studio-authored row, as ``{kind, name, files, updated_at}``.

    Selection is exactly the tier the Studio used to write: agent rows whose
    ``files_json`` carries the ``.studio-created`` marker, skills with
    ``origin='studio'``, workflow defs with ``source='studio'``. A missing
    table means this database never had that tier — zero rows, not an error.
    Repo-imported and pack-synced rows are NOT drafts and are left alone.
    """
    import json

    is_pg = store._db.placeholder() == "%s"

    def _q(sql: str) -> str:
        return sql.replace("?", "%s") if is_pg else sql

    def _query(sql: str) -> list[dict]:
        # One connection per table: on PostgreSQL an error aborts the
        # transaction, and a missing table must not poison the next query.
        try:
            with store._conn() as con:
                store._db.init_connection(con)
                cur = con.cursor()
                try:
                    cur.execute(_q(sql), (workspace_code,))
                    return [dict(r) for r in cur.fetchall()]
                finally:
                    cur.close()
        except Exception:  # noqa: BLE001 - absent legacy table = nothing to migrate
            return []

    out: list[dict] = []
    for r in _query("SELECT role, files_json, updated_at FROM "
                    "studio_agent_defs WHERE workspace_code=?"):
        if ".studio-created" not in (r.get("files_json") or ""):
            continue
        try:
            files = json.loads(r.get("files_json") or "{}")
        except ValueError:
            files = {}
        out.append({"kind": "agent", "name": r["role"], "raw": files,
                    "updated_at": r.get("updated_at") or ""})
    for r in _query("SELECT name, files_json, updated_at FROM studio_skills "
                    "WHERE workspace_code=? AND origin='studio'"):
        try:
            files = json.loads(r.get("files_json") or "{}")
        except ValueError:
            files = {}
        out.append({"kind": "skill", "name": r["name"], "raw": files,
                    "updated_at": r.get("updated_at") or ""})
    for r in _query("SELECT code, yaml, files_json, updated_at FROM "
                    "studio_workflow_defs WHERE workspace_code=? "
                    "AND source='studio'"):
        try:
            files = json.loads(r.get("files_json") or "{}")
        except ValueError:
            files = {}
        if not isinstance(files, dict):
            files = {}
        # The definition's yaml column IS workflow.yaml; files_json holds any
        # extra files (steps/, roles/). The yaml wins a key collision - it is
        # the copy the old tier actually served.
        files = dict(files)
        if (r.get("yaml") or "").strip():
            files["workflow.yaml"] = r["yaml"]
        out.append({"kind": "workflow", "name": r["code"], "raw": files,
                    "updated_at": r.get("updated_at") or ""})
    return out


@drafts_app.command("migrate")
def migrate_cmd(
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Report what would migrate; write nothing."),
    author: str = typer.Option(
        _MIGRATE_AUTHOR, "--author",
        help=f"Author the migrated drafts belong to (default "
             f"{_MIGRATE_AUTHOR})."),
    workspace: str = typer.Option(
        None, "--workspace",
        help="Must match the active workspace - migrate is a write."),
) -> None:
    """WRITE: turn the legacy studio-authored tenant rows into drafts.

    A name an installed pack provides becomes an OVERLAY draft (base pinned
    from the pack as it is on this box); a name no pack provides becomes a
    new-item draft. Idempotent: a row whose draft already exists and is at
    least as new is skipped, so re-running never clobbers a draft the author
    has edited since. The legacy rows are NOT deleted - they stay for the
    transitional read tier and for rollback.
    """
    cli = _cli()
    ws = cli._workspace_code(workspace, required=True, write=True)
    _context(ws)
    store = _store()
    dstore = D.DraftStore(store)
    rows = _legacy_rows(store, ws)
    if not rows:
        typer.echo(f"nothing to migrate: no legacy studio-authored rows in "
                   f"workspace '{ws}'.")
        return

    from ioagentfarm.web import catalog as cat
    try:
        items = cat.stamps()
    except Exception:  # noqa: BLE001 - no stamps just means new-item pins
        items = []

    migrated = skipped_newer = 0
    for row in rows:
        skipped_files: list[str] = []
        files = _decode_files(row["raw"], skipped_files)
        label = f"{row['kind']} {row['name']}"
        if not files:
            typer.echo(f"  skip {label}: the row carries no text files")
            continue

        existing = dstore.find(ws, row["kind"], row["name"], author,
                               statuses=None)
        if existing is not None and \
                (existing.get("updated_at") or "") >= (row["updated_at"] or ""):
            # The draft is the newer record — the author (or a previous
            # migration) already owns this content; overwriting it would
            # undo their edits with a stale row.
            skipped_newer += 1
            typer.echo(f"  skip {label}: draft {existing['id']} already "
                       "exists and is newer")
            continue

        _dir, base_files, stamp = _installed_item(
            row["kind"], row["name"], ws, items)
        if _dir is not None:
            shape = "overlay"
            base = {p: base_files[p] for p in files if p in base_files}
        else:
            shape = "new-item"
            base, stamp = {}, ""

        note = "migrated from the legacy studio tier"
        if dry_run:
            typer.echo(f"  would migrate {label}: {shape} draft, "
                       f"{len(files)} file(s)"
                       + (f", skipping non-text: {', '.join(skipped_files)}"
                          if skipped_files else ""))
            continue
        created = dstore.upsert(
            workspace_code=ws, kind=row["kind"], name=row["name"],
            author=author, files=files, base_files=base, base_stamp=stamp,
            note=note)
        migrated += 1
        typer.echo(f"  migrated {label}: {shape} draft {created['id']}, "
                   f"{len(files)} file(s)"
                   + (f", skipped non-text: {', '.join(skipped_files)}"
                      if skipped_files else ""))

    if dry_run:
        typer.echo(f"\ndry run: {len(rows)} legacy row(s) examined; "
                   "nothing written.")
    else:
        typer.echo(f"\nmigrated {migrated} draft(s), skipped {skipped_newer} "
                   "already-newer. Legacy rows are retained (transitional "
                   "read tier / rollback).")
