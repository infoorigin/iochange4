"""Workspace <-> solution-repo bridge — the CLI-only push/pull engine.

THE CONTRACT (platform decision, 2026-07-27):
  * In the product the DB is authoritative — the UI never sees git.
  * ``repo -> DB`` (import) and ``DB -> repo`` (export) are OPERATOR CLI
    actions (``aicore workspace push|export``). No UI button, no
    webhook, no boot-sync.
  * NOTHING SILENTLY ERASES A BUSINESS USER'S WORK — enforced, not promised:
    every imported item records ``imported_sha``/``imported_hash``/``origin``;
    import REFUSES diverged items by default (exit 3, names them), and even
    an explicit ``--take-repo`` snapshots the prior DB content under
    ``<IOF_ROOT>/workspaces/<code>/.backups/<ts>/`` first. Studio-created
    items (absent from the repo) are never touched at all. The batch applies
    atomically — all or nothing.

Tenancy keying rule (see apps/agentfarm-api/app/tenancy.py): these are
API-side ``studio_*`` tables, keyed by the human ``workspace_code``.

Phase 2 scope: WORKFLOWS. The item model (kind column) already carries
agents/skills for Phase 3.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
from contextlib import contextmanager
import time
from datetime import datetime, timezone
from pathlib import Path

from ioagentfarm.engine.filecodec import encode_file, write_file
from ioagentfarm.engine.workspaces import PLATFORM_TIER as _PLATFORM_TIER_SYNC

from ioagentfarm.solution_manifest import (
    MANIFEST_NAME, ManifestError, SolutionManifest, find_manifest,
    load_manifest, validate_reserved,
)

logger = logging.getLogger(__name__)

# ── exit codes (cli-hub convention) ─────────────────────────────────
EXIT_OK = 0
EXIT_ERROR = 1
EXIT_GAPS = 3   # validation rejected / diverged items refused

_LOCK_STALE_S = 30 * 60

# ── schema ──────────────────────────────────────────────────────────

_REPOS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workspace_repos ("
    "  workspace_code   TEXT PRIMARY KEY,"
    "  repo_url         TEXT NOT NULL,"
    "  branch           TEXT NOT NULL DEFAULT 'main',"
    "  credential_ref   TEXT NOT NULL DEFAULT '',"   # env-var NAME, never a secret
    "  clone_path       TEXT NOT NULL DEFAULT '',"
    "  last_sha         TEXT NOT NULL DEFAULT '',"
    "  last_imported_at TEXT,"
    "  last_exported_at TEXT,"
    "  last_report_json TEXT NOT NULL DEFAULT '{}',"
    "  updated_at       TEXT NOT NULL"
    ")"
)

_ITEMS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workspace_items ("
    "  workspace_code TEXT NOT NULL,"
    "  kind           TEXT NOT NULL,"        # workflow | agent | skill
    "  name           TEXT NOT NULL,"
    "  imported_sha   TEXT NOT NULL DEFAULT '',"
    "  imported_hash  TEXT NOT NULL DEFAULT '',"
    "  origin         TEXT NOT NULL DEFAULT 'repo',"  # repo | studio
    "  updated_at     TEXT NOT NULL,"
    "  PRIMARY KEY (workspace_code, kind, name)"
    ")"
)

#: Fresh-DB shape of the (API-owned, shared-DDL) workflow defs table.
#: Legacy single-tenant tables are migrated in place — see ensure_schema().
_DEFS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workflow_defs ("
    "  workspace_code TEXT NOT NULL DEFAULT 'default',"
    "  code           TEXT NOT NULL,"
    "  yaml           TEXT NOT NULL,"
    "  files_json     TEXT NOT NULL DEFAULT '{}',"
    "  source         TEXT NOT NULL DEFAULT 'pack-sync',"
    "  shadows_pack   INTEGER NOT NULL DEFAULT 0,"
    "  synced_at      TEXT,"
    "  updated_at     TEXT NOT NULL,"
    "  imported_sha   TEXT NOT NULL DEFAULT '',"
    "  imported_hash  TEXT NOT NULL DEFAULT '',"
    "  origin         TEXT NOT NULL DEFAULT '',"
    "  content_hash   TEXT NOT NULL DEFAULT '',"
    "  version        INTEGER NOT NULL DEFAULT 1,"
    # Which SOLUTION of the workspace family owns this workflow ('' = the
    # family itself / unattributed). Written by pack sync (Pack.solution) and
    # repo import (manifest workflow_solution_map); read by the Studio, which
    # is packs-blind and could never derive it. Agents/skills deliberately
    # have no such column — they are family-level by design.
    "  solution       TEXT NOT NULL DEFAULT '',"
    "  PRIMARY KEY (workspace_code, code)"
    ")"
)

#: Materialize-on-use: the DB copy of studio-authored AGENT workspaces
#: (identity files + skills; never memory/sessions). Written by the studio
#: API on every agent/skill save; read by engine hydration at run/task/chat
#: seams. Same shape discipline as studio_workflow_defs.
_AGENT_DEFS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_agent_defs ("
    "  workspace_code TEXT NOT NULL DEFAULT 'default',"
    "  role           TEXT NOT NULL,"
    "  files_json     TEXT NOT NULL DEFAULT '{}',"
    "  content_hash   TEXT NOT NULL DEFAULT '',"
    "  version        INTEGER NOT NULL DEFAULT 1,"
    "  updated_at     TEXT NOT NULL,"
    "  PRIMARY KEY (workspace_code, role)"
    ")"
)


#: A skill's own identity (2026-07-30). Before this table a skill existed only
#: as path-keyed entries inside every carrying agent's ``files_json`` — stored
#: once per carrier, so one edit fanned out into N full agent re-snapshots, and
#: a repo-imported standalone skill had nowhere to live at all.
#:
#: DELIBERATELY NO agent<->skill mapping table: ``roles_json`` already IS the
#: assignment (``_validate_skill_payload`` folds ``install_to`` into it, and
#: ``workspaces.ensure_agent_workspace`` places a shared skill by it). A
#: mapping table would be a second answer to a question already answered, free
#: to drift from the first.
#:
#: ASSIGNMENT, NOT ELIGIBILITY. It records which agents HOLD the skill — their
#: baseline — and nothing consults it to refuse one: a workflow step resolves
#: what the job needs from the whole catalog, so it may name a skill no agent
#: holds. (Until 2026-08 the SKILL.md ``roles:`` key was also a default-closed
#: gate; that gate is gone, and the key now only seeds a workspace's baseline
#: the first time it is materialised.)
_SKILLS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_skills ("
    "  workspace_code TEXT NOT NULL DEFAULT 'default',"
    "  name           TEXT NOT NULL,"
    "  files_json     TEXT NOT NULL DEFAULT '{}',"
    # null | "all" | [roles]. A LIST COLUMN, not an (agent, skill) mapping
    # table — decided, with two known costs written down in
    # docs/PLATFORM_HARDENING_BACKLOG.md ("Skill assignment as a mapping
    # table"): assigning a role is read-modify-write, so two concurrent
    # Studio saves on one skill can lose an update; and carried_skills
    # selects every skill in the workspace and filters in Python where an
    # indexed (workspace_code, role) lookup would be one seek.
    "  roles_json     TEXT NOT NULL DEFAULT 'null',"
    "  content_hash   TEXT NOT NULL DEFAULT '',"
    "  version        INTEGER NOT NULL DEFAULT 1,"
    "  updated_at     TEXT NOT NULL,"
    "  imported_sha   TEXT NOT NULL DEFAULT '',"
    "  imported_hash  TEXT NOT NULL DEFAULT '',"
    "  origin         TEXT NOT NULL DEFAULT '',"       # repo | studio
    "  PRIMARY KEY (workspace_code, name)"
    ")"
)


#: ── THE PACK CATALOG MIRROR ───────────────────────────────────────────────
#:
#: What the INSTALLED WHEELS contain, published into the database by the
#: ENGINE (``engine/catalog_sync.py``) so a consumer that has no packs — the
#: Studio API pod, which is never co-located with the engine — can render an
#: agent or a skill it cannot read from disk. Same idea as ``agents.pack``,
#: which already exists for exactly this reason; these two tables extend it
#: from "which solution" to "what does it look like".
#:
#: THESE ARE NOT TENANT CONTENT, and the distinction is the whole design:
#:
#:   * ``studio_agent_defs`` / ``studio_skills`` are TENANT-OWNED. They are
#:     workspace-keyed, written by the Studio and by ``workspace push``,
#:     exported back to a solution repo, and they are what hydration
#:     MATERIALISES from. A tenant copy of a wheel's skill in ``studio_skills``
#:     would freeze a fork no SDK upgrade ever reaches — which is why
#:     ``skill_defs.upsert_skill_def`` refuses to write content onto a shared
#:     skill's row.
#:   * ``pack_agents`` / ``pack_skills`` are a MIRROR. Not workspace-keyed
#:     (a wheel is identical in every tenant), never exported, NEVER read by
#:     hydration or by any materialisation path, never editable through the
#:     Studio, and REPLACED WHOLESALE by every sync — rows for content that
#:     left the wheel are deleted. So they cannot go stale across an upgrade
#:     the way a tenant copy would: bumping the wheel and re-running
#:     ``aicore sync`` is the refresh.
#:
#: A tenant row always WINS on read; the mirror is the answer for everything
#: the tenant has not taken ownership of.
#:
#: The AGENT half of the mirror is not a table — it is three columns added to
#: the existing global ``agents`` catalog (``soul``, ``tools_md``,
#: ``skills_json``; see ``engine/store.py``), because ``agents`` already IS
#: that catalog and already carries ``pack`` for exactly this reason. Only the
#: SKILL half needed a new table: skills had a per-workspace content/assignment
#: table and no global catalog at all.

#: The skill half of the mirror — the missing counterpart of ``agents.pack``.
#: Until it existed there was NO skills sync anywhere, so a pod with no packs
#: showed no ``presentation``, no ``data_query``, no ``guardrails``: a pack
#: skill only ever reached the database as an ASSIGNMENT-ONLY ``studio_skills``
#: row (``origin='pack'``, ``files_json='{}'``), which says who holds it and
#: nothing about what it is.
#:
#: ``skill_md`` holds SKILL.md verbatim because that text IS what the Studio's
#: detail view renders (description, `always`, body, the raw package). Storing
#: it here is not the thing the shared tier forbids: this row is not
#: tenant-owned, is not exported, is not a materialisation source (hydration
#: resolves an assignment-only row from the WHEEL, via
#: ``workspaces.shared_skill_files``), and is overwritten by the next sync.
#:
#: ``shared`` marks the tier a tenant may not take ownership of
#: (``reserved_names()[1]`` — core + the shared-skills wheel). It is what lets
#: the API answer "may the Studio edit this?" without importing the registry.
#: A CONVERSATION with an always-on agent (2026-08-18) — the durable half of
#: the Studio's chat surface. The engine already answers a turn
#: (`POST /api/chat/<role>`) and already logs its progress to `messages`; what
#: nothing kept was the THREAD: which turns belong together, in what order,
#: under whose name.
#:
#: Workspace-scoped and AUTHOR-scoped. A conversation belongs to the member who
#: opened it — the Studio API stamps the verified identity, exactly as
#: `content_drafts` does, because the engine has no auth and this API is the
#: only place identity is real.
_CONVERSATIONS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_conversations ("
    "  workspace_code TEXT NOT NULL DEFAULT 'default',"
    "  id             TEXT NOT NULL,"
    # The always-on agent this thread talks to. A conversation is per-AGENT:
    # the engine keys its own session by `session_key`, and mixing two agents
    # into one thread would give the UI a history the engine never had.
    "  role           TEXT NOT NULL,"
    "  author         TEXT NOT NULL,"
    "  title          TEXT NOT NULL DEFAULT '',"
    # The CALLER's key/value bag, verbatim, never read or written by us. An
    # OpenAI-shaped client sends `metadata` on a conversation and expects it
    # back unchanged; without somewhere to put it we would accept the field and
    # silently drop it, which is worse than refusing it. Our own derived facts
    # (the auto-generated title, the agent) stay in their own columns rather
    # than spending the caller's bag.
    "  metadata_json  TEXT NOT NULL DEFAULT '',"
    "  created_at     TEXT NOT NULL,"
    "  updated_at     TEXT NOT NULL,"
    "  PRIMARY KEY (workspace_code, id)"
    ")"
)

#: One turn. Rows are append-only and ordered by `seq` within a conversation —
#: NOT by `created_at`, which is a display value and ties at second resolution
#: for a fast exchange.
#:
#: `envelope_json` holds the agent's structured answer verbatim when it emitted
#: one. Stored beside the text rather than parsed out of it: the engine already
#: returns the parsed envelope on the chat response, and re-parsing a fenced
#: block out of prose is how a renderer ends up disagreeing with the agent.
_CONVERSATION_MESSAGES_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_conversation_messages ("
    "  workspace_code  TEXT NOT NULL DEFAULT 'default',"
    "  conversation_id TEXT NOT NULL,"
    "  seq             INTEGER NOT NULL,"
    "  id              TEXT NOT NULL,"
    "  role            TEXT NOT NULL,"          # 'user' | 'assistant'
    "  content         TEXT NOT NULL DEFAULT '',"
    "  envelope_json   TEXT NOT NULL DEFAULT '',"
    "  run_id          TEXT NOT NULL DEFAULT '',"
    "  error           TEXT NOT NULL DEFAULT '',"
    # The agent's own reasoning for this turn, as it streamed. Kept because
    # throwing it away is a real loss: it is where the SQL path, the rejected
    # approaches and the caveats live, and it was visible for the 4 minutes
    # the user waited and then vanished the moment the answer arrived.
    "  thoughts        TEXT NOT NULL DEFAULT '',"
    "  created_at      TEXT NOT NULL,"
    "  PRIMARY KEY (workspace_code, conversation_id, seq)"
    ")"
)


_PACK_SKILLS_DDL = (
    "CREATE TABLE IF NOT EXISTS pack_skills ("
    "  name      TEXT PRIMARY KEY,"
    "  pack      TEXT NOT NULL DEFAULT '',"
    "  shared    INTEGER NOT NULL DEFAULT 0,"
    "  skill_md  TEXT NOT NULL DEFAULT '',"       # SKILL.md verbatim
    "  synced_at TEXT NOT NULL DEFAULT ''"
    ")"
)


#: Per-tenant catalog scoping (API-owned; ``apps/agentfarm-api/app/
#: workspace_settings.py``). Declared here too because the importer writes it:
#: a workspace with NO row is UNSCOPED, and unscoped means the Studio lists
#: every installed pack's agents in it. That is the state every newly created
#: workspace was in — the rows existed only for two hard-coded demo tenants —
#: so a fresh tenant showed other solutions' agents the moment its own import
#: succeeded.
_WS_SETTINGS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workspace_settings ("
    "  workspace_code TEXT PRIMARY KEY,"
    "  include_packs  TEXT NOT NULL DEFAULT '',"
    "  exclude_packs  TEXT NOT NULL DEFAULT '',"
    "  updated_at     TEXT NOT NULL"
    ")"
)


#: Who may reach a tenant (API-owned; ``apps/agentfarm-api/app/
#: workspace_members.py``). Membership is CLOSED — no row, no access — so a
#: workspace created with no member is one nobody can open. The CLI could
#: create exactly that until ``workspace create --member`` existed, and the
#: symptom was the least legible one available: ``GET /api/workspaces``
#: answered ``[]`` for a workspace that had just been created successfully.
#:
#: DELIBERATELY NOT ENSURED BY :func:`ensure_platform_schema`, unlike the other
#: shared tables here. This one is written by exactly one CLI path (granting a
#: member) and read defensively everywhere else, so an engine-only deployment
#: that never grants anything genuinely does not have the table — the state
#: ``apps/agentfarm-api/tests/test_workspace_sync.py`` builds on to prove a
#: delete against an absent tenant table does not roll back the deletes beside
#: it. Ensuring it here would quietly delete that test's premise.
_MEMBERS_DDL = (
    "CREATE TABLE IF NOT EXISTS studio_workspace_members ("
    "  workspace_code TEXT NOT NULL,"
    "  user_email     TEXT NOT NULL,"
    "  role           TEXT NOT NULL DEFAULT 'member',"
    "  added_at       TEXT NOT NULL,"
    "  PRIMARY KEY (workspace_code, user_email)"
    ")"
)

#: The platform-wide grant, expressed through the members table. Mirrors
#: ``app.workspace_members.ADMIN_ROLE``; a user holding it on ANY row reaches
#: every workspace.
ADMIN_ROLE = "admin"
MEMBER_ROLES = ("member", ADMIN_ROLE)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ensure_members_table(con, is_pg: bool) -> None:
    cur = con.cursor()
    cur.execute(_MEMBERS_DDL)
    try:
        cur.execute("CREATE INDEX IF NOT EXISTS ix_ws_members_user_email "
                    "ON studio_workspace_members (user_email)")
    except Exception:          # pragma: no cover - an optimisation, not a need
        pass
    try:
        con.commit()
    except Exception:
        pass


def add_workspace_member(code: str, email: str, role: str = "member") -> dict:
    """Grant *email* access to workspace *code*. Idempotent.

    MIRRORS ``apps/agentfarm-api/app/workspace_members.py::add_member`` — same
    lowercasing, same upsert on ``(workspace_code, user_email)``, same
    ``added_at``. Core cannot import the API (they are separate distributions
    and the API pod installs no packs), so the *shape* is the contract and
    these two implementations have to be read against each other. A row written
    here must be indistinguishable from a row the Studio wrote, or a
    CLI-provisioned tenant behaves differently from a UI-provisioned one.
    """
    email = (email or "").strip().lower()
    if not email:
        raise ValueError("an email address is required")
    if role not in MEMBER_ROLES:
        raise ValueError(f"role must be one of {list(MEMBER_ROLES)}")
    with connected() as (adapter, con):
        is_pg = adapter.placeholder() == "%s"
        ensure_members_table(con, is_pg)
        cur = con.cursor()
        upsert = (
            "INSERT INTO studio_workspace_members "
            "(workspace_code, user_email, role, added_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT (workspace_code, user_email) DO UPDATE SET "
            "role = EXCLUDED.role"
            if is_pg else
            "INSERT OR REPLACE INTO studio_workspace_members "
            "(workspace_code, user_email, role, added_at) VALUES (?, ?, ?, ?)")
        cur.execute(_q(adapter, upsert), (code, email, role, _now()))
        try:
            con.commit()
        except Exception:
            pass
    return {"workspace_code": code, "user_email": email, "role": role}


def seed_empty_scope(code: str) -> bool:
    """Give a brand-new workspace an EMPTY scoping row. True if written.

    MIRRORS ``apps/agentfarm-api/app/workspace_settings.py::seed_empty_scope``,
    which the Studio's create screen already calls. Without it the two creation
    paths diverge in the least visible way available: a workspace created in
    the product opens empty, and the identical workspace created from the CLI
    opens showing every installed solution's agents — because an ABSENT row
    means unscoped, and unscoped means "list everything".

    Never overwrites. ``_scope_workspace_to_solution`` claims this placeholder
    at the first import, and a curated row is a deliberate choice.
    The platform tier is skipped: it is unscoped by design.
    """
    from ioagentfarm.engine.workspaces import PLATFORM_TIER
    code = (code or "").strip().lower()
    if not code or code == PLATFORM_TIER:
        return False
    try:
        with connected() as (adapter, con):
            cur = con.cursor()
            cur.execute(_q(adapter, "SELECT workspace_code FROM "
                                    "studio_workspace_settings "
                                    "WHERE workspace_code = ?"), (code,))
            if cur.fetchone() is not None:
                return False
            cur.execute(_q(adapter,
                "INSERT INTO studio_workspace_settings (workspace_code,"
                " include_packs, exclude_packs, updated_at) "
                "VALUES (?, '', '', ?)"), (code, _now()))
            try:
                con.commit()
            except Exception:
                pass
            return True
    except Exception:      # pragma: no cover - best effort, as in the API
        return False


def list_workspace_members(code: str) -> list[dict]:
    """Members of *code*. An absent table means nobody has been granted yet."""
    with connected() as (adapter, con):
        cur = con.cursor()
        try:
            cur.execute(_q(adapter,
                           "SELECT user_email, role, added_at "
                           "FROM studio_workspace_members "
                           "WHERE workspace_code = ? ORDER BY user_email"),
                        (code,))
        except Exception:
            return []
        return [r if isinstance(r, dict) else dict(r) for r in cur.fetchall()]


def _iof_root() -> Path:
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve()


def connect():
    """(adapter, connection) on the engine DB — IOF_DATABASE_URL or the
    default sqlite state store."""
    from ioagentfarm.engine.db import make_adapter
    url = (os.getenv("IOF_DATABASE_URL") or "").strip() \
        or f"sqlite:///{_iof_root() / 'state.db'}"
    adapter = make_adapter(url)
    con = adapter.connect()
    try:
        adapter.init_connection(con)
    except Exception:
        pass
    return adapter, con


def release(con) -> None:
    """Hand a connection back — the other half of :func:`connect`.

    Under Postgres ``connect()`` returns a ``_PooledConnection``. Every
    ``connect()`` here used to acquire and never release, so each call
    permanently consumed a pool slot; the pool exhausts and the process wedges
    on the next checkout. It has not bitten yet only because every caller is a
    short-lived CLI process that dies with its leak — the moment a Studio
    endpoint calls ``push_workspace`` (a live roadmap item) the same code is
    running inside a long-lived server and the leak is real.

    Same fix as ``engine/hydration.py`` (commit f647962): the wrapper's
    ``__exit__`` honours psycopg2's commit-on-clean-exit contract AND returns
    the connection to the pool. NEVER call ``close()`` on the wrapper for this
    purpose — that is the leak path the hydration bug was.
    """
    try:
        if hasattr(con, "_pool"):          # _PooledConnection
            con.__exit__(None, None, None)
        else:
            con.close()
    except Exception:
        pass


@contextmanager
def connected():
    """``with connected() as (adapter, con):`` — connect, ensure schema, release.

    The only correct way to use :func:`connect` outside a caller that already
    owns the connection's lifetime. Prefer it to a bare ``connect()``.
    """
    adapter, con = connect()
    try:
        ensure_schema(adapter, con)
        yield adapter, con
    finally:
        release(con)


def _q(adapter, sql: str) -> str:
    return sql.replace("?", "%s") if adapter.placeholder() == "%s" else sql


def _table_columns(cur, table: str, is_pg: bool) -> list[str]:
    """The table's columns IN THE SCHEMA THIS CONNECTION RESOLVES TO.

    ``current_schema()`` is not decoration: several workspaces share one
    database, each in its own schema, and an unqualified
    ``information_schema.columns`` lookup matches the table in ANY of them.
    A brand-new workspace schema on a database that already held another
    one therefore answered "studio_workflow_defs exists" - the CREATE was
    skipped, the migration branch ran against a table that was not there,
    and the workspace ran without it. Found by ensuring a fresh scratch
    schema on a real shared database; an empty test database cannot show
    it, because there is no other schema for the lookup to find.
    """
    try:
        if is_pg:
            cur.execute(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_name = %s AND table_schema = current_schema()",
                (table,))
            return [r[0] if not isinstance(r, dict) else r["column_name"]
                    for r in cur.fetchall()]
        cur.execute(f"PRAGMA table_info({table})")
        return [dict(r)["name"] if not isinstance(r, tuple) else r[1]
                for r in cur.fetchall()]
    except Exception:
        return []


def ensure_schema(adapter, con) -> None:
    """Adapter-flavored wrapper over :func:`ensure_platform_schema`."""
    ensure_platform_schema(con, adapter.placeholder() == "%s")


def _fetch_all(cur, sql, is_pg: bool, params=None) -> list | None:
    """A guarded SELECT that returns its rows, or None when it could not run.

    Not `_exec_one` + `cur.fetchall()`: after a rolled-back SAVEPOINT the
    cursor holds NO RESULT SET, and psycopg2 answers a fetch with
    `ProgrammingError: no results to fetch` - a real-database behaviour an
    in-memory fake cannot show, and the exact shape that turned a guarded
    read into an unhandled exception during hardening. Fetching HERE, inside
    the same guard that ran the statement, is what keeps the two together.
    """
    if not _exec_one(cur, sql, is_pg, params):
        return None
    try:
        return list(cur.fetchall())
    except Exception:  # noqa: BLE001 - a statement that returned no rows
        return None


def _exec_one(cur, sql, is_pg: bool, params=None) -> bool:
    """One statement, isolated. On PostgreSQL under its own SAVEPOINT, so a
    failure neither aborts the transaction (poisoning every later statement)
    nor needs `con.rollback()` - the call that silently DISCARDED every
    CREATE executed before it. Found live: a fresh workspace schema ended
    with 39 of the platform tables because one migration statement failed
    and the rollback took the conversation tables with it, while the
    function reported success. Returns whether the statement ran."""
    if is_pg:
        cur.execute("SAVEPOINT _eps_one")
        try:
            if params is None:
                cur.execute(sql)
            else:
                cur.execute(sql, params)
            cur.execute("RELEASE SAVEPOINT _eps_one")
            return True
        except Exception:  # noqa: BLE001 - isolation is the point
            try:
                cur.execute("ROLLBACK TO SAVEPOINT _eps_one")
            except Exception:  # noqa: BLE001
                pass
            return False
    try:
        if params is None:
            cur.execute(sql)
        else:
            cur.execute(sql, params)
        return True
    except Exception:  # noqa: BLE001
        return False


def ensure_platform_schema(con, is_pg: bool) -> None:
    """Idempotent platform tables + legacy studio_workflow_defs migration.

    THE single implementation — the CLI calls it through ``ensure_schema``
    and apps/agentfarm-api's ``workflow_defs.ensure_defs`` calls it directly
    with its own connection, so the two sides can never drift.

    Migration semantics: existing single-tenant rows all belong to the
    'default' workspace; origin mirrors source ('studio' stays 'studio',
    'pack-sync' becomes 'repo' with UNKNOWN import hash — pack-sync rows
    were never divergence-tracked and the pack-sync endpoint keeps its own
    kept-studio conflict policy).
    """
    cur = con.cursor()
    _exec_one(cur, _REPOS_DDL, is_pg)
    _exec_one(cur, _ITEMS_DDL, is_pg)
    _exec_one(cur, _AGENT_DEFS_DDL, is_pg)
    _exec_one(cur, _SKILLS_DDL, is_pg)
    _exec_one(cur, _WS_SETTINGS_DDL, is_pg)
    # The skills catalog. Created HERE as well as in engine/store.py so BOTH
    # sides get it from one implementation: the engine WRITES it (it has the
    # wheels) and the API READS it, and the API only ever reaches the schema
    # through this function.
    _exec_one(cur, _PACK_SKILLS_DDL, is_pg)
    _exec_one(cur, _CONVERSATIONS_DDL, is_pg)
    _exec_one(cur, _CONVERSATION_MESSAGES_DDL, is_pg)
    # ADDITIVE, because CREATE TABLE IF NOT EXISTS adds nothing to a table that
    # already exists — the column simply never appeared on any database created
    # before it was declared, and the insert failed at runtime rather than at
    # deploy. Same shape as the studio_workflow_defs migrations below.
    if "thoughts" not in _table_columns(cur, "studio_conversation_messages",
                                        is_pg):
        _exec_one(cur, "ALTER TABLE studio_conversation_messages "
                        "ADD COLUMN thoughts TEXT NOT NULL DEFAULT ''", is_pg)
    # Boot registration (One Truth model, docs/one-truth-content-model.md
    # §3.3/§5): what content each engine pod is running, one row per pack
    # per boot. The engine WRITES it at `serve` startup and the API will
    # READ it ("which commit is running in UAT?"), so it is ensured on both
    # sides — from ONE DDL function in engine/registration.py, which is what
    # keeps this copy and Store.init's from drifting.
    from ioagentfarm.engine.registration import content_registration_ddl
    for _ddl in content_registration_ddl(is_pg):
        _exec_one(cur, _ddl, is_pg)
    # Content drafts (One Truth §3.5): the Studio WRITES them (a Save is a
    # draft) and the engine READS them (a Try-it session resolves pack + the
    # author's overlay), so both sides ensure the table — from the ONE DDL
    # function in engine/drafts.py, which is what keeps this copy and
    # Store.init's from drifting.
    from ioagentfarm.engine.drafts import content_drafts_ddl
    for _ddl in content_drafts_ddl(is_pg):
        _exec_one(cur, _ddl, is_pg)

    cols = _table_columns(cur, "studio_workflow_defs", is_pg)
    if not cols:
        _exec_one(cur, _DEFS_DDL, is_pg)
    elif "workspace_code" not in cols:
        if is_pg:
            for ddl in (
                "ALTER TABLE studio_workflow_defs ADD COLUMN workspace_code TEXT NOT NULL DEFAULT 'default'",
                "ALTER TABLE studio_workflow_defs ADD COLUMN imported_sha TEXT NOT NULL DEFAULT ''",
                "ALTER TABLE studio_workflow_defs ADD COLUMN imported_hash TEXT NOT NULL DEFAULT ''",
                "ALTER TABLE studio_workflow_defs ADD COLUMN origin TEXT NOT NULL DEFAULT ''",
            ):
                _exec_one(cur, ddl, is_pg)
            if _exec_one(cur, "ALTER TABLE studio_workflow_defs "
                              "DROP CONSTRAINT studio_workflow_defs_pkey",
                         is_pg):
                _exec_one(cur, "ALTER TABLE studio_workflow_defs "
                               "ADD PRIMARY KEY (workspace_code, code)", is_pg)
        else:
            # sqlite: rebuild (ALTER cannot change a PK)
            cur.execute("ALTER TABLE studio_workflow_defs RENAME TO _swd_legacy")
            cur.execute(_DEFS_DDL)
            cur.execute(
                "INSERT INTO studio_workflow_defs (workspace_code, code, yaml,"
                " files_json, source, shadows_pack, synced_at, updated_at,"
                " imported_sha, imported_hash, origin) "
                "SELECT 'default', code, yaml, files_json, source, shadows_pack,"
                " synced_at, updated_at, '', '',"
                " CASE source WHEN 'studio' THEN 'studio' ELSE 'repo' END "
                "FROM _swd_legacy")
            cur.execute("DROP TABLE _swd_legacy")
        _exec_one(cur,
            "UPDATE studio_workflow_defs SET origin = CASE source "
            "WHEN 'studio' THEN 'studio' ELSE 'repo' END "
            "WHERE origin = ''", is_pg)

    # Materialize-on-use sync-key columns (2026-07-27) — idempotent adds +
    # a one-time content_hash backfill so pre-hydration rows carry a real key
    # (empty hash = "no reliable key" and the hydrator fails open past it).
    cols = _table_columns(cur, "studio_workflow_defs", is_pg)
    for col, ddl in (
        ("content_hash", "ALTER TABLE studio_workflow_defs "
                         "ADD COLUMN content_hash TEXT NOT NULL DEFAULT ''"),
        ("version", "ALTER TABLE studio_workflow_defs "
                    "ADD COLUMN version INTEGER NOT NULL DEFAULT 1"),
        # 2026-08: per-solution workflow attribution (workspace families)
        ("solution", "ALTER TABLE studio_workflow_defs "
                     "ADD COLUMN solution TEXT NOT NULL DEFAULT ''"),
    ):
        if cols and col not in cols:
            _exec_one(cur, ddl, is_pg)
    ph = "%s" if is_pg else "?"
    _defs = _fetch_all(cur, "SELECT workspace_code, code, yaml, files_json "
                            "FROM studio_workflow_defs WHERE content_hash = ''",
                       is_pg)
    if _defs is not None:
        rows = [dict(x) if not isinstance(x, dict) else x for x in _defs]
        for r in rows:
            try:
                files = json.loads(r.get("files_json") or "{}")
            except json.JSONDecodeError:
                files = {}
            _exec_one(cur,
                f"UPDATE studio_workflow_defs SET content_hash = {ph} "
                f"WHERE workspace_code = {ph} AND code = {ph}", is_pg,
                (content_hash(r["yaml"], files), r["workspace_code"], r["code"]))

    _backfill_skills(cur, con, is_pg)

    try:
        con.commit()
    except Exception:
        pass


def skill_roles(files: dict[str, str]) -> object:
    """A skill's DECLARED ``roles:``, read from its SKILL.md frontmatter.

    Used at import to give a standalone repo skill an initial assignment when
    the manifest does not state one — it is a starting assignment, not an
    allow-list, and nothing consults it afterwards to refuse the skill to an
    agent. Mirrors ``engine.workspaces._legacy_default_assignment`` (that one
    reads a directory and answers about one role; this one reads a decoded
    payload and returns the raw declaration).

    Returns ``None`` (undeclared: assigned to no agent yet), the literal
    ``"all"``, or a list of role names.
    """
    txt = files.get("SKILL.md") or ""
    if not txt.startswith("---"):
        return None
    try:
        import yaml as _yaml
        meta = _yaml.safe_load(txt.split("---", 2)[1]) or {}
    except Exception:
        return None
    return meta.get("roles") if isinstance(meta, dict) else None


def _backfill_skills(cur, con, is_pg: bool) -> None:
    """Copy ``skills/**`` out of every agent blob into ``studio_skills``.

    COPIES — ``studio_agent_defs.files_json`` is deliberately left untouched,
    so the pre-migration state stays recoverable. Reads cut over to this table;
    the legacy keys become a frozen snapshot nothing consults.

    Re-runnable: names already present for a workspace are skipped, which is
    the same "skip what is already done" predicate the workflow content_hash
    backfill above uses to make a second run a no-op.

    One skill name can appear in several agents with DIFFERENT content (a
    Studio edit reaches only the agents it was installed to). Majority content
    wins, ties broken by first carrying role — deterministic, and it stops one
    agent's stale copy from beating five identical ones.

    ``roles_json`` is set to the roles that ACTUALLY carry the skill, not to
    its declared ``roles:`` frontmatter. The two usually agree, but not for an
    agent-carried repo skill: living under ``agents/<role>/workspace/skills/``
    IS its assignment, and a boilerplate ``roles: all`` in such a file would
    otherwise redistribute it into every agent the first time hydration read
    this table — re-inflating exactly the prompts the scoped ``roles:`` lists
    were introduced to trim. Migration must preserve today's placement exactly;
    it is not the moment to re-derive it. (Studio writes agree by construction:
    ``_validate_skill_payload`` already sets ``roles = sorted(install_to)``.)
    """
    ph = "%s" if is_pg else "?"
    # Guarded reads: this runs inside ensure_platform_schema's transaction,
    # and a `con.rollback()` here discarded every CREATE the ensure had
    # already executed. A read that fails simply ends the backfill.
    _rows = _fetch_all(cur, "SELECT workspace_code, name FROM studio_skills",
                       is_pg)
    if _rows is None:
        return
    have = {(r["workspace_code"], r["name"]) if isinstance(r, dict)
            else (r[0], r[1]) for r in _rows}
    _rows = _fetch_all(cur, "SELECT workspace_code, role, files_json "
                            "FROM studio_agent_defs", is_pg)
    if _rows is None:
        return
    rows = [dict(x) if not isinstance(x, dict) else x for x in _rows]

    # (workspace, skill) -> content_hash -> [count, first_role, files]
    found: dict[tuple[str, str], dict[str, list]] = {}
    carriers: dict[tuple[str, str], set[str]] = {}
    for r in rows:
        ws = r.get("workspace_code") or _PLATFORM_TIER_SYNC
        try:
            files = json.loads(r.get("files_json") or "{}")
        except json.JSONDecodeError:
            continue
        per_skill: dict[str, dict[str, str]] = {}
        for key, text in files.items():
            parts = key.split("/")
            if len(parts) < 3 or parts[0] != "skills":
                continue
            per_skill.setdefault(parts[1], {})["/".join(parts[2:])] = text
        for name, sub in per_skill.items():
            if (ws, name) in have:
                continue
            carriers.setdefault((ws, name), set()).add(r.get("role") or "")
            h = content_hash("", sub)
            bucket = found.setdefault((ws, name), {})
            if h in bucket:
                bucket[h][0] += 1
            else:
                bucket[h] = [1, r.get("role") or "", sub]

    if not found:
        return

    # PLATFORM-SHARED SKILLS ARE NOT THE TENANT'S TO OWN. `data_query`,
    # `guardrails`, `vectorfs_query` and friends come from the agentfarm-skills
    # wheel and are re-seeded into every agent workspace on each
    # ensure_agent_workspace. They arrive in `files_json` because import
    # re-snapshots the LIVE workspace after seeding, and this migration then
    # copied them out into per-tenant `studio_skills` rows — frozen at whatever
    # version existed the day the tenant was created, and never updated by an
    # SDK upgrade again. That is the fork the shared-skills tier exists to
    # prevent, and it happened without anyone choosing it: a scaffolded
    # solution shipping ONE skill ended up with five rows.
    #
    # This migration exists to rescue skills that only ever lived inside agent
    # blobs. A wheel's own skills are not in that category. Resolved lazily —
    # ensure_platform_schema runs on every connection and this point is only
    # reached when there is genuinely something to insert.
    try:
        _, shared_skills = reserved_names()
    except Exception:       # pragma: no cover - registry unavailable
        shared_skills = set()
    if shared_skills:
        for key in [k for k in found if k[1] in shared_skills]:
            found.pop(key, None)
            carriers.pop(key, None)
        if not found:
            return

    ledger: dict[tuple[str, str], dict] = {}
    for x in (_fetch_all(cur, "SELECT workspace_code, name, imported_sha,"
                              " imported_hash, origin FROM"
                              " studio_workspace_items WHERE kind = 'skill'",
                         is_pg) or []):
        d = dict(x) if not isinstance(x, dict) else x
        ledger[(d["workspace_code"], d["name"])] = d

    now = _now()
    for (ws, name), bucket in sorted(found.items()):
        # most carriers first, then first role alphabetically
        _cnt, _role, files = sorted(
            bucket.values(), key=lambda v: (-v[0], v[1]))[0]
        led = ledger.get((ws, name), {})
        _exec_one(cur,
            f"INSERT INTO studio_skills (workspace_code, name, files_json,"
            f" roles_json, content_hash, version, updated_at, imported_sha,"
            f" imported_hash, origin) VALUES ({ph}, {ph}, {ph}, {ph}, {ph},"
            f" 1, {ph}, {ph}, {ph}, {ph})", is_pg,
            (ws, name, json.dumps(files),
             json.dumps(sorted(c for c in carriers[(ws, name)] if c)),
             content_hash("", files), now,
             led.get("imported_sha") or "", led.get("imported_hash") or "",
             led.get("origin") or ""))


# ── content hashing ─────────────────────────────────────────────────

def content_hash(yaml_text: str, files: dict[str, str]) -> str:
    """Canonical hash of one workflow's full content (yaml + prompt files)."""
    h = hashlib.sha256()
    h.update(yaml_text.encode("utf-8"))
    for rel in sorted(files):
        h.update(b"\x00")
        h.update(rel.encode("utf-8"))
        h.update(b"\x01")
        h.update(files[rel].encode("utf-8"))
    return h.hexdigest()


def read_workflow_dir(d: Path) -> tuple[str, dict[str, str]]:
    yaml_text = (d / "workflow.yaml").read_text(encoding="utf-8")
    files: dict[str, str] = {}
    for sub in ("steps", "roles"):
        sd = d / sub
        if sd.is_dir():
            for f in sorted(sd.glob("*.md")):
                files[f"{sub}/{f.name}"] = f.read_text(encoding="utf-8",
                                                       errors="replace")
    return yaml_text, files


#: Identity files captured for an agent — mirrors
#: ``apps/agentfarm-api/app/agent_defs.py::_IDENTITY_FILES`` so the import
#: writes rows the Studio and hydration already understand.
#:
#: ``skills.yaml`` is the AUTHORED carriage declaration
#: (``engine.workspaces.DECLARED_SKILLS_FILE``) — the repo saying, by name,
#: which shared skills this agent holds. Deliberately NOT in
#: :data:`_AGENT_GENERATED` beside its generated sibling: it has to be hashed,
#: or an edit to it classifies as ``unchanged`` and never reaches the database,
#: and it has to be exported, or the round trip loses it.
#: ``USER.md`` and ``HEARTBEAT.md`` are DELIBERATELY ABSENT. The agent runtime
#: scaffolds both into a workspace the first time an agent runs, so they are
#: per-host runtime state like ``memory/`` and ``sessions/`` -- not content any
#: author wrote. Capturing them meant `push` stored them and `pull` then wrote
#: them into the repository, so a converged push followed by a pull left two
#: untracked files behind and made the documented "pull converges" false on the
#: first pull. One of them also carries the runtime's own wording about
#: heartbeat cron, which is not this product's to publish into a customer repo.
_AGENT_IDENTITY_FILES = ("SOUL.md", "AGENTS.md", "TOOLS.md", "a2a-card.yaml",
                         ".studio-created", ".skills-assigned.json",
                         "skills.yaml")
_AGENT_SKIP_SUFFIXES = (".pyc", ".pyo", ".exe", ".dll", ".so")
_AGENT_SKIP_NAMES = (".materialized",)

#: EXCLUDED FROM THE DIVERGENCE HASH (but still stored). Both entries are
#: GENERATED PER HOST, so hashing them reports a permanent false divergence:
#:
#: * ``AGENTS.md`` — regenerated by ``_generate_agents_md`` on every
#:   ``ensure_agent_workspace`` from the LOCAL agent roster, which differs per
#:   tenant, so every agent would look 'diverged' after a single run.
#: * ``.skills-assigned.json`` — the shared-skill assignment record, written by
#:   ``ensure_agent_workspace``. A repo checkout never contains one (no author
#:   writes it), so hashing it would make EVERY imported agent diverge against
#:   its own repo the moment it was first seeded, and the fail-closed import
#:   gate would refuse the next import of a repo nobody had touched.
#: * ``.platform-skills.json`` — the record of what the platform placed into
#:   ``skills/``, written by ``ensure_agent_workspace`` so a later seed can
#:   tell "the platform withdrew this" from "something else put this here".
#:   Generated for exactly the same reason as the line above, and excluded for
#:   exactly the same reason: no repo checkout contains one.
_AGENT_GENERATED = ("AGENTS.md", ".skills-assigned.json",
                    ".platform-skills.json")


def read_agent_dir(role_dir: Path) -> dict[str, str]:
    """An agent's content from a repo checkout: identity files + skills/**.

    Same file set as the Studio's ``snapshot_workspace_files`` (which reads a
    LIVE workspace), so a repo agent and a Studio-edited one are directly
    comparable. ``memory/``, ``sessions/`` and ``metadata/`` are excluded
    structurally by never being traversed — they are runtime state, not
    content, and must never make an agent look diverged.
    """
    ws = role_dir / "workspace"
    files: dict[str, str] = {}
    for name in _AGENT_IDENTITY_FILES:
        f = ws / name
        if f.is_file():
            v = encode_file(f)
            if v is not None:
                files[name] = v
    skills = ws / "skills"
    if skills.is_dir():
        for f in sorted(skills.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(ws)
            if "__pycache__" in rel.parts or f.suffix in _AGENT_SKIP_SUFFIXES \
                    or f.name in _AGENT_SKIP_NAMES:
                continue
            v = encode_file(f)
            if v is not None:
                files[rel.as_posix()] = v
    return files


def exportable_agent_files(files: dict[str, str], skip_skills: set[str]
                           ) -> dict[str, str]:
    """The subset of a live agent snapshot the SOLUTION REPO may own.

    ``studio_agent_defs.files_json`` is a snapshot of the LIVE workspace, so it
    contains two categories of file the repo never declared — the same two
    :func:`agent_content_hash` already excludes from the divergence
    comparison. The comparison was restricted; the EXPORT was not, and it wrote
    them into the repo:

        $ aicore workspace pull logistics
        exported 1 item(s)
        $ git status --short
        ?? .../logistics_analyst/workspace/skills/data_query/
        ?? .../logistics_analyst/workspace/skills/guardrails/
        ?? .../logistics_analyst/workspace/skills/vectorfs_query/

    Those three are SHARED SKILLS from the ``agentfarm-skills`` wheel, seeded
    into every agent workspace by the shared-skill rule. ``git add -A`` — the
    obvious next move, and the one the export message invites ("review and
    commit in git") — vendors a frozen fork of the SDK's own skills into a
    domain repo. They then never receive an upstream improvement, and the
    importer writes tenant-owned ``studio_skills`` rows for them. Nobody chose
    any of that; the platform's own export command did it.

    *skip_skills* additionally covers skills the manifest declares as
    standalone directories: those export through the skills path, and writing a
    second copy inside an agent workspace changes what decides their
    assignment (location, rather than their ``roles:`` frontmatter).

    ``AGENTS.md`` stays excluded — it is regenerated per host from the local
    agent roster, so exporting it commits one machine's view of the world.
    """
    out: dict[str, str] = {}
    for rel, content in files.items():
        if rel in _AGENT_GENERATED:
            continue
        parts = rel.split("/")
        if len(parts) >= 2 and parts[0] == "skills" and parts[1] in skip_skills:
            continue
        out[rel] = content
    return out


def agent_content_hash(files: dict[str, str],
                       only: set[str] | None = None) -> str:
    """Divergence hash for an agent — over the files the REPO owns.

    Deliberately NOT ``studio_agent_defs.content_hash``: that is ``files_hash``
    over the whole snapshot, which includes three categories of file the repo
    never declared, all of which would otherwise report a permanent false
    divergence:

    * ``AGENTS.md`` — regenerated from the LOCAL agent roster on every
      ``ensure_agent_workspace``, and the roster differs per tenant.
    * ``.skills-assigned.json`` — the shared-skill assignment record, written
      by ``ensure_agent_workspace``. No repo author writes one.
    * platform-seeded skills — ``data_query``, ``guardrails`` and friends are
      seeded into agent workspaces from the shared sources, so a Studio save
      captures them into the row even though they are the platform's content,
      not the solution's.

    Passing *only* (the repo's key set) restricts the comparison to the files
    the solution actually ships. A file the repo declares but the DB lacks
    still diverges, because the key sets then differ.
    """
    subset = {k: v for k, v in files.items() if k not in _AGENT_GENERATED}
    if only is not None:
        subset = {k: v for k, v in subset.items() if k in only}
    return content_hash("", subset)


def read_skill_dir(d: Path) -> dict[str, str]:
    """One skill directory's files, keyed relative to the skill root.

    Binary-safe: a skill's ``assets/logo.png`` survives the DB round trip
    (base64 behind a sentinel) instead of arriving as U+FFFD soup.
    """
    files: dict[str, str] = {}
    for f in sorted(d.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(d)
        if "__pycache__" in rel.parts or f.suffix in _AGENT_SKIP_SUFFIXES \
                or f.name in _AGENT_SKIP_NAMES:
            continue
        v = encode_file(f)
        if v is not None:
            files[rel.as_posix()] = v
    return files


# ── repo binding + git ──────────────────────────────────────────────

#: URL forms that are REMOTE and must not be checked against the filesystem:
#: a scheme (`https://`, `ssh://`, `file://`) or scp-style `git@host:path`.
_REMOTE_URL = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*://|^[^/\\]+@[^/\\]+:")


def looks_local(url: str) -> bool:
    """Is this `--url` a filesystem path rather than a remote?

    :func:`resolve_repo_tree` decides the same way, by falling through to a
    clone when the path is not a directory. That fallthrough is why a typo'd
    or non-existent path reaches git as a REMOTE and comes back as "does not
    appear to be a git repository" -- an error about the wrong thing, two
    commands after the mistake.
    """
    return bool(url) and not _REMOTE_URL.search(url.strip())


def local_repo_problem(url: str) -> str:
    """Why this local `--url` cannot be imported from, or "" if it is fine.

    Checked at ATTACH time. Attach used to accept anything and report success,
    so the first sign of a wrong path was a git failure during `diff` or
    `push`, naming a cause that was not the cause.
    """
    if not looks_local(url):
        return ""
    p = Path(url.strip())
    if not p.exists():
        return f"{p} does not exist"
    if not p.is_dir():
        return f"{p} is not a directory"
    if find_manifest(p) is None and not (p / ".git").exists():
        return (f"{p} is neither a git repository nor a solution repo "
                f"(no .git and no {MANIFEST_NAME})")
    return ""


def attach_repo(code: str, repo_url: str, branch: str = "main",
                credential_ref: str = "") -> dict:
    with connected() as (adapter, con):
        clone_path = str(_iof_root() / "workspaces" / code / "repo")
        cur = con.cursor()
        cur.execute(_q(adapter,
            "INSERT INTO studio_workspace_repos (workspace_code, repo_url, branch,"
            " credential_ref, clone_path, updated_at) VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT (workspace_code) DO UPDATE SET repo_url = excluded.repo_url,"
            " branch = excluded.branch, credential_ref = excluded.credential_ref,"
            " clone_path = excluded.clone_path, updated_at = excluded.updated_at"),
            (code, repo_url, branch, credential_ref, clone_path, _now()))
        try:
            con.commit()
        except Exception:
            pass
        return {"workspace_code": code, "repo_url": repo_url, "branch": branch,
                "credential_ref": credential_ref, "clone_path": clone_path}


def get_repo(code: str) -> dict | None:
    with connected() as (adapter, con):
        cur = con.cursor()
        cur.execute(_q(adapter,
            "SELECT workspace_code, repo_url, branch, credential_ref, clone_path,"
            " last_sha, last_imported_at, last_exported_at "
            "FROM studio_workspace_repos WHERE workspace_code = ?"), (code,))
        row = cur.fetchone()
        return dict(row) if row else None


def _authed_url(repo_url: str, credential_ref: str) -> str:
    """Inject the credential (resolved from env AT CALL TIME) into an https
    URL for the one subprocess invocation. Never persisted anywhere — after
    a clone the remote is reset to the clean URL."""
    token = (os.getenv(credential_ref) or "").strip() if credential_ref else ""
    if not token or "://" not in repo_url:
        return repo_url
    scheme, rest = repo_url.split("://", 1)
    if "@" in rest.split("/", 1)[0]:
        return repo_url  # URL already carries userinfo — respect it
    return f"{scheme}://oauth2:{token}@{rest}"


def _git(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], cwd=str(cwd) if cwd else None,
                          capture_output=True, text=True, timeout=600,
                          encoding="utf-8", errors="replace")


def resolve_repo_tree(repo_row: dict, keep_tree: bool = False) -> tuple[Path, str]:
    """Return (checkout root, sha) for the workspace's solution repo.

    * local-directory repo_url -> used in place (dev / CI-mounted).
    * remote url -> clone into clone_path once; later imports fetch+reset,
      but ONLY on a clean tree — a dirty tree (un-committed export output)
      is refused unless keep_tree, which imports from the tree as-is.
    """
    url = repo_row["repo_url"]
    local = Path(url)
    if local.is_dir():
        sha = ""
        if (local / ".git").exists():
            r = _git(["rev-parse", "HEAD"], cwd=local)
            sha = r.stdout.strip() if r.returncode == 0 else ""
        return local, sha or "local"

    dest = Path(repo_row["clone_path"] or (_iof_root() / "workspaces"
                / repo_row["workspace_code"] / "repo"))
    branch = repo_row.get("branch") or "main"
    authed = _authed_url(url, repo_row.get("credential_ref") or "")

    if not (dest / ".git").is_dir():
        dest.parent.mkdir(parents=True, exist_ok=True)
        r = _git(["clone", "--branch", branch, authed, str(dest)])
        if r.returncode != 0:
            raise RuntimeError(f"git clone failed: {r.stderr.strip()[:400]}")
        # scrub the credential from the persisted remote
        _git(["remote", "set-url", "origin", url], cwd=dest)
    elif not keep_tree:
        status = _git(["status", "--porcelain"], cwd=dest)
        if status.stdout.strip():
            raise RuntimeError(
                "clone working tree has uncommitted changes (likely a prior "
                "`workspace pull`). Commit/discard them in "
                f"{dest}, or re-run with --keep-tree to import from the tree as-is.")
        _git(["remote", "set-url", "origin", authed], cwd=dest)
        try:
            r = _git(["fetch", "origin", branch], cwd=dest)
            if r.returncode != 0:
                raise RuntimeError(f"git fetch failed: {r.stderr.strip()[:400]}")
            r = _git(["checkout", "-B", branch, f"origin/{branch}"], cwd=dest)
            if r.returncode != 0:
                raise RuntimeError(f"git checkout failed: {r.stderr.strip()[:400]}")
        finally:
            _git(["remote", "set-url", "origin", url], cwd=dest)

    r = _git(["rev-parse", "HEAD"], cwd=dest)
    return dest, (r.stdout.strip() if r.returncode == 0 else "")


# ── reserved (platform-shared) names ───────────────────────────────

#: The platform tier a solution repo may never shadow: core's own agents
#: (Jarvis, Quinn, Alex) and the shared-skills wheel. DOMAIN packs are
#: deliberately absent — a solution that is both pip-installed as a pack
#: (engine runtime) and imported as a repo (studio catalog) is the SAME
#: solution twice, not a shadow; reserving every installed pack's names
#: made a solution's import reject itself.
_PLATFORM_PACKS = {"core", "skills"}


def reserved_names() -> tuple[set[str], set[str]]:
    """(platform agent roles, platform shared skill names) a solution may
    not shadow. Core pack + the shared-skills pack ONLY — never domain
    packs; failures degrade to empty sets (validation then only guards
    structure, honestly logged by the caller)."""
    agents: set[str] = set()
    skills: set[str] = set()
    try:
        from ioagentfarm.packs import load_registry
        reg = load_registry()
        for pack in reg.packs:
            if pack.name not in _PLATFORM_PACKS:
                continue
            if pack.agents is not None:
                try:
                    for entry in pack.agents.iterdir():
                        name = getattr(entry, "name", "")
                        if name.startswith(("_", ".")):
                            continue
                        ws = entry / "workspace"
                        try:
                            if (ws / "SOUL.md").is_file():
                                agents.add(name)
                        except Exception:
                            continue
                except Exception:
                    pass
            if pack.skills is not None:
                try:
                    for entry in pack.skills.iterdir():
                        try:
                            if (entry / "SKILL.md").is_file():
                                skills.add(entry.name)
                        except Exception:
                            continue
                except Exception:
                    pass
    except Exception:
        pass
    return agents, skills


# ── classification ─────────────────────────────────────────────────

#: action -> is it applied by a default (non --take-repo) import?
#: "reconciled" = repo and DB carry IDENTICAL content that both drifted from
#: the last import (the normal state right after `workspace pull` + commit)
#: — nothing to overwrite, just re-anchor imported_sha/imported_hash.
APPLY_DEFAULT = {"added": True, "updated": True, "unchanged": False,
                 "reconciled": True, "diverged": False,
                 "diverged-local": False, "studio-owned": False,
                 "orphaned": False}


def classify_workflows(adapter, con, code: str, manifest: SolutionManifest,
                       sha: str) -> list[dict]:
    cur = con.cursor()
    cur.execute(_q(adapter,
        "SELECT code, yaml, files_json, origin, imported_hash "
        "FROM studio_workflow_defs WHERE workspace_code = ?"), (code,))
    db_rows = {r["code"] if isinstance(r, dict) else dict(r)["code"]:
               (r if isinstance(r, dict) else dict(r)) for r in cur.fetchall()}

    items: list[dict] = []
    repo_dirs = manifest.workflow_dirs()
    for wf_code, d in sorted(repo_dirs.items()):
        yaml_text, files = read_workflow_dir(d)
        repo_hash = content_hash(yaml_text, files)
        row = db_rows.pop(wf_code, None)
        item = {"kind": "workflow", "name": wf_code, "repo_hash": repo_hash,
                "yaml": yaml_text, "files": files, "sha": sha}
        if row is None:
            item["action"] = "added"
        elif row["origin"] == "studio":
            item["action"] = "studio-owned"
        else:
            db_hash = content_hash(row["yaml"],
                                   json.loads(row["files_json"] or "{}"))
            clean = bool(row["imported_hash"]) and db_hash == row["imported_hash"]
            repo_changed = repo_hash != row["imported_hash"]
            if clean and not repo_changed:
                item["action"] = "unchanged"
            elif clean:
                item["action"] = "updated"
            elif repo_hash == db_hash:
                # both drifted to IDENTICAL content (export -> commit ->
                # import round trip): nothing to overwrite — re-anchor the
                # import markers so the two directions agree.
                item["action"] = "reconciled"
            elif not repo_changed:
                # Studio edited it; the repo still matches the last import —
                # nothing new to bring. DB stays authoritative, reported.
                item["action"] = "diverged-local"
            else:
                item["action"] = "diverged"
        items.append(item)

    # DB rows the manifest does not declare: studio-created items are
    # reported (and never touched); repo-origin leftovers are orphans —
    # NEVER deleted silently, reported so an operator can decide.
    for wf_code, row in sorted(db_rows.items()):
        action = "studio-owned" if row["origin"] == "studio" else "orphaned"
        items.append({"kind": "workflow", "name": wf_code, "action": action})
    return items


def _item_ledger(adapter, con, code: str, kind: str) -> dict[str, dict]:
    """``studio_workspace_items`` rows for one kind, keyed by name.

    This table has been written since the first import and read by NOTHING.
    Workflows carry their own mirrored ``imported_hash``/``origin`` columns on
    ``studio_workflow_defs``; agents and skills have no such columns, so this
    is where their import anchor lives — which is exactly what the table was
    created for.
    """
    cur = con.cursor()
    cur.execute(_q(adapter,
        "SELECT name, imported_sha, imported_hash, origin "
        "FROM studio_workspace_items WHERE workspace_code = ? AND kind = ?"),
        (code, kind))
    out: dict[str, dict] = {}
    for r in cur.fetchall():
        row = r if isinstance(r, dict) else dict(r)
        out[row["name"]] = row
    return out


def _classify_one(name: str, kind: str, repo_hash: str,
                  db_hash: str | None, ledger: dict | None,
                  extra: dict) -> dict:
    """The shared decision table — identical semantics for every kind.

    Mirrors ``classify_workflows`` exactly so an agent and a workflow behave
    the same way under the nothing-erases gate.
    """
    item = {"kind": kind, "name": name, "repo_hash": repo_hash, **extra}
    if db_hash is None:
        item["action"] = "added"
        return item
    if ledger and ledger.get("origin") == "studio":
        item["action"] = "studio-owned"
        return item
    imported = (ledger or {}).get("imported_hash") or ""
    clean = bool(imported) and db_hash == imported
    repo_changed = repo_hash != imported
    if clean and not repo_changed:
        item["action"] = "unchanged"
    elif clean:
        item["action"] = "updated"
    elif repo_hash == db_hash:
        item["action"] = "reconciled"
    elif not repo_changed:
        item["action"] = "diverged-local"
    else:
        item["action"] = "diverged"
    return item


def _repo_skill_roots(manifest: SolutionManifest) -> list[Path]:
    """Every root in the CHECKOUT a declared skill name can resolve against.

    An import reads a repo that may not be pip-installed in this environment —
    it is a working tree, not a wheel — so its own ``skills/`` root is in no
    pack registry. Without these, every declaration in a repo being imported
    for the first time would read as unresolvable and the import would refuse
    a perfectly correct solution.
    """
    roots: list[Path] = list(manifest.skills_roots)
    for _role, d in manifest.agent_dirs().items():
        sk = d / "workspace" / "skills"
        if sk.is_dir():
            roots.append(sk)
    for _name, (d, _roles) in manifest.injected_skills().items():
        roots.append(d.parent)
    return roots


def classify_agents(adapter, con, code: str, manifest: SolutionManifest,
                    sha: str) -> list[dict]:
    """Repo agents vs this tenant's ``studio_agent_defs`` rows.

    Also the FAIL-LOUD point for carriage declarations. A ``skills.yaml``
    naming a skill nothing can supply refuses the whole batch here — before a
    single row is written, and from ``workspace diff`` as well as
    ``workspace push``, so the operator sees it in the preview. The seed-time
    check in ``ensure_agent_workspace`` is the backstop for the path that never
    goes near an import (a locally installed pack + ``setup-agents``).
    """
    from ioagentfarm.engine.workspaces import (
        SkillDeclarationError, resolve_declared_skills)

    cur = con.cursor()
    cur.execute(_q(adapter,
        "SELECT role, files_json FROM studio_agent_defs "
        "WHERE workspace_code = ?"), (code,))
    db_rows: dict[str, dict] = {}
    for r in cur.fetchall():
        row = r if isinstance(r, dict) else dict(r)
        db_rows[row["role"]] = row
    ledger = _item_ledger(adapter, con, code, "agent")

    items: list[dict] = []
    repo_roots = _repo_skill_roots(manifest)
    declaration_problems: list[str] = []
    for role, role_dir in sorted(manifest.agent_dirs().items()):
        files = read_agent_dir(role_dir)
        if "SOUL.md" not in files:
            # Same guard as upsert_agent_def: not a complete workspace.
            continue
        try:
            resolve_declared_skills(role_dir / "workspace", role,
                                    extra_roots=repo_roots)
        except SkillDeclarationError as exc:
            declaration_problems.append(str(exc))
        row = db_rows.pop(role, None)
        # Compare over the repo's key set: the live row also carries
        # platform-seeded skills and a regenerated AGENTS.md that the
        # solution never declared.
        repo_keys = set(files)
        db_hash = None
        if row is not None:
            db_hash = agent_content_hash(
                json.loads(row["files_json"] or "{}"), only=repo_keys)
        items.append(_classify_one(
            role, "agent", agent_content_hash(files, only=repo_keys), db_hash,
            ledger.get(role), {"files": files, "sha": sha}))

    # Every bad declaration at once, like every other manifest problem — one
    # per import round is how a five-typo repo takes five imports to fix.
    if declaration_problems:
        raise ManifestError(declaration_problems)

    for role, _row in sorted(db_rows.items()):
        led = ledger.get(role) or {}
        action = "orphaned" if led.get("origin") == "repo" else "studio-owned"
        items.append({"kind": "agent", "name": role, "action": action})
    return items


def classify_skills(adapter, con, code: str, manifest: SolutionManifest,
                    sha: str) -> list[dict]:
    """Repo skills vs their DB rows.

    Skills round-trip like agents and workflows now that ``studio_skills``
    gives each one a content row: a Studio edit moves that row's hash, so this
    reports it as diverged and the nothing-erases gate refuses the import by
    name. Before the table, the 'db' side was the derived staging dir, which a
    Studio edit never touched — so a Studio-side change was structurally
    invisible here and could be silently overwritten.

    The staging dir stays as the fallback for a database that predates the
    table, so an import against an un-migrated schema still classifies rather
    than reporting every skill as new.
    """
    ledger = _item_ledger(adapter, con, code, "skill")
    staged_root = _iof_root() / "workspaces" / code / "skills"

    db_hashes: dict[str, str] = {}
    try:
        cur = con.cursor()
        cur.execute(_q(adapter, "SELECT name, content_hash, files_json "
                                "FROM studio_skills WHERE workspace_code = ?"),
                    (code,))
        for r in cur.fetchall():
            d = r if isinstance(r, dict) else dict(r)
            # AN ASSIGNMENT-ONLY ROW HOLDS NO CONTENT, so it cannot have
            # diverged from content. `setup-agents` writes one for every skill
            # an agent carries (`origin='pack'`, `files_json='{}'`) -- carriage
            # is a tenant fact and has to be durable -- and its hash is the
            # hash of an empty file set, which matches no repository skill.
            # With no import marker either, `_classify_one` then read "both
            # sides differ" as `diverged` and push REFUSED skills nobody had
            # touched, on a workspace whose only history was a seed. Skipping
            # the row leaves the staged-directory fallback to answer, which is
            # what it did before the table existed.
            try:
                empty = not (json.loads(d.get("files_json") or "{}") or {})
            except Exception:
                empty = False
            if empty:
                continue
            db_hashes[d["name"]] = d.get("content_hash") or ""
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass

    items: list[dict] = []
    for name, d in sorted(manifest.skill_dirs().items()):
        files = read_skill_dir(d)
        db_hash = db_hashes.get(name)
        if db_hash is None:
            staged = staged_root / name
            if staged.is_dir():
                db_hash = content_hash("", read_skill_dir(staged))
        items.append(_classify_one(
            name, "skill", content_hash("", files), db_hash,
            ledger.get(name), {"files": files, "sha": sha}))
    return items


def classify_items(adapter, con, code: str, manifest: SolutionManifest,
                   sha: str) -> list[dict]:
    """Every declared kind, in one list, under one gate.

    SWARMS are deliberately absent: push/diff accept a manifest that
    declares them and simply do not carry them yet — the runtime reads
    swarms from installed packs and the override tree, not the database.
    DB round-trip is the documented follow-up (docs/swarms.md).
    """
    return (classify_workflows(adapter, con, code, manifest, sha)
            + classify_agents(adapter, con, code, manifest, sha)
            + classify_skills(adapter, con, code, manifest, sha))


# ── lock ────────────────────────────────────────────────────────────

def _lock_path(code: str) -> Path:
    return _iof_root() / "workspaces" / code / ".sync.lock"


class SyncLock:
    def __init__(self, code: str):
        self.path = _lock_path(code)

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            age = time.time() - self.path.stat().st_mtime
            if age < _LOCK_STALE_S:
                raise RuntimeError(
                    f"another sync holds the lock for this workspace "
                    f"({self.path}, {int(age)}s old). Retry later, or delete "
                    "the lock if the other sync crashed.")
        self.path.write_text(str(os.getpid()), encoding="utf-8")
        return self

    def __exit__(self, *_exc):
        try:
            self.path.unlink()
        except OSError:
            pass


# ── import / diff / export ─────────────────────────────────────────

def _load_and_validate(code: str, keep_tree: bool) -> tuple[SolutionManifest, Path, str, dict]:
    repo_row = get_repo(code)
    if not repo_row:
        raise RuntimeError(
            f"workspace '{code}' has no repo attached — run "
            f"`aicore workspace attach {code} --url <git-url>` first")
    tree, sha = resolve_repo_tree(repo_row, keep_tree=keep_tree)
    manifest = load_manifest(tree)          # raises ManifestError (all problems)
    r_agents, r_skills = reserved_names()
    shadow = validate_reserved(manifest, r_agents, r_skills)
    if shadow:
        raise ManifestError(shadow)
    return manifest, tree, sha, repo_row


def diff_workspace(code: str, keep_tree: bool = False) -> dict:
    manifest, _tree, sha, _repo = _load_and_validate(code, keep_tree)
    with connected() as (adapter, con):
        # Every kind the import gates on — a preview that showed only workflows
        # told the operator an import was clean while a diverged agent or skill
        # was about to refuse the whole batch.
        items = classify_items(adapter, con, code, manifest, sha)
        return _report(code, sha, items)


def _report(code: str, sha: str, items: list[dict]) -> dict:
    counts: dict[str, int] = {}
    for it in items:
        counts[it["action"]] = counts.get(it["action"], 0) + 1
    return {
        "workspace": code,
        "sha": sha,
        "counts": counts,
        "items": [{"kind": i["kind"], "name": i["name"], "action": i["action"]}
                  for i in items],
    }


def _materialize_workflow(code: str, wf_code: str, yaml_text: str,
                          files: dict[str, str]) -> None:
    """Derived engine-format tree the workspace pack serves to the loader."""
    root = _iof_root() / "workspaces" / code / "workflows" / wf_code
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True, exist_ok=True)
    (root / "workflow.yaml").write_text(yaml_text, encoding="utf-8")
    for rel, content in files.items():
        write_file(root / rel, content)


def _backup_row(code: str, ts: str, wf_code: str, row: dict) -> Path:
    dest = _iof_root() / "workspaces" / code / ".backups" / ts / "workflows" / wf_code
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "workflow.yaml").write_text(row["yaml"], encoding="utf-8")
    for rel, content in json.loads(row["files_json"] or "{}").items():
        write_file(dest / rel, content)
    return dest


def _backup_agent(code: str, ts: str, role: str, row: dict) -> Path:
    """Snapshot the DB's agent content before --take-repo overwrites it.

    The kind segment mirrors the workflow path, so `.backups/<ts>/` reads as
    an inventory of everything a forced import replaced.
    """
    dest = _iof_root() / "workspaces" / code / ".backups" / ts / "agents" / role
    dest.mkdir(parents=True, exist_ok=True)
    for rel, content in json.loads(row.get("files_json") or "{}").items():
        write_file(dest / rel, content)
    return dest


def _backup_skill(code: str, ts: str, name: str,
                  row: dict | None = None) -> Path | None:
    """Snapshot the DB's skill content before --take-repo overwrites it.

    THE ROW, NOT THE STAGED DIRECTORY. This copied
    ``<IOF_ROOT>/workspaces/<code>/skills/<name>``, which is DERIVED: it holds
    whatever was last materialised, and a Studio edit moves the database row
    without touching it. So in the one case this exists for -- overwriting an
    edit somebody else made in the Studio -- it preserved the stale local copy
    and the edit being destroyed was not saved anywhere, while the command
    reported "prior DB content ... snapshotted".

    Proven by editing a skill in the database and in the repo, then running
    `workspace push --take-repo --only <name>`: the backup came back holding
    the previous REPO text, with the database's version absent.

    `_backup_agent` already read its row; this is the same thing for skills.
    The staged directory remains the fallback for a row that carries no
    content of its own (an assignment-only pack row is ``files_json = '{}'``).
    """
    dest = _iof_root() / "workspaces" / code / ".backups" / ts / "skills" / name
    files = {}
    if row:
        try:
            files = json.loads(row.get("files_json") or "{}") or {}
        except (TypeError, ValueError):
            files = {}
    if files:
        dest.mkdir(parents=True, exist_ok=True)
        for rel, content in files.items():
            write_file(dest / rel, content)
        return dest
    src = _iof_root() / "workspaces" / code / "skills" / name
    if not src.is_dir():
        return None
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dest, dirs_exist_ok=True)
    return dest


def _files_hash(files: dict[str, str]) -> str:
    """The hash the Studio stores in ``studio_agent_defs.content_hash``.

    Imported rows must carry the SAME hash the Studio would write, or the
    next Studio save would look like a change when nothing moved. Falls back
    to the local implementation when core's hydration module is unavailable.
    """
    try:
        from ioagentfarm.engine.hydration import files_hash
        return files_hash(files)
    except Exception:      # pragma: no cover - defensive
        return content_hash("", files)


def _upsert_item(adapter, cur, code: str, kind: str, name: str,
                 sha: str, repo_hash: str) -> None:
    """Re-anchor an item's import markers in ``studio_workspace_items``."""
    cur.execute(_q(adapter,
        "INSERT INTO studio_workspace_items (workspace_code, kind, name,"
        " imported_sha, imported_hash, origin, updated_at) "
        "VALUES (?, ?, ?, ?, ?, 'repo', ?) "
        "ON CONFLICT (workspace_code, kind, name) DO UPDATE SET"
        " imported_sha = excluded.imported_sha,"
        " imported_hash = excluded.imported_hash,"
        " updated_at = excluded.updated_at"),
        (code, kind, name, sha, repo_hash, _now()))


def _anchor_pulled_item(adapter, cur, code: str, kind: str, name: str,
                        sha: str, pulled_hash: str) -> None:
    """Record that the REPO now holds what the database holds.

    WITHOUT THIS A PULL NEVER CONVERGES. Drift is
    ``origin != 'repo' or hash != imported_hash``, and a pull wrote the files
    but left both markers alone -- so an item edited in the Studio stayed
    ``origin='studio'`` forever. Every subsequent `diff` reported it as
    diverged and every subsequent `pull` rewrote the identical bytes, which
    is indistinguishable from a pull that silently does nothing.

    ``_upsert_item`` cannot serve here: its ``DO UPDATE`` deliberately leaves
    ``origin`` untouched, because an import must not claim authorship of
    content the Studio edited. A pull is the one operation that legitimately
    resets it -- the repo has just received that content, so the repo is now
    where it comes from.
    """
    cur.execute(_q(adapter,
        "INSERT INTO studio_workspace_items (workspace_code, kind, name,"
        " imported_sha, imported_hash, origin, updated_at) "
        "VALUES (?, ?, ?, ?, ?, 'repo', ?) "
        "ON CONFLICT (workspace_code, kind, name) DO UPDATE SET"
        " imported_sha = excluded.imported_sha,"
        " imported_hash = excluded.imported_hash,"
        " origin = 'repo',"
        " updated_at = excluded.updated_at"),
        (code, kind, name, sha, pulled_hash, _now()))


def _scope_workspace_to_solution(adapter, cur, code: str, solution: str) -> bool:
    """Give a workspace its catalog scoping row, if it has none. True if written.

    A workspace with no ``studio_workspace_settings`` row is UNSCOPED, and the
    Studio then lists every installed pack's agents in it — pharma agents in a
    logistics tenant. Rows existed only for two hard-coded demo tenants, so
    every workspace anyone actually created was in that state, and the symptom
    appeared right after a *successful* import, which reads as the import
    having done something wrong.

    Importing a solution repo IS the moment a tenant becomes "the <solution>
    workspace", so that is where the scope belongs.

    NEVER OVERWRITES a CURATED row: a deployment that curates a tenant to
    several packs, or excludes one, has made a deliberate choice that a routine
    re-import must not silently undo.

    An EMPTY row is not curation. Workspace creation now seeds one, so that
    an un-imported workspace is scoped to nothing rather than to everything
    (an absent row means unscoped). Treating that placeholder as a deliberate
    choice would make import stop scoping the very workspaces it fills — the
    empty row would be permanent and the tenant would never see its own
    solution. So the claim is: write when there is no row, or when the row
    carries neither an include nor an exclude.
    """
    if not solution or code == _PLATFORM_TIER_SYNC:
        return False
    cur.execute(_q(adapter, "SELECT include_packs, exclude_packs FROM "
                            "studio_workspace_settings WHERE workspace_code = ?"),
                (code,))
    row = cur.fetchone()
    if row is not None:
        existing = row if isinstance(row, dict) else dict(row)
        curated = (existing.get("include_packs") or "").strip() or \
                  (existing.get("exclude_packs") or "").strip()
        if curated:
            return False
        cur.execute(_q(adapter,
            "UPDATE studio_workspace_settings SET include_packs = ?,"
            " updated_at = ? WHERE workspace_code = ?"),
            (solution, _now(), code))
        return True
    cur.execute(_q(adapter,
        "INSERT INTO studio_workspace_settings (workspace_code, include_packs,"
        " exclude_packs, updated_at) VALUES (?, ?, '', ?)"),
        (code, solution, _now()))
    return True


def _pack_agent_roles() -> dict[str, set[str]]:
    """``{pack name: roles it ships}`` — agent dirs carrying a ``SOUL.md``.

    Read from the registry rather than from a directory scan of an agent home,
    so it answers "who does this pack contribute?" the same way on a host with
    no state at all. Degrades to ``{}`` (registry unavailable) — the caller then
    falls back to the roles the DATABASE names, which is the tier that matters.
    """
    out: dict[str, set[str]] = {}
    try:
        from ioagentfarm.packs import load_registry
        packs = load_registry().packs
    except Exception:                       # pragma: no cover - registry gone
        logger.debug("pack registry unavailable for the agent roster",
                     exc_info=True)
        return out
    for pack in packs:
        if pack.agents is None:
            continue
        names: set[str] = set()
        try:
            for entry in pack.agents.iterdir():
                name = getattr(entry, "name", "")
                if not name or name.startswith(("_", ".")):
                    continue
                try:
                    if (entry / "workspace" / "SOUL.md").is_file():
                        names.add(name)
                except OSError:
                    continue
        except Exception:
            continue
        if names:
            out[pack.name] = out.get(pack.name, set()) | names
    return out


def _desk_side_root():
    """The checkout this process is working in, or ``None`` on a server.

    TWO SIGNALS, BECAUSE THERE ARE TWO DESK-SIDE SESSIONS AND ONLY ONE OF
    THEM USED TO COUNT:

    * ``IOF_BUILD_REPO`` — an ``aicore build`` session, which records the
      repository it opened. Checked FIRST and used as the root, because the
      builder places content at the REPO root whatever the current
      directory is; cwd would be the less precise answer.
    * local mode — ``aicore local on``, where this directory is the source
      of truth for state as well as content. Then the root is cwd.

    LOCAL MODE ALONE WAS THE GATE, AND IT ANSWERS A DIFFERENT QUESTION.
    ``IOF_LOCAL`` says where STATE lives — a SQLite file in this directory,
    or the configured database. What this function needs to know is where
    CONTENT lives. A developer running ``aicore build`` against a
    database-backed workspace has both at once, content in their checkout
    and state in the database, and the gate refused: ``workspace_agent_roles``
    then returned the platform tier and nothing else, so the builder
    reported that it could only see platform agents (2026-09-04).
    Reproduced at SIX roles against sixteen — same workspace, same
    database, same directory, same installed packs, ``IOF_LOCAL`` the only
    difference.

    A server sets neither variable, so its roster is unchanged. That is the
    property the original gate was protecting, and it is protected here by
    asking about the session rather than about the storage mode.
    """
    import os as _os
    from pathlib import Path as _Path

    from ioagentfarm.engine.workspaces import _local_mode_on

    repo = (_os.environ.get("IOF_BUILD_REPO") or "").strip()
    if repo:
        try:
            return _Path(repo).resolve()
        except OSError:                      # pragma: no cover - defensive
            return None
    if not _local_mode_on():
        return None
    try:
        return _Path.cwd().resolve()
    except OSError:                          # pragma: no cover - defensive
        return None


def _local_pack_names() -> set[str]:
    """Packs whose content lives under the directory this session works in.

    THE WORKSPACE BEING BUILT HERE OWNS THEM, WHATEVER THEY ARE CALLED. Name
    equality cannot answer that question: the documented flow is `workspace
    create pharma_comm` followed by `new-solution pharma_comm_sol`, so the
    pack name and the workspace code differ BY DESIGN and a `Pack.name ==
    code` match never fires for anyone following the guide. The symptom is
    a seeding pass taking only the platform's agents and announcing
    "workspace has no agents of its own" while the reader is looking at the
    two they just created — with the printed remedy, `workspace push`,
    failing because nothing is attached yet.

    Scoped to a desk-side session by :func:`_desk_side_root`, which is what
    keeps a server's roster untouched.
    """
    from pathlib import Path as _Path

    cwd = _desk_side_root()
    if cwd is None:
        return set()
    out: set[str] = set()
    try:
        from ioagentfarm.packs import load_registry
        packs = load_registry().packs
    except Exception:                        # pragma: no cover - registry gone
        return out
    for pack in packs:
        for root in (pack.agents, pack.skills, pack.workflows):
            if root is None:
                continue
            try:
                p = _Path(str(root)).resolve()
            except (OSError, TypeError, ValueError):
                continue
            if p == cwd or cwd in p.parents:
                out.add(pack.name)
                break
    return out


def workspace_pack_scope(adapter, con, code: str) -> tuple[list[str], list[str], bool]:
    """``(include, exclude, scoped)`` for *code* from ``studio_workspace_settings``.

    *scoped* is False only when the workspace has NO ROW — the one state that
    means "every installed pack". An EMPTY row means the opposite ("no solution
    packs yet"), which is what a created-but-never-imported workspace carries;
    the API reads the same two states the same way (``workspace_settings``).
    """
    try:
        cur = con.cursor()
        cur.execute(_q(adapter, "SELECT include_packs, exclude_packs FROM "
                                "studio_workspace_settings "
                                "WHERE workspace_code = ?"), (code,))
        row = cur.fetchone()
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass
        return [], [], False
    if row is None:
        return [], [], False
    d = row if isinstance(row, dict) else dict(row)

    def _split(v):
        return [p.strip() for p in (v or "").split(",") if p.strip()]

    return _split(d.get("include_packs")), _split(d.get("exclude_packs")), True


def workspace_agent_roles(code: str, adapter=None, con=None) -> list[str]:
    """The roles that BELONG to workspace *code*.

    THE ROSTER, and the one thing every tenant-seeding caller must agree on.
    It used to be ``list_bundled_agents()`` — a directory scan of every agent
    source on the machine — which was wrong in both directions at once:

    * an agent that exists only as a ``studio_agent_defs`` row (imported from a
      solution repo, or Studio-built) is invisible to a scan, so on a host
      rebuilt from the database the tenant's OWN agents were the ones missing;
    * every other solution's agents were seeded INTO the tenant, and each one
      then recorded its shared-skill assignment against this workspace — which
      is how a two-agent tenant came to own a ``data_query`` row naming nine
      agents, none of them its own.

    So the roster is: the DATABASE's rows for this workspace, plus whatever is
    already materialised in its home, plus the platform tier (Jarvis/Quinn/Alex
    are framework-owned and identical everywhere), plus the agents of the packs
    the workspace is SCOPED to — mirroring the studio's own visibility rule so
    a tenant is seeded with exactly what it is shown. A workspace with no
    scoping row is unscoped and keeps the old every-pack behaviour.

    An UNSET code returns NOTHING: an unset caller has no tenant, and
    answering with every installed agent is exactly the mistake this
    function exists to prevent (a machine-global roster presented as a
    tenant's). The platform tier — passed EXPLICITLY, never resolved —
    keeps the bundled roster: it is the shared tier, whose roster is by
    definition what the platform ships.
    """
    from ioagentfarm.engine.workspaces import (
        PLATFORM_SHARED_ROLES, PLATFORM_TIER, list_bundled_agents,
    )
    if not code:
        return []
    if code == PLATFORM_TIER:
        return list_bundled_agents()
    if con is None:
        try:
            with connected() as (a, c):
                return workspace_agent_roles(code, a, c)
        except Exception:
            # Fail-open like every other DB seam in the engine, but say so: the
            # answer that comes back is the machine's agents, which is the very
            # thing this function exists to stop being mistaken for a tenant's.
            logger.warning(
                "workspace %r: the database is unreachable, so its own agents "
                "cannot be listed — seeding only what is installed on this "
                "host", code, exc_info=True)
            return list_bundled_agents()

    roles: set[str] = set()
    try:
        cur = con.cursor()
        cur.execute(_q(adapter, "SELECT role FROM studio_agent_defs "
                                "WHERE workspace_code = ?"), (code,))
        roles |= {(r if isinstance(r, dict) else dict(r))["role"]
                  for r in cur.fetchall()}
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass
        logger.debug("agent rows unreadable for workspace %r", code,
                     exc_info=True)

    home = _iof_root() / "workspaces" / code / "agents"
    try:
        roles |= {d.name for d in home.iterdir()
                  if (d / "workspace" / "SOUL.md").is_file()}
    except OSError:
        pass

    by_pack = _pack_agent_roles()
    every = set().union(*by_pack.values()) if by_pack else set()
    roles |= set(PLATFORM_SHARED_ROLES) & every

    include, exclude, scoped = workspace_pack_scope(adapter, con, code)
    if not scoped:
        roles |= every
    else:
        for name in include:
            roles |= by_pack.get(name, set())
        # A WORKSPACE ALWAYS OWNS THE PACK THAT CARRIES ITS NAME, scoped or
        # not. `workspace create` writes an empty scoping row -- correctly, so
        # the Studio does not list every installed solution's agents in a new
        # tenant -- but that also excluded the tenant's OWN pack until a push
        # had filled `include_packs` in. The documented sequence (local mode,
        # create, then work) therefore ended with `setup-agents` seeding the
        # platform agents and announcing "workspace has no agents of its own"
        # while `agents/<role>/` sat in the current directory, and the fix it
        # printed -- `workspace push` -- exits 1 until something is attached.
        #
        # Scoping is about which OTHER packs a tenant sees. Its own is not a
        # judgement call, so it does not wait for a push.
        roles |= by_pack.get(code, set())
        # ...and its own pack is usually NOT named after it. `new-solution
        # pharma_comm_sol` inside workspace `pharma_comm` is the documented
        # flow, so the line above misses the very case it was written for.
        # In a desk-side session the packs rooted in the checkout being
        # worked in are this workspace's, by location rather than by name.
        for _local in _local_pack_names():
            roles |= by_pack.get(_local, set())
    for name in exclude:
        roles -= (by_pack.get(name, set()) - set(PLATFORM_SHARED_ROLES))
    return sorted(roles)


def _seed_tenant_agents(adapter, con, code: str) -> list[str]:
    """Materialise the tenant's agents and place staged skills in them.

    Composes the existing seeding path rather than reimplementing either job:
    ``ensure_agent_workspace`` hydrates the agent from the row this import
    just wrote (atomic swap, per-item lock, memory/sessions/metadata
    preserved) and then seeds its shared-skill baseline over
    ``_shared_skill_dirs()``, which now includes this tenant's staging root.
    A freshly imported workspace has no assignment record yet, so that seed is
    derived once from the skills' ``roles:`` declarations and written down.

    The role list is :func:`workspace_agent_roles` — the DB's rows for this
    tenant, its already-materialised agents, the platform tier, and the packs it
    is scoped to. Disk alone is not enough: an agent that arrived in this very
    import exists only as a ``studio_agent_defs`` row until something
    materialises it, so a directory scan cannot see it yet. That
    chicken-and-egg is why a freshly imported agent otherwise received no
    shared skills and stayed invisible to every downstream directory scan.

    Runs with ``IOF_WORKSPACE`` set for the duration — that is how the staging
    root and the tenant agent home resolve — and restores it, so a process
    importing several workspaces is not left pointing at the last one.
    """
    from ioagentfarm.engine.workspaces import (
        SkillDeclarationError, ensure_agent_workspace)

    cur = con.cursor()
    cur.execute(_q(adapter, "SELECT role FROM studio_agent_defs "
                            "WHERE workspace_code = ?"), (code,))
    db_roles = {(r if isinstance(r, dict) else dict(r))["role"]
                for r in cur.fetchall()}
    roster = workspace_agent_roles(code, adapter, con)

    prior = os.environ.get("IOF_WORKSPACE")
    os.environ["IOF_WORKSPACE"] = code
    home = _iof_root() / "workspaces" / code / "agents"
    touched: list[str] = []
    try:
        for role in roster:
            try:
                ensure_agent_workspace(role, home / role / "workspace",
                                       workspace_code=code)
                touched.append(role)
            except FileNotFoundError:
                # No pack template and no usable DB content — nothing to seed.
                continue
            except SkillDeclarationError as exc:
                # ERROR, not the generic warning below: this agent was seeded
                # WITHOUT a skill somebody assigned it, which is the one
                # outcome that reads as success and is not. The repo's own
                # agents were already validated by `classify_agents` before
                # anything was written, so reaching here means an agent from a
                # pack installed on this host — bad enough to shout about,
                # not bad enough to abort a committed import of a good repo.
                logger.error("tenant seeding refused role %s: %s", role, exc)
                continue
            except Exception:
                logger.warning("tenant seeding skipped for role %s",
                               role, exc_info=True)
                continue
            # Re-snapshot the tenant's OWN agents so what seeding just placed
            # in the workspace — notably a standalone `skills:` skill — is
            # DB-backed and therefore survives to another pod.
            #
            # Without this, a standalone repo skill was filesystem-only twice
            # over: the staging dir is derived, and the agent row still held
            # only what the repo declared. A fresh pod would hydrate the agent
            # from that row, find no staging dir, and the skill would simply
            # be gone.
            #
            # Restricted to roles the tenant owns. Platform-shared agents keep
            # hydrating from the 'default' row by design (Phase 3), so writing
            # tenant rows for them would fork one identity per tenant.
            if role in db_roles:
                _resnapshot_agent(adapter, con, code, role, home / role)
    finally:
        if prior is None:
            os.environ.pop("IOF_WORKSPACE", None)
        else:
            os.environ["IOF_WORKSPACE"] = prior
    return touched


def _upsert_skill(adapter, cur, code: str, name: str, files: dict[str, str],
                  roles, sha: str, repo_hash: str) -> None:
    """Write one skill's content row. Version bumps so hydration's composite
    sync key moves and every carrier re-materialises on next use."""
    cur.execute(_q(adapter,
        "INSERT INTO studio_skills (workspace_code, name, files_json,"
        " roles_json, content_hash, version, updated_at, imported_sha,"
        " imported_hash, origin) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, 'repo') "
        "ON CONFLICT (workspace_code, name) DO UPDATE SET"
        " files_json = excluded.files_json,"
        " roles_json = excluded.roles_json,"
        " content_hash = excluded.content_hash,"
        " version = studio_skills.version + 1,"
        " updated_at = excluded.updated_at,"
        " imported_sha = excluded.imported_sha,"
        " imported_hash = excluded.imported_hash"),
        (code, name, json.dumps(files), json.dumps(roles),
         content_hash("", files), _now(), sha, repo_hash))


def _skill_carriers(items: list[dict]) -> dict[str, set[str]]:
    """Which roles carry each skill, across the WHOLE repo, before any write.

    ``roles_json`` is one column replaced wholesale by each upsert, and there is
    no portable SQLite/Postgres predicate to union into a JSON list — so the
    union has to exist in Python, and it has to be complete before the first
    row is written. Computing it per-agent inside the apply loop is what made
    the second agent's ``[role]`` overwrite the first's: two agents both
    carrying ``output_protocol`` (which every agent ships) left whichever
    sorted last as the sole recorded carrier.

    Built from EVERY agent item, not only the ones this import applies. An
    incremental import that touches one agent must not rewrite a shared skill's
    carriers down to that one agent.

    Two ways an agent carries a skill, and both count:

    * **By location** — a directory under ``agents/<role>/workspace/skills/``.
    * **By declaration** — its name in that agent's ``skills.yaml`` ``carries:``
      list, which is how ``ioagentfarm assign-skill`` records an agent holding a
      skill that lives once at pack level. The seed path has always honoured
      this file; the importer never read it, so an assigned pack-level skill
      landed in the database as ``roles_json = null`` — held by nobody, while
      both agents' materialised workspaces plainly held it.
    """
    from .engine.workspaces import (       # noqa: PLC0415 - avoid import cycle
        SkillDeclarationError, parse_declared_skills)

    carriers: dict[str, set[str]] = {}
    for it in items:
        if it.get("kind") != "agent":
            continue
        role = it["name"]
        files = it.get("files") or {}
        for key in files:
            parts = key.split("/")
            if len(parts) >= 3 and parts[0] == "skills":
                carriers.setdefault(parts[1], set()).add(role)
        try:
            declared = parse_declared_skills(files.get("skills.yaml") or "")
        except SkillDeclarationError:
            # classify_agents already collected this as a gap and the batch
            # will refuse; recording nothing here keeps that the only report.
            continue
        for name in declared:
            carriers.setdefault(name, set()).add(role)
    return carriers


def _merge_roles(declared: object, carried: set[str]) -> object:
    """A skill's declared assignment unioned with the roles that hold it.

    ``declared`` is what a manifest's ``inject.yaml`` or a SKILL.md frontmatter
    states — ``None``, the literal ``"all"``, or a list. ``carried`` is what the
    repo demonstrates. A contributing pack naming roles and an agent declaring
    the skill are both true at once, so this unions rather than picking one;
    ``"all"`` already covers everything and absorbs the rest.
    """
    if declared == "all":
        return "all"
    names = {r for r in (declared or []) if isinstance(r, str)} | carried
    return sorted(names) or None


def _upsert_carried_skills(adapter, cur, code: str, role: str,
                           files: dict[str, str], sha: str,
                           carriers: dict[str, set[str]] | None = None) -> None:
    """Split an imported agent's ``skills/**`` into their own rows.

    Assignment comes from ``carriers`` — every role in the repo that holds this
    skill — NOT the file's declared ``roles:``. A skill living under
    ``agents/<role>/workspace/skills/`` is assigned by its LOCATION; a
    boilerplate ``roles: all`` in such a file would otherwise redistribute it
    into every agent on this host. Same rule the migration applies to
    pre-existing rows.

    The agent row keeps its ``skills/**`` keys: they are what
    ``classify_agents`` compares against the repo, and dropping them would
    make every imported agent read as permanently diverged.
    """
    per_skill: dict[str, dict[str, str]] = {}
    for key, text in files.items():
        parts = key.split("/")
        if len(parts) >= 3 and parts[0] == "skills":
            per_skill.setdefault(parts[1], {})["/".join(parts[2:])] = text
    # Same rule as _backfill_skills: a wheel's shared skill is never a tenant's
    # to own, whichever path it arrives by. `validate_reserved` catches a
    # solution that declares one in its skills root; an agent-carried copy
    # bypasses that check, so it is filtered here too.
    try:
        _, shared_skills = reserved_names()
    except Exception:       # pragma: no cover - registry unavailable
        shared_skills = set()
    for name, sub in per_skill.items():
        if name in shared_skills:
            continue
        try:
            _upsert_skill(adapter, cur, code, name, sub,
                          sorted((carriers or {}).get(name) or {role}), sha,
                          content_hash("", sub))
        except Exception:
            logger.warning("carried-skill row failed for %s/%s", role, name,
                           exc_info=True)


def _resnapshot_agent(adapter, con, code: str, role: str,
                      role_dir: Path) -> None:
    """Write the LIVE tenant workspace back into ``studio_agent_defs``.

    Mirrors what the Studio's ``_sync_studio_template`` does after any agent
    write — the same table, the same hash — so the two write paths cannot
    drift. ``imported_hash`` lives in ``studio_workspace_items`` and is NOT
    touched here, so the divergence anchor still points at the repo content:
    the extra files this adds are restricted out of the comparison by
    ``agent_content_hash(..., only=<repo keys>)``.
    """
    files = read_agent_dir(role_dir)
    if "SOUL.md" not in files:
        return
    try:
        cur = con.cursor()
        cur.execute(_q(adapter,
            "UPDATE studio_agent_defs SET files_json = ?, content_hash = ?,"
            " version = version + 1, updated_at = ? "
            "WHERE workspace_code = ? AND role = ?"),
            (json.dumps(files), _files_hash(files), _now(), code, role))
        con.commit()
    except Exception:      # never fail an import over the snapshot
        logger.warning("agent re-snapshot failed for %s", role, exc_info=True)


def _materialize_skill(code: str, name: str, files: dict[str, str]) -> None:
    """Stage a solution skill under the tenant's skills root.

    ``engine/workspaces._shared_skill_dirs()`` serves this root to
    ``ensure_agent_workspace``, which gives it to the agents that already carry
    it — or, on a workspace being materialised for the first time, to the
    agents its ``roles:`` declaration names. Either way a workflow step can
    name it regardless: the staged root is a catalog source.
    """
    root = _iof_root() / "workspaces" / code / "skills" / name
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True, exist_ok=True)
    for rel, content in files.items():
        write_file(root / rel, content)


def push_workspace(code: str, take_repo: bool | list[str] = False,
                     keep_tree: bool = False) -> tuple[int, dict]:
    """The fail-safe import. Returns (exit_code, report)."""
    with SyncLock(code), connected() as (adapter, con):
        manifest, _tree, sha, _repo = _load_and_validate(code, keep_tree)
        items = classify_items(adapter, con, code, manifest, sha)

        def _authorized(name: str) -> bool:
            if take_repo is True:
                return True
            return isinstance(take_repo, list) and name in take_repo

        # ONE gate across every kind: a single diverged agent refuses the
        # whole batch, workflows included. Partial application is exactly what
        # the nothing-erases guarantee forbids.
        refused = [i for i in items
                   if i["action"] == "diverged" and not _authorized(i["name"])]
        report = _report(code, sha, items)
        if refused:
            report["refused"] = [i["name"] for i in refused]
            report["resolution"] = (
                "export the diverged items first (`workspace pull`), or "
                "re-run with --take-repo [--only <name>] to overwrite them "
                "(prior DB content is snapshotted to .backups/ first)")
            return EXIT_GAPS, report

        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        cur = con.cursor()
        backups: list[str] = []
        applied = 0
        # Every carrier of every skill, resolved up front. The apply loop
        # writes agents before standalone skills, so a per-agent answer is
        # necessarily partial at the moment it is written.
        carriers = _skill_carriers(items)
        # Per-solution workflow attribution (None = column absent, i.e. a
        # DBA-managed schema where ensure_platform_schema could not ALTER —
        # the import must not die over an attribution column).
        wf_solutions: dict[str, str] | None = None
        try:
            if "solution" in _table_columns(
                    cur, "studio_workflow_defs",
                    adapter.placeholder() == "%s"):
                wf_solutions = manifest.workflow_solution_map()
        except Exception:
            wf_solutions = None
        try:
            for it in items:
                act = it["action"]
                kind = it["kind"]
                overwrite_diverged = act == "diverged" and _authorized(it["name"])
                if not (APPLY_DEFAULT.get(act) or overwrite_diverged):
                    continue

                if kind == "agent":
                    if overwrite_diverged:
                        cur.execute(_q(adapter,
                            "SELECT files_json FROM studio_agent_defs "
                            "WHERE workspace_code = ? AND role = ?"),
                            (code, it["name"]))
                        prior = cur.fetchone()
                        if prior:
                            _backup_agent(code, ts, it["name"], dict(prior))
                            backups.append(it["name"])
                    # version bumps so hydration's sync key moves and the
                    # tenant's live workspace re-materialises on next use.
                    cur.execute(_q(adapter,
                        "INSERT INTO studio_agent_defs (workspace_code, role,"
                        " files_json, content_hash, version, updated_at) "
                        "VALUES (?, ?, ?, ?, 1, ?) "
                        "ON CONFLICT (workspace_code, role) DO UPDATE SET"
                        " files_json = excluded.files_json,"
                        " content_hash = excluded.content_hash,"
                        " version = studio_agent_defs.version + 1,"
                        " updated_at = excluded.updated_at"),
                        (code, it["name"], json.dumps(it["files"]),
                         _files_hash(it["files"]), _now()))
                    _upsert_item(adapter, cur, code, "agent", it["name"],
                                 sha, it["repo_hash"])
                    _upsert_carried_skills(adapter, cur, code, it["name"],
                                           it["files"], sha, carriers)
                    applied += 1
                    continue

                if kind == "skill":
                    if overwrite_diverged:
                        cur.execute(_q(adapter,
                            "SELECT files_json FROM studio_skills "
                            "WHERE workspace_code = ? AND name = ?"),
                            (code, it["name"]))
                        _prior = cur.fetchone()
                        _backup_skill(code, ts, it["name"],
                                      dict(_prior) if _prior else None)
                        backups.append(it["name"])
                    # The skill's own row — what makes a repo skill survive to
                    # another pod. Before it, a standalone skill was
                    # filesystem-only twice over: the staging dir is derived,
                    # and the agent rows held only what the repo declared for
                    # the AGENT, so a fresh pod hydrated from the DB and the
                    # skill was simply gone.
                    # An inject.yaml's `roles:` wins over the SKILL.md
                    # frontmatter: the point of an inject dir is that the
                    # CONTRIBUTING pack decides who receives the skill.
                    # Either way it is UNIONED with the agents that actually
                    # declare the skill in their `carries:` — a pack-level
                    # skill assigned by `assign-skill` has neither an inject
                    # dir nor a frontmatter `roles:` (skills are open, so
                    # `new-skill` emits none), and both sources answering None
                    # is what wrote `roles_json = null` over agents that held
                    # it. This write also lands AFTER the agent writes, so
                    # without the union it would undo them.
                    _upsert_skill(adapter, cur, code, it["name"], it["files"],
                                  _merge_roles(
                                      manifest.skill_assignment(it["name"])
                                      or skill_roles(it["files"]),
                                      carriers.get(it["name"], set())),
                                  sha, it["repo_hash"])
                    _upsert_item(adapter, cur, code, "skill", it["name"],
                                 sha, it["repo_hash"])
                    applied += 1
                    continue

                if overwrite_diverged:
                    cur.execute(_q(adapter,
                        "SELECT yaml, files_json FROM studio_workflow_defs "
                        "WHERE workspace_code = ? AND code = ?"),
                        (code, it["name"]))
                    prior = cur.fetchone()
                    if prior:
                        _backup_row(code, ts, it["name"],
                                    dict(prior))
                        backups.append(it["name"])
                files_json = json.dumps(it["files"])
                if wf_solutions is not None:
                    cur.execute(_q(adapter,
                        "INSERT INTO studio_workflow_defs (workspace_code,"
                        " code, yaml, files_json, source, shadows_pack,"
                        " synced_at, updated_at, imported_sha, imported_hash,"
                        " origin, solution) "
                        "VALUES (?, ?, ?, ?, 'pack-sync', 0, ?, ?, ?, ?,"
                        " 'repo', ?) "
                        "ON CONFLICT (workspace_code, code) DO UPDATE SET"
                        " yaml = excluded.yaml,"
                        " files_json = excluded.files_json,"
                        " synced_at = excluded.synced_at,"
                        " updated_at = excluded.updated_at,"
                        " imported_sha = excluded.imported_sha,"
                        " imported_hash = excluded.imported_hash,"
                        " origin = 'repo', solution = excluded.solution"),
                        (code, it["name"], it["yaml"], files_json, _now(),
                         _now(), sha, it["repo_hash"],
                         wf_solutions.get(it["name"], "")))
                else:
                    cur.execute(_q(adapter,
                        "INSERT INTO studio_workflow_defs (workspace_code, code,"
                        " yaml, files_json, source, shadows_pack, synced_at,"
                        " updated_at, imported_sha, imported_hash, origin) "
                        "VALUES (?, ?, ?, ?, 'pack-sync', 0, ?, ?, ?, ?, 'repo') "
                        "ON CONFLICT (workspace_code, code) DO UPDATE SET"
                        " yaml = excluded.yaml, files_json = excluded.files_json,"
                        " synced_at = excluded.synced_at,"
                        " updated_at = excluded.updated_at,"
                        " imported_sha = excluded.imported_sha,"
                        " imported_hash = excluded.imported_hash,"
                        " origin = 'repo'"),
                        (code, it["name"], it["yaml"], files_json, _now(), _now(),
                         sha, it["repo_hash"]))
                cur.execute(_q(adapter,
                    "INSERT INTO studio_workspace_items (workspace_code, kind,"
                    " name, imported_sha, imported_hash, origin, updated_at) "
                    "VALUES (?, 'workflow', ?, ?, ?, 'repo', ?) "
                    "ON CONFLICT (workspace_code, kind, name) DO UPDATE SET"
                    " imported_sha = excluded.imported_sha,"
                    " imported_hash = excluded.imported_hash,"
                    " updated_at = excluded.updated_at"),
                    (code, it["name"], sha, it["repo_hash"], _now()))
                applied += 1
            # Declared carriage lands even when the skill's own content was
            # UNCHANGED this round. The standalone-skill branch writes
            # declared ∪ carried only for APPLIED items, so `carries: X`
            # added to an agent while X's files stood still never reached
            # X's roles_json — the import-side half of the skills.yaml
            # round-trip bug. UNION-ONLY, so a Studio assignment this repo
            # does not know about is never erased; and computed over the
            # items this import actually accepted, so a refused diverged
            # agent's declaration stays out.
            accepted = _skill_carriers([
                it for it in items
                if APPLY_DEFAULT.get(it["action"]) or it["action"] == "unchanged"
                or (it["action"] == "diverged" and _authorized(it["name"]))])
            for s_name, holder_roles in accepted.items():
                try:
                    cur.execute(_q(adapter,
                        "SELECT roles_json FROM studio_skills "
                        "WHERE workspace_code = ? AND name = ?"),
                        (code, s_name))
                    r0 = cur.fetchone()
                    if r0 is None:
                        continue
                    r0d = r0 if isinstance(r0, dict) else dict(r0)
                    existing = json.loads(r0d.get("roles_json") or "null")
                except Exception:
                    continue
                merged = _merge_roles(existing, set(holder_roles))
                if merged != existing:
                    cur.execute(_q(adapter,
                        "UPDATE studio_skills SET roles_json = ?, "
                        "updated_at = ? WHERE workspace_code = ? AND name = ?"),
                        (json.dumps(merged), _now(), code, s_name))

            scoped = _scope_workspace_to_solution(
                adapter, cur, code, manifest.solution)
            cur.execute(_q(adapter,
                "UPDATE studio_workspace_repos SET last_sha = ?,"
                " last_imported_at = ?, last_report_json = ?, updated_at = ? "
                "WHERE workspace_code = ?"),
                (sha, _now(), json.dumps(report), _now(), code))
            con.commit()
            if scoped:
                report["scoped_to_pack"] = manifest.solution
        except Exception:
            try:
                con.rollback()
            except Exception:
                pass
            raise

        # Derived engine-format trees (outside the tx — regenerable artifacts)
        def _materialized(it: dict) -> bool:
            return it["action"] in ("added", "updated", "unchanged", "reconciled") \
                or (it["action"] == "diverged" and _authorized(it["name"]))

        needs_seeding = False
        for it in items:
            if not _materialized(it):
                continue
            if it["kind"] == "workflow":
                _materialize_workflow(code, it["name"], it["yaml"], it["files"])
            elif it["kind"] == "skill":
                _materialize_skill(code, it["name"], it["files"])
                needs_seeding = True
            elif it["kind"] == "agent":
                # NOT copied here — seeding below goes through
                # ensure_agent_workspace, i.e. hydration, keeping the atomic
                # swap and memory preservation a direct copy would bypass.
                needs_seeding = True

        # Two jobs, one pass: put imported agents on disk (they exist only as
        # DB rows until now) and let the roles: rule place staged skills into
        # them. Both matter for visibility — the Studio's agent gallery and
        # skill inventory are directory scans, so a DB-only agent and a
        # staged-only skill are both invisible until this runs.
        if needs_seeding:
            report["seeded_agents"] = _seed_tenant_agents(adapter, con, code)

        report["applied"] = applied
        report["backups"] = backups
        if backups:
            report["backup_dir"] = str(
                _iof_root() / "workspaces" / code / ".backups" / ts)
        return EXIT_OK, report


#: Tenant-scoped tables, in the order they must be cleared. Keyed by the human
#: ``workspace_code`` per the tenancy keying rule (apps/agentfarm-api/app/
#: tenancy.py). Engine-owned and API-owned tables sit in one list because they
#: share one database and one tenant identity — a delete that cleared only the
#: engine's half would leave the Studio serving a workspace that no longer
#: exists.
_TENANT_TABLES = (
    ("studio_workflow_defs", "workspace_code"),
    ("studio_agent_defs", "workspace_code"),
    ("studio_skills", "workspace_code"),
    ("studio_workspace_items", "workspace_code"),
    ("studio_workspace_repos", "workspace_code"),
    ("studio_workspace_members", "workspace_code"),
    ("studio_workspace_settings", "workspace_code"),
    # A tenant's unpromoted drafts. They are content nobody promoted, so they
    # die with the workspace; the on-disk draft homes under
    # workspaces/<code>/drafts/ go with the tree the delete already removes.
    ("content_drafts", "workspace_code"),
    # WORKSPACE MEMORY, INCLUDING WHAT WAS EXTRACTED FROM CONVERSATIONS.
    # These were absent, so deleting a tenant left every memory row behind —
    # an independent validator counted 35 surviving rows for a deleted
    # workspace, among them `user:alice` and `user:bob` facts distilled from
    # their chats. On a local SQLite database the folder deletion hid it; on a
    # shared PostgreSQL deployment, which is the one that matters, personal
    # context outlived the tenant it belonged to. A memory tier whose whole
    # premise is governed retention cannot leave rows behind when the thing
    # they are governed for is deleted.
    ("workspace_memory", "workspace_code"),
    ("workspace_memory_history", "workspace_code"),
    ("workspace_memory_runs", "workspace_code"),
    ("workspace_memory_settings", "workspace_code"),
    # WHAT CONTENT EACH HOST BOOTED FOR THIS TENANT. Keyed by workspace_code
    # and left behind by every delete until now, so a deleted tenant kept
    # naming itself in the registration table forever - and the row carries
    # pack, distribution and version, which is a description of the tenant's
    # deployment, not of the platform's.
    ("content_registration", "workspace_code"),
)

#: The PLATFORM TIER's row key. Not a workspace: it cannot be selected,
#: created or resolved to — it is the shared tier that holds platform-owned
#: rows (platform-shared roles, pack assignment records). Deleting those rows
#: would strip every tenant of the shared content they resolve against, so
#: deletion is refused with a message that says what the tier is.
PROTECTED_WORKSPACES = frozenset({_PLATFORM_TIER_SYNC})


class RunHistoryRefused(ValueError):
    """Deleting a workspace that still holds runs, without ``force``.

    A distinct type so each front end can word the escalation in its OWN
    vocabulary. ``str()`` stays the CLI sentence — this is a CLI-first
    codebase and that is where the flag belongs — but the Studio was relaying
    it verbatim into a browser dialog, telling a business user with no
    terminal to "re-run with --force (API: ?force=true)". The API now catches
    the type and says what its own UI does.

    Subclasses ValueError so every existing ``except ValueError`` still
    catches it and no caller had to change.
    """

    def __init__(self, code: str, run_count: int):
        self.code = code
        self.run_count = run_count
        super().__init__(
            f"workspace '{code}' has {run_count} run(s) — refusing to delete "
            "run history. Re-run with --force (API: ?force=true) to delete "
            "them too; on-disk run artifacts under <IOF_ROOT>/instances are "
            "left alone either way.")


def delete_workspace_rows(con, is_pg: bool, code: str,
                          force: bool = False) -> dict:
    """Delete every row keyed to a tenant workspace, on a CALLER'S connection.

    Same split as :func:`ensure_platform_schema`, and for the same reason: the
    CLI reaches it through :func:`delete_workspace` (own connection) and the
    studio API calls it directly with ``app.database.get_db()``, so the two
    sides cannot drift into two different ideas of what a workspace is made of.

    FAIL-CLOSED ON HISTORY. Runs are the one thing here that is not
    regenerable — the rows are joined by artifacts and forensics on disk — so a
    workspace with runs is refused unless *force*, and the refusal says how
    many there are. ``force`` removes the run rows and their dependent
    step/story/message/task rows; it does NOT touch ``<IOF_ROOT>/instances``,
    so the forensic trail survives a mis-aimed delete.

    Catalog content is regenerable by construction — ``workspace push`` reads
    it back from the solution repo. Anything a business user authored ONLY in
    the Studio is genuinely lost, so export first if you want to keep it; that
    is the same resolution import's nothing-erases gate points at.

    Raises ``ValueError`` when the workspace is protected, missing, or holds
    runs without *force*.
    """
    code = (code or "").strip().lower()
    if not code:
        raise ValueError("workspace code is required")
    if code in PROTECTED_WORKSPACES:
        raise ValueError(
            f"'{code}' is the platform tier, not a workspace: it holds the "
            "shared rows (platform agents, pack skill assignments) every "
            "tenant resolves against, and cannot be deleted")

    ph = "%s" if is_pg else "?"

    def _one(row):
        return row if isinstance(row, dict) else dict(row)

    cur = con.cursor()
    # `workspaces` belongs to the engine store (`ioagentfarm init`), not to the
    # platform tables ensured above — on a database where init has never run it
    # is simply absent, and "does not exist" is the truthful answer rather than
    # an OperationalError the caller has to decode.
    if not _table_columns(cur, "workspaces", is_pg):
        raise ValueError(f"workspace '{code}' does not exist")
    cur.execute(f"SELECT id FROM workspaces WHERE code = {ph}", (code,))
    row = cur.fetchone()
    if row is None:
        raise ValueError(f"workspace '{code}' does not exist")
    ws_id = _one(row)["id"]

    cur.execute(f"SELECT count(*) AS n FROM runs WHERE workspace_id = {ph}",
                (ws_id,))
    run_count = int(_one(cur.fetchone())["n"])
    if run_count and not force:
        raise RunHistoryRefused(code, run_count)

    removed: dict[str, int] = {}
    if run_count:
        cur.execute(f"SELECT id FROM runs WHERE workspace_id = {ph}", (ws_id,))
        run_ids = [_one(x)["id"] for x in cur.fetchall()]
        for table in ("steps", "stories", "messages", "tasks"):
            n = 0
            for rid in run_ids:
                try:
                    cur.execute(f"DELETE FROM {table} WHERE run_id = {ph}",
                                (rid,))
                    n += max(cur.rowcount, 0)
                except Exception:
                    logger.warning("could not clear %s for run %s", table, rid,
                                   exc_info=True)
            if n:
                removed[table] = n
        cur.execute(f"DELETE FROM runs WHERE workspace_id = {ph}", (ws_id,))
        removed["runs"] = max(cur.rowcount, 0)

    # CHAT MESSAGES HAVE NO RUN, so the per-run sweep above never reached them:
    # every conversation an always-on agent ever held survived the deletion of
    # the tenant it belonged to, in cleartext, keyed by user_id. An independent
    # validator counted 390 rows after a documented teardown reported success.
    #
    # Unconditional, and NOT behind `force`: that gate exists for run history,
    # which is joined to artifacts on disk that the delete deliberately leaves
    # alone. A chat message has no artifact and no other owner — it is the
    # tenant's conversation, and the tenant is being deleted.
    #
    # On the local layout the database sits inside the folder the operator
    # removes next, which is why this went unnoticed; on a shared path or
    # PostgreSQL, which are the deployments that matter, nothing removed it.
    try:
        cur.execute(f"DELETE FROM messages WHERE workspace_id = {ph}", (ws_id,))
        n = max(cur.rowcount, 0)
        if n:
            removed["messages"] = removed.get("messages", 0) + n
        # UNATTRIBUTED ROWS ARE REPORTED, NEVER GUESSED AT. Chat messages
        # written before the workspace stamp existed carry workspace_id NULL,
        # and on a shared database nothing distinguishes one tenant's from
        # another's - deleting them by user_id would take a different
        # tenant's conversations with them. So they are counted and named:
        # an operator who must remove them can, and silence cannot be
        # mistaken for a clean sweep. `workspace delete` is the surface that
        # tells the truth about retention; it must not round it up.
        cur.execute("SELECT COUNT(*) AS n FROM messages WHERE workspace_id IS NULL")
        row = cur.fetchone()
        orphans = int((row["n"] if isinstance(row, dict) or hasattr(row, "keys")
                       else row[0]) or 0)
        if orphans:
            removed["messages_unattributed_left"] = orphans
    except Exception:  # noqa: BLE001 - a young database may lack the table
        logger.debug("could not clear messages for workspace %s", code,
                     exc_info=True)

    for table, col in _TENANT_TABLES:
        # EXISTENCE IS CHECKED, NOT CAUGHT. These tables are ensured lazily by
        # whichever side first needs them, so a young database legitimately
        # lacks some of them — but recovering from the failed DELETE with a
        # rollback would discard the deletes already made in this transaction
        # (silently, on sqlite: the run rows come back and the workspace row
        # does not go away). Skipping the absent table leaves the transaction
        # clean on both backends.
        if not _table_columns(cur, table, is_pg):
            continue
        cur.execute(f"DELETE FROM {table} WHERE {col} = {ph}", (code,))
        if cur.rowcount > 0:
            removed[table] = cur.rowcount

    cur.execute(f"DELETE FROM workspaces WHERE code = {ph}", (code,))
    removed["workspaces"] = max(cur.rowcount, 0)

    # IN-PROCESS MEMOS OUTLIVE THE ROWS THEY DESCRIBE. The pack-assignment
    # guard is keyed (database, workspace_code, role) and nothing evicted it,
    # so a workspace deleted and recreated under the SAME code in one
    # long-lived process was told "already reconciled" about rows this delete
    # had just removed - and its catalog listed none of the SDK's skills.
    try:
        from ioagentfarm.engine.workspaces import forget_pack_assignments
        forgotten = forget_pack_assignments(code)
        if forgotten:
            logger.debug("forgot %d pack-assignment memo(s) for %s",
                         forgotten, code)
    except Exception:  # noqa: BLE001 - a memo must not fail a deletion
        logger.debug("could not clear pack-assignment memo for %s", code,
                     exc_info=True)
    try:
        con.commit()
    except Exception:
        pass
    return {"workspace": code, "removed": removed, "runs_deleted": run_count}


def workspace_catalog(code: str) -> dict:
    """What a tenant workspace CONTAINS, read straight from the database.

    The CLI answer to "did my import land, and is this tenant scoped?" — the
    two questions the getting-started walk previously answered with three
    ``curl`` calls, a bearer token and a ``python -c`` JSON filter, none of
    which say anything the database does not already know. No HTTP, no server,
    no token: it works with the Studio API stopped, which is also what makes it
    the right check on a host that only has the database.

    Reads the TENANT tier only (``studio_*``), deliberately. The Studio shows
    these rows PLUS the platform-shared agents every workspace sees (Jarvis,
    Quinn, Alex) and the shared skills the SDK ships — so this listing is
    always a subset of that screen, and it is the subset the reader owns.
    Mixing the two here would reproduce the confusion the ``include_packs``
    scope exists to prevent.

    Every read degrades to empty rather than raising: on a database where the
    Studio tables have never been created, "this workspace holds nothing" is
    the truthful answer, not an OperationalError the caller has to decode.
    """
    code = (code or "").strip().lower()
    out: dict = {"workspace": code, "workflows": [], "agents": [],
                 "skills": [], "members": [], "scope": None, "repo": None,
                 "runs": 0}

    #: Names a savepoint per read, so a failure can be rolled back to exactly
    #: here rather than taking the connection with it.
    probe = [0]

    def _q_all(cur, adapter, sql: str, args=()) -> list[dict]:
        """One read, ISOLATED, degrading to empty.

        THE SAVEPOINT IS THE WHOLE POINT ON POSTGRESQL. The docstring above
        says a missing Studio table should read as "this workspace holds
        nothing", and that reasoning is correct on SQLite, where a failed
        statement is just a failed statement. On PostgreSQL the first failure
        ABORTS THE TRANSACTION, and every later statement on the same
        connection raises InFailedSqlTransaction - which this except clause
        also swallowed. So ONE absent table emptied every read after it,
        including reads of tables that exist and hold rows.

        Measured on a freshly created schema: `studio_workflow_defs` was
        absent, and `aicore workspace show` then reported "access nobody -
        this workspace has no members, so it cannot be opened in the Studio"
        (with a `fix:` line telling the reader to re-run `create`) about a
        workspace whose members row was right there, plus 0 runs against
        three real runs. A false report is worse than an error, because it
        reads as an answer.

        Same rule the case and play stores already follow: every statement
        that may fail runs inside a SAVEPOINT.
        """
        probe[0] += 1
        name = f"iof_catalog_probe_{probe[0]}"
        nested = False
        try:
            cur.execute(f"SAVEPOINT {name}")
            nested = True
        except Exception:
            # No transaction to nest in (autocommit, or a backend without
            # savepoints). Nothing to protect, and nothing to undo.
            nested = False
        try:
            cur.execute(_q(adapter, sql), args)
            rows = [r if isinstance(r, dict) else dict(r)
                    for r in cur.fetchall()]
        except Exception:
            if nested:
                try:
                    cur.execute(f"ROLLBACK TO SAVEPOINT {name}")
                    cur.execute(f"RELEASE SAVEPOINT {name}")
                except Exception:
                    pass
            return []
        if nested:
            try:
                cur.execute(f"RELEASE SAVEPOINT {name}")
            except Exception:
                pass
        return rows

    with connected() as (adapter, con):
        cur = con.cursor()
        rows = _q_all(cur, adapter,
                      "SELECT id, code, name, description FROM workspaces "
                      "WHERE code = ?", (code,))
        if not rows:
            return {}
        out.update(rows[0])

        out["workflows"] = sorted(
            (r["code"] for r in _q_all(
                cur, adapter, "SELECT code FROM studio_workflow_defs "
                              "WHERE workspace_code = ?", (code,))))
        out["agents"] = sorted(
            (r["role"] for r in _q_all(
                cur, adapter, "SELECT role FROM studio_agent_defs "
                              "WHERE workspace_code = ?", (code,))))

        # WHICH PACK SHIPS IT, so the reader can be told the truth about their
        # own content. `studio_skills.origin` only says whether the CONTENT is
        # stored here, so `origin='pack'` covers the SDK's wheels AND this
        # repo's own skills before they are pushed -- and labelling both "sdk"
        # told an author that the skill they had just written came from the
        # framework. `pack_skills` knows the owning pack and whether it is the
        # shared tier; absent (an unsynced or repo-only skill) means neither.
        ships: dict[str, dict] = {}
        try:
            for r in _q_all(cur, adapter,
                            "SELECT name, pack, shared FROM pack_skills"):
                ships[r["name"]] = {"pack": r.get("pack") or "",
                                    "shared": bool(r.get("shared"))}
        except Exception:
            try:
                con.rollback()
            except Exception:
                pass
            logger.debug("pack_skills unreadable; skill origin will be coarse",
                         exc_info=True)

        skills = []
        for r in _q_all(cur, adapter,
                        "SELECT name, origin, roles_json FROM studio_skills "
                        "WHERE workspace_code = ?", (code,)):
            try:
                held_by = json.loads(r.get("roles_json") or "null")
            except json.JSONDecodeError:
                held_by = None
            info = ships.get(r["name"], {})
            skills.append({"name": r["name"], "origin": r.get("origin") or "",
                           "held_by": held_by,
                           "pack": info.get("pack", ""),
                           "shared": info.get("shared", False)})
        out["skills"] = sorted(skills, key=lambda s: s["name"])

        settings = _q_all(cur, adapter,
                          "SELECT include_packs FROM studio_workspace_settings "
                          "WHERE workspace_code = ?", (code,))
        # '' is a REAL and different state from no row at all: an empty string
        # is "scoped to nothing yet, waiting for an import to claim it", and a
        # missing row is "unscoped — the Studio lists every installed pack's
        # agents here". Collapsing them would hide the second.
        out["scope"] = settings[0]["include_packs"] if settings else None
        out["scoped"] = bool(settings)

        out["members"] = _q_all(
            cur, adapter, "SELECT user_email, role FROM studio_workspace_members "
                          "WHERE workspace_code = ? ORDER BY user_email", (code,))

        repo = _q_all(cur, adapter,
                      "SELECT repo_url, branch, last_sha, last_imported_at "
                      "FROM studio_workspace_repos WHERE workspace_code = ?",
                      (code,))
        out["repo"] = repo[0] if repo else None

        runs = _q_all(cur, adapter,
                      "SELECT count(*) AS n FROM runs WHERE workspace_id = ?",
                      (out["id"],))
        out["runs"] = int(runs[0]["n"]) if runs else 0
    return out


def workspace_state_dir(code: str) -> Path:
    """``<IOF_ROOT>/workspaces/<code>`` — derived trees, staging, clone, backups."""
    return _iof_root() / "workspaces" / (code or "").strip().lower()


def remove_workspace_state(code: str) -> bool:
    """Delete the workspace's derived on-disk state. True when it went away."""
    d = workspace_state_dir(code)
    if not d.exists():
        return False
    shutil.rmtree(d, ignore_errors=True)
    return not d.exists()


def delete_workspace(code: str, force: bool = False,
                     keep_files: bool = False) -> dict:
    """Remove a tenant workspace and everything keyed to it.

    The counterpart to ``workspace create`` — which existed from the start
    while nothing could undo it. A workspace created by mistake (a typo in the
    code, an evaluation tenant, a scaffold tried and discarded) was permanent:
    no CLI verb, no API route, only hand-written SQL across seven tables an
    operator had to know the names of.
    """
    with connected() as (adapter, con):
        report = delete_workspace_rows(
            con, adapter.placeholder() == "%s", code, force=force)
    report["state_dir"] = str(workspace_state_dir(code))
    report["state_dir_removed"] = (
        False if keep_files else remove_workspace_state(code))
    return report


def _skill_assignments(adapter, con, code: str
                       ) -> dict[str, tuple[object, str, bool, object]]:
    """``{skill: (roles, origin, assignment_only, authored_roles)}``.

    ``roles`` is the parsed ``roles_json`` (None | "all" | [roles]) — THE
    assignment record. ``authored_roles`` is the skill's own frontmatter
    ``roles:`` — an assignment the REPO already states, which import
    re-derives on its own and export must therefore never restate. Read once
    per export; the regeneration of every agent's ``skills.yaml`` keys off
    this.
    """
    cur = con.cursor()
    try:
        cur.execute(_q(adapter,
            "SELECT name, roles_json, origin, files_json "
            "FROM studio_skills WHERE workspace_code = ?"), (code,))
        rows = cur.fetchall()
    except Exception:
        return {}
    out: dict[str, tuple[object, str, bool, object]] = {}
    for r in rows:
        row = r if isinstance(r, dict) else dict(r)
        try:
            roles = json.loads(row.get("roles_json") or "null")
        except json.JSONDecodeError:
            roles = None
        raw_files = row.get("files_json") or "{}"
        assignment_only = raw_files == "{}"
        authored: object = None
        if not assignment_only:
            try:
                authored = skill_roles(json.loads(raw_files))
            except Exception:
                authored = None
        out[row["name"]] = (roles, row.get("origin") or "",
                            assignment_only, authored)
    return out


def _assignment_covers(roles: object, role: str) -> bool:
    return roles == "all" or (isinstance(roles, list) and role in roles)


def _opening_hand() -> dict[str, object]:
    """The packs' merged ``skill_defaults`` — {} when the registry is absent."""
    try:
        from ioagentfarm.packs import load_registry
        return load_registry().skill_defaults()
    except Exception:
        return {}


def _regenerated_carries(role: str, files: dict[str, str],
                         declared_prior: set[str],
                         assign: dict[str, tuple[object, str, bool]],
                         opening: dict[str, object],
                         skip_skills: set[str],
                         inject_roles: dict[str, set[str]]) -> set[str]:
    """What this agent's ``skills.yaml`` SHOULD declare, from the database.

    The export-side half of the round trip. Import derives ``roles_json``
    from ``skills.yaml`` + location; a Studio assignment moves ONLY
    ``roles_json``; so export has to derive ``skills.yaml`` back from
    ``roles_json`` or the Studio's change is silently lost the next time the
    repo is imported.

    The rules, each earning its place:

    * a PRIOR declaration is kept unless a row EXPLICITLY excludes the role —
      "no row anywhere" must not delete an authored line (the skill may not
      be materialised on this host at all);
    * a skill physically in this agent's exported files is location-assigned
      — declaring it too would be a second answer to one question;
    * a pack/SDK skill the opening hand already deals to this role is NOT
      declared: the wheel re-deals it on any install, and exporting it would
      freeze today's baseline into the repo (the assignment-form of the
      frozen-fork problem). A pack skill assigned BEYOND its opening hand is
      a deliberate tenant choice and IS declared;
    * an assignment the repo itself already AUTHORS — an ``inject.yaml`` or
      the skill's own frontmatter ``roles:`` — is never restated: import
      re-derives those on its own, and restating them would churn every
      affected agent's declaration on the first export after any import
      (proven by the code-first walkthrough, whose house-style skill is
      frontmatter-assigned). A Studio assignment BEYOND the authored roles
      still exports — that is the delta only the database knows.
    """
    location = {k.split("/")[1] for k in files
                if k.startswith("skills/") and len(k.split("/")) >= 3}
    physical = location - set(skip_skills) - declared_prior

    carries: set[str] = set()
    for name in declared_prior:
        rec = assign.get(name)
        # `roles_json: null` is "nothing recorded", NOT "explicitly excluded"
        # — only a real list (or []) that omits the role is a removal. A
        # declaration must survive a host that simply has no assignment row.
        if rec is None or rec[0] is None or _assignment_covers(rec[0], role):
            carries.add(name)
    for name, (roles, origin, assignment_only, authored) in assign.items():
        if name in carries or name in physical:
            continue
        if not _assignment_covers(roles, role):
            continue
        if role in (inject_roles.get(name) or ()):
            continue
        if _assignment_covers(authored, role):
            continue
        if origin == "pack" or assignment_only:
            dealt = opening.get(name)
            if dealt == "all" or (isinstance(dealt, (set, list, tuple))
                                  and role in dealt):
                continue
        carries.add(name)
    return carries


def _render_declared_skills(names: list[str]) -> str:
    """A regenerated ``skills.yaml``. Written ONLY when the set disagrees with
    the authored file, so hand-written comments survive every export where
    the declaration is already true."""
    header = (
        "# Skills this agent CARRIES BY NAME — one copy elsewhere (the pack,\n"
        "# the SDK, or another agent), no fork. REGENERATED by `workspace\n"
        "# export` from the workspace's assignment record\n"
        "# (studio_skills.roles_json) whenever the two disagree, so an\n"
        "# assignment made in the Studio survives the repo round trip.\n")
    if not names:
        return header + "carries: []\n"
    return header + "carries:\n" + "".join(f"  - {n}\n" for n in names)


def pull_workspace(code: str, keep_tree: bool = True) -> tuple[int, dict]:
    """DB -> repo working tree. Writes files; NEVER commits or pushes.

    Exports every workflow whose DB content is studio-owned or has drifted
    from its last import — the operator reviews the diff in git.
    """
    manifest, tree, sha, _repo = _load_and_validate(code, keep_tree)
    # Each kind is gated on its OWN root. A missing workflows root used to
    # abort the whole export, so a solution that ships only agents and skills
    # could never take back a Studio edit — the very thing import's refusal
    # message tells the operator to do.
    if not (manifest.workflows_roots or manifest.agents_roots
            or manifest.skills_roots):
        return EXIT_GAPS, {
            "workspace": code,
            "error": "manifest declares no root to export into"}
    target_root = (manifest.workflows_roots[0] if manifest.workflows_roots
                   else None)

    with connected() as (adapter, con):
        cur = con.cursor()
        rows = []
        if target_root is not None:
            cur.execute(_q(adapter,
                "SELECT code, yaml, files_json, origin, imported_hash "
                "FROM studio_workflow_defs WHERE workspace_code = ?"), (code,))
            rows = [dict(r) for r in cur.fetchall()]

        exported: list[str] = []
        # WHERE EACH ITEM ACTUALLY LANDED. The three kinds go to three
        # different roots -- workflows to the workflows root, agents to the
        # agents root, a declared skill to its own directory -- and the
        # report named ONE of them, the workflows root, for everything. So a
        # pull that correctly wrote an agent to `agents/` announced it under
        # a workflows path that does not exist, which reads as the bug it is
        # not and sends the reader looking in the wrong directory.
        wrote_to: dict[str, str] = {}
        for row in rows:
            files = json.loads(row["files_json"] or "{}")
            db_hash = content_hash(row["yaml"], files)
            drifted = row["origin"] == "studio" or db_hash != row["imported_hash"]
            if not drifted:
                continue
            dest = target_root / row["code"]
            dest.mkdir(parents=True, exist_ok=True)
            (dest / "workflow.yaml").write_text(row["yaml"], encoding="utf-8")
            for rel, content in files.items():
                write_file(dest / rel, content)
            exported.append(row["code"])
            wrote_to[f"workflow/{row['code']}"] = str(dest)
            _anchor_pulled_item(adapter, cur, code, "workflow", row["code"],
                                sha, db_hash)
            # A workflow keeps its own markers on the def table, and THAT is
            # what this loop's drift test reads -- the ledger row alone would
            # leave `origin='studio'` here and the item diverged forever.
            cur.execute(_q(adapter,
                "UPDATE studio_workflow_defs SET origin = 'repo',"
                " imported_sha = ?, imported_hash = ?, updated_at = ? "
                "WHERE workspace_code = ? AND code = ?"),
                (sha, db_hash, _now(), code, row["code"]))

        # Agents — the resolution path import's refusal message promises
        # ("export the diverged items first"), so it must cover every kind that
        # can be refused.
        exported_agents: list[str] = []
        assignment_refreshed: list[str] = []
        if manifest.agents_roots:
            from ioagentfarm.engine.workspaces import (
                SkillDeclarationError, parse_declared_skills)
            agents_root = manifest.agents_roots[0]
            ledger = _item_ledger(adapter, con, code, "agent")
            # Skills the repo must NOT receive a copy of: the shared-skills
            # wheel's (a solution may not shadow those — validate_reserved
            # rejects a manifest that does) and the ones this manifest already
            # exports through its own skills root.
            _, shared_skills = reserved_names()
            skip_skills = set(shared_skills) | set(manifest.skill_dirs())
            # The assignment record + the packs' opening hand, read once.
            # Export regenerates each agent's skills.yaml from these — a
            # Studio-made assignment moves ONLY roles_json, so without the
            # regeneration it is silently lost on the round trip (import then
            # derives roles_json from the STALE declaration and undoes it).
            assignments = _skill_assignments(adapter, con, code)
            opening = _opening_hand()
            inject_roles = {name: set(roles) for name, (_d, roles)
                            in manifest.injected_skills().items()}
            cur.execute(_q(adapter,
                "SELECT role, files_json FROM studio_agent_defs "
                "WHERE workspace_code = ?"), (code,))
            for r in cur.fetchall():
                row = r if isinstance(r, dict) else dict(r)
                files = json.loads(row["files_json"] or "{}")
                led = ledger.get(row["role"]) or {}
                # A DECLARED skill is carried by name, so the live workspace
                # holds a materialised copy of it that the repo must not
                # receive — writing it back would recreate the very duplication
                # the declaration removed, and the `skills.yaml` exported
                # alongside it would then be redundant with a copy that can
                # drift from the original.
                try:
                    declared = set(parse_declared_skills(
                        files.get("skills.yaml") or "",
                        where=f"{row['role']}/workspace/skills.yaml"))
                except SkillDeclarationError:
                    # A declaration this broken already refuses at import; an
                    # export is the operator trying to GET it back, so hand
                    # over what there is rather than blocking the repair.
                    declared = set()
                carries = _regenerated_carries(
                    row["role"], files, declared, assignments, opening,
                    skip_skills, inject_roles)
                # ONE HASH DOMAIN. Build what the repo WOULD hold, hash that,
                # and compare it to the marker -- because push and `diff`
                # compute their hash over the REPO's key set
                # (`agent_content_hash(files, only=repo_keys)`), while this
                # loop compared the whole database snapshot. For an agent the
                # two never agree: the row holds platform-seeded skills, a
                # regenerated AGENTS.md and the materialised copy of every
                # declared skill, none of which the repo receives.
                #
                # Anchoring the database-side hash therefore left push and
                # `diff` permanently disagreeing with pull: push refused the
                # item as diverged, pull answered "pulled 0 item(s)" because
                # by ITS measure nothing had changed, and `diff` reported
                # diverged forever. The documented recovery -- "export the
                # diverged items first" -- could not terminate, and
                # `--take-repo` was the only way out.
                dest = agents_root / row["role"] / "workspace"
                out_files = exportable_agent_files(
                    files, skip_skills | declared | carries)
                assignment_drifted = carries != declared
                if assignment_drifted and (carries or declared):
                    # `carries or declared`: an agent with no declaration and
                    # nothing to declare gets no file, not an empty stub.
                    # ONLY on drift: with the two in agreement the author's
                    # own file passes through verbatim, comments included.
                    out_files["skills.yaml"] = _render_declared_skills(
                        sorted(carries))
                # Hash WHAT THE REPO WILL HOLD: the files about to be written,
                # plus the author's existing declaration when it is being left
                # alone -- because that is the file push will hash.
                hash_files = dict(out_files)
                if "skills.yaml" not in hash_files:
                    try:
                        _existing = dest / "skills.yaml"
                        if _existing.is_file():
                            hash_files["skills.yaml"] = _existing.read_text(
                                encoding="utf-8")
                    except OSError:         # pragma: no cover - defensive
                        pass
                target_hash = agent_content_hash(hash_files)
                if (led.get("origin") == "repo"
                        and target_hash == (led.get("imported_hash") or "")):
                    continue
                regenerated = out_files.get("skills.yaml") if assignment_drifted                     else None
                if regenerated is not None:
                    assignment_refreshed.append(row["role"])
                    # AND WRITE IT BACK, so the row states what the repo now
                    # holds. `declared` is parsed from THIS ROW's stored
                    # skills.yaml; leaving it stale kept the row describing an
                    # assignment that no longer matched either side.
                    files["skills.yaml"] = regenerated
                    try:
                        cur.execute(_q(adapter,
                            "UPDATE studio_agent_defs SET files_json = ?, "
                            "updated_at = ? WHERE workspace_code = ? "
                            "AND role = ?"),
                            (json.dumps(files), _now(), code, row["role"]))
                    except Exception:       # pragma: no cover - defensive
                        logger.warning(
                            "could not write back the regenerated declaration "
                            "for %s; the next pull will repeat it", row["role"])
                for rel, content in out_files.items():
                    write_file(dest / rel, content)
                exported_agents.append(row["role"])
                wrote_to[f"agent/{row['role']}"] = str(dest)
                # Anchor the hash of what was WRITTEN, which is the domain
                # push and `diff` measure in. Anchoring the database-side
                # hash is what made them disagree with pull permanently.
                _anchor_pulled_item(adapter, cur, code, "agent", row["role"],
                                    sha, target_hash)

        # Skills — the last kind that could be refused but not exported, which
        # made import's "export the diverged items first" advice a dead end for a
        # Studio-edited skill. Possible only now that a skill has a content row;
        # before, the DB side was a derived staging dir with nothing to write back.
        exported_skills: list[str] = []
        # An inject-dir skill goes back to ITS OWN dir, not the skills root —
        # writing it to the skills root would silently relocate it and change
        # who receives it (inject.yaml `roles:` vs the file's frontmatter).
        declared_dirs = manifest.skill_dirs()
        if declared_dirs:
            ledger = _item_ledger(adapter, con, code, "skill")
            try:
                cur.execute(_q(adapter,
                    "SELECT name, files_json, origin, imported_hash "
                    "FROM studio_skills WHERE workspace_code = ?"), (code,))
                skill_rows = [r if isinstance(r, dict) else dict(r)
                              for r in cur.fetchall()]
            except Exception:
                skill_rows = []
            # Only skills the manifest actually declares: an agent-carried skill
            # is exported as part of its agent's workspace above, and a pack skill
            # is not this repo's to own.
            for row in skill_rows:
                dest = declared_dirs.get(row["name"])
                if dest is None:
                    continue
                files = json.loads(row["files_json"] or "{}")
                led = ledger.get(row["name"]) or {}
                drifted = (row.get("origin") != "repo"
                           or content_hash("", files) != (led.get("imported_hash") or ""))
                if not drifted:
                    continue
                for rel, content in files.items():
                    write_file(dest / rel, content)
                exported_skills.append(row["name"])
                wrote_to[f"skill/{row['name']}"] = str(dest)
                _anchor_pulled_item(adapter, cur, code, "skill", row["name"],
                                    sha, content_hash("", files))
                # Same split as workflows: the hash is compared against the
                # ledger, but `origin` is read from studio_skills.
                cur.execute(_q(adapter,
                    "UPDATE studio_skills SET origin = 'repo', updated_at = ? "
                    "WHERE workspace_code = ? AND name = ?"),
                    (_now(), code, row["name"]))

        cur.execute(_q(adapter,
            "UPDATE studio_workspace_repos SET last_exported_at = ?, updated_at = ? "
            "WHERE workspace_code = ?"), (_now(), _now(), code))
        try:
            con.commit()
        except Exception:
            pass
        return EXIT_OK, {"workspace": code, "sha": sha, "exported": exported,
                         "exported_agents": exported_agents,
                         "exported_skills": exported_skills,
                         "assignment_refreshed": assignment_refreshed,
                         "wrote_to": wrote_to,
                         "target": str(target_root) if target_root else "",
                         "note": "working tree updated — review and commit in git; "
                                 "the platform never commits for you"}
