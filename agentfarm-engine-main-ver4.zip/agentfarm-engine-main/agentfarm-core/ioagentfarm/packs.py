"""AgentFarm pack registry — the SDK extension seam.

A *pack* contributes content (workflows, agent workspaces, skills, products,
goals, taxonomy, UI labels) to the runtime. Core discovers packs at startup and
merges their content through this registry, so a domain solution plugs in
*without editing any core code*.

Discovery order (each contributes; precedence noted per-scanner):
  1. ``core_pack()``      — the built-in pack shipped with agentfarm-core.
  2. entry-point packs    — every installed distribution that declares a
                            ``aicore.packs`` entry point returning a ``Pack``.

The filesystem overlay under ``.iof/`` (handled by individual loaders) still
takes precedence over any pack source — that behavior is unchanged.

Phase 1 note: ``core_pack()`` currently wraps the monolithic ``ioagentfarm.*``
packages so registry-based resolution is byte-for-byte identical to the old
hardcoded single-package scan. In Phase 3+ it narrows to the shared ``corepack``
(engine skills + shared agents) and domain content moves out to entry-point
packs (``solutions/<domain>``) + the shared-skills pack.
"""
from __future__ import annotations

import importlib.util
import logging
from dataclasses import dataclass, field
from functools import lru_cache
from importlib import resources
import dataclasses
from importlib.metadata import entry_points
from pathlib import Path
from typing import Optional

import yaml

try:  # Python 3.11+: canonical location
    from importlib.resources.abc import Traversable
except ImportError:  # pragma: no cover - older interpreters
    from importlib.abc import Traversable  # type: ignore

logger = logging.getLogger(__name__)

#: Distributions register a pack by pointing this entry-point group at a
#: zero-arg callable (or a ``Pack`` instance) in their package, e.g.::
#:
#:     [project.entry-points."aicore.packs"]
#:     procurement = "agentfarm_procurement:pack"
ENTRY_POINT_GROUP = "aicore.packs"

#: Groups still discovered. A pack built before the product was named AI Core
#: Harness declares the first of these, and its entry-point metadata is baked
#: into an INSTALLED distribution — a pack author cannot fix it by editing a
#: file, only by rebuilding and reinstalling. Dropping this would make such a
#: pack vanish with no error at all: ``load_registry()`` would simply return
#: fewer packs, and the first symptom is a workflow that cannot find its agent.
LEGACY_ENTRY_POINT_GROUPS = ("agentfarm.packs",)

#: Every group discovered, preferred first. A pack declaring the same entry-point
#: name in two groups is taken from the current one.
ENTRY_POINT_GROUPS = (ENTRY_POINT_GROUP, *LEGACY_ENTRY_POINT_GROUPS)


@dataclass(frozen=True)
class Pack:
    """A unit of content contributed to the runtime.

    ``workspace`` is the one required value: the WORKSPACE this content
    belongs to. ``name`` is its deprecated spelling (2026-08-25) — the two
    are made equal at construction, so every reader of ``.name`` still
    works and ``Pack(name=...)`` still constructs. ``pack`` is this pack's
    OWN identity: the ``aicore.packs`` entry-point name, attached by
    discovery, or set explicitly (core sets ``"core"``). It is what a
    collision report names when two packs of ONE workspace ship the same
    content — the one thing ``workspace`` cannot say. Every other field is
    optional — a pack contributes only the dimensions it has (e.g. the
    shared-skills pack sets only ``skills``; a domain pack sets
    ``workflows``/``agents``/``skills``/``metadata``).

    ``name`` is the WORKSPACE FAMILY code, and every distribution of one
    workspace repo declares the SAME name. That is how a team shares content
    across its solutions: the family's shared pack carries the agents, skills
    and tools once; each solution package carries only its workflows and sets
    ``solution`` so the catalog can attribute them. The pharma repo is the
    canonical shape — ``pharma_common`` (agents, no workflows),
    ``barrier_signal`` and ``signal_brief`` (workflows, no agents), all three
    ``name="barrier_insights"``. A standalone single-package repo is simply a
    workspace-of-one: same name, ``solution`` omitted.

    Because the family shares one name, role/skill/tool names must be unique
    ACROSS the family — the shared pack is the only carrier of agents, skills
    and tools; a solution package shipping any of them is an authoring error
    (``detect_collisions`` flags it as ``same_family``).

    Content fields are ``Traversable`` roots (from ``importlib.resources.files``)
    so a pack can ship its content as ordinary package data and stay
    zip-safe / installable from an artifact repository.
    """

    #: DEPRECATED spelling of ``workspace`` — kept first and positional so
    #: ``Pack("acme")`` and ``Pack(name="acme")`` keep working.
    name: Optional[str] = None
    #: The SOLUTION this pack's workflows belong to, within the family named by
    #: ``name``. ``None`` (the default, and every pre-existing pack) means the
    #: pack IS the solution — solution code == family code. Only
    #: workflow-carrying packs of a multi-solution workspace need to set it;
    #: consumed by the workflow catalog sync (``workflow_solution_map``) so the
    #: Studio can say which solution a workflow came from. Never used for
    #: agent/skill/tool resolution — those are family-level by design.
    solution: Optional[str] = None
    workflows: Optional[Traversable] = None
    #: SWARMS — the goal-oriented sibling of ``workflows``: each subdirectory
    #: holds a ``swarm.yaml`` (meta-agent + roster + goal contract), compiled
    #: at run creation into a one-step workflow (``engine/swarms.py``).
    #: Solution-level, like workflows.
    swarms: Optional[Traversable] = None
    agents: Optional[Traversable] = None
    skills: Optional[Traversable] = None
    #: CURATED WORKSPACE MEMORY — Markdown under ``solutions/<ws>/memory/``,
    #: routed by path (``workspace/``, ``role/<role>/``, ``user/<id>/``,
    #: ``solution/<code>/``; a top-level file is workspace-wide). Carried
    #: whole into the workspace-memory store as authored context and
    #: injected into every agent of the workspace. Workspace-level, like
    #: agents and skills. See ``engine/memory/packtier.py``.
    memory: Optional[Traversable] = None
    products: Optional[Traversable] = None
    goals: Optional[Traversable] = None
    taxonomy: Optional[Traversable] = None
    #: Optional tool-name → UI-label overrides (replaces hardcoded strings in
    #: web/thought_processor.py once Phase 2 lands).
    labels: dict[str, str] = field(default_factory=dict)
    #: Optional list of **CLI tools** this pack's agents invoke via ``exec``
    #: (``vectorfs``, ``iof-query``, deck-export Node deps, …) — NOT MCP servers
    #: (those are wired in ``engine/iobot_config.py`` and have a different
    #: execution model). Each entry is a plain dict —
    #: ``{name, owner, installer?, bin?, package?, check?}`` — consumed by the
    #: setup-time resolver (``tools_resolver``). Core never inspects the contents;
    #: a pack populates this in its ``pack()`` (typically by reading its own
    #: ``tools.yaml``), keeping core domain-free. See ``PackRegistry.tools()``.
    tools: list[dict] = field(default_factory=list)
    #: Optional ``{server_name: entry}`` — **MCP servers** this pack's content
    #: needs, typically loaded from the pack's own ``mcp.yaml`` via
    #: :func:`load_mcp_servers`. The MCP analogue of ``tools``: a pack ships
    #: DEFAULTS ("my skills use the ``github`` server, here is how to reach
    #: it"); the machine-global config and the workspace's ``mcp.yaml``
    #: override by server name (see ``engine/iobot_config.py``,
    #: ``merged_mcp_servers``). Entries are iobot ``MCPServerConfig``-shaped
    #: dicts (``command``/``args``/``env`` or ``url``/``headers``, plus
    #: ``toolTimeout``/``enabledTools``); ``${VAR}`` refs stay unexpanded so
    #: no secret ever ships in a wheel. Core never interprets the fields.
    mcp_servers: dict[str, dict] = field(default_factory=dict)
    #: Optional ``{delivery_kind: {tool: ...} | {tools: [...]}}`` — the tools
    #: this workspace sends CASE ACTIONS through (``email``,
    #: ``monitoring_task``, and the tools a ``verification`` contract may
    #: name), typically loaded from the pack's own ``deliveries.yaml`` via
    #: :func:`load_deliveries`. The LOWEST tier: the workspace's
    #: ``deliveries.yaml`` and ``IOF_CASE_DELIVERIES`` outrank it. See
    #: ``engine/deliveries.py``.
    deliveries: dict[str, dict] = field(default_factory=dict)
    #: Optional ``{default: ..., models: {provider/model: {status, ...}}}`` —
    #: the MODEL REGISTRY this pack ships, typically loaded from its own
    #: ``models.yaml`` via :func:`load_models`. The LOWEST tier: the
    #: workspace's ``models.yaml`` and ``IOF_MODELS`` outrank it. See
    #: ``engine/model_registry.py``.
    models: dict = field(default_factory=dict)
    #: Optional ``{skill_name: "all" | [role, …]}`` — the OPENING HAND a
    #: brand-new agent workspace starts with, before anyone has assigned
    #: anything. Typically loaded from the pack's own ``skill_defaults.yaml``.
    #:
    #: NOT a permission and NOT a gate. Nothing consults it to refuse a skill:
    #: a workflow may name any skill in the workspace, the Studio may assign
    #: any skill to any agent, and import never refuses one. It is read ONCE
    #: per agent, and from then on the assignment record (``studio_skills``)
    #: is authoritative — including removals. Change the mapping in the
    #: database and this is never consulted again.
    #:
    #: Each pack declares its OWN roles, which is what keeps core domain-free:
    #: the shared-skills wheel declares the universally-useful skills, and a
    #: domain pack declares what its own agents start with. Core never names
    #: a domain role. See ``PackRegistry.skill_defaults()``.
    skill_defaults: dict[str, object] = field(default_factory=dict)
    #: THE WORKSPACE this content belongs to — the family code every
    #: distribution of one workspace repo declares. Equal to ``name``.
    workspace: Optional[str] = None
    #: This pack's OWN identity — the entry-point name (attached at
    #: discovery) or an explicit value. Never a tenant, never resolved
    #: against; it exists so a report can name the culprit.
    pack: Optional[str] = None

    def __post_init__(self) -> None:
        ws = self.workspace or self.name
        if not ws:
            raise ValueError(
                "Pack needs the workspace code its content belongs to: "
                "Pack(workspace=...) (`name=` is the deprecated spelling)")
        object.__setattr__(self, "workspace", ws)
        object.__setattr__(self, "name", ws)


def _res(pkg: str) -> Optional[Traversable]:
    """Resolve a package to a Traversable root, or ``None`` if absent."""
    try:
        return resources.files(pkg)
    except (ModuleNotFoundError, TypeError, ImportError):
        return None


def _core_cli_tools() -> list[dict]:
    """Core-owned CLI-tool declarations from ``ioagentfarm/tools.yaml`` (empty if
    absent). These are CLI tools agents invoke via ``exec`` (iof-query, vectorfs)
    — NOT MCP servers. The setup-time resolver validates/builds them."""
    try:
        raw = (resources.files("ioagentfarm") / "tools.yaml").read_text(encoding="utf-8")
    except (FileNotFoundError, OSError, ModuleNotFoundError):
        return []
    try:
        spec = yaml.safe_load(raw) or {}
    except yaml.YAMLError:
        return []
    return list(spec.get("tools", []) or [])


def core_pack() -> Pack:
    """The built-in pack shipped inside agentfarm-core.

    Ships ONLY what the framework owns: the always-on agents **Jarvis**,
    **Quinn** (queryngine) and **Alex** (project_lead). The generic
    software-delivery team (analyst, developer, reviewer, strategist, …) and
    its workflows (feature_dev, story_loop, bug_fix, …) moved to the
    ``agentfarm-devkit`` pack — they are useful content, not framework, and a
    client installing core to run their own solution should not inherit a
    software-delivery team plus its domain skills.

    ``workflows`` carries ONLY the play tier's platform workflows
    (``ioagentfarm/workflows/``: ``playbook_compile`` since 2026-08-25;
    ``case_action`` follows once its delivery tools are deployment-declared).
    They are domain-free machinery the meta agent, ``iof-plays`` and
    ``iof-case`` - all already in core - depend on, and shipping them here
    is what makes a compiler fix a version bump instead of a copy in every
    workspace. Every other workflow is solution-level and arrives through a
    pack. Skills live inside each agent workspace rather than a top-level
    package, so ``skills`` stays ``None`` and the workspace scanner picks
    them up via ``agents``.
    """
    # The name is ``core``, not ``ioagentfarm-core``. It was the latter until
    # 2026-08-16, and every surface that put it in front of a person rewrote it
    # on the way out - five sites in ``catalog_sync`` plus one in the Studio
    # router, all spelling ``"core" if pack.name == "ioagentfarm-core"``. So
    # the distribution name never reached the database: the catalog has always
    # stored ``core``, and renaming here changes no stored data. What it fixes
    # is the leak the rewrites did not cover - ``load_registry()`` handed the
    # raw name to anything reading it directly, which is why the setup docs
    # told a client to expect ``ioagentfarm-core`` from a registry dump while
    # every catalog surface said ``core``. One name now, defined once.
    return Pack(
        workspace="core",
        pack="core",
        workflows=_res("ioagentfarm.workflows"),
        agents=_res("ioagentfarm.agents"),
        products=_res("ioagentfarm.products"),
        tools=_core_cli_tools(),
        mcp_servers=load_mcp_servers("ioagentfarm"),
        # The framework's ONE universal skill. Every agent carries
        # output_protocol by construction (scaffolds copy it, seeding adds
        # it, workflow resolution always includes it) — but until core SAID
        # so, the opening hand had no entry for it, and `workspace export`
        # read each agent's output_protocol assignment row as a deliberate
        # tenant choice made BEYOND the packs' defaults, declaring it into
        # every exported skills.yaml. The baseline belongs to the wheel that
        # re-deals it on any install, not to the repo round trip.
        skill_defaults={"output_protocol": "all"},
    )


def load_mcp_servers(package: str) -> dict[str, dict]:
    """A pack's ``mcp.yaml`` as ``{server_name: entry}``.

    Helper so every pack loads its own the same way — the ``tools.yaml``
    convention applied to MCP servers, in a SEPARATE file because
    ``tools.yaml`` is documented CLI-only and the two have different
    execution models. Expected shape::

        mcp_servers:
          github:
            command: npx
            args: ["-y", "@modelcontextprotocol/server-github"]
            env: { GITHUB_TOKEN: "${GITHUB_TOKEN}" }

    Missing or malformed file -> {}.
    """
    try:
        raw = (resources.files(package) / "mcp.yaml").read_text(
            encoding="utf-8")
    except (FileNotFoundError, OSError, ModuleNotFoundError, TypeError):
        return {}
    try:
        spec = yaml.safe_load(raw) or {}
    except yaml.YAMLError:
        logger.warning("%s/mcp.yaml is not valid YAML — ignored", package)
        return {}
    out = spec.get("mcp_servers") if isinstance(spec, dict) else None
    return out if isinstance(out, dict) else {}


def load_deliveries(package: str) -> dict[str, dict]:
    """A pack's ``deliveries.yaml`` as ``{delivery_kind: entry}`` — ``{}``
    when the pack ships none. See ``engine/deliveries.py`` for the shape."""
    from ioagentfarm.engine.deliveries import load_pack_deliveries
    return load_pack_deliveries(package)


def load_models(package: str) -> dict:
    """A pack's ``models.yaml`` as the raw ``{default, models}`` mapping —
    ``{}`` when the pack ships none. See ``engine/model_registry.py``."""
    from ioagentfarm.engine.model_registry import load_pack_models
    return load_pack_models(package)


def load_skill_defaults(package: str) -> dict[str, object]:
    """A pack's ``skill_defaults.yaml`` as ``{skill: "all" | [role, …]}``.

    Helper so every pack loads its own the same way — the ``tools.yaml``
    convention, applied to the opening hand. Missing or malformed file -> {}.
    """
    try:
        raw = (resources.files(package) / "skill_defaults.yaml").read_text(
            encoding="utf-8")
    except (FileNotFoundError, OSError, ModuleNotFoundError, TypeError):
        return {}
    try:
        spec = yaml.safe_load(raw) or {}
    except yaml.YAMLError:
        logger.warning("%s/skill_defaults.yaml is not valid YAML — ignored",
                       package)
        return {}
    out = spec.get("skill_defaults") if isinstance(spec, dict) else None
    return out if isinstance(out, dict) else {}


#: Packs whose ``pack()`` raised, as ``{entry-point name: one-line reason}``.
#:
#: A pack that fails to load is skipped, and every consumer downstream then
#: sees a world in which its agents simply do not exist - so each one reports
#: the absence in its own words, and the words are wrong. A client was told
#: "No installed pack provides an agent named 'chat_advisor'. Install the pack
#: that ships this agent" about a pack they had installed correctly and which
#: had announced its own failure moments earlier. This is how a downstream
#: message can tell the difference between "no such agent" and "the pack
#: carrying it is broken".
#:
#: Rewritten on every discovery pass, never appended to, so a pack fixed
#: without restarting the process stops being reported.
_BROKEN_PACKS: dict[str, str] = {}


def broken_packs() -> dict[str, str]:
    """Packs that failed to load on the most recent discovery, and why.

    Empty when discovery has not run - callers must treat "no entries" as
    "nothing known", never as "nothing wrong".
    """
    return dict(_BROKEN_PACKS)


def content_root(package: str):
    """A pack's content directory, or ``None`` if it cannot be resolved.

    ``importlib.resources.files()`` RAISES for a directory that is declared
    in ``pyproject.toml`` and absent from disk, and a pack's roots are
    resolved inside its own ``pack()``, so one missing OPTIONAL directory
    takes down agents, skills, tools and workflows together. A curated
    `memory/` root that nobody created should mean "this workspace has no
    curated memory" - it should not mean the workspace has no agents.

    Both failure shapes are Python internals with no useful text:
    ``FileNotFoundError: MultiplexedPath must contain at least one path``
    (the directory is gone) and ``NotADirectoryError: MultiplexedPath only
    supports directories`` (an editable install's finder still points at it).
    Neither names the package or the path.

    Use this for OPTIONAL roots. A required root should still raise - a pack
    with no agents directory is broken, and silence there would be worse.
    """
    from importlib import resources

    try:
        return resources.files(package)
    except (FileNotFoundError, NotADirectoryError, ModuleNotFoundError) as exc:
        logger.warning(
            "pack content root %r could not be resolved (%s: %s) - that tier "
            "is treated as EMPTY. If the directory is declared in "
            "pyproject.toml, either create it or remove the mapping; if it "
            "was added after `pip install -e`, reinstall the pack.",
            package, type(exc).__name__, exc)
        return None


def _discover_entry_point_packs() -> list[Pack]:
    """Entry-point packs, sorted by entry-point name.

    The sort is load-bearing: several consumers are first-match-wins across
    packs (agent workspaces, workflow dirs, skill sources), and
    ``entry_points()`` iteration order is undeclared and install-order
    dependent. Sorting makes "which pack wins a name collision" reproducible
    across machines — and :func:`detect_collisions` makes the collision itself
    loud instead of silent.
    """
    loaded: list[tuple[str, Pack]] = []
    seen: set[str] = set()
    # Rewritten, not appended to: a pack fixed in a long-lived process must
    # stop being reported as broken.
    _BROKEN_PACKS.clear()
    for group in ENTRY_POINT_GROUPS:
        try:
            eps = entry_points(group=group)
        except Exception:  # pragma: no cover - importlib.metadata edge cases
            logger.debug("entry_points(group=%r) discovery failed", group, exc_info=True)
            continue
        for ep in eps:
            # The current group wins: a pack rebuilt under the new name while an
            # older install of itself lingers must not be loaded twice.
            if ep.name in seen:
                continue
            seen.add(ep.name)
            if group != ENTRY_POINT_GROUP:
                logger.info(
                    "pack %r was found under the legacy entry-point group %r; it "
                    "still loads, but rebuild it against %r when convenient",
                    ep.name, group, ENTRY_POINT_GROUP,
                )
            try:
                obj = ep.load()
                pack = obj() if callable(obj) else obj
                if isinstance(pack, Pack):
                    # The entry-point name IS the pack's identity. It used to
                    # be sorted on and then discarded, so a collision inside
                    # one workspace could only print the workspace twice.
                    if pack.pack is None:
                        pack = dataclasses.replace(pack, pack=ep.name)
                    loaded.append((ep.name, pack))
                else:
                    logger.warning(
                        "pack entry point %r did not return a Pack (got %r); skipping",
                        ep.name, type(pack).__name__,
                    )
            except Exception as exc:
                _BROKEN_PACKS[ep.name] = f"{type(exc).__name__}: {exc}"
                logger.warning("%s", _broken_pack_message(ep, exc))
                logger.debug(
                    "pack entry point %r raised", ep.name, exc_info=True,
                )
    loaded.sort(key=lambda item: item[0])
    return [pack for _, pack in loaded]


def _broken_pack_message(ep, exc: BaseException) -> str:
    """One actionable line for a pack whose ``pack()`` raised.

    The traceback this replaces was 27 lines on EVERY command, and it buried
    the only two facts that matter: the pack is skipped, so every agent,
    skill and tool it carries is gone, and a stale editable install is the
    usual cause. A pack's content roots are resolved inside its own
    ``pack()`` function, so the harness cannot load it partially — but it can
    say precisely what was lost and what to do.
    """
    lost = "its agents, skills, tools and workflows are NOT available"
    head = f"pack {ep.name!r} failed to load - {lost}: {type(exc).__name__}: {exc}"

    missing = getattr(exc, "name", None) if isinstance(exc, ModuleNotFoundError) else None
    if missing:
        # The upgrade failure mode: `pip install -e` writes a finder listing
        # the packages that existed AT INSTALL TIME, so a content package
        # added to pyproject.toml afterwards (a `memory/` root, a new
        # solution) never resolves and takes the whole pack down with it.
        where = _distribution_hint(ep)
        head += (
            f"\n  {missing!r} is declared by the pack but is not importable."
            " If this pack is installed with `pip install -e`, reinstall it -"
            " an editable install does not pick up packages added to"
            " pyproject.toml since it was installed"
        )
        if where:
            head += f":\n    pip install -e {where}"
        return head

    # THE DOWNGRADE SHAPE. A pack written against a newer engine passes a
    # keyword this `Pack` does not have, and the whole pack is skipped - so a
    # rollback silently removes every agent, skill and tool the tenant owns,
    # while chat keeps answering from the materialized cache and `aicore
    # current` still lists the workspace as live content. An upgrade
    # validator hit exactly this rolling back three days:
    # `Pack.__init__() got an unexpected keyword argument 'memory'`.
    #
    # `TypeError` alone says nothing about versions. Naming the cause is the
    # difference between a five-minute fix and an afternoon.
    # THE MISSING-CONTENT-ROOT SHAPE, and the message is pure Python
    # internals: "MultiplexedPath only supports directories" names neither
    # the package nor the path, and a client reading it concluded they had
    # missed `pip install`. Both spellings mean one thing - a directory this
    # pack's pyproject maps is not a directory on disk.
    if (isinstance(exc, (NotADirectoryError, FileNotFoundError))
            and "MultiplexedPath" in str(exc)):
        where = _distribution_hint(ep)
        if isinstance(exc, NotADirectoryError):
            # THE DIRECTORY IS PRESENT. Saying "create it" here sends the
            # reader looking for something that is already there - the first
            # version of this message did exactly that to the client who
            # found the bug.
            head += (
                "\n  A content directory this pack declares has no"
                " `__init__.py`, so an editable install treats it as a"
                " NAMESPACE package - and setuptools' namespace finder"
                " always appends a placeholder to the search path that is"
                " not a directory, which is what this error is. The"
                " directory itself is fine."
                "\n  Add an empty `__init__.py` to each directory named in"
                " [tool.setuptools.package-dir] (agents/, skills/, tools/,"
                " memory/), then reinstall - the reinstall is required,"
                " because it regenerates the finder."
            )
        else:
            head += (
                "\n  A content directory this pack declares does not exist"
                " on disk. `pyproject.toml` maps names like `<ws>_agents`,"
                " `<ws>_skills` and `<ws>_memory` onto directories; one of"
                " them is missing. Create the directory, or remove its line"
                " from [tool.setuptools.package-dir] and the matching"
                " `files(...)` call in the pack's __init__.py, then"
                " reinstall."
            )
        if where:
            head += f"\n    pip install -e {where}"
        return head

    if isinstance(exc, TypeError) and "unexpected keyword argument" in str(exc):
        head += (
            "\n  This pack was authored against a NEWER engine than the one"
            " installed: it passes a field this version of `Pack` does not"
            " have. Upgrade the engine, or install the pack version that"
            " matches it. Until then this workspace's content is NOT loaded -"
            " and a running agent may keep answering from its materialized"
            " copy, which is now stale."
        )
    return head


def _distribution_hint(ep) -> Optional[str]:
    """Best-effort path to reinstall from, for the message above only."""
    try:
        dist = getattr(ep, "dist", None)
        module = (ep.value or "").split(":")[0].split(".")[0]
        spec = importlib.util.find_spec(module)
        locations = getattr(spec, "submodule_search_locations", None) if spec else None
        if locations:
            # An editable install points at the source tree; the pyproject
            # sits at or above the mapped package directory.
            here = Path(list(locations)[0])
            for candidate in (here, *here.parents):
                if (candidate / "pyproject.toml").is_file():
                    return str(candidate)
        if dist is not None and getattr(dist, "name", None):
            return dist.name
    except Exception:  # pragma: no cover - a hint must never raise
        return None
    return None


class PackRegistry:
    """Ordered collection of packs with per-dimension source accessors.

    Sources are returned in pack order (core first, then entry-point packs in
    discovery order). Callers that want "first match wins" (workflows, agents)
    should iterate in order; callers that aggregate (skills) consume all.
    """

    def __init__(self, packs: list[Pack]):
        self._packs = list(packs)

    @property
    def packs(self) -> list[Pack]:
        return list(self._packs)

    def _sources(self, attr: str) -> list[Traversable]:
        out: list[Traversable] = []
        for p in self._packs:
            src = getattr(p, attr)
            if src is not None:
                out.append(src)
        return out

    def workflow_sources(self) -> list[Traversable]:
        return self._sources("workflows")

    def swarm_sources(self) -> list[Traversable]:
        return self._sources("swarms")

    def agent_sources(self) -> list[Traversable]:
        return self._sources("agents")

    def skill_sources(self) -> list[Traversable]:
        return self._sources("skills")

    def memory_sources(self) -> list[Traversable]:
        """Curated workspace-memory roots, in pack order (core first)."""
        return self._sources("memory")

    def product_sources(self) -> list[Traversable]:
        return self._sources("products")

    def goal_sources(self) -> list[Traversable]:
        return self._sources("goals")

    def taxonomy_sources(self) -> list[Traversable]:
        return self._sources("taxonomy")

    def labels(self) -> dict[str, str]:
        merged: dict[str, str] = {}
        for p in self._packs:
            if p.labels:
                merged.update(p.labels)
        return merged

    def tools(self) -> list[dict]:
        """All pack-declared tool specs, in pack order (core first).

        Each entry is the raw dict a pack put in ``Pack.tools`` (typically loaded
        from its ``tools.yaml``), annotated with ``_pack`` provenance. The
        setup-time resolver (``tools_resolver.resolve_all``) consumes these; core
        never interprets the fields, so a domain declares whatever tools it needs
        without any core edit.

        DEDUPED BY TOOL NAME, first pack wins. Two packs of one workspace family
        legitimately depend on the same tool; without the dedup the resolver
        validates (and potentially installs) it twice. A dropped duplicate that
        *differs* from the kept spec is warned about — that is two packs
        disagreeing on what the tool is, and only one of them can be right."""
        out: list[dict] = []
        kept: dict[str, tuple[str, dict]] = {}   # name -> (pack, raw spec)
        for p in self._packs:
            for spec in p.tools or []:
                if not isinstance(spec, dict):
                    continue
                name = str(spec.get("name") or "")
                if name and name in kept:
                    prior_pack, prior_spec = kept[name]
                    if spec != prior_spec:
                        logger.warning(
                            "CLI tool %r declared by pack %r and again by pack %r "
                            "with a DIFFERENT spec — keeping %r's declaration",
                            name, prior_pack, p.name, prior_pack)
                    continue
                out.append({**spec, "_pack": p.name})
                if name:
                    kept[name] = (p.name, spec)
        return out

    def mcp_servers(self) -> dict[str, dict]:
        """All pack-declared MCP server entries, merged by server name.

        FIRST PACK WINS (core first, then entry-point packs in discovery
        order) — same semantics as :meth:`tools`, and for the same reason:
        two packs of one workspace family legitimately need the same server,
        and a dropped duplicate that *differs* is two packs disagreeing on
        what the server is, so it is warned about. Each kept entry is
        annotated with ``_pack`` provenance; the merge in
        ``engine/iobot_config.py`` strips it before anything
        iobot-shaped is written. This is the LOWEST declaration tier —
        the machine-global config and the workspace ``mcp.yaml`` both
        override by name.
        """
        kept: dict[str, dict] = {}
        origin: dict[str, tuple[str, dict]] = {}   # name -> (pack, raw spec)
        for p in self._packs:
            for name, spec in (p.mcp_servers or {}).items():
                if not isinstance(name, str) or not isinstance(spec, dict):
                    continue
                if name in origin:
                    prior_pack, prior_spec = origin[name]
                    if spec != prior_spec:
                        logger.warning(
                            "MCP server %r declared by pack %r and again by "
                            "pack %r with a DIFFERENT spec — keeping %r's "
                            "declaration",
                            name, prior_pack, p.name, prior_pack)
                    continue
                kept[name] = {**spec, "_pack": p.name}
                origin[name] = (p.name, spec)
        return kept

    def deliveries(self) -> dict[str, dict]:
        """Pack-declared deliveries merged BY KIND, first pack wins — the same
        rule as :meth:`tools` and :meth:`mcp_servers`: a dropped duplicate
        that differs is two packs disagreeing on which tool sends an email,
        and only one of them can be right, so it is warned about."""
        out: dict[str, dict] = {}
        origin: dict[str, str] = {}
        for p in self._packs:
            for kind, entry in (p.deliveries or {}).items():
                if kind in out:
                    if entry != out[kind]:
                        logger.warning(
                            "delivery %r declared by pack %r and again by pack "
                            "%r with a DIFFERENT tool — keeping %r's",
                            kind, origin[kind], p.pack or p.workspace,
                            origin[kind])
                    continue
                out[kind] = dict(entry)
                origin[kind] = p.pack or p.workspace
        return out

    def models(self) -> dict:
        """Pack-declared model registries merged BY MODEL NAME, first pack
        wins; ``default`` from the first pack that declares one. ``{}`` when
        no pack ships a ``models.yaml`` — the registry is then absent at
        this tier and every model is allowed."""
        models: dict[str, object] = {}
        default = None
        origin: dict[str, str] = {}
        for p in self._packs:
            raw = p.models or {}
            if not isinstance(raw, dict):
                continue
            if default is None and raw.get("default"):
                default = raw["default"]
            for name, entry in (raw.get("models") or {}).items():
                if name in models:
                    if entry != models[name]:
                        logger.warning(
                            "model %r declared by pack %r and again by pack "
                            "%r with a DIFFERENT entry — keeping %r's",
                            name, origin[name], p.pack or p.workspace,
                            origin[name])
                    continue
                models[name] = entry
                origin[name] = p.pack or p.workspace
        if not models and default is None:
            return {}
        out: dict = {"models": models}
        if default is not None:
            out["default"] = default
        return out

    def skill_defaults(self) -> dict[str, object]:
        """Merged ``{skill_name: "all" | {role, …}}`` across every pack.

        The opening hand a brand-new agent starts with. Read ONCE per agent;
        after that ``studio_skills`` is authoritative, so a change made in the
        database is never overridden by this.

        MERGED BY UNION, not last-wins: two packs naming the same shared skill
        for different roles both mean it, and a later pack must not silently
        take the skill away from an earlier pack's agents. ``"all"`` absorbs
        any role list for that skill — it is already the widest claim.

        This is why core stays domain-free. The shared-skills wheel declares
        the universally-useful skills; each domain pack declares what ITS own
        agents start with. Nothing in ``agentfarm-core`` names a domain role.
        """
        merged: dict[str, object] = {}
        for p in self._packs:
            for name, roles in (p.skill_defaults or {}).items():
                if not isinstance(name, str):
                    continue
                prior = merged.get(name)
                if prior == "all" or roles == "all":
                    merged[name] = "all"
                    continue
                incoming = {str(r) for r in (roles or [])}
                merged[name] = (set(prior) if isinstance(prior, set)
                                else set()) | incoming
        return merged

    def domain_skill_injections(self) -> dict[str, list[Path]]:
        """``role -> [skill dirs]`` to seed into base agents at setup time.

        A pack declares setup-time skill injections via an underscore-prefixed
        content directory in its agent source containing an ``inject.yaml``::

            _procurement/inject.yaml:   { skills_dir: skills, roles: [aria] }

        This keeps core **domain-free**: it reads the manifest generically and
        never names a domain or a role. The domain knowledge ("aria receives the
        procurement skill pack") lives in the domain's own content and travels
        with it when the pack moves to ``solutions/<domain>``.
        """
        out: dict[str, list[Path]] = {}
        for root in self.agent_sources():
            try:
                entries = list(root.iterdir())
            except (FileNotFoundError, TypeError, NotADirectoryError):
                continue
            for entry in entries:
                if not entry.name.startswith("_"):
                    continue
                manifest = entry / "inject.yaml"
                try:
                    if not manifest.is_file():
                        continue
                    spec = yaml.safe_load(manifest.read_text(encoding="utf-8")) or {}
                except (FileNotFoundError, TypeError, NotADirectoryError, yaml.YAMLError):
                    continue
                skills_dir = entry / spec.get("skills_dir", "skills")
                try:
                    if not skills_dir.is_dir():
                        continue
                except (FileNotFoundError, TypeError, NotADirectoryError):
                    continue
                skills_path = Path(str(skills_dir))
                for role in spec.get("roles", []) or []:
                    out.setdefault(role, []).append(skills_path)
        return out


@dataclass(frozen=True)
class Collision:
    """One name claimed by more than one installed pack, in one dimension.

    ``packs`` holds the carriers' ``Pack.workspace`` values in registry
    order — the FIRST entry is the winner under first-match-wins resolution.
    ``carriers`` holds the same packs' OWN identities (``Pack.pack``), which
    is what names the culprit when ``packs`` is one workspace twice.
    """

    kind: str                # "agent" | "skill" | "tool"
    name: str                # the colliding role / skill / tool name
    packs: tuple[str, ...]   # carrying Pack.workspace values, registry order
    carriers: tuple[str, ...] = ()   # the same packs' Pack.pack, same order

    @property
    def same_family(self) -> bool:
        """All carriers share one ``Pack.name`` — i.e. two distributions of one
        workspace family both ship this name. That is an authoring error in the
        family's repo (the shared pack should be the only carrier)."""
        return len(set(self.packs)) == 1


def _pack_agent_roles(pack: Pack) -> list[str]:
    """Role names this pack ships an agent workspace for (``<role>/workspace/SOUL.md``)."""
    root = pack.agents
    if root is None:
        return []
    out: list[str] = []
    try:
        entries = list(root.iterdir())
    except (OSError, TypeError, NotADirectoryError):
        return out
    for entry in entries:
        if entry.name.startswith(("_", ".")):
            continue   # inject.yaml content dirs / metadata, not agents
        try:
            if (entry / "workspace" / "SOUL.md").is_file():
                out.append(entry.name)
        except (OSError, TypeError, NotADirectoryError):
            continue
    return out


def _pack_skill_names(pack: Pack) -> list[str]:
    """Skill names in this pack's TOP-LEVEL skills root (``Pack.skills``).

    Deliberately excludes agent-workspace-local skills: an agent-local copy
    shadowing a shared name is the DESIGNED override mechanism (resolution
    tier 1 — the agent's own workspace wins), not a collision. The collision
    that matters is two pack-level roots claiming one name, where first-wins
    is silent and install-order used to decide it.
    """
    root = pack.skills
    if root is None:
        return []
    out: list[str] = []
    try:
        entries = list(root.iterdir())
    except (OSError, TypeError, NotADirectoryError):
        return out
    for entry in entries:
        try:
            if (entry / "SKILL.md").is_file():
                out.append(entry.name)
        except (OSError, TypeError, NotADirectoryError):
            continue
    return out


def _pack_tool_names(pack: Pack) -> list[str]:
    """CLI tool names this pack declares (duplicates within one pack preserved)."""
    return [str(spec["name"]) for spec in (pack.tools or [])
            if isinstance(spec, dict) and spec.get("name")]


def _pack_mcp_server_names(pack: Pack) -> list[str]:
    """MCP server names this pack declares in its ``mcp.yaml``."""
    return [str(name) for name in (pack.mcp_servers or {})]


def _pack_swarm_names(pack: Pack) -> list[str]:
    """Swarm codes this pack ships (``<code>/swarm.yaml``)."""
    root = pack.swarms
    if root is None:
        return []
    out: list[str] = []
    try:
        entries = list(root.iterdir())
    except (OSError, TypeError, NotADirectoryError):
        return out
    for entry in entries:
        try:
            if (entry / "swarm.yaml").is_file():
                out.append(entry.name)
        except (OSError, TypeError, NotADirectoryError):
            continue
    return out


def _pack_workflow_names(pack: Pack) -> list[str]:
    """Workflow codes this pack ships (``<code>/workflow.yaml``).

    A cross-pack duplicate here is legal at the DATABASE level — workflow
    codes are unique per workspace, not globally — but the raw pack loader
    is still first-match-wins, so two installed packs shipping one code is
    worth a warning: whichever sorts first supplies the definition for any
    tenant that resolves it from pack sources rather than its own catalog.
    """
    root = pack.workflows
    if root is None:
        return []
    out: list[str] = []
    try:
        entries = list(root.iterdir())
    except (OSError, TypeError, NotADirectoryError):
        return out
    for entry in entries:
        try:
            if (entry / "workflow.yaml").is_file():
                out.append(entry.name)
        except (OSError, TypeError, NotADirectoryError):
            continue
    return out


def detect_collisions(registry: "PackRegistry") -> list[Collision]:
    """Every agent-role / pack-level-skill / tool name claimed by >1 pack.

    Pure inspection — no side effects. ``load_registry()`` calls this once per
    process and logs each finding, so a collision that used to be silent
    first-wins now names both carriers in the log.
    """
    found: list[Collision] = []
    scanners = (("agent", _pack_agent_roles),
                ("skill", _pack_skill_names),
                ("tool", _pack_tool_names),
                ("mcp_server", _pack_mcp_server_names),
                ("workflow", _pack_workflow_names),
                ("swarm", _pack_swarm_names))
    for kind, names_of in scanners:
        carriers: dict[str, list[str]] = {}
        owners: dict[str, list[str]] = {}
        for p in registry.packs:
            for name in names_of(p):
                carriers.setdefault(name, []).append(p.workspace)
                owners.setdefault(name, []).append(p.pack or p.workspace)
        for name in sorted(carriers):
            packs = carriers[name]
            if len(packs) > 1:
                found.append(Collision(kind=kind, name=name,
                                       packs=tuple(packs),
                                       carriers=tuple(owners[name])))
    return found


def uninstalled_solution_near(start=None):
    """``(repo_root, [entry-point names])`` for a solution repo at or above
    *start* whose ``aicore.packs`` entry points are NOT installed in this
    interpreter - or ``None``.

    The engine resolves content through installed entry points, so a
    freshly scaffolded solution is invisible until `pip install -e .` runs
    in the engine's venv. Every symptom of that reads as something else:
    "No installed pack provides an agent named X" after a teardown and a
    re-scaffold sent a team looking for a configuration step. The repo is
    right there on disk; this finds it so the error can name the command.
    """
    import sys
    import tomllib
    from importlib.metadata import entry_points
    from pathlib import Path as _P

    here = _P(start or _P.cwd()).resolve()
    for d in (here, *here.parents):
        pj = d / "pyproject.toml"
        if not pj.is_file():
            continue
        try:
            data = tomllib.loads(pj.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError):
            continue
        eps = ((data.get("project") or {}).get("entry-points") or {})
        declared = {}
        for group in ENTRY_POINT_GROUPS:
            declared.update(eps.get(group) or {})
        if not declared:
            continue
        installed = set()
        for group in ENTRY_POINT_GROUPS:
            try:
                installed.update(ep.name for ep in entry_points(group=group))
            except Exception:                  # noqa: BLE001
                pass
        missing = sorted(n for n in declared if n not in installed)
        if missing:
            return d, missing
        return None
    return None


def install_hint(start=None) -> str:
    """One sentence naming the uninstalled solution and its fix, or ''."""
    import sys
    found = uninstalled_solution_near(start)
    if not found:
        return ""
    root, names = found
    return (f" The solution at {root} declares pack(s) {', '.join(names)} "
            f"but they are not installed in this Python environment "
            f"({sys.prefix}): run `pip install -e \"{root}\"` with this "
            "environment's pip, then retry.")


@lru_cache(maxsize=1)
def load_registry() -> PackRegistry:
    """Build (and cache) the pack registry: core pack + entry-point packs.

    Also runs :func:`detect_collisions` and logs every finding — once per
    process, courtesy of the cache. A collision is never fatal here (a running
    deployment must not brick on content it has always tolerated); making it an
    ERROR is the manifest validator's and the linter's job.
    """
    packs = [core_pack()] + _discover_entry_point_packs()
    registry = PackRegistry(packs)
    for c in detect_collisions(registry):
        if c.same_family:
            logger.warning(
                "duplicate %s %r inside workspace %r: two distributions of one "
                "workspace ship it — packs %s; first in registry order wins "
                "(%r); the workspace's shared pack should be the only carrier",
                c.kind, c.name, c.packs[0], list(c.carriers), c.carriers[0])
        else:
            logger.warning(
                "%s name collision: %r shipped by packs %s — first in registry "
                "order wins (%r)", c.kind, c.name, list(c.packs), c.packs[0])
    logger.debug("agentfarm pack registry: %s", [p.name for p in packs])
    return registry


def reset_registry_cache() -> None:
    """Clear the cached registry (tests / dynamic install scenarios)."""
    load_registry.cache_clear()
