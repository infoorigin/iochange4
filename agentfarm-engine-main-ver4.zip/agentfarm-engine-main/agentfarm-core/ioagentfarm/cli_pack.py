"""`new-workflow` / `new-agent` / `new-skill` / `new-tool` / `assign-skill` —
grow a pack.

``new-solution`` hands someone a repo with one workflow, one agent and one
skill. Until these commands existed there was no way to add a SECOND of
anything: the only written guidance was a section of the framework's own
CLAUDE.md, addressed to people who maintain the engine, which is by definition
not the audience — they have never read this repo and never will.

``new-tool`` is here for the opposite reason: not that the second one is hard,
but that the FIRST one had no command at all. A skill is instructions and a CLI
tool is an executable, the platform's own rule is *if the correct behaviour can
be written as a script, write the script* — and a CLI offering `new-skill` and
nothing else nudges every author towards the prompt. It writes three artefacts
because a tool is not one file: the script, the ``console_scripts`` entry point
that puts it on PATH, and the ``tools.yaml`` declaration the setup-time resolver
reads. Two of the three are silent when missing — the script exists, nothing can
run it.

TELLING AN AGENT THE TOOL EXISTS IS A SECOND COMMAND, ``new-skill --tool``, and
the split is not tidiness. ``new-tool --role <agent>`` read as *this tool
belongs to this agent*, which is false: a console script is on PATH and every
agent can run it. What the flag actually scoped was the paired SKILL — one flag
doing a second thing at one remove, and the remove is where it misleads. So the
pipeline is written out instead: create the tool, write a skill around it,
assign the skill to an agent. ``new-skill --tool`` validates the name against
the pack's ``tools.yaml``, because a skill teaching an agent to run a binary
that does not exist is worse than no skill at all — the agent tries.

Hand-writing the second one is where it hurts, because every mistake is silent:

* ``requires_artifact:`` (no ``s``) loads clean. ``WorkflowLoader`` reads every
  field with ``data.get(...)``, so an unrecognised key is not rejected, it is
  never read — and the fail-closed artifact gate that stops a step reporting
  success without writing its handoff is simply off. The run "works" and a
  downstream step composes its section from a file that was never written.
  ``skilz:`` un-filters a role's skills the same way. That is why
  ``lint-workflow`` had to be written; a scaffold that emits a correct skeleton
  removes most of what the linter exists to catch, which is better than
  catching it.
* An agent without its OWN ``skills/output_protocol/SKILL.md`` emits no
  ``STATUS:``/``OUTPUT:``. It is not injected from core. Every step that agent
  runs is marked failed and retried to the hard attempt cap, having done the
  work correctly every time.

FLAG-DRIVEN, NOT INTERACTIVE. Prompting for each field was proposed and
rejected: these are commands people run more than once, often from a script or
with shell history, and a prompt sequence cannot be replayed from either.

TEMPLATES COME FROM ``cli_scaffold``. Nothing here re-declares a workflow
skeleton, a SOUL or a step-prompt tail — two copies of a skeleton is the exact
drift this repo keeps paying for, and the copy that rots is always the one
nobody is reading. What IS declared here is the content that has no counterpart
in ``new-solution``: prompts for steps whose purpose the author has not told us,
and a domain skill (the scaffold's is a house-style skill, which is a specific
thing, not a generic one).
"""
from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass
from pathlib import Path

import typer
from rich.console import Console

from ioagentfarm.cli_scaffold import (_declared_pack_eps,
                                      _installed_pack_names)
from ioagentfarm.packs import ENTRY_POINT_GROUP as PACK_ENTRY_POINT_GROUP
from ioagentfarm.solution_manifest import MANIFEST_NAME, find_manifest

from ioagentfarm.cli_scaffold import (
    A2A_CARD,
    invocation,
    CATALOG_YAML,
    MEMORY_MD,
    ROLE_PROMPT,
    SOUL,
    SOUL_DATA,
    SWARM_META_MD,
    SWARM_ROLE_MD,
    SWARM_YAML,
    TOOLS_MD,
    TOOLS_MD_DATA,
    TOOLS_YAML,
    _prog,
    _write,
    render_workflow_yaml,
    sectioned_write_note,
    step_output_block,
)

console = Console()

#: Workflow names, agent roles and skill names all become directory names, and
#: two of the three also become Python-ish identifiers in YAML. Two characters
#: minimum rather than the three ``new-solution`` demands of a package name:
#: `qa` is a real role and nothing downstream cares.
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,48}$")

#: Step keys become directory names under the run output and forensics trees.
#: Looser than NAME_RE because the engine itself allows `[A-Za-z0-9_.-]`, and
#: `:` is refused outright — that prefix belongs to the `story:<id>:<suffix>`
#: keys the fan-out materializes and the scheduler routes on.
STEP_KEY_RE = re.compile(r"^[A-Za-z0-9_.-]+$")

#: MCP server names may carry a hyphen: the name is a config key,
#: not a Python module.
_MCP_NAME_RE = re.compile(r"^[a-z][a-z0-9_-]{0,48}$")

def _normalised(value: str, pattern: "re.Pattern[str]") -> str | None:
    """`value` corrected by the obvious mechanical rules, or None.

    Never invents a name. It lowercases, folds every disallowed run to a
    single underscore and trims the ends - and if the result still does
    not match, it offers nothing rather than something wrong.
    """
    cand = re.sub(r"[^a-z0-9_]+", "_", str(value).strip().lower())
    cand = re.sub(r"_{2,}", "_", cand).strip("_")
    if not cand or cand == str(value) or not pattern.match(cand):
        return None
    return cand


def refuse_name(value: str, becomes: str,
                pattern: "re.Pattern[str]" = None) -> typer.BadParameter:
    """The refusal a malformed name gets, with the fix in it.

    A raw regex states what is wrong and leaves the reader to work out
    what to type. That gap is not cosmetic: observed live, the builder
    agent ran `new-tool brand-scan`, was handed
    `^[a-z][a-z0-9_]{1,48}$`, and ABANDONED the scaffold path rather than
    retry with an underscore - hand-editing tools.yaml to declare a tool
    that no script and no entry point provided, then writing a skill
    teaching agents to run a binary that does not exist. The defect was
    not the refusal. It was that the refusal did not say `brand_scan`.
    """
    pattern = pattern if pattern is not None else NAME_RE
    hint = _normalised(value, pattern)
    tail = f" Did you mean {hint!r}?" if hint else ""
    return typer.BadParameter(
        f"{value!r} must match {pattern.pattern} - it becomes "
        f"{becomes}.{tail}")


# ── finding the pack ─────────────────────────────────────────────────

@dataclass
class PackPkg:
    """One ``aicore.packs`` entry point's package, inside a repo.

    A classic solution repo has exactly one. A WORKSPACE repo has several —
    the family's shared package (agents + skills + tools, no workflows) and
    one package per solution (workflows only) — either as one distribution
    with several entry points (``new-workspace`` output) or as several
    distributions in sibling directories (the pharma monorepo shape).
    """

    dist_dir: Path        # directory holding the pyproject.toml
    pkg_dir: Path         # the import package — agents/, skills/, workflows/
    pkg: str
    slug: str             # entry-point name
    title: str
    solution: str = ""    # solution code (manifest `solutions:`), "" otherwise

    def agent_roles(self) -> list[str]:
        agents = self.pkg_dir / "agents"
        if not agents.is_dir():
            return []
        # Underscore dirs are inject.yaml content, not agents — a package
        # holding ONLY an inject dir (signal_brief's shape) carries no agent.
        return sorted(p.name for p in agents.iterdir()
                      if not p.name.startswith(("_", "."))
                      and (p / "workspace").is_dir())

    @property
    def is_content(self) -> bool:
        """The family's content home: agents and pack-level skills live here.

        SHAPE first, contents second. A freshly scaffolded shared package has
        an agents/ root, a skills/ root and nothing in either - judging by
        contents alone would refuse the very first `new-agent` for lack of an
        agent. A package whose roots say "agents and skills, no workflows" IS
        the shared package, empty or not.
        """
        has_agent_root = (self.pkg_dir / "agents").is_dir()
        has_skill_root = (self.pkg_dir / "skills").is_dir()
        if (has_agent_root or has_skill_root) and not self.has_workflows:
            return True
        if self.agent_roles():
            return True
        skills = self.pkg_dir / "skills"
        try:
            return skills.is_dir() and any(
                (d / "SKILL.md").is_file() for d in skills.iterdir())
        except OSError:               # pragma: no cover - unreadable dir
            return False

    @property
    def has_workflows(self) -> bool:
        return (self.pkg_dir / "workflows").is_dir()


@dataclass
class PackRepo:
    """A solution repo, located from the directory the command was run in.

    ``root``/``pkg_dir``/``pkg``/``slug`` describe the PRIMARY package — the
    only one in a classic repo, the content-holding (shared) one in a
    workspace repo. ``packages`` lists every package; commands that need a
    specific kind go through :meth:`require_content_target` (agents / skills /
    tools land in the shared package) or :meth:`workflow_package` (workflows
    are solution-level).
    """

    root: Path            # the repo — pyproject.toml / aicore.solution.yaml
    pkg_dir: Path         # <root>/<pkg> — where agents/, skills/, workflows/ live
    pkg: str
    slug: str
    solution: str
    title: str
    dist_dir: Path = None                     # the primary's pyproject dir
    packages: list = None                     # list[PackPkg]; never empty
    start: Path = None                        # where the command was run
    _primary_reason: str = "only"             # only|cwd|content|ambiguous
    #: FLAT layout only: the IMPORT name of the package-dir-mapped tools
    #: package (`acme_tools` mapped onto `tools/`). None in packaged repos,
    #: where the tools subpackage is `<pkg>.tools` as ever. `new-tool` keys
    #: its console-script target and pyproject wiring off this.
    tools_import: str = None

    def __post_init__(self):
        if self.dist_dir is None:
            self.dist_dir = self.root
        if self.packages is None:
            self.packages = [PackPkg(dist_dir=self.dist_dir,
                                     pkg_dir=self.pkg_dir, pkg=self.pkg,
                                     slug=self.slug, title=self.title)]
        if self.start is None:
            self.start = self.root

    @property
    def agents(self) -> Path:
        return self.pkg_dir / "agents"

    @property
    def skills(self) -> Path:
        return self.pkg_dir / "skills"

    @property
    def workflows(self) -> Path:
        return self.pkg_dir / "workflows"

    def agent_roles(self) -> list[str]:
        if not self.agents.is_dir():
            return []
        return sorted(p.name for p in self.agents.iterdir()
                      if (p / "workspace").is_dir())

    def rel(self, path: Path) -> str:
        try:
            return path.relative_to(self.root).as_posix()
        except ValueError:            # pragma: no cover - --dir outside the repo
            return str(path)

    # -- multi-package targeting ----------------------------------------
    def _with_primary(self, p: PackPkg) -> "PackRepo":
        import dataclasses
        return dataclasses.replace(
            self, pkg_dir=p.pkg_dir, pkg=p.pkg, slug=p.slug, title=p.title,
            dist_dir=p.dist_dir, _primary_reason="content")

    def for_content(self, what: str) -> "PackRepo":
        """This repo, re-rooted on the family's CONTENT package.

        Agents, skills and tools are FAMILY-level: whatever directory the
        command ran from, they belong in the shared package - running
        `new-skill` from inside a workflows-only solution package must not
        drop a skill there. One content package -> retarget silently (the
        printed path says where it landed). Several or none -> ask, never
        guess.
        """
        if len(self.packages) == 1:
            return self
        content = [p for p in self.packages if p.is_content]
        if len(content) == 1:
            return self if content[0].pkg == self.pkg \
                else self._with_primary(content[0])
        if content:
            # several content packages: the directory the author stands in
            # picks; standing outside all of them is genuine ambiguity
            for p in content:
                anchor = p.dist_dir if p.dist_dir != self.root else p.pkg_dir
                if anchor != self.root and self.start.is_relative_to(anchor):
                    return self._with_primary(p)
        names = ", ".join(p.slug or p.pkg for p in self.packages)
        raise typer.BadParameter(
            f"this workspace repo has several packages ({names}) and none is "
            f"clearly the shared content package, so there is nowhere "
            f"unambiguous to put {what}.\nRun the command from inside the "
            "intended package directory, or point at it with --dir.")

    def family_agent_roles(self) -> list[str]:
        """Every agent role ANY package of this repo ships - the roles a
        workflow may name, wherever the command ran from."""
        seen: set[str] = set()
        for p in self.packages:
            seen.update(p.agent_roles())
        return sorted(seen)

    def workflow_package(self, solution: str | None) -> PackPkg:
        """The package a new workflow lands in. Workflows are SOLUTION-level.

        One package -> it (the classic repo, byte-identical behavior).
        Several -> `--solution <code>`, or the directory the command ran in,
        or the single workflow-carrying candidate; anything else is asked for
        explicitly rather than guessed.
        """
        if len(self.packages) == 1:
            return self.packages[0]

        by_code = {p.solution or p.slug: p for p in self.packages
                   if not p.is_content}
        if solution:
            hit = by_code.get(solution)
            if hit is None:
                known = ", ".join(sorted(by_code)) or "(none)"
                raise typer.BadParameter(
                    f"no solution `{solution}` in this workspace - it has: "
                    f"{known}.\nAdd one first: `aicore new-solution "
                    f"{solution}` (run inside this repo).")
            return hit

        # The directory the author is standing in is an answer, when it is
        # inside a solution package. Inside the SHARED package it is the
        # opposite of one: workflows are the thing that package must not hold.
        for p in self.packages:
            anchor = p.dist_dir if p.dist_dir != self.root else p.pkg_dir
            if anchor != self.root and self.start.is_relative_to(anchor):
                if p.is_content:
                    raise typer.BadParameter(
                        f"`{p.pkg}` is the workspace's shared package — "
                        "agents, skills and tools live there, workflows do "
                        "not. Pass --solution <code>; this workspace has: "
                        + (", ".join(sorted(by_code)) or "(none)"))
                return p

        if len(by_code) == 1:
            return next(iter(by_code.values()))
        known = ", ".join(sorted(by_code)) or "(none)"
        raise typer.BadParameter(
            f"this workspace has several solutions ({known}) — say which one "
            "the workflow belongs to with --solution <code>. Workflows are "
            "solution-level; only agents, skills and tools are shared.")


def _find_repo_root(start: Path) -> Path | None:
    """Walk up looking for the repo. Same convention ``new-solution`` uses.

    The MANIFEST is the stronger marker and wins over a nearer pyproject:
    a workspace repo holds several distributions, each with its own
    pyproject.toml, under one ``aicore.solution.yaml`` - anchoring at the
    first pyproject would see one package of a family and miss the rest. A
    classic repo has both files at the same level, where the two rules agree.
    """
    pyproject_hit: Path | None = None
    for d in [start, *start.parents]:
        if find_manifest(d) is not None:
            return d
        if pyproject_hit is None and (d / "pyproject.toml").is_file():
            pyproject_hit = d
    return pyproject_hit


def _packs_from_pyproject(dist_dir: Path) -> list[PackPkg]:
    """Every ``aicore.packs`` entry point one pyproject declares.

    The RUNTIME's own answer: whatever the entry points name is what the
    engine will actually load, even where the manifest disagrees. A workspace
    distribution legitimately declares several (shared + per-solution), so
    this reads them ALL - taking only the first was how a multi-package repo
    could not be addressed at all.
    """
    try:
        data = tomllib.loads(
            (dist_dir / "pyproject.toml").read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return []
    project = data.get("project") or {}
    eps = _declared_pack_eps(project)
    desc = str(project.get("description") or "")
    base_title = desc          # title derived per entry point below
    # setuptools package-dir: the FLAT layout's whole trick — the directory
    # is `tools/`, the import name is `acme_tools`, and only pyproject knows.
    pkg_map = (((data.get("tool") or {}).get("setuptools")) or {}
               ).get("package-dir") or {}
    out: list[PackPkg] = []
    for slug, target in eps.items():
        pkg = str(target).split(":", 1)[0].strip()
        pkg_dir = dist_dir / str(pkg_map.get(pkg, pkg))
        if not pkg_dir.is_dir():
            continue          # declaration/directory disagreement; skip here,
                              # the single-package path still errors loudly
        out.append(PackPkg(
            dist_dir=dist_dir, pkg_dir=pkg_dir, pkg=pkg, slug=slug,
            title=_title_from_description(base_title, slug)))
    return out


#: What the scaffold appends to a pack's `description`. EVERY shape must be
#: stripped, including retired ones: only the first was once, so a workspace
#: scaffolded with `--layout packaged` (whose description is "<Name> workspace
#: for AgentFarm") took the WHOLE description as its title, and the title is
#: substituted into the agent SOUL.md the scaffold writes -- producing "You
#: are Tam, the Globex workspace for AgentFarm analyst." An agent's identity
#: is the one place a packaging string must never reach: it is the prompt, so
#: the model reads it as part of who it is.
#:
#: The pre-rename suffixes stay for exactly that reason. A repo scaffolded
#: before the product was named AI Core Harness still carries them in its
#: `pyproject.toml`, and dropping them here would not fail -- it would put the
#: old product name inside that team's agents.
_DESC_SUFFIXES = (" solution pack for AI Core Harness",
                  " workspace for AI Core Harness",
                  " solution pack for AgentFarm",
                  " workspace for AgentFarm")


def _title_from_description(desc: str, slug: str) -> str:
    """The human title of a pack, from its `description`.

    Falls back to the entry-point name when the description is absent or is
    nothing but the suffix, so the title is always something a reader would
    recognise rather than an empty string.
    """
    title = (desc or "").strip()
    for suffix in _DESC_SUFFIXES:
        if title.endswith(suffix):
            title = title[: -len(suffix)].strip()
            break
    return title or slug.replace("_", " ").title()


def _pack_from_pyproject(root: Path) -> tuple[str, str, str] | None:
    """(slug, pkg, title) of the FIRST entry point - the classic single-pack
    reading, kept for the declaration-vs-directory error path."""
    try:
        data = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return None
    project = data.get("project") or {}
    eps = _declared_pack_eps(project)
    if not eps:
        return None
    slug, target = next(iter(eps.items()))
    pkg = str(target).split(":", 1)[0].strip()
    desc = str(project.get("description") or "")
    return slug, pkg, _title_from_description(desc, slug)


def _manifest_solution_of(root: Path) -> dict[Path, str]:
    """``{resolved workflow root: solution code}`` from the manifest's
    ``solutions:`` key - tolerant raw read, {} on any problem. Used only to
    LABEL packages; fail-closed validation stays the importer's job."""
    import yaml

    f = find_manifest(root)
    if f is None:
        return {}
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return {}
    out: dict[Path, str] = {}
    sols = data.get("solutions")
    if not isinstance(sols, dict):
        return out
    for code, spec in sols.items():
        if not isinstance(spec, dict):
            continue
        for rel in (spec.get("workflows") or []
                    if isinstance(spec.get("workflows"), list) else []):
            try:
                out[(root / str(rel)).resolve()] = str(code)
            except OSError:            # pragma: no cover - malformed path
                continue
    return out


def _pack_from_manifest(root: Path) -> tuple[str, str] | None:
    """(solution, pkg) from ``aicore.solution.yaml``.

    The fallback, not the primary: this file serves the IMPORTER (it is what
    ``workspace push`` reads to fill the Studio catalog), while the entry
    point serves the runtime. A repo needs both, and only one of them names
    the package the engine will import.
    """
    import yaml

    f = find_manifest(root)
    if f is None:
        return None
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return None
    roots = (data.get("roots") or {}).get("agents") or []
    if not roots:
        return None
    pkg = Path(str(roots[0])).parts[0]
    return str(data.get("solution") or pkg), pkg


def _flat_workspace(root: Path, start: Path,
                    discovered: list[PackPkg]) -> PackRepo | None:
    """The FLAT workspace shape, synthesized from the manifest.

    Flat = content dirs (``agents/``, ``skills/``) at the repo root on the
    import path, solutions under ``solutions/<code>/workflows``, and at most
    one PACKAGED thing: the tools package, package-dir-mapped onto ``tools/``.
    There is no entry-point package holding the content, so the discovery
    above finds only the tools package (or nothing) - the manifest is the
    map, and this builds the PackRepo from it.

    Returns None when the repo is NOT flat: no manifest, no ``solutions:``
    mapping, no agents root on disk, or a discovered entry-point package
    already contains the agents root (the packaged shape).
    """
    import yaml

    f = find_manifest(root)
    if f is None:
        return None
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return None
    sols = data.get("solutions")
    if not isinstance(sols, dict):
        return None
    agents_rel = ((data.get("roots") or {}).get("agents")) or []
    if not agents_rel:
        return None
    agents_dir = (root / str(agents_rel[0])).resolve()
    if not agents_dir.is_dir():
        return None
    for p in discovered:
        try:
            # STRICTLY INSIDE. A packaged repo's wrapper package CONTAINS the
            # agents root (wsfam_shared/agents). A flat repo that also maps
            # its content dirs into wheel-shippable packages (the both-pipes
            # variant) has a package whose dir IS the agents root — that is
            # flat, not packaged.
            if (agents_dir.is_relative_to(p.pkg_dir.resolve())
                    and agents_dir != p.pkg_dir.resolve()):
                return None            # packaged: a package holds the content
        except (OSError, ValueError):  # pragma: no cover - defensive
            continue

    family = str(data.get("solution") or root.name)
    content = PackPkg(dist_dir=root, pkg_dir=agents_dir.parent,
                      pkg=family, slug=family,
                      title=family.replace("_", " ").title())
    packages: list[PackPkg] = [content]
    for code, spec in sols.items():
        wf_roots = (spec.get("workflows") or []
                    if isinstance(spec, dict) else [])
        if not wf_roots:
            continue
        sol_dir = (root / str(wf_roots[0])).parent
        packages.append(PackPkg(
            dist_dir=root, pkg_dir=sol_dir, pkg=str(code), slug=str(code),
            title=str(code).replace("_", " ").title(), solution=str(code)))

    # The mapped tools package, when the repo has one — kept OUT of
    # `packages` (it is neither a content nor a workflow target) but its
    # import name drives new-tool's console-script wiring.
    tools_import = next(
        (p.pkg for p in discovered if p.pkg_dir.name == "tools"), None)

    return PackRepo(root=root, pkg_dir=content.pkg_dir, pkg=content.pkg,
                    slug=family, solution=family, title=content.title,
                    dist_dir=root, packages=packages, start=start,
                    _primary_reason="content", tools_import=tools_import)


def find_pack(directory: Path | None) -> PackRepo:
    """Locate the pack(s) rooted at *directory* (default: current directory).

    Every failure names what was looked for and where. "Not a solution repo" on
    its own sends people hunting for a flag that does not exist; the fix is
    almost always `cd`, and the message should be able to say so.

    A classic single-package repo resolves exactly as it always has. A
    WORKSPACE repo - several entry points in one pyproject, or several
    distributions under one manifest - additionally fills ``packages``, and
    the primary fields point at the shared content package when the repo has
    exactly one (agents/skills/tools land there; workflows go through
    :meth:`PackRepo.workflow_package`).
    """
    start = Path(directory).resolve() if directory else Path.cwd().resolve()
    if not start.is_dir():
        raise typer.BadParameter(f"{start} is not a directory")

    root = _find_repo_root(start)
    if root is None:
        raise typer.BadParameter(
            f"no solution repo at {start} (or in any directory above it) — "
            f"looked for `{MANIFEST_NAME}` and `pyproject.toml`.\n"
            "Run this from inside the repo `aicore new-solution` created, "
            "or point at it with --dir.")

    # Every entry-point package: the root's own pyproject plus one directory
    # level of sibling distributions (the pharma monorepo shape).
    packages: list[PackPkg] = _packs_from_pyproject(root)
    try:
        children = sorted(d for d in root.iterdir() if d.is_dir())
    except OSError:                    # pragma: no cover - unreadable root
        children = []
    for child in children:
        if (child / "pyproject.toml").is_file():
            packages.extend(_packs_from_pyproject(child))

    # THE FLAT SHAPE: content at the root on the import path, tools the only
    # package. Checked before everything else — its entry points resolve to
    # the tools package alone, which the packaged-shape logic would misread.
    flat = _flat_workspace(root, start, packages)
    if flat is not None:
        return flat

    # Solution codes from the manifest's `solutions:` map, matched by root.
    sol_of = _manifest_solution_of(root)
    for p in packages:
        for wf_root, code in sol_of.items():
            try:
                if wf_root.is_relative_to(p.pkg_dir):
                    p.solution = code
                    break
            except (OSError, ValueError):     # pragma: no cover - defensive
                continue

    from_yaml = _pack_from_manifest(root)

    if not packages:
        # No entry point anywhere: keep the classic two fallbacks (manifest
        # naming a root; loud error otherwise), byte-identical to before.
        from_toml = _pack_from_pyproject(root)
        if from_toml:
            slug, pkg, title = from_toml
        elif from_yaml:
            _, pkg = from_yaml
            slug = pkg.removeprefix("agentfarm_")
            title = slug.replace("_", " ").title()
        else:
            raise typer.BadParameter(
                f"{root} has no AI Core pack in it — its pyproject.toml declares "
                f'no [project.entry-points."{PACK_ENTRY_POINT_GROUP}"] block and there is no '
                f"{MANIFEST_NAME} naming a content root.\n"
                "Without the entry point a pack installs and is invisible to the "
                "engine, so this is worth fixing whether or not you add anything "
                "to it: compare against a fresh `aicore new-solution`.")
        pkg_dir = root / pkg
        if not pkg_dir.is_dir():
            raise typer.BadParameter(
                f"{root} declares the package `{pkg}` but {pkg_dir} does not "
                "exist. The declaration and the directory have to agree — the "
                "engine imports the name, not the folder it can find.")
        solution = (from_yaml or (slug, pkg))[0]
        return PackRepo(root=root, pkg_dir=pkg_dir, pkg=pkg, slug=slug,
                        solution=solution, title=title, start=start)

    # -- primary selection ------------------------------------------------
    reason = "only"
    if len(packages) == 1:
        primary = packages[0]
    else:
        primary = None
        # 1. the package the author is standing in
        for p in packages:
            anchor = p.dist_dir if p.dist_dir != root else p.pkg_dir
            if anchor != root and start.is_relative_to(anchor):
                primary, reason = p, "cwd"
                break
        # 2. the unique content-holding (shared) package
        if primary is None:
            content = [p for p in packages if p.is_content]
            if len(content) == 1:
                primary, reason = content[0], "content"
        # 3. nothing unambiguous — first package, and require_content_target
        #    turns any content command into a question instead of a guess
        if primary is None:
            primary, reason = packages[0], "ambiguous"

    solution = (from_yaml[0] if from_yaml else primary.solution or primary.slug)
    return PackRepo(root=root, pkg_dir=primary.pkg_dir, pkg=primary.pkg,
                    slug=primary.slug, solution=solution, title=primary.title,
                    dist_dir=primary.dist_dir, packages=packages, start=start,
                    _primary_reason=reason)


def _subs(pack: PackRepo, **extra: str) -> dict[str, str]:
    """Template substitutions in the vocabulary ``cli_scaffold`` declares."""
    return {"__SLUG__": pack.slug, "__PKG__": pack.pkg,
            "__SOLUTION__": pack.solution, "__TITLE__": pack.title, **extra}


def _agent_name(role: str) -> str:
    """`logistics_reviewer` -> `Logistics Reviewer`.

    A default, not a decision: `--name` exists because agents in this codebase
    are called Jarvis, Quinn and Iris, and a person naming one will say so.
    """
    return role.replace("_", " ").title()


def _resolve_default_role(pack: PackRepo, explicit: str | None,
                          why: str) -> str:
    """The agent to use when the author did not name one.

    Defaulting to the single agent in a one-agent pack is the whole point -
    that IS the state a freshly scaffolded repo is in. Guessing between two is
    worse than asking: the wrong agent produces a workflow that runs, produces
    output, and is subtly the wrong output.
    """
    if explicit:
        return explicit
    roles = pack.family_agent_roles()
    if len(roles) == 1:
        return roles[0]
    if not roles:
        raise typer.BadParameter(
            f"{pack.rel(pack.agents)} contains no agents, so there is nothing "
            f"to {why}.\nCreate one first: `aicore new-agent <role>`.")
    raise typer.BadParameter(
        f"this pack has {len(roles)} agents ({', '.join(roles)}), so --role is "
        f"required — {why} is not something to guess at.")


def _check_role_exists(pack: PackRepo, role: str) -> None:
    for p in pack.packages:
        if (p.pkg_dir / "agents" / role / "workspace").is_dir():
            return
    # A PLATFORM-SHARED ROLE IS NOT MISSING - it is framework-owned and
    # identical in every workspace, and the engine ships it. This looked only
    # inside the pack, so `new-workflow --role project_lead` - the DEFAULT
    # DRIVER, the role every agent-driven workflow's own steps run as - was
    # refused with "this pack has no agent `project_lead` - it has mira", and
    # the fix it offered (create a local one) is exactly the wrong move: a
    # local copy would shadow the framework's driver. Found in the joint
    # stability round, whose workaround was to scaffold with a local role and
    # then edit the YAML by hand.
    try:
        from ioagentfarm.engine.workspaces import PLATFORM_SHARED_ROLES
        if role in PLATFORM_SHARED_ROLES:
            return
    except Exception:                      # noqa: BLE001 - fall through
        pass
    known = pack.family_agent_roles()
    raise typer.BadParameter(
        f"this pack has no agent `{role}`"
        + (f" - it has {', '.join(known)}" if known else "")
        + f".\nCreate it first: `aicore new-agent {role}`.")


def _refuse_duplicate_in_family(pack: PackRepo, name: str, target: Path,
                                force: bool) -> None:
    """Refuse a workflow name another solution of this workspace already uses.

    A workspace is ONE family, and a workflow is addressed by NAME: `aicore run
    <name>`, `aicore lint-workflow <name>`. Two solutions carrying the same
    name is therefore ambiguous, and the engine resolves it by registry order.
    `list-workflows` warns about it -- but only afterwards, and only if the
    warning is read.

    That is a bad moment to find out. Seen live while walking the docs: a
    `claims_triage` existed in `billing`, a second was created in `claims`, and
    `lint-workflow claims_triage` then linted the BILLING copy and reported it
    clean -- while the file that had just been broken sat unlinted in `claims`.
    A gate that silently checks the wrong file is worse than no gate.

    Creation is the one moment another name is still free, so the check belongs
    here rather than at run time.

    NOT BYPASSABLE, unlike `_refuse_existing`. `--force` there overwrites
    one directory, which is recoverable. Here it produced a repository the
    product then refuses more widely: the manifest rejects a name declared
    by two roots, so `workspace diff` and `workspace push` fail for EVERY
    item -- agents, skills and the other workflows included -- until one
    copy is deleted. An escape hatch that leads somewhere nothing can
    publish is not an escape hatch.
    """
    seen: list[tuple[str, Path]] = []
    # CROSS-KIND on purpose: a workflow and a SWARM sharing one name collide
    # in `runs.workflow_name`, in the Studio's per-name run tiles and in the
    # reader's head — `run x` and `run-swarm x` would be two different things
    # wearing one name.
    for kind, patterns in (
            ("workflow", ("*/*/workflows/" + name, "*/workflows/" + name)),
            ("swarm", ("*/*/swarms/" + name, "*/swarms/" + name))):
        for pattern in patterns:
            for found in sorted(pack.root.glob(pattern)):
                if found.is_dir() and found.resolve() != target.resolve():
                    if (kind, found) not in seen:
                        seen.append((kind, found))
    if not seen:
        return
    where = chr(10).join(f"  {k}: " + str(pack.rel(c)) for k, c in seen)
    raise typer.BadParameter(
        "this workspace already uses the name " + repr(name) + ":"
        + chr(10) + where + chr(10)
        + "Workflows and swarms are addressed by name (`run` / `run-swarm`, "
        "and one runs.workflow_name column records both), so two of them are "
        "ambiguous: the registry resolves whichever it lists first, and you "
        "can edit one while running the other." + chr(10)
        + "Pick another name: the manifest refuses a name declared by two "
        "roots, so a duplicate stops `workspace diff` from reading anything "
        "at all.")


def _shipped_elsewhere(role: str) -> list[str]:
    """Installed packs, OUTSIDE this repo, that already ship agent *role*."""
    from ioagentfarm.packs import load_registry, _pack_agent_roles
    out: list[str] = []
    try:
        packs = load_registry().packs
    except Exception:                          # noqa: BLE001 - no registry, no check
        return out
    for p in packs:
        try:
            if role not in _pack_agent_roles(p):
                continue
        except Exception:                      # noqa: BLE001
            continue
        out.append(str(p.pack or p.workspace or p.name or "?"))
    return out


def _refuse_shipped_role(role: str, pack: PackRepo) -> None:
    """A role an installed pack already ships can never run from this one.

    Seen live: a team scaffolded `project_lead` ("George") into their
    solution and asked why the run used Alex. Core ships `project_lead`,
    the registry lists core first, and `run` resolves an agent by name in
    registry order - so the new agent is dead by construction, and the
    only place that said so was a warning in the log after the fact.
    Creation is the moment the name can still change. Not bypassable: no
    flag makes the run pick the second carrier.
    """
    carriers = [c for c in _shipped_elsewhere(role)
                if c not in {pack.slug, *(pk.slug for pk in (pack.packages or []))}]
    if not carriers:
        return
    word = pack.slug.split("_", 1)[0] or "my"
    raise typer.BadParameter(
        f"an installed pack already ships an agent named `{role}` "
        f"({', '.join(carriers)}). A run resolves agents by name in registry "
        f"order, so this one would never be used - the other pack's "
        f"`{role}` would run in its place, silently.\n"
        f"Pick a name that is yours, e.g. `{word}_{role}`, and use that name "
        f"as the `role:` in your workflows.")


def _skills_of(pack: PackRepo, like: str) -> list[Path]:
    """Every skill directory the pack's agent *like* carries."""
    known = pack.agent_roles()
    if like not in known:
        raise typer.BadParameter(
            f"--like {like}: this pack has no agent `{like}` - it has "
            f"{', '.join(known) or 'none'}.")
    skills = pack.agents / like / "workspace" / "skills"
    if not skills.is_dir():
        return []
    return sorted(d for d in skills.iterdir()
                  if d.is_dir() and (d / "SKILL.md").is_file())


def _copy_skills(sources: list[Path], dest_root: Path) -> list[str]:
    """Copy skill directories in, SKIPPING `output_protocol`: the platform
    ships it and the engine resolves it per step, so propagating one agent's
    copy would only re-create the duplication. Returns the names copied."""
    import shutil
    copied: list[str] = []
    for src in sources:
        if src.name == "output_protocol":
            continue
        dest = dest_root / src.name
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src, dest)
        copied.append(src.name)
    return copied


def _refuse_existing(target: Path, pack: PackRepo, kind: str,
                     force: bool) -> None:
    if not target.exists() or force:
        return
    raise typer.BadParameter(
        f"{kind} already exists at {pack.rel(target)} — pass --force to "
        "overwrite it.\nOverwriting replaces the files this command writes and "
        "leaves anything else in the directory alone, so a hand-edited prompt "
        "that is not one of them survives.")


def _editable_note(pack: PackRepo, target=None) -> str:
    """Whether what was just written is live, and say which.

    "Installed?" is answered from the ENTRY POINT, not from whether the package
    imports. Importability is not the same question and gives the wrong answer
    in the case that matters: run from the repo root, the current directory is
    on ``sys.path``, so the package imports perfectly while the engine - which
    resolves content by iterating the ``aicore.packs`` group - sees nothing
    at all. That is failure mode #1 from `cli_scaffold`'s docstring, and a
    reassuring "nothing to reinstall" on top of it is worse than silence.

    Given it IS installed, editable-vs-copy is then a path comparison: an
    editable install resolves through the source tree and sees these files now;
    a copy was taken at install time and never will.

    *target* IS THE PACKAGE THE CONTENT WENT INTO, and passing it matters as
    soon as a repo has more than one. A workflow written into a new solution
    lands in that solution's package, whose entry point pip has not registered
    yet -- while the WORKSPACE package is installed and editable. Answering
    about the workspace produced "Nothing to reinstall or re-run" for a
    workflow the engine could not see, immediately after `new-solution` had
    correctly said a reinstall was required.
    """
    import importlib.util
    from importlib.metadata import entry_points

    slug = getattr(target, "slug", None) or pack.slug
    pkg = getattr(target, "pkg", None) or pack.pkg
    dist_dir = getattr(target, "dist_dir", None) or pack.dist_dir

    if slug not in _installed_pack_names():
        return ("[yellow]REINSTALL REQUIRED - the entry point "
                f"`{slug}` is not registered in this venv, so the engine "
                "cannot see this content: no error, just an empty catalog. "
                f"Run `pip install -e \".[dev]\"` in {dist_dir}.[/]")
    try:
        spec = importlib.util.find_spec(pkg)
    except (ImportError, ValueError):          # pragma: no cover - defensive
        spec = None
    origin = Path(spec.origin).resolve() if spec and spec.origin else None
    if origin is None or origin.is_relative_to(pack.root.resolve()):
        return ("[dim]Nothing to reinstall or re-run: the engine reads this "
                "pack from these files, as they are now.[/]")
    return ("[yellow]This pack is installed as a COPY (not `-e`), at "
            f"{origin.parent} — the engine will keep reading that copy and will "
            f"not see this. Re-run `pip install -e .` in {dist_dir}.[/]")


def _lint_line(wf_dir: Path) -> str:
    """Lint what we just generated, at generation time.

    CI proves the template is clean today. This proves the FILE is clean on the
    machine it was written on - after substitution, with the prompt files
    actually on disk, which is the half of `lint-workflow` no unit test covers.
    """
    from ioagentfarm.engine.workflow_lint import lint_workflow_dir

    res = lint_workflow_dir(wf_dir)
    if res.ok and not res.warnings:
        return "[green]clean[/]"
    if res.ok:
        return f"[yellow]{len(res.warnings)} warning(s)[/] - `aicore lint-workflow`"
    return (f"[red]{len(res.errors)} error(s)[/] — this is a bug in the "
            "scaffold, please report it:\n" + res.format())


# ── step prompts (no counterpart in new-solution) ────────────────────
#
# `new-solution`'s two prompts describe a job it chose. Here the author has
# named a step and nothing else, so these say the things that are true of any
# step in this engine — read your grounding, write your artifact, do not invent
# what is missing — and leave the substance to be written in.

_STEP_FIRST = """\
# __STEP_TITLE__

Goal: {{goal}}

## What to do

1. Read `{{metadata_dir}}/catalog.yaml` before querying anything. It is the
   only source of entity and column names; do not guess them. If it declares
   no entities yet, say so in your deliverable and name the file to fill in —
   an empty catalog is a finding, not a failure, and hunting the filesystem for
   data nobody catalogued is how a run ends up quoting an unrelated file.
2. << REPLACE THIS with what this step is for. Keep every result small:
   aggregate in SQL rather than reading rows back and adding them up. >>
3. Write `{{output_dir}}/__ARTIFACT__`. Every figure carries its source — the
   entity it came from and the filter that produced it. A figure without one is
   a claim, and claims do not ship.
4. State gaps explicitly: "not available in `<entity>`". A gap is a finding.

"""

_STEP_NEXT = """\
# __STEP_TITLE__

Goal: {{goal}}

What `__PREV__` reported:

{{step_output.__PREV__}}

## What to do

1. Read `{{output_dir}}/__PREV_ARTIFACT__` — it is the source for this step. Do
   not introduce a figure that is not in it. If it reports a gap, repeat the
   gap; do not fill it in to have something to hand over.
2. << REPLACE THIS with what this step is for. >>
3. Write `{{output_dir}}/__ARTIFACT__`.
4. __SECTIONED__
"""


def _step_prompt(*, title: str, key: str, artifact: str,
                 prev: str | None, prev_artifact: str | None) -> str:
    if prev is None:
        return _STEP_FIRST.replace("__STEP_TITLE__", title).replace(
            "__ARTIFACT__", artifact) + step_output_block(
                f"<one-line summary of {artifact}>", explain=True)
    return (_STEP_NEXT
            .replace("__STEP_TITLE__", title)
            .replace("__PREV_ARTIFACT__", prev_artifact or "")
            .replace("__PREV__", prev)
            .replace("__ARTIFACT__", artifact)
            .replace("__SECTIONED__", sectioned_write_note(key, artifact))
            + step_output_block(f"<one-line summary of {artifact}>",
                                explain=False))


# ── new-workflow ─────────────────────────────────────────────────────

def _parse_steps(raw: str) -> list[tuple[str, str | None]]:
    """``analyze,compose`` or ``analyze:ida,review:rey`` -> [(key, role|None)].

    ONE ARGUMENT RATHER THAN A REPEATABLE FLAG. The per-step agent had to be
    expressible - the Studio's no-code form already spreads steps across agents
    and a CLI that could not would be the weaker of the two - and the two ways
    to say it are `--steps a:ida,b:rey` and `--step a:ida --step b:rey`. The
    single argument wins on the thing that actually matters here: ORDER. These
    steps become a dependency chain, so their sequence is part of the meaning,
    and a repeatable flag hides that in argv positions where it reads as
    incidental. It also keeps the common case - one agent, two steps - as short
    as it was before per-step agents existed.
    """
    out: list[tuple[str, str | None]] = []
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        key, _, role = chunk.partition(":")
        key, role = key.strip(), role.strip()
        if not key:
            raise typer.BadParameter(
                f"`{chunk}` has no step name before the ':' — write "
                "`--steps analyze:ida,review:rey`")
        if not STEP_KEY_RE.match(key):
            raise typer.BadParameter(
                f"step name `{key}` must be letters, digits, `_`, `-` or `.` — "
                "it becomes a directory name in the run output and forensics "
                "trees")
        if key.startswith("story"):
            # Not a style rule: the engine materializes fan-out steps as
            # `story:<id>:<suffix>` and the scheduler routes on that prefix.
            raise typer.BadParameter(
                f"step name `{key}` may not start with `story` — that prefix "
                "belongs to the per-item steps a fan-out materializes")
        out.append((key, role or None))
    if not out:
        raise typer.BadParameter("--steps named no steps")
    seen = [k for k, _ in out]
    dupes = {k for k in seen if seen.count(k) > 1}
    if dupes:
        raise typer.BadParameter(
            f"duplicate step name(s): {', '.join(sorted(dupes))}. The engine "
            "keys steps by name, so only one of each could ever be addressed "
            "and a `deps:` pointing at it would be ambiguous.")
    return out


def new_workflow(
    name: str = typer.Argument(
        ..., help="Workflow name - lowercase, e.g. 'carrier_review'."),
    role: str = typer.Option(
        None, "--role", "-r",
        help="Agent to run the steps (default: the pack's agent, when it has "
             "exactly one)."),
    steps: str = typer.Option(
        "analyze,compose", "--steps", "-s",
        help="Comma-separated step names, in order. Give a step its own agent "
             "with `name:agent`, e.g. 'analyze:ida,review:rey'."),
    title: str = typer.Option(
        None, "--title", help="One-line description (default: derived)."),
    solution: str = typer.Option(
        None, "--solution",
        help="Which solution of the workspace owns this workflow. Only needed "
             "in a workspace repo with several solutions - a classic "
             "single-package repo has exactly one answer."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
    force: bool = typer.Option(
        False, "--force", help="Overwrite an existing workflow."),
) -> None:
    """Add a workflow to the solution pack you are in."""
    if not NAME_RE.match(name):
        raise refuse_name(name, "a directory name and the name you run")

    pack = find_pack(directory)
    # Workflows are SOLUTION-level — the one content kind that does not go in
    # the shared package. Resolved before anything is written.
    wf_target = pack.workflow_package(solution)
    parsed = _parse_steps(steps)

    # The default is resolved only if some step needs it, so a fully-specified
    # `--steps a:ida,b:rey` works in a pack with ten agents and no --role.
    default_role: str | None = None
    if any(r is None for _, r in parsed):
        default_role = _resolve_default_role(
            pack, role, "which agent runs a step")
    resolved = [(k, r or default_role or "") for k, r in parsed]
    for _, r in resolved:
        _check_role_exists(pack, r)

    wf_dir = wf_target.pkg_dir / "workflows" / name
    _refuse_existing(wf_dir, pack, "workflow", force)
    _refuse_duplicate_in_family(pack, name, wf_dir, force)

    # Linear chain: step N depends on step N-1. It is the only shape derivable
    # from a flat ordered list — a fan-in needs an explicit graph, and inventing
    # one from the order would be a guess the author cannot see. The generated
    # `deps: [x]` is the thing to edit when they want one.
    artifacts = {k: f"{k}.md" for k, _ in resolved}
    step_defs = []
    for i, (key, r) in enumerate(resolved):
        prev = resolved[i - 1][0] if i else None
        step_defs.append({
            "key": key,
            "title": key.replace("_", " ").replace("-", " ").capitalize(),
            "role": r,
            "deps": [prev] if prev else [],
            # Every step declares its deliverable. The gate is fail-closed: on
            # `STATUS: done` with the file missing or empty the step flips to
            # failed and retries, which is what stops a broken handoff becoming
            # a fabricated downstream section.
            "requires_artifacts": [artifacts[key]],
        })

    # `skills:` is deliberately absent — see _WF_ROLE_NO_SKILLS in cli_scaffold.
    ordered_roles: list[str] = []
    for _, r in resolved:
        if r not in ordered_roles:
            ordered_roles.append(r)

    yaml_text = render_workflow_yaml(
        name=name,
        description=title or (
            f"{len(step_defs)}-step {pack.title} workflow: "
            + " then ".join(k for k, _ in resolved) + "."),
        roles=[{"name": r, "skills": None} for r in ordered_roles],
        steps=step_defs,
    )
    wf_dir.mkdir(parents=True, exist_ok=True)
    (wf_dir / "workflow.yaml").write_text(yaml_text, encoding="utf-8")

    # `{{metadata_dir}}` resolves to THIS workflow's metadata/ — and to the
    # empty string when it has none, so a prompt saying "read the catalog in
    # `{{metadata_dir}}`" renders as "read the catalog in ``" and the agent
    # spends its first turns looking for a directory that will never exist.
    # Every workflow ships its own; catalogs are per-workflow, not per-pack.
    _write(wf_dir / "metadata" / "catalog.yaml", CATALOG_YAML, _subs(pack))

    for r in ordered_roles:
        _write(wf_dir / "roles" / f"{r}.md", ROLE_PROMPT,
               _subs(pack, __ROLE__=r, __AGENT_NAME__=_agent_name(r),
                     __ROLE_WORD__=r.rsplit("_", 1)[-1]))

    for i, (key, _) in enumerate(resolved):
        prev = resolved[i - 1][0] if i else None
        (wf_dir / "steps").mkdir(parents=True, exist_ok=True)
        (wf_dir / "steps" / f"{key}.md").write_text(
            _step_prompt(
                title=step_defs[i]["title"], key=key, artifact=artifacts[key],
                prev=prev, prev_artifact=artifacts.get(prev or "")),
            encoding="utf-8")

    console.print(f"[bold green]Created[/] {pack.rel(wf_dir)}")
    console.print("  steps : " + " -> ".join(
        f"{k} ({r})" for k, r in resolved))
    console.print(f"  lint  : {_lint_line(wf_dir)}")
    console.print(_editable_note(pack, wf_target))
    console.print("\n[bold]Next[/]")
    # Reinstall FIRST when this solution's entry point is unregistered:
    # `list-workflows` would otherwise be run, not show the workflow, and
    # give no hint -- its two-causes help only prints when the list is EMPTY,
    # and in a workspace with another solution it is not.
    from importlib.metadata import entry_points as _eps
    _target_slug = getattr(wf_target, "slug", None) or pack.slug
    if _target_slug not in _installed_pack_names():
        console.print('  pip install -e ".[dev]"          '
                      "# registers this solution's entry point",
                      markup=False)
    console.print(f"  aicore list-workflows            # expect {name}",
                  markup=False)
    console.print(f"  aicore run {name} --goal \"...\" --dry-run",
                  markup=False)
    console.print("[dim]Write the real instructions into "
                  f"{pack.rel(wf_dir / 'steps')} - each prompt has a "
                  "`<< REPLACE THIS >>` line where the work goes.[/]")


# ── new-swarm ────────────────────────────────────────────────────────
#
# The goal-oriented sibling of new-workflow. A swarm is ONE definition file
# plus two optional overrides; the run pipeline compiles it at run creation,
# so unlike a workflow there are no step prompts to fill in - the generated
# briefing already carries the goal, roster, budget and checkpoint contract.

def _swarm_lint_line(swarm_dir: Path) -> str:
    """Same contract as _lint_line, over the swarm linter."""
    from ioagentfarm.engine.swarm_lint import lint_swarm_dir

    res = lint_swarm_dir(swarm_dir)
    if res.ok and not res.warnings:
        return "[green]clean[/]"
    if res.ok:
        return (f"[yellow]{len(res.warnings)} warning(s)[/] - "
                "`aicore lint-swarm`")
    return (f"[red]{len(res.errors)} error(s)[/] - this is a bug in the "
            "scaffold, please report it:\n" + res.format())


def new_swarm(
    name: str = typer.Argument(
        ..., help="Swarm name - lowercase, e.g. 'portfolio_review'."),
    role: str = typer.Option(
        None, "--role", "-r",
        help="The meta-agent that runs the swarm (default: the pack's agent, "
             "when it has exactly one). Must not be project_lead."),
    agents: str = typer.Option(
        None, "--agents",
        help="Comma-separated external A2A agent roster (workspace registry "
             "names). Omit the flag entirely for ALL registered agents; pass "
             "an empty string for none."),
    mcp: str = typer.Option(
        None, "--mcp",
        help="Comma-separated MCP server roster (declared tier names). Omit "
             "for every declared server; empty string for none."),
    description: str = typer.Option(
        None, "--description",
        help="One line: what this swarm achieves. Operators pick a swarm "
             "from it, and the orchestrator's persona quotes it."),
    solution: str = typer.Option(
        None, "--solution",
        help="Which solution of the workspace owns this swarm. Only needed "
             "in a workspace repo with several solutions."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
    force: bool = typer.Option(
        False, "--force", help="Overwrite an existing swarm."),
) -> None:
    """Add a swarm to the solution pack you are in.

    A swarm is a meta-agent, a goal (given at run time) and a roster of
    external agents and MCP tools - the meta-agent decides call order at
    runtime, under a budget and a fail-closed deliverable gate.
    """
    if not NAME_RE.match(name):
        raise refuse_name(
            name, "a directory name and the run name `run-swarm` uses")

    pack = find_pack(directory)
    # Swarms are SOLUTION-level, exactly like workflows - the resolver serves
    # both kinds.
    sw_target = pack.workflow_package(solution)
    meta_role = _resolve_default_role(pack, role, "which agent runs the swarm")
    if meta_role == "project_lead":
        raise typer.BadParameter(
            "project_lead is the run DRIVER; a swarm needs its own "
            f"orchestrator agent. Create one: `{_prog()} new-agent "
            "<role>`.")
    _check_role_exists(pack, meta_role)

    swarm_dir = sw_target.pkg_dir / "swarms" / name
    _refuse_existing(swarm_dir, pack, "swarm", force)
    _refuse_duplicate_in_family(pack, name, swarm_dir, force)

    def _split(raw: str) -> list[str]:
        return [x.strip() for x in raw.split(",") if x.strip()]

    roster_lines: list[str] = []
    if agents is not None:
        roster_lines.append(
            "agents: [" + ", ".join(_split(agents)) + "]")
    else:
        roster_lines.append("# agents: [a, b]     # omitted = every "
                            "registered external agent")
    if mcp is not None:
        roster_lines.append(
            "mcp_servers: [" + ", ".join(_split(mcp)) + "]")
    else:
        roster_lines.append("# mcp_servers: [x]   # omitted = every declared "
                            "MCP server")

    desc = description or f"REPLACE ME - what the {name.replace('_', ' ')} swarm achieves"
    subs = _subs(pack, __SWARM__=name,
                 __SWARM_TITLE__=name.replace("_", " ").capitalize(),
                 __ROLE__=meta_role, __DESCRIPTION__=desc,
                 __ROSTER_BLOCK__="\n".join(roster_lines))
    _write(swarm_dir / "swarm.yaml", SWARM_YAML, subs)
    _write(swarm_dir / "meta.md", SWARM_META_MD, subs)
    role_file = swarm_dir / "roles" / f"{meta_role}.md"
    if not role_file.exists():
        _write(role_file, SWARM_ROLE_MD, subs)

    console.print(f"[bold green]Created[/] {pack.rel(swarm_dir)}")
    console.print(f"  meta-agent : {meta_role}")
    console.print("  roster     : "
                  + ("agents=" + (agents or "(all registered)"))
                  + ", mcp=" + (mcp or "(all declared)"))
    console.print(f"  lint       : {_swarm_lint_line(swarm_dir)}")
    console.print(_editable_note(pack, sw_target))
    console.print("\n[bold]Next[/]")
    from ioagentfarm.cli_scaffold import _installed_pack_names as _ipn
    _target_slug = getattr(sw_target, "slug", None) or pack.slug
    if _target_slug not in _ipn():
        console.print('  pip install -e ".[dev]"          '
                      "# registers this solution's entry point",
                      markup=False)
    console.print(f"  {_prog()} list-swarms                # expect {name}",
                  markup=False)
    console.print(f"  {_prog()} lint-swarm {name}", markup=False)
    console.print(f"  {_prog()} run-swarm {name} --goal \"...\" --dry-run",
                  markup=False)
    console.print("[dim]  meta.md is an OPTIONAL briefing override - delete "
                  "it to use the generated briefing (goal + roster + budget "
                  "+ checkpoint discipline are already in it).[/]")


# ── new-agent ────────────────────────────────────────────────────────

def new_agent(
    role: str = typer.Argument(
        ..., help=(
            "The agent's ID - lowercase, underscores, e.g. "
            "'logistics_reviewer'. This is how everything addresses it: the "
            "directory it lives in, the `role:` a workflow step names, the "
            "`agent` field on a chat request, and its A2A path. It is NOT "
            "what people call it - that is --name - and it is not a job "
            "title the engine interprets. Pick it once; renaming it later "
            "means renaming it everywhere."),),
    name: str = typer.Option(
        None, "--name",
        help="What people call it, e.g. \"Ida\" (default: derived from the "
             "role)."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
    kind: str = typer.Option(
        "general", "--kind",
        help="What shape of agent to scaffold: 'general' (the default - a "
             "grounded agent with no assumptions about what it reaches for) "
             "or 'data' (an analyst that reads a catalog and shows its SQL). "
             "The scaffold used to write the 'data' identity for every agent, "
             "which made every new agent look like a query engine."),
    a2a: bool = typer.Option(
        False, "--a2a",
        help="Also author an a2a-card.yaml with `expose: true`, so the agent "
             "is served on the A2A surface (a public card + JSON-RPC "
             "endpoint) by `aicore serve` - the card is the exposure "
             "declaration; no deployment change needed."),
    like: str = typer.Option(
        None, "--like",
        help="An existing agent of this pack whose SKILLS the new one "
             "starts with - every skill directory under its workspace is "
             "copied. The SOUL is still yours to write."),
    force: bool = typer.Option(
        False, "--force", help="Overwrite an existing agent."),
) -> None:
    """Add an agent to the solution pack you are in."""
    if not NAME_RE.match(role):
        raise refuse_name(
            role,
            "a directory name and the name a workflow step's `role:` uses")

    # Agents are FAMILY-level: in a workspace repo they live in the shared
    # package, where every solution's workflows can name them.
    pack = find_pack(directory).for_content("an agent")
    agent_dir = pack.agents / role
    _refuse_existing(agent_dir, pack, "agent", force)
    _refuse_shipped_role(role, pack)
    like_skills = _skills_of(pack, like) if like else []

    ws = agent_dir / "workspace"
    display = name or _agent_name(role)
    subs = _subs(pack, __ROLE__=role, __AGENT_NAME__=display,
                 __ROLE_WORD__=role.rsplit("_", 1)[-1])

    # THE DEFAULT IS THE COMMON CASE, and most agents are not query engines.
    _kind = (kind or "general").strip().lower()
    if _kind not in ("general", "data"):
        raise typer.BadParameter(
            f"--kind {kind!r} is not a shape; use 'general' or 'data'.")
    _write(ws / "SOUL.md", SOUL_DATA if _kind == "data" else SOUL, subs)
    _write(ws / "TOOLS.md",
           TOOLS_MD_DATA if _kind == "data" else TOOLS_MD, subs)
    _write(ws / "memory" / "MEMORY.md", MEMORY_MD, subs)
    if a2a:
        _write(ws / "a2a-card.yaml", A2A_CARD, subs)
    # AGENTS.md is generated per host and must not be authored here.

    # NO `output_protocol` COPY IS SEEDED ANY MORE. The engine mandates the
    # skill for every step and now SHIPS it (shared-skills wheel), so
    # `_resolve_skill` supplies it to an agent that does not carry one.
    # Seeding a copy here is what put 25 byte-identical copies in this
    # monorepo, each free to drift from the contract the engine enforces -
    # and the file they were copied from carried a named client in its
    # example, which then shipped in every pack.
    copied = _copy_skills(like_skills, ws / "skills")

    console.print(f"[bold green]Created[/] {pack.rel(agent_dir)}")
    console.print(f"  name  : {display}")
    files_line = "SOUL.md, TOOLS.md, memory/MEMORY.md"
    if a2a:
        files_line += ", a2a-card.yaml"
    console.print(f"  files : {files_line}")
    if like:
        console.print(f"  skills: {', '.join(copied) if copied else '(none)'}"
                      f"  - copied from {like}")
    if a2a:
        console.print(
            "[dim]  a2a-card.yaml declares `expose: true` - `aicore serve` "
            "mounts this agent at /a2a/" + role + " with a public card. "
            "Fill in the description and examples: they are what an "
            "external caller's routing matches against. The engine port "
            "has no authentication - keep it on an internal network.[/]")
    console.print("[dim]  output_protocol is supplied by the platform - the "
                  "engine resolves it for every step this agent runs, so the "
                  "agent does not carry a copy. Give it one only to override "
                  "the contract deliberately.[/]")
    console.print(_editable_note(pack))
    console.print("\n[bold]Next[/]")
    console.print(f"  Edit {pack.rel(ws / 'SOUL.md')} - say what this agent is "
                  "for and what it refuses to do.", markup=False)
    console.print(f"  aicore new-workflow <name> --role {role}",
                  markup=False)
    console.print(f'  aicore agent-chat --role {role} -m "Who are you?"'
                  "      # one LLM call proves the persona loaded",
                  markup=False)
    # `run`/`run-step`/`agent-chat` resolve the agent from the installed pack
    # on use, so nothing here needs a sync or a seed. The Studio reads the
    # catalog from the engine serving this workspace, so there is no step
    # for it either (docs/one-truth-content-model.md 4.3).
    console.print("[dim]  A run or a chat picks the agent up from the pack on "
                  "its own. In the Studio it appears once the engine serving "
                  "this workspace runs this pack - there is no sync step.[/]")


# ── new-skill ────────────────────────────────────────────────────────
#
# NOT built on output_protocol's template, and it must not become so. That file
# is platform plumbing that every agent needs a copy of; a skill is domain
# capability. Sharing a template would mean an edit to one silently rewriting
# the other, and one of the two is load-bearing for the protocol parser.
#
# NO `roles:` KEY. It used to be an eligibility gate and is not one any more —
# skills are open, any skill in a workspace may be assigned to any agent, and a
# workflow step resolves a skill by name from the whole catalog. What survives
# is a starting assignment for a workspace that does not exist yet, which is
# not what an author adding a skill to a live pack is doing. Emitting it would
# teach a dead concept to precisely the reader least equipped to spot it.

#: The description is ALWAYS quoted. Frontmatter is parsed with
#: ``yaml.safe_load`` and a plain scalar containing ": " is a mapping, not a
#: string — so an unquoted "when a window is missed: what to check" is a parse
#: error, and a skill whose frontmatter will not parse has no name and no
#: description to match a job against. `<<` is worse still: YAML reads it as
#: the merge key. Neither shows up until something reads the skill.
#: The commented `always` line is the one authoring decision that fails
#: SILENTLY when it is missed. Without it a skill is only ADVERTISED to the
#: agent — name, description, path — and the agent reads it if it judges the
#: skill relevant; a request it can satisfy directly gets answered directly
#: and the skill never participates. Nothing errors, so the author concludes
#: the skill did not load. Stating the choice in the file is the only place
#: it is met at the moment it is made.
_SKILL = """\
---
name: __SKILL__
description: "__DESCRIPTION__"
# always: true   # place this skill's full text in EVERY request. Use it when
#                # the judgement must govern all work (an output contract, a
#                # format rule, a safety boundary). Leave commented out for a
#                # task-specific skill: the agent is told it exists and reads
#                # it when the job matches the description above.
---

# __SKILL_TITLE__

<< One paragraph: what this skill is for, in the words someone would use to
ask for it. This description is the first thing the agent reads and it is what
it matches against the job in front of it. >>

## When this applies

<< Name the situation, not the tool. "When a delivery window was missed and the
carrier disputes it" tells the agent when to reach for this; "when using the
deliveries table" does not. >>

## How to work

1. << The first thing to do, concretely. >>
2. << The next. Keep each result small — aggregate in SQL rather than reading
   rows back and adding them up. >>
3. << Where the answer goes, and in what shape. >>

## What not to do

- << The mistake this skill exists to prevent. Every skill has one; it is
  usually the thing that looks reasonable and is subtly wrong. >>
- Do not state a figure you have not queried. Report the gap instead: "not
  available in `<entity>`".
"""


# ── the tool ↔ skill seam ────────────────────────────────────────────
#
# Both commands live on this: `new-tool` writes the binary name into
# `tools.yaml`, `new-skill --tool` reads it back out. They are separate
# commands that have to agree about one string, so the derivation and the
# lookup sit together rather than one restating the other from memory.

#: `iof-<slug>-<name>`, and the convention is not invented here — the scaffold's
#: own commented stub in PYPROJECT already reads `iof-__SLUG__-prep`, so this
#: fills in the example the reader was handed. The two halves each earn their
#: place: `iof-` marks it as an AgentFarm tool alongside `iof-query` /
#: `iof-consult`, and the SLUG is collision insurance — console scripts are
#: installed per-ENVIRONMENT, not per-package, so two packs in one venv that
#: both declared a plain `iof-score` would have one silently shadow the other,
#: with pip reporting nothing and whichever installed last winning.
def _entry_point_name(slug: str, name: str) -> str:
    return f"iof-{slug}-{name}"


def _tools_yaml_path(pack: PackRepo) -> Path:
    """Where this repo's ``tools.yaml`` lives (or belongs).

    Packaged shape: ``<pkg>/tools.yaml`` beside the content roots. FLAT
    shape: ``tools/tools.yaml`` INSIDE the mapped package - a root-level
    file belongs to no package and a wheel could not ship it. The existing
    file wins wherever it is; creation follows the repo's shape.
    """
    beside = pack.pkg_dir / "tools.yaml"
    inside = pack.pkg_dir / "tools" / "tools.yaml"
    if beside.is_file():
        return beside
    if inside.is_file():
        return inside
    return inside if pack.tools_import else beside


def _mcp_yaml_path(pack: PackRepo) -> Path:
    """Where this repo's ``mcp.yaml`` lives (or belongs).

    Same shape logic as ``tools.yaml`` (a SEPARATE file, because that one is
    documented CLI-only and the two have different execution models):
    packaged shape ``<pkg>/mcp.yaml`` beside the content roots; FLAT shape
    inside the mapped tools package so a wheel can ship it. The existing file
    wins wherever it is; creation follows the repo's shape.
    """
    beside = pack.pkg_dir / "mcp.yaml"
    inside = pack.pkg_dir / "tools" / "mcp.yaml"
    if beside.is_file():
        return beside
    if inside.is_file():
        return inside
    return inside if pack.tools_import else beside


def _declared_mcp_servers(pack: PackRepo) -> list[str]:
    """Every server name the pack's ``mcp.yaml`` declares, in file order."""
    import yaml

    path = _mcp_yaml_path(pack)
    if not path.is_file():
        return []
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return []
    servers = raw.get("mcp_servers") if isinstance(raw, dict) else None
    return [str(n) for n in servers] if isinstance(servers, dict) else []


def _resolve_mcp_server(pack: PackRepo, server: str) -> str:
    """``--mcp-server github`` -> the server name, refused when undeclared.

    CHECKED against the pack's own ``mcp.yaml`` first, then against the
    effective merged view (installed packs + global config + workspace tier) —
    a server may legitimately be operator-declared rather than pack-shipped.
    A typo'd name would otherwise produce a well-formed skill teaching an
    agent to call ``mcp_<server>_*`` tools that never register, and the agent
    WILL look for them: the step burns its attempts reporting a capability
    that does not exist, guided by a file that looks authoritative.
    """
    declared = _declared_mcp_servers(pack)
    if server in declared:
        return server
    # Secondary: what this machine's merged tiers actually know about.
    try:
        from ioagentfarm.engine.iobot_config import effective_mcp_servers
        known = sorted(effective_mcp_servers())
    except Exception:
        known = []
    if server in known:
        return server

    rel = pack.rel(_mcp_yaml_path(pack))
    everything = sorted(set(declared) | set(known))
    if not everything:
        raise typer.BadParameter(
            f"no MCP server named `{server}` is declared anywhere - {rel} "
            f"does not exist and no tier on this machine declares one.\n"
            f"Declare it first: `{_prog()} new-mcp-server {server} "
            f"--command ...` (or `--url ...`), then re-run this.")
    raise typer.BadParameter(
        f"no MCP server named `{server}` - declared here or on this machine: "
        + ", ".join(f"`{s}`" for s in everything)
        + f".\nName one of those, or declare `{server}` first: `{_prog()} "
        f"new-mcp-server {server} --command ...` (or `--url ...`).")


def _declared_tools(pack: PackRepo) -> list[str]:
    """Every binary the pack's ``tools.yaml`` declares, in file order.

    ``name`` falling back to ``bin`` mirrors ``ToolSpec.from_dict`` - the
    resolver accepts an entry giving only one of them, so a lookup that demanded
    ``name`` would report "no such tool" for a tool the resolver validates
    happily.
    """
    import yaml

    path = _tools_yaml_path(pack)
    if not path.is_file():
        return []
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return []
    out: list[str] = []
    for entry in raw.get("tools") or []:
        if isinstance(entry, dict):
            got = str(entry.get("name") or entry.get("bin") or "").strip()
            if got:
                out.append(got)
    return out


def _resolve_tool(pack: PackRepo, tool: str) -> str:
    """``--tool overrun_math`` (or the full binary) -> the binary name.

    CHECKED AGAINST ``tools.yaml`` - the pack's own answer to "what executables
    are there" - and refused by name when it is not one of them. A typo'd
    ``--tool`` would otherwise produce a perfectly well-formed skill teaching an
    agent to run a binary nobody will ever install, and the agent WILL try: it
    surfaces as a step burning its attempts on `command not found`, guided by a
    file that looks authoritative and never mentions the tool that does exist.

    Both spellings resolve. The author says ``overrun_math`` because that is
    what they typed into ``new-tool``; the file says ``iof-<slug>-overrun_math``
    because a console script is installed per-environment and needs the slug not
    to shadow another pack's. Demanding one of the two would be demanding they
    remember which layer they are talking to.
    """
    declared = _declared_tools(pack)
    for candidate in (tool, _entry_point_name(pack.slug, tool)):
        if candidate in declared:
            return candidate

    rel = pack.rel(_tools_yaml_path(pack))
    if not declared:
        raise typer.BadParameter(
            f"{rel} declares no CLI tools at all, so there is no `{tool}` to "
            f"build a skill around.\nWrite the tool first: `{_prog()} "
            f'new-tool {tool} --description "..."`, then re-run this.')
    raise typer.BadParameter(
        f"{rel} declares no tool `{tool}` - it declares "
        + ", ".join(f"`{d}`" for d in declared)
        + f".\nName one of those, or write `{tool}` first: `{_prog()} "
        f"new-tool {tool}`.\n--tool takes the name you gave `new-tool`; the "
        f"full binary name (`{_entry_point_name(pack.slug, tool)}`) works too.")


def _paired_skill_name(tool: str) -> str:
    """What to call the skill that says when to run *tool* - a suggestion.

    Printed inside a command line the reader is meant to paste, so it has to be
    a name ``new-skill`` will accept: NAME_RE caps the length, and a long tool
    name would otherwise produce a suggestion that is refused on arrival.
    """
    candidate = f"{tool}_usage"
    return candidate if NAME_RE.match(candidate) else "<skill_name>"


#: Appended to the SHARED skill template — see `_render_skill`. Everything above
#: it is the ordinary skill file; this is the part that is only true of a skill
#: paired with an executable.
_TOOL_SKILL_TAIL = """
## Running it

```bash
__EP__ --help
```

Read `--help` rather than anything written here: the tool is the contract and
its own help output is current in a way this file cannot be. Nothing below
restates a flag.

<< How to read what it prints — which part carries the answer, what an empty
result means, what a non-zero exit means. That is the half the agent cannot get
from `--help`, and it is why this file exists. >>

<< When NOT to run it: the neighbouring question it does not answer. A tool run
for the wrong job returns a confident number about something nobody asked. >>
"""


#: Appended to the SHARED skill template for `--mcp-server` — the MCP analogue
#: of `_TOOL_SKILL_TAIL`. An MCP server's tools register themselves at session
#: start, so unlike a CLI tool there is no `--help` to defer to: the live tool
#: definitions are the flag reference, and this file carries only the judgement.
_MCP_SKILL_TAIL = """
## The server's tools

This skill is built around the `__SERVER__` MCP server. When the session
starts, the runtime connects to it and registers each of its tools as
`mcp___SERVER___<tool>` — the live tool list is in your tool definitions, not
in this file, and those definitions are current in a way this file cannot be.
Nothing below restates a parameter.

<< Which of the server's tools answers which job, and how to read what each
returns — the half the agent cannot get from the tool definitions. That is
why this file exists. >>

<< When NOT to reach for this server: the neighbouring question it does not
answer. >>

If no `mcp___SERVER___*` tools are registered in this session, the server is
not connected in this deployment (not declared here, or dropped because an
environment variable it references is unset). Say so plainly — never
improvise the capability.
"""


def _render_skill(name: str, description: str) -> str:
    """The SKILL.md template, substituted. ``--tool`` renders through here too.

    ONE TEMPLATE, and it has to stay one. A tool's paired skill differs from an
    ordinary skill by an appended section about reading the tool's output -
    everything above it (the frontmatter contract, when-this-applies, what-not-
    to-do) is the same file. A second copy would drift, and the copy that rots
    is always the one nobody is reading.
    """
    return _SKILL.replace("__SKILL__", name).replace(
        "__SKILL_TITLE__", name.replace("_", " ").capitalize()).replace(
        # Escaped for the double-quoted scalar, not sanitised: a description
        # containing a colon is entirely reasonable and should survive.
        "__DESCRIPTION__",
        description.replace("\\", "\\\\").replace('"', '\\"'))


#: Words that mean the author is describing ARITHMETIC, not judgement. Matched
#: against `--description` only to print ONE hint — never to refuse, never to
#: change what is written. A wrong guess here must cost a reader nothing but a
#: line of output, which is why there is no prompt and no exit code attached to
#: it. Stems, so "computes"/"computation"/"calculated" all land.
_DETERMINISTIC = re.compile(
    r"\b(comput\w*|calculat\w*|sums?|total(?:s|led|ing)?|scor\w*|pars\w*|"
    r"convert\w*|count\w*|aggregat\w*|normali[sz]\w*|dedup\w*|tall(?:y|ies)|"
    r"arithmetic|percentages?|ratios?|averag\w*|tabulat\w*)\b", re.I)


def new_skill(
    name: str = typer.Argument(
        ..., help="Skill name - lowercase, e.g. 'dispute_handling'."),
    role: str = typer.Option(
        None, "--role", "-r",
        help="Give the skill to this agent (its workspace). Omit to add it to "
             "the pack, available to any workflow step that names it."),
    tool: str = typer.Option(
        None, "--tool",
        help="Build the skill around a CLI tool this pack declares - when to "
             "run it, how to read what it prints, when not to. The tool must "
             "exist already: `aicore new-tool <name>` writes it."),
    mcp_server: str = typer.Option(
        None, "--mcp-server",
        help="Build the skill around an MCP server this pack (or this "
             "machine's tiers) declares - when to use its mcp_<server>_* "
             "tools, how to read what they return, when not to. Declare the "
             "server first: `aicore new-mcp-server <name>`."),
    description: str = typer.Option(
        None, "--description",
        help="The one-line description the agent matches against."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
    force: bool = typer.Option(
        False, "--force", help="Overwrite an existing skill."),
) -> None:
    """Add a skill to the solution pack you are in.

    `--tool` writes the skill that makes a CLI tool reachable: a binary on PATH
    is available to every agent and known to none of them until something says
    when to run it. `--role` then assigns it. The two flags are independent -
    a tool skill with no role is a pack-level skill a workflow step names.
    """
    if not NAME_RE.match(name):
        raise refuse_name(
            name,
            "a directory name and the name a workflow step's `skills:` uses")

    if tool and mcp_server:
        raise typer.BadParameter(
            "--tool and --mcp-server are two different bindings (a binary on "
            "PATH vs a server whose tools self-register) - pass one of them")

    # Skills are FAMILY-level, like agents — the shared package is their home.
    pack = find_pack(directory).for_content("a skill")
    # Resolved BEFORE anything is written: a refusal here must leave no skill
    # behind, or the retry after fixing the typo hits `--force`.
    ep = _resolve_tool(pack, tool) if tool else None
    mcp = _resolve_mcp_server(pack, mcp_server) if mcp_server else None

    # THE TWO PLACEMENTS ARE DIFFERENT THINGS, and --role is how you choose.
    # Under an agent's workspace, assignment is BY LOCATION: the skill belongs
    # to that agent because of where it sits. At pack level it belongs to
    # nobody until a workflow step names it — which is a legitimate and common
    # shape, because a step resolves skills from the whole catalog.
    if role:
        _check_role_exists(pack, role)
        skill_dir = pack.agents / role / "workspace" / "skills" / name
    else:
        skill_dir = pack.skills / name
    _refuse_existing(skill_dir, pack, "skill", force)

    human = name.replace("_", " ")
    if ep:
        # THE BINARY GOES IN THE DESCRIPTION. It is the line the agent matches
        # a job against, and for a tool skill the job arrives as "is this
        # something `iof-x-y` answers" — a description that never names the
        # executable leaves the skill matching on the prose alone.
        desc = f"When to run `{ep}`: " + (
            description
            or f"REPLACE ME - what {ep} answers, and when that is the question")
    elif mcp:
        # Same rule, MCP spelling: the agent's registered tools are named
        # `mcp_<server>_<tool>`, so the description names that prefix.
        desc = f"When to use the `{mcp}` MCP server (tools `mcp_{mcp}_*`): " + (
            description
            or f"REPLACE ME - what {mcp} answers, and when that is the question")
    else:
        desc = description or f"REPLACE ME - when {pack.title} work needs {human}"

    body = _render_skill(name, desc)
    if ep:
        body += _TOOL_SKILL_TAIL.replace("__EP__", ep)
    elif mcp:
        body += _MCP_SKILL_TAIL.replace("__SERVER__", mcp)

    skill_dir.mkdir(parents=True, exist_ok=True)
    (skill_dir / "SKILL.md").write_text(body, encoding="utf-8")

    console.print(f"[bold green]Created[/] {pack.rel(skill_dir / 'SKILL.md')}")
    if ep:
        console.print(f"  built around  : {ep}  [dim](its `--help` stays the "
                      "flag reference; this file says when and why)[/]")
    if mcp:
        console.print(f"  built around  : MCP server `{mcp}`  [dim](its tools "
                      f"register live as mcp_{mcp}_*; this file says when "
                      "and why)[/]")
    if role:
        console.print(f"  {_agent_name(role)} now carries it - it sits in that "
                      "agent's workspace, which is what assigns it.")
    else:
        console.print("  Available to the pack; no agent holds it yet. Name it "
                      "in a workflow step's `skills:` list, or give it to an "
                      f"agent: `{_prog()} assign-skill {name} --role <agent>` "
                      "(by name - no copy).")
    console.print(_editable_note(pack))
    console.print("\n[bold]Next[/]")
    console.print(f"  Write {pack.rel(skill_dir / 'SKILL.md')} - every "
                  "`<< ... >>` is a placeholder.", markup=False)
    console.print("[dim]  A step's `skills:` list is the EXACT set for that "
                  "job: any skill it does not name is dropped - except "
                  "output_protocol, which is added unconditionally. Naming "
                  "this one is enough to get it - the agent does not need "
                  "to carry it already.[/]")

    # ONE HINT, AND IT NEVER BLOCKS. The skill is already written by the time
    # this prints; the reader may well be right and we are guessing from a
    # sentence. What it is worth saying once is that the alternative EXISTS —
    # a CLI that offers `new-skill` and nothing else quietly recommends the
    # prompt for work that should have been a script, which is the opposite of
    # this platform's own rule.
    #
    # Silent when --tool was passed: that author already wrote the executable,
    # and this is the skill telling an agent to run it.
    if description and not ep and not mcp and _DETERMINISTIC.search(description):
        console.print(
            "[dim]  That description sounds deterministic. A skill that "
            "teaches an agent to compute something returns an answer that is "
            "plausible and occasionally wrong, with nothing to tell the two "
            "apart. Two commands write the alternative:[/]")
        console.print(f"    aicore new-tool {name} --description \"...\"",
                      markup=False)
        console.print(f"    aicore new-skill {_paired_skill_name(name)} "
                      f"--tool {name}"
                      + (f" --role {role}" if role else ""), markup=False)


# A `_warn_scaffold_skill_test` used to print here: the generated
# `tests/test_pack.py` asserted that every pack-level skill declares `roles:`,
# which nothing written by this command does, so a reader's first `new-skill`
# turned a suite they had not written red. The template no longer asserts it
# (see cli_scaffold.TEST_PACK), and the warning went with it rather than
# staying on as a detector for a defect that was fixed — two places to remember
# one rule is how the rule drifts. A repo scaffolded before that change still
# carries the old assertion and will fail it; the failure names the assertion,
# which is enough to act on.


# ── new-tool ─────────────────────────────────────────────────────────
#
# A tool is THREE artefacts, and only the first of them is the thing the author
# came here to write:
#
#   1. `<pkg>/tools/<name>.py`      the script
#   2. `[project.scripts]`          what actually puts it on PATH
#   3. `tools.yaml`                 what the setup-time resolver validates
#
# Miss 2 and the file is perfect and unreachable. Miss 3 and `cli-hub check`
# passes a pod that has no such binary. Neither announces itself.
#
# The FOURTH thing a usable tool needs — a skill saying when an agent should
# reach for it — is `new-skill --tool <name>`, and this command's closing output
# names that exact line. It is not written here because it is not the same
# decision: the tool is on PATH for everyone, while the skill is scoped, is
# assigned to an agent, and is optional in the one real case where nothing
# decides anything (a `type: exec` step calling the binary by name).


def _dist_name(root: Path) -> str:
    """``project.name`` - the pip-installable name, for the `package:` hint."""
    try:
        data = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):        # pragma: no cover
        return ""
    return str((data.get("project") or {}).get("name") or "")


_TOOLS_INIT = '''\
"""Deterministic CLI tools this pack's agents run via `exec`.

THIS IS A PACKAGE, AND `pyproject.toml` SAYS SO — `new-tool` adds
`"__PKG__.tools"` to `[tool.setuptools] packages`, which lists them explicitly.
Declare it and `pip install .` is required to ship it. Today's setuptools also
sweeps the directory into the wheel when it is left out, but that is behaviour
to inherit, not to depend on: what it would cost is a console script that
installs, resolves, and raises ModuleNotFoundError the first time an agent runs
it — invisible in dev, because an editable install imports from the source tree
where the file has always been, and visible on a pod as a step that failed for
no reason anyone can see.
"""
'''

#: The script. Runnable the moment it is written — `python <file> --help` works
#: before anything is installed — because a template whose body is `pass` gets
#: read as "fill this in later" and is what a reader compares their own broken
#: version against.
_TOOL_SCRIPT = '''\
"""__EP__ — __DESCRIPTION__

A DETERMINISTIC TOOL, not an agent. Everything here runs the same way every
time and can be tested without a model. That is the entire reason it exists: an
agent asked to compute something returns an answer that is plausible and
occasionally wrong, with nothing to tell the two apart.

NOTHING HERE TELLS AN AGENT THIS EXISTS. A console script is on PATH for every
agent and known to none of them; the skill that says WHEN to run it and how to
read what it prints is a separate file, written by
`aicore new-skill __NAME___usage --tool __NAME__`. That skill deliberately
does not restate the flags — `--help` is current in a way a hand-copied list
never is.

THE CONTRACT IS WORTH KEEPING: the machine-readable result on stdout, anything
for a human on stderr, non-zero exit on failure. An agent runs this through
`exec` and parses stdout; a friendly sentence printed there is one more thing it
has to guess its way past, and a traceback there reads as data.
"""
from __future__ import annotations

import argparse
import json
import sys


def summarize(values: list[float]) -> dict:
    """<< REPLACE THIS with what the tool actually computes. >>

    Kept out of `main` so it can be tested directly — no argv, no process, no
    stdout. That is most of the value of writing this as a tool at all.
    """
    if not values:
        return {"count": 0, "sum": 0.0, "min": None, "max": None}
    return {"count": len(values), "sum": sum(values),
            "min": min(values), "max": max(values)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="__EP__",
        description="__DESCRIPTION__")
    parser.add_argument(
        "input", nargs="?", default="-",
        help="JSON file holding an array of numbers, or `-` to read stdin")
    parser.add_argument(
        "--indent", type=int, default=2,
        help="pretty-print width for the JSON result (0 for one line)")
    args = parser.parse_args(argv)

    try:
        if args.input == "-":
            raw = sys.stdin.read()
        else:
            with open(args.input, encoding="utf-8") as fh:
                raw = fh.read()
        values = [float(v) for v in json.loads(raw)]
    except (OSError, ValueError, TypeError) as exc:
        # stderr and a non-zero exit, so the caller sees a FAILURE rather than
        # parsing a traceback off stdout as though it were the result.
        print(f"__EP__: cannot read {args.input}: {exc}", file=sys.stderr)
        return 1

    json.dump(summarize(values), sys.stdout, indent=args.indent or None)
    sys.stdout.write("\\n")
    return 0


if __name__ == "__main__":   # runnable before the console script exists
    sys.exit(main())
'''

#: One entry appended to the pack's `tools.yaml`. Fields per `tools_resolver`.
_TOOLS_YAML_ENTRY = """\
  # __DESCRIPTION__
  #
  # Rides this pack's OWN wheel as a console script, so it is present wherever
  # the pack is installed and this entry is validate-only in practice.
  # `installer: pip` is the mechanism for filling a gap and needs a `package:`
  # before it can act, which only means something once this pack is published.
  - name: __EP__
    owner: domain
    installer: pip
    # package: __DIST__          # uncomment once this pack is on an index
    bin: __EP__
    # `check:` REPLACES the `bin:` probe with a shell command (rc 0 = present).
    # Do not add one for a console script: `bin:` also looks in the running
    # interpreter's own Scripts/ directory, which is exactly where a
    # non-activated venv keeps it, and a shell `check:` reports a false gap
    # there. Use `check:` for a tool whose presence needs more than a PATH hit.
    # check: "__EP__ --version"
"""


def _refuse_existing_tool(pack: PackRepo, script: Path, force: bool) -> None:
    """One artefact can clash, and one thing needs saying that the generic
    refusal cannot.

    `pyproject.toml` and `tools.yaml` are amended in place whether or not
    `--force` is passed, and an entry that is already correct is left alone
    rather than duplicated - so refusing here has not half-written anything,
    which is the question a reader asks on seeing this message.
    """
    if not script.exists() or force:
        return
    raise typer.BadParameter(
        f"this pack already has a tool script at {pack.rel(script)} — pass "
        "--force to overwrite it.\n`pyproject.toml` and `tools.yaml` are edited "
        "in place either way; an entry that is already correct is left alone "
        "rather than duplicated, so nothing is half-written by this refusal.")


def _refuse_retired_flags(name: str, role: str | None,
                          skill: bool | None) -> None:
    """`--role` and `--skill/--no-skill` are gone; say what replaced them.

    KEPT AS HIDDEN OPTIONS RATHER THAN DELETED. Click answers a deleted option
    with "No such option: --role", which reads as a typo - and it sends the
    reader to `--help`, where the flag really is absent and nothing says where
    it went or that the model changed underneath them. A flag that is removed
    because the concept was wrong has to say so once, in the place the old
    command line lands.

    `--role` is the one that mattered: it read as *this tool belongs to this
    agent*, which is false of anything on PATH. `--no-skill` is now simply what
    the command does, and it errors too rather than being accepted silently -
    the outcome would be right and the mental model behind it still wrong,
    which is exactly how someone reaches for `--role` next.
    """
    paired = _paired_skill_name(name)
    if role is not None:
        raise typer.BadParameter(
            "`new-tool --role` is gone. A console script is on PATH, so every "
            "agent can already run it — the flag was really scoping the SKILL "
            "that came with the tool, which is now its own command:\n"
            f'  aicore new-tool {name} --description "…"\n'
            f"  aicore new-skill {paired} --tool {name} --role {role}")
    if skill is not None:
        raise typer.BadParameter(
            "`new-tool --skill/--no-skill` is gone — this command no longer "
            "writes a skill at all, so `--no-skill` is what it always does now. "
            "Drop the flag.\nTo pair a skill with the tool afterwards: "
            f"`aicore new-skill {paired} --tool {name} [--role <agent>]`.")


# ── editing pyproject.toml, carefully ────────────────────────────────
#
# TEXT MANIPULATION, NOT A TOML ROUND-TRIP, and that is the whole design
# constraint. `tomllib` reads and cannot write; `tomlkit` is not a dependency
# and adding one to core so a scaffold can add a line is a poor trade. Every
# writer available in the stdlib would reformat the file and DROP EVERY
# COMMENT — and in this particular file the comments are the content: the
# entry-point block explains that a pack without it installs and is invisible,
# and the package-data block explains that a missing glob is fatal only on a
# pod. Losing those to add one line is a net loss.
#
# So: surgical insertion, then `tomllib.loads` the RESULT and assert the value
# landed. If either step cannot be done safely nothing is written at all and
# the caller prints the lines for the reader to paste. A manual step is a minor
# annoyance; a mangled pyproject.toml is a repo that no longer installs.

def _insert_script_entry(text: str, line: str) -> str | None:
    """Add ``line`` to ``[project.scripts]``, creating the table if needed."""
    lines = text.splitlines(keepends=True)

    for i, raw in enumerate(lines):
        if raw.strip() == "[project.scripts]":
            j = i + 1
            while j < len(lines) and not lines[j].lstrip().startswith("["):
                j += 1
            while j > i + 1 and not lines[j - 1].strip():
                j -= 1          # keep the blank line that separates the tables
            lines.insert(j, line + "\n")
            return "".join(lines)

    # The scaffold ships the table COMMENTED OUT, with an example entry under
    # it. Uncommenting it is what it is there for, and replacing the example
    # with the real thing is better than leaving a stub beside its own answer.
    for i, raw in enumerate(lines):
        if re.fullmatch(r"#\s*\[project\.scripts\]", raw.strip()):
            j = i + 1
            while j < len(lines) and re.match(r"^#\s*[\w.-]+\s*=", lines[j]):
                j += 1
            lines[i:j] = ["[project.scripts]\n", line + "\n"]
            return "".join(lines)

    # No table and no stub: a full table appended at the end of the file is
    # always valid TOML, and the duplicate-table case was ruled out by the
    # caller before we got here.
    tail = text if text.endswith("\n") else text + "\n"
    return f"{tail}\n[project.scripts]\n{line}\n"


def _insert_subpackage(text: str, subpkg: str) -> str | None:
    """Add ``subpkg`` to ``[tool.setuptools] packages = [...]``.

    Only the single-line array the scaffold writes is handled. Anything else
    returns None and becomes a printed manual step - guessing at a shape we did
    not write is how a build file gets mangled.
    """
    m = re.search(r"^(\s*packages\s*=\s*)\[([^\]\n]*)\]([^\n]*)$", text, re.M)
    if not m:
        return None
    inner = m.group(2).strip().rstrip(",")
    joined = f'{inner}, "{subpkg}"' if inner else f'"{subpkg}"'
    return text[:m.start()] + f"{m.group(1)}[{joined}]{m.group(3)}" + text[m.end():]


def _wire_pyproject(root: Path, pkg: str, ep_name: str,
                    target: str, subpkg: str | None = None) -> tuple[str, list[str]]:
    """Declare the console script (and the ``tools`` subpackage) in pyproject.

    Returns ``(outcome, lines_to_paste)`` where outcome is ``added``,
    ``present`` or ``manual``. On ``manual`` the file is untouched.

    *subpkg* overrides the package the script's module must live in - the
    FLAT layout passes its mapped tools package (`acme_tools`), which is
    already in ``packages``, so only the script line is inserted.
    """
    subpkg = subpkg or f"{pkg}.tools"
    paste = [f'[project.scripts]  ->  {ep_name} = "{target}"',
             f'[tool.setuptools]  ->  packages = ["{pkg}", "{subpkg}"]']
    path = root / "pyproject.toml"
    try:
        text = path.read_text(encoding="utf-8")
        data = tomllib.loads(text)
    except (OSError, tomllib.TOMLDecodeError):
        return "manual", paste

    scripts = ((data.get("project") or {}).get("scripts")) or {}
    declared = (((data.get("tool") or {}).get("setuptools")) or {}).get("packages")

    need_script = scripts.get(ep_name) != target
    # A dict here is the `find` directive (auto-discovery), which already covers
    # any subpackage; absent means auto-discovery too. Only an explicit list has
    # to be told, and the scaffold writes an explicit list.
    need_pkg = isinstance(declared, list) and subpkg not in declared
    if not need_script and not need_pkg:
        return "present", []

    new = text
    if need_script:
        new = _insert_script_entry(new, f'{ep_name} = "{target}"')
        if new is None:                       # pragma: no cover - defensive
            return "manual", paste
    if need_pkg:
        nxt = _insert_subpackage(new, subpkg)
        if nxt is None:
            return "manual", paste
        new = nxt

    # THE GATE. Everything above is string surgery on a file we did not write;
    # this is what makes it safe to do at all.
    try:
        after = tomllib.loads(new)
        assert ((after.get("project") or {}).get("scripts") or {})[ep_name] == target
        recheck = (((after.get("tool") or {}).get("setuptools")) or {}).get("packages")
        assert not isinstance(recheck, list) or subpkg in recheck
    except (tomllib.TOMLDecodeError, KeyError, AssertionError):
        return "manual", paste

    path.write_text(new, encoding="utf-8")
    return "added", []


def _declare_in_tools_yaml(pack: PackRepo, entry: str,
                           tool_name: str) -> tuple[str, str]:
    """Append the tool's entry to the pack's ``tools.yaml``.

    Returns ``(outcome, rel_path)``; outcome is ``added``, ``present`` or
    ``manual``. Same rule as the pyproject edit - the file is comment-heavy,
    ``yaml.dump`` would discard all of it, so this inserts text and then parses
    the result to prove the entry landed.
    """
    import yaml

    path = _tools_yaml_path(pack)
    rel = pack.rel(path)
    if not path.is_file():
        # An older pack scaffolded before tools.yaml existed. Write the SDK's
        # own template rather than a bare `tools:` — it carries the CLI-tools-
        # are-not-MCP-servers warning, which is the mistake this file invites.
        _write(path, TOOLS_YAML, _subs(pack))

    text = path.read_text(encoding="utf-8")
    try:
        existing = (yaml.safe_load(text) or {}).get("tools") or []
    except yaml.YAMLError:
        return "manual", rel
    if any(isinstance(t, dict) and t.get("name") == tool_name for t in existing):
        return "present", rel

    lines = text.splitlines(keepends=True)
    out: list[str] | None = None
    for i, raw in enumerate(lines):
        if re.fullmatch(r"tools:\s*\[\s*\]", raw.strip()):
            # `tools: []` is the scaffold's empty state, followed by a commented
            # example of the entry we are about to write for real. Drop the
            # example with it — a stub next to its own answer just reads as two
            # competing declarations.
            j = i + 1
            if j < len(lines) and re.fullmatch(r"#\s*tools:", lines[j].strip()):
                j += 1
                while j < len(lines) and lines[j].lstrip().startswith("#"):
                    j += 1
            out = lines[:i] + ["tools:\n", entry] + lines[j:]
            break
        if re.fullmatch(r"tools:\s*", raw.rstrip("\n")):
            j = i + 1
            while j < len(lines) and (not lines[j].strip()
                                      or lines[j][:1] in (" ", "\t", "#")):
                j += 1
            while j > i + 1 and not lines[j - 1].strip():
                j -= 1
            out = lines[:j] + [entry] + lines[j:]
            break
    if out is None:
        return "manual", rel

    new = "".join(out)
    try:
        parsed = (yaml.safe_load(new) or {}).get("tools") or []
        assert any(isinstance(t, dict) and t.get("name") == tool_name
                   for t in parsed)
    except (yaml.YAMLError, AssertionError):
        return "manual", rel

    path.write_text(new, encoding="utf-8")
    return "added", rel


def _reinstall_note(pack: PackRepo) -> str:
    """Why `_editable_note` MUST NOT be reused for a console script.

    Its reassuring branch - "nothing to reinstall, the engine reads this pack
    from these files, as they are now" - is true of every file a pack contains
    except this one. An entry point is not read from the source tree at all:
    pip generates a launcher into the venv's scripts directory at INSTALL time,
    from the pyproject as it stood then. An editable install does not conjure a
    script that did not exist when it ran. Skip the reinstall and the tool is
    written, declared, and absent from PATH - with `cli-hub check` reporting a
    gap for a file sitting right there.
    """
    import sys as _sys
    from importlib.metadata import entry_points

    if pack.slug not in _installed_pack_names():
        return ("[yellow]This pack is not installed in the venv running this "
                f"command, so neither the engine nor PATH can see any of it. "
                f"Install it: `pip install -e .` in {pack.dist_dir}.[/]")
    bin_dir = Path(_sys.executable).resolve().parent
    return ("[yellow]REINSTALL REQUIRED - unlike an agent or a workflow, a "
            "console script is generated at install time, not read from your "
            f"files. Until you re-run `\"{bin_dir / 'pip'}\" install -e .` the "
            "tool is not on PATH and `cli-hub check` reports a gap.[/]")


def new_tool(
    name: str = typer.Argument(
        ..., help="Tool name - lowercase, e.g. 'window_math'."),
    description: str = typer.Option(
        None, "--description",
        help="One line: what the tool computes. Used in the script and the "
             "tools.yaml entry."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
    force: bool = typer.Option(
        False, "--force", help="Overwrite an existing tool."),
    # Retired. Hidden so `--help` is the new surface, present so an old command
    # line gets an explanation instead of "No such option" — see
    # `_refuse_retired_flags`.
    role: str = typer.Option(None, "--role", "-r", hidden=True),
    skill: bool = typer.Option(None, "--skill/--no-skill", hidden=True),
) -> None:
    """Add a deterministic CLI tool (script + entry point + declaration).

    A skill is instructions; a tool is an executable. If the correct behaviour
    can be written as a script, write the script - an agent asked to compute
    something returns an answer that is plausible and occasionally wrong, with
    nothing to tell the two apart.

    This writes the tool and makes it reachable. Nothing yet tells an agent it
    exists: `aicore new-skill <name>_usage --tool <name>` does that, and
    this command prints the exact line.
    """
    _refuse_retired_flags(name, role, skill)
    if not NAME_RE.match(name):
        raise refuse_name(
            name,
            "a module name and the tail of the binary name")

    # Tools are FAMILY-level: one venv, one PATH — a console script is shared
    # with every solution whether it wants to be or not, so it belongs where
    # the sharing is deliberate.
    pack = find_pack(directory).for_content("a tool")
    ep = _entry_point_name(pack.slug, name)
    # FLAT layout: the tools dir is package-dir-mapped, so the import path is
    # `acme_tools.window_math`, not `<pkg>.tools.window_math`.
    target = (f"{pack.tools_import}.{name}:main" if pack.tools_import
              else f"{pack.pkg}.tools.{name}:main")
    script = pack.pkg_dir / "tools" / f"{name}.py"
    _refuse_existing_tool(pack, script, force)

    human = name.replace("_", " ")
    desc = description or f"REPLACE ME - the {human} {pack.title} computes"

    # 1. the script. `tools/__init__.py` is written only when absent: it is a
    #    file an author may well have added imports to, and the second tool in
    #    a pack must not blank it.
    init = pack.pkg_dir / "tools" / "__init__.py"
    if not init.exists():
        _write(init, _TOOLS_INIT, _subs(pack))
    _write(script, _TOOL_SCRIPT, {
        "__EP__": ep,
        "__NAME__": name,
        # Escaped for a Python double-quoted literal — the description is
        # substituted into `description="…"` as well as into the docstring.
        "__DESCRIPTION__": desc.replace("\\", "\\\\").replace('"', '\\"'),
    })

    # 2. the entry point — the only one of the three that puts it on PATH.
    #    The PRIMARY package's pyproject: in a multi-distribution workspace
    #    that is the shared package's own file, not the repo root's.
    wired, paste = _wire_pyproject(pack.dist_dir, pack.pkg, ep, target,
                                   subpkg=pack.tools_import)

    # 3. the declaration the setup-time resolver reads.
    declared, tools_rel = _declare_in_tools_yaml(
        pack,
        _TOOLS_YAML_ENTRY.replace("__EP__", ep)
                         .replace("__DIST__",
                                  _dist_name(pack.dist_dir) or pack.slug)
                         .replace("__DESCRIPTION__", " ".join(desc.split())),
        ep)

    console.print(f"[bold green]Created[/] {pack.rel(script)}")
    console.print(f"  binary   : {ep}  [dim]-> {target}[/]")
    if wired == "added":
        # markup=False: rich reads "[project.scripts]" as a style tag and eats
        # it, so this line printed as "pyproject.toml , packages += …" — with
        # the name of the block that does the actual work missing.
        console.print("  declared : pyproject.toml [project.scripts]"
                      f", packages += "
                      f"{pack.tools_import or pack.pkg + '.tools'}",
                      markup=False)
    elif wired == "present":
        console.print("  declared : pyproject.toml - already correct, left "
                      "alone")
    else:
        console.print("[yellow]  ! pyproject.toml was NOT edited - its shape is "
                      "not one this command will modify safely, and a mangled "
                      "build file is far worse than a manual step. Add these "
                      "yourself:[/]")
        for line in paste:
            console.print(f"      {line}", markup=False)
    if declared == "added":
        console.print(f"  resolver : {tools_rel} - owner: domain, validate-only")
    elif declared == "present":
        console.print(f"  resolver : {tools_rel} - already declared")
    else:
        console.print(f"[yellow]  ! {tools_rel} was NOT edited; add an entry "
                      f"for `{ep}` by hand (name/owner/bin) or `cli-hub check` "
                      "will never look for it.[/]")
    console.print("  skill    : none - this command writes the executable, not "
                  "the instructions. See Next.")
    console.print(_reinstall_note(pack))

    import sys as _sys
    bin_dir = Path(_sys.executable).resolve().parent
    paired = _paired_skill_name(name)
    console.print("\n[bold]Next[/]")
    console.print(f'  "{bin_dir / "pip"}" install -e .        '
                  "# generates the console script", markup=False)
    console.print(f"  {ep} --help", markup=False)
    console.print(f'  {invocation()} cli-hub check   '
                  f"# expect {ep} ready", markup=False)
    # THE LINE THAT MAKES IT REACHABLE BY AN AGENT. Without it the tool is
    # installed, validated, and nothing in the pack ever mentions it — the
    # quietest of the failure modes, because every check passes. Printed
    # runnable, not as a shape: a one-agent pack gets that agent's name, and a
    # pack with no agents gets no --role at all, which writes the pack-level
    # skill that is the correct thing there.
    roles = pack.agent_roles()
    role_hint = (f" --role {roles[0]}" if len(roles) == 1
                 else " --role <agent>" if roles else "")
    console.print(f'  {invocation()} new-skill {paired} '
                  f"--tool {name}{role_hint}", markup=False)
    console.print(f"[dim]  Write {pack.rel(script)} - `summarize()` is a "
                  "placeholder that runs, so you can replace it one piece at a "
                  "time and keep a working `--help`.[/]")
    console.print("[dim]  Until a skill names it, the binary is on PATH and no "
                  "agent has a reason to run it. Skip the skill only for a tool "
                  "a `type: exec` step calls by name - there nothing decides "
                  "anything.[/]")


# ── assign-skill ─────────────────────────────────────────────────────
#
# THE THIRD WAY AN AGENT CAN HOLD A SKILL, and the only one that does not
# duplicate anything. The other two are physical: a skill under
# `agents/<role>/workspace/skills/` belongs to that agent because of where it
# sits, and a shared wheel skill is seeded in by the pack's opening hand. Give
# one pack-level skill to three agents physically and you have three copies
# that drift — which is not hypothetical: `catalog_reader`,
# `grounded_analysis` and `output_protocol` are each duplicated across two
# agents in `solutions/pharma` today.
#
# The engine has always carried skills by NAME internally (the assignment
# record is names only, content resolved from the shared source at
# materialisation). This command makes that authorable from a repo. What it
# writes is one line in one file; what it prevents is a copy.
#
# IT VALIDATES BEFORE IT WRITES, and that is most of the value. A declaration
# naming a skill nothing can supply is refused here, at import, and at seed —
# three gates for one mistake, because the failure it replaces is an agent that
# runs, reports success, and is quietly missing what you gave it.


_DECLARATION_HEADER = """\
# Skills this agent CARRIES, by name — maintained by `aicore assign-skill`.
#
# The skill itself lives in ONE place: this pack's `skills/` directory, another
# agent's workspace, or the SDK. This file records that this agent holds it.
# Three agents carrying one skill is three lines like these, in three files —
# not three copies of the skill that drift apart.
#
# Content is resolved when the workspace is materialised, so an edit to the
# skill reaches every agent that declares it. A name nothing can supply is
# refused loudly at import and at seed rather than carried as nothing.
carries:
"""


def _declaration_path(pack: PackRepo, role: str) -> Path:
    from ioagentfarm.engine.workspaces import DECLARED_SKILLS_FILE
    return pack.agents / role / "workspace" / DECLARED_SKILLS_FILE


def _read_declaration(pack: PackRepo, role: str) -> list[str]:
    from ioagentfarm.engine.workspaces import (
        SkillDeclarationError, read_declared_skills)
    try:
        return read_declared_skills(pack.agents / role / "workspace")
    except SkillDeclarationError as exc:
        raise typer.BadParameter(
            f"{exc}\nFix the file by hand, or delete it and re-run this "
            "command — it rewrites the whole file.")


def _write_declaration(pack: PackRepo, role: str, names: list[str]) -> None:
    """Rewrite the declaration in full.

    THE WHOLE FILE IS REWRITTEN. It has exactly one key and this command is its
    only author, so there is nothing to preserve.

    AN EMPTY LIST IS WRITTEN, NOT A DELETED FILE, and that is load-bearing
    rather than tidy. ``ensure_agent_workspace`` refreshes the target's copy
    FROM the template, so a template with no file at all leaves whatever the
    workspace already had - the last declaration, still naming the skill the
    author just removed, re-placed on every seed. "Declares nothing" has to be
    something the file can say.
    """
    path = _declaration_path(pack, role)
    path.parent.mkdir(parents=True, exist_ok=True)
    body = "".join(f"  - {n}\n" for n in sorted(names)) if names else " []\n"
    header = (_DECLARATION_HEADER if names
              else _DECLARATION_HEADER.removesuffix("\n"))
    path.write_text(header + body, encoding="utf-8")


def _locate_skill(pack: PackRepo, name: str, role: str) -> str:
    """Where *name* resolves from, as a phrase for the report. Refuses loudly.

    THE REPO IS SEARCHED FIRST and separately from the installed sources,
    because the repo may not be pip-installed in this venv - a pack-level skill
    written five minutes ago is then in no registry and would read as missing.
    """
    from ioagentfarm.engine.workspaces import _resolvable_skill_dirs

    searched: list[str] = []

    cand = pack.skills / name
    searched.append(pack.rel(pack.skills))
    if (cand / "SKILL.md").is_file():
        return f"the pack - {pack.rel(cand)}"

    for other in pack.agent_roles():
        d = pack.agents / other / "workspace" / "skills" / name
        searched.append(pack.rel(pack.agents / other / "workspace" / "skills"))
        if (d / "SKILL.md").is_file():
            return (f"{other}'s workspace - {pack.rel(d)}" if other != role
                    else f"this agent's own workspace - {pack.rel(d)}")

    for root in _resolvable_skill_dirs():
        searched.append(str(root))
        try:
            if (root / name / "SKILL.md").is_file():
                return f"the installed SDK - {root / name}"
        except OSError:
            continue

    raise typer.BadParameter(
        f"no skill `{name}` in this pack or the installed SDK. Searched:\n"
        + "\n".join(f"  {s}" for s in dict.fromkeys(searched))
        + f"\nWrite it first: `aicore new-skill {name}` puts it at pack "
        "level, where any agent can be assigned it.")


#: Skills no agent may be without, and why. Refusing here is the honest
#: answer: both are in the SDK's opening hand and both are protected by the
#: seed's removal guard, so an "unassign" of either was always a no-op that
#: reported success.
#:
#: `guardrails` is the safety contract - no external installs, no credential
#: handling, scope enforcement. `output_protocol` is structural: an agent
#: without it emits no `STATUS:`/`OUTPUT:`, so every step it runs is marked
#: failed and retried until the attempt cap.
def _in_opening_hand(skill: str, role: str) -> bool:
    """Is *skill* already dealt to *role* by the packs' skill defaults?

    The opening hand is what a brand-new agent starts with, merged across every
    installed pack.
    """
    try:
        from ioagentfarm.packs import load_registry
        mapping = load_registry().skill_defaults()
    except Exception:                          # pragma: no cover - defensive
        return False
    entry = mapping.get(skill)
    if entry is None:
        return False
    return entry == "all" or role in entry


def _agent_actually_carries(role: str, skill: str) -> bool:
    """Does *role*'s SEEDED workspace hold *skill* right now?

    The opening hand says what a NEW agent starts with. It does not say what an
    EXISTING agent has, and the two diverge whenever an agent was seeded before
    the pack supplying the skill was installed: the hand names it, the agent
    never got it, and re-running `setup-agents` does not back-fill because the
    assignment record written at that first seed is authoritative afterwards
    (deliberately -- it is what makes a removal survive re-seeding).

    Answering the first question when asked the second is how `assign-skill`
    came to refuse the only command that fixes it, replying "already carries
    it, this changes nothing" about a skill absent from disk, from the database
    and from `workspace show`.

    Read from the DATABASE row, not from a path. The seeded tree is
    workspace-scoped (``.iof/workspaces/<code>/agents/...`` under local mode)
    while ``iobot_agent_workspace`` returns the machine-global
    ``~/.iobot/agents/...``; checking the latter reports "not carried" for
    every agent on a local-mode deployment, which turns the honest no-op back
    into a misleading "Assigned".

    ``pack_assignment`` returns None for "no record to consult" -- no
    database, or nothing derived yet. Treated as NOT carried, so the
    assignment proceeds: writing a declaration that was already true is
    harmless, while refusing one that was needed is the bug this fixes.
    """
    try:
        from ioagentfarm.cli import _workspace_code
        from ioagentfarm.engine.hydration import pack_assignment
        recorded = pack_assignment(_workspace_code(required=True), role)
    except Exception:                          # pragma: no cover - defensive
        return False
    return bool(recorded) and skill in recorded


PROTECTED_SKILLS = {
    "guardrails": "it is the safety contract every agent runs under",
    "output_protocol": "without it an agent's steps cannot report a result",
}


def assign_skill(
    skill: str = typer.Argument(
        ..., help="Skill name, e.g. 'dispute_handling'."),
    role: str = typer.Option(
        None, "--role", "-r",
        help="The agent that carries it (default: the pack's agent, when it "
             "has exactly one)."),
    unassign: bool = typer.Option(
        False, "--unassign", help="Take the skill away from the agent."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
    force: bool = typer.Option(
        False, "--force",
        help="Declare it even when the agent already holds a physical copy."),
) -> None:
    """Give an agent a skill by NAME, without copying it.

    The skill stays where it is - one copy, in the pack or the SDK - and the
    agent's workspace records that it carries it. Assigning one skill to three
    agents costs three lines, not three copies that drift apart.
    """
    # The declaration lands in an agent workspace: family-level content.
    pack = find_pack(directory).for_content("a skill assignment")
    role = _resolve_default_role(pack, role, "which agent carries a skill")
    _check_role_exists(pack, role)

    declared = _read_declaration(pack, role)
    local = pack.agents / role / "workspace" / "skills" / skill

    if unassign:
        if skill in PROTECTED_SKILLS:
            # REFUSE, RATHER THAN REPORT A REMOVAL THAT DOES NOT HAPPEN. These
            # skills are in the SDK's opening hand AND protected by the seed's
            # removal guard, so taking the name out of `skills.yaml` changed
            # nothing: the next seed put the directory back and the catalog
            # still listed the agent as carrying it. The command printed
            # "Unassigned `guardrails`" and the agent kept it -- a safety skill
            # reported as removed while still in force is the worst of both.
            console.print(
                f"[red]`{skill}` cannot be unassigned[/] - {PROTECTED_SKILLS[skill]}")
            console.print(f"[dim]  It stays on every agent. "
                          f"{_agent_name(role)} keeps it.[/]")
            raise typer.Exit(code=2)
        if skill not in declared:
            # NOT silence, and not an error either. The likeliest reason a
            # `--unassign` finds nothing is that the skill is a physical copy —
            # a different mechanism, removed a different way, and saying so is
            # the whole job of this branch.
            console.print(f"[yellow]{_agent_name(role)} does not DECLARE "
                          f"`{skill}` - nothing to remove.[/]")
            if local.is_dir():
                console.print(
                    f"  It has a copy at {pack.rel(local)}. That is assignment "
                    "by LOCATION, not by declaration - delete the directory to "
                    "take it away.")
            elif declared:
                console.print("  It declares: " + ", ".join(declared))
            return
        declared = [n for n in declared if n != skill]
        _write_declaration(pack, role, declared)
        console.print(f"[bold green]Unassigned[/] `{skill}` from "
                      f"{_agent_name(role)}")
    else:
        # BOTH conditions, and the second is the load-bearing one. The opening
        # hand describes a NEW agent; this one may predate the pack that
        # supplies the skill, in which case the hand names it and the agent
        # does not have it. Short-circuiting on the hand alone made this
        # command refuse the only thing that recovers that state.
        if _in_opening_hand(skill, role) and _agent_actually_carries(skill=skill, role=role):
            # SAY WHEN THE COMMAND CHANGES NOTHING. This skill is dealt to the
            # agent already, so declaring it adds a line to `skills.yaml` and
            # nothing else -- yet the command printed "Assigned `guardrails`",
            # which reads as though the agent had just gained it. A reader
            # then believes assignment is what put it there, and that not
            # running the command would have left it out.
            console.print(f"[yellow]{_agent_name(role)} already carries "
                          f"`{skill}`[/] [dim]- it is in the opening hand "
                          "every new agent starts with, so this changes "
                          "nothing.[/]")
            if skill not in declared:
                console.print("[dim]  Declaring it anyway pins it, so a change "
                              "to the defaults cannot take it away:[/]")
                console.print(f"[dim]    {_prog()} assign-skill {skill} "
                              f"--role {role} --force[/]")
            if not force:
                return
        where = _locate_skill(pack, skill, role)
        if local.is_dir() and not force:
            raise typer.BadParameter(
                f"{_agent_name(role)} already has its OWN copy at "
                f"{pack.rel(local)} — sitting in the agent's workspace IS the "
                "assignment, so declaring it too would say the same thing "
                "twice and leave a copy behind to drift.\nTo carry the shared "
                f"one instead: delete {pack.rel(local)}, then re-run this. "
                "To declare it anyway: --force.")
        if skill in declared:
            console.print(f"[yellow]{_agent_name(role)} already declares "
                          f"`{skill}` - nothing changed.[/]")
            return
        declared = sorted({*declared, skill})
        _write_declaration(pack, role, declared)
        console.print(f"[bold green]Assigned[/] `{skill}` to "
                      f"{_agent_name(role)}")
        console.print(f"  resolves from : {where}")
        console.print(f"  declared in   : "
                      f"{pack.rel(_declaration_path(pack, role))}")

    # WHAT THE AGENT NOW CARRIES, both ways, because they are different
    # mechanisms and a reader who only sees one of them will believe a skill
    # went missing. The wheel's own always-on skills are absent from both — the
    # pack's opening hand seeds those, and they are not this pack's to list.
    physical = sorted(
        p.name for p in (pack.agents / role / "workspace" / "skills").iterdir()
        if p.is_dir() and (p / "SKILL.md").is_file()) \
        if (pack.agents / role / "workspace" / "skills").is_dir() else []
    console.print(f"\n[bold]{_agent_name(role)} carries[/]")
    console.print("  declared : " + (", ".join(declared) or "[dim]none[/]"))
    console.print("  its own  : " + (", ".join(physical) or "[dim]none[/]"))
    console.print(_editable_note(pack))
    console.print("\n[bold]Next[/]")
    # NOTHING TO MATERIALISE BY HAND. A run or a chat rebuilds the agent's
    # workspace from the installed pack on use, declaration included, so the
    # next step is simply to use it (docs/one-truth-content-model.md 3.4).
    console.print(f'  {_prog()} agent-chat --role {role} -m "What skills do '
                  'you carry?"      # a run or a chat sees the declaration '
                  "immediately", markup=False)
    # NAME THE WORKSPACE THIS WILL ACT ON. The bare command is correct once a
    # workspace is selected and REFUSES before — there is no fallback tier
    # any more, so the only states are "acts on <code>" and "will refuse".
    try:
        from ioagentfarm.cli import _workspace_code as _ws
        _code = _ws(None, required=False)
    except Exception:
        _code = None
    if _code:
        console.print(f"[dim]  It acts on the selected workspace, {_code}.[/]")
    else:
        console.print("[yellow]  ! no workspace is selected, so that command "
                      f"will refuse[/] [dim]- run `{_prog()} workspace "
                      "use <code>` first[/]")
    console.print("[dim]  The declaration is names only - the skill is "
                  "resolved from its one source every time the workspace is "
                  "built, so an edit to it reaches every agent that declares "
                  "it.[/]")


def unassign_skill(
    skill: str = typer.Argument(
        ..., help="Skill name, e.g. 'dispute_handling'."),
    role: str = typer.Option(
        None, "--role", "-r",
        help="The agent to take it from (default: the pack's agent, when it "
             "has exactly one)."),
    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
) -> None:
    """Take a skill away from an agent."""
    # THE PAIR OF `assign-skill`, and a command rather than a flag on it. The
    # only way to remove an assignment was `assign-skill <name> --unassign`,
    # which reads as an assignment that happens to undo one -- so it was not
    # where anyone looked, and `--help` listed no way to remove a skill at
    # all. The flag still works; this is the name. Kept out of the docstring
    # because Typer renders that as `--help` text, and why a command exists is
    # not something a reader of `--help` asked for.
    assign_skill(skill=skill, role=role, unassign=True,
                 directory=directory, force=False)


# ── new-mcp-server ───────────────────────────────────────────────────
#
# The MCP analogue of `new-tool`, one artefact instead of three: an MCP
# server needs no script (the server IS the executable, launched by the
# runtime) and no entry point (its tools self-register as mcp_<server>_<tool>
# at session start). What it does need is the DECLARATION — the pack's
# `mcp.yaml`, the lowest tier of the pack -> global -> workspace merge — and
# then a skill saying when to use it, which is the paired `new-skill
# <name>_usage --mcp-server <name>` this command's closing output names.

_MCP_YAML_HEADER = """\
# MCP servers this pack's content needs — the PACK tier of the declaration
# merge (pack -> global -> workspace, higher tier wins by server name).
# Entries are iobot MCPServerConfig-shaped; ${VAR} references stay
# unexpanded here and resolve from the environment at config load, so no
# secret ever ships in the wheel. NOT tools.yaml: that file declares CLI
# binaries agents run via exec — a different execution model.
"""


#: Auth scheme words that are meaningless on their own. `Authorization:
#: Bearer` with nothing after it is not a header, it is the wreckage of one.
_SCHEME_ONLY = ("bearer", "basic", "token", "apikey", "digest")


def _kv_pairs(pairs: list, flag: str) -> dict:
    """``K=V`` strings -> dict, refusing malformed entries by name.

    AN EMPTY VALUE IS REFUSED, because on the shells this runs under it is
    almost never typed - it is what is left when the shell expanded a
    variable that was not set. Measured: a build session ran

        --header "Authorization=Bearer ${REY_MCP_TOKEN}"

    with DOUBLE quotes, PowerShell read `${REY_MCP_TOKEN}` as its own
    variable syntax, and the CLI received `Authorization=Bearer `. The
    declaration written was `Authorization: Bearer` - which looks like a
    header, passes lint, ships, and fails at runtime with a 401 that names
    nothing. The reference must reach this process UNEXPANDED; single
    quotes are what keeps it whole, and the docs show single quotes.

    The CLI is the right place to catch it: it is the last point that can
    still see the difference between "the user meant empty" and "the shell
    ate it", and by the next line the evidence is gone.
    """
    out: dict = {}
    for raw in pairs or []:
        key, sep, value = str(raw).partition("=")
        if not sep or not key.strip():
            raise typer.BadParameter(f"{flag} expects K=V (got {raw!r})")
        key, value = key.strip(), value.strip()
        if not value or value.lower() in _SCHEME_ONLY:
            raise typer.BadParameter(
                f"{flag} {key}={value!r} has no value. On PowerShell and "
                f"bash alike, \"${{VAR}}\" inside DOUBLE quotes is expanded "
                f"by the shell before this command runs, and an unset "
                f"variable expands to nothing - which is what this looks "
                f"like. Use SINGLE quotes so the reference arrives whole: "
                f"{flag} '{key}={value + ' ' if value else ''}${{YOUR_VAR}}'. "
                f"The value itself belongs in the workspace .env, never in "
                f"the command.")
        out[key] = value
    return out


def _auth_block_or_refuse(auth_type, token_url, client_id, client_secret,
                          scope, audience):
    """`build_auth_block`, with its refusal as a CLI error not a traceback.

    A half-written `--auth-*` set is an ordinary user mistake; showing a
    Python traceback for it buries the one sentence that says which flag is
    missing.
    """
    from ioagentfarm.engine.iobot_config import build_auth_block
    try:
        return build_auth_block(
            auth_type=auth_type, token_url=token_url, client_id=client_id,
            client_secret=client_secret, scope=scope, audience=audience)
    except ValueError as exc:
        raise typer.BadParameter(str(exc))


def new_mcp_server(
    name: str = typer.Argument(
        ..., help="Server name - lowercase, e.g. 'github'. Its tools appear "
                  "to agents as mcp_<name>_<tool>."),
    command: str = typer.Option(
        "", help="Stdio: command that launches the server (e.g. npx)."),
    args: str = typer.Option(
        "", help="Comma-separated args (e.g. "
                 "'-y,@modelcontextprotocol/server-github')."),
    url: str = typer.Option(
        "", help="Remote: sse/streamableHttp endpoint URL."),
    server_type: str = typer.Option(
        "", "--type",
        help="stdio | sse | streamableHttp (auto-detected when omitted)."),
    header: list[str] = typer.Option(
        [], "--header",
        help="HTTP header K=V for remote servers (repeatable; write secrets "
             "as ${VAR} - they resolve from the environment, never from this "
             "file)."),
    env: list[str] = typer.Option(
        [], "--env",
        help="Env var K=V for stdio servers (repeatable; ${VAR} refs stay "
             "unexpanded)."),
    tool_timeout: int = typer.Option(
        0, help="Per-tool-call timeout in seconds (0 = runtime default)."),
    enabled_tools: str = typer.Option(
        "", help="Comma-separated tool allowlist (default: every tool, "
                 "resource and prompt the server offers)."),
    auth_type: str = typer.Option(
        "", "--auth-type",
        help="OAuth grant for this server: oauth2_client_credentials. The "
             "runtime mints and RENEWS the token itself - use this instead "
             "of a static header when the server issues short-lived tokens."),
    auth_token_url: str = typer.Option(
        "", "--auth-token-url", help="OAuth token endpoint."),
    auth_client_id: str = typer.Option(
        "", "--auth-client-id",
        help="OAuth client id. Write it as ${VAR}; the value belongs in the "
             "workspace .env, not on the command line."),
    auth_client_secret: str = typer.Option(
        "", "--auth-client-secret",
        help="OAuth client secret as ${VAR} (never the value itself)."),
    auth_scope: str = typer.Option("", "--auth-scope", help="OAuth scope."),
    auth_audience: str = typer.Option(
        "", "--auth-audience", help="OAuth audience, when the server wants one."),

    directory: Path = typer.Option(
        None, "--dir", "-d",
        help="The solution repo (default: the current directory)."),
    force: bool = typer.Option(
        False, "--force", help="Overwrite an existing declaration."),
) -> None:
    """Declare an MCP server in this pack's mcp.yaml (the pack tier).

    The runtime does the rest: at session start it connects the server and
    registers each tool as mcp_<name>_<tool> for every agent in scope. The
    declaration is a DEFAULT - the machine's global config and a workspace's
    own mcp.yaml both override it by server name.
    """
    import yaml

    if not _MCP_NAME_RE.match(name):
        raise refuse_name(
            name, "part of every registered tool's name "
            "(mcp_<name>_<tool>)", _MCP_NAME_RE)
    if bool(command) == bool(url):
        raise typer.BadParameter("exactly one of --command (stdio) or --url "
                                 "(sse/streamableHttp) is required")

    # MCP servers are FAMILY-level, like CLI tools — the shared package.
    pack = find_pack(directory).for_content("an MCP server")
    path = _mcp_yaml_path(pack)

    existing: dict = {}
    if path.is_file():
        try:
            existing = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as exc:
            raise typer.BadParameter(
                f"{pack.rel(path)} is not valid YAML ({exc}) - fix it before "
                "declaring another server; rewriting a file that does not "
                "parse would discard whatever it was trying to say.")
    servers = existing.get("mcp_servers") or {}
    if not isinstance(servers, dict):
        raise typer.BadParameter(
            f"{pack.rel(path)} has a non-mapping `mcp_servers:` - fix it "
            "before declaring another server.")
    if name in servers and not force:
        raise typer.BadParameter(
            f"{pack.rel(path)} already declares `{name}` - pass --force to "
            "replace that entry (other entries are left alone).")

    from ioagentfarm.engine.iobot_config import (build_auth_block,
                                                    build_mcp_entry)
    try:
        entry = build_mcp_entry(
            command=command or None,
            args=[a.strip() for a in args.split(",") if a.strip()] or None,
            env=_kv_pairs(env, "--env") or None,
            url=url or None,
            server_type=server_type or None,
            headers=_kv_pairs(header, "--header") or None,
            tool_timeout=tool_timeout or None,
            enabled_tools=([t.strip() for t in enabled_tools.split(",")
                            if t.strip()] if enabled_tools else None),
            auth=_auth_block_or_refuse(
                auth_type, auth_token_url, auth_client_id, auth_client_secret,
                auth_scope, auth_audience),
        )
    except ValueError as exc:
        raise typer.BadParameter(str(exc))

    servers[name] = entry
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        _MCP_YAML_HEADER + yaml.safe_dump(
            {"mcp_servers": servers}, sort_keys=True, allow_unicode=True),
        encoding="utf-8")

    console.print(f"[bold green]Declared[/] `{name}` in {pack.rel(path)}")
    target = command or url
    console.print(f"  launches as   : {target}"
                  + (f" {' '.join(entry.get('args', []))}" if entry.get('args')
                     else ""), markup=False)
    console.print(f"  agents see    : mcp_{name}_<tool>  [dim](registered "
                  "live at session start by the runtime)[/]")
    from ioagentfarm.engine.env_template import (pack_env_example, refs_in,
                                                 workspace_env_stub)
    refs = sorted(refs_in(entry))
    if refs:
        console.print(f"  needs env     : {', '.join(refs)}  [dim](a server "
                      "referencing an unset variable is dropped from configs, "
                      "loudly, rather than aborting runs)[/]")
        # THE VALUE IS TYPED BY A PERSON, INTO A FILE NOTHING HERE WRITES A
        # VALUE INTO. Two stubs: the committed `.env.example` documents the
        # requirement for whoever clones the repo, and the workspace's own
        # `.env` - the file the runtime actually reads - gets a COMMENTED
        # line to uncomment. Commented matters: an empty `VAR=` counts as
        # SET, which would replace the loud "dropped" warning with a server
        # that connects using an empty credential and is rejected on every
        # call.
        why = f"MCP server '{name}'"
        ex_path, ex_added = pack_env_example(pack.root, refs, why)
        if ex_added:
            console.print(f"  documented in : {pack.rel(ex_path)}  "
                          f"[dim](committed; no values)[/]")
        ws_code = ""
        try:
            from ioagentfarm.cli import _workspace_code
            ws_code = _workspace_code("", required=False) or ""
        except Exception:                  # noqa: BLE001 - optional
            ws_code = ""
        ws_path, ws_added = workspace_env_stub(ws_code, refs, why)
        if ws_added:
            console.print(f"  fill in       : {ws_path}", markup=False)
            console.print(f"                  [dim]uncomment "
                          f"{ws_added[0]}= and put the value after the '='. "
                          "That file is yours; nothing else writes it.[/]")
        elif ws_path is None:
            console.print("  [dim]fill in       : no workspace selected - "
                          "the value goes in that workspace's .env "
                          "(`aicore current` names the file)[/]")
    console.print(_editable_note(pack))
    console.print("\n[bold]Next[/]")
    console.print(f"  Nothing announces this server to an agent by itself - "
                  f"write the skill that says when to use it:")
    console.print(f"    {_prog()} new-skill {_paired_skill_name(name)} "
                  f"--mcp-server {name}", markup=False)


def register(app: typer.Typer) -> None:
    app.command("new-workflow")(new_workflow)
    app.command("new-swarm")(new_swarm)
    app.command("new-agent")(new_agent)
    app.command("new-skill")(new_skill)
    app.command("new-tool")(new_tool)
    app.command("new-mcp-server")(new_mcp_server)
    app.command("assign-skill")(assign_skill)
    app.command("unassign-skill")(unassign_skill)
