# `config.json` — the model provider

Written by `aicore init-home`, beside this file. Edit it, then check it:

```bash
aicore config-check
```

## What to set

The file is generated with an **Azure OpenAI** gateway configured. The model and
endpoint are set to working values; **the API key is the only required field**.

| Field | |
|---|---|
| `providers.azure_openai.apiKey` | Required. Replace `<your-api-key>`. |
| `agents.defaults.model` | Set to `gpt-5.2`. This is the **deployment name**, not the published model name, and carries **no `provider/` prefix**. Change it only for a different deployment. |
| `providers.azure_openai.apiBase` | Set to the gateway route. Change it only for a different endpoint. |

Some Azure tenants require `"apiVersion": "<api-version>"` in the same block.
Add it only where the tenant specifies one; gateways that route to a fixed
deployment generally do not.

### Keep exactly one provider block

The provider is chosen by matching the model against the configured providers,
so a second block left in place with a partly-filled key can win the match. Set
the one you use and delete the rest.

### Using Anthropic or an Anthropic-compatible endpoint instead

Replace the whole `providers` block, and prefix the model:

```json
  "providers": {
    "anthropic": {
      "apiKey": "<your-api-key>",
      "apiBase": "https://api.anthropic.com"
    }
  }
```

with `"model": "anthropic/<your-model-id>"`. The prefix is a routing hint and
is removed before the request is sent, so the endpoint receives the model id
alone. **This applies to Anthropic only.** An Azure deployment name must stay
bare — a prefix there is sent as part of the deployment name and the request
fails.

### The provider name must be one the runtime knows

`azure_openai` (or `azureOpenai`) selects the Azure backend. Any other spelling
is accepted and treated as a **generic OpenAI-compatible endpoint** instead —
including near-misses like `azure-openai-gw` or a name left with an `_example_`
prefix. Nothing reports this; the request is simply built for the wrong API
shape. `anthropic`, `openai`, `bedrock` and `openrouter` behave the same way.

Check the file after editing:

```bash
aicore config-check
```

## Only known keys are accepted

**This file must contain no keys other than the ones the runtime defines.** The
top-level object rejects anything it does not recognize, and the rejection does
not appear when you save the file or when `config-check` passes — it appears at
the first agent call, as a validation dump followed by a message about tool
iterations or exec timeouts, which is not the cause.

Notes and reminders therefore live in this file rather than in the JSON. That
is why this file exists: two explanatory keys used to sit at the top of
`config.json`, and they made every agent call fail.

Nested provider blocks are the exception: `providers` accepts entries it does
not recognize, because that is how a custom OpenAI-compatible endpoint is
declared. It is also why a misspelled provider name is not rejected — see
"The provider name must be one the runtime knows" above.

## `maxTokens` is 21333, and that is not a tuning choice

**Do not raise it.** 21333 is the Anthropic SDK's ceiling for a **non-streaming**
request, and the engine runs non-streaming by design.

Above that ceiling every **generation** call is rejected while cheap read calls
still succeed. It therefore presents as a flaky model rather than as a
configuration error, and it is diagnosed by reading the forensic `http.log` for
the real status rather than by retrying. This cost days once.

`contextWindowTokens` is a different setting and is not subject to that limit.

## Nothing here is overwritten

`aicore init-home` never replaces an existing `config.json` — it holds a live
API key — and there is no flag that would. Re-running reports the file as kept.
To start from the template again, delete the file first.
