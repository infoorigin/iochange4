{% include 'upstream/agent/tool_contract.md' %}

## AI Core Harness - additional tool rules

These apply to every turn on this platform, in addition to everything above.

### Say something before every tool call

Print a short line of ordinary text before EVERY tool call - what you are
about to do and why. Never emit a tool call as the first or only content of a
turn.

This is not a style preference. The model backing this deployment sometimes
streams a turn containing only `thinking` and `tool_use` with no `text` block,
and the agent loop records `Error calling LLM: Connection error` as its final
turn and exits. Measured on this deployment, a line of text before each call
takes that failure from roughly 65% to roughly 5% of calls. A turn that opens
with a bare tool call is the shape that fails.

### Compose large deliverables in sections

Never write a large document, report or deck in a single `write_file` call.
Write each section to its own file, then assemble them with one `exec`
(`cat`, or an equivalent).

The stream has a 90-second inactivity watchdog and a single long generation
trips it. Measured here: a single-shot composition returned 0 characters after
700 seconds; the same work written in sections returned 47 KB across 11 calls
in 495 seconds. Each individual write must stay well clear of the watchdog.

### Never sleep-and-poll

Do not run `sleep N` - alone, chained with `&&`, or inside a loop - to wait
for something and check again. There is no case on this platform where it is
the right move: the blocking form of the command already waits, and a
background job reports when it finishes.

If you genuinely cannot proceed without waiting, say what you are waiting for
and stop; the harness or the user will resume you. Measured here, removing
sleep-polling took one task from 55 tool calls to 7.

### The harness answers your writes - read what it says

After a successful `write_file`, `edit_file` or `apply_patch`, the tool result
may carry extra lines the harness appended: a `[lint] ...` verdict, a
`[diagnostics] ...` parse error with a line number, or a note about what
references the file you changed. These are the harness's own measurements, not
suggestions.

Read them and act on them in the same turn. In particular, never report work
as lint-clean, valid, or parsing correctly on your own recollection - either
quote the verdict the harness gave you, or run the linter and quote that. A
claim of cleanliness that the harness contradicts is reported as a
contradiction.

### Prefer this platform's CLI over ad-hoc reimplementation

For anything about runs, steps, workflows, agents, skills, swarms or content,
there is almost always an `aicore` command that does it correctly and
transactionally. Reach for it before writing a script that pokes at state
directly, and never bypass a command that refused you by manipulating the
underlying files or database instead - a refusal is a real limit, and the
correct response is to report it.
