"""Per-workspace registry of EXTERNAL A2A agents.

The static counterpart of ``ainf_registry`` (which discovers agents from a
remote SavantRegistry, env-gated): here an operator registers external A2A
endpoints by hand — ``aicore a2a-add`` — and the entries are materialized
into agent workspaces so any agent carrying the ``a2a_consult`` skill can
route to them via ``iof-consult``.

Storage: ``~/.iobot/workspaces/<code>/external-agents.yaml``, sibling of the
workspace's ``.env`` on purpose. Entries reference secrets as ``${VAR}``
(``iof-consult`` expands them at dispatch time, after loading that ``.env``),
so the YAML itself never carries a token and can travel with backups freely.

Entry schema — the SAME ``agents[]`` shape ``ainf_registry`` writes into
``catalog_dynamic.yaml``, plus an optional ``headers`` mapping. One schema
means the consult skill reads the static and the dynamic catalog
identically::

    agents:
      - name: partner-insights
        description: "Partner market-insights agent"
        a2a_url: "https://partner.example.com/a2a/insights"
        tags: [market-share, partner]
        examples: ["Which regions grew share last quarter?"]
        headers:
          Authorization: "Bearer ${PARTNER_A2A_TOKEN}"

Materialization lands at ``<agent workspace>/metadata/external_agents.yaml``
— sibling of ``catalog_dynamic.yaml`` — at the two seams every runtime
workspace passes through: always-on pool warmup (``web/app.py``) and
``create_filtered_workspace`` (workflow runs). Always-on agents cache their
AgentLoop, so an ``a2a-add`` reaches them at the next warmup or run, not
mid-session.
"""
from __future__ import annotations

import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)

#: The filename agents read, relative to their workspace metadata dir.
MATERIALIZED_NAME = "external_agents.yaml"

#: Bash-style refs iof-consult expands (``${VAR}`` / ``${VAR:-default}``).
_ENV_REF_RE = re.compile(r"\$\{(\w+)(?::-([^}]*))?\}")


def _workspace_code(code: Optional[str]) -> str:
    """Explicit code, or the selected workspace — fail-closed, never invented.

    The registry file carries auth headers; writing or reading it under a
    workspace nobody chose is a credentials-scoping bug, not a convenience.
    """
    if code:
        return code
    from ioagentfarm.engine.workspaces import resolved_workspace_code
    return resolved_workspace_code()


def external_agents_path(code: Optional[str] = None) -> Path:
    """``~/.iobot/workspaces/<code>/external-agents.yaml``."""
    from ioagentfarm.engine.workspace_env import workspace_home
    return workspace_home(_workspace_code(code)) / "external-agents.yaml"


def read_external_agents(code: Optional[str] = None) -> List[Dict[str, Any]]:
    """The workspace's registered external agents (empty list if none)."""
    path = external_agents_path(code)
    if not path.exists():
        return []
    try:
        spec = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (yaml.YAMLError, OSError) as exc:
        logger.warning("external-agents.yaml at %s is unreadable (%s) — "
                       "treated as empty", path, exc)
        return []
    agents = spec.get("agents") if isinstance(spec, dict) else None
    return [a for a in agents if isinstance(a, dict)] if isinstance(
        agents, list) else []


def _write(code: Optional[str], agents: List[Dict[str, Any]]) -> Path:
    path = external_agents_path(code)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump({"agents": agents}, allow_unicode=True,
                       sort_keys=False),
        encoding="utf-8",
    )
    return path


def add_external_agent(
    name: str,
    a2a_url: str,
    description: str = "",
    tags: Optional[List[str]] = None,
    examples: Optional[List[str]] = None,
    headers: Optional[Dict[str, str]] = None,
    code: Optional[str] = None,
) -> Path:
    """Add or replace one external agent entry (matched by ``name``).

    ``a2a_url`` and header values keep their ``${VAR}`` references verbatim
    — expansion is ``iof-consult``'s job at dispatch time.
    """
    entry: Dict[str, Any] = {
        "name": name,
        "description": description,
        "a2a_url": a2a_url,
        "tags": list(tags or []),
        "examples": list(examples or []),
    }
    if headers:
        entry["headers"] = dict(headers)
    agents = [a for a in read_external_agents(code) if a.get("name") != name]
    agents.append(entry)
    path = _write(code, agents)
    logger.info("Registered external A2A agent %r in %s", name, path)
    return path


def remove_external_agent(name: str, code: Optional[str] = None) -> bool:
    """Remove one entry by name. Returns True if something was removed."""
    agents = read_external_agents(code)
    kept = [a for a in agents if a.get("name") != name]
    if len(kept) == len(agents):
        return False
    _write(code, kept)
    logger.info("Removed external A2A agent %r from workspace %s",
                name, _workspace_code(code))
    return True


def unresolved_header_vars(entry: Dict[str, Any]) -> List[str]:
    """``${VAR}`` names in this entry's headers/url that are currently unset
    (and carry no ``:-default``). For diagnostics — never resolves values."""
    unset: List[str] = []
    values = [str(entry.get("a2a_url") or "")]
    values += [str(v) for v in (entry.get("headers") or {}).values()]
    for value in values:
        for m in _ENV_REF_RE.finditer(value):
            if m.group(2) is None and m.group(1) not in os.environ:
                unset.append(m.group(1))
    return sorted(set(unset))


def materialize_external_agents(
    workspace_dir: Path, code: Optional[str] = None,
    names: Optional[List[str]] = None,
) -> Optional[Path]:
    """Write the registry into an AGENT workspace as
    ``metadata/external_agents.yaml`` (the file the consult skill reads).

    Same top-level shape as ``catalog_dynamic.yaml`` (``agents:`` list plus a
    timestamp) so the skill merges the two without a second parser. No
    registered agents -> nothing written, and a STALE materialized copy is
    removed so a de-registered endpoint does not linger in workspaces.

    ``names`` scopes the catalog to a ROSTER (a swarm's ``agents:`` list) —
    without it, routing would match against every registered agent, which is
    a capability leak, not just noise. A roster name with no registry entry
    is warned about by name: the swarm expects an agent this machine has
    never registered, and the meta-agent would otherwise discover that only
    by failing to route.
    """
    target = Path(workspace_dir) / "metadata" / MATERIALIZED_NAME
    agents = read_external_agents(code)
    if names is not None:
        registered = {a.get("name") for a in agents}
        for missing in [n for n in names if n not in registered]:
            logger.warning(
                "swarm roster names external agent %r but the workspace "
                "registry has no such entry (registered: %s) - register it "
                "with a2a-add or fix the roster",
                missing, ", ".join(sorted(filter(None, registered))) or "none")
        agents = [a for a in agents if a.get("name") in set(names)]
    if not agents:
        if target.exists():
            try:
                target.unlink()
                logger.info("Removed stale %s (registry now empty)", target)
            except OSError:
                pass
        return None
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        yaml.safe_dump(
            {"updated_at": datetime.now(timezone.utc).isoformat(),
             "agents": agents},
            allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    logger.debug("Materialized %d external agent(s) into %s",
                 len(agents), target)
    return target
