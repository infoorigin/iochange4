"""Provider factory for iobot v0.1.5+ (native SDK providers).

Mirrors iobot's ``_make_provider()`` routing logic without the CLI-specific
``typer.Exit`` error handling, making it safe for use in web servers and
gateway processes.
"""
from __future__ import annotations


def make_provider(config):
    """Create an LLM provider from a iobot ``Config`` object.

    Routes to the correct backend (Anthropic, OpenAI-compat, Azure, Codex)
    based on the ``ProviderSpec.backend`` field in iobot's provider registry.
    """
    from iobot.providers.base import GenerationSettings
    from iobot.providers.registry import find_by_name

    model = config.agents.defaults.model
    provider_name = config.get_provider_name(model)
    p = config.get_provider(model)
    spec = find_by_name(provider_name) if provider_name else None
    backend = spec.backend if spec else "openai_compat"

    api_key = p.api_key if p else None
    api_base = config.get_api_base(model)
    extra_headers = p.extra_headers if p else None

    if backend == "openai_codex":
        from iobot.providers.openai_codex_provider import OpenAICodexProvider
        provider = OpenAICodexProvider(default_model=model)
    elif backend == "azure_openai":
        from iobot.providers.azure_openai_provider import AzureOpenAIProvider
        provider = AzureOpenAIProvider(
            api_key=p.api_key if p else "",
            api_base=p.api_base if p else "",
            default_model=model,
        )
    elif backend == "anthropic":
        from iobot.providers.anthropic_provider import AnthropicProvider
        provider = AnthropicProvider(
            api_key=api_key,
            api_base=api_base,
            default_model=model,
            extra_headers=extra_headers,
        )
    else:  # openai_compat — covers OpenAI, DeepSeek, OpenRouter, Ollama, vLLM, etc.
        from iobot.providers.openai_compat_provider import OpenAICompatProvider
        provider = OpenAICompatProvider(
            api_key=api_key,
            api_base=api_base,
            default_model=model,
            extra_headers=extra_headers,
            spec=spec,
        )

    defaults = config.agents.defaults
    provider.generation = GenerationSettings(
        temperature=defaults.temperature,
        max_tokens=defaults.max_tokens,
        reasoning_effort=getattr(defaults, "reasoning_effort", None),
    )
    return provider
