"""Dynamic AINF agent discovery from the SavantRegistry external registry.

Called at server startup (and on background refresh) to build catalog_dynamic.yaml
for ainf-meta-agent's workspace.  Uses only httpx (already a project dependency)
and pyyaml (already in the venv via iobot).
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import httpx
import yaml
from loguru import logger

from ioagentfarm.engine.a2a_client import parse_agent_card

PAGE_SIZE = 24


async def discover_ainf_agents(
    registry_url: str,
    api_key: str,
    self_node_id: str = "",
) -> list[dict]:
    """Discover AINF-capable agents from the external agent registry.

    Three-step flow per the SavantRegistry API:
    1. Paginate GET /api/v2/search/?type=AGENT until all pages consumed.
    2. Filter: 'AINF' in description (case-insensitive) AND approvalStatus=='APPROVED'.
       Skip self_node_id to prevent cyclic dispatch.
    3. For each candidate: GET /api/v2/nodes/{node_id}/overview → gateway_url,
       then GET {gateway_url}/.well-known/agent-card.json → parse_agent_card().

    Returns a list of catalog entry dicts: {name, description, a2a_url, tags, examples}.
    Single-agent fetch failures are logged and skipped; list-fetch failures raise.
    """
    registry_url = registry_url.rstrip("/")
    headers = {"x-api-key": api_key} if api_key else {}

    async with httpx.AsyncClient(headers=headers, timeout=30.0) as client:
        raw_agents = await _fetch_all_registry_agents(client, registry_url)
        logger.info(
            f"agent registry: {len(raw_agents)} total agents fetched"
        )

        _accepted_statuses = {"APPROVED", "IN_REVIEW"}
        candidates = [
            a for a in raw_agents
            if a.get("approvalStatus") in _accepted_statuses
            and a.get("node_id") != self_node_id
        ]
        logger.info(
            f"agent registry: {len(candidates)} candidates "
            f"(excluded self={self_node_id!r})"
        )

        entries: list[dict] = []
        for agent in candidates:
            node_id = agent.get("node_id") or agent.get("id") or ""
            name = agent.get("name", node_id)
            entry = await _fetch_catalog_entry(client, node_id, registry_url, name)
            if entry:
                entries.append(entry)
            else:
                logger.warning(
                    f"agent registry: skipped {name!r} ({node_id}) — card fetch failed"
                )

        logger.info(
            f"agent registry: catalog built with {len(entries)} agents: "
            f"{[e['name'] for e in entries]}"
        )
        return entries


async def _fetch_all_registry_agents(
    client: httpx.AsyncClient,
    registry_url: str,
) -> list[dict]:
    """Paginate /api/v2/search/?type=AGENT until all pages consumed."""
    all_agents: list[dict] = []
    page = 1
    total_pages = 1

    while page <= total_pages:
        url = (
            f"{registry_url}/api/v2/search/"
            f"?page={page}&page_size={PAGE_SIZE}&search_type=NAME&type=AGENT"
        )
        resp = await client.get(url)
        logger.info(
            f"agent registry: GET {url} → {resp.status_code} "
            f"body_preview={resp.text[:500]!r}"
        )
        resp.raise_for_status()
        body = resp.json()
        all_agents.extend(body.get("data") or [])
        total_pages = body.get("total_pages", 1)
        page += 1

    return all_agents


async def _fetch_catalog_entry(
    client: httpx.AsyncClient,
    node_id: str,
    registry_url: str,
    display_name: str,
) -> dict | None:
    """Fetch gateway_url from node overview, then parse the agent card.

    GET /api/v2/nodes/{node_id}/overview → gateway_url
    GET {gateway_url}/.well-known/agent-card.json → parse_agent_card()

    Returns a catalog entry dict or None on any failure.
    """
    try:
        overview_url = f"{registry_url}/api/v2/nodes/{node_id}/overview"
        resp = await client.get(overview_url)
        resp.raise_for_status()
        overview = resp.json()
        gateway_url = (overview.get("data") or {}).get("gateway_url") or ""
        if not gateway_url:
            logger.warning(
                f"agent registry: {display_name!r} overview has no gateway_url"
            )
            return None
    except Exception as exc:
        logger.warning(
            f"agent registry: overview fetch failed for {display_name!r}: {exc}"
        )
        return None

    card_url = gateway_url.rstrip("/") + "/.well-known/agent-card.json"
    try:
        resp = await client.get(card_url, timeout=10.0)
        resp.raise_for_status()
        card = resp.json()
    except Exception as exc:
        logger.warning(
            f"agent registry: agent card fetch failed for {display_name!r} "
            f"at {card_url}: {exc}"
        )
        return None

    entry = parse_agent_card(card)
    logger.info(
        f"agent registry: included {entry['name']!r} → {entry['a2a_url']} "
        f"tags={entry['tags']}"
    )
    return entry


async def write_catalog_dynamic(
    agents: list[dict],
    workspace_path: Path,
    reporting_url: str = "",
) -> None:
    """Write catalog_dynamic.yaml to {workspace_path}/metadata/.

    Creates the metadata/ directory if it does not exist.
    Overwrites on every call (used for both initial write and refresh).

    Format::

        discovered_at: 2026-07-12T10:00:00+00:00
        reporting_url: "http://localhost:8000/a2a/reporting"
        agents:
          - name: "AINF Profound Server"
            description: "..."
            a2a_url: "https://...gateway.../a2a/<id>"
            tags: [market-share, sov, ...]
            examples: ["Which products are gaining NRx share?", ...]
    """
    metadata_dir = workspace_path / "metadata"
    metadata_dir.mkdir(parents=True, exist_ok=True)

    catalog = {
        "discovered_at": datetime.now(timezone.utc).isoformat(),
        "reporting_url": reporting_url,
        "agents": agents,
    }
    catalog_path = metadata_dir / "catalog_dynamic.yaml"
    with open(catalog_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(catalog, f, allow_unicode=True, sort_keys=False)

    logger.debug(f"agent registry: wrote {catalog_path}")
