"""OAuth for MCP servers: the harness acquires the token itself.

WHY THIS IS IN CORE. The runtime sent a static header and nothing else, so a
remote MCP server behind OAuth could not be connected at all - the credential
was refused, the server was dropped from the tool registry, and the agent ran
on without those tools. The documented workaround was to put a gateway in
front that performs the flow and presents a static bearer. That works (proven
end to end in `examples/mcp-oauth-lab/`), but it makes every client stand up
and operate a process to do something the client should do for itself.

So the declaration carries an `auth:` block and the runtime mints the token:

    mcp_servers:
      vendors:
        url: https://vendors.example.com/mcp
        auth:
          type: oauth2_client_credentials
          token_url: https://vendors.example.com/token
          client_id: ${VENDORS_CLIENT_ID}
          client_secret: ${VENDORS_CLIENT_SECRET}
          scope: mcp:tools            # optional
          audience: https://vendors   # optional

`${VAR}` references resolve from the environment exactly as they do for
headers - the value still never sits in a file, and the person still types it
into the workspace `.env`.

THIS ALSO FIXES THE JWT CASE. A static JWT works until its `exp` and then
stops, because nothing renews it; measured, that is a scheduled outage. A
token this module minted is re-minted before it expires, so the capability
does not lapse.

Nothing here logs, returns or stores a credential value beyond the live token
it must hold to make requests.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Any

import httpx

from ioagentfarm.engine.env_template import ENV_REF

#: The one grant implemented. Authorization-code needs a browser and a
#: redirect URI, which a headless agent runtime has nowhere to put; naming
#: the supported grant explicitly is what keeps a declaration honest rather
#: than failing at connect time with something vague.
CLIENT_CREDENTIALS = "oauth2_client_credentials"
SUPPORTED_TYPES = (CLIENT_CREDENTIALS,)

#: Re-mint this many seconds before expiry. A token that expires between the
#: check and the request is the failure this exists to remove.
_SKEW_S = 60


class AuthConfigError(ValueError):
    """A declaration that cannot work, named at the earliest possible moment."""


def expand(value: Any) -> tuple[Any, list[str]]:
    """Expand ``${VAR}`` in *value*; report the names that were unset."""
    if not isinstance(value, str):
        return value, []
    missing: list[str] = []

    def one(m):
        name = m.group(1)
        if name in os.environ:
            return os.environ[name]
        whole = m.group(0)
        if ":-" in whole:
            return whole.split(":-", 1)[1].rstrip("}")
        missing.append(name)
        return ""

    return ENV_REF.sub(one, value), missing


def validate(auth: dict) -> list[str]:
    """Everything wrong with an ``auth:`` block, or an empty list.

    Returns problems rather than raising so a linter, `mcp-list` and the
    connect path can all report the same thing in their own voice.
    """
    if not isinstance(auth, dict):
        return ["`auth:` must be a mapping"]
    problems: list[str] = []
    kind = str(auth.get("type") or "").strip()
    if not kind:
        problems.append("`auth.type` is required "
                        f"(supported: {', '.join(SUPPORTED_TYPES)})")
    elif kind not in SUPPORTED_TYPES:
        problems.append(
            f"`auth.type: {kind}` is not supported. This runtime implements "
            f"{', '.join(SUPPORTED_TYPES)}; an authorization-code flow needs "
            "a browser and a redirect URI, which a headless agent has nowhere "
            "to put - terminate that flow in a gateway and give this "
            "declaration the gateway's static credential instead")
    for required in ("token_url", "client_id", "client_secret"):
        if not str(auth.get(required) or "").strip():
            problems.append(f"`auth.{required}` is required")
    url = str(auth.get("token_url") or "")
    if url and not url.startswith(("http://", "https://")):
        problems.append("`auth.token_url` must be an http(s) URL")
    return problems


def unresolved(auth: dict) -> list[str]:
    """``${VAR}`` names in *auth* that the environment does not supply."""
    missing: list[str] = []
    for value in (auth or {}).values():
        _, names = expand(value)
        missing += names
    return sorted(set(missing))


class ClientCredentialsAuth(httpx.Auth):
    """An ``httpx.Auth`` that mints and renews a client_credentials token.

    SUBCLASSES `httpx.Auth` rather than merely quacking like one: httpx
    type-checks the `auth=` argument and refuses anything else with
    `TypeError: Invalid "auth" argument`, which arrives as an
    `unreachable` verdict blaming the network for a local mistake.

    Implemented as the generator-style flow so ONE object serves both the
    sync and async clients - the probe (`mcp-list --probe`) is sync and the
    runtime's MCP transport is async, and they must present the identical
    credential or the diagnostic stops describing the real thing.

    Token state is shared per instance and guarded by a lock: an agent opens
    several MCP requests concurrently and they should mint once, not once
    each.
    """

    # httpx calls this to decide whether to buffer the request body for a
    # possible retry. We do retry once on 401, so the body must be replayable.
    requires_request_body = False
    requires_response_body = True

    def __init__(self, auth: dict):
        problems = validate(auth)
        if problems:
            raise AuthConfigError("; ".join(problems))
        self._raw = dict(auth)
        self._token: str | None = None
        self._expires_at = 0.0
        self._lock = threading.Lock()

    # -- the token ---------------------------------------------------------

    def _form(self) -> dict:
        missing: list[str] = []
        out = {"grant_type": "client_credentials"}
        for key, field in (("client_id", "client_id"),
                           ("client_secret", "client_secret"),
                           ("scope", "scope"), ("audience", "audience")):
            raw = self._raw.get(key)
            if raw in (None, ""):
                continue
            value, miss = expand(raw)
            missing += miss
            out[field] = value
        if missing:
            raise AuthConfigError(
                "unset environment variable(s) for this server's OAuth "
                f"credentials: {', '.join(sorted(set(missing)))}")
        return out

    def _token_url(self) -> str:
        url, missing = expand(self._raw.get("token_url"))
        if missing:
            raise AuthConfigError(
                f"unset environment variable(s) in auth.token_url: "
                f"{', '.join(missing)}")
        return url

    def _fresh_enough(self) -> str | None:
        if self._token and time.time() < self._expires_at - _SKEW_S:
            return self._token
        return None

    def _store(self, payload: dict) -> str:
        token = str(payload.get("access_token") or "")
        if not token:
            raise AuthConfigError(
                "the token endpoint returned no access_token")
        self._token = token
        self._expires_at = time.time() + float(payload.get("expires_in") or 3600)
        return token

    def token_sync(self, client_factory=None) -> str:
        """Mint or reuse, synchronously. Used by the probe."""
        with self._lock:
            cached = self._fresh_enough()
            if cached:
                return cached
            url, form = self._token_url(), self._form()
        with (client_factory or httpx.Client)(timeout=20) as c:
            r = c.post(url, data=form)
            r.raise_for_status()
            payload = r.json()
        with self._lock:
            return self._store(payload)

    async def token_async(self) -> str:
        """Mint or reuse, asynchronously. Used by the MCP transport."""
        with self._lock:
            cached = self._fresh_enough()
            if cached:
                return cached
            url, form = self._token_url(), self._form()
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.post(url, data=form)
            r.raise_for_status()
            payload = r.json()
        with self._lock:
            return self._store(payload)

    def invalidate(self) -> None:
        """Forget the cached token - the server just rejected it."""
        with self._lock:
            self._token, self._expires_at = None, 0.0

    # -- httpx.Auth --------------------------------------------------------

    def sync_auth_flow(self, request):
        request.headers["Authorization"] = f"Bearer {self.token_sync()}"
        response = yield request
        if response.status_code == 401:
            # The server disagrees with our cache - rotated signing key,
            # revoked grant, clock skew. Mint once more and retry; a second
            # 401 is the server's answer and is passed through.
            self.invalidate()
            request.headers["Authorization"] = f"Bearer {self.token_sync()}"
            yield request

    async def async_auth_flow(self, request):
        request.headers["Authorization"] = f"Bearer {await self.token_async()}"
        response = yield request
        if response.status_code == 401:
            self.invalidate()
            request.headers["Authorization"] = (
                f"Bearer {await self.token_async()}")
            yield request


#: One auth object per server NAME, so a token is shared across every
#: connection to that server in this process rather than minted per request.
_AUTHS: dict[str, ClientCredentialsAuth] = {}
_AUTHS_LOCK = threading.Lock()


def auth_for(name: str, spec: dict):
    """The ``httpx.Auth`` for *spec*, or ``None`` when it declares none.

    Raises :class:`AuthConfigError` when an ``auth:`` block is present and
    unusable - a declaration that cannot work should say so at connect time,
    not degrade into an anonymous request that gets a confusing 401.
    """
    auth = (spec or {}).get("auth")
    if not auth:
        return None
    with _AUTHS_LOCK:
        existing = _AUTHS.get(name)
        if existing is not None and existing._raw == auth:
            return existing
        made = ClientCredentialsAuth(auth)
        _AUTHS[name] = made
        return made


def reset() -> None:
    """Forget every cached token. For tests and for `mcp-list --probe`."""
    with _AUTHS_LOCK:
        _AUTHS.clear()
