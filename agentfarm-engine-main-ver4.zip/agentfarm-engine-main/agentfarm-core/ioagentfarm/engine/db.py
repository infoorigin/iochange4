"""Database connection adapters for pluggable store backends.

Built-in adapters:
  - SqliteAdapter  (default, zero dependencies)
  - PostgresAdapter (optional, requires psycopg2)

Third-party packages can implement the DbAdapter protocol
without inheriting anything — just match the method signatures.

Configuration via IOF_DATABASE_URL environment variable:
  - unset / empty       → SQLite at {IOF_ROOT}/state.db
  - sqlite:///path      → SQLite at path
  - postgresql://...    → PostgreSQL

PostgreSQL schema via IOF_DB_SCHEMA (default ``iof``) — see engine_schema().
"""
from __future__ import annotations

import os
import time as _time
import re
from typing import Any, Protocol, runtime_checkable

#: How long an SQLite connection waits for a write lock before raising
#: "database is locked". See SqliteAdapter.connect for why it is not 5s.
SQLITE_BUSY_TIMEOUT_S = float(os.getenv("IOF_SQLITE_BUSY_TIMEOUT_S", "30"))

#: Default PostgreSQL schema for engine-owned tables. Unset env → this value,
#: so every pre-existing deployment keeps working untouched.
DEFAULT_ENGINE_SCHEMA = "iof"

#: A bare SQL identifier. The schema name reaches us from the environment and
#: is interpolated into DDL/`SET search_path`, which cannot take a bind
#: parameter — so it is validated rather than escaped.
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def engine_schema() -> str:
    """PostgreSQL schema holding the engine tables (runs, steps, studio_*).

    Resolved at CONNECT time, not import time, so a process that repoints
    IOF_DB_SCHEMA does not need restarting — the same contract the DB URLs
    already follow.

    SQLite ignores schemas entirely; this only affects PostgreSQL.
    """
    raw = (os.getenv("IOF_DB_SCHEMA") or DEFAULT_ENGINE_SCHEMA).strip()
    if not _IDENT_RE.match(raw):
        raise ValueError(
            f"IOF_DB_SCHEMA={raw!r} is not a valid SQL identifier "
            "(letters, digits and underscore only, not starting with a digit)"
        )
    return raw


@runtime_checkable
class DbAdapter(Protocol):
    """Protocol for database backend adapters.

    Implement these methods to add a new backend (Redis, DynamoDB, etc.)
    as a separate package. No inheritance required — structural typing.
    """

    def connect(self) -> Any:
        """Return a connection with dict-like row access."""
        ...

    def placeholder(self) -> str:
        """Single parameter placeholder: '?' (SQLite) or '%s' (PostgreSQL)."""
        ...

    def auto_id(self) -> str:
        """Column definition for auto-increment integer primary key."""
        ...

    def upsert_ignore(self, sql: str) -> str:
        """Transform an INSERT statement into an insert-or-ignore variant."""
        ...

    def returning_clause(self) -> str:
        """SQL fragment appended to INSERT to return the generated id."""
        ...

    def init_connection(self, con: Any) -> None:
        """Run connection-level setup (e.g. WAL pragma for SQLite)."""
        ...

    def begin_immediate(self, con: Any) -> None:
        """Begin an exclusive transaction for atomic claim operations."""
        ...

    def end_immediate(self, con: Any) -> None:
        """Restore connection state after begin_immediate transaction (COMMIT/ROLLBACK already issued)."""
        ...

    def get_last_id(self, cursor: Any) -> int:
        """Retrieve the auto-generated id from the last INSERT."""
        ...


# ---------------------------------------------------------------------------
# Built-in adapters
# ---------------------------------------------------------------------------

class SqliteAdapter:
    """SQLite backend using stdlib sqlite3. Zero external dependencies."""

    def __init__(self, db_path: str):
        self._db_path = db_path

    def connect(self) -> Any:
        import sqlite3
        from pathlib import Path

        Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
        # THE BUSY TIMEOUT IS THE WHOLE CONCURRENCY STORY FOR SQLITE. A run
        # is several processes on one file - the driver, each step's
        # run-step, its 30s heartbeat thread, the supervisor sweep, `serve` -
        # and WAL lets readers proceed but still serialises WRITERS. The
        # stdlib default waits 5s for the lock and then raises "database is
        # locked"; a heartbeat or a message insert losing that race failed a
        # step for a contention that would have cleared a moment later.
        # 30s is the interval the heartbeat itself runs at.
        con = sqlite3.connect(self._db_path, timeout=SQLITE_BUSY_TIMEOUT_S)
        con.row_factory = sqlite3.Row
        return con

    def placeholder(self) -> str:
        return "?"

    def auto_id(self) -> str:
        return "INTEGER PRIMARY KEY AUTOINCREMENT"

    def upsert_ignore(self, sql: str) -> str:
        return sql.replace("INSERT INTO", "INSERT OR IGNORE INTO", 1)

    def returning_clause(self) -> str:
        return ""

    def init_connection(self, con: Any) -> None:
        con.execute("PRAGMA journal_mode=WAL;")
        # WAL's partner setting: fsync at checkpoints rather than after every
        # transaction. Consistency is unchanged (a crash loses at most the
        # last transactions, never corrupts); what changes is that a message
        # insert per agent stdout line no longer pays a disk sync each.
        con.execute("PRAGMA synchronous=NORMAL;")

    def begin_immediate(self, con: Any) -> None:
        con.isolation_level = None
        con.execute("BEGIN IMMEDIATE;")

    def end_immediate(self, con: Any) -> None:
        con.isolation_level = ""  # restore default deferred transaction mode

    def get_last_id(self, cursor: Any) -> int:
        return int(cursor.lastrowid)


class _PooledConnection:
    """Wrapper that returns a psycopg2 connection to the pool on ``__exit__``.

    The codebase uses ``with store._conn() as con:`` everywhere, relying on
    psycopg2's own context-manager semantics (commit on clean exit, rollback
    on exception, but **no** close). Without a pool, the connection then just
    gets garbage-collected. With this wrapper, we still honour the
    commit/rollback contract by delegating to the underlying connection's
    ``__exit__``, and *additionally* hand the connection back to the pool so
    it can be reused — instead of opening a fresh TCP+TLS connection per
    query (the bottleneck this class exists to fix).

    If an exception leaked out of the body, the connection might be left in
    an unhealthy state (e.g. aborted transaction). We tell the pool to close
    it rather than reuse it — psycopg2.pool's ``putconn(close=True)``.
    """

    __slots__ = ("_pool", "_conn", "_returned", "_on_clean_return")

    def __init__(self, pool: Any, conn: Any, on_clean_return: Any = None) -> None:
        self._pool = pool
        self._conn = conn
        self._returned = False
        # Called only when the body completed WITHOUT raising. That is the
        # signal the checkout path needs: a connection handed back cleanly did
        # real work a moment ago, so asking the server whether it is alive is
        # asking a question we already know the answer to.
        self._on_clean_return = on_clean_return

    def __enter__(self) -> Any:
        # psycopg2 Connection.__enter__ returns the connection itself; the
        # store code expects ``con`` to be the actual psycopg2 connection
        # (it calls ``.cursor()``, ``.commit()``, sets ``.autocommit``,
        # etc.), so we surface that directly.
        return self._conn.__enter__()

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> Any:
        try:
            # Honour psycopg2's commit-on-success / rollback-on-exception
            # contract. Returning False (or None) so exceptions propagate.
            self._conn.__exit__(exc_type, exc_val, exc_tb)
        finally:
            if not self._returned:
                self._returned = True
                # If the body raised, the connection may still be in a bad
                # state — discard it. Otherwise reuse.
                close = exc_type is not None
                if not close and self._on_clean_return is not None:
                    try:
                        self._on_clean_return(self._conn)
                    except Exception:  # pragma: no cover - defensive
                        pass
                try:
                    self._pool.putconn(self._conn, close=close)
                except Exception:  # pragma: no cover - defensive
                    # If the pool is already closed (shutdown race), don't
                    # mask the original exception.
                    pass
        return False

    # ── direct-use compatibility (no with-protocol) ─────────────────────
    # Not every caller wraps the connection in ``with`` — workspace_sync's
    # CLI bridge does ``adapter.connect()`` and calls ``.cursor()`` /
    # ``.commit()`` directly, which hit this wrapper instead of psycopg2
    # (AttributeError: '_PooledConnection' object has no attribute
    # 'cursor'). A wrapper that claims to be a connection must behave like
    # one outside ``with`` too: delegate unknown attributes, and map
    # ``close()`` to a pool return (the pooled analogue of closing).

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_conn"), name)

    def close(self) -> None:
        if not self._returned:
            self._returned = True
            try:
                self._pool.putconn(self._conn, close=False)
            except Exception:  # pragma: no cover - defensive
                pass


class PostgresAdapter:
    """PostgreSQL backend using psycopg2 + ThreadedConnectionPool.

    psycopg2-binary is a HARD dependency of agentfarm-core, so nothing needs
    installing for this backend. There is no [postgres] extra.

    Pool sizing:
      - ``IOF_PG_POOL_MIN`` (default 2): warmed connections kept open
      - ``IOF_PG_POOL_MAX`` (default 20): hard ceiling per pod

    A pod with 10 concurrent session users typically needs ~10 connections
    (one per request handler). Defaulting to max=20 leaves headroom for
    background tasks (s3 sync, learning persistence) without exhausting
    Postgres' default max_connections (100). Tune via env vars per
    deployment. With 30 pods × 20 conn = 600 — too many for stock RDS;
    you'd lower IOF_PG_POOL_MAX or run RDS Proxy in front. With 30 pods
    × 5 conn = 150 = comfortable for a db.r6g.large.
    """

    def __init__(self, dsn: str):
        self._dsn = dsn
        self._pool: Any = None  # lazy-initialised on first connect()
        # id(connection) -> monotonic time of its last CLEAN return.
        # Keyed by id rather than stored on the connection because psycopg2's
        # connection is a C type with no __dict__. Bounded by the pool's own
        # maxconn, and an entry is dropped when its connection is discarded, so
        # this cannot grow.
        self._last_ok: dict[int, float] = {}

    def _get_pool(self) -> Any:
        """Return the ThreadedConnectionPool, initialising it on first use."""
        if self._pool is not None:
            return self._pool
        try:
            import psycopg2.extras  # noqa: F401 - registers cursor factory
            from psycopg2 import pool as _pg_pool
        except ImportError:
            raise ImportError(
                "PostgreSQL backend requires psycopg2, which is a hard "
                "dependency of agentfarm-core — if it is missing, the "
                "install is broken rather than incomplete. Reinstall the "
                "engine. (There is no [postgres] extra; a message here "
                "used to name one, sending people after a flag pip "
                "rejects.)"
            )
        import psycopg2.extras as _extras

        minconn = int(os.getenv("IOF_PG_POOL_MIN", "2"))
        maxconn = int(os.getenv("IOF_PG_POOL_MAX", "20"))
        # ThreadedConnectionPool is safe across asyncio + ThreadPoolExecutor
        # workers because FastAPI runs sync DB ops on a thread pool.
        #
        # TCP keepalives are REQUIRED for managed Postgres (AWS RDS, Cloud SQL)
        # and NAT/firewall paths: without them, an idle pooled connection is
        # silently dropped server-side, and the next getconn() hands out a dead
        # socket → "server closed the connection unexpectedly" mid-operation
        # (the failure that stalled long orchestration steps). Keepalives keep
        # idle connections warm across a multi-minute step and surface a real
        # drop promptly. Tunable via env; defaults are conservative.
        self._pool = _pg_pool.ThreadedConnectionPool(
            minconn,
            maxconn,
            dsn=self._dsn,
            cursor_factory=_extras.RealDictCursor,
            keepalives=1,
            keepalives_idle=int(os.getenv("IOF_PG_KEEPALIVE_IDLE", "30")),
            keepalives_interval=int(os.getenv("IOF_PG_KEEPALIVE_INTERVAL", "10")),
            keepalives_count=int(os.getenv("IOF_PG_KEEPALIVE_COUNT", "5")),
            connect_timeout=int(os.getenv("IOF_PG_CONNECT_TIMEOUT", "10")),
            # search_path rides the HANDSHAKE. It used to be a SET statement in
            # init_connection, run on EVERY transaction - two round trips
            # (the SET and its commit) for a value that cannot change for the
            # life of a connection. The Studio API pool already fixed this the
            # same way (app/database.py); the engine's pool never got it.
            options=f"-c search_path={engine_schema()},public",
        )
        return self._pool

    def connect(self) -> Any:
        import psycopg2
        pool = self._get_pool()
        # A managed-Postgres connection can be dropped server-side while idle in
        # the pool (RDS idle timeout, failover, NAT). A dropped socket often is
        # NOT noticed by rollback() alone — it surfaces mid-operation as
        # "server closed the connection unexpectedly". So validate each checkout
        # with a liveness probe and, if the connection is dead, discard it and
        # take a fresh one. This is the DB layer participating in the harness's
        # expected-failure tolerance: a stale connection is a *normal* event,
        # recovered transparently, not an error surfaced to the caller.
        retries = max(1, int(os.getenv("IOF_PG_CHECKOUT_RETRIES", "3")))
        # How long a connection may coast on its last clean use before the
        # probe is worth paying for again. The probe costs TWO round trips -
        # rollback() and SELECT 1 - measured at 780 ms against RDS, on EVERY
        # checkout, including one returned a second earlier. A store operation
        # was 1880 ms and about 40% of it was verifying a connection we had
        # just finished using.
        #
        # Default 20s, deliberately under the 30s keepalives_idle below: within
        # that window TCP keepalives have not even begun probing, so a peer that
        # died is not yet detectable by any means cheaper than the round trip we
        # are skipping - and the causes of a dead pooled connection (RDS idle
        # timeout, failover, NAT reaping) all take minutes, not seconds.
        probe_after = float(os.getenv("IOF_PG_PROBE_AFTER_S", "20"))
        last_err: Exception | None = None
        for _ in range(retries):
            con = pool.getconn()
            # con.closed is a LOCAL flag - 0.001 ms, no round trip - and catches
            # every connection psycopg2 already knows is gone.
            if (con.closed == 0
                    and (_time.monotonic() - self._last_ok.get(id(con), 0.0))
                    < probe_after):
                con.autocommit = False   # local; applied with the next command
                return _PooledConnection(pool, con, self._mark_clean)
            try:
                con.autocommit = False
                con.rollback()  # clear any aborted-transaction state
                cur = con.cursor()
                cur.execute("SELECT 1")  # liveness probe: dead sockets raise here
                cur.fetchone()
                cur.close()
                return _PooledConnection(pool, con, self._mark_clean)
            except (psycopg2.OperationalError, psycopg2.InterfaceError, psycopg2.DatabaseError) as e:
                last_err = e
                # Broken/stale connection — discard so the pool makes a fresh one.
                self._last_ok.pop(id(con), None)
                try:
                    pool.putconn(con, close=True)
                except Exception:  # pragma: no cover - defensive
                    pass
                continue
        # Exhausted retries without a healthy connection — surface the last error.
        raise last_err if last_err is not None else RuntimeError(
            "PostgresAdapter.connect: could not obtain a live connection"
        )

    def _mark_clean(self, con: Any) -> None:
        """Record that this connection completed an operation without raising."""
        self._last_ok[id(con)] = _time.monotonic()

    def close_pool(self) -> None:
        """Close all pooled connections. Call on application shutdown."""
        if self._pool is not None:
            try:
                self._pool.closeall()
            finally:
                self._pool = None
                self._last_ok.clear()

    def placeholder(self) -> str:
        return "%s"

    def auto_id(self) -> str:
        return "SERIAL PRIMARY KEY"

    def upsert_ignore(self, sql: str) -> str:
        return sql + " ON CONFLICT DO NOTHING"

    def returning_clause(self) -> str:
        return " RETURNING id"

    def init_connection(self, con: Any) -> None:
        """Nothing to do: search_path is set in the connect handshake.

        This used to issue `SET search_path` plus a commit on every single
        transaction. Measured against RDS that is two round trips - about 520 ms
        - repeated for every store operation, including one that only writes a
        line of agent stdout. The value is per-connection and never varies, so
        it belongs in the DSN options where it costs nothing.
        """
        return None

    def begin_immediate(self, con: Any) -> None:
        con.autocommit = True
        cur = con.cursor()
        cur.execute("BEGIN;")

    def end_immediate(self, con: Any) -> None:
        con.autocommit = False  # restore transactional mode

    def get_last_id(self, cursor: Any) -> int:
        row = cursor.fetchone()
        return int(row["id"])


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

# Cache of adapters keyed by URL. PostgresAdapter holds a connection pool
# whose value depends on being a single shared instance per process — many
# call sites in the codebase do ``make_adapter(...)`` per request, and each
# fresh instance would build its own pool, leaking connections and
# defeating the point of pooling. Cache by URL so equivalent calls return
# the same adapter (and therefore the same pool).
_ADAPTER_CACHE: dict[str, DbAdapter] = {}


def make_adapter(url: str | None = None) -> DbAdapter:
    """Create a DbAdapter from a database URL.

    Reads IOF_DATABASE_URL env var if url is not provided.

    Supported schemes:
      - sqlite:///path/to/db   (or empty for default SQLite)
      - postgresql://user:pass@host:port/dbname
      - postgres://...         (alias)

    PostgresAdapter instances are cached by DSN so the connection pool is
    shared across the process — important because many callers construct
    ``make_adapter(...)`` per request rather than holding a long-lived
    reference. SQLite adapters are cached too for symmetry; they're cheap
    and reusing them is harmless.

    Third-party adapters can be used by calling Store(adapter) directly.
    """
    url = url or os.getenv("IOF_DATABASE_URL", "")
    cache_key = url or "__default_sqlite__"

    cached = _ADAPTER_CACHE.get(cache_key)
    if cached is not None:
        return cached

    if not url or url.startswith("sqlite"):
        # Extract path from URL
        path = ""
        if url.startswith("sqlite:///"):
            path = url[len("sqlite:///"):]
        elif url.startswith("sqlite://"):
            path = url[len("sqlite://"):]
        if not path:
            path = ".iof/state.db"  # fallback; cli.py overrides this
        adapter: DbAdapter = SqliteAdapter(path)
    elif url.startswith("postgresql://") or url.startswith("postgres://"):
        adapter = PostgresAdapter(url)
    else:
        raise ValueError(
            f"Unsupported database URL scheme: {url}\n"
            f"Supported: sqlite:///path, postgresql://user:pass@host/db"
        )

    _ADAPTER_CACHE[cache_key] = adapter
    return adapter


def describe_db_target(root_path=None, url: str | None = None) -> str:
    """Human-readable "where does this actually write", credentials redacted.

    `ioagentfarm init` used to report only the state directory, and the two can
    diverge without a word. Found on Git Bash: MSYS rewrites a bare POSIX path
    in an environment variable into a Windows one, but leaves a path INSIDE a
    URL alone, so::

        IOF_ROOT=/c/work/.iof                 -> C:\\work\\.iof
        IOF_DATABASE_URL=sqlite:////c/work/db -> C:\\c\\work\\db  (drive-relative)

    The state directory landed on one path and every row on another, with
    `init` reporting success. Naming the resolved target makes that visible in
    the first command anybody runs.

    The sqlite branch strips exactly the scheme, the way :func:`make_adapter`
    does — a blanket ``lstrip('/')`` would turn ``sqlite:////c/x`` into the
    RELATIVE ``c/x`` and resolve it against the cwd, reporting a third location
    that is neither configured nor opened.
    """
    from pathlib import Path

    url = url if url is not None else (os.getenv("IOF_DATABASE_URL") or "").strip()
    if not url:
        base = Path(root_path) if root_path is not None else Path(".iof")
        return f"{base / 'state.db'} (default sqlite)"
    if url.startswith("sqlite"):
        if url.startswith("sqlite:///"):
            raw = url[len("sqlite:///"):]
        elif url.startswith("sqlite://"):
            raw = url[len("sqlite://"):]
        else:
            raw = url.split(":", 1)[1]
        try:
            return f"{Path(raw).resolve()} (sqlite)"
        except (OSError, ValueError):      # pragma: no cover - unresolvable
            return f"{raw} (sqlite)"
    if "://" in url:
        scheme, rest = url.split("://", 1)
        if "@" in rest:
            userinfo, hostpart = rest.rsplit("@", 1)
            return f"{scheme}://{userinfo.split(':', 1)[0]}:***@{hostpart}"
    return url


def reset_adapter_cache() -> None:
    """Drop cached adapters (closing pools). Used on application shutdown."""
    for adapter in list(_ADAPTER_CACHE.values()):
        close_fn = getattr(adapter, "close_pool", None)
        if callable(close_fn):
            try:
                close_fn()
            except Exception:
                pass
    _ADAPTER_CACHE.clear()
