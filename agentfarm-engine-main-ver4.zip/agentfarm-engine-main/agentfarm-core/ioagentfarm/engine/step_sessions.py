"""Where a step's session file is, and how a run chat forks it.

THE FORK-ON-FIRST-CHAT NEVER FIRED, AND NEITHER DID THE S3 PUSH (found
2026-09-05). A run follow-up is supposed to start from the step's own JSONL -
the agent's full trail from the run - so that "why did you flag BAR-00012?"
is answered from what actually happened. The engine looked for that file as
``iof_<run>_<step>_u_<user>.jsonl`` under the ROLE'S HOME. Two things had
moved out from under it:

* the runtime names a session file by the base64url of its key
  (``SessionManager._storage_key``); the ``:``-to-``_`` spelling is its
  LEGACY name, kept only as a read fallback;
* a step runs in the PER-RUN workspace (``instances/<run>/workspaces/<role>``),
  so its session lives there, not in the role's home.

So ``exists()`` was False on every host, the log said "No step session to
fork - starting fresh chat" on every thread, and the same guard in front of
the S3 push meant nothing was ever pushed: a run's ``sessions/`` prefix held
zero objects after a full run and three chat turns. Every run chat was
answering from a blank session while the code, the docs and the scaling
table said otherwise.

ONE resolver, used by the fork, by the step-completion push and by the
after-reply push, so the three cannot disagree about a name again. The
encoding is pinned equal to the runtime's own by a test, so an upstream
change fails loudly at upgrade rather than silently at the next chat.

Two more things this module settles:

* which step is "the" step for a role - the NEWEST DONE one, the same
  choice the Studio makes when it shows a run id beside the reply. The
  handler used to take the first step in sequence order, so the Studio and
  the engine named different steps for one conversation;
* the S3 object name for a step session is CANONICAL (``step.<step>.jsonl``),
  because the local name carries the user id the step ran under, and that
  varies with which process spawned the step (the driver, a resume from a
  terminal) - a puller on another pod cannot guess it.
"""

from __future__ import annotations

import base64
import json
import re
from pathlib import Path
from typing import Any

#: the prefix every step session key carries: ``iof:<run>:<step>[:u:<uid>]``
STEP_KEY_PREFIX = "iof"


# ── the runtime's naming, in one place ───────────────────────────────────────

def encode_stem(key: str) -> str:
    """The runtime's file stem for a session key (base64url, no padding)."""
    return base64.urlsafe_b64encode(key.encode("utf-8")).decode("ascii").rstrip("=")


def decode_stem(stem: str) -> str | None:
    """Reverse of :func:`encode_stem`; ``None`` for a stem that is not one."""
    try:
        padded = stem + "=" * ((-len(stem)) % 4)
        return base64.urlsafe_b64decode(padded).decode("utf-8")
    except Exception:  # noqa: BLE001 - any malformed stem is "not a key"
        return None


def legacy_stem(key: str) -> str:
    """The runtime's PREVIOUS stem: ``:`` to ``_``, read-only fallback now."""
    return key.replace(":", "_")


def session_file(sessions_dir: Path, key: str) -> Path:
    """The file the runtime reads for ``key`` in ``sessions_dir``.

    The base64 path, unless only the legacy-named file exists - which is
    the runtime's own resolution order.
    """
    primary = sessions_dir / f"{encode_stem(key)}.jsonl"
    if primary.exists():
        return primary
    legacy = sessions_dir / f"{legacy_stem(key)}.jsonl"
    return legacy if legacy.exists() else primary


# ── where a step's session is ────────────────────────────────────────────────

def step_sessions_dir(root: Path, run_id: str, role: str) -> Path:
    """The per-run workspace a step ran in, where its session file lives."""
    return root / "instances" / run_id / "workspaces" / role / "sessions"


def _is_step_key(key: str, run_id: str, step_key: str) -> bool:
    base = f"{STEP_KEY_PREFIX}:{run_id}:{step_key}"
    return key == base or key.startswith(base + ":u:")


def find_step_session(root: Path, run_id: str, step_key: str, role: str) -> Path | None:
    """The step's session file, or ``None``.

    Matched by DECODING each file's stem back to its key - never by guessing
    the user id the step ran under, which differs between the driver and a
    resume from a terminal within one run. Several attempts of one step
    leave several files; the newest wins.
    """
    directory = step_sessions_dir(root, run_id, role)
    if not directory.is_dir():
        return None
    legacy_base = legacy_stem(f"{STEP_KEY_PREFIX}:{run_id}:{step_key}")
    hits: list[Path] = []
    for candidate in directory.glob("*.jsonl"):
        key = decode_stem(candidate.stem)
        if key is not None:
            if _is_step_key(key, run_id, step_key):
                hits.append(candidate)
        elif candidate.stem == legacy_base or candidate.stem.startswith(legacy_base + "_u_"):
            hits.append(candidate)
    if not hits:
        return None
    return max(hits, key=lambda p: p.stat().st_mtime)


def canonical_object_name(step_key: str) -> str:
    """The S3 object name for a step's session: one per step, no user id."""
    return "step." + re.sub(r"[^A-Za-z0-9_.-]+", "_", step_key) + ".jsonl"


def choose_step_for_role(steps: list[dict[str, Any]], role: str) -> dict[str, Any] | None:
    """The step a run chat with ``role`` continues: the newest DONE one.

    The same choice the Studio makes for the run id it shows. With no done
    step, the first in sequence, so a chat about a running pipeline still
    has a step to anchor on.
    """
    mine = [s for s in steps if s.get("role") == role]
    if not mine:
        return None
    done = [s for s in mine if s.get("status") == "done"]
    if done:
        return max(done, key=lambda s: (str(s.get("updated_at") or ""), s.get("seq") or 0))
    return mine[0]


# ── the two operations ───────────────────────────────────────────────────────

def copy_rekeyed(src: Path, dst: Path, key: str) -> None:
    """Copy a session file as the runtime's own file for ``key``.

    The first row of a session file is a metadata row carrying the key it was
    written under. The runtime keys a LOADED session from the name it asked
    for, so a plain copy would work today - and would carry the step's key in
    the copy's metadata, which is what the runtime's legacy resolution and
    session listing read. Re-keyed, the fork is indistinguishable from a
    session the runtime wrote itself.
    """
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp")
    with src.open(encoding="utf-8") as fin, tmp.open("w", encoding="utf-8") as fout:
        for line in fin:
            text = line.strip()
            if not text:
                continue
            try:
                row = json.loads(text)
            except ValueError:
                fout.write(text + "\n")
                continue
            if isinstance(row, dict) and row.get("_type") == "metadata":
                row["key"] = key
                fout.write(json.dumps(row, ensure_ascii=False) + "\n")
            else:
                fout.write(text + "\n")
    tmp.replace(dst)


def push_step_session(storage: Any, root: Path, run_id: str, step_key: str, role: str) -> Path | None:
    """Push a completed step's session under its canonical object name.

    Returns the local file pushed, or ``None`` when the step left no session
    (an ``exec`` step, or a workspace already cleaned up).
    """
    src = find_step_session(root, run_id, step_key, role)
    if src is None:
        return None
    storage.push_file(run_id, src, sub_prefix="sessions", name=canonical_object_name(step_key))
    return src


def fork_step_session(storage: Any, root: Path, run_id: str, step_key: str, role: str,
                      chat_key: str, home_sessions_dir: Path) -> str:
    """Make sure the chat thread ``chat_key`` has a session file to start from.

    Returns what happened, for the log: ``existing`` (the thread already has
    one), ``pulled`` (its own file came back from storage - pod recovery),
    ``forked`` (copied from the step's session on this host), ``forked-from-
    storage`` (copied from the step's pushed session - another pod ran the
    step), or ``fresh`` (nothing to start from; the runtime creates a blank
    session on first use).
    """
    home_sessions_dir.mkdir(parents=True, exist_ok=True)
    chat_file = home_sessions_dir / f"{encode_stem(chat_key)}.jsonl"
    if chat_file.exists() or (home_sessions_dir / f"{legacy_stem(chat_key)}.jsonl").exists():
        return "existing"
    if storage.pull_file(run_id, chat_file.name, chat_file, sub_prefix="sessions"):
        return "pulled"
    src = find_step_session(root, run_id, step_key, role)
    if src is not None:
        copy_rekeyed(src, chat_file, chat_key)
        return "forked"
    staged = chat_file.with_name(chat_file.name + ".step")
    if storage.pull_file(run_id, canonical_object_name(step_key), staged, sub_prefix="sessions"):
        try:
            copy_rekeyed(staged, chat_file, chat_key)
        finally:
            staged.unlink(missing_ok=True)
        return "forked-from-storage"
    return "fresh"
