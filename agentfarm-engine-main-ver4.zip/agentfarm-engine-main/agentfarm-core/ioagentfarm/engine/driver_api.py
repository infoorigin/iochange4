"""The driver contract - the two calls any driver is made of.

A DRIVER is whatever decides the order a run's steps execute in. Three exist
or are foreseen, and they must be interchangeable:

* the agent driver   - project_lead reasons about the next step (default)
* the code driver    - `engine/code_driver.py`, a loop over this module
* a Temporal driver  - a Temporal workflow whose activities call this module

They can be interchangeable because a driver only ever does two things, both
here, and NOTHING about a particular workflow lives in it:

    state = poll_runnable(run_id, ...)     # `aicore next-step --all`
    proc  = start_step(run_id, key, ...)   # `aicore run-step --step-key`

Routing (`type: route`), backward turns (`on_fail`), fan-out, gates, retries
and the attempt cap are all applied by the ENGINE in `_finalize_step`, and
`next-step` reads the result. So a routed workflow needs no routing code in
its driver, and the same YAML runs unchanged under any of the three.

WHAT A TEMPORAL DRIVER LOOKS LIKE, so the seam is concrete:

    @workflow.defn
    class AicoreRun:
        @workflow.run
        async def run(self, run_id: str) -> str:
            while True:
                state = await workflow.execute_activity(poll, run_id, ...)
                if state.get("done"):   return "done"
                if state.get("error"):  raise ApplicationError(state["error"])
                await asyncio.gather(*(
                    workflow.execute_activity(run_step, run_id, s["step_key"], ...)
                    for s in state.get("steps") or []))
                # `waiting` -> loop; Temporal's timer is the poll interval

    @activity.defn
    async def poll(run_id): return poll_runnable(run_id, uid, root, env)

    @activity.defn
    async def run_step(run_id, key):
        return start_step(run_id, key, uid, root, env).wait()

That is the whole of it: a generic loop, identical in shape to
`code_driver.drive`. Temporal then owns durability of the LOOP (a killed
worker resumes polling) while the engine keeps owning the steps - which
already survive a dead driver on their own (`aicore resume`, the supervisor).
Nothing about DeepInsights, or any workflow, appears in either.

Both calls shell out to the CLI on purpose. `next-step` also sweeps the run
supervisor and beats the driver heartbeat; `run-step` owns claiming, the
hard attempt cap, the artifact gate, forensics and pipeline advance. A
second implementation of any of that is a second place for it to drift.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from loguru import logger


def cli_argv(*args: str) -> List[str]:
    return [sys.executable, "-m", "ioagentfarm.cli", *args]


def child_env(workspace: Optional[str]) -> Dict[str, str]:
    """The environment a step command runs in.

    Run and step commands resolve their tenant from the ambient environment;
    a driver-only flag would split the deployment (see `serve --workspace`).
    """
    env = os.environ.copy()
    if workspace:
        env["IOF_WORKSPACE"] = workspace
    # Every start belongs to the driver. The engine's own auto fan-out (a
    # finalizing stories step spawning the first per-item steps itself)
    # bypassed the driver's in-flight table and its console: the first
    # fan-out item ran without ever printing `started` (novice finding).
    env["IOF_AUTO_FANOUT"] = "0"
    return env


def first_json(raw: str) -> Dict[str, Any]:
    """The first JSON object in *raw*, or {}.

    Every workspace-scoped command prints a context line naming its tenant, so
    stdout is not pure JSON. `raw_decode` from the first brace also tolerates
    anything printed after the object.
    """
    i = raw.find("{")
    if i < 0:
        return {}
    try:
        obj, _ = json.JSONDecoder().raw_decode(raw[i:])
    except ValueError:
        return {}
    return obj if isinstance(obj, dict) else {}


def poll_timeout_s() -> float:
    """How long ONE `next-step` poll may take. Strictly under the clock that
    judges the driver for being silent.

    `next-step` writes the driver heartbeat at its START and then sweeps the
    run and renders a prompt per batch entry before returning, so the age the
    supervisor measures is really "how long the last poll took, plus the
    interval". This used to be a flat 120 s against a 30 s staleness
    threshold: a poll allowed to take four times longer than the silence that
    condemns it. A driver inside one slow poll on a loaded shared PostgreSQL
    was therefore declared dead and a second one spawned against its run.

    Killing a poll that overruns is strictly better than letting it outlive
    that clock: the driver simply polls again, and polling again is what
    writes a fresh heartbeat. So the cap is derived from the threshold rather
    than chosen beside it - raise `IOF_SUPERVISOR_CODE_DRIVER_STALE_S` and
    this follows.
    """
    from ioagentfarm.engine.supervisor import code_driver_stale_s
    # The margin covers the poll INTERVAL plus the child's own start-up: the
    # heartbeat lands a moment after the process does.
    return max(20.0, code_driver_stale_s() - 15.0)


def poll_runnable(run_id: str, uid: str, root_path: Path,
                  env: Dict[str, str]) -> Dict[str, Any]:
    """Everything runnable right now: `next-step --all`.

    Always `--all`. The singular form hands out one step and would serialise
    a DAG built to branch. Shape of the answer:

        {"done": true}
        {"done": false, "steps": [{"step_key", "role", "output_dir"}, ...],
         "running": n, "limit": cap, "waiting": bool, "pending_count": n}
        {"error": "..."}
        {}   - could not be read; poll again
    """
    try:
        proc = subprocess.run(
            cli_argv("next-step", "--all", "--run-id", run_id,
                     "--user-id", uid, "--root", str(root_path)),
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", env=env, timeout=poll_timeout_s(),
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        logger.debug("driver: next-step failed: %s", e)
        return {}
    return first_json(proc.stdout or "")


def _survives_ctrl_c() -> Dict[str, Any]:
    """Popen kwargs letting a step child outlive Ctrl+C - but NOT `cancel`.

    Ctrl+C is delivered to the whole foreground process GROUP, so a driver
    started in a terminal took every in-flight step down with it: four
    half-finished adjudication sessions, minutes of model spend each, for a
    keystroke that means "I am stepping away". The steps are the expensive
    part and each is individually recoverable - a child left to finish
    records its result, and `aicore resume` then finds the step done instead
    of paying for it twice.

    **THE DISTINCTION IS THE SIGNAL, NOT THE GROUP, AND GETTING THAT WRONG
    BREAKS THE STOP VERB.** `aicore cancel` exists (certification round 6:
    "no verb to cancel a run") and on POSIX it stops a run with
    `os.killpg(os.getpgid(driver_pid))`. Putting the child in its own
    session - the obvious way to escape Ctrl+C - also puts it outside that
    group, so cancel would kill the driver, mark every step failed, and
    leave the children running and spending against a cancelled run.

    So the child STAYS in the group and ignores SIGINT instead. Ctrl+C is
    SIGINT; cancel sends SIGTERM (and `taskkill /T` on Windows, which walks
    the parent-child tree and is unaffected by the process group). That maps
    exactly onto the two meanings: Ctrl+C is "I am stepping away", cancel is
    "stop this run", and only one of them is meant to reach the work.

    WHAT THIS DOES NOT DO: survive the container. A pod eviction tears down
    every process in it, and nothing here changes that - `resume` re-runs
    those steps.
    """
    if sys.platform == "win32":
        # A new GROUP escapes the console's Ctrl+C event; `taskkill /T`
        # reaches it anyway, because that walks parentage, not groups.
        return {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)}

    def _ignore_sigint() -> None:  # pragma: no cover - runs in the child
        import signal
        signal.signal(signal.SIGINT, signal.SIG_IGN)

    return {"preexec_fn": _ignore_sigint}


def step_log_path(root_path: Path, run_id: str, step_key: str) -> Path:
    """Where a driver child's own console output is kept.

    One file per step key, in the run's log directory, using the same
    colon-folded spelling as everything else that has to name a fan-out step
    in a filename (`story:G01:detect` -> `story_G01_detect`) - Windows
    cannot create a file with a colon in it at all.
    """
    safe = step_key.replace(":", "_").replace("/", "_")
    return root_path / "instances" / run_id / "logs" / "steps" / f"{safe}.log"


def start_step(run_id: str, step_key: str, uid: str, root_path: Path,
               env: Dict[str, str]) -> subprocess.Popen:
    """Start one step and return its process: `run-step --step-key`.

    Foreground, not `--background`: the driver owns the child so it can wait
    on it.

    ITS OUTPUT GOES TO A FILE, NOT TO DEVNULL AND NOT TO THE CONSOLE. The
    console is right to stay clean - with several steps in flight the only
    readable one is the driver's own progress line - but DISCARDING the
    stream threw away the only account of a child that dies before it
    records anything.

    Every early refusal in `run-step` is a `print(json.dumps({"error": ...}))`
    on STDOUT: a step already claimed by someone else, a workspace that would
    not resolve, a step in the wrong status, a prompt that would not render.
    With stdout discarded the driver saw only "the child exited", read the
    row (still `pending`, `attempt` 0) and reported `failed on attempt 0/2 -
    retry queued`, having binned the sentence that said why. Observed live
    on a `barrier_detection` fan-out: two of four children died within
    seconds of spawn and the reason was unrecoverable from the run.

    It matters more at the end of that road than at the start. Five such
    spawns trip `_SPAWN_CAP` and fail the whole run with a message naming
    disk space and permissions - which is a GUESS, and a wrong one if the
    real cause was a duplicate claim. The file is what settles it.

    Truncated per spawn, so it holds the last attempt rather than growing
    without bound, and a failure to open it never stops the step: an
    unwritable log is a worse reason to lose a run than no log at all.
    """
    log = step_log_path(root_path, run_id, step_key)
    try:
        log.parent.mkdir(parents=True, exist_ok=True)
        sink = open(log, "w", encoding="utf-8", errors="replace")
    except OSError:
        logger.debug("driver: cannot open %s; child output discarded", log)
        sink = None
    try:
        return subprocess.Popen(
            cli_argv("run-step", "--step-key", step_key, "--run-id", run_id,
                     "--user-id", uid, "--root", str(root_path)),
            stdout=(sink or subprocess.DEVNULL),
            stderr=(subprocess.STDOUT if sink else subprocess.DEVNULL),
            env=env,
            **_survives_ctrl_c(),
        )
    finally:
        # The CHILD holds its own duplicated handle; this one is ours and
        # closing it is what lets the file be read while the step runs.
        if sink is not None:
            sink.close()


# THERE IS NO `blocked_steps()` HERE, ON PURPOSE. The engine already decides
# when a run cannot converge - `store.mark_run_failed_if_stuck`, called at every
# step finalization - and records it as `runs.status='failed'` + `run.failed`.
# A first cut recomputed that rule here so drivers could stop; it was a second
# discovery of one fact, and the two would have drifted. `next-step` reports
# `blocked` FROM THE RUN'S STATUS, and a driver stops on that.
