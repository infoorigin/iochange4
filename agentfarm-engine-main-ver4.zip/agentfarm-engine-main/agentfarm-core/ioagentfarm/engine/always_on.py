"""Which agents a served engine pre-warms — ONE answer, for every reader.

The startup banner and the agent pool each worked this out for themselves, and
they disagreed. The pool inserts the Core Assistant unconditionally, whatever
``IOF_ALWAYS_ON_AGENTS`` says; the banner read the variable. So an operator who
set the variable to one role read ``agent pool: chat_advisor pre-warmed`` while
the log two lines below said ``Pre-warmed agent: cora`` as well — two extra
model calls and several seconds of startup that the line denied.

That is the same shape as every other defect this file's neighbours were
written for: a statement ABOUT the system computed separately from the system.
The banner now asks this function, and so does the pool.
"""
from __future__ import annotations

import os

#: The Core Assistant is the gateway agent: it answers the Studio's own
#: console and the default chat namespace, so a served engine pre-warms it
#: whether or not a deployment lists it.
GATEWAY_ROLE = "cora"

#: Roles that exist for a person at a desk and must NOT answer over HTTP.
#:
#: ``cora_build`` is the desk-side authoring loop: it carries a shell, writes
#: files and runs scaffold commands, and its own documentation says "local
#: only". It was also a PLATFORM-SHARED role, so it was seeded into every
#: tenant and reachable by name on the served chat surface - and an
#: independent validator drove it, anonymously over HTTP, into running
#: ``echo``; the same route reached ``meta_agent`` and returned ``whoami`` and
#: the host's real filesystem path.
#:
#: That is arbitrary command execution as the serving user, from a caller with
#: no credential. The engine's port has always been documented as a trust
#: boundary, and this does not change that - but "an exposed port lets someone
#: chat with your agents" and "an exposed port is host compromise" are
#: different sentences, and only the second one was true.
#:
#: The build loop is unaffected: ``aicore build`` runs the agent in-process at
#: a terminal and never goes through this surface.
DESK_SIDE_ROLES = frozenset({"cora_build"})


def is_desk_side(role: str) -> bool:
    """Whether *role* is refused on a served surface."""
    from ioagentfarm.engine.workspaces import canonical_role
    try:
        return canonical_role((role or "").strip()) in DESK_SIDE_ROLES
    except Exception:  # noqa: BLE001 - a guard must not depend on imports
        return (role or "").strip() in DESK_SIDE_ROLES


def resolved_always_on(raw: str | None = None) -> list[str]:
    """The roles a served engine pre-warms, in the order it warms them.

    *raw* overrides the environment, for callers that already read it.
    Retired slugs are canonicalised BEFORE the membership test, or a
    deployment still saying ``jarvis`` pre-warms it twice, once under each
    name.
    """
    if raw is None:
        raw = os.environ.get("IOF_ALWAYS_ON_AGENTS", GATEWAY_ROLE)
    try:
        from ioagentfarm.engine.workspaces import canonical_role
    except Exception:  # noqa: BLE001 - a banner must not depend on imports
        def canonical_role(value):  # type: ignore[misc]
            return value

    roles = [canonical_role(a.strip()) for a in (raw or "").split(",") if a.strip()]
    if GATEWAY_ROLE not in roles:
        roles.insert(0, GATEWAY_ROLE)
    return roles


def describe_pool(raw: str | None = None) -> str:
    """One line for the startup banner, naming what is actually pre-warmed."""
    roles = resolved_always_on(raw)
    if not roles:
        return "none pre-warmed; every agent is built on demand"
    return ", ".join(roles) + " pre-warmed, others on demand"
