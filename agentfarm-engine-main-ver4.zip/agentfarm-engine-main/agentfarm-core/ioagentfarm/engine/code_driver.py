"""The code driver — the run's ORDER is decided by code, not by an agent.

`aicore run` normally spawns project_lead as the scheduler: an LLM deciding
which step runs next. `--driver code` replaces that decision with this loop.

**It does not make the run AI-free, and must never be described that way.**
Every step still runs exactly what the workflow says — an `exec` step runs its
command, an agent step runs its agent with its tools and its turn budget. What
changes is that nothing is *asked* which step comes next: the DAG already says,
and a model in the control plane is the largest remaining source of
non-determinism in an otherwise reproducible run.

**Both primitives are shelled out, never re-implemented.** `next-step` also
sweeps the run supervisor and beats the driver heartbeat; `run-step` owns
claiming, the hard attempt cap, the artifact gate, forensics and pipeline
advance. A second implementation of any of that is a second place for it to
drift — so this decides *what* to run and delegates *how* to the same commands
the agent driver calls.

**Parallelism is the point.** `next-step --all` returns EVERY runnable step,
bounded by `IOF_FANOUT_MAX_CHILDREN`; the singular form hands out one and would
serialise a DAG built to branch. Independent siblings and fan-out items run
together, one subprocess each, so a step that dies takes nothing else with it.

The loop terminates. `next-step` says `done` when no step is pending or
running; past that, `IOF_CODE_DRIVER_STALL_S` with nothing running and nothing
startable means the DAG cannot advance, and the run is left with a
`run.driver_gave_up` event rather than a spin.

**The two primitives live in `engine/driver_api.py`, not here.** This module
is one client of that seam; a Temporal workflow whose activities call the same
two functions is another, with an identical loop. Routing (`type: route`),
backward turns (`on_fail`) and every gate are applied by the engine in
`_finalize_step`, so no driver carries workflow-specific code - see
driver_api's docstring for the Temporal sketch.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from loguru import logger

#: No step started or finished for this long, with nothing running: the DAG
#: cannot advance (a dependency that is never satisfied, a step the supervisor
#: cannot reap). This is what bounds the loop.
STALL_S = float(os.environ.get("IOF_CODE_DRIVER_STALL_S", "600"))

#: How often to ask what is runnable while work is in flight.
POLL_S = 2.0


# THE SEAM. Both primitives live in driver_api so a Temporal driver can call
# the very same functions from its activities - see that module's docstring.
# The old private names stay as aliases: they are what tests patch.
from ioagentfarm.engine.driver_api import (  # noqa: E402
    child_env as _child_env, first_json as _first_json,
    poll_runnable as _poll, start_step as _start_step,
    step_log_path as _step_log,
)


#: ANSI escape sequences: the log FILE keeps the raw stream (evidence);
#: the console tail strips them, exactly as `_invoke_agent` does for the
#: agent driver's display.
_ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

#: A loguru runtime record (`2026-09-01 07:08:47.755 | INFO | module:...`).
#: The child's stderr merges into its log file, so the runtime's own log
#: records ride the same stream as the agent's narration. They stay in the
#: FILE - they are the debugging record - but the tail is for a person
#: watching the agent think, and the first live user got whole log dumps
#: stamped with internal module names instead.
_LOG_RECORD = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} \| ")


class _StepTail:
    """Tail one step's log file to the console, line-prefixed (`--follow`).

    The child's stdout - agent thoughts, tool lines, exec output - already
    lands live in `step_log_path(...)`; the console stays quiet by default
    because several steps in flight interleave into soup. This is the
    opt-in middle ground: one tail per SPAWN (the file is truncated per
    spawn), every line prefixed ``[step_key]`` so parallel steps stay
    readable, stopped at reap by draining to EOF first so a child's last
    words are never lost. It never raises - a tail must not be able to
    take down the run it narrates - and every line is encoded to survive
    a legacy Windows console.

    THE TAIL IS A VIEW, NOT THE RECORD. Three transforms apply on the way
    to the console and never to the file: ANSI escapes are stripped,
    loguru runtime records are dropped (they are log plumbing, not
    narration - the file keeps them), and internal names are rewritten to
    the product's own (`branding.rebrand`), because a console a client
    watches must not be stamped with an import package they were never
    given.
    """

    def __init__(self, key: str, path: Path) -> None:
        import threading
        self.key = key
        self.path = path
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._run, daemon=True,
                                   name=f"tail:{key}")
        self._t.start()

    def _emit(self, text: str) -> None:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        safe = text.encode(enc, errors="backslashreplace").decode(
            enc, errors="replace")
        print(safe, flush=True)

    def _run(self) -> None:
        try:
            from ioagentfarm.engine.branding import rebrand
        except Exception:  # noqa: BLE001 - a tail must not die on an import
            def rebrand(s: str) -> str:
                return s
        try:
            with open(self.path, "r", encoding="utf-8",
                      errors="replace") as f:
                while True:
                    line = f.readline()
                    if line:
                        text = _ANSI.sub("", line).rstrip("\r\n")
                        if text and not _LOG_RECORD.match(text):
                            self._emit(f"  [{self.key}] {rebrand(text)}")
                        continue
                    # EOF. Once stop is set the child has exited, so EOF
                    # here means fully drained - not merely "no new bytes
                    # yet", which is what it means while the child lives.
                    if self._stop.is_set():
                        return
                    time.sleep(0.25)
        except Exception:  # noqa: BLE001 - never let a tail kill the drive
            pass

    def stop(self) -> None:
        self._stop.set()
        try:
            self._t.join(timeout=5)
        except Exception:  # noqa: BLE001
            pass


#: How many times the driver will start one step that never records an
#: attempt. Deliberately small: a step that cannot reach its own bookkeeping
#: is not failing intermittently, it is failing for a reason that will not
#: change on the next try.
_SPAWN_CAP = 5


def _wait_any(inflight: Dict[str, subprocess.Popen], timeout: float) -> None:
    """Block until one child exits or *timeout* elapses.

    Polled rather than `os.wait()` because this has to work on Windows, where
    the whole local-development story lives.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if any(p.poll() is not None for p in inflight.values()):
            return
        time.sleep(0.2)


def _gave_up(root_path: Path, run_id: str, state: Dict[str, Any],
             reason: str = "") -> None:
    """Leave a diagnosable record, the way the agent driver's give-up does.

    Same event type on purpose: `forensics explain` already reads it, and a
    second name for "the driver stopped without converging" would mean the
    postmortem answers one shape and not the other.
    """
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_FATAL
        get_forensics(root_path).emit(
            run_id=run_id,
            event_type="run.driver_gave_up",
            severity=SEVERITY_FATAL,
            message=(f"code driver: {reason}" if reason else
                     (f"code driver: nothing started or finished for "
                      f"{STALL_S:.0f}s and no step is running - the DAG "
                      f"cannot advance")),
            payload={"driver": "code",
                     "reason": reason or "stalled",
                     "pending_count": state.get("pending_count"),
                     "waiting": state.get("waiting")},
        )
    except Exception:  # noqa: BLE001 - never let the record break the exit
        logger.debug("code driver: give-up emit failed", exc_info=True)


def _step_verdict(root_path: Path, run_id: str, step_key: str) -> str:
    """`done` / `failed` / `pending again` from the step's ROW.

    OUTPUT.md is what the TOOL said; the artifact gate and the route
    universe can fail a step whose tool said done, and the console printed
    `-> done` for exactly those (novice finding). The row is what the
    engine decided. OUTPUT.md stays the fallback when the store is out of
    reach.
    """
    try:
        from ioagentfarm.engine.db import make_adapter
        from ioagentfarm.engine.store import Store
        url = os.getenv("IOF_DATABASE_URL", "") or f"sqlite:///{Path(root_path) / 'state.db'}"
        st = Store(make_adapter(url))
        row = next((r for r in st.list_steps(run_id) if r["step_key"] == step_key), None)
        if row is not None:
            status = str(row.get("status") or "")
            if status == "pending":
                # the engine queued another attempt: say why, and which
                try:
                    meta = json.loads(row.get("meta_json") or "{}")
                except Exception:  # noqa: BLE001
                    meta = {}
                if meta.get("reset_by"):
                    return f"reset by {meta['reset_by']} - re-run queued"
                # ATTEMPT 0 IS A DIFFERENT ANIMAL and used to read the same.
                # A step back at `pending` with the counter still on zero did
                # not fail its work - it never got as far as claiming, so
                # `run-step` refused it and said why on a stream the driver
                # discarded. Say which, and where the child's own words are.
                if not int(row.get("attempt") or 0):
                    return ("exited before claiming the step (no attempt "
                            "recorded) - the child's own output is in "
                            f"{_step_log(root_path, run_id, step_key)}")
                return (f"failed on attempt {row.get('attempt')}/"
                        f"{row.get('max_attempts')} - retry queued")
            if status:
                return status
    except Exception:  # noqa: BLE001 - fall back to what the tool said
        pass
    try:
        from ioagentfarm.cli_orchestration import safe_step_key
        from ioagentfarm.engine.protocol import parse_key_value_protocol
        p = root_path / "runs" / run_id / "steps" / safe_step_key(step_key) / "OUTPUT.md"
        kv, _, _ = parse_key_value_protocol(p.read_text(encoding="utf-8", errors="replace"))
        st = (kv.get("STATUS") or "").strip().lower()
        return st or "unknown"
    except Exception:  # noqa: BLE001
        return "unknown"


def _drive_loop(*, root_path: Path, run_id: str, uid: str,
          workspace: Optional[str] = None,
          follow: bool = False,
          on_event: Optional[Callable[[str], None]] = None) -> str:
    """Drive *run_id* to a terminal state. Returns why the loop stopped.

    One of ``"done"`` (nothing left to run), ``"failed"`` (a step failed on
    its last attempt and nothing can advance - the run is marked failed),
    ``"error"`` (next-step refused) or ``"stalled"`` (the give-up path above). The caller reports the run's
    real status from the store — this only says why driving ended.

    Children run with their output off the console by default: with several
    steps in flight the only readable console is this loop's own progress
    lines, the full stream is captured per step in `step_log_path(...)`, and
    an exec step's stdout/stderr land beside its artifacts as
    `_exec_stdout.log` / `_exec_stderr.log` regardless. *follow* is the
    opt-in middle ground: each child's log is tailed live to the console,
    line-prefixed with its step key (`_StepTail`).
    """
    env = _child_env(workspace)
    inflight: Dict[str, subprocess.Popen] = {}
    tails: Dict[str, _StepTail] = {}
    # Per-step spawn counters: see _SPAWN_CAP. The database's
    # attempt counter cannot bound what never reaches the database.
    spawns: Dict[str, int] = {}
    attempt_seen: Dict[str, int] = {}
    last_progress = time.monotonic()

    def say(msg: str) -> None:
        if on_event:
            on_event(msg)

    def reap(wait: bool = False) -> None:
        nonlocal last_progress
        for key, p in list(inflight.items()):
            if wait:
                try:
                    p.wait(timeout=60)
                except Exception:  # noqa: BLE001
                    pass
            if p.poll() is None:
                continue
            inflight.pop(key)
            t = tails.pop(key, None)
            if t:
                t.stop()   # drains to EOF first: last words before "finished"
            last_progress = time.monotonic()
            say(f"finished {key} -> {_step_verdict(root_path, run_id, key)}")

    while True:
        reap()
        state = _poll(run_id, uid, root_path, env)
        # A child whose step the engine already finalized may still be
        # exiting: reap again so `finished x` prints before `started y`,
        # and so the LAST step's line is not lost when the poll says done.
        reap()
        if state.get("error"):
            say(f"next-step refused: {state['error']}")
            return "error"
        if state.get("done"):
            reap(wait=True)
            return "done"
        if state.get("blocked") and not inflight and not state.get("steps"):
            # Terminal only when NOTHING can move: nothing in flight here and
            # nothing next-step handed out. Runnable work always outranks a
            # verdict - what finishes may be the retry that unblocks it.
            # The ENGINE decided the run cannot converge (mark_run_failed_if_
            # stuck at finalization) and next-step relays it. The first cut of
            # this driver never looked at run status and polled `waiting` for
            # 300s on a run the engine had failed at 9s. Stop.
            failed = state.get("failed_steps") or []
            say(f"blocked: {failed} failed terminally; the engine has marked "
                "the run failed; nothing can advance")
            return "failed"

        # 3. Dispatch every runnable step that is not already mine. The
        #    in-flight guard is ours to keep: a step spawned a moment ago is
        #    not 'running' in the database until its child claims it, so a
        #    fast re-poll would otherwise hand it back and start it twice.
        for st in state.get("steps") or []:
            key = str(st.get("step_key") or "")
            if not key or key in inflight:
                continue

            # A SPAWN THAT NEVER BECOMES AN ATTEMPT MUST STILL BE BOUNDED.
            # `run-step` records its attempt only AFTER it has made the run
            # directory, so a write failure there - a full disk, a read-only
            # volume, a permissions change - kills the child before any
            # bookkeeping. The step stays runnable at attempt 0, `max_attempts`
            # is never reached and neither is the hard cap, and this loop
            # re-dispatches forever. A validator denied write on `.iof/runs`
            # and measured TEN spawns in TEN minutes, attempt pinned at 0/2,
            # still going - against a documented guarantee that a run always
            # converges to done or a clean `step.hard_cap_reached`.
            #
            # So the DRIVER counts its own spawns per step. The database's
            # attempt counter cannot bound what never reaches the database.
            seen_attempt = int(st.get("attempt") or 0)
            if spawns.get(key, 0) and seen_attempt > attempt_seen.get(key, -1):
                spawns[key] = 0            # real progress: the child got far
                                           # enough to record an attempt
            attempt_seen[key] = max(attempt_seen.get(key, -1), seen_attempt)
            if spawns.get(key, 0) >= _SPAWN_CAP:
                say(f"{key}: {spawns[key]} spawns and the attempt counter "
                    f"never advanced past {seen_attempt} - the step is not "
                    "reaching the point where it records an attempt. The "
                    "child said why here: "
                    f"{_step_log(root_path, run_id, key)} - read that first. "
                    f"Check that {root_path} is writable and has free space; "
                    "a step another driver already claimed looks identical "
                    "from out here, and only the log tells the two apart.")
                _gave_up(root_path, run_id, state,
                         reason=f"{key} spawned {spawns[key]} times without "
                                "recording an attempt")
                return "failed"

            try:
                inflight[key] = _start_step(run_id, key, uid, root_path, env)
            except OSError as e:
                say(f"could not start {key}: {e}")
                spawns[key] = spawns.get(key, 0) + 1
                continue
            if follow:
                # After the spawn: start_step truncates the log per spawn,
                # so tailing from position 0 of the fresh file is exactly
                # this attempt's stream and nothing stale.
                tails[key] = _StepTail(key, _step_log(root_path, run_id, key))
            spawns[key] = spawns.get(key, 0) + 1
            # PROGRESS IS AN ATTEMPT, NOT A SPAWN. Resetting the stall clock
            # on a bare spawn is why the loop above also outran STALL_S: it
            # kept "making progress" by starting a process that died at once.
            if seen_attempt > 0:
                last_progress = time.monotonic()
            say(f"started {key} ({st.get('role') or '?'})")

        # 4. Wait, or conclude the DAG is stuck.
        if inflight:
            _wait_any(inflight, POLL_S)
            continue
        if time.monotonic() - last_progress > STALL_S:
            _gave_up(root_path, run_id, state)
            return "stalled"
        time.sleep(POLL_S)


def _clear_heartbeat(root_path: Path, run_id: str) -> None:
    try:
        from ioagentfarm.engine.db import make_adapter
        from ioagentfarm.engine.store import Store
        url = os.getenv("IOF_DATABASE_URL", "") or f"sqlite:///{Path(root_path) / 'state.db'}"
        Store(make_adapter(url)).clear_driver_heartbeat(run_id)
    except Exception:  # noqa: BLE001
        pass


def drive(*, root_path: Path, run_id: str, uid: str,
          workspace: Optional[str] = None,
          follow: bool = False,
          on_event: Optional[Callable[[str], None]] = None) -> str:
    """`_drive_loop`, and the heartbeat cleared when it returns - whatever
    the reason. The row must not claim a driver that has exited."""
    try:
        return _drive_loop(root_path=root_path, run_id=run_id, uid=uid,
                           workspace=workspace, follow=follow,
                           on_event=on_event)
    finally:
        _clear_heartbeat(root_path, run_id)
