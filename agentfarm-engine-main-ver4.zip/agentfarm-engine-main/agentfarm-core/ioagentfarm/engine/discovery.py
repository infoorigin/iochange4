"""What this environment HOLDS, answered at a terminal: skills and agent scope.

Three registry questions had no CLI answer (docs/capabilities/evidence/
A-harness-router-registries.md, sections 3, 5 and 6): which skills the
installed packs ship, which of them one agent actually LOADS, and what
scope an agent DECLARES to a router. Each had an answer somewhere - a
served catalog endpoint, a per-role context report, an agent card served
over HTTP - and none of them was reachable from a shell with no server up.

THE RULE HERE IS THE SAME AS `context_provenance`'s: ASK THE CONSUMER.
The skill catalog is `catalog_sync.pack_skill_sources()` - the walk the
``pack_skills`` mirror is built from - not a second walk of the packs. The
per-role verdict is the runtime's own `SkillsLoader`, via `build_report`.
The agent scope is `web.a2a.build_agent_card`, the function behind
``GET /a2a/<role>/.well-known/agent-card.json``, so the CLI cannot print a
scope the served card disagrees with. This module owns presentation-shaped
rows and nothing about meaning.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

#: Carrier labels. ``shared`` is a `Pack.skills` root (the shared-skills
#: wheel, or a pack's top-level skills); ``agent:<role>`` is a skill that
#: lives in one agent's workspace; ``inject:<x>`` is an ``inject.yaml``
#: content directory (``agents/_<x>/skills``).
SHARED = "shared"
NOT_CARRIED = "not-carried"


def ascii_only(text: Any) -> str:
    """Console text must survive a legacy code page (CLAUDE.md): a skill
    description or a tool's docstring is data we do not author, and one
    em-dash in it is a `UnicodeEncodeError` in the renderer after the work
    is done. Non-ASCII becomes `?`; nothing is dropped silently."""
    return str(text or "").encode("ascii", errors="replace").decode("ascii")


def _as_path(traversable: Any) -> Path | None:
    """A `Path` for a pack root, or None when it is not filesystem-shaped.

    `importlib.resources.files()` returns a real `Path` for a regular
    package - which every package-dir-mapped directory is required to be
    (CLAUDE.md, 2026-08-30). A `MultiplexedPath` is the namespace-package
    case and has no parent to classify by; it is tolerated, never fatal.
    """
    try:
        return Path(traversable)
    except TypeError:
        return None


def _shared_roots() -> set[str]:
    try:
        from ioagentfarm.packs import load_registry
        packs = load_registry().packs
    except Exception:  # noqa: BLE001 - the catalog is already empty then
        return set()
    out: set[str] = set()
    for pack in packs:
        if pack.skills is None:
            continue
        path = _as_path(pack.skills)
        if path is not None:
            out.add(str(path))
    return out


def carrier_of(skill_dir: Path | None, shared_roots: set[str]) -> str:
    """Which shape of `pack_skill_sources` this skill directory came from."""
    if skill_dir is None:
        return SHARED
    if str(skill_dir.parent) in shared_roots:
        return SHARED
    parts = skill_dir.parts
    # <pack>/agents/<role>/workspace/skills/<name>
    if (len(parts) >= 5 and parts[-2] == "skills" and parts[-3] == "workspace"
            and parts[-5] == "agents"):
        return f"agent:{parts[-4]}"
    # <pack>/agents/_<x>/skills/<name>  (inject.yaml dirs, legacy _common)
    if (len(parts) >= 4 and parts[-2] == "skills" and parts[-3].startswith("_")
            and parts[-4] == "agents"):
        return f"inject:{parts[-3].lstrip('_')}"
    return SHARED


def _read_skill(skill_dir: Path | None) -> tuple[dict, str]:
    """(frontmatter mapping or {}, whole text) - through the linter's parser.

    `content_lint._frontmatter` is the parser `lint-skill` reads a SKILL.md
    with; using it here means this listing and the linter agree about what
    a skill declares. An unparseable block reads as {} - the loader's own
    verdict on that case (`FRONTMATTER_UNPARSEABLE`) is what `--role` shows.
    """
    from ioagentfarm.engine.content_lint import _frontmatter
    if skill_dir is None:
        return {}, ""
    try:
        text = (skill_dir / "SKILL.md").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {}, ""
    data, _raw, _ = _frontmatter(text)
    return (data if isinstance(data, dict) else {}), text


def _declares_always(data: dict) -> bool | None:
    """The `always:` flag, top-level or under the runtime's nested metadata
    block; None when the file does not say."""
    if "always" in data:
        return bool(data.get("always"))
    meta = data.get("metadata")
    if isinstance(meta, dict):
        for key in ("iobot", "openclaw", "iobot"):
            block = meta.get(key)
            if isinstance(block, dict) and "always" in block:
                return bool(block.get("always"))
    return None


def _description(data: dict, text: str) -> str:
    desc = data.get("description")
    if isinstance(desc, str) and desc.strip():
        return " ".join(desc.split())
    body = text
    if text.startswith("---"):
        parts = text.split("---", 2)
        body = parts[2] if len(parts) == 3 else ""
    for line in body.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            return " ".join(line.split())
    return ""


def skill_rows() -> list[dict[str, Any]]:
    """Every skill the installed packs ship, one row each, sorted by name.

    Row: ``name, pack, carrier, always (bool|None), description, path``.
    Source of truth is `pack_skill_sources()` - first pack wins in registry
    order, the same precedence the engine resolves a skill by.
    """
    from ioagentfarm.engine.catalog_sync import pack_skill_sources
    sources = pack_skill_sources()
    shared_roots = _shared_roots()
    rows: list[dict[str, Any]] = []
    for name in sorted(sources):
        skill_dir, pack = sources[name]
        path = _as_path(skill_dir)
        data, text = _read_skill(path)
        rows.append({
            "name": name,
            "pack": pack,
            "carrier": carrier_of(path, shared_roots),
            "always": _declares_always(data),
            "description": _description(data, text),
            "path": str(path if path is not None else skill_dir),
        })
    return rows


def skill_rows_for_role(role: str) -> dict[str, Any]:
    """The catalog, with the runtime loader's verdict on each skill for *role*.

    Goes through `context_provenance.build_report`, which asks the runtime's
    own `SkillsLoader` - so ``loaded`` is `injected` (full text in the
    system prompt), `listed` (name and description only; loaded on demand)
    or `dropped`, with the loader's ``reason``. A pack skill the agent's
    workspace does not hold is ``dropped`` / ``not-carried``. Skills the
    workspace holds that no pack ships (learned, tenant-authored, the
    runtime's builtins) are appended with ``pack: "-"``.

    Raises whatever resolving the agent home raises (`WorkspaceNotSelected`
    when no workspace is selected and ``IOF_AGENT_HOME`` is unset) - the
    caller decides how to say it. ``materialized`` is False when the home
    does not exist yet, in which case every row is a guess and the caller
    should say so rather than print it.
    """
    from ioagentfarm.engine import context_provenance as cp
    report = cp.build_report(role)
    verdict: dict[str, Any] = {}
    for f in report.files:
        if f.kind == "skill" and f.name not in verdict:
            verdict[f.name] = f       # the loader's entry precedes a shadowed one
    catalog = {r["name"]: r for r in skill_rows()}

    rows: list[dict[str, Any]] = []
    for name, row in catalog.items():
        f = verdict.get(name)
        if f is None:
            rows.append(dict(row, loaded=cp.DROPPED, reason=NOT_CARRIED,
                             detail=f"not in {role}'s workspace"))
        else:
            rows.append(dict(row, loaded=f.mode, reason=f.reason, detail=f.detail))
    for name, f in verdict.items():
        if name in catalog:
            continue
        path = Path(f.path)
        data, text = _read_skill(path.parent if path.is_file() else path)
        rows.append({
            "name": name, "pack": "-", "carrier": f.source,
            "always": _declares_always(data),
            "description": _description(data, text), "path": f.path,
            "loaded": f.mode, "reason": f.reason, "detail": f.detail,
        })
    rows.sort(key=lambda r: r["name"])
    return {
        "role": role,
        "workspace": report.workspace,
        "materialized": Path(report.workspace).is_dir(),
        "skills": rows,
    }


def agent_scope(role: str, workspace_code: str) -> dict[str, Any]:
    """The scope a router would match *role* on: what its Agent Card says.

    Composed by `web.a2a.build_agent_card` - the SAME function that serves
    ``/a2a/<role>/.well-known/agent-card.json`` - so the listing cannot
    disagree with the card. ``exposed`` follows `exposed_roles`' rule: the
    card's ``expose: true`` (`card_exposes`) or membership of
    ``IOF_ALWAYS_ON_AGENTS`` (`resolved_always_on`), and a desk-side role is
    never exposed whatever it declares.
    """
    out: dict[str, Any] = {"description": "", "skills": [], "tags": [],
                           "skill_names": [], "examples": [],
                           "exposed": False, "exposure": ""}
    try:
        from ioagentfarm.web.a2a import build_agent_card
        card = build_agent_card(role, "")
        out["description"] = card.description or ""
        out["skills"] = [s.id for s in card.skills]
        tags: list[str] = []
        for s in card.skills:
            for t in (s.tags or []):
                if t not in tags:
                    tags.append(t)
        out["tags"] = tags
        # The router (`engine/router.py`) scores on these two as well; they
        # ride the SAME card read so it cannot see a scope this listing
        # does not. Skill names are the human label beside the id;
        # examples are the card's own sample requests, when it carries any.
        out["skill_names"] = [s.name for s in card.skills if s.name and s.name != s.id]
        examples: list[str] = []
        for s in card.skills:
            for e in (s.examples or []):
                if isinstance(e, str) and e.strip() and e not in examples:
                    examples.append(e.strip())
        out["examples"] = examples
    except Exception as exc:  # noqa: BLE001 - a listing, never a traceback
        out["error"] = f"{type(exc).__name__}: {str(exc)[:120]}"

    try:
        from ioagentfarm.engine.always_on import is_desk_side
        if is_desk_side(role):
            out["exposure"] = "desk-side"
            return out
    except Exception:  # noqa: BLE001
        pass
    by_card = False
    try:
        from ioagentfarm.web.a2a import card_exposes
        by_card = bool(card_exposes(role, workspace_code))
    except Exception:  # noqa: BLE001
        by_card = False
    always_on = False
    try:
        from ioagentfarm.engine.always_on import resolved_always_on
        always_on = role in resolved_always_on()
    except Exception:  # noqa: BLE001
        always_on = False
    out["exposed"] = by_card or always_on
    out["exposure"] = "+".join(
        label for label, on in (("card", by_card), ("always-on", always_on)) if on)
    return out
