from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict

class Runner(ABC):
    @abstractmethod
    def run_step(
        self,
        *,
        run_id: str,
        step_key: str,
        role: str,
        role_prompt: str,
        step_prompt: str,
        goal: str,
        workspace: Path,
        context: Dict[str, Any],
    ) -> str:
        ...
