from __future__ import annotations
import logging
import os
import shutil
from typing import List
import yaml
from importlib import resources
from pathlib import Path

from ioagentfarm.engine.models import Workflow, Role, Step, StepTemplate, SandboxWorkflowConfig, OnFail
from ioagentfarm.packs import load_registry

logger = logging.getLogger(__name__)


def _on_fail_kwargs(d: dict) -> dict:
    """`reset: draft` is what a person writes first; the model wants a list."""
    d = dict(d or {})
    r = d.get("reset")
    if isinstance(r, str):
        d["reset"] = [r]
    return d


def collect_workflow_errors(workflow: Workflow) -> List[str]:
    """The graph rules, as a list of messages instead of an exception.

    Checks:
    - All step deps reference existing step keys
    - Dependency graph is a DAG (no cycles)
    - All step roles exist in the workflow's role list

    ``validate_workflow`` raises on the result; ``engine.workflow_lint`` reports
    it alongside its own findings. Both call THIS — the graph rules exist once,
    so the linter can never disagree with the loader about what will run.
    """
    step_keys = {s.key for s in workflow.steps}
    role_names = set(workflow.roles.keys())
    errors: List[str] = []

    # Duplicate step keys, reported as themselves.
    #
    # Without this the cycle check below misreports them: it compares a
    # key-indexed visited count against len(workflow.steps), so two steps
    # sharing a key make visited < len and the workflow fails with
    # "Circular dependency detected involving steps: []" — an empty cycle,
    # which is the least useful sentence available for "you named two steps
    # the same thing".
    seen: set[str] = set()
    for step in workflow.steps:
        if step.key in seen:
            errors.append(
                f"Duplicate step key '{step.key}': two steps share this key, so "
                f"only one can ever be addressed and any deps naming it are "
                f"ambiguous. Give each step a distinct key."
            )
        seen.add(step.key)

    # Check step roles exist in workflow roles.
    # exec steps run a command with no agent — their role is attribution-only
    # (defaults to "system") and need not name a defined agent role.
    for step in workflow.steps:
        if step.runs_command:
            continue
        if step.role not in role_names:
            errors.append(
                f"Step '{step.key}' references role '{step.role}' which is not defined in workflow roles: {sorted(role_names)}"
            )

    # Check deps reference valid step keys
    for step in workflow.steps:
        for dep in (step.deps or []):
            if dep not in step_keys:
                errors.append(
                    f"Step '{step.key}' depends on '{dep}' which does not exist. Available steps: {sorted(step_keys)}"
                )
    # A route target or an on_fail reset target that is not a step LOADED
    # and RAN (lint refused it; the loader did not): the route chose among
    # names that did not exist and the step the author meant ran
    # unconditionally, green (novice finding).
    for step in workflow.steps:
        for r in (getattr(step, "routes", None) or []):
            if r not in step_keys:
                errors.append(
                    f"Step '{step.key}' routes to '{r}' which does not exist. Available steps: {sorted(step_keys)}"
                )
        _of = getattr(step, "on_fail", None)
        for t in (getattr(_of, "reset", None) or []):
            if t not in step_keys:
                errors.append(
                    f"Step '{step.key}' on_fail resets '{t}' which does not exist. Available steps: {sorted(step_keys)}"
                )

    # Cycle detection via topological sort (Kahn's algorithm)
    in_degree = {s.key: 0 for s in workflow.steps}
    adj = {s.key: [] for s in workflow.steps}
    for step in workflow.steps:
        for dep in (step.deps or []):
            if dep in adj:  # skip invalid deps (already reported above)
                adj[dep].append(step.key)
                in_degree[step.key] += 1

    queue = [k for k, d in in_degree.items() if d == 0]
    visited = 0
    while queue:
        node = queue.pop(0)
        visited += 1
        for neighbor in adj[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    # Compare against the number of DISTINCT keys — in_degree/adj are keyed by
    # step key, so duplicates (reported above) would otherwise show up here as
    # a phantom cycle with an empty key list.
    if visited < len(in_degree):
        cycle_keys = [k for k, d in in_degree.items() if d > 0]
        errors.append(
            f"Circular dependency detected involving steps: {cycle_keys}. "
            f"The dependency graph must be a DAG (no cycles)."
        )

    return errors


def validate_workflow(workflow: Workflow) -> None:
    """Validate a loaded workflow for structural correctness.

    Raises ValueError with a descriptive message on failure. See
    ``collect_workflow_errors`` for the checks.
    """
    errors = collect_workflow_errors(workflow)
    if errors:
        msg = f"Workflow '{workflow.name}' validation failed:\n" + "\n".join(f"  - {e}" for e in errors)
        raise ValueError(msg)

def _iof_root() -> Path:
    # Default: .iof in current working directory (same as CLI default)
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve()

class WorkflowLoader:
    def __init__(self):
        self._pkg = "ioagentfarm.workflows"

    @staticmethod
    def _files_win() -> bool:
        """RETIRED - the pack always wins now; kept for callers that still ask.

        Under the One Truth model (docs/one-truth-content-model.md) the
        installed pack is the only source a workflow is resolved from, in
        every mode. The staged copy under ``<IOF_ROOT>/workspaces/<code>/
        workflows/`` no longer outranks it - it may only ADD a workflow that
        no pack provides (a Studio-authored one, until drafts replace that
        path), and such a load is stamped and logged as unpromoted.

        History, because the failure recurs if the tier comes back: a pushed
        or synced workspace materialised workflows to that tree, the tree
        took precedence unconditionally, and editing the source changed
        nothing until the next push. `run` executed a stale pipeline and
        `lint-workflow --workspace <code>` linted the staged copy - measured
        again on 2026-08-14/15: fourteen prompt refinements, five runs, none
        executed. ``IOF_LOCAL`` used to flip this; it is now accepted and
        ignored.
        """
        return True

    def _installed_dir(self, workspace: str | None = None) -> Path:
        """The installed-override root for *workspace*.

        Tenant workflows materialize under ``<IOF_ROOT>/workspaces/<code>/
        workflows`` — written by ``workspace_sync._materialize_workflow``,
        ``hydration.workflow_override_dir`` and the studio's ``_override_dir``.
        Until this read side existed, nothing loaded them: scoped-workspace
        saves had to defer engine validation (``"validated": False``).

        *workspace* is passed EXPLICITLY by concurrent callers (the web server
        serves many tenants from one process, so env would be wrong); it falls
        back to ``IOF_WORKSPACE`` for CLI and subprocess callers, which is how
        a spawned ``run-step`` inherits its tenant.
        """
        from ioagentfarm.engine.hydration import workflow_override_dir

        # Reuse hydration's resolver so the read and write sides can never
        # drift; it returns the per-code dir for non-default workspaces and
        # the flat <IOF_ROOT>/workflows for 'default'. Parent of the
        # <name> component is the root we want.
        return workflow_override_dir("_", workspace_code=workspace).parent

    def _workflow_dir(self, name: str):
        """First pack source (in registry order) that contains ``<name>/workflow.yaml``.

        Returns a Traversable dir or ``None``. Replaces the old single-package
        ``resources.files(self._pkg) / name`` lookup so pack-contributed
        workflows resolve the same way bundled ones do.
        """
        for base in load_registry().workflow_sources():
            cand = base / name
            try:
                if cand.is_dir() and (cand / "workflow.yaml").is_file():
                    return cand
            except (FileNotFoundError, TypeError, NotADirectoryError):
                continue
        return None

    def list_workflows(self, workspace: str | None = None):
        names = set()

        # bundled + pack-contributed sources
        for base in load_registry().workflow_sources():
            try:
                for p in base.iterdir():
                    if p.is_dir():
                        names.add(p.name)
            except (FileNotFoundError, TypeError, NotADirectoryError):
                logger.debug("failed to scan workflow source %r", base, exc_info=True)

        # ADD-ONLY overrides: a staged workflow that no pack provides (a
        # Studio-authored one) is still listed; one that a pack provides is
        # the pack's, and the staged copy is ignored - see _files_win.
        for inst in self._override_roots(workspace):
            if inst.exists():
                for p in inst.iterdir():
                    if p.is_dir() and (p / "workflow.yaml").exists():
                        names.add(p.name)

        return sorted(names)

    def _override_roots(self, workspace: str | None) -> list[Path]:
        """Staged-copy roots, tenant tree first then the platform tier.
        Consulted ONLY for names no pack provides."""
        from ioagentfarm.engine.workspaces import PLATFORM_TIER
        # FAIL-CLOSED on purpose: with no workspace named and none selected,
        # `_installed_dir` raises WorkspaceNotSelected - a listing must never
        # come from a silently chosen tree (the explicit-workspace contract,
        # pinned by the API suite's test_workspace_isolation). A caller that
        # wants only what the packs and the platform tier hold names
        # PLATFORM_TIER. (A 2026-08-27 change made this fall back to the
        # platform tier and broke that pin; reverted the same day.)
        roots = [self._installed_dir(workspace)]
        if workspace and workspace != PLATFORM_TIER:
            roots.append(self._installed_dir(PLATFORM_TIER))
        return roots

    def _unpromoted_dir(self, name: str, workspace: str | None) -> Path | None:
        """The staged copy of *name* when NO pack provides it - the
        transitional home of Studio-authored workflows until drafts land.
        Returns None when a pack provides the name (the pack wins) or no
        staged copy exists. Hydration from the database happens here and
        only here, so a pack workflow never triggers a DB read."""
        if self._workflow_dir(name) is not None:
            return None
        try:
            from ioagentfarm.engine.hydration import hydrate_workflow
            hydrate_workflow(name, workspace_code=workspace)
        except Exception:
            logger.debug("workflow hydration skipped for %r", name, exc_info=True)
        for inst in self._override_roots(workspace):
            cand = inst / name
            if cand.is_dir() and (cand / "workflow.yaml").exists():
                logger.warning(
                    "workflow %r is UNPROMOTED content (no installed pack provides "
                    "it; loaded from %s) - promote it into a pack to make it real",
                    name, cand)
                return cand
        return None

    def load_from_dir(self, base: Path) -> Workflow:
        """Parse + validate the workflow rooted at *base* (a real directory).

        Public since drafts: a draft run materialises "pack (+) overlay"
        into a temp dir and loads THAT, so the merged bytes are validated
        exactly as a pack directory would be.
        """
        data = yaml.safe_load((base / "workflow.yaml").read_text(encoding="utf-8"))

        roles = {}
        for r in data.get("roles", []):
            role_name = r["name"]
            prompt_path = base / r["prompt"]
            roles[role_name] = Role(
                name=role_name,
                prompt=prompt_path.read_text(encoding="utf-8"),
                allowed_tools=r.get("allowed_tools", []) or [],
                skills=r.get("skills"),
                model=r.get("model"),
            )

        steps = []
        for s in data.get("steps", []):
            # exec steps run a command instead of an agent — prompt is optional
            if s.get("type") in ("exec", "route") and not (s.get("command") or "").strip():
                raise ValueError(f"exec step '{s.get('key')}' requires a non-empty 'command'")
            prompt_path = (base / s["prompt"]) if s.get("prompt") else None

            per_item_steps = []
            for t in (s.get("per_item_steps") or []):
                for _k in ("key_suffix", "role", "prompt"):
                    if not t.get(_k):
                        raise ValueError(
                            f"per_item_steps entry {t.get('key_suffix') or '?'!r} of step "
                            f"{s.get('key')!r} needs `{_k}:`")
                tp = base / t["prompt"]
                per_item_steps.append(
                    StepTemplate(
                        key_suffix=t["key_suffix"],
                        title=t.get("title", ""),
                        role=t["role"],
                        prompt=tp.read_text(encoding="utf-8"),
                        max_attempts=int(t.get("max_attempts", 2)),
                        deps=t.get("deps", []) or [],
                        mcp_tools=t.get("mcp_tools"),
                    )
                )

            steps.append(
                Step(
                    key=s["key"],
                    title=s.get("title", ""),
                    role=s.get("role") or ("system" if s.get("type") in ("exec", "route") else s["role"]),
                    type=s.get("type", "normal"),
                    deps=s.get("deps", []) or [],
                    max_attempts=int(s.get("max_attempts", 2)),
                    prompt=prompt_path.read_text(encoding="utf-8") if prompt_path else "",
                    command=s.get("command", "") or "",
                    stories_from=s.get("stories_from", "") or "",
                    timeout=s.get("timeout"),
                    fresh_session=bool(s.get("fresh_session", True)),
                    loop_source_key=s.get("loop_source_key"),
                    per_item_steps=per_item_steps,
                    requires_artifacts=s.get("requires_artifacts", []) or [],
                    mcp_tools=s.get("mcp_tools"),
                    routes=[str(r) for r in (s.get("routes") or [])],
                    on_fail=(OnFail(**_on_fail_kwargs(s["on_fail"]))
                             if isinstance(s.get("on_fail"), dict) else None),
                )
            )

        # Read team.md if it exists
        team_path = base / "team.md"
        team = team_path.read_text(encoding="utf-8") if team_path.exists() else ""

        # Parse team roster from YAML (structured list of roles)
        from ioagentfarm.engine.models import TeamMember
        team_roster = [TeamMember(role=t["role"]) for t in data.get("team", [])]

        # Parse sandbox config from YAML (optional)
        sandbox_data = data.get("sandbox")
        sandbox_config = SandboxWorkflowConfig(**sandbox_data) if sandbox_data else None

        # Parse workflow-level vars (per-workflow template variables)
        wf_vars = data.get("vars") or {}

        wf = Workflow(
            name=data["name"],
            description=data.get("description", ""),
            roles=roles,
            steps=steps,
            protocol=data.get("protocol", {}) or {},
            team=team,
            team_roster=team_roster,
            sandbox=sandbox_config,
            vars=wf_vars,
            # Read in BOTH loader blocks - a key added to one only is
            # the classic silent divergence here.
            depends_on_runs=[str(x) for x in (data.get("depends_on_runs") or [])],
            single_active_run=bool(data.get("single_active_run") or False),
            coverage=list(data.get("coverage") or []),
        )
        validate_workflow(wf)
        return wf

    # Kept as an alias so pre-rename callers (and any monkey-patch aimed at
    # the private name) keep working; new code uses the public name.
    _load_from_dir = load_from_dir

    def _copy_traversable(self, src, dest: Path) -> None:
        """Recursively copy a Traversable (importlib.resources) tree to a real Path."""
        dest.mkdir(parents=True, exist_ok=True)
        for item in src.iterdir():
            target = dest / item.name
            if item.is_file():
                target.write_bytes(item.read_bytes())
            elif item.is_dir():
                self._copy_traversable(item, target)

    def snapshot_workflow(self, name: str, run_id: str, root: Path | None = None,
                          workspace: str | None = None,
                          overlay: dict | None = None) -> Path:
        """Copy the workflow directory into the run's instance dir.

        Creates ``.iof/instances/<run_id>/workflow/`` containing the full
        workflow directory (workflow.yaml, roles/, steps/, metadata/, etc.).
        This frozen snapshot is used for all subsequent step execution within
        the run, ensuring workflow changes don't affect in-flight runs.

        The snapshot lives under ``instances/`` so it is automatically
        included in S3 sync (horizontal scaling / crash recovery).

        *overlay* (a draft's ``{rel: text | null}`` map) is applied ON TOP of
        the pack copy - the pack tree is still copied first so the pack's
        binary assets (a metadata catalog's data files) survive, and a
        ``null`` entry deletes its file, which a merged-files map could not
        express. With no pack dir the overlay alone IS the snapshot (a
        new-item workflow draft).

        Returns the path to the snapshot directory.
        """
        root = root or _iof_root()
        snapshot_dir = root / "instances" / run_id / "workflow"
        if snapshot_dir.exists():
            logger.debug("Workflow snapshot already exists: %s", snapshot_dir)
            return snapshot_dir

        # THE PACK IS THE TRUTH: a run snapshots the installed pack's copy of
        # the workflow - the same bytes load() and lint resolve - so what was
        # validated is what runs, and what runs is what is installed here.
        base = self._workflow_dir(name)
        if base is not None:
            self._copy_traversable(base, snapshot_dir)
            if overlay:
                from ioagentfarm.engine.draft_files import apply_overlay
                apply_overlay(snapshot_dir, overlay)
                logger.info("Workflow '%s' snapshot (pack + draft overlay) -> %s",
                            name, snapshot_dir)
                return snapshot_dir
            logger.info("Workflow '%s' snapshot (pack) -> %s", name, snapshot_dir)
            return snapshot_dir

        if overlay:
            # A new-item workflow draft: no pack dir exists, the draft is the
            # whole supply. load_from_dir already validated these same bytes
            # from the temp materialisation at run creation.
            from ioagentfarm.engine.draft_files import apply_overlay
            snapshot_dir.mkdir(parents=True, exist_ok=True)
            apply_overlay(snapshot_dir, overlay)
            logger.info("Workflow '%s' snapshot (draft, new item) -> %s",
                        name, snapshot_dir)
            return snapshot_dir

        # Transitional: an unpromoted (Studio-authored) workflow no pack has.
        inst = self._unpromoted_dir(name, workspace)
        if inst is not None:
            shutil.copytree(inst, snapshot_dir)
            logger.info("Workflow '%s' snapshot (UNPROMOTED) -> %s", name, snapshot_dir)
            return snapshot_dir
        raise FileNotFoundError(f"Workflow '{name}' not found.")

    def load(self, name: str, *, run_id: str | None = None, root: Path | None = None,
             workspace: str | None = None) -> Workflow:
        # If run_id given, prefer the frozen snapshot
        if run_id:
            r = root or _iof_root()
            snapshot = r / "instances" / run_id / "workflow"
            if snapshot.is_dir() and (snapshot / "workflow.yaml").exists():
                return self._load_from_dir(snapshot)

        # THE PACK IS THE TRUTH (docs/one-truth-content-model.md s3.2): the
        # installed pack's copy is what loads, in every mode. A staged copy
        # under the workspace tree is consulted ONLY for a name no pack
        # provides - a Studio-authored workflow, until drafts replace that
        # path - and is logged as unpromoted when it is.
        base = self._workflow_dir(name)
        if base is None:
            inst = self._unpromoted_dir(name, workspace)
            if inst is not None:
                return self._load_from_dir(inst)
            raise FileNotFoundError(f"Workflow '{name}' not found.")
        # base is a Traversable; read files through it directly.
        data = yaml.safe_load((base / "workflow.yaml").read_text(encoding="utf-8"))

        roles = {}
        for r in data.get("roles", []):
            role_name = r["name"]
            prompt_path = base / r["prompt"]
            roles[role_name] = Role(
                name=role_name,
                prompt=prompt_path.read_text(encoding="utf-8"),
                allowed_tools=r.get("allowed_tools", []) or [],
                skills=r.get("skills"),
                model=r.get("model"),
            )

        steps = []
        for s in data.get("steps", []):
            # exec steps run a command instead of an agent — prompt is optional
            if s.get("type") in ("exec", "route") and not (s.get("command") or "").strip():
                raise ValueError(f"exec step '{s.get('key')}' requires a non-empty 'command'")
            prompt_path = (base / s["prompt"]) if s.get("prompt") else None

            per_item_steps = []
            for t in (s.get("per_item_steps") or []):
                for _k in ("key_suffix", "role", "prompt"):
                    if not t.get(_k):
                        raise ValueError(
                            f"per_item_steps entry {t.get('key_suffix') or '?'!r} of step "
                            f"{s.get('key')!r} needs `{_k}:`")
                tp = base / t["prompt"]
                per_item_steps.append(
                    StepTemplate(
                        key_suffix=t["key_suffix"],
                        title=t.get("title", ""),
                        role=t["role"],
                        prompt=tp.read_text(encoding="utf-8"),
                        max_attempts=int(t.get("max_attempts", 2)),
                        deps=t.get("deps", []) or [],
                        mcp_tools=t.get("mcp_tools"),
                    )
                )

            steps.append(
                Step(
                    key=s["key"],
                    title=s.get("title", ""),
                    role=s.get("role") or ("system" if s.get("type") in ("exec", "route") else s["role"]),
                    type=s.get("type", "normal"),
                    deps=s.get("deps", []) or [],
                    max_attempts=int(s.get("max_attempts", 2)),
                    prompt=prompt_path.read_text(encoding="utf-8") if prompt_path else "",
                    command=s.get("command", "") or "",
                    stories_from=s.get("stories_from", "") or "",
                    timeout=s.get("timeout"),
                    fresh_session=bool(s.get("fresh_session", True)),
                    loop_source_key=s.get("loop_source_key"),
                    per_item_steps=per_item_steps,
                    requires_artifacts=s.get("requires_artifacts", []) or [],
                    mcp_tools=s.get("mcp_tools"),
                    routes=[str(r) for r in (s.get("routes") or [])],
                    on_fail=(OnFail(**_on_fail_kwargs(s["on_fail"]))
                             if isinstance(s.get("on_fail"), dict) else None),
                )
            )

        # Read team.md if it exists (bundled via Traversable)
        try:
            team = (base / "team.md").read_text(encoding="utf-8")
        except (FileNotFoundError, TypeError):
            team = ""

        # Parse team roster from YAML
        from ioagentfarm.engine.models import TeamMember
        team_roster = [TeamMember(role=t["role"]) for t in data.get("team", [])]

        # Parse sandbox config from YAML (optional)
        sandbox_data = data.get("sandbox")
        sandbox_config = SandboxWorkflowConfig(**sandbox_data) if sandbox_data else None

        # Parse workflow-level vars (per-workflow template variables)
        wf_vars = data.get("vars") or {}

        wf = Workflow(
            name=data["name"],
            description=data.get("description", ""),
            roles=roles,
            steps=steps,
            protocol=data.get("protocol", {}) or {},
            team=team,
            team_roster=team_roster,
            sandbox=sandbox_config,
            vars=wf_vars,
            # Read in BOTH loader blocks - a key added to one only is
            # the classic silent divergence here.
            depends_on_runs=[str(x) for x in (data.get("depends_on_runs") or [])],
            single_active_run=bool(data.get("single_active_run") or False),
            coverage=list(data.get("coverage") or []),
        )
        validate_workflow(wf)
        return wf


def resolvable_workflow_names(workspace: str | None = None) -> set[str]:
    """Every workflow name a run could resolve here - the installed packs
    plus the workspace's override tree, enumerated by the loader `run`
    uses. The ONE implementation the play tier (`iof-plays put`) and the
    case tier (a rulebook action that commissions a workflow) check names
    against, so the two cannot disagree about what exists."""
    from ioagentfarm.engine.workspaces import PLATFORM_TIER, WorkspaceNotSelected
    try:
        return set(WorkflowLoader().list_workflows(workspace or None))
    except WorkspaceNotSelected:
        # Nothing selected: the packs plus the unscoped override tree are
        # still what a run here could resolve; refusing to answer would
        # refuse every play on a box with no selection (CI, a fresh clone).
        return set(WorkflowLoader().list_workflows(PLATFORM_TIER))
