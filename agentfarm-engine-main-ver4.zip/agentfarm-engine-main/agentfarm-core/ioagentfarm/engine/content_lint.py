"""Linters for the two content kinds that had none: SKILLS and AGENTS.

`lint-workflow` and `lint-swarm` existed; `lint-skill` and `lint-agent` did
not, and the asymmetry was found the way asymmetries are - the build
assistant invented `aicore lint-skill` by symmetry during a live turn and
the CLI refused it. The inference was sound: both kinds have documented
failure modes that are SILENT, which is the same reason the other two
linters exist.

What is silent about each:

* **A skill's `description`** is what an agent matches a job against. An
  unquoted value containing ``": "`` is parsed by YAML as a MAPPING, so the
  skill loads with no description at all and is never selected - measured
  this session, on-demand skills reach an agent only through that string.
* **Two always-on output contracts** give the model contradictory format
  directives every turn, and which wins is a coin flip. (The opposite - an
  agent carrying none - is no longer a defect: the engine ships
  ``output_protocol`` and resolves it for any agent without its own.)

Both are checked here rather than remembered, on the `requires_artifacts`
principle: the failure is invisible at authoring time and expensive at run
time.
"""
from __future__ import annotations

from pathlib import Path

import yaml

from ioagentfarm.engine.workflow_lint import (ALWAYS_INJECTED_SKILL, ERROR,
                                              WARNING, Finding, LintResult)

#: Frontmatter keys a SKILL.md may carry. `roles:` is accepted but flagged -
#: it gates nothing since skills became open, and a boilerplate `roles: all`
#: in an agent-local skill is how one gets redistributed to every agent.
#: `output_format`/`from_tools` declare a per-request output format (backlog
#: K6; read by `engine/output_formats.declared_formats`) - the K6 live cert
#: caught this linter calling the key "unrecognised - nothing reads it"
#: while the engine's own 400 was teaching callers to write it: an author
#: obeying the linter un-declared the feature.
_SKILL_KEYS = {"name", "description", "always", "roles", "tools",
               "mcp_server", "output_format", "from_tools"}

#: Identity files an agent workspace is expected to carry. AGENTS.md is
#: generated per host and deliberately absent from this list.
_AGENT_FILES = ("SOUL.md", "TOOLS.md")


def _frontmatter(text: str) -> tuple[dict | None, str, int]:
    """(parsed mapping, raw block, first body line). None when unparseable."""
    if not text.startswith("---"):
        return None, "", 0
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None, "", 0
    raw = parts[1]
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError:
        return None, raw, raw.count("\n") + 1
    return (data if isinstance(data, dict) else None), raw, raw.count("\n") + 1


def _raw_value(raw: str, key: str) -> tuple[str, int] | None:
    """The unparsed text of one frontmatter key, plus its 1-based line."""
    for i, line in enumerate(raw.splitlines(), start=2):
        if line.startswith(f"{key}:"):
            return line.split(":", 1)[1].strip(), i
    return None


def lint_skill_dir(base: Path) -> LintResult:
    """Lint one ``<name>/SKILL.md``. *base* is the skill DIRECTORY."""
    base = Path(base)
    f: list[Finding] = []
    md = base / "SKILL.md"
    if not md.is_file():
        f.append(Finding(ERROR, "SKILL.md",
                         f"no SKILL.md in {base} - the runtime discovers "
                         "skills as <dir>/SKILL.md, so this directory is "
                         "not a skill at all",
                         f"create {base.name}/SKILL.md"))
        return LintResult(base, f, base.name)

    text = md.read_text(encoding="utf-8", errors="replace")
    data, raw, _ = _frontmatter(text)
    if data is None:
        # Name the usual cause rather than reporting "does not parse". An
        # unquoted value containing ": " is the documented trap, and it does
        # not degrade gracefully: YAML raises `mapping values are not
        # allowed here` for the WHOLE block, so the skill loads with no name
        # and no description at all.
        culprit = None
        for i, line in enumerate(raw.splitlines(), start=2):
            head, sep, tail = line.partition(":")
            if (sep and ": " in tail and not head.strip().startswith("#")
                    and not tail.strip().startswith(('"', "'"))):
                culprit = (head.strip(), i)
                break
        if culprit:
            key, line_no = culprit
            f.append(Finding(
                ERROR, f"frontmatter.{key}",
                f'unquoted value contains ": " - YAML rejects the whole '
                "frontmatter with `mapping values are not allowed here`, so "
                "the skill loads with NO name and NO description and can "
                "never be matched to a job",
                f"wrap the value of `{key}:` in double quotes", line_no))
        else:
            f.append(Finding(ERROR, "frontmatter",
                             "frontmatter is missing or does not parse as a "
                             "YAML mapping - the skill loads with no name and "
                             "no description",
                             'open with `---`, then `name:` and '
                             '`description:`, then `---`', 1))
        return LintResult(base, f, base.name)

    # description - the string an agent matches a job against
    rv = _raw_value(raw, "description")
    if not data.get("description"):
        f.append(Finding(
            ERROR, "frontmatter.description",
            "no description - this is the ONLY text an agent matches a job "
            "against, so the skill can never be selected on demand",
            'add `description: "When <situation>: <what this covers>"`',
            rv[1] if rv else 1))
    elif rv is not None:
        value, line = rv
        quoted = value.startswith(('"', "'"))
        if not quoted and ": " in value:
            f.append(Finding(
                ERROR, "frontmatter.description",
                'unquoted value contains ": " - YAML parses this as a '
                "MAPPING, so the skill loads with no description and is "
                "never matched to a job",
                "wrap the whole value in double quotes", line))
        elif not quoted:
            f.append(Finding(
                WARNING, "frontmatter.description",
                "description is not quoted - it survives today, but a later "
                'edit that adds ": " turns it into a mapping silently',
                "wrap the value in double quotes", line))
        # The trigger convention applies to ON-DEMAND skills only. An
        # `always: true` skill has its whole text injected every turn, so
        # its description is never matched against a job and phrasing it as
        # a situation would be advice nobody acts on.
        if (data.get("always") is not True
                and not str(data["description"]).strip().lower()
                .startswith("when ")):
            f.append(Finding(
                WARNING, "frontmatter.description",
                "the description is the TRIGGER an agent matches a job "
                "against - phrase it as the situation",
                'start with "When ..."', line))

    if "<<" in raw:
        f.append(Finding(ERROR, "frontmatter",
                         "`<<` is the YAML merge key, not text - it changes "
                         "how the mapping is built",
                         "quote the value, or rewrite without `<<`", 1))

    name = data.get("name")
    nv = _raw_value(raw, "name")
    if not name:
        f.append(Finding(ERROR, "frontmatter.name", "no name",
                         f'add `name: {base.name}`', 1))
    elif str(name) != base.name:
        f.append(Finding(
            WARNING, "frontmatter.name",
            f"name {str(name)!r} does not match the directory "
            f"{base.name!r} - the runtime discovers by DIRECTORY, so the "
            "frontmatter name is what everything else refers to",
            f"rename one so they agree", nv[1] if nv else 1))

    always = data.get("always")
    if always is not None and not isinstance(always, bool):
        av = _raw_value(raw, "always")
        f.append(Finding(
            ERROR, "frontmatter.always",
            f"`always: {always!r}` is not a boolean - anything other than "
            "true/false is truthy or ignored depending on the reader",
            "use `always: true` or remove the key",
            av[1] if av else 1))

    if "roles" in data:
        rvv = _raw_value(raw, "roles")
        f.append(Finding(
            WARNING, "frontmatter.roles",
            "`roles:` no longer gates anything - skills are open, and an "
            "agent's assignment comes from its location or its record",
            "remove the key", rvv[1] if rvv else 1))

    unknown = set(data) - _SKILL_KEYS
    for k in sorted(unknown):
        kv = _raw_value(raw, k)
        f.append(Finding(WARNING, f"frontmatter.{k}",
                         f"unrecognised key {k!r} - nothing reads it",
                         "remove it, or check the spelling",
                         kv[1] if kv else 1))

    # A declared output format (K6) is validated, not just tolerated: the
    # contract is the fenced JSON-Schema block, and a declaration without
    # one silently validates every reply trivially - legal, but almost
    # always a missing fence rather than a choice, so it is SAID here.
    if isinstance(data.get("output_format"), str) and data["output_format"].strip():
        try:
            from ioagentfarm.engine.output_formats import _schema_from_body
            _has_schema = _schema_from_body(text) is not None
        except Exception:                  # noqa: BLE001 - lint must not die
            _has_schema = True             # cannot check -> do not accuse
        if not _has_schema:
            ov = _raw_value(raw, "output_format")
            f.append(Finding(
                WARNING, "frontmatter.output_format",
                f"format {data['output_format']!r} declares no fenced JSON "
                "Schema block - replies in this format will not be "
                "structurally validated",
                "add a ```json fence whose object carries `properties`/"
                "`required` (see engine/output_formats.py)",
                ov[1] if ov else 1))

    body = text.split("---", 2)[2] if text.count("---") >= 2 else ""
    if not body.strip():
        f.append(Finding(ERROR, "body",
                         "the skill has frontmatter and no content - it will "
                         "be advertised and teach nothing",
                         "write the judgement under a `# Title`"))
    return LintResult(base, f, str(name or base.name))


#: Phrases that mark a skill as OWNING the agent's output format. A
#: heuristic, deliberately: the linter cannot know, so where it matches it
#: downgrades to a warning and names the skill rather than asserting.
#: A skill owns the output contract when it says so. The list is phrasing,
#: not semantics, so a false negative here is worse than it looks: the ERROR
#: it produces tells the author to add `output_protocol`, which is precisely
#: the two-always-on-format-skills bug the rule exists to prevent. `cora_query`
#: hit that — its composer opens "Your ENTIRE response is the JSON block
#: below ... if you emit any character outside the fenced block the response
#: is invalid", which is a stricter contract than the one the linter
#: recognised, and it was reported as having none.
_CONTRACT_CUES = ("only output format", "output format is",
                  "nothing outside", "the only thing you emit",
                  "emit exactly", "output contract",
                  "entire response is", "response is invalid")


def defines_output_contract(skill_dir: Path) -> bool:
    """True when an always-on skill appears to dictate the output format.

    PUBLIC because the runtime needs the same answer the linter gives. The
    chat path decides whether to append a composition suffix, and appending
    one to an agent that owns its format is precisely the contradiction
    `lint-agent` exists to warn about — two sources for one rule would drift.
    """
    md = skill_dir / "SKILL.md"
    if skill_dir.name == ALWAYS_INJECTED_SKILL or not md.is_file():
        return False
    text = md.read_text(encoding="utf-8", errors="replace")
    data, _, _ = _frontmatter(text)
    if not isinstance(data, dict) or data.get("always") is not True:
        return False
    body = text.lower()
    return any(cue in body for cue in _CONTRACT_CUES)


def lint_agent_dir(base: Path) -> LintResult:
    """Lint one agent directory (the one CONTAINING ``workspace/``)."""
    base = Path(base)
    f: list[Finding] = []
    ws = base / "workspace"
    if not ws.is_dir():
        f.append(Finding(ERROR, "workspace",
                         f"no workspace/ under {base} - an agent IS its "
                         "workspace directory; nothing will be seeded",
                         f"create {base.name}/workspace/"))
        return LintResult(base, f, base.name)

    for fname in _AGENT_FILES:
        p = ws / fname
        if not p.is_file():
            sev = ERROR if fname == "SOUL.md" else WARNING
            f.append(Finding(sev, fname,
                             f"no {fname} - "
                             + ("the agent has no identity at all"
                                if fname == "SOUL.md"
                                else "the agent is told nothing about its "
                                     "tools"),
                             f"create workspace/{fname}"))
        elif not p.read_text(encoding="utf-8", errors="replace").strip():
            f.append(Finding(WARNING, fname, f"{fname} is empty",
                             f"write the agent's identity into {fname}"
                             if fname == "SOUL.md" else "describe its tools"))

    skills = ws / "skills"
    have = {d.name for d in skills.iterdir() if d.is_dir()} \
        if skills.is_dir() else set()

    # EXACTLY ONE output contract. Zero and two are both real failures, and
    # the second one happened: Quinn carried `output_protocol` alongside
    # `result_composer`, and two always:true skills gave contradictory
    # format directives. So the rule is not "has output_protocol" - an
    # always-on agent may own its format instead, which is why the check
    # looks for the CONTRACT rather than the file.
    owners = [n for n in sorted(have) if defines_output_contract(skills / n)]
    # CARRYING `output_protocol` IS NO LONGER REQUIRED, and this was an ERROR
    # that said it was. The engine mandates the skill for every step
    # (`create_filtered_workspace` adds it to the required set) and now also
    # SHIPS it, in the shared-skills wheel, so `_resolve_skill` supplies it to
    # any agent that does not carry its own. Requiring a copy here is what
    # produced 25 byte-identical copies across this monorepo - and the file
    # they were all copied from carried a named client in its example.
    # An agent may still carry its own; tier 1 wins and nothing changes.
    if ALWAYS_INJECTED_SKILL not in have and owners:
        f.append(Finding(
            WARNING, f"skills/{ALWAYS_INJECTED_SKILL}",
            f"no {ALWAYS_INJECTED_SKILL}, but {', '.join(owners)} appears to "
            "define the output format instead - correct for an always-on "
            "agent with its own envelope, wrong for anything that runs "
            "workflow steps",
            "confirm this agent never runs a step; if it does, add "
            f"{ALWAYS_INJECTED_SKILL}"))
    elif owners:
        f.append(Finding(
            ERROR, f"skills/{ALWAYS_INJECTED_SKILL}",
            f"BOTH {ALWAYS_INJECTED_SKILL} and {', '.join(owners)} define an "
            "output format, and both are always-on - the agent receives "
            "contradictory directives every turn",
            f"keep one: {ALWAYS_INJECTED_SKILL} for a step agent, the "
            "envelope skill for an always-on agent"))

    # Every carried skill is linted here: an agent is only as loadable as
    # the skills it carries, and a broken one is invisible until a job
    # fails to match it.
    for d in sorted(skills.iterdir() if skills.is_dir() else []):
        if not d.is_dir():
            continue
        for sf in lint_skill_dir(d).findings:
            f.append(Finding(sf.severity, f"skills/{d.name}.{sf.where}",
                             sf.message, sf.fix, sf.line))

    card = ws / "a2a-card.yaml"
    if card.is_file():
        try:
            data = yaml.safe_load(card.read_text(encoding="utf-8")) or {}
            if not isinstance(data, dict):
                raise yaml.YAMLError("not a mapping")
            if data.get("expose") is not None \
                    and not isinstance(data["expose"], bool):
                f.append(Finding(ERROR, "a2a-card.yaml.expose",
                                 "`expose` must be true or false - it is what "
                                 "puts the agent in the served pool",
                                 "use `expose: true`"))
        except yaml.YAMLError as exc:
            f.append(Finding(ERROR, "a2a-card.yaml",
                             f"does not parse ({exc}) - the served card falls "
                             "back to a minimal auto-card and the authored "
                             "one is silently unused",
                             "fix the YAML"))
    return LintResult(base, f, base.name)


#: Retained so an existing import keeps resolving.
_defines_output_contract = defines_output_contract
