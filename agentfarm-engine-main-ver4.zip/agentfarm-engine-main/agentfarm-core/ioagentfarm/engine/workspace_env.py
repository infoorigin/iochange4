"""One workspace, one environment file: ``~/.iobot/workspaces/<code>/.env``.

THE RULE:

    real environment  >  the workspace's own .env  >  nothing else

The real environment -- an explicit export, a pod's environment spec, a CI
variable -- always takes precedence, because that is the layer an operator
uses to state an override deliberately.

NO OTHER FILE IS READ. ``~/.env``, ``~/.iobot/.env``, a ``.env`` in the
current directory or any parent, and the container image's ``/app/.env`` were
all loaded at import time, before any command had named the workspace it
applied to. Settings that belong to one tenant were therefore readable by
another according to where the shell happened to be standing.

``~/.env`` was the most damaging of the four. The search for a
working-directory ``.env`` proceeds UPWARD, and on Windows project and
temporary directories are located under the home directory, so that file was
reachable from most paths on the machine. It supplied a production database
URL to commands run in a temporary directory, and this repository's own file
names a production database as well. A test run reached a production catalog
table by exactly that route.

A workspace with an environment file owns its settings. A workspace without
one inherits nothing and resolves to a local SQLite database under its own
state directory, which is the only default that cannot reach another tenant's
data. ``source_of()`` and ``IGNORED`` exist so that the CLI can report which
file supplied a value, and which files were found and not read.

SEPARATE FROM ``cli.py`` ON PURPOSE. That module replaces ``sys.stdout``
with a ``TextIOWrapper`` at import time, so importing it inside a captured
test closes pytest's capture buffer and every test in the file errors in
teardown (see ``tests/test_cli_version.py``, which resorts to subprocesses).
Resolution logic that deserves direct unit tests must live where it can be
imported freely — and it is engine behaviour, not presentation, either way.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger("ioagentfarm")

#: The REAL environment — shell, pod spec, CI job — captured when this module
#: is first imported. ``cli.py`` imports it ABOVE its dotenv block precisely
#: so this snapshot precedes any file load; taken afterwards it would contain
#: everything those files injected, and a workspace's own ``.env`` could no
#: longer override the machine's. That failure was observed once: the
#: workspace file loaded and the repo's production URL still won.
REAL_ENV: frozenset = frozenset(os.environ)

#: Workspaces already applied in this process. Repeated resolution is then
#: free, and a second workspace cannot silently re-point the first mid-run.
_LOADED: dict[str, Path | None] = {}

#: ``key -> the file that supplied it``. Reporting whether the workspace has
#: an environment file of its own does not answer the question a reader is
#: asking, which is why a particular database is in use. ``aicore current``
#: reported "env file: (none)" and then printed a production host: accurate
#: about the workspace's own file, and unhelpful about the value in force.
PROVENANCE: dict[str, str] = {}


#: Files found in a location that is no longer read. Reported by
#: `aicore current` so that a setting's absence is explained rather than
#: silently observed.
IGNORED: list[str] = []


def note_ignored_env(path) -> None:
    """Record that an environment file was found and not loaded.

    Environment files are per workspace. `~/.iobot/workspaces/<workspace>/.env` is the
    only file read; a file in any other location applies to commands that
    have not named the workspace it belongs to, which is how settings from
    one workspace reach another.
    """
    entry = str(path)
    if entry not in IGNORED:
        IGNORED.append(entry)
    logger.debug("environment file %s is not read; settings belong in "
                 "~/.iobot/workspaces/<workspace>/.env", entry)


def record_provenance(path, keys) -> None:
    """Note that *path* supplied *keys* — first writer wins, matching
    ``load_dotenv(override=False)``, so this records who actually decided."""
    for key in keys:
        PROVENANCE.setdefault(str(key), str(path))


def source_of(key: str) -> str:
    """Where *key*'s current value came from, in terms a reader can act on.

    ASCII only: this string is printed to the console, and a non-ASCII
    character raises UnicodeEncodeError on a cp437 or cp1252 terminal.
    """
    if key in REAL_ENV:
        return "the environment (exported before this command ran)"
    return PROVENANCE.get(key, "not set by any file; using the default")


def state_dir_name() -> str:
    return (os.getenv("IOF_STATE_DIR_NAME") or ".iobot").strip() or ".iobot"


def workspace_home(code: str) -> Path:
    """``~/.iobot/workspaces/<code>`` — one workspace's settings.

    UNDER ``workspaces/`` FOR TWO REASONS.

    It reads as a sibling of the engine's own ``<IOF_ROOT>/workspaces/<code>/``,
    which holds that workspace's agent homes. Both are "per workspace" and the
    two used to be spelled differently -- ``~/.iobot/<code>`` against
    ``<IOF_ROOT>/workspaces/<code>`` -- so which root a path belonged to had to
    be remembered rather than read. Two walkthroughs mislabelled one as the
    other, and so did our own diagrams.

    And it removes a collision: ``~/.iobot`` already contains ``agents``,
    ``cron``, ``logs``, ``media``, ``cli-apps`` and ``config.json``. A
    workspace code equal to any of those used to resolve ON TOP of the
    runtime's own directory.

    Settings still live in the HOME tree rather than under ``IOF_ROOT``,
    because they must follow the workspace between directories; agent homes
    are derived and belong with the rest of the state.
    """
    return Path.home() / state_dir_name() / "workspaces" / code


def legacy_workspace_home(code: str) -> Path:
    """Where a workspace's settings used to live, before ``workspaces/``."""
    return Path.home() / state_dir_name() / code


def workspace_env_path(code: str) -> Path:
    """The ONLY ``.env`` that applies to *code*.

    Falls back to the pre-``workspaces/`` location when that is the only one
    present, so an existing installation keeps working untouched. Nothing is
    moved automatically: this file holds credentials, and relocating it
    silently is not a thing to do on someone's behalf. `aicore current`
    reports which of the two supplied the settings.
    """
    current = workspace_home(code) / ".env"
    if current.is_file():
        return current
    legacy = legacy_workspace_home(code) / ".env"
    if legacy.is_file():
        return legacy
    return current


def loaded_env(code: str) -> Path | None:
    """The file applied for *code*, if any — for reporting, not resolution."""
    return _LOADED.get(code)


def reset() -> None:
    """Forget what has been applied (tests, and dynamic re-resolution).

    RE-SNAPSHOTS ``REAL_ENV`` as well as clearing the memo. That snapshot is
    taken at import so it precedes any file load - correct once per process,
    and wrong for a caller that has since rearranged the environment and is
    asking for resolution to happen again. A key left in a stale snapshot
    outranks the workspace's own file forever, silently, which is the exact
    shape of the leak this module exists to close.

    Observed as three order-dependent test failures: whichever test imported
    this module first decided the snapshot, and a later one that had cleared
    ``IOF_DATABASE_URL`` from the environment still could not apply the
    workspace's own value.
    """
    global REAL_ENV
    # MINUS what a workspace file supplied. A bare `frozenset(os.environ)`
    # here captures the values the file just injected, and the next workspace
    # can then never override them - the failure this module's own comment
    # describes, and the first version of this line reproduced it.
    # `PROVENANCE` is the record of which keys came from a file.
    _LOADED.clear()
    REAL_ENV = frozenset(k for k in os.environ if k not in PROVENANCE)
    PROVENANCE.clear()


#: Keys a workspace file must not be able to strip even when it claims the
#: environment: PATH and friends are the operating system's, not a tenant's,
#: and removing them breaks every subprocess an agent runs.
_NEVER_STRIP = frozenset({
    "PATH", "PATHEXT", "SYSTEMROOT", "WINDIR", "COMSPEC", "TEMP", "TMP",
    "HOME", "USERPROFILE", "USERNAME", "USER", "LANG", "LC_ALL", "TERM",
    "SHELL", "PYTHONPATH", "PYTHONIOENCODING", "VIRTUAL_ENV", "SSL_CERT_FILE",
    "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "HOMEDRIVE", "HOMEPATH",
    # The workspace SELECTOR. It can never meaningfully come FROM a
    # workspace file (it is what chose the file - the one variable the file
    # cannot supply), so stripping it is never isolation, always breakage.
    # Found live: `serve --workspace ainf` sets it AFTER import, so it is
    # not in the REAL_ENV snapshot, and the very load it triggered stripped
    # it - the CLI warned "workspace 'ainf' ... was used" and the lifespan
    # then served the STORED selection, a different tenant. A pre-launch
    # `set IOF_WORKSPACE=...` was in the snapshot and survived, which is why
    # every environment except the flag path worked.
    "IOF_WORKSPACE",
    # The DATABASE SCHEMA, for exactly the same reason and found the same
    # way. It selects which schema `runs`/`steps` live in and can never come
    # FROM a workspace file. When it is not in the REAL_ENV snapshot (an
    # entrypoint that writes it into a late-loaded env file, or any path that
    # sets it after this module imported), the strip step dropped it and
    # `engine_schema()` fell back to the default `iof`. On a deployment whose
    # schema is NOT `iof` (e.g. `iof_client`) the next pooled connection then
    # resolved to a schema with no `runs`, so the supervisor sweep threw
    # `relation "runs" does not exist` — after a resurrection, because that
    # is when `spawn_run` triggers a workspace-env load. Found live on three
    # pods sharing one scratch schema (2026-08-27): the sweep connection's
    # search_path was the DEFAULT, not the run's schema. IOF_DATABASE_URL and
    # IOF_ROOT are covered by _LOCALISED (replaced, not stripped); the schema
    # had no such cover and fell through.
    "IOF_DB_SCHEMA",
})


#: What LOCAL MODE takes over. Each is replaced only when its current value
#: came from a FILE — never when the real environment set it, because that is
#: the layer an operator uses to mean it.
_LOCALISED = ("IOF_ROOT", "IOF_DATABASE_URL", "IOF_AGENT_HOME",
              "IOF_HYDRATION")


def localise(root: Path | None = None,
             code: str | None = None) -> dict[str, str]:
    """Point this process's state at the working directory. Returns what moved.

    Local mode covers every location a run touches. An earlier version
    disabled hydration only, which left the database, the state root and the
    agent home wherever an inherited file had placed them, so a run described
    as local still wrote to a shared database and to another user's agent
    tree.

    Values supplied by the REAL environment are not replaced. Local mode with
    an explicit ``IOF_DATABASE_URL`` continues to use that database.

    AND AN EXPLICIT ``IOF_ROOT`` ANCHORS EVERYTHING DERIVED HERE. The cwd
    fallback is for the human in their project directory — the promise
    "everything resolves to the current folder" is made to THEM. A tool an
    AGENT execs runs with cwd = the agent's own workspace, and anchoring on
    that built a fresh empty database at
    ``<agent workspace>/.iof/state.db`` while the per-key guard below kept
    the forwarded ``IOF_ROOT`` — a split brain where `aicore current`
    printed the right root and the wrong database, the active-run pointer
    resolved but its run row did not, and the Core Assistant truthfully
    reported a run "not in this database" that the user's own shell could
    see. Found live on a client VM; every prior theory (config, allowlist,
    runtime version) checked out and this one line was the divergence.
    """
    if root is None and "IOF_ROOT" in REAL_ENV and os.environ.get("IOF_ROOT"):
        root = Path(os.environ["IOF_ROOT"])
    root = Path(root) if root else Path.cwd() / ".iof"
    moved: dict[str, str] = {}
    wanted = {
        "IOF_ROOT": str(root),
        "IOF_DATABASE_URL": f"sqlite:///{(root / 'state.db').as_posix()}",
        "IOF_HYDRATION": "0",
    }
    if code:
        # PER WORKSPACE, matching what `_activate_workspace` derives — because
        # it RESPECTS a pre-set IOF_AGENT_HOME, so setting a flat
        # <root>/agents here would override that and make every workspace in
        # this directory share one agent tree, silently mixing their memory.
        # With NO workspace selected yet (`aicore local on` is step one,
        # before any workspace exists) the variable is OMITTED: activation
        # derives it per-workspace later, and the engine's own resolution now
        # fails closed rather than falling back to a machine-global tree, so
        # leaving it unset cannot land agents anywhere silently.
        wanted["IOF_AGENT_HOME"] = str(root / "workspaces" / code / "agents")
    for key in _LOCALISED:
        if key not in wanted:
            continue          # IOF_AGENT_HOME: no workspace selected yet
        if key in REAL_ENV:
            continue          # an explicit export outranks the mode
        if os.environ.get(key) != wanted[key]:
            os.environ[key] = wanted[key]
            moved[key] = wanted[key]
        else:
            os.environ[key] = wanted[key]
        # THE MODE IS NOW THE SOURCE, so say so. Local mode overwrites what
        # the workspace's own file supplied, and leaving the earlier
        # provenance in place made `aicore current` name that file as the
        # origin of a database it does not contain -- the reported database
        # was right and its stated source was wrong, on the one line the
        # docs tell an operator to trust before writing.
        PROVENANCE[key] = "local mode (aicore local on)"
    return moved


#: What counts as "local mode is ON" / "explicitly OFF" in ``IOF_LOCAL``.
#: The OFF set matters as much as the ON set: ``--no-local`` records ``0``
#: rather than deleting the variable, because deleting it would let the
#: DIRECTORY MARKER re-enable the mode the flag just turned off. An explicit
#: refusal has to be representable, or it is not a refusal.
LOCAL_ON = frozenset({"1", "true", "yes", "on"})
LOCAL_OFF = frozenset({"0", "false", "no", "off"})


def declared_local() -> bool | None:
    """Has local mode been declared for this process? Tri-state.

    ``True`` — the workspace's own ``.env`` (loaded by ``load_workspace_env``)
    or this directory's marker says so.
    ``False`` — somebody said NO explicitly (``--no-local``).
    ``None`` — nothing has said anything; the caller's default stands.

    The tri-state is the point. A two-state answer cannot distinguish "off
    because nobody asked for it" from "off because the operator refused it",
    and only the second must override the directory marker.
    """
    raw = (os.getenv("IOF_LOCAL") or "").strip().lower()
    if raw in LOCAL_ON:
        return True
    if raw in LOCAL_OFF:
        return False
    return True if directory_local() else None


def adopt_if_declared(code: str | None = None,
                      root: Path | None = None) -> bool:
    """Apply local mode AT THE POINT A DATABASE OR STATE ROOT IS RESOLVED.

    THIS IS THE FIX FOR THE LEAK, and the shape matters more than the fix.

    Local mode used to be applied EAGERLY, by whichever command remembered to
    call ``cli.local_mode()``. Five did. Fifty opened a store. So ``aicore
    local on`` was honoured by ``run`` and reported by ``current`` — which
    printed the local SQLite path — while ``status``, ``next-step``,
    ``step-complete``, ``resume``, ``agent-chat``, the forensics commands and
    the rest read whatever ``IOF_DATABASE_URL`` the workspace's own ``.env``
    supplied: on a DB-backed deployment, the SHARED database.

    The operator was told *"every command in this workspace is local now"* and
    then shown another deployment's runs, with their own local runs invisible.
    Measured on a live workspace: `status` returned three runs that existed
    only in PostgreSQL while the local SQLite it had just been told it was
    using held two different ones.

    Writes were never affected — ``run`` does call ``local_mode()``, so
    nothing leaked OUT of local mode into the shared database. The damage was
    to what the operator could SEE, which is worse than it sounds: it is the
    reading on the instrument you check before deciding anything.

    LAZY, at consumption, is what makes it un-forgettable: a command cannot
    open a store without going through the resolver, so there is no order to
    get right and nothing for the fifty-first command to remember. It also
    makes ``--no-local`` work by construction — the flag records its refusal
    before anything consumes, and :func:`declared_local` reports it.

    Idempotent. Returns whether local mode is in force.
    """
    declared = declared_local()
    if declared is not True:
        return False
    localise(root, code or None)
    # Keep the variable in the environment the child processes inherit. A run
    # spawns subprocesses that resolve their own state; a parent that is local
    # and a child that is not is the split-brain this whole module exists to
    # prevent.
    os.environ["IOF_LOCAL"] = "1"
    return True


def _marker_path() -> Path:
    """The directory-level local-mode marker: ``<IOF_ROOT>/local``."""
    root = os.getenv("IOF_ROOT", "").strip() or ".iof"
    return Path(root) / "local"


def set_directory_local(on: bool) -> Path:
    """Turn local mode on or off for THIS DIRECTORY, before any workspace.

    Local mode is the FIRST thing you turn on -- it is what guarantees the
    workspace you create next is created locally rather than in a shared
    database. But it used to be stored only in
    ``~/.iobot/workspaces/<code>/.env``, which meant the very first command
    had to name a workspace that did not exist yet.

    So the switch is recorded here, against the directory, and
    :func:`adopt_directory_local` copies it into a workspace's own settings
    the moment one is created or selected. The directory is the honest scope
    anyway: local mode says "this folder is self-contained", and two checkouts
    of the same workspace code in two folders are independent.
    """
    path = _marker_path()
    if on:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("1\n", encoding="utf-8")
    else:
        try:
            path.unlink()
        except OSError:
            pass
    reset()
    return path


def directory_local() -> bool:
    """Is local mode on for this directory?"""
    try:
        return _marker_path().read_text(encoding="utf-8").strip() != ""
    except OSError:
        return False


def adopt_directory_local(code: str) -> bool:
    """Carry the directory's local mode into *code*'s own settings.

    Called when a workspace is created or selected. Returns whether it wrote.
    Without this the mode would live in one place and the workspace's `.env`
    -- the file `aicore current` reports and the one a pod reads -- would not
    record it.
    """
    if not directory_local() or is_local(code):
        return False
    set_persistent_local(code, True)
    return True


def is_local(code: str) -> bool:
    """Does *code*'s own settings file record local mode?"""
    path = workspace_env_path(code)
    try:
        return any(ln.strip().startswith("IOF_LOCAL=")
                   and ln.split("=", 1)[1].strip() not in ("", "0", "false")
                   for ln in path.read_text(encoding="utf-8-sig").splitlines())
    except OSError:
        return False


def set_persistent_local(code: str, on: bool) -> Path:
    """Turn local mode on or off for *code*, durably.

    Written as ``IOF_LOCAL`` in the workspace's own ``.env`` rather than a
    new state file: that file is already the workspace's settings, already
    loaded on every command, and already reported by ``aicore current``. One
    concept instead of two, and the switch is a line you can read.
    """
    path = workspace_env_path(code)
    path.parent.mkdir(parents=True, exist_ok=True)
    # The COMMENT belongs to the setting, so it is removed with it. Left
    # behind by `local off`, a file whose only content is "# local mode:
    # files win" describes a mode that is no longer on.
    banner = "# local mode: files win, state stays in this directory"
    lines = []
    if path.is_file():
        lines = [ln for ln in path.read_text(encoding="utf-8").splitlines()
                 if not ln.strip().startswith("IOF_LOCAL=")
                 and ln.strip() != banner]
    if on:
        lines.append(banner)
        lines.append("IOF_LOCAL=1")
    path.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
    reset()
    return path


def load_workspace_env(code: str) -> Path | None:
    """Apply the workspace's own ``.env``. Returns the file, or ``None``.

    This is the only environment file the CLI reads. A workspace with a file
    of its own owns its settings: values that any other file supplied are
    removed unless this workspace declares them. The stripping step remains
    even though no other file is loaded at import time, because a process may
    be re-pointed at a second workspace, and because a caller embedding this
    module can populate the environment by other means.

    Two categories are never removed: the REAL environment, which an operator
    or a pod specification set deliberately, and the operating system's own
    variables such as ``PATH``, whose removal breaks every subprocess an agent
    runs.

    Idempotent per code. A malformed file is reported and ignored: a bad
    settings file must make ITSELF unusable, not the whole CLI.
    """
    if code in _LOADED:
        return _LOADED[code]
    path = workspace_env_path(code)
    applied: Path | None = None
    try:
        if path.is_file():
            from dotenv import dotenv_values
            # utf-8-SIG: PowerShell's Set-Content, Out-File and `>` all
            # write a byte-order mark, so a Windows reader creating this
            # file the obvious way silently lost its FIRST setting -- and
            # `aicore current` then printed the file on one line and "not
            # set by any file" on the next, which is the exact
            # contradiction that report exists to resolve.
            declared = {k: v for k, v in
                        dotenv_values(path, encoding="utf-8-sig").items()
                        if v is not None}
            # 1. remove what OTHER FILES injected and this workspace does not
            #    claim — the isolation half.
            for key in [k for k in os.environ
                        if k not in REAL_ENV
                        and k not in declared
                        and k not in _NEVER_STRIP]:
                os.environ.pop(key, None)
            # 2. apply this workspace's own, still below the real environment
            #
            # RECORD PROVENANCE HERE. This is the file that actually supplies
            # a workspace's settings, and it was the one source `source_of()`
            # could not name: provenance was recorded only by `cli.py`'s
            # loader, which this function does not go through. So
            # `aicore current` reported "not set by any file; using the
            # default" while printing a database this very file had just
            # supplied -- the exact failure the line was added to prevent,
            # inverted.
            for key, value in declared.items():
                if key not in REAL_ENV:
                    os.environ[key] = value
                    PROVENANCE[key] = str(path)
            applied = path
    except Exception:
        logger.warning("could not read %s — ignoring it", path, exc_info=True)
    _LOADED[code] = applied
    return applied
