"""Chat guardrails - deterministic ENFORCEMENT at the inbound chat seams.

The platform already had two deterministic scanners and applied both only
where content becomes durable: ``learning/skill_scan.py`` refuses a
prompt-injection body before it becomes an approved skill, and
``memory/rails.py`` masks PII before a fact becomes workspace memory. An
INBOUND CHAT TURN - ``POST /api/chat/{ns}``, its ``/stream`` twin and
``POST /v1/conversations/{id}/responses`` - passed through neither: the
only thing standing between "ignore all previous instructions" and the
model was the always-on ``guardrails`` SKILL, which is an INSTRUCTION to the
model (measured elsewhere in this repo: a rule stated to a model is a
request). This module is the enforcement half. It REUSES the two scanners
rather than carrying a third vocabulary, so what the learning channel
refuses, what memory masks and what chat refuses cannot drift.

FAIL-OPEN WHEN UNCONFIGURED, FAIL-CLOSED WHEN MISCONFIGURED. No policy file
means every surface behaves byte-for-byte as it did: ``load_policy`` returns
``None`` and the seam helpers hand the text back untouched with no
``guardrails`` field in the reply. A policy that EXISTS and cannot be read -
an unknown mode, a bad regex, a path the environment names that is missing -
raises :class:`PolicyError`, and the seam turns that into HTTP 503: a
deployment that wrote a policy expects enforcement, and running without it
because the file had a typo is the silent failure this platform keeps
paying for.

Resolution, most explicit first: ``IOF_GUARDRAILS`` (a path), then the
workspace tier ``~/.iobot/workspaces/<code>/guardrails.yaml`` (beside
``mcp.yaml`` and ``deliveries.yaml``). Shape::

    input:
      prompt_injection: refuse      # refuse | flag | off
      pii: redact                   # redact | flag | off
      deny_patterns: ["(?i)account\\s+balance"]    # extra regexes; a hit refuses
    output:
      pii: redact                   # redact | flag | off
      disclaimer: "AI-generated. Verify before acting."
    phi: true                       # adds MRN / NPI / ICD-10 / DOB to the PII set

WHAT IS DETERMINISTIC HERE, AND WHAT IS NOT. Every decision in this module
is a regex over the text; nothing asks a model. That buys explainability
(a refusal quotes the pattern that fired) and costs recall: a paraphrased
injection the pattern list does not spell is not caught here, which is why
the skill stays on and this does not replace it. The two are layers.

WHAT THE ORIGINAL TEXT NEVER REACHES. When input redaction is on, the seam
replaces the request's content with the redacted text BEFORE the message
row is written, before the prompt is composed and before the
``chat.start`` log line hashes it - so the store, the model, the session
JSONL and the log all see the same redacted text and the original exists
only in the request body that has already been consumed.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Tuple

ENV_VAR = "IOF_GUARDRAILS"
FILE_NAME = "guardrails.yaml"

INPUT_MODES = ("refuse", "flag", "off")
PII_MODES = ("redact", "flag", "off")

ALLOW = "allow"
REFUSE = "refuse"
FLAG = "flag"

#: The reason codes a refusal carries. Fixed strings so a client can switch
#: on them; the human text rides in ``detail``.
REASON_PROMPT_INJECTION = "prompt_injection"
REASON_DENY_PATTERN = "deny_pattern"
REASON_POLICY_ERROR = "policy_error"


class PolicyError(ValueError):
    """The policy exists and cannot be honoured. Named, never swallowed."""


# ---------------------------------------------------------------------------
# detection - shared code, plus the re-roling spellings the skill itself names
# ---------------------------------------------------------------------------

#: The always-on ``guardrails`` skill tells the model what re-roling looks
#: like ("you are now DAN", "ignore your SOUL", "pretend you have no
#: restrictions"). Those three spellings are enforced here as well, so the
#: examples the instruction gives are also the examples the policy refuses.
#: Deliberately SHORT: a chat surface sees ordinary language all day, and a
#: pattern that fires on "pretend you are a pirate for this story" would
#: teach operators to turn the rail off. Each is the OBVIOUS spelling of an
#: attack, never a chase after an evasion.
CHAT_INJECTION_RES: Tuple[re.Pattern, ...] = (
    re.compile(r"\byou\s+are\s+now\s+(?:dan|in\s+developer\s+mode|jailbroken|unrestricted)\b", re.I),
    re.compile(r"\bignore\s+your\s+(?:soul|system\s+prompt|guardrails|rules)\b", re.I),
    re.compile(r"\bpretend\s+(?:you\s+have|there\s+are)\s+no\s+(?:restrictions|rules|guardrails|limits)\b", re.I),
)


def find_prompt_injection(text: str) -> Optional[str]:
    """The matched excerpt when *text* carries a prompt-injection phrase,
    else ``None``. The learning channel's vocabulary first (shared code),
    then the chat supplement."""
    from ioagentfarm.engine.learning.skill_scan import PROMPT_INJECTION_RES
    for rx in tuple(PROMPT_INJECTION_RES) + CHAT_INJECTION_RES:
        m = rx.search(text or "")
        if m:
            return m.group(0)[:120].replace("\n", " ")
    return None


def redact_pii(text: str, *, phi: bool = False) -> Tuple[str, List[str]]:
    """The memory rail's redactor, with the PHI set when asked."""
    from ioagentfarm.engine.memory.rails import redact
    return redact(text or "", phi=phi)


# ---------------------------------------------------------------------------
# the policy
# ---------------------------------------------------------------------------

@dataclass
class Decision:
    action: str                       # allow | refuse | flag
    text: str                         # what the model may see (possibly redacted)
    flags: List[str] = field(default_factory=list)
    reason: Optional[str] = None      # a reason code when refused
    detail: Optional[str] = None      # the human sentence when refused

    def to_dict(self) -> dict:
        return {"action": self.action, "text": self.text, "flags": list(self.flags),
                "reason": self.reason, "detail": self.detail}


@dataclass
class Filtered:
    text: str
    flags: List[str] = field(default_factory=list)
    disclaimer_added: bool = False


@dataclass
class Policy:
    input_prompt_injection: str = "off"
    input_pii: str = "off"
    deny_patterns: List[re.Pattern] = field(default_factory=list)
    output_pii: str = "off"
    disclaimer: str = ""
    phi: bool = False
    source: str = ""

    # -- input --------------------------------------------------------------

    def check_input(self, text: str) -> Decision:
        """Refuse, flag or allow one inbound message; redact when told to."""
        text = text or ""
        flags: List[str] = []
        if self.input_prompt_injection != "off":
            hit = find_prompt_injection(text)
            if hit is not None:
                if self.input_prompt_injection == "refuse":
                    return Decision(
                        REFUSE, text, [REASON_PROMPT_INJECTION],
                        reason=REASON_PROMPT_INJECTION,
                        detail=("the message carries an instruction aimed at "
                                f"the model rather than the task ({hit!r}); "
                                "this deployment refuses such turns"))
                flags.append(REASON_PROMPT_INJECTION)
        for rx in self.deny_patterns:
            m = rx.search(text)
            if m:
                return Decision(
                    REFUSE, text, [REASON_DENY_PATTERN],
                    reason=REASON_DENY_PATTERN,
                    detail=(f"the message matches a denied pattern "
                            f"({rx.pattern!r}: {m.group(0)[:80]!r})"))
        if self.input_pii != "off":
            masked, kinds = redact_pii(text, phi=self.phi)
            if kinds:
                flags.extend(f"pii:{k}" for k in kinds)
                if self.input_pii == "redact":
                    text = masked
        return Decision(FLAG if flags else ALLOW, text, flags)

    # -- output -------------------------------------------------------------

    def filter_output(self, text: str) -> Filtered:
        """Redact or flag PII in a reply; append the disclaimer exactly once."""
        text = text or ""
        flags: List[str] = []
        if self.output_pii != "off":
            masked, kinds = redact_pii(text, phi=self.phi)
            if kinds:
                flags.extend(f"pii:{k}" for k in kinds)
                if self.output_pii == "redact":
                    text = masked
        added = False
        if self.disclaimer:
            # Idempotent: a reply that already ends with the line (a seam
            # called twice, a model that echoed it) does not get a second.
            if text.rstrip().endswith(self.disclaimer):
                pass
            else:
                text = (text.rstrip() + "\n\n" + self.disclaimer) if text.strip() else self.disclaimer
                added = True
        return Filtered(text, flags, added)

    # -- reporting ----------------------------------------------------------

    def describe(self) -> dict:
        return {
            "source": self.source,
            "input": {"prompt_injection": self.input_prompt_injection,
                      "pii": self.input_pii,
                      "deny_patterns": [rx.pattern for rx in self.deny_patterns]},
            "output": {"pii": self.output_pii, "disclaimer": self.disclaimer},
            "phi": self.phi,
        }


# ---------------------------------------------------------------------------
# loading
# ---------------------------------------------------------------------------

def _mode(section: dict, key: str, legal: Tuple[str, ...], where: str) -> str:
    raw = section.get(key, "off")
    if raw is None or raw is False:
        return "off"
    value = str(raw).strip().lower()
    if value not in legal:
        raise PolicyError(
            f"{where}.{key}: {raw!r} is not a mode; use one of "
            + ", ".join(legal))
    return value


def parse_policy(data: Any, source: str = "") -> Policy:
    """A :class:`Policy` from the YAML's mapping. Every illegal value is a
    :class:`PolicyError` that names the legal ones."""
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise PolicyError(f"{source or 'policy'}: the document must be a mapping")
    inp = data.get("input") or {}
    out = data.get("output") or {}
    if not isinstance(inp, dict):
        raise PolicyError("input: must be a mapping")
    if not isinstance(out, dict):
        raise PolicyError("output: must be a mapping")
    for section, name, legal in ((inp, "input", ("prompt_injection", "pii", "deny_patterns")),
                                 (out, "output", ("pii", "disclaimer"))):
        unknown = sorted(set(section) - set(legal))
        if unknown:
            raise PolicyError(
                f"{name}: unknown key(s) {', '.join(unknown)}; legal keys are "
                + ", ".join(legal))
    unknown_top = sorted(set(data) - {"input", "output", "phi"})
    if unknown_top:
        raise PolicyError(
            f"unknown top-level key(s) {', '.join(unknown_top)}; legal keys "
            "are input, output, phi")
    patterns: List[re.Pattern] = []
    raw_deny = inp.get("deny_patterns") or []
    if isinstance(raw_deny, str):
        raw_deny = [raw_deny]
    if not isinstance(raw_deny, list):
        raise PolicyError("input.deny_patterns: must be a list of regexes")
    for p in raw_deny:
        try:
            patterns.append(re.compile(str(p)))
        except re.error as e:
            raise PolicyError(f"input.deny_patterns: {p!r} is not a valid regex ({e})") from e
    disclaimer = out.get("disclaimer") or ""
    if not isinstance(disclaimer, str):
        raise PolicyError("output.disclaimer: must be a string")
    phi = data.get("phi", False)
    if not isinstance(phi, bool):
        raise PolicyError(f"phi: {phi!r} is not a boolean; use true or false")
    return Policy(
        input_prompt_injection=_mode(inp, "prompt_injection", INPUT_MODES, "input"),
        input_pii=_mode(inp, "pii", PII_MODES, "input"),
        deny_patterns=patterns,
        output_pii=_mode(out, "pii", PII_MODES, "output"),
        disclaimer=disclaimer.strip(),
        phi=phi,
        source=source,
    )


def _workspace_code(workspace: Optional[str]) -> Optional[str]:
    if workspace:
        return workspace
    env = (os.environ.get("IOF_WORKSPACE") or "").strip()
    if env:
        return env
    try:
        from ioagentfarm.engine.workspaces import resolved_workspace_code
        return resolved_workspace_code()
    except Exception:            # noqa: BLE001 - no workspace = no policy
        return None


def policy_path(workspace: Optional[str] = None) -> Tuple[Optional[Path], str]:
    """``(path, tier)`` - the file that would be read and which tier named
    it (``env``, ``workspace`` or ``none``). ``env`` is returned even when
    the file is missing, so ``load_policy`` can refuse rather than fall
    open on a declaration that failed."""
    # The literal name is read here, not through ENV_VAR: the environment
    # reference is GENERATED from read sites, and a constant is invisible to it.
    raw = (os.environ.get("IOF_GUARDRAILS") or "").strip()
    if raw:
        return Path(raw).expanduser(), "env"
    code = _workspace_code(workspace)
    if not code:
        return None, "none"
    from ioagentfarm.engine.workspace_env import workspace_home
    p = workspace_home(code) / FILE_NAME
    return (p, "workspace") if p.is_file() else (None, "none")


_CACHE: dict = {}


def load_policy(workspace: Optional[str] = None) -> Optional[Policy]:
    """The policy in force, or ``None`` when none is declared.

    Raises :class:`PolicyError` when one IS declared and cannot be read.
    Cached per path and mtime, so a turn costs one ``stat``.
    """
    path, tier = policy_path(workspace)
    if path is None:
        return None
    if not path.is_file():
        raise PolicyError(f"{ENV_VAR} names {path}, which does not exist")
    try:
        mtime = path.stat().st_mtime_ns
    except OSError as e:
        raise PolicyError(f"{path}: cannot stat ({e})") from e
    key = str(path)
    hit = _CACHE.get(key)
    if hit and hit[0] == mtime:
        return hit[1]
    import yaml
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as e:
        raise PolicyError(f"{path}: cannot be read as YAML ({e})") from e
    policy = parse_policy(data, source=f"{tier}:{path}")
    _CACHE[key] = (mtime, policy)
    return policy


# ---------------------------------------------------------------------------
# the seam helpers - ONE call at the top of a chat handler, ONE at the reply
# ---------------------------------------------------------------------------

_REFUSAL_CLS = None


def refusal_class():
    """``GuardrailRefusal`` - an ``HTTPException`` whose body is exactly
    ``{"error": "guardrails", "reason": ..., "detail": ...}``. Built lazily
    so this engine module does not import FastAPI at import time (the CLI
    startup budget) and so ``install_error_shape`` and the raisers share
    ONE class."""
    global _REFUSAL_CLS
    if _REFUSAL_CLS is None:
        from fastapi import HTTPException

        class GuardrailRefusal(HTTPException):
            def __init__(self, status_code: int, body: dict):
                super().__init__(status_code=status_code, detail=body)
                self.body = body

        _REFUSAL_CLS = GuardrailRefusal
    return _REFUSAL_CLS


def install_error_shape(app) -> None:
    """Render a :func:`refusal_class` as its bare body, not under ``detail``.

    Scoped by TYPE, like the conversations router's own handler, so no other
    route on the engine is restyled.
    """
    from fastapi.responses import JSONResponse
    cls = refusal_class()

    @app.exception_handler(cls)
    async def _handle(_request, exc):        # noqa: ANN202
        return JSONResponse(status_code=exc.status_code, content=exc.body)


def _http(status: int, reason: str, detail: str):
    return refusal_class()(status, {
        "error": "guardrails", "reason": reason, "detail": detail})


def guard_input(text: str, workspace: Optional[str] = None) -> Tuple[str, Optional[dict]]:
    """``(text_for_the_model, state)`` for one inbound message.

    ``state`` is ``None`` when no policy is declared - the caller then
    changes nothing, which is what keeps the unconfigured path identical.
    A refusal is raised as HTTP 422 with ``{"error": "guardrails", "reason",
    "detail"}``; a policy that cannot be read is HTTP 503 with reason
    ``policy_error``.
    """
    try:
        policy = load_policy(workspace)
    except PolicyError as e:
        raise _http(503, REASON_POLICY_ERROR, str(e)) from e
    if policy is None:
        return text, None
    d = policy.check_input(text)
    if d.action == REFUSE:
        raise _http(422, d.reason or REASON_DENY_PATTERN, d.detail or "refused")
    return d.text, {"input_flags": list(d.flags), "_policy": policy}


def guard_output(text: str, state: Optional[dict],
                 envelope: Optional[dict] = None) -> Tuple[str, Optional[dict]]:
    """``(reply_text, guardrails_field)`` for the reply of a guarded turn.

    ``state`` is what :func:`guard_input` returned; ``None`` means no policy
    and the text comes back untouched with no field. The returned dict is
    the ``guardrails`` value a client renders: ``input_flags``,
    ``output_flags``, ``disclaimer`` (true when appended) and, on a
    streamed turn, ``deltas_unfiltered: true`` - the deltas already left
    the wire and only the terminal ``message`` event carries the filtered
    text. When *envelope* is given, its ``answer`` and ``insight`` strings
    are filtered in place under the same PII mode, since a client renders
    those rather than the prose.
    """
    if not state:
        return text, None
    policy: Policy = state["_policy"]
    f = policy.filter_output(text)
    flags = list(f.flags)
    if isinstance(envelope, dict) and policy.output_pii != "off":
        for key in ("answer", "insight"):
            val = envelope.get(key)
            if isinstance(val, str) and val:
                masked, kinds = redact_pii(val, phi=policy.phi)
                if kinds:
                    flags.extend(f"pii:{k}" for k in kinds if f"pii:{k}" not in flags)
                    if policy.output_pii == "redact":
                        envelope[key] = masked
    out = {"input_flags": list(state.get("input_flags") or []),
           "output_flags": flags,
           "disclaimer": f.disclaimer_added}
    try:
        from ioagentfarm.web import chat_stream
        if chat_stream.streaming():
            out["deltas_unfiltered"] = True
    except Exception:            # noqa: BLE001 - reporting must not break a turn
        pass
    return f.text, out
