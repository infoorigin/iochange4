from __future__ import annotations
from ioagentfarm.engine.iobot_runner import IobotRunner
from ioagentfarm.engine.local_runner import LocalEchoRunner
from ioagentfarm.engine.runner_base import Runner

def get_default_runner(mode: str) -> Runner:
    mode = (mode or "auto").lower()
    if mode == "iobot":
        return IobotRunner()
    if mode == "echo":
        return LocalEchoRunner()
    if IobotRunner.is_available():
        return IobotRunner()
    return LocalEchoRunner()
