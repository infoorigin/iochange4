"""Lay down `~/.iobot/` — the runtime home — as EDITABLE TEMPLATES.

The agent runtime reads its model provider from `~/.iobot/config.json`, at a
fixed path, and there was nothing that created it. The getting-started guide
answered that with a JSON blob to copy out of the docs by hand and a Python
heredoc to check the copy worked — which is how a reader ends up with a config
that is subtly wrong in the one field that matters.

TEMPLATES, NOT PROMPTS. This writes files with placeholders and stops; the
reader opens them and fills in their key and URL. An interactive wizard would
have to know every provider's shape, and a `--api-key` flag puts a credential
in shell history. A file you edit is the thing people already know how to do,
and it is the same contract as `.env.example`.

NOTHING IS OVERWRITTEN, AND THERE IS NO FLAG THAT WOULD. An existing
`config.json` holds a live API key and an existing `.env` holds this machine's
database. A `--force` that backs up first is still a command someone runs at
2am and then goes hunting for a `.bak` file, so there isn't one: existing means
kept and reported. Starting over is `rm` — a deliberate act, by the person who
knows what was in the file.
"""

from __future__ import annotations

import json
from pathlib import Path

WROTE = "wrote"
KEPT = "kept"            # already there — left exactly as found
FAILED = "failed"

#: `<shipped template>` -> `<name under ~/.iobot/>`.
#:
#: THE TEMPLATES ARE FILES, NOT STRINGS IN THIS MODULE. They are content a
#: reader edits, so they belong somewhere reviewable in a diff and editable
#: without touching Python. They ship as package data because the audience
#: `pip install`s the SDK and has no checkout — a template that lives only in
#: the repo is one this command cannot copy.
#:
#: Named `.example` with NO leading dot, the same convention as the repo's own
#: `.env.example`: an ordinary package-data glob does not match a dotfile, and
#: a template that silently fails to ship produces a wheel whose first command
#: writes nothing.
_TEMPLATES = {
    "config.json.example": "config.json",
    "env.example": ".env",
    # The guidance that used to live INSIDE config.json, as two top-level
    # `_README`/`_maxTokens_note` keys. JSON carries no comments, so the notes
    # were written as keys -- and the runtime's top-level config model forbids
    # unknown keys, so the file this command generates was rejected by the
    # runtime it generates it for. `config-check` passed it; the failure
    # surfaced at the first agent call as a validation dump plus a message
    # about tool iterations, which is not the cause. The notes are worth
    # keeping and cannot live in the JSON, so they live beside it.
    "config.README.md": "config.README.md",
}

#: `21333` is not a tuning choice. It is the Anthropic SDK's ceiling for a
#: NON-STREAMING request, and the engine runs non-streaming by design. Above
#: it, every generation call is rejected while cheap read calls still succeed —
#: so it presents as a flaky model rather than a configuration error. That cost
#: days once. It is written into the template so nobody has to read a warning
#: box to get it right.
MAX_TOKENS_NON_STREAMING = 21333

def _template_text(name: str) -> str:
    """One shipped template's text.

    `importlib.resources`, not a path relative to __file__: the same lookup
    works from a wheel, an editable install and a zip, and this command's whole
    point is that it runs for someone who has no checkout.
    """
    from importlib.resources import files
    return (files("ioagentfarm") / "templates" / name).read_text(encoding="utf-8")


def _state_dir_name() -> str:
    import os
    return (os.getenv("IOF_STATE_DIR_NAME") or ".iobot").strip() or ".iobot"


def iobot_home() -> Path:
    return Path.home() / _state_dir_name()


def bootstrap_home() -> list[dict]:
    """Create `~/.iobot/` and place `config.json` + `.env` if absent.

    NEVER OVERWRITES, AND HAS NO FLAG THAT DOES. An existing `config.json`
    holds a live API key and an existing `.env` holds this machine's database;
    replacing either to "help" is the worst thing this module could do, and a
    `--force` that backs up first is still a command someone runs at 2am and
    then hunts for a `.bak` file. Existing means kept, reported, and that is
    all. To start over, delete the file yourself — a deliberate act, by the
    person who knows what was in it.

    Returns one record per file: ``{"path", "action", "error"}``.
    """
    home = iobot_home()
    results: list[dict] = []
    try:
        home.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return [{"path": home, "action": FAILED, "backup": None,
                 "error": str(exc)}]

    try:
        payloads = {home / dest: _template_text(src)
                    for src, dest in _TEMPLATES.items()}
    except (FileNotFoundError, OSError, ModuleNotFoundError) as exc:
        # The templates are package data. Missing means the installed wheel
        # shipped without them — a packaging fault, not a user error, and worth
        # naming rather than reporting an empty success.
        return [{"path": home, "action": FAILED, "backup": None,
                 "error": f"shipped templates not found ({exc}) — the "
                          f"installed agentfarm-core is missing its "
                          f"templates/ package data"}]
    for path, text in payloads.items():
        record = {"path": path, "action": KEPT, "error": None}
        try:
            if not path.exists():
                path.write_text(text, encoding="utf-8")
                record["action"] = WROTE
        except OSError as exc:
            record["action"] = FAILED
            record["error"] = str(exc)
        results.append(record)
    return results


#: Providers whose traffic goes through the `anthropic` Python SDK, and are
#: therefore subject to its non-streaming ceiling. `GenaiBedrockProvider`
#: subclasses `AnthropicProvider`, so a Bedrock-wrapper deployment inherits it.
#: Everything else -- azure_openai, openai, any OpenAI-compatible gateway --
#: uses a different client with no such rule, and `maxTokens` there is bounded
#: only by what that endpoint accepts.
_ANTHROPIC_SDK_PROVIDERS = frozenset({"anthropic", "bedrock", "genai_bedrock"})


def uses_anthropic_sdk(provider: str | None) -> bool:
    """Does this provider's traffic go through the `anthropic` SDK?

    Unknown or unset returns False: a limit is asserted only where it is known
    to apply. Guessing the other way refuses a working configuration, which is
    exactly what a provider-blind version of this check did to an Azure
    deployment running `maxTokens: 125000` quite happily.
    """
    return bool(provider) and str(provider).strip().lower() in _ANTHROPIC_SDK_PROVIDERS


def unknown_top_level_keys(data: dict) -> list[str]:
    """Top-level keys the agent runtime will REFUSE, in file order.

    The runtime's top-level config model forbids unknown keys while its
    ``providers`` block allows them, so a stray key here is fatal and a stray
    provider entry is not. Nothing reports that until the first agent call,
    where it arrives as a validation dump followed by a message about tool
    iterations or exec timeouts -- which is not the cause. `config-check` is
    the command the guides tell a reader to trust, so it is where this belongs.

    The field list is read FROM the runtime model rather than hardcoded: a
    hardcoded copy would start refusing keys the runtime added, which is the
    same failure with the blame reversed. If the model cannot be imported,
    nothing is reported -- an unavailable runtime is not evidence of a bad
    config.
    """
    try:
        from iobot.config.schema import Config
    except Exception:                     # pragma: no cover - runtime absent
        return []
    allowed = set(getattr(Config, "model_fields", {}))
    if not allowed:                       # pragma: no cover - shape changed
        return []
    for field in getattr(Config, "model_fields", {}).values():
        alias = getattr(field, "alias", None)
        if alias:
            allowed.add(alias)
    return [k for k in data if k not in allowed]


def describe_config() -> dict:
    """What is configured, WITHOUT revealing a key.

    Replaces the Python heredoc the guide asked readers to paste. `configured`
    is False while the template placeholders are still in place, which is the
    state that otherwise looks fine and fails at the first generation call.
    """
    path = iobot_home() / "config.json"
    out = {"path": path, "exists": path.is_file(), "model": None,
           "max_tokens": None, "providers": [], "configured": False,
           "unknown_keys": []}
    if not out["exists"]:
        return out
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        out["error"] = str(exc)
        return out
    out["unknown_keys"] = unknown_top_level_keys(data)
    defaults = (data.get("agents") or {}).get("defaults") or {}
    # Which provider a model actually routes through, most explicit first.
    # It decides whether SDK-specific limits apply at all, so it is read
    # rather than assumed: the non-streaming ceiling below is the Anthropic
    # SDK's arithmetic and means nothing to an Azure or OpenAI endpoint.
    out["provider"] = (
        defaults.get("provider")
        or (str(defaults.get("model") or "").split("/", 1)[0]
            if "/" in str(defaults.get("model") or "") else None))
    out["model"] = defaults.get("model")
    out["max_tokens"] = defaults.get("maxTokens")
    for name, prov in (data.get("providers") or {}).items():
        if name.startswith("_"):
            continue          # a commented-out example, not a provider
        key = (prov or {}).get("apiKey") or ""
        out["providers"].append({
            "name": name,
            "api_base": (prov or {}).get("apiBase"),
            "has_key": bool(key) and not key.startswith("<"),
        })
    out["configured"] = (
        bool(out["model"]) and not str(out["model"]).endswith(">")
        and any(p["has_key"] for p in out["providers"]))
    return out
