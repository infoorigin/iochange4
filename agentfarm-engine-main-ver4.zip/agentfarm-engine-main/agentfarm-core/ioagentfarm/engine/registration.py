"""Boot registration — WHAT IS RUNNING HERE, written to the database.

The One Truth model (docs/one-truth-content-model.md §3.3 / §4.2 / §5): every
engine boot writes one row per installed content distribution into
``content_registration`` — the stamp from :mod:`ioagentfarm.engine.content`
plus ``booted_at`` and ``host``. The latest rows per ``(workspace, host)`` are
what is running there; "which commit is running in UAT?" is one query on this
table in UAT's database, and a rolling deploy shows two versions honestly
until the roll completes.

Kept apart from ``content.py`` on purpose: the stamp is pure detection and
must stay importable with no database in sight (it is printed on every CLI
command); this module is the only place the stamp meets a cursor.

DDL lives here too — :func:`content_registration_ddl` — and BOTH schema
ensurers call it (``engine/store.py`` ``Store.init`` for the engine,
``workspace_sync.ensure_platform_schema`` for the API), so the two sides
cannot drift the way a table declared in one and not the other did before
(``pack_skills``, see the CLAUDE.md note). ``scripts/setup_schema.sql`` and the
API tests' hand-maintained schema carry their own copies of the same text.

Timestamps are stored as ISO-8601 UTC STRINGS on both backends (the string is
what a ``TIMESTAMP`` column accepts without a session-timezone conversion —
a tz-aware ``datetime`` parameter would be adapted to ``timestamptz`` and
shifted into the session's zone on the way into a naive column). Reads
normalise whatever the driver hands back to the same ISO string.
"""

from __future__ import annotations

import logging
import socket
from datetime import datetime, timezone
from typing import Any

from ioagentfarm.engine.content import Stamp, stamps

logger = logging.getLogger(__name__)

TABLE = "content_registration"
INDEX = "idx_content_registration_ws_host_booted"


def content_registration_ddl(is_pg: bool) -> list[str]:
    """The table + its index, in the dialect asked for. Idempotent statements.

    ``dirty`` is BOOLEAN on PostgreSQL and INTEGER on SQLite; the writer passes
    a Python ``bool`` so each driver adapts it natively. ``booted_at`` is a
    TIMESTAMP on both — SQLite keeps the ISO string (NUMERIC affinity cannot
    convert it, so it is stored as text), PostgreSQL parses it.
    """
    auto_id = "SERIAL PRIMARY KEY" if is_pg else "INTEGER PRIMARY KEY AUTOINCREMENT"
    dirty = "BOOLEAN NOT NULL DEFAULT FALSE" if is_pg else "INTEGER NOT NULL DEFAULT 0"
    return [
        f"""CREATE TABLE IF NOT EXISTS {TABLE} (
            id             {auto_id},
            workspace_code TEXT NOT NULL,
            host           TEXT NOT NULL,
            pack           TEXT NOT NULL,
            dist           TEXT NOT NULL,
            version        TEXT NOT NULL,
            source         TEXT,
            git_sha        TEXT,
            dirty          {dirty},
            root           TEXT,
            booted_at      TIMESTAMP NOT NULL
        );""",
        f"CREATE INDEX IF NOT EXISTS {INDEX} "
        f"ON {TABLE}(workspace_code, host, booted_at);",
    ]


def ensure_table(store_or_adapter) -> None:
    """Create the table on a bare adapter/store that has not run ``init()``."""
    store = _as_store(store_or_adapter)
    is_pg = store._db.placeholder() == "%s"
    with store._tx() as cursor:
        for ddl in content_registration_ddl(is_pg):
            cursor.execute(ddl)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _as_store(store_or_adapter):
    """Accept a ``Store`` or a ``DbAdapter``; always hand back a ``Store``.

    Imported lazily so ``engine/store.py`` can import THIS module for the DDL
    without a cycle.
    """
    from ioagentfarm.engine.store import Store
    if isinstance(store_or_adapter, Store):
        return store_or_adapter
    return Store(store_or_adapter)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _iso(value: Any) -> Any:
    """Normalise a driver-returned timestamp to the ISO string that was written.

    PostgreSQL hands back a naive ``datetime`` for a TIMESTAMP column (the UTC
    clock value we stored, offset dropped) — re-attach UTC. SQLite hands back
    the string itself.
    """
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    return value


def _row(r: Any) -> dict:
    d = r if isinstance(r, dict) else dict(r)
    d["booted_at"] = _iso(d.get("booted_at"))
    d["dirty"] = bool(d.get("dirty"))
    return d


# ---------------------------------------------------------------------------
# public
# ---------------------------------------------------------------------------

def register_content(store_or_adapter, workspace_code: str,
                     host: str | None = None,
                     items: list[Stamp] | None = None) -> int:
    """Write one row per stamp with a single ``booted_at``; return the count.

    ``host`` defaults to this machine's hostname; ``items`` to
    :func:`ioagentfarm.engine.content.stamps` (core first, then every pack).
    """
    if not (workspace_code or "").strip():
        raise ValueError("register_content: workspace_code is required")
    store = _as_store(store_or_adapter)
    host = (host or "").strip() or socket.gethostname()
    items = stamps() if items is None else list(items)
    booted_at = _utc_now_iso()
    sql = store._q(
        f"INSERT INTO {TABLE}(workspace_code, host, pack, dist, version, "
        "source, git_sha, dirty, root, booted_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?)")
    with store._tx() as cursor:
        for s in items:
            cursor.execute(sql, (workspace_code, host, s.pack, s.dist,
                                 s.version, s.source, s.sha, bool(s.dirty),
                                 s.root, booted_at))
    return len(items)


def latest_registration(store_or_adapter, workspace_code: str,
                        host: str | None = None) -> list[dict]:
    """Rows of the most recent boot for *workspace_code* on *host* — or, with
    ``host=None``, the most recent boot across every host. ``[]`` when nothing
    has registered. Rows are dicts with ``booted_at`` as an ISO string and
    ``dirty`` as a bool, ordered as written (core first)."""
    store = _as_store(store_or_adapter)
    where = "workspace_code=?"
    params: list[Any] = [workspace_code]
    if host:
        where += " AND host=?"
        params.append(host)
    sql = store._q(
        f"SELECT id, workspace_code, host, pack, dist, version, source, "
        f"git_sha, dirty, root, booted_at FROM {TABLE} "
        f"WHERE {where} AND booted_at = "
        f"(SELECT MAX(booted_at) FROM {TABLE} WHERE {where}) "
        "ORDER BY id")
    with store._tx() as cursor:
        cursor.execute(sql, tuple(params + params))
        return [_row(r) for r in cursor.fetchall()]
