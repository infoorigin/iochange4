"""Does this MCP server actually ANSWER us? - the question `mcp-list` could not ask.

`mcp-list` reads files: it knows what is declared, which tier won, and which
``${VAR}`` is unset. It cannot know whether the far end accepts the
credential, so a server whose every request is rejected printed exactly like
a working one. That is how a client lost an afternoon: a green checklist, an
agent quietly missing its tools, and one unnamed red line on the console.

This module makes one real request and says what came back. It is
deliberately NOT the runtime's connection path - it is a diagnostic, so it
answers in HTTP terms a person can act on (401 means the credential was
refused; 404 means the URL is wrong) rather than in the runtime's terms,
where every one of those arrives as ``McpError: Connection closed``.

**Nothing here logs or returns a credential value.** Headers are expanded to
make the request and the result records only which variables were missing.
"""
from __future__ import annotations

import os
import re
from typing import Any

from ioagentfarm.engine.env_template import ENV_REF

#: What a probe concluded. `ok` is the only one that means "tools will load".
OK = "ok"
UNAUTHORIZED = "unauthorized"
FORBIDDEN = "forbidden"
NOT_FOUND = "not-found"
HTTP_ERROR = "http-error"
#: A stdio server that started and then failed the handshake - closed the
#: pipe, answered a JSON-RPC error, or died. It used to be labelled
#: `http-error`, the HTTP vocabulary, about a process that never spoke HTTP
#: (walked 2026-09-02).
STDIO_ERROR = "stdio-error"
UNREACHABLE = "unreachable"
UNSET_VARS = "unset-vars"
SKIPPED = "skipped"

#: An OAuth-protected server announces itself with the RFC 9728 POINTER - the
#: URL of its protected-resource metadata, which a compliant client follows to
#: find the authorization server. The runtime cannot follow it (static header
#: only), so recognising it separates "your token is wrong" from "this server
#: needs a flow we do not implement".
#:
#: ONLY the pointer counts. `realm=` and `error="invalid_token"` are what ANY
#: bearer server sends on a bad token, and matching those told a user with a
#: simple typo'd API key that their server wanted OAuth - a wrong answer that
#: sends them to the vendor instead of to their own .env.
_OAUTH_HINT = re.compile(r"resource_metadata=", re.I)


def _expand(value: str) -> tuple[str, list[str]]:
    """Expand ``${VAR}``/``${VAR:-default}``; report names that were unset."""
    missing: list[str] = []

    def one(m: re.Match) -> str:
        name = m.group(1)
        if name in os.environ:
            return os.environ[name]
        whole = m.group(0)
        if ":-" in whole:
            return whole.split(":-", 1)[1].rstrip("}")
        missing.append(name)
        return ""

    return ENV_REF.sub(one, value), missing


def probe_entries(workspace_code=None) -> dict:
    """Every declared server as a PROBE-READY entry: spec PLUS its auth block.

    ONE READER FOR THREE CONSUMERS. `mcp-list --probe`, the build session's
    startup health check and the runtime's failure diagnosis all have to
    present the credential the RUNTIME presents, or a diagnostic contradicts
    the product. That already happened: the health check called
    `merged_mcp_servers()` - which strips `auth:`, because that key is ours
    and not iobot's - probed an OAuth server anonymously, got a 401, and
    told the model the server would not answer. The model believed the
    warning over its own tools and refused a job it could have done, while
    the runtime was connected and authenticated the whole time.

    So the merge of spec-and-auth happens HERE, once, and everything that
    probes goes through it.
    """
    from ioagentfarm.engine.iobot_config import effective_mcp_servers
    out: dict = {}
    for name, info in (effective_mcp_servers(workspace_code) or {}).items():
        if info.get("status") == "disabled":
            continue
        entry = dict(info.get("spec") or {})
        if info.get("auth"):
            entry["auth"] = info["auth"]
        out[name] = entry
    return out



def _probe_stdio(entry: dict, out: dict, *, timeout: float) -> dict[str, Any]:
    """Launch the declared command, do the MCP handshake, count its tools.

    Speaks newline-delimited JSON-RPC directly rather than through the MCP
    client library: it is a handful of frames, and the probe must not fail
    for a reason the runtime would not (a missing optional dependency here
    would report a healthy server as broken).

    Never raises, and never leaves the child running.
    """
    import json
    import subprocess
    import sys

    command = str(entry.get("command") or "").strip()
    if not command:
        out["detail"] = "no command declared"
        return out

    args = [str(a) for a in (entry.get("args") or [])]
    env = dict(os.environ)
    missing: list[str] = []
    for k, v in (entry.get("env") or {}).items():
        expanded, miss = _expand(str(v))
        missing += miss
        env[str(k)] = expanded
    if missing:
        out["status"] = UNSET_VARS
        out["missing"] = sorted(set(missing))
        out["detail"] = "unset: " + ", ".join(out["missing"])
        return out

    proc = None
    try:
        proc = subprocess.Popen(
            [command, *args], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=env, text=True, encoding="utf-8",
            errors="replace", bufsize=1,
            cwd=str(entry.get("cwd")) if entry.get("cwd") else None)
    except FileNotFoundError:
        out["status"] = UNREACHABLE
        out["detail"] = f"command not found: {command}"
        return out
    except Exception as exc:  # noqa: BLE001
        out["status"] = UNREACHABLE
        out["detail"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        return out

    def _send(payload: dict) -> None:
        proc.stdin.write(json.dumps(payload) + "\n")
        proc.stdin.flush()

    result: dict[str, Any] = {}

    def _converse() -> None:
        _send({"jsonrpc": "2.0", "id": 1, "method": "initialize",
               "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                          "clientInfo": {"name": "aicore-mcp-probe", "version": "1"}}})
        while True:
            line = proc.stdout.readline()
            if not line:
                result["error"] = "server closed the pipe during initialize"
                return
            try:
                msg = json.loads(line)
            except ValueError:
                continue          # servers may log to stdout before framing
            if msg.get("id") == 1:
                if msg.get("error"):
                    result["error"] = str(msg["error"])[:160]
                    return
                result["server"] = ((msg.get("result") or {}).get("serverInfo") or {})
                break
        _send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        _send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        while True:
            line = proc.stdout.readline()
            if not line:
                result["error"] = "server closed the pipe during tools/list"
                return
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            if msg.get("id") == 2:
                if msg.get("error"):
                    result["error"] = str(msg["error"])[:160]
                    return
                defs = (msg.get("result") or {}).get("tools") or []
                result["tools"] = [t.get("name") for t in defs
                                   if isinstance(t, dict)]
                result["tool_defs"] = _tool_defs(defs)
                return

    import threading
    worker = threading.Thread(target=_converse, daemon=True)
    worker.start()
    worker.join(timeout)

    stderr_tail = ""
    try:
        if proc.poll() is not None:
            stderr_tail = (proc.stderr.read() or "")[-300:]
    except Exception:  # noqa: BLE001
        pass
    finally:
        try:
            proc.kill()
        except Exception:  # noqa: BLE001
            pass

    if worker.is_alive():
        out["status"] = UNREACHABLE
        out["detail"] = f"no MCP handshake within {timeout:.0f}s"
        return out
    if result.get("error"):
        out["status"] = STDIO_ERROR
        detail = result["error"]
        if stderr_tail.strip():
            detail += f" | stderr: {stderr_tail.strip()[-160:]}"
        out["detail"] = detail
        return out
    if "tools" not in result:
        out["status"] = UNREACHABLE
        out["detail"] = ("server did not answer tools/list"
                         + (f" | stderr: {stderr_tail.strip()[-160:]}"
                            if stderr_tail.strip() else ""))
        return out

    names = [n for n in (result.get("tools") or []) if n]
    out["status"] = OK
    out["tools"] = len(names)
    label = (result.get("server") or {}).get("name") or "stdio"
    out["server"] = label
    out["tool_list"] = result.get("tool_defs") or []
    out["detail"] = f"{label}: " + (", ".join(names[:6]) if names else "no tools")
    return out


def _tool_defs(defs: Any) -> list[dict[str, str]]:
    """``[{name, description}]`` from a ``tools/list`` result - nothing else
    the server said about a tool (schemas can be kilobytes) is kept."""
    out: list[dict[str, str]] = []
    for t in defs or []:
        if isinstance(t, dict) and t.get("name"):
            out.append({"name": str(t["name"]),
                        "description": str(t.get("description") or "")})
    return out


def _http_context(entry: dict, out: dict) -> tuple[str, dict, Any, str] | None:
    """Expand the URL and headers and build the auth: what EVERY HTTP request
    to a declared server presents, shared by `probe` and `list_tools`.

    Returns ``(url, headers, auth, kind)``, or None with *out* filled in
    when the server cannot be asked at all (an unset ``${VAR}``, no httpx,
    an unusable OAuth block).
    """
    url = str(entry.get("url") or "").strip()
    # THE DIAGNOSTIC MUST PRESENT WHAT THE RUNTIME PRESENTS. A server that
    # authenticates by OAuth would otherwise be probed anonymously and
    # reported `unauthorized` while the agent connects to it perfectly well -
    # a diagnostic that contradicts the product is worse than none.
    declared_auth = entry.get("auth") if isinstance(entry, dict) else None

    # The URL is expanded like every other field - the runtime expands the
    # whole config at load, and a url of `${CREATIVE_MCP_URL}` probed as a
    # LITERAL produced `UnsupportedProtocol ... check the host, port and any
    # proxy`, blaming the server for the diagnostic's own unexpanded ref.
    # An unset url variable joins `missing` for the same reason headers' do:
    # the runtime drops that server before connecting.
    url, missing = _expand(url)

    headers: dict[str, str] = {}
    for k, v in (entry.get("headers") or {}).items():
        expanded, miss = _expand(str(v))
        headers[str(k)] = expanded
        missing += miss
    for v in (entry.get("env") or {}).values():
        _, miss = _expand(str(v))
        missing += miss
    if declared_auth:
        # A `${VAR}` the OAuth block needs is as fatal as one a header needs:
        # without it there is no token to mint, and probing anyway reports a
        # 401 that blames the server for the operator's unset variable.
        from ioagentfarm.engine.mcp_auth import unresolved
        missing += unresolved(declared_auth)
    out["missing"] = sorted(set(missing))
    if out["missing"]:
        # The runtime drops such a server before connecting, so a probe would
        # answer a question nobody is asking.
        out["status"] = UNSET_VARS
        out["detail"] = "unset: " + ", ".join(out["missing"])
        return None

    try:
        import httpx  # noqa: F401 - presence check; the caller opens the client
    except Exception as exc:               # noqa: BLE001 - never break a list
        out["detail"] = f"httpx unavailable: {exc}"
        return None

    kind = str(entry.get("type") or "").strip()
    headers.setdefault("Accept", "application/json, text/event-stream")
    auth = None
    if declared_auth:
        try:
            from ioagentfarm.engine.mcp_auth import ClientCredentialsAuth
            auth = ClientCredentialsAuth(declared_auth)
        except Exception as exc:           # noqa: BLE001 - report, don't raise
            out["status"] = UNAUTHORIZED
            out["detail"] = f"OAuth declaration unusable: {exc}"
            return None
    out["declared_oauth"] = bool(declared_auth)
    return url, headers, auth, kind


def _status_for_http(code: int) -> str:
    if code == 401:
        return UNAUTHORIZED
    if code == 403:
        return FORBIDDEN
    if code == 404:
        return NOT_FOUND
    if code >= 400:
        return HTTP_ERROR
    return OK


def _jsonrpc_from_response(response: Any) -> dict | None:
    """The JSON-RPC message an MCP HTTP response carries, whichever body the
    server chose: a plain ``application/json`` document, or an SSE stream
    whose ``data:`` lines each hold one message (the sample lab server and
    the reference Python SDK answer a POST this way)."""
    import json
    text = response.text or ""
    ctype = (response.headers.get("content-type") or "").lower()
    if "text/event-stream" in ctype or text.lstrip().startswith(("event:", "data:")):
        last: dict | None = None
        for line in text.splitlines():
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if not payload:
                continue
            try:
                msg = json.loads(payload)
            except ValueError:
                continue
            if isinstance(msg, dict) and ("result" in msg or "error" in msg):
                last = msg
        return last
    try:
        msg = json.loads(text)
    except ValueError:
        return None
    return msg if isinstance(msg, dict) else None


_INITIALIZE_PARAMS = {"protocolVersion": "2025-06-18", "capabilities": {},
                      "clientInfo": {"name": "aicore-mcp-probe", "version": "1"}}


def list_tools(entry: dict, *, timeout: float = 6.0) -> dict[str, Any]:
    """The tools one declared server OFFERS. Never raises.

    Returns ``{status, detail, server, tools}`` where ``tools`` is a list of
    ``{name, description}`` when the server answered ``tools/list`` and
    None when it could not be asked - ``detail`` then says why, in the
    same vocabulary as :func:`probe`.

    `probe` stops at ``initialize`` on purpose (reachability, in HTTP terms
    a person can act on); this goes the two frames further the runtime
    goes - ``notifications/initialized`` then ``tools/list`` - so a
    declaration can be checked against the tool names an agent will see
    (``mcp_<server>_<tool>``) before a run depends on them. Streamable
    HTTP: the ``Mcp-Session-Id`` the server assigns on ``initialize`` is
    echoed on every later request, and the session is deleted at the end
    as a courtesy. Stdio: the probe already speaks the whole exchange.
    """
    out: dict[str, Any] = {"status": SKIPPED, "detail": "", "server": "",
                           "tools": None, "missing": []}
    url = str(entry.get("url") or "").strip()
    if not url:
        probed = probe(entry, timeout=timeout)
        out["status"] = probed["status"]
        out["detail"] = probed["detail"]
        out["missing"] = probed.get("missing") or []
        out["server"] = probed.get("server") or ""
        if probed["status"] == OK:
            out["tools"] = probed.get("tool_list") or []
            out["detail"] = f"{len(out['tools'])} tool(s)"
        return out

    ctx = _http_context(entry, out)
    if ctx is None:
        return out
    url, headers, auth, kind = ctx
    if kind == "sse":
        # The legacy transport opens a GET stream and POSTs to an endpoint
        # the server names in its first event. Listing its tools is a
        # different conversation; say so rather than guess at it.
        out["detail"] = ("legacy sse transport - tool listing supports "
                         "stdio and streamableHttp; --probe still checks it")
        return out
    import httpx
    headers = dict(headers)
    headers.setdefault("Content-Type", "application/json")

    def _post(client, rid, method, params=None, session=None):
        body: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if rid is not None:
            body["id"] = rid
        if params is not None:
            body["params"] = params
        h = dict(headers)
        if session:
            h["Mcp-Session-Id"] = session
        return client.post(url, headers=h, json=body)

    def _fail(stage: str, status: str, detail: str) -> dict[str, Any]:
        out["status"] = status
        out["detail"] = f"{stage}: {detail}"
        return out

    try:
        with httpx.Client(timeout=timeout, follow_redirects=True,
                          auth=auth) as c:
            r = _post(c, 1, "initialize", _INITIALIZE_PARAMS)
            if r.status_code >= 400:
                return _fail("initialize", _status_for_http(r.status_code),
                             f"HTTP {r.status_code}")
            msg = _jsonrpc_from_response(r)
            if msg is None:
                return _fail("initialize", HTTP_ERROR,
                             "no JSON-RPC response in a "
                             f"{r.headers.get('content-type') or 'body-less'} reply")
            if msg.get("error"):
                return _fail("initialize", HTTP_ERROR, str(msg["error"])[:160])
            session = r.headers.get("mcp-session-id") or None
            result = msg.get("result") or {}
            out["server"] = ((result.get("serverInfo") or {}).get("name")
                             or "")
            if result.get("protocolVersion"):
                headers.setdefault("MCP-Protocol-Version",
                                   str(result["protocolVersion"]))
            try:
                _post(c, None, "notifications/initialized", session=session)
            except Exception:  # noqa: BLE001 - a notification; 202 or nothing
                pass
            r = _post(c, 2, "tools/list", {}, session=session)
            if r.status_code >= 400:
                return _fail("tools/list", _status_for_http(r.status_code),
                             f"HTTP {r.status_code}")
            msg = _jsonrpc_from_response(r)
            if msg is None:
                return _fail("tools/list", HTTP_ERROR,
                             "no JSON-RPC response in a "
                             f"{r.headers.get('content-type') or 'body-less'} reply")
            if msg.get("error"):
                return _fail("tools/list", HTTP_ERROR, str(msg["error"])[:160])
            out["tools"] = _tool_defs((msg.get("result") or {}).get("tools"))
            out["status"] = OK
            out["detail"] = f"{len(out['tools'])} tool(s)"
            if session:
                try:
                    c.delete(url, headers={**headers, "Mcp-Session-Id": session})
                except Exception:  # noqa: BLE001 - a courtesy
                    pass
    except Exception as exc:               # noqa: BLE001 - any transport error
        out["status"] = UNREACHABLE
        out["detail"] = f"{type(exc).__name__}: {str(exc)[:120]}"
    return out


def probe(entry: dict, *, timeout: float = 6.0) -> dict[str, Any]:
    """Probe one merged server entry. Never raises.

    Returns ``{status, detail, oauth: bool, missing: [names], tools: int|None}``.
    """
    out: dict[str, Any] = {"status": SKIPPED, "detail": "", "oauth": False,
                           "declared_oauth": False, "missing": [],
                           "tools": None}
    url = str(entry.get("url") or "").strip()
    if not url:
        # A STDIO SERVER IS THE COMMON CASE AND WAS THE UNANSWERABLE ONE.
        # "launched by the runtime, not probed" is true and useless: a server
        # that crashes on startup, or whose interpreter path is wrong, was
        # invisible until an agent turn failed - and the agent reports that
        # as "the tool is unavailable", which reads as the model refusing.
        # The runtime launches it exactly this way, so probing it here asks
        # the same question the runtime will ask, before anyone waits on it.
        return _probe_stdio(entry, out, timeout=timeout)

    # Expansion, headers and auth are shared with `list_tools` (see
    # `_http_context`): the two must present the same credential, or one of
    # them contradicts the product.
    ctx = _http_context(entry, out)
    if ctx is None:
        return out
    url, headers, auth, kind = ctx
    import httpx
    try:
        with httpx.Client(timeout=timeout, follow_redirects=True,
                          auth=auth) as c:
            if kind == "sse":
                r = c.get(url, headers=headers)
            else:
                headers.setdefault("Content-Type", "application/json")
                r = c.post(url, headers=headers, json={
                    "jsonrpc": "2.0", "id": 1, "method": "initialize",
                    "params": {"protocolVersion": "2025-06-18",
                               "capabilities": {},
                               "clientInfo": {"name": "aicore-mcp-probe",
                                              "version": "1"}}})
    except Exception as exc:               # noqa: BLE001 - any transport error
        out["status"] = UNREACHABLE
        out["detail"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        return out

    www = r.headers.get("www-authenticate", "")
    out["oauth"] = bool(www and _OAUTH_HINT.search(www))
    if r.status_code == 401:
        out["status"] = UNAUTHORIZED
        out["detail"] = ("credential refused"
                         + (f" - {www[:90]}" if www else ""))
    elif r.status_code == 403:
        out["status"] = FORBIDDEN
        out["detail"] = "authenticated but not permitted"
    elif r.status_code == 404:
        out["status"] = NOT_FOUND
        out["detail"] = "no MCP endpoint at this URL"
    elif r.status_code >= 400:
        out["status"] = HTTP_ERROR
        out["detail"] = f"HTTP {r.status_code}"
    else:
        out["status"] = OK
        out["detail"] = f"HTTP {r.status_code}"
    return out


def advice(result: dict) -> str:
    """One actionable line for a non-ok probe, or "" when there is nothing to say."""
    status = result.get("status")
    if status == UNAUTHORIZED:
        if result.get("declared_oauth"):
            return ("the declared OAuth grant was rejected - check "
                    "auth.token_url, the client id/secret in the workspace "
                    ".env, and any scope or audience the server requires")
        if result.get("oauth"):
            return ("this server wants an OAuth flow (it answered with an "
                    "authorization challenge). The runtime sends a STATIC "
                    "header only - ask the vendor for a long-lived token, or "
                    "terminate the flow in a gateway and point the "
                    "declaration at that")
        return ("the credential was refused - check the value in the "
                "workspace .env, not the declaration")
    if status == NOT_FOUND:
        return "check the URL path (many servers serve MCP at /mcp)"
    if status == UNREACHABLE:
        return "nothing answered - check the host, port and any proxy"
    if status == STDIO_ERROR:
        return ("the process started and failed the MCP handshake - run the "
                "command by hand from the same shell; a bare interpreter name "
                "can resolve to a different Python than the one that has the "
                "server's packages (use the full path)")
    if status == UNSET_VARS:
        return "set the variable(s) in the workspace .env; until then the server is dropped"
    return ""
