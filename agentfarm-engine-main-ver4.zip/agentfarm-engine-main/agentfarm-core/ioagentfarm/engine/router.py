"""Deterministic capability router: ``route(query) -> the agent whose DECLARED
scope matches``, with the score explained term by term. NO MODEL CALL.

Routing in this engine was model-mediated everywhere it existed
(docs/capabilities/evidence/A-harness-router-registries.md, section 2): a
swarm's meta-agent decides at run time, ``cora``'s ``ai_assistant`` skill
routes at prompt level, and ``@agent`` mentions are a regex. None of them is
a function an application can call before paying for a turn, and none can
say WHY an agent was chosen in terms a person can check against the
agent's card.

This module is that function. It scores each agent on what the agent
DECLARES - the A2A card's skill tags, skill ids/names, examples and
description, read through `discovery.agent_scope` (the same
`web.a2a.build_agent_card` read that serves
``/a2a/<role>/.well-known/agent-card.json``, so the router cannot match on a
scope the served card does not show) - and on the workspace's registered
external A2A agents (`a2a_registry.read_external_agents`: description,
tags, examples), labelled ``external``.

The scoring is lexical and fixed: the query is tokenised (lower-cased,
stopwords out, plurals stemmed), and every query token found in a field
scores that field's weight once - tags 3, skill ids/names 3, examples 2,
description 1 - plus a small bonus for a two-word phrase of the query found
verbatim in the card. Ties go to an exposed agent, then to the name. Below
``min_score`` nothing is chosen and the result says so; the router never
invents a match - the meta-agent (a swarm) or the default chat role
handles what no declared scope covers.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

METHOD = "lexical"
LOCAL = "local"
EXTERNAL = "external"

#: Field weights - what a hit in each card field is worth. Tags and skill
#: ids/names are what an author writes FOR a router; an example is a sample
#: request; the description is prose and matches loosely, so it counts least.
WEIGHT_TAGS = 3
WEIGHT_SKILLS = 3
WEIGHT_EXAMPLES = 2
WEIGHT_DESCRIPTION = 1
#: A two-word phrase of the query found verbatim in the card, per phrase.
PHRASE_BONUS = 1
PHRASE_BONUS_CAP = 3

NO_MATCH_WHY = ("no agent's declared scope matches; the meta-agent (swarm) "
                "or the default chat role handles it")

STOPWORDS = frozenset("""
a about above after again against all also am an and any are as at be because
been before being below between both but by can could did do does doing done
down during each few for from further had has have having he her here hers
him his how i if in into is it its itself just let me might more most must my
no nor not of off on once only or other our ours out over own please same she
should so some such than that the their theirs them then there these they
this those through to too under until up us very was we were what when where
which while who whom why will with would you your yours
""".split())

_TOKEN_RE = re.compile(r"[a-z0-9][a-z0-9_\-]*")


def _stem(tok: str) -> str:
    """Plural stemming only - enough that ``vendors`` meets ``vendor`` and
    ``queries`` meets ``query`` without a stemmer that also folds ``data`` to
    ``dat``. Deliberately conservative: a wrong fold is a wrong match."""
    if len(tok) <= 3:
        return tok
    if tok.endswith("ies"):
        return tok[:-3] + "y"
    if tok.endswith(("sses", "xes", "ches", "shes")):
        return tok[:-2]
    # `status`, `analysis`, `basis`, `chaos`: a trailing s after a vowel
    # cluster is the word, not a plural (`statu` printed in a rehearsal's
    # tokens line, 2026-09-02). Cards stem the same way, so matching held;
    # the printed token was wrong.
    if tok.endswith("s") and not tok.endswith(("ss", "us", "is", "os")):
        return tok[:-1]
    return tok


def tokenize(text: Any) -> list[str]:
    """Lower-cased, stopword-free, plural-stemmed tokens in order, deduplicated."""
    seen: dict[str, None] = {}
    for raw in _TOKEN_RE.findall(str(text or "").lower()):
        if raw in STOPWORDS:
            continue
        tok = _stem(raw)
        if len(tok) < 2 or tok in STOPWORDS:
            continue
        seen.setdefault(tok, None)
    return list(seen)


def _phrases(text: Any) -> list[str]:
    """Consecutive two-word phrases of the query after stopword removal, in
    the stemmed form the card text is compared in."""
    toks = tokenize(text)
    return [f"{a} {b}" for a, b in zip(toks, toks[1:])]


def _stemmed_text(text: Any) -> str:
    """Card text in the same normalised form as the query tokens, so a
    phrase comparison is plural-safe on both sides."""
    return " ".join(_stem(t) for t in _TOKEN_RE.findall(str(text or "").lower()))


@dataclass
class Candidate:
    agent: str
    kind: str
    score: int
    matched: list[str] = field(default_factory=list)
    why: str = ""
    exposed: bool = False
    name: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"agent": self.agent, "kind": self.kind, "score": self.score,
                "matched": list(self.matched), "why": self.why,
                "exposed": self.exposed, "name": self.name}


@dataclass
class RouteResult:
    query: str
    candidates: list[Candidate]
    chosen: Optional[str]
    why: str
    method: str = METHOD
    min_score: int = 1
    tokens: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"query": self.query, "method": self.method,
                "tokens": list(self.tokens), "min_score": self.min_score,
                "chosen": self.chosen, "why": self.why,
                "candidates": [c.to_dict() for c in self.candidates]}


# ---------------------------------------------------------------------------
# The scope catalog - what there is to route to
# ---------------------------------------------------------------------------

def _entry(agent: str, kind: str, *, name: str = "", description: str = "",
           tags: Iterable[str] = (), skill_ids: Iterable[str] = (),
           skill_names: Iterable[str] = (), examples: Iterable[str] = (),
           exposed: bool = False) -> dict[str, Any]:
    return {"agent": agent, "kind": kind, "name": name or agent,
            "description": description or "",
            "tags": [str(t) for t in tags if t],
            "skill_ids": [str(s) for s in skill_ids if s],
            "skill_names": [str(s) for s in skill_names if s],
            "examples": [str(e) for e in examples if e],
            "exposed": bool(exposed)}


def external_entry(raw: dict[str, Any]) -> Optional[dict[str, Any]]:
    """One ``external-agents.yaml`` entry in the router's shape, or None when
    it has no name. An external agent is registered to be called, so it
    ranks as exposed for tie-breaking."""
    name = str(raw.get("name") or "").strip()
    if not name:
        return None
    return _entry(name, EXTERNAL, name=name,
                  description=str(raw.get("description") or ""),
                  tags=raw.get("tags") or [], examples=raw.get("examples") or [],
                  exposed=True)


def local_entry(role: str, scope: dict[str, Any], name: str = "") -> dict[str, Any]:
    """One `discovery.agent_scope` result in the router's shape."""
    return _entry(role, LOCAL, name=name or role,
                  description=scope.get("description") or "",
                  tags=scope.get("tags") or [], skill_ids=scope.get("skills") or [],
                  skill_names=scope.get("skill_names") or [],
                  examples=scope.get("examples") or [],
                  exposed=bool(scope.get("exposed")))


def scope_entries(workspace: Optional[str] = None, *,
                  include_external: bool = True) -> list[dict[str, Any]]:
    """Every routable scope: the local roles a run may name (the same
    roster as ``aicore list-agents``), each read through
    `discovery.agent_scope`, plus the workspace's external A2A registry.

    A role whose card cannot be read contributes its role name and nothing
    else (the scope reader records the error; a listing never raises). The
    external registry is read only when a workspace is selected, since the
    file lives under the workspace home.
    """
    from ioagentfarm.engine.discovery import agent_scope
    from ioagentfarm.engine.workspaces import get_agent_name, list_bundled_agents
    entries: list[dict[str, Any]] = []
    for role in sorted(set(list_bundled_agents())):
        try:
            name = get_agent_name(role)
        except Exception:  # noqa: BLE001 - a name is a courtesy
            name = role
        entries.append(local_entry(role, agent_scope(role, workspace or ""), name))
    if include_external:
        try:
            from ioagentfarm.engine.a2a_registry import read_external_agents
            for raw in read_external_agents(workspace):
                ext = external_entry(raw)
                if ext is not None:
                    entries.append(ext)
        except Exception:  # noqa: BLE001 - no workspace, no registry: nothing to add
            pass
    return entries


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------

def _field_hits(tokens: list[str], values: Iterable[str]) -> list[str]:
    """Query tokens present in the tokenised field, in query order."""
    have: set[str] = set()
    for value in values:
        have.update(tokenize(value))
    return [t for t in tokens if t in have]


def score_entry(query: str, entry: dict[str, Any]) -> Candidate:
    """Score ONE scope entry against the query, explaining every point."""
    tokens = tokenize(query)
    score = 0
    matched: list[str] = []
    parts: list[str] = []

    def take(label: str, hits: list[str], weight: int) -> None:
        nonlocal score
        if not hits:
            return
        score += weight * len(hits)
        for h in hits:
            if h not in matched:
                matched.append(h)
        parts.append(f"{label}: {', '.join(hits)} (+{weight * len(hits)})")

    take("tags", _field_hits(tokens, entry.get("tags") or []), WEIGHT_TAGS)
    take("skills", _field_hits(tokens, list(entry.get("skill_ids") or [])
                               + list(entry.get("skill_names") or [])), WEIGHT_SKILLS)
    take("examples", _field_hits(tokens, entry.get("examples") or []), WEIGHT_EXAMPLES)
    take("description", _field_hits(tokens, [entry.get("description") or ""]),
         WEIGHT_DESCRIPTION)

    # Phrase bonus: a two-word phrase of the query found verbatim in any card
    # text. Small and capped - it separates "last quarter" from "quarter", it
    # does not outrank a tag.
    card_text = " | ".join(_stemmed_text(v) for v in (
        [entry.get("description") or ""] + list(entry.get("examples") or [])
        + list(entry.get("tags") or []) + list(entry.get("skill_names") or [])))
    phrase_hits = [p for p in _phrases(query) if p in card_text]
    if phrase_hits:
        bonus = min(PHRASE_BONUS * len(phrase_hits), PHRASE_BONUS_CAP)
        score += bonus
        parts.append(f"phrase: {', '.join(repr(p) for p in phrase_hits)} (+{bonus})")

    why = "; ".join(parts) if parts else "no declared term of this agent appears in the query"
    return Candidate(agent=entry["agent"], kind=entry.get("kind") or LOCAL,
                     score=score, matched=matched, why=why,
                     exposed=bool(entry.get("exposed")), name=entry.get("name") or entry["agent"])


def route(query: str, workspace: Optional[str] = None, *, top: int = 3,
          min_score: int = 1, include_external: bool = True,
          entries: Optional[list[dict[str, Any]]] = None) -> RouteResult:
    """Rank the routable agents for *query*; choose the best if it clears
    ``min_score``. ``entries`` overrides the catalog (tests, embedders); by
    default it is `scope_entries` for *workspace*.

    Deterministic: the same query over the same cards yields the same
    result, and every point in ``why`` names the field and the term that
    earned it. Ties: higher score, then an exposed agent over one that is
    not, then the agent name.
    """
    query = " ".join(str(query or "").split())
    if entries is None:
        entries = scope_entries(workspace, include_external=include_external)
    elif not include_external:
        entries = [e for e in entries if e.get("kind") != EXTERNAL]
    scored = [score_entry(query, e) for e in entries]
    scored.sort(key=lambda c: (-c.score, not c.exposed, c.agent))
    top = max(1, int(top or 1))
    min_score = max(0, int(min_score))
    candidates = scored[:top]
    if candidates and candidates[0].score >= min_score and candidates[0].score > 0:
        best = candidates[0]
        return RouteResult(query=query, candidates=candidates, chosen=best.agent,
                           why=best.why, min_score=min_score, tokens=tokenize(query))
    return RouteResult(query=query, candidates=candidates, chosen=None,
                       why=NO_MATCH_WHY, min_score=min_score, tokens=tokenize(query))
