"""Binary-safe encoding for DB-backed workspace content.

Agent workspaces, skills and workflows are stored as ``{path: text}`` JSON
blobs. Everything was read with ``errors="replace"``, which is lossless for
markdown and silently destructive for anything else: a PNG in a skill's
``assets/``, an ``.xlsx`` fixture, a font. The file came back a different size,
full of U+FFFD, with no error anywhere in the chain — the skill just stopped
working on whatever host had hydrated from the database.

The map stays ``str -> str`` (JSON has no bytes, and changing the shape would
mean migrating every existing row). Binary files are base64-encoded behind a
sentinel prefix instead.

**Why the sentinel cannot collide with real text.** It starts with NUL, which
cannot appear in a text file we would have decoded as text — and to be exact
rather than nearly-exact, :func:`encode_file` treats *any* content starting
with NUL as binary, so a file that would be ambiguous is never stored as text
in the first place. Round-tripping is therefore total, not probabilistic.
"""
from __future__ import annotations

import base64
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

#: Marks a base64 payload. NUL-prefixed so it cannot begin a text file.
BINARY_PREFIX = "\x00b64:"

#: Base64 inflates by ~33%, and these blobs live in a single DB column read on
#: every hydrate. A file above this is skipped WITH A NAMED WARNING rather than
#: quietly dropped or silently bloating every read.
MAX_BYTES = 2 * 1024 * 1024


def is_binary(value: str) -> bool:
    return value.startswith(BINARY_PREFIX)


def encode_file(path: Path) -> str | None:
    """File content for a ``files_json`` blob, or ``None`` to skip it.

    Text stays text — unchanged storage for every file that has ever worked.
    Anything that is not valid UTF-8 (or that would be ambiguous with the
    sentinel) is base64-encoded.
    """
    try:
        size = path.stat().st_size
    except OSError:
        return None
    if size > MAX_BYTES:
        logger.warning(
            "skipping %s in the DB snapshot: %.1f MB exceeds the %.0f MB "
            "per-file limit — it will not reach other hosts",
            path, size / 1e6, MAX_BYTES / 1e6)
        return None
    try:
        text = path.read_text(encoding="utf-8")
        if not text.startswith("\x00"):
            return text
    except (UnicodeDecodeError, ValueError):
        pass
    except OSError:
        return None
    try:
        return BINARY_PREFIX + base64.b64encode(path.read_bytes()).decode("ascii")
    except OSError:
        return None


def decode_file(value: str) -> bytes | str:
    """The stored value as it should hit disk: ``bytes`` if it was binary."""
    if not is_binary(value):
        return value
    try:
        return base64.b64decode(value[len(BINARY_PREFIX):], validate=True)
    except (ValueError, TypeError):
        # Corrupt payload — better an empty file than a file of literal
        # base64 text that a tool would read as valid content.
        logger.warning("undecodable binary payload (%d chars) — writing empty",
                       len(value))
        return b""


def write_file(dest: Path, value: str) -> None:
    """Write one ``files_json`` entry, binary-aware. Creates parents."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    decoded = decode_file(value)
    if isinstance(decoded, bytes):
        dest.write_bytes(decoded)
    else:
        dest.write_text(decoded, encoding="utf-8")
