"""A suite file: which agent, and the cases to put to it.

    name: cora_smoke            # optional; defaults to the file stem
    agent: cora                 # the role /api/chat/{agent} addresses
    user_id: eval               # optional; the person the turns run as
    cases:
      - id: identity
        input: "Who are you?"
        setup: ["an earlier turn", {input: "another"}]     # optional
        expect:
          contains: ["Core Assistant"]
          not_contains: ["$"]
          regex: "assist"
          json_path: {path: data.type, equals: scalar}
          max_seconds: 60
      - id: po_count                 # run_bench.py's golden shape, unchanged
        question: "How many POs?"    # `question` is an alias of `input`
        golden: {data_type: scalar, value: 48}

A ``turns:`` case (run_bench's shared-session shape) is accepted with its
last turn graded and the earlier ones sent as setup.

Loading REFUSES what it does not understand - an unknown ``expect`` key, a
case with no id, a duplicate id, a case with neither ``expect`` nor
``golden`` - naming the case, because a check that is silently never run is
a suite that passes for the wrong reason.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ioagentfarm.engine.eval.grading import EXPECT_KEYS


class SuiteError(ValueError):
    pass


@dataclass
class Case:
    id: str
    input: str
    expect: dict | None = None
    golden: dict | None = None
    setup: list[str] = field(default_factory=list)


@dataclass
class Suite:
    name: str
    agent: str
    cases: list[Case]
    user_id: str = "eval"
    path: str = ""


def _setup_turns(raw: Any, case_id: str) -> list[str]:
    out: list[str] = []
    for i, t in enumerate(raw or []):
        if isinstance(t, str):
            out.append(t)
        elif isinstance(t, dict) and (t.get("input") or t.get("question")):
            out.append(str(t.get("input") or t.get("question")))
        else:
            raise SuiteError(f"case '{case_id}': setup[{i}] must be a string or "
                             "{input: ...}")
    return out


def parse_suite(data: dict, *, name: str = "", path: str = "") -> Suite:
    if not isinstance(data, dict):
        raise SuiteError("a suite file is a mapping with 'agent' and 'cases'")
    agent = str(data.get("agent") or "").strip()
    if not agent:
        raise SuiteError("suite has no 'agent' - the role /api/chat/{agent} addresses")
    raw_cases = data.get("cases")
    if not isinstance(raw_cases, list) or not raw_cases:
        raise SuiteError("suite has no 'cases' (a non-empty list)")
    cases: list[Case] = []
    seen: set[str] = set()
    for i, rc in enumerate(raw_cases):
        if not isinstance(rc, dict):
            raise SuiteError(f"cases[{i}] must be a mapping")
        cid = str(rc.get("id") or "").strip()
        if not cid:
            raise SuiteError(f"cases[{i}] has no 'id'")
        if cid in seen:
            raise SuiteError(f"duplicate case id '{cid}'")
        seen.add(cid)
        setup: list[str] = []
        text = rc.get("input") or rc.get("question")
        golden = rc.get("golden")
        expect = rc.get("expect")
        if rc.get("turns"):
            turns = rc["turns"]
            if not isinstance(turns, list) or not turns:
                raise SuiteError(f"case '{cid}': 'turns' must be a non-empty list")
            setup = _setup_turns(turns[:-1], cid)
            last = turns[-1] if isinstance(turns[-1], dict) else {"input": turns[-1]}
            text = last.get("input") or last.get("question")
            golden = golden or last.get("golden")
            expect = expect or last.get("expect")
        setup = setup + _setup_turns(rc.get("setup"), cid)
        if not text or not str(text).strip():
            raise SuiteError(f"case '{cid}' has no 'input'")
        if expect is None and golden is None:
            raise SuiteError(f"case '{cid}' declares neither 'expect' nor 'golden'")
        if expect is not None:
            if not isinstance(expect, dict):
                raise SuiteError(f"case '{cid}': 'expect' must be a mapping")
            unknown = sorted(set(expect) - set(EXPECT_KEYS))
            if unknown:
                raise SuiteError(f"case '{cid}': unknown expect key(s) {unknown}; "
                                 f"legal keys: {', '.join(EXPECT_KEYS)}")
        if golden is not None and not isinstance(golden, dict):
            raise SuiteError(f"case '{cid}': 'golden' must be a mapping")
        cases.append(Case(id=cid, input=str(text), expect=expect, golden=golden,
                          setup=setup))
    return Suite(name=str(data.get("name") or name or "suite"), agent=agent,
                 cases=cases, user_id=str(data.get("user_id") or "eval"),
                 path=path)


def load_suite(path: str | Path) -> Suite:
    import yaml

    p = Path(path)
    if not p.is_file():
        raise SuiteError(f"no suite file at {p}")
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise SuiteError(f"{p}: not valid YAML ({exc})")
    return parse_suite(data, name=p.stem, path=str(p))
