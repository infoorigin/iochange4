"""Grading: does one recorded output satisfy what the case expects.

Two graders, one contract - ``(passed, reason)`` with ``reason == "ok"`` on a
pass and a sentence naming the first failed check otherwise:

* :func:`grade` is the GOLDEN grader lifted unchanged out of
  ``benchmarks/queryngine/run_bench.py``: it compares the v1 response
  envelope of a data agent against ``golden: {data_type, value | rows_*}``.
  ``run_bench.py`` imports it from here, so the benchmark and the eval runner
  cannot disagree about what a golden case means.
* :func:`check_expect` is the TEXT grader for any agent: ``contains``,
  ``not_contains``, ``regex``, ``json_path`` and ``max_seconds`` over the
  reply text and the turn's duration.

Neither reads a model, a server or a clock: a grader that needed any of them
could not grade a replay the same way it graded the live run.
"""
from __future__ import annotations

import json
import re
from typing import Any

ENVELOPE_RE = re.compile(r"```(?:json)?\s*(\{.*\})\s*```", re.DOTALL)

#: The keys :func:`check_expect` understands. Anything else in ``expect:`` is
#: refused by the suite loader with this list, because a misspelt key would
#: otherwise be a check that silently never runs.
EXPECT_KEYS: tuple[str, ...] = ("contains", "not_contains", "regex", "json_path",
                                "max_seconds", "case_sensitive")


def extract_envelope(content: str) -> dict | None:
    """Pull the first fenced JSON block out of a reply."""
    m = ENVELOPE_RE.search(content or "")
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return None


def _coerce_number(x: Any) -> Any:
    """DuckDB may return decimals as strings; normalize for comparison."""
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        try:
            return float(x.replace(",", "").replace("$", ""))
        except ValueError:
            return x
    return x


def _rows_match(got: list, expected: list, ordered: bool) -> bool:
    """Compare row sets. Rows are 2-element [label, number] by current spec."""
    if len(got) != len(expected):
        return False

    def norm(r):
        if not isinstance(r, (list, tuple)) or len(r) < 2:
            return (str(r), 0.0)
        return (str(r[0]).strip(), _coerce_number(r[1]))

    g = [norm(r) for r in got]
    e = [norm(r) for r in expected]
    if ordered:
        return g == e
    return sorted(g) == sorted(e)


def grade(envelope: dict | None, golden: dict) -> tuple[bool, str]:
    """Return (passed, reason) for a v1 envelope against a golden record."""
    if envelope is None:
        return False, "no envelope in response"
    data = envelope.get("data")

    if golden.get("data_is_null"):
        if data is not None:
            return False, f"expected data: null, got {type(data).__name__}"
        if golden.get("evidence_is_null") and envelope.get("evidence") is not None:
            return False, "expected evidence: null"
        if golden.get("insight_nonempty"):
            insight = envelope.get("insight") or ""
            if not insight.strip():
                return False, "expected non-empty insight"
        return True, "ok"

    dtype = golden.get("data_type")
    if data is None:
        return False, f"expected data_type={dtype}, got null"
    if data.get("type") != dtype:
        return False, f"expected data.type={dtype}, got {data.get('type')}"

    if dtype == "scalar":
        got = _coerce_number(data.get("value"))
        want = _coerce_number(golden.get("value"))
        if got != want:
            return False, f"scalar mismatch: got {got}, want {want}"
        return True, "ok"

    if dtype == "table":
        rows = data.get("rows") or []
        if "rows_ordered" in golden:
            ok = _rows_match(rows, golden["rows_ordered"], ordered=True)
            if not ok:
                return False, f"ordered rows mismatch: got {rows}, want {golden['rows_ordered']}"
        elif "rows_unordered" in golden:
            ok = _rows_match(rows, golden["rows_unordered"], ordered=False)
            if not ok:
                return False, f"unordered rows mismatch: got {rows}, want {golden['rows_unordered']}"
        return True, "ok"

    return False, f"unknown data_type: {dtype}"


def llm_call_count(envelope: dict | None) -> int | None:
    """Queries referenced in evidence.queries + 1 for the compose round - the
    cheapest proxy for tool-using LLM rounds the envelope alone offers."""
    if not envelope:
        return None
    ev = envelope.get("evidence")
    if ev is None:
        return 1
    q = ev.get("queries") or []
    return len(q) + 1


# -- the text grader ----------------------------------------------

def _as_list(v: Any) -> list[str]:
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v]
    return [str(v)]


def _json_in(output: str) -> Any:
    """The reply as JSON: the whole text if it parses, else its first fenced
    block, else None."""
    text = (output or "").strip()
    if text:
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            pass
    return extract_envelope(output)


_PATH_TOKEN = re.compile(r"([^.\[\]]+)|\[(\d+)\]")


def resolve_path(doc: Any, path: str) -> tuple[bool, Any]:
    """``data.rows[0][1]`` -> ``(found, value)``. A missing key is ``(False, None)``."""
    cur = doc
    for m in _PATH_TOKEN.finditer(path or ""):
        key, idx = m.group(1), m.group(2)
        if idx is not None:
            if not isinstance(cur, (list, tuple)) or int(idx) >= len(cur):
                return False, None
            cur = cur[int(idx)]
        else:
            if not isinstance(cur, dict) or key not in cur:
                return False, None
            cur = cur[key]
    return True, cur


def check_expect(output: str, duration_s: float | None,
                 expect: dict) -> tuple[bool, str]:
    """Every check in ``expect`` against one reply. Reasons are joined with
    '; ' so a case that fails three ways says so once."""
    if not isinstance(expect, dict):
        return False, "expect must be a mapping"
    unknown = sorted(set(expect) - set(EXPECT_KEYS))
    if unknown:
        return False, (f"unknown expect key(s) {unknown}; legal keys: "
                       f"{', '.join(EXPECT_KEYS)}")
    text = output or ""
    sensitive = bool(expect.get("case_sensitive", False))
    hay = text if sensitive else text.lower()
    failures: list[str] = []

    for needle in _as_list(expect.get("contains")):
        n = needle if sensitive else needle.lower()
        if n not in hay:
            failures.append(f"contains: {needle!r} not found in output")
    for needle in _as_list(expect.get("not_contains")):
        n = needle if sensitive else needle.lower()
        if n in hay:
            failures.append(f"not_contains: {needle!r} found in output")

    pattern = expect.get("regex")
    if pattern:
        try:
            if re.search(str(pattern), text, re.DOTALL) is None:
                failures.append(f"regex: no match for {pattern!r}")
        except re.error as exc:
            failures.append(f"regex: invalid pattern {pattern!r} ({exc})")

    jp = expect.get("json_path")
    if jp is not None:
        if not isinstance(jp, dict) or "path" not in jp:
            failures.append("json_path: must be a mapping with 'path' and 'equals'")
        else:
            doc = _json_in(text)
            if doc is None:
                failures.append("json_path: no JSON in output")
            else:
                found, got = resolve_path(doc, str(jp["path"]))
                if not found:
                    failures.append(f"json_path: {jp['path']} not present")
                elif "equals" in jp and _coerce_number(got) != _coerce_number(jp["equals"]):
                    failures.append(
                        f"json_path: {jp['path']} = {got!r}, want {jp['equals']!r}")

    limit = expect.get("max_seconds")
    if limit is not None:
        try:
            lim = float(limit)
        except (TypeError, ValueError):
            failures.append(f"max_seconds: not a number ({limit!r})")
        else:
            if duration_s is None:
                failures.append("max_seconds: the turn has no duration")
            elif duration_s > lim:
                failures.append(f"max_seconds: took {duration_s:.1f}s, limit {lim:g}s")

    if failures:
        return False, "; ".join(failures)
    return True, "ok"


def grade_case(output: str, duration_s: float | None, *,
               expect: dict | None = None, golden: dict | None = None,
               error: str = "") -> tuple[bool, str]:
    """One case, whichever grader(s) it declares. Both must pass when both
    are present. A server error with no output is its own reason."""
    if expect is None and golden is None:
        return False, "case declares neither expect nor golden"
    if error and not (output or "").strip():
        return False, f"server error: {error}"
    reasons: list[str] = []
    ok = True
    if golden is not None:
        p, r = grade(extract_envelope(output), golden)
        ok = ok and p
        if not p:
            reasons.append(r)
    if expect is not None:
        p, r = check_expect(output, duration_s, expect)
        ok = ok and p
        if not p:
            reasons.append(r)
    return ok, ("ok" if ok else "; ".join(reasons))
