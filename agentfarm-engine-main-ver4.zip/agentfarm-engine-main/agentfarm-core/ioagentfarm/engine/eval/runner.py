"""Run a suite: live against a served engine, or offline from a cassette.

THE ONE RULE: grading never sees which mode produced the turn. An executor
answers ``Turn(output, duration_s, error)`` for a case; :func:`run_suite`
grades every turn with :func:`grading.grade_case` and, if asked, writes the
turns to a cassette. The replay executor reads the same cassette back and
returns the same turns, so ``--live --record x`` followed by ``--replay x``
grades identically by construction - including ``max_seconds``, which is
graded against the RECORDED duration.

The live executor drives ``POST /api/chat/{agent}`` the way
``benchmarks/queryngine/run_bench.py`` does, with a fresh ``conversation_id``
per case so a case's setup turns share one thread and two runs never share a
memory. It presents the engine rail credential (``security/rail.py``) when
one is configured.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Protocol

from ioagentfarm.engine.eval.grading import grade_case
from ioagentfarm.engine.eval.suite import Case, Suite

MODES = ("live", "replay")


@dataclass
class Turn:
    output: str = ""
    duration_s: float | None = None
    error: str = ""
    # setup turns' outputs, kept for the record but never graded
    setup_outputs: list[str] = field(default_factory=list)


@dataclass
class CaseResult:
    suite: str
    case_id: str
    mode: str
    passed: bool
    reason: str
    duration_s: float | None
    output: str
    output_sha: str
    error: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


class Executor(Protocol):
    mode: str

    def run(self, suite: Suite, case: Case) -> Turn: ...


class MissingRecording(KeyError):
    pass


def sha(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# -- live ---------------------------------------------------------

class LiveExecutor:
    """One HTTP turn per setup line, then the graded input, on one thread."""

    mode = "live"

    def __init__(self, url: str, *, client=None, timeout: float = 300.0,
                 headers: dict | None = None):
        import httpx

        self.url = url.rstrip("/")
        self.timeout = timeout
        if headers is None:
            try:
                from ioagentfarm.security.rail import engine_auth_headers
                headers = engine_auth_headers()
            except Exception:       # noqa: BLE001 - the rail is optional
                headers = {}
        self.headers = dict(headers)
        self._client = client or httpx.Client(timeout=timeout)

    def _post(self, agent: str, content: str, user_id: str,
              conversation_id: str) -> tuple[str, float, str]:
        payload = {"content": content, "agent": agent, "sender_id": user_id,
                   "user_id": user_id, "conversation_id": conversation_id}
        t0 = time.time()
        r = self._client.post(f"{self.url}/api/chat/{agent}", json=payload,
                              headers=self.headers, timeout=self.timeout)
        dt = time.time() - t0
        if r.status_code >= 400:
            return "", dt, f"HTTP {r.status_code}: {r.text[:500]}"
        try:
            body = r.json()
        except ValueError:
            return "", dt, f"non-JSON reply: {r.text[:200]}"
        if not isinstance(body, dict):
            return "", dt, f"unexpected reply shape: {type(body).__name__}"
        content_out = body.get("content") or ""
        err = body.get("error") or ""
        return str(content_out), dt, (str(err) if err else "")

    def run(self, suite: Suite, case: Case) -> Turn:
        conv = f"eval-{suite.name}-{case.id}-{uuid.uuid4().hex[:8]}"
        setup_outputs: list[str] = []
        for line in case.setup:
            out, _dt, err = self._post(suite.agent, line, suite.user_id, conv)
            if err and not out:
                return Turn(output="", duration_s=None,
                            error=f"setup turn failed: {err}",
                            setup_outputs=setup_outputs)
            setup_outputs.append(out)
        out, dt, err = self._post(suite.agent, case.input, suite.user_id, conv)
        return Turn(output=out, duration_s=round(dt, 3), error=err,
                    setup_outputs=setup_outputs)


# -- replay -------------------------------------------------------

def read_cassette(path: str | Path) -> dict[str, dict]:
    """``{case_id: record}``; a later line for the same case wins."""
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"no cassette at {p}")
    out: dict[str, dict] = {}
    with p.open(encoding="utf-8") as fh:
        for n, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{p}:{n}: not JSON ({exc})")
            if not isinstance(rec, dict) or not rec.get("case_id"):
                raise ValueError(f"{p}:{n}: a cassette line needs a case_id")
            out[str(rec["case_id"])] = rec
    return out


class ReplayExecutor:
    """Answers each case from the cassette; no server, no model."""

    mode = "replay"

    def __init__(self, cassette: str | Path):
        self.path = str(cassette)
        self.records = read_cassette(cassette)

    def run(self, suite: Suite, case: Case) -> Turn:
        rec = self.records.get(case.id)
        if rec is None:
            raise MissingRecording(case.id)
        dur = rec.get("duration_s")
        return Turn(output=str(rec.get("output") or ""),
                    duration_s=float(dur) if dur is not None else None,
                    error=str(rec.get("error") or ""),
                    setup_outputs=list(rec.get("setup_outputs") or []))


def cassette_record(suite: Suite, case: Case, turn: Turn) -> dict:
    """One cassette line. Everything a replay needs and nothing a grader
    would read differently across the two modes."""
    return {
        "suite": suite.name, "case_id": case.id, "agent": suite.agent,
        "input": case.input, "setup": list(case.setup),
        "setup_outputs": list(turn.setup_outputs),
        "output": turn.output, "duration_s": turn.duration_s,
        "error": turn.error, "recorded_at": _now(),
    }


# -- the run ------------------------------------------------------

def run_suite(suite: Suite, executor: Executor, *,
              record_to: str | Path | None = None,
              only: set[str] | None = None,
              on_case: Callable[[CaseResult], None] | None = None) -> list[CaseResult]:
    results: list[CaseResult] = []
    sink = None
    if record_to:
        Path(record_to).parent.mkdir(parents=True, exist_ok=True)
        sink = open(record_to, "w", encoding="utf-8")
    try:
        for case in suite.cases:
            if only and case.id not in only:
                continue
            try:
                turn = executor.run(suite, case)
            except MissingRecording:
                turn = None
                res = CaseResult(suite.name, case.id, executor.mode, False,
                                 f"no recording for case '{case.id}' in "
                                 f"{getattr(executor, 'path', 'the cassette')}",
                                 None, "", sha(""))
            except Exception as exc:    # noqa: BLE001 - one case, not the run
                turn = None
                res = CaseResult(suite.name, case.id, executor.mode, False,
                                 f"executor error: {type(exc).__name__}: {exc}",
                                 None, "", sha(""))
            if turn is not None:
                passed, reason = grade_case(turn.output, turn.duration_s,
                                            expect=case.expect, golden=case.golden,
                                            error=turn.error)
                res = CaseResult(suite.name, case.id, executor.mode, passed, reason,
                                 turn.duration_s, turn.output, sha(turn.output),
                                 error=turn.error)
                if sink is not None:
                    sink.write(json.dumps(cassette_record(suite, case, turn),
                                          ensure_ascii=True) + "\n")
                    sink.flush()
            results.append(res)
            if on_case is not None:
                on_case(res)
    finally:
        if sink is not None:
            sink.close()
    return results


def tally(results: list[CaseResult]) -> dict:
    passed = sum(1 for r in results if r.passed)
    return {"total": len(results), "passed": passed,
            "failed": len(results) - passed}
