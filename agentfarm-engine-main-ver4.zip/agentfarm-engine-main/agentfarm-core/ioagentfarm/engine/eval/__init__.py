"""Offline eval: suites, a live or replay runner, graders and a result store.

    from ioagentfarm.engine.eval import load_suite, run_suite, LiveExecutor, ReplayExecutor

See docs/reference/eval-and-feedback.md and ``aicore eval --help``.
"""
from ioagentfarm.engine.eval.grading import (check_expect, extract_envelope,
                                             grade, grade_case)
from ioagentfarm.engine.eval.runner import (CaseResult, LiveExecutor,
                                            ReplayExecutor, Turn,
                                            cassette_record, read_cassette,
                                            run_suite, tally)
from ioagentfarm.engine.eval.suite import Case, Suite, SuiteError, load_suite, parse_suite

__all__ = [
    "Case", "CaseResult", "LiveExecutor", "ReplayExecutor", "Suite", "SuiteError",
    "Turn", "cassette_record", "check_expect", "extract_envelope", "grade",
    "grade_case", "load_suite", "parse_suite", "read_cassette", "run_suite", "tally",
]
