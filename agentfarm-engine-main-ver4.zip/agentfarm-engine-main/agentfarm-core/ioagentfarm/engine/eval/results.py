"""Persisted eval results: ``eval_results``, created by ``Store.init()``.

One row per case per run. Every row of one run shares ``created_at``, which
is what ``latest`` groups on - a run is the set of rows written together.
"""
from __future__ import annotations

from datetime import datetime, timezone

from ioagentfarm.engine.eval.runner import CaseResult

_COLS = "id, suite, case_id, mode, passed, reason, duration_s, output_sha, created_at"


def _now() -> str:
    # Microseconds: `created_at` is the RUN's identity (every row of one run
    # shares it), and two runs a second apart would otherwise merge.
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def persist(store, results: list[CaseResult], *, created_at: str | None = None) -> str:
    """Write every result under one timestamp; returns it."""
    stamp = created_at or _now()
    with store._tx() as cur:
        for r in results:
            cur.execute(store._q(
                "INSERT INTO eval_results (suite, case_id, mode, passed, reason,"
                " duration_s, output_sha, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"),
                (r.suite, r.case_id, r.mode, 1 if r.passed else 0, r.reason,
                 r.duration_s, r.output_sha, stamp))
    return stamp


def _rows(store, sql: str, params: tuple) -> list[dict]:
    with store._tx() as cur:
        cur.execute(store._q(sql), params)
        return [dict(r) for r in cur.fetchall()]


def list_suites(store) -> list[dict]:
    """Every suite with a result, and its LATEST run's tally."""
    rows = _rows(store, f"SELECT {_COLS} FROM eval_results ORDER BY suite, created_at, id", ())
    latest: dict[str, dict] = {}
    for r in rows:
        s = latest.setdefault(r["suite"], {"suite": r["suite"], "created_at": "",
                                           "mode": "", "runs": set(), "cases": []})
        s["runs"].add(r["created_at"])
        if r["created_at"] > s["created_at"]:
            s["created_at"] = r["created_at"]
            s["mode"] = r["mode"]
            s["cases"] = []
        if r["created_at"] == s["created_at"]:
            s["cases"].append(r)
    out = []
    for s in latest.values():
        cases = s["cases"]
        out.append({"suite": s["suite"], "last_run": s["created_at"],
                    "mode": s["mode"], "runs": len(s["runs"]),
                    "total": len(cases),
                    "passed": sum(1 for c in cases if int(c["passed"]))})
    return sorted(out, key=lambda x: x["suite"])


def show(store, suite: str, *, all_runs: bool = False) -> list[dict]:
    """The latest run's rows for a suite (or every run, newest first)."""
    rows = _rows(store, f"SELECT {_COLS} FROM eval_results WHERE suite=?"
                        " ORDER BY created_at DESC, id ASC", (suite,))
    if not rows or all_runs:
        return rows
    stamp = rows[0]["created_at"]
    return [r for r in rows if r["created_at"] == stamp]
