"""The engine package - lazy.

Every name below used to be imported eagerly, so `from ioagentfarm.engine
import workspace_env` - the CLI's first line - paid for models (pydantic
class construction), db, store, learning, scheduler, loader, lint and
workspaces before any command ran: ~0.35s of a startup a person waits for
on every invocation. PEP 562: a name resolves when first read.
"""
from __future__ import annotations

import importlib

_EXPORTS = {
    "Workflow": ".models", "Step": ".models", "Role": ".models",
    "StepTemplate": ".models", "SandboxWorkflowConfig": ".models",
    "DbAdapter": ".db", "make_adapter": ".db",
    "Store": ".store",
    "LearningLifecycle": ".learning", "LearningBackend": ".learning",
    "LearningStore": ".learning", "LearningLog": ".learning",
    "render_step_prompt": ".scheduler",
    "validate_workflow": ".workflow_loader", "collect_workflow_errors": ".workflow_loader",
    "lint_workflow_dir": ".workflow_lint", "lint_workflow_text": ".workflow_lint",
    "LintResult": ".workflow_lint", "Finding": ".workflow_lint",
    "iobot_agent_workspace": ".workspaces", "ensure_iobot_agent": ".workspaces",
    "build_task_prompt": ".workspaces", "build_spawn_prompt": ".workspaces",
    "create_filtered_workspace": ".workspaces",
}
__all__ = sorted(_EXPORTS)


def __getattr__(name: str):
    mod = _EXPORTS.get(name)
    if mod is None:
        raise AttributeError(f"module 'ioagentfarm.engine' has no attribute {name!r}")
    value = getattr(importlib.import_module(mod, __name__), name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(set(globals()) | set(_EXPORTS))
