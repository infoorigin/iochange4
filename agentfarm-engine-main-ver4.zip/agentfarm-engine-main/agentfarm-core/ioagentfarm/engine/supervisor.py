"""Run supervisor — the self-healing layer that makes stuck runs impossible.

The production failure this kills
---------------------------------
A step's iobot subprocess dies SILENTLY (no traceback, rc unseen) leaving
``steps.status='running'`` forever; eventually the driver (Alex / the
``ioagentfarm run`` loop) exhausts its respawn budget or dies too. Result: a
run stuck 'running', steps stuck running/pending, and NO executor left. Every
pre-existing recovery layer (Fix-6 in-step retries, hard attempt cap, driver
respawn loop, web ``POST /resume``) assumes a *live invoker* — a human
operator had to run ``step-retry --crash-recovery`` + ``run-step`` by hand.

The supervisor closes that gap with DB-based heartbeats (works across pods —
PID checks don't) and a periodic sweep:

1. **Step reaping** — a 'running' step whose ``heartbeat_at`` is stale
   (> ``IOF_SUPERVISOR_STEP_STALE_S``, default 180s; the run-step process
   beats every ~30s while its subprocess lives) is put through the exact
   same crash-recovery transition as ``step-retry --crash-recovery``
   (``Store.crash_recover_step`` — one implementation, two callers).
   Steps with NO heartbeat (legacy rows, code paths not yet wired) get a
   generous grace (``IOF_SUPERVISOR_NO_HEARTBEAT_GRACE_S``, default 900s)
   measured against ``updated_at``.

2. **Driver resurrection** — a run with runnable pending steps, no live
   running step, and a stale ``driver_heartbeat_at``
   (> ``IOF_SUPERVISOR_DRIVER_STALE_S``, default 300s) gets its driver
   re-spawned via the same machinery as ``POST /api/run/{id}/resume``
   (``web.spawn.spawn_run`` against the EXISTING run). BOUNDED: the
   ``runs.supervisor_resumes`` counter caps resurrections at
   ``IOF_SUPERVISOR_MAX_RESUMES`` (default 5); beyond it the run is marked
   'failed' with reason ``supervisor_gave_up`` — bounded convergence, never
   infinite, the same philosophy as the hard attempt cap.

Every action emits a forensic event (``supervisor.step_reaped``,
``supervisor.driver_resumed``, ``supervisor.gave_up``) so the timeline shows
exactly what the supervisor did and why.

Where it runs
-------------
- ``ioagentfarm serve``: a lifespan asyncio task loops ``supervise_once``
  every ``IOF_SUPERVISOR_INTERVAL_S`` (default 60s). Kill-switch:
  ``IOF_SUPERVISOR=0``.
- ``ioagentfarm supervise [--once] [--interval N]``: CLI-only / cron
  deployments.
- The blocking ``ioagentfarm run`` loop calls ``supervise_once`` scoped to
  its OWN run each drive-cycle iteration (with ``resume_drivers=False`` —
  the loop IS the driver) so pure-CLI runs self-heal stuck steps without
  ``serve``.

Idempotency: on a healthy system a sweep performs ZERO actions. Fresh
heartbeats are never touched; the sweep only converges broken state.

Multi-pod safety: heartbeats and counters live in the shared DB. The
driver-resume claim is an atomic conditional UPDATE (``WHERE
supervisor_resumes = <seen>``) so exactly one pod wins a given resume slot.
"""
from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SupervisorRunNotFound(LookupError):
    """A scoped sweep named a run this store does not contain.

    Distinct from "swept and found nothing to do": that is a health report,
    this is a configuration fault. Conflating them hid a supervisor pointed at
    an empty local SQLite while the runs lived in Postgres.
    """



# ---------------------------------------------------------------------------
# Tunables (read at call time so tests/env changes apply without reimport)
# ---------------------------------------------------------------------------

def _step_stale_s() -> float:
    return float(os.environ.get("IOF_SUPERVISOR_STEP_STALE_S", "180"))


def _no_heartbeat_grace_s() -> float:
    # Steps with a NULL heartbeat (legacy rows / not-yet-wired code paths)
    # get a generous grace against updated_at. Must comfortably exceed the
    # exec-step ceiling (IOF_EXEC_STEP_TIMEOUT_S, default 600) so a
    # heartbeat-less long exec is never falsely reaped.
    default = max(900.0, float(os.environ.get("IOF_EXEC_STEP_TIMEOUT_S", "600")) + 120.0)
    return float(os.environ.get("IOF_SUPERVISOR_NO_HEARTBEAT_GRACE_S", str(default)))


def _driver_stale_s() -> float:
    return float(os.environ.get("IOF_SUPERVISOR_DRIVER_STALE_S", "300"))


#: Silence from a CODE driver before it is presumed dead. Its own poll beats
#: the heartbeat every couple of seconds, so this is nothing like the agent
#: driver's 300 s - an LLM turn can legitimately take minutes; a poll loop
#: cannot.
#:
#: 60, NOT 30, AND THE NUMBER IS NOT FREE. The heartbeat is written at the
#: START of `next-step`, and then that same call sweeps the run and renders a
#: prompt per batch entry before it returns. So the age this threshold judges
#: is really "how long one poll took, plus the interval" - and if the
#: threshold is below what a poll can legitimately take, the supervisor
#: declares a live driver dead and spawns a second one against the run. On a
#: loaded shared PostgreSQL a fan-out poll doing several `render_step_prompt`
#: calls past 30 s is ordinary; past 60 s it is not.
#:
#: The other half of the guarantee is in `driver_api.poll_timeout_s`, which
#: caps the poll subprocess BELOW this value. A poll that cannot finish in
#: time is killed and retried - which writes a fresh heartbeat - rather than
#: being allowed to outlive the clock that is judging it. Raise this and the
#: poll cap follows; they cannot be chosen independently, which is why they
#: are one number and one derivation rather than two constants.
DEFAULT_CODE_DRIVER_STALE_S = 60.0


def code_driver_stale_s() -> float:
    """The code driver's staleness threshold. ONE implementation.

    It had three, byte-identical, in `driver_state`, the sweep's
    resurrection decision and that decision's own event payload - so a
    change to the default reached whichever of them the author happened to
    be reading. `status`, `watch`, `resume` and the sweep must agree about
    whether a driver is alive, or the operator is told to resume a run the
    sweep is about to resume for them.
    """
    try:
        return float(os.environ.get("IOF_SUPERVISOR_CODE_DRIVER_STALE_S")
                     or DEFAULT_CODE_DRIVER_STALE_S)
    except ValueError:
        return DEFAULT_CODE_DRIVER_STALE_S


def driver_state(run: dict, steps=None) -> dict:
    """Is the run's driver alive, by the same clock the sweeper uses?

    A run whose driver was killed reads `running` forever in `status` and
    `explain` (novice finding, round 3): nothing on those surfaces looked
    at `driver_heartbeat_at`. This is the read-only half of the
    supervisor's decision, so the two cannot disagree.
    """
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    hb = _parse_ts((run or {}).get("driver_heartbeat_at"))
    age = _age_s(now, hb)
    # The code driver heartbeats every poll (~2s); five minutes of silence
    # from it is a corpse, not a long model turn. The agent driver keeps
    # the sweeper's threshold - an LLM turn can legitimately take minutes.
    if (run or {}).get("driver") == "code":
        threshold = code_driver_stale_s()
    else:
        threshold = _driver_stale_s()
    running = [s for s in (steps or []) if s.get("status") == "running"]
    newest_step = None
    for s in running:
        a = _age_s(now, _parse_ts(s.get("heartbeat_at")))
        if a is not None and (newest_step is None or a < newest_step):
            newest_step = a
    is_code = (run or {}).get("driver") == "code"
    # A driver that has NEVER heartbeated is not thereby dead: a run two
    # seconds old was declared GONE with a resume line (novice, round 6).
    # Until the first heartbeat lands its age is measured from creation.
    if age is None:
        since_created = _age_s(now, _parse_ts((run or {}).get("created_at")))
        silent = since_created is None or since_created > threshold
    else:
        silent = age > threshold
    # The code driver heartbeats every poll WHILE a step runs, so a step's
    # own heartbeat cannot excuse it: killed mid-step it was called alive
    # for the step's 180 s window while every message said 30 s (novice,
    # round 6). The agent driver is blocked inside its exec during a step
    # and keeps the excuse.
    step_excuse = ((not is_code) and newest_step is not None
                   and newest_step <= _step_stale_s())
    stale = ((run or {}).get("status") == "running" and silent and not step_excuse)
    return {"heartbeat_age_s": None if age is None else round(age, 1),
            "threshold_s": threshold, "stale": bool(stale),
            "running_steps": [s.get("step_key") for s in running]}


def _pid_alive(pid: int) -> bool:
    """Is that process still running? Used to decide whether a TERMINAL run
    row is actually finished - an agent driver marks a run failed between
    attempts and keeps spending, so the row alone cannot answer it.

    Unknown answers FALSE: cancel then takes the ordinary "already concluded"
    path, which is the behaviour before this check existed. Never raises.
    """
    if not pid or pid <= 0:
        # A pid file holding 0 or a negative is nonsense, and on Windows
        # `psutil.pid_exists(0)` is TRUE - pid 0 is the System Idle Process,
        # which would make every cancel think a driver was alive.
        return False
    try:
        import psutil                       # present in the runtime stack
        return psutil.pid_exists(pid)
    except Exception:                       # noqa: BLE001 - fall through
        pass
    try:
        if os.name == "nt":
            import subprocess
            out = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                capture_output=True, text=True, timeout=10).stdout
            return str(pid) in out
        os.kill(pid, 0)
        return True
    except Exception:                       # noqa: BLE001
        return False


def _kill_pid_tree(pid: int) -> bool:
    """Did the process stop? Best effort, never raises.

    ASSERT THE POST-CONDITION, NOT THE TOOL'S RETURN CODE. This reported
    `r.returncode == 0` from `taskkill /PID <pid> /T /F` - and with `/T`, a
    child that has ALREADY EXITED makes taskkill exit non-zero (128 on a
    not-found pid). So cancel killed the driver and then told the operator
    "no pid on record": the run really stopped, the pid on disk was the one
    it killed, and `killed_pids` came back empty (certification round 7).
    That is the mirror image of the rounds-5-and-6 bug - then it claimed to
    have stopped a run that kept spending; here it disowns a kill that
    worked - and both come from trusting a proxy instead of the fact.

    The fact is whether the process is gone, so that is what is checked, on
    both platforms and after the signal either way.
    """
    import signal
    import subprocess
    try:
        if sys.platform.startswith("win"):
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True, text=True, timeout=20)
        else:
            try:
                os.killpg(os.getpgid(pid), signal.SIGTERM)
            except (ProcessLookupError, PermissionError, OSError):
                os.kill(pid, signal.SIGTERM)
    except Exception:  # noqa: BLE001 - the check below is the answer
        pass
    # A moment for the OS to reap it, then ask.
    for _ in range(10):
        if not _pid_alive(pid):
            return True
        try:
            import time as _t
            _t.sleep(0.1)
        except Exception:  # noqa: BLE001
            break
    return not _pid_alive(pid)


def cancel_run(store, root_path: Path, run_id: str, *, by: str,
               reason: str = "") -> Dict[str, Any]:
    """Stop a run for good: no retry, no resurrection, no further model calls.

    There was no verb for this (novice finding, round 6): an operator's
    tools for an unwanted run were `taskkill` - undone by the next sweep,
    up to IOF_SUPERVISOR_MAX_RESUMES times, each spending model calls -
    `step-skip` (refused when an artifact is declared) or waiting for
    `supervisor_gave_up`. This kills the detached driver when its pid is
    on record, fails every running step with the reason, fails the run,
    clears the heartbeat and writes `run.cancelled`; a failed run is not
    resurrected. `step-retry` re-opens a step if it was a mistake.

    Raises KeyError for an unknown run; returns ``{"already": status}``
    for a run that had already concluded.
    """
    run = store.get_run(run_id)
    # THE ROW IS NOT THE DRIVER. This returned "already failed - nothing to
    # cancel" (exit 0) for any terminal STATUS - and an agent driver marks a
    # run failed BETWEEN attempts and keeps driving. Measured twice in the
    # certification (rounds 5 and 6): `cancel` reported nothing to do while
    # the driver went on from 80 to 92 model calls in the next 45 seconds,
    # and on to 71 calls / $2.22 in the other run. The message reads as
    # "already stopped", a script believes exit 0, and only `taskkill` on the
    # pid in `logs/run.pid` actually stopped it.
    #
    # So a terminal row is only accepted as final when NO driver is alive.
    # The pid the run wrote is the authority - it was on disk the whole time
    # in the case where cancel claimed it had none.
    pid_file = Path(root_path) / "instances" / run_id / "logs" / "run.pid"
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        pid = None
    if run.get("status") in ("done", "failed") and not (
            pid and _pid_alive(pid)):
        return {"run_id": run_id, "already": run["status"], "killed_pids": [],
                "stopped_steps": []}
    killed: list = []
    if pid and _kill_pid_tree(pid):
        killed.append(pid)
    stopped: list = []
    note = f"cancelled by {by}" + (f" - {reason}" if reason else "")
    for s in store.list_steps(run_id):
        if s.get("status") == "running":
            try:
                store.set_step_output(run_id, s["step_key"], "failed",
                                      f"STATUS: failed\nOUTPUT: {note}")
                stopped.append(s["step_key"])
            except Exception:  # noqa: BLE001
                logger.debug("cancel: could not fail step %s", s.get("step_key"), exc_info=True)
    store.set_run_status(run_id, "failed")
    try:
        store.clear_driver_heartbeat(run_id)
    except Exception:  # noqa: BLE001
        pass
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
        get_forensics(Path(root_path)).emit(
            run_id=run_id, event_type="run.cancelled", severity=SEVERITY_WARN,
            step_key=None, role=None, message=note,
            payload={"by": by, "reason": reason, "killed_pids": killed,
                     "stopped_steps": stopped})
    except Exception:  # noqa: BLE001
        pass
    return {"run_id": run_id, "status": "failed", "killed_pids": killed,
            "stopped_steps": stopped, "by": by, "reason": reason}


def _max_resumes() -> int:
    return int(os.environ.get("IOF_SUPERVISOR_MAX_RESUMES", "5"))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_ts(value: Any) -> Optional[datetime]:
    """Parse a stored timestamp into an aware UTC datetime, or None.

    The store writes ``datetime.now(timezone.utc).isoformat()`` (TEXT) on
    both SQLite and PostgreSQL, but be defensive: tolerate naive strings,
    'Z' suffixes, and actual datetime objects (a future TIMESTAMP column).
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    s = str(value).strip()
    if not s:
        return None
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _age_s(now: datetime, ts: Optional[datetime]) -> Optional[float]:
    if ts is None:
        return None
    return (now - ts).total_seconds()


def _run_workspace(store, run: Dict[str, Any]) -> Optional[str]:
    """The run's own workspace code from its row, or None if unattributed.

    The supervisor fires AUTOMATICALLY, so it must never guess a tenant: a
    resurrection used to omit ``workspace=`` from ``spawn_run``, which
    silently re-spawned a tenant run under the retired ``default`` fallback
    — a different agent home and roster, mid-run, after one sweep.
    """
    from ioagentfarm.engine.workspaces import RETIRED_WORKSPACE_CODES
    ws_id = run.get("workspace_id")
    if not ws_id:
        return None
    try:
        row = store.get_workspace_by_id(ws_id)
    except Exception:
        return None
    code = ((row or {}).get("code") or "").strip()
    if not code or code in RETIRED_WORKSPACE_CODES:
        return None
    return code


def _warn_if_work_already_exists(store, root_path, run_id: str) -> None:
    """Say so when a pending step's artifacts are already on disk.

    See the caller. The database and the filesystem disagree, and the database
    is the one that lost state - so the filesystem is the evidence that this
    work was done before.
    """
    from pathlib import Path

    try:
        steps = store.list_steps(run_id) or []
    except Exception:  # noqa: BLE001
        return
    stale = []
    for st in steps:
        status = str(st.get("status") or "")
        if status not in ("pending", "queued"):
            continue
        if int(st.get("attempt") or 0) > 0:
            continue                      # a real retry, not a rollback
        key = str(st.get("step_key") or "")
        if not key:
            continue
        out = Path(root_path) / "instances" / run_id / "steps" / key
        try:
            if out.is_dir() and any(out.iterdir()):
                stale.append(key)
        except Exception:  # noqa: BLE001
            continue
    if not stale:
        return

    message = (
        f"run {run_id}: {len(stale)} step(s) are pending with no attempts but "
        f"already have artifacts on disk ({', '.join(stale[:4])}). This is "
        f"the signature of a database restored without its write-ahead log - "
        f"the work was done by a process this database no longer remembers. "
        f"Resuming will run it AGAIN, and any side effects will repeat.")
    logger.warning(message)
    try:
        from ioagentfarm.engine import degraded
        degraded.record("run.work_may_repeat", message, scope=run_id)
    except Exception:  # noqa: BLE001
        pass
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
        get_forensics(Path(root_path)).emit(
            run_id=run_id, event_type="supervisor.work_may_repeat",
            severity=SEVERITY_WARN, message=message,
            payload={"steps": stale})
    except Exception:  # noqa: BLE001
        pass


def _spawn_driver(run: Dict[str, Any], root_path: Path,
                  workspace: str) -> None:
    """Re-spawn the driver (Alex) against the EXISTING run.

    Exactly the machinery ``POST /api/run/{id}/resume`` uses — the run and
    its steps already exist; ``spawn_run`` launches the project_lead session
    that drives the pipeline via next-step/run-step. Detached so the driver
    outlives the supervisor process (supervise --once, serve restarts).
    Kept as a module-level function so tests can monkeypatch it.
    *workspace* is the run's own workspace, resolved by the caller via
    :func:`_run_workspace` — required, never inferred here.
    """
    from ioagentfarm.web.spawn import spawn_run
    spawn_run(
        run_id=run["id"],
        workflow=run["workflow_name"],
        goal=run["goal"],
        project_dir=run.get("project_dir", "") or "",
        user_id=run.get("user_id", "") or "",
        root_path=root_path,
        workspace=workspace,
        detach=True,
    )


def _forensics(root_path: Path):
    from ioagentfarm.engine.forensics import get_forensics
    return get_forensics(root_path)


def _emit_run_boundary(root_path: Path, store, rid: str, new_status: str,
                       healed_by: str) -> None:
    """Close the run's timeline when the SUPERVISOR is what ended it.

    _finalize_step emits run.completed/run.failed on the normal path, but a
    run the supervisor heals, deadlock-fails or gives up on transitions
    WITHOUT a finalizer — leaving no closing anchor, so cross-run SQL keyed
    on the boundary events silently undercounts exactly the unhealthy runs.
    Best-effort like every other supervisor emit: never fails the sweep.
    """
    try:
        from ioagentfarm.engine.forensics import SEVERITY_ERROR, SEVERITY_INFO
        kind = "workflow"
        try:
            kind = store.get_run(rid).get("kind") or "workflow"
        except Exception:
            pass
        _forensics(root_path).emit(
            run_id=rid,
            event_type=("run.completed" if new_status == "done"
                        else "run.failed"),
            severity=(SEVERITY_INFO if new_status == "done"
                      else SEVERITY_ERROR),
            message=f"run transitioned to {new_status} (by supervisor)",
            payload={"kind": kind, "healed_by": healed_by},
        )
    except Exception:
        logger.debug("supervisor run boundary emit failed", exc_info=True)


# ---------------------------------------------------------------------------
# The sweep
# ---------------------------------------------------------------------------

def supervise_once(
    store,
    root_path: Path,
    *,
    run_id: Optional[str] = None,
    resume_drivers: bool = True,
) -> List[Dict[str, Any]]:
    """One supervision sweep over active runs. Returns the actions taken.

    Pure in the sense that all state lives in the store; safe to call from
    any process at any cadence. A healthy system yields ``[]``.

    Parameters
    ----------
    store : Store
        The shared state store (SQLite or PostgreSQL).
    root_path : Path
        IOF_ROOT — used for forensic events and driver spawn.
    run_id : str, optional
        Scope the sweep to a single run (the blocking ``run`` loop passes
        its own run). Default: all runs with status='running'.
    resume_drivers : bool
        When False, only reap stale steps — never spawn a driver. Used by
        the blocking ``run`` loop, which IS the driver (resurrecting a
        second one would double-drive its own run).
    """
    actions: List[Dict[str, Any]] = []
    now = datetime.now(timezone.utc)

    try:
        if run_id:
            try:
                runs = [store.get_run(run_id)]
            except KeyError:
                # A run the store cannot see is NOT "nothing to do". This
                # swallowed the case where the supervisor was pointed at the
                # wrong database entirely — every scoped sweep returned an
                # empty action list, which reads as a clean bill of health.
                # Raise so the caller can say which it was; the unscoped sweep
                # keeps its broad handler below, where an empty list really
                # does mean no runs are active.
                raise SupervisorRunNotFound(
                    f"run {run_id!r} is not in this store. The supervisor "
                    f"reports no action for a run it cannot see, so check the "
                    f"database before reading an empty sweep as healthy: a "
                    f"workspace must be selected (IOF_WORKSPACE / `workspace "
                    f"use`) for IOF_DATABASE_URL to be loaded from its .env."
                ) from None
            runs = [r for r in runs if r.get("status") == "running"]
        else:
            runs = store.list_active_runs()
    except SupervisorRunNotFound:
        # Must escape the broad handler below. The first version of this fix
        # raised INSIDE that try, so the very handler this bug hides behind
        # caught it, logged it to a logger the CLI does not print, and
        # returned [] — reproducing the exact symptom being fixed.
        raise
    except Exception:
        logger.warning("supervise_once: could not list active runs", exc_info=True)
        return actions

    for run in runs:
        try:
            actions.extend(_supervise_run(store, root_path, run, now,
                                          resume_drivers=resume_drivers))
        except Exception:
            logger.warning("supervise_once: sweep failed for run %s",
                           run.get("id"), exc_info=True)
    return actions


def _supervise_run(
    store,
    root_path: Path,
    run: Dict[str, Any],
    now: datetime,
    *,
    resume_drivers: bool,
) -> List[Dict[str, Any]]:
    actions: List[Dict[str, Any]] = []
    rid = run["id"]
    steps = store.list_steps(rid)

    # ---- (a) Reap stale running steps -----------------------------------
    step_stale = _step_stale_s()
    nohb_grace = _no_heartbeat_grace_s()
    reaped_any = False
    for s in steps:
        if s["status"] != "running":
            continue
        hb = _parse_ts(s.get("heartbeat_at"))
        upd = _parse_ts(s.get("updated_at"))
        if hb is not None:
            age = _age_s(now, hb)
            threshold = step_stale
            basis = "heartbeat_at"
        else:
            age = _age_s(now, upd)
            threshold = nohb_grace
            basis = "updated_at (no heartbeat)"
        if age is None:
            continue  # unparseable timestamps — never act on guesses
        if age <= threshold:
            continue  # fresh — a live executor owns this step

        result = store.crash_recover_step(rid, s["step_key"])
        if result.get("action") != "crash_recovery":
            # done-with-output (completed after all) or vanished — no-op.
            continue
        reaped_any = True
        try:
            from ioagentfarm.engine.forensics import SEVERITY_WARN
            _forensics(root_path).emit(
                run_id=rid, event_type="supervisor.step_reaped",
                severity=SEVERITY_WARN,
                step_key=s["step_key"], attempt=int(s.get("attempt") or 0),
                role=s.get("role"),
                message=(
                    f"Supervisor reaped stuck step '{s['step_key']}' — {basis} "
                    f"stale by {age:.0f}s (threshold {threshold:.0f}s). Applied "
                    f"crash-recovery transition (status -> pending, attempts preserved)."
                ),
                payload={
                    "basis": basis,
                    "age_s": round(age, 1),
                    "threshold_s": threshold,
                    "heartbeat_at": s.get("heartbeat_at"),
                    "updated_at": s.get("updated_at"),
                },
            )
        except Exception:
            logger.debug("supervisor.step_reaped emit failed", exc_info=True)
        try:
            store.insert_message(
                run_id=rid, step_key=s["step_key"], source="system",
                role="supervisor", agent_name="Supervisor",
                content=(
                    f"Supervisor: step '{s['step_key']}' had no heartbeat for "
                    f"{age:.0f}s — its executor is presumed dead. Reset to pending "
                    f"for re-execution (crash recovery, attempts preserved)."
                ),
                msg_type="message",
            )
        except Exception:
            logger.debug("supervisor reap message insert failed", exc_info=True)
        actions.append({
            "action": "step_reaped",
            "run_id": rid,
            "step_key": s["step_key"],
            "age_s": round(age, 1),
            "basis": basis,
        })

    # Refresh local view if we changed anything.
    if reaped_any:
        steps = store.list_steps(rid)

    # Opportunistic run-level convergence (idempotent, zero-cost when healthy):
    # heal "all steps done but run still 'running'" and "all failed, nothing
    # actionable" states left behind by a dead finalizer.
    try:
        # Claim the transition (see Store.mark_run_done_if_complete): emit the
        # closing boundary ONLY when THIS sweep is the one that flipped the run,
        # not merely when the run is now terminal. A run the finalizer — or a
        # sweep on another pod — converges in the same instant is already
        # terminal by the time we re-read it; emitting on that alone added a
        # second run.completed to 92 of 292 runs in a 3-pod soak.
        _did_done = bool(store.mark_run_done_if_complete(rid))
        _did_fail = bool(store.mark_run_failed_if_stuck(rid))
        run_now = store.get_run(rid)
        if run_now.get("status") != "running":
            new_status = run_now.get("status")
            if not (_did_done or _did_fail):
                # Converged by the finalizer or a sweep on another pod; whoever
                # WON the running->terminal transition emitted the boundary.
                # The run is converged either way, so still STOP driving it —
                # just do not add a second run.completed / run.failed.
                return actions
            # THIS sweep won the transition — emit the closing boundary.
            # mark_run_failed_if_stuck fails a run whose remaining pending
            # steps are all transitively blocked behind failed deps. That IS
            # the dependency deadlock — the store just converges it earlier
            # than the driver-staleness branch below. Keep the rich
            # diagnostic event riding along so `explain` and cross-run SQL
            # still see the deadlock shape, not just a bare run.failed.
            blocked = ([s for s in steps if s["status"] == "pending"]
                       if new_status == "failed" else [])
            _emit_run_boundary(
                root_path, store, rid, new_status,
                healed_by="dependency_deadlock" if blocked
                else "convergence_heal")
            if blocked:
                try:
                    from ioagentfarm.engine.forensics import SEVERITY_FATAL
                    _forensics(root_path).emit(
                        run_id=rid, event_type="supervisor.deadlock",
                        severity=SEVERITY_FATAL,
                        message=(
                            f"Dependency deadlock: {len(blocked)} pending "
                            f"step(s) can never become runnable (blocked "
                            f"behind failed dep(s), nothing running). Run "
                            f"marked failed. Revive via step-retry on the "
                            f"failed dep(s) then POST /resume."
                        ),
                        payload={
                            "reason": "dependency_deadlock",
                            "blocked": [s["step_key"] for s in blocked],
                        },
                    )
                except Exception:
                    logger.debug("supervisor.deadlock emit failed",
                                 exc_info=True)
            return actions  # converged — nothing left to drive
    except Exception:
        logger.debug("supervisor run-level convergence check failed", exc_info=True)

    # ---- (b) Resurrect a dead driver ------------------------------------
    if not resume_drivers:
        return actions

    status_map = {s["step_key"]: s["status"] for s in steps}
    running_alive = any(s["status"] == "running" for s in steps)
    if running_alive:
        # A live (fresh-heartbeat) step executor exists — the pipeline is
        # moving; driver staleness during a long step is normal (the driver
        # may be blocked in a run-step exec call).
        return actions

    pending = [s for s in steps if s["status"] == "pending"]
    runnable = [
        s for s in pending
        if all(status_map.get(d) == "done"
               for d in json.loads(s["deps_json"] or "[]"))
    ]

    driver_hb = _parse_ts(run.get("driver_heartbeat_at"))
    # NULL driver heartbeat (pre-supervisor runs): fall back to the run's
    # updated_at — it is touched on every step finalization, so it is a fair
    # "last sign of pipeline life".
    basis_ts = driver_hb if driver_hb is not None else _parse_ts(run.get("updated_at"))
    basis = "driver_heartbeat_at" if driver_hb is not None else "updated_at (no driver heartbeat)"
    age = _age_s(now, basis_ts)
    # ONE CLOCK. `status`, `watch`, `resume` and the single_active_run
    # refusal judge a code driver through driver_state() - see code_driver_stale_s - while this
    # decision used the agent driver's 300 s for both kinds, so the sweep
    # resurrected a code driver five minutes after every other surface had
    # called it gone and told the operator to type `resume` (three pods on
    # one schema, 2026-08-27; novice round 7's "stale by 309s").
    _thr = (code_driver_stale_s() if run.get("driver") == "code"
            else _driver_stale_s())
    driver_stale = age is not None and age > _thr

    if not runnable:
        # Dependency deadlock detection. With no running step and no
        # runnable pending step, the pending set is STRUCTURALLY stuck:
        # nothing is executing, so no dependency will ever flip to 'done'
        # (typical cause: a dep failed at max attempts — chaos-observed:
        # probe_work failed 2/2 on provider transients, probe_verify
        # pending behind it, driver gone → the run would sit 'running'
        # silently forever). A LIVE driver gets the full staleness window
        # to escalate first (step-retry bumps max_attempts and revives a
        # failed dep; step-skip unblocks). Only when the driver is also
        # gone do we conclude nobody can ever act: mark the run failed —
        # an honest, human-recoverable terminal (step-retry + /resume
        # still work) — and emit supervisor.deadlock.
        if pending and driver_stale:
            blocked_detail = [
                {
                    "step_key": s["step_key"],
                    "blocking_deps": {
                        d: status_map.get(d, "(missing)")
                        for d in json.loads(s["deps_json"] or "[]")
                        if status_map.get(d) != "done"
                    },
                }
                for s in pending
            ]
            try:
                with store._tx() as cursor:
                    cursor.execute(
                        store._q("UPDATE runs SET status='failed', updated_at=? WHERE id=? AND status='running'"),
                        (store._now(), rid),
                    )
                    deadlocked = cursor.rowcount > 0
            except Exception:
                logger.warning("supervisor deadlock update failed for %s", rid, exc_info=True)
                return actions
            if not deadlocked:
                return actions  # another pod already acted
            _emit_run_boundary(root_path, store, rid, "failed",
                               healed_by="dependency_deadlock")
            try:
                from ioagentfarm.engine.forensics import SEVERITY_FATAL
                _forensics(root_path).emit(
                    run_id=rid, event_type="supervisor.deadlock",
                    severity=SEVERITY_FATAL,
                    message=(
                        f"Dependency deadlock: {len(pending)} pending step(s) "
                        f"can never become runnable (no running step, no "
                        f"runnable step, driver gone {age:.0f}s). Run marked "
                        f"failed. Revive via step-retry on the failed dep(s) "
                        f"then POST /resume."
                    ),
                    payload={
                        "reason": "dependency_deadlock",
                        "driver_stale_s": round(age, 1),
                        "blocked": blocked_detail,
                    },
                )
            except Exception:
                logger.debug("supervisor.deadlock emit failed", exc_info=True)
            try:
                store.insert_message(
                    run_id=rid, source="system", role="supervisor",
                    agent_name="Supervisor",
                    content=(
                        f"Supervisor: dependency deadlock — {len(pending)} "
                        f"pending step(s) blocked behind non-done deps with no "
                        f"executor and no driver. Run marked failed. Revive: "
                        f"step-retry the failed dep, then resume the run."
                    ),
                    msg_type="message",
                )
            except Exception:
                logger.debug("supervisor deadlock message insert failed", exc_info=True)
            actions.append({
                "action": "deadlock_failed",
                "run_id": rid,
                "blocked": [b["step_key"] for b in blocked_detail],
            })
        return actions

    if not driver_stale:
        return actions  # driver looks alive (or too young to judge)

    resumes = int(run.get("supervisor_resumes") or 0)
    if resumes >= _max_resumes():
        # Bounded convergence: stop resurrecting, fail the run cleanly.
        try:
            with store._tx() as cursor:
                cursor.execute(
                    store._q("UPDATE runs SET status='failed', updated_at=? WHERE id=? AND status='running'"),
                    (store._now(), rid),
                )
                gave_up = cursor.rowcount > 0
        except Exception:
            logger.warning("supervisor give-up update failed for %s", rid, exc_info=True)
            return actions
        if not gave_up:
            return actions  # another pod already acted
        _emit_run_boundary(root_path, store, rid, "failed",
                           healed_by="supervisor_gave_up")
        try:
            from ioagentfarm.engine.forensics import SEVERITY_FATAL
            _forensics(root_path).emit(
                run_id=rid, event_type="supervisor.gave_up",
                severity=SEVERITY_FATAL,
                message=(
                    f"Supervisor gave up on run {rid}: driver resurrected "
                    f"{resumes}x (cap {_max_resumes()}) and it still died with "
                    f"runnable steps waiting. Run marked failed "
                    f"(reason: supervisor_gave_up)."
                ),
                payload={
                    "reason": "supervisor_gave_up",
                    "supervisor_resumes": resumes,
                    "max_resumes": _max_resumes(),
                    "runnable_steps": [s["step_key"] for s in runnable],
                },
            )
        except Exception:
            logger.debug("supervisor.gave_up emit failed", exc_info=True)
        try:
            store.insert_message(
                run_id=rid, source="system", role="supervisor",
                agent_name="Supervisor",
                content=(
                    f"Supervisor gave up: the driver was resurrected {resumes} "
                    f"time(s) and kept dying. Run marked failed "
                    f"(supervisor_gave_up). Investigate forensics, then "
                    f"POST /api/run/{rid}/resume to try again manually."
                ),
                msg_type="message",
            )
        except Exception:
            logger.debug("supervisor give-up message insert failed", exc_info=True)
        actions.append({
            "action": "gave_up",
            "run_id": rid,
            "supervisor_resumes": resumes,
        })
        return actions

    # The run's own workspace, before anything is claimed: a run the
    # supervisor cannot attribute is FAILED, not resurrected into a guessed
    # tenant — an automatic sweep is the one place a guess can never be
    # noticed, let alone corrected.
    run_ws = _run_workspace(store, run)
    if not run_ws:
        try:
            with store._tx() as cursor:
                cursor.execute(
                    store._q("UPDATE runs SET status='failed', updated_at=? "
                             "WHERE id=? AND status='running'"),
                    (store._now(), rid),
                )
                marked = cursor.rowcount > 0
        except Exception:
            logger.warning("supervisor workspace_unresolved update failed "
                           "for %s", rid, exc_info=True)
            return actions
        if not marked:
            return actions  # another pod already acted
        _emit_run_boundary(root_path, store, rid, "failed",
                           healed_by="workspace_unresolved")
        try:
            from ioagentfarm.engine.forensics import SEVERITY_FATAL
            _forensics(root_path).emit(
                run_id=rid, event_type="supervisor.workspace_unresolved",
                severity=SEVERITY_FATAL,
                message=(
                    f"Supervisor cannot resurrect run {rid}: the run row is "
                    f"not attributed to a workspace, and the supervisor "
                    f"never guesses a tenant. Run marked failed (reason: "
                    f"workspace_unresolved). Re-create the run in a named "
                    f"workspace."
                ),
                payload={"reason": "workspace_unresolved",
                         "workspace_id": run.get("workspace_id")},
            )
        except Exception:
            logger.debug("supervisor.workspace_unresolved emit failed",
                         exc_info=True)
        actions.append({"action": "workspace_unresolved", "run_id": rid})
        return actions

    # Atomically claim this resume slot (multi-pod: exactly one winner) and
    # stamp a fresh driver heartbeat so the next sweep gives the new driver
    # the full stale window to boot before judging it.
    try:
        with store._tx() as cursor:
            cursor.execute(
                store._q(
                    "UPDATE runs SET supervisor_resumes=?, driver_heartbeat_at=?, updated_at=? "
                    "WHERE id=? AND status='running' AND COALESCE(supervisor_resumes,0)=?"
                ),
                (resumes + 1, store._now(), store._now(), rid, resumes),
            )
            claimed = cursor.rowcount > 0
    except Exception:
        logger.warning("supervisor resume claim failed for %s", rid, exc_info=True)
        return actions
    if not claimed:
        return actions  # lost the race to another pod — its resume covers us

    # WORK THAT LOOKS PENDING BUT HAS ALREADY BEEN DONE. A validator restored
    # a hot copy of `state.db` taken WITHOUT its write-ahead log. It passes
    # `integrity_check` and silently rolls state back: a finished run
    # reappeared as `running` with both steps `pending`. The supervisor
    # resurrected it and re-ran both from attempt 1, overwriting the
    # artifacts, and reported `done (by supervisor)`. Nothing said the work
    # had happened twice - and on a deployment whose steps have side effects
    # (a case delivery, an outbound message) a restore re-fires them.
    #
    # The signature is detectable: a step with no attempts whose output
    # directory already holds artifacts was completed by a process this
    # database no longer remembers. Reported, not blocked - the operator may
    # well want the re-run, and refusing here would strand a legitimately
    # interrupted run.
    try:
        _warn_if_work_already_exists(store, root_path, rid)
    except Exception:  # noqa: BLE001 - a warning must not stop a resume
        logger.debug("supervisor: prior-work check failed for %s", rid,
                     exc_info=True)

    try:
        _spawn_driver(run, root_path, run_ws)
        spawn_ok, spawn_err = True, None
    except Exception as exc:  # spawn failure — the claim (counter) stands,
        spawn_ok, spawn_err = False, str(exc)  # bounding still converges
        logger.warning("supervisor driver spawn failed for %s: %s", rid, exc)

    try:
        from ioagentfarm.engine.forensics import SEVERITY_WARN, SEVERITY_ERROR
        _forensics(root_path).emit(
            run_id=rid, event_type="supervisor.driver_resumed",
            severity=SEVERITY_WARN if spawn_ok else SEVERITY_ERROR,
            message=(
                f"Supervisor resurrected the driver for run {rid} — {basis} stale "
                f"by {age:.0f}s with {len(runnable)} runnable step(s) waiting "
                f"(resume {resumes + 1}/{_max_resumes()})."
                + ("" if spawn_ok else f" SPAWN FAILED: {spawn_err}")
            ),
            payload={
                "basis": basis,
                "age_s": round(age, 1),
                "threshold_s": (code_driver_stale_s()
                                if run.get("driver") == "code"
                                else _driver_stale_s()),
                "resume_n": resumes + 1,
                "max_resumes": _max_resumes(),
                "runnable_steps": [s["step_key"] for s in runnable],
                "spawn_ok": spawn_ok,
                "spawn_error": spawn_err,
            },
        )
    except Exception:
        logger.debug("supervisor.driver_resumed emit failed", exc_info=True)
    try:
        store.insert_message(
            run_id=rid, source="system", role="supervisor",
            agent_name="Supervisor",
            content=(
                f"Supervisor: no live driver for {age:.0f}s with "
                f"{len(runnable)} runnable step(s) waiting — re-spawned the "
                f"orchestrator (resume {resumes + 1}/{_max_resumes()})."
            ),
            msg_type="message",
        )
    except Exception:
        logger.debug("supervisor resume message insert failed", exc_info=True)
    actions.append({
        "action": "driver_resumed",
        "run_id": rid,
        "resume_n": resumes + 1,
        "age_s": round(age, 1),
        "spawn_ok": spawn_ok,
    })
    return actions
