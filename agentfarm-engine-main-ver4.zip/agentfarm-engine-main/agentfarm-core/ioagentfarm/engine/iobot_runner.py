from __future__ import annotations
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict

from ioagentfarm.engine.runner_base import Runner
from ioagentfarm.engine.workspaces import ensure_agent_workspace, build_spawn_prompt


class IobotRunner(Runner):
    """Execute workflow steps by calling ``iobot agent --message <prompt>``.

    Identity & memory (iobot v0.1.5+ multi-instance)
    ---------------------------------------------------
    iobot supports ``--workspace`` and ``--config`` CLI flags:
    - ``--workspace`` points to the per-role agent workspace
      (``~/.iobot/agents/<role>/workspace/``), loading SOUL.md, MEMORY.md,
      and skills natively.  Sessions are stored workspace-locally.
    - ``--config`` points to a per-run instance config with project-specific
      MCP servers, isolated logs, and cron.

    We also use ``build_spawn_prompt()`` to prepend identity and learnings to
    the step prompt for redundancy — ensuring the LLM sees "You are Analyst,
    the ANALYST ..." even if workspace loading has issues.

    Session isolation
    -----------------
    Each step+attempt gets a unique session key ``iof:<run_id>:<step_key>:<attempt>``
    stored in the workspace-scoped sessions directory
    (``{workspace}/sessions/iof_<run_id>_<step_key>_<attempt>.jsonl``).  This
    prevents cross-contamination between concurrent workflows, different steps,
    and retries of the same step.

    Workspace sandboxing
    --------------------
    ``IOBOT_TOOLS__RESTRICT_TO_WORKSPACE=true`` is always injected into the
    subprocess environment — unconditionally, with no opt-out.  This sandboxes
    all agent file/shell tools to iobot's configured workspace directory so
    agents cannot read or write files outside it.

    Output
    ------
    ``build_spawn_prompt()`` is called with ``output_path=""`` (stdout mode) because
    the sandbox prevents the agent from writing to the ioagentfarm step directory.
    The agent prints its output to stdout; the scheduler captures it and writes
    ``out_dir/OUTPUT.txt`` itself (``execute_one_step`` lines 327-329).
    The async spawn path (``render-spawn`` + Alex's iobot spawn tool) passes an
    explicit ``output_path`` and is NOT subject to this sandbox restriction.
    """

    def __init__(self, iobot_bin: str | None = None):
        self.iobot_bin = iobot_bin or self._resolve_iobot_bin()

    @staticmethod
    def _resolve_iobot_bin() -> str:
        """Resolve the runtime binary. See engine/runtime_bin.py."""
        from ioagentfarm.engine.runtime_bin import runtime_bin
        return runtime_bin()

    @staticmethod
    def is_available(iobot_bin: str | None = None) -> bool:
        if iobot_bin:
            return shutil.which(iobot_bin) is not None
        from ioagentfarm.engine.runtime_bin import runtime_bin_available
        return runtime_bin_available()

    def run_step(
        self,
        *,
        run_id: str,
        step_key: str,
        role: str,
        role_prompt: str,
        step_prompt: str,
        goal: str,
        workspace: Path,
        context: Dict[str, Any],
    ) -> str:
        # Materialise agent identity files into the step workspace for archival.
        # (iobot reads its live identity from ~/.iobot/workspace/ at runtime,
        # but we archive the role-specific files here for debugging/inspection.)
        ensure_agent_workspace(role, workspace)

        task = {
            "run_id": run_id,
            "step_key": step_key,
            "role": role,
            "goal": goal,
            "context": context,
        }
        (workspace / "TASK.json").write_text(
            json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8"
        )

        # Build the full message using build_spawn_prompt() — the same function
        # used by the async spawn flow.  This prepends:
        #   # Identity  →  role's SOUL.md (overrides iobot's global identity)
        #   # Learnings  →  role's MEMORY.md (accumulated past-run learnings)
        #   # Task  →  the rendered step prompt
        #   # Learning protocol  →  instructions to write to memory/MEMORY.md
        #   # Output requirements  →  STATUS/OUTPUT format (stdout mode, no file path)
        #
        # output_path="" (stdout mode): IOBOT_TOOLS__RESTRICT_TO_WORKSPACE=true sandboxes
        # the agent to ~/.iobot/workspace/ so it cannot write to the ioagentfarm step dir.
        # The agent prints to stdout; the scheduler captures it and writes OUTPUT.txt itself.
        full_msg = build_spawn_prompt(
            role=role,
            step_prompt=step_prompt,
            output_path="",   # stdout mode — no file-write instruction
        )

        # Unique session key per step+attempt → isolated conversation history.
        # Including the attempt number prevents a retry from seeing the failed
        # attempt's conversation history in iobot's session file.
        attempt = context.get("attempt", 0)
        session_key = f"iof:{run_id}:{step_key}:{attempt}"

        # Resolve per-role workspace for --workspace flag
        from ioagentfarm.engine.workspaces import iobot_agent_workspace
        role_workspace = str(iobot_agent_workspace(role))

        cmd = [
            self.iobot_bin,
            "agent",
            "--message", full_msg,
            "--session", session_key,
            "--no-markdown",  # suppress markdown rendering for clean protocol output
            "--workspace", role_workspace,
        ]

        # Pass per-run instance config if available
        config_path = context.get("config_path", "")
        if config_path:
            cmd.extend(["--config", str(config_path)])

        # Always enforce workspace sandboxing — no opt-out.
        # project_dir IS the sandbox boundary: IOBOT_WORKSPACE points iobot's sandbox
        # at the user's project directory, so Sam can write code there and nowhere else.
        # Without project_dir the sandbox falls back to the role workspace (safe default).
        env = os.environ.copy()
        env["IOBOT_TOOLS__RESTRICT_TO_WORKSPACE"] = "true"
        project_dir = context.get("project_dir", "")
        if project_dir:
            env["IOBOT_WORKSPACE"] = project_dir
        else:
            env["IOBOT_WORKSPACE"] = role_workspace

        proc = subprocess.run(cmd, capture_output=True, text=True, env=env)
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()

        (workspace / "RAW_STDOUT.txt").write_text(out, encoding="utf-8")
        if err:
            (workspace / "RAW_STDERR.txt").write_text(err, encoding="utf-8")

        # Stdout is the primary output channel (stdout mode — no file-write instruction).
        # The scheduler captures this return value and writes out_dir/OUTPUT.txt itself.
        if proc.returncode != 0:
            return (
                f"STATUS: failed\n"
                f"OUTPUT: iobot exited with code {proc.returncode}\n"
                f"STDERR: {err[:4000]}"
            )
        return out
