"""Cross-check the v1 envelope's `data.rows` against the session's tool_results.

Quinn (queryngine) is required by `result_composer/SKILL.md` to emit values in
`data.rows` verbatim from the most recent successful `iof-query` tool_result.
Under long sessions (many tool calls, high context length), MiniMax has been
observed to paraphrase tool_results instead of quoting them — fabricating
plausible-looking PO numbers and amounts that do not match the queried data.

This module provides the safety net: parse the envelope, find the most recent
successful tabular tool_result in the session, and flag any `data.rows` cell
value that does not appear in the tool_result. Callers use the flags to decide
whether to re-invoke Quinn with a corrective prompt, annotate the envelope, or
reject it outright.

Scope:
- Only validates `data.type == "table"` envelopes. Scalar/list/text pass through.
- Only cross-checks against tool_results that look like iof-query JSON output
  (`{"success": true, "rows": [...], "columns": [...]}`). vectorfs grep/cat
  outputs are free-form text and aren't validated here.
- Numeric values are compared with tolerance for format drift (int vs float,
  string-of-number vs number). Strings are compared with trim + case-insensitive
  match by default.
- Values not anchored to a specific source row (e.g., computed aggregates the
  agent composed from multiple rows) are expected to be flagged; that's fine —
  the validator reports, caller decides.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


@dataclass
class RowViolation:
    row_index: int
    column_index: int
    column_name: str | None
    envelope_value: Any
    reason: str


@dataclass
class ValidationResult:
    checked: bool
    ok: bool
    reason: str
    violations: list[RowViolation] = field(default_factory=list)
    source_event_index: int | None = None
    source_row_count: int = 0
    envelope_row_count: int = 0

    def summary(self) -> str:
        if not self.checked:
            return f"skipped: {self.reason}"
        if self.ok:
            return f"ok: {self.envelope_row_count} envelope rows match source"
        return (f"fabrication_detected: {len(self.violations)} violations "
                f"across {self.envelope_row_count} envelope rows (source has "
                f"{self.source_row_count} rows)")


def _normalize_scalar(v: Any) -> Any:
    """Canonicalize a cell value for equality comparison.

    - Numbers coerced to float where possible.
    - Strings trimmed and lowercased.
    - None stays None.
    - Everything else returned as-is.
    """
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        s = v.strip()
        # Strip currency/grouping decoration before numeric parse
        cleaned = s.replace(",", "").replace("$", "").replace("US$", "").strip()
        try:
            return float(cleaned)
        except ValueError:
            return s.lower()
    return v


def _flatten_cell_values(rows: list[dict] | list[list]) -> set:
    out: set = set()
    for r in rows:
        if isinstance(r, dict):
            for v in r.values():
                n = _normalize_scalar(v)
                if n is not None:
                    out.add(n)
        elif isinstance(r, (list, tuple)):
            for v in r:
                n = _normalize_scalar(v)
                if n is not None:
                    out.add(n)
    return out


def _iter_session_events(session_path: Path) -> Iterable[dict]:
    if not session_path.exists():
        return []
    events = []
    for line in session_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return events


def _find_all_iof_query_results(events: list[dict]) -> list[tuple[int, dict]]:
    """Walk events in order; return list of (index, parsed_result_dict) for
    every tool event whose content parses as a successful iof-query JSON
    response. Validator checks envelope cells against the UNION of all rows
    across all these results — Quinn often composes her final envelope from
    data returned by an EARLIER query in the session (e.g., she runs a
    filtered follow-up that returns 0 rows, but her envelope legitimately
    cites rows from the initial broad query). Checking against only the
    most-recent tool_result would false-positive flag those cases.
    """
    out: list[tuple[int, dict]] = []
    for i, e in enumerate(events):
        if e.get("role") != "tool":
            continue
        content = e.get("content", "")
        if not isinstance(content, str) or '"rows":' not in content:
            continue
        m = re.search(r"\{.*\}", content, re.DOTALL)
        if not m:
            continue
        try:
            obj = json.loads(m.group(0))
        except json.JSONDecodeError:
            continue
        if not isinstance(obj, dict) or not obj.get("success"):
            continue
        if not isinstance(obj.get("rows"), list):
            continue
        out.append((i, obj))
    return out


def _collect_session_text_blobs(events: list[dict]) -> str:
    """Concatenate all tool_result content bodies for substring matching of
    free-form text cells. Used to validate prose quotes Quinn pulled from
    vectorfs grep/cat output — the cell content should appear verbatim in
    some session tool output.
    """
    chunks: list[str] = []
    for e in events:
        if e.get("role") != "tool":
            continue
        c = e.get("content", "")
        if isinstance(c, str):
            chunks.append(c)
    return "\n".join(chunks)


def _normalize_whitespace(s: str) -> str:
    """Collapse runs of whitespace (spaces, tabs, newlines) to a single space.

    vectorfs/iof-query output often wraps long clauses across multiple lines
    or has different whitespace than the agent's rendered cell value. We
    compare post-normalization so that a clause quoted one-line in the
    envelope still matches its multi-line form in the source.
    """
    return re.sub(r"\s+", " ", s).strip()


def validate_envelope_rows(envelope: dict, session_path: Path) -> ValidationResult:
    """Cross-check envelope `data.rows` against the most recent iof-query
    tool_result in the session.
    """
    data = envelope.get("data") if isinstance(envelope, dict) else None
    if not isinstance(data, dict) or data.get("type") != "table":
        return ValidationResult(checked=False, ok=True,
                                reason="envelope has no table data to validate")
    rows = data.get("rows") or []
    if not rows:
        return ValidationResult(checked=False, ok=True,
                                reason="envelope has empty rows")

    events = list(_iter_session_events(session_path))
    all_results = _find_all_iof_query_results(events)
    text_blob = _collect_session_text_blobs(events)
    text_blob_norm = _normalize_whitespace(text_blob)

    if not all_results:
        # Honest labeling: validator is SQL-biased — it can only cross-check
        # envelope cells against iof-query tool_results. When Quinn answered
        # entirely from vectorfs prose, data.rows cells may be derived from
        # chunk text and are not verified here. Callers should treat trust
        # as "unverified" on this response.
        return ValidationResult(checked=False, ok=True,
                                reason="no structured iof-query tool_result — cells derived from vectorfs prose not cross-checked; trust: unverified")

    # UNION of all iof-query cell values across the entire session. See the
    # comment on _find_all_iof_query_results for why: Quinn commonly composes
    # her envelope from data returned by an EARLIER query (e.g., her final
    # query is a filter that returns 0 rows, but the answer legitimately
    # cites rows from an initial broad query).
    src_values: set = set()
    total_src_rows = 0
    for _, obj in all_results:
        rows_obj = obj.get("rows") or []
        total_src_rows += len(rows_obj)
        src_values |= _flatten_cell_values(rows_obj)

    columns = data.get("columns") or []
    violations: list[RowViolation] = []
    for ri, row in enumerate(rows):
        if not isinstance(row, (list, tuple)):
            continue
        for ci, cell in enumerate(row):
            norm = _normalize_scalar(cell)
            if norm is None:
                continue
            # Short strings that are clearly labels/categories we trust
            # (e.g., "Opex", "Capex", "Total") — skip if <= 8 chars and
            # all-alphanumeric.
            if isinstance(norm, str):
                if len(norm) <= 8 and norm.replace(" ", "").isalpha():
                    continue
            # Check 1: numeric/normalized match against any iof-query cell
            # value in the session union.
            if norm in src_values:
                continue
            # Check 2: for longer text cells (>= 15 chars), allow if the
            # cell value is a verbatim substring of any session tool_result
            # content AFTER whitespace normalization. Contracts often wrap
            # clauses across multiple lines in the source; Quinn may render
            # them one-line in the cell. Whitespace-normalize both sides so
            # a multi-line vectorfs grep/cat output still matches the agent's
            # single-line rendering. We require 15+ chars to avoid trivial
            # substring matches for short numbers / slugs; those must pass
            # Check 1 instead.
            if isinstance(cell, str) and len(cell) >= 15:
                cell_norm = _normalize_whitespace(cell)
                if cell_norm in text_blob_norm:
                    continue
            violations.append(RowViolation(
                row_index=ri, column_index=ci,
                column_name=columns[ci] if ci < len(columns) else None,
                envelope_value=cell,
                reason=("not found in any session iof-query tool_result; "
                        "also not a verbatim substring of vectorfs output"),
            ))
    # Pick the largest-row iof-query as the "representative" source_event_index
    # (breaks ties by recency) — used by the retry prompt to show tool_result
    # rows in context; pragmatically the biggest is usually the one Quinn was
    # composing against.
    rep_idx, rep_obj = max(all_results, key=lambda t: (len(t[1].get("rows") or []), t[0]))
    return ValidationResult(
        checked=True,
        ok=not violations,
        reason=("ok" if not violations else
                f"{len(violations)} fabricated cell(s)"),
        violations=violations,
        source_event_index=rep_idx,
        source_row_count=total_src_rows,
        envelope_row_count=len(rows),
    )


def build_corrective_prompt(violations: list[RowViolation],
                            source_rows: list[dict]) -> str:
    """Compose a corrective prompt that re-triggers Quinn's compose step.

    Lists each fabricated cell, quotes the source rows verbatim, and instructs
    Quinn to re-emit the envelope with `data.rows` taken directly from the
    tool_result. Used when `validate_envelope_rows` detects fabrication.
    """
    bullets = []
    for v in violations[:10]:  # cap at 10 to keep the prompt bounded
        col = f" (column '{v.column_name}')" if v.column_name else ""
        bullets.append(
            f"- row {v.row_index}, col {v.column_index}{col}: envelope wrote "
            f"{v.envelope_value!r} which does not appear in the tool_result."
        )
    if len(violations) > 10:
        bullets.append(f"- ... and {len(violations) - 10} more.")
    source_excerpt = json.dumps(source_rows, indent=2, default=str)[:2000]
    return (
        "**Envelope validation failed.** Your `data.rows` contained values "
        "that do not appear in ANY iof-query tool_result from this session "
        "(numeric / ID cells) and are not verbatim substrings of any vectorfs "
        "tool_result (long text cells). Specifically:\n\n"
        + "\n".join(bullets)
        + "\n\nOne of the tool_results (the largest-row query in this session) is:\n```json\n"
        + source_excerpt
        + "\n```\n\n"
        "**Re-emit the v1 envelope now.** Rules for `data.rows` cells:\n"
        "- Numeric values MUST be a verbatim cell value from an iof-query row "
        "(no manual sums, counts, or blended averages — put those in `insight`).\n"
        "- IDs (PO-*, ICT-*) MUST come verbatim from an iof-query row.\n"
        "- Text cells of 15+ characters MUST be a verbatim substring of some "
        "tool_result (typically a vectorfs grep/cat output you actually ran).\n"
        "- Derived values (counts of rows, ratios, formatted currency like "
        "'$17M', composed date ranges) go in `insight` — not in data.rows.\n\n"
        "If the rows you want to show span multiple tool_results, you may "
        "choose a SUBSET of columns from any single source and move the "
        "cross-source comparison into `insight`. Return the full envelope "
        "in one fenced JSON block."
    )

# ---------------------------------------------------------------------------
# Prose figures
#
# `validate_envelope_rows` checks `data.rows`. It cannot see a number the agent
# only ASSERTED — a total, a rate, a year-to-date line written into `answer` or
# `insight`. Measured upstream: every monthly figure was exact because SQL
# computed it, while the YTD line was wrong because it was summed by hand.
#
# NOT WIRED into the chat path yet, deliberately: it needs a hit-rate
# measurement first, and a validator that cries wolf is worse than none.
# ---------------------------------------------------------------------------


@dataclass
class ProseNumberResult:
    """Numbers asserted in prose that no query in this session returned."""
    checked: bool
    ok: bool
    reason: str
    unsupported: list = field(default_factory=list)
    candidates: int = 0

    def summary(self) -> str:
        if not self.checked:
            return f"skipped: {self.reason}"
        if self.ok:
            return f"ok: {self.candidates} prose figures all trace to query output"
        return (f"unsupported_prose_numbers: {', '.join(str(u) for u in self.unsupported)} "
                f"(of {self.candidates} candidates)")


_NUM_RE = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{3})+|\d+\.\d+|\d+)(?![\w])")
_YEAR_RE = re.compile(r"^(19|20)\d{2}$")


def _num_variants(tok: str) -> set:
    """The forms a query could legitimately have returned this number as.

    Strict on purpose. An earlier version rounded to int and scaled by 100 on
    both sides of the comparison, which made 7.4 match a returned 7.2 (both
    round to "7") and 1.6 match 2.2 — every fabricated figure found a partner
    and the check passed everything.

    Only trailing-zero forms are treated as the same number. A percentage is
    matched against its ratio, but the caller expands one side only.
    """
    raw = tok.replace(",", "").rstrip("%")
    out = {raw}
    try:
        f = float(raw)
    except ValueError:
        return out
    if f.is_integer():
        out.add(str(int(f)))
        out.add(f"{f:.1f}")
        out.add(f"{f:.2f}")
    else:
        out.add(f"{f:g}")
        out.add(f"{f:.1f}")
        out.add(f"{f:.2f}")
    return {v for v in out if v}


def _pct_partner(tok: str) -> set:
    """A rate in prose may restate a ratio the query returned, or vice versa."""
    raw = tok.replace(",", "").rstrip("%")
    try:
        f = float(raw)
    except ValueError:
        return set()
    out = set()
    for g in (f / 100.0, f * 100.0):
        out.add(f"{g:g}")
        out.add(f"{g:.1f}")
        out.add(f"{g:.2f}")
    return out


def validate_prose_numbers(envelope: dict, session_path: Path) -> ProseNumberResult:
    """Cross-check figures asserted in answer/insight against query output."""
    if not isinstance(envelope, dict):
        return ProseNumberResult(False, True, "no envelope")

    prose = " ".join(
        str(envelope.get(k) or "") for k in ("answer", "insight"))
    if not prose.strip():
        return ProseNumberResult(False, True, "no prose to check")

    # Everything the session legitimately produced.
    supported: set = set()
    try:
        events = list(_iter_session_events(session_path))
        for _, obj in _find_all_iof_query_results(events):
            for r in (obj.get("rows") or []):
                cells = r.values() if isinstance(r, dict) else (
                    r if isinstance(r, (list, tuple)) else [])
                for c in cells:
                    n = _normalize_scalar(c)
                    if n is not None:
                        supported.add(str(n))
    except Exception:
        return ProseNumberResult(False, True, "session unreadable")

    if not supported:
        return ProseNumberResult(False, True, "no query output to check against")

    # The envelope's own table and window are legitimate restatements.
    data = envelope.get("data")
    if isinstance(data, dict):
        for r in (data.get("rows") or []):
            cells = r.values() if isinstance(r, dict) else (
                r if isinstance(r, (list, tuple)) else [])
            for c in cells:
                n = _normalize_scalar(c)
                if n is not None:
                    supported.add(str(n))
    ev = envelope.get("evidence")
    if isinstance(ev, dict):
        dw = ev.get("data_window")
        if isinstance(dw, dict):
            for v in dw.values():
                if v is not None:
                    supported.add(str(v))

    supported_variants: set = set()
    for v in supported:
        supported_variants |= _num_variants(str(v))

    unsupported: list = []
    candidates = 0
    for m in _NUM_RE.finditer(prose):
        tok = m.group(1)
        bare = tok.replace(",", "")
        if _YEAR_RE.match(bare):
            continue
        # Only figures specific enough to be a claim rather than an ordinal.
        digits = bare.replace(".", "").lstrip("0")
        if "." not in bare and len(digits) < 3:
            continue
        candidates += 1
        if not ((_num_variants(tok) | _pct_partner(tok)) & supported_variants):
            if bare not in unsupported:
                unsupported.append(bare)

    if unsupported:
        return ProseNumberResult(True, False, "figures not found in query output",
                                 unsupported=unsupported, candidates=candidates)
    return ProseNumberResult(True, True, "all prose figures traceable",
                             candidates=candidates)

# ---------------------------------------------------------------------------
# The data window
#
# `evidence.data_window` states WHAT THE NUMBERS COVER — start, end, claims,
# patients. It is the one part of an envelope the agent RESTATES rather than
# derives, and restating is where it goes wrong: observed live on this
# deployment, an envelope whose table rows were exact to the row declared
# 2026-01-09..2026-07-31 / 530 claims / 212 patients, against a true range of
# 2025-08-01..2026-08-17, 94 patients, and only 340 claims inside the dates it
# named. It reported `trust: high`. Nothing downstream could tell.
#
# These checks are ARITHMETIC ON THE ENVELOPE'S OWN CLAIMS plus the session's
# query output — no database, no schema, no domain. That is deliberate: the
# upstream implementation also ships `compute_data_window()`, which derives
# the window by querying the fact table, and hardcodes `commercial.ladd`,
# `svc_dt`, `pat_id` and `clm_typ` to do it. Domain SQL does not belong in
# core (see CLAUDE.md: capabilities are skill- and pack-shaped, never engine
# edits), so that half is deliberately NOT taken here. Detection is what
# catches the defect; derivation is a pack's job.
# ---------------------------------------------------------------------------

@dataclass
class WindowValidationResult:
    """Outcome of the evidence.data_window reconciliation check."""
    checked: bool
    ok: bool
    reason: str
    window_claims: int | None = None
    window_patients: int | None = None
    row_total: int | None = None
    count_column: str | None = None
    latest_source_date: str | None = None

    def summary(self) -> str:
        if not self.checked:
            return f"skipped: {self.reason}"
        return ("ok: data_window reconciles" if self.ok
                else f"data_window_inconsistent: {self.reason}")


_DATE_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")


def _as_int(v: Any) -> int | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float) and v.is_integer():
        return int(v)
    if isinstance(v, str):
        t = v.strip().replace(",", "")
        if t.isdigit():
            return int(t)
    return None


def _as_date_key(v: Any) -> str | None:
    """Return YYYY-MM-DD when the value looks like a date, else None."""
    if not isinstance(v, str):
        v = str(v) if v is not None else ""
    m = _DATE_RE.match(v.strip())
    return m.group(0) if m else None


def _count_column_index(columns: list, rows: list) -> tuple[int | None, str | None]:
    """Find a column that plainly holds claim counts.

    Requires the name to mention claims and NOT be a rate/percentage, and every
    value in it to be an integer. Anything ambiguous returns None so the check
    skips rather than guesses.
    """
    if not columns:
        return None, None
    for i, name in enumerate(columns):
        n = str(name).lower()
        if "claim" not in n:
            continue
        if any(bad in n for bad in ("rate", "%", "pct", "percent", "per ")):
            continue
        vals = []
        for r in rows:
            cell = r[i] if isinstance(r, list) and i < len(r) else (
                r.get(name) if isinstance(r, dict) else None)
            iv = _as_int(cell)
            if iv is None:
                vals = []
                break
            vals.append(iv)
        if vals:
            return i, str(name)
    return None, None


def validate_data_window(envelope: dict, session_path: Path) -> WindowValidationResult:
    """Check evidence.data_window against the answer's own rows and the session's data."""
    if not isinstance(envelope, dict):
        return WindowValidationResult(False, True, "no envelope")
    ev = envelope.get("evidence")
    dw = ev.get("data_window") if isinstance(ev, dict) else None
    if not isinstance(dw, dict):
        return WindowValidationResult(False, True, "no evidence.data_window")

    claims = _as_int(dw.get("claims"))
    patients = _as_int(dw.get("patients"))
    start = _as_date_key(dw.get("start"))
    end = _as_date_key(dw.get("end"))

    # 1. ordering
    if start and end and start > end:
        return WindowValidationResult(False if False else True, False,
                                      f"window start {start} is after end {end}",
                                      window_claims=claims)

    # 2. patients cannot exceed claims
    if claims is not None and patients is not None and patients > claims:
        return WindowValidationResult(True, False,
                                      f"window reports {patients} patients over {claims} claims — "
                                      f"a patient has at least one claim",
                                      window_claims=claims, window_patients=patients)

    # 3. the answer's own rows cannot exceed the window they came from
    data = envelope.get("data")
    row_total = None
    col_name = None
    if isinstance(data, dict) and data.get("type") == "table":
        rows = data.get("rows") or []
        cols = data.get("columns") or []
        idx, col_name = _count_column_index(list(cols), rows)
        if idx is not None:
            total = 0
            for r in rows:
                cell = r[idx] if isinstance(r, list) and idx < len(r) else (
                    r.get(col_name) if isinstance(r, dict) else None)
                iv = _as_int(cell)
                if iv is not None:
                    total += iv
            row_total = total
    if claims is not None and row_total is not None and row_total > claims:
        return WindowValidationResult(True, False,
                                      f"rows sum to {row_total} in '{col_name}' but the window "
                                      f"reports only {claims} claims",
                                      window_claims=claims, row_total=row_total,
                                      count_column=col_name)

    # 4. the window cannot end after the newest date the data actually holds
    latest = None
    try:
        events = list(_iter_session_events(session_path))
        for _, obj in _find_all_iof_query_results(events):
            for r in (obj.get("rows") or []):
                cells = r.values() if isinstance(r, dict) else (r if isinstance(r, list) else [])
                for c in cells:
                    d = _as_date_key(c)
                    if d and (latest is None or d > latest):
                        latest = d
    except Exception:
        latest = None

    if end and latest and end > latest:
        return WindowValidationResult(True, False,
                                      f"window ends {end} but the newest date in the data this "
                                      f"session is {latest} — window anchored on the calendar, "
                                      f"not on the data",
                                      window_claims=claims, row_total=row_total,
                                      count_column=col_name, latest_source_date=latest)

    return WindowValidationResult(True, True, "consistent", window_claims=claims,
                                  window_patients=patients, row_total=row_total,
                                  count_column=col_name, latest_source_date=latest)


# Canonical aliases an agent must use so the engine can lift the window stats
# straight out of its query results instead of asking it to restate them.
WINDOW_ALIASES = ("window_start", "window_end", "window_claims", "window_patients")


def extract_window_stats(session_path: Path) -> dict | None:
    """Lift data_window straight from the agent's own query results.

    Scans this session's iof-query tool_results for a row carrying the
    canonical aliases and returns {start, end, claims, patients}. The LAST
    match wins — a later query supersedes an earlier one. Returns None when no
    row carries them, so the caller keeps whatever the agent emitted.
    """
    found = None
    try:
        events = list(_iter_session_events(session_path))
        for _, obj in _find_all_iof_query_results(events):
            for r in (obj.get("rows") or []):
                if not isinstance(r, dict):
                    continue
                keys = {str(k).lower(): k for k in r.keys()}
                if "window_claims" not in keys:
                    continue
                claims = _as_int(r.get(keys["window_claims"]))
                if claims is None:
                    continue
                out = {"claims": claims}
                if "window_start" in keys:
                    out["start"] = _as_date_key(r.get(keys["window_start"]))
                if "window_end" in keys:
                    out["end"] = _as_date_key(r.get(keys["window_end"]))
                if "window_patients" in keys:
                    out["patients"] = _as_int(r.get(keys["window_patients"]))
                if out.get("start") and out.get("end"):
                    found = out
    except Exception:
        return None
    return found


def _population_filter_from_patterns(patterns: list[str]) -> str:
    """Read the population filter out of the metric definitions themselves.

    The definition is the authority on which rows a metric covers — that is the
    whole reason the slug exists. Rather than guessing a filter, look at the
    canonical SQL and reuse the claim_type predicate it declares.
    """
    import re as _re
    for p in patterns:
        if not isinstance(p, str):
            continue
        m = _re.search(r"claim_type\s*=\s*'([^']+)'", p)
        if m:
            return m.group(1)
    return ""


@dataclass
class WindowSource:
    """Where a data window is measured FROM, declared rather than assumed.

    The upstream implementation hardcodes `commercial.ladd`, `svc_dt`,
    `pat_id` and `clm_typ='Rx'` into the engine. That works for a
    single-product engine and cannot work here: `agentfarm-core` is shared by
    every pack, and a claims table is one domain's fact. Same computation, four
    identifiers lifted out — the pack that owns the data names them.
    """
    table: str
    date_column: str
    #: counted with COUNT(DISTINCT ...) — patients, vendors, accounts.
    entity_column: str | None = None
    #: optional equality filter, e.g. ("clm_typ", "Rx"), so encounters do not
    #: sit in a dispense denominator.
    filter_column: str | None = None
    filter_value: str | None = None


def window_source_from_catalog(catalog: dict) -> "WindowSource | None":
    """Read the optional `window_source:` block from a pack's catalog.

    Absent is the normal case and means "do not compute" — never a guess at
    which table is the fact table.
    """
    if not isinstance(catalog, dict):
        return None
    ws = catalog.get("window_source")
    if not isinstance(ws, dict):
        return None
    table, date_column = ws.get("table"), ws.get("date_column")
    if not isinstance(table, str) or not isinstance(date_column, str):
        return None
    opt = lambda k: ws.get(k) if isinstance(ws.get(k), str) else None
    return WindowSource(table=table, date_column=date_column,
                        entity_column=opt("entity_column"),
                        filter_column=opt("filter_column"),
                        filter_value=opt("filter_value"))


#: `schema.table` or a bare identifier. `[.]` rather than an escape so the
#: pattern survives being read, edited and re-quoted by hand.
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*([.][A-Za-z_][A-Za-z0-9_]*)*$")


def compute_data_window(envelope: dict, db_url: str,
                        source: "WindowSource | None" = None) -> dict | None:
    """Compute `evidence.data_window` from the database — a projection, not a claim.

    Takes the window the agent DECLARED (start/end, which it gets right) and
    replaces the bounds and counts with measured ones, clamped to the data's
    real range. Returns None on any doubt, so a caller keeps what the agent
    emitted rather than swapping in a guess.

    Why this exists: the counts are the half an agent restates from memory.
    Observed live — an envelope whose table rows were exact to the row declared
    2026-01-09..2026-07-31 / 530 claims / 212 patients against a true
    2025-08-01..2026-08-17 / 530 / 94. EVERY internal-consistency check in
    `validate_data_window` passes on that: 212 < 530, the dates are ordered,
    and the end falls before the last service date. Only measurement catches it.

    `source` is required in practice: with none this returns None rather than
    guessing which table is the fact table.
    """
    if not isinstance(envelope, dict) or not db_url or source is None:
        return None
    ev = envelope.get("evidence")
    if not isinstance(ev, dict):
        return None
    dw = ev.get("data_window")
    if not isinstance(dw, dict):
        return None
    start = _as_date_key(dw.get("start"))
    end = _as_date_key(dw.get("end"))
    if not start or not end or start > end:
        return None

    # Identifiers cannot be bound as parameters, so they are interpolated —
    # which makes validating their SHAPE the thing standing between a catalog
    # file and arbitrary SQL. Values stay parameterised.
    for ident in (source.table, source.date_column,
                  source.entity_column, source.filter_column):
        if ident is not None and not _IDENT_RE.match(ident):
            return None

    try:
        import psycopg2
    except ImportError:
        return None

    where_filter, filter_params = "", []
    if source.filter_column and source.filter_value is not None:
        where_filter = f" AND {source.filter_column} = %s"
        filter_params = [source.filter_value]

    try:
        with psycopg2.connect(db_url) as cn:
            with cn.cursor() as cur:
                # Clamp to the data's real range. A window anchored on the
                # calendar runs past the last row, so counting it verbatim
                # reports a window the data does not cover.
                cur.execute(
                    f"SELECT MIN({source.date_column}), MAX({source.date_column}) "
                    f"FROM {source.table} WHERE TRUE{where_filter}", filter_params)
                _lo, _hi = cur.fetchone()
                if _hi is not None and end > str(_hi):
                    # Shift the WHOLE window back by the same amount, so a
                    # "last 3 months" ask stays three months long instead of
                    # being truncated to whatever overlaps the data.
                    from datetime import date as _date
                    try:
                        _e, _s = _date.fromisoformat(end), _date.fromisoformat(start)
                        _new_e = _date.fromisoformat(str(_hi))
                        start, end = str(_s - (_e - _new_e)), str(_new_e)
                    except Exception:
                        end = str(_hi)
                if _lo is not None and start < str(_lo):
                    start = str(_lo)

                entity = (f", COUNT(DISTINCT {source.entity_column})"
                          if source.entity_column else "")
                cur.execute(
                    f"SELECT COUNT(*){entity} FROM {source.table} "
                    f"WHERE {source.date_column} >= %s AND {source.date_column} <= %s"
                    f"{where_filter}", [start, end, *filter_params])
                row = cur.fetchone()
                if not row:
                    return None
                out = {"start": start, "end": end, "claims": int(row[0])}
                if source.entity_column:
                    out["patients"] = int(row[1])
                return out
    except Exception:
        return None
