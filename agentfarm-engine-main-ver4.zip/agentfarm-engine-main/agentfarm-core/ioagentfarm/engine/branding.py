"""Present the engine as ``aicore`` in operator-facing output.

A workflow developer in a solution repo writes workflow.yaml and runs
`aicore run`. They never read agentfarm-core source. What they DO see is the
console during a run — and loguru stamps every record with the engine's IMPORT
package, ``ioagentfarm.engine.learning.distiller``: a name that is not the
product's, not in their documentation, and not one they were ever given.
``aicore`` is a real console script for the same application, so a rewritten
line that quotes a command still runs.

This rewrites that at DISPLAY time. The agent runtime needs no such rewrite:
its import package, banner, logger names and logo are ``iobot`` / ``(io)`` in
the vendored source itself, so nothing about it is renamed here.

What this does NOT touch, on purpose
------------------------------------
* ``forensics/stdout.log`` — a raw byte tee, written before this runs. Forensic
  blobs and session JSONL are EVIDENCE; rewriting them to satisfy branding
  would corrupt the record a debugger depends on.
* Agent-authored artifacts (OUTPUT.md, hub_note.md, …) — written by the agent
  straight to disk, never through this path.
* Identifiers a person must TYPE: ``IOF_*`` variables, ``ioagentfarm_thing``.
  A ``\\b`` boundary keeps them intact, because rewriting a name someone has to
  type turns a cosmetic problem into a broken instruction.
"""

from __future__ import annotations

import re

# Word-boundary so we rewrite the package name, not arbitrary substrings.
# Case-preserving because log records vary and the name appears in prose.
_PATTERN = re.compile(r"\b(ioagentfarm)\b", re.IGNORECASE)

_REPLACEMENTS = {
    "ioagentfarm": "aicore",
    "Ioagentfarm": "Aicore",
    "IOAgentFarm": "AICore",
    "IOAGENTFARM": "AICORE",
}


def _swap(match: re.Match[str]) -> str:
    found = match.group(0)
    direct = _REPLACEMENTS.get(found)
    if direct is not None:
        return direct
    if found.isupper():
        return "AICORE"
    if found[:1].isupper():
        return "Aicore"
    return "aicore"


def rebrand(text: str) -> str:
    """Rewrite the engine's import-package name for display. Safe on arbitrary text."""
    if not text:
        return text
    if "ioagentfarm" not in text.lower():
        return text  # fast path: the overwhelming majority of lines
    return _PATTERN.sub(_swap, text)


def install_log_rebranding() -> bool:
    """Rewrite loguru record module names in THIS process (the `serve` path).

    Subprocess output is handled in ``cli.py:_invoke_agent``, but `serve` runs
    agents in-process, so its logs never pass through that reader.

    Uses ``logger.configure(patcher=...)`` — the global hook — because
    ``logger.patch()`` returns a NEW logger and would not affect the singleton
    that every runtime module already imported.

    Returns True if installed. Best-effort by design: a later
    ``logger.configure()`` anywhere replaces the patcher, and loguru offers no
    way to chain one. Branding is not worth fighting the logging stack for, so
    this fails quiet rather than loud.
    """
    try:
        from loguru import logger
        from ioagentfarm.engine import log_redaction as _redaction
    except Exception:
        return False

    def _patcher(record: dict) -> None:
        name = record.get("name") or ""
        # `rebrand()` has its own fast path for text carrying no engine name,
        # so this is one substring test per record.
        if name:
            record["name"] = rebrand(name)
        # LOGURU HAS ONE PATCHER SLOT, as the docstring above says, so
        # redaction rides this one rather than competing for it — a second
        # `logger.configure()` would silently replace the first, and whichever
        # lost would fail open. The runtime logs both halves of every turn at
        # INFO; `log_redaction` decides what survives.
        _redaction.redact_record(record)

    try:
        logger.configure(patcher=_patcher)
        return True
    except Exception:
        return False
