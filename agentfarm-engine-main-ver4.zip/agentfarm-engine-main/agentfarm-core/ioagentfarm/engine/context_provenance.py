"""What actually reaches the model, and — when it does not — why.

MATERIALIZED IS NOT LOADED. That sentence is already in CLAUDE.md as the bug
worth remembering: ingest wrote ``skills/learned/<name>.md`` flat while the
runtime's loader discovers ``skills/<name>/SKILL.md``, so every approved skill
landed where no agent could load it. The injection was recorded, the
attribution was counted, and ZERO turns were influenced. It was caught by an
A/B fingerprint test (not loadable -> 1/6 terms; loadable -> 6/6), which is a
heroic way to learn that a file is in the wrong shape.

This module is the standing version of that check. For one agent it answers,
per file, *does this contribute to the system prompt* — and when the answer is
no, WHICH RULE dropped it.

THE ONE DESIGN RULE: ASK THE CONSUMER, NEVER REIMPLEMENT IT.
Every fact here comes from the runtime's own :class:`SkillsLoader` and
:class:`ContextBuilder` — ``get_always_skills()``, ``get_skill_availability()``,
``get_skill_metadata()``, ``BOOTSTRAP_FILES``, ``_is_template_content``. A
report that re-derived "a skill is a directory with a SKILL.md" would be a
SECOND implementation of the rule the original bug was made of: the writer and
the reader disagreeing. Two implementations cannot disagree if there is only
one, so the only thing this module owns is the WALK of the tree — what exists
on disk — and it hands every question about meaning to the loader.

Consequence worth knowing: this reports the view of the interpreter it runs in.
``aicore patches`` has exactly this caveat already ("reports the CLI's own
interpreter, not the child"), and the gates that matter here are call-time env
reads — ``memory_v1_off`` keys on ``IOF_LEARNING_V2`` at every call. So the
report names the gates it observed rather than implying it observed the child.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

#: Why a file that EXISTS does not reach the model. Each value is a rule in
#: the runtime, not a rule of ours — the docstring on each is the loader
#: behaviour it names, so a reader can go check it.
NOT_A_SKILL_DIRECTORY = "not-a-skill-directory"
"""A `.md` under `skills/` that is not `<name>/SKILL.md`. `SkillsLoader.
_skill_entries_from_dir` requires a DIRECTORY holding a file named exactly
`SKILL.md`; anything else is invisible. This is the flat-file bug."""

EMPTY_SKILL_DIRECTORY = "empty-skill-directory"
"""A directory under `skills/` with no `SKILL.md` in it."""

SHADOWED_BY_WORKSPACE = "shadowed-by-workspace"
"""A builtin skill whose name a workspace skill also uses. `list_skills`
passes `skip_names=workspace_names`, so the builtin copy never loads."""

DISABLED = "disabled"
"""Named in `disabled_skills`."""

REQUIREMENTS_UNMET = "requirements-unmet"
"""`requires.bins` not on PATH or `requires.env` unset. `_check_requirements`
returns False, which drops the skill from `list_skills(filter_unavailable=
True)` AND from `get_always_skills()` — so an `always: true` skill with a
missing binary is silently not always-on."""

FRONTMATTER_UNPARSEABLE = "frontmatter-unparseable"
"""`get_skill_metadata` returns None on a YAML error, so `always` is never
seen and an always-on skill is silently demoted to on-demand. This is the
lint-skill defect (an unquoted description containing ": " is a mapping, not
a string) seen from the loader's side."""

TEMPLATE_UNMODIFIED = "template-unmodified"
"""`_is_template_content` — an AGENTS.md/USER.md still byte-identical to the
bundled template is skipped, and an unmodified SOUL.md is REPLACED by the
bundled one."""

EMPTY = "empty"
"""`_load_bootstrap_files` skips a file whose content does not `.strip()`."""

MEMORY_GATED = "memory-gated"
"""`memory_v1_off`: under learning v2 (the default) `get_memory_context()`
returns "" — MEMORY.md is neither loaded nor populated."""

NOT_READ_BY_RUNTIME = "not-read-by-runtime"
"""The file is materialized by this platform but appears in no context source
the runtime reads. `ContextBuilder.BOOTSTRAP_FILES` is the whole identity
list; a file outside it reaches the model through nothing."""


#: HOW a file reaches the model. The distinction is the loader's, not ours,
#: and collapsing it would hide the finding that matters most.
#:
#: `build_skills_summary` lists EVERY discovered skill — including ones whose
#: requirements are unmet, which it marks "(unavailable: CLI: foo)". Only
#: `get_always_skills()` — which filters on those same requirements — decides
#: whose full text is injected. So a skill declaring `always: true` with a
#: missing binary is not absent from the prompt: it is DEMOTED to a listing
#: the agent cannot act on. "Dropped" would be wrong about it and "loaded"
#: would be worse.
INJECTED = "injected"    # full text is in the system prompt
LISTED = "listed"        # name + description only (progressive disclosure)
DROPPED = "dropped"      # reaches the model in no form


@dataclass
class ContextFile:
    """One file, and how — or whether — it reaches the model."""

    path: str
    kind: str  # "identity" | "memory" | "skill"
    name: str
    source: str  # "workspace" | "builtin" | "platform"
    mode: str  # INJECTED | LISTED | DROPPED
    reason: str = ""  # empty when nothing surprising happened
    detail: str = ""  # the specific missing bin/env, the shadowing path, ...
    chars: int = 0
    declares_always: bool = False  # the FILE asked for always-on

    @property
    def contributes(self) -> bool:
        return self.mode != DROPPED

    def as_dict(self) -> dict:
        return {
            "path": self.path,
            "kind": self.kind,
            "name": self.name,
            "source": self.source,
            "mode": self.mode,
            "contributes": self.contributes,
            "reason": self.reason,
            "detail": self.detail,
            "chars": self.chars,
            "declares_always": self.declares_always,
        }


@dataclass
class ContextReport:
    role: str
    workspace: str
    files: list[ContextFile] = field(default_factory=list)
    gates: dict = field(default_factory=dict)

    @property
    def loaded(self) -> list[ContextFile]:
        return [f for f in self.files if f.contributes]

    @property
    def dropped(self) -> list[ContextFile]:
        return [f for f in self.files if not f.contributes]

    @property
    def findings(self) -> list[ContextFile]:
        """Outcomes a person would NOT predict from looking at the tree.

        NOT a subset of :attr:`dropped`, and that is the correction worth
        recording: the commonest real failure — a skill declaring
        ``always: true`` whose required binary is missing — comes out
        ``LISTED``, because `build_skills_summary` still lists it (marked
        unavailable) while `get_always_skills` refuses to inject it. Keyed on
        `dropped` this property would have missed the exact case the module
        was written for, and reported a clean bill of health.

        So the key is the REASON, not the mode. A `template-unmodified` skip
        is the system working as designed and is not a finding; a file the
        loader cannot see, or one whose author asked for always-on and did
        not get it, is.

        ONE EXCLUSION, and it is what keeps the list readable: a BUILTIN skill
        with an unmet requirement is upstream shipping an optional capability
        and correctly marking it unavailable — iobot bundles `tmux` and
        `summarize`, whose binaries exist on no stock Windows box. Reported as
        findings they appear on every machine in every report, and a list that
        always has two entries in it is a list nobody reads; the real finding
        then arrives as a third line among noise. A builtin that DECLARES
        always-on still counts, because that one is load-bearing wherever it
        came from.
        """
        surprising = (NOT_A_SKILL_DIRECTORY, EMPTY_SKILL_DIRECTORY,
                      FRONTMATTER_UNPARSEABLE, REQUIREMENTS_UNMET,
                      NOT_READ_BY_RUNTIME)
        return [
            f for f in self.files
            if f.reason in surprising
            and not (f.source == "builtin"
                     and f.reason == REQUIREMENTS_UNMET
                     and not f.declares_always)
        ]

    def as_dict(self) -> dict:
        return {
            "role": self.role,
            "workspace": self.workspace,
            "gates": self.gates,
            "summary": {
                "loaded": len(self.loaded),
                "dropped": len(self.dropped),
                "findings": len(self.findings),
            },
            "files": [f.as_dict() for f in self.files],
        }


def _chars(path: Path) -> int:
    try:
        return len(path.read_text(encoding="utf-8"))
    except OSError:
        return 0


def _memory_is_gated() -> bool:
    """The same call-time gate `memory_v1_off` reads.

    Deliberately re-expressed rather than imported: the patch gates INSIDE
    `MemoryStore.get_memory_context`, and importing that would require the
    patch to be applied in this process to observe it. Reading the env the
    same way is honest about being an observation of THIS interpreter, which
    is what the module docstring promises.
    """
    v2_off = (os.environ.get("IOF_LEARNING_V2") or "").strip() == "0"
    v1_on = (os.environ.get("IOF_LEARNING_V1") or "").strip() == "1"
    # Only the explicit two-key legacy opt-in unpauses MEMORY.md.
    return not (v2_off and v1_on)


def _skill_files(report: ContextReport, ws: Path, loader) -> None:
    """Every skill on disk, and the loader's verdict on each."""
    skills_root = ws / "skills"

    # What the loader CAN see. `filter_unavailable=False` because that is what
    # `build_skills_summary` itself passes — an unavailable skill is still
    # LISTED, marked "(unavailable: ...)", and reporting it as absent would
    # misdescribe the prompt.
    discovered = loader.list_skills(filter_unavailable=False)
    by_name = {e["name"]: e for e in discovered}
    always = set(loader.get_always_skills())
    workspace_names = {e["name"] for e in discovered if e["source"] == "workspace"}
    disabled = set(getattr(loader, "disabled_skills", None) or ())

    for entry in discovered:
        name, path = entry["name"], Path(entry["path"])
        meta = loader.get_skill_metadata(name)
        available, missing = loader.get_skill_availability(name)
        declares_always = bool(meta and (meta.get("always")
                                         or _nested_always(loader, meta)))

        mode, reason, detail = LISTED, "", ""
        if name in disabled:
            mode, reason = DROPPED, DISABLED
        elif name in always:
            mode = INJECTED
        elif declares_always and not available:
            # THE FINDING THIS MODULE EXISTS FOR, in its commonest shape.
            # `get_always_skills` filters on the same requirements check, so
            # a missing binary turns an always-on skill into a listing that
            # advertises itself as unavailable. Nothing anywhere says so.
            reason, detail = REQUIREMENTS_UNMET, (
                f"declares always: true, but {missing} is missing, so it is "
                f"listed as unavailable instead of injected")
        elif not available:
            reason, detail = REQUIREMENTS_UNMET, f"{missing} missing"
        elif meta is None and _raw_declares_always(path):
            # The file says `always:` and the loader could not parse the
            # block, so `get_always_skills` never saw it. It still loads on
            # demand — the author asked for always-on and did not get it.
            reason, detail = FRONTMATTER_UNPARSEABLE, (
                "declares `always:` but the YAML frontmatter does not parse, "
                "so it is listed on demand instead of injected")
        elif declares_always:
            reason, detail = FRONTMATTER_UNPARSEABLE, (
                "declares always but the loader does not report it as one")

        report.files.append(ContextFile(
            path=str(path), kind="skill", name=name, source=entry["source"],
            mode=mode, reason=reason, detail=detail, chars=_chars(path),
            declares_always=declares_always))

    # What the loader CANNOT see. This is the flat-file bug's home: a walk of
    # the tree minus everything the loader discovered.
    if skills_root.is_dir():
        for child in sorted(skills_root.iterdir()):
            if child.is_file() and child.suffix == ".md":
                report.files.append(ContextFile(
                    path=str(child), kind="skill", name=child.stem,
                    source="workspace", mode=DROPPED,
                    reason=NOT_A_SKILL_DIRECTORY,
                    detail=f"the loader reads skills/<name>/SKILL.md; move it "
                           f"to skills/{child.stem}/SKILL.md",
                    chars=_chars(child)))
            elif child.is_dir() and not (child / "SKILL.md").exists():
                report.files.append(ContextFile(
                    path=str(child), kind="skill", name=child.name,
                    source="workspace", mode=DROPPED,
                    reason=EMPTY_SKILL_DIRECTORY,
                    detail="no SKILL.md in this directory"))

    # Builtin skills a workspace skill shadows by name — `list_skills` passes
    # `skip_names=workspace_names`, so the builtin copy is never even an entry.
    builtin = getattr(loader, "builtin_skills", None)
    if builtin and Path(builtin).is_dir():
        for child in sorted(Path(builtin).iterdir()):
            if not child.is_dir() or child.name not in workspace_names:
                continue
            sk = child / "SKILL.md"
            if sk.exists() and str(sk) != by_name[child.name]["path"]:
                report.files.append(ContextFile(
                    path=str(sk), kind="skill", name=child.name,
                    source="builtin", mode=DROPPED,
                    reason=SHADOWED_BY_WORKSPACE,
                    detail=f"the workspace copy at "
                           f"{by_name[child.name]['path']} wins",
                    chars=_chars(sk)))


def _nested_always(loader, meta: dict) -> bool:
    """`always` can live under the nested iobot/openclaw metadata block."""
    try:
        return bool(loader._parse_iobot_metadata(meta.get("metadata")).get("always"))
    except Exception:
        return False


def _raw_declares_always(path: Path) -> bool:
    try:
        head = path.read_text(encoding="utf-8", errors="replace")[:2000]
    except OSError:
        return False
    return "always:" in head or '"always"' in head


def _identity_files(report: ContextReport, ws: Path, builder_cls) -> None:
    """The bootstrap files, plus the ones this platform writes and nothing reads."""
    bootstrap = list(getattr(builder_cls, "BOOTSTRAP_FILES",
                             ["AGENTS.md", "SOUL.md", "USER.md"]))
    skippable = set(getattr(builder_cls, "_SKIPPABLE_DEFAULTS",
                            {"AGENTS.md", "USER.md"}))

    for fname in bootstrap:
        path = ws / fname
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        reason = detail = ""
        mode = INJECTED
        if not text.strip():
            mode, reason = DROPPED, EMPTY
        elif fname in skippable and _is_template(builder_cls, text, fname):
            mode, reason = DROPPED, TEMPLATE_UNMODIFIED
            detail = "byte-identical to the bundled template, so the loader skips it"
        elif fname == "SOUL.md" and _is_template(builder_cls, text, "legacy/SOUL.md"):
            detail = ("unmodified legacy template - the BUNDLED SOUL.md is "
                      "substituted, so this file's text is not what reaches "
                      "the model")
        report.files.append(ContextFile(
            path=str(path), kind="identity", name=fname, source="workspace",
            mode=mode, reason=reason, detail=detail, chars=len(text)))

    # FILES THIS PLATFORM MATERIALIZES THAT NO CONTEXT SOURCE READS.
    # `TOOLS.md` is copied by `ensure_agent_workspace`, scaffolded by
    # `new-agent`, carried in `_IDENTITY_FILES`, synced into `agents.tools_md`
    # and named in CLAUDE.md beside SOUL.md as "static personality" — and it
    # is in no BOOTSTRAP_FILES list and appears nowhere in the vendored tree.
    # It renders on the Studio's agent-detail screen, which is a real use; it
    # has never influenced a turn, which is not what "identity file" implies.
    # TOOLS.md ONLY, and the list stays that short deliberately. The first
    # cut guessed at ("TOOLS.md", "HEARTBEAT.md", "team.md") on the strength
    # of "our code copies it and BOOTSTRAP_FILES does not name it", and was
    # wrong on two of the three:
    #
    #   HEARTBEAT.md - READ. `iobot/cli/commands.py` opens
    #                  `config.workspace_path / "HEARTBEAT.md"` for the
    #                  gateway heartbeat job. Not a prompt, but a reader.
    #   team.md      - READ. `workflow_loader.py` reads it into
    #                  `Workflow.team`, which reaches the model through the
    #                  step prompt rather than the workspace bootstrap.
    #
    # Both were reported as findings for one run of this command, which is
    # the failure mode a diagnostic can least afford: a check that fails a
    # correct setup gets the NEXT real finding ignored too. Nothing goes in
    # this tuple that has not been grepped to zero readers across the
    # vendored tree AND core.
    for fname in ("TOOLS.md",):
        path = ws / fname
        if fname in bootstrap or not path.exists():
            continue
        report.files.append(ContextFile(
            path=str(path), kind="identity", name=fname, source="platform",
            mode=DROPPED, reason=NOT_READ_BY_RUNTIME,
            detail="no context source reads this file; it is carried for the "
                   "catalog and the Studio, not for the model",
            chars=_chars(path)))


def _is_template(builder_cls, text: str, template_path: str) -> bool:
    try:
        return bool(builder_cls._is_template_content(text, template_path))
    except Exception:
        return False


def _memory_file(report: ContextReport, ws: Path) -> None:
    path = ws / "memory" / "MEMORY.md"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8", errors="replace")
    gated = _memory_is_gated()
    report.files.append(ContextFile(
        path=str(path), kind="memory", name="MEMORY.md", source="workspace",
        mode=(DROPPED if (gated or not text.strip()) else INJECTED),
        reason=MEMORY_GATED if gated else ("" if text.strip() else EMPTY),
        detail=("learning v2 is on, so get_memory_context() returns '' - the "
                "file is untouched and unsetting the gate restores it")
        if gated else "",
        chars=len(text)))


def build_report(role: str, workspace_dir: Path | None = None) -> ContextReport:
    """Ask the runtime's own loaders what reaches the model for *role*.

    ``workspace_dir`` overrides resolution — used by tests and by anything
    inspecting a filtered per-run workspace rather than the agent home.

    Resolution goes through :func:`iobot_agent_workspace`, the canonical
    role-string-to-path function, EVEN THOUGH it can trigger the renamed-home
    migration. A diagnostic should not create state; a diagnostic that reports
    on a different directory than the runtime reads is worse, because it is
    confidently wrong about the only question being asked. The migration it
    can trigger is the one the next run performs anyway.
    """
    from iobot.agent.context import ContextBuilder
    from iobot.agent.skills import SkillsLoader

    if workspace_dir is not None:
        ws = Path(workspace_dir)
    else:
        from ioagentfarm.engine.workspaces import iobot_agent_workspace
        ws = iobot_agent_workspace(role)

    report = ContextReport(role=role, workspace=str(ws), gates={
        "memory_gated": _memory_is_gated(),
        "learning_v2": (os.environ.get("IOF_LEARNING_V2") or "1").strip() != "0",
    })
    if not ws.is_dir():
        return report

    loader = SkillsLoader(ws)
    _identity_files(report, ws, ContextBuilder)
    _memory_file(report, ws)
    _skill_files(report, ws, loader)
    return report
