"""Narrate a detached run: what each step did, and why it stopped moving.

WHAT THIS IS FOR. `aicore run` streams the agent's own output while it blocks,
so an operator sees the work happen. `aicore run --json` detaches - which is
what `run_ops` asks for, because a run outlives the session that started it -
and from that moment nothing is emitted at all. The run progresses, the console
is silent, and "is it working or is it dead?" has no answer short of somebody
knowing to run three different forensics commands.

`forensics tail` already streams the raw event vocabulary, and that is the
right substrate but the wrong reading: ``step.inline_complete_refused`` and
``step.subprocess_exited rc=0 after 16.087s`` are the engine talking to itself.
This turns the same events into what a person actually wants to know - a step
started, who is doing it, how long it took, what it cost, what is next - and,
crucially, ESCALATES on its own when nothing has moved.

THE ESCALATION IS THE POINT. Observed 2026-08-16: a signal_detection run spent
twenty minutes on two ``agent_premature_termination`` retries that Fix 6
absorbed silently. Nothing was wrong - the recovery layer was working exactly
as designed - but the console said nothing for twenty minutes and the operator
had no way to tell that from a hang. So when a step goes quiet past the
supervisor's own staleness threshold, this asks the question a human would ask
next: is this recovery, or is it stuck? It says which, and stays watching.

It is a REPORTER. It never retries, never kills, never intervenes - fighting
the recovery machinery is the one thing the resilience design asks nobody to
do, and a watcher that acts would be exactly that.
"""

from __future__ import annotations

from typing import Any

#: Events that are the engine talking to itself. Dropping them is the
#: difference between a log and a narration.
_NOISE = {
    "agent.next_step_polled",           # the driver checking - constant
    "step.inline_complete_refused",     # governance, correct, uninteresting
    "step.output_md_written",           # implied by finalized
    "step.spawn_subprocess",            # implied by started
}


def humanise(event: dict) -> str | None:
    """One event as a line a person would write. None = not worth saying."""
    kind = event.get("event_type") or ""
    if kind in _NOISE:
        return None
    step = event.get("step_key") or ""
    msg = event.get("message") or ""
    payload = event.get("payload") or {}

    if kind == "run.created":
        return f"run created - {payload.get('workflow') or msg}"
    if kind == "step.started":
        role = payload.get("role") or ""
        att = event.get("attempt")
        suffix = f" (attempt {att})" if att and int(att) > 1 else ""
        return f"{step} started{suffix}" + (f" - {role}" if role else "")
    if kind == "step.exec_completed":
        return f"{step} done - {msg}"
    if kind == "step.subprocess_exited":
        return f"{step} agent finished - {msg}"
    if kind == "step.tool_usage":
        return f"{step} {msg}"
    if kind == "step.finalized":
        # The payload does not always carry `status`; the message says
        # "_finalize_step completed with status=done", which is the engine
        # narrating its own function call. Take the verdict out of it.
        status = payload.get("status")
        if not status and "status=" in msg:
            status = msg.split("status=", 1)[1].split()[0].strip(".,;")
        return f"{step} -> {status or msg}"
    if kind == "step.auto_retry_after_stall":
        # The one that was invisible for twenty minutes.
        return f"{step} RETRYING - {msg}"
    if kind == "step.artifact_missing":
        return f"{step} BLOCKED - required artifact missing: {msg}"
    if kind == "step.hard_cap_reached":
        return f"{step} GAVE UP - {msg}"
    if kind == "run.coverage":
        checks = payload.get("checks") or []
        return "coverage at completion: " + "; ".join(
            f"{c.get('name')}: {(c.get('output') or '').splitlines()[-1][:60]}"
            for c in checks[:2]) if checks else None
    if kind == "run.completed":
        return "RUN COMPLETE"
    if kind == "run.failed":
        return "RUN FAILED"
    if kind == "run.driver_gave_up":
        return f"DRIVER GAVE UP - {msg}"
    if kind.startswith("swarm."):
        return f"{kind.split('.', 1)[1]} - {msg}"
    return f"{step + ' ' if step else ''}{kind} {msg}".strip()


def live_attempt_dir(root: Any, run_id: str, step_key: str):
    """The blob directory of the attempt currently running, or None.

    Retries live in `stall_attempt_*` SUBdirectories of the attempt, so the
    newest top-level `<step>.<n>` is what a live agent is writing into.
    """
    from pathlib import Path

    safe = step_key.replace(":", "_").replace("/", "_")
    base = Path(root) / "instances" / run_id / "forensics" / "attempts"
    if not base.is_dir():
        return None
    mine = [d for d in base.iterdir()
            if d.is_dir() and d.name.rsplit(".", 1)[0] == safe]
    if not mine:
        return None
    return max(mine, key=lambda d: d.stat().st_mtime)


def agent_lines(path, offset: int) -> tuple[list[str], int]:
    """New agent output since *offset*, as readable lines.

    THIS is what `aicore run` shows and a detached run does not: the agent's
    own reasoning. It is captured to stdout.log for every run, attached or
    not, and nothing surfaced it.

    Read as BYTES and decoded here, because the runtime redraws its live view
    with bare carriage returns on Windows - reading it as text would translate
    those to newlines and duplicate every visual line (the same reason
    `_invoke_agent` reads the stream as bytes). ANSI is stripped and the
    upstream branding rewritten, so the reader sees the same console the
    attached run would have shown.
    """
    import re

    if path is None or not path.exists():
        return [], offset
    size = path.stat().st_size
    if size <= offset:
        return [], offset               # truncated or nothing new
    with open(path, "rb") as fh:
        fh.seek(offset)
        chunk = fh.read()
    text = chunk.decode("utf-8", "replace")
    text = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", text)      # ANSI
    out = [l.rstrip() for l in text.replace("\r", "\n").splitlines() if l.strip()]
    return out, size


def quiet_for(step: dict) -> float | None:
    """Seconds since this running step last showed a heartbeat."""
    from datetime import datetime, timezone

    stamp = step.get("heartbeat_at") or step.get("updated_at")
    if not stamp:
        return None
    try:
        t = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        if t.tzinfo is None:
            t = t.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - t).total_seconds()
    except (TypeError, ValueError):
        return None


def diagnose(store: Any, run_id: str, step_key: str, root: Any) -> str:
    """Why has this step gone quiet? Recovery, or genuinely stuck.

    Asks the same question a person would, using the instrument that settles
    it: `is-recovering` is structural (was the latest attempt finalized?)
    rather than time-based, so it distinguishes "Fix 6 is mid-retry" from
    "nothing is happening" without guessing.
    """
    try:
        from ioagentfarm.engine.forensics import get_forensics
        events = get_forensics(root).get_run_timeline(run_id) or []
    except Exception:                                        # noqa: BLE001
        return "cannot reach the forensic record to say why"

    mine = [e for e in events if (e.get("step_key") or "") == step_key]
    # a command step's start is `step.exec_started`; the first cut looked
    # for the agent path's event only and said "no start event recorded"
    # beside the recorded one (novice finding, round 3)
    started = [e for e in mine
               if e.get("event_type") in ("step.started", "step.exec_started")]
    try:
        from ioagentfarm.engine.supervisor import driver_state
        _run = store.get_run(run_id)
        _ds = driver_state(_run, store.list_steps(run_id))
        if _ds["stale"]:
            _age = _ds["heartbeat_age_s"]
            return (f"the DRIVER is gone - no heartbeat for "
                    f"{'ever' if _age is None else f'{_age:.0f}s'}; nothing will "
                    f"move. Restart it: `aicore resume {run_id}`")
    except Exception:  # noqa: BLE001
        pass
    if not started:
        return "no start event recorded - the step may not have spawned"
    latest_attempt = started[-1].get("attempt")
    finalized = [e for e in mine
                 if e.get("event_type") == "step.finalized"
                 and e.get("attempt") == latest_attempt]
    if finalized:
        return "the attempt finalized; the driver has not yet moved on"

    after = [e.get("event_type") for e in mine
             if (e.get("attempt") == latest_attempt
                 and e.get("event_type") != "step.started")]
    if "step.auto_retry_after_stall" in after:
        return ("Fix 6 is auto-retrying after a stall - this is recovery "
                "working, leave it alone")
    if "step.subprocess_exited" in after:
        return "the agent exited; the step is being finalized"
    return _liveness_verdict(store, run_id, step_key, root)


def _blob_age_s(attempt_dir) -> float | None:
    """Seconds since the live attempt's newest blob was written, or None."""
    import time
    if attempt_dir is None:
        return None
    newest = None
    for name in ("stdout.log", "http.log", "stderr.log"):
        f = attempt_dir / name
        try:
            m = f.stat().st_mtime
        except OSError:
            continue
        newest = m if newest is None else max(newest, m)
    return None if newest is None else max(0.0, time.time() - newest)


def _liveness_verdict(store: Any, run_id: str, step_key: str, root: Any) -> str:
    """Alive, dead, or alive-but-mute - from evidence, not from absence.

    The event log says nothing between `step.spawn_subprocess` and
    `step.subprocess_exited`, so a structural check alone always concluded
    "still running - leave it alone; the harness will retry if it dies".
    Printed by `watch` ONLY once the heartbeat is already past the stale
    threshold, that sentence was wrong every time it appeared: a live
    executor beats every 30s. Seen on a client box for fifteen minutes on
    a step whose process was gone, while `status` said running and nothing
    swept a detached run. Three sources settle it: the heartbeat age, the
    age of the newest forensic blob, and `exit.json`.
    """
    from ioagentfarm.engine.supervisor import _step_stale_s

    try:
        step = next((s for s in store.list_steps(run_id)
                     if s.get("step_key") == step_key), None)
    except Exception:                                        # noqa: BLE001
        step = None
    quiet = quiet_for(step) if step else None
    stale = _step_stale_s()
    d = live_attempt_dir(root, run_id, step_key)
    blob_age = _blob_age_s(d)
    exited = d is not None and (d / "exit.json").is_file()

    if exited:
        return ("the agent subprocess EXITED (exit.json is written) but the "
                "step was never finalized - the run-step process died on the "
                f"way out. Run `aicore supervise --once --run-id {run_id}` "
                f"(the sweep a detached run never gets), then `aicore "
                f"forensics explain {run_id}` for what to do next")
    if quiet is not None and quiet > stale:
        if blob_age is not None and blob_age <= stale:
            return (f"the agent is ALIVE - it wrote output {int(blob_age)}s "
                    f"ago - but its heartbeat is {int(quiet)}s old: the "
                    "step's heartbeat write is failing (a locked SQLite "
                    "file, a dropped DB connection). Do not retry; check the "
                    "engine log for the write error")
        seen = (f"no output for {int(blob_age)}s" if blob_age is not None
                else "no output blob at all")
        return (f"no heartbeat for {int(quiet)}s and {seen}: the process "
                "running this step appears to be GONE. Nothing sweeps a "
                "detached run on its own - run `aicore supervise --once "
                f"--run-id {run_id}` to reap it, then `aicore forensics "
                f"explain {run_id}` for what to do next")
    return ("the agent subprocess is still running - a long LLM call, not a "
            "hang (heartbeat "
            + (f"{int(quiet)}s" if quiet is not None else "unknown")
            + " old). Leave it alone; the harness will retry if it dies")
