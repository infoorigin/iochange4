"""Shared A2A agent card utilities reused across the codebase."""
from __future__ import annotations


def parse_agent_card(card: dict) -> dict:
    """Parse an A2A agent card JSON dict into a catalog entry.

    Returns:
        {
            name: str,          # card.name
            description: str,   # card.description or first skill.description
            a2a_url: str,       # card.supportedInterfaces[0].url
            tags: list[str],    # flat deduped union of skill.tags across all skills
            examples: list[str] # flat union of skill.examples across all skills
        }
    All fields default to "" / [] when absent. Never raises.
    """
    description = card.get("description") or ""
    skills = card.get("skills") or []
    if not description and skills:
        description = skills[0].get("description") or ""

    a2a_url = ""
    interfaces = card.get("supportedInterfaces") or []
    if interfaces:
        a2a_url = (interfaces[0].get("url") or "").rstrip("/")

    seen_tags: set[str] = set()
    tags: list[str] = []
    examples: list[str] = []
    for skill in skills:
        for tag in skill.get("tags") or []:
            t = str(tag).strip()
            if t and t.lower() not in seen_tags:
                seen_tags.add(t.lower())
                tags.append(t)
        examples.extend(skill.get("examples") or [])

    return {
        "name": (card.get("name") or "").strip(),
        "description": description.strip(),
        "a2a_url": a2a_url,
        "tags": tags,
        "examples": examples,
    }
