"""Data retention — the policy, the plan, and the deletion it authorises.

WHAT WAS MISSING. Nothing in the engine expired anything except workspace
memory (``expires_at``, retired by ``aicore memory sweep``). ``runs``,
``steps``, ``messages``, ``forensic_events``, the learning log, the Studio's
conversation threads and the per-run blob directories under
``<IOF_ROOT>/instances/<run_id>/`` (forensic attempts, ``usage.jsonl``,
artifacts) all grew without bound, and ``engine/forensics.py`` promised a
"future ``forensics prune``" that never existed. The one deletion path,
``aicore workspace delete --force``, removes a whole tenant.

THE SHAPE. A policy is a small YAML file naming a window per CLASS; a plan is
a pure read that lists what the policy would delete NOW; ``apply`` performs
exactly that plan, re-checking every guard inside the transaction. Nothing
here has a default window: no file means no policy, and ``prune`` refuses to
run without an explicit ``--older-than`` rather than deleting on a number
nobody wrote down.

The classes::

    runs           completed runs (done/failed/cancelled) and their steps,
                   tasks, stories, messages, forensic events, learning-log
                   rows and memory-consolidation claims
    blobs          <IOF_ROOT>/instances/<run_id>/ of completed runs — the
                   forensic attempts, the run's usage.jsonl, its artifacts
    conversations  studio_conversations + studio_conversation_messages, and
                   `messages` rows that belong to no run (always-on chat)
    memory         workspace-memory rows past their own expires_at — the
                   store's existing rule, invoked here so one command covers
                   everything

WHAT IS NEVER TOUCHED. A run whose status is ``running``; a run with a step
still ``running``; a run younger than the window (age is the run's
``updated_at`` — its last transition — so a run resumed late is measured
from the resume, never from its birth); a failed run's blob directory while
``keep_failed`` is on (the postmortem); a run or message with no workspace
stamp (on a shared database nothing says whose it is — counted and
reported, never guessed at); an instance directory with no run row in THIS
database (a run in another schema on the same host looks identical from the
filesystem).

ORDER. Child rows before the run row, so a foreign key can never be left
dangling; blob directories after the rows of the same run, never before.
On PostgreSQL each destructive statement runs inside a SAVEPOINT, so a table
a young database does not have cannot poison the transaction that is
deleting from the ones it does.

The policy's ``blobs`` window may not exceed ``runs``: a directory whose run
row is already gone is unattributable and would be reported forever.
"""
from __future__ import annotations

import os
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

CLASSES: tuple = ("runs", "blobs", "conversations", "memory")
TERMINAL = ("done", "failed", "cancelled")

#: The keys a policy file may carry. ``usage`` is deliberately not one: the
#: run's ``usage.jsonl`` lives inside its instance directory and leaves with
#: the ``blobs`` class, so a separate window would be a promise the layout
#: cannot keep.
POLICY_KEYS = ("runs", "blobs", "conversations", "keep_failed")

_DURATION = re.compile(r"^\s*(\d+)\s*([dh])\s*$")

#: Tables that hang off a run, in the order they are cleared. The run row
#: itself goes last.
_RUN_CHILD_TABLES: tuple = (
    ("forensic_events", "run_id"),
    ("learning_log", "run_id"),
    ("workspace_memory_runs", "run_id"),
    ("messages", "run_id"),
    ("tasks", "run_id"),
    ("stories", "run_id"),
    ("steps", "run_id"),
)


class PolicyError(ValueError):
    """A retention policy that cannot be honoured as written."""


def parse_duration(text: Any) -> timedelta:
    """``<n>d`` or ``<n>h``. Anything else names the legal forms."""
    m = _DURATION.match(str(text)) if text is not None else None
    if not m:
        raise PolicyError(
            f"invalid duration {text!r}: the legal forms are <n>d (days) or "
            f"<n>h (hours), for example 90d or 12h")
    n, unit = int(m.group(1)), m.group(2)
    if n <= 0:
        raise PolicyError(
            f"invalid duration {text!r}: the count must be at least 1 "
            f"(legal forms: <n>d or <n>h)")
    return timedelta(days=n) if unit == "d" else timedelta(hours=n)


def format_duration(td: Optional[timedelta]) -> str:
    if td is None:
        return "-"
    secs = int(td.total_seconds())
    if secs % 86400 == 0:
        return f"{secs // 86400}d"
    return f"{secs // 3600}h"


@dataclass(frozen=True)
class Policy:
    runs: Optional[timedelta] = None
    blobs: Optional[timedelta] = None
    conversations: Optional[timedelta] = None
    keep_failed: bool = True
    source: str = "(none)"

    def window(self, cls: str) -> Optional[timedelta]:
        return getattr(self, cls, None) if cls in ("runs", "blobs", "conversations") else None

    def as_dict(self) -> Dict[str, Any]:
        return {"runs": format_duration(self.runs), "blobs": format_duration(self.blobs),
                "conversations": format_duration(self.conversations),
                "keep_failed": self.keep_failed, "source": self.source}


def policy_path(workspace_code: Optional[str]) -> Optional[Path]:
    """Where the policy comes from, most explicit first: ``IOF_RETENTION``
    (a path), then ``~/.iobot/workspaces/<code>/retention.yaml``. None when
    neither names a file that exists — except that an ``IOF_RETENTION`` that
    points at nothing is an error, because a deployment that set it meant it."""
    explicit = (os.environ.get("IOF_RETENTION") or "").strip()
    if explicit:
        p = Path(explicit).expanduser()
        if not p.is_file():
            raise PolicyError(f"IOF_RETENTION names {p}, which is not a file")
        return p
    if workspace_code:
        from ioagentfarm.engine.workspace_env import workspace_home
        p = workspace_home(workspace_code) / "retention.yaml"
        if p.is_file():
            return p
    return None


def parse_policy(data: Any, source: str = "(inline)") -> Policy:
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise PolicyError(f"{source}: a retention policy is a mapping of "
                          f"{', '.join(POLICY_KEYS)}")
    unknown = sorted(k for k in data if k not in POLICY_KEYS)
    if unknown:
        hint = ""
        if "usage" in unknown:
            hint = (" ('usage' is not a class: a run's usage.jsonl lives in its "
                    "instance directory and leaves with 'blobs')")
        raise PolicyError(f"{source}: unknown key(s) {', '.join(unknown)}; the legal "
                          f"keys are {', '.join(POLICY_KEYS)}{hint}")
    windows: Dict[str, Optional[timedelta]] = {}
    for key in ("runs", "blobs", "conversations"):
        if key in data and data[key] is not None:
            try:
                windows[key] = parse_duration(data[key])
            except PolicyError as exc:
                raise PolicyError(f"{source}: {key}: {exc}") from None
        else:
            windows[key] = None
    keep_failed = data.get("keep_failed", True)
    if not isinstance(keep_failed, bool):
        raise PolicyError(f"{source}: keep_failed must be true or false")
    if windows["blobs"] is not None and windows["runs"] is not None \
            and windows["blobs"] > windows["runs"]:
        raise PolicyError(
            f"{source}: blobs ({format_duration(windows['blobs'])}) must not exceed "
            f"runs ({format_duration(windows['runs'])}): a blob directory whose run "
            f"row is already gone cannot be attributed to a workspace and is never "
            f"removed")
    return Policy(runs=windows["runs"], blobs=windows["blobs"],
                  conversations=windows["conversations"], keep_failed=keep_failed,
                  source=source)


def load_policy(workspace_code: Optional[str]) -> Optional[Policy]:
    """The resolved policy, or None when no file applies."""
    p = policy_path(workspace_code)
    if p is None:
        return None
    import yaml
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 - name the file, not the parser
        raise PolicyError(f"{p}: not valid YAML ({exc})") from None
    return parse_policy(data, source=str(p))


def override(policy: Optional[Policy], older_than: timedelta,
             classes: Iterable[str] = CLASSES) -> Policy:
    """``--older-than``: one window for every named class, on top of the
    policy in force (or of no policy at all)."""
    base = policy or Policy()
    cls = set(classes)
    if older_than is not None and "runs" in cls and "blobs" not in cls \
            and base.blobs is not None and base.blobs > older_than:
        # Only the runs window moved; a longer blobs window would then be
        # unattributable. Pull it down with it.
        blobs = older_than
    else:
        blobs = base.blobs
    return Policy(
        runs=older_than if "runs" in cls else base.runs,
        blobs=older_than if "blobs" in cls else blobs,
        conversations=older_than if "conversations" in cls else base.conversations,
        keep_failed=base.keep_failed,
        source=f"{base.source} + --older-than {format_duration(older_than)}")


# ---------------------------------------------------------------------------
# the plan — a pure read
# ---------------------------------------------------------------------------

@dataclass
class Plan:
    workspace_code: Optional[str]
    now: datetime
    policy: Policy
    classes: tuple
    runs: List[Dict[str, Any]] = field(default_factory=list)
    blobs: List[Dict[str, Any]] = field(default_factory=list)
    conversations: List[Dict[str, Any]] = field(default_factory=list)
    messages_unattached: int = 0
    memory_expired: int = 0
    #: What was seen and deliberately left, by reason.
    left: Dict[str, int] = field(default_factory=dict)

    def counts(self) -> Dict[str, int]:
        return {
            "runs": len(self.runs),
            "run_children": sum(sum(r["children"].values()) for r in self.runs),
            "blobs": len(self.blobs),
            "conversations": len(self.conversations),
            "conversation_messages": sum(c["messages"] for c in self.conversations),
            "messages_unattached": self.messages_unattached,
            "memory": self.memory_expired,
        }

    def is_empty(self) -> bool:
        return not (self.runs or self.blobs or self.conversations
                    or self.messages_unattached or self.memory_expired)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "workspace": self.workspace_code,
            "now": self.now.isoformat(),
            "policy": self.policy.as_dict(),
            "classes": list(self.classes),
            "counts": self.counts(),
            "runs": [{"id": r["id"], "status": r["status"], "updated_at": r["updated_at"],
                      "children": r["children"]} for r in self.runs],
            "blobs": [{"id": b["id"], "status": b["status"], "path": str(b["path"])}
                      for b in self.blobs],
            "conversations": [{"id": c["id"], "updated_at": c["updated_at"],
                               "messages": c["messages"]} for c in self.conversations],
            "left": dict(self.left),
        }


def _v(row: Any, key: str, idx: int) -> Any:
    if isinstance(row, dict) or hasattr(row, "keys"):
        return row[key]
    return row[idx]


def _is_pg(store) -> bool:
    return store._db.placeholder() == "%s"


def _table_exists(cur, table: str, is_pg: bool) -> bool:
    """Through the catalog, never a failing SELECT (which on PostgreSQL would
    abort the transaction this is asked from)."""
    try:
        if is_pg:
            cur.execute("SELECT 1 FROM information_schema.tables WHERE table_name = %s "
                        "AND table_schema = current_schema()", (table,))
        else:
            cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,))
        return cur.fetchone() is not None
    except Exception:  # noqa: BLE001
        return False


def _guarded(cur, sql: str, params: Sequence[Any] = ()) -> Optional[int]:
    """One destructive statement inside a SAVEPOINT. Returns the rowcount, or
    None when the statement failed and was rolled back to the savepoint —
    the enclosing transaction stays usable on both backends."""
    cur.execute("SAVEPOINT iof_retention")
    try:
        cur.execute(sql, params)
        n = cur.rowcount
        cur.execute("RELEASE SAVEPOINT iof_retention")
        return max(int(n), 0) if n is not None else 0
    except Exception:  # noqa: BLE001 - the table may be absent or shaped differently
        cur.execute("ROLLBACK TO SAVEPOINT iof_retention")
        cur.execute("RELEASE SAVEPOINT iof_retention")
        return None


def _parse_ts(text: Any) -> Optional[datetime]:
    """The store writes ``datetime.now(timezone.utc).isoformat()``; be
    tolerant of a trailing ``Z`` and a naive value, and refuse to date what
    cannot be parsed — an undatable row is never old enough."""
    if not text:
        return None
    s = str(text).strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _workspace_id(cur, store, code: str) -> Optional[int]:
    cur.execute(store._q("SELECT id FROM workspaces WHERE code=?"), (code,))
    row = cur.fetchone()
    return int(_v(row, "id", 0)) if row else None


def _count_children(cur, store, run_ids: List[str], is_pg: bool) -> Dict[str, Dict[str, int]]:
    out: Dict[str, Dict[str, int]] = {rid: {} for rid in run_ids}
    for table, col in _RUN_CHILD_TABLES:
        if not _table_exists(cur, table, is_pg):
            continue
        for i in range(0, len(run_ids), 400):
            chunk = run_ids[i:i + 400]
            marks = ",".join("?" for _ in chunk)
            cur.execute(store._q(f"SELECT {col} AS rid, COUNT(*) AS n FROM {table} "
                                 f"WHERE {col} IN ({marks}) GROUP BY {col}"), tuple(chunk))
            for row in cur.fetchall():
                out[str(_v(row, "rid", 0))][table] = int(_v(row, "n", 1))
    return out


def _running_step_runs(cur, store, run_ids: List[str]) -> set:
    found: set = set()
    for i in range(0, len(run_ids), 400):
        chunk = run_ids[i:i + 400]
        marks = ",".join("?" for _ in chunk)
        cur.execute(store._q(f"SELECT DISTINCT run_id FROM steps WHERE status='running' "
                             f"AND run_id IN ({marks})"), tuple(chunk))
        found.update(str(_v(r, "run_id", 0)) for r in cur.fetchall())
    return found


def plan(store, root: Path, policy: Policy, now: Optional[datetime] = None, *,
         workspace_code: Optional[str] = None,
         classes: Iterable[str] = CLASSES) -> Plan:
    """What *policy* would delete at *now*. Reads only.

    *workspace_code* scopes every class to one tenant; None keeps the plan
    unscoped for the one caller that means a platform-wide sweep and must
    say so. Rows with no workspace stamp are counted under ``left``, never
    selected.
    """
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    cls = tuple(c for c in CLASSES if c in set(classes))
    p = Plan(workspace_code=workspace_code, now=now, policy=policy, classes=cls)
    is_pg = _is_pg(store)
    root = Path(root)

    with store._tx() as cur:
        ws_id: Optional[int] = None
        if workspace_code:
            ws_id = _workspace_id(cur, store, workspace_code)

        # ---- runs and blobs share one candidate scan ---------------------
        need_runs = ("runs" in cls and policy.runs is not None)
        need_blobs = ("blobs" in cls and policy.blobs is not None)
        if need_runs or need_blobs:
            if workspace_code and ws_id is None:
                rows: list = []
            else:
                where = "workspace_id=?" if workspace_code else "1=1"
                cur.execute(store._q(
                    "SELECT id, status, updated_at, created_at FROM runs "
                    f"WHERE {where} ORDER BY updated_at ASC"),
                    (ws_id,) if workspace_code else ())
                rows = [dict(id=str(_v(r, "id", 0)), status=str(_v(r, "status", 1) or ""),
                             updated_at=_v(r, "updated_at", 2), created_at=_v(r, "created_at", 3))
                        for r in cur.fetchall()]
            if workspace_code:
                cur.execute("SELECT COUNT(*) AS n FROM runs WHERE workspace_id IS NULL")
                orphans = int(_v(cur.fetchone(), "n", 0) or 0)
                if orphans:
                    p.left["runs_unattributed"] = orphans

            terminal = [r for r in rows if r["status"] in TERMINAL]
            p.left["runs_running"] = len(rows) - len(terminal)
            busy = _running_step_runs(cur, store, [r["id"] for r in terminal]) if terminal else set()
            if busy:
                p.left["runs_with_running_steps"] = len(busy)
            terminal = [r for r in terminal if r["id"] not in busy]

            def _older(r, window):
                ts = _parse_ts(r["updated_at"]) or _parse_ts(r["created_at"])
                if ts is None:
                    p.left["runs_undatable"] = p.left.get("runs_undatable", 0) + 1
                    return False
                return ts < now - window

            if need_runs:
                eligible = [r for r in terminal if _older(r, policy.runs)]
                p.left["runs_young"] = len(terminal) - len(eligible)
                children = _count_children(cur, store, [r["id"] for r in eligible], is_pg)
                p.runs = [dict(id=r["id"], status=r["status"], updated_at=r["updated_at"],
                               children=children.get(r["id"], {})) for r in eligible]

            if need_blobs:
                inst = root / "instances"
                for r in terminal:
                    d = inst / r["id"]
                    if not d.is_dir():
                        continue
                    if r["status"] == "failed" and policy.keep_failed:
                        p.left["blobs_kept_failed"] = p.left.get("blobs_kept_failed", 0) + 1
                        continue
                    if not _older(r, policy.blobs):
                        p.left["blobs_young"] = p.left.get("blobs_young", 0) + 1
                        continue
                    p.blobs.append(dict(id=r["id"], status=r["status"], path=d))
                # Directories with no run row in THIS database: counted, never removed.
                known = {r["id"] for r in rows}
                if inst.is_dir():
                    unattributed = sum(1 for d in inst.iterdir()
                                       if d.is_dir() and d.name not in known)
                    if unattributed:
                        p.left["blobs_unattributed"] = unattributed

        # ---- conversations -----------------------------------------------
        if "conversations" in cls and policy.conversations is not None:
            cutoff = now - policy.conversations
            if _table_exists(cur, "studio_conversations", is_pg):
                where = "workspace_code=?" if workspace_code else "1=1"
                cur.execute(store._q(f"SELECT id, updated_at FROM studio_conversations "
                                     f"WHERE {where}"),
                            (workspace_code,) if workspace_code else ())
                convs = [(str(_v(r, "id", 0)), _v(r, "updated_at", 1)) for r in cur.fetchall()]
                old = [(cid, ts) for cid, ts in convs
                       if (_parse_ts(ts) or now) < cutoff]
                p.left["conversations_young"] = len(convs) - len(old)
                has_msgs = _table_exists(cur, "studio_conversation_messages", is_pg)
                for cid, ts in old:
                    n = 0
                    if has_msgs:
                        cur.execute(store._q(
                            "SELECT COUNT(*) AS n FROM studio_conversation_messages "
                            "WHERE conversation_id=?" + (" AND workspace_code=?" if workspace_code else "")),
                            (cid, workspace_code) if workspace_code else (cid,))
                        n = int(_v(cur.fetchone(), "n", 0) or 0)
                    p.conversations.append(dict(id=cid, updated_at=ts, messages=n))
            if _table_exists(cur, "messages", is_pg):
                if workspace_code and ws_id is None:
                    p.messages_unattached = 0
                else:
                    where = "workspace_id=?" if workspace_code else "1=1"
                    cur.execute(store._q(
                        f"SELECT COUNT(*) AS n FROM messages WHERE {where} "
                        "AND run_id IS NULL AND created_at < ?"),
                        (ws_id, cutoff.isoformat()) if workspace_code else (cutoff.isoformat(),))
                    p.messages_unattached = int(_v(cur.fetchone(), "n", 0) or 0)
                if workspace_code:
                    cur.execute("SELECT COUNT(*) AS n FROM messages WHERE workspace_id IS NULL "
                                "AND run_id IS NULL")
                    orphans = int(_v(cur.fetchone(), "n", 0) or 0)
                    if orphans:
                        p.left["messages_unattributed"] = orphans

        # ---- memory --------------------------------------------------------
        if "memory" in cls and workspace_code and _table_exists(cur, "workspace_memory", is_pg):
            cur.execute(store._q(
                "SELECT COUNT(*) AS n FROM workspace_memory WHERE workspace_code=? "
                "AND status='active' AND expires_at IS NOT NULL AND expires_at < ?"),
                (workspace_code, now.isoformat()))
            p.memory_expired = int(_v(cur.fetchone(), "n", 0) or 0)
    return p


# ---------------------------------------------------------------------------
# apply — exactly the plan, guards re-checked inside the transaction
# ---------------------------------------------------------------------------

@dataclass
class Report:
    plan: Plan
    removed: Dict[str, int] = field(default_factory=dict)
    blobs_removed: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict[str, Any]:
        return {"removed": dict(self.removed), "blobs_removed": list(self.blobs_removed),
                "skipped": list(self.skipped), "errors": list(self.errors),
                "workspace": self.plan.workspace_code}


def _bump(d: Dict[str, int], key: str, n: Optional[int]) -> None:
    if n:
        d[key] = d.get(key, 0) + int(n)


def _delete_run(store, run_id: str, report: Report) -> bool:
    """One run's rows in one transaction. Re-checks that the run is still
    terminal with no running step — a resume between plan and apply flips a
    run back to ``running``, and that run is not ours to delete."""
    is_pg = _is_pg(store)
    with store._tx() as cur:
        cur.execute(store._q("SELECT status FROM runs WHERE id=?"), (run_id,))
        row = cur.fetchone()
        if row is None:
            report.skipped.append(f"{run_id}: already gone")
            return False
        if str(_v(row, "status", 0)) not in TERMINAL:
            report.skipped.append(f"{run_id}: no longer terminal")
            return False
        cur.execute(store._q("SELECT COUNT(*) AS n FROM steps WHERE run_id=? AND status='running'"),
                    (run_id,))
        if int(_v(cur.fetchone(), "n", 0) or 0):
            report.skipped.append(f"{run_id}: a step is running")
            return False
        for table, col in _RUN_CHILD_TABLES:
            if not _table_exists(cur, table, is_pg):
                continue
            n = _guarded(cur, store._q(f"DELETE FROM {table} WHERE {col}=?"), (run_id,))
            if n is None:
                report.errors.append(f"{run_id}: could not clear {table}")
                return False
            _bump(report.removed, table, n)
        if _table_exists(cur, "user_context", is_pg):
            _guarded(cur, store._q("UPDATE user_context SET active_run_id=NULL "
                                   "WHERE active_run_id=?"), (run_id,))
        n = _guarded(cur, store._q("DELETE FROM runs WHERE id=?"), (run_id,))
        if n is None:
            report.errors.append(f"{run_id}: could not delete the run row")
            return False
        _bump(report.removed, "runs", n)
    return True


def _remove_blob_dir(root: Path, run_id: str, path: Path, report: Report) -> bool:
    inst = (Path(root) / "instances").resolve()
    target = Path(path).resolve()
    if target.parent != inst or target.name != run_id or "/" in run_id or "\\" in run_id:
        report.errors.append(f"{run_id}: refusing to remove {target} (not an instance directory)")
        return False
    if not target.is_dir():
        report.skipped.append(f"{run_id}: blob directory already gone")
        return False
    problems: List[str] = []

    def _onerror(_fn, p, exc_info):
        problems.append(f"{p}: {exc_info[1]}")

    shutil.rmtree(target, onerror=_onerror)
    if problems:
        report.errors.append(f"{run_id}: {len(problems)} path(s) could not be removed "
                             f"(first: {problems[0]})")
        return not target.exists()
    return True


def apply(store, root: Path, p: Plan) -> Report:
    """Perform *p*. Rows first, then the blob directories of the same runs;
    conversations; then the memory store's own expiry."""
    report = Report(plan=p)
    root = Path(root)

    deleted_runs: set = set()
    for r in p.runs:
        if _delete_run(store, r["id"], report):
            deleted_runs.add(r["id"])

    for b in p.blobs:
        rid = b["id"]
        if rid in {x["id"] for x in p.runs} and rid not in deleted_runs:
            # Its rows were planned for deletion and were not deleted (the
            # run woke up, or a statement failed): the directory stays with
            # them. Never the blobs before the rows.
            report.skipped.append(f"{rid}: rows kept, so the blob directory is kept")
            continue
        if _remove_blob_dir(root, rid, b["path"], report):
            report.blobs_removed.append(rid)
    _bump(report.removed, "blobs", len(report.blobs_removed))

    if p.conversations or p.messages_unattached:
        is_pg = _is_pg(store)
        with store._tx() as cur:
            ws_id = _workspace_id(cur, store, p.workspace_code) if p.workspace_code else None
            for c in p.conversations:
                if _table_exists(cur, "studio_conversation_messages", is_pg):
                    n = _guarded(cur, store._q(
                        "DELETE FROM studio_conversation_messages WHERE conversation_id=?"
                        + (" AND workspace_code=?" if p.workspace_code else "")),
                        (c["id"], p.workspace_code) if p.workspace_code else (c["id"],))
                    _bump(report.removed, "studio_conversation_messages", n)
                n = _guarded(cur, store._q(
                    "DELETE FROM studio_conversations WHERE id=?"
                    + (" AND workspace_code=?" if p.workspace_code else "")),
                    (c["id"], p.workspace_code) if p.workspace_code else (c["id"],))
                if n is None:
                    report.errors.append(f"conversation {c['id']}: could not delete")
                _bump(report.removed, "studio_conversations", n)
            if p.messages_unattached and p.policy.conversations is not None \
                    and _table_exists(cur, "messages", is_pg):
                cutoff = (p.now - p.policy.conversations).isoformat()
                if p.workspace_code and ws_id is None:
                    n = 0
                elif p.workspace_code:
                    n = _guarded(cur, store._q(
                        "DELETE FROM messages WHERE workspace_id=? AND run_id IS NULL "
                        "AND created_at < ?"), (ws_id, cutoff))
                else:
                    n = _guarded(cur, store._q(
                        "DELETE FROM messages WHERE run_id IS NULL AND created_at < ?"), (cutoff,))
                if n is None:
                    report.errors.append("messages: could not delete unattached rows")
                _bump(report.removed, "messages_unattached", n)

    if "memory" in p.classes and p.workspace_code:
        try:
            from ioagentfarm.engine.memory.hooks import memory_store
            n = memory_store(root).expire(p.workspace_code)
            _bump(report.removed, "memory", n)
        except Exception as exc:  # noqa: BLE001 - the memory tier may be absent
            report.errors.append(f"memory: expiry failed ({exc})")
    return report


def sweep(store, root: Path, workspace_code: str, *,
          now: Optional[datetime] = None) -> Optional[Report]:
    """One unattended pass for one workspace under ITS policy file. No file
    means nothing happens: the scheduler never invents a window."""
    policy = load_policy(workspace_code)
    if policy is None:
        return None
    p = plan(store, root, policy, now, workspace_code=workspace_code)
    if p.is_empty():
        return Report(plan=p)
    return apply(store, root, p)
