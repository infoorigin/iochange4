"""Plan cache for Quinn (queryngine).

Caches the SQL plan Quinn generated for a question. On hit, the cached SQL is
re-executed live against the database (never cached rows) and Quinn composes
the v1 envelope in a single LLM round. Data accuracy is preserved because every
hit queries fresh data; only the LLM planning rounds are skipped.

Key components:
  cache_key = sha256(user_scope + role + question_hash_normalized
                     + catalog_hash + data_fingerprint)

where:
  - question_hash_normalized: conservative normalization (lowercase, trim,
    punct-strip, plural collapse on entity-name tokens, catalog-driven
    synonym substitution). No embeddings, no general stemming, no LLM-based
    paraphrase.
  - catalog_hash: sha256 of catalog.yaml — any edit evicts.
  - data_fingerprint: hash of (filename, mtime, size) of every file in
    metadata/data/ — catches upstream data changes.
  - user_scope: per-user isolation; cross-user sharing waits for governance.

Cold-path bypass: if the question contains trigger phrases (*"right now",
"fresh", "re-run", "latest", "live", "recompute"*), skip cache read AND write.

Storage: SQLite at `<IOF_ROOT>/plan_cache.db` — separate from the main store
to avoid schema-migration entanglement.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


COLD_PATH_PHRASES = (
    "right now", "fresh", "re-run", "rerun", "latest",
    "recompute", "live data", "real-time", "realtime",
    "up to date", "up-to-date",
)


@dataclass
class CacheEntry:
    cache_key: str
    sql: str
    db_name: str
    entity: str
    created_at: str
    hit_count: int


class PlanCache:
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _conn(self) -> sqlite3.Connection:
        # Schema creation is idempotent — we re-run it on every connect so an
        # externally-deleted DB file (e.g. `rm .iof/plan_cache.db`) heals on
        # next access instead of silently returning "no such table: plan_cache"
        # errors for the rest of the process lifetime.
        con = sqlite3.connect(str(self.db_path))
        try:
            con.execute(
                """CREATE TABLE IF NOT EXISTS plan_cache (
                    cache_key TEXT PRIMARY KEY,
                    user_scope TEXT NOT NULL,
                    role TEXT NOT NULL,
                    question_original TEXT NOT NULL,
                    question_normalized TEXT NOT NULL,
                    catalog_hash TEXT NOT NULL,
                    data_fingerprint TEXT NOT NULL,
                    sql TEXT NOT NULL,
                    db_name TEXT NOT NULL,
                    entity TEXT NOT NULL DEFAULT '',
                    plan_fingerprint TEXT,
                    hit_count INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    last_hit_at TEXT
                );"""
            )
            con.execute(
                "CREATE INDEX IF NOT EXISTS idx_plan_cache_user_role "
                "ON plan_cache(user_scope, role);"
            )
            con.commit()
        except sqlite3.Error:
            pass
        return con

    def _ensure_schema(self) -> None:
        with self._conn() as con:
            con.execute(
                """CREATE TABLE IF NOT EXISTS plan_cache (
                    cache_key TEXT PRIMARY KEY,
                    user_scope TEXT NOT NULL,
                    role TEXT NOT NULL,
                    question_original TEXT NOT NULL,
                    question_normalized TEXT NOT NULL,
                    catalog_hash TEXT NOT NULL,
                    data_fingerprint TEXT NOT NULL,
                    sql TEXT NOT NULL,
                    db_name TEXT NOT NULL,
                    entity TEXT NOT NULL DEFAULT '',
                    plan_fingerprint TEXT,
                    hit_count INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    last_hit_at TEXT
                );"""
            )
            con.execute(
                "CREATE INDEX IF NOT EXISTS idx_plan_cache_user_role "
                "ON plan_cache(user_scope, role);"
            )

    # ------------------------------------------------------------------ utils

    @staticmethod
    def is_cold_path(question: str) -> bool:
        q = question.lower()
        return any(phrase in q for phrase in COLD_PATH_PHRASES)

    @staticmethod
    def normalize_question(question: str, synonyms: dict[str, str]) -> str:
        """Conservative normalization.

        Operations (in order):
          1. lowercase
          2. trim + collapse internal whitespace
          3. strip most punctuation (keep hyphens — appear in 'non-None' etc)
          4. apply catalog-driven synonym substitutions (whole-word, ordered
             longest-source-first so multi-word synonyms match before their
             constituent single words)
          5. collapse singular/plural for a small closed set of entity tokens
        """
        q = question.lower().strip()
        q = re.sub(r"[?!.,;:'\"()\[\]{}]", " ", q)
        q = re.sub(r"\s+", " ", q).strip()

        # Plural-collapse BEFORE synonym substitution so a single synonym
        # entry like "supplier → vendor" also handles "suppliers" without
        # requiring a separate plural entry. Token list is a small closed set
        # of entity-name-shaped words; we don't attempt general stemming.
        plural_tokens = ("vendor", "supplier", "po", "payment",
                         "contract", "dollar", "row", "column",
                         "record", "document", "order", "purchase")
        for word in plural_tokens:
            q = re.sub(rf"\b{word}s\b", word, q)

        # Apply catalog-driven synonyms, longest source first so multi-word
        # entries match before their constituent single words.
        sorted_syns = sorted(synonyms.items(), key=lambda kv: -len(kv[0]))
        for src, dst in sorted_syns:
            pattern = r"\b" + re.escape(src.lower()) + r"\b"
            q = re.sub(pattern, dst.lower(), q)

        q = re.sub(r"\s+", " ", q).strip()
        return q

    @staticmethod
    def compute_catalog_hash(catalog_path: Path) -> str:
        if not catalog_path.exists():
            return ""
        return hashlib.sha256(catalog_path.read_bytes()).hexdigest()[:16]

    @staticmethod
    def compute_data_fingerprint(metadata_dir: Path) -> str:
        """Hash of (name, mtime, size) for every file in metadata/data/.
        Any upstream CSV/parquet change invalidates the cache.
        """
        data_dir = metadata_dir / "data"
        if not data_dir.exists():
            return ""
        parts: list[str] = []
        for p in sorted(data_dir.rglob("*")):
            if p.is_file():
                st = p.stat()
                parts.append(f"{p.name}:{int(st.st_mtime)}:{st.st_size}")
        if not parts:
            return ""
        return hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]

    @staticmethod
    def load_synonyms(metadata_dir: Path) -> dict[str, str]:
        """Load catalog-driven synonyms from metadata/synonyms.yaml if present.

        Format:
          synonyms:
            - {from: "total spend",  to: "total payment"}
            - {from: "supplier",     to: "vendor"}

        Returns empty dict if the file is absent.
        """
        path = metadata_dir / "synonyms.yaml"
        if not path.exists():
            return {}
        try:
            import yaml  # type: ignore
        except ImportError:
            return {}
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except Exception:
            return {}
        out: dict[str, str] = {}
        for item in data.get("synonyms") or []:
            if not isinstance(item, dict):
                continue
            src, dst = item.get("from"), item.get("to")
            if isinstance(src, str) and isinstance(dst, str) and src and dst:
                out[src] = dst
        return out

    @staticmethod
    def _compute_key(user_scope: str, role: str, q_norm: str,
                     catalog_hash: str, data_fp: str) -> str:
        raw = f"{user_scope}::{role}::{q_norm}::{catalog_hash}::{data_fp}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    # -------------------------------------------------------------- public API

    def lookup(self, *, question: str, role: str, user_scope: str,
               synonyms: dict[str, str], catalog_hash: str,
               data_fingerprint: str) -> Optional[CacheEntry]:
        if self.is_cold_path(question):
            return None
        q_norm = self.normalize_question(question, synonyms)
        key = self._compute_key(user_scope, role, q_norm, catalog_hash,
                                data_fingerprint)
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as con:
            row = con.execute(
                "SELECT sql, db_name, entity, created_at, hit_count "
                "FROM plan_cache WHERE cache_key = ?",
                (key,),
            ).fetchone()
            if not row:
                return None
            con.execute(
                "UPDATE plan_cache SET hit_count = hit_count + 1, "
                "last_hit_at = ? WHERE cache_key = ?",
                (now, key),
            )
            con.commit()
            return CacheEntry(
                cache_key=key,
                sql=row[0],
                db_name=row[1],
                entity=row[2] or "",
                created_at=row[3],
                hit_count=int(row[4]) + 1,
            )

    def store(self, *, question: str, role: str, user_scope: str,
              synonyms: dict[str, str], catalog_hash: str,
              data_fingerprint: str, sql: str, db_name: str,
              entity: str = "") -> str:
        """Store (or upsert) a plan. Returns the cache_key.

        Cold-path requests are not stored either — caching them would just
        fight the user's explicit 'fresh' intent.
        """
        if self.is_cold_path(question):
            return ""
        q_norm = self.normalize_question(question, synonyms)
        key = self._compute_key(user_scope, role, q_norm, catalog_hash,
                                data_fingerprint)
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as con:
            con.execute(
                """INSERT INTO plan_cache
                    (cache_key, user_scope, role, question_original,
                     question_normalized, catalog_hash, data_fingerprint,
                     sql, db_name, entity, hit_count, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
                   ON CONFLICT(cache_key) DO UPDATE SET
                     sql = excluded.sql,
                     db_name = excluded.db_name,
                     entity = excluded.entity,
                     created_at = excluded.created_at""",
                (key, user_scope, role, question, q_norm, catalog_hash,
                 data_fingerprint, sql, db_name, entity, now),
            )
            con.commit()
        return key

    def stats(self, role: Optional[str] = None) -> dict:
        with self._conn() as con:
            if role:
                total = con.execute(
                    "SELECT COUNT(*), COALESCE(SUM(hit_count), 0) "
                    "FROM plan_cache WHERE role = ?", (role,)).fetchone()
            else:
                total = con.execute(
                    "SELECT COUNT(*), COALESCE(SUM(hit_count), 0) "
                    "FROM plan_cache").fetchone()
            return {
                "entries": int(total[0]),
                "total_hits": int(total[1]),
            }

    def clear(self, role: Optional[str] = None) -> int:
        with self._conn() as con:
            if role:
                cur = con.execute(
                    "DELETE FROM plan_cache WHERE role = ?", (role,))
            else:
                cur = con.execute("DELETE FROM plan_cache")
            con.commit()
            return cur.rowcount
