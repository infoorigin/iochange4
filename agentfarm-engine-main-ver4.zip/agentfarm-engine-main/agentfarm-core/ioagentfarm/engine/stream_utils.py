"""Streaming utilities for iobot v0.1.5+ native SDK providers.

The Anthropic native SDK requires streaming for requests with large
``max_tokens``.  Passing an ``on_stream`` callback to ``process_direct()``
triggers iobot's streaming code path (``chat_stream_with_retry``).

When streaming is enabled, iobot's hook skips forwarding LLM thoughts to
``on_progress`` (to avoid duplication).  ``LineBufferedStream`` bridges
this gap by buffering stream deltas and flushing complete lines to
``on_progress``, preserving the line-by-line thought capture in the DB.
"""
from __future__ import annotations

from typing import Awaitable, Callable


class LineBufferedStream:
    """Buffer streaming deltas and flush complete lines to *on_progress*.

    Usage::

        stream = LineBufferedStream(on_progress_callback)
        result = await agent.process_direct(..., on_stream=stream)
        await stream.flush()
    """

    def __init__(self, on_progress: Callable[..., Awaitable[None]] | None = None):
        self._on_progress = on_progress
        self._buf = ""

    async def __call__(self, delta: str) -> None:
        self._buf += delta
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            stripped = line.strip()
            if stripped and self._on_progress:
                await self._on_progress(stripped)

    async def flush(self) -> None:
        """Flush any remaining partial line."""
        stripped = self._buf.strip()
        if stripped and self._on_progress:
            await self._on_progress(stripped)
        self._buf = ""


async def noop_stream(_delta: str) -> None:
    """No-op stream callback — enables streaming without capturing thoughts.

    Use this when there is no ``on_progress`` to forward to (e.g. cron,
    heartbeat callbacks).
    """
