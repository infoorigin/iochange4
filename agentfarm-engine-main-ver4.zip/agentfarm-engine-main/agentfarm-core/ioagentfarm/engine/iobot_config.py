"""Iobot configuration helpers for the thin orchestration model.

Manages per-agent iobot configuration including MCP server setup,
workspace configuration, and runtime feature enablement.

Iobot config lives at ~/.iobot/config.json (global) and can be
augmented per-agent via IOBOT_WORKSPACE env var.

Per-run instance configs are created under .iof/instances/<run_id>/config.json
via ``create_instance_config()``.  Each instance gets its own MCP servers,
logs, and cron — while agent identity and memory stay per-role in the
shared workspace at ``~/.iobot/agents/<role>/workspace/``.
"""
from __future__ import annotations
import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

#: iobot's exact env-reference syntax (``config/loader.py:_ENV_REF_PATTERN``).
#: No ``${VAR:-default}`` form exists there — a ref either resolves or the
#: runtime's ``resolve_config_env_vars`` RAISES at config load, killing the
#: whole run over one entry. That is why the merge below drops unresolvable
#: servers loudly instead of writing them.
_MCP_ENV_REF = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

#: ioagentfarm extension keys on an MCP server entry — consumed by the merge,
#: stripped before anything iobot-shaped is written. ``enabled: false`` lets
#: a higher tier remove a lower tier's server; ``_pack`` is provenance added
#: by ``PackRegistry.mcp_servers()``.
#: `auth` joins them: iobot's MCPServerConfig has `extra="ignore"`, so an
#: `auth:` key written into its config is SILENTLY DROPPED - it would look
#: declared and do nothing. It is OURS: stripped before the iobot-shaped
#: config is written, and read back from the declaration tiers by the
#: `mcp_oauth` runtime patch and by `mcp-list --probe`, which is what keeps
#: the credential the diagnostic uses identical to the one the runtime sends.
_MCP_EXTENSION_KEYS = ("enabled", "_pack", "auth")

def _global_config_path() -> Path:
    """Where the runtime's global config.json lives (``~/.iobot/config.json``).

    Resolved through ``state_dir`` rather than hardcoded: this constant used to
    read ``~/.iobot/config.json`` while the runtime (and entrypoint.sh) had
    moved to ``~/.iobot``, so `serve` reported "config exists=False" and silently
    fell back to defaults — a provider/model misconfiguration that surfaces as a
    failing run, not as a startup error. Caught by reading the serve log.
    """
    from ioagentfarm.engine.state_dir import state_dir_root
    return state_dir_root() / "config.json"


# Module-level for backwards compatibility with importers; the function above is
# the source of truth and is what new code should call.
IOBOT_CONFIG_PATH = _global_config_path()


def read_iobot_config() -> Dict[str, Any]:
    """Read iobot's global config.json.  Returns empty dict if not found."""
    if not IOBOT_CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(IOBOT_CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Failed to read iobot config: %s", exc)
        return {}


def write_iobot_config(config: Dict[str, Any]) -> None:
    """Write iobot's global config.json (creates parent dirs if needed)."""
    IOBOT_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    IOBOT_CONFIG_PATH.write_text(
        json.dumps(config, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    logger.debug("Wrote iobot config to %s", IOBOT_CONFIG_PATH)


def build_mcp_entry(
    command: Optional[str] = None,
    args: Optional[List[str]] = None,
    env: Optional[Dict[str, str]] = None,
    url: Optional[str] = None,
    server_type: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
    cwd: Optional[str] = None,
    tool_timeout: Optional[int] = None,
    enabled_tools: Optional[List[str]] = None,
    auth: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """A iobot ``MCPServerConfig``-shaped entry from CLI-level inputs.

    Exactly one of ``command`` (stdio) / ``url`` (sse or streamableHttp) is
    required — iobot auto-detects the transport when ``server_type`` is
    omitted. Keys are written camelCase to match the runtime's aliases
    (``toolTimeout``, ``enabledTools``). ``${VAR}`` references are kept
    verbatim — iobot resolves them at config load, so secret values never
    land on disk.
    """
    if bool(command) == bool(url):
        raise ValueError("an MCP server needs exactly one of command (stdio) "
                         "or url (sse/streamableHttp)")
    if server_type and server_type not in ("stdio", "sse", "streamableHttp"):
        raise ValueError(f"unknown MCP server type {server_type!r} — expected "
                         "stdio, sse or streamableHttp")
    entry: Dict[str, Any] = {}
    if command:
        entry["command"] = command
    if args:
        entry["args"] = list(args)
    if env:
        entry["env"] = dict(env)
    if url:
        entry["url"] = url
    if server_type:
        entry["type"] = server_type
    if headers:
        entry["headers"] = dict(headers)
    if cwd:
        entry["cwd"] = cwd
    if tool_timeout is not None:
        entry["toolTimeout"] = int(tool_timeout)
    if enabled_tools is not None:
        entry["enabledTools"] = list(enabled_tools)
    if auth:
        # OURS, not iobot's - see `_MCP_EXTENSION_KEYS`. Validated at
        # declaration time so a broken grant is refused by the command that
        # writes it, not by a 401 three steps later.
        from ioagentfarm.engine.mcp_auth import validate as _validate_auth
        problems = _validate_auth(auth)
        if problems:
            raise ValueError("; ".join(problems))
        entry["auth"] = dict(auth)
    return entry


def build_auth_block(*, auth_type: str = "", token_url: str = "",
                     client_id: str = "", client_secret: str = "",
                     scope: str = "", audience: str = "") -> Optional[Dict[str, Any]]:
    """An ``auth:`` block from CLI-level inputs, or None when none was asked for.

    Refuses a PARTIAL block loudly. Half an OAuth declaration is the shape
    that reaches production and fails at connect time with a 401 that blames
    the server - naming the missing flag here costs one command instead of an
    afternoon.
    """
    supplied = {k: v for k, v in (
        ("type", auth_type), ("token_url", token_url),
        ("client_id", client_id), ("client_secret", client_secret),
        ("scope", scope), ("audience", audience)) if str(v or "").strip()}
    if not supplied:
        return None
    supplied.setdefault("type", "oauth2_client_credentials")
    from ioagentfarm.engine.mcp_auth import validate as _validate_auth
    problems = _validate_auth(supplied)
    if problems:
        raise ValueError(
            "incomplete --auth-* declaration: " + "; ".join(problems)
            + ". Write the credentials as ${VAR} references; the values go "
              "in the workspace .env, never on the command line.")
    return supplied


def configure_mcp_server(
    name: str,
    command: Optional[str] = None,
    args: Optional[List[str]] = None,
    env: Optional[Dict[str, str]] = None,
    *,
    auth: Optional[Dict[str, Any]] = None,
    url: Optional[str] = None,
    server_type: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
    cwd: Optional[str] = None,
    tool_timeout: Optional[int] = None,
    enabled_tools: Optional[List[str]] = None,
    workspace: Optional[str] = None,
) -> bool:
    """Add or update an MCP server declaration.

    ``workspace=None`` writes iobot's global config (``tools.mcpServers`` in
    ``~/.iobot/config.json`` — the operator tier the runtime natively reads);
    ``workspace=<code>`` writes that workspace's ``mcp.yaml`` (the highest-
    precedence tier, see :func:`merged_mcp_servers`).

    Returns True if the target store was modified.
    """
    new_entry = build_mcp_entry(
        command=command, args=args, env=env, url=url, server_type=server_type,
        headers=headers, cwd=cwd, tool_timeout=tool_timeout,
        enabled_tools=enabled_tools, auth=auth)

    if workspace:
        servers = read_workspace_mcp(workspace)
        if servers.get(name) == new_entry:
            return False
        servers[name] = new_entry
        write_workspace_mcp(workspace, servers)
        logger.info("Configured MCP server '%s' in workspace %s", name, workspace)
        return True

    config = read_iobot_config()
    servers = config.setdefault("tools", {}).setdefault("mcpServers", {})
    if servers.get(name) == new_entry:
        return False  # No change
    servers[name] = new_entry
    write_iobot_config(config)
    logger.info("Configured MCP server '%s' in iobot config", name)
    return True


def remove_mcp_server(name: str, *, workspace: Optional[str] = None) -> bool:
    """Remove an MCP server declaration.  Returns True if removed.

    ``workspace=None`` targets the global config; ``workspace=<code>`` targets
    that workspace's ``mcp.yaml``. Note this removes the DECLARATION at one
    tier — a lower tier's server survives; to suppress it instead, write an
    override entry with ``enabled: false`` at the higher tier.
    """
    if workspace:
        servers = read_workspace_mcp(workspace)
        if name not in servers:
            return False
        del servers[name]
        write_workspace_mcp(workspace, servers)
        logger.info("Removed MCP server '%s' from workspace %s", name, workspace)
        return True
    config = read_iobot_config()
    servers = config.get("tools", {}).get("mcpServers", {})
    if name not in servers:
        return False
    del servers[name]
    write_iobot_config(config)
    logger.info("Removed MCP server '%s' from iobot config", name)
    return True


def list_mcp_servers() -> Dict[str, Any]:
    """The GLOBAL tier's raw mcpServers dict (one store, unmerged).

    For the effective cross-tier view a run would actually get, use
    :func:`effective_mcp_servers`.
    """
    config = read_iobot_config()
    return config.get("tools", {}).get("mcpServers", {})


# ---------------------------------------------------------------------------
# MCP declaration tiers: pack -> global -> workspace
#
# iobot ships the entire MCP client (all three transports, tool
# registration as mcp_<server>_<tool>, SSRF hardening, hot reload) — this
# section only decides WHICH server entries reach a config. Three
# user-facing tiers mirror the CLI-tool model (pack tools.yaml -> skill ->
# agent): a pack ships defaults in its mcp.yaml, the machine-global config
# carries operator intent, and the workspace's mcp.yaml is the tenant's
# word. Merge is by server name, WHOLE-ENTRY replacement — a half-merged
# server (a pack's stdio command surviving under a workspace's url) is a
# silent mis-wire, so no per-field deep merge.
# ---------------------------------------------------------------------------

def _env_ref_names(obj: Any) -> set:
    """Every ``${VAR}`` name referenced anywhere in *obj* (recursive)."""
    if isinstance(obj, str):
        return set(_MCP_ENV_REF.findall(obj))
    if isinstance(obj, dict):
        names: set = set()
        for v in obj.values():
            names |= _env_ref_names(v)
        return names
    if isinstance(obj, (list, tuple)):
        names = set()
        for v in obj:
            names |= _env_ref_names(v)
        return names
    return set()


def workspace_mcp_path(code: str) -> Path:
    """``~/.iobot/workspaces/<code>/mcp.yaml`` — the workspace MCP tier.

    Sibling of the workspace's ``.env`` on purpose: entries reference
    secrets as ``${VAR}`` and the values live in that ``.env``, so the pair
    travels (and is backed up) together while the YAML itself never carries
    a token.
    """
    from ioagentfarm.engine.workspace_env import workspace_home
    return workspace_home(code) / "mcp.yaml"


def read_workspace_mcp(code: str) -> Dict[str, Any]:
    """The workspace tier's ``{name: entry}`` dict (empty if absent/bad)."""
    path = workspace_mcp_path(code)
    if not path.exists():
        return {}
    import yaml
    try:
        spec = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (yaml.YAMLError, OSError) as exc:
        logger.warning("workspace mcp.yaml at %s is unreadable (%s) — tier "
                       "ignored", path, exc)
        return {}
    servers = spec.get("mcp_servers") if isinstance(spec, dict) else None
    return dict(servers) if isinstance(servers, dict) else {}


def write_workspace_mcp(code: str, servers: Dict[str, Any]) -> Path:
    """Write the workspace tier's ``mcp.yaml`` (top-level ``mcp_servers:``)."""
    import yaml
    path = workspace_mcp_path(code)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump({"mcp_servers": servers}, sort_keys=True,
                       allow_unicode=True),
        encoding="utf-8",
    )
    return path


def effective_mcp_servers(
    workspace_code: Optional[str] = None,
    *,
    include_workspace_tier: bool = True,
) -> Dict[str, Dict[str, Any]]:
    """The merged cross-tier view, with provenance and viability per server.

    Returns ``{name: {"spec", "tier", "status", "missing"}}`` where ``tier``
    is ``pack:<name>`` / ``global`` / ``workspace:<code>`` (highest tier that
    declared the name — whole-entry replacement), ``status`` is ``active`` |
    ``disabled`` (the winning entry says ``enabled: false``) | ``dropped``
    (references an unset ``${VAR}``), and ``missing`` names the unset vars.
    ``spec`` is the iobot-shaped entry with extension keys stripped.

    ``workspace_code=None`` resolves the SELECTED workspace (fail-closed:
    raises when nothing is selected) — the same resolution that already
    scopes agent homes, and ``IOF_WORKSPACE`` is in ``PASSTHROUGH_ENV_KEYS``
    so nested run-steps agree. A tenant's MCP servers must never be silently
    replaced by another workspace's.

    ``include_workspace_tier=False`` is for REPORTING ONLY: it skips both the
    resolution and the workspace tier, returning just the two tiers that do
    not depend on a workspace. A run must never pass it — that is why it is
    keyword-only and defaults to the fail-closed behaviour. It exists because
    `mcp-list` is a diagnostic: refusing to answer "what does this machine
    declare?" until a workspace is selected turned the command into a
    traceback while the pack and global tiers were sitting right there,
    perfectly answerable.
    """
    code = ""
    if include_workspace_tier:
        if workspace_code:
            code = workspace_code
        else:
            from ioagentfarm.engine.workspaces import resolved_workspace_code
            code = resolved_workspace_code()

    merged: Dict[str, Dict[str, Any]] = {}
    # Pack tier (lowest): shipped defaults must never beat operator intent.
    # Guarded — a broken pack registry must not block run creation.
    try:
        from ioagentfarm.packs import load_registry
        pack_servers = load_registry().mcp_servers()
    except Exception:
        logger.warning("pack registry unavailable while merging MCP servers "
                       "— pack tier skipped", exc_info=True)
        pack_servers = {}
    for name, spec in pack_servers.items():
        if isinstance(spec, dict):
            merged[name] = {"spec": spec,
                            "tier": f"pack:{spec.get('_pack', '?')}"}
    # Global tier: the machine config an operator (or `mcp-add`) wrote.
    for name, spec in (list_mcp_servers() or {}).items():
        if isinstance(spec, dict):
            merged[name] = {"spec": spec, "tier": "global"}
    # Workspace tier (highest): the tenant owns its settings.
    if code:
        for name, spec in read_workspace_mcp(code).items():
            if isinstance(spec, dict):
                merged[name] = {"spec": spec, "tier": f"workspace:{code}"}

    out: Dict[str, Dict[str, Any]] = {}
    for name, info in merged.items():
        raw = info["spec"]
        disabled = raw.get("enabled") is False
        clean = {k: v for k, v in raw.items() if k not in _MCP_EXTENSION_KEYS}
        auth = raw.get("auth") if isinstance(raw.get("auth"), dict) else None
        # A `${VAR}` the AUTH block needs is as fatal as one a header needs -
        # both mean the server cannot authenticate - so it counts toward the
        # same loud drop rather than failing later as an opaque 401.
        auth_missing: list = []
        if auth:
            from ioagentfarm.engine.mcp_auth import unresolved
            auth_missing = unresolved(auth)
        missing = sorted(set(v for v in _env_ref_names(clean)
                             if v not in os.environ) | set(auth_missing))
        status = ("disabled" if disabled
                  else "dropped" if missing else "active")
        out[name] = {"spec": clean, "tier": info["tier"], "status": status,
                     "missing": missing, "auth": auth}
    return out


def merged_mcp_servers(workspace_code: Optional[str] = None) -> Dict[str, Any]:
    """The runnable ``tools.mcpServers`` dict a config should carry.

    Applies the tier merge, honors ``enabled: false`` suppressions, strips
    extension keys, and DROPS any server referencing an unset ``${VAR}`` —
    loudly, naming the variable and the declaring tier. Left in place, that
    entry would make iobot's ``resolve_config_env_vars`` raise at
    subprocess startup and kill the entire run (providers included) over one
    optional server. Surviving ``${VAR}`` refs stay unexpanded on disk;
    iobot resolves them at load.
    """
    out: Dict[str, Any] = {}
    for name, info in effective_mcp_servers(workspace_code).items():
        if info["status"] == "disabled":
            logger.info("MCP server %r disabled by %s", name, info["tier"])
            continue
        if info["status"] == "dropped":
            logger.warning(
                "MCP server %r (declared by %s) references unset environment "
                "variable(s) %s — dropped from this config so one bad entry "
                "cannot abort the run at startup. Set the variable(s) or "
                "remove the server.",
                name, info["tier"], ", ".join(info["missing"]))
            continue
        _warn_if_interactive_interpreter(name, info)
        out[name] = info["spec"]
    return out


#: Interpreters that, invoked with no arguments, start a REPL: a process that
#: opens fine, reads stdin forever, and never speaks MCP.
_REPL_COMMANDS = {
    "python", "python3", "python.exe", "python3.exe", "py", "py.exe",
    "node", "node.exe", "irb", "ruby", "R", "ghci", "scala", "R.exe",
}


def _warn_if_interactive_interpreter(name: str, info: Dict[str, Any]) -> None:
    """Say so when a declaration can only ever hang.

    A stdio server declared as a bare interpreter — ``command: python`` with no
    ``args`` — starts the interactive REPL. The process launches, the pipes
    open, and the handshake never completes, so the agent blocks BEFORE its
    first LLM call with nothing in any log to say why (see the
    ``mcp_connect_timeout`` patch, which bounds the wait).

    Warned, never dropped. The runtime timeout is what protects the run; this
    exists so the cause is named at the moment the declaration is read, rather
    than a minute later when the connect is abandoned. Dropping it here would
    also guess about a shape someone may have a reason for — a wrapper script
    named ``node``, say — and this is a declaration we merged, not one we own.
    """
    spec = info.get("spec") or {}
    if not isinstance(spec, dict):
        return
    command = str(spec.get("command") or "").strip()
    if not command or spec.get("args"):
        return
    if os.path.basename(command).lower() not in _REPL_COMMANDS:
        return
    logger.warning(
        "MCP server %r (declared by %s) runs %r with no arguments, which "
        "starts an interactive interpreter. That process never completes an "
        "MCP handshake, so every run declaring it waits for the connect "
        "timeout and then continues without it. Give the command the script "
        "that implements the server, or remove the declaration.",
        name, info.get("tier"), command)


def resolve_mcp_env_refs(servers: Dict[str, Any]) -> Dict[str, Any]:
    """Expand ``${VAR}`` refs in-memory, for paths that bypass iobot's own
    config resolver.

    The in-process agent pool (``web/app.py``) hands ``mcp_servers=`` straight
    to ``AgentLoop`` — ``load_config()`` never env-resolves — so expansion
    happens here. :func:`merged_mcp_servers` has already dropped servers with
    unset vars; if a caller passes an unmerged dict anyway, a missing var
    expands to ``""`` rather than raising.
    """
    def _walk(obj: Any) -> Any:
        if isinstance(obj, str):
            return _MCP_ENV_REF.sub(
                lambda m: os.environ.get(m.group(1), ""), obj)
        if isinstance(obj, dict):
            return {k: _walk(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_walk(v) for v in obj]
        return obj
    return _walk(dict(servers))


#: Env vars an agent's `exec` subprocess must inherit. iobot strips a tool
#: subprocess to {HOME, LANG, TERM}, so anything not listed here is GONE — and
#: a stripped `ioagentfarm` re-resolves its database from `$HOME/.env`, which
#: is a DIFFERENT database from the one the operator exported. That is not a
#: missing-credentials problem, it is a wrong-data problem: the agent reads and
#: writes somewhere nobody chose.
#:
#: Shared by BOTH paths on purpose. It used to live only inside
#: `create_instance_config`, so workflow-run agents inherited it and the
#: always-on pool (`web/app.py`) did not — Jarvis answered "your last run"
#: with a run from whatever `~/.env` happened to name.
PASSTHROUGH_ENV_KEYS = ("IOF_DATABASE_URL", "IOF_ROOT", "IOF_DB_SCHEMA",
                        "IOF_WORKSPACE", "IOF_AGENT_HOME",
                        # LOCAL MODE IS PART OF THE ANSWER TO "WHERE IS
                        # CONTENT?", so a tool the agent execs has to know it
                        # too. Without it the child resolves the state
                        # directory correctly (IOF_ROOT is above) and still
                        # disagrees with its parent about whether YOUR FILES
                        # or the workspace own the content it reads.
                        "IOF_LOCAL",
                        # OpenTelemetry (docs/reference/observability-otel.md).
                        # A tool the AGENT execs starts with a stripped
                        # environment; without these it has no parent span
                        # and no endpoint, and its spans - `iof-query`'s,
                        # `iof-consult`'s - either float or never leave.
                        # TRACEPARENT is the step span run-step set in the
                        # agent's own env; the OTEL_* are the deployment's.
                        "TRACEPARENT", "IOF_RUN_ID", "IOF_STEP_KEY",
                        "IOF_OTEL_EXPORTER", "OTEL_EXPORTER_OTLP_ENDPOINT",
                        "OTEL_EXPORTER_OTLP_HEADERS", "OTEL_EXPORTER_OTLP_PROTOCOL",
                        "OTEL_SERVICE_NAME", "OTEL_RESOURCE_ATTRIBUTES")


def setup_project_mcp(project_dir: str) -> Dict[str, bool]:
    """Configure MCP servers that add capabilities beyond iobot's built-ins.

    iobot already provides native tools (read_file, write_file,
    list_directory, exec) — no MCP filesystem server needed.
    GitHub access is handled via native git CLI through iobot's exec tool.

    This function is kept as an extension point for future MCP servers
    that provide genuinely new capabilities not available in iobot.

    Returns dict of {server_name: was_modified}.
    """
    return {}


# ---------------------------------------------------------------------------
# Per-run instance config (iobot --config multi-instance support)
# ---------------------------------------------------------------------------

def create_instance_config(
    root_path: Path,
    run_id: str,
    project_dir: str,
) -> Path:
    """Create a per-run iobot instance config.

    Copies provider/model settings from the global ``~/.iobot/config.json``
    and writes project-specific MCP servers into the instance config at
    ``.iof/instances/<run_id>/config.json``.

    iobot derives its data directory (sessions, logs, cron) from the config
    file's parent, so each run gets fully isolated runtime state while sharing
    agent identity and memory via ``--workspace``.

    Returns the path to the instance config file.
    """
    instance_dir = root_path / "instances" / run_id
    instance_dir.mkdir(parents=True, exist_ok=True)
    config_path = instance_dir / "config.json"

    # Start from the global config (preserves providers, model, etc.)
    base = read_iobot_config()
    # Loud, not fatal: providers CAN legitimately come from env vars alone
    # (AZURE_OPENAI_API_KEY fallback, gateway keys), but an empty global
    # config is usually a process running under a DIFFERENT HOME than the
    # one that was configured (serve launched as another user/elevated
    # shell). Silent before: the run spawned keyless and died on its first
    # LLM call with a cryptic provider 401.
    if not base:
        logger.warning(
            "global iobot config not found or empty at %s (Path.home()=%s) "
            "— run %s inherits NO provider credentials from config and will "
            "rely on provider env vars only. If your CLI works but this run "
            "fails its first LLM call, this process resolves a different "
            "home directory than your shell.",
            IOBOT_CONFIG_PATH, Path.home(), run_id,
        )
    elif not base.get("providers"):
        logger.warning(
            "iobot config at %s has no 'providers' section — run %s will "
            "rely on provider env vars only.", IOBOT_CONFIG_PATH, run_id,
        )

    # MCP servers: the merged pack -> global -> workspace declaration tiers
    # (see merged_mcp_servers). This line used to write {} unconditionally,
    # which silently disconnected every server `mcp-add` had configured —
    # no workflow-run agent ever saw an MCP tool. iobot itself needs no
    # servers for filesystem/git access (native tools cover those); these
    # are for genuinely external capabilities.
    servers: Dict[str, Any] = merged_mcp_servers()

    # A compiled SWARM's markers ride the run's workflow snapshot — the raw
    # YAML, because the workflow loader ignores unknown keys (the `learning:`
    # precedent). `mcp_servers:` scopes the merged tier view to the swarm's
    # roster; `budget.tool_calls` becomes the run's maxToolIterations (the
    # hard rabbit-hole cap). Fail-open: no snapshot (or a plain workflow's
    # snapshot, which carries neither key) leaves both untouched. This one
    # seam covers the blocking run path, spawn_run, and run-step's S3
    # recovery re-creation alike.
    _budget_tool_calls: Optional[int] = None
    try:
        import yaml as _yaml
        _wf_yaml = root_path / "instances" / run_id / "workflow" / "workflow.yaml"
        if _wf_yaml.exists():
            _wf_data = _yaml.safe_load(_wf_yaml.read_text(encoding="utf-8")) or {}
            _roster = _wf_data.get("mcp_servers")
            if isinstance(_roster, list):
                _names = {str(n) for n in _roster}
                for _unknown in sorted(_names - set(servers)):
                    logger.warning(
                        "swarm roster names MCP server %r but no declaration "
                        "tier provides it (available: %s) - declare it with "
                        "mcp-add or a pack mcp.yaml, or fix the roster",
                        _unknown, ", ".join(sorted(servers)) or "none")
                servers = {k: v for k, v in servers.items() if k in _names}
            _bt = (_wf_data.get("budget") or {}).get("tool_calls") \
                if isinstance(_wf_data.get("budget"), dict) else None
            if isinstance(_bt, int) and _bt >= 1:
                _budget_tool_calls = max(20, _bt)
    except Exception:
        # Fail CLOSED, same contract as the roster read in
        # create_filtered_workspace: the MCP roster and the tool-call budget
        # are capability CONTROLS, and a control narrows on failure. Leaving
        # `servers` unfiltered here would hand a swarm whose snapshot went
        # unreadable EVERY declared MCP server at the deployment-default
        # iteration cap - the same leak as the agent-catalog one, one seam
        # over. Zero servers is the safe degradation; a corrupt snapshot
        # fails the run at the scheduler's own read regardless. (A MISSING
        # snapshot takes the normal path above and keeps everything - that
        # is the plain-workflow/no-marker case, not a corrupt control.)
        servers = {}
        logger.warning(
            "could not read run %s's snapshot for swarm markers - MCP "
            "servers fail CLOSED (zero servers this run); budget cap "
            "unknown, deployment default applies. Fix the snapshot under "
            "instances/%s/workflow/ and retry.", run_id, run_id,
            exc_info=True)

    tools = base.setdefault("tools", {})
    tools["mcpServers"] = servers
    # Ensure exec tool is explicitly enabled (v0.1.5 gates on exec.enable).
    # Set pathAppend to venv bin dir + node bin dir so exec'd commands
    # (ioagentfarm run-step, iof-query, iof-consult, vectorfs, node) resolve
    # to the correct binaries.
    #
    # NATIVE paths joined with os.pathsep — NOT the Git-Bash form this used
    # to write. iobot 0.1.5 ran exec through `bash -l -c` on Windows, so
    # `/c/...:...` was right then; 0.3.0's ExecTool defaults to POWERSHELL on
    # Windows and composes path_append into env["PATH"] with os.pathsep
    # (shell.py:_compose_path), where a bash-style entry is garbage. The
    # symptom was every venv console script being invisible to agents on
    # Windows — found when a federation pressure test's fresh session could
    # not resolve `iof-consult`, while an earlier session had "recovered" by
    # recursively searching the filesystem for the absolute path.
    import shutil

    exec_cfg = tools.setdefault("exec", {})
    exec_cfg["enable"] = True
    venv_bin = os.path.join(sys.prefix, "Scripts" if sys.platform == "win32" else "bin")
    extra_path_parts = [venv_bin]
    seen_bin = {venv_bin}
    # Discover additional bin dirs (vectorfs/node/npm) via shutil.which against
    # the parent process PATH so workflow subprocesses can find them too.
    for binary in ("vectorfs", "node", "npm"):
        located = shutil.which(binary)
        if not located:
            continue
        bin_dir = str(Path(located).parent)
        if bin_dir in seen_bin:
            continue
        seen_bin.add(bin_dir)
        extra_path_parts.append(bin_dir)
    exec_cfg["pathAppend"] = os.pathsep.join(extra_path_parts)

    # Env passthrough for exec'd sub-commands (run-step, iof-query, iof-api, ...).
    # iobot's ExecTool runs with a STRIPPED env and only forwards keys listed in
    # `allowedEnvKeys` (default: none). Without this, a delegated `ioagentfarm
    # run-step` never inherits IOF_ROOT and resolves `.iof` relative to the
    # sub-agent's workspace cwd — splitting the run's snapshot / forensics /
    # output / metadata across two roots (the metadata-fallback + MYSQL_HOST bug).
    # This lists only KEY NAMES; iobot reads each value from os.environ at exec
    # time, so no secret values are written to the config file. IOF_ROOT is the
    # load-bearing one (must match the pod's configured absolute root in K8s);
    # the rest keep sub-commands consistent with the parent process.
    _passthrough_keys = list(PASSTHROUGH_ENV_KEYS) + [
        # Tenant identity. Without these two the exec strip silently drops a
        # scoped run back to the DEFAULT agent home: the driver holds the
        # tenant env, but `run-step` — exec'd BY iobot — inherits only the
        # allowlist, so the step agent loads the wrong persona and writes the
        # wrong MEMORY.md. Caught by a live scoped run whose artifact came
        # from the default persona (Phase 3).
        "IOF_WORKSPACE", "IOF_AGENT_HOME",
        "IOF_ROOT", "IOF_DATABASE_URL", "IOF_RUNNER", "IOF_STORAGE",
        "IOF_S3_BUCKET", "IOF_S3_PREFIX", "IOF_S3_REGION", "IOF_S3_ENDPOINT",
        "IOF_DISABLE_STREAMING", "IOF_REQUEST_TIMEOUT_S", "IOF_STALL_MAX_RETRIES",
        "IOF_HARD_ATTEMPT_CAP_MULTIPLIER", "IOF_SANDBOX", "IOF_PROGRESS_FILE",
        "VECTORFS_STORE", "VECTORFS_COLLECTION", "QDRANT_URL", "QDRANT_API_KEY",
        "IOF_USE_GENAI_BEDROCK", "GENAI_API_KEY", "GENAI_API_BASE", "GENAI_MODEL",
        "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_DEFAULT_REGION", "AWS_REGION",
        "MINIMAX_API_KEY", "PYTHONIOENCODING",
        # Azure OpenAI env-fallbacks read by the vendored chat provider —
        # AZURE_OPENAI_API_VERSION in particular is env-ONLY (no config
        # field), so without these a nested run-step loses it entirely.
        "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_API_BASE",
        "AZURE_OPENAI_MODEL", "AZURE_OPENAI_API_VERSION",
        # Learning v2. The driver holds IOF_LEARNING_V2 but `run-step` —
        # exec'd BY iobot — inherits only this allowlist, and it is
        # run-step's process that runs _finalize_step AND spawns the step
        # agent. Without these, a v2-activated deployment silently runs its
        # nested steps in v1 mode: MEMORY.md loads and populates again, v1
        # observations accumulate, and no draft is ever distilled — while
        # the top-level process believes v2 is on. Same trap as the tenant
        # identity keys above, one feature later.
        "IOF_LEARNING_V2", "IOF_LEARNING_REVIEWER", "IOF_LEARNING_HUB",
        "IOF_LEARNING_HUB_URL", "IOF_PREFERENCES_DB", "IOF_PREFERENCES_DB_URL",
        # Documentation search. Jarvis execs `iof-docs` to help a stuck user;
        # the tool resolves the doc set from AICORE_DOCS_DIR, so without it in
        # the exec allowlist the tool cannot find the docs a deployment mounted
        # and falls back to walking up from the (wrong) exec cwd.
        "AICORE_DOCS_DIR",
    ]
    exec_cfg["allowedEnvKeys"] = sorted(set((exec_cfg.get("allowedEnvKeys") or []) + _passthrough_keys))

    # Disable web search/fetch — agents don't need web access during steps.
    # Saves ~750 tokens per LLM call in tool definitions.
    tools.setdefault("web", {})["enable"] = False
    # Sandbox only when explicitly requested.  Agents need project directory
    # access by default (reading input files, running code, etc.).
    # Set IOF_SANDBOX=true to confine all tools to IOBOT_WORKSPACE.
    if os.environ.get("IOF_SANDBOX", "").lower() == "true":
        tools["restrictToWorkspace"] = True

    # Disable Dream memory consolidation — ioagentfarm manages MEMORY.md
    # via its own learning system (persist_agent_memory).  Dream would race
    # and overwrite our compiled memory.  Set interval to ~1 year.
    agents = base.setdefault("agents", {}).setdefault("defaults", {})
    agents.setdefault("dream", {})["intervalH"] = 8760

    # Swarm budget: the HARD tool-iteration cap for this run's sessions.
    # Never raises the deployment default — a budget is a ceiling, not a
    # grant.
    if _budget_tool_calls is not None:
        current = agents.get("maxToolIterations")
        agents["maxToolIterations"] = (min(current, _budget_tool_calls)
                                       if isinstance(current, int)
                                       else _budget_tool_calls)

    config_path.write_text(
        json.dumps(base, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    logger.info("Created instance config for run %s at %s", run_id, config_path)
    return config_path


def create_role_config(base_config_path: Path, role: str, model: str) -> Path:
    """Create a role-specific config with a model override.

    Copies the base instance config and sets agents.defaults.model to the
    specified model.  Written next to the base config as config_<role>.json.
    If the role model matches the base config model, returns the base path
    unchanged (no extra file needed).
    """
    base = json.loads(base_config_path.read_text(encoding="utf-8"))
    current_model = base.get("agents", {}).get("defaults", {}).get("model", "")
    if current_model == model:
        return base_config_path  # No override needed

    base.setdefault("agents", {}).setdefault("defaults", {})["model"] = model
    role_config_path = base_config_path.parent / f"config_{role}.json"
    role_config_path.write_text(
        json.dumps(base, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    logger.info("Created role config for %s with model=%s at %s", role, model, role_config_path)
    return role_config_path


def narrow_mcp_tools(config: dict, allowed: list) -> dict:
    """Return a copy of a iobot config with every MCP server's
    ``enabledTools`` narrowed to ``allowed``.

    ``allowed`` entries may be raw tool names or wrapped
    ``mcp_<server>_<tool>`` names — iobot's enabledTools matches both. An
    empty list leaves every server declared but with no enabled tools (no
    ``*``, no names), which registers nothing: the step runs MCP-blind.

    Pure function so the least-privilege narrowing is unit-testable apart
    from the filesystem.
    """
    out = json.loads(json.dumps(config))
    servers = out.get("tools", {}).get("mcpServers", {}) or {}
    names = [str(a) for a in (allowed or [])]
    for entry in servers.values():
        if isinstance(entry, dict):
            entry["enabledTools"] = list(names)
    return out


def create_step_tools_config(base_config_path: Path, step_key: str,
                             allowed: list) -> Path:
    """Create a per-STEP config narrowing MCP tools to the step's allowlist.

    The engine-level half of least privilege: a workflow step that declares
    ``mcp_tools`` gets a derived instance config whose servers enable ONLY
    those tools, so the step's agent never even sees a delivery/publish tool
    it has no business calling (observed live: a generate-side agent called
    publish_campaign_update unprompted, before any approval existed — a
    prompt-level allowlist is advice; this is enforcement).

    Written next to the base config as ``config_step_<key>.json``; the step
    key is sanitized for story steps (``story:X:suffix``).
    """
    base = json.loads(base_config_path.read_text(encoding="utf-8"))
    narrowed = narrow_mcp_tools(base, allowed)
    safe_key = re.sub(r"[^A-Za-z0-9_.-]", "_", step_key)
    step_config_path = base_config_path.parent / f"config_step_{safe_key}.json"
    step_config_path.write_text(
        json.dumps(narrowed, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    logger.info("Created step config for %s narrowing MCP tools to %s at %s",
                step_key, allowed, step_config_path)
    return step_config_path


def get_instance_config_path(root_path: Path, run_id: str) -> Optional[Path]:
    """Return the instance config path if it exists, else None."""
    config_path = root_path / "instances" / run_id / "config.json"
    return config_path if config_path.exists() else None


def get_run_output_dir(root_path: Path, run_id: str) -> Path:
    """Return the run-scoped project output directory.

    All agent-written artifacts go here.  Always at
    ``.iof/instances/<run_id>/project/`` — derivable from run_id,
    no DB column needed.
    """
    return root_path / "instances" / run_id / "project"
