"""Named output formats, chosen per request — the K6 phase-1 registry.

WHY THIS EXISTS. The response envelope (wire ``"schema": "v1"``) gets a
safety net — lenient extraction, structural validation, bounded
retry-on-malformed — and a CUSTOM format gets none of it, because all three
seams are hardcoded to the v1 shape (`emits_v1_envelope`'s cue list,
`_extract_envelope_lenient`'s key set, `envelope_validator`'s `data.rows`
check). The stated expectation (2026-08-28): a custom format should have the
same safety net as v1, and an agent should be able to answer in MULTIPLE
formats — the format is a per-request choice, not a property welded to the
agent. See NEXT_PHASE_BACKLOG.md K6 for the full design; this module is
phase 1: the registry, generic extraction, schema validation and the bounded
retry. The anti-fabrication (`from_tools`) generalisation is phase 2 — the
field is parsed and carried so a declaration written today keeps working.

HOW A FORMAT IS DECLARED. A skill directory whose SKILL.md frontmatter
carries ``output_format: <name>`` declares a format:

    ---
    name: card_format
    description: "..."
    output_format: summary_card
    from_tools: [figures]        # optional; phase-2 anti-fabrication tag
    ---
    <emit instructions the model follows for this format>
    ```json
    { "type": "object", "required": [...], "properties": {...} }
    ```

The body is the EMIT INSTRUCTION (injected into the prompt only for a turn
that names this format); the first fenced JSON block that looks like a JSON
Schema is the contract the reply is validated against. Two deliberate
consequences of living in ``skills/``:

- it RIDES THE MATERIALISER: `ensure_agent_workspace` copies named parts
  (SOUL.md, skills/, ...) and nothing else, so a sibling ``formats/`` tree
  would silently not reach a deployed agent home;
- it does NOT trip lint-agent's exactly-one-output-contract rule, which
  counts only ``always: true`` skills (`defines_output_contract`). A format
  skill is ``always: false`` — it governs nothing until a request names it.

``viz_envelope`` is the BUILT-IN format: any agent can be asked for the
response envelope by name, and a workspace cannot shadow it. The request
name was ``v1`` for a short while and was renamed before anything shipped
against it — ``v1`` is a wire-version tag, not a name a front-end developer
would guess, while "the response envelope" has always been the platform's
own vocabulary for this shape. TWO NAMES, TWO JOBS, deliberately: the
REQUEST name (``format: "viz_envelope"``) says which shape the caller wants;
the payload's internal ``"schema": "v1"`` stamps which VERSION of that
shape came back, is what clients and the lenient extractor key on, and does
not move with this rename. ``format: "v1"`` does not resolve — the 400
lists ``viz_envelope``. The legacy ``format: "json"`` request value is NOT
routed here — it keeps its historic suffix-and-extract behaviour in
``web/app.py``, byte-identical.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

__all__ = [
    "OutputFormat", "V1_FORMAT", "declared_formats", "declared_format_names",
    "resolve_format", "extract_json_block", "validate_against",
    "enforce_format", "format_instructions_suffix",
]


@dataclass(frozen=True)
class OutputFormat:
    """One named output contract: what to ask for, and what to accept."""
    name: str
    schema: dict | None
    instructions: str
    from_tools: tuple[str, ...] = ()      # phase-2: fields cross-checked
    source: str = "builtin"               # "builtin" | the SKILL.md path


#: The response envelope, structurally. This is a VALIDATION schema for the
#: shape `result_composer` mandates — every top-level field present, `null`
#: when unused — not a replacement for that skill's prose (which stays the
#: emit instruction for agents that carry it). Kept deliberately permissive
#: inside `data`: the composer's rules 2/9/10 are prose judgement, and a
#: validator stricter than the contract would reject compliant replies.
V1_SCHEMA: dict = {
    "type": "object",
    "required": ["schema", "answer", "data", "insight", "evidence"],
    "properties": {
        "schema": {"const": "v1"},
        "answer": {"type": ["string", "null"]},
        "data": {"type": ["object", "null"]},
        "insight": {"type": ["string", "null"]},
        "viz_hint": {"type": ["object", "null"]},
        "follow_up_chips": {"type": ["array", "null"]},
        "evidence": {"type": ["object", "null"]},
    },
}

_V1_INSTRUCTIONS = """
Respond with EXACTLY ONE fenced ```json block and nothing outside it, matching
the response envelope: {"schema": "v1", "answer": <one-line answer or null>,
"data": <{"type": "scalar"|"table"|"list"|"text", ...} or null>, "insight":
<one paragraph or null>, "viz_hint": <chart hint or null>, "follow_up_chips":
<array of short next questions or null>, "evidence": <{"sources": [...],
"queries": [...], "trust": ..., "freshness": ..., "caveats": [...]} or null>}.
Every top-level field present; use the literal JSON null for unused fields;
raw JSON numbers, no markdown inside values.
"""

#: The symbol keeps the wire version in its name (V1_*) because that is
#: what it carries — the schema whose payload stamps ``"schema": "v1"``.
#: The REQUEST name is the OutputFormat's ``name``: ``viz_envelope``.
V1_FORMAT = OutputFormat(name="viz_envelope", schema=V1_SCHEMA,
                         instructions=_V1_INSTRUCTIONS, source="builtin")

#: A fenced JSON block. Deliberately NOT anchored to end-of-response — the
#: same lesson `_extract_envelope_lenient` carries: a trailing footer after
#: the fence must not drop the payload.
_FENCE_RE = re.compile(r"```(?:json)?\s*\n(.*?)```", re.DOTALL)

#: What makes a fenced block a SCHEMA rather than an example payload: JSON
#: Schema vocabulary at the top level. An example envelope in the same skill
#: body has none of these keys.
_SCHEMA_MARKERS = ("$schema", "properties", "required")


def _parse_frontmatter(text: str) -> dict | None:
    """The skill's frontmatter mapping, or None. One implementation with the
    linter would be ideal; `content_lint._frontmatter` is imported lazily so
    a lint refactor cannot break format discovery at import time."""
    try:
        from ioagentfarm.engine.content_lint import _frontmatter
        data, _, _ = _frontmatter(text)
        return data if isinstance(data, dict) else None
    except Exception:
        # Minimal fallback: split the --- fence and yaml-load it.
        try:
            import yaml
            m = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
            if not m:
                return None
            data = yaml.safe_load(m.group(1))
            return data if isinstance(data, dict) else None
        except Exception:
            return None


def _schema_from_body(body: str) -> dict | None:
    """The first fenced JSON block that reads as a JSON Schema."""
    for m in _FENCE_RE.finditer(body):
        try:
            cand = json.loads(m.group(1))
        except Exception:
            continue
        if isinstance(cand, dict) and any(k in cand for k in _SCHEMA_MARKERS):
            return cand
    return None


def declared_formats(workspace: Path | str) -> dict[str, OutputFormat]:
    """Every format the agent's workspace declares, by name.

    NOT CACHED, for the same reason `emits_v1_envelope` is not: the workspace
    is re-seeded from the pack on a new session inside the same filesystem
    tick, so an mtime memo serves the stale answer exactly when it matters.
    The scan is a handful of small reads against an LLM call measured in
    seconds.
    """
    out: dict[str, OutputFormat] = {}
    skills = Path(workspace) / "skills"
    try:
        entries = sorted(skills.iterdir())
    except OSError:
        return out
    for d in entries:
        md = d / "SKILL.md"
        try:
            if not d.is_dir() or not md.is_file():
                continue
            text = md.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        fm = _parse_frontmatter(text)
        if not fm:
            continue
        name = fm.get("output_format")
        if not isinstance(name, str) or not name.strip():
            continue
        name = name.strip()
        if name == "viz_envelope":
            continue                      # the builtin cannot be shadowed
        body = re.sub(r"^---\s*\n.*?\n---\s*\n", "", text, count=1,
                      flags=re.DOTALL)
        schema = _schema_from_body(body)
        raw_ft = fm.get("from_tools")
        from_tools = tuple(str(x) for x in raw_ft) \
            if isinstance(raw_ft, (list, tuple)) else ()
        out[name] = OutputFormat(
            name=name, schema=schema,
            instructions=body.strip(),
            from_tools=from_tools, source=str(md))
    return out


def declared_format_names(workspace: Path | str) -> list[str]:
    """The names a request may pass — the builtin first."""
    return ["viz_envelope", *sorted(declared_formats(workspace))]


def resolve_format(workspace: Path | str, name: str | None) -> OutputFormat | None:
    """The format a request named, or None.

    ``None``/``""``/``"json"`` are NOT formats — ``"json"`` is the legacy
    request value whose suffix-and-extract behaviour lives in ``web/app.py``
    and must stay byte-identical, so it deliberately does not resolve here.
    """
    if not name or name == "json":
        return None
    if name == "viz_envelope":
        return V1_FORMAT
    return declared_formats(workspace).get(name)


def extract_json_block(text: str) -> dict | None:
    """The reply's JSON payload, tolerating sloppiness — format-agnostic.

    Preference order mirrors `_extract_envelope_lenient` without its v1 key
    check: the LAST fenced JSON dict wins (an agent that narrates a sample
    first puts the real payload last), then the whole reply as bare JSON.
    """
    if not text:
        return None
    found: list[dict] = []
    for m in _FENCE_RE.finditer(text):
        try:
            cand = json.loads(m.group(1))
        except Exception:
            continue
        if isinstance(cand, dict):
            found.append(cand)
    if found:
        return found[-1]
    try:
        cand = json.loads(text.strip())
        return cand if isinstance(cand, dict) else None
    except Exception:
        return None


def _fallback_validate(schema: dict, obj: dict) -> list[str]:
    """required + top-level type/const checks, for a host without jsonschema."""
    problems: list[str] = []
    for key in schema.get("required") or []:
        if key not in obj:
            problems.append(f"$.{key}: required field is missing")
    _types = {"object": dict, "array": list, "string": str, "number":
              (int, float), "integer": int, "boolean": bool,
              "null": type(None)}
    for key, spec in (schema.get("properties") or {}).items():
        if key not in obj or not isinstance(spec, dict):
            continue
        if "const" in spec and obj[key] != spec["const"]:
            problems.append(f"$.{key}: must be {spec['const']!r}, "
                            f"got {obj[key]!r}")
            continue
        t = spec.get("type")
        if t is None:
            continue
        allowed = t if isinstance(t, list) else [t]
        pytypes = tuple(pt for a in allowed
                        for pt in ((_types[a],) if not isinstance(
                            _types.get(a), tuple) else _types[a])
                        if a in _types)
        # bool is an int in Python; "integer"/"number" must not accept it.
        if pytypes and not isinstance(obj[key], pytypes) or (
                isinstance(obj[key], bool) and bool not in pytypes
                and any(a in ("integer", "number") for a in allowed)):
            problems.append(
                f"$.{key}: expected {'|'.join(map(str, allowed))}, got "
                f"{type(obj[key]).__name__}")
    return problems


def validate_against(fmt: OutputFormat, obj: Any) -> list[str]:
    """Violations of *fmt*'s schema in *obj* — [] means valid.

    A format with NO schema validates trivially: declaring instructions
    without a schema is legal, and buys the extraction + the prompt
    injection but no structural check.
    """
    if fmt.schema is None:
        return []
    if not isinstance(obj, dict):
        return ["$: reply is not a JSON object"]
    try:
        import jsonschema
        errs = sorted(jsonschema.Draft7Validator(fmt.schema).iter_errors(obj),
                      key=lambda e: list(e.absolute_path))
        return [
            "$." + ".".join(str(p) for p in e.absolute_path) + ": " + e.message
            if e.absolute_path else "$: " + e.message
            for e in errs
        ]
    except ImportError:
        return _fallback_validate(fmt.schema, obj)


def format_instructions_suffix(fmt: OutputFormat) -> str:
    """The per-turn prompt frame for a named format."""
    return (
        "\n\n---\n**Output format requirement (engine-enforced, format "
        f"'{fmt.name}'):**\n{fmt.instructions.strip()}\n"
        "Respond with the fenced ```json block this format requires; prose "
        "outside it is dropped by the parser."
    )


def _prose_outside_block(response: str) -> bool:
    """True when the reply carries text outside its fenced JSON block.

    Whitespace does not count, and neither does a reply that IS bare JSON
    (no fence at all) - that is a different shape, already accepted by
    `extract_json_block`, and calling it "prose" would be a false positive
    on every caller that asks for raw JSON.
    """
    if "```" not in (response or ""):
        return False
    outside = _FENCE_RE.sub("", response)
    return bool(outside.strip())


def _corrective_prompt(fmt: OutputFormat, problems: list[str]) -> str:
    """Name the exact violations — the discipline the v1 retry already has:
    a re-prompt that names the schema path beats 'try again'."""
    listed = "\n".join(f"- {p}" for p in problems[:10])
    return (
        f"Your previous reply did not conform to the required output format "
        f"'{fmt.name}'. Violations:\n{listed}\n\n"
        "Re-emit the SAME content, corrected: exactly one fenced ```json "
        "block conforming to the format, nothing outside it. Do not run "
        "tools again; do not change the substance of the answer."
    )


async def enforce_format(
    fmt: OutputFormat,
    response: str,
    reprompt: Callable[[str], Awaitable[str]],
    max_retries: int = 1,
) -> tuple[str, dict | None, list[str]]:
    """Extract → validate → bounded retry. Returns (response, payload, problems).

    The retry spends a model call, so it is BOUNDED (default one) and only a
    STRICT improvement replaces the original: a retry that is also invalid
    keeps whichever reply has fewer violations, and a retry that returns no
    payload at all changes nothing. `problems == []` means the returned
    payload conforms.
    """
    payload = extract_json_block(response)
    problems = (validate_against(fmt, payload) if payload is not None
                else ["$: no JSON payload found in the reply"])
    # PROSE OUTSIDE THE BLOCK IS A VIOLATION, and it was reported as
    # `valid: true, problems: []` (chat round 4): a persona greeting before
    # the fence and a signature after it. A client reading the parsed
    # `envelope` is unharmed; one reading `content` gets prose it cannot
    # parse, which is exactly what a declared format promises it will not
    # get. Named as a problem so the corrective retry can fix it, and last
    # so a schema violation is still the first thing reported.
    if payload is not None and _prose_outside_block(response):
        problems = problems + [
            "$: text outside the fenced JSON block - the format requires the "
            "block and nothing else"]
    tries = 0
    while problems and tries < max_retries:
        tries += 1
        retry_text = await reprompt(_corrective_prompt(fmt, problems))
        if not retry_text:
            break
        p2 = extract_json_block(retry_text)
        problems2 = (validate_against(fmt, p2) if p2 is not None
                     else ["$: no JSON payload found in the reply"])
        if p2 is not None and (not problems2 or len(problems2) < len(problems)):
            response, payload, problems = retry_text, p2, problems2
    return response, payload, problems
