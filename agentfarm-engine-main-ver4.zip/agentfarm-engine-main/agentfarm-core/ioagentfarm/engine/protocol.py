from __future__ import annotations
import json
from typing import Any, Dict, List, Optional, Tuple


def _try_parse_json(raw: str) -> Optional[Any]:
    """Strip optional markdown fences and parse JSON."""
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(cleaned)
    except Exception:
        return None


# ROUTE_JSON: a `type: route` step's choice of which declared successors run.
# Printed by the tool (ioagentfarm.sdk.route.next) and read by _finalize_step.
_KNOWN_KEYS = {"STATUS", "OUTPUT", "STORIES_JSON", "TASKS_JSON", "STDERR", "ROUTE_JSON"}


def parse_key_value_protocol(text: str) -> Tuple[Dict[str, str], Optional[Any], Optional[List[Dict[str, Any]]]]:
    """Parse KEY: value protocol from agent output.

    Only recognizes known protocol keys (STATUS, OUTPUT, STORIES_JSON, TASKS_JSON, STDERR).
    Other ALL_CAPS: lines in agent output (HTTP:, TODO:, API:, etc.) are treated as
    regular text, preventing false-positive key detection that corrupts parsing.

    Returns (kv_dict, stories_list_or_none, tasks_list_or_none).
    """
    kv: Dict[str, str] = {}
    lines = (text or "").splitlines()
    i = 0

    def is_key_line(line: str) -> bool:
        if ":" not in line:
            return False
        k = line.split(":", 1)[0].strip()
        return k in _KNOWN_KEYS

    while i < len(lines):
        line = lines[i]
        if is_key_line(line):
            key, rest = line.split(":", 1)
            key = key.strip()
            rest_val = rest.lstrip()
            i += 1
            buf = [rest_val] if rest_val else []
            while i < len(lines) and not is_key_line(lines[i]):
                buf.append(lines[i])
                i += 1
            kv[key] = "\n".join(buf).strip("\n")
        else:
            i += 1

    stories_obj = None
    if "STORIES_JSON" in kv:
        stories_obj = _try_parse_json(kv["STORIES_JSON"])

    tasks_obj = None
    if "TASKS_JSON" in kv:
        tasks_obj = _try_parse_json(kv["TASKS_JSON"])
        if not isinstance(tasks_obj, list):
            tasks_obj = None

    return kv, stories_obj, tasks_obj
