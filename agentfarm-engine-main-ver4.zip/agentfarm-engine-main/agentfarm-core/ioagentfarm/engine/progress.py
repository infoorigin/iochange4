from __future__ import annotations
from typing import Any, Dict, List, Optional
from datetime import datetime
import json


def build_progress_markdown(
    *,
    run: Dict[str, Any],
    steps: List[Dict[str, Any]],
    stories: Dict[str, int],
    last_event: Dict[str, Any] | None = None,
    team_roster: Optional[str] = None,
) -> str:
    # Structured but human-friendly.
    lines: list[str] = []
    lines.append(f"# Progress — {run['id']}")
    lines.append("")
    lines.append(f"- **Workflow:** {run['workflow_name']}")
    lines.append(f"- **Status:** {run['status']}")
    lines.append(f"- **Goal:** {run['goal']}")
    lines.append(f"- **Updated:** {run['updated_at']}")
    lines.append("")

    # Team roster (generated from workflow roles + agent SOUL.md files)
    if team_roster:
        lines.append(team_roster)
        lines.append("")

    lines.append("## Stories")
    lines.append(f"- Done/Total: **{stories.get('done',0)} / {stories.get('total',0)}**")
    lines.append("")
    if last_event:
        lines.append("## Last event")
        lines.append("```json")
        lines.append(json.dumps(last_event, ensure_ascii=False, indent=2))
        lines.append("```")
        lines.append("")
    lines.append("## Steps")
    lines.append("| Seq | Step | Role | Status | Attempts |")
    lines.append("|---:|---|---|---|---|")
    for s in steps:
        lines.append(
            f"| {s['seq']} | `{s['step_key']}` | `{s['role']}` | **{s['status']}** | {s['attempt']}/{s['max_attempts']} |"
        )
    lines.append("")
    lines.append("## Notes")
    lines.append("- This file is overwritten by the scheduler after each step.")
    lines.append("- Prompts can inject it via `{{progress}}`.")
    lines.append("")
    return "\n".join(lines)
