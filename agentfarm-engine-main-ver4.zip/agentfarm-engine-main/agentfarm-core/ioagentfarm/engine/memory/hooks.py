"""Thin façade — the ONLY surface the rest of the engine calls.

Every entry point is self-contained (its own gating, store, error handling)
so each call site is one line and carries no memory logic. Mirrors
``engine/learning/hooks.py`` deliberately.

Call sites:
  * cli_orchestration._finalize_step (run → done)  -> on_run_completed()
  * engine.workspaces.create_filtered_workspace     -> provision_step_workspace()
  * web.app.AgentPool.get                           -> wrap_with_workspace_memory()
  * web.app.adhoc_chat                              -> chat_user_block()
  * web.app lifespan / aicore memory sweep          -> sweep()

Gate: ``IOF_MEMORY`` (default on; ``0``/``off`` disables everything here —
the store and the CLI keep working for a steward).
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from loguru import logger

_STORES: Dict[str, Any] = {}
_OFF = ("0", "false", "off", "no", "disabled")


def enabled() -> bool:
    return (os.environ.get("IOF_MEMORY") or "").strip().lower() not in _OFF


def sync_mode() -> bool:
    """Consolidate INLINE at run completion instead of in a detached
    process. Tests and the chaos harness set it; a pod does not."""
    return (os.environ.get("IOF_MEMORY_SYNC") or "").strip().lower() in ("1", "true", "on", "yes")


def db_url(root: Path) -> str:
    url = (os.environ.get("IOF_DATABASE_URL") or "").strip()
    return url or f"sqlite:///{Path(root) / 'state.db'}"


def memory_store(root: Path):
    """The shared :class:`WorkspaceMemoryStore` for this process, keyed by
    database URL so a test that repoints the root gets a fresh one."""
    url = db_url(root)
    store = _STORES.get(url)
    if store is None:
        from ioagentfarm.engine.db import make_adapter
        from ioagentfarm.engine.memory.store import WorkspaceMemoryStore
        store = WorkspaceMemoryStore(make_adapter(url))
        store.init()
        _STORES[url] = store
    return store


def add_by_hand(store, workspace_code: str, *, fact: str, scope: str = "workspace",
                mark: str = "durable", draft: bool = False, actor: str = "unknown",
                source_ref: str = ""):
    """A hand-written fact, through the rails, into the store - THE ONE PATH.

    ``aicore memory add`` and ``POST /api/users/{id}/memory`` both call this,
    so the finding-drop, the PII redaction and the security scan apply to an
    HTTP write exactly as they do at the terminal: neither surface can be
    the one that bypasses a rail. Returns ``(gate, row, outcome)`` - when
    ``gate.dropped`` the row is None and ``gate.reason`` says why the fact
    was refused; otherwise ``outcome`` is the store's verdict (``activated`` /
    ``added`` / ``duplicate`` / ``stale``) and ``gate.notes`` lists what
    was redacted or flagged.
    """
    from datetime import datetime as _dt, timezone as _tz
    from ioagentfarm.engine.memory import rails
    from ioagentfarm.engine.memory.models import Candidate
    gate = rails.apply(Candidate(fact=fact, mark=mark, scope=scope))
    if gate.dropped or gate.candidate is None:
        return gate, None, "refused"
    row, outcome = store.add(workspace_code, gate.candidate,
                             status="draft" if draft else "active",
                             origin="manual", source_ref=source_ref or actor, actor=actor,
                             source_at=_dt.now(_tz.utc).isoformat())
    return gate, row, outcome


def reset_cache() -> None:
    _STORES.clear()


def workspace_for_run(run_store, run: Dict[str, Any]) -> Optional[str]:
    from ioagentfarm.engine.supervisor import _run_workspace
    return _run_workspace(run_store, run)


_SOLUTION_MAP: Optional[Dict[str, str]] = None


def solution_for_workflow(workflow_name: Optional[str]) -> Optional[str]:
    """The SOLUTION a workflow belongs to (``Pack.solution``), so a step
    receives the ``solution:<code>`` scope beside the workspace's. Best-
    effort and cached: the map is read from the installed packs once."""
    global _SOLUTION_MAP
    if not workflow_name:
        return None
    if _SOLUTION_MAP is None:
        try:
            from ioagentfarm.engine.catalog_sync import workflow_solution_map
            _SOLUTION_MAP = dict(workflow_solution_map())
        except Exception:  # noqa: BLE001
            _SOLUTION_MAP = {}
    return _SOLUTION_MAP.get(workflow_name) or None


# ---------------------------------------------------------------------------
# run completion
# ---------------------------------------------------------------------------

def _spawn_consolidation(root: Path, run_id: str, workspace_code: str) -> Optional[int]:
    """Detached ``aicore memory consolidate --run <id>``: the run's forensic
    attempts are on THIS pod's disk, so the extraction runs here, but the
    finalizer must not wait on two model calls. Log lands beside the run."""
    log_dir = Path(root) / "instances" / run_id / "memory"
    log_dir.mkdir(parents=True, exist_ok=True)
    log = open(log_dir / "consolidate.log", "ab")  # noqa: SIM115 - handed to the child
    argv = [sys.executable, "-m", "ioagentfarm.cli", "memory", "consolidate",
            "--run", run_id, "--workspace", workspace_code, "--json"]
    kwargs: Dict[str, Any] = {"stdout": log, "stderr": subprocess.STDOUT,
                              "stdin": subprocess.DEVNULL, "close_fds": True}
    env = dict(os.environ)
    env["IOF_ROOT"] = str(root)
    env["IOF_WORKSPACE"] = workspace_code
    if os.name == "nt":
        kwargs["creationflags"] = 0x00000200 | 0x00000008  # NEW_PROCESS_GROUP | DETACHED
    else:
        kwargs["start_new_session"] = True
    try:
        proc = subprocess.Popen(argv, env=env, **kwargs)
        return proc.pid
    finally:
        log.close()


def on_run_completed(root: Path, run_store, run_id: str) -> Dict[str, Any]:
    """Called ONCE per run by the finalizer that won the terminal transition.
    Returns a small report for the forensic event; never raises."""
    report: Dict[str, Any] = {"run_id": run_id, "mode": "off"}
    if not enabled():
        return report
    try:
        run = run_store.get_run(run_id)
        workspace_code = workspace_for_run(run_store, run)
        if not workspace_code:
            report["mode"] = "skipped"
            report["reason"] = "run is not attributed to a workspace"
            return report
        report["workspace"] = workspace_code
        if sync_mode():
            from ioagentfarm.engine.memory.consolidate import consolidate_run
            store = memory_store(root)
            result = consolidate_run(store, run_store, Path(root), workspace_code, run_id)
            report["mode"] = "inline"
            report.update({k: v for k, v in result.items() if k != "run_id"})
            return report
        pid = _spawn_consolidation(Path(root), run_id, workspace_code)
        report["mode"] = "detached"
        report["pid"] = pid
        return report
    except Exception as exc:  # noqa: BLE001 - never costs the run its closing anchor
        logger.debug("memory: on_run_completed failed for {}", run_id, exc_info=True)
        report["mode"] = "error"
        report["error"] = f"{type(exc).__name__}: {exc}"
        return report


# ---------------------------------------------------------------------------
# step workspaces and served agents
# ---------------------------------------------------------------------------

def provision_step_workspace(root: Path, dest: Path, *, role: str,
                             workspace_code: Optional[str], solution: Optional[str] = None) -> bool:
    """Materialize the block into a step's filtered workspace. Best-effort."""
    if not enabled() or not workspace_code:
        return False
    try:
        from ioagentfarm.engine.memory.inject import materialize
        return materialize(memory_store(root), workspace_code, Path(dest), role=role,
                           solution=solution, force=True)
    except Exception:  # noqa: BLE001
        logger.debug("memory: provision_step_workspace skipped", exc_info=True)
        return False


def refresh_served_workspace(root: Path, workspace_dir: Path, *, role: str,
                             workspace_code: str, solution: Optional[str] = None) -> bool:
    if not enabled() or not workspace_code:
        return False
    try:
        from ioagentfarm.engine.memory.inject import materialize
        return materialize(memory_store(root), workspace_code, Path(workspace_dir), role=role,
                           solution=solution)
    except Exception:  # noqa: BLE001
        logger.debug("memory: refresh_served_workspace skipped", exc_info=True)
        return False


def chat_user_block(root: Path, workspace_code: Optional[str], user_id: Optional[str]) -> str:
    """The USER scope for one chat turn (per person, so per turn)."""
    if not enabled() or not workspace_code or not user_id:
        return ""
    try:
        from ioagentfarm.engine.memory.inject import user_block
        return user_block(memory_store(root), workspace_code, user_id)
    except Exception:  # noqa: BLE001
        logger.debug("memory: chat_user_block skipped", exc_info=True)
        return ""


def _user_from_session_key(session_key: Optional[str]) -> str:
    key = session_key or ""
    if ":u:" in key:
        return key.rsplit(":u:", 1)[1]
    return ""


def on_chat_turn(root: Path, workspace_code: str, *, role: str, user_id: str,
                 question: str, answer: str) -> None:
    """Extract from one Q/A pair in a background thread (the served process
    is long-lived, so a daemon thread outlives the request)."""
    if not enabled() or len((answer or "").strip()) < 80:
        return

    def _work():
        try:
            from ioagentfarm.engine.memory.consolidate import consolidate_chat
            rep = consolidate_chat(memory_store(root), workspace_code, role=role, user_id=user_id,
                                   question=question, answer=answer)
            logger.info("memory: chat turn consolidated role={} changed={}", role, rep.get("changed"))
        except Exception:  # noqa: BLE001
            logger.debug("memory: on_chat_turn failed", exc_info=True)

    threading.Thread(target=_work, daemon=True, name="memory-chat").start()


def wrap_with_workspace_memory(process_direct, *, role: str, workspace_code: str,
                               workspace: Path, root: Path):
    """Refresh the agent home's block before each turn (version-gated — one
    cheap SELECT) and extract from the turn afterwards. Returns the callable
    untouched when memory is off."""
    if not enabled():
        return process_direct
    import functools

    @functools.wraps(process_direct)
    async def _wrapped(*args, **kwargs):
        refresh_served_workspace(root, workspace, role=role, workspace_code=workspace_code)
        result = await process_direct(*args, **kwargs)
        try:
            question = str(args[0]) if args else str(kwargs.get("content") or "")
            answer = getattr(result, "content", "") or ""
            on_chat_turn(root, workspace_code, role=role,
                         user_id=_user_from_session_key(kwargs.get("session_key")),
                         question=question, answer=answer)
        except Exception:  # noqa: BLE001
            logger.debug("memory: post-turn extraction skipped", exc_info=True)
        return result

    return _wrapped


# ---------------------------------------------------------------------------
# the sweep — the crash-safety net and the schedule
# ---------------------------------------------------------------------------

def sweep(root: Path, run_store, workspace_code: str, *, limit: int = 20,
          sync_curated: bool = True) -> Dict[str, Any]:
    """One pass for one workspace: retire expired rows, re-sync the curated
    tiers, and consolidate every completed run that no worker finished —
    fresh runs whose detached consolidation died, and claims gone stale.
    Any pod may run it at any cadence; the claim table makes it safe."""
    out: Dict[str, Any] = {"workspace": workspace_code, "expired": 0, "consolidated": [],
                           "skipped": 0}
    if not enabled():
        out["mode"] = "off"
        return out
    store = memory_store(root)
    try:
        out["expired"] = store.expire(workspace_code)
    except Exception:  # noqa: BLE001
        logger.debug("memory: expire failed", exc_info=True)
    if sync_curated:
        try:
            from ioagentfarm.engine.memory.packtier import sync_curated as _sync
            out["curated"] = _sync(store, workspace_code)
        except Exception:  # noqa: BLE001
            logger.debug("memory: curated sync failed", exc_info=True)
    try:
        from ioagentfarm.engine.memory.consolidate import consolidate_run
        claims = {c["run_id"]: c for c in store.run_claims(workspace_code)}
        stale = {c["run_id"] for c in store.stale_claims(workspace_code)}
        done = 0
        # OLDEST FIRST. list_runs is newest-first; consolidating a backlog
        # in that order applied an older run's value after a newer run's
        # correction. The store's recency rule (source_at) is the guarantee;
        # this order keeps it the exception rather than the common path.
        backlog = sorted(run_store.list_runs(limit=max(limit * 5, 100)),
                         key=lambda r: str(r.get("created_at") or ""))
        for run in backlog:
            if run.get("status") != "done":
                continue
            if workspace_for_run(run_store, run) != workspace_code:
                continue
            rid = run["id"]
            claim = claims.get(rid)
            if claim is not None and claim.get("status") == "done":
                continue
            if claim is not None and claim.get("status") == "claimed" and rid not in stale:
                out["skipped"] += 1
                continue
            rep = consolidate_run(store, run_store, Path(root), workspace_code, rid)
            out["consolidated"].append({"run_id": rid, "claimed": rep.get("claimed"),
                                        "changed": rep.get("changed"),
                                        "candidates": rep.get("candidates"),
                                        "skipped": rep.get("skipped"), "error": rep.get("error")})
            done += 1
            if done >= limit:
                break
    except Exception:  # noqa: BLE001
        logger.debug("memory: sweep failed", exc_info=True)
    return out
