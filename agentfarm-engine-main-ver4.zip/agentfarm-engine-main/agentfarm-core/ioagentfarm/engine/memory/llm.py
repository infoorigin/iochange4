"""The one LLM seam of workspace memory.

Every model call goes through the harness's own provider path
(``provider_factory.make_provider(load_config())`` — the same object the
agent runtime uses), so auth, the provider swaps, forensic HTTP logging and
the non-streaming ceiling all apply. No second LLM stack.

``IOF_MEMORY_EXTRACTOR`` selects the completer:

* ``iobot`` (default, empty) — the deployment's model.
* ``stub`` — deterministic, no network: for EXTRACTION it returns the lines
  of the input that are already written in the ``- [mark] [scope] fact``
  form (the model that trusts the transcript); for CONSOLIDATION it emits
  ``ADD`` for every candidate. Tests, the chaos harness and an air-gapped
  smoke run use it.
* ``off`` — memory extraction disabled; the store, the CLI and injection
  keep working (curated tiers still flow).
"""
from __future__ import annotations

import os
import re
from typing import Callable, Optional

from loguru import logger

Completer = Callable[[str, str], str]

STAGE_EXTRACT = "MEMORY-STAGE: EXTRACT"
STAGE_CONSOLIDATE = "MEMORY-STAGE: CONSOLIDATE"

_PROVIDER = None


def extractor_mode() -> str:
    mode = (os.environ.get("IOF_MEMORY_EXTRACTOR") or "").strip().lower()
    if mode in ("", "iobot", "iobot"):
        return "iobot"
    if mode in ("stub", "off", "none", "0", "disabled"):
        return "stub" if mode == "stub" else "off"
    logger.warning("IOF_MEMORY_EXTRACTOR={!r} not recognised - extraction off "
                   "(valid: iobot, stub, off)", mode)
    return "off"


def _max_tokens() -> int:
    return int(os.environ.get("IOF_MEMORY_MAX_TOKENS", "1800"))


def provider_complete(system: str, user: str) -> str:
    """One-shot completion via the runtime's provider, no tools.

    RUNS ON THE SHARED WORKER LOOP, for the reason the learning distiller
    does. `_PROVIDER` is cached deliberately - a background call should not
    pay a TLS handshake every time - and this used `asyncio.run()`, which
    CREATES a loop and CLOSES it on the way out. The second call then reached
    into a connection pool whose sockets belonged to a dead loop, and closing
    one of those schedules `call_soon` on it:

        RuntimeError: Event loop is closed  ->  APIConnectionError

    which reads as an unreliable model and is nothing of the kind.

    THIS WAS THE THIRD COPY. The distiller and `recall_fts` were fixed a day
    earlier and this was missed, because it was a COPY of the same pattern -
    its own docstring said "exactly as the learning distiller does". A client
    hit the error again the next day on this path: memory consolidation runs
    immediately after a chat turn, which is why their log showed a 200 on
    /api/chat/general and then the failure.
    """
    global _PROVIDER
    import asyncio

    from ioagentfarm.engine.learning.distiller import _worker_loop

    if _PROVIDER is None:
        from iobot.config.loader import load_config
        from ioagentfarm.engine.provider_factory import make_provider
        _PROVIDER = make_provider(load_config())
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": user}]

    async def _call():
        return await _PROVIDER.chat(messages, max_tokens=_max_tokens(),
                                    temperature=0.2)

    resp = asyncio.run_coroutine_threadsafe(_call(), _worker_loop()).result(
        timeout=180)
    return getattr(resp, "content", "") or ""


_MARKED_LINE = re.compile(r"^\s*[-*]\s*\[(?:permanent|durable|ephemeral|correction|skip)\]", re.I)
_CANDIDATE_LINE = re.compile(r"^\s*(\d+)\.\s+\[")


def stub_complete(system: str, user: str) -> str:
    """Deterministic stand-in. See the module docstring."""
    if STAGE_CONSOLIDATE in system:
        ops = []
        for line in user.splitlines():
            m = _CANDIDATE_LINE.match(line)
            if m:
                ops.append(f"ADD {line.strip().split(' ', 1)[1]}")
        return "\n".join(ops) if ops else "(nothing)"
    lines = [l.strip() for l in user.splitlines() if _MARKED_LINE.match(l)]
    return "\n".join(lines) if lines else "(nothing)"


def get_completer() -> Optional[Completer]:
    mode = extractor_mode()
    if mode == "off":
        return None
    if mode == "stub":
        return stub_complete
    return provider_complete
