"""Stage (b): candidates → operations against the CURRENT active set.

Dream's discipline, applied to rows instead of files: the model is shown
what memory holds NOW (so it edits the real thing, not a remembered
version), asked for surgical operations (add / replace-in-place / drop /
retire), and its output is ground truth for nothing — every op is checked
against the ids that exist, every ADD passes the rails again, and "did
anything change" is read from the database, never from the model's
narrative. The claim (``workspace_memory_runs``) is finished with
``changed`` from the store's counts.

Without a model (``IOF_MEMORY_EXTRACTOR=stub`` or a completion failure)
the deterministic plan applies: exact-duplicate → drop, conflicting →
replace, else add. That plan is also what makes re-consolidating the same
run a no-op, which is what a pod crash mid-consolidation relies on.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from loguru import logger

from ioagentfarm.engine.memory import extract as _extract
from ioagentfarm.engine.memory import rails
from ioagentfarm.engine.memory.llm import STAGE_CONSOLIDATE, get_completer
from ioagentfarm.engine.memory.models import (
    MARKS, SCOPE_WORKSPACE, Candidate, MemoryFact, conflicts, fact_sig, sig_set,
)
from ioagentfarm.engine.memory.store import WorkspaceMemoryStore

CONSOLIDATE_SYSTEM = """You are the memory consolidation engine of a SHARED workspace memory used by several AI agents. You receive the memory's CURRENT ACTIVE ROWS (each with an id) and a numbered list of CANDIDATE facts extracted from a completed run. Decide, for each candidate, ONE operation, and optionally retire existing rows the candidates prove obsolete.

Operations (one per line, nothing else):
  ADD <n> [mark] [scope] fact          — the candidate is new: store it (you may tighten the wording; keep it atomic and MECE)
  REPLACE <id> <n> [mark] [scope] fact — the candidate corrects or updates existing row <id>: the new wording replaces it in place
  DROP <n> reason                      — duplicate of an existing row, restatement of another candidate, or not memory-worthy
  RETIRE <id> reason                   — an existing row is now false or obsolete according to the candidates (never a [permanent] row unless a candidate explicitly corrects it)

Rules:
- Atomic facts, one per line. Never merge two facts into one. Never invent a fact that is in neither list.
- A candidate that says the same thing as an active row in other words is a DROP, not an ADD.
- A candidate that changes the value of something an active row states is a REPLACE of that row.
- Keep the mark and scope of the candidate unless the existing row's is clearly better.
- Prefer fewer, sharper rows. Removing stale content matters as much as adding.
- Output only operation lines. If there is nothing to do, output: (nothing)
""" + STAGE_CONSOLIDATE + "\n"


@dataclass
class Op:
    kind: str                       # add | replace | drop | retire
    n: Optional[int] = None         # candidate number (1-based)
    target: Optional[int] = None    # existing row id
    candidate: Optional[Candidate] = None
    reason: str = ""


@dataclass
class ApplyResult:
    added: List[int] = field(default_factory=list)       # draft ids
    activated: List[int] = field(default_factory=list)   # active ids
    replaced: List[int] = field(default_factory=list)    # existing ids superseded/targeted
    retired: List[int] = field(default_factory=list)
    dropped: List[Dict[str, str]] = field(default_factory=list)
    duplicates: int = 0
    retire_proposed: List[int] = field(default_factory=list)

    @property
    def changed(self) -> bool:
        return bool(self.added or self.activated or self.replaced or self.retired)

    def to_dict(self) -> Dict[str, Any]:
        d = dict(self.__dict__)
        d["changed"] = self.changed
        return d


# ---------------------------------------------------------------------------
# rendering the consolidation prompt
# ---------------------------------------------------------------------------

def render_user(active: List[MemoryFact], candidates: List[Candidate]) -> str:
    lines = ["## Current active rows"]
    if active:
        for f in active:
            if f.kind != "fact":
                continue
            lines.append(f"#{f.id} [{f.mark}] [{f.scope}] {f.fact}")
    if len(lines) == 1:
        lines.append("(none)")
    lines.append("")
    lines.append("## Candidates")
    for i, c in enumerate(candidates, start=1):
        lines.append(f"{i}. [{c.mark}] [{c.scope}] {c.fact}")
    return "\n".join(lines)


_OP = re.compile(r"^\s*(ADD|REPLACE|DROP|RETIRE)\b\s*(.*)$", re.I)
_BRACKETED = re.compile(r"^\[(?P<mark>[a-z]+)\]\s*\[(?P<scope>[^\]]+)\]\s*(?P<fact>.+)$", re.I)


def _cand_from(text: str, fallback: Candidate, roles: List[str], user_id: str) -> Candidate:
    m = _BRACKETED.match(text.strip())
    if not m:
        return Candidate(fact=text.strip() or fallback.fact, mark=fallback.mark, scope=fallback.scope,
                         correction=fallback.correction)
    mark = m.group("mark").lower()
    if mark not in MARKS:
        mark = fallback.mark
    scope = _extract.parse_scope(m.group("scope"), roles=roles, user_id=user_id)
    return Candidate(fact=m.group("fact").strip(), mark=mark, scope=scope, correction=fallback.correction)


def parse_ops(text: str, candidates: List[Candidate], active: List[MemoryFact], *,
              roles: Optional[List[str]] = None, user_id: str = "") -> List[Op]:
    roles = roles or []
    ids = {f.id for f in active}
    ops: List[Op] = []
    handled: set = set()
    for line in (text or "").splitlines():
        m = _OP.match(line)
        if not m:
            continue
        kind, rest = m.group(1).upper(), m.group(2).strip()
        try:
            if kind == "ADD":
                n_s, body = rest.split(" ", 1) if " " in rest else (rest, "")
                n = int(n_s)
                if not (1 <= n <= len(candidates)) or n in handled:
                    continue
                handled.add(n)
                ops.append(Op("add", n=n, candidate=_cand_from(body, candidates[n - 1], roles, user_id)))
            elif kind == "REPLACE":
                id_s, n_s, body = (rest.split(" ", 2) + ["", ""])[:3]
                tid, n = int(id_s.lstrip("#")), int(n_s)
                if tid not in ids or not (1 <= n <= len(candidates)) or n in handled:
                    continue
                handled.add(n)
                ops.append(Op("replace", n=n, target=tid,
                              candidate=_cand_from(body, candidates[n - 1], roles, user_id)))
            elif kind == "DROP":
                n_s, reason = (rest.split(" ", 1) + [""])[:2]
                n = int(n_s)
                if not (1 <= n <= len(candidates)) or n in handled:
                    continue
                handled.add(n)
                ops.append(Op("drop", n=n, reason=reason.strip()))
            elif kind == "RETIRE":
                id_s, reason = (rest.split(" ", 1) + [""])[:2]
                tid = int(id_s.lstrip("#"))
                if tid not in ids:
                    continue
                ops.append(Op("retire", target=tid, reason=reason.strip()))
        except ValueError:
            continue
    # a candidate the model said nothing about is handled by the deterministic plan
    for i, c in enumerate(candidates, start=1):
        if i not in handled:
            ops.extend(plan_without_llm([c], active, offset=i - 1))
    return ops


def plan_without_llm(candidates: List[Candidate], active: List[MemoryFact], *,
                     offset: int = 0) -> List[Op]:
    """Deterministic: duplicate → drop, conflicting → replace, else add."""
    ops: List[Op] = []
    by_scope: Dict[str, List[MemoryFact]] = {}
    for f in active:
        if f.kind == "fact":
            by_scope.setdefault(f.scope, []).append(f)
    for i, c in enumerate(candidates, start=offset + 1):
        sig = fact_sig(c.fact)
        sset = sig_set(sig)
        same = next((f for f in by_scope.get(c.scope, []) if f.sig == sig), None)
        if same is not None:
            ops.append(Op("drop", n=i, reason=f"duplicate of #{same.id}"))
            continue
        clash = next((f for f in by_scope.get(c.scope, []) if conflicts(sset, sig_set(f.sig))), None)
        if clash is not None:
            ops.append(Op("replace", n=i, target=clash.id, candidate=c))
        else:
            ops.append(Op("add", n=i, candidate=c))
    return ops


# ---------------------------------------------------------------------------
# applying a plan
# ---------------------------------------------------------------------------

def apply_plan(store: WorkspaceMemoryStore, workspace_code: str, ops: List[Op], *,
               posture: str, actor: str, origin: str, source_ref: str,
               source_text: str = "", source_at: Optional[str] = None) -> ApplyResult:
    res = ApplyResult()
    status = "active" if posture == "auto" else "draft"
    for op in ops:
        if op.kind == "drop":
            res.dropped.append({"n": str(op.n), "reason": op.reason or "dropped"})
            continue
        if op.kind == "retire":
            if posture == "auto":
                if store.forget(workspace_code, op.target, actor=actor,
                                reason=f"retired by consolidation of {source_ref}: {op.reason}") == "removed":
                    res.retired.append(op.target)
            else:
                res.retire_proposed.append(op.target)
            continue
        cand = op.candidate
        if cand is None:
            continue
        # the rails run AGAIN on the model's rewording — a consolidator may
        # not smuggle a figure back in that extraction dropped
        gate = rails.apply(cand, source_text=source_text)
        if gate.dropped or gate.candidate is None:
            res.dropped.append({"n": str(op.n), "reason": gate.reason})
            continue
        cand = gate.candidate
        if op.kind == "replace":
            cand.evidence = (cand.evidence + "; " if cand.evidence else "") + f"replaces #{op.target}"
        row, outcome = store.add(workspace_code, cand, status=status, origin=origin,
                                 source_ref=source_ref, actor=actor, source_at=source_at)
        if outcome == "duplicate":
            res.duplicates += 1
            continue
        if outcome == "stale":
            # the recency rule: a newer source already states this
            res.dropped.append({"n": str(op.n), "reason": f"stale: #{row.id} carries a newer value"})
            continue
        if outcome == "activated":
            res.activated.append(row.id)
            if op.kind == "replace" and op.target not in res.replaced:
                # conflicts() normally superseded it inside add(); make the
                # replacement explicit when the wording moved too far apart
                target = store.get(workspace_code, op.target)
                if target is not None and target.status == "active":
                    store.forget(workspace_code, op.target, actor=actor,
                                 reason=f"replaced by #{row.id}")
                res.replaced.append(op.target)
        elif outcome == "added":
            res.added.append(row.id)
            if op.kind == "replace":
                res.replaced.append(op.target)
    return res


# ---------------------------------------------------------------------------
# the orchestration
# ---------------------------------------------------------------------------

def consolidate_candidates(store: WorkspaceMemoryStore, workspace_code: str,
                           candidates: List[Candidate], *, posture: str, actor: str,
                           origin: str, source_ref: str, source_text: str = "",
                           complete: Optional[Callable[[str, str], str]] = None,
                           roles: Optional[List[str]] = None, user_id: str = "",
                           source_at: Optional[str] = None) -> ApplyResult:
    if not candidates:
        return ApplyResult()
    scopes = sorted({c.scope for c in candidates} | {SCOPE_WORKSPACE})
    active = store.active(workspace_code, scopes)
    ops: List[Op]
    if complete is not None:
        try:
            raw = complete(CONSOLIDATE_SYSTEM, render_user(active, candidates))
            ops = parse_ops(raw, candidates, active, roles=roles, user_id=user_id)
        except Exception:  # noqa: BLE001
            logger.warning("memory: consolidation completion failed; deterministic plan", exc_info=True)
            ops = plan_without_llm(candidates, active)
    else:
        ops = plan_without_llm(candidates, active)
    return apply_plan(store, workspace_code, ops, posture=posture, actor=actor, origin=origin,
                      source_ref=source_ref, source_text=source_text, source_at=source_at)


def consolidate_run(store: WorkspaceMemoryStore, run_store, root: Path, workspace_code: str,
                    run_id: str, *, actor: str = "consolidator",
                    complete: Optional[Callable[[str, str], str]] = None,
                    worker: Optional[str] = None, force: bool = False) -> Dict[str, Any]:
    """Consolidate one completed run into workspace memory, exactly once
    across pods (the claim), idempotently (the plan). Returns a report."""
    report: Dict[str, Any] = {"run_id": run_id, "workspace": workspace_code,
                              "claimed": False, "changed": False}
    if not store.claim_run(workspace_code, run_id, worker=worker, force=force):
        claim = store.run_claim(workspace_code, run_id) or {}
        report["skipped"] = f"claim held by {claim.get('claimed_by')} ({claim.get('status')})"
        return report
    report["claimed"] = True
    try:
        completer = complete if complete is not None else get_completer()
        if completer is None:
            store.finish_run(workspace_code, run_id, changed=False, detail="extractor off", worker=worker)
            report["skipped"] = "extractor off"
            return report
        transcript, meta = _extract.run_substrate(run_store, root, run_id)
        report["meta"] = meta
        # the recency axis: WHEN the run happened, never when it was consolidated
        try:
            source_at = str(run_store.get_run(run_id).get("created_at") or "") or None
        except Exception:  # noqa: BLE001
            source_at = None
        if not transcript.strip() or meta.get("steps", 0) == 0:
            store.finish_run(workspace_code, run_id, changed=False, detail="no done steps", worker=worker)
            report["skipped"] = "no done steps"
            return report
        cands, dropped = _extract.extract(transcript, complete=completer,
                                          roles=meta.get("roles") or [], user_id=meta.get("user_id") or "")
        report["candidates"] = len(cands)
        report["dropped_at_extraction"] = dropped
        posture = store.posture(workspace_code)
        res = consolidate_candidates(store, workspace_code, cands, posture=posture, actor=actor,
                                     origin="run", source_ref=run_id, source_text=transcript,
                                     complete=completer, roles=meta.get("roles") or [],
                                     user_id=meta.get("user_id") or "", source_at=source_at)
        report["posture"] = posture
        report["result"] = res.to_dict()
        report["changed"] = res.changed
        store.finish_run(workspace_code, run_id, changed=res.changed,
                         detail=f"candidates={len(cands)} added={len(res.added)} "
                                f"activated={len(res.activated)} replaced={len(res.replaced)} "
                                f"retired={len(res.retired)} dropped={len(res.dropped)}",
                         worker=worker)
        return report
    except Exception as exc:  # noqa: BLE001
        logger.warning("memory: consolidation of run {} failed", run_id, exc_info=True)
        store.fail_run(workspace_code, run_id, detail=f"{type(exc).__name__}: {exc}", worker=worker)
        report["error"] = f"{type(exc).__name__}: {exc}"
        return report


def consolidate_chat(store: WorkspaceMemoryStore, workspace_code: str, *, role: str,
                     user_id: str, question: str, answer: str, actor: str = "consolidator",
                     complete: Optional[Callable[[str, str], str]] = None) -> Dict[str, Any]:
    completer = complete if complete is not None else get_completer()
    if completer is None:
        return {"skipped": "extractor off"}
    transcript = _extract.chat_substrate(role, user_id, question, answer)
    cands, dropped = _extract.extract(transcript, complete=completer, roles=[role], user_id=user_id)
    posture = store.posture(workspace_code)
    from datetime import datetime as _dt, timezone as _tz
    res = consolidate_candidates(store, workspace_code, cands, posture=posture, actor=actor,
                                 origin="chat", source_ref=f"chat:{role}:{user_id}",
                                 source_text=transcript, complete=completer, roles=[role],
                                 user_id=user_id, source_at=_dt.now(_tz.utc).isoformat())
    return {"candidates": len(cands), "dropped_at_extraction": dropped, "posture": posture,
            "result": res.to_dict(), "changed": res.changed}
