"""Stage (a): a transcript → candidate facts, marked and scoped.

The prompt is the agent runtime's own consolidation prompt
(``agent/consolidator_archive.md`` — the SNIP test, the retention marks),
rendered through its template loader so it stays byte-identical to upstream,
plus an addendum that adds the SCOPE bracket and the finding rule. Output
is one fact per line::

    - [mark] [scope] fact

The transcript is built STRATIFIED across steps — each step gets an equal
share of the character budget rather than the tail being truncated — because
a cap that keeps "the first N" deterministically drops whatever the run
produced last, which is usually the deliverable.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from loguru import logger

from ioagentfarm.engine.memory import rails
from ioagentfarm.engine.memory.llm import STAGE_EXTRACT
from ioagentfarm.engine.memory.models import (
    MARKS, SCOPE_WORKSPACE, Candidate, role_scope, solution_scope, user_scope,
)

# Fallback copy of the upstream prompt's substance, used only if the runtime
# template cannot be rendered (it always can in an engine venv; this keeps the
# extractor importable in a test that has no runtime on the path).
_FALLBACK_EXTRACT = """Extract key facts from this conversation. For each fact, annotate its memory attributes.

Only SNIP facts deserve a non-[skip] mark:
- Signal: would the user need to repeat this if forgotten?
- Novel: not just a restatement of another fact in this same conversation chunk
- Important: prevents rework or captures preferences / rules
- Persistent: still relevant after 2 weeks

Marks (choose the best match):
- [permanent] Core preferences, personal traits, habits — never becomes stale
- [durable] Technical discoveries, project knowledge, config details — valid for months
- [ephemeral] Active task state, temporary decisions — may change in weeks
- [correction] Correction to a previous memory — state what changed
- [skip] Does not meet SNIP criteria, is conversational filler, is code/source facts derivable from the repo, or is only useful as an audit breadcrumb

Output concise bullet points only. No preamble, no commentary.
If nothing noteworthy happened, output: (nothing)"""

_SCOPE_ADDENDUM = """
## Scope (required)
This memory is SHARED by every agent of a workspace, so each fact also carries a scope in a second bracket:
- [workspace] — facts about the environment, data, systems, project or organisation that every agent should know (schemas, conventions, what a dataset lacks, who owns what, deadlines, decisions).
- [role:<role>] — facts about how THIS agent's job is done here (the role name is given in the transcript header). Use only for role-specific practice, never for shared facts.
- [user:<id>] — facts about the person named in the transcript header (their preferences, identity, how they want things). Only when a user id is given.
Default to [workspace] when unsure.

## What is NOT memory — findings
A FINDING is any conclusion about ONE case, account, brand, product, scope, period or run: what happened, why it happened, what was identified, what should be done about it. A finding is [skip] whether or not it carries a number. Examples that are ALL [skip]:
- "Root cause is access, not messaging or price"
- "Remedy is contracting — remove the brand from the step edit"
- "Case under analysis: CASE-XYZ-Northeast"; "Scope SCOPE-Q1 covers 3 pairs"
- "24 denied claims were identified for review"; "brand X captured the volume brand Y lost"
- "pair DE has no evidence in this scope"; "share fell from 35.9% to 28.8%"
- the identity of the user running the analysis (it is already known to the platform)
CONTEXT is what stays true across cases and runs: how the data is organised and what it lacks, conventions and tools, systems and their quirks, owners and deadlines, decisions about how work is done here. Keep "the extract has no region column"; drop "region DE had no evidence". A fact about units or scale is context — state it WITHOUT quoting measured values ("NTS actuals and plan are in units, not thousands", never "actuals are 33.52"). Never restate the task, the goal or the deliverable; record only what would help the NEXT run in this workspace start further ahead.

## Output format (one per line, nothing else)
- [mark] [scope] fact
""" + "\n" + STAGE_EXTRACT + "\n"


def extract_system_prompt() -> str:
    base = None
    try:
        from iobot.utils.prompt_templates import render_template
        base = render_template("agent/consolidator_archive.md", strip=True)
    except Exception:  # noqa: BLE001 - no runtime on the path
        base = None
    return (base or _FALLBACK_EXTRACT) + "\n" + _SCOPE_ADDENDUM


# ---------------------------------------------------------------------------
# transcript building
# ---------------------------------------------------------------------------

def _cut(text: str, n: int) -> str:
    text = (text or "").strip()
    if len(text) <= n:
        return text
    head = int(n * 0.7)
    return text[:head].rstrip() + "\n…\n" + text[-(n - head):].lstrip()


def build_transcript(parts: List[Dict[str, Any]], *, budget: int = 14000,
                     header: str = "") -> str:
    """*parts*: ``[{"title": ..., "prompt": ..., "output": ...}, ...]``.
    Equal share per part; within a part, 30% prompt / 70% output."""
    parts = [p for p in parts if (p.get("prompt") or p.get("output"))]
    if not parts:
        return header.strip()
    share = max(600, budget // len(parts))
    chunks = [header.strip()] if header.strip() else []
    for p in parts:
        prompt = _cut(p.get("prompt") or "", int(share * 0.3))
        output = _cut(p.get("output") or "", int(share * 0.7))
        block = [f"### {p.get('title') or 'step'}"]
        if prompt:
            block.append(f"PROMPT:\n{prompt}")
        if output:
            block.append(f"OUTPUT:\n{output}")
        chunks.append("\n".join(block))
    return "\n\n".join(chunks)


def _latest_prompt(root: Path, run_id: str, step_key: str) -> str:
    """The step's rendered prompt from the newest forensic attempt, or ''."""
    base = root / "instances" / run_id / "forensics" / "attempts"
    if not base.is_dir():
        return ""
    best: Optional[Path] = None
    best_n = -1
    for d in base.iterdir():
        name = d.name
        if not name.startswith(step_key + "."):
            continue
        try:
            n = int(name.rsplit(".", 1)[1])
        except ValueError:
            continue
        if n > best_n and (d / "prompt.txt").is_file():
            best, best_n = d, n
    if best is None:
        return ""
    try:
        return (best / "prompt.txt").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def run_substrate(store, root: Path, run_id: str) -> Tuple[str, Dict[str, Any]]:
    """The transcript of a completed run: goal + every done step's prompt and
    output. Returns ``(transcript, meta)`` with meta carrying roles and the
    user for scope hints."""
    run = store.get_run(run_id)
    steps = store.list_steps(run_id)
    roles = sorted({str(s.get("role") or "") for s in steps if s.get("role")})
    parts = []
    for s in steps:
        if s.get("status") not in ("done",):
            continue
        key = str(s.get("step_key"))
        parts.append({
            "title": f"step {key} (role: {s.get('role') or '?'})",
            "prompt": _latest_prompt(Path(root), run_id, key),
            "output": s.get("output_text") or "",
        })
    header = (f"RUN {run_id} — workflow: {run.get('workflow_name')}\n"
              f"ROLES: {', '.join(roles) or '?'}\n"
              f"USER: {run.get('user_id') or '(none)'}\n"
              f"GOAL: {(run.get('goal') or '')[:600]}")
    return build_transcript(parts, header=header), {
        "roles": roles, "user_id": run.get("user_id") or "",
        "workflow": run.get("workflow_name") or "", "steps": len(parts),
    }


def chat_substrate(role: str, user_id: str, question: str, answer: str) -> str:
    header = f"CHAT — role: {role}\nUSER: {user_id or '(none)'}"
    return build_transcript([{"title": "turn", "prompt": question, "output": answer}],
                            header=header, budget=9000)


# ---------------------------------------------------------------------------
# parsing
# ---------------------------------------------------------------------------

_LINE = re.compile(r"^\s*[-*•]\s*\[(?P<mark>[a-z]+)\]\s*(?:\[(?P<scope>[^\]]+)\]\s*)?(?P<fact>.+?)\s*$", re.I)
_SCOPE_RE = re.compile(r"^(?:scope\s*=\s*)?(workspace|role|user|solution)(?:\s*[:=]\s*(.+))?$", re.I)


def parse_scope(raw: Optional[str], *, roles: List[str], user_id: str = "") -> str:
    if not raw:
        return SCOPE_WORKSPACE
    m = _SCOPE_RE.match(raw.strip())
    if not m:
        return SCOPE_WORKSPACE
    kind, name = m.group(1).lower(), (m.group(2) or "").strip()
    if kind == "workspace":
        return SCOPE_WORKSPACE
    if kind == "role":
        if name and name in roles:
            return role_scope(name)
        if len(roles) == 1:
            return role_scope(roles[0])
        return role_scope(name) if name else SCOPE_WORKSPACE
    if kind == "user":
        uid = name or user_id
        return user_scope(uid) if uid else SCOPE_WORKSPACE
    if kind == "solution":
        return solution_scope(name) if name else SCOPE_WORKSPACE
    return SCOPE_WORKSPACE


def parse_candidates(text: str, *, roles: Optional[List[str]] = None,
                     user_id: str = "") -> List[Candidate]:
    roles = roles or []
    out: List[Candidate] = []
    for line in (text or "").splitlines():
        m = _LINE.match(line)
        if not m:
            continue
        mark = m.group("mark").lower()
        if mark == "skip":
            continue
        correction = mark == "correction"
        if mark not in MARKS:
            mark = "durable"
        fact = re.sub(r"\s+", " ", m.group("fact")).strip().strip("\"'")
        if not fact:
            continue
        out.append(Candidate(fact=fact, mark=mark,
                             scope=parse_scope(m.group("scope"), roles=roles, user_id=user_id),
                             correction=correction))
    return out


# ---------------------------------------------------------------------------
# the stage
# ---------------------------------------------------------------------------

def extract(transcript: str, *, complete: Callable[[str, str], str],
            roles: Optional[List[str]] = None, user_id: str = "") -> Tuple[List[Candidate], List[Dict[str, str]]]:
    """Run the extraction prompt and the rails. Returns ``(survivors,
    dropped)`` where each dropped entry names the fact and the reason —
    the report a steward can read to see what the rails refused."""
    if not (transcript or "").strip():
        return [], []
    try:
        raw = complete(extract_system_prompt(), transcript)
    except Exception:  # noqa: BLE001
        logger.warning("memory: extraction completion failed", exc_info=True)
        return [], [{"fact": "", "reason": "extraction completion failed"}]
    cands = parse_candidates(raw, roles=roles, user_id=user_id)
    survivors: List[Candidate] = []
    dropped: List[Dict[str, str]] = []
    seen = set()
    for c in cands:
        outcome = rails.apply(c, source_text=transcript)
        if outcome.dropped or outcome.candidate is None:
            dropped.append({"fact": c.fact[:200], "reason": outcome.reason})
            continue
        key = (outcome.candidate.scope, outcome.candidate.fact.lower())
        if key in seen:
            continue
        seen.add(key)
        if outcome.notes:
            outcome.candidate.evidence = "; ".join(outcome.notes)
        survivors.append(outcome.candidate)
    return survivors, dropped
