"""Vocabulary and value types of workspace memory.

Everything here is deliberately small and dependency-free: the store, the
rails, the CLI and the runtime patch all import it, and the patch runs inside
every agent subprocess via the sitecustomize shim.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, Optional

#: Retention marks — Dream's vocabulary, kept verbatim so a reviewer who knows
#: one knows the other. ``correction`` is an INSTRUCTION to the consolidator
#: (replace in place), not a mark a stored row carries; it lands as ``durable``.
MARKS = ("permanent", "durable", "ephemeral")

#: Row states. A DRAFT is inert (never injected); ACTIVE is what agents see;
#: SUPERSEDED was replaced in place by a correction; REMOVED was forgotten or
#: expired; REJECTED was refused by a steward. Nothing is ever deleted — the
#: history is the audit.
STATUSES = ("draft", "active", "superseded", "removed", "rejected")

#: ``fact`` — an atomic extracted statement. ``doc`` — a curated pack-tier
#: file carried whole (its content is authored context, not a candidate).
KINDS = ("fact", "doc")

#: Where a row came from.
ORIGINS = ("pack", "workspace", "run", "chat", "manual")

#: Governance postures. ``review``: extraction produces drafts a steward
#: approves. ``auto``: extraction activates directly (still rails-scanned,
#: still audited, still revertible). The default is ``review`` — a memory row
#: is injected into agent context, which makes it an instruction to the
#: model whether it is labelled one or not.
POSTURES = ("review", "auto")
DEFAULT_POSTURE = "review"

SCOPE_WORKSPACE = "workspace"


def role_scope(role: str) -> str:
    return f"role:{role}"


def user_scope(user_id: str) -> str:
    return f"user:{user_id}"


def solution_scope(code: str) -> str:
    return f"solution:{code}"


def scope_label(scope: str) -> str:
    """The heading a scope renders under in the injected block."""
    if scope == SCOPE_WORKSPACE:
        return "Workspace (shared by every agent)"
    kind, _, name = scope.partition(":")
    return {"role": f"Role: {name}", "user": f"User: {name}",
            "solution": f"Solution: {name}"}.get(kind, scope)


# ---------------------------------------------------------------------------
# signatures — how two facts are judged the same, or in conflict
# ---------------------------------------------------------------------------

_STOP = frozenset("""
a an the and or of to in on at for by with from as is are was were be been
being it its this that these those there here has have had do does did not
no yes we our you your they their he she his her i my me us them
""".split())
_TOKEN_RE = re.compile(r"[a-z0-9][a-z0-9_.\-/]*")


def _tokens(text: str) -> FrozenSet[str]:
    toks = _TOKEN_RE.findall((text or "").lower())
    return frozenset(t.strip(".-/") for t in toks if t.strip(".-/") and t not in _STOP)


def fact_sig(text: str) -> str:
    """A stable, order-independent signature of a fact's content words.

    Stored as a space-joined sorted token list so the database can compare
    it with ``=`` (exact duplicate) and Python can read it back as a set
    (near-duplicate / correction detection via :func:`conflicts`).
    """
    return " ".join(sorted(_tokens(text)))


def sig_set(sig: str) -> FrozenSet[str]:
    return frozenset((sig or "").split())


def conflicts(a: FrozenSet[str], b: FrozenSet[str], *, threshold: float = 0.6) -> bool:
    """True when two facts are about the same thing closely enough that the
    newer must REPLACE the older (Dream's "[correction]: replace in place;
    never keep both versions").

    Jaccard over content tokens (>= 0.6), with a containment rule for short
    facts (three or more shared tokens covering 80% of the shorter one), so
    "the procurement hub lives in postgres schema savant_data_hub_v2" and
    "... schema savant_data_hub_v3" conflict — they share everything but the
    value — while "hub schema is X" and "fiscal year starts in April" do
    not. Two very short facts that differ only in their value (five content
    words, four shared) fall below both rules on purpose: with that little
    text the signatures cannot tell a correction from a sibling fact, and
    the consolidator's REPLACE op is what names the target explicitly.
    """
    if not a or not b:
        return False
    if a == b:
        return True
    inter = len(a & b)
    union = len(a | b)
    if union and inter / union >= threshold:
        return True
    small, large = (a, b) if len(a) <= len(b) else (b, a)
    return len(small) >= 3 and inter >= max(3, int(0.8 * len(small)))


# ---------------------------------------------------------------------------
# value types
# ---------------------------------------------------------------------------

@dataclass
class Candidate:
    """A fact proposed by extraction, before the rails and the store."""
    fact: str
    mark: str = "durable"
    scope: str = SCOPE_WORKSPACE
    correction: bool = False
    evidence: str = ""

    def normalized(self) -> "Candidate":
        mark = self.mark if self.mark in MARKS else "durable"
        scope = self.scope or SCOPE_WORKSPACE
        return Candidate(fact=" ".join((self.fact or "").split()), mark=mark,
                         scope=scope, correction=self.correction,
                         evidence=(self.evidence or "")[:400])


@dataclass
class MemoryFact:
    """One row of ``workspace_memory``."""
    id: int
    workspace_code: str
    scope: str
    kind: str
    fact: str
    mark: str
    status: str
    sig: str
    origin: str
    source_ref: str = ""
    evidence: str = ""
    decided_by: str = ""
    created_at: str = ""
    updated_at: str = ""
    expires_at: Optional[str] = None
    #: WHEN THE SOURCE HAPPENED — the run's ``created_at`` for a run fact,
    #: the turn's time for a chat fact, the moment of entry for a manual one.
    #: This is the recency axis for corrections: a candidate loses to an
    #: existing conflicting row whose source is newer, whatever order the
    #: backlog was consolidated in. ``created_at`` is when the ROW was
    #: written, which says nothing about which value is later.
    source_at: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "MemoryFact":
        known = {f for f in cls.__dataclass_fields__ if f != "extra"}
        data = {k: row.get(k) for k in known}
        data["id"] = int(row.get("id") or 0)
        for k in ("source_ref", "evidence", "decided_by", "created_at", "updated_at"):
            data[k] = data.get(k) or ""
        return cls(**data, extra={k: v for k, v in row.items() if k not in known})

    def to_dict(self) -> Dict[str, Any]:
        d = {k: getattr(self, k) for k in self.__dataclass_fields__ if k != "extra"}
        return d
