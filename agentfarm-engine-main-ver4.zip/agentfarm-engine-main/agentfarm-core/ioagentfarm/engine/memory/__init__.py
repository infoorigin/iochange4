"""Workspace memory — durable, governed CONTEXT shared by every agent of a workspace.

The gap this fills. Learning v2 captures METHOD (transferable technique) and
PREFERENCE, and drops FINDING (a conclusion from one run's data) in code. A
fourth kind had no home at all: CONTEXT — durable facts about the tenant's
world that are neither method nor finding and that an agent otherwise
re-discovers every run or is told in every prompt ("the hub schema is
``savant_data_hub_v2``", "this corpus carries no region column", "fiscal
year starts in April"). The agent runtime's own answer is a per-agent,
per-host ``memory/MEMORY.md`` consolidated by a "Dream" job — the wrong tier
for a workspace-scoped, database-backed, pod-rebuilt harness, and the very
channel learning v2 retired. What this package keeps from Dream is the
METHOD (SNIP filtering, consolidate against the embedded current state,
prune as deliberately as add, advance the cursor only on a real change);
what it replaces is the mechanism.

Three tiers, like every other kind of content:

* **Pack tier** — curated Markdown under ``solutions/<ws>/memory/`` (routed by
  path: ``workspace/``, ``role/<role>/``, ``user/<id>/``, ``solution/<code>/``)
  and the deployment's own ``<IOF_ROOT>/workspaces/<code>/memory/`` tree.
  Human-written, versioned, synced into the store by content hash.
* **Workspace tier** — the ``workspace_memory`` table in the engine database:
  extracted atomic facts, one row each, with a mark (permanent / durable /
  ephemeral), a status (draft / active / superseded / removed / rejected) and a
  provenance. Shared by every agent, pod and host of the workspace.
* **Session tier** — unchanged: the runtime's own in-session archive.

The pipeline: a completed run (or a chat turn) is EXTRACTED into candidate
facts (:mod:`extract`), every candidate passes the rails (:mod:`rails` —
finding-drop, PII redaction, the learning security scan), and the survivors
are CONSOLIDATED against the current active set (:mod:`consolidate`) into
drafts (posture ``review``) or active rows (posture ``auto``). Injection
(:mod:`inject`) renders the active set as one session-stable block in the
SYSTEM position — never the user turn.

Façade for the rest of the engine: :mod:`hooks`. CLI: ``aicore memory``.
"""
from __future__ import annotations

from ioagentfarm.engine.memory.models import (  # noqa: F401
    MARKS, STATUSES, KINDS, ORIGINS, POSTURES,
    SCOPE_WORKSPACE, role_scope, user_scope, solution_scope,
    MemoryFact, Candidate, fact_sig, conflicts,
)
from ioagentfarm.engine.memory.store import WorkspaceMemoryStore  # noqa: F401
