"""Seeding helpers shared by the test suite and the chaos harness.

A completed run is rows in ``runs`` + ``steps`` (and, optionally, a
forensic ``prompt.txt`` per step) — exactly what the extractor reads. The
stub extractor trusts lines already written as ``- [mark] [scope] fact``,
so a seeded output is also a way to state precisely which candidates a run
should yield, and which the rails must refuse.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Optional, Sequence, Tuple

StepSpec = Tuple[str, str, str]  # (step_key, role, output_text)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def seed_completed_run(store, *, workspace_code: str, steps: Sequence[StepSpec],
                       goal: str = "seeded run", user_id: str = "", root: Optional[Path] = None,
                       prompts: Optional[dict] = None, workflow_name: str = "seeded",
                       status: str = "done") -> str:
    """Create a run with the given steps already ``done`` (or *status*).
    Returns the run id. With *root*, writes each step's prompt into the
    forensic attempt directory the extractor reads."""
    ws_id = store.ensure_workspace(code=workspace_code, name=workspace_code)
    run_id = store.create_run(workflow_name=workflow_name, goal=goal, user_id=user_id,
                              workspace_id=ws_id)
    now = _now()
    with store._tx() as cur:  # noqa: SLF001 - fixtures write the raw rows
        for seq, (key, role, output) in enumerate(steps):
            cur.execute(
                store._q("INSERT INTO steps (run_id, seq, step_key, role, status, attempt, "
                         "max_attempts, deps_json, meta_json, output_text, created_at, updated_at) "
                         "VALUES (?, ?, ?, ?, ?, 1, 2, '[]', '{}', ?, ?, ?)"),
                (run_id, seq, key, role, status, output, now, now),
            )
        if status == "done":
            cur.execute(store._q("UPDATE runs SET status='done', updated_at=? WHERE id=?"),
                        (now, run_id))
    if root is not None and prompts:
        for key, prompt in prompts.items():
            d = Path(root) / "instances" / run_id / "forensics" / "attempts" / f"{key}.1"
            d.mkdir(parents=True, exist_ok=True)
            (d / "prompt.txt").write_text(prompt, encoding="utf-8")
    return run_id


def marked(lines: Iterable[Tuple[str, str, str]]) -> str:
    """Render ``(mark, scope, fact)`` triples as the bullet form the stub
    extractor trusts, e.g. ``marked([("durable", "workspace", "...")])``."""
    return "\n".join(f"- [{m}] [{s}] {f}" for m, s, f in lines)


def as_json(obj) -> str:
    return json.dumps(obj, indent=2, default=str)
