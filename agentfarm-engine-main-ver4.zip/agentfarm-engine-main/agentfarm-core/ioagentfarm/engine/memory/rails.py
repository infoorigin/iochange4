"""The rails every candidate passes before it can become memory.

Three, in order, all deterministic (no model is asked whether a fact is
safe — a model's judgement is a request, a regex is a rule):

1. **Finding-drop.** A conclusion computed from this session's data — a
   percentage, an amount, a ranking, a trend, or a figure quoted from the
   source — is a FINDING, and a finding stored as memory is the pollution
   learning v1 was retired for ("Caplyta 24.3%" anchoring every later run).
   The same rail learning v2's distiller applies to methods.
2. **PII redaction.** E-mail addresses, phone numbers, long identifiers and
   titled person names are masked in place (the Operational-Insights surface
   already masks names to initials; memory must not be the channel that
   leaks what the UI hides).
3. **Security scan.** ``skill_scan.scan_skill_md`` — the learning channel's
   scanner, shared code. A memory row is injected into agent context, so a
   dangerous body is a prompt-injection vector wearing a fact's label.
   ``dangerous`` drops the candidate; ``caution`` passes with the findings
   recorded.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from ioagentfarm.engine.memory.models import Candidate

# ---------------------------------------------------------------------------
# 1. finding-drop
# ---------------------------------------------------------------------------

_PERCENT = re.compile(r"\d+(?:[.,]\d+)?\s?%")
_CURRENCY = re.compile(r"(?:[$€£¥]\s?\d|\b\d+(?:[.,]\d+)?\s?(?:usd|eur|gbp|inr|million|billion|bn|mn|mm|k)\b)", re.I)
_TREND = re.compile(r"\b(?:increas|decreas|grew|grow|fell|declin|rose|drop|surg|jump|up by|down by|"
                    r"outperform|underperform|highest|lowest|largest|smallest|top\s?\d|bottom\s?\d|"
                    r"rank|vs\.?|versus|compared|share of|accounts? for|totall?ed|averag|median)\w*",
                    re.I)
_MEASURE = re.compile(r"\b(?:total|sum|count|average|mean|median|revenue|spend|sales|share|rate|"
                      r"volume|margin|cost|price|amount|budget|savings|units|orders|pos?\b|invoices?)\b",
                      re.I)
_NUMBER = re.compile(r"\b\d[\d,]*(?:\.\d+)?\b")
_YEARISH = re.compile(r"^(?:19|20)\d{2}$")
# Prose conclusions — a finding needs no figure to be one. These are the
# phrasings a diagnosis, a verdict or a case-bound statement is written in;
# measured on real extraction output (a brand-campaign run yielded "root
# cause is access", "remedy is contracting", "case under analysis: CASE-…",
# "24 denied claims were identified" — all past the numeric rails).
_CONCLUSION = re.compile(
    r"\b(?:root cause (?:is|was)|remedy (?:is|was)|(?:were|was|has been|have been) "
    r"(?:identified|detected|found|flagged)|under analysis|in this (?:scope|run|case|period|"
    r"analysis|session)|for (?:this|the current) (?:run|case|scope|period)|captured the "
    r"(?:volume|share)|lost (?:on|to)\b|(?:fell|rose|grew|dropped) from|has no evidence|"
    r"no inference can be made|the user running|(?:identified|flagged|selected) for "
    r"(?:review|appeal|follow-up|escalation|bridge)|\d+ \w+(?: \w+){0,3} (?:identified|flagged|"
    r"detected|found))\b", re.I)
# Case-bound identifiers: a fact naming one run, case or scope is about that
# one thing, not the workspace.
_CASE_ID = re.compile(r"\b(?:CASE|SCOPE|CARD|TICKET|INC)-[A-Z0-9][A-Z0-9-]{2,}\b|\brun_\d{8}_\d{6}\b")


def _figures(text: str) -> List[str]:
    """Numbers that read as measured figures: at least three significant
    digits or a decimal, and not a year. Ports, versions and years survive."""
    out = []
    for m in _NUMBER.finditer(text or ""):
        raw = m.group(0)
        digits = raw.replace(",", "").replace(".", "")
        if _YEARISH.match(raw):
            continue
        if "." in raw or len(digits) >= 4:
            out.append(raw)
    return out


def looks_like_finding(fact: str, source_text: str = "") -> Optional[str]:
    """The reason *fact* is a finding, or ``None`` when it is not.

    Hard signals: a percentage, a currency amount, a magnitude word after a
    number. Soft signal: a trend or comparison verb beside any number. The
    "session's own figures" rule: a measured figure that appears verbatim
    in the source transcript, beside a measure noun.
    """
    text = fact or ""
    if _PERCENT.search(text):
        return "percentage — an analytical result, not context"
    if _CURRENCY.search(text):
        return "monetary amount — an analytical result, not context"
    m = _CONCLUSION.search(text)
    if m:
        return f"conclusion phrasing ({m.group(0).lower()!r}) — about one case or run, not the workspace"
    m = _CASE_ID.search(text)
    if m:
        return f"names one case/scope/run ({m.group(0)}) — bound to it, not the workspace"
    has_digit = bool(re.search(r"\d", text))
    if has_digit and _TREND.search(text):
        return "trend/ranking with a number — a conclusion from this session's data"
    figs = _figures(text)
    if figs and _MEASURE.search(text):
        src = source_text or ""
        if any(f in src for f in figs) or not src:
            return "quotes a figure measured in this session beside a measure noun"
    return None


# ---------------------------------------------------------------------------
# 2. PII redaction
# ---------------------------------------------------------------------------

_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE = re.compile(r"(?<!\w)(?:\+?\d{1,3}[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)\d{3}[\s.-]?\d{4}(?!\w)")
_SSN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_LONG_ID = re.compile(r"\b\d{9,}\b")
_TITLED_NAME = re.compile(r"\b(Dr|Mr|Mrs|Ms|Prof|Sir|Dame)\.?\s+([A-Z][a-z]+)(?:\s+([A-Z][a-z]+))+")


def _initials(m: re.Match) -> str:
    title = m.group(1)
    words = m.group(0).split()[1:]
    return f"{title}. " + " ".join(f"{w[0]}." for w in words)


# PHI - protected health information, OPT-IN (``redact(text, phi=True)``).
# Off by default because every existing caller is the memory rail, whose
# corpus is business context; the chat guardrails switch it on for a
# deployment whose ``guardrails.yaml`` says ``phi: true``. Each pattern is
# LABELLED (``MRN 12345``, ``NPI 1234567890``, ``DOB 01/02/1980``) or has a
# shape nothing else has (an ICD-10 code with its dot): a bare number is not
# evidence of health information, and a rule that masked every ten-digit
# figure would also mask an order count. They run BEFORE the phone and
# long-id rules so a labelled identifier is reported under its own name
# rather than swallowed as ``[phone]`` or ``[id]``.
_MRN = re.compile(r"\b(?:MRN|medical\s+record\s+(?:no|number|#)?)\s*[:#-]?\s*\d{5,}\b", re.I)
_NPI = re.compile(r"\bNPI\s*[:#-]?\s*\d{10}\b", re.I)
_ICD10 = re.compile(r"\b(?:ICD(?:-?10)?(?:-CM)?\s*[:#-]?\s*)?[A-TV-Z]\d{2}\.\d{1,4}\b")
_DOB = re.compile(
    r"\b(?:DOB|D\.O\.B\.|date\s+of\s+birth|born\s+on)\s*[:#-]?\s*"
    r"(?:\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}|\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})",
    re.I)
_PHI = (("mrn", _MRN, "[mrn]"), ("npi", _NPI, "[npi]"),
        ("icd10", _ICD10, "[icd10]"), ("dob", _DOB, "[dob]"))


def redact(text: str, *, phi: bool = False) -> Tuple[str, List[str]]:
    """Mask personal identifiers in place. Returns ``(text, kinds_masked)``.

    ``phi=True`` adds the protected-health-information set (MRN, NPI, ICD-10,
    date of birth). The default is unchanged for every existing caller.
    """
    kinds: List[str] = []
    out = text or ""
    if _EMAIL.search(out):
        out = _EMAIL.sub("[email]", out)
        kinds.append("email")
    if _SSN.search(out):
        out = _SSN.sub("[id]", out)
        kinds.append("ssn")
    if phi:
        for kind, rx, mask in _PHI:
            if rx.search(out):
                out = rx.sub(mask, out)
                kinds.append(kind)
    if _PHONE.search(out):
        out = _PHONE.sub("[phone]", out)
        kinds.append("phone")
    if _LONG_ID.search(out):
        out = _LONG_ID.sub("[id]", out)
        kinds.append("id")
    if _TITLED_NAME.search(out):
        out = _TITLED_NAME.sub(_initials, out)
        kinds.append("person")
    return out, kinds


# ---------------------------------------------------------------------------
# 3. security scan (shared with the learning channel)
# ---------------------------------------------------------------------------

def scan(text: str):
    from ioagentfarm.engine.learning.skill_scan import scan_skill_md
    return scan_skill_md(text or "")


# ---------------------------------------------------------------------------
# the gate
# ---------------------------------------------------------------------------

@dataclass
class RailOutcome:
    candidate: Optional[Candidate]
    dropped: bool
    reason: str = ""
    notes: List[str] = field(default_factory=list)


def apply(cand: Candidate, *, source_text: str = "", min_chars: int = 12,
          max_chars: int = 600) -> RailOutcome:
    """Run the three rails over one candidate. A dropped candidate carries
    the reason; a passed one may carry notes (what was redacted, a caution
    finding) for the history record."""
    c = cand.normalized()
    if len(c.fact) < min_chars:
        return RailOutcome(None, True, "too short to be a fact")
    if len(c.fact) > max_chars:
        c.fact = c.fact[:max_chars].rsplit(" ", 1)[0] + " …"
    why = looks_like_finding(c.fact, source_text)
    if why:
        return RailOutcome(None, True, f"finding: {why}")
    notes: List[str] = []
    redacted, kinds = redact(c.fact)
    if kinds:
        c.fact = redacted
        notes.append("redacted: " + ", ".join(kinds))
    result = scan(c.fact)
    if result.blocked:
        cats = ", ".join(f.category for f in result.findings if f.severity == "dangerous")
        return RailOutcome(None, True, f"security scan DANGEROUS ({cats})")
    if result.verdict == "caution":
        notes.append("scan: caution — " + ", ".join(f.category for f in result.findings))
    return RailOutcome(c, False, "", notes)
