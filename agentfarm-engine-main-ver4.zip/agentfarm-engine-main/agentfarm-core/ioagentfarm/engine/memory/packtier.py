"""The curated tiers: Markdown files a person wrote, synced by content hash.

Two roots, same layout, routed by path:

* **Pack tier** — ``Pack.memory`` (``solutions/<ws>/memory/`` in a flat
  workspace repo), shipped in the wheel like agents and skills.
* **Workspace tier** — ``~/.iobot/workspaces/<code>/memory/``, beside the
  workspace's ``mcp.yaml`` and ``deliveries.yaml``: what THIS deployment
  knows that the repo does not (a host name, a schema, a contact).

Routing::

    memory/<anything>.md              -> workspace
    memory/workspace/**.md            -> workspace
    memory/solution/<code>/**.md      -> solution:<code>
    memory/role/<role>/**.md          -> role:<role>
    memory/user/<id>/**.md            -> user:<id>

A file is carried WHOLE as a ``doc`` row (its content is authored context,
not a candidate — the rails do not apply; the security scan does). The sync
is "rewrite what it finds, retire what it does not": edit a file and the row
is superseded and re-added; delete it and the row is removed. Nothing is
extracted from a curated file and nothing extracted is ever written back
into one — promotion of an extracted fact into the repo is a person's
``aicore memory show`` and a commit.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple

from loguru import logger

from ioagentfarm.engine.memory.models import (
    SCOPE_WORKSPACE, role_scope, solution_scope, user_scope,
)
from ioagentfarm.engine.memory.store import WorkspaceMemoryStore

Doc = Tuple[str, str, str]  # (scope, relative path, content)

_ROUTES = {"role": role_scope, "user": user_scope, "solution": solution_scope}


#: The core pack's workspace code. Core-shipped memory is platform-wide and
#: reaches every workspace; everything else is scoped to the one it declares.
_CORE_WORKSPACE = "core"


def route(rel_parts: List[str]) -> Optional[str]:
    """Scope for a file at ``memory/<parts...>``; None to skip (a bare
    ``role/`` directory with no role name, a non-Markdown file)."""
    if not rel_parts or not rel_parts[-1].lower().endswith(".md"):
        return None
    head = rel_parts[0].lower()
    if len(rel_parts) == 1 or head == "workspace":
        return SCOPE_WORKSPACE
    if head in _ROUTES:
        if len(rel_parts) < 3:
            return None
        return _ROUTES[head](rel_parts[1])
    return SCOPE_WORKSPACE


def _walk(root: Any, rel: List[str]) -> Iterator[Tuple[List[str], Any]]:
    try:
        entries = sorted(root.iterdir(), key=lambda e: e.name)
    except Exception:  # noqa: BLE001 - not a directory, or unreadable
        return
    for entry in entries:
        name = entry.name
        if name.startswith(".") or name.startswith("_"):
            continue
        if entry.is_dir():
            yield from _walk(entry, rel + [name])
        elif entry.is_file():
            yield rel + [name], entry


def docs_under(root: Any) -> List[Doc]:
    """Every routed Markdown file under *root* (a ``Path`` or a package
    ``Traversable``)."""
    out: List[Doc] = []
    if root is None:
        return out
    for parts, entry in _walk(root, []):
        scope = route(parts)
        if scope is None:
            continue
        try:
            content = entry.read_text(encoding="utf-8")
        except Exception:  # noqa: BLE001
            logger.debug("memory: unreadable curated file {}", "/".join(parts), exc_info=True)
            continue
        if content.strip():
            out.append((scope, "/".join(parts), content))
    return out


def workspace_memory_dir(code: str) -> Path:
    from ioagentfarm.engine.workspace_env import workspace_home
    return workspace_home(code) / "memory"


def pack_docs(registry=None, workspace_code: Optional[str] = None) -> List[Doc]:
    """Curated memory from the packs that belong to THIS workspace.

    The workspace filter is what separates this from every other pack
    dimension, and it is not optional. An agent or a skill contributed by
    another workspace's pack is merely AVAILABLE - nothing resolves it unless
    something names it, so a permissive registry costs nothing. Workspace
    memory is APPLIED: every row is injected into every agent's system
    prompt, unconditionally. Iterating the whole registry therefore put one
    tenant's conventions into another tenant's prompts as instructions -
    observed on a fresh workspace whose agents were told to query a database
    that belongs to a different deployment and does not exist here.

    A pack that declares no workspace, and the core pack, are platform-wide
    and always included; everything else must match by code.
    """
    if registry is None:
        from ioagentfarm.packs import load_registry
        registry = load_registry()
    out: List[Doc] = []
    for pack in registry.packs:
        if pack.memory is None:
            continue
        owner = pack.workspace
        if workspace_code and owner and owner not in (workspace_code, _CORE_WORKSPACE):
            logger.debug(
                "workspace memory: pack {} belongs to workspace {}, not {} - skipped",
                pack.pack, owner, workspace_code)
            continue
        out.extend(docs_under(pack.memory))
    return out


def workspace_docs(code: str) -> List[Doc]:
    d = workspace_memory_dir(code)
    return docs_under(d) if d.is_dir() else []


def _scanned(docs: Iterable[Doc]) -> List[Doc]:
    """The security scan applies to curated content too — a DANGEROUS file
    is refused with a warning, never carried."""
    from ioagentfarm.engine.learning.skill_scan import scan_skill_md
    kept: List[Doc] = []
    for scope, path, content in docs:
        result = scan_skill_md(content)
        if result.blocked:
            logger.warning("memory: curated file {} refused by the security scan ({})", path,
                           ", ".join(f.category for f in result.findings if f.severity == "dangerous"))
            continue
        kept.append((scope, path, content))
    return kept


def sync_curated(store: WorkspaceMemoryStore, workspace_code: str, *, registry=None,
                 actor: str = "sync") -> Dict[str, Dict[str, int]]:
    """Reconcile both curated tiers into the store. Returns per-tier counts."""
    return {
        "pack": store.sync_docs(workspace_code,
                                _scanned(pack_docs(registry, workspace_code)),
                                origin="pack", actor=actor),
        "workspace": store.sync_docs(workspace_code, _scanned(workspace_docs(workspace_code)),
                                     origin="workspace", actor=actor),
    }


def content_hash(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()[:24]
