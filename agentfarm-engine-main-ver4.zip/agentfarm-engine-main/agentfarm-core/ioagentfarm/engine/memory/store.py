"""``WorkspaceMemoryStore`` — the workspace tier, in the engine database.

Four tables, all keyed by ``workspace_code`` so one database serves every
tenant and every pod:

* ``workspace_memory``          — one row per fact or curated doc.
* ``workspace_memory_history``  — append-only audit: every state change,
  who/what caused it, when. The record a steward reads and a chaos run
  verifies against.
* ``workspace_memory_runs``     — the CLAIM table. A completed run is
  consolidated by whichever pod inserts its row first (``INSERT … OR
  IGNORE`` / ``ON CONFLICT DO NOTHING``); a claim whose worker died is
  re-claimable after a stale window. This is Dream's "cursor advances only
  on a real change" generalised to several pods: a run is consolidated at
  least once, its effect is idempotent, and nothing is lost when the pod
  that claimed it is killed mid-way.
* ``workspace_memory_settings`` — the workspace's posture.

Invariants the schema enforces rather than the code hoping for them:

* AT MOST ONE ACTIVE ROW PER ``(workspace, scope, sig)`` — a partial unique
  index. Two pods activating the same fact concurrently cannot both win;
  the loser reads the winner's row.
* Every DDL statement runs inside a SAVEPOINT (``_guarded``), because on
  PostgreSQL one failed statement aborts the transaction and every later
  one raises ``InFailedSqlTransaction`` — the lesson the case and play
  stores paid for on their first real command.
* Rows are read BY NAME, never by position (``RealDictCursor`` on Postgres).
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import socket
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from ioagentfarm.engine.db import DbAdapter
from ioagentfarm.engine.memory.models import (
    DEFAULT_POSTURE, KINDS, MARKS, POSTURES, SCOPE_WORKSPACE, STATUSES,
    Candidate, MemoryFact, conflicts, fact_sig, sig_set,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# SQL — every statement lives here, as a constant
# ---------------------------------------------------------------------------

SQL_CREATE_MEMORY = """CREATE TABLE IF NOT EXISTS workspace_memory (
    id {auto_id},
    workspace_code TEXT NOT NULL,
    scope TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'fact',
    fact TEXT NOT NULL,
    mark TEXT NOT NULL DEFAULT 'durable',
    status TEXT NOT NULL DEFAULT 'draft',
    sig TEXT NOT NULL,
    origin TEXT NOT NULL DEFAULT 'run',
    source_ref TEXT NOT NULL DEFAULT '',
    evidence TEXT NOT NULL DEFAULT '',
    decided_by TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    expires_at TEXT,
    source_at TEXT
)"""
# Additive, for a database created before `source_at` existed (guarded).
SQL_ADD_MEMORY_SOURCE_AT = "ALTER TABLE workspace_memory ADD COLUMN source_at TEXT"
SQL_INDEX_MEMORY_LOOKUP = ("CREATE INDEX IF NOT EXISTS idx_ws_memory_lookup "
                           "ON workspace_memory(workspace_code, scope, status)")
# The invariant: one ACTIVE row per (workspace, scope, sig). Partial unique
# indexes exist on both SQLite (3.8+) and PostgreSQL. Guarded, because a
# database that already holds duplicates from before this index refuses it —
# and then the code path below (select-before-insert inside the writer lock)
# still dedupes; the index is the belt, the check the braces.
SQL_INDEX_MEMORY_ACTIVE = ("CREATE UNIQUE INDEX IF NOT EXISTS uq_ws_memory_active "
                           "ON workspace_memory(workspace_code, scope, sig) "
                           "WHERE status = 'active'")
SQL_CREATE_HISTORY = """CREATE TABLE IF NOT EXISTS workspace_memory_history (
    id {auto_id},
    workspace_code TEXT NOT NULL,
    memory_id INTEGER,
    event TEXT NOT NULL,
    actor TEXT NOT NULL DEFAULT '',
    detail TEXT NOT NULL DEFAULT '',
    at TEXT NOT NULL
)"""
SQL_INDEX_HISTORY = ("CREATE INDEX IF NOT EXISTS idx_ws_memory_history "
                     "ON workspace_memory_history(workspace_code, at)")
SQL_CREATE_RUNS = """CREATE TABLE IF NOT EXISTS workspace_memory_runs (
    workspace_code TEXT NOT NULL,
    run_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'claimed',
    claimed_by TEXT NOT NULL DEFAULT '',
    claimed_at TEXT NOT NULL,
    done_at TEXT,
    changed INTEGER NOT NULL DEFAULT 0,
    attempts INTEGER NOT NULL DEFAULT 1,
    detail TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (workspace_code, run_id)
)"""
# Additive, for a database created before `attempts` existed (guarded: the
# statement fails harmlessly where the column is already there).
SQL_ADD_RUNS_ATTEMPTS = ("ALTER TABLE workspace_memory_runs ADD COLUMN attempts INTEGER "
                         "NOT NULL DEFAULT 1")
SQL_CREATE_SETTINGS = """CREATE TABLE IF NOT EXISTS workspace_memory_settings (
    workspace_code TEXT NOT NULL PRIMARY KEY,
    posture TEXT NOT NULL DEFAULT 'review',
    updated_at TEXT NOT NULL
)"""

SQL_INSERT_MEMORY = ("INSERT INTO workspace_memory (workspace_code, scope, kind, fact, mark, "
                     "status, sig, origin, source_ref, evidence, decided_by, created_at, "
                     "updated_at, expires_at, source_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
SQL_SELECT_BY_ID = "SELECT * FROM workspace_memory WHERE workspace_code=? AND id=?"
SQL_SELECT_STATUS_SCOPE = ("SELECT * FROM workspace_memory WHERE workspace_code=? AND scope=? "
                           "AND status=?")
SQL_SELECT_ACTIVE_SCOPES = ("SELECT * FROM workspace_memory WHERE workspace_code=? AND status='active' "
                            "AND scope IN ({scopes}) ORDER BY scope, kind DESC, created_at, id")
SQL_SELECT_STATUS = ("SELECT * FROM workspace_memory WHERE workspace_code=? AND status=? "
                     "ORDER BY created_at, id")
SQL_SELECT_ALL = "SELECT * FROM workspace_memory WHERE workspace_code=? ORDER BY id"
SQL_UPDATE_STATUS = ("UPDATE workspace_memory SET status=?, decided_by=?, updated_at=? "
                     "WHERE workspace_code=? AND id=?")
SQL_UPDATE_STATUS_IF = ("UPDATE workspace_memory SET status=?, decided_by=?, updated_at=? "
                        "WHERE workspace_code=? AND id=? AND status=?")
SQL_TOUCH = "UPDATE workspace_memory SET updated_at=? WHERE workspace_code=? AND id=?"
SQL_VERSION = ("SELECT COUNT(*) AS n, MAX(updated_at) AS m, MAX(id) AS x FROM workspace_memory "
               "WHERE workspace_code=? AND status='active'")
SQL_EXPIRE = ("UPDATE workspace_memory SET status='removed', decided_by='expiry', updated_at=? "
              "WHERE workspace_code=? AND status='active' AND expires_at IS NOT NULL "
              "AND expires_at < ?")
SQL_SELECT_EXPIRED = ("SELECT id FROM workspace_memory WHERE workspace_code=? AND status='active' "
                      "AND expires_at IS NOT NULL AND expires_at < ?")
SQL_SELECT_DOCS = ("SELECT * FROM workspace_memory WHERE workspace_code=? AND kind='doc' "
                   "AND status='active'")

SQL_INSERT_HISTORY = ("INSERT INTO workspace_memory_history (workspace_code, memory_id, event, "
                      "actor, detail, at) VALUES (?, ?, ?, ?, ?, ?)")
SQL_SELECT_HISTORY = ("SELECT * FROM workspace_memory_history WHERE workspace_code=? "
                      "ORDER BY id DESC LIMIT ?")
SQL_SELECT_HISTORY_FOR = ("SELECT * FROM workspace_memory_history WHERE workspace_code=? "
                          "AND memory_id=? ORDER BY id")

SQL_CLAIM_RUN = ("INSERT INTO workspace_memory_runs (workspace_code, run_id, status, claimed_by, "
                 "claimed_at, done_at, changed, attempts, detail) "
                 "VALUES (?, ?, 'claimed', ?, ?, NULL, 0, 1, '')")
SQL_SELECT_RUN_CLAIM = "SELECT * FROM workspace_memory_runs WHERE workspace_code=? AND run_id=?"
# Take over a claim whose worker is gone: a `claimed` row older than the
# stale window (the worker died), or a `failed` row under the attempt cap
# (the worker raised — retried, bounded). Either way attempts advances.
SQL_RECLAIM = ("UPDATE workspace_memory_runs SET claimed_by=?, claimed_at=?, status='claimed', "
               "done_at=NULL, attempts=attempts+1, detail=? WHERE workspace_code=? AND run_id=? "
               "AND ((status='claimed' AND claimed_at < ?) OR (status='failed' AND attempts < ?))")
SQL_FORCE_CLAIM = ("UPDATE workspace_memory_runs SET claimed_by=?, claimed_at=?, status='claimed', "
                   "done_at=NULL, attempts=attempts+1, detail=? WHERE workspace_code=? AND run_id=?")
# `detail` is APPENDED, never overwritten: a takeover note ("reclaimed from
# <worker>") must survive the completion that follows it — it is the only
# record that a crash happened and who finished the work.
SQL_FINISH_RUN = ("UPDATE workspace_memory_runs SET status='done', done_at=?, changed=?, "
                  "detail=CASE WHEN detail='' THEN ? ELSE detail || '; ' || ? END "
                  "WHERE workspace_code=? AND run_id=? AND claimed_by=?")
SQL_FAIL_RUN = ("UPDATE workspace_memory_runs SET status='failed', done_at=?, "
                "detail=CASE WHEN detail='' THEN ? ELSE detail || '; ' || ? END "
                "WHERE workspace_code=? AND run_id=? AND claimed_by=?")
SQL_RELEASE_RUN = ("DELETE FROM workspace_memory_runs WHERE workspace_code=? AND run_id=? "
                   "AND claimed_by=? AND status='claimed'")
SQL_SELECT_RUN_CLAIMS = ("SELECT * FROM workspace_memory_runs WHERE workspace_code=? "
                         "ORDER BY claimed_at")
SQL_SELECT_STALE_CLAIMS = ("SELECT * FROM workspace_memory_runs WHERE workspace_code=? "
                           "AND status='claimed' AND claimed_at < ?")

SQL_SELECT_POSTURE = "SELECT posture FROM workspace_memory_settings WHERE workspace_code=?"
SQL_UPSERT_POSTURE_INSERT = ("INSERT INTO workspace_memory_settings (workspace_code, posture, "
                             "updated_at) VALUES (?, ?, ?)")
SQL_UPSERT_POSTURE_UPDATE = ("UPDATE workspace_memory_settings SET posture=?, updated_at=? "
                             "WHERE workspace_code=?")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _guarded(cur, sql: str, params: Sequence[Any] = ()) -> bool:
    """One statement that may legitimately fail, confined to a SAVEPOINT so a
    failure cannot poison the enclosing transaction on PostgreSQL. SQLite
    honours the same syntax, so one code path serves both."""
    cur.execute("SAVEPOINT ws_memory_guard")
    try:
        cur.execute(sql, params)
        cur.execute("RELEASE SAVEPOINT ws_memory_guard")
        return True
    except Exception:  # noqa: BLE001 - the statement was optional
        cur.execute("ROLLBACK TO SAVEPOINT ws_memory_guard")
        cur.execute("RELEASE SAVEPOINT ws_memory_guard")
        return False


def worker_identity() -> str:
    """Who holds a claim: ``<host>:<pid>``. Distinct per pod AND per process,
    so a restarted worker on the same host never mistakes a dead sibling's
    claim for its own."""
    return f"{socket.gethostname()}:{os.getpid()}"


_ENSURED: set = set()


def reset_schema_memo() -> None:
    """Tests that point one process at several databases."""
    _ENSURED.clear()


class WorkspaceMemoryStore:
    """The workspace-memory tables over a :class:`DbAdapter`."""

    #: A claim older than this with no completion is assumed to belong to a
    #: worker that died; another sweep may take it over.
    STALE_CLAIM_S = int(os.environ.get("IOF_MEMORY_STALE_CLAIM_S", "600"))
    #: A FAILED consolidation is retried by later sweeps up to this many
    #: attempts in total; past it the run stays `failed` for a person
    #: (`aicore memory consolidate --run <id> --force`).
    MAX_ATTEMPTS = int(os.environ.get("IOF_MEMORY_MAX_ATTEMPTS", "3"))

    def __init__(self, adapter: DbAdapter) -> None:
        self._db = adapter
        self._is_pg = adapter.placeholder() == "%s"

    # -- connection helpers (mirror DbPreferenceStore) -----------------------
    @contextmanager
    def _tx(self):
        with self._db.connect() as con:
            self._db.init_connection(con)
            if not self._is_pg:
                # Several pods on one SQLite file: wait for the writer rather
                # than fail on the first contention. WAL is set by
                # init_connection; this is the busy handler beside it.
                try:
                    con.execute("PRAGMA busy_timeout=15000;")
                except Exception:  # noqa: BLE001
                    pass
            cur = con.cursor()
            try:
                yield cur
            finally:
                cur.close()

    @contextmanager
    def _write_tx(self):
        """A WRITER transaction. SQLite: ``BEGIN IMMEDIATE`` takes the write
        lock up front so two pods' select-then-insert cannot interleave.
        PostgreSQL: a transaction-scoped advisory lock keyed on the table name
        serialises writers the same way (row locks alone would not cover the
        select-before-insert)."""
        with self._db.connect() as con:
            self._db.init_connection(con)
            if self._is_pg:
                cur = con.cursor()
                try:
                    cur.execute("SELECT pg_advisory_xact_lock(hashtext('workspace_memory'))")
                    yield cur
                    con.commit()
                except Exception:
                    con.rollback()
                    raise
                finally:
                    cur.close()
            else:
                try:
                    con.execute("PRAGMA busy_timeout=15000;")
                except Exception:  # noqa: BLE001
                    pass
                self._db.begin_immediate(con)
                cur = con.cursor()
                try:
                    yield cur
                    con.execute("COMMIT;")
                except Exception:
                    try:
                        con.execute("ROLLBACK;")
                    except Exception:  # noqa: BLE001
                        pass
                    raise
                finally:
                    cur.close()
                    self._db.end_immediate(con)

    def _q(self, sql: str) -> str:
        ph = self._db.placeholder()
        return sql if ph == "?" else sql.replace("?", ph)

    @staticmethod
    def _one(cur) -> Optional[Dict[str, Any]]:
        row = cur.fetchone()
        return dict(row) if row is not None else None

    @staticmethod
    def _rows(cur) -> List[Dict[str, Any]]:
        return [dict(r) for r in cur.fetchall()]

    # -- schema --------------------------------------------------------------
    def init(self) -> None:
        key = id(self._db)
        if key in _ENSURED:
            return
        auto_id = self._db.auto_id()
        with self._tx() as cur:
            for ddl in (
                SQL_CREATE_MEMORY.format(auto_id=auto_id),
                SQL_ADD_MEMORY_SOURCE_AT,
                SQL_INDEX_MEMORY_LOOKUP,
                SQL_INDEX_MEMORY_ACTIVE,
                SQL_CREATE_HISTORY.format(auto_id=auto_id),
                SQL_INDEX_HISTORY,
                SQL_CREATE_RUNS,
                SQL_ADD_RUNS_ATTEMPTS,
                SQL_CREATE_SETTINGS,
            ):
                _guarded(cur, ddl)
        _ENSURED.add(key)

    # -- posture -------------------------------------------------------------
    def posture(self, workspace_code: str) -> str:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_POSTURE), (workspace_code,))
            row = self._one(cur)
        if row and row.get("posture") in POSTURES:
            return str(row["posture"])
        env = (os.environ.get("IOF_MEMORY_POSTURE") or "").strip().lower()
        return env if env in POSTURES else DEFAULT_POSTURE

    def set_posture(self, workspace_code: str, posture: str, *, actor: str = "") -> str:
        if posture not in POSTURES:
            raise ValueError(f"posture must be one of {', '.join(POSTURES)}; got {posture!r}")
        now = _utc_now()
        with self._write_tx() as cur:
            cur.execute(self._q(SQL_UPSERT_POSTURE_UPDATE), (posture, now, workspace_code))
            if cur.rowcount == 0:
                cur.execute(self._q(SQL_UPSERT_POSTURE_INSERT), (workspace_code, posture, now))
            self._history(cur, workspace_code, None, "posture", actor, posture, now)
        return posture

    # -- history -------------------------------------------------------------
    def _history(self, cur, workspace_code: str, memory_id: Optional[int], event: str,
                 actor: str, detail: str, now: Optional[str] = None) -> None:
        cur.execute(self._q(SQL_INSERT_HISTORY),
                    (workspace_code, memory_id, event, actor or "", (detail or "")[:2000],
                     now or _utc_now()))

    def history(self, workspace_code: str, *, limit: int = 50) -> List[Dict[str, Any]]:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_HISTORY), (workspace_code, int(limit)))
            return self._rows(cur)

    def history_for(self, workspace_code: str, memory_id: int) -> List[Dict[str, Any]]:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_HISTORY_FOR), (workspace_code, int(memory_id)))
            return self._rows(cur)

    # -- reads ---------------------------------------------------------------
    def get(self, workspace_code: str, memory_id: int) -> Optional[MemoryFact]:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_BY_ID), (workspace_code, int(memory_id)))
            row = self._one(cur)
        return MemoryFact.from_row(row) if row else None

    def active(self, workspace_code: str, scopes: Iterable[str]) -> List[MemoryFact]:
        """Active rows of the given scopes, expired ones excluded, in a STABLE
        order (scope, docs before facts, then creation) — the injected block
        must render identically on every pod."""
        scope_list = [s for s in dict.fromkeys(scopes) if s]
        if not scope_list:
            return []
        ph = self._db.placeholder()
        sql = SQL_SELECT_ACTIVE_SCOPES.format(scopes=",".join([ph] * len(scope_list)))
        with self._tx() as cur:
            cur.execute(self._q(sql), (workspace_code, *scope_list))
            rows = self._rows(cur)
        now = _utc_now()
        out = [MemoryFact.from_row(r) for r in rows
               if not (r.get("expires_at") and str(r["expires_at"]) < now)]
        out.sort(key=lambda f: (scope_list.index(f.scope), 0 if f.kind == "doc" else 1,
                                MARKS.index(f.mark) if f.mark in MARKS else 9,
                                f.source_ref if f.kind == "doc" else "", f.created_at, f.id))
        return out

    def by_status(self, workspace_code: str, status: str) -> List[MemoryFact]:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_STATUS), (workspace_code, status))
            return [MemoryFact.from_row(r) for r in self._rows(cur)]

    def pending(self, workspace_code: str) -> List[MemoryFact]:
        return self.by_status(workspace_code, "draft")

    def all_rows(self, workspace_code: str) -> List[MemoryFact]:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_ALL), (workspace_code,))
            return [MemoryFact.from_row(r) for r in self._rows(cur)]

    def version(self, workspace_code: str) -> str:
        """Cheap etag of the active set — what the injector compares before
        rewriting a materialized file."""
        with self._tx() as cur:
            cur.execute(self._q(SQL_VERSION), (workspace_code,))
            r = self._one(cur) or {}
        return f"{r.get('n', 0)}:{r.get('x') or 0}:{r.get('m') or ''}"

    # -- writes --------------------------------------------------------------
    def _find_same(self, cur, workspace_code: str, scope: str, status: str, sig: str
                   ) -> Optional[Dict[str, Any]]:
        cur.execute(self._q(SQL_SELECT_STATUS_SCOPE), (workspace_code, scope, status))
        for row in self._rows(cur):
            if (row.get("sig") or "") == sig:
                return row
        return None

    def _supersede_conflicting(self, cur, workspace_code: str, scope: str, new_sig: str,
                               *, actor: str, now: str, keep_id: Optional[int] = None) -> List[int]:
        """Mark every ACTIVE row of *scope* that :func:`conflicts` with
        *new_sig* as superseded (a correction replaces in place). Returns the
        ids superseded."""
        new_set = sig_set(new_sig)
        cur.execute(self._q(SQL_SELECT_STATUS_SCOPE), (workspace_code, scope, "active"))
        out: List[int] = []
        for row in self._rows(cur):
            if keep_id is not None and int(row["id"]) == keep_id:
                continue
            if conflicts(new_set, sig_set(row.get("sig") or "")):
                cur.execute(self._q(SQL_UPDATE_STATUS),
                            ("superseded", actor, now, workspace_code, int(row["id"])))
                self._history(cur, workspace_code, int(row["id"]), "superseded", actor,
                              f"replaced by a correction: {new_sig[:120]}", now)
                out.append(int(row["id"]))
        return out

    def _newer_conflicting(self, cur, workspace_code: str, scope: str, sig: str,
                           source_at: Optional[str]) -> Optional[Dict[str, Any]]:
        """An ACTIVE row of *scope* that conflicts with *sig* and whose
        source is NEWER than *source_at* — the row a candidate must lose to.
        None when there is none, or when either side has no source time
        (an undated row cannot claim to be newer)."""
        if not source_at:
            return None
        new_set = sig_set(sig)
        cur.execute(self._q(SQL_SELECT_STATUS_SCOPE), (workspace_code, scope, "active"))
        for row in self._rows(cur):
            other = row.get("source_at")
            if other and str(other) > str(source_at) and conflicts(new_set, sig_set(row.get("sig") or "")):
                return row
        return None

    def add(self, workspace_code: str, cand: Candidate, *, status: str = "draft",
            origin: str = "run", source_ref: str = "", actor: str = "",
            kind: str = "fact", ttl: Optional[timedelta] = None,
            source_at: Optional[str] = None) -> Tuple[Optional[MemoryFact], str]:
        """Insert one candidate. Returns ``(row, outcome)`` where outcome is
        ``added`` / ``activated`` / ``duplicate`` (an identical row already
        holds that status, or is already active — nothing written, the
        existing row returned) / ``stale`` (a conflicting ACTIVE row comes
        from a NEWER source — the candidate is the older value of a
        correction and is not stored; the newer row is returned).

        THE RECENCY RULE. Runs are consolidated in whatever order pods reach
        them, and a backlog swept newest-first would otherwise let an older
        run's value replace a newer run's correction (measured: four of four
        correction pairs ended backwards). ``source_at`` — the run's own
        creation time — is the axis that decides, never the order of arrival.

        Activating supersedes conflicting active rows first, inside the same
        writer transaction, so the partial unique index never fires on a
        legitimate correction. If it fires anyway (a true concurrent
        duplicate from another pod), the winner's row is returned as
        ``duplicate`` — never an exception up the stack.
        """
        if status not in STATUSES:
            raise ValueError(f"status must be one of {', '.join(STATUSES)}")
        if kind not in KINDS:
            raise ValueError(f"kind must be one of {', '.join(KINDS)}")
        c = cand.normalized()
        if not c.fact:
            return None, "empty"
        sig = fact_sig(c.fact) if kind == "fact" else f"doc:{hashlib.sha256(c.fact.encode('utf-8')).hexdigest()[:24]}"
        now = _utc_now()
        expires = None
        if ttl is None and c.mark == "ephemeral":
            ttl = timedelta(days=int(os.environ.get("IOF_MEMORY_EPHEMERAL_TTL_DAYS", "14")))
        if ttl is not None:
            expires = (datetime.now(timezone.utc) + ttl).isoformat()
        with self._write_tx() as cur:
            same = self._find_same(cur, workspace_code, c.scope, status, sig)
            if same is None and status == "draft":
                # A draft for a fact that is ALREADY active is not a change
                # either — the plan read the active set before a steward's
                # approval landed, and the draft would only be superseded at
                # its own approval.
                same = self._find_same(cur, workspace_code, c.scope, "active", sig)
            if same is not None:
                # Not touched: an identical row is not a change, and bumping
                # updated_at would move version() and re-materialize every
                # cached block for nothing.
                return MemoryFact.from_row(same), "duplicate"
            if kind == "fact":
                newer = self._newer_conflicting(cur, workspace_code, c.scope, sig, source_at)
                if newer is not None:
                    return MemoryFact.from_row(newer), "stale"
            if status == "active":
                self._supersede_conflicting(cur, workspace_code, c.scope, sig, actor=actor, now=now)
            params = (workspace_code, c.scope, kind, c.fact, c.mark, status, sig, origin,
                      source_ref or "", c.evidence, actor, now, now, expires, source_at)
            try:
                cur.execute("SAVEPOINT ws_memory_insert")
                cur.execute(self._q(SQL_INSERT_MEMORY), params)
                new_id = self._db.get_last_id(cur) if not self._is_pg else None
                if self._is_pg:
                    cur.execute("SELECT lastval() AS id")
                    new_id = int((self._one(cur) or {}).get("id") or 0)
                cur.execute("RELEASE SAVEPOINT ws_memory_insert")
            except Exception as exc:  # the partial unique index fired
                cur.execute("ROLLBACK TO SAVEPOINT ws_memory_insert")
                cur.execute("RELEASE SAVEPOINT ws_memory_insert")
                same = self._find_same(cur, workspace_code, c.scope, "active", sig)
                if same is not None:
                    return MemoryFact.from_row(same), "duplicate"
                raise exc
            self._history(cur, workspace_code, int(new_id), "added" if status == "draft" else "activated",
                          actor, f"{origin}:{source_ref} [{c.mark}] {c.fact[:160]}", now)
            cur.execute(self._q(SQL_SELECT_BY_ID), (workspace_code, int(new_id)))
            row = self._one(cur)
        return MemoryFact.from_row(row), ("activated" if status == "active" else "added")

    def approve(self, workspace_code: str, memory_id: int, *, actor: str) -> Tuple[Optional[MemoryFact], str]:
        """Draft → active. Supersedes conflicting actives; an identical active
        row makes the draft ``superseded`` (nothing to add) — outcome
        ``duplicate``. Outcome ``not_pending`` when the row is not a draft
        (already decided by another steward or another pod)."""
        now = _utc_now()
        with self._write_tx() as cur:
            cur.execute(self._q(SQL_SELECT_BY_ID), (workspace_code, int(memory_id)))
            row = self._one(cur)
            if row is None:
                return None, "missing"
            if row.get("status") != "draft":
                return MemoryFact.from_row(row), "not_pending"
            sig = row.get("sig") or ""
            same = self._find_same(cur, workspace_code, row["scope"], "active", sig)
            if same is not None:
                cur.execute(self._q(SQL_UPDATE_STATUS_IF),
                            ("superseded", actor, now, workspace_code, int(memory_id), "draft"))
                self._history(cur, workspace_code, int(memory_id), "superseded", actor,
                              f"identical active row #{same['id']} already present", now)
                return MemoryFact.from_row(same), "duplicate"
            newer = self._newer_conflicting(cur, workspace_code, row["scope"], sig, row.get("source_at"))
            if newer is not None:
                # The draft is the OLDER value of a correction whose newer
                # value is already active: approving it would roll the
                # workspace back. Outcome `stale`; the draft is closed.
                cur.execute(self._q(SQL_UPDATE_STATUS_IF),
                            ("superseded", actor, now, workspace_code, int(memory_id), "draft"))
                self._history(cur, workspace_code, int(memory_id), "superseded", actor,
                              f"stale: #{newer['id']} carries a newer value (source {newer.get('source_at')})", now)
                return MemoryFact.from_row(newer), "stale"
            self._supersede_conflicting(cur, workspace_code, row["scope"], sig, actor=actor, now=now)
            cur.execute(self._q(SQL_UPDATE_STATUS_IF),
                        ("active", actor, now, workspace_code, int(memory_id), "draft"))
            if cur.rowcount == 0:
                cur.execute(self._q(SQL_SELECT_BY_ID), (workspace_code, int(memory_id)))
                return MemoryFact.from_row(self._one(cur) or row), "not_pending"
            self._history(cur, workspace_code, int(memory_id), "approved", actor, "", now)
            cur.execute(self._q(SQL_SELECT_BY_ID), (workspace_code, int(memory_id)))
            row = self._one(cur)
        return MemoryFact.from_row(row), "approved"

    def reject(self, workspace_code: str, memory_id: int, *, actor: str, reason: str = "") -> str:
        now = _utc_now()
        with self._write_tx() as cur:
            cur.execute(self._q(SQL_UPDATE_STATUS_IF),
                        ("rejected", actor, now, workspace_code, int(memory_id), "draft"))
            if cur.rowcount == 0:
                return "not_pending"
            self._history(cur, workspace_code, int(memory_id), "rejected", actor, reason, now)
        return "rejected"

    def forget(self, workspace_code: str, memory_id: int, *, actor: str, reason: str = "") -> str:
        """Active → removed. The row stays (audit); it is never injected again."""
        now = _utc_now()
        with self._write_tx() as cur:
            cur.execute(self._q(SQL_UPDATE_STATUS_IF),
                        ("removed", actor, now, workspace_code, int(memory_id), "active"))
            if cur.rowcount == 0:
                return "not_active"
            self._history(cur, workspace_code, int(memory_id), "removed", actor, reason, now)
        return "removed"

    def expire(self, workspace_code: str) -> int:
        """Retire ephemeral rows past their TTL (Dream's age-and-decay rule)."""
        now = _utc_now()
        with self._write_tx() as cur:
            cur.execute(self._q(SQL_SELECT_EXPIRED), (workspace_code, now))
            ids = [int(r["id"]) for r in self._rows(cur)]
            if not ids:
                return 0
            cur.execute(self._q(SQL_EXPIRE), (now, workspace_code, now))
            for i in ids:
                self._history(cur, workspace_code, i, "expired", "expiry", "", now)
        return len(ids)

    # -- curated docs (pack / workspace tier) --------------------------------
    def sync_docs(self, workspace_code: str, docs: Iterable[Tuple[str, str, str]], *,
                  origin: str, actor: str = "sync") -> Dict[str, int]:
        """Reconcile the curated tier: *docs* is ``(scope, path, content)``.
        Unchanged content is left alone; changed content supersedes the old
        row; a path no longer present is removed. Returns counts."""
        counts = {"added": 0, "updated": 0, "removed": 0, "unchanged": 0}
        now = _utc_now()
        incoming: Dict[Tuple[str, str], Tuple[str, str]] = {}
        for scope, path, content in docs:
            content = (content or "").strip()
            if not content:
                continue
            incoming[(scope, path)] = (content, f"doc:{hashlib.sha256(content.encode('utf-8')).hexdigest()[:24]}")
        with self._write_tx() as cur:
            cur.execute(self._q(SQL_SELECT_DOCS), (workspace_code,))
            existing = {(r["scope"], r["source_ref"]): r for r in self._rows(cur)
                        if r.get("origin") == origin}
            for key, (content, sig) in incoming.items():
                old = existing.pop(key, None)
                if old is not None and (old.get("sig") or "") == sig:
                    counts["unchanged"] += 1
                    continue
                if old is not None:
                    cur.execute(self._q(SQL_UPDATE_STATUS),
                                ("superseded", actor, now, workspace_code, int(old["id"])))
                    self._history(cur, workspace_code, int(old["id"]), "superseded", actor,
                                  f"{origin} doc changed: {key[1]}", now)
                    counts["updated"] += 1
                else:
                    counts["added"] += 1
                cur.execute(self._q(SQL_INSERT_MEMORY),
                            (workspace_code, key[0], "doc", content, "permanent", "active", sig,
                             origin, key[1], "", actor, now, now, None, None))
                new_id = self._db.get_last_id(cur) if not self._is_pg else None
                if self._is_pg:
                    cur.execute("SELECT lastval() AS id")
                    new_id = int((self._one(cur) or {}).get("id") or 0)
                self._history(cur, workspace_code, int(new_id), "activated", actor,
                              f"{origin} doc: {key[1]}", now)
            for key, old in existing.items():
                cur.execute(self._q(SQL_UPDATE_STATUS),
                            ("removed", actor, now, workspace_code, int(old["id"])))
                self._history(cur, workspace_code, int(old["id"]), "removed", actor,
                              f"{origin} doc gone: {key[1]}", now)
                counts["removed"] += 1
        return counts

    # -- run claims (the distributed cursor) ---------------------------------
    def claim_run(self, workspace_code: str, run_id: str, *, worker: Optional[str] = None,
                  force: bool = False) -> bool:
        """Claim *run_id* for consolidation. True when THIS worker holds the
        claim (fresh, or a stale one taken over); False when another worker
        holds it or it is already done.

        A ``failed`` claim (the worker raised — a model error, a bad
        transcript) is re-claimable at once, up to ``MAX_ATTEMPTS`` in
        total, so a transient failure is retried by a later sweep rather
        than pinning the run as never-consolidated, and a deterministic one
        stops costing model calls after three. ``force`` takes the claim
        whatever its state — the operator's ``--force``."""
        worker = worker or worker_identity()
        now = _utc_now()
        with self._write_tx() as cur:
            cur.execute(self._q(self._db.upsert_ignore(SQL_CLAIM_RUN)),
                        (workspace_code, run_id, worker, now))
            cur.execute(self._q(SQL_SELECT_RUN_CLAIM), (workspace_code, run_id))
            row = self._one(cur) or {}
            if row.get("claimed_by") == worker and row.get("status") == "claimed":
                return True
            if force:
                cur.execute(self._q(SQL_FORCE_CLAIM),
                            (worker, now, f"forced; was {row.get('status')} by {row.get('claimed_by')}",
                             workspace_code, run_id))
                return cur.rowcount > 0
            if row.get("status") not in ("claimed", "failed"):
                return False
            stale_before = (datetime.now(timezone.utc) - timedelta(seconds=self.STALE_CLAIM_S)).isoformat()
            cur.execute(self._q(SQL_RECLAIM),
                        (worker, now, f"reclaimed from {row.get('claimed_by')} ({row.get('status')})",
                         workspace_code, run_id, stale_before, int(self.MAX_ATTEMPTS)))
            return cur.rowcount > 0

    def finish_run(self, workspace_code: str, run_id: str, *, changed: bool, detail: str = "",
                   worker: Optional[str] = None) -> bool:
        worker = worker or worker_identity()
        with self._write_tx() as cur:
            d = (detail or "")[:2000]
            cur.execute(self._q(SQL_FINISH_RUN),
                        (_utc_now(), 1 if changed else 0, d, d, workspace_code, run_id, worker))
            return cur.rowcount > 0

    def fail_run(self, workspace_code: str, run_id: str, *, detail: str = "",
                 worker: Optional[str] = None) -> bool:
        worker = worker or worker_identity()
        with self._write_tx() as cur:
            d = (detail or "")[:2000]
            cur.execute(self._q(SQL_FAIL_RUN),
                        (_utc_now(), d, d, workspace_code, run_id, worker))
            return cur.rowcount > 0

    def release_run(self, workspace_code: str, run_id: str, *, worker: Optional[str] = None) -> bool:
        """Give a claim back untouched (nothing to consolidate yet)."""
        worker = worker or worker_identity()
        with self._write_tx() as cur:
            cur.execute(self._q(SQL_RELEASE_RUN), (workspace_code, run_id, worker))
            return cur.rowcount > 0

    def run_claims(self, workspace_code: str) -> List[Dict[str, Any]]:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_RUN_CLAIMS), (workspace_code,))
            return self._rows(cur)

    def run_claim(self, workspace_code: str, run_id: str) -> Optional[Dict[str, Any]]:
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_RUN_CLAIM), (workspace_code, run_id))
            return self._one(cur)

    def stale_claims(self, workspace_code: str) -> List[Dict[str, Any]]:
        stale_before = (datetime.now(timezone.utc) - timedelta(seconds=self.STALE_CLAIM_S)).isoformat()
        with self._tx() as cur:
            cur.execute(self._q(SQL_SELECT_STALE_CLAIMS), (workspace_code, stale_before))
            return self._rows(cur)

    # -- reporting -----------------------------------------------------------
    def integrity(self) -> tuple[bool, str]:
        """Is the database itself sound? ``(ok, detail)``.

        WHY A PROBE AND NOT ERROR HANDLING. A validator zeroed 4 KB of one
        page: `memory list` raised `database disk image is malformed` while
        `memory status` printed `draft 8 | active 4 | total 12`. Nothing was
        swallowing an error - SQLite corruption is PER PAGE, so the count
        query read a sound page and returned real numbers from an unsound
        file. No amount of try/except would have caught that; only asking the
        database about itself does.

        `quick_check` rather than `integrity_check`: it is the same answer for
        this purpose and does not walk every page, so a status command stays a
        status command.

        Non-SQLite backends have no equivalent single question, and a server
        that answers at all is sound in the sense meant here, so they report
        ok. Any failure to ask is reported as unknown rather than as health.
        """
        try:
            with self._tx() as cur:
                try:
                    cur.execute("PRAGMA quick_check(1)")
                except Exception:
                    return True, "not applicable to this backend"
                row = self._one(cur) or {}
                verdict = str(
                    (row.get("quick_check") if isinstance(row, dict) else None)
                    or (list(row.values())[0] if isinstance(row, dict) and row
                        else "")
                    or "").strip()
            if not verdict:
                return True, "not applicable to this backend"
            return (verdict.lower() == "ok"), verdict
        except Exception as exc:  # noqa: BLE001
            return False, f"could not be checked: {type(exc).__name__}: {exc}"

    def counts(self, workspace_code: str) -> Dict[str, int]:
        rows = self.all_rows(workspace_code)
        out = {s: 0 for s in STATUSES}
        for r in rows:
            out[r.status] = out.get(r.status, 0) + 1
        out["total"] = len(rows)
        return out

    def dump(self, workspace_code: str) -> str:
        return json.dumps([f.to_dict() for f in self.all_rows(workspace_code)], indent=2, default=str)
