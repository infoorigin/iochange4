from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict

from ioagentfarm.engine.runner_base import Runner

class LocalEchoRunner(Runner):
    def run_step(
        self,
        *,
        run_id: str,
        step_key: str,
        role: str,
        role_prompt: str,
        step_prompt: str,
        goal: str,
        workspace: Path,
        context: Dict[str, Any],
    ) -> str:
        workspace.mkdir(parents=True, exist_ok=True)
        (workspace / "ECHO_ROLE.md").write_text(role_prompt, encoding="utf-8")
        (workspace / "ECHO_STEP.md").write_text(step_prompt, encoding="utf-8")
        (workspace / "ECHO_GOAL.md").write_text(goal, encoding="utf-8")

        # Loop steps need synthetic STORIES_JSON so the pipeline can be tested end-to-end
        if context.get("step_type") == "loop":
            synthetic_stories = [
                {"id": "s1", "title": "Echo story 1", "acceptance": ["criterion 1"]},
                {"id": "s2", "title": "Echo story 2", "acceptance": ["criterion 1"]},
            ]
            return (
                "STATUS: done\n"
                "OUTPUT: (echo-runner) Generated synthetic stories for loop step.\n"
                f"STORIES_JSON: {json.dumps(synthetic_stories)}"
            )

        return "STATUS: done\nOUTPUT: (echo-runner) iobot not available; recorded inputs in workspace."
