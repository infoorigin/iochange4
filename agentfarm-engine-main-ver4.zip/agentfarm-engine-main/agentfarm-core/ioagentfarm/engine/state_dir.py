"""The runtime's on-disk state directory.

The runtime state lives under ``~/.iobot`` (config.json, agent workspaces,
sessions, logs, cron). That is the vendored runtime's own default; the
``state_dir_override`` entry in ``_iobot_patches.PATCHES`` relocates it when
``IOF_STATE_DIR_NAME`` names another directory (test isolation, a shared
host). This module is the OUR-SIDE half: the same resolution for engine code
that needs the root without importing the runtime.
"""

from __future__ import annotations

import os
from pathlib import Path

DEFAULT_STATE_DIR = ".iobot"


def state_dir_name() -> str:
    """Directory name under $HOME. Mirrors the runtime patch's toggle."""
    return (os.getenv("IOF_STATE_DIR_NAME") or DEFAULT_STATE_DIR).strip() or DEFAULT_STATE_DIR


def state_dir_root() -> Path:
    return Path.home() / state_dir_name()
