"""Materialising a draft on disk — the ONLY module here that touches files.

:mod:`ioagentfarm.engine.drafts` holds the record and the pure logic and is
imported by the Studio API, whose pod has no filesystem. Everything that writes
a directory lives here instead, and the API never imports this module. The
split is the reason a draft cannot repeat the class of defect the One Truth
model was written to remove: code that works on a developer's machine because
the API and the engine happened to share a disk.

What it owns:

* :func:`apply_overlay` — write one overlay onto a materialised item.
* :func:`draft_home_root` / :func:`draft_agent_workspace` — where an author's
  private agent homes live: ``<IOF_ROOT>/workspaces/<code>/drafts/<slug>/
  agents/<role>/workspace``. Deliberately OUTSIDE ``agent_home_root()`` and
  outside every scanner that enumerates roles from disk (``_agent_roots``,
  the A2A ``exposed_roles`` sweep), so a draft can never make an agent appear
  in a catalog, an A2A card list or another user's session.
* :func:`materialize_draft_home` — build that home: the shared home refreshed
  from the installed pack, copied (never symlinked, never shared), then the
  author's overlay applied on top.

Two rules the implementation exists to keep:

1. **The shared agent home is never written on a draft's behalf.** Seeding a
   draft home by calling ``ensure_agent_workspace`` with the draft path as its
   TARGET looks equivalent and is not: that function resolves the tenant's own
   home as the template, copies its ``memory/``, and records the resulting
   carriage into the workspace's shared ``studio_skills`` row — so one author's
   private skill removal would change what every other user sees. The shared
   home is refreshed at its own path; the draft home is a copy.
2. **A draft session gets its own memory.** The draft home starts with a blank
   ``memory/`` and its own ``sessions/``, so an experiment cannot write into
   the agent's accumulated memory, and a discarded draft leaves nothing behind.
"""

from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Iterable, Sequence

from ioagentfarm.engine.drafts import (SKILLS_KEY, author_slug, carried_skills,
                                       draft_signature, normalise_files)

logger = logging.getLogger(__name__)

#: Identity files copied from the shared home into a draft home. The same list
#: ``create_filtered_workspace`` copies for a run — one agent, one identity,
#: whichever surface is serving it.
IDENTITY_FILES = ("SOUL.md", "AGENTS.md", "TOOLS.md", "USER.md",
                  "HEARTBEAT.md", "team.md", "a2a-card.yaml")

#: Host state a draft home gets fresh rather than inherited.
_BLANK_MEMORY = ("# Memory\n\nClean slate - this is a draft session's own "
                 "memory. Nothing written here reaches the agent's real "
                 "memory, and it is removed with the draft.\n")

#: Never absent, whatever the draft says: without it an agent emits no
#: STATUS:/OUTPUT: and every step it runs is marked failed and retried.
REQUIRED_SKILL = "output_protocol"


# ---------------------------------------------------------------------------
# overlay -> disk
# ---------------------------------------------------------------------------

def apply_overlay(target: Path, files: dict | None) -> list[str]:
    """Write an overlay into an already-materialised item directory.

    Returns the relative paths written or deleted, in sorted order.
    ``None`` deletes; :data:`~ioagentfarm.engine.drafts.SKILLS_KEY` is carriage
    and is skipped here (see :func:`materialize_draft_home`). Paths are
    re-validated even though the writer validated them at save time — this is
    the last gate before a filesystem, and the record may have travelled
    through a database that a different version wrote.
    """
    touched: list[str] = []
    for rel, value in sorted(normalise_files(files).items()):
        if rel == SKILLS_KEY:
            continue
        path = target / rel
        if value is None:
            if path.is_file():
                path.unlink()
                touched.append(rel)
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value, encoding="utf-8")
        touched.append(rel)
    return touched


# ---------------------------------------------------------------------------
# where a draft materialises
# ---------------------------------------------------------------------------

def draft_home_root(workspace_code: str, author: str) -> Path:
    """``<IOF_ROOT>/workspaces/<code>/drafts/<author-slug>``.

    Derived from ``IOF_ROOT`` and the workspace, NOT from ``agent_home_root()``
    — that honours ``IOF_AGENT_HOME``, which a deployment may point anywhere,
    including at a tree something else enumerates. A draft home must be
    somewhere nothing but this module looks.
    """
    from ioagentfarm.engine.workspaces import _iof_root
    if not (workspace_code or "").strip():
        raise ValueError("draft_home_root: a workspace code is required")
    return (_iof_root() / "workspaces" / workspace_code / "drafts"
            / author_slug(author))


def draft_agent_workspace(role: str, workspace_code: str, author: str) -> Path:
    """The author's private workspace directory for one agent role."""
    return draft_home_root(workspace_code, author) / "agents" / role / "workspace"


def discard_draft_home(workspace_code: str, author: str,
                       role: str | None = None) -> None:
    """Remove a draft home (one role, or the author's whole tree).

    Best-effort: a home that cannot be removed is logged and left. It is a
    cache, so a stale one costs disk, not correctness — the next
    materialisation rebuilds it.
    """
    target = (draft_agent_workspace(role, workspace_code, author) if role
              else draft_home_root(workspace_code, author))
    try:
        if target.exists():
            shutil.rmtree(target, ignore_errors=True)
    except OSError:
        logger.debug("could not remove draft home %s", target, exc_info=True)


# ---------------------------------------------------------------------------
# building a draft agent home
# ---------------------------------------------------------------------------

def _skill_dirs(skills_root: Path) -> list[str]:
    if not skills_root.is_dir():
        return []
    return sorted(d.name for d in skills_root.iterdir()
                  if d.is_dir() and d.name != "reference"
                  and (d / "SKILL.md").is_file())


def _seed_required_skill(skills_dst: Path) -> bool:
    """Copy the INSTALLED core's ``output_protocol`` into a draft home.

    Same source and the same reason as the scaffold's
    ``cli_scaffold._seed_output_protocol``: copy what the SDK enforces rather
    than embedding a second copy that can drift from it.
    """
    try:
        from importlib.resources import files
        src = (files("ioagentfarm") / "agents" / "project_lead" / "workspace"
               / "skills" / REQUIRED_SKILL / "SKILL.md")
        dest = skills_dst / REQUIRED_SKILL / "SKILL.md"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
        return True
    except Exception:  # noqa: BLE001 - the caller warns
        return False


def _refresh_shared_home(role: str, workspace_code: str) -> Path | None:
    """Refresh the agent's REAL home from the installed pack; return it.

    ``None`` when no pack and no unpromoted row provides the role — the
    new-item case, where the draft itself is the whole supply.
    """
    from ioagentfarm.engine.workspaces import (ensure_agent_workspace,
                                               iobot_agent_workspace)
    real = iobot_agent_workspace(role)
    try:
        ensure_agent_workspace(role, real, workspace_code=workspace_code)
    except FileNotFoundError:
        return None
    except Exception:  # noqa: BLE001 - fail open, the SOUL check below decides
        logger.debug("shared home refresh failed for %s", role, exc_info=True)
    return real if (real / "SOUL.md").is_file() else None


def materialize_draft_home(role: str, workspace_code: str, author: str,
                           drafts: Sequence[dict]) -> Path:
    """Build ``<draft home>/agents/<role>/workspace`` = base (+) this author's drafts.

    *drafts* is the author's OPEN draft set (any kind); the agent draft for
    *role* and every skill draft the role carries are applied. The directory is
    rebuilt from scratch on every call — it is a cache keyed by
    :func:`~ioagentfarm.engine.drafts.draft_signature`, and the caller decides
    when to call; rebuilding is what makes "save, then ask again" work.

    Raises ``FileNotFoundError`` when neither the pack nor the draft supplies a
    ``SOUL.md`` — the same fail-closed rule as a run's workspace, and for the
    same reason: a workspace with no identity does not fail, it silently runs
    the runtime's stock persona.
    """
    from ioagentfarm.engine.workspaces import _resolve_skill

    by_kind = _index(drafts)
    agent_draft = by_kind["agent"].get(role)
    target = draft_agent_workspace(role, workspace_code, author)
    if target.exists():
        shutil.rmtree(target, ignore_errors=True)
    target.mkdir(parents=True, exist_ok=True)

    real = _refresh_shared_home(role, workspace_code)

    # identity
    if real is not None:
        for fname in IDENTITY_FILES:
            src = real / fname
            if src.is_file():
                shutil.copy2(str(src), str(target / fname))
        for extra in ("metadata",):
            src = real / extra
            if src.is_dir():
                shutil.copytree(str(src), str(target / extra), dirs_exist_ok=True)

    # skills: the role's baseline, then the draft's carriage
    skills_dst = target / "skills"
    skills_dst.mkdir(exist_ok=True)
    skills_src = (real / "skills") if real is not None else target / "skills"
    baseline = _skill_dirs(real / "skills") if real is not None else []
    wanted = carried_skills(agent_draft.get("files") if agent_draft else None)
    names = sorted(set(wanted if wanted is not None else baseline)
                   | {REQUIRED_SKILL})
    for name in names:
        if _resolve_skill(name, skills_src, skills_dst) is not None:
            continue
        if name == REQUIRED_SKILL and _seed_required_skill(skills_dst):
            # A brand-new agent has no pack template to inherit it from, and
            # output_protocol does not ship as a shared skill - it lives inside
            # every agent. Without this a draft agent runs with no output
            # contract, which does not look broken: the session answers, and
            # every step it is later given fails its protocol parse.
            continue
        logger.warning(
            "draft home for role=%s author=%s: skill %r is in no catalog "
            "source - the draft session runs WITHOUT it", role, author, name)
    ref = (real / "skills" / "reference") if real is not None else None
    if ref is not None and ref.is_dir():
        shutil.copytree(str(ref), str(skills_dst / "reference"), dirs_exist_ok=True)

    # the author's overlays: the agent itself, then any skill this role carries
    if agent_draft is not None:
        apply_overlay(target, agent_draft.get("files"))
    for name in names:
        skill_draft = by_kind["skill"].get(name)
        if skill_draft is not None:
            (skills_dst / name).mkdir(parents=True, exist_ok=True)
            apply_overlay(skills_dst / name, skill_draft.get("files"))

    if not (target / "SOUL.md").is_file():
        raise FileNotFoundError(
            f"no SOUL.md for role={role!r} in a draft session for {author!r}: "
            f"no installed pack provides the agent and the draft does not "
            f"supply one. Add a SOUL.md to the draft, or check the role name.")

    # host state, never inherited
    mem = target / "memory"
    mem.mkdir(exist_ok=True)
    (mem / "MEMORY.md").write_text(_BLANK_MEMORY, encoding="utf-8")
    (target / "sessions").mkdir(exist_ok=True)

    from ioagentfarm.engine.agent_metadata import embed_metadata_into_skills
    embed_metadata_into_skills(target)

    from ioagentfarm.engine.workspaces import _generate_agents_md
    try:
        _generate_agents_md(target, role)
    except Exception:  # noqa: BLE001 - AGENTS.md is generated, never authored
        logger.debug("AGENTS.md generation skipped for draft %s", role,
                     exc_info=True)

    logger.info("draft home built: role=%s author=%s signature=%s at %s",
                role, author, draft_signature(drafts)[:12], target)
    return target


def _index(drafts: Iterable[dict] | None) -> dict[str, dict[str, dict]]:
    """``{kind: {name: draft}}`` for fast lookup, ignoring unknown kinds."""
    out: dict[str, dict[str, dict]] = {"agent": {}, "skill": {}, "workflow": {}}
    for d in drafts or []:
        kind = str(d.get("kind") or "")
        if kind in out:
            out[kind][str(d.get("name") or "")] = d
    return out


def index_by_kind(drafts: Iterable[dict] | None) -> dict[str, dict[str, dict]]:
    """Public form of :func:`_index` — used by the run-side resolver."""
    return _index(drafts)
