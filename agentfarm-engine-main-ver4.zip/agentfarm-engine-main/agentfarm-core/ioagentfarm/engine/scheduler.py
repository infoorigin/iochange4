from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict

from ioagentfarm.engine.models import Workflow
from ioagentfarm.engine.iobot_config import get_run_output_dir
from ioagentfarm.engine.store import Store
from ioagentfarm.engine.templating import render

logger = logging.getLogger(__name__)


_STEP_WRAPPER = """# Workflow step

- run_id: {{run_id}}
- workflow: {{workflow}}
- step_key: {{step_key}}
- role: {{role}}
- attempt: {{attempt}}/{{max_attempts}}
{{role_section}}
## Goal
{{goal}}

## Source directory (existing code and input files — READ)
{{project_dir}}

## Output directory (write all deliverable artifacts here)
{{output_dir}}

DELIVERABLES ONLY. Your STATUS/OUTPUT protocol file does NOT belong in this
directory - it goes to the exact path named under "Output destination" at the
end of this prompt, which is a DIFFERENT directory. Writing it here leaves the
step reading as failed however well the work went, and re-running will not
help. If you are told your output file is missing, do not move it here and do
not go looking: write it to that named path.

## Feedback from previous attempt
{{feedback}}

## Shared progress
{{progress}}

## Step instructions
{{instructions}}
"""


def render_step_prompt(
    *, store: Store, workflow: Workflow, root: Path, run_id: str, step_key: str,
    consume_feedback: bool = True) -> Dict[str, Any]:
    """Render a step's prompt with all template vars.

    Returns dict with keys: role, prompt, max_attempts, output_dir.
    Does NOT claim or mutate the step — read-only.
    """
    run = store.get_run(run_id)
    goal = run["goal"]
    project_dir = run.get("project_dir", "")
    step_by_key = {s.key: s for s in workflow.steps}

    run_dir = root / "runs" / run_id
    progress_path = run_dir / "progress.txt"

    story_ctx: Dict[str, Any] = {}
    step_command_raw = ""
    if step_key.startswith("story:"):
        suffix = step_key.split(":")[-1]
        story_id = step_key.split(":")[1] if len(step_key.split(":")) > 2 else ""
        story_ctx["story_id"] = story_id
        # Any step carrying per-item templates anchors the fan-out — `type: loop`
        # (agent emits STORIES_JSON) or `type: exec` (stories read from a manifest).
        loop_step = next((s for s in workflow.steps if s.per_item_steps), None)
        if not loop_step:
            return {"error": f"No loop step found for story key {step_key}"}
        tmpl = next((t for t in loop_step.per_item_steps if t.key_suffix == suffix), None)
        if not tmpl:
            return {"error": f"No template found for suffix {suffix}"}
        role = tmpl.role
        step_prompt_raw = tmpl.prompt
        max_attempts = tmpl.max_attempts
    else:
        step = step_by_key.get(step_key)
        if step:
            role = step.role
            step_prompt_raw = step.prompt
            max_attempts = step.max_attempts
            step_command_raw = step.command
        else:
            # Dynamic task — prompt and role live in the DB row
            steps = store.list_steps(run_id)
            db_row = next((s for s in steps if s["step_key"] == step_key), None)
            if not db_row:
                return {"error": f"Step {step_key} not found in workflow or store"}
            meta = json.loads(db_row.get("meta_json") or "{}")
            if meta.get("type") != "dynamic":
                return {"error": f"Step {step_key} not found in workflow"}
            role = db_row["role"]
            step_prompt_raw = meta.get("prompt") or meta.get("title") or step_key
            max_attempts = int(db_row["max_attempts"])

    # Read current attempt from DB (don't bump)
    steps = store.list_steps(run_id)
    step_row = next((s for s in steps if s["step_key"] == step_key), None)
    # The row counts attempts ALREADY made, and the prompt is rendered
    # BEFORE the claim bumps it - so it describes the attempt about to
    # start. A novice read `attempt: 0/2` in prompt.txt and concluded the
    # step had never run. A `running` row was bumped by its claim already
    # (the background re-entry case) and is reported as is.
    attempt = int(step_row["attempt"]) if step_row else 0
    if not step_row or step_row.get("status") != "running":
        attempt += 1

    run_output_dir = get_run_output_dir(root, run_id)

    # Workflow snapshot directory (frozen at run creation)
    workflow_snapshot_dir = root / "instances" / run_id / "workflow"
    # metadata_dir: prefer the workflow's OWN bundled metadata (correct catalog +
    # databases.yml), fall back to project_dir/metadata only as a last resort.
    metadata_dir = workflow_snapshot_dir / "metadata"
    if not metadata_dir.is_dir():
        # The snapshot can live under a different IOF_ROOT than this process
        # resolves: `run` creates it from the launch cwd, while a delegated
        # `run-step` resolves `root` from the sub-agent's workspace cwd. In that
        # case the snapshot metadata isn't at THIS root — so re-materialise the
        # workflow snapshot here from its source (pack/installed/bundled), which
        # always carries the right catalog. This avoids silently falling back to
        # a stale, unrelated <project_dir>/metadata (e.g. a global multi-source
        # config with mysql/postgres entries) that breaks grounded queries.
        try:
            from ioagentfarm.engine.workflow_loader import WorkflowLoader
            WorkflowLoader().snapshot_workflow(workflow.name, run_id, root)
        except Exception:
            logger.debug("scheduler: snapshot_workflow re-materialise failed", exc_info=True)
        if not metadata_dir.is_dir() and project_dir:
            fallback = Path(project_dir) / "metadata"
            # Only accept the project_dir fallback if it looks like THIS
            # workflow's catalog home (has a catalog.yaml), not stale cruft.
            if fallback.is_dir() and (fallback / "catalog.yaml").is_file():
                metadata_dir = fallback

    # For large step outputs, reference the existing file in the state directory
    # instead of inlining in the prompt (avoids Windows 32K command-line limit).
    step_outputs = store.get_step_outputs_map(run_id)
    run_dir = root / "runs" / run_id
    for prev_key, prev_output in step_outputs.items():
        if prev_output and len(prev_output) > 4000:
            ref_file = run_dir / "steps" / prev_key.replace(":", "_") / "OUTPUT.md"
            if not ref_file.exists():
                # Fallback: write it if the file doesn't exist yet
                ref_file.parent.mkdir(parents=True, exist_ok=True)
                ref_file.write_text(prev_output, encoding="utf-8")
            step_outputs[prev_key] = (
                f"[Output from '{prev_key}' step saved to file — "
                f"read it with: read_file {ref_file}]"
            )
            logger.info("Large step output (%d chars) referenced at %s", len(prev_output), ref_file)

    # Read feedback from previous attempt (written by pipeline backtrack)
    feedback_path = run_dir / "steps" / step_key.replace(":", "_") / "FEEDBACK.md"
    feedback = ""
    if feedback_path.exists():
        feedback = feedback_path.read_text(encoding="utf-8").strip()
        # Consume the feedback file - don't re-inject on subsequent runs.
        # ONLY when this render is the one that runs the step. `next-step`
        # renders too, to PEEK at role/output_dir, and every driver peeks
        # before it runs - so an unconditional unlink here meant the feedback
        # was gone by the time run-step rendered for real. The "Feedback from
        # previous attempt" section was dead for every driver; nothing wrote
        # FEEDBACK.md until on_fail did, which is how it went unnoticed.
        if consume_feedback:
            feedback_path.unlink()

    # Use forward slashes for path-typed template vars on Windows so they
    # work in both bash command lines AND inside SQL string literals (DuckDB
    # accepts forward slashes on Windows; backslashes get parsed as escape
    # sequences by SQL inside `read_csv('C:\Users\...')`).
    def _fwd(p) -> str:
        return str(p).replace("\\", "/") if p else ""

    ctx = {
        "run_id": run_id,
        "workflow": workflow.name,
        "goal": goal,
        "project_dir": _fwd(project_dir),
        "output_dir": _fwd(run_output_dir),
        "workflow_dir": _fwd(workflow_snapshot_dir) if workflow_snapshot_dir.is_dir() else "",
        "metadata_dir": _fwd(metadata_dir) if metadata_dir.is_dir() else "",
        "step_key": step_key,
        # step_key with ':' and '/' folded to '_', which is the ONLY form safe
        # in a filename: a fan-out step's key is `story:G01:detect`, and
        # Windows cannot create a file containing ':' at all. A prompt that
        # needs to name a per-step file — the `_<key>_plan.md` checkpoint the
        # Fix-6 smart continuation reads — must use this, not step_key.
        "step_key_safe": step_key.replace(":", "_").replace("/", "_"),
        "role": role,
        "attempt": attempt,
        "max_attempts": max_attempts,
        "feedback": feedback,
        "progress": progress_path.read_text(encoding="utf-8") if progress_path.exists() else "",
        "step_output": step_outputs,
        **workflow.vars,  # per-workflow template variables from workflow.yaml vars:
        **story_ctx,
    }

    # Merge CLI --var overrides (workflow_vars.json written by `aicore run --var`)
    overrides: Dict[str, Any] = {}
    vars_override_file = root / "instances" / run_id / "workflow_vars.json"
    if vars_override_file.exists():
        try:
            import json as _json
            overrides = _json.loads(
                vars_override_file.read_text(encoding="utf-8"))
            ctx.update(overrides)
        except Exception:
            logger.warning("Failed to load workflow_vars.json for run %s", run_id)
    # `{{vars.target_brand}}` is the spelling authors reach for - a live
    # workflow shipped with it, lint passed it, and the templater rendered
    # every occurrence as "" (the step prompt read "alert has arrived for
    #  in ."). The bare form stays canonical; this alias makes the
    # intuitive form mean the same thing instead of silently meaning
    # nothing. Overrides are folded in so both spellings agree.
    ctx["vars"] = {**workflow.vars, **{k: v for k, v in overrides.items()
                                       if isinstance(k, str)}}
    # THE ROLE PROMPT. `roles[].prompt` is read into `Role.prompt` at load
    # and, until 2026-08-27, was consumed by NOTHING on the model path: every
    # `roles/<name>.md` in every shipped workflow - the swarm compiler's whole
    # orchestrator persona included - had never influenced a turn, while the
    # reference doc called it "the role's system prompt". It is rendered with
    # the SAME context as the step prompt (the shipped ones use
    # `{{metadata_dir}}`, and lint already checks role prompts against
    # `_CTX_NAMES`) and lands as `## Role` ahead of the goal, on every step
    # that names the role - normal, per-item and dynamic alike. A blank file
    # contributes no section rather than an empty heading. Single-pass
    # substitution means nothing inside the rendered role text is expanded
    # again when the wrapper renders.
    role_def = workflow.roles.get(role)
    role_text = render(role_def.prompt if role_def else "", ctx).strip()
    ctx["role_section"] = f"\n## Role\n{role_text}\n" if role_text else ""
    step_instructions = render(step_prompt_raw, ctx)
    full_prompt = render(_STEP_WRAPPER, {**ctx, "instructions": step_instructions})

    # TWO DIRECTORIES, ON PURPOSE - and this returns the OTHER one, which is
    # the single most confusing thing in this function:
    #
    #   ctx["output_dir"]  = instances/<run>/project     (SHARED)
    #       What {{output_dir}} renders to in prompts and exec commands. The
    #       artifacts workspace: every step writes deliverables here, later
    #       steps read them, and `requires_artifacts` is checked here.
    #
    #   the returned "output_dir" = runs/<run>/steps/<key>   (PER-STEP)
    #       Where run_step puts OUTPUT.md and hands the agent as `output_path`.
    #       Per-step because the protocol file is one step's verdict; a shared
    #       one would be overwritten by whichever step finished last.
    #
    # The comment that used to sit here claimed these were the same directory.
    # They are not, and believing it cost real time: the stall false-alarm
    # guard looked for OUTPUT.md in the shared dir where it never lands, so it
    # never fired once and finished steps were re-run. Agents hit the same
    # confusion from the other side - their consoles show them reasoning about
    # "the orchestrator is looking for it in the project directory ... but I
    # wrote it one level up in the steps directory" and moving the file to
    # satisfy both.
    output_dir = str(run_dir / "steps" / step_key.replace(":", "_"))
    # exec steps render their command with the SAME ctx as prompts, so
    # {{output_dir}} means the SHARED dir for them too - which is what keeps a
    # tool's --out and the artifact gate pointed at the same place.
    rendered_command = ""
    if step_command_raw:
        rendered_command = render(step_command_raw, ctx)
    return {
        "role": role,
        "prompt": full_prompt,
        "max_attempts": max_attempts,
        "output_dir": output_dir,
        # THE OTHER DIRECTORY, NAMED. `output_dir` above is the per-step one
        # and the comment says why; what it could not do was stop a caller
        # believing the name. Measured in the agent-driver certification
        # (round 2): 4 of 6 drivers wrote the deliverable to the `output_dir`
        # the next-step JSON handed them, 3 of 6 runs failed the artifact
        # gate for it, and one probe burned 10 attempts and 58 model calls
        # before finding the shared directory. An inline `project_lead` step
        # gets no rendered prompt, so `{{output_dir}}` never reaches that
        # model and the field name is its ONLY signal.
        #
        # Additive on purpose: renaming `output_dir` to `step_dir` is the
        # honest fix and breaks the orchestrate skill and every external
        # driver at once, so both keys ship and the ambiguous one keeps its
        # meaning. `artifact_dir` is where `requires_artifacts` is checked
        # and where `{{output_dir}}` points in a prompt.
        "artifact_dir": _fwd(run_output_dir),
        "step_key": step_key,
        "run_id": run_id,
        "command": rendered_command,
        # An exec/route step gets it as IOF_STEP_FEEDBACK (the prompt is never
        # sent to a model); the file was consumed above, so this is the only
        # copy the step will see.
        "feedback": feedback,
    }
