"""Learning System v2 — orchestration glue (kept out of cli_orchestration.py).

The live orchestration file carries only tiny gated calls; everything real
lives here and in the sibling modules, so it is unit-testable without iobot.
All v2 behavior is gated by ``IOF_LEARNING_V2`` and is best-effort: any failure
logs at DEBUG and never disrupts a run.

Covers Phases 2-5:
  * inject-tracking + outcome attribution (Phase 2)
  * hub ingest into the workspace, draft-inert (Phase 3)
  * distillation pipeline with throttles: dedup, rate cap, refine-first (Phase 4)
  * per-skill outcome ledger + degradation -> refine telemetry (Phase 5)
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from loguru import logger


# ---------------------------------------------------------------------------
# Gate + config
# ---------------------------------------------------------------------------

def v2_enabled() -> bool:
    """Learning v2 is the platform DEFAULT — no key needed to turn it on.

    ``IOF_LEARNING_V2=0`` is the deployment opt-out, and it means learning
    OFF — NOT a fall-back to the v1 MEMORY.md pipeline, which needs its own
    explicit key (see ``v1_enabled`` directly below; this line said the
    opposite of that function until 2026-08-09). Unset and empty both mean ON: empty equals unset
    because PowerShell deletes a variable assigned "", so the empty form
    cannot be a reliable signal on Windows. The flip exists to avoid key
    mushrooming: the desired state costs zero configuration; only
    deviation is spelled out.
    """
    return os.environ.get("IOF_LEARNING_V2", "").strip().lower() not in (
        "0", "false", "off", "no", "disabled")


def v1_enabled() -> bool:
    """The LEGACY v1 pipeline requires an EXPLICIT opt-in — and only while
    v2 is off.

    ``IOF_LEARNING_V2=0`` alone means learning OFF, not v1 back on: v1 is
    deprecated and will be removed, so opting out of v2 must never silently
    resurrect it. Running the legacy pipeline is a two-key, deliberate act:
    ``IOF_LEARNING_V2=0`` + ``IOF_LEARNING_V1=1``. If ``IOF_LEARNING_V1=1``
    is set while v2 is active, v2 wins and the caller logs the conflict —
    the two generations never run together.
    """
    return os.environ.get("IOF_LEARNING_V1", "").strip().lower() in (
        "1", "true", "on", "yes")


def _submit_cap() -> int:
    try:
        return max(0, int(os.environ.get("IOF_LEARNING_SUBMIT_CAP", "3")))
    except ValueError:
        return 3


def _degrade_threshold() -> float:
    try:
        return float(os.environ.get("IOF_LEARNING_DEGRADE_THRESHOLD", "0.5"))
    except ValueError:
        return 0.5


def _degrade_min_samples() -> int:
    try:
        return max(1, int(os.environ.get("IOF_LEARNING_DEGRADE_MIN", "5")))
    except ValueError:
        return 5


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def _safe(step_key: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", step_key or "step")


def _injected_dir(root_path: Path, run_id: str) -> Path:
    return Path(root_path) / "instances" / run_id / "v2_injected"


# ---------------------------------------------------------------------------
# Inject-tracking (Phase 2)
# ---------------------------------------------------------------------------

def record_injected_skills(root_path: Path, run_id: str, step_key: str, skill_ids: List[str]) -> None:
    if not skill_ids:
        return
    try:
        d = _injected_dir(root_path, run_id)
        d.mkdir(parents=True, exist_ok=True)
        (d / f"{_safe(step_key)}.json").write_text(json.dumps(list(skill_ids)), encoding="utf-8")
    except Exception:
        logger.debug("v2: record_injected_skills failed", exc_info=True)


def _read_injected(root_path: Path, run_id: str, step_key: str) -> List[str]:
    try:
        f = _injected_dir(root_path, run_id) / f"{_safe(step_key)}.json"
        if f.exists():
            data = json.loads(f.read_text(encoding="utf-8"))
            return [str(x) for x in data] if isinstance(data, list) else []
    except Exception:
        logger.debug("v2: _read_injected failed", exc_info=True)
    return []


def attribute_step_outcome(ll, root_path: Path, run_id: str, step_key: str, completed: bool) -> int:
    """Local-learnings variant (Phase 2): record_application against the DB store.
    Retained as a tested utility; the v2 integration path uses the ledger below."""
    n = 0
    for sid in _read_injected(root_path, run_id, step_key):
        try:
            ll.record_application(sid, completed=completed)
            n += 1
        except Exception:
            logger.debug("v2: record_application failed for {}", sid, exc_info=True)
    return n


# ---------------------------------------------------------------------------
# Per-skill outcome ledger (Phase 5) — keyed by HUB skill id
# ---------------------------------------------------------------------------

class SkillOutcomeLedger:
    """File-backed {skill_id: {applied, completed, flagged}} under IOF_ROOT."""

    def __init__(self, root_path: Path) -> None:
        self._path = Path(root_path) / "v2_skill_outcomes.json"

    def _load(self) -> Dict[str, Dict]:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text(encoding="utf-8"))
            except Exception:
                return {}
        return {}

    def _save(self, data: Dict[str, Dict]) -> None:
        try:
            self._path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            logger.debug("v2: ledger save failed", exc_info=True)

    def update(self, skill_id: str, completed: bool, *, at: Optional[str] = None) -> None:
        from datetime import datetime, timezone
        data = self._load()
        rec = data.setdefault(skill_id, {"applied": 0, "completed": 0, "flagged": False})
        rec["applied"] += 1
        if completed:
            rec["completed"] += 1
        rec["last_at"] = at or datetime.now(timezone.utc).isoformat()  # recency for the curator
        self._save(data)

    def last_at(self, skill_id: str) -> Optional[str]:
        return (self._load().get(skill_id) or {}).get("last_at")

    def stats(self, skill_id: str) -> Tuple[int, int, Optional[float]]:
        rec = self._load().get(skill_id) or {}
        applied = int(rec.get("applied", 0))
        completed = int(rec.get("completed", 0))
        rate = (completed / applied) if applied else None
        return applied, completed, rate

    def mark_flagged(self, skill_id: str) -> None:
        data = self._load()
        if skill_id in data:
            data[skill_id]["flagged"] = True
            self._save(data)

    def is_flagged(self, skill_id: str) -> bool:
        return bool((self._load().get(skill_id) or {}).get("flagged"))


# ---------------------------------------------------------------------------
# Hub ingest into the workspace (Phase 3) — draft-inert
# ---------------------------------------------------------------------------

def ingest_hub_skills(root_path: Path, run_id: str, step_key: str, *, role: str, workflow: str, dest: Path) -> List[str]:
    """Sync APPROVED hub skills for (role, workflow) into the agent workspace.

    Only approved skills are returned by the hub, so drafts can never reach an
    agent (the draft-inert invariant).  On hub failure we leave the last-synced
    files in place (the offline cache).  Returns the list of hub skill ids
    written (for outcome attribution).

    LAYOUT — ``skills/<name>/SKILL.md``, the iobot-native directory-per-skill
    shape its ``SkillsLoader`` discovers (``iterdir()`` over ``skills/`` +
    ``<dir>/SKILL.md``). The old flat ``skills/learned/<name>.md`` wrote to a
    location the loader NEVER reads — it saw the ``learned/`` directory, looked
    for ``learned/SKILL.md``, found none, and skipped the lot. So every
    approved skill was materialized where no agent could load it: the injection
    record said "injected", attribution counted it, and it never entered a
    single turn. Found by a live A/B whose "after" run was byte-for-byte
    unchanged. Under ``skills/<name>/`` a scaffolded, hub, or learned skill all
    look identical to the loader, which is the point.
    """
    from ioagentfarm.engine.learning.hub_client import get_hub_client
    from ioagentfarm.engine.learning.v2_models import Scope

    try:
        hub = get_hub_client()
        approved = hub.fetch_approved(Scope(role=role, workflow=workflow))
    except Exception:
        logger.debug("v2: hub fetch failed — keeping offline cache", exc_info=True)
        return []

    from ioagentfarm.engine.learning.skill_scan import scan_skill_md

    skills_root = Path(dest) / "skills"
    skills_root.mkdir(parents=True, exist_ok=True)
    ids: List[str] = []
    for sk in approved:
        # The hub is a TRUST BOUNDARY, not a trusted source: an approved skill
        # is still injected into agent context, and approval is a human act
        # that can be mistaken or an upstream that can be compromised. Refuse a
        # dangerous body at the ingest seam, fail-closed — it is never
        # materialized, so it cannot reach the agent even once. Same scanner as
        # the distiller's draft-time drop (shared code, so the two seams cannot
        # disagree on what "dangerous" means).
        scan = scan_skill_md(sk.skill_md or "")
        if scan.blocked:
            logger.warning(
                "v2: REFUSED approved skill %s (%s) at ingest - security scan "
                "DANGEROUS: %s. Not materialized.", sk.skill_id, sk.skill_name,
                ", ".join(f.category for f in scan.findings
                          if f.severity == "dangerous"))
            continue
        body = sk.skill_md
        if not body.lstrip().startswith("---"):
            body = (
                f"---\nname: {sk.skill_name}\nskill_id: {sk.skill_id}\n"
                f"version: {sk.version or 1}\nalways: true\n---\n\n{body}\n"
            )
        skill_dir = skills_root / _safe(sk.skill_name)
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text(body, encoding="utf-8")
        ids.append(sk.skill_id)

    record_injected_skills(root_path, run_id, step_key, ids)
    logger.info("v2: ingested {} approved hub skills for {}/{}", len(ids), role, workflow)
    return ids


# ---------------------------------------------------------------------------
# Distillation pipeline with throttles (Phases 1/4)
# ---------------------------------------------------------------------------

ReviewerFn = Callable  # (observations, scope, existing_names) -> list[ReviewerProposal]


def _stub_reviewer(observations, scope, existing_names):
    """Deterministic stand-in for the forked LLM reviewer — lets the full
    in-orchestration cycle run without an LLM (IOF_LEARNING_REVIEWER=stub).
    Produces one structured METHOD skill from the session trace."""
    from ioagentfarm.engine.learning.distiller import ReviewerProposal, _method_domain
    from ioagentfarm.engine.learning.v2_models import SkillType

    if not observations:
        return []

    name = f"{scope.role}-method"
    tag = scope.role.replace("_", "-")
    domain = _method_domain(scope.role)

    # Collect up to 4000 chars of trace across observations
    parts = []
    budget = 4000
    for obs in observations:
        chunk = (obs.get("content") or "").strip()
        if chunk:
            parts.append(chunk[:budget])
            budget -= len(parts[-1])
            if budget <= 0:
                break
    trace = "\n\n".join(parts)

    # Split Q and A if trace is in "Q: ...\nA: ..." format
    q_text, a_text = "", trace
    import re as _re
    q_match = _re.match(r'Q:\s*(.*?)\nA:\s*(.*)', trace, _re.DOTALL)
    if q_match:
        q_text = q_match.group(1).strip()[:500]
        a_text = q_match.group(2).strip()[:3000]

    when_to_use = f"When answering questions like: {q_text[:300]}" if q_text else f"When performing {scope.role} analysis in {scope.workflow} workflow"

    thoughts = (
        f"Captured from {scope.role} session in {scope.workflow} workflow. "
        f"Pattern emerged: {domain.split('.')[0].strip()}. "
        f"Stub reviewer — replace with iobot reviewer for LLM-quality extraction."
    )

    body = (
        f"---\nname: {name}\n"
        f"description: Transferable {domain.split(':')[0].strip()} method observed in {scope.role}\n"
        f"version: \"1.0.0\"\ntags: [{tag}]\n"
        f"thoughts: \"{thoughts}\"\n---\n\n"
        f"## When to use\n{when_to_use}\n\n"
        f"## Approach\n"
        f"The following approach was observed in this session. Steps to replicate:\n\n"
        f"1. Understand the question domain: {q_text[:150] if q_text else 'Identify query intent'}\n"
        f"2. Identify relevant data entities and schemas from the catalog.\n"
        f"3. Decompose into sub-queries if cross-pillar or multi-entity.\n"
        f"4. Apply filters, joins, and aggregations as observed below.\n"
        f"5. Synthesize results with caveats (N size, data freshness, confidence).\n\n"
        f"Observed execution trace:\n\n{a_text}\n\n"
        f"## Key patterns\n"
        f"- Domain: {domain}\n"
        f"- Workflow: {scope.workflow}\n"
        f"- Role: {scope.role}\n"
        f"- Observations count: {len(observations)}\n\n"
        f"## Pitfalls\n"
        f"- Stub reviewer output — body contains raw session trace. "
        f"Set IOF_LEARNING_REVIEWER=iobot for LLM-distilled, generic skill content.\n"
        f"- Verify no domain-specific data (product names, numbers) leaked into Key patterns.\n"
    )
    return [ReviewerProposal(skill_name=name, skill_md=body, skill_type=SkillType.METHOD, thoughts=thoughts)]


def get_reviewer() -> Optional[ReviewerFn]:
    """Resolve the distiller's reviewer. DEFAULT (unset): the production
    ``iobot`` reviewer — activating v2 is one decision, not two, so the
    default posture authors as well as attributes. ``stub`` for tests;
    ``off`` disables authoring while keeping attribution.

    ``iobot`` is the documented explicit value — the public surface is iobot
    everywhere a user types a name.
    """
    mode = os.environ.get("IOF_LEARNING_REVIEWER", "").strip().lower()
    if mode == "stub":
        return _stub_reviewer
    if mode in ("off", "none", "0", "disabled"):
        return None
    if mode in ("", "iobot"):
        from ioagentfarm.engine.learning.distiller import iobot_reviewer_fn
        try:
            return iobot_reviewer_fn()
        except NotImplementedError:
            logger.info("v2: runtime reviewer not yet wired; distillation skipped")
            return None
    logger.warning("IOF_LEARNING_REVIEWER=%r not recognised - authoring off "
                   "(valid: iobot, stub, off)", mode)
    return None


def _submit_count_path(root_path: Path, run_id: str) -> Path:
    return _injected_dir(root_path, run_id) / "_submit_counts.json"


def _under_cap(root_path: Path, run_id: str, scope_key: str, n: int) -> int:
    """Return how many of *n* new submissions are allowed under the per-scope cap."""
    cap = _submit_cap()
    p = _submit_count_path(root_path, run_id)
    counts = {}
    if p.exists():
        try:
            counts = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            counts = {}
    used = int(counts.get(scope_key, 0))
    allowed = max(0, cap - used)
    take = min(n, allowed)
    counts[scope_key] = used + take
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(counts), encoding="utf-8")
    except Exception:
        pass
    return take


def _recurrence_k() -> int:
    try:
        return max(1, int(os.environ.get("IOF_LEARNING_RECURRENCE_K", "2")))
    except ValueError:
        return 2


def gated_distill(root_path: Path, scope, trace: str, *, sig_trace: "str | None" = None,
                  hub=None, reviewer_fn=None, descriptor_fn=None, run_id: str = "chat") -> dict:
    """Novelty + recurrence gate in front of authoring. A method is authored ONLY
    when a genuinely new approach RECURS (>= K) — covered approaches reinforce the
    existing method, one-offs wait. The population-explosion guard.

    sig_trace: if provided, use this (instead of trace) for novelty signature
    computation. Allows the caller to use a stable Q-only string for recurrence
    detection while passing the full Q+A as trace for the distiller.

    run_id: rate-cap bucket. Pass a date-stamped id for the always-on chat path
    (e.g. "chat-2026-06-17") so the cap resets daily instead of accumulating forever.

    Returns {decision: covered|pending|author, refs: [...]}."""
    decision = gate_decision(root_path, scope, trace, sig_trace=sig_trace, hub=hub,
                             descriptor_fn=descriptor_fn)
    if decision != "author":
        return {"decision": decision, "refs": []}
    refs = run_distillation(root_path, run_id, "session", scope=scope,
                            observations=[{"step_key": "session", "content": trace}],
                            reviewer_fn=reviewer_fn or get_reviewer(), hub=hub)
    return {"decision": "author", "refs": refs}


def gate_decision(root_path: Path, scope, trace: str, *, sig_trace: "str | None" = None,
                  hub=None, descriptor_fn=None) -> str:
    """The novelty + recurrence DECISION alone - covered | pending | author.

    Cheap and local (a signature over the trace, a file of pending clusters,
    the approved skills' signatures); no model call. Split out so a caller
    can take the expensive authoring step somewhere else - the workflow
    finalizer runs it in a detached process, like memory consolidation.
    """
    from ioagentfarm.engine.learning.novelty import (
        extract_signature, extract_skill_signature, NoveltyGate)
    from ioagentfarm.engine.learning.hub_client import get_hub_client
    hub = hub or get_hub_client()
    try:
        existing = [extract_skill_signature(s.skill_md) for s in hub.fetch_approved(scope)]
    except Exception:
        existing = []
    sig = extract_signature(sig_trace or trace, descriptor_fn=descriptor_fn)
    decision = NoveltyGate(root_path, recurrence_k=_recurrence_k()).decide(sig, existing)
    if decision != "author":
        logger.info("novelty gate: {} for {} — no draft", decision, scope.key())
    return decision


def run_distillation(root_path: Path, run_id: str, step_key: str, *, scope, observations, reviewer_fn, hub=None) -> list:
    """Author -> throttle -> submit. Returns the list of SubmissionRefs."""
    if reviewer_fn is None or not observations:
        return []
    from ioagentfarm.engine.learning.distiller import Distiller
    from ioagentfarm.engine.learning.hub_client import get_hub_client
    from ioagentfarm.engine.learning.v2_models import EvidenceBundle, SubmissionAction

    hub = hub or get_hub_client()
    try:
        existing = hub.fetch_approved(scope)
    except Exception:
        existing = []
    existing_names = {s.skill_name for s in existing}

    drafts = Distiller(reviewer_fn).distill(observations, scope, hub_existing=existing)

    # --- Phase 4 throttles ---
    seen_names: set = set()
    kept = []
    for d in drafts:
        if d.action == SubmissionAction.NEW and d.skill_name in existing_names:
            logger.info("v2: drop new draft '{}' — name already approved (should be refine)", d.skill_name)
            continue
        if d.skill_name in seen_names:  # batch dedup
            continue
        seen_names.add(d.skill_name)
        # attach evidence on refines (the target has a track record)
        if d.action == SubmissionAction.REFINE and d.target_skill_id:
            applied, _c, rate = SkillOutcomeLedger(root_path).stats(d.target_skill_id)
            if applied:
                d.evidence = EvidenceBundle(applications=applied, completion_rate=rate)
        kept.append(d)

    # rate cap only applies to NEW submissions (refines are bounded by existing skills)
    new_drafts = [d for d in kept if d.action == SubmissionAction.NEW]
    refine_drafts = [d for d in kept if d.action == SubmissionAction.REFINE]
    take = _under_cap(root_path, run_id, scope.key(), len(new_drafts))
    if take < len(new_drafts):
        logger.info("v2: rate cap dropped {} new submission(s) for {}", len(new_drafts) - take, scope.key())
    to_submit = refine_drafts + new_drafts[:take]

    refs = []
    for d in to_submit:
        try:
            refs.append(hub.submit_draft(d))
        except Exception:
            logger.info("v2: submit_draft failed for '{}'", d.skill_name, exc_info=True)
    if refs:
        logger.info("v2: submitted {} draft(s) for {}", len(refs), scope.key())
    return refs


# ---------------------------------------------------------------------------
# Step-finalized handler (Phases 2/5) — outcome ledger + degradation telemetry
# ---------------------------------------------------------------------------

def on_step_finalized(root_path: Path, run_id: str, step_key: str, completed: bool, *, hub=None) -> None:
    """Attribute the step's outcome to the injected hub skills, then flag any
    skill that has degraded below threshold for refine (Phase 5)."""
    ids = _read_injected(root_path, run_id, step_key)
    if not ids:
        return
    ledger = SkillOutcomeLedger(root_path)
    threshold, min_n = _degrade_threshold(), _degrade_min_samples()
    hub_client = None
    for sid in ids:
        ledger.update(sid, completed)
        applied, _c, rate = ledger.stats(sid)
        if rate is not None and applied >= min_n and rate < threshold and not ledger.is_flagged(sid):
            if hub_client is None:
                from ioagentfarm.engine.learning.hub_client import get_hub_client
                hub_client = hub or get_hub_client()
            try:
                hub_client.report_telemetry(
                    sid,
                    {"applications": applied, "completion_rate": round(rate, 4),
                     "flag": "refine", "reason": "degradation_below_threshold"},
                )
                ledger.mark_flagged(sid)
                logger.info("v2: flagged skill {} for refine (rate={:.2f} over {})", sid, rate, applied)
            except Exception:
                logger.debug("v2: degradation telemetry failed for {}", sid, exc_info=True)
