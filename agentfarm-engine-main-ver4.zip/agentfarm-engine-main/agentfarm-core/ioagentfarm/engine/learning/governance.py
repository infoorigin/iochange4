"""Human review of learning drafts — the interim steward workflow.

The learning pipeline is draft-inert: an authored skill sits as a DRAFT until a
person approves it, and only then does an agent ever see it. The enforcement is
solid; what was missing was a way for that person to DO the review without
hand-dropping JSON or curling an endpoint. This module is that surface, driven
by ``aicore learning pending|show|approve|reject``.

Backend-aware, because "where drafts live" differs by hub:

* ``stub`` (default) — drafts are files in ``<IOF_ROOT>/hub_outbox/sub_*.json``;
  approval writes an ``ApprovedSkill`` into the inbox (``inbox_base()``, which
  ``IOF_LEARNING_INBOX_DIR`` can repoint at a git repo) and moves the draft to
  ``hub_reviewed/``.
* ``http`` (temp_hub) — drafts and governance are the temp_hub's own
  ``/hub/skills/all`` + ``/approve`` + ``/reject`` endpoints.

Every decision is appended to ``<IOF_ROOT>/hub_audit.jsonl`` — who, when, which
skill, the verdict and (for a git inbox) the commit — so the approval trail
survives regardless of backend. The security scan runs again at review time so
a steward never approves blind, and a DANGEROUS draft cannot be approved at
all.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from loguru import logger

from ioagentfarm.engine.learning.hub_client import _outbox_dir, inbox_base
from ioagentfarm.engine.learning.skill_scan import scan_skill_md


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", name or "skill")


@dataclass
class DraftRecord:
    """One pending draft, normalized across backends for the review UI."""
    ident: str                       # what approve/reject addresses
    skill_name: str
    skill_type: str
    scope_role: str
    scope_workflow: str
    action: str                      # new | refine
    skill_md: str
    thoughts: str
    evidence: Dict[str, Any]
    security_scan: Dict[str, Any]
    source_path: Optional[str] = None
    #: The tenant the draft was distilled under; None on legacy drafts, which
    #: only a platform admin's unscoped view lists (see ``pending``).
    workspace_code: Optional[str] = None

    def to_dict(self) -> dict:
        d = dict(self.__dict__)
        return d


# ─────────────────────────────────────────────────────────────────────────────
# audit
# ─────────────────────────────────────────────────────────────────────────────

def _audit_path() -> Path:
    return Path(os.environ.get("IOF_ROOT", ".iof")) / "hub_audit.jsonl"


def _audit(entry: Dict[str, Any]) -> None:
    entry = {"at": _now(), **entry}
    p = _audit_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")


def audit_log(limit: int = 50) -> List[Dict[str, Any]]:
    p = _audit_path()
    if not p.exists():
        return []
    rows = [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
    return rows[-limit:]


# ─────────────────────────────────────────────────────────────────────────────
# backend detection
# ─────────────────────────────────────────────────────────────────────────────

def _backend() -> str:
    return os.environ.get("IOF_LEARNING_HUB", "stub").strip().lower()


# ─────────────────────────────────────────────────────────────────────────────
# pending / show
# ─────────────────────────────────────────────────────────────────────────────

def _draft_from_dict(d: Dict[str, Any], *, ident: str, source_path: Optional[str] = None) -> DraftRecord:
    scope = d.get("scope") or {}
    scan = d.get("security_scan") or scan_skill_md(d.get("skill_md", "")).to_dict()
    return DraftRecord(
        ident=ident,
        skill_name=d.get("skill_name", "?"),
        skill_type=str(d.get("skill_type", "method")),
        scope_role=scope.get("role", "?"),
        scope_workflow=scope.get("workflow", "?"),
        action=str(d.get("action", "new")),
        skill_md=d.get("skill_md", ""),
        thoughts=d.get("thoughts") or "",
        evidence=d.get("evidence") or {},
        security_scan=scan,
        source_path=source_path,
        workspace_code=d.get("workspace_code") or None,
    )


def pending(workspace: Optional[str] = None,
            include_unscoped: bool = True) -> List[DraftRecord]:
    """Every draft awaiting a decision, normalized.

    *workspace* filters to one tenant's drafts. Legacy drafts predate the
    workspace stamp and carry ``workspace_code=None`` — they are listed only
    when *include_unscoped* is true, which the Studio proxy grants to
    platform admins alone: an unscoped draft belongs to nobody provably, so
    no single tenant's steward may claim or approve it by default.
    """
    if _backend() == "http":
        from ioagentfarm.engine.learning.hub_client import HttpHubClient
        cli = HttpHubClient()
        resp = cli._client.get("/hub/skills/all")
        resp.raise_for_status()
        out = []
        for rec in resp.json().get("skills", []):
            if rec.get("status") == "draft":
                ident = rec.get("submission_id") if rec.get("action") == "refine" else rec.get("skill_id")
                out.append(_draft_from_dict(rec, ident=str(ident)))
    else:
        # stub: outbox files (exclude telemetry sidecars)
        out = []
        for f in sorted(_outbox_dir().glob("sub_*.json")):
            if f.name.startswith("telemetry_"):
                continue
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                logger.debug("governance: unreadable draft {}", f, exc_info=True)
                continue
            out.append(_draft_from_dict(d, ident=f.stem, source_path=str(f)))
    if workspace is not None:
        out = [r for r in out
               if r.workspace_code == workspace
               or (include_unscoped and r.workspace_code is None)]
    elif not include_unscoped:
        out = [r for r in out if r.workspace_code is not None]
    return out


def show(ident: str) -> Optional[DraftRecord]:
    for d in pending():
        if d.ident == ident:
            return d
    return None


# ─────────────────────────────────────────────────────────────────────────────
# approve / reject
# ─────────────────────────────────────────────────────────────────────────────

class ReviewError(RuntimeError):
    pass


def _reviewed_dir() -> Path:
    d = Path(os.environ.get("IOF_ROOT", ".iof")) / "hub_reviewed"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _git(args: List[str], cwd: Path) -> Optional[str]:
    try:
        r = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True,
                           text=True, timeout=30)
        if r.returncode != 0:
            logger.debug("git {} failed: {}", args, r.stderr.strip())
            return None
        return r.stdout.strip()
    except Exception:
        logger.debug("git {} errored", args, exc_info=True)
        return None


def _is_git_repo(path: Path) -> bool:
    return _git(["rev-parse", "--is-inside-work-tree"], path) == "true"


def approve(ident: str, *, approver: str, commit: bool = False,
            note: str = "") -> Dict[str, Any]:
    """Approve a draft. Fail-closed on a DANGEROUS scan — a steward cannot
    approve a skill the scanner blocks, whatever the backend.

    On a git-backed inbox with ``commit=True``, the approved file is committed
    with the approver in the message — the reviewed-PR audit trail."""
    rec = show(ident)
    if rec is None:
        raise ReviewError(f"no pending draft addressed by {ident!r}")

    scan = scan_skill_md(rec.skill_md)
    if scan.blocked:
        _audit({"event": "approve_refused", "ident": ident, "approver": approver,
                "skill_name": rec.skill_name, "workspace": rec.workspace_code,
                "reason": "security_scan_dangerous",
                "findings": [f.to_dict() for f in scan.findings if f.severity == "dangerous"]})
        raise ReviewError(
            f"REFUSED: {rec.skill_name} is DANGEROUS "
            f"({', '.join(f.category for f in scan.findings if f.severity == 'dangerous')}) "
            f"- it cannot be approved. Reject it.")

    if _backend() == "http":
        from ioagentfarm.engine.learning.hub_client import HttpHubClient
        cli = HttpHubClient()
        resp = cli._client.post(f"/hub/skills/{ident}/approve")
        resp.raise_for_status()
        body = resp.json()
        _audit({"event": "approve", "ident": ident, "approver": approver,
                "skill_name": rec.skill_name, "workspace": rec.workspace_code,
                "backend": "http",
                "skill_id": body.get("skill_id"), "note": note})
        return {"status": "approved", "skill_id": body.get("skill_id"), "backend": "http"}

    # stub: mint an ApprovedSkill into the inbox.
    from ioagentfarm.engine.learning.v2_models import ApprovedSkill, Scope
    skill_id = f"sk_{_safe(rec.skill_name)}"
    approved = ApprovedSkill(
        skill_id=skill_id, skill_name=rec.skill_name,
        scope=Scope(role=rec.scope_role, workflow=rec.scope_workflow),
        skill_md=rec.skill_md, version="1", approved_at=_now())
    scope_dir = inbox_base() / rec.scope_role / rec.scope_workflow
    scope_dir.mkdir(parents=True, exist_ok=True)
    target = scope_dir / f"{skill_id}.json"
    target.write_text(approved.model_dump_json(indent=2), encoding="utf-8")

    committed = None
    inbox = inbox_base()
    if commit and _is_git_repo(inbox):
        rel = str(target.relative_to(inbox)) if target.is_relative_to(inbox) else str(target)
        _git(["add", rel], inbox)
        msg = (f"learning: approve {rec.skill_name} "
               f"({rec.scope_role}::{rec.scope_workflow})\n\n"
               f"Approver: {approver}\nSkill-Id: {skill_id}\n"
               f"Security-Scan: {scan.verdict}\n" + (f"Note: {note}\n" if note else ""))
        if _git(["commit", "-m", msg], inbox) is not None:
            committed = _git(["rev-parse", "HEAD"], inbox)

    # move the draft out of the pending queue
    if rec.source_path:
        src = Path(rec.source_path)
        if src.exists():
            src.replace(_reviewed_dir() / f"{ident}.approved.json")

    _audit({"event": "approve", "ident": ident, "approver": approver,
            "skill_name": rec.skill_name, "workspace": rec.workspace_code,
            "backend": "stub", "skill_id": skill_id,
            "scope": f"{rec.scope_role}::{rec.scope_workflow}",
            "security_scan": scan.verdict, "inbox": str(inbox),
            "commit": committed, "note": note})
    return {"status": "approved", "skill_id": skill_id, "backend": "stub",
            "inbox": str(inbox), "commit": committed}


def reject(ident: str, *, approver: str, reason: str = "") -> Dict[str, Any]:
    rec = show(ident)
    if rec is None:
        raise ReviewError(f"no pending draft addressed by {ident!r}")

    if _backend() == "http":
        from ioagentfarm.engine.learning.hub_client import HttpHubClient
        cli = HttpHubClient()
        resp = cli._client.post(f"/hub/skills/{ident}/reject")
        resp.raise_for_status()
    elif rec.source_path:
        src = Path(rec.source_path)
        if src.exists():
            src.replace(_reviewed_dir() / f"{ident}.rejected.json")

    _audit({"event": "reject", "ident": ident, "approver": approver,
            "skill_name": rec.skill_name, "workspace": rec.workspace_code,
            "backend": _backend(), "reason": reason})
    return {"status": "rejected", "ident": ident}
