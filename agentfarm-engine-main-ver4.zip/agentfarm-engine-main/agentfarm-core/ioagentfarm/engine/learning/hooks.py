"""Thin façade for the learning subsystem — the ONLY surface the rest of
ioagentfarm calls. Every entry point here is self-contained: it does its own
gating, store-building, and best-effort error handling, so each call-site is a
single line and carries no learning logic.

Call-sites:
  * cli_orchestration.run_step      -> provision_workspace()
  * cli_orchestration._finalize_step-> finalize_step()
  * web.app AgentPool.get           -> compile_global_prefs()
  * web.app adhoc_chat              -> inject_prefs()
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from loguru import logger


# ---------------------------------------------------------------------------
# Workflow hooks (gated by IOF_LEARNING_V2)
# ---------------------------------------------------------------------------

def provision_workspace(root_path, run_id, step_key, *, role, workflow, dest) -> None:
    """Provision learned skills into a step's workspace. v2: ingest approved hub
    skills (drafts inert). v1 (default): compile DB skills + observations into
    MEMORY.md. Best-effort."""
    try:
        from ioagentfarm.engine.learning import v2_integration as _v2
        if _v2.v2_enabled():
            _v2.ingest_hub_skills(root_path, run_id, step_key, role=role, workflow=workflow, dest=dest)
            return
        # v1 default behaviour
        from ioagentfarm.cli import _learning_lifecycle
        ll = _learning_lifecycle(root_path)
        ll.compile_for_workspace(role=role, workflow=workflow, dest=dest)
        memory_md = ll.compile_memory_md(role=role, workflow=workflow, include_skills=False)
        if memory_md:
            memory_dir = Path(dest) / "memory"
            memory_dir.mkdir(parents=True, exist_ok=True)
            memory_file = memory_dir / "MEMORY.md"
            existing = memory_file.read_text(encoding="utf-8") if memory_file.exists() else ""
            memory_file.write_text(memory_md + ("\n\n" + existing if existing else ""), encoding="utf-8")
            from ioagentfarm.engine.workspaces import enforce_memory_cap
            enforce_memory_cap(memory_file)
    except Exception:
        logger.debug("learning: provision_workspace skipped", exc_info=True)


def _index_for_recall(root_path, run_id, step_key, *, role, workflow, output_text) -> None:
    """Index a completed step's output for cross-run recall (iof-recall).

    Best-effort and scope-isolated by (role, workflow). This keeps the FTS
    index warm incrementally so `iof-recall` answers without a `--reindex`
    on the common path; the backfill covers history from before v2. The
    corpus is step OUTPUT (a durable run artifact), never agent memory - so
    recall carries no pollution risk: nothing here feeds a prompt on its own.
    """
    text = (output_text or "").strip()
    if not text:
        return
    try:
        import os
        from ioagentfarm.engine.db import make_adapter
        from ioagentfarm.engine.learning.recall_fts import FtsRecall
        url = (os.environ.get("IOF_DATABASE_URL") or "").strip() or \
            f"sqlite:///{Path(root_path) / 'state.db'}"
        fts = FtsRecall(make_adapter(url))
        fts.init()
        fts.index(f"{run_id}:{step_key}", f"{role}::{workflow}", text[:4000])
    except Exception:
        logger.debug("recall: incremental index skipped", exc_info=True)


def _author_step_method(root_path, run_id, step_key, scope, trace, reviewer_fn) -> None:
    """The reviewer (model) call, OFF the finalizer's critical path.

    `run-step` blocks the agent driver until it exits, and the reviewer call
    measured 10-17s whenever the gate said `author`. Same shape as memory
    consolidation: the trace is written beside the run and a detached
    `aicore learning distill <file>` authors from it. The stub reviewer
    (tests, the chaos harness) runs inline - it costs nothing and a test
    wants the draft on the spot.
    """
    from ioagentfarm.engine.learning import v2_integration as _v2
    if reviewer_fn is _v2._stub_reviewer:
        _v2.run_distillation(root_path, run_id, step_key, scope=scope,
                             observations=[{"step_key": step_key, "content": trace}],
                             reviewer_fn=reviewer_fn)
        return
    import json
    import subprocess
    import sys
    work = Path(root_path) / "instances" / run_id / "v2_injected"
    work.mkdir(parents=True, exist_ok=True)
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in step_key)
    job = work / f"distill_{safe}.json"
    job.write_text(json.dumps({
        "root": str(root_path), "run_id": run_id, "step_key": step_key,
        "role": scope.role, "workflow": scope.workflow, "trace": trace,
    }), encoding="utf-8")
    log = open(work / "distill.log", "ab")  # noqa: SIM115 - handed to the child
    argv = [sys.executable, "-m", "ioagentfarm.cli", "learning", "distill", str(job)]
    kwargs = {"stdout": log, "stderr": subprocess.STDOUT,
              "stdin": subprocess.DEVNULL, "close_fds": True}
    if os.name == "nt":
        kwargs["creationflags"] = 0x00000200 | 0x00000008  # NEW_PROCESS_GROUP | DETACHED
    else:
        kwargs["start_new_session"] = True
    try:
        proc = subprocess.Popen(argv, env=dict(os.environ), **kwargs)
        logger.info("learning: authoring for {}/{} detached (pid {})", run_id, step_key, proc.pid)
    finally:
        log.close()


def author_from_job(job_path) -> int:
    """The detached half: read the job file, author, submit. Returns the
    number of drafts submitted. Used by `aicore learning distill`."""
    import json
    from ioagentfarm.engine.learning import v2_integration as _v2
    from ioagentfarm.engine.learning.v2_models import Scope
    job = Path(job_path)
    data = json.loads(job.read_text(encoding="utf-8"))
    refs = _v2.run_distillation(
        Path(data["root"]), data["run_id"], data["step_key"],
        scope=Scope(role=data["role"], workflow=data["workflow"]),
        observations=[{"step_key": data["step_key"], "content": data["trace"]}],
        reviewer_fn=_v2.get_reviewer())
    try:
        job.unlink()
    except OSError:
        pass
    return len(refs)


def memory_paused() -> bool:
    """True unless the LEGACY v1 pipeline is explicitly on.

    MEMORY.md is v1's artifact — the accumulation channel (observation
    compile, persist-back, in-session writes) exists only for the
    deprecated pipeline, so it is paused in BOTH of the normal states:
    v2 active (the default) and learning off (``IOF_LEARNING_V2=0``).
    Only the explicit two-key legacy opt-in (``IOF_LEARNING_V2=0`` +
    ``IOF_LEARNING_V1=1``) unpauses it, and that combination is scheduled
    for removal with v1 itself.
    """
    from ioagentfarm.engine.learning import v2_integration as _v2
    return not (_v2.v1_enabled() and not _v2.v2_enabled())


def finalize_step(root_path, run_id, step_key, *, role, workflow, step_status,
                  output_text, store=None, learning_disabled=False) -> None:
    """After a step: ONE dispatch across the three learning states.

    * ``learning: disabled`` (workflow opt-out) -> nothing runs, ever.
    * v2 on (the DEFAULT)     -> attribute outcome to injected hub skills
      (+ degradation telemetry) and distill candidates into hub drafts.
    * v2 off, v1 NOT opted in -> learning entirely OFF. Opting out of v2
      never silently resurrects the deprecated pipeline.
    * v2 off + IOF_LEARNING_V1=1 -> the LEGACY v1 path: observation into
      the learning log + feedback card. Explicit, two keys, scheduled for
      removal with v1.
    """
    if not role:
        return
    if learning_disabled:
        return
    try:
        from ioagentfarm.engine.learning import v2_integration as _v2
        completed = (step_status == "done")
        if _v2.v2_enabled():
            if _v2.v1_enabled():
                logger.warning(
                    "IOF_LEARNING_V1=1 ignored - v2 is active and the two "
                    "generations never run together (set IOF_LEARNING_V2=0 "
                    "as well if you truly need the legacy pipeline)")
            if completed:
                _index_for_recall(root_path, run_id, step_key,
                                  role=role, workflow=workflow,
                                  output_text=output_text)
            _v2.on_step_finalized(root_path, run_id, step_key, completed)
            if completed:
                # THROUGH THE GATE, like the chat path. This called
                # run_distillation directly, so every completed step paid a
                # synchronous reviewer call - measured 13s and 29s on a
                # two-step run, inside run-step, which the agent driver
                # blocks on - and authored a "method" from a single
                # occurrence. Recurrence-gated authoring is the documented
                # contract; the workflow path just never went through it.
                from ioagentfarm.engine.learning.v2_models import Scope
                _reviewer = _v2.get_reviewer()
                _trace = (output_text or "")[:4000]
                if _reviewer is not None and _trace.strip():
                    _scope = Scope(role=role, workflow=workflow)
                    if _v2.gate_decision(root_path, _scope, _trace) == "author":
                        _author_step_method(root_path, run_id, step_key, _scope,
                                            _trace, _reviewer)
            return
        # v2 is off. The LEGACY pipeline runs only on its own explicit key —
        # otherwise learning is entirely off, which is the intended meaning
        # of IOF_LEARNING_V2=0.
        if not _v2.v1_enabled():
            return
        if not completed:
            return
        import json as _json
        from ioagentfarm.cli import _learning_lifecycle
        ll = _learning_lifecycle(root_path)
        ll.append_observation(
            run_id=run_id, step_key=step_key, role=role, workflow=workflow,
            content=(output_text or "")[:4000])
        if store is not None:
            card_payload = ll.build_feedback_card_payload(
                run_id=run_id, step_key=step_key, role=role, workflow=workflow,
                output_snippet=(output_text or "")[:2000])
            store.insert_message(
                run_id=run_id, step_key=step_key, source="system", role=role,
                content=_json.dumps(card_payload), msg_type="feedback_card")
    except Exception:
        logger.debug("learning: finalize_step skipped", exc_info=True)


# ---------------------------------------------------------------------------
# Preference hooks (gated by IOF_PREFERENCES_DB)
# ---------------------------------------------------------------------------

_PREF_STORE = None


def _prefs_enabled() -> bool:
    return os.environ.get("IOF_PREFERENCES_DB", "").strip().lower() in ("1", "true", "on", "yes")


def _pref_store():
    """Lazy shared preference store — None unless IOF_PREFERENCES_DB is on."""
    global _PREF_STORE
    if not _prefs_enabled():
        return None
    if _PREF_STORE is None:
        try:
            from ioagentfarm.engine.db import make_adapter
            from ioagentfarm.engine.learning.preference_store_db import DbPreferenceStore
            root = Path(os.getenv("IOF_ROOT", ".iof")).resolve()
            url = (os.getenv("IOF_PREFERENCES_DB_URL") or os.getenv("IOF_DATABASE_URL")
                   or f"sqlite:///{root}/state.db")
            store = DbPreferenceStore(make_adapter(url))
            store.init()
            _PREF_STORE = store
        except Exception:
            logger.debug("learning: preference store init failed", exc_info=True)
            return None
    return _PREF_STORE


def compile_global_prefs(workspace) -> None:
    """Compile GLOBAL prefs into a workspace USER.md (cached prefix) at warmup."""
    try:
        store = _pref_store()
        if store is not None:
            from ioagentfarm.engine.learning.preference_store_db import compile_global_into_userdoc
            compile_global_into_userdoc(store, workspace_dir=workspace)
    except Exception:
        logger.debug("learning: compile_global_prefs skipped", exc_info=True)


def _v2_on() -> bool:
    # ONE definition of the gate - v2_integration.v2_enabled (default ON).
    from ioagentfarm.engine.learning.v2_integration import v2_enabled
    return v2_enabled()


def _extract_distill_answer(content: str) -> str:
    """Return distillable text from an agent response.

    For v1 JSON envelopes (any federation/query agent — e.g. queryngine and
    domain analysts all return ``{"schema": "v1", ...}``):
      - Extract ``insight`` + ``answer`` fields (interpretive prose reasoning).
      - Discard ``data`` / ``sub_agents`` / ``evidence`` — raw tables, SQL, and
        row-level numbers are findings, not methods.

    For plain prose responses: return content unchanged.
    Returns ``""`` when there is nothing worth distilling (empty insight + answer).

    Why insight not full JSON: feeding the full v1 envelope (with data rows, SQL,
    column lists) to the distiller LLM causes it to copy findings verbatim into
    skill_md ("Lemon -7%, Fig -5.5%...") and mislabel them as methods. The
    insight field contains the interpretive reasoning the distiller actually needs.
    """
    import re as _re, json as _json
    m = _re.search(r'```json\s*(\{.*?\})\s*```', content, _re.DOTALL)
    if not m:
        return content
    try:
        obj = _json.loads(m.group(1))
    except Exception:
        return content
    if obj.get("schema") != "v1":
        return content
    parts = [p.strip() for p in [obj.get("insight") or "", obj.get("answer") or ""] if (p or "").strip()]
    return "\n\n".join(parts)


def wrap_process_direct(process_direct, role: str):
    """Make method-learning a property of the AGENT, not the caller.

    Wrapping the pooled agent's ``process_direct`` means it learns whenever it
    runs — A2A sub-agent call, direct chat, or run-message — uniformly, because
    learning attaches to the agent's execution, not the invocation surface.
    (Preferences are a USER property and stay at the request surface.) No-op
    unless IOF_LEARNING_V2; returns the original fn untouched when off."""
    v2_val = os.environ.get("IOF_LEARNING_V2", "(unset)")
    if not _v2_on():
        logger.info("learning: wrap_process_direct SKIP role={} IOF_LEARNING_V2={!r}", role, v2_val)
        return process_direct
    logger.info("learning: wrap_process_direct APPLIED role={} IOF_LEARNING_V2={!r}", role, v2_val)
    import functools

    workflow = role  # an always-on agent's learning scope is its own identity

    @functools.wraps(process_direct)
    async def _wrapped(*args, **kwargs):
        logger.info("learning: _wrapped called role={} v2={}", role, os.environ.get("IOF_LEARNING_V2", "(unset)"))
        # inject this agent's approved methods (its tradecraft) before it runs
        if args:
            q = str(args[0])
            args = (inject_methods(role, workflow, q, q),) + tuple(args[1:])
        else:
            q = ""
        result = await process_direct(*args, **kwargs)
        # distill a candidate method from this session (background, best-effort)
        try:
            raw_answer = getattr(result, "content", "") or ""
            logger.info("learning: _wrapped post-run role={} answer_len={}", role, len(raw_answer))
            # For v1 envelopes: extract insight+answer prose (strips data tables,
            # SQL, row numbers). For prose responses: use as-is. Skip if empty.
            distill_answer = _extract_distill_answer(raw_answer)
            logger.info("learning: _wrapped distill_answer_len={} role={}", len(distill_answer), role)
            if distill_answer:
                import re as _re
                q_clean = _re.split(r'\n\n---\n', q, maxsplit=1)[0].strip()
                distill_from_chat(role, workflow, q_clean, distill_answer)
        except Exception:
            logger.info("learning: post-run distill skipped for {}", role, exc_info=True)
        return result

    return _wrapped


def inject_methods(role: str, workflow: str, question: str, content: str) -> str:
    """Prepend the firm-approved analytical METHODS most relevant to *question*
    so the federation APPLIES learned tradecraft. No-op unless IOF_LEARNING_V2.
    Used on the live federation chat path."""
    if not _v2_on():
        return content
    try:
        import re
        from ioagentfarm.engine.learning.hub_client import get_hub_client
        from ioagentfarm.engine.learning.v2_models import Scope
        approved = get_hub_client().fetch_approved(Scope(role=role, workflow=workflow))
        if not approved:
            return content
        qtok = set(re.findall(r"[a-z0-9_]+", (question or "").lower()))

        def overlap(s):
            return len(qtok & set(re.findall(r"[a-z0-9_]+", (s.skill_md or "").lower())))

        top = sorted(approved, key=overlap, reverse=True)
        top = [s for s in top if overlap(s) >= 2][:2]
        if not top:
            return content
        block = ("## Firm-approved analytical methods — APPLY these in your answer\n\n"
                 + "\n\n".join(s.skill_md for s in top))
        logger.info("learning: injected {} approved method(s) into {}/{}", len(top), role, workflow)
        return block + "\n\n---\n\n" + content
    except Exception:
        logger.debug("learning: inject_methods skipped", exc_info=True)
        return content


def distill_from_chat(role: str, workflow: str, question: str, answer: str) -> None:
    """After a federation session, author a candidate method and submit it to the
    hub as a draft — in a BACKGROUND THREAD so it never blocks the response (and
    a fresh event loop is fine for the reviewer's provider call). No-op unless v2."""
    if not _v2_on() or len((answer or "").strip()) < 100:
        return
    # THE QUESTION IS THE USER'S MESSAGE. Logged verbatim at INFO, this put
    # every chat turn into the pod log by a THIRD route, after the runtime's
    # two were closed — and an independent validator recovered a private note
    # from it, from an unrelated thread, by asking the agent to grep the
    # machine. Same rule and same switch as every other conversation surface.
    from ioagentfarm.engine.log_redaction import chat_content_logged, summarize
    _q = (question.replace("\n", " ")[:80] if chat_content_logged()
          else summarize(question or ""))
    logger.info("learning: distill queued role={} q={}", role, _q)

    def _work():
        logger.info("learning: distill_work start role={}", role)
        try:
            from datetime import date as _date
            from ioagentfarm.engine.learning import v2_integration as _v2
            from ioagentfarm.engine.learning.v2_models import Scope
            root = Path(os.getenv("IOF_ROOT", ".iof")).resolve()
            # sig_trace: question only — stable recurrence signal. Answers vary
            # per run (different sub-agent data) so including them produces
            # different structural frozensets for identical questions, defeating
            # the recurrence gate. The question represents the analysis pattern.
            sig_trace = f"Q: {question}"
            # full trace for the distiller LLM (has Q+A context for method authoring)
            trace = f"Q: {question}\nA: {(answer or '')[:3500]}"
            # daily run_id: cap resets each day instead of accumulating forever
            daily_id = f"chat-{_date.today().isoformat()}"
            _v2.gated_distill(root, Scope(role=role, workflow=workflow), trace,
                              sig_trace=sig_trace, run_id=daily_id)
        except Exception:
            logger.info("learning: distill_work failed role={}", role, exc_info=True)

    try:
        import threading
        threading.Thread(target=_work, daemon=True).start()
    except Exception:
        logger.debug("learning: distill thread failed", exc_info=True)


def inject_prefs(user_id: str, content: str) -> str:
    """Prepend the requesting user's USER+GROUP prefs to the message. Returns
    *content* unchanged when disabled or the user has none."""
    try:
        store = _pref_store()
        if store is not None:
            from ioagentfarm.engine.learning.preference_store_db import inject_user_preferences
            return inject_user_preferences(store, user_id, content)
    except Exception:
        logger.debug("learning: inject_prefs skipped", exc_info=True)
    return content
