"""Retrieval upgrade — full-text recall + LLM summarization.

Replaces the IDF `recall.py` for scale and quality (the Hermes "FTS5 + cross-
session summarization" capability, made portable + governed):
  * `FtsRecall` — a DB-backed full-text index over observations.
        SQLite  -> FTS5 virtual table (dev/test)
        Postgres-> tsvector column + GIN (prod)
  * `summarize_recall` — condenses the recalled rows into a brief (injectable
    LLM, like the distiller's reviewer) instead of dumping raw rows.
  * `recall_brief` — search + summarize in one call.

Scope-isolated (a `(role, workflow)` key) so one agent never recalls another's.
"""
from __future__ import annotations

import logging
import re
from contextlib import contextmanager
from typing import Any, Callable, Dict, List, Optional

from ioagentfarm.engine.db import DbAdapter

logger = logging.getLogger(__name__)

_TOKEN = re.compile(r"[A-Za-z0-9_]+")


def _fts_query(text: str) -> str:
    """Sanitize free text into a safe FTS expression. Each token is DOUBLE-QUOTED
    so FTS5 reserved words (AND/OR/NOT) and special chars can never be parsed as
    operators — the robust subset of Hermes' sanitizer (hermes_state.py:3140)."""
    toks = _TOKEN.findall(text or "")
    return " OR ".join(f'"{t}"' for t in toks) if toks else ""


class FtsRecall:
    """Full-text index over observation-like docs, scoped by (role, workflow)."""

    def __init__(self, adapter: DbAdapter) -> None:
        self._db = adapter
        self._sqlite = adapter.placeholder() == "?"

    def _conn(self):
        return self._db.connect()

    @contextmanager
    def _tx(self):
        with self._conn() as con:
            self._db.init_connection(con)
            cur = con.cursor()
            try:
                yield cur
            finally:
                cur.close()

    def _q(self, sql: str) -> str:
        ph = self._db.placeholder()
        return sql if ph == "?" else sql.replace("?", ph)

    def init(self) -> None:
        with self._tx() as cur:
            if self._sqlite:
                cur.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS recall_fts "
                    "USING fts5(doc_id UNINDEXED, scope_key UNINDEXED, content)"
                )
            else:
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS recall_docs ("
                    "doc_id TEXT PRIMARY KEY, scope_key TEXT NOT NULL, content TEXT NOT NULL, "
                    "tsv tsvector)"
                )
                cur.execute("CREATE INDEX IF NOT EXISTS idx_recall_tsv ON recall_docs USING GIN(tsv)")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_recall_scope ON recall_docs(scope_key)")

    def index(self, doc_id: str, scope_key: str, content: str) -> None:
        with self._tx() as cur:
            if self._sqlite:
                cur.execute(self._q("DELETE FROM recall_fts WHERE doc_id=?"), (doc_id,))
                cur.execute(
                    self._q("INSERT INTO recall_fts (doc_id, scope_key, content) VALUES (?, ?, ?)"),
                    (doc_id, scope_key, content),
                )
            else:
                cur.execute(
                    self._q(
                        "INSERT INTO recall_docs (doc_id, scope_key, content, tsv) "
                        "VALUES (?, ?, ?, to_tsvector('english', ?)) "
                        "ON CONFLICT (doc_id) DO UPDATE SET "
                        "scope_key=EXCLUDED.scope_key, content=EXCLUDED.content, tsv=EXCLUDED.tsv"
                    ),
                    (doc_id, scope_key, content, content),
                )

    def index_observations(self, ll, *, role: str, workflow: str, limit: int = 500) -> int:
        """Pull recent observations from the learning log and index them."""
        scope_key = f"{role}::{workflow}"
        obs = ll.get_observations(role=role, workflow=workflow, limit=limit)
        n = 0
        for o in obs:
            doc_id = str(o.get("id") or f"{o.get('run_id','')}:{o.get('step_key','')}:{n}")
            self.index(doc_id, scope_key, str(o.get("content", "")))
            n += 1
        return n

    def search(self, scope_key: str, query: str, limit: int = 8) -> List[Dict[str, Any]]:
        fq = _fts_query(query)
        if not fq:
            return []
        with self._tx() as cur:
            if self._sqlite:
                cur.execute(
                    self._q(
                        "SELECT doc_id, content, bm25(recall_fts) AS rank FROM recall_fts "
                        "WHERE scope_key=? AND recall_fts MATCH ? ORDER BY rank LIMIT ?"
                    ),
                    (scope_key, fq, limit),
                )
            else:
                cur.execute(
                    self._q(
                        "SELECT doc_id, content, ts_rank(tsv, plainto_tsquery('english', ?)) AS rank "
                        "FROM recall_docs WHERE scope_key=? AND tsv @@ plainto_tsquery('english', ?) "
                        "ORDER BY rank DESC LIMIT ?"
                    ),
                    (query, scope_key, query, limit),
                )
            return [dict(r) for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# Summarization (Hermes "cross-session recall via summarization")
# ---------------------------------------------------------------------------

_SUMMARY_SYSTEM = (
    "You condense retrieved prior-session notes into a SHORT brief that helps an "
    "agent answer a related question. Output 2-5 tight bullets of transferable "
    "signal (techniques, pitfalls, what worked). No preamble, no domain numbers, "
    "no fluff. If the notes are irrelevant to the question, output exactly 'NONE'."
)


def _default_complete(system: str, user: str) -> str:
    """One-shot completion on the learning worker loop.

    Shares `distiller._worker_loop` rather than calling `asyncio.run` here,
    for two reasons. `asyncio.run` RAISES from inside a running loop, so this
    could never have been called from the served path at all. And a client
    hit the other half of that mistake next door: a cached client whose
    sockets belonged to a loop `asyncio.run` had already closed, surfacing as
    `RuntimeError: Event loop is closed` behind an `APIConnectionError`.
    """
    import asyncio

    from iobot.config.loader import load_config

    from ioagentfarm.engine.learning.distiller import _worker_loop
    from ioagentfarm.engine.provider_factory import make_provider

    provider = make_provider(load_config())
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": user}]

    async def _call():
        return await provider.chat(messages, max_tokens=600, temperature=0.2)

    resp = asyncio.run_coroutine_threadsafe(_call(), _worker_loop()).result(
        timeout=120)
    return getattr(resp, "content", "") or ""


def summarize_recall(items: List[Dict[str, Any]], query: str, *,
                     complete_fn: Optional[Callable[[str, str], str]] = None) -> str:
    """Condense recalled items into a brief. *complete_fn(system, user)->str* is
    injectable for tests; default calls iobot's provider. Returns '' if no
    items or the model finds nothing relevant."""
    if not items:
        return ""
    cf = complete_fn or _default_complete
    notes = "\n".join(f"- {str(i.get('content',''))[:600]}" for i in items)
    user = f"Question: {query}\n\nRetrieved notes:\n{notes}"
    try:
        out = (cf(_SUMMARY_SYSTEM, user) or "").strip()
    except Exception:
        logger.debug("recall: summarization failed", exc_info=True)
        return ""
    return "" if out.upper().strip() in ("", "NONE") else out


def recall_brief(fts: FtsRecall, scope_key: str, query: str, *,
                 complete_fn: Optional[Callable[[str, str], str]] = None, limit: int = 8) -> str:
    """Search the index and summarize the hits into a brief."""
    return summarize_recall(fts.search(scope_key, query, limit), query, complete_fn=complete_fn)
