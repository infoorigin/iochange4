"""Governed curator — long-term skill-library hygiene.

Ported from Hermes' curator (`agent/curator.py`: `should_run_now` scheduling +
`apply_automatic_transitions` recency lifecycle), adapted to our model:

  * **Recency + outcome** — Hermes transitions on recency alone (active→stale→
    archived by last-use). We add our *outcome* signal (completion-rate
    degradation), so we catch the *failing* skill, not just the *idle* one.
  * **Proposes, never mutates** — Hermes' curator archives/consolidates directly
    (recoverably). Ours emits PROPOSALS (refine / archive / consolidate) that go
    back to the hub for governance. Nothing is auto-deleted; nothing skips the
    human gate. Archive is recoverable (Hermes invariant, kept).
  * **Scheduled, deterministic** — `should_run` mirrors Hermes' gate (run only
    when the last run is older than the interval); `now` is injectable for tests.
  * **Exempt set** — golden/pinned skills bypass all transitions (Hermes pin).
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

DEFAULT_INTERVAL_HOURS = 24 * 7      # weekly (Hermes default)
DEFAULT_STALE_AFTER_DAYS = 30
DEFAULT_ARCHIVE_AFTER_DAYS = 90


def _parse_iso(ts: Optional[str]) -> Optional[datetime]:
    if not ts:
        return None
    try:
        d = datetime.fromisoformat(ts)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# Scheduling gate (port of Hermes should_run_now — deterministic)
# ---------------------------------------------------------------------------

def should_run(state_path: Path, *, now: Optional[datetime] = None,
               interval_hours: int = DEFAULT_INTERVAL_HOURS) -> bool:
    """True if the last run is older than the interval. First call seeds state
    and DEFERS (don't curate on the very first tick) — Hermes' first-run rule."""
    now = now or datetime.now(timezone.utc)
    state_path = Path(state_path)
    state = {}
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception:
            state = {}
    last = _parse_iso(state.get("last_run_at"))
    if last is None:
        _save_state(state_path, {"last_run_at": now.isoformat(), "seeded": True})
        return False
    return (now - last) >= timedelta(hours=interval_hours)


def _save_state(state_path: Path, state: dict) -> None:
    try:
        Path(state_path).parent.mkdir(parents=True, exist_ok=True)
        Path(state_path).write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        logger.debug("curator: state save failed", exc_info=True)


def mark_ran(state_path: Path, *, now: Optional[datetime] = None, summary: str = "") -> None:
    now = now or datetime.now(timezone.utc)
    _save_state(Path(state_path), {"last_run_at": now.isoformat(), "last_summary": summary})


# ---------------------------------------------------------------------------
# Curation report
# ---------------------------------------------------------------------------

@dataclass
class CurationReport:
    scope: str
    checked: int = 0
    refine: List[str] = field(default_factory=list)        # degraded -> propose refine
    stale: List[str] = field(default_factory=list)         # idle past stale window
    archive: List[str] = field(default_factory=list)       # idle past archive window (recoverable)
    consolidate: List[dict] = field(default_factory=list)  # [{keep, absorb:[...], reason}]
    kept: List[str] = field(default_factory=list)

    def summary(self) -> str:
        return (f"checked={self.checked} refine={len(self.refine)} stale={len(self.stale)} "
                f"archive={len(self.archive)} consolidate={len(self.consolidate)} kept={len(self.kept)}")

    def is_empty(self) -> bool:
        return not (self.refine or self.stale or self.archive or self.consolidate)


# ---------------------------------------------------------------------------
# Curator
# ---------------------------------------------------------------------------

class Curator:
    """Reviews a scope's approved hub skills + the outcome ledger and proposes
    refine / archive / consolidate actions. Pure analysis in `run`; governed
    emission in `apply` (telemetry to the hub — never auto-deletes)."""

    def __init__(self, hub, ledger, *,
                 stale_after_days: int = DEFAULT_STALE_AFTER_DAYS,
                 archive_after_days: int = DEFAULT_ARCHIVE_AFTER_DAYS,
                 degrade_threshold: float = 0.5, degrade_min: int = 3,
                 consolidate_threshold: float = 0.6,
                 exempt_skill_ids: Sequence[str] = ()) -> None:
        self._hub = hub
        self._ledger = ledger
        self._stale_days = stale_after_days
        self._archive_days = archive_after_days
        self._degrade_threshold = degrade_threshold
        self._degrade_min = degrade_min
        self._consolidate_threshold = consolidate_threshold
        self._exempt = set(exempt_skill_ids)

    def run(self, scope, *, now: Optional[datetime] = None) -> CurationReport:
        now = now or datetime.now(timezone.utc)
        rep = CurationReport(scope=scope.key() if hasattr(scope, "key") else str(scope))
        try:
            skills = self._hub.fetch_approved(scope)
        except Exception:
            logger.debug("curator: fetch_approved failed", exc_info=True)
            return rep

        stale_cut = now - timedelta(days=self._stale_days)
        arch_cut = now - timedelta(days=self._archive_days)

        for s in skills:
            rep.checked += 1
            sid = s.skill_id
            if sid in self._exempt:                      # golden/pinned bypass
                rep.kept.append(sid)
                continue
            applied, _c, rate = self._ledger.stats(sid)
            # 1) outcome: degraded -> refine (our signal; Hermes lacks it)
            if rate is not None and applied >= self._degrade_min and rate < self._degrade_threshold:
                rep.refine.append(sid)
                continue
            # 2) recency: stale / archive (Hermes signal). Anchor = last use, else
            #    approval time, else now (never archive a brand-new skill).
            anchor = _parse_iso(self._ledger.last_at(sid)) or _parse_iso(s.approved_at) or now
            if anchor <= arch_cut:
                rep.archive.append(sid)
            elif anchor <= stale_cut:
                rep.stale.append(sid)
            else:
                rep.kept.append(sid)

        rep.consolidate = self._find_consolidations(skills)
        return rep

    def _find_consolidations(self, skills) -> List[dict]:
        """Propose merges of near-duplicate skills by Jaccard token overlap —
        robust to corpus size (unlike TF-IDF, which zeroes shared terms with few
        docs). Proposal only — the hub approves the actual merge."""
        import re
        items = [(s.skill_id, set(re.findall(r"[a-z0-9_]+", (s.skill_md or "").lower())))
                 for s in skills if s.skill_id not in self._exempt]
        proposals: List[dict] = []
        absorbed: set = set()
        for i in range(len(items)):
            keep_id, keep_toks = items[i]
            if keep_id in absorbed or not keep_toks:
                continue
            absorb: List[str] = []
            for j in range(i + 1, len(items)):
                jid, jtoks = items[j]
                if jid in absorbed or not jtoks:
                    continue
                jac = len(keep_toks & jtoks) / len(keep_toks | jtoks)
                if jac >= self._consolidate_threshold:
                    absorb.append(jid)
                    absorbed.add(jid)
            if absorb:
                proposals.append({"keep": keep_id, "absorb": absorb,
                                  "reason": f"near-duplicate (jaccard>={self._consolidate_threshold})"})
        return proposals

    def apply(self, report: CurationReport) -> Dict[str, int]:
        """Governed emission — push PROPOSALS to the hub as telemetry. Never
        deletes, never patches directly; the hub/human acts on the proposals."""
        counts = {"refine": 0, "archive": 0, "consolidate": 0}
        for sid in report.refine:
            if self._telemetry(sid, {"flag": "refine", "reason": "curator_degraded"}):
                counts["refine"] += 1
        for sid in report.archive:
            if self._telemetry(sid, {"flag": "archive", "reason": "curator_stale_recoverable"}):
                counts["archive"] += 1
        for c in report.consolidate:
            if self._telemetry(c["keep"], {"flag": "consolidate", "absorb": c["absorb"],
                                           "reason": c["reason"]}):
                counts["consolidate"] += 1
        logger.info("curator applied proposals: %s", counts)
        return counts

    def _telemetry(self, skill_id: str, metrics: dict) -> bool:
        try:
            self._hub.report_telemetry(skill_id, metrics)
            return True
        except Exception:
            logger.debug("curator: telemetry failed for %s", skill_id, exc_info=True)
            return False


# ---------------------------------------------------------------------------
# Scheduled entry point
# ---------------------------------------------------------------------------

def maybe_run_curator(root_path: Path, scope, *, now: Optional[datetime] = None,
                      interval_hours: int = DEFAULT_INTERVAL_HOURS,
                      hub=None, exempt_skill_ids: Sequence[str] = ()) -> Optional[CurationReport]:
    """Run the curator if due (Hermes-style gate). Returns the report, or None
    if not due / disabled. Best-effort."""
    try:
        state_path = Path(root_path) / "curator_state.json"
        if not should_run(state_path, now=now, interval_hours=interval_hours):
            return None
        from ioagentfarm.engine.learning.hub_client import get_hub_client
        from ioagentfarm.engine.learning.v2_integration import SkillOutcomeLedger
        hub = hub or get_hub_client()
        cur = Curator(hub, SkillOutcomeLedger(root_path), exempt_skill_ids=exempt_skill_ids)
        report = cur.run(scope, now=now)
        cur.apply(report)
        mark_ran(state_path, now=now, summary=report.summary())
        logger.info("curator ran for %s: %s", report.scope, report.summary())
        return report
    except Exception:
        logger.debug("curator: maybe_run failed", exc_info=True)
        return None
