"""Deterministic security scan of the LEARNING channel.

An approved skill's body is injected into agent context — a careless or
compromised entry is a prompt-injection vector wearing a governance badge.
This scanner is the Hermes Skills-Hub idea (scan before trust) rebuilt for
this platform's fail-closed discipline: pure regex, no LLM, every finding
names its pattern and excerpt so a hub reviewer sees WHY, and the verdict
tiers decide what happens:

  * ``dangerous`` — blocks. Dropped at draft time, REFUSED at ingest time.
  * ``caution``   — passes, findings attached for the hub reviewer.
  * ``clean``     — passes.

Enforced at BOTH seams (the campaign lesson: every capture-layer pair
shares its code): the distiller drops dangerous drafts before submission,
and ``ingest_hub_skills`` refuses dangerous approved skills before they
materialize — the hub is a trust boundary, not a trusted source.

Deliberately NOT flagged: SQL SELECT/aggregate examples, tool names the
platform ships (``iof-query``, ``vectorfs``), and ``${VAR}`` placeholder
references — methods legitimately teach those. False positives here would
train reviewers to ignore the scan, which costs the thing it is for.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

DANGEROUS = "dangerous"
CAUTION = "caution"
CLEAN = "clean"


@dataclass
class ScanFinding:
    category: str
    severity: str            # dangerous | caution
    excerpt: str             # the matched text, trimmed

    def to_dict(self) -> dict:
        return {"category": self.category, "severity": self.severity,
                "excerpt": self.excerpt}


@dataclass
class ScanResult:
    verdict: str             # dangerous | caution | clean
    findings: List[ScanFinding] = field(default_factory=list)

    @property
    def blocked(self) -> bool:
        return self.verdict == DANGEROUS

    def to_dict(self) -> dict:
        return {"verdict": self.verdict,
                "findings": [f.to_dict() for f in self.findings]}


# ── patterns ────────────────────────────────────────────────────────────────
# Each entry: (category, severity, compiled regex). Order does not matter;
# the worst severity wins the verdict.

#: PROMPT INJECTION - instructions aimed at the MODEL's obedience rather than
#: the task. Exposed by name because the chat guardrails
#: (``engine/guardrails.py``) enforce the SAME vocabulary on an inbound chat
#: turn: one list, so what the learning channel refuses and what the chat
#: surface refuses cannot drift. ``scan_skill_md`` reads it through ``_P``
#: exactly as before; nothing about its verdicts changed.
PROMPT_INJECTION_RE = re.compile(
    r"ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|rules?)"
    r"|disregard\s+(your|the)\s+(instructions?|system\s+prompt)"
    r"|you\s+are\s+no\s+longer\b|do\s+not\s+(tell|inform|reveal\s+to)\s+the\s+user"
    r"|reveal\s+(your|the)\s+system\s+prompt", re.I)
PROMPT_INJECTION_RES = (PROMPT_INJECTION_RE,)

_P = [
    # Destructive shell — a method has no business deleting trees, rewriting
    # permissions, or piping the network into a shell.
    ("destructive_shell", DANGEROUS, re.compile(
        r"\brm\s+(-[a-z]*[rf][a-z]*\s+)+|\bmkfs\b|\bdd\s+if=|\bshutdown\b"
        r"|\bchmod\s+777\b|:\s*\(\s*\)\s*\{.*\};\s*:", re.I)),
    ("pipe_to_shell", DANGEROUS, re.compile(
        r"\b(curl|wget)\b[^\n|]*\|\s*(ba)?sh\b", re.I)),
    # Destructive SQL — teaching an analyst agent to DROP or TRUNCATE is not
    # a method, whatever the label says.
    ("destructive_sql", DANGEROUS, re.compile(
        r"\b(DROP\s+(TABLE|DATABASE|SCHEMA)|TRUNCATE\s+TABLE?|DELETE\s+FROM\b(?![^\n]*WHERE))",
        re.I)),
    # Prompt injection — instructions aimed at the MODEL's obedience rather
    # than the task.
    ("prompt_injection", DANGEROUS, PROMPT_INJECTION_RE),
    # Exfiltration — reading credentials, or sending anything to a network
    # endpoint. A method may NAME a protocol; it may not carry a destination.
    ("credential_access", DANGEROUS, re.compile(
        r"\b(cat|type|read|open)\b[^\n]{0,40}\.(env|pem|key|aws/credentials)\b"
        r"|\bAWS_SECRET|\bAPI[_-]?KEY\s*=", re.I)),
    ("network_destination", CAUTION, re.compile(
        r"https?://[\w.-]+\.[a-z]{2,}", re.I)),
    # Apparent secrets baked into the body.
    ("embedded_secret", DANGEROUS, re.compile(
        r"\bAKIA[0-9A-Z]{16}\b|\bsk-[A-Za-z0-9]{20,}\b"
        r"|\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}", )),
    # Base64 blobs — payloads hide here; a method should never need one.
    ("opaque_blob", CAUTION, re.compile(r"[A-Za-z0-9+/]{80,}={0,2}")),
    # Shell execution framing that is not obviously destructive — worth a
    # reviewer's eye, not a block (methods do legitimately run iof-* tools).
    ("shell_execution", CAUTION, re.compile(
        r"\b(subprocess|os\.system|eval\(|exec\()\b", re.I)),
]


#: LITERAL SECRETS - a value, as opposed to a ``${VAR}`` reference to one.
#: Shared by the learning scanner (an approved skill must not carry one) and
#: the build session's write gate and exec guard (an authored file or a
#: command must not either). One list, because the two seams had the same
#: job and would otherwise drift: the scanner knew AWS keys and JWTs, the
#: guard knew connection strings, and a token that passed one passed the
#: other. ``${VAR}`` is excluded by construction - that IS the compliant form.
SECRET_LITERAL_RES = [
    ("aws_access_key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    # At least one digit: a real key always has one, and the standard
    # placeholder spellings (sk-your-openai-api-key-here,
    # sk-proj-REPLACE_ME_WITH_YOUR_KEY) never do - and those are what
    # a builder writes into a .env.example, which this refused.
    ("openai_style_key", re.compile(
        r"\bsk-(?=[A-Za-z0-9_-]*\d)[A-Za-z0-9_-]{20,}\b")),
    ("jwt", re.compile(
        r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")),
    ("github_token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b")),
    ("slack_token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{20,}\b")),
    ("private_key_block", re.compile(
        r"-----BEGIN (RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    # `Authorization: Bearer <value>` / `Authorization=Bearer <value>` with a
    # literal where a `${VAR}` belongs. A placeholder in angle brackets is
    # not a literal; neither is the reference.
    ("bearer_literal", re.compile(
        r"\bBearer\s+(?!\$\{)(?!<)[A-Za-z0-9._~+/=-]{20,}", re.I)),
    # A connection URL carrying its password: the RDS URL that lives in the
    # workspace .env and must never land in a repository file.
    ("url_with_password", re.compile(
        r"\b[a-z][a-z0-9+.-]*://[^:/\s@]+:(?!\$\{)[^@/\s]{4,}@[^\s/]+", re.I)),
    # key = "long opaque value" where the key name says it is a secret and
    # the value is neither a reference nor a placeholder.
    # The value must look like a SECRET, not merely like twenty opaque
    # characters. Measured false positives, each refusing an ordinary
    # authored file: a key-FILE PATH (any value with a path separator)
    # and a UUID (a sample id, not a credential). Both shapes are
    # excluded; a real token containing a slash is still caught by the
    # bearer/jwt/url rules.
    ("named_secret_assignment", re.compile(
        r"\b(api[_-]?key|secret(_key)?|password|passwd|access[_-]?token|"
        r"auth[_-]?token|client[_-]?secret|private[_-]?key)\b\s*[:=]\s*"
        r"[\"']?(?!\$\{)(?!<)(?![\"']?\s*$)"
        r"(?![^\s\"']*[\\/])"
        r"(?![0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
        r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}(?![\w-]))"
        r"[A-Za-z0-9._~+/=-]{20,}[\"']?",
        re.I)),
]


#: Values that ANNOUNCE they are not a credential. A template has to show
#: the SHAPE of a connection string, and the shape is what the pattern
#: matches - so without this the scaffold's own `.env.example`
#: (`postgresql://user:pass@host:5432/aicore`) reads as a leaked password,
#: and an agent documenting that shape would have its write refused.
#:
#: Word-boundary matched, and every entry has to be a word nobody picks as
#: a real secret. `pass` is here and `password1` is not, which is the whole
#: distinction: this recognises a PLACEHOLDER, not a weak credential.
#: `example` is NOT here, and that is the point of the list being short. It
#: would have exempted AWS's own documentation access-key id - which ends in
#: the word, so arguably right - and with it every real secret that happens
#: to contain it. The observed false positive is triggered by `user:pass`;
#: the narrowest token that fixes it is the one to add. A detector that
#: grows a broad exemption to fix a narrow miss stops being a detector.
#:
#: THAT KEY IS DESCRIBED, NOT WRITTEN. A credential-shaped literal in this
#: file trips the client's own secret scanner on every clone - reported from
#: a client checkout, against this exact comment. A detector must not be the
#: thing that fails the scan, and the rule holds for the tests too: assemble
#: a fixture at runtime rather than committing twenty characters that match.
_PLACEHOLDERS = (
    "user:pass", "username:password", "user:password", "changeme",
    "your-password", "your_password", "yourpassword", "placeholder",
    "xxxxx", "<password>", "<user>", "redacted",
    # The standard fill-this-in spellings, measured refusing a
    # builder-authored .env.example and a documented Authorization
    # header. your_/your- inside a 20+-character opaque value is a
    # sentence, not entropy; no credential generator emits one.
    "replace_me", "replace-me", "your_", "your-", "_here", "-here",
    "sample_key", "example_key",
)


def _is_placeholder(fragment: str) -> bool:
    low = (fragment or "").lower()
    return any(p in low for p in _PLACEHOLDERS)


def find_secret_literals(text: str) -> List[str]:
    """Kinds of literal secret found in *text* (empty when clean).

    Deterministic and explainable - the names are what a refusal quotes.
    ``${VAR}`` references never match, so the sanctioned way to declare a
    credential is never flagged by the thing that refuses the unsanctioned
    one. Neither do the obvious PLACEHOLDERS a template must contain: found
    by a corpus run, where the scaffold's own `.env.example` was reported as
    a leaked password by the very check that ships beside it.

    Every MATCH is tested, not the whole text, so a real secret sitting in
    the same file as a placeholder is still caught.
    """
    found: List[str] = []
    for kind, rx in SECRET_LITERAL_RES:
        for m in rx.finditer(text or ""):
            if _is_placeholder(m.group(0)):
                continue
            found.append(kind)
            break
    return found


def scan_skill_md(text: str) -> ScanResult:
    """Scan a skill body. Deterministic; explainable; worst severity wins."""
    findings: List[ScanFinding] = []
    for category, severity, rx in _P:
        for m in rx.finditer(text or ""):
            findings.append(ScanFinding(
                category=category, severity=severity,
                excerpt=m.group(0)[:120].replace("\n", " ")))
    verdict = CLEAN
    if any(f.severity == CAUTION for f in findings):
        verdict = CAUTION
    if any(f.severity == DANGEROUS for f in findings):
        verdict = DANGEROUS
    return ScanResult(verdict=verdict, findings=findings)
