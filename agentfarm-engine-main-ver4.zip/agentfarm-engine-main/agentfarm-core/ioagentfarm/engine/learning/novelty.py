"""Novelty + recurrence gate — so a method is born only when a genuinely new
approach proves it RECURS, not on every Q&A (the population-explosion guard).

Mechanism:
  1. Turn a session trace into an APPROACH SIGNATURE = a deterministic structural
     key (tools / agents / ops / entities seen in the trace) + a short semantic
     descriptor (one cheap LLM line, injectable).
  2. NOVELTY = the signature matches no existing approved method's signature
     (similarity miss). A match -> the session merely applied a known method.
  3. RECURRENCE = a novel signature is seen >= K times before it authors. One-offs
     sit in a pending store and never become skills.

Matching requires BOTH structural and semantic agreement, so it neither over-
merges (same tools, different technique) nor under-merges (same technique,
different wording). Every decision is explainable ("matched method X by signature").
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional, Sequence

from loguru import logger

# Deterministic vocab for the structural key. File-plumbing tools (write_file,
# exec, ...) are deliberately excluded — they're execution noise, not technique.
# Core ships only GENERIC tokens (core tools + analytical ops + core always-on
# agents). Domain agents/entities are NOT hardcoded here — a domain deployment
# supplies them via env (CSV/newline) so the recurrence signature is grounded in
# that domain's vocabulary while core stays domain-free, e.g.:
#   IOF_LEARNING_SIGNATURE_AGENTS="sia_agent,profound_a2a,market_feedback,reporting"
#   IOF_LEARNING_SIGNATURE_ENTITIES="nrx,trx,sov,formulary,persistence"
def _env_vocab(var: str) -> frozenset:
    raw = os.environ.get(var, "")
    return frozenset(t.strip().lower().replace(" ", "_")
                     for t in re.split(r"[,\n]+", raw) if t.strip())


_TOOLS = {"iof-consult", "iof-query", "vectorfs", "dispatch"}
_AGENTS = {"queryngine", "cora"} | _env_vocab("IOF_LEARNING_SIGNATURE_AGENTS")
_OPS = {"join", "group by", "group", "normalize", "reconcile", "decompose",
        "aggregate", "rank", "filter", "compare", "divergence", "gap", "trajectory"}
_ENTITIES = _env_vocab("IOF_LEARNING_SIGNATURE_ENTITIES")
_VOCAB = _TOOLS | _AGENTS | _OPS | _ENTITIES

_STOP = set("the a an to of for in on with as it that this and or is are be by your you "
            "method how when use step do not before after".split())
_TOKEN = re.compile(r"[a-z0-9_]+")


def _scan(text: str) -> frozenset:
    low = (text or "").lower()
    return frozenset(k.replace(" ", "_") for k in _VOCAB if k in low)


def _toks(text: str) -> frozenset:
    return frozenset(t for t in _TOKEN.findall((text or "").lower()) if t not in _STOP and len(t) > 1)


def _jaccard(a: frozenset, b: frozenset) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _overlap(a: frozenset, b: frozenset) -> float:
    """Overlap coefficient |a∩b| / min(|a|,|b|) — robust to one being a subset of
    the other (a method's substance is a subset of a noisy session).
    Two empty sets are considered maximally overlapping (both have no vocab signal)."""
    if not a and not b:
        return 1.0  # both empty: same (vacuous) structural pattern
    if not a or not b:
        return 0.0
    return len(a & b) / min(len(a), len(b))


@dataclass
class ApproachSignature:
    structural: frozenset = field(default_factory=frozenset)   # tools/agents/ops/entities
    descriptor: str = ""                                        # one-line technique
    tokens: frozenset = field(default_factory=frozenset)        # semantic fingerprint

    def to_dict(self):
        return {"structural": sorted(self.structural), "descriptor": self.descriptor,
                "tokens": sorted(self.tokens)}

    @staticmethod
    def from_dict(d):
        return ApproachSignature(frozenset(d.get("structural", [])), d.get("descriptor", ""),
                                 frozenset(d.get("tokens", [])))


def extract_signature(trace: str, *, descriptor_fn: Optional[Callable[[str], str]] = None) -> ApproachSignature:
    """Signature of a session trace. The structural key is always computed (cheap,
    deterministic). The semantic descriptor is OPT-IN via descriptor_fn (e.g.
    `_default_descriptor` for an LLM line, or an injected fn in tests) — without it
    the gate matches on structural alone, so there is NO per-session LLM cost."""
    desc = ""
    if descriptor_fn is not None:
        try:
            desc = descriptor_fn(trace) or ""
        except Exception:
            logger.debug("novelty: descriptor failed", exc_info=True)
    return ApproachSignature(structural=_scan(trace), descriptor=desc.strip(), tokens=_toks(desc))


def _skill_descriptor(skill_md: str) -> str:
    n = re.search(r"name:\s*(.+)", skill_md or "")
    d = re.search(r"description:\s*(.+)", skill_md or "")
    out = ((n.group(1) if n else "") + " " + (d.group(1) if d else "")).strip()
    return out or (skill_md or "")[:160]


def extract_skill_signature(skill_md: str) -> ApproachSignature:
    """Signature of an existing approved method (from its SKILL.md)."""
    desc = _skill_descriptor(skill_md)
    return ApproachSignature(structural=_scan(skill_md), descriptor=desc, tokens=_toks(desc))


def signatures_match(a: ApproachSignature, b: ApproachSignature, *,
                     struct_thresh: float = 0.4, sem_thresh: float = 0.25) -> bool:
    """Same approach iff the structural keys agree (containment — handles method-
    substance ⊂ noisy session) AND, when both have a semantic descriptor, the
    fingerprints agree too. Structural-only when no descriptor (cheap default)."""
    if _overlap(a.structural, b.structural) < struct_thresh:
        return False
    if a.tokens and b.tokens:
        return _jaccard(a.tokens, b.tokens) >= sem_thresh
    return True


def _default_descriptor(trace: str) -> str:
    from ioagentfarm.engine.learning.distiller import _provider_complete  # reuse provider
    # _provider_complete prepends the REVIEW system prompt; for a crisp descriptor we
    # call the provider directly via the same helper but a focused instruction.
    return _provider_complete(
        "In <= 10 words, name the METHOD/technique used in this session. "
        "No numbers, no product names. Just the technique.\n\n" + trace[:2000]
    )


# ---------------------------------------------------------------------------
# Recurrence gate
# ---------------------------------------------------------------------------

class NoveltyGate:
    """Decides covered / pending / author for a session signature.
    Pending novel patterns are clustered in a file-backed store under IOF_ROOT."""

    def __init__(self, root_path, *, recurrence_k: int = 2,
                 struct_thresh: float = 0.4, sem_thresh: float = 0.25) -> None:
        self._path = Path(root_path) / "novelty_pending.json"
        self._k = max(1, recurrence_k)
        self._st, self._sm = struct_thresh, sem_thresh

    def _load(self) -> List[dict]:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text(encoding="utf-8"))
            except Exception:
                return []
        return []

    def _save(self, data: List[dict]) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            logger.debug("novelty: save failed", exc_info=True)

    def decide(self, sig: ApproachSignature, existing_method_sigs: Sequence[ApproachSignature]) -> str:
        """Return 'covered' | 'pending' | 'author'."""
        if not sig.structural and not sig.tokens:
            # NO SIGNAL, NO RECURRENCE. A trace that hits none of the
            # vocabulary and carries no descriptor says nothing about the
            # approach taken, and two such traces "match" vacuously (empty
            # overlaps empty). Counted, that made every second vocabulary-
            # free step output "recur": a review and an unrelated swarm
            # report authored a method between them, at a synchronous
            # reviewer call each. Nothing to count on, nothing stored.
            return "pending"
        for m in existing_method_sigs:
            if signatures_match(sig, m, struct_thresh=self._st, sem_thresh=self._sm):
                return "covered"  # the session merely applied a known method
        pending = self._load()
        for cluster in pending:
            csig = ApproachSignature.from_dict(cluster)
            if signatures_match(sig, csig, struct_thresh=self._st, sem_thresh=self._sm):
                cluster["count"] = int(cluster.get("count", 1)) + 1
                if cluster["count"] >= self._k:
                    pending.remove(cluster)
                    self._save(pending)
                    return "author"
                self._save(pending)
                return "pending"
        # brand-new pattern
        if self._k <= 1:
            # K=1: author immediately on first novel occurrence — no pending hold
            return "author"
        rec = sig.to_dict()
        rec["count"] = 1
        pending.append(rec)
        self._save(pending)
        return "pending"
