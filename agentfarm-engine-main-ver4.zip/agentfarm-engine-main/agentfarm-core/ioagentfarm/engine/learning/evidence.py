"""Learning System v2 — evidence builder.

Turns the existing quality-tracking signals (``record_application`` counters +
``learning_health``) into an :class:`EvidenceBundle` attached to drafts.  This
is the moat: the hub reviewer sees *measured effectiveness*, not just prose.

Phase 2 produces a scope-level aggregate (good enough to make approve/reject
data-backed); per-candidate precision can be layered on later.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from ioagentfarm.engine.learning.lifecycle import LearningLifecycle
from ioagentfarm.engine.learning.store import LearningStore
from ioagentfarm.engine.learning.v2_models import EvidenceBundle, Scope

logger = logging.getLogger(__name__)


def build_evidence(
    ll: LearningLifecycle,
    scope: Scope,
    distilled_from: Optional[List[str]] = None,
) -> EvidenceBundle:
    """Aggregate field evidence across the active learnings in *scope*."""
    skills = ll.get_skills(role=scope.role, workflow=scope.workflow)
    applications = sum(int(s.get("total_applied", 0)) for s in skills)
    completions = sum(int(s.get("total_completions", 0)) for s in skills)
    completion_rate = (completions / applications) if applications > 0 else None

    healths = [LearningStore.learning_health(s) for s in skills] if skills else []
    health = (sum(healths) / len(healths)) if healths else None

    return EvidenceBundle(
        applications=applications,
        completion_rate=round(completion_rate, 4) if completion_rate is not None else None,
        health=round(health, 4) if health is not None else None,
        distilled_from=list(distilled_from or []),
    )
