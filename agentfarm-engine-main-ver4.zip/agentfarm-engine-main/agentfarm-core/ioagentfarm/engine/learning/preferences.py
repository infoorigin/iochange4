"""Learning System v2 — preference / correction learning (the third mode).

Distinct from domain methods: a user *directive* about how the agent should
behave ("don't add Co-Authored-By to commits") is authoritative the moment it
is said, applies immediately, is user-scoped, and skips the hub gate and the
outcome ledger. It lands in the agent's ``USER.md`` (which iobot loads every
turn) so the user never has to repeat it.

Preferences NEVER go through the hub — the hub is for domain *methods*
(institutional, SME-approved). Preferences are a separate lane:
  * personal  -> immediate, user-scoped USER.md (no approval at all)
  * org/team  -> a team preference store, settable only by an authorized user
                 (an admin), applied to everyone — still NOT the hub.

Precedence (a personal pref can never override a guardrail):
  org policy / guardrails  >  team preference  >  personal  >  default
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional

# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

_NEG = r"(?:do\s*not|don'?t|never|stop|avoid|no\s+need\s+to|quit|cease|without)"
_POS = r"(?:always|make\s+sure\s+to|be\s+sure\s+to|remember\s+to|ensure)"
_PERSIST = r"(?:from\s+now\s+on|going\s+forward|henceforth|every\s+time|each\s+(?:commit|time|message)|in\s+future|always|never)"
_REVERSAL = r"(?:actually|never\s*mind|undo|go\s+back\s+to|scratch\s+that|disregard\s+that|re-?enable)"

# Action verbs that mark a directive aimed at the agent's behavior (reduces
# false positives like "I don't know").
_ACTION = (
    "add include use write format append prefix suffix commit name label comment "
    "sign tag mention put set remove omit drop skip start stop reply respond answer "
    "explain summarize call run print show output wrap"
).split()

_ORG_CUES = ["our team", "everyone", "company", "company-wide", "org-wide", "all of us",
             "the team", "as standard", "team convention", "all commits", "house style"]

_POLARITY_WORDS = set("do not dont don't never always stop avoid no need to remember to "
                      "make sure to be sure to ensure quit cease without".split())
_STOP = set("the a an to of for in on with as it that this your you i we my our and or "
            "is are be will would should can could please".split())


@dataclass
class PreferenceCandidate:
    polarity: str          # "avoid" | "do"
    directive: str         # normalized human-readable rule
    raw: str
    scope: str = "personal"   # "personal" | "org"
    is_reversal: bool = False


def _has_action(text: str) -> bool:
    toks = set(re.findall(r"[a-z0-9'-]+", text.lower()))
    return any(v in toks for v in _ACTION)


def _clean_tail(tail: str) -> str:
    tail = tail.strip().strip(".!?,;: ")
    # drop a leading filler ("to ", "that ", "you ")
    tail = re.sub(r"^(?:to|that|you|me|it)\s+", "", tail, flags=re.I)
    return tail.strip()


def detect_preference(message: str) -> Optional[PreferenceCandidate]:
    """Return a PreferenceCandidate if *message* is a behavioral directive, else None."""
    if not message or not message.strip():
        return None
    msg = message.strip()
    low = msg.lower()
    is_rev = re.search(_REVERSAL, low) is not None
    persist = re.search(_PERSIST, low) is not None
    scope = "org" if any(c in low for c in _ORG_CUES) else "personal"

    neg = re.search(_NEG, low)
    pos = re.search(_POS, low)
    # choose the earliest trigger
    trig = None
    polarity = None
    for m, pol in ((neg, "avoid"), (pos, "do")):
        if m and (trig is None or m.start() < trig.start()):
            trig, polarity = m, pol
    if trig is None:
        return None

    tail = _clean_tail(msg[trig.end():])
    if not tail:
        return None
    # require an action verb OR an explicit persistence cue — kills "I don't know"
    if not (_has_action(tail) or persist):
        return None

    directive = (f"Do not {tail}" if polarity == "avoid" else f"Always {tail}")
    directive = directive[0].upper() + directive[1:]
    return PreferenceCandidate(polarity=polarity, directive=directive, raw=msg,
                               scope=scope, is_reversal=is_rev)


# ---------------------------------------------------------------------------
# Conflict signature (for supersede + precedence)
# ---------------------------------------------------------------------------

def _sig(directive: str) -> frozenset:
    toks = re.findall(r"[a-z0-9'-]+", directive.lower())
    content = [t for t in toks if t not in _POLARITY_WORDS and t not in _STOP and len(t) > 1]
    return frozenset(content)


def _conflict(a: frozenset, b: frozenset) -> bool:
    if not a or not b:
        return False
    overlap = len(a & b)
    return overlap >= max(2, min(len(a), len(b)) // 2)


# ---------------------------------------------------------------------------
# User-scoped store
# ---------------------------------------------------------------------------

def _safe(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", s or "user")


class PreferenceStore:
    """File-backed, per-user preference store under IOF_ROOT/preferences/."""

    def __init__(self, root_path: Path) -> None:
        self._dir = Path(root_path) / "preferences"

    def _path(self, user_id: str) -> Path:
        return self._dir / f"{_safe(user_id)}.json"

    def _load(self, user_id: str) -> List[dict]:
        p = self._path(user_id)
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                return []
        return []

    def _save(self, user_id: str, data: List[dict]) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path(user_id).write_text(json.dumps(data, indent=2), encoding="utf-8")

    def add(self, user_id: str, cand: PreferenceCandidate) -> dict:
        """Add a preference; supersede any active preference it conflicts with
        (latest directive wins — handles reversals and changes-of-mind)."""
        data = self._load(user_id)
        sig = _sig(cand.directive)
        for rec in data:
            if rec.get("status") == "active" and _conflict(sig, frozenset(rec.get("sig", []))):
                rec["status"] = "superseded"
        rec = {**asdict(cand), "status": "active", "sig": sorted(sig)}
        data.append(rec)
        self._save(user_id, data)
        return rec

    def list_active(self, user_id: str) -> List[dict]:
        return [r for r in self._load(user_id) if r.get("status") == "active"]


# ---------------------------------------------------------------------------
# Precedence resolver
# ---------------------------------------------------------------------------

def resolve(*, personal: List[dict], org: List[dict] = (), guardrails: List[dict] = ()) -> List[dict]:
    """Merge tiers by precedence: guardrails > org > personal. A lower-tier rule
    that conflicts a higher-tier one is dropped (personal can't override a guardrail)."""
    effective: List[dict] = []
    used: List[frozenset] = []
    for tier, label in ((guardrails, "guardrail"), (org, "org"), (personal, "personal")):
        for p in tier:
            sig = frozenset(p.get("sig") or _sig(p.get("directive", "")))
            if any(_conflict(sig, u) for u in used):
                continue
            effective.append({**p, "_tier": label})
            used.append(sig)
    return effective


# ---------------------------------------------------------------------------
# USER.md compiler (the natively-loaded substrate)
# ---------------------------------------------------------------------------

_BLOCK_START = "<!-- IOF:PREFERENCES -->"
_BLOCK_END = "<!-- /IOF:PREFERENCES -->"


def preference_target_paths(workspace_dir: Path) -> List[Path]:
    """Resolve where preferences are written inside an agent workspace.

    Default is USER.md — NOT MEMORY.md — to avoid conflicting with iobot's
    own memory management. In iobot (verified v0.2.1):
      * USER.md is a bootstrap file loaded every turn and is NEVER auto-written
        by iobot (no `write_user` caller) — safe, stable, our territory.
      * MEMORY.md is iobot-owned: the Dream consolidation rewrites it wholesale
        via LLM summarization and it is git-tracked + line-age annotated. A block
        we write there would be reworded/dropped by Dream and churn its git ages.

    Controlled by IOF_PREFERENCES_TARGET = user (default) | memory | both.
    Use 'memory'/'both' ONLY if Dream is disabled and you accept the tradeoff;
    the block is still cap-protected in `enforce_memory_cap` as defense-in-depth.
    """
    workspace_dir = Path(workspace_dir)
    target = os.environ.get("IOF_PREFERENCES_TARGET", "user").strip().lower()
    memory_md = workspace_dir / "memory" / "MEMORY.md"
    user_md = workspace_dir / "USER.md"
    if target == "memory":
        return [memory_md]
    if target == "both":
        return [user_md, memory_md]
    return [user_md]


def render_block(effective: List[dict]) -> str:
    if not effective:
        body = "_(none yet)_"
    else:
        body = "\n".join(f"- {p['directive']}" for p in effective)
    return f"{_BLOCK_START}\n## Your saved preferences\n\n{body}\n{_BLOCK_END}"


def compile_into_userdoc(usermd_path: Path, effective: List[dict]) -> None:
    """Write the effective preferences into a managed block in USER.md, leaving
    the agent's static personality content untouched."""
    usermd_path = Path(usermd_path)
    block = render_block(effective)
    existing = usermd_path.read_text(encoding="utf-8") if usermd_path.exists() else ""
    if _BLOCK_START in existing and _BLOCK_END in existing:
        new = re.sub(
            re.escape(_BLOCK_START) + r".*?" + re.escape(_BLOCK_END),
            block, existing, flags=re.DOTALL,
        )
    else:
        new = (existing.rstrip() + "\n\n" + block + "\n") if existing else block + "\n"
    usermd_path.parent.mkdir(parents=True, exist_ok=True)
    usermd_path.write_text(new, encoding="utf-8")


# ---------------------------------------------------------------------------
# One-call capture (what the chat/message hook invokes)
# ---------------------------------------------------------------------------

TEAM_SCOPE = "__team__"  # team preferences live under this reserved user key


def capture_from_message(
    root_path: Path,
    user_id: str,
    message: str,
    *,
    workspace_dir: Optional[Path] = None,
    usermd_path: Optional[Path] = None,
    guardrails: Optional[List[dict]] = None,
    is_admin: bool = False,
) -> Optional[dict]:
    """Detect a directive in *message*; if found, apply it. NEVER touches the hub.

    * personal directive -> stored immediately for this user, doc recompiled.
    * team directive ("our team always...") -> stored in the team scope ONLY if
      the caller is authorized (*is_admin*); otherwise returned as a suggestion
      (status 'needs_team_authorization') with no effect.

    Pass *workspace_dir* to write into the agent workspace using
    IOF_PREFERENCES_TARGET (MEMORY.md by default), or *usermd_path* to target an
    explicit file. Returns the stored/suggested preference dict, or None.
    """
    cand = detect_preference(message)
    if cand is None:
        return None
    store = PreferenceStore(root_path)

    if cand.scope == "org":
        if not is_admin:
            return {**asdict(cand), "status": "needs_team_authorization"}
        rec = store.add(TEAM_SCOPE, cand)  # team store — applied to everyone, not the hub
    else:
        rec = store.add(user_id, cand)

    targets: List[Path] = []
    if usermd_path is not None:
        targets.append(Path(usermd_path))
    if workspace_dir is not None:
        targets.extend(preference_target_paths(workspace_dir))
    if targets:
        effective = resolve(
            personal=store.list_active(user_id),
            org=store.list_active(TEAM_SCOPE),
            guardrails=guardrails or [],
        )
        for t in targets:
            compile_into_userdoc(t, effective)
    return rec
