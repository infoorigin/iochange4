"""Pluggable interfaces for agent learning backends and rationalization strategies.

Any learning solution (built-in DB, mem0, OpenSpace, vector store)
can implement LearningBackend and be used by ioagentfarm without
changing orchestration code.

Any rationalization strategy (naive keyword, embedding, graph, LLM)
can implement Rationalizer and be plugged into LearningLifecycle.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Protocol, runtime_checkable


@runtime_checkable
class LearningBackend(Protocol):
    """Protocol for pluggable learning backends.

    Two layers:
    - Layer 1 (observations): raw append-only log from step execution
    - Layer 2 (learned skills): curated, quality-tracked, loaded into agent context

    The rest of ioagentfarm talks only to this interface.
    """

    def init(self) -> None:
        """Create tables/indexes. Must be idempotent."""
        ...

    # --- Layer 1: Observations ---

    def append_observation(
        self, *, run_id: str, step_key: str, role: str, workflow: str, content: str,
    ) -> str:
        """Append a raw observation from step execution. Returns entry_id."""
        ...

    def get_observations(
        self, *, role: str, workflow: str, limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """Get recent observations for a role+workflow scope, newest first."""
        ...

    # --- Layer 2: Learned Skills ---

    def capture_skill(
        self, *, role: str, workflow: str, name: str, content: str, run_id: str | None = None,
    ) -> str:
        """Capture or deduplicate a learned skill. Returns skill_id."""
        ...

    def get_skills(self, *, role: str, workflow: str) -> List[Dict[str, Any]]:
        """Get active learned skills for a role+workflow scope."""
        ...

    def record_application(self, skill_id: str, *, completed: bool) -> None:
        """Record that a learned skill was applied in a step."""
        ...

    def record_feedback(
        self, skill_id: str, *, signal: str, content: str = "",
        user_id: str = "", run_id: str = "", step_key: str = "", source_channel: str = "",
    ) -> None:
        """Record user feedback on a learned skill."""
        ...

    # --- Compilation ---

    def compile_for_workspace(self, *, role: str, workflow: str, dest: Path) -> int:
        """Write learned skills as .md files into workspace. Returns count."""
        ...

    def compile_memory_md(self, *, role: str, workflow: str) -> str:
        """Render markdown for MEMORY.md from observations + learned skills."""
        ...


@runtime_checkable
class Rationalizer(Protocol):
    """Strategy for deduplicating and merging similar learned skills.

    Built-in: NaiveRationalizer (keyword overlap / Jaccard similarity).
    Future: EmbeddingRationalizer (vector cosine), GraphRationalizer (knowledge graph),
    LLMRationalizer (LLM-driven semantic merge).

    The rationalizer only decides merge groups — it never writes to DB.
    The lifecycle applies the returned actions.
    """

    def rationalize(
        self,
        skills: List[Dict[str, Any]],
        *,
        similarity_threshold: float = 0.6,
    ) -> List[Dict[str, Any]]:
        """Identify merge groups from a list of skills.

        Returns a list of merge actions:
        [{"keep": skill_id, "absorb": [skill_id, ...], "merged_content": "..."}]
        """
        ...
