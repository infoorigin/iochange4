"""Learning System v2 — pluggable client for the enterprise skill hub.

The hub owns governance (approve / reject) and the registry of approved
skills.  Our side only (a) submits agent-authored drafts and (b) syncs
approved skills back down.  Everything in v2 talks to the hub through this
seam, so the whole stack can be built and tested against ``StubHubClient``
before the real hub contract (docs/learning_system_v2.md §9) is wired.

Select the implementation with ``IOF_LEARNING_HUB`` (``stub`` | ``http``).
"""
from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Any, List, Protocol, runtime_checkable

from loguru import logger

from ioagentfarm.engine.learning.v2_models import (
    ApprovedSkill,
    DraftSubmission,
    Scope,
    SubmissionRef,
)


@runtime_checkable
class HubClient(Protocol):
    """Contract between the agent-side learning layer and the skill hub."""

    def submit_draft(self, draft: DraftSubmission) -> SubmissionRef:
        """Submit an agent-authored draft for human approve/reject."""
        ...

    def fetch_approved(self, scope: Scope) -> List[ApprovedSkill]:
        """Return approved, hub-installed skills for a (role, workflow) scope."""
        ...

    def report_telemetry(self, skill_id: str, metrics: dict) -> None:
        """Push post-approval field telemetry for a deployed skill."""
        ...


def _outbox_dir() -> Path:
    root = Path(os.environ.get("IOF_ROOT", ".iof"))
    d = root / "hub_outbox"
    d.mkdir(parents=True, exist_ok=True)
    return d


def inbox_base() -> Path:
    """The approved-skill store the stub reads and the review CLI writes.

    Defaults to ``<IOF_ROOT>/hub_inbox``, but ``IOF_LEARNING_INBOX_DIR``
    repoints it at a GIT-VERSIONED directory: approval becomes a reviewed
    commit / PR (a real audit trail with an approver identity) instead of an
    opaque file drop, until the enterprise steward console exists. Both the
    reader (``fetch_approved``) and the writer (governance ``approve``) resolve
    the inbox HERE so they cannot diverge.
    """
    override = (os.environ.get("IOF_LEARNING_INBOX_DIR") or "").strip()
    if override:
        return Path(override).expanduser()
    return Path(os.environ.get("IOF_ROOT", ".iof")) / "hub_inbox"


class StubHubClient:
    """Offline stand-in for the real hub.

    Writes every submission/telemetry call to ``.iof/hub_outbox/*.json`` and
    returns a synthetic ref, so Phases 0/1/2/4/6 run end-to-end with no
    network.  ``fetch_approved`` reads any JSON files dropped under
    ``.iof/hub_inbox/<scope>/`` to simulate approved-skill sync in tests.
    """

    def __init__(self, deterministic_id: str | None = None) -> None:
        # deterministic_id lets tests avoid uuid (Math.random-style nondeterminism)
        self._fixed = deterministic_id

    def _new_id(self, prefix: str) -> str:
        if self._fixed:
            return f"{prefix}_{self._fixed}"
        return f"{prefix}_{uuid.uuid4().hex[:12]}"

    def submit_draft(self, draft: DraftSubmission) -> SubmissionRef:
        sub_id = self._new_id("sub")
        path = _outbox_dir() / f"{sub_id}.json"
        path.write_text(draft.model_dump_json(indent=2), encoding="utf-8")
        logger.info(
            "StubHub: draft submitted scope={} action={} name={} -> {}",
            draft.scope.key(), draft.action.value, draft.skill_name, path,
        )
        return SubmissionRef(submission_id=sub_id, skill_id=None, status="draft")

    def fetch_approved(self, scope: Scope) -> List[ApprovedSkill]:
        scope_dir = inbox_base() / scope.role / scope.workflow
        if not scope_dir.exists():
            return []
        out: List[ApprovedSkill] = []
        for f in sorted(scope_dir.glob("*.json")):
            try:
                out.append(ApprovedSkill.model_validate_json(f.read_text(encoding="utf-8")))
            except Exception:
                logger.debug("StubHub: skipping unreadable approved skill {}", f, exc_info=True)
        return out

    def report_telemetry(self, skill_id: str, metrics: dict) -> None:
        path = _outbox_dir() / f"telemetry_{skill_id}.json"
        existing = []
        if path.exists():
            try:
                existing = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                existing = []
        existing.append(metrics)
        path.write_text(json.dumps(existing, indent=2), encoding="utf-8")
        logger.info("StubHub: telemetry recorded skill={} -> {}", skill_id, path)


class HttpHubClient:
    """temp_hub client — speaks the contract defined in ``temp_hub.py``.

    Used for local demos and integration tests (``IOF_LEARNING_HUB=http``).
    Talks to ``IOF_LEARNING_HUB_URL`` (default ``http://127.0.0.1:8900``) with
    optional bearer ``IOF_LEARNING_HUB_TOKEN``.

    A pre-built ``client`` can be injected (tests wire an httpx ASGITransport
    at ``temp_hub.app`` so the full cycle runs with no live server).
    """

    def __init__(self, client: "Any | None" = None) -> None:
        import httpx

        self._base = os.environ.get("IOF_LEARNING_HUB_URL", "http://127.0.0.1:8900")
        token = os.environ.get("IOF_LEARNING_HUB_TOKEN", "")
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        self._client = client or httpx.Client(base_url=self._base, headers=headers, timeout=30.0)

    def submit_draft(self, draft: DraftSubmission) -> SubmissionRef:
        resp = self._client.post("/hub/skills", json=draft.model_dump(mode="json"))
        resp.raise_for_status()
        body = resp.json()
        return SubmissionRef(
            submission_id=body["submission_id"],
            skill_id=body.get("skill_id"),
            status=body.get("status", "draft"),
            raw=body,
        )

    def fetch_approved(self, scope: Scope) -> List[ApprovedSkill]:
        resp = self._client.get(
            "/hub/skills",
            params={"role": scope.role, "workflow": scope.workflow, "status": "approved"},
        )
        resp.raise_for_status()
        return [ApprovedSkill.model_validate(s) for s in resp.json().get("skills", [])]

    def report_telemetry(self, skill_id: str, metrics: dict) -> None:
        resp = self._client.post(f"/hub/telemetry/{skill_id}", json={"metrics": metrics})
        resp.raise_for_status()


class EnterpriseHubClient:
    """Real enterprise skill hub client (POST /api/v2/skillhub).

    Switch to this with ``IOF_LEARNING_HUB=enterprise``.  Talks to
    ``IOF_LEARNING_HUB_URL`` with an API-key header whose name is configured
    via ``IOF_LEARNING_HUB_API_KEY_HEADER`` (default ``api-key``).  Additional
    query params ``owner_id`` and ``workspace_id`` are read from
    ``IOF_LEARNING_HUB_OWNER_ID`` / ``IOF_LEARNING_HUB_WORKSPACE_ID``.
    """

    # Workflow-scoping marker embedded in uploaded .md — harmless HTML comment,
    # survives round-trip through S3 / hub.
    _WF_MARKER = "<!-- iof:workflow:{workflow} -->"

    def __init__(self, client: "Any | None" = None) -> None:
        import httpx

        self._base = os.environ.get("IOF_LEARNING_HUB_URL", "http://127.0.0.1:8900")
        self._owner = os.environ.get("IOF_LEARNING_HUB_OWNER_ID", "")
        self._ws = os.environ.get("IOF_LEARNING_HUB_WORKSPACE_ID", "")
        api_key = os.environ.get("IOF_LEARNING_HUB_API_KEY", "")
        key_header = os.environ.get("IOF_LEARNING_HUB_API_KEY_HEADER", "api-key")
        headers = {key_header: api_key} if api_key else {}
        self._client = client or httpx.Client(base_url=self._base, headers=headers, timeout=30.0)

    def _wf_marker(self, workflow: str) -> str:
        return self._WF_MARKER.format(workflow=workflow)

    @staticmethod
    def _normalize_frontmatter(md_content: str, skill_name: str, role: str, thoughts: str = "") -> str:
        """Normalize frontmatter for hub upload.

        Keeps: name, description, version (semver), tags (inline), thoughts.
        Strips: requires, target_roles, env_vars, network, and anything else
        that hub validation rejects.
        """
        import re as _re

        tag = role.replace("_", "-")

        def _build(name, description, ver, tags_list, body_text, t):
            tags_inline = "[" + ", ".join(str(x) for x in tags_list) + "]"
            thoughts_line = f"thoughts: \"{t}\"\n" if t else ""
            return (
                f"---\nname: {name}\n"
                f"description: {description}\n"
                f"version: \"{ver}\"\ntags: {tags_inline}\n"
                f"{thoughts_line}---\n\n{body_text}"
            )

        def _parse_fm_linewise(text: str):
            """Line-by-line frontmatter extractor.

            Works when LLM omits closing ---, has no blank line before body,
            or mixes body headers directly after YAML keys.
            Frontmatter ends at: closing ---, blank line, or markdown header (##/#).
            """
            lines = text.splitlines()
            if not lines or lines[0].strip() != "---":
                return None, text
            fm_lines, body_lines = [], []
            in_fm = True
            for line in lines[1:]:
                if not in_fm:
                    body_lines.append(line)
                elif line.strip() == "---":
                    in_fm = False
                elif line.startswith("#") or (not line.strip() and fm_lines):
                    in_fm = False
                    body_lines.append(line)
                else:
                    fm_lines.append(line)
            return "\n".join(fm_lines), "\n".join(body_lines).lstrip("\n")

        fm_text, body = _parse_fm_linewise(md_content)
        if fm_text is None:
            logger.info(
                "EnterpriseHub: no frontmatter in skill_md — adding minimal block. "
                "first_bytes_hex={}",
                (md_content or "")[:30].encode("utf-8", errors="replace").hex(),
            )
            t = thoughts.strip().replace('"', "'")
            return _build(skill_name, f"Analytical method for {role}", "1.0.0", [tag], md_content, t)

        fm: dict = {}
        try:
            import yaml as _yaml
            fm = _yaml.safe_load(fm_text) or {}
        except Exception as e:
            logger.warning("EnterpriseHub: yaml parse failed — kv fallback: {}", e)
            for line in fm_text.splitlines():
                kv = _re.match(r'^(\w+):\s*(.*)', line)
                if kv:
                    fm[kv.group(1)] = kv.group(2).strip().strip('"')

        tags = fm.get("tags") or [tag]
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",")]
        elif not isinstance(tags, list):
            tags = [tag]

        ver = str(fm.get("version") or "1.0.0")
        if not _re.match(r'^\d+\.\d+\.\d+', ver):
            ver = "1.0.0"

        t = (thoughts or fm.get("thoughts") or "").strip().replace('"', "'")
        if not t:
            desc = (fm.get("description") or "").strip()
            t = (
                f"Recurring {role} method — {desc[:150]}"
                if desc else
                f"Auto-extracted transferable method from {role} agent ({skill_name})."
            )
        logger.info(
            "EnterpriseHub: normalized frontmatter name={} description_len={} body_len={} thoughts_len={}",
            fm.get("name") or skill_name, len(fm.get("description") or ""), len(body), len(t),
        )
        return _build(
            fm.get("name") or skill_name,
            fm.get("description") or f"Analytical method for {role}",
            ver, tags, body, t,
        )

    def submit_draft(self, draft: DraftSubmission) -> SubmissionRef:
        slug = draft.skill_name.lower().replace(" ", "-").replace("_", "-")
        filename = f"{slug}-{uuid.uuid4().hex[:8]}.md"
        logger.info(
            "EnterpriseHub: submit_draft skill_name={} skill_md_preview={!r}",
            draft.skill_name, (draft.skill_md or "")[:300],
        )
        md_content = self._normalize_frontmatter(
            draft.skill_md.rstrip(), draft.skill_name, draft.scope.role,
            thoughts=draft.thoughts or "",
        )
        md_content = md_content + "\n\n" + self._wf_marker(draft.scope.workflow) + "\n"
        files = {"file": (filename, md_content.encode("utf-8"), "application/octet-stream")}
        params: dict = {}
        if self._owner:
            params["owner_id"] = self._owner
        if self._ws:
            params["workspace_id"] = self._ws
        logger.info(
            "EnterpriseHub: POST /api/v2/skillhub file={} params={} base={}",
            filename, params, self._base,
        )
        resp = self._client.post("/api/v2/skillhub", files=files, params=params)
        logger.info(
            "EnterpriseHub: response status={} body={!r}",
            resp.status_code, resp.text[:500],
        )
        resp.raise_for_status()
        body = resp.json()
        skill_id = body.get("skill_id") or body.get("id") or body.get("slug") or slug
        logger.info(
            "EnterpriseHub: submitted '%s' -> skill_id=%s slug=%s",
            draft.skill_name, skill_id, body.get("slug", slug),
        )
        return SubmissionRef(
            submission_id=str(skill_id),
            skill_id=str(skill_id),
            status=body.get("status", "active"),
            raw=body,
        )

    def _fetch_content(self, slug: str) -> str:
        try:
            resp = self._client.get(f"/api/v2/skillhub/{slug}/download")
            if resp.status_code != 200:
                logger.warning("EnterpriseHub: download failed slug={} status={}", slug, resp.status_code)
                return ""
            return resp.text
        except Exception:
            logger.debug("EnterpriseHub: download error slug={}", slug, exc_info=True)
            return ""

    def fetch_approved(self, scope: Scope) -> List[ApprovedSkill]:
        out: List[ApprovedSkill] = []
        cursor: str | None = None
        logger.info("EnterpriseHub: fetch_approved scope={} base={}", scope.key(), self._base)
        while True:
            params: dict = {"status": "active", "limit": 50}
            if cursor:
                params["cursor"] = cursor
            logger.info("EnterpriseHub: GET {}/api/v2/skillhub params={}", self._base, params)
            resp = self._client.get("/api/v2/skillhub", params=params)
            body = resp.json()
            items = body.get("items") or body.get("skills") or []
            logger.info("EnterpriseHub: list status={} items_count={} body_keys={}", resp.status_code, len(items), list(body.keys()))
            resp.raise_for_status()
            for item in items:
                slug = item.get("slug") or ""
                content = self._fetch_content(slug)
                if not content:
                    logger.info("EnterpriseHub: skipped slug={} reason=no_content", slug)
                    continue
                out.append(ApprovedSkill(
                    skill_id=str(item.get("skill_id") or item.get("id") or slug),
                    scope=scope,
                    skill_name=item.get("name") or slug,
                    skill_md=content,
                    version=str(item.get("latest_version") or ""),
                    approved_at=item.get("updated_at") or item.get("created_at") or "",
                ))
            cursor = body.get("next_cursor")
            if not cursor:
                break
        logger.info("EnterpriseHub: fetched {} approved skill(s) for {}/{}", len(out), scope.role, scope.workflow)
        return out

    def report_telemetry(self, skill_id: str, metrics: dict) -> None:
        logger.info("EnterpriseHub: telemetry skipped (no endpoint) skill={}", skill_id)


def get_hub_client() -> HubClient:
    """Factory keyed off IOF_LEARNING_HUB (default: stub).

    ``stub``       → StubHubClient (local outbox, no network)
    ``http``       → HttpHubClient (temp_hub at IOF_LEARNING_HUB_URL, demo/test)
    ``enterprise`` → EnterpriseHubClient (real hub at IOF_LEARNING_HUB_URL)
    """
    backend = os.environ.get("IOF_LEARNING_HUB", "stub").strip().lower()
    if backend == "http":
        return HttpHubClient()
    if backend == "enterprise":
        return EnterpriseHubClient()
    return StubHubClient()
