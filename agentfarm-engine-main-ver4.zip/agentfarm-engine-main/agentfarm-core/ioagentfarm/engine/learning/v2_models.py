"""Learning System v2 — data models for hub-governed agent learning.

These models define the contract between the agent-side authoring/evidence
layer and the enterprise skill hub. See docs/learning_system_v2.md.

Pydantic v2 (project already depends on pydantic>=2.7).
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class SkillType(str, Enum):
    """Editorial classification assigned by the distiller.

    Only METHOD and PREFERENCE are ever submitted to the hub.  FINDING
    (a domain conclusion, e.g. "discontinuation rate 24.3%") is the
    pollution class — it is classified so it can be deterministically
    DROPPED before submission, never turned into a standing instruction.
    """

    METHOD = "method"
    PREFERENCE = "preference"
    FINDING = "finding"


class SubmissionAction(str, Enum):
    NEW = "new"
    REFINE = "refine"


class Scope(BaseModel):
    """A learning is always scoped to a (role, workflow) pair."""

    role: str
    workflow: str

    def key(self) -> str:
        return f"{self.role}::{self.workflow}"


class EvidenceBundle(BaseModel):
    """Field evidence attached to a draft — OPTIONAL, never a submission gate.

    This is the differentiator the hub does not get today: reviewers see
    measured effectiveness, not just prose.
    """

    applications: int = 0
    completion_rate: Optional[float] = None
    health: Optional[float] = None
    helped_runs: List[str] = Field(default_factory=list)
    hurt_runs: List[str] = Field(default_factory=list)
    distilled_from: List[str] = Field(default_factory=list)

    def is_empty(self) -> bool:
        return self.applications == 0 and self.completion_rate is None and self.health is None


class DraftSubmission(BaseModel):
    """What the agent POSTs to the hub intake API (status always 'draft')."""

    scope: Scope
    action: SubmissionAction = SubmissionAction.NEW
    target_skill_id: Optional[str] = None  # set when action == REFINE
    status: str = "draft"
    skill_name: str  # class-level umbrella name (validated by the distiller)
    skill_md: str  # SKILL.md: frontmatter + class-level playbook prose
    skill_type: SkillType = SkillType.METHOD
    provenance: str = "agent-created"
    evidence: Optional[EvidenceBundle] = None
    thoughts: Optional[str] = None  # why this skill was created (embedded in frontmatter on upload)
    security_scan: Optional[Dict[str, Any]] = None  # {verdict, findings} - the reviewer sees WHY a draft is safe/caution (dangerous never reaches here)
    # The tenant the draft was distilled under. Stamped from the ambient
    # workspace at authoring time; None on legacy drafts and migrations.
    # Governance filters on it so one tenant's steward never reviews —
    # or approves into — another tenant's queue.
    workspace_code: Optional[str] = None

    def model_post_init(self, __context: Any) -> None:
        # Structural guards mirrored from the editorial policy. The distiller
        # also enforces these, but the model refuses to construct an invalid
        # submission so no other path can bypass them.
        if self.skill_type == SkillType.FINDING:
            raise ValueError("FINDING-typed candidates must never be submitted to the hub")
        if self.action == SubmissionAction.REFINE and not self.target_skill_id:
            raise ValueError("action=refine requires target_skill_id")


class SubmissionRef(BaseModel):
    """Returned by the hub on submit; our only handle on a draft's lifecycle."""

    submission_id: str
    skill_id: Optional[str] = None  # stable hub skill id (for refine/telemetry), if returned
    status: str = "draft"
    raw: Dict[str, Any] = Field(default_factory=dict)


class ApprovedSkill(BaseModel):
    """An approved, hub-installed skill synced down into an agent workspace."""

    skill_id: str
    scope: Scope
    skill_name: str
    skill_md: str
    version: Optional[str] = None
    approved_at: Optional[str] = None
