"""Learning System v2 — relevance-ranked recall (Phase 6).

v1 injected the *recent N* observations. This ranks observations by relevance
to a query (token-overlap / IDF-weighted), which is smarter than recency for
surfacing the right prior context. Pure-Python over the existing learning_log
(no schema change / no FTS5 DDL); FTS5 is a later optimization for scale.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, List

_TOKEN = re.compile(r"[A-Za-z0-9_]+")


def _tokens(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN.findall(text or "")]


def recall_observations(ll, *, role: str, workflow: str, query: str, limit: int = 10, pool: int = 200) -> List[Dict]:
    """Return up to *limit* observations for (role, workflow) ranked by relevance
    to *query*. Falls back to recency when the query has no signal."""
    obs = ll.get_observations(role=role, workflow=workflow, limit=pool)
    if not obs:
        return []
    q = set(_tokens(query))
    if not q:
        return obs[:limit]

    # IDF over the candidate pool so common tokens count for less.
    df: Counter = Counter()
    doc_tokens: List[set] = []
    for o in obs:
        toks = set(_tokens(o.get("content", "")))
        doc_tokens.append(toks)
        for t in toks:
            df[t] += 1
    n = len(obs)

    scored = []
    for o, toks in zip(obs, doc_tokens):
        overlap = q & toks
        score = sum(math.log((n + 1) / (df[t])) for t in overlap)
        scored.append((score, o))
    scored.sort(key=lambda x: x[0], reverse=True)
    ranked = [o for s, o in scored if s > 0]
    # back-fill with recency if relevance under-fills the limit
    if len(ranked) < limit:
        seen = {id(o) for o in ranked}
        ranked += [o for o in obs if id(o) not in seen][: limit - len(ranked)]
    return ranked[:limit]
