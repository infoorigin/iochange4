"""Durable, pod-resilient preference store + team-preference management.

Preferences are pod-local files in dev (`preferences.PreferenceStore`); in
production (K8s) the source of truth must be the shared DB so prefs survive
pod crashes and stay consistent across scale-out/in — same pattern as runs,
learnings, and sessions.

This module adds:
  * ``DbPreferenceStore`` — Postgres/SQLite-backed, keyed by *scope_key*
    (a user_id for personal, ``team:global`` / ``team:role:<role>`` for team).
  * Team-preference management: set (admin-gated) / list / remove.
  * ``compile_team_into_userdoc`` — resolve team prefs (+ guardrails) and write
    them into the role workspace USER.md (the cached system prefix). Called at
    pod warmup; team prefs are global + rarely-changing, so the cached prefix is
    the right home and stays cache-warm.

Personal prefs are injected per-turn from this same store (cache-safe), NOT
compiled into USER.md — see the web injection path.
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from ioagentfarm.engine.db import DbAdapter
from ioagentfarm.engine.learning.preferences import (
    PreferenceCandidate, _conflict, _sig, compile_into_userdoc, detect_preference,
)

logger = logging.getLogger(__name__)

# Scope keys encode the LEVEL a preference applies to.
GLOBAL = "global"                         # everyone


def user_key(user_id: str) -> str:
    return f"user:{user_id}"


def group_key(group_id: str) -> str:
    return f"group:{group_id}"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class DbPreferenceStore:
    """Shared, durable preference store. Same add/list API as the file store,
    but keyed by an arbitrary scope_key and backed by the cross-pod DB."""

    def __init__(self, adapter: DbAdapter) -> None:
        self._db = adapter

    # -- connection helpers (mirror LearningStore) ---------------------------
    def _conn(self) -> Any:
        return self._db.connect()

    @contextmanager
    def _tx(self):
        with self._conn() as con:
            self._db.init_connection(con)
            cur = con.cursor()
            try:
                yield cur
            finally:
                cur.close()

    def _q(self, sql: str) -> str:
        ph = self._db.placeholder()
        return sql if ph == "?" else sql.replace("?", ph)

    # -- schema --------------------------------------------------------------
    def init(self) -> None:
        auto_id = self._db.auto_id()
        with self._tx() as cur:
            cur.execute(
                f"""CREATE TABLE IF NOT EXISTS user_preferences (
                    id {auto_id},
                    scope_key TEXT NOT NULL,
                    directive TEXT NOT NULL,
                    polarity TEXT NOT NULL,
                    sig TEXT NOT NULL,
                    mandatory INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'active',
                    source_user TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );"""
            )
            cur.execute(
                "CREATE INDEX IF NOT EXISTS idx_user_prefs_scope_status "
                "ON user_preferences(scope_key, status);"
            )
            # Group membership (durable, cross-pod). In production this can be
            # backfilled from SSO/gateway claims instead.
            cur.execute(
                """CREATE TABLE IF NOT EXISTS user_group_membership (
                    user_id TEXT NOT NULL,
                    group_id TEXT NOT NULL,
                    PRIMARY KEY (user_id, group_id)
                );"""
            )

    # -- group membership ----------------------------------------------------
    def add_membership(self, user_id: str, group_id: str) -> None:
        with self._tx() as cur:
            cur.execute(
                self._q(self._db.upsert_ignore(
                    "INSERT INTO user_group_membership (user_id, group_id) VALUES (?, ?)"
                )),
                (user_id, group_id),
            )

    def groups_for_user(self, user_id: str) -> List[str]:
        with self._tx() as cur:
            cur.execute(
                self._q("SELECT group_id FROM user_group_membership WHERE user_id=? ORDER BY group_id"),
                (user_id,),
            )
            return [dict(r)["group_id"] for r in cur.fetchall()]

    # -- writes --------------------------------------------------------------
    def add(self, scope_key: str, cand: PreferenceCandidate, *,
            mandatory: bool = False, source_user: Optional[str] = None) -> Dict[str, Any]:
        """Insert a preference; supersede any active one it conflicts with
        (latest directive wins — handles change-of-mind/reversal).
        *mandatory* marks a policy (cannot be overridden by lower scopes)."""
        now = _utc_now()
        new_sig = _sig(cand.directive)
        with self._tx() as cur:
            cur.execute(
                self._q("SELECT id, sig FROM user_preferences WHERE scope_key=? AND status='active'"),
                (scope_key,),
            )
            for row in cur.fetchall():
                d = dict(row)
                if _conflict(new_sig, frozenset((d.get("sig") or "").split())):
                    cur.execute(
                        self._q("UPDATE user_preferences SET status='superseded', updated_at=? WHERE id=?"),
                        (now, d["id"]),
                    )
            cur.execute(
                self._q(
                    "INSERT INTO user_preferences "
                    "(scope_key, directive, polarity, sig, mandatory, status, source_user, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?)"
                ),
                (scope_key, cand.directive, cand.polarity, " ".join(sorted(new_sig)),
                 1 if mandatory else 0, source_user, now, now),
            )
        return {"scope_key": scope_key, "directive": cand.directive,
                "polarity": cand.polarity, "mandatory": mandatory, "status": "active"}

    def deactivate(self, scope_key: str, directive: str) -> bool:
        """Remove (soft-delete) the active preference matching *directive*."""
        now = _utc_now()
        target = _sig(directive)
        removed = False
        with self._tx() as cur:
            cur.execute(
                self._q("SELECT id, sig FROM user_preferences WHERE scope_key=? AND status='active'"),
                (scope_key,),
            )
            for row in cur.fetchall():
                d = dict(row)
                if _conflict(target, frozenset((d.get("sig") or "").split())):
                    cur.execute(
                        self._q("UPDATE user_preferences SET status='removed', updated_at=? WHERE id=?"),
                        (now, d["id"]),
                    )
                    removed = True
        return removed

    # -- reads ---------------------------------------------------------------
    def list_active(self, scope_key: str) -> List[Dict[str, Any]]:
        with self._tx() as cur:
            cur.execute(
                self._q("SELECT * FROM user_preferences WHERE scope_key=? AND status='active' "
                        "ORDER BY created_at"),
                (scope_key,),
            )
            out = []
            for row in cur.fetchall():
                d = dict(row)
                d["sig"] = (d.get("sig") or "").split()
                d["mandatory"] = bool(d.get("mandatory"))
                out.append(d)
            return out

    def version(self, scope_key: str) -> str:
        """Cheap etag for staleness checks — '<count>:<max_updated_at>'."""
        with self._tx() as cur:
            cur.execute(
                self._q("SELECT COUNT(*) AS n, MAX(updated_at) AS m FROM user_preferences "
                        "WHERE scope_key=? AND status='active'"),
                (scope_key,),
            )
            r = dict(cur.fetchone() or {})
            return f"{r.get('n', 0)}:{r.get('m') or ''}"


# ---------------------------------------------------------------------------
# Setting preferences (personal = self; group/global = admin-gated; NEVER hub)
# ---------------------------------------------------------------------------

def set_personal_preference(store: DbPreferenceStore, user_id: str, message: str) -> Optional[Dict[str, Any]]:
    """A user's own overridable preference. No authorization needed."""
    cand = detect_preference(message)
    if cand is None:
        return None
    return store.add(user_key(user_id), cand, source_user=user_id)


def set_scoped_preference(
    store: DbPreferenceStore, message: str, *, source_user: str,
    group_id: Optional[str] = None, mandatory: bool = False, is_admin: bool = False,
) -> Optional[Dict[str, Any]]:
    """Set a GROUP (if group_id) or GLOBAL preference/policy. Admin-only.
    *mandatory* makes it a policy that lower scopes cannot override.
    Returns the record, ``needs_team_authorization`` if not admin, or None."""
    cand = detect_preference(message)
    if cand is None:
        return None
    if not is_admin:
        return {"directive": cand.directive, "status": "needs_team_authorization"}
    scope = group_key(group_id) if group_id else GLOBAL
    rec = store.add(scope, cand, mandatory=mandatory, source_user=source_user)
    logger.info("preference set scope=%s mandatory=%s by=%s: %s",
                scope, mandatory, source_user, cand.directive)
    return rec


# ---------------------------------------------------------------------------
# Resolution — precedence across levels (the user-vs-group answer)
#   mandatory (policy) always wins:  global-policy > group-policy
#   overridable (preference) most-specific wins:  user > group > global
# external guardrails (compliance) are mandatory and outrank everything.
# ---------------------------------------------------------------------------

def resolve_for_user(
    *, user: List[dict], groups: List[List[dict]], global_: List[dict],
    guardrails: Optional[List[dict]] = None,
) -> List[dict]:
    """Merge all applicable scopes for one user into the effective set.
    Highest-priority tier first; a lower-priority rule conflicting a
    higher one is dropped. ``groups`` is a list of per-group pref lists."""
    flat_groups = [p for g in groups for p in g]

    def _split(rows, mand):
        return [r for r in rows if bool(r.get("mandatory")) == mand]

    # tier order, highest precedence first
    tiers = [
        [{"directive": g["directive"], "mandatory": True, "_tier": "guardrail"} for g in (guardrails or [])],
        _split(global_, True),       # global policy
        _split(flat_groups, True),   # group policy
        _split(user, False),         # personal preference (overridable)
        _split(flat_groups, False),  # group default
        _split(global_, False),      # global default
    ]
    labels = ["guardrail", "global-policy", "group-policy", "user", "group", "global"]

    effective: List[dict] = []
    used: List[frozenset] = []
    for rows, label in zip(tiers, labels):
        for p in rows:
            sig = frozenset(p.get("sig") or _sig(p.get("directive", "")))
            if any(_conflict(sig, u) for u in used):
                continue
            effective.append({**p, "_tier": p.get("_tier", label)})
            used.append(sig)
    return effective


def effective_for_user(
    store: DbPreferenceStore, user_id: str, *, groups: Iterable[str] = (),
    guardrails: Optional[List[dict]] = None,
) -> List[dict]:
    """Fully-resolved preferences for one user (user + their groups + global)."""
    return resolve_for_user(
        user=store.list_active(user_key(user_id)),
        groups=[store.list_active(group_key(g)) for g in groups],
        global_=store.list_active(GLOBAL),
        guardrails=guardrails,
    )


def per_user_block(
    store: DbPreferenceStore, user_id: str, *, groups: Iterable[str] = (),
    guardrails: Optional[List[dict]] = None,
) -> List[dict]:
    """The USER + GROUP subset to inject PER-TURN (global already lives in the
    cached USER.md). Group/user prefs that conflict a global mandatory policy
    are dropped here so the policy in USER.md stays authoritative."""
    full = effective_for_user(store, user_id, groups=groups, guardrails=guardrails)
    return [p for p in full if p.get("_tier") in ("user", "group", "group-policy")]


# ---------------------------------------------------------------------------
# Compile GLOBAL prefs into the cached USER.md (pod warmup)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Per-turn injection (USER + GROUP), appended to the user message — kept OUT
# of the cached system prefix so per-user content doesn't thrash the cache.
# ---------------------------------------------------------------------------

def render_preferences_preamble(prefs: List[dict]) -> str:
    if not prefs:
        return ""
    lines = "\n".join(f"- {p['directive']}" for p in prefs)
    return (
        "## Your active preferences (honor these for this request)\n"
        f"{lines}\n"
    )


def inject_user_preferences(
    store: DbPreferenceStore, user_id: str, content: str, *,
    groups: Optional[Iterable[str]] = None, guardrails: Optional[List[dict]] = None,
) -> str:
    """Resolve the requesting user's USER+GROUP prefs and prepend them to the
    message. Groups auto-resolve from membership if not supplied. Returns the
    original content unchanged when the user has no applicable prefs."""
    grp = list(groups) if groups is not None else store.groups_for_user(user_id)
    block = per_user_block(store, user_id, groups=grp, guardrails=guardrails)
    preamble = render_preferences_preamble(block)
    return f"{preamble}\n{content}" if preamble else content


def compile_global_into_userdoc(
    store: DbPreferenceStore, *, workspace_dir: Path, guardrails: Optional[List[dict]] = None,
) -> str:
    """Write the GLOBAL prefs (+ guardrails) — identical for every user — into
    the role workspace USER.md (cached system prefix). Group/user prefs are
    injected per-turn, not here. Returns the global version (etag)."""
    rows = store.list_active(GLOBAL)
    effective = resolve_for_user(user=[], groups=[], global_=rows, guardrails=guardrails)
    compile_into_userdoc(Path(workspace_dir) / "USER.md", effective)
    ver = store.version(GLOBAL)
    logger.info("compiled %d global prefs into USER.md (v=%s)", len(rows), ver)
    return ver
