"""Rationalization strategies for deduplicating learned skills.

Built-in:
- TFIDFRationalizer (default) — TF-IDF cosine similarity, stdlib only
- NaiveRationalizer (fallback) — Jaccard keyword overlap

Plug in custom strategies via the Rationalizer protocol.
"""
from __future__ import annotations

import math
from collections import Counter
from typing import Any, Dict, List


class TFIDFRationalizer:
    """TF-IDF cosine similarity rationalizer (stdlib only).

    Computes term frequency-inverse document frequency vectors for each skill,
    then uses cosine similarity to find merge candidates.  Significantly more
    accurate than Jaccard for skills with varying length and vocabulary,
    and scales well past 100 skills per scope.
    """

    def rationalize(
        self,
        skills: List[Dict[str, Any]],
        *,
        similarity_threshold: float = 0.6,
    ) -> List[Dict[str, Any]]:
        if len(skills) < 2:
            return []

        # Build TF-IDF vectors
        docs = []
        for s in skills:
            tokens = _tokenize(s["name"] + " " + s["content"])
            docs.append(tokens)

        # Document frequency: how many docs contain each term
        df: Counter = Counter()
        for tokens in docs:
            for t in set(tokens):
                df[t] += 1

        n_docs = len(docs)
        # IDF: log(N / df) — standard TF-IDF formula
        idf = {t: math.log(n_docs / count) for t, count in df.items()}

        # TF-IDF vectors (sparse, as dicts)
        vectors = []
        for tokens in docs:
            tf = Counter(tokens)
            vec = {t: (count / len(tokens)) * idf.get(t, 0) for t, count in tf.items()}
            vectors.append(vec)

        # Find merge groups via cosine similarity
        actions = []
        absorbed_ids: set = set()

        for i in range(len(skills)):
            if skills[i]["learning_id"] in absorbed_ids:
                continue

            absorb_list = []
            for j in range(i + 1, len(skills)):
                if skills[j]["learning_id"] in absorbed_ids:
                    continue

                sim = _cosine_similarity(vectors[i], vectors[j])
                if sim >= similarity_threshold:
                    absorb_list.append(skills[j]["learning_id"])
                    absorbed_ids.add(skills[j]["learning_id"])

            if absorb_list:
                all_in_group = [skills[i]] + [
                    s for s in skills if s["learning_id"] in absorb_list
                ]
                best = max(all_in_group, key=lambda s: len(s["content"]))
                actions.append({
                    "keep": skills[i]["learning_id"],
                    "absorb": absorb_list,
                    "merged_content": best["content"],
                })

        return actions


class NaiveRationalizer:
    """Keyword overlap rationalizer (Jaccard similarity).

    Simpler fallback — uses Jaccard similarity on token sets.
    Works for small skill sets (<50 per scope).
    """

    def rationalize(
        self,
        skills: List[Dict[str, Any]],
        *,
        similarity_threshold: float = 0.6,
    ) -> List[Dict[str, Any]]:
        if len(skills) < 2:
            return []

        skill_tokens = []
        for s in skills:
            tokens = set(_tokenize(s["name"] + " " + s["content"]))
            skill_tokens.append((s, tokens))

        actions = []
        absorbed_ids: set = set()

        for i in range(len(skill_tokens)):
            s_a, tokens_a = skill_tokens[i]
            if s_a["learning_id"] in absorbed_ids:
                continue

            absorb_list = []
            merged_tokens = set(tokens_a)

            for j in range(i + 1, len(skill_tokens)):
                s_b, tokens_b = skill_tokens[j]
                if s_b["learning_id"] in absorbed_ids:
                    continue

                sim = _jaccard_similarity(merged_tokens, tokens_b)
                if sim >= similarity_threshold:
                    absorb_list.append(s_b["learning_id"])
                    absorbed_ids.add(s_b["learning_id"])
                    merged_tokens = merged_tokens | tokens_b

            if absorb_list:
                all_skills = [s_a] + [
                    s for s, _ in skill_tokens
                    if s["learning_id"] in absorb_list
                ]
                best = max(all_skills, key=lambda s: len(s["content"]))
                actions.append({
                    "keep": s_a["learning_id"],
                    "absorb": absorb_list,
                    "merged_content": best["content"],
                })

        return actions


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_STOP_WORDS = frozenset({
    "the", "a", "an", "is", "are", "was", "were", "be", "been",
    "to", "of", "in", "for", "on", "with", "at", "by", "from",
    "and", "or", "not", "this", "that", "it", "as", "do", "if",
    "has", "had", "have", "will", "would", "could", "should",
    "can", "may", "must", "shall", "its", "but", "so", "than",
    "then", "when", "where", "which", "who", "how", "what",
    "all", "each", "every", "both", "few", "more", "most",
    "other", "some", "such", "no", "nor", "only", "own", "same",
    "too", "very", "just", "because", "about", "into", "through",
    "during", "before", "after", "above", "below", "between",
    "does", "did", "doing", "done", "being", "also", "these",
    "those", "any", "out", "up", "down", "over", "under",
    "status", "output", "done", "failed", "step", "run",
})


def _tokenize(text: str) -> list:
    """Extract lowercase keyword tokens from text. Returns list (preserves frequency)."""
    words = []
    for w in text.lower().split():
        clean = "".join(c for c in w if c.isalnum())
        if clean and len(clean) > 2 and clean not in _STOP_WORDS:
            words.append(clean)
    return words


def _cosine_similarity(a: Dict[str, float], b: Dict[str, float]) -> float:
    """Cosine similarity between two sparse TF-IDF vectors."""
    if not a or not b:
        return 0.0

    # Dot product (only shared keys contribute)
    shared_keys = set(a) & set(b)
    dot = sum(a[k] * b[k] for k in shared_keys)

    # Magnitudes
    mag_a = math.sqrt(sum(v * v for v in a.values()))
    mag_b = math.sqrt(sum(v * v for v in b.values()))

    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


def _jaccard_similarity(a: set, b: set) -> float:
    """Jaccard similarity between two token sets (0.0 to 1.0)."""
    if not a or not b:
        return 0.0
    intersection = len(a & b)
    union = len(a | b)
    return intersection / union if union > 0 else 0.0
