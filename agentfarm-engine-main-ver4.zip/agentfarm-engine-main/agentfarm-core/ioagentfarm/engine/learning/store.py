"""Workflow-scoped learning store for agent knowledge.

Agents accumulate learnings from task execution. Learnings are:
- Scoped to a workflow + role (no cross-workflow contamination)
- Quality-tracked (applied, completed, endorsed, rejected)
- Feedback-aware (user corrections drive learning evolution)
- Compilable to iobot workspace files for native loading

Uses the same DbAdapter protocol as Store — works with SQLite (dev)
and PostgreSQL (prod) identically.
"""
from __future__ import annotations

import json
import logging
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from ioagentfarm.engine.db import DbAdapter

logger = logging.getLogger(__name__)



def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _uuid() -> str:
    return uuid.uuid4().hex[:12]


class LearningStore:
    """Workflow-scoped learning store with quality tracking and feedback.

    Learnings are scoped to (role, workflow) pairs. A learning acquired during
    edi_integration never leaks into feature_dev unless explicitly promoted.

    Accepts the same DbAdapter used by Store — shares the database.
    """

    def __init__(self, adapter: DbAdapter):
        self._db = adapter

    # ------------------------------------------------------------------
    # Connection helpers (same pattern as Store)
    # ------------------------------------------------------------------

    def _conn(self) -> Any:
        return self._db.connect()

    @contextmanager
    def _tx(self):
        with self._conn() as con:
            self._db.init_connection(con)
            cursor = con.cursor()
            try:
                yield cursor
            finally:
                cursor.close()

    @contextmanager
    def _tx_pair(self):
        with self._conn() as con:
            self._db.init_connection(con)
            cursor = con.cursor()
            try:
                yield con, cursor
            finally:
                cursor.close()

    def _q(self, sql: str) -> str:
        ph = self._db.placeholder()
        if ph == "?":
            return sql
        return sql.replace("?", ph)

    def _now(self) -> str:
        return _utc_now()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def init(self) -> None:
        """Create learnings, learning_feedback, and learning_history tables."""
        auto_id = self._db.auto_id()
        with self._tx() as cursor:
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS learnings (
                    id {auto_id},
                    learning_id TEXT NOT NULL UNIQUE,
                    role TEXT NOT NULL,
                    workflow TEXT NOT NULL,
                    name TEXT NOT NULL,
                    content TEXT NOT NULL,
                    total_applied INTEGER NOT NULL DEFAULT 0,
                    total_completions INTEGER NOT NULL DEFAULT 0,
                    total_fallbacks INTEGER NOT NULL DEFAULT 0,
                    total_endorsements INTEGER NOT NULL DEFAULT 0,
                    total_rejections INTEGER NOT NULL DEFAULT 0,
                    total_corrections INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    parent_learning_id TEXT,
                    evolution_type TEXT,
                    created_from_run TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(name, role, workflow)
                );"""
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_learnings_role_workflow_active "
                "ON learnings(role, workflow, is_active);"
            )

            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS learning_feedback (
                    id {auto_id},
                    learning_id TEXT NOT NULL,
                    run_id TEXT,
                    step_key TEXT,
                    user_id TEXT,
                    signal TEXT NOT NULL,
                    content TEXT NOT NULL DEFAULT '',
                    source_channel TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );"""
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_learning_feedback_learning "
                "ON learning_feedback(learning_id);"
            )

            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS learning_history (
                    id {auto_id},
                    learning_id TEXT NOT NULL,
                    event TEXT NOT NULL,
                    old_content TEXT,
                    new_content TEXT,
                    reason TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );"""
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_learning_history_learning "
                "ON learning_history(learning_id);"
            )

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def capture_learning(
        self,
        *,
        role: str,
        workflow: str,
        name: str,
        content: str,
        evolution_type: str = "captured",
        parent_learning_id: str | None = None,
        run_id: str | None = None,
    ) -> str:
        """Capture a new learning. Returns the learning_id."""
        learning_id = _uuid()
        now = self._now()
        with self._tx() as cursor:
            sql = self._q(
                self._db.upsert_ignore(
                    "INSERT INTO learnings "
                    "(learning_id, role, workflow, name, content, "
                    "evolution_type, parent_learning_id, created_from_run, "
                    "created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                )
            )
            cursor.execute(sql, (
                learning_id, role, workflow, name, content,
                evolution_type, parent_learning_id, run_id,
                now, now,
            ))
            # Check if it was actually inserted (upsert_ignore may skip on name conflict)
            cursor.execute(
                self._q("SELECT learning_id FROM learnings WHERE name=? AND role=? AND workflow=?"),
                (name, role, workflow),
            )
            row = cursor.fetchone()
            return dict(row)["learning_id"] if row else learning_id

    def get_learning(self, learning_id: str) -> Dict[str, Any] | None:
        """Get a single learning by learning_id."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT * FROM learnings WHERE learning_id=?"),
                (learning_id,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_learnings(
        self,
        *,
        role: str,
        workflow: str,
    ) -> List[Dict[str, Any]]:
        """Get all active learnings for a role+workflow scope.

        Strictly scoped — only returns learnings for this exact workflow.
        No cross-workflow contamination.
        """
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "SELECT * FROM learnings "
                    "WHERE role=? AND workflow=? AND is_active=1 "
                    "ORDER BY updated_at DESC"
                ),
                (role, workflow),
            )
            return [dict(r) for r in cursor.fetchall()]

    def update_learning(
        self,
        learning_id: str,
        *,
        content: str,
        reason: str = "",
    ) -> bool:
        """Update a learning's content. Records history."""
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT content FROM learnings WHERE learning_id=?"),
                (learning_id,),
            )
            row = cursor.fetchone()
            if not row:
                return False
            old_content = dict(row)["content"]

            cursor.execute(
                self._q(
                    "UPDATE learnings SET content=?, updated_at=? WHERE learning_id=?"
                ),
                (content, now, learning_id),
            )
            cursor.execute(
                self._q(
                    "INSERT INTO learning_history "
                    "(learning_id, event, old_content, new_content, reason, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)"
                ),
                (learning_id, "updated", old_content, content, reason, now),
            )
            return True

    def deactivate_learning(self, learning_id: str, *, reason: str = "") -> bool:
        """Deactivate a learning (soft delete). Records history."""
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("UPDATE learnings SET is_active=0, updated_at=? WHERE learning_id=?"),
                (now, learning_id),
            )
            cursor.execute(
                self._q(
                    "INSERT INTO learning_history "
                    "(learning_id, event, old_content, new_content, reason, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)"
                ),
                (learning_id, "deactivated", None, None, reason, now),
            )
            return True

    # ------------------------------------------------------------------
    # Quality tracking
    # ------------------------------------------------------------------

    def record_application(
        self,
        learning_id: str,
        *,
        completed: bool,
    ) -> None:
        """Record that a learning was applied in a step. Atomic counter increment."""
        now = self._now()
        with self._tx() as cursor:
            if completed:
                cursor.execute(
                    self._q(
                        "UPDATE learnings SET "
                        "total_applied = total_applied + 1, "
                        "total_completions = total_completions + 1, "
                        "updated_at=? WHERE learning_id=?"
                    ),
                    (now, learning_id),
                )
            else:
                cursor.execute(
                    self._q(
                        "UPDATE learnings SET "
                        "total_applied = total_applied + 1, "
                        "total_fallbacks = total_fallbacks + 1, "
                        "updated_at=? WHERE learning_id=?"
                    ),
                    (now, learning_id),
                )

    def record_feedback(
        self,
        learning_id: str,
        *,
        signal: str,
        content: str = "",
        user_id: str = "",
        run_id: str = "",
        step_key: str = "",
        source_channel: str = "",
    ) -> None:
        """Record user feedback on a learning.

        signal: 'positive', 'negative', or 'correction'
        """
        if signal not in ("positive", "negative", "correction"):
            raise ValueError(f"Invalid feedback signal: {signal!r}")
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "INSERT INTO learning_feedback "
                    "(learning_id, run_id, step_key, user_id, signal, content, "
                    "source_channel, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                ),
                (learning_id, run_id, step_key, user_id, signal, content,
                 source_channel, now),
            )
            # Update counters atomically
            col = {
                "positive": "total_endorsements",
                "negative": "total_rejections",
                "correction": "total_corrections",
            }[signal]
            cursor.execute(
                self._q(
                    f"UPDATE learnings SET {col} = {col} + 1, updated_at=? "
                    f"WHERE learning_id=?"
                ),
                (now, learning_id),
            )

    def get_feedback(self, learning_id: str) -> List[Dict[str, Any]]:
        """Get all feedback for a learning, newest first."""
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "SELECT * FROM learning_feedback WHERE learning_id=? "
                    "ORDER BY created_at DESC"
                ),
                (learning_id,),
            )
            return [dict(r) for r in cursor.fetchall()]

    def get_history(self, learning_id: str) -> List[Dict[str, Any]]:
        """Get evolution history for a learning, newest first."""
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "SELECT * FROM learning_history WHERE learning_id=? "
                    "ORDER BY created_at DESC"
                ),
                (learning_id,),
            )
            return [dict(r) for r in cursor.fetchall()]

    @staticmethod
    def learning_health(learning: Dict[str, Any], recent_feedback: Optional[List[Dict[str, Any]]] = None) -> float:
        """Compute health score for a learning (0.0 to 1.0).

        Blends automated signal (completion rate) with human signal (feedback score).
        Human feedback weighted 60% because it catches semantic failures
        that automated signals miss.

        When *recent_feedback* is provided (list of feedback rows with 'signal'
        and 'created_at'), uses exponential decay so recent feedback counts more
        than old feedback. A skill that was bad but recently endorsed can recover.
        Half-life: 30 days.
        """
        import math

        applied = learning.get("total_applied", 0)
        completions = learning.get("total_completions", 0)

        # Automated signal: completion rate
        auto_score = completions / applied if applied > 0 else 0.5

        # Human signal: recency-weighted if feedback rows provided, else aggregate
        if recent_feedback:
            now = datetime.now(timezone.utc)
            half_life_days = 30.0
            decay_lambda = math.log(2) / half_life_days

            weighted_pos = 0.0
            weighted_total = 0.0
            for fb in recent_feedback:
                if fb["signal"] not in ("positive", "negative"):
                    continue
                try:
                    created = datetime.fromisoformat(fb["created_at"])
                    if created.tzinfo is None:
                        created = created.replace(tzinfo=timezone.utc)
                    age_days = max((now - created).total_seconds() / 86400, 0)
                except (ValueError, TypeError):
                    age_days = 0
                weight = math.exp(-decay_lambda * age_days)
                weighted_total += weight
                if fb["signal"] == "positive":
                    weighted_pos += weight

            human_score = weighted_pos / weighted_total if weighted_total > 0 else 0.5
            has_feedback = weighted_total > 0
        else:
            endorsements = learning.get("total_endorsements", 0)
            rejections = learning.get("total_rejections", 0)
            total_feedback = endorsements + rejections
            human_score = endorsements / total_feedback if total_feedback > 0 else 0.5
            has_feedback = total_feedback > 0

        # Blend: human feedback weighted higher
        if has_feedback and applied > 0:
            return 0.4 * auto_score + 0.6 * human_score
        elif has_feedback:
            return human_score
        elif applied > 0:
            return auto_score
        else:
            return 0.5  # No data yet — neutral

    def get_healthy_learnings(
        self,
        *,
        role: str,
        workflow: str,
        min_health: float = 0.3,
    ) -> List[Dict[str, Any]]:
        """Get active learnings above a health threshold, sorted by health descending.

        Uses recency-weighted feedback when available.
        """
        learnings = self.get_learnings(
            role=role, workflow=workflow,
        )
        scored = []
        for l in learnings:
            feedback = self.get_feedback(l["learning_id"])
            h = self.learning_health(l, recent_feedback=feedback)
            l["_health"] = h
            if h >= min_health:
                scored.append(l)
        scored.sort(key=lambda x: x["_health"], reverse=True)
        return scored

    def get_underperforming(
        self,
        *,
        role: str,
        workflow: str,
        threshold: float = 0.3,
        min_applications: int = 3,
    ) -> List[Dict[str, Any]]:
        """Get active learnings below health threshold with enough data to judge."""
        learnings = self.get_learnings(role=role, workflow=workflow)
        result = []
        for l in learnings:
            if l.get("total_applied", 0) < min_applications:
                continue
            h = self.learning_health(l)
            if h < threshold:
                l["_health"] = h
                result.append(l)
        return result

    # ------------------------------------------------------------------
    # Workspace compilation
    # ------------------------------------------------------------------

    def compile_for_workspace(
        self,
        *,
        role: str,
        workflow: str,
        dest: Path,
        max_learnings: int = 20,
        min_health: float = 0.3,
    ) -> int:
        """Write top-N healthy learnings as .md files into a workspace directory.

        Called by create_filtered_workspace() at step start.
        Returns the number of learnings written.
        """
        learnings = self.get_healthy_learnings(
            role=role, workflow=workflow, min_health=min_health,
        )[:max_learnings]

        if not learnings:
            return 0

        learned_dir = dest / "skills" / "learned"
        learned_dir.mkdir(parents=True, exist_ok=True)

        count = 0
        for l in learnings:
            filename = _safe_filename(l["name"]) + ".md"
            filepath = learned_dir / filename
            learning_content = (
                f"---\n"
                f"name: {l['name']}\n"
                f"learning_id: {l['learning_id']}\n"
                f"workflow: {l['workflow']}\n"
                f"health: {self.learning_health(l):.2f}\n"
                f"always: true\n"
                f"---\n\n"
                f"{l['content']}\n"
            )
            filepath.write_text(learning_content, encoding="utf-8")
            count += 1

        logger.info(
            "Compiled %d learnings for role=%s workflow=%s -> %s",
            count, role, workflow, learned_dir,
        )
        return count

    def compile_memory_summary(
        self,
        *,
        role: str,
        workflow: str,
        max_learnings: int = 15,
    ) -> str:
        """Render a markdown summary of learnings for MEMORY.md injection.

        Returns markdown text to append to the agent's MEMORY.md.
        """
        learnings = self.get_healthy_learnings(
            role=role, workflow=workflow, min_health=0.3,
        )[:max_learnings]

        if not learnings:
            return ""

        lines = [f"## Learned Knowledge ({workflow})\n"]
        for l in learnings:
            health = self.learning_health(l)
            lines.append(f"### {l['name']} (health: {health:.0%})")
            lines.append(l["content"])
            lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Bulk / utility
    # ------------------------------------------------------------------

    def list_learnings(
        self,
        *,
        role: str | None = None,
        workflow: str | None = None,
        active_only: bool = True,
    ) -> List[Dict[str, Any]]:
        """List learnings with optional filters. For admin/CLI use."""
        clauses = []
        params: list = []
        if role:
            clauses.append("role=?")
            params.append(role)
        if workflow:
            clauses.append("workflow=?")
            params.append(workflow)
        if active_only:
            clauses.append("is_active=1")

        where = " AND ".join(clauses) if clauses else "1=1"
        with self._tx() as cursor:
            cursor.execute(
                self._q(f"SELECT * FROM learnings WHERE {where} ORDER BY updated_at DESC"),
                tuple(params),
            )
            return [dict(r) for r in cursor.fetchall()]

    def learning_summary(
        self,
        *,
        role: str | None = None,
        workflow: str | None = None,
    ) -> Dict[str, Any]:
        """Summary stats for learnings. For status commands."""
        learnings = self.list_learnings(role=role, workflow=workflow)
        if not learnings:
            return {"total": 0, "by_workflow": {}, "by_role": {}}

        by_workflow: Dict[str, int] = {}
        by_role: Dict[str, int] = {}
        healthy = 0
        underperforming = 0
        for l in learnings:
            wf = l["workflow"]
            r = l["role"]
            by_workflow[wf] = by_workflow.get(wf, 0) + 1
            by_role[r] = by_role.get(r, 0) + 1
            h = self.learning_health(l)
            if h >= 0.5:
                healthy += 1
            elif l.get("total_applied", 0) >= 3:
                underperforming += 1

        return {
            "total": len(learnings),
            "healthy": healthy,
            "underperforming": underperforming,
            "by_workflow": by_workflow,
            "by_role": by_role,
        }


    def analytics(
        self,
        *,
        role: str | None = None,
        workflow: str | None = None,
    ) -> Dict[str, Any]:
        """Learning analytics with effectiveness metrics and feedback loop closure.

        Returns:
        - effectiveness: per-skill completion rate with vs without (before/after capture)
        - top_performers: highest health skills with impact data
        - underperformers: skills dragging down completion rate
        - feedback_by_channel: distribution of feedback signals by source
        - loop_closure: overall before/after impact metrics (ROI signal)
        """
        learnings = self.list_learnings(role=role, workflow=workflow)
        if not learnings:
            return {
                "total_skills": 0, "top_performers": [], "underperformers": [],
                "feedback_by_channel": {}, "loop_closure": {},
            }

        # Per-skill effectiveness
        skill_stats = []
        for l in learnings:
            feedback = self.get_feedback(l["learning_id"])
            health = self.learning_health(l, recent_feedback=feedback)
            applied = l.get("total_applied", 0)
            completions = l.get("total_completions", 0)
            fallbacks = l.get("total_fallbacks", 0)
            completion_rate = completions / applied if applied > 0 else None

            skill_stats.append({
                "learning_id": l["learning_id"],
                "name": l["name"],
                "role": l["role"],
                "workflow": l["workflow"],
                "health": round(health, 3),
                "applied": applied,
                "completions": completions,
                "fallbacks": fallbacks,
                "completion_rate": round(completion_rate, 3) if completion_rate is not None else None,
                "endorsements": l.get("total_endorsements", 0),
                "rejections": l.get("total_rejections", 0),
                "corrections": l.get("total_corrections", 0),
            })

        # Top performers (health >= 0.7, at least 2 applications)
        top = sorted(
            [s for s in skill_stats if s["health"] >= 0.7 and s["applied"] >= 2],
            key=lambda s: s["health"], reverse=True,
        )[:10]

        # Underperformers (health < 0.4, at least 3 applications)
        under = sorted(
            [s for s in skill_stats if s["health"] < 0.4 and s["applied"] >= 3],
            key=lambda s: s["health"],
        )[:10]

        # Feedback by channel
        channel_counts: Dict[str, Dict[str, int]] = {}
        for l in learnings:
            feedback = self.get_feedback(l["learning_id"])
            for fb in feedback:
                ch = fb.get("source_channel", "unknown") or "unknown"
                if ch not in channel_counts:
                    channel_counts[ch] = {"positive": 0, "negative": 0, "correction": 0}
                sig = fb.get("signal", "")
                if sig in channel_counts[ch]:
                    channel_counts[ch][sig] += 1

        # Loop closure: aggregate before/after signal
        total_applied = sum(s["applied"] for s in skill_stats)
        total_completions = sum(s["completions"] for s in skill_stats)
        total_fallbacks = sum(s["fallbacks"] for s in skill_stats)
        total_endorsements = sum(s["endorsements"] for s in skill_stats)
        total_rejections = sum(s["rejections"] for s in skill_stats)
        overall_completion_rate = total_completions / total_applied if total_applied > 0 else None
        net_sentiment = total_endorsements - total_rejections

        loop_closure = {
            "total_skill_applications": total_applied,
            "total_step_completions_with_skills": total_completions,
            "total_step_failures_with_skills": total_fallbacks,
            "overall_completion_rate": round(overall_completion_rate, 3) if overall_completion_rate is not None else None,
            "net_feedback_sentiment": net_sentiment,
            "total_endorsements": total_endorsements,
            "total_rejections": total_rejections,
            "skills_above_70_health": len([s for s in skill_stats if s["health"] >= 0.7]),
            "skills_below_40_health": len([s for s in skill_stats if s["health"] < 0.4]),
        }

        return {
            "total_skills": len(skill_stats),
            "top_performers": top,
            "underperformers": under,
            "feedback_by_channel": channel_counts,
            "loop_closure": loop_closure,
        }


def _safe_filename(name: str) -> str:
    """Convert a name to a safe filename."""
    safe = name.lower().replace(" ", "_")
    safe = "".join(c for c in safe if c.isalnum() or c in ("_", "-"))
    return safe[:60] or "learning"
