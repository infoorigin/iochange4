"""Learning System v2 — the distiller (autonomous authoring engine).

Adapted from Hermes' ``background_review.py`` pattern: after a step, a
tool-whitelisted reviewer inspects the run's observations and proposes
reusable skills.  Our enterprise hardening on top of Hermes:

  * Output is a *draft* for the hub, never live knowledge.
  * Each candidate is typed METHOD / PREFERENCE / FINDING; **FINDING is
    dropped** (the anti-pollution rail — a domain conclusion never becomes
    a standing instruction).  This is deterministic, not a prose nudge.
  * Class-level umbrella naming is validated; ``fix-X-today`` artifacts are
    rejected (Hermes' authoring discipline, enforced in code).
  * Refine-first: if an existing hub skill covers the territory, emit a
    patch (action=refine) against its id instead of a new submission.

The LLM call is injected via ``reviewer_fn`` so the distiller is unit-testable
with no iobot round-trip.  Production wires ``iobot_reviewer_fn`` (a forked,
memory/skill-tool-only agent).  Dedup + rate-cap throttles land in Phase 4.
"""
from __future__ import annotations

import json
import re
from typing import Callable, Dict, List, Optional, Sequence

from pydantic import BaseModel

from loguru import logger

from ioagentfarm.engine.learning.skill_scan import scan_skill_md
from ioagentfarm.engine.learning.v2_models import (
    ApprovedSkill,
    DraftSubmission,
    EvidenceBundle,
    Scope,
    SkillType,
    SubmissionAction,
)


# ---------------------------------------------------------------------------
# Reviewer contract (what the injected LLM step returns)
# ---------------------------------------------------------------------------

class ReviewerProposal(BaseModel):
    """One candidate skill proposed by the reviewer step."""

    skill_name: str
    skill_md: str
    skill_type: SkillType = SkillType.METHOD
    covers_existing: Optional[str] = None
    thoughts: Optional[str] = None  # why this skill was created (injected into frontmatter)


# reviewer_fn(observations, scope, existing_names) -> proposals
ReviewerFn = Callable[[List[Dict], Scope, List[str]], List[ReviewerProposal]]


# ---------------------------------------------------------------------------
# Class-level umbrella name validation (Hermes authoring discipline, in code)
# ---------------------------------------------------------------------------

# Reject names that only make sense for one task: PR numbers, error strings,
# fix-/debug-/audit-X-today artifacts, dated/temporal one-offs.
_BAD_NAME_PATTERNS = [
    re.compile(r"^(fix|debug|audit|patch|hotfix)[-_]", re.I),
    re.compile(r"(today|yesterday|now|temp|tmp|wip)", re.I),
    re.compile(r"pr[-_]?\d+", re.I),
    re.compile(r"#\d+"),
    re.compile(r"\berror\b|\bexception\b|\btraceback\b", re.I),
    re.compile(r"\d{4}-\d{2}-\d{2}"),  # ISO date in the name
]


_FIGURE_RE = re.compile(r"\d{4,}(?:\.\d+)?|\d+\.\d+")


def _ambient_workspace() -> Optional[str]:
    """The tenant this distillation runs under, or None.

    Learning is fail-open by design: an unscoped context (legacy runs, tests
    with no selection) authors an UNSCOPED draft rather than erroring — the
    governance console shows those only to platform admins.
    """
    try:
        from ioagentfarm.engine.workspaces import maybe_workspace_code
        return maybe_workspace_code()
    except Exception:
        return None


def _figure_tokens(text: str) -> set:
    """Data-shaped numeric tokens: >=4-digit integers and any decimal figure.

    Deliberately excludes small structural integers ("top-2", "3 sources",
    "one decimal") — those describe the METHOD. What it matches is the shape
    session data takes: amounts (187000) and computed rates (96.8). Version
    strings ("1.0.0") produce "1.0"/"0.0"-style tokens that a session trace
    essentially never contains as figures, so intersection stays clean.
    """
    return set(_FIGURE_RE.findall(text or ""))


def _session_figures(observations: Sequence[Dict]) -> set:
    """Every data-shaped figure the session's observations contain."""
    figs: set = set()
    for ob in observations:
        figs |= _figure_tokens(str(ob.get("content", "")))
    return figs


def is_valid_umbrella_name(name: str) -> bool:
    """True if *name* is a durable, class-level skill name."""
    n = (name or "").strip()
    if not (3 <= len(n) <= 80):
        return False
    if " " in n and "-" not in n and "_" not in n:
        # free-text sentence rather than a slug-style class name
        return False
    return not any(p.search(n) for p in _BAD_NAME_PATTERNS)


# ---------------------------------------------------------------------------
# Distiller
# ---------------------------------------------------------------------------

class Distiller:
    """Turns run observations into hub-ready draft submissions."""

    def __init__(self, reviewer_fn: ReviewerFn) -> None:
        self._reviewer = reviewer_fn

    def distill(
        self,
        observations: Sequence[Dict],
        scope: Scope,
        hub_existing: Sequence[ApprovedSkill] = (),
        evidence: Optional[EvidenceBundle] = None,
    ) -> List[DraftSubmission]:
        """Produce zero or more draft submissions from *observations*.

        Drops FINDING-typed and invalidly-named candidates; maps candidates
        that cover an existing hub skill to refine actions.  *evidence* (if
        provided by Phase 2) is attached to every emitted draft.
        """
        if not observations:
            return []

        existing_by_name = {s.skill_name: s for s in hub_existing}
        proposals = self._reviewer(list(observations), scope, list(existing_by_name))

        drafts: List[DraftSubmission] = []
        session_figs = _session_figures(observations)
        for p in proposals:
            if p.skill_type == SkillType.FINDING:
                logger.info("distiller: dropped FINDING candidate '{}' (anti-pollution)", p.skill_name)
                continue
            if not is_valid_umbrella_name(p.skill_name):
                logger.info("distiller: dropped non-umbrella name '{}'", p.skill_name)
                continue
            scan = scan_skill_md(p.skill_md or "")
            if scan.blocked:
                # A skill body is injected into agent context; a dangerous one
                # is a prompt-injection / destructive vector wearing a method's
                # label. Drop at DRAFT time so it never reaches the hub - the
                # ingest seam refuses it too (defence in depth), but a draft
                # that cannot pass ingest should never be submitted.
                logger.info(
                    "distiller: dropped '{}' - security scan DANGEROUS: {}",
                    p.skill_name,
                    ", ".join(f"{f.category}={f.excerpt!r}"
                              for f in scan.findings if f.severity == "dangerous"))
                continue
            leaked = session_figs & _figure_tokens(p.skill_md or "")
            if leaked:
                # A method-typed draft whose BODY quotes the session's figures
                # is a finding wearing a method's label — usually a worked
                # example ("(187000 - 95000) / 95000 = 96.8%"). Approved, it
                # would put this run's numbers in front of every future run,
                # which is the anchoring the FINDING drop exists to prevent;
                # the type check cannot see it because the type is right and
                # the body is wrong. Deterministic and explainable: every
                # dropped token provably came from this session's
                # observations. Found live on the first v2-armed run.
                logger.info(
                    "distiller: dropped '{}' - session figures in the method "
                    "body: {} (write formulas with placeholders, not this "
                    "run's numbers)", p.skill_name, sorted(leaked))
                continue

            action = SubmissionAction.NEW
            target_id = None
            covered = existing_by_name.get(p.covers_existing or "")
            if covered is not None:
                action = SubmissionAction.REFINE
                target_id = covered.skill_id

            try:
                drafts.append(
                    DraftSubmission(
                        scope=scope,
                        action=action,
                        target_skill_id=target_id,
                        skill_name=p.skill_name,
                        skill_md=p.skill_md,
                        skill_type=p.skill_type,
                        evidence=evidence,
                        thoughts=p.thoughts,
                        # A clean/caution verdict rides along so the hub
                        # reviewer sees WHY it is safe (dangerous was already
                        # dropped above and never reaches here).
                        security_scan=scan.to_dict(),
                        workspace_code=_ambient_workspace(),
                    )
                )
            except ValueError as exc:  # model guard rejected it (belt + suspenders)
                logger.info("distiller: candidate '{}' rejected by model guard: {}", p.skill_name, exc)

        logger.info(
            "distiller: scope={} proposals={} -> drafts={}",
            scope.key(), len(proposals), len(drafts),
        )
        return drafts


# ---------------------------------------------------------------------------
# Production reviewer (forked iobot agent) — shell for Phase 1 wiring
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Production reviewer — a structured LLM completion (Hermes background_review,
# adapted: NO agent loop / NO tools, because our reviewer only RETURNS proposals;
# our pipeline does the writing). Conservative (not "be ACTIVE"), typed so the
# deterministic FINDING-drop works, class-level naming, refine-first.
# ---------------------------------------------------------------------------

_REVIEW_SYSTEM = (
    "You extract REUSABLE METHODS (transferable tradecraft) from a completed "
    "agent step, for a governed enterprise skill library.\n\n"
    "Rules:\n"
    "- Propose a skill if EITHER:\n"
    "  (a) a genuinely transferable technique/process/workflow emerged that a "
    "future run would benefit from, OR\n"
    "  (b) the step FAILED due to a technical error (wrong SQL function, "
    "unsupported syntax, missing column, API error) — in this case extract the "
    "CORRECT approach as a METHOD skill so the agent never makes the same mistake. "
    "Failure traces are the most valuable source of corrective methods.\n"
    "  If truly nothing durable emerged AND the step succeeded, return [].\n"
    "- Classify each candidate's skill_type:\n"
    "    method     = a transferable procedure/technique (the only kind worth keeping)\n"
    "    preference = a user style/format directive\n"
    "    finding    = a DOMAIN CONCLUSION or number (e.g. a rate, a count). Classify "
    "honestly — findings are dropped downstream; never dress one up as a method.\n"
    "- skill_name MUST be CLASS-LEVEL and durable (e.g. 'querying-rx-data', "
    "'reconciling-intent-vs-volume'). NEVER a one-off: no 'fix-X-today', no PR "
    "numbers, no dates, no error strings.\n"
    "- The skill_md BODY must be dataset-agnostic: formulas and worked examples "
    "use PLACEHOLDERS ('(current - prior) / prior'), NEVER this session's "
    "figures, names or amounts. A method quoting the session's numbers is a "
    "finding in disguise and is dropped deterministically downstream.\n"
    "- If an existing skill (provided) already covers the territory, set "
    "covers_existing to that exact name so it becomes a refinement, not a new entry.\n"
    "- thoughts: 1–2 sentences explaining WHY this skill was created — the concrete "
    "gap or recurring pattern that made it worth capturing.\n\n"
    "NEVER propose skills about:\n"
    "  - Reading catalogs, mapping entities to tables, schema lookup\n"
    "    (catalog_reader is already an operational skill in every agent workspace)\n"
    "  - Generic SQL syntax that any SQL user knows (SELECT, WHERE, GROUP BY basics)\n"
    "  - Tool invocations every agent already knows (exec, write_file, read_file)\n"
    "  - Re-descriptions of the agent's existing built-in skills\n"
    "DO propose skills about:\n"
    "  - Database-engine-specific function availability (e.g. DuckDB vs PostgreSQL "
    "differences, unsupported ANSI functions and their correct replacements)\n"
    "  - Multi-step reasoning, cross-entity reconciliation, dispatch patterns\n"
    "  - Analytical heuristics a future agent would NOT discover from built-in skills\n"
    "  - Corrective patterns from observed failures (wrong function → correct function)\n\n"
    "OUTPUT FORMAT — two blocks, in order:\n\n"
    "Block 1: a fenced ```json array with ONE object per proposed skill:\n"
    '  [{"skill_name": "slug", "skill_type": "method", '
    '"covers_existing": null, "thoughts": "why created"}]\n\n'
    "Block 2: for EACH skill in that array (same order), a fenced ```skillmd block "
    "containing the complete SKILL.md. Write rich, detailed content — minimum 200 words "
    "in the body. Use this structure:\n"
    "  ---\n"
    "  name: <same slug as skill_name>\n"
    "  description: <one sentence — what transferable method this captures>\n"
    "  version: \"1.0.0\"\n"
    "  tags: [<role-tag>]\n"
    "  ---\n\n"
    "  ## When to use\n"
    "  <one sentence trigger>\n\n"
    "  ## Approach\n"
    "  <5–8 numbered steps — concrete, specific, follow-blind-able>\n\n"
    "  ## Key patterns\n"
    "  <3–5 bullets with SQL snippets or pseudo-code; generic placeholders>\n\n"
    "  ## Pitfalls\n"
    "  <2–4 failure modes and exactly how to avoid them>\n\n"
    "No product names, company names, or actual numbers from this session. "
    "Generic enough to apply to a different dataset next time.\n\n"
    "If proposing 0 skills: output only ```json\n[]\n``` and nothing else."
)


# Each agent learns the KIND of method appropriate to its expertise. An agent is
# an agent; whether invoked via A2A / workflow / direct call it learns in its own
# lane. Override/extend via IOF_LEARNING_METHOD_DOMAINS (JSON role->focus).
# Core ships NO domain-specific focuses — a domain deployment supplies them via
# IOF_LEARNING_METHOD_DOMAINS (JSON role->focus). Unknown roles fall back to a
# generic focus (see _method_domain). This keeps core domain-free: the pharma /
# procurement per-role focuses live in the domain pack's deploy config, not here.
METHOD_DOMAINS = {
    "cora": "routing requests to the right agent or workflow.",
}


def _method_domain(role: str) -> str:
    import json
    import os
    override = os.environ.get("IOF_LEARNING_METHOD_DOMAINS", "")
    if override:
        try:
            m = json.loads(override)
            if role in m:
                return str(m[role])
        except Exception:
            pass
    return METHOD_DOMAINS.get(role, "this agent's own domain of expertise")


def _build_review_user(observations: Sequence[Dict], scope, existing_names: List[str]) -> str:
    obs = "\n".join(f"- [{o.get('step_key','')}] {str(o.get('content',''))[:1500]}" for o in observations)
    existing = ", ".join(existing_names) if existing_names else "(none)"
    return (
        f"Agent: {scope.role}  (workflow {scope.workflow})\n"
        f"This agent's expertise — look ONLY for transferable methods in THIS domain:\n"
        f"  {_method_domain(scope.role)}\n\n"
        f"Existing skills in this scope: {existing}\n\n"
        f"Step observations:\n{obs}\n"
    )


_JSON_FENCE = re.compile(r"```json\s*([\s\S]+?)```", re.MULTILINE)
_SKILLMD_FENCE = re.compile(r"```skillmd\s*([\s\S]+?)```", re.MULTILINE)
# Legacy fallback: any fenced block (old format had skill_md embedded in JSON)
_ANY_FENCE = re.compile(r"```(?:json)?\s*([\s\S]+?)```", re.MULTILINE)


def _parse_proposals(text: str) -> List[ReviewerProposal]:
    """Parse the two-block reviewer output into proposals.

    New format:
      Block 1 — ```json  array of {skill_name, skill_type, covers_existing, thoughts}
      Block 2+ — ```skillmd  one block per skill (same order), full SKILL.md content

    Legacy fallback: single ```json block with skill_md embedded (old format).
    """
    if not text or not text.strip():
        return []

    # --- Extract JSON metadata block ---
    json_m = _JSON_FENCE.search(text)
    blob = json_m.group(1) if json_m else text
    data = None
    try:
        data = json.loads(blob)
    except Exception:
        try:
            import json_repair
            data = json_repair.loads(blob)
        except Exception:
            logger.info("reviewer: could not parse proposals JSON")
            return []
    if not isinstance(data, list):
        return []

    # --- Extract skillmd body blocks (new format) ---
    skillmd_blocks = [m.group(1).strip() for m in _SKILLMD_FENCE.finditer(text)]

    out: List[ReviewerProposal] = []
    for i, item in enumerate(data):
        if not isinstance(item, dict) or not item.get("skill_name"):
            continue
        try:
            stype = SkillType(str(item.get("skill_type", "method")).lower())
        except ValueError:
            stype = SkillType.METHOD

        # New format: body from separate skillmd block at same index
        # Legacy format: body from skill_md key in the JSON item
        skill_md = (
            skillmd_blocks[i]
            if i < len(skillmd_blocks)
            else str(item.get("skill_md") or "")
        )
        if not skill_md:
            logger.info("reviewer: skipping '{}' — no skill_md body", item.get("skill_name"))
            continue

        out.append(ReviewerProposal(
            skill_name=str(item["skill_name"]).strip(),
            skill_md=skill_md,
            skill_type=stype,
            covers_existing=(item.get("covers_existing") or None),
            thoughts=(item.get("thoughts") or None),
        ))
    return out


_PROVIDER = None  # cached across calls — see _worker_loop() for the rule
_WORKER_LOOP = None
_WORKER_LOCK = None


def _worker_loop():
    """One event loop, for the whole process, that is never closed.

    THE RULE THIS ENFORCES: a cached HTTP client may not outlive the loop its
    sockets were opened on. `_PROVIDER` is cached deliberately — a background
    housekeeping call should not pay a TLS handshake every time — and the
    previous implementation then ran each call through `asyncio.run()`, which
    creates a loop and CLOSES it on the way out. The second call reached into
    a connection pool belonging to a dead loop, and closing one of those
    schedules `call_soon` on it:

        RuntimeError: Event loop is closed
        -> APIConnectionError -> "upstream LLM call failed"

    which reads as an unreliable model and is nothing of the kind. A client
    hit it in a plain chat demo.

    A daemon thread, so it never holds up interpreter exit, and never joined:
    there is nothing to flush, and a shutdown that waits on a background LLM
    call would be a worse bug than the one this fixes.
    """
    global _WORKER_LOOP
    import asyncio
    import threading

    global _WORKER_LOCK
    if _WORKER_LOCK is None:
        _WORKER_LOCK = threading.Lock()
    with _WORKER_LOCK:
        if _WORKER_LOOP is not None and not _WORKER_LOOP.is_closed():
            return _WORKER_LOOP
        loop = asyncio.new_event_loop()
        threading.Thread(
            target=loop.run_forever,
            name="iof-learning-llm",
            daemon=True,
        ).start()
        _WORKER_LOOP = loop
        return loop


def _provider_complete(prompt: str) -> str:
    """Default LLM completion via the runtime's provider (one-shot, no tools).

    Always runs on :func:`_worker_loop`, from inside FastAPI's loop and from
    a plain CLI process alike — so there is no "which loop am I on" branch,
    and the cached client's sockets always belong to a loop that is still
    open.
    """
    global _PROVIDER
    import asyncio
    if _PROVIDER is None:
        from iobot.config.loader import load_config
        from ioagentfarm.engine.provider_factory import make_provider
        _PROVIDER = make_provider(load_config())
    messages = [
        {"role": "system", "content": _REVIEW_SYSTEM},
        {"role": "user", "content": prompt},
    ]

    async def _call():
        return await _PROVIDER.chat(messages, max_tokens=2000, temperature=0.3)

    fut = asyncio.run_coroutine_threadsafe(_call(), _worker_loop())
    resp = fut.result(timeout=120)
    return getattr(resp, "content", "") or ""


def iobot_reviewer_fn(complete_fn: Optional[Callable[[str], str]] = None) -> ReviewerFn:
    """Production reviewer. *complete_fn* (prompt -> text) is injectable so the
    prompt-build + parse logic is unit-testable without an LLM; the default
    calls iobot's provider."""
    cf = complete_fn or _provider_complete

    def reviewer(observations: List[Dict], scope, existing_names: List[str]) -> List[ReviewerProposal]:
        if not observations:
            return []
        try:
            text = cf(_build_review_user(observations, scope, existing_names))
        except Exception:
            logger.info("reviewer: LLM completion failed", exc_info=True)
            return []
        logger.info("reviewer: LLM returned {!r}", (text or "")[:300])
        proposals = _parse_proposals(text)
        logger.info("reviewer: parsed {} proposal(s) from LLM text", len(proposals))
        return proposals

    return reviewer
