"""Agent learning module — workflow-scoped observations and learned skills.

Usage:
    from ioagentfarm.engine.learning import LearningLifecycle, LearningBackend

    ll = LearningLifecycle(adapter)
    ll.init()
"""
from ioagentfarm.engine.learning.protocol import LearningBackend, Rationalizer
from ioagentfarm.engine.learning.lifecycle import LearningLifecycle
from ioagentfarm.engine.learning.log import LearningLog
from ioagentfarm.engine.learning.store import LearningStore
from ioagentfarm.engine.learning.rationalize import TFIDFRationalizer, NaiveRationalizer
