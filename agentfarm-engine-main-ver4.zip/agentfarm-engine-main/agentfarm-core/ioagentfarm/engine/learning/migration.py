"""Learning System v2 — one-time migration (backfill).

Bulk-submit the existing v1 ``learnings`` rows to the hub as drafts, so nothing
accumulated is lost — it goes through governance retroactively. After backfill,
the v1 ``learnings`` table is frozen (callers stop writing to it under v2).

Usage (script-style):
    from ioagentfarm.engine.learning.migration import backfill_learnings_to_hub
    backfill_learnings_to_hub(ll, hub, scopes=[("analyst", "my_workflow")])
"""
from __future__ import annotations

import logging
from typing import Iterable, List, Tuple

logger = logging.getLogger(__name__)


def backfill_learnings_to_hub(ll, hub, scopes: Iterable[Tuple[str, str]]) -> List[dict]:
    """Submit every active learning in each (role, workflow) scope as a draft.

    Returns a per-skill result list ``[{name, ok, submission_id|error}]``.
    Idempotency is the hub's concern (re-running creates new drafts); intended
    to run once at cutover.
    """
    from ioagentfarm.engine.learning.v2_models import (
        DraftSubmission, EvidenceBundle, Scope, SkillType,
    )
    from ioagentfarm.engine.learning.store import LearningStore

    results: List[dict] = []
    for role, workflow in scopes:
        scope = Scope(role=role, workflow=workflow)
        for s in ll.get_skills(role=role, workflow=workflow):
            applied = int(s.get("total_applied", 0))
            completed = int(s.get("total_completions", 0))
            ev = EvidenceBundle(
                applications=applied,
                completion_rate=(completed / applied) if applied else None,
                health=round(LearningStore.learning_health(s), 4),
            )
            md = s.get("content") or ""
            if not md.lstrip().startswith("---"):
                md = f"---\nname: {s['name']}\n---\n\n{md}\n"
            try:
                draft = DraftSubmission(
                    scope=scope, skill_name=s["name"], skill_md=md,
                    skill_type=SkillType.METHOD,
                    evidence=ev if not ev.is_empty() else None,
                )
                ref = hub.submit_draft(draft)
                results.append({"name": s["name"], "ok": True, "submission_id": ref.submission_id})
            except Exception as exc:  # noqa: BLE001
                logger.debug("backfill: failed for %s", s.get("name"), exc_info=True)
                results.append({"name": s.get("name"), "ok": False, "error": str(exc)})
    ok = sum(1 for r in results if r["ok"])
    logger.info("backfill: %d/%d learnings submitted as drafts", ok, len(results))
    return results
