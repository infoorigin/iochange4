"""Agent learning lifecycle — the single entry point for all learning operations.

Combines two layers:
- Layer 1 (LearningLog): raw observations from step execution
- Layer 2 (LearningStore): curated learned skills with quality tracking

Implements LearningBackend protocol — can be swapped for mem0, OpenSpace,
or any custom backend without changing orchestration code.

Usage:
    from ioagentfarm.engine.learning import LearningLifecycle

    ll = LearningLifecycle(make_adapter(db_url))
    ll.init()

    # Pluggable rationalization:
    from ioagentfarm.engine.learning import NaiveRationalizer
    ll = LearningLifecycle(adapter, rationalizer=NaiveRationalizer())
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

from ioagentfarm.engine.db import DbAdapter
from ioagentfarm.engine.learning.log import LearningLog
from ioagentfarm.engine.learning.store import LearningStore
from ioagentfarm.engine.learning.protocol import Rationalizer
from ioagentfarm.engine.learning.rationalize import TFIDFRationalizer

logger = logging.getLogger(__name__)

# Max chars to store per observation (prevents DB bloat from large outputs)
MAX_OBSERVATION_LENGTH = 4000


class LearningLifecycle:
    """Facade combining observation log + learned skills + compilation.

    This is the only class external code needs to import for learning.
    Implements the LearningBackend protocol.
    """

    def __init__(self, adapter: DbAdapter, rationalizer: Rationalizer | None = None):
        self._log = LearningLog(adapter)
        self._store = LearningStore(adapter)
        self._rationalizer = rationalizer or TFIDFRationalizer()

    def init(self) -> None:
        """Create all tables. Idempotent."""
        self._log.init()
        self._store.init()

    # ------------------------------------------------------------------
    # Layer 1: Observations
    # ------------------------------------------------------------------

    def append_observation(
        self, *, run_id: str, step_key: str, role: str, workflow: str, content: str,
    ) -> str:
        """Append a raw observation from step execution. Returns entry_id."""
        truncated = content[:MAX_OBSERVATION_LENGTH]
        entry_id = self._log.append(
            run_id=run_id, step_key=step_key, role=role,
            workflow=workflow, content=truncated,
        )
        logger.debug(
            "Observation appended: entry=%s run=%s step=%s role=%s workflow=%s len=%d",
            entry_id, run_id, step_key, role, workflow, len(truncated),
        )
        return entry_id

    def get_observations(
        self, *, role: str, workflow: str, limit: int = 50,
    ) -> List[Dict[str, Any]]:
        return self._log.get_recent(role=role, workflow=workflow, limit=limit)

    def get_run_observations(self, run_id: str) -> List[Dict[str, Any]]:
        return self._log.get_for_run(run_id)

    # ------------------------------------------------------------------
    # Layer 2: Learned Skills
    # ------------------------------------------------------------------

    def capture_skill(
        self, *, role: str, workflow: str, name: str, content: str, run_id: str | None = None,
    ) -> str:
        return self._store.capture_learning(
            role=role, workflow=workflow, name=name, content=content, run_id=run_id,
        )

    def get_skills(self, *, role: str, workflow: str) -> List[Dict[str, Any]]:
        return self._store.get_learnings(role=role, workflow=workflow)

    def get_healthy_skills(
        self, *, role: str, workflow: str, min_health: float = 0.3,
    ) -> List[Dict[str, Any]]:
        return self._store.get_healthy_learnings(
            role=role, workflow=workflow, min_health=min_health,
        )

    def get_skill(self, skill_id: str) -> Dict[str, Any] | None:
        return self._store.get_learning(skill_id)

    def update_skill(self, skill_id: str, *, content: str, reason: str = "") -> bool:
        return self._store.update_learning(skill_id, content=content, reason=reason)

    def deactivate_skill(self, skill_id: str, *, reason: str = "") -> bool:
        return self._store.deactivate_learning(skill_id, reason=reason)

    def record_application(self, skill_id: str, *, completed: bool) -> None:
        self._store.record_application(skill_id, completed=completed)

    def record_feedback(
        self, skill_id: str, *, signal: str, content: str = "",
        user_id: str = "", run_id: str = "", step_key: str = "", source_channel: str = "",
    ) -> None:
        self._store.record_feedback(
            skill_id, signal=signal, content=content, user_id=user_id,
            run_id=run_id, step_key=step_key, source_channel=source_channel,
        )

    def get_feedback(self, skill_id: str) -> List[Dict[str, Any]]:
        return self._store.get_feedback(skill_id)

    def get_underperforming(
        self, *, role: str, workflow: str, threshold: float = 0.3, min_applications: int = 3,
    ) -> List[Dict[str, Any]]:
        return self._store.get_underperforming(
            role=role, workflow=workflow, threshold=threshold, min_applications=min_applications,
        )

    # ------------------------------------------------------------------
    # Compilation
    # ------------------------------------------------------------------

    def compile_for_workspace(
        self, *, role: str, workflow: str, dest: Path, max_skills: int = 20, min_health: float = 0.3,
    ) -> int:
        return self._store.compile_for_workspace(
            role=role, workflow=workflow, dest=dest,
            max_learnings=max_skills, min_health=min_health,
        )

    def compile_memory_md(
        self, *, role: str, workflow: str,
        max_observations: int = 10, max_skills: int = 15,
        include_skills: bool = True,
        max_bytes: int = 6 * 1024,
    ) -> str:
        """Compile MEMORY.md content from DB layers.

        When include_skills=False, only observations are included — use this
        when compile_for_workspace() is also called (skills are already loaded
        as separate .md files, so including them in MEMORY.md would duplicate).

        Observations are truncated to 200 chars each and capped at max_bytes
        total to prevent context window bloat.
        """
        sections = []
        if include_skills:
            skills_md = self._store.compile_memory_summary(
                role=role, workflow=workflow, max_learnings=max_skills,
            )
            if skills_md:
                sections.append(skills_md)

        observations = self._log.get_recent(
            role=role, workflow=workflow, limit=max_observations,
        )
        if observations:
            lines = ["## Recent Observations\n"]
            for obs in observations:
                snippet = obs["content"][:200]
                lines.append(f"- [{obs['step_key']}] {snippet}")
            sections.append("\n".join(lines))

        result = "\n\n".join(sections)
        # Hard cap: prevent compiled output from exceeding budget
        if len(result.encode("utf-8")) > max_bytes:
            result = result.encode("utf-8")[:max_bytes].decode("utf-8", errors="ignore")
            # Clean break at last newline
            last_nl = result.rfind("\n")
            if last_nl > 0:
                result = result[:last_nl]
        return result

    # ------------------------------------------------------------------
    # Rationalization (pluggable strategy)
    # ------------------------------------------------------------------

    def rationalize(
        self, *, role: str, workflow: str, similarity_threshold: float = 0.6,
    ) -> Dict[str, Any]:
        """Deduplicate and merge similar learned skills within a scope.

        Delegates to the pluggable Rationalizer strategy.
        The rationalizer decides merge groups; this method applies them to the DB.
        """
        skills = self._store.get_learnings(role=role, workflow=workflow)
        if len(skills) < 2:
            return {"checked": len(skills), "merged": 0, "deactivated": 0, "actions": []}

        actions = self._rationalizer.rationalize(
            skills, similarity_threshold=similarity_threshold,
        )

        merged = 0
        deactivated = 0
        for action in actions:
            keep_id = action["keep"]
            absorb_ids = action["absorb"]
            merged_content = action["merged_content"]

            keep_skill = next((s for s in skills if s["learning_id"] == keep_id), None)
            if not keep_skill:
                continue

            self._store.update_learning(
                keep_id, content=merged_content,
                reason=f"rationalized: absorbed {len(absorb_ids)} similar skill(s)",
            )
            for aid in absorb_ids:
                absorbed = next((s for s in skills if s["learning_id"] == aid), None)
                absorbed_name = absorbed["name"] if absorbed else aid
                self._store.deactivate_learning(
                    aid, reason=f"rationalized: merged into '{keep_skill['name']}'",
                )
                deactivated += 1
                logger.info("Rationalized: '%s' merged into '%s'", absorbed_name, keep_skill["name"])
            merged += 1

        return {
            "checked": len(skills), "merged": merged,
            "deactivated": deactivated,
            "actions": [{"keep": a["keep"], "absorbed": len(a["absorb"])} for a in actions],
        }

    # ------------------------------------------------------------------
    # Feedback card (structured message for UI)
    # ------------------------------------------------------------------

    def build_feedback_card_payload(
        self, *, run_id: str, step_key: str, role: str, workflow: str, output_snippet: str = "",
    ) -> Dict[str, Any]:
        skills = self._store.get_learnings(role=role, workflow=workflow)
        skill_refs = [{"learning_id": s["learning_id"], "name": s["name"]} for s in skills]
        return {
            "type": "feedback_card",
            "run_id": run_id, "step_key": step_key,
            "role": role, "workflow": workflow,
            "output_snippet": output_snippet[:2000],
            "skills": skill_refs,
            "actions": ["positive", "negative", "correction"],
        }

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def summary(self, *, role: str | None = None, workflow: str | None = None) -> Dict[str, Any]:
        skill_summary = self._store.learning_summary(role=role, workflow=workflow)
        obs_count = self._log.count(role=role, workflow=workflow)
        return {**skill_summary, "observations": obs_count}

    def analytics(self, *, role: str | None = None, workflow: str | None = None) -> Dict[str, Any]:
        """Learning effectiveness analytics with feedback loop closure metrics."""
        return self._store.analytics(role=role, workflow=workflow)
