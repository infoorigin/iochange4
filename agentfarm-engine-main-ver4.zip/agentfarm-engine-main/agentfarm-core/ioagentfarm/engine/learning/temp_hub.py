"""Temporary skill hub — a stand-in for the enterprise hub so the full v2
learning cycle (submit -> govern -> ingest -> telemetry) can be tested end to
end before the real hub contract is wired.

This DEFINES the contract HttpHubClient speaks (since we own both ends here):

  POST   /hub/skills                      submit a draft        -> {submission_id, skill_id, status}
  GET    /hub/skills?role=&workflow=&status=approved   ingest approved skills (list)
  GET    /hub/skills/all                  inspect everything (governance view)
  POST   /hub/skills/{skill_id}/approve   governance: approve   (human action, simulated)
  POST   /hub/skills/{skill_id}/reject    governance: reject
  POST   /hub/telemetry/{skill_id}        post-approval field telemetry

File-backed under ``$IOF_ROOT/temp_hub/`` so state survives restarts and tests
can point IOF_ROOT at a tmp dir.  Single-process; not for production.

Run standalone:
    IOF_ROOT=.iof uvicorn ioagentfarm.engine.learning.temp_hub:app --port 8900
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from ioagentfarm.engine.learning.v2_models import DraftSubmission

app = FastAPI(title="ioagentfarm temp skill hub")


# ---------------------------------------------------------------------------
# File-backed store (path resolved per-request so tests can set IOF_ROOT)
# ---------------------------------------------------------------------------

def _store_path() -> Path:
    root = Path(os.environ.get("IOF_ROOT", ".iof"))
    d = root / "temp_hub"
    d.mkdir(parents=True, exist_ok=True)
    return d / "skills.json"


def _load() -> Dict[str, Dict[str, Any]]:
    p = _store_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(data: Dict[str, Dict[str, Any]]) -> None:
    _store_path().write_text(json.dumps(data, indent=2), encoding="utf-8")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.post("/hub/skills")
def submit(draft: DraftSubmission) -> Dict[str, Any]:
    """Submit an agent-authored draft (status forced to 'draft')."""
    data = _load()
    submission_id = "sub_" + uuid.uuid4().hex[:12]

    if draft.action.value == "refine" and draft.target_skill_id:
        skill_id = draft.target_skill_id  # patch lands on the existing skill on approve
    else:
        skill_id = "skl_" + uuid.uuid4().hex[:12]

    record = json.loads(draft.model_dump_json())
    record.update(
        {
            "skill_id": skill_id,
            "submission_id": submission_id,
            "status": "draft",
            "created_at": _now(),
            "updated_at": _now(),
        }
    )
    # A refine draft is stored under a submission-scoped key so it doesn't
    # clobber the live approved record until approved.
    store_key = submission_id if record["action"] == "refine" else skill_id
    data[store_key] = record
    _save(data)
    return {"submission_id": submission_id, "skill_id": skill_id, "status": "draft"}


@app.post("/hub/skills/{ident}/approve")
def approve(ident: str) -> Dict[str, Any]:
    """Governance action — flip a draft to approved (simulates the human gate).

    ``ident`` may be a submission_id (refine drafts) or a skill_id (new drafts).
    """
    data = _load()
    rec = _find(data, ident)
    if rec is None:
        raise HTTPException(404, f"no draft for {ident}")

    if rec["action"] == "refine":
        target = data.get(rec["skill_id"])
        if target is not None:
            target["skill_md"] = rec["skill_md"]
            target["status"] = "approved"
            target["updated_at"] = _now()
            target["version"] = (target.get("version") or 1) + 1
        # drop the submission-scoped refine record now that it's merged
        data.pop(rec["submission_id"], None)
    else:
        rec["status"] = "approved"
        rec["updated_at"] = _now()
        rec["version"] = rec.get("version") or 1
    _save(data)
    return {"skill_id": rec["skill_id"], "status": "approved"}


@app.post("/hub/skills/{ident}/reject")
def reject(ident: str) -> Dict[str, Any]:
    data = _load()
    rec = _find(data, ident)
    if rec is None:
        raise HTTPException(404, f"no draft for {ident}")
    key = rec.get("submission_id") if rec["action"] == "refine" else rec["skill_id"]
    if key in data:
        data[key]["status"] = "rejected"
        data[key]["updated_at"] = _now()
    _save(data)
    return {"skill_id": rec["skill_id"], "status": "rejected"}


@app.get("/hub/skills")
def list_skills(role: str, workflow: str, status: str = "approved") -> Dict[str, Any]:
    """Ingest endpoint — approved skills for a (role, workflow) scope."""
    data = _load()
    out: List[Dict[str, Any]] = []
    for rec in data.values():
        sc = rec.get("scope") or {}
        if sc.get("role") == role and sc.get("workflow") == workflow and rec.get("status") == status:
            out.append(
                {
                    "skill_id": rec["skill_id"],
                    "scope": sc,
                    "skill_name": rec["skill_name"],
                    "skill_md": rec["skill_md"],
                    "version": str(rec.get("version") or 1),
                    "approved_at": rec.get("updated_at"),
                }
            )
    return {"skills": out}


@app.get("/hub/skills/all")
def list_all() -> Dict[str, Any]:
    return {"skills": list(_load().values())}


class TelemetryIn(BaseModel):
    metrics: Dict[str, Any]


@app.post("/hub/telemetry/{skill_id}")
def telemetry(skill_id: str, body: TelemetryIn) -> Dict[str, Any]:
    root = Path(os.environ.get("IOF_ROOT", ".iof")) / "temp_hub"
    root.mkdir(parents=True, exist_ok=True)
    p = root / "telemetry.json"
    log = []
    if p.exists():
        try:
            log = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            log = []
    log.append({"skill_id": skill_id, "at": _now(), **body.metrics})
    p.write_text(json.dumps(log, indent=2), encoding="utf-8")
    return {"ok": True, "skill_id": skill_id}


def _find(data: Dict[str, Dict[str, Any]], ident: str) -> Optional[Dict[str, Any]]:
    if ident in data:
        return data[ident]
    for rec in data.values():
        if rec.get("submission_id") == ident or rec.get("skill_id") == ident:
            return rec
    return None
