"""Layer 1: Append-only observation log from step execution.

Raw observations captured after every step completion. High volume,
low confidence — the raw material from which learned skills are curated.

Replaces MEMORY.md as the source of truth for agent observations.
Stored in PostgreSQL (shared across all pods) or SQLite (dev).
"""
from __future__ import annotations

import logging
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, List

from ioagentfarm.engine.db import DbAdapter

logger = logging.getLogger(__name__)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _uuid() -> str:
    return uuid.uuid4().hex[:12]


class LearningLog:
    """Append-only observation log scoped to role+workflow.

    Every step completion produces one or more observations.
    No updates, no deletes — pure append.
    """

    def __init__(self, adapter: DbAdapter):
        self._db = adapter

    def _conn(self) -> Any:
        return self._db.connect()

    @contextmanager
    def _tx(self):
        with self._conn() as con:
            self._db.init_connection(con)
            cursor = con.cursor()
            try:
                yield cursor
            finally:
                cursor.close()

    def _q(self, sql: str) -> str:
        ph = self._db.placeholder()
        if ph == "?":
            return sql
        return sql.replace("?", ph)

    def init(self) -> None:
        """Create the learning_log table."""
        auto_id = self._db.auto_id()
        with self._tx() as cursor:
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS learning_log (
                    id {auto_id},
                    entry_id TEXT NOT NULL UNIQUE,
                    run_id TEXT NOT NULL,
                    step_key TEXT NOT NULL,
                    role TEXT NOT NULL,
                    workflow TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );"""
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_learning_log_role_workflow "
                "ON learning_log(role, workflow);"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_learning_log_run "
                "ON learning_log(run_id);"
            )

    def append(
        self,
        *,
        run_id: str,
        step_key: str,
        role: str,
        workflow: str,
        content: str,
    ) -> str:
        """Append a raw observation. Returns entry_id."""
        entry_id = _uuid()
        now = _utc_now()
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "INSERT INTO learning_log "
                    "(entry_id, run_id, step_key, role, workflow, content, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)"
                ),
                (entry_id, run_id, step_key, role, workflow, content, now),
            )
        return entry_id

    def get_recent(
        self,
        *,
        role: str,
        workflow: str,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """Get recent observations for a role+workflow scope, newest first."""
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "SELECT * FROM learning_log "
                    "WHERE role=? AND workflow=? "
                    "ORDER BY created_at DESC LIMIT ?"
                ),
                (role, workflow, limit),
            )
            return [dict(r) for r in cursor.fetchall()]

    def get_for_run(self, run_id: str) -> List[Dict[str, Any]]:
        """Get all observations for a specific run."""
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "SELECT * FROM learning_log WHERE run_id=? ORDER BY created_at ASC"
                ),
                (run_id,),
            )
            return [dict(r) for r in cursor.fetchall()]

    def count(
        self,
        *,
        role: str | None = None,
        workflow: str | None = None,
    ) -> int:
        """Count observations with optional filters."""
        clauses = []
        params: list = []
        if role:
            clauses.append("role=?")
            params.append(role)
        if workflow:
            clauses.append("workflow=?")
            params.append(workflow)

        where = " AND ".join(clauses) if clauses else "1=1"
        with self._tx() as cursor:
            cursor.execute(
                self._q(f"SELECT COUNT(*) as cnt FROM learning_log WHERE {where}"),
                tuple(params),
            )
            return dict(cursor.fetchone())["cnt"]
