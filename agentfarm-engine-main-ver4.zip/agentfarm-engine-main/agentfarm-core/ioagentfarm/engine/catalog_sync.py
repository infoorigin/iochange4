"""Agent + workflow catalog sync — the DB rows the studio reads.

WHY THIS IS A MODULE AND NOT TWO ENDPOINT BODIES. Both operations are pure
"re-read the installed packs and upsert rows"; neither touches server state.
They existed only as ``POST /api/agents/sync`` and ``POST /api/workflows/sync``
on the engine web API, so the documented setup was two ``curl`` calls that
require the engine to be running — and CLIENT_SETUP.md has to warn, twice, what
breaks when you forget them:

    "Skip 8a and every workspace shows the same unscoped agent list"

That is exactly what a first-time operator sees: right after a successful
``workspace push`` the Studio's agent list carries every OTHER solution's
agents, because ``agents.pack`` — the column the studio scopes on — has never
been written. The remedy was a curl to a service they may not have started yet.

With the work here, ``aicore sync`` performs both, and ``setup-agents``
runs the agent half automatically at the moment it seeds the workspaces. The
HTTP endpoints call these same functions, so the two surfaces cannot drift.

SKILLS were the missing third (2026-08). Agents had ``agents.pack`` and
workflows had a sync; skills had NO global catalog anywhere, so on an API pod
with no packs installed — the correct deployment — the Studio listed no
``presentation``, no ``data_query``, no ``guardrails``: a pack skill reached
the database only as an assignment-only ``studio_skills`` row, which records
who holds it and carries no name, description or body by design.
:func:`sync_pack_skills` fills that gap; see the block comment above it for
why a global catalog row is not the tenant copy the shared tier forbids.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

logger = logging.getLogger("ioagentfarm")

#: Display styles for core's own agents. STYLES LOOKUP ONLY — never a source of
#: roles. Entries exist for core agents; everything else gets derive_style().
AGENT_STYLES: dict[str, dict[str, str]] = {
    "cora":         {"title": "Core Assistant", "color": "#888888", "avatar": "CA"},
    "queryngine":   {"title": "Queryngine",   "color": "#E67E22", "avatar": "QN"},
    "project_lead": {"title": "Project Lead", "color": "#4A90D9", "avatar": "AL"},
}


def derive_style(role: str, name: str) -> dict[str, str]:
    """Display style for a role with no hand-authored entry in AGENT_STYLES.

    ``title`` is the role LABEL a human reads, not the slug. ``avatar`` derives
    from the agent's NAME, not the role — deriving from the role gave every
    ``pharma_*`` role the same "PH" initials.
    """
    title = re.sub(r"[_-]+", " ", role).title()
    parts = [p for p in re.split(r"[\s_-]+", name or "") if p]
    if len(parts) >= 2:
        avatar = (parts[0][0] + parts[1][0]).upper()
    elif parts:
        avatar = parts[0][:2].upper()
    else:
        avatar = role[:2].upper()
    return {"title": title, "color": "#888888", "avatar": avatar}


def role_pack_map() -> dict[str, str]:
    """role -> ``Pack.name`` for every pack-bundled agent ("core" = built-in).

    First source wins, matching the order the engine resolves agent workspaces.
    """
    mapping: dict[str, str] = {}
    try:
        from ioagentfarm.packs import load_registry
        for pack in load_registry().packs:
            root = pack.agents
            if root is None:
                continue
            pname = pack.name
            try:
                for entry in root.iterdir():
                    if entry.name.startswith("_"):
                        continue   # inject.yaml content dirs, not agents
                    try:
                        if (entry / "workspace" / "SOUL.md").is_file():
                            prior = mapping.get(entry.name)
                            if prior is None:
                                mapping[entry.name] = pname
                            elif prior != pname:
                                logger.warning(
                                    "agent role %r shipped by pack %r and again "
                                    "by pack %r — %r wins (registry order); "
                                    "agents.pack will say %r",
                                    entry.name, prior, pname, prior, prior)
                    except OSError:
                        continue
            except OSError:
                continue
    except Exception as exc:
        logger.warning("pack registry unavailable; agents.pack will be blank: %s",
                       exc)
    return mapping


def sync_agents(store, prune: bool = False) -> list[dict[str, Any]]:
    """Upsert one ``agents`` row per bundled agent: provenance AND content.

    ``agents.pack`` is what lets the studio scope a workspace's agent list to
    its own solution. Until this runs, that column is empty and every tenant
    sees every installed pack's agents.

    ``soul`` / ``tools_md`` / ``skills_json`` are the same argument carried to
    the DETAIL screen. The Studio API pod has no packs and no agent home, so
    without them it can list an agent and not open it. They are the wheel's
    text VERBATIM, rewritten by every sync — a mirror, never tenant content.

    ``prune=True`` (opt-in, unlike the skills sync which always prunes)
    additionally deletes rows whose role is gone from every installed pack —
    but ONLY rows attributed to a pack THIS environment has. Rows with a
    blank or unknown ``pack`` are another host's knowledge: agents rows are
    written from partial environments (a packs-blind pod answers "" for every
    pack), so an unconditional prune here would delete agents that merely
    aren't installed locally. That asymmetry with ``pack_skills`` is why the
    default stays False.
    """
    from ioagentfarm.engine.workspaces import (
        _agent_names, get_agent_name, list_bundled_agents,
    )

    # This is the declared "re-read the world" operation, but _agent_names() is
    # lru_cached for the process lifetime — without the invalidation a renamed
    # agent keeps its old name here until the server restarts.
    _agent_names.cache_clear()

    now = store._now()
    pack_map = role_pack_map()
    synced: list[dict[str, Any]] = []

    # Real agents only: bundled workspaces (core + installed packs).
    # AGENT_STYLES must NOT contribute roles — it is a display lookup, and
    # unioning its keys used to insert rows for agents that don't exist.
    for role in list_bundled_agents():
        try:
            name = get_agent_name(role)
        except Exception:
            name = role
        style = AGENT_STYLES.get(role) or derive_style(role, name)
        pack = pack_map.get(role, "")
        ws = _agent_workspace_source(role)
        soul = _read_text(ws / "SOUL.md") if ws is not None else ""
        tools_md = _read_text(ws / "TOOLS.md") if ws is not None else ""
        skills = _workspace_skill_names(ws) if ws is not None else []

        with store._tx() as cursor:
            cursor.execute(store._q("SELECT pack FROM agents WHERE role=?"),
                           (role,))
            existing = cursor.fetchone()
            if existing is not None:
                # A BLANK NEVER OVERWRITES A KNOWN PACK. `pack_map` is built
                # from the packs installed in THIS process, so a host that does
                # not have the pack answers "" — which is ignorance, not the
                # statement that the agent belongs to no solution. Writing it
                # through erased the provenance the studio scopes on, and the
                # tenant's own agent disappeared from its workspace: exactly the
                # pod case, where the agent is rebuilt from the database and the
                # pack is deliberately absent.
                prior = (existing["pack"] if hasattr(existing, "keys")
                         else existing[0]) or ""
                pack = pack or prior
                cursor.execute(
                    store._q("UPDATE agents SET name=?, title=?, avatar=?, "
                             "color=?, pack=?, seeded_at=? WHERE role=?"),
                    (name, style["title"], style["avatar"], style["color"],
                     pack, now, role))
            else:
                cursor.execute(
                    store._q("INSERT INTO agents(role, name, title, avatar, "
                             "color, pack, seeded_at) VALUES(?,?,?,?,?,?,?)"),
                    (role, name, style["title"], style["avatar"],
                     style["color"], pack, now))

        # Same "ignorance never overwrites knowledge" rule as `pack`: a host
        # that cannot see this agent's files must not blank a persona another
        # host published. Separate statement so a schema that predates the
        # columns still gets the row above.
        if soul.strip():
            try:
                with store._tx() as cursor:
                    cursor.execute(
                        store._q("UPDATE agents SET soul=?, tools_md=?, "
                                 "skills_json=? WHERE role=?"),
                        (soul, tools_md, json.dumps(skills), role))
            except Exception:
                logger.debug("agents.soul not writable for %r (older schema?)",
                             role, exc_info=True)

        synced.append({"role": role, "name": name, "pack": pack,
                       "skills": len(skills), **style})

    if prune:
        _prune_agent_rows(store, keep=[r["role"] for r in synced])
    return synced


def _prune_agent_rows(store, keep: list[str]) -> int:
    """Delete ``agents`` rows for roles gone from every installed pack —
    restricted to rows whose ``pack`` this environment actually has.

    A blank ``pack`` (written by a packs-blind host) or an unknown one (a
    wheel not installed HERE) is someone else's knowledge; deleting those
    from a partial environment is how a deployment loses agents that were
    never wrong. An empty roster is refused outright, same as ``_prune``.
    """
    if not keep:
        logger.warning("agents prune skipped: empty roster — refusing to "
                       "empty the table")
        return 0
    try:
        from ioagentfarm.packs import load_registry
        known = sorted({p.name for p in load_registry().packs})
    except Exception:
        logger.warning("agents prune skipped: pack registry unavailable")
        return 0
    if not known:
        return 0
    with store._tx() as cursor:
        marks = ",".join("?" * len(keep))
        pmarks = ",".join("?" * len(known))
        cursor.execute(
            store._q(f"DELETE FROM agents WHERE role NOT IN ({marks}) "
                     f"AND pack IN ({pmarks})"),
            (*keep, *known))
        n = cursor.rowcount if cursor.rowcount and cursor.rowcount > 0 else 0
    if n:
        logger.info("agents: pruned %d role(s) no longer in any installed "
                    "pack", n)
    return n


# ── the pack catalog: what the installed wheels contain ─────────────────
#
# WHY. The API pod and the engine pod are separate and never co-located: the
# API has no packs, no agent home and no state directory, so it cannot answer
# "what does `presentation` say?" or "what is Quinn's persona?" by reading
# anything. Until this it did — the Studio scanned `~/.iobot/agents` — and
# that is the shared root cause of three walkthrough bugs: a tenant rebuilt
# from the database showed no agents, a newly imported agent stayed invisible
# behind a cache, and the scanned path was the pre-rename one the engine has
# not written since `~/.iobot`.
#
# `agents.pack` already established the shape: the engine, which HAS the
# wheels, publishes into the database and the API reads the row. AGENTS get
# three more columns on that same global catalog table (`soul`, `tools_md`,
# `skills_json`). SKILLS had no global catalog at all — only per-workspace
# `studio_skills`, whose pack rows are assignment-only by design — so they get
# one: `pack_skills`.
#
# WHY THIS IS NOT "a tenant copy of pack content", the one thing the shared
# tier forbids:
#   * not workspace-keyed. One row per role/skill for the whole deployment, so
#     an SDK upgrade lands everywhere at once; a per-workspace copy would be N
#     copies free to drift, which is the fork problem one level down.
#   * nothing MATERIALISES from it. Hydration resolves an assignment-only
#     skill row from the WHEEL (`workspaces.shared_skill_files`), never from
#     here, and `workspace pull` never writes it to a solution repo.
#   * REPLACED, not accumulated. Every sync rewrites what it finds and DELETES
#     what it does not, so a changed description or a skill dropped from the
#     wheel is picked up by re-running the sync. A write-once cache would
#     reproduce, one layer over, exactly the staleness the rule exists to
#     prevent.
#
# A tenant row (`studio_agent_defs`, a `studio_skills` content row) always
# WINS on read. `used_by` is never taken from here: carriage is assignment,
# and assignment lives in `studio_skills.roles_json` for every tier.


def _agent_workspace_source(role: str):
    """The directory this role's identity actually comes from, or None.

    Live workspace first, then the pack templates — the same order
    ``_agent_names()`` resolves a display name in, so the mirror describes what
    an operator on this host would see. It matters that live wins: shared
    skills are INJECTED at seed time (``skill_defaults``, ``inject.yaml``), so
    a pack template alone under-reports what the agent runs with.
    """
    from ioagentfarm.engine.workspaces import _agent_roots, iobot_agent_workspace

    try:
        live = iobot_agent_workspace(role)
        if (live / "SOUL.md").is_file():
            return live
    except OSError:
        pass
    # Traversable, NOT Path(str(root)): core's agent root is a MultiplexedPath
    # whose str() is a repr, so the Path form silently found nothing and Jarvis
    # synced with an empty persona while every entry-point pack synced fine.
    for root in _agent_roots():
        try:
            ws = root / role / "workspace"
            if (ws / "SOUL.md").is_file():
                return ws
        except (OSError, TypeError, NotADirectoryError):
            continue
    return None


def _read_text(path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _workspace_skill_names(ws) -> list[str]:
    try:
        return sorted(d.name for d in (ws / "skills").iterdir()
                      if d.is_dir() and (d / "SKILL.md").is_file())
    except (OSError, TypeError, NotADirectoryError):
        return []


def _prune(store, table: str, key: str, keep: list[str]) -> int:
    """Delete every row of *table* whose *key* is not in *keep*.

    The half of "refreshed on every sync" that is easy to forget: without it a
    skill deleted from the wheel keeps its catalog row for ever, and the Studio
    offers an agent a skill that no longer exists anywhere.

    An EMPTY keep-set is refused, not honoured. "This environment sees zero
    packs" is far more often a broken venv or a packs-blind host than a real
    uninstall-everything, and the old behaviour — truncate the whole table —
    destroyed a correct catalog silently. A host that genuinely removed every
    pack can clear the table deliberately.
    """
    if not keep:
        logger.warning(
            "prune of %s skipped: keep-set is empty (no packs visible from this "
            "environment) — refusing to truncate the whole table", table)
        return 0
    with store._tx() as cursor:
        marks = ",".join("?" * len(keep))
        cursor.execute(
            store._q(f"DELETE FROM {table} WHERE {key} NOT IN ({marks})"),
            tuple(keep))
        return cursor.rowcount if cursor.rowcount and cursor.rowcount > 0 else 0


def pack_skill_sources() -> dict[str, tuple[Any, str]]:
    """``{skill_name: (dir, pack)}`` for every skill the INSTALLED PACKS ship.

    Three shapes, all of which a pack legitimately uses:
      * ``Pack.skills`` — the shared-skills wheel's top-level roots;
      * ``Pack.agents/<role>/workspace/skills/`` — a skill that belongs to one
        agent;
      * ``Pack.agents/_<x>/skills/`` — the ``inject.yaml`` content directories
        (and the legacy ``_common/skills``).

    First source wins, in registry order — the same precedence the engine
    resolves a skill by, so the mirror cannot describe a different file from
    the one that would be materialised.

    A name claimed by two PACK-LEVEL roots (``Pack.skills`` of two packs) is
    warned about: that first-wins is silent and used to be install-order
    dependent. An agent-workspace-local copy shadowing a shared name is NOT
    warned — that is the designed per-agent override mechanism.
    """
    out: dict[str, tuple[Any, str]] = {}
    _shared_tier: dict[str, bool] = {}   # name -> claimed by a Pack.skills root

    def _take(root, pack: str, shared: bool = False) -> None:
        try:
            entries = list(root.iterdir())
        except (OSError, TypeError, NotADirectoryError):
            return
        for entry in entries:
            try:
                if (entry / "SKILL.md").is_file():
                    prior = out.get(entry.name)
                    if prior is None:
                        out[entry.name] = (entry, pack)
                        _shared_tier[entry.name] = shared
                    elif (shared and _shared_tier.get(entry.name)
                          and prior[1] != pack):
                        logger.warning(
                            "skill %r shipped at pack level by both %r and %r "
                            "— %r wins (registry order); pack_skills mirrors "
                            "%r's copy", entry.name, prior[1], pack,
                            prior[1], prior[1])
            except (OSError, TypeError, NotADirectoryError):
                continue

    try:
        from ioagentfarm.packs import load_registry
        packs = load_registry().packs
    except Exception as exc:
        logger.warning("pack registry unavailable; pack_skills will be empty: %s",
                       exc)
        return out

    for pack in packs:
        label = pack.name
        if pack.skills is not None:
            _take(pack.skills, label, shared=True)
        if pack.agents is None:
            continue
        try:
            entries = list(pack.agents.iterdir())
        except (OSError, TypeError, NotADirectoryError):
            continue
        for entry in entries:
            try:
                if entry.name.startswith("."):
                    continue
                if entry.name.startswith("_"):
                    _take(entry / "skills", label)          # inject.yaml dirs
                else:
                    _take(entry / "workspace" / "skills", label)
            except (OSError, TypeError, NotADirectoryError):
                continue
    return out


def sync_pack_skills(store) -> list[dict[str, Any]]:
    """Mirror every pack-shipped skill's SKILL.md into ``pack_skills``.

    THE MISSING SYNC. Agents had ``POST /api/agents/sync`` and workflows had
    theirs; skills had none, so on a pod with no packs every SDK skill —
    ``presentation``, ``data_query``, ``guardrails``, ``vectorfs_query`` —
    simply did not exist as far as the Studio was concerned. The only trace a
    pack skill left in the database was an assignment-only ``studio_skills``
    row, which records who holds it and carries no name, no description and no
    body by design.

    ``shared`` comes from ``reserved_names()`` (core + the shared-skills
    wheel), not a hardcoded list, so a skill added to the wheel is marked
    automatically — it is what tells the Studio the skill may not be edited
    into a tenant fork.
    """
    try:
        from ioagentfarm.workspace_sync import reserved_names
        _, shared = reserved_names()
    except Exception:
        logger.warning("reserved_names unavailable; no skill will be marked "
                       "shared, so the Studio cannot refuse a tenant fork",
                       exc_info=True)
        shared = set()

    now = store._now()
    out: list[dict[str, Any]] = []
    for name, (d, pack) in sorted(pack_skill_sources().items()):
        text = _read_text(d / "SKILL.md")
        if not text.strip():
            continue
        is_shared = 1 if name in shared else 0
        with store._tx() as cursor:
            cursor.execute(store._q("SELECT name FROM pack_skills WHERE name=?"),
                           (name,))
            if cursor.fetchone() is not None:
                cursor.execute(
                    store._q("UPDATE pack_skills SET pack=?, shared=?, "
                             "skill_md=?, synced_at=? WHERE name=?"),
                    (pack, is_shared, text, now, name))
            else:
                cursor.execute(
                    store._q("INSERT INTO pack_skills(name, pack, shared, "
                             "skill_md, synced_at) VALUES(?,?,?,?,?)"),
                    (name, pack, is_shared, text, now))
        out.append({"name": name, "pack": pack, "shared": bool(is_shared)})

    removed = _prune(store, "pack_skills", "name", [r["name"] for r in out])
    if removed:
        logger.info("pack_skills: pruned %d skill(s) no longer in any pack",
                    removed)
    return out


def pack_workflow_dirs() -> dict[str, Any]:
    """``{code: dir}`` for every workflow the INSTALLED PACKS ship.

    From the pack registry, which is the only correct source. The Studio API
    had its own copy of this that globbed
    ``IOF_AGENTFARM_DIR/solutions/*/*/*/workflows/*/workflow.yaml`` — a REPO
    LAYOUT — so it found workflows only on a developer's checkout and, on a
    pod, silently synced nothing while reporting success.
    """
    from ioagentfarm.packs import load_registry

    out: dict[str, Any] = {}
    for root in load_registry().workflow_sources():
        try:
            entries = list(root.iterdir())
        except (OSError, TypeError, NotADirectoryError):
            continue
        for entry in entries:
            try:
                if (entry / "workflow.yaml").is_file():
                    out.setdefault(entry.name, entry)
            except (OSError, TypeError, NotADirectoryError):
                continue
    return out


def workflow_pack_map() -> dict[str, str]:
    """``{workflow code: pack name}`` — which FAMILY ships each workflow.

    ``Pack.name`` is the workspace-family code, so this answers the scoping
    question (``include_packs``); :func:`workflow_solution_map` answers the
    finer attribution question — which solution within the family.
    """
    from ioagentfarm.packs import load_registry

    out: dict[str, str] = {}
    for pack in load_registry().packs:
        if pack.workflows is None:
            continue
        label = pack.name
        try:
            entries = list(pack.workflows.iterdir())
        except (OSError, TypeError, NotADirectoryError):
            continue
        for entry in entries:
            try:
                if (entry / "workflow.yaml").is_file():
                    out.setdefault(entry.name, label)
            except (OSError, TypeError, NotADirectoryError):
                continue
    return out


def workflow_solution_map() -> dict[str, str]:
    """``{workflow code: solution code}`` — which SOLUTION owns each workflow.

    ``Pack.solution or Pack.name``: a pack that does not set ``solution`` IS
    the solution (the workspace-of-one case, and every pack that predates the
    field). Written into ``studio_workflow_defs.solution`` by the sync so the
    packs-blind Studio can attribute a workflow without the registry.
    """
    from ioagentfarm.packs import load_registry

    out: dict[str, str] = {}
    for pack in load_registry().packs:
        if pack.workflows is None:
            continue
        family = pack.name
        label = pack.solution or family
        try:
            entries = list(pack.workflows.iterdir())
        except (OSError, TypeError, NotADirectoryError):
            continue
        for entry in entries:
            try:
                if (entry / "workflow.yaml").is_file():
                    out.setdefault(entry.name, label)
            except (OSError, TypeError, NotADirectoryError):
                continue
    return out


def read_workflow_dir(d) -> tuple[str, dict[str, str]]:
    """``(workflow.yaml text, {rel: content})`` for one workflow directory."""
    yaml_text = (d / "workflow.yaml").read_text(encoding="utf-8")
    files: dict[str, str] = {}
    for sub in ("steps", "roles"):
        sd = d / sub
        try:
            if not sd.is_dir():
                continue
            entries = sorted(sd.iterdir(), key=lambda p: p.name)
        except (OSError, TypeError, NotADirectoryError):
            continue
        for f in entries:
            if f.name.endswith(".md"):
                files[f"{sub}/{f.name}"] = f.read_text(encoding="utf-8",
                                                       errors="replace")
    return yaml_text, files


def scoped_workspaces() -> dict[str, list[str]]:
    """``{workspace_code: [declared pack names]}`` for every SCOPED workspace.

    Reads ``studio_workspace_settings``, which the Studio owns — a plain DB
    read, not a pack read, so the engine may do it. ``default`` is absent by
    design: it is unscoped and imports the whole installed catalog.

    A row with an EMPTY include list is kept, and it means "no solution packs
    yet" — not "unscoped". Dropping it here would silently promote a
    deliberately-empty tenant to the full catalog.
    """
    from ioagentfarm.workspace_sync import connected
    from ioagentfarm.engine.workspaces import PLATFORM_TIER

    out: dict[str, list[str]] = {}
    try:
        with connected() as (adapter, con):
            cur = con.cursor()
            cur.execute("SELECT workspace_code, include_packs "
                        "FROM studio_workspace_settings")
            for row in cur.fetchall():
                d = dict(row)
                code = d["workspace_code"]
                if code == PLATFORM_TIER:
                    continue
                out[code] = [p.strip() for p in
                             (d["include_packs"] or "").split(",") if p.strip()]
    except Exception:
        logger.debug("no studio_workspace_settings to scope by", exc_info=True)
    return out


def sync_workflow_defs(workspace_code: str,
                       include_packs: list[str] | None = None) -> dict:
    """Import the installed pack workflows into ``studio_workflow_defs``.

    THE ENGINE'S JOB, because it needs the packs. This used to live only in
    ``apps/agentfarm-api``, which is a pod with no packs installed — the same
    mistake as the Studio's agent-home scan, one surface over.

    Semantics preserved from that implementation, because deployments depend on
    them: a STUDIO-authored definition is never clobbered by a pack re-import
    (it is marked ``shadows_pack`` instead), and a refresh of the PLATFORM-TIER
    catalog PROPAGATES to every tenant still on pack content — without that,
    "sync" refreshes only the shared tier while the scoped tenants whose
    copies materialise into real runs stay stale.

    Overrides under ``<IOF_ROOT>/workflows`` are NOT read. They are a derived
    artifact regenerated FROM these rows; importing them back would make the
    derived tree an input and let a stale one overwrite the record.
    """
    from ioagentfarm.workspace_sync import connected, _table_columns
    from ioagentfarm.engine.workspaces import PLATFORM_TIER

    packs = pack_workflow_dirs()
    pack_map = workflow_pack_map() if include_packs is not None else {}
    solution_map = workflow_solution_map()
    results: list[dict] = []
    synced: dict[str, tuple[str, dict]] = {}

    with connected() as (adapter, con):
        # Attribution is written only where the column exists — checked once,
        # not per-row, because a failed statement poisons a PG transaction.
        # A DBA-managed schema that predates the column syncs fine without it.
        try:
            cols = _table_columns(con.cursor(), "studio_workflow_defs",
                                  adapter.placeholder() == "%s")
        except Exception:
            cols = set()
        has_solution = "solution" in (cols or set())

        for code in sorted(packs):
            if include_packs is not None \
                    and pack_map.get(code, "core") not in include_packs:
                continue
            try:
                yaml_text, files = read_workflow_dir(packs[code])
            except (OSError, UnicodeDecodeError) as exc:
                results.append({"code": code, "error": str(exc)})
                continue
            solution = solution_map.get(code, "") if has_solution else None
            existing = _wf_row(adapter, con, workspace_code, code)
            if existing and existing["source"] == "studio":
                if not existing["shadows_pack"]:
                    _wf_mark_shadow(adapter, con, workspace_code, code)
                results.append({"code": code, "source": "studio",
                                "action": "kept-studio"})
                continue
            _wf_upsert(adapter, con, workspace_code, code, yaml_text, files,
                       shadows_pack=False, solution=solution)
            synced[code] = (yaml_text, files)
            results.append({"code": code, "source": "pack-sync",
                            "action": "updated" if existing else "imported"})

        propagated: list[dict] = []
        if workspace_code == PLATFORM_TIER and synced:
            for ws_code, code in _wf_pack_sync_tenants(adapter, con,
                                                       sorted(synced)):
                yaml_text, files = synced[code]
                _wf_upsert(adapter, con, ws_code, code, yaml_text, files,
                           shadows_pack=False,
                           solution=(solution_map.get(code, "")
                                     if has_solution else None))
                propagated.append({"workspace": ws_code, "code": code})
        try:
            con.commit()
        except Exception:
            pass

    return {
        "synced": sum(1 for r in results if r.get("action") != "kept-studio"),
        "total": len(results),
        "workspace": workspace_code,
        "workflows": results,
        "propagated": propagated,
    }


# ── studio_workflow_defs row helpers (engine side) ──────────────────────

def _wf_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _wf_q(adapter, sql: str) -> str:
    return sql.replace("?", "%s") if adapter.placeholder() == "%s" else sql


def _wf_row(adapter, con, workspace_code: str, code: str) -> dict | None:
    cur = con.cursor()
    cur.execute(_wf_q(adapter,
        "SELECT code, source, shadows_pack FROM studio_workflow_defs "
        "WHERE workspace_code = ? AND code = ?"), (workspace_code, code))
    row = cur.fetchone()
    return dict(row) if row is not None else None


def _wf_mark_shadow(adapter, con, workspace_code: str, code: str) -> None:
    cur = con.cursor()
    cur.execute(_wf_q(adapter,
        "UPDATE studio_workflow_defs SET shadows_pack = 1, updated_at = ? "
        "WHERE workspace_code = ? AND code = ?"),
        (_wf_now(), workspace_code, code))


def _wf_upsert(adapter, con, workspace_code: str, code: str, yaml_text: str,
               files: dict[str, str], *, shadows_pack: bool,
               solution: str | None = None) -> None:
    """``solution=None`` means "do not touch the column" — the caller checked
    the schema once and passes None on a database that predates it. ``""`` is
    a real value (family-level / unattributed)."""
    from ioagentfarm.engine.hydration import workflow_content_hash

    now = _wf_now()
    cur = con.cursor()
    if solution is None:
        cur.execute(_wf_q(adapter,
            "INSERT INTO studio_workflow_defs (workspace_code, code, yaml, "
            "files_json, source, shadows_pack, synced_at, updated_at, "
            "content_hash, version) VALUES (?,?,?,?,'pack-sync',?,?,?,?,1) "
            "ON CONFLICT (workspace_code, code) DO UPDATE SET "
            "yaml = excluded.yaml, files_json = excluded.files_json, "
            "source = excluded.source, shadows_pack = excluded.shadows_pack, "
            "synced_at = excluded.synced_at, updated_at = excluded.updated_at, "
            "content_hash = excluded.content_hash, "
            "version = studio_workflow_defs.version + 1"),
            (workspace_code, code, yaml_text, json.dumps(files),
             1 if shadows_pack else 0, now, now,
             workflow_content_hash(yaml_text, files)))
        return
    cur.execute(_wf_q(adapter,
        "INSERT INTO studio_workflow_defs (workspace_code, code, yaml, "
        "files_json, source, shadows_pack, synced_at, updated_at, "
        "content_hash, version, solution) "
        "VALUES (?,?,?,?,'pack-sync',?,?,?,?,1,?) "
        "ON CONFLICT (workspace_code, code) DO UPDATE SET "
        "yaml = excluded.yaml, files_json = excluded.files_json, "
        "source = excluded.source, shadows_pack = excluded.shadows_pack, "
        "synced_at = excluded.synced_at, updated_at = excluded.updated_at, "
        "content_hash = excluded.content_hash, "
        "solution = excluded.solution, "
        "version = studio_workflow_defs.version + 1"),
        (workspace_code, code, yaml_text, json.dumps(files),
         1 if shadows_pack else 0, now, now,
         workflow_content_hash(yaml_text, files), solution))


def _wf_pack_sync_tenants(adapter, con, codes: list[str]) -> list[tuple[str, str]]:
    from ioagentfarm.engine.workspaces import PLATFORM_TIER
    cur = con.cursor()
    marks = ",".join("?" * len(codes))
    cur.execute(_wf_q(adapter,
        "SELECT workspace_code, code FROM studio_workflow_defs "
        f"WHERE workspace_code != ? AND source = 'pack-sync' "
        f"AND code IN ({marks})"), (PLATFORM_TIER, *codes))
    return sorted((r["workspace_code"], r["code"]) if isinstance(r, dict)
                  else (dict(r)["workspace_code"], dict(r)["code"])
                  for r in cur.fetchall())


def sync_workflows(store, workspace_code: str) -> list[dict[str, Any]]:
    """Upsert the engine's run-metadata row for every discoverable workflow.

    *workspace_code* is required, and the loader enumerates THAT workspace's
    tree — this used to call ``list_workflows()`` bare, which read the
    ambient/platform tree while writing rows under the caller's workspace: a
    cross-tenant content copy that looked like a successful sync.
    """
    from ioagentfarm.engine.workflow_loader import WorkflowLoader
    from ioagentfarm.engine.workspaces import (PLATFORM_TIER, _agent_names,
                                               get_agent_name)

    _agent_names.cache_clear()

    loader = WorkflowLoader()
    names = loader.list_workflows(workspace=workspace_code)
    synced: list[dict[str, Any]] = []

    for name in names:
        try:
            wf = loader.load(name, workspace=workspace_code)
            store.ensure_workspace(
                code=workspace_code,
                name=("Platform" if workspace_code == PLATFORM_TIER
                      else workspace_code.replace("_", " ").title()))
            wf_id = store.ensure_workflow(
                code=name,
                workspace_code=workspace_code,
                name=name.replace("_", " ").title(),
                description=wf.description or "",
                steps_json=json.dumps([s.key for s in wf.steps]),
                roles_json=json.dumps(list(wf.roles.keys())),
                team_json=json.dumps([{"role": m.role} for m in wf.team_roster]),
            )
            team = []
            for member in wf.team_roster:
                try:
                    team.append({"role": member.role,
                                 "name": get_agent_name(member.role)})
                except Exception:
                    team.append({"role": member.role, "name": member.role})
            synced.append({"name": name, "workflow_id": wf_id,
                           "steps": len(wf.steps),
                           "roles": list(wf.roles.keys()), "team": team})
        except Exception as exc:
            synced.append({"name": name, "error": str(exc)})
    return synced
