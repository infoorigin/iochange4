"""Run-side draft resolution — how one author's drafts reach a WORKFLOW RUN.

A draft run is "the installed pack plus THIS author's overlay", created by
``POST /api/run`` with ``draft_author`` and by nothing else. This module owns
the run side of that rule:

* :func:`resolve_for_run` — read the author's open drafts at run creation,
  refuse a ``project_lead`` agent draft (the DRIVER always executes on the
  shared home, so a draft there would be recorded on the run and never take
  effect — an applied-looking edit that changed nothing), and compute the
  workflow bytes the run must load and snapshot.
* ``instances/<run_id>/drafts.json`` (:func:`write_run_drafts` /
  :func:`load_run_drafts`) — the ONLY channel through which a spawned
  ``run-step`` subprocess learns the run is a draft run. The creating HTTP
  request is long gone by the time a step executes, possibly on another pod;
  a record that does not travel with the instance dir would make the first
  step of every draft run silently run pack bytes.
* :class:`RunDrafts` — applying the role's agent/skill drafts inside
  ``create_filtered_workspace``, so ``workspaces.py`` gains call sites only.

Must not import: ``ioagentfarm.web.*`` (this module runs in the ``run-step``
CLI subprocess and must not pull FastAPI into its import graph — the lazy
patch-arming work exists because that class of import tax was real), and the
Studio API never imports it (disk is engine-only, the same split as
``draft_files``).
"""

from __future__ import annotations

import json
import logging
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator, Sequence

from ioagentfarm.engine.drafts import (carried_skills, overlay,
                                       provenance_summary)
from ioagentfarm.engine.draft_files import apply_overlay, index_by_kind

logger = logging.getLogger(__name__)

#: Travels with the instance dir (S3 sync included), beside provenance.json.
DRAFTS_FILE = "drafts.json"

#: The driver role. A draft on it is refused, not silently ignored: the
#: driver is spawned on the SHARED agent home (web/spawn.py), so the overlay
#: could never be applied, while the run would still be stamped as a draft
#: run — the author would read "my draft ran" about bytes that did not.
DRIVER_ROLE = "project_lead"


class DraftRunRefused(ValueError):
    """A draft run that cannot honour what the author's drafts ask for."""


# ---------------------------------------------------------------------------
# reading a pack workflow tree (text files only — what a draft can overlay)
# ---------------------------------------------------------------------------

_SKIP_PARTS = ("__pycache__", "sessions")


def read_workflow_tree(base: Any, prefix: str = "") -> dict[str, str]:
    """``{rel_posix: text}`` for every UTF-8 file under a pack workflow dir.

    *base* is whatever ``WorkflowLoader._workflow_dir`` returned — a real
    ``Path`` on an editable install, a ``Traversable`` from a zipped wheel —
    so this walks the Traversable protocol rather than assuming a filesystem.
    Binary files are skipped: a draft overlays TEXT, and the snapshot keeps
    the pack's binaries by copying the pack tree itself (see
    ``snapshot_workflow``'s ``overlay=`` kwarg), never this map.
    """
    files: dict[str, str] = {}
    for entry in base.iterdir():
        name = entry.name
        if name in _SKIP_PARTS:
            continue
        rel = f"{prefix}{name}"
        try:
            if entry.is_dir():
                files.update(read_workflow_tree(entry, prefix=f"{rel}/"))
                continue
            if entry.is_file():
                files[rel] = entry.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue    # binary without a telling suffix — not overlayable
        except (OSError, TypeError):
            continue
    return files


# ---------------------------------------------------------------------------
# run creation
# ---------------------------------------------------------------------------

@dataclass
class DraftRunContext:
    """Everything ``start_run`` needs to make one run a draft run."""

    author: str
    #: The author's open draft rows (any kind), files parsed.
    drafts: list[dict] = field(default_factory=list)
    #: Full merged text tree (pack (+) draft) for the run's workflow — what
    #: the loader parses. ``None`` when the author holds no draft of it.
    workflow_files: dict | None = None
    #: The RAW workflow draft overlay (``None`` values = deletions) — what
    #: the snapshot applies ON TOP of the pack copy. Kept separate from
    #: ``workflow_files`` deliberately: the merged map cannot express a
    #: deletion, and it drops the pack's binary files (a catalog's data
    #: assets), both of which the snapshot must honour.
    workflow_overlay: dict | None = None

    def as_provenance(self) -> dict:
        """What provenance.json and the run.created event carry: enough to
        say WHICH drafts shaped this run, without any content."""
        return {"author": self.author, "items": provenance_summary(self.drafts)}


def resolve_for_run(store: Any, workspace_code: str, author: str,
                    workflow_name: str) -> DraftRunContext | None:
    """The author's draft context for a new run, or ``None`` when they hold
    no open drafts (the run then proceeds exactly as an ordinary one).

    Raises :class:`DraftRunRefused` on a ``project_lead`` agent draft — see
    :data:`DRIVER_ROLE` for why refusal beats silence.
    """
    author = (author or "").strip().lower()
    if not author:
        return None
    from ioagentfarm.engine.drafts import for_author
    drafts = for_author(store, workspace_code, author)
    if not drafts:
        return None

    for d in drafts:
        if d.get("kind") == "agent" and d.get("name") == DRIVER_ROLE:
            raise DraftRunRefused(
                f"a draft on role '{DRIVER_ROLE}' cannot run: the driver "
                "executes on the shared agent home, so the draft could not "
                "take effect and the run would falsely claim it did. "
                "Discard or promote that draft first.")

    ctx = DraftRunContext(author=author, drafts=drafts)
    wf_draft = next((d for d in drafts
                     if d.get("kind") == "workflow"
                     and d.get("name") == workflow_name), None)
    if wf_draft is not None:
        from ioagentfarm.engine.workflow_loader import WorkflowLoader
        base_dir = WorkflowLoader()._workflow_dir(workflow_name)
        base = read_workflow_tree(base_dir) if base_dir is not None else {}
        ctx.workflow_overlay = dict(wf_draft.get("files") or {})
        ctx.workflow_files = overlay(base, ctx.workflow_overlay)
    return ctx


@contextmanager
def materialized_workflow(files: dict) -> Iterator[Path]:
    """The merged workflow tree on disk, for exactly one ``load_from_dir``.

    A temp dir rather than the instance dir on purpose: the loader validates
    BEFORE the run exists, and a failed validation must leave nothing behind
    that a later run id could collide with.
    """
    with tempfile.TemporaryDirectory(prefix="iof-draft-wf-") as td:
        target = Path(td)
        apply_overlay(target, files)
        yield target


# ---------------------------------------------------------------------------
# drafts.json — the per-run record
# ---------------------------------------------------------------------------

def _drafts_path(root_path: Path, run_id: str) -> Path:
    return Path(root_path) / "instances" / run_id / DRAFTS_FILE


def write_run_drafts(root_path: Path, run_id: str,
                     ctx: DraftRunContext) -> Path:
    """Persist the author + full draft set beside the run's snapshot."""
    doc = {
        "author": ctx.author,
        "drafts": [{
            "id": d.get("id"),
            "kind": d.get("kind"),
            "name": d.get("name"),
            "content_hash": d.get("content_hash"),
            "files": d.get("files") or {},
        } for d in ctx.drafts],
    }
    path = _drafts_path(root_path, run_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, indent=2, ensure_ascii=False),
                    encoding="utf-8")
    return path


def run_has_drafts(root_path: Path, run_id: str) -> bool:
    """Cheap existence probe — what ``run_step`` branches on."""
    try:
        return _drafts_path(root_path, run_id).is_file()
    except OSError:
        return False


class RunDrafts:
    """The drafts.json record, ready to apply inside a per-run workspace."""

    def __init__(self, author: str, drafts: Sequence[dict]):
        self.author = author
        self.drafts = list(drafts)
        self._by_kind = index_by_kind(self.drafts)

    def agent_draft(self, role: str) -> dict | None:
        return self._by_kind["agent"].get(role)

    def skill_names(self, role: str, baseline: Sequence[str]) -> list[str]:
        """The skill set the role's draft declares, or *baseline* untouched.

        Carriage REPLACES the baseline when declared (``_skills`` is the full
        list, same rule as ``materialize_draft_home``): an add-only merge
        would make a Studio-side skill REMOVAL invisible in the very run
        meant to try it.
        """
        d = self.agent_draft(role)
        wanted = carried_skills(d.get("files") if d else None)
        return list(wanted) if wanted is not None else list(baseline)

    def apply_agent_overlay(self, workspace: Path, role: str) -> None:
        """The role's agent draft onto the per-run workspace root.

        This is what supplies ``SOUL.md`` for a role only the draft
        introduces, so it must run BEFORE the fail-closed identity check.
        """
        d = self.agent_draft(role)
        if d is not None:
            apply_overlay(workspace, d.get("files"))

    def apply_skill_overlays(self, skills_dst: Path,
                             names: Sequence[str]) -> None:
        """Skill drafts for every carried name, onto the resolved skills.

        Runs AFTER base skill resolution on purpose: ``_resolve_skill``
        writes the pack's bytes into the destination, so an overlay applied
        earlier would be clobbered by its own base.
        """
        for name in names:
            d = self._by_kind["skill"].get(name)
            if d is None:
                continue
            (skills_dst / name).mkdir(parents=True, exist_ok=True)
            apply_overlay(skills_dst / name, d.get("files"))


def load_run_drafts(root_path: Path, run_id: str) -> RunDrafts | None:
    """The run's draft record, ``None`` for an ordinary run (no file).

    An EXISTING but unreadable record raises: the run was created as a draft
    run, and degrading it to pack bytes would execute content the author did
    not ask for while every stamp still says their draft ran. Loud beats
    wrong-bytes — the same fail-closed rule as the swarm roster read.
    """
    path = _drafts_path(root_path, run_id)
    if not path.is_file():
        return None
    try:
        doc = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(doc, dict):
            raise ValueError("drafts.json is not an object")
        return RunDrafts(str(doc.get("author") or ""),
                         [d for d in (doc.get("drafts") or [])
                          if isinstance(d, dict)])
    except (OSError, ValueError) as exc:
        raise RuntimeError(
            f"run {run_id} was created as a draft run but its {DRAFTS_FILE} "
            f"is unreadable ({exc}). Refusing to run the step on pack bytes "
            f"under a draft run's identity - fix or remove "
            f"instances/{run_id}/{DRAFTS_FILE} and retry.") from exc
