"""Boot gate: every CLI tool the installed packs declare must be on this host.

The One Truth model (docs/one-truth-content-model.md s4.2, scenario 11):
``serve`` validates the declared CLI tools at boot - "the one genuine host
fact - a binary on PATH is not derivable from any table; a missing one fails
boot instead of the first agent call". This is the same validate-only pass
as ``aicore cli-hub check`` (every pack's ``tools.yaml`` through
:func:`ioagentfarm.tools_resolver.resolve_all` with ``check_only=True``),
turned into a startup gate.

Why a gate and not a warning: an image missing ``iof-query`` still boots,
still warms its agents, still answers ``/ready`` - and every step that
execs the tool burns its attempts on ``command not found``, which the
forensics then report as an agent failure. Refusing to start names the
binary AND the pack that declares it, at the moment the operator is looking.

    IOF_TOOLS_CHECK=warn      log the gaps and boot anyway (the documented
                              escape hatch; default is strict)

Anything other than ``warn`` - unset, ``strict``, a typo - is strict: a
control fails closed.
"""

from __future__ import annotations

import logging
import os

from ioagentfarm.tools_resolver import (READY, ToolResult, ToolSpec,
                                        display_pack, resolve_all)

logger = logging.getLogger(__name__)

TOOLS_CHECK_ENV = "IOF_TOOLS_CHECK"
STRICT = "strict"
WARN = "warn"


class DeclaredToolsMissing(RuntimeError):
    """Raised at boot when a declared CLI tool is absent and the mode is strict.

    ``missing`` carries the resolver results so a caller can render them; the
    message names every binary with the pack that declares it and the two
    ways out (install it, or ``IOF_TOOLS_CHECK=warn``).
    """

    def __init__(self, missing: list[ToolResult]) -> None:
        self.missing = list(missing)
        named = ", ".join(
            f"{r.spec.name} (declared by {display_pack(r.spec.pack)}"
            + (f", bin={r.spec.bin}" if r.spec.bin else "") + ")"
            for r in self.missing)
        super().__init__(
            f"{len(self.missing)} declared CLI tool(s) missing on this host: "
            f"{named}. Install them (`aicore cli-hub install`) or bake them "
            f"into the image; `aicore cli-hub check` shows the same table. "
            f"Set {TOOLS_CHECK_ENV}=warn to boot anyway.")


#: The core pack's workspace code. Platform tools are everyone's business.
CORE_WORKSPACE = "core"


def tools_check_mode() -> str:
    """``'warn'`` when the escape hatch is set, else ``'strict'``.

    An unrecognised value is strict AND logged: a typo in an escape hatch
    must not silently disable the gate, and must not silently ignore the
    operator's intent either.
    """
    raw = (os.environ.get(TOOLS_CHECK_ENV) or "").strip().lower()
    if raw == WARN:
        return WARN
    if raw and raw != STRICT:
        logger.warning("%s=%r is not 'strict' or 'warn'; treating it as strict",
                       TOOLS_CHECK_ENV, raw)
    return STRICT


def declared_tool_specs(workspace_code: str | None = None) -> list[ToolSpec]:
    """Pack-declared ``tools.yaml`` entries, in registry order.

    Scoped to *workspace_code* when one is given, because ONE ENGINE VENV
    HOLDS EVERY WORKSPACE IT SERVES over its life. Unscoped, a tool declared
    by a pack belonging to a DIFFERENT workspace - a colleague's, or one from
    last month that is still pip-installed - is missing on this host and
    stops `serve` booting for a workspace that never needed it. Observed
    three times in one afternoon of independent validation, each time
    reported as "aicore serve refuses to start", each time about a tool
    belonging to somebody else's workspace.

    The core pack and any pack declaring no workspace are always included:
    those tools are the platform's, and their absence is this deployment's
    problem whichever workspace is being served.

    `aicore cli-hub check` keeps the unscoped view - "what does this
    environment declare in total" is the right question for that command.
    """
    from ioagentfarm.packs import load_registry
    registry = load_registry()
    if not workspace_code:
        return [ToolSpec.from_dict(raw, pack=raw.get("_pack", "?"))
                for raw in registry.tools()]

    owners = {p.pack: p.workspace for p in registry.packs}
    out: list[ToolSpec] = []
    for raw in registry.tools():
        declaring = raw.get("_pack", "?")
        owner = owners.get(declaring)
        if owner and owner not in (workspace_code, CORE_WORKSPACE):
            logger.debug(
                "tools gate: %r is declared by pack %r of workspace %r, not "
                "%r - not required here", raw.get("name"), declaring, owner,
                workspace_code)
            continue
        out.append(ToolSpec.from_dict(raw, pack=declaring))
    return out


def check_declared_tools(specs: list[ToolSpec] | None = None, *,
                         mode: str | None = None,
                         workspace_code: str | None = None) -> list[ToolResult]:
    """Validate every declared CLI tool (check-only; installs nothing).

    Every tool that is not READY - absent, or not validatable because its
    declaration names neither ``bin`` nor ``check`` (the manifest gap
    ``cli-hub check`` also reports) - is logged at ERROR, naming the binary
    and the declaring pack. Then, unless *mode* (default: the environment's)
    is ``'warn'``, :class:`DeclaredToolsMissing` is raised so the caller can
    refuse to start. Returns the full result list either way.
    """
    specs = declared_tool_specs(workspace_code) if specs is None else list(specs)
    mode = mode or tools_check_mode()
    results = resolve_all(specs, check_only=True)

    # AN OPTIONAL TOOL IS REPORTED, NEVER FATAL. The gate exists so a missing
    # binary is named at boot instead of burning a step's attempts on
    # `command not found` - and that reasoning holds only for a tool the
    # install can actually deliver. `vectorfs` is built from source and
    # published to no registry, so a plain `pip install` of the SDK could
    # never satisfy it: a client following the first walkthrough on a clean
    # machine hit `DeclaredToolsMissing` on their FIRST `aicore serve`, for a
    # tool nothing in that walkthrough uses. A gate that refuses every fresh
    # install is not a control, it is an outage.
    absent = [r for r in results if r.status != READY]
    optional = [r for r in absent if r.spec.optional]
    missing = [r for r in absent if not r.spec.optional]
    for r in optional:
        logger.warning(
            "optional CLI tool %r is not on this host - declared by pack %s"
            "%s. Booting without it; agents that exec it will fail. Install "
            "it with `aicore cli-hub install --allow-build --only %s`.",
            r.spec.name, display_pack(r.spec.pack),
            f" (bin={r.spec.bin})" if r.spec.bin else "", r.spec.name)
    for r in missing:
        logger.error(
            "declared CLI tool %r is MISSING on this host - declared by pack %s"
            "%s: %s", r.spec.name, display_pack(r.spec.pack),
            f" (bin={r.spec.bin})" if r.spec.bin else "", r.detail)
    if missing:
        if mode == WARN:
            logger.warning(
                "%d declared CLI tool(s) missing; booting anyway because "
                "%s=warn - agents that exec them will fail",
                len(missing), TOOLS_CHECK_ENV)
        else:
            raise DeclaredToolsMissing(missing)
    else:
        logger.info("declared CLI tools present: %s",
                    ", ".join(r.spec.name for r in results
                              if r.status == READY) or "(none declared)")
    return results
