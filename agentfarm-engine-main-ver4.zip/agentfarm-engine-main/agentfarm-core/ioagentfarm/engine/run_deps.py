"""`depends_on_runs:` — a workflow may not start while what it consumes is still producing.

THE DEFECT THIS CLOSES. A pipeline is often split across workflows: one
produces records, the next consumes them. Between STEPS that ordering is
expressed by ``deps:`` and enforced by the scheduler. Between RUNS nothing
expressed it at all, so nothing stopped both starting at once — and the
consumer then worked from whatever half of the input happened to exist,
producing output that is not wrong so much as founded on less evidence than it
appears to be. Nothing fails. Every gate is green.

Observed three times in a row, across three different phrasings of the
instruction: a vague goal, an explicit scope, and finally a numbered list
reading ``2. aicore run barrier_detection - only after 1 has
finished``. Every time the agent started the consumer immediately and explained
the gap away ("if it adds new signals later, that would be a maintenance
pass"). It is a capable agent reasoning its way past a rule, which is what
rules do when they are only stated: this codebase's own lesson is that a rule
stated to a model is a request. So this is the same rule as physics.

WHAT IT IS NOT. It does not wait. Blocking the CLI until a dependency finishes
is exactly the behaviour ``run_ops`` forbids, and it would make the caller's
timeout the run's timeout. It REFUSES, names the run that is in the way, and
tells the caller what to watch — so the decision to wait belongs to whoever is
driving, and costs them nothing while they do.

It also does not require that the dependency has ever run. Re-deriving barriers
from an existing corpus is legitimate, and a precondition that forbade it would
be refusing correct work to prevent a race that is not happening. The rule is
narrow on purpose: not WHILE it is producing.

    # barrier_detection/workflow.yaml
    depends_on_runs: [signal_detection]

Core stays domain-free: it reads its own runs table and nothing else.
"""

from __future__ import annotations

from typing import Any

#: Statuses that mean a run is still producing.
_ACTIVE = ("running", "pending")


def single_active(workflow: Any) -> bool:
    """``single_active_run: true`` - refuse a SECOND run of this workflow.

    The sibling of ``depends_on_runs``, for the case where a workflow consumes
    its own queue. Observed 2026-08-16: two ``signal_detection`` runs went in
    flight over the same fifty unprocessed notes, and both detected on all of
    them - the ``processed`` flag is set when a batch FINISHES, so both runs
    selected the same rows at the start and neither could see the other. One
    produced 104 signals, the other 30, over the same input.

    Steps have atomic claiming (``claim_next_runnable_step``); a domain's own
    queue rows have none, and core cannot give them any without knowing what
    they are. What core CAN do is refuse to start the second consumer, which
    removes the race at its source rather than trying to reconcile it after.
    """
    v = (workflow.get("single_active_run") if isinstance(workflow, dict)
         else getattr(workflow, "single_active_run", False))
    return str(v).strip().lower() in ("true", "1", "yes", "on")


def declared(workflow: Any) -> list[str]:
    """The ``depends_on_runs:`` names of a workflow, normalised.

    Read tolerantly, like ``learning:`` and the swarm markers: an engine that
    has never heard of the key ignores it rather than refusing to load the
    workflow, so adding it cannot break an older deployment.
    """
    raw = (workflow.get("depends_on_runs") if isinstance(workflow, dict)
           else getattr(workflow, "depends_on_runs", None))
    if not raw:
        return []
    if isinstance(raw, str):
        raw = [raw]
    return [str(x).strip() for x in raw if str(x).strip()]


def blocking_runs(store: Any, names: list[str], workspace_code: str | None = None,
                  ) -> list[dict]:
    """Active runs of *names*. Empty when nothing is in the way."""
    if not names:
        return []
    try:
        rows = store.list_runs(limit=200)
    except Exception:                                        # noqa: BLE001
        return []
    out = []
    for r in rows or []:
        row = dict(r)
        if row.get("workflow_name") not in names:
            continue
        if (row.get("status") or "") not in _ACTIVE:
            continue
        # A run in another tenant's workspace is not this caller's dependency.
        if workspace_code and row.get("workspace_code") not in (None, "", workspace_code):
            continue
        out.append(row)
    return out


def driver_notes(store, blocking: list[dict]) -> dict:
    """Per blocking run, a note when its driver is GONE - a `running` row
    whose driver was killed holds the queue forever, and a refusal that
    only says `[running]` sends the operator to wait for a run that will
    never finish (novice finding, round 5). Keyed by run id; a live driver
    has no entry. Never raises: a note is advice, the refusal stands."""
    notes: dict = {}
    for r in blocking:
        rid = r.get("id")
        try:
            from ioagentfarm.engine.supervisor import driver_state
            row = store.get_run(rid) or r
            ds = driver_state(row, store.list_steps(rid))
        except Exception:  # noqa: BLE001
            continue
        if ds.get("stale"):
            age = ds.get("heartbeat_age_s")
            notes[rid] = ("driver GONE - no heartbeat ever" if age is None
                          else f"driver GONE - no heartbeat for {age:.0f}s")
    return notes


def refusal(blocking: list[dict], workflow: str, driver_notes: dict | None = None) -> str:
    """What the caller is told. Names the run, whether its driver is alive,
    and what to do about it."""
    notes = driver_notes or {}
    lines = [f"{workflow} consumes what these runs are still producing, "
             f"so starting it now would work from part of the input:"]
    for r in blocking:
        note = notes.get(r.get("id"))
        lines.append(f"  {r.get('workflow_name')}  {r.get('id')}  "
                     f"[{r.get('status')}{' - ' + note if note else ''}]")
    first = blocking[0].get("id")
    dead = [r.get("id") for r in blocking if r.get("id") in notes]
    if dead:
        lines += [
            "",
            "A run whose driver is gone will not finish on its own; it holds the",
            "queue until something restarts it:",
            *[f"  aicore resume {d}" for d in dead],
            "(a service under `aicore serve` does this on its own - see",
            "Automatic recovery in the running-solutions docs).",
        ]
    live = [r.get("id") for r in blocking if r.get("id") not in notes]
    if live:
        lines += [
            "",
            "This is not a wait - the run outlives this command and records its own",
            "result. Watch it and start again when it is done:",
            f"  aicore status --run-id {live[0] if live else first} --json",
        ]
    lines += ["", "Use --allow-concurrent if working from a partial corpus is intended."]
    return "\n".join(lines)
