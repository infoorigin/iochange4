from __future__ import annotations
import re
from typing import Any, Dict, List, Optional, Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator


class _Model(BaseModel):
    """Every workflow model defers its pydantic schema build to first use:
    building seven schemas at import cost ~150ms of every CLI startup, and
    a `--help` never instantiates one."""
    model_config = ConfigDict(defer_build=True)

class Role(_Model):
    name: str
    prompt: str
    allowed_tools: List[str] = Field(default_factory=list)
    skills: Optional[List[str]] = None  # per-workflow skill filter; None = all skills
    model: Optional[str] = None  # per-role model override (e.g. "qwen/Qwen3-235B"); None = use config.json default

class StepTemplate(_Model):
    key_suffix: str
    title: str = ""
    role: str
    prompt: str = ""
    max_attempts: int = 2
    deps: List[str] = Field(default_factory=list)
    # per-step MCP tool allowlist — see Step.mcp_tools
    mcp_tools: Optional[List[str]] = None

class OnFail(_Model):
    """What a step's FAILURE does to the steps before it.

    `reset` names upstream steps to send back to pending - together with every
    step downstream of them that has already run, since their inputs are now
    stale - so the chain re-runs in dependency order and this step gets another
    attempt at the fresh result. Bounded by THIS step's `max_attempts`: when
    they are exhausted the failure is terminal and nothing is reset. That bound
    is written in the YAML where a reviewer sees it, which is the point.

    `feedback` names a file in the SHARED artifact dir this step writes before
    failing (a critique, a diff, a checklist). Its content lands in each reset
    target's FEEDBACK.md - the "Feedback from previous attempt" section of an
    agent step's prompt, `{{feedback}}` / IOF_STEP_FEEDBACK for an exec step.
    """
    reset: List[str] = Field(default_factory=list)
    feedback: str = ""


class Step(_Model):
    key: str
    title: str = ""
    role: str
    # `route`: runs `command` like exec, then its ROUTE_JSON decides which of
    # its declared `routes` run; the rest are closed as "skipped by route",
    # and so is anything reachable only through them. A `switch`, never a
    # `goto`: the universe of turns is in the YAML, so lint can see every
    # path and no run can invent a step.
    type: Literal["normal", "loop", "exec", "route"] = "normal"
    routes: List[str] = Field(default_factory=list)
    on_fail: Optional[OnFail] = None
    deps: List[str] = Field(default_factory=list)
    max_attempts: int = 2
    prompt: str = ""
    # exec steps: a step whose correct behaviour is fully deterministic runs a
    # command directly — no agent, no LLM turns, no copy-the-manifest fragility.
    # `command` is templated with the same {{var}} context as step prompts.
    # `stories_from` (optional) names a JSON file in the step's output dir whose
    # top-level `stories` array (or the whole file, if it IS an array) becomes
    # the step's STORIES_JSON — letting a deterministic tool anchor a loop
    # fan-out without an agent transcribing it.
    command: str = ""
    stories_from: str = ""
    # Seconds this exec step's command may run. None = IOF_EXEC_STEP_TIMEOUT_S,
    # the deployment-wide default. A ported pipeline's small/medium/large
    # timeout classes belong on the steps themselves — that is where a reader
    # looks for them — while the env var stays the floor under everything and
    # should sit above the largest step, or it fires first and the per-step
    # value never applies.
    timeout: Optional[int] = Field(default=None, ge=1)
    # sessioning
    fresh_session: bool = True  # if false, reuse a persistent role workspace within the run
    # loop
    loop_source_key: Optional[str] = None
    per_item_steps: List[StepTemplate] = Field(default_factory=list)
    # fail-closed artifact gate: deliverable files that MUST exist (non-empty)
    # in the step output dir before the step can be marked done. If any are
    # missing, the step is flipped to failed and retried — prevents a step
    # from claiming success without producing the handoff a downstream step
    # depends on (e.g. analyst never writes intelligence_report.md).
    requires_artifacts: List[str] = Field(default_factory=list)
    @property
    def runs_command(self) -> bool:
        """exec and route both run `command` with no agent."""
        return self.type in ("exec", "route")

    # per-step MCP tool allowlist (least privilege at the ENGINE level, not
    # prompt level). None = all merged servers' tools, unchanged. A list =
    # only these tools are registered for the step's agent (raw or wrapped
    # `mcp_<server>_<tool>` names — iobot's enabledTools matches both).
    # [] = the step gets NO MCP tools. Observed need: a generate-side agent
    # called publish_campaign_update unprompted before any approval existed;
    # a prompt allowlist is advice, this is enforcement.
    mcp_tools: Optional[List[str]] = None

class TeamMember(_Model):
    role: str

class SandboxWorkflowConfig(_Model):
    """Per-workflow sandbox configuration from workflow YAML.

    Controls how this workflow's runs are isolated via OpenShell sandboxes.
    Only used when IOF_RUNNER=sandbox.

    Validation:
    - policy: alphanumeric + hyphens/underscores only (prevents path traversal)
    - pool: same rules as policy
    - idle_timeout: must be >= 0
    """
    policy: str = "default"        # policy YAML name (resolves to sandbox_policies/<name>.yaml)
    prewarm: bool = False          # create sandbox at server startup?
    idle_timeout: int = 300        # seconds before idle sandbox is destroyed (0 = never)
    pool: Optional[str] = None     # share sandbox with other workflows using same pool name
    image: Optional[str] = None    # custom container image (default: openshell base)

    @field_validator("policy")
    @classmethod
    def validate_policy(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z0-9_-]+$", v) or len(v) > 64:
            raise ValueError(f"Invalid policy name '{v}': must be alphanumeric/hyphens/underscores, max 64 chars")
        return v

    @field_validator("pool")
    @classmethod
    def validate_pool(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and (not re.match(r"^[a-zA-Z0-9_-]+$", v) or len(v) > 64):
            raise ValueError(f"Invalid pool name '{v}': must be alphanumeric/hyphens/underscores, max 64 chars")
        return v

    @field_validator("idle_timeout")
    @classmethod
    def validate_idle_timeout(cls, v: int) -> int:
        if v < 0:
            raise ValueError(f"idle_timeout must be >= 0, got {v}")
        return v

class Workflow(_Model):
    name: str
    description: str = ""
    roles: Dict[str, Role]
    steps: List[Step]
    protocol: Dict[str, Any] = Field(default_factory=dict)
    team: str = ""  # contents of team.md (agent name-to-role mapping)
    team_roster: List[TeamMember] = Field(default_factory=list)  # from YAML team field
    sandbox: Optional[SandboxWorkflowConfig] = None  # per-workflow sandbox config
    vars: Dict[str, str] = Field(default_factory=dict)  # per-workflow template variables
    #: Workflows this one CONSUMES from. It is refused while one of them has a
    #: run still producing - `deps:` between steps, one level up. See
    #: engine/run_deps.py for why it refuses rather than waits.
    depends_on_runs: List[str] = Field(default_factory=list)
    #: Refuse a SECOND run of THIS workflow while one is active - for a
    #: workflow that consumes its own queue. See engine/run_deps.py.
    single_active_run: bool = False
    #: Commands describing what a run did NOT cover, executed at the completion
    #: transition and recorded as `run.coverage`. See engine/coverage.py.
    coverage: List[Any] = Field(default_factory=list)
