from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Dict, Any

_VAR_RE = re.compile(r"\{\{\s*([a-zA-Z0-9_\.:-]+)\s*\}\}")

def render(template: str, ctx: Dict[str, Any]) -> str:
    """Very small templater: replaces {{var}} from ctx (missing -> '')."""
    if not template:
        return ""

    def _get(key: str) -> str:
        cur: Any = ctx
        for part in key.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                return ""
        return "" if cur is None else str(cur)

    def _sub(m: re.Match) -> str:
        return _get(m.group(1))

    return _VAR_RE.sub(_sub, template)
