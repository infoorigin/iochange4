"""Per-workflow sandbox lifecycle manager.

Manages sandbox creation, pooling, prewarming, and idle timeout.

Security features:
    - Policy name validation (no path traversal)
    - Health checks after creation
    - Max concurrent sandbox limit
    - Race-safe cleanup (hold lock during destroy)
    - Audit logging for all lifecycle events
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from threading import Lock
from typing import TYPE_CHECKING

from ioagentfarm.engine.sandbox import (
    SandboxClient, SandboxInfo, get_sandbox_client,
    validate_policy_name, _audit_log,
)

if TYPE_CHECKING:
    from ioagentfarm.engine.models import SandboxWorkflowConfig

logger = logging.getLogger("ioagentfarm.sandbox_manager")

# Default max concurrent sandboxes — prevents resource exhaustion
DEFAULT_MAX_SANDBOXES = int(os.getenv("IOF_MAX_SANDBOXES", "20"))


class SandboxManager:
    """Manages per-workflow OpenShell sandboxes."""

    def __init__(
        self,
        client: SandboxClient | None = None,
        policies_dir: Path | None = None,
        max_sandboxes: int = DEFAULT_MAX_SANDBOXES,
    ):
        self._client = client or get_sandbox_client()
        self._policies_dir = policies_dir or self._default_policies_dir()
        self._max_sandboxes = max_sandboxes
        self._lock = Lock()

        # sandbox_name → SandboxInfo
        self._sandboxes: dict[str, SandboxInfo] = {}
        # workflow_name → sandbox_name
        self._workflow_map: dict[str, str] = {}
        # pool_name → sandbox_name
        self._pool_map: dict[str, str] = {}
        # sandbox_name → last used timestamp
        self._last_used: dict[str, float] = {}
        # sandbox_name → idle_timeout (0 = never destroy)
        self._idle_timeouts: dict[str, int] = {}
        # sandbox_name → prewarmed flag
        self._prewarmed: dict[str, bool] = {}
        # sandbox_name → currently in use count (prevents cleanup during execution)
        self._in_use: dict[str, int] = {}

    @staticmethod
    def _default_policies_dir() -> Path:
        """Bundled policy directory."""
        return Path(__file__).parent / "sandbox_policies"

    def _sandbox_name(self, workflow_name: str, pool: str | None = None) -> str:
        """Generate sandbox name from workflow or pool."""
        base = pool or workflow_name
        return f"iof-{base}".lower().replace("_", "-")

    def _policy_path(self, policy_name: str) -> Path | None:
        """Resolve policy YAML path with validation."""
        if not validate_policy_name(policy_name):
            logger.error("Invalid policy name: '%s' — must be alphanumeric/hyphens/underscores", policy_name)
            _audit_log("policy_invalid", policy=policy_name, reason="invalid characters or too long")
            return None
        path = self._policies_dir / f"{policy_name}.yaml"
        if path.exists():
            return path
        logger.warning("Policy file not found: %s", path)
        return None

    def prewarm(self, workflows: dict[str, "SandboxWorkflowConfig"]) -> int:
        """Create sandboxes for workflows with prewarm=true.

        Called at server startup. Runs health checks after creation.
        Returns count of sandboxes successfully created and verified.
        """
        created = 0
        for wf_name, config in workflows.items():
            if not config.prewarm:
                continue
            try:
                name = self.get_or_create(wf_name, config)
                # Health check: verify sandbox can execute commands
                if self._client.health_check(name):
                    created += 1
                    _audit_log("prewarm_ok", sandbox=name, workflow=wf_name)
                else:
                    logger.warning(
                        "Sandbox '%s' created but health check failed — may not work correctly",
                        name,
                    )
                    _audit_log("prewarm_unhealthy", sandbox=name, workflow=wf_name)
                    created += 1  # Still count as created; health check failure is a warning
            except Exception:
                logger.exception("Failed to prewarm sandbox for workflow '%s'", wf_name)
                _audit_log("prewarm_failed", workflow=wf_name)
        return created

    def get_or_create(
        self,
        workflow_name: str,
        config: "SandboxWorkflowConfig",
    ) -> str:
        """Get existing sandbox or create one. Returns sandbox name.

        Raises RuntimeError if max sandbox limit is reached.
        """
        with self._lock:
            # Already mapped?
            if workflow_name in self._workflow_map:
                name = self._workflow_map[workflow_name]
                self._last_used[name] = time.time()
                return name

            # Pool sharing?
            if config.pool and config.pool in self._pool_map:
                name = self._pool_map[config.pool]
                self._workflow_map[workflow_name] = name
                self._last_used[name] = time.time()
                logger.info(
                    "Workflow '%s' sharing sandbox '%s' (pool=%s)",
                    workflow_name, name, config.pool,
                )
                return name

            # Check max sandbox limit
            if len(self._sandboxes) >= self._max_sandboxes:
                _audit_log("limit_reached", max=self._max_sandboxes, workflow=workflow_name)
                raise RuntimeError(
                    f"Maximum sandbox limit ({self._max_sandboxes}) reached. "
                    f"Cannot create sandbox for workflow '{workflow_name}'. "
                    f"Increase IOF_MAX_SANDBOXES or use pool sharing."
                )

            # Validate policy name
            if not validate_policy_name(config.policy):
                raise ValueError(
                    f"Invalid policy name '{config.policy}' for workflow '{workflow_name}'. "
                    f"Policy names must be alphanumeric with hyphens/underscores only."
                )

            # Create new sandbox
            name = self._sandbox_name(workflow_name, config.pool)

            # Avoid recreating if sandbox already exists (e.g., from another workflow in same pool)
            if name not in self._sandboxes:
                policy_path = self._policy_path(config.policy)
                image = config.image if config.image else None
                info = self._client.create(name, policy_path=policy_path, image=image)
                info.workflow = workflow_name
                info.pool = config.pool
                info.policy = config.policy
                self._sandboxes[name] = info
                self._idle_timeouts[name] = config.idle_timeout
                self._prewarmed[name] = config.prewarm
                self._in_use[name] = 0

            self._workflow_map[workflow_name] = name
            if config.pool:
                self._pool_map[config.pool] = name
            self._last_used[name] = time.time()

            logger.info(
                "Sandbox '%s' ready for workflow '%s' (policy=%s, prewarm=%s, pool=%s)",
                name, workflow_name, config.policy, config.prewarm, config.pool,
            )
            return name

    def resolve_sandbox_name(self, workflow_name: str) -> str | None:
        """Resolve sandbox name for a workflow. Returns None if not mapped."""
        with self._lock:
            name = self._workflow_map.get(workflow_name)
            if name:
                self._last_used[name] = time.time()
            return name

    def acquire(self, sandbox_name: str) -> None:
        """Mark sandbox as in-use (prevents idle cleanup during execution)."""
        with self._lock:
            self._in_use[sandbox_name] = self._in_use.get(sandbox_name, 0) + 1
            self._last_used[sandbox_name] = time.time()

    def release(self, sandbox_name: str) -> None:
        """Mark sandbox as no longer in-use."""
        with self._lock:
            count = self._in_use.get(sandbox_name, 0)
            self._in_use[sandbox_name] = max(0, count - 1)
            self._last_used[sandbox_name] = time.time()

    def health_check_all(self) -> dict[str, bool]:
        """Health check all managed sandboxes. Returns name → healthy map.

        Called periodically to detect crashed sandboxes. Dead sandboxes
        are automatically destroyed and removed from mappings so they
        get recreated on next use.
        """
        results = {}
        dead = []

        with self._lock:
            names = list(self._sandboxes.keys())

        for name in names:
            healthy = self._client.health_check(name)
            results[name] = healthy
            if not healthy:
                dead.append(name)

        # Auto-recover: remove dead sandboxes so get_or_create rebuilds them
        if dead:
            with self._lock:
                for name in dead:
                    _audit_log("sandbox_dead", sandbox=name, detail="removing for auto-recovery")
                    logger.warning("Sandbox '%s' is dead — removing for auto-recovery", name)
                    self._sandboxes.pop(name, None)
                    self._last_used.pop(name, None)
                    self._idle_timeouts.pop(name, None)
                    self._prewarmed.pop(name, None)
                    self._in_use.pop(name, None)
                    self._workflow_map = {
                        wf: sb for wf, sb in self._workflow_map.items() if sb != name
                    }
                    self._pool_map = {
                        p: sb for p, sb in self._pool_map.items() if sb != name
                    }

                    # Try to destroy the dead sandbox (cleanup resources)
                    try:
                        self._client.destroy(name)
                    except Exception:
                        pass  # Already dead, destroy is best-effort

        return results

    def cleanup_idle(self) -> int:
        """Destroy sandboxes that exceeded their idle timeout.

        Thread-safe: holds lock during the entire destroy operation
        to prevent race conditions with concurrent get_or_create().
        Never destroys pre-warmed or in-use sandboxes.
        """
        now = time.time()

        with self._lock:
            to_destroy = []
            for name, last_used in list(self._last_used.items()):
                timeout = self._idle_timeouts.get(name, 0)
                if timeout <= 0:
                    continue  # 0 = never destroy
                if self._prewarmed.get(name, False):
                    continue  # Never destroy pre-warmed sandboxes
                if self._in_use.get(name, 0) > 0:
                    continue  # Currently in use — skip
                if (now - last_used) > timeout:
                    to_destroy.append(name)

            destroyed = 0
            for name in to_destroy:
                try:
                    self._client.destroy(name)
                    destroyed += 1
                    _audit_log("idle_destroyed", sandbox=name)
                except Exception:
                    logger.exception("Failed to destroy idle sandbox '%s'", name)
                    continue

                # Clean up all mappings while still holding the lock
                self._sandboxes.pop(name, None)
                self._last_used.pop(name, None)
                self._idle_timeouts.pop(name, None)
                self._prewarmed.pop(name, None)
                self._in_use.pop(name, None)
                self._workflow_map = {
                    wf: sb for wf, sb in self._workflow_map.items() if sb != name
                }
                self._pool_map = {
                    p: sb for p, sb in self._pool_map.items() if sb != name
                }

        if destroyed:
            logger.info("Cleaned up %d idle sandbox(es)", destroyed)
        return destroyed

    def list_sandboxes(self) -> list[SandboxInfo]:
        """List all managed sandboxes."""
        with self._lock:
            return list(self._sandboxes.values())

    def shutdown(self) -> None:
        """Destroy all managed sandboxes. Called at server shutdown."""
        with self._lock:
            names = list(self._sandboxes.keys())

        for name in names:
            try:
                self._client.destroy(name)
            except Exception:
                logger.exception("Failed to destroy sandbox '%s' during shutdown", name)

        with self._lock:
            self._sandboxes.clear()
            self._workflow_map.clear()
            self._pool_map.clear()
            self._last_used.clear()
            self._idle_timeouts.clear()
            self._prewarmed.clear()
            self._in_use.clear()

        _audit_log("shutdown", count=len(names))
        logger.info("SandboxManager shutdown: destroyed %d sandbox(es)", len(names))


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_manager: SandboxManager | None = None


def init_sandbox_manager(
    client: SandboxClient | None = None,
    policies_dir: Path | None = None,
    max_sandboxes: int = DEFAULT_MAX_SANDBOXES,
) -> SandboxManager:
    """Initialize the global SandboxManager. Called once at server startup."""
    global _manager
    _manager = SandboxManager(
        client=client, policies_dir=policies_dir, max_sandboxes=max_sandboxes,
    )
    return _manager


def get_sandbox_manager() -> SandboxManager | None:
    """Get the global SandboxManager, or None if not initialized."""
    return _manager
