"""OpenShell sandbox client — wraps the openshell CLI for sandbox lifecycle.

Two implementations:
    OpenShellClient  — real OpenShell (requires Docker + openshell binary)
    StubClient       — local passthrough (no Docker, tests full flow)

Selected automatically: OpenShell if available, stub otherwise.

Security model:
    - IOF_SANDBOX_TOKEN: cryptographic nonce set ONLY by sandbox_wrap_cmd(),
      verified by should_sandbox() to prevent spoofing.
    - Environment filtering: only whitelisted env vars pass into sandboxes.
    - Policy validation: policy names must be alphanumeric (no path traversal).
    - Audit logging: all sandbox operations logged to structured audit trail.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from pydantic import BaseModel

logger = logging.getLogger("ioagentfarm.sandbox")

# Cryptographic token for sandbox identity — set once per process.
# Agents CANNOT forge this because they don't know the token value.
_SANDBOX_TOKEN: str | None = None


# ---------------------------------------------------------------------------
# Environment filtering — only these vars pass into sandboxes
# ---------------------------------------------------------------------------

SANDBOX_ENV_WHITELIST = {
    # Python runtime
    "PATH", "PYTHONPATH", "PYTHONIOENCODING", "PYTHONUNBUFFERED",
    # Terminal
    "FORCE_COLOR", "TERM", "NO_COLOR", "HOME", "USER", "LANG", "LC_ALL",
    # ioagentfarm state (needed for CLI commands inside sandbox)
    "IOF_ROOT", "IOF_DATABASE_URL", "IOF_STORAGE", "IOF_S3_BUCKET",
    "IOF_S3_PREFIX", "IOF_S3_ENDPOINT", "IOF_S3_REGION",
    # iobot runtime (needed for agent execution)
    "IOBOT_WORKSPACE", "IOBOT_PROVIDER", "IOBOT_MODEL",
    "IOBOT_API_KEY", "IOBOT_API_BASE",
    # Sandbox internal markers
    "IOF_SANDBOX_ID", "IOF_SANDBOX_TOKEN", "IOF_SANDBOX_NAME",
}


def filter_env_for_sandbox(env: dict[str, str]) -> dict[str, str]:
    """Filter environment variables for sandbox execution.

    Only whitelisted variables pass through. This prevents credential
    leakage (GITHUB_TOKEN, AWS_*, API keys) into sandboxes.

    OpenShell's credential isolation (gateway routing) handles inference
    credentials. This filter handles everything else.
    """
    filtered = {}
    for key in SANDBOX_ENV_WHITELIST:
        if key in env:
            filtered[key] = env[key]
    return filtered


# ---------------------------------------------------------------------------
# Policy name validation
# ---------------------------------------------------------------------------

_VALID_POLICY_NAME = re.compile(r"^[a-zA-Z0-9_-]+$")


def validate_policy_name(name: str) -> bool:
    """Validate policy name — alphanumeric, hyphens, underscores only.

    Prevents path traversal attacks via policy names like '../../etc/passwd'.
    """
    return bool(_VALID_POLICY_NAME.match(name)) and len(name) <= 64


# ---------------------------------------------------------------------------
# Audit logging
# ---------------------------------------------------------------------------

def _audit_log(action: str, **kwargs) -> None:
    """Structured audit log entry for sandbox operations.

    Logs to both Python logger and a machine-readable format for
    security monitoring and forensic analysis.
    """
    entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "action": action,
        **kwargs,
    }
    logger.info("SANDBOX_AUDIT: %s", json.dumps(entry))


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class SandboxInfo(BaseModel):
    """Runtime info about an active sandbox."""
    name: str
    policy: str = "default"
    status: str = "unknown"  # creating | ready | stopped | stub
    workflow: str | None = None
    pool: str | None = None


# ---------------------------------------------------------------------------
# SandboxClient — interface + OpenShell implementation
# ---------------------------------------------------------------------------

class SandboxClient:
    """Wraps the ``openshell`` CLI for sandbox create/destroy/status.

    Does NOT wrap command execution — callers use ``wrap_command()`` to
    prepend the sandbox exec prefix, then pass the result to subprocess.
    """

    def is_available(self) -> bool:
        """Check if the openshell binary is on PATH."""
        return shutil.which("openshell") is not None

    def create(
        self,
        name: str,
        *,
        policy_path: Path | None = None,
        image: str | None = None,
    ) -> SandboxInfo:
        """Create a persistent sandbox."""
        cmd = ["openshell", "sandbox", "create", "--name", name]
        if image:
            cmd.extend(["--from", image])
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as exc:
            _audit_log("create_failed", sandbox=name, error=exc.stderr[:200])
            raise

        # Apply policy if provided
        if policy_path and policy_path.exists():
            self.apply_policy(name, policy_path)

        _audit_log("created", sandbox=name, policy=policy_path.name if policy_path else "none")
        return SandboxInfo(name=name, status="ready")

    def apply_policy(self, name: str, policy_path: Path) -> None:
        """Apply or hot-reload a policy on a running sandbox."""
        cmd = ["openshell", "policy", "set", name, "--policy", str(policy_path)]
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
            _audit_log("policy_applied", sandbox=name, policy=policy_path.name)
        except subprocess.CalledProcessError as exc:
            _audit_log("policy_failed", sandbox=name, policy=policy_path.name, error=exc.stderr[:200])

    def destroy(self, name: str) -> None:
        """Destroy a sandbox."""
        cmd = ["openshell", "sandbox", "delete", name, "--yes"]
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
            _audit_log("destroyed", sandbox=name)
        except subprocess.CalledProcessError as exc:
            _audit_log("destroy_failed", sandbox=name, error=exc.stderr[:200])

    def status(self, name: str) -> str:
        """Check sandbox status: running | stopped | unknown."""
        cmd = ["openshell", "sandbox", "list", "--json"]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                sandboxes = json.loads(result.stdout)
                for sb in sandboxes:
                    if sb.get("name") == name:
                        return sb.get("status", "unknown")
        except Exception:
            pass
        return "unknown"

    def health_check(self, name: str) -> bool:
        """Verify sandbox is alive by executing a test command.

        Returns True if the sandbox can execute commands successfully.
        """
        cmd = ["openshell", "sandbox", "exec", name, "--", "echo", "healthcheck"]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return result.returncode == 0 and "healthcheck" in result.stdout
        except (subprocess.TimeoutExpired, Exception):
            return False

    def wrap_command(self, sandbox_name: str, cmd: list[str]) -> list[str]:
        """Wrap a command to execute inside the named sandbox.

        Uses ``openshell sandbox exec`` to run the command non-interactively.
        The caller passes the result to subprocess.Popen as usual — stdout
        streams through the openshell exec proxy.
        """
        return ["openshell", "sandbox", "exec", sandbox_name, "--"] + cmd


# ---------------------------------------------------------------------------
# StubClient — local passthrough for testing without Docker
# ---------------------------------------------------------------------------

class StubClient(SandboxClient):
    """Test double — tracks sandbox lifecycle but executes commands locally.

    Used when IOF_RUNNER=sandbox but Docker/OpenShell is not available.
    Validates the full sandbox flow without actual containers.
    """

    def __init__(self):
        self._sandboxes: dict[str, SandboxInfo] = {}

    def is_available(self) -> bool:
        return True  # Stub is always available

    def create(self, name, *, policy_path=None, image=None):
        info = SandboxInfo(name=name, status="stub")
        self._sandboxes[name] = info
        _audit_log("created", sandbox=name, client="stub")
        return info

    def apply_policy(self, name, policy_path):
        _audit_log("policy_applied", sandbox=name, client="stub")

    def destroy(self, name):
        self._sandboxes.pop(name, None)
        _audit_log("destroyed", sandbox=name, client="stub")

    def status(self, name):
        if name in self._sandboxes:
            return "stub"
        return "unknown"

    def health_check(self, name):
        return name in self._sandboxes

    def wrap_command(self, sandbox_name, cmd):
        # No wrapping — run locally as-is
        logger.warning(
            "SANDBOX_STUB: executing unsandboxed (sandbox='%s'). "
            "Install Docker + OpenShell for real isolation.",
            sandbox_name,
        )
        _audit_log("exec_unsandboxed", sandbox=sandbox_name, client="stub",
                    detail="command executed locally without isolation")
        return cmd


# ---------------------------------------------------------------------------
# Factory — auto-detect OpenShell or fall back to stub
# ---------------------------------------------------------------------------

_client: SandboxClient | None = None


def get_sandbox_client() -> SandboxClient:
    """Get the sandbox client. Cached after first call.

    Returns OpenShellClient if ``openshell`` binary is found on PATH,
    otherwise returns StubClient with a warning.
    """
    global _client
    if _client is not None:
        return _client

    # Check for explicit stub mode
    if os.environ.get("IOF_SANDBOX_STUB", "").lower() in ("true", "1"):
        _client = StubClient()
        logger.info("Sandbox: using stub client (IOF_SANDBOX_STUB=true)")
        return _client

    # Auto-detect
    real = SandboxClient()
    if real.is_available():
        _client = real
        logger.info("Sandbox: using OpenShell client")
    else:
        _client = StubClient()
        logger.warning(
            "Sandbox: openshell not found — using stub client (local passthrough). "
            "Install OpenShell for real sandbox isolation."
        )

    return _client


def _generate_sandbox_token() -> str:
    """Generate a cryptographic sandbox token for this process.

    The token is set once per orchestrator process. Only processes that
    received the token from the orchestrator can prove they're inside
    a sandbox. Agents cannot forge this because the token is generated
    per-process and never exposed in agent prompts or YAML.
    """
    global _SANDBOX_TOKEN
    if _SANDBOX_TOKEN is None:
        _SANDBOX_TOKEN = secrets.token_hex(16)
    return _SANDBOX_TOKEN


def should_sandbox() -> bool:
    """Should subprocess calls be wrapped with sandbox exec?

    Returns False if:
    - IOF_RUNNER is not 'sandbox'
    - Already inside a sandbox (verified by cryptographic token)

    Security: IOF_SANDBOX_ID alone is not trusted. The token in
    IOF_SANDBOX_TOKEN must match our process token to confirm
    the process is genuinely inside a sandbox we created.
    """
    if os.environ.get("IOF_RUNNER", "local").lower() != "sandbox":
        return False

    # Check if we're inside a sandbox — requires BOTH marker AND valid token
    sandbox_id = os.environ.get("IOF_SANDBOX_ID")
    sandbox_token = os.environ.get("IOF_SANDBOX_TOKEN")

    if sandbox_id and sandbox_token:
        # Verify the token matches ours (only our orchestrator knows the token)
        expected = _generate_sandbox_token()
        if secrets.compare_digest(sandbox_token, expected):
            return False  # Genuinely inside our sandbox — don't nest
        else:
            # Token mismatch — possibly spoofed. Log and sandbox anyway.
            _audit_log("token_mismatch", sandbox_id=sandbox_id,
                       detail="IOF_SANDBOX_TOKEN does not match — possible spoof attempt")
            logger.warning("SECURITY: IOF_SANDBOX_TOKEN mismatch — ignoring IOF_SANDBOX_ID, will sandbox")

    return True


def make_sandbox_env(env: dict[str, str], sandbox_name: str = "") -> dict[str, str]:
    """Prepare environment for a sandboxed subprocess.

    1. Filters to whitelisted vars only (prevents credential leakage)
    2. Sets IOF_SANDBOX_ID + IOF_SANDBOX_TOKEN (anti-spoofing)
    3. Sets IOF_SANDBOX_NAME for session isolation
    """
    filtered = filter_env_for_sandbox(env)
    filtered["IOF_SANDBOX_ID"] = "1"
    filtered["IOF_SANDBOX_TOKEN"] = _generate_sandbox_token()
    if sandbox_name:
        filtered["IOF_SANDBOX_NAME"] = sandbox_name
    return filtered


def sandbox_wrap_cmd(
    cmd: list[str],
    *,
    workflow_name: str | None = None,
) -> list[str]:
    """Wrap a command for sandbox execution if configured.

    Phase 1: uses IOF_SANDBOX_NAME (single sandbox)
    Phase 2: resolves per-workflow sandbox via SandboxManager
    """
    if not should_sandbox():
        return cmd

    client = get_sandbox_client()

    # Phase 2: per-workflow sandbox
    if workflow_name:
        try:
            from ioagentfarm.engine.sandbox_manager import get_sandbox_manager
            mgr = get_sandbox_manager()
            if mgr:
                sandbox_name = mgr.resolve_sandbox_name(workflow_name)
                if sandbox_name:
                    _audit_log("exec", sandbox=sandbox_name, workflow=workflow_name,
                               cmd_hash=hashlib.sha256(" ".join(cmd).encode()).hexdigest()[:12])
                    return client.wrap_command(sandbox_name, cmd)
        except ImportError:
            pass

    # Phase 1: single named sandbox (fallback)
    sandbox_name = os.environ.get("IOF_SANDBOX_NAME", "agentfarm")
    _audit_log("exec", sandbox=sandbox_name, workflow=workflow_name or "unknown",
               cmd_hash=hashlib.sha256(" ".join(cmd).encode()).hexdigest()[:12])
    return client.wrap_command(sandbox_name, cmd)
