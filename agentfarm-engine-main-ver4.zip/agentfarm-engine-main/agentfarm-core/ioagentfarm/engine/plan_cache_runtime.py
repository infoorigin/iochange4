"""Runtime helpers for integrating PlanCache into the web/app.py chat flow.

Separated from plan_cache.py to keep the core cache module free of web/server
assumptions (subprocess, prompt shapes, etc.) and easier to unit-test.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

from ioagentfarm.engine.plan_cache import PlanCache


# Single hook point: returns a PlanCache bound to <IOF_ROOT>/plan_cache.db.
# Lazy so tests can swap IOF_ROOT between invocations.
_cache_singleton: dict[str, PlanCache] = {}


def get_plan_cache(iof_root: Path) -> PlanCache:
    key = str(iof_root.resolve())
    cached = _cache_singleton.get(key)
    if cached is None:
        cached = PlanCache(iof_root / "plan_cache.db")
        _cache_singleton[key] = cached
    return cached


# ---------------------------------------------------------------- extraction

_ENVELOPE_RE = re.compile(r"```(?:json)?\s*(\{.*\})\s*```", re.DOTALL)


def extract_envelope(content: str) -> Optional[dict]:
    if not content:
        return None
    m = _ENVELOPE_RE.search(content)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return None


def extract_sql_and_db_from_envelope(envelope: dict) -> Optional[tuple[str, str, str]]:
    """Pull (sql, db_name, entity) from a Quinn v1 envelope.

    Returns None if the envelope is missing evidence or references no database.
    When evidence.queries contains multiple SQLs we only cache the first — the
    golden path is a single-entity query, and multi-source cases (vectorfs +
    spend_cube joins) are out of scope for v1 plan cache.
    """
    evidence = envelope.get("evidence") or {}
    queries = evidence.get("queries") or []
    sources = evidence.get("sources") or []
    if not queries or not sources:
        return None

    sql = next(
        (q for q in queries if isinstance(q, str)
         and q.strip().upper().startswith(("SELECT", "WITH"))),
        None,
    )
    if not sql:
        return None

    primary = sources[0]
    if not isinstance(primary, dict):
        return None
    db_name = primary.get("database") or ""
    entity = primary.get("entity") or ""
    if not db_name:
        return None
    return sql.strip(), db_name, entity


# ---------------------------------------------------------------- execution

def execute_cached_sql(*, sql: str, db_name: str, metadata_dir: Path,
                      timeout_s: int = 30) -> Optional[dict]:
    """Re-execute the cached SQL server-side via `iof-query`.

    Returns the parsed JSON result dict, or None on failure. Failure is a
    signal to the caller to fall through to the normal (un-cached) path —
    typically means schema drift the fingerprint didn't pick up, or a
    transient DB issue. Never raises; the cache is best-effort.
    """
    iof_query = shutil.which("iof-query")
    if not iof_query:
        return None

    try:
        proc = subprocess.run(
            [iof_query,
             "--db", db_name,
             "--sql", sql,
             "--metadata-dir", str(metadata_dir)],
            capture_output=True, text=True, timeout=timeout_s,
            cwd=str(metadata_dir.parent),
        )
    except (subprocess.TimeoutExpired, OSError):
        return None

    if proc.returncode != 0:
        return None
    try:
        result = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return None
    if not isinstance(result, dict) or not result.get("success"):
        return None
    return result


# ------------------------------------------------------------ prompt rewrite

_CACHE_HIT_TEMPLATE = """{original_question}

---
**PLAN CACHE HIT — pre-executed SQL.** The following SQL was generated for a prior identical question and has just been re-executed against the live database. Use these results to compose the v1 envelope. **DO NOT call any tools** — all data you need is below.

Cached SQL (re-executed live):
```sql
{sql}
```

Fresh tool_result:
```json
{result_json}
```

Primary source: entity=`{entity}`, database=`{db_name}`, rows={row_count}.

Now compose the v1 envelope per your `result_composer` skill:
- `data`: populated from the fresh tool_result above
- `evidence.queries`: `["{sql_escaped}"]`
- `evidence.sources`: `[{{"entity": "{entity}", "database": "{db_name}", "rows": {row_count}}}]`
- `answer`, `insight`: your composition of the results

Return the envelope only. No additional tool calls.
"""


def build_cache_hit_prompt(*, question: str, sql: str, result: dict,
                           entity: str, db_name: str) -> str:
    rows = result.get("rows") or []
    row_count = result.get("row_count") if "row_count" in result else len(rows)
    compact_result = {
        "columns": result.get("columns"),
        "rows": rows,
        "row_count": row_count,
    }
    sql_escaped = sql.replace('"', '\\"').replace("\n", " ")
    return _CACHE_HIT_TEMPLATE.format(
        original_question=question,
        sql=sql,
        sql_escaped=sql_escaped,
        result_json=json.dumps(compact_result, indent=2, default=str),
        entity=entity or "",
        db_name=db_name,
        row_count=row_count,
    )
