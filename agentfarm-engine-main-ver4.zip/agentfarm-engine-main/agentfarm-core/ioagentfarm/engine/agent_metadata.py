"""Host-applied agent metadata — re-applied after every identity refresh.

``configure-agent`` deploys a deployment's own metadata (``catalog.yaml``,
``vectorfs.yaml``, ``databases.yml``, ``data/``) into an always-on agent's
home under ``metadata/`` and EMBEDS the catalog into the relevant
``skills/*/SKILL.md`` so it rides in the system prompt without a read_file
round-trip. That embed edits a PACK FILE inside the home.

Under the One Truth model (docs/one-truth-content-model.md s3.4) identity
files are refreshed from the installed pack on every use, so a one-shot
embed would be erased by the next session's refresh and Quinn would come up
without a catalog after the first chat - a regression the model must not
introduce. ``metadata/`` itself is host state (outside the refresh, like
``memory/``), so the embed is made a DETERMINISTIC POST-STEP derived from it:
``ensure_agent_workspace`` calls :func:`embed_metadata_into_skills` after
refreshing identity, and ``configure-agent`` calls the same function after
copying the metadata. One implementation, idempotent by marker, so the two
can never disagree about what an embed looks like.
"""

from __future__ import annotations

from pathlib import Path

#: What ``configure-agent`` deploys and what this module embeds from.
METADATA_DIR = "metadata"

_EMBEDS = (
    # (metadata file, skill dir, section marker)
    ("catalog.yaml", "catalog_reader", "## Current catalog"),
    ("catalog.yml", "catalog_reader", "## Current catalog"),
    ("vectorfs.yaml", "vectorfs_query", "## Current vectorfs config"),
)


def _embed(skill_md: Path, marker: str, payload: str) -> bool:
    text = skill_md.read_text(encoding="utf-8")
    if marker in text:
        text = text[:text.index(marker)]
    new = text.rstrip() + f"\n\n{marker}\n\n```yaml\n{payload}```\n"
    if skill_md.read_text(encoding="utf-8") == new:
        return False
    skill_md.write_text(new, encoding="utf-8")
    return True


def embed_metadata_into_skills(workspace: Path) -> list[str]:
    """Embed ``<workspace>/metadata/*.yaml`` into the matching skills.

    Returns the skill names that were (re)written. No-op when the home has
    no ``metadata/`` dir, no matching skill, or the embed is already current.
    Never raises on a missing piece - a home without a catalog is not an
    error, it is an agent that has not been configured.
    """
    meta = workspace / METADATA_DIR
    if not meta.is_dir():
        return []
    written: list[str] = []
    for fname, skill, marker in _EMBEDS:
        src = meta / fname
        skill_md = workspace / "skills" / skill / "SKILL.md"
        if not (src.is_file() and skill_md.is_file()):
            continue
        try:
            if _embed(skill_md, marker, src.read_text(encoding="utf-8")):
                written.append(skill)
        except OSError:
            continue
    return written
