"""Materialize-on-use - pull-based DB hydration of file-plane content.

THE MECHANISM (design: docs/PLATFORM_HARDENING_BACKLOG.md, user-locked
2026-07-27): the DB rows (``studio_workflow_defs`` / ``studio_agent_defs``)
are the durable, cluster-visible copy of studio-authored content; every
execution host (pod, server, desktop) derives its local files from them AT
THE MOMENT OF USE. Always PULL, never a daemon:

  * workflow run creation   -> ``hydrate_workflow()`` (snapshot_workflow seam)
  * agent workspace seeding -> ``hydrate_agent()``    (ensure_agent_workspace /
                                                       create_filtered_workspace)

Sync key = (version, content_hash) PER ITEM: hash equal -> strict no-op
(even if version moved: a no-op save); hash differs -> copy that item only.
Each host keeps a ``.materialized`` stamp per item recording the pair it
last copied, plus provenance (``db``) so deletions are safe: a stamped
(DB-materialized) workflow tree whose row vanished is removed; pack-baked
content is NEVER deleted by the hydrator. Agent workspaces are never
auto-deleted (they carry ``memory/``) - a vanished row only drops the stamp.

Hardening (built in from the start, per the design review):
  * atomic writes - temp dir + swap; the stamp is written LAST so a crash
    mid-copy self-heals on the next pull;
  * one SELECT per item per pull;
  * per-item lock (SyncLock idiom) - concurrent runs on one host skip
    rather than interleave writes;
  * FAIL-OPEN - DB unreachable / any error -> run with existing files and
    log at debug; the engine works offline unchanged. ``IOF_HYDRATION=0``
    disables the whole mechanism.

``memory/`` and ``sessions/`` are never part of hydration content (DB-backed
learning owns memory); they are preserved across agent re-materializations.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import time
from pathlib import Path

from ioagentfarm.engine.filecodec import write_file

logger = logging.getLogger(__name__)

STAMP_NAME = ".materialized"
_LOCK_STALE_S = 5 * 60

#: dirs inside an agent workspace that hydration must never write nor delete
_AGENT_PRESERVE = ("memory", "sessions", "metadata")

#: FILES at the workspace root kept across a re-materialization WHEN THE ROW
#: DOES NOT CARRY THEM — same intent as ``_AGENT_PRESERVE`` but for single
#: files (that tuple is copied with ``copytree``, which ignores non-directories).
#:
#: ``.skills-assigned.json`` is the agent's shared-skill assignment record
#: (``engine.workspaces.SKILL_ASSIGNMENT_MARKER``). It IS part of the agent's
#: row — it is in both identity-file tuples — so the DB copy WINS: that is what
#: carries the record to a pod whose only state is the database. This tuple is
#: the fallback for the window before the row has been written: losing the
#: record there would make the next ``ensure_agent_workspace`` re-derive the
#: baseline from the legacy ``roles:`` rule and RESURRECT a skill the user
#: removed — the removal would appear to work, then quietly undo itself.
_AGENT_PRESERVE_FILES = (".skills-assigned.json",)


# -- sync-key hashing (single source for writers AND readers) ----------

def files_hash(files: dict[str, str]) -> str:
    """Canonical content hash of a {rel_path: text} file set."""
    h = hashlib.sha256()
    for rel in sorted(files):
        h.update(b"\x00")
        h.update(rel.encode("utf-8"))
        h.update(b"\x01")
        h.update(files[rel].encode("utf-8"))
    return h.hexdigest()


def workflow_content_hash(yaml_text: str, files: dict[str, str]) -> str:
    """Byte-compatible with ``workspace_sync.content_hash`` (yaml + files)."""
    h = hashlib.sha256()
    h.update(yaml_text.encode("utf-8"))
    for rel in sorted(files):
        h.update(b"\x00")
        h.update(rel.encode("utf-8"))
        h.update(b"\x01")
        h.update(files[rel].encode("utf-8"))
    return h.hexdigest()


# -- plumbing ----------------------------------------------------------

def _enabled() -> bool:
    return os.getenv("IOF_HYDRATION", "1").strip().lower() not in ("0", "false", "off")


def _iof_root() -> Path:
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve()


def _active_workspace() -> str:
    """The selected workspace, fail-closed — never an invented code."""
    from ioagentfarm.engine.workspaces import resolved_workspace_code
    return resolved_workspace_code()


def _connect():
    """(adapter, connection) on the engine DB. Postgres connections come
    back as ``_PooledConnection`` wrappers (context-manager only) - use
    :func:`_raw` for cursor access and :func:`_release` to hand the
    connection back to the pool (NEVER ``con.close()``: the wrapper has no
    ``close`` and the pooled connection would leak until the pool exhausts -
    the exact failure that killed engine startup when this module first
    shipped)."""
    from ioagentfarm.engine.db import make_adapter
    url = (os.getenv("IOF_DATABASE_URL") or "").strip() \
        or f"sqlite:///{_iof_root() / 'state.db'}"
    adapter = make_adapter(url)
    con = adapter.connect()
    try:
        adapter.init_connection(_raw(con))
    except Exception:
        pass
    return adapter, con


def _raw(con):
    """The underlying DB-API connection (unwraps _PooledConnection)."""
    return getattr(con, "_conn", con)


def _release(con) -> None:
    """Return a pooled connection to its pool / close a plain one."""
    try:
        if hasattr(con, "_pool"):          # _PooledConnection
            con.__exit__(None, None, None)
        else:
            con.close()
    except Exception:
        pass


def _q(adapter, sql: str) -> str:
    return sql.replace("?", "%s") if adapter.placeholder() == "%s" else sql


def _row(r) -> dict:
    return r if isinstance(r, dict) else dict(r)


def _read_stamp(d: Path) -> dict | None:
    try:
        return json.loads((d / STAMP_NAME).read_text(encoding="utf-8"))
    except Exception:
        return None


def _write_stamp(d: Path, kind: str, version, chash: str) -> None:
    (d / STAMP_NAME).write_text(
        json.dumps({"kind": kind, "version": version, "content_hash": chash,
                    "provenance": "db"}),
        encoding="utf-8")


def _safe_rel(rel: str) -> Path | None:
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts:
        return None
    return p


class _ItemLock:
    """Non-blocking per-item lock (SyncLock idiom, shorter staleness).
    Contention -> ``acquired == False`` - the caller SKIPS hydration
    (another process on this host is already doing it; fail-open)."""

    def __init__(self, path: Path):
        self.path = path
        self.acquired = False

    def __enter__(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            if self.path.exists():
                if time.time() - self.path.stat().st_mtime < _LOCK_STALE_S:
                    return self
                self.path.unlink()
            self.path.write_text(str(os.getpid()), encoding="utf-8")
            self.acquired = True
        except OSError:
            self.acquired = False
        return self

    def __exit__(self, *_exc):
        if self.acquired:
            try:
                self.path.unlink()
            except OSError:
                pass


def _swap_in(target: Path, build: Path) -> None:
    """Atomic-ish replace: rmtree old, rename built tree into place."""
    if target.exists():
        shutil.rmtree(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    build.rename(target)


# -- run attribution (workspace ownership resolver) --------------------

_OWNER_TTL_S = 30.0
_owner_cache: dict[str, tuple[str | None, float]] = {}


def resolve_owning_workspace(workflow_code: str) -> str | None:
    """ATTRIBUTION-ONLY: the workspace that owns *workflow_code*, or ``None``.

    Used by run-creation sites when NO explicit workspace was given
    (no --workspace / IOF_WORKSPACE / request field): if exactly ONE
    tenant workspace carries the code in tenant-keyed
    ``studio_workflow_defs``, the run is attributed to it
    (``runs.workspace_id`` + message writes).

    ``None`` means UNATTRIBUTABLE — no tenant owner, multiple owners, or a
    DB error. Callers must treat ``None`` as "require an explicit
    workspace": there is no fallback code, because attributing a run to a
    workspace nobody chose is how run history became untraceable. Cached
    briefly (the ownership map changes only on imports).

    THIS NEVER ACTIVATES TENANT EXECUTION: callers must not feed the result
    into ``_activate_workspace`` / ``IOF_AGENT_HOME`` / ``spawn --workspace``
    - per-tenant agent homes remain an explicit-workspace-only flip.
    Attribution and execution are separate concerns.
    """
    from ioagentfarm.engine.workspaces import PLATFORM_TIER
    now = time.time()
    hit = _owner_cache.get(workflow_code)
    if hit is not None and now - hit[1] < _OWNER_TTL_S:
        return hit[0]
    owner: str | None = None
    try:
        adapter, con = _connect()
    except Exception:
        logger.debug("attribution: DB unreachable for %r - unattributable",
                     workflow_code, exc_info=True)
        return None
    try:
        cur = _raw(con).cursor()
        cur.execute(_q(adapter,
            "SELECT DISTINCT workspace_code FROM studio_workflow_defs "
            "WHERE code = ? AND workspace_code <> ?"),
            (workflow_code, PLATFORM_TIER))
        owners = sorted({(_row(r))["workspace_code"] for r in cur.fetchall()})
        if len(owners) == 1:
            owner = owners[0]
        elif owners:
            logger.debug("attribution: workflow %r has multiple tenant "
                         "owners %s - unattributable", workflow_code, owners)
    except Exception:
        logger.debug("attribution: owner lookup failed for %r - "
                     "unattributable", workflow_code, exc_info=True)
    finally:
        _release(con)
    _owner_cache[workflow_code] = (owner, now)
    return owner


# -- workflows ---------------------------------------------------------

def workflow_override_dir(code: str, workspace_code: str | None = None) -> Path:
    """The override tree for *code*: the tenant's own, or the unscoped tree.

    ``workspace_code=None`` resolves the selected workspace (fail-closed —
    raises when nothing is selected). Passing ``PLATFORM_TIER`` explicitly
    addresses the unscoped ``<IOF_ROOT>/workflows/`` tree, which is where
    platform-tier catalog content materializes.
    """
    from ioagentfarm.engine.workspaces import PLATFORM_TIER
    ws = workspace_code or _active_workspace()
    if ws and ws != PLATFORM_TIER:
        return _iof_root() / "workspaces" / ws / "workflows" / code
    return _iof_root() / "workflows" / code


def hydrate_workflow(code: str, workspace_code: str | None = None) -> str:
    """Pull one workflow's override tree up to date with its DB row.

    Returns an action label: ``disabled | no-db | noop | materialized |
    removed | locked | error``. NEVER raises.
    """
    if not _enabled():
        return "disabled"
    ws = workspace_code or _active_workspace()
    target = workflow_override_dir(code, ws)
    try:
        adapter, con = _connect()
    except Exception:
        logger.debug("hydration: DB unreachable - running with existing "
                     "files for workflow %r", code, exc_info=True)
        return "error"
    try:
        cur = _raw(con).cursor()
        try:
            cur.execute(_q(adapter,
                "SELECT yaml, files_json, version, content_hash "
                "FROM studio_workflow_defs "
                "WHERE workspace_code = ? AND code = ?"), (ws, code))
            row = cur.fetchone()
        except Exception:
            logger.debug("hydration: sync-key query failed for workflow %r "
                         "(schema predates hydration?) - fail-open", code,
                         exc_info=True)
            return "error"

        stamp = _read_stamp(target)
        if row is None:
            # Deletion provenance: only a DB-materialized tree may be removed.
            if stamp is not None and stamp.get("provenance") == "db":
                with _ItemLock(target.parent / f".{code}.hydrate.lock") as lk:
                    if lk.acquired and _read_stamp(target) is not None:
                        shutil.rmtree(target, ignore_errors=True)
                        logger.info("hydration: removed workflow override %r "
                                    "(DB row vanished)", code)
                        return "removed"
                return "locked"
            return "no-db"

        row = _row(row)
        chash = row.get("content_hash") or ""
        if not chash:
            return "no-db"     # pre-hydration row - no reliable key; fail-open
        if stamp is not None and stamp.get("content_hash") == chash:
            return "noop"

        files = {}
        try:
            files = json.loads(row.get("files_json") or "{}")
        except json.JSONDecodeError:
            pass

        with _ItemLock(target.parent / f".{code}.hydrate.lock") as lk:
            if not lk.acquired:
                return "locked"
            build = target.parent / f".{code}.hydrating"
            shutil.rmtree(build, ignore_errors=True)
            build.mkdir(parents=True, exist_ok=True)
            (build / "workflow.yaml").write_text(row["yaml"], encoding="utf-8")
            for rel, content in (files or {}).items():
                rp = _safe_rel(rel)
                if rp is None:
                    continue
                write_file(build / rp, content)
            _swap_in(target, build)
            _write_stamp(target, "workflow", row.get("version"), chash)
            logger.info("hydration: materialized workflow %r (v%s) -> %s",
                        code, row.get("version"), target)
            return "materialized"
    except Exception:
        logger.debug("hydration: workflow %r failed - fail-open", code,
                     exc_info=True)
        return "error"
    finally:
        _release(con)


# -- agents ------------------------------------------------------------

def carried_skills(adapter, con, workspace_code: str,
                   role: str) -> dict[str, dict]:
    """``{name: {"files": {...}, "content_hash": str}}`` for one agent.

    Assignment comes from ``studio_skills.roles_json`` — ``"all"``, or a list
    containing *role*. ``null`` assigns to nobody.

    This filter is ASSIGNMENT, not eligibility, and it stays: ``roles_json`` is
    the record of what the user gave this agent, so it decides the agent's
    BASELINE — the skills it runs with when no workflow says otherwise. What
    was removed alongside the ``roles:`` frontmatter gate is the idea that a
    skill could be *refused* to an agent; a workflow step names what the job
    needs and resolves through :func:`workspace_skill`, which does not filter.

    Filtering happens in Python rather than SQL because ``roles_json`` is a
    JSON scalar-or-list and there is no portable predicate across SQLite and
    Postgres for that. A workspace holds tens of skills, so the read is cheap.

    PACK ROWS CARRY NO CONTENT. A shared skill's row is assignment ONLY
    (``files_json = '{}'``, ``origin = 'pack'``) and its files are resolved
    HERE from the wheel, every time. That is what lets a pack skill have a
    durable, cluster-visible assignment — the thing that reaches a pod whose
    only state is the database — without a tenant-owned copy that freezes a
    fork the SDK can never update again. Its ``content_hash`` is the WHEEL's
    current hash, so an SDK upgrade moves :func:`agent_sync_key` and every
    carrier re-materialises with the new content; storing a hash would defeat
    the whole arrangement by pinning carriers to the version that was current
    when the skill was assigned.

    Fail-open ({}): a schema that predates ``studio_skills`` must degrade to
    the pre-normalisation behaviour (skills come from ``files_json``), never
    break hydration.
    """
    try:
        cur = _raw(con).cursor()
        cur.execute(_q(adapter,
            "SELECT name, files_json, roles_json, content_hash "
            "FROM studio_skills WHERE workspace_code = ?"), (workspace_code,))
        rows = [_row(r) for r in cur.fetchall()]
    except Exception:
        try:
            _raw(con).rollback()   # PG aborts the tx on a failed statement
        except Exception:
            pass
        logger.debug("hydration: studio_skills unreadable - skills fall back "
                     "to the agent blob", exc_info=True)
        return {}

    out: dict[str, dict] = {}
    for r in rows:
        try:
            assigned = json.loads(r.get("roles_json") or "null")
        except json.JSONDecodeError:
            continue
        if assigned != "all" and role not in (assigned or []):
            continue
        try:
            files = json.loads(r.get("files_json") or "{}")
        except json.JSONDecodeError:
            continue
        if not isinstance(files, dict):
            continue
        if not files:
            # Assignment-only row: the wheel is the content, now and on every
            # future pull. A row we cannot resolve is skipped rather than
            # materialised empty — an empty skill directory reads to the agent
            # as a skill that exists and says nothing.
            from ioagentfarm.engine.workspaces import shared_skill_files
            files = shared_skill_files(r["name"]) or {}
            if not files:
                logger.debug("hydration: assignment-only skill %r is in no "
                             "shared source - skipped", r["name"])
                continue
            out[r["name"]] = {"files": files,
                              "content_hash": files_hash(files)}
            continue
        out[r["name"]] = {"files": files,
                          "content_hash": r.get("content_hash") or ""}
    return out


def pack_assignment(workspace_code: str, role: str) -> set[str] | None:
    """Shared skills assigned to *role* here, or ``None`` if unknowable.

    ``None`` means "there is no record to consult" — no database, no
    ``studio_skills`` table, or no ``origin='pack'`` row for this workspace at
    all (nothing has been derived yet). It is deliberately distinct from an
    empty set, which means "the record says this agent holds no shared skills",
    e.g. because the user removed them all. Collapsing the two would make a
    removal indistinguishable from a fresh install, and the caller would
    re-derive the baseline and hand back skills the user deleted.
    """
    try:
        adapter, con = _connect()
    except Exception:
        return None
    try:
        cur = _raw(con).cursor()
        try:
            cur.execute(_q(adapter,
                "SELECT name, roles_json FROM studio_skills "
                "WHERE workspace_code = ? AND origin = 'pack'"),
                (workspace_code,))
            rows = [_row(r) for r in cur.fetchall()]
        except Exception:
            try:
                _raw(con).rollback()
            except Exception:
                pass
            return None
        if not rows:
            return None
        out: set[str] = set()
        for r in rows:
            try:
                assigned = json.loads(r.get("roles_json") or "null")
            except json.JSONDecodeError:
                continue
            if assigned == "all" or role in (assigned or []):
                out.add(r["name"])
        return out
    finally:
        _release(con)


def record_pack_assignment(workspace_code: str, role: str,
                           names) -> bool:
    """Set *role*'s shared-skill assignment to exactly *names*. Never raises.

    Writes assignment-only rows (``origin='pack'``, ``files_json='{}'``) —
    content stays in the wheel, see :func:`carried_skills`. Reconciles both
    ways so a removal is as durable as an addition.

    The ENGINE's writer for this record. ``skill_defs.upsert_pack_assignment``
    is the API's, on its own pooled connection, and the two must keep writing
    the same row shape (``origin='pack'``, ``files_json='{}'``) — two writers
    for one row is how the halves of a shared table drift apart.

    A NAME THAT ALREADY HAS A NON-PACK ROW IS LEFT ALONE. ``_shared_skill_dirs()``
    serves the tenant's own staged solution skills alongside the wheel's, so
    *names* routinely contains a skill whose row is ``origin='repo'`` — content
    and assignment both owned by that row, and honoured by :func:`carried_skills`
    on every pull. This used to reach the INSERT, hit the ``(workspace_code,
    name)`` primary key, abort the transaction, and lose THE WHOLE
    reconciliation for that role: the agent silently vanished from the rows of
    every shared skill it genuinely carries. That is how a tenant's own agent
    came to be missing from a row that named three other solutions' agents.
    """
    names = set(names)
    try:
        adapter, con = _connect()
    except Exception:
        return False
    try:
        raw = _raw(con)
        cur = raw.cursor()
        cur.execute(_q(adapter,
            "SELECT name, roles_json, origin FROM studio_skills "
            "WHERE workspace_code = ?"), (workspace_code,))
        rows = [_row(x) for x in cur.fetchall()]
        owned_elsewhere = {r["name"] for r in rows
                           if (r.get("origin") or "") != "pack"}
        current = {r["name"]: r.get("roles_json") for r in rows
                   if r["name"] not in owned_elsewhere}
        now = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
        for name in sorted((names | set(current)) - owned_elsewhere):
            try:
                assigned = json.loads(current.get(name) or "null")
            except json.JSONDecodeError:
                assigned = None
            if assigned == "all":
                continue                      # already covers every role
            roles = set(assigned or [])
            roles = (roles | {role}) if name in names else (roles - {role})
            if name in current:
                if roles == set(assigned or []):
                    continue                  # no change: leave the row alone
                cur.execute(_q(adapter,
                    "UPDATE studio_skills SET roles_json = ?, "
                    "version = version + 1, updated_at = ? "
                    "WHERE workspace_code = ? AND name = ?"),
                    (json.dumps(sorted(roles)), now, workspace_code, name))
            elif roles:
                cur.execute(_q(adapter,
                    "INSERT INTO studio_skills (workspace_code, name,"
                    " files_json, roles_json, content_hash, version,"
                    " updated_at, origin) "
                    "VALUES (?, ?, '{}', ?, '', 1, ?, 'pack')"),
                    (workspace_code, name, json.dumps(sorted(roles)), now))
        raw.commit()
        return True
    except Exception:
        try:
            _raw(con).rollback()
        except Exception:
            pass
        logger.debug("hydration: pack assignment write failed for %r/%r",
                     workspace_code, role, exc_info=True)
        return False
    finally:
        _release(con)


def workspace_skill(name: str, workspace_codes) -> dict[str, str] | None:
    """One skill's files from ``studio_skills``, IGNORING its assignment.

    :func:`carried_skills` answers "what is this agent's baseline?" and filters
    on ``roles_json`` — correctly, because that column IS the assignment
    record. This answers a different question: "does the WORKSPACE have a skill
    by this name?" A workflow step declares what the JOB needs and resolves
    against the whole workspace catalog, so it must be able to name a skill the
    agent has never carried. Filtering here would put the removed eligibility
    gate straight back, one layer down.

    *workspace_codes* is tried in order (tenant, then ``default``) because a
    platform-shared agent runs inside a tenant home while its own definition
    lives on the canonical ``default`` row.

    Returns ``None`` when unknown — including on any DB error, so a step whose
    catalog lookup fails falls through to the pack sources rather than dying.
    """
    try:
        adapter, con = _connect()
    except Exception:
        logger.debug("hydration: DB unreachable - no catalog lookup for skill "
                     "%r", name, exc_info=True)
        return None
    try:
        cur = _raw(con).cursor()
        for code in workspace_codes:
            try:
                cur.execute(_q(adapter,
                    "SELECT files_json FROM studio_skills "
                    "WHERE workspace_code = ? AND name = ?"), (code, name))
                row = cur.fetchone()
            except Exception:
                try:
                    _raw(con).rollback()   # PG aborts the tx on a failed stmt
                except Exception:
                    pass
                logger.debug("hydration: studio_skills unreadable - skill %r "
                             "not resolvable from the catalog", name,
                             exc_info=True)
                return None
            if row is None:
                continue
            try:
                files = json.loads(_row(row).get("files_json") or "{}")
            except json.JSONDecodeError:
                continue
            if isinstance(files, dict) and files:
                return files
        return None
    finally:
        _release(con)


def agent_sync_key(agent_hash: str, skills: dict[str, dict]) -> str:
    """The agent's materialization key, INCLUDING its carried skills.

    Load-bearing: once skills live in their own rows, a skill edit does not
    touch ``studio_agent_defs.content_hash``, so a key of that hash alone
    would leave every carrier holding stale content on disk forever — silent,
    and invisible until an agent behaves oddly. Folding the skills' hashes in
    makes exactly the affected agents re-materialize.

    Degenerate case preserved deliberately: no carried skills hashes to the
    agent hash unchanged, so agents that carry none keep their existing stamp
    and do not all re-materialize once on upgrade.
    """
    if not skills:
        return agent_hash
    h = hashlib.sha256()
    h.update(agent_hash.encode("utf-8"))
    for name in sorted(skills):
        h.update(b"\x00")
        h.update(name.encode("utf-8"))
        h.update(b"\x01")
        h.update((skills[name].get("content_hash") or "").encode("utf-8"))
    return h.hexdigest()


def hydrate_agent(role: str, target: Path | None = None,
                  *, workspace_code: str) -> str:
    """Pull one agent's live workspace up to date with its DB row.

    *workspace_code* is REQUIRED — which tenant's row (or ``PLATFORM_TIER``
    for platform-shared roles) is a decision the caller must make; a default
    here silently hydrated tenant homes from the shared tier.

    ``memory/``, ``sessions/`` and ``metadata/`` are preserved across
    re-materializations and never come from the DB. A vanished row never
    deletes the workspace (it holds memory) - only the stamp is dropped.
    Returns the same action labels as :func:`hydrate_workflow`; NEVER raises.
    """
    if not _enabled():
        return "disabled"
    if target is None:
        from ioagentfarm.engine.workspaces import iobot_agent_workspace
        target = iobot_agent_workspace(role)
    try:
        adapter, con = _connect()
    except Exception:
        logger.debug("hydration: DB unreachable - running with existing "
                     "workspace for agent %r", role, exc_info=True)
        return "error"
    try:
        cur = _raw(con).cursor()
        try:
            cur.execute(_q(adapter,
                "SELECT files_json, version, content_hash "
                "FROM studio_agent_defs "
                "WHERE workspace_code = ? AND role = ?"),
                (workspace_code, role))
            row = cur.fetchone()
        except Exception:
            logger.debug("hydration: sync-key query failed for agent %r "
                         "(schema predates hydration?) - fail-open", role,
                         exc_info=True)
            return "error"

        stamp = _read_stamp(target)
        if row is None:
            if stamp is not None and stamp.get("provenance") == "db":
                try:
                    (target / STAMP_NAME).unlink()
                except OSError:
                    pass
                logger.info("hydration: agent %r row vanished - stamp "
                            "dropped, workspace kept (holds memory)", role)
            return "no-db"

        row = _row(row)
        chash = row.get("content_hash") or ""
        if not chash:
            return "no-db"
        skills = carried_skills(adapter, con, workspace_code, role)
        sync_key = agent_sync_key(chash, skills)
        if stamp is not None and stamp.get("content_hash") == sync_key \
                and (target / "SOUL.md").is_file():
            return "noop"

        try:
            files = json.loads(row.get("files_json") or "{}")
        except json.JSONDecodeError:
            return "error"
        if not isinstance(files, dict) or "SOUL.md" not in files:
            return "error"     # a workspace without a SOUL is not an agent

        # Join carried skills INTO the payload, before the build loop below.
        # NOT as a step after hydration: _swap_in rmtrees the target, and
        # create_filtered_workspace runs nothing afterwards to repair it (only
        # ensure_agent_workspace does), so a skill-filtered run workspace would
        # come out with no skills at all. The DB row wins over any legacy
        # skills/** key left in files_json by the pre-normalisation migration.
        for name, sk in skills.items():
            for rel, content in sk["files"].items():
                files[f"skills/{name}/{rel}"] = content

        with _ItemLock(target.parent / f".{role}.hydrate.lock") as lk:
            if not lk.acquired:
                return "locked"
            build = target.parent / f".{role}.hydrating"
            shutil.rmtree(build, ignore_errors=True)
            build.mkdir(parents=True, exist_ok=True)
            for rel, content in files.items():
                rp = _safe_rel(rel)
                if rp is None or (rp.parts and rp.parts[0] in _AGENT_PRESERVE):
                    continue
                write_file(build / rp, content)
            # carry over preserved state from the existing workspace
            for keep in _AGENT_PRESERVE:
                src = target / keep
                if src.is_dir():
                    shutil.copytree(src, build / keep, dirs_exist_ok=True)
            # ...and the record files, ONLY where the row did not supply one.
            # The row wins: it is the copy that reaches a host with no disk.
            for keep in _AGENT_PRESERVE_FILES:
                src = target / keep
                if keep not in files and src.is_file():
                    shutil.copy2(src, build / keep)
            if not (build / "memory" / "MEMORY.md").exists():
                (build / "memory").mkdir(parents=True, exist_ok=True)
                (build / "memory" / "MEMORY.md").write_text("# Memory\n",
                                                            encoding="utf-8")
            _swap_in(target, build)
            _write_stamp(target, "agent", row.get("version"), sync_key)
            logger.info("hydration: materialized agent %r (v%s, %d skill(s)) "
                        "-> %s", role, row.get("version"), len(skills), target)
            return "materialized"
    except Exception:
        logger.debug("hydration: agent %r failed - fail-open", role,
                     exc_info=True)
        return "error"
    finally:
        _release(con)
