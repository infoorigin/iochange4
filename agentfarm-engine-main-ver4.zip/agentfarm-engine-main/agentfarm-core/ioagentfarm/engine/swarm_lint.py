"""Linter for swarm definitions — the validator ``parse_swarm`` is not.

Small sibling of ``workflow_lint``: same finding shapes, same did-you-mean
on unknown keys, and the same never-disagree rule — the deepest check
compiles the definition with the REAL compiler (``compile_swarm_docs`` is
pure) and validates the resulting graph with the loader's own
``collect_workflow_errors``, so lint-clean means run-loadable.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, List, Optional

import yaml

from ioagentfarm.engine.workflow_lint import (ERROR, WARNING, Finding,
                                              LintResult, _suggest)

SWARM_TOP_LEVEL_KEYS = frozenset({
    "name", "description", "role", "agents", "mcp_servers",
    "skills", "deliverable", "max_attempts", "budget", "vars",
})

_BUDGET_KEYS = frozenset({"tool_calls", "consults"})

_LIST_KEYS = ("agents", "mcp_servers", "skills")


def lint_swarm_text(text: str, dir_name: Optional[str] = None,
                    base_dir: Any = None) -> List[Finding]:
    findings: List[Finding] = []
    try:
        data = yaml.safe_load(text) or {}
    except yaml.YAMLError as exc:
        return [Finding(ERROR, "swarm.yaml", f"not valid YAML: {exc}",
                        "fix the YAML syntax before anything else")]
    if not isinstance(data, dict):
        return [Finding(ERROR, "swarm.yaml", "top level must be a mapping",
                        "start the file with `name: <swarm>`")]

    for key in sorted(set(data) - SWARM_TOP_LEVEL_KEYS):
        guess = _suggest(key, SWARM_TOP_LEVEL_KEYS)
        findings.append(Finding(
            ERROR, key,
            "unknown key - the swarm loader never reads it, so whatever it "
            "was meant to do silently does not happen",
            f"did you mean `{guess}`?" if guess
            else "remove it, or check docs/reference/swarm-yaml.md"))

    name = data.get("name")
    if not isinstance(name, str) or not name:
        findings.append(Finding(ERROR, "name", "missing or not a string",
                                "name: <the directory name>"))
    elif dir_name and name != dir_name:
        findings.append(Finding(
            ERROR, "name",
            f"`{name}` does not match the directory name `{dir_name}` - "
            "everything that addresses a swarm uses the directory name",
            f"name: {dir_name}"))

    role = data.get("role")
    if not isinstance(role, str) or not role:
        findings.append(Finding(ERROR, "role",
                                "missing or not a string - a swarm is run by "
                                "one meta-agent",
                                "role: <an agent role in this family>"))
    elif role == "project_lead":
        findings.append(Finding(
            ERROR, "role",
            "project_lead is the run DRIVER; run-step refuses to execute "
            "steps as it",
            "name a dedicated orchestrator agent (aicore new-agent <role>)"))

    for key in _LIST_KEYS:
        if key in data and data[key] is not None and not isinstance(
                data[key], list):
            findings.append(Finding(
                ERROR, key, "must be a list (or omitted)",
                f"{key}: [a, b] - or omit the key entirely"))

    if "deliverable" in data and not isinstance(data["deliverable"], str):
        findings.append(Finding(ERROR, "deliverable",
                                "must be a file name string",
                                "deliverable: swarm_report.md"))
    if "max_attempts" in data and (not isinstance(data["max_attempts"], int)
                                   or data["max_attempts"] < 1):
        findings.append(Finding(ERROR, "max_attempts", "must be an int >= 1",
                                "max_attempts: 2"))
    if "vars" in data and not isinstance(data["vars"], dict):
        findings.append(Finding(ERROR, "vars", "must be a mapping",
                                "vars: {key: value}"))
    elif isinstance(data.get("vars"), dict):
        # Same contract as workflow vars: values are STRINGS (the model is
        # Dict[str, str] and pydantic refuses the whole definition
        # otherwise). Catch it here with a fix, not as a pydantic dump.
        for key, value in data["vars"].items():
            if not isinstance(value, str):
                shown = ("a list - join it into one string"
                         if isinstance(value, list)
                         else f"{type(value).__name__} - quote it")
                findings.append(Finding(
                    ERROR, f"vars.{key}",
                    f"var values must be quoted strings; this is {shown}",
                    f'vars: {{{key}: "..."}}'))

    budget = data.get("budget")
    if budget is not None:
        if not isinstance(budget, dict):
            findings.append(Finding(ERROR, "budget", "must be a mapping",
                                    "budget: {tool_calls: 120, consults: 6}"))
        else:
            for key in sorted(set(budget) - _BUDGET_KEYS):
                guess = _suggest(key, _BUDGET_KEYS)
                findings.append(Finding(
                    ERROR, f"budget.{key}", "unknown key",
                    f"did you mean `{guess}`?" if guess
                    else "known keys: tool_calls, consults"))
            for key in _BUDGET_KEYS & set(budget):
                if not isinstance(budget[key], int) or budget[key] < 1:
                    findings.append(Finding(
                        ERROR, f"budget.{key}", "must be an int >= 1",
                        f"budget: {{{key}: 100}}"))
            tc = budget.get("tool_calls")
            if isinstance(tc, int) and 1 <= tc < 20:
                findings.append(Finding(
                    WARNING, "budget.tool_calls",
                    "values under 20 are raised to 20 at compile time - the "
                    "run driver shares the instance config and needs "
                    "headroom for its own cycles",
                    "budget: {tool_calls: 20} or higher"))

    if not str(data.get("description") or "").strip():
        findings.append(Finding(
            WARNING, "description",
            "empty - operators pick a swarm from this line, and the "
            "meta-agent's persona quotes it",
            "one sentence: what this swarm achieves"))

    if data.get("agents") == [] and data.get("mcp_servers") == []:
        findings.append(Finding(
            WARNING, "agents",
            "both rosters are explicitly empty - this swarm can consult "
            "nothing and will answer from the meta-agent's own knowledge",
            "name at least one agent or MCP server, or omit the keys"))

    if findings and any(f.severity == ERROR for f in findings):
        return findings

    # The deepest check: compile with the real compiler and validate the
    # graph the run would execute.
    from ioagentfarm.engine.models import Role, Step, Workflow
    from ioagentfarm.engine.swarms import compile_swarm_docs, parse_swarm
    from ioagentfarm.engine.workflow_loader import collect_workflow_errors
    try:
        swarm = parse_swarm(text, base_dir=base_dir)
        wf_dict, _role_md, _step_md = compile_swarm_docs(swarm)
        role_spec = wf_dict["roles"][0]
        skeleton = Workflow(
            name=wf_dict["name"],
            description=wf_dict.get("description", ""),
            roles={role_spec["name"]: Role(name=role_spec["name"],
                                           prompt="(generated)",
                                           skills=role_spec["skills"])},
            steps=[Step(key=s["key"], title=s.get("title", ""),
                        role=s["role"], max_attempts=s["max_attempts"],
                        prompt="(generated)",
                        requires_artifacts=s["requires_artifacts"])
                   for s in wf_dict["steps"]],
        )
        for msg in collect_workflow_errors(skeleton):
            findings.append(Finding(ERROR, "compiled", msg,
                                    "this is a compiler bug - please report it"))
    except ValueError as exc:
        findings.append(Finding(ERROR, "swarm.yaml", str(exc), ""))
    return findings


def lint_swarm_dir(base: Path) -> LintResult:
    base = Path(base)
    marker = base / "swarm.yaml"
    if not marker.is_file():
        return LintResult(base, [Finding(
            ERROR, "swarm.yaml", "not found - a swarm dir is defined by it",
            f"create {marker}")])
    findings = lint_swarm_text(marker.read_text(encoding="utf-8"),
                               dir_name=base.name, base_dir=base)
    name = ""
    try:
        name = (yaml.safe_load(marker.read_text(encoding="utf-8"))
                or {}).get("name") or ""
    except yaml.YAMLError:
        pass
    return LintResult(marker, findings, name=name)


def lint_swarm(target: str, root: Optional[Path] = None) -> LintResult:
    """Lint by NAME (resolved like run-swarm resolves) or by PATH."""
    as_path = Path(target)
    if as_path.is_dir() and (as_path / "swarm.yaml").is_file():
        return lint_swarm_dir(as_path)
    if as_path.is_file() and as_path.name == "swarm.yaml":
        return lint_swarm_dir(as_path.parent)

    from ioagentfarm.engine.swarms import SwarmLoader
    loader = SwarmLoader()
    override = loader._override_dir(target, root)
    if (override / "swarm.yaml").is_file():
        return lint_swarm_dir(override)
    for source in loader._sources():
        try:
            candidate = source / target
            if (candidate / "swarm.yaml").is_file():
                if isinstance(candidate, Path) or hasattr(candidate, "name"):
                    text = (candidate / "swarm.yaml").read_text(
                        encoding="utf-8")
                    findings = lint_swarm_text(text, dir_name=target,
                                               base_dir=candidate)
                    return LintResult(f"pack:{target}", findings, name=target)
        except (OSError, TypeError, AttributeError):
            continue
    return LintResult(target, [Finding(
        ERROR, "swarm", f"no swarm named {target!r} and no such path",
        "aicore list-swarms shows what exists; aicore new-swarm creates one")])
