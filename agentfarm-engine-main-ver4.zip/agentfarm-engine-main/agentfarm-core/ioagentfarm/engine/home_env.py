"""Publishing a project ``.env`` to the home directory, where agent tools read it.

The agent runtime strips a tool subprocess's environment down to
``{HOME, LANG, TERM}``, so an agent running ``iof-query`` or ``vectorfs``
inherits no credentials at all. Those tools fall back to ``$HOME/.env``, and
HOME is the one variable that survives — it is the only stable anchor.

THAT IS A CREDENTIAL MOVE, AND IT DESERVES CARE. It copies whatever ``.env``
is in the current directory to the user's home directory, where every agent,
every CLI tool and every other project on the machine will read it. Run
``setup-agents`` from a checkout whose ``.env`` points at production and that
becomes the machine-wide default.

The decision lives here, apart from the CLI, so it can be tested: this is
exactly the sort of code where "I assumed it did X" is expensive.
"""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path

#: Outcomes. The CLI renders these; tests assert on them.
UNCHANGED = "unchanged"      # home copy already matches the source
LINKED = "linked"            # symlinked (single source of truth)
COPIED = "copied"            # copied (no symlink privilege)
FAILED = "failed"


def _state_dir_name() -> str:
    """``.iobot``, or whatever ``IOF_STATE_DIR_NAME`` overrides it to.

    Same variable the runtime state-dir patch reads, so a rollback to
    ``.iobot`` moves this file with everything else rather than stranding
    credentials in a directory nothing looks at any more.
    """
    import os
    return (os.getenv("IOF_STATE_DIR_NAME") or ".iobot").strip() or ".iobot"


def home_env_path() -> Path:
    """Where a published ``.env`` belongs: ``~/.iobot/.env``.

    IT USED TO BE ``~/.env``, on the reasoning that HOME is the one variable
    surviving the tool-subprocess env strip. True, and it does not follow that
    the file must sit AT ``$HOME`` — ``~/.iobot/`` is derived from the same
    variable and is reachable in exactly the same places, a pod included
    (``/root/.iobot/``, where the entrypoint already writes ``config.json``).

    What ``$HOME/.env`` cost: `setup-agents`, run from any directory, published
    that directory's credentials to a path shared with every other tool on the
    machine. It collided with hand-maintained files, it survived every teardown
    of this product's own state, and it is how an agent came to answer with a
    run from an entirely different environment's database. Namespacing it fixes
    all three — the file now lives and dies with the state directory it belongs
    to.
    """
    return Path.home() / _state_dir_name() / ".env"


def home_env_candidates() -> list[Path]:
    """Every published ``.env`` a tool should consult, best first.

    The legacy ``~/.env`` stays in the READ chain and is gone from the write
    path. An install that predates the move keeps working; nothing new is put
    there, so the old file ages out rather than being deleted underneath
    someone — the same rule the rest of this module follows.
    """
    return [home_env_path(), Path.home() / ".env", Path("/app/.env")]


def deploy_home_env(src: Path, dest: Path) -> dict:
    """Publish *src* to *dest*, preserving anything already there.

    Returns ``{"action", "src", "dest", "backup", "error"}``.

    Three things this used to get wrong, all of which defeated exactly the
    operator who was right to be suspicious:

    * It reported ``~/.env`` rather than the resolved path — and ``~`` is
      ambiguous under Git Bash, where ``$HOME`` and ``USERPROFILE`` can differ.
    * It used :func:`shutil.copy2`, which preserves the SOURCE mtime. A file
      published seconds ago looked days old, so the most natural check — "was
      anything written just now?" — returned the wrong answer.
    * It deleted an existing file outright. A hand-maintained ``~/.env``, or
      another project's credentials, vanished with no backup and no mention,
      in a platform whose stated rule elsewhere is that nothing is erased
      without a snapshot first.
    """
    result = {"action": FAILED, "src": src, "dest": dest,
              "backup": None, "error": None}
    try:
        if dest.is_file() and not dest.is_symlink() \
                and dest.read_bytes() == src.read_bytes():
            result["action"] = UNCHANGED
            return result

        if dest.exists() or dest.is_symlink():
            if dest.is_file() and not dest.is_symlink():
                # with_name, not with_suffix: ".env" has an EMPTY suffix and a
                # stem of ".env", so with_suffix() produces ".env.env.bak.…".
                backup = dest.with_name(
                    f".env.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}")
                shutil.copy2(str(dest), str(backup))
                result["backup"] = backup
            dest.unlink()

        try:
            dest.symlink_to(src)
            result["action"] = LINKED
        except OSError:
            # Windows without developer mode/admin has no symlink privilege.
            # copy, NOT copy2 — the file must carry a CURRENT mtime so the
            # deployment is visible to whoever comes looking for it.
            shutil.copy(str(src), str(dest))
            result["action"] = COPIED
    except Exception as exc:      # never fail setup over this
        result["error"] = str(exc)
    return result
