"""Cheap fail-fast environment guards for run creation.

A run that starts on a nearly-full disk fails LATE and UGLY: half-written
artifacts, truncated session JSONLs, corrupt SQLite pages — all of which
look like agent/provider bugs and burn forensic time. Failing run creation
fast with a named error beats all of that.

Guards are deliberately conservative and env-tunable; a guard must never
produce a false refusal on a healthy system (set ``IOF_MIN_FREE_DISK_MB=0``
to disable).
"""
from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


class DiskSpaceError(RuntimeError):
    """Raised when the state volume has less free space than the floor."""


def ensure_free_disk(root_path: Path, *, min_mb: int | None = None) -> None:
    """Fail fast when the IOF state volume is nearly full.

    Checked at run creation (CLI ``run`` + ``POST /api/run``). Floor via
    ``IOF_MIN_FREE_DISK_MB`` (default 500; ``0`` disables). Best-effort on
    the measurement itself: if the volume cannot be inspected we do NOT
    block the run (an unreadable statvfs must not take the platform down),
    but a genuine below-floor reading raises ``DiskSpaceError``.
    """
    floor_mb = min_mb if min_mb is not None else int(
        os.environ.get("IOF_MIN_FREE_DISK_MB", "500"))
    if floor_mb <= 0:
        return
    try:
        probe = Path(root_path)
        while not probe.exists() and probe.parent != probe:
            probe = probe.parent
        free_mb = shutil.disk_usage(str(probe)).free / (1024 * 1024)
    except Exception:
        logger.debug("disk-space guard could not inspect %s", root_path, exc_info=True)
        return
    if free_mb < floor_mb:
        raise DiskSpaceError(
            f"Refusing to create run: only {free_mb:.0f} MB free on the state "
            f"volume ({root_path}), below the IOF_MIN_FREE_DISK_MB floor of "
            f"{floor_mb} MB. A run started on a full disk fails late with "
            f"corrupt artifacts; free space or lower the floor, then retry."
        )
