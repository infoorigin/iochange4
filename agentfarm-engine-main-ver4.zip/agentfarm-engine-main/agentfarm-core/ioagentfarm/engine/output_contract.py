"""Does this agent promise the v1 envelope?

WHY THIS EXISTS. Four capabilities in the chat path — suppressing the
composition suffix, extracting the envelope, measuring `data_window`, and
cross-checking rows against the tool results they claim to come from — were
gated on a hand-written tuple of role names in ``web/app.py``. A list of
"roles known to emit v1", maintained a long way from the skill that makes the
promise, drifts in both directions and did: it named ``aria``, which has no
agent workspace in this repository, while omitting ``market_feedback``,
``profound_a2a``, ``reporting`` and ``sia_agent``, each of which ships a
``result_composer`` mandating the same envelope. Their answers came back
unparsed, with a SMART composition suffix contradicting their own
``always: true`` skill.

THE SIGNAL IS THE AGENT'S OWN CONTENT, so the capability follows the skill.
Give any agent a composer that mandates the envelope and it is treated as a v1
agent, with no core edit — which is the rule the rest of this codebase already
follows for capabilities.

TWO CONDITIONS, BOTH REQUIRED, and the second is not redundant.
``defines_output_contract`` (the linter's own detector, shared rather than
reimplemented) answers "does an always-on skill dictate the format" — it says
yes for ``ainf-meta-agent``, whose contract is real and is NOT this one. Asking
additionally for the v1 field vocabulary is what separates "owns a format" from
"owns THIS format", and it matters most for the capability that puts words in
the agent's mouth: the two-phase prompts name `answer`/`data`/`viz_hint` and
`insight`/`follow_up_chips`/`evidence` explicitly, so handing them to an agent
with a different contract asks it for fields it has never heard of.

It is a heuristic over prose, like the linter's half, and it fails SAFE: a
false negative leaves an agent exactly where it is today, and a false positive
costs a parse attempt that returns None. Neither can corrupt an answer.
"""
from __future__ import annotations

from pathlib import Path

from ioagentfarm.engine.content_lint import defines_output_contract

#: Vocabulary unique to the v1 envelope. `viz_hint` and `follow_up_chips` are
#: the discriminating pair — `answer`, `data` and `evidence` are ordinary words
#: that appear in many contracts, so matching on those would re-admit exactly
#: the agent this list exists to exclude.
_V1_CUES = ("viz_hint", "follow_up_chips", '"schema": "v1"', "schema: v1")

#: NOT CACHED, deliberately. The obvious memo is keyed on the skills directory
#: and its mtime — and that is wrong at exactly the moment it matters: the
#: workspace is re-seeded from the pack on the first turn of a new session, and
#: a skill materialised inside the same filesystem tick as a prior check leaves
#: the mtime unmoved, so the stale answer wins for the life of the process. It
#: cost nothing worth having either: this is a handful of small reads against
#: an LLM call measured in seconds, and the runtime already re-reads SOUL.md
#: and every skill on every turn.


#: The binaries the per-session scratch block exists to serialise. An agent
#: that names neither has nothing to write into a scratch directory.
_QUERY_TOOL_CUES = ("iof-query", "vectorfs")


def uses_query_tools(workspace: Path | str) -> bool:
    """True when any skill in *workspace* tells the agent to run a query tool.

    The per-session scratch directory is MANDATORY for the agents that do
    (parallel requests otherwise race on one `query.sql` — see CLAUDE.md), and
    meaningless for the ones that do not: the B2 certification found ~2.4 KB
    per turn instructing `iof-query --sql-file` / `vectorfs --scratch` injected
    into a warm conversational agent carrying neither tool — a standing
    invitation to call a binary that is not installed, paid for on every turn
    of every chat.

    FAILS OPEN, deliberately and asymmetrically: an unreadable workspace
    returns True. Injecting the block into an agent that does not need it
    costs tokens; withholding it from one that does costs a concurrency race
    on a shared file, which is the failure this block exists to prevent.
    """
    return _names_a_query_tool(workspace) and _has_query_metadata(workspace)


def _names_a_query_tool(workspace: Path | str) -> bool:
    """Does any skill in the workspace tell the agent to run a query tool?"""
    skills = Path(workspace) / "skills"
    try:
        entries = sorted(skills.iterdir())
    except OSError:
        return True                        # cannot tell -> keep the guarantee
    for d in entries:
        try:
            if not d.is_dir():
                continue
            body = (d / "SKILL.md").read_text(
                encoding="utf-8", errors="replace").lower()
        except OSError:
            return True                    # cannot tell -> keep the guarantee
        if any(cue in body for cue in _QUERY_TOOL_CUES):
            return True
    return False


#: What `configure-agent` deploys into an agent that is meant to query -
#: the deployment's own catalog, databases and vector config. Their PRESENCE
#: is the honest answer to "can this agent query anything at all".
_QUERY_METADATA = ("catalog.yaml", "catalog.yml", "databases.yml",
                   "databases.yaml", "vectorfs.yaml", "vectorfs.yml")


#: CLI tools an agent's skills name when they mean "run this from a shell".
#: Deliberately broad: keeping a shell an agent does not need is a leak, and
#: taking one it DOES need is an outage, so anything shell-shaped counts.
_OTHER_CLI_CUES = ("iof-consult", "iof-recall", "iof-case", "iof-plays",
                   "iof-run-audit", "iof-s3", "aicore ", "ioagentfarm ",
                   "npm ", "node ", "python ", "pytest")


#: Query tools are NOT in the declared-cue set below: seeding gives every
#: agent the shared `data_query` skill, so "mentions iof-query" is true of a
#: warm conversational agent too. They keep the stricter test in
#: `uses_query_tools`, which additionally requires deployed DATA.
_QUERY_TOOL_BINS = {"iof-query", "vectorfs"}


def _declared_tool_bins() -> set[str]:
    """Binaries the INSTALLED PACKS declare, from their `tools.yaml`.

    The static cue list above can only ever name core's own tools, so an
    agent whose skill teaches a tool the CLIENT wrote - the entire point of
    `aicore new-tool` - was read as "never runs a command" and lost its
    shell. It then reported, correctly and uselessly, that it could not run
    the tool its own skill told it to run.

    A declaration is the deployment's own statement that the binary exists
    here, which is the same kind of evidence `uses_query_tools` demands, so
    naming one in a skill is enough. Never raises: this decides whether to
    REMOVE a capability, and an unreadable registry must leave it in place.
    """
    try:
        from ioagentfarm.packs import load_registry
        bins: set[str] = set()
        for tool in load_registry().tools():
            for key in ("bin", "name"):
                value = tool.get(key)
                if isinstance(value, str) and value.strip():
                    bins.add(value.strip())
        return {b for b in bins if b not in _QUERY_TOOL_BINS}
    except Exception:  # noqa: BLE001
        return set()


def needs_exec(workspace: Path | str) -> bool:
    """Does this agent's own content say it runs shell commands?

    WHY AN AGENT LOSES ITS SHELL. Certification round 6 read another user's
    secret out of a sibling agent's session file through four different shell
    spellings, and demonstrated why a denylist cannot close it: one route
    wrote a python script and ran it, another built the path from an
    environment variable and a wildcard and named no sibling at all. The rail
    catches the obvious spelling; it cannot catch a shell.

    What CAN be closed is the question of who needs a shell in the first
    place. A warm conversational agent - the client-facing case - never runs
    a command, so the tool is pure exposure for it; a query agent runs
    `iof-query`, and taking that away would be an outage. So the pool asks
    the agent's OWN content, exactly as `uses_query_tools` does, and removes
    the tool only from an agent whose skills never mention a command.

    Fails OPEN (True) on anything it cannot read: losing a shell an agent
    needs breaks a deployment, and this is a reduction of exposure, not a
    security boundary - real containment is OS-level, and is recorded in the
    backlog.
    """
    if uses_query_tools(workspace):
        return True
    declared = _declared_tool_bins()
    skills = Path(workspace) / "skills"
    try:
        entries = sorted(skills.iterdir())
    except OSError:
        return True                        # cannot tell -> keep the tool
    for d in entries:
        try:
            if not d.is_dir():
                continue
            body = (d / "SKILL.md").read_text(
                encoding="utf-8", errors="replace").lower()
        except OSError:
            return True
        if any(cue in body for cue in _OTHER_CLI_CUES):
            return True
        if any(b.lower() in body for b in declared):
            return True
    # DELIBERATELY NOT: "any skill that mentions a query tool". Seeding gives
    # every agent the shared `data_query` skill, so that test answers True
    # for a warm conversational agent - the same mistake that made the
    # scratch-block gate unreachable in a real deployment. A query agent is
    # recognised by `uses_query_tools` above, which needs deployed DATA.
    return False


def _has_query_metadata(workspace: Path | str) -> bool:
    """True when the agent has data deployed for it to query.

    THE SKILL ALONE IS NOT THE SIGNAL, and assuming it was made the first
    version of this gate unreachable. Seeding gives EVERY agent the shared
    `data_query` skill, so a scan for query cues answered True for a warm
    conversational agent that had never been near a database - the B3
    certification measured the 2.2 KB scratch preamble still reaching a
    tool-less agent on every turn, and on an EMPTY message the preamble
    WAS the whole prompt: the agent replied "I'm ready to help you run SQL
    queries". What separates the two is not the skill (everyone has it) but
    whether a deployment ever gave this agent data: `configure-agent` writes
    `catalog.yaml`/`databases.yml`/`vectorfs.yaml` into its `metadata/`.

    Fails OPEN on an unreadable directory, like its caller: withholding the
    per-session scratch path from an agent that really does query costs a
    race on a shared `query.sql`.
    """
    ws = Path(workspace)
    md = ws / "metadata"
    try:
        if not ws.is_dir():
            # The AGENT HOME itself is absent: nothing can be told about this
            # agent at all, so keep the guarantee. Distinct from the case
            # below, where the home exists and simply holds no data - that is
            # an ANSWER, not an absence of one.
            return True
        if not md.is_dir():
            return False                   # nothing deployed -> nothing to query
        names = {p.name.lower() for p in md.iterdir()}
    except OSError:
        return True                        # cannot tell -> keep the guarantee
    return any(n in names for n in _QUERY_METADATA)


def emits_v1_envelope(workspace: Path | str) -> bool:
    """True when an always-on skill in *workspace* mandates the v1 envelope."""
    skills = Path(workspace) / "skills"
    try:
        entries = sorted(skills.iterdir())
    except OSError:
        return False
    for d in entries:
        try:
            if not d.is_dir() or not defines_output_contract(d):
                continue
            body = (d / "SKILL.md").read_text(
                encoding="utf-8", errors="replace").lower()
        except OSError:
            continue
        if any(cue in body for cue in _V1_CUES):
            return True
    return False
