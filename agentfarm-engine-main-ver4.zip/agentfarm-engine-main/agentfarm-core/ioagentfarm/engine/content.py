"""Content provenance — WHICH pack, version and commit this environment runs.

The One Truth model (docs/one-truth-content-model.md): the installed pack is
the only source of agents, skills and workflows, and every surface that shows
or runs content says where it came from. This module computes that stamp.

    stamps()      -> [Stamp, ...]   one per installed distribution that is
                                     agentfarm-core or declares an aicore pack
    stamp_line()  -> "pharma 0.2.0 @ 5eee3fd+local | agentfarm-core 0.6.4 @ 5eee3fd+local"

Detection, never declaration. For each distribution:
  * version   — distribution metadata
  * checkout  — an editable install (``direct_url.json`` with ``dir_info.editable``)
                whose directory sits inside a git work tree: sha = HEAD, dirty =
                ``git status --porcelain`` scoped to the pack's own directory
  * wheel     — no git; sha = ``IOF_BUILD_SHA`` (baked into an image at build
                time) or None

``+local`` marks a checkout with uncommitted changes to the pack's files —
"commit X plus edits" — and is the honest answer for a developer machine.

Cheap by construction: git is invoked at most twice per work tree per process
(cached), with a short timeout, and never on a wheel.
"""

from __future__ import annotations

import logging
import os
import subprocess
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from functools import lru_cache
from importlib.metadata import (Distribution, PackageNotFoundError, distribution,
                                entry_points)
from pathlib import Path
from urllib.parse import unquote, urlparse
import json

from ioagentfarm.packs import ENTRY_POINT_GROUPS

logger = logging.getLogger(__name__)

#: The engine's own distribution — always stamped first.
#:
#: The SHIPPED name. An organisation that republishes the SDK under its own
#: name has no distribution called this, so every lookup below must fall
#: back to asking WHICH distribution provides this import package rather
#: than trusting the literal: on a republished install the engine was not
#: stamped first, and `packs_only` failed to exclude it, because the name
#: never matched (found while removing publisher names from the client
#: guides, 2026-09-03).
CORE_DIST = "agentfarm-core"


def core_dist() -> str:
    """The distribution that actually provides this engine, on this host.

    `CORE_DIST` when it is installed under the shipped name; otherwise the
    distribution that supplies the `ioagentfarm` import package. One
    metadata lookup in the common case, a scan only when republished -
    the same order `cli._sdk_distributions` uses.
    """
    global _CORE_DIST_RESOLVED
    if _CORE_DIST_RESOLVED is not None:
        return _CORE_DIST_RESOLVED
    name = CORE_DIST
    try:
        distribution(CORE_DIST)
    except PackageNotFoundError:
        try:
            from ioagentfarm.cli_scaffold import _dist_providing
            name = _dist_providing("ioagentfarm") or CORE_DIST
        except Exception:  # noqa: BLE001 - a stamp must never raise
            name = CORE_DIST
    _CORE_DIST_RESOLVED = name
    return name


#: Memoised: the answer cannot change within a process.
_CORE_DIST_RESOLVED: str | None = None
#: Baked into a container image at build time; the commit for a wheel.
BUILD_SHA_ENV = "IOF_BUILD_SHA"
_GIT_TIMEOUT_S = 3.0
#: Per-run record of WHICH content the run was created from —
#: ``.iof/instances/<run_id>/provenance.json``. Written once at run creation
#: (the ``run.created`` seam every creation path reaches), read by
#: ``forensics explain``. Travels with the instance dir, so S3 sync carries it.
RUN_PROVENANCE_FILE = "provenance.json"
#: What ``explain`` prints for a run created before this file existed.
CONTENT_NOT_RECORDED = "(not recorded — run predates provenance)"
#: ...and for a run whose creation wrote the file but could not compute a stamp.
CONTENT_STAMP_FAILED = "(not recorded — stamp unavailable at run creation)"


@dataclass(frozen=True)
class Stamp:
    """Provenance of one installed distribution."""
    pack: str            #: entry-point name (family code), or the dist name for core
    dist: str            #: distribution name as installed
    version: str
    source: str          #: 'checkout' | 'wheel'
    root: str | None     #: directory the content is read from
    sha: str | None      #: short commit; None when unknown
    dirty: bool          #: checkout only: uncommitted changes under `root`

    def render(self) -> str:
        sha = self.sha or "?"
        local = "+local" if self.dirty else ""
        return f"{self.dist} {self.version} @ {sha}{local}"

    def as_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# distribution → root / kind
# ---------------------------------------------------------------------------

def _direct_url(dist: Distribution) -> dict | None:
    try:
        txt = dist.read_text("direct_url.json")
    except Exception:  # pragma: no cover - metadata edge cases
        return None
    if not txt:
        return None
    try:
        return json.loads(txt)
    except ValueError:
        return None


def _dist_root(dist: Distribution) -> tuple[str, Path | None]:
    """('checkout', <dir>) for an editable install, else ('wheel', <site dir>)."""
    du = _direct_url(dist)
    if du and isinstance(du.get("dir_info"), dict) and du["dir_info"].get("editable"):
        url = du.get("url") or ""
        if url.startswith("file:"):
            p = urlparse(url).path
            # file:///C:/x on Windows parses to /C:/x
            if os.name == "nt" and len(p) > 2 and p[0] == "/" and p[2] == ":":
                p = p[1:]
            return "checkout", Path(unquote(p))
    try:
        return "wheel", Path(str(dist.locate_file("")))
    except Exception:  # pragma: no cover
        return "wheel", None


# ---------------------------------------------------------------------------
# git
# ---------------------------------------------------------------------------

def _git(args: list[str], cwd: Path) -> str | None:
    try:
        out = subprocess.run(
            ["git", *args], cwd=str(cwd), capture_output=True, text=True,
            timeout=_GIT_TIMEOUT_S, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if out.returncode != 0:
        return None
    return out.stdout


@lru_cache(maxsize=32)
def _git_toplevel(root: str) -> str | None:
    out = _git(["rev-parse", "--show-toplevel"], Path(root))
    return out.strip() if out else None


@lru_cache(maxsize=32)
def _git_head(toplevel: str) -> str | None:
    out = _git(["rev-parse", "--short=7", "HEAD"], Path(toplevel))
    return out.strip() if out else None


@lru_cache(maxsize=64)
def _git_dirty(toplevel: str, subdir: str) -> bool:
    """Uncommitted changes under *subdir* (tracked or untracked-not-ignored)."""
    out = _git(["status", "--porcelain", "--", subdir], Path(toplevel))
    return bool(out and out.strip())


def git_info(root: Path) -> tuple[str | None, bool]:
    """(short sha, dirty) for the git work tree containing *root*; (None, False)
    when it is not inside one or git is unavailable."""
    if root is None or not root.exists():
        return None, False
    top = _git_toplevel(str(root))
    if not top:
        return None, False
    sha = _git_head(top)
    try:
        rel = str(root.resolve().relative_to(Path(top).resolve()))
    except ValueError:
        rel = "."
    return sha, _git_dirty(top, rel or ".")


# ---------------------------------------------------------------------------
# public
# ---------------------------------------------------------------------------

def _stamp_for(pack: str, dist: Distribution) -> Stamp:
    name = dist.metadata["Name"]
    kind, root = _dist_root(dist)
    sha, dirty = (None, False)
    if kind == "checkout":
        sha, dirty = git_info(root)
    if sha is None:
        env_sha = (os.environ.get(BUILD_SHA_ENV) or "").strip()
        sha = env_sha[:7] if env_sha else None
    return Stamp(pack=pack, dist=name, version=dist.version, source=kind,
                 root=str(root) if root else None, sha=sha, dirty=dirty)


def _pack_distributions() -> list[tuple[str, Distribution]]:
    """(entry-point name, distribution) for every installed aicore pack, plus
    core first. De-duplicated by distribution name; sorted by pack name so the
    line is stable across machines."""
    out: list[tuple[str, Distribution]] = []
    seen: set[str] = set()
    # Direct lookup — iterating distributions() walks every dist-info on the
    # path (measured 4.6 s cold in a full venv) to find one name.
    _core_name = core_dist()
    try:
        core = distribution(_core_name)
    except PackageNotFoundError:
        core = None
    if core is not None:
        out.append((_core_name, core))
        seen.add(_core_name)
    packs: list[tuple[str, Distribution]] = []
    for group in ENTRY_POINT_GROUPS:
        try:
            eps = entry_points(group=group)
        except Exception:  # pragma: no cover
            continue
        for ep in eps:
            dist = getattr(ep, "dist", None)
            if dist is None:
                continue
            dname = dist.metadata["Name"]
            if dname in seen:
                continue
            seen.add(dname)
            packs.append((ep.name, dist))
    packs.sort(key=lambda t: t[0])
    return out + packs


def stamps() -> list[Stamp]:
    """One Stamp per installed distribution that carries content: core first,
    then every aicore pack in name order."""
    return [_stamp_for(pack, dist) for pack, dist in _pack_distributions()]


def stamp_line(items: list[Stamp] | None = None, *, packs_only: bool = False) -> str:
    """The one-line provenance shown on every command and every run header."""
    items = stamps() if items is None else items
    if packs_only:
        _core_name = core_dist()
        items = [s for s in items if s.dist != _core_name] or items
    return " | ".join(s.render() for s in items)


def stamp_dict(items: list[Stamp] | None = None) -> dict:
    """JSON-friendly form for snapshots, events and registration rows."""
    items = stamps() if items is None else items
    return {"line": stamp_line(items), "packs": [s.as_dict() for s in items]}


# ---------------------------------------------------------------------------
# per-run provenance — .iof/instances/<run_id>/provenance.json
# ---------------------------------------------------------------------------

def run_provenance_path(root: Path, run_id: str) -> Path:
    return Path(root) / "instances" / run_id / RUN_PROVENANCE_FILE


_COMPUTE = object()   # sentinel: "compute the stamp here"


def write_run_provenance(root: Path, run_id: str, *,
                         workspace_code: str | None,
                         content: dict | None | object = _COMPUTE,
                         draft: dict | None = None) -> dict | None:
    """Record which content a run was created from. FAIL-OPEN.

    Returns the document written, or ``None`` when nothing could be written.
    A stamp failure never fails run creation: the document is still written
    with ``content: null`` (so ``explain`` can say "stamp unavailable" rather
    than "predates provenance"), and the cause is logged at WARNING — loud
    enough to notice, never fatal.

    ``content`` may be passed in when the caller has already computed
    :func:`stamp_dict` (the run.created event carries the same line, and the
    two must agree); pass ``None`` explicitly to record that the stamp
    could not be computed. Omitted, it is computed here.

    ``draft`` — ``{"author": ..., "items": [...]}`` for a DRAFT run. The
    stamp alone would then be a lie of omission: the pack line says what is
    installed, while what actually ran was the pack plus one author's
    overlay, and a postmortem that cannot see the difference blames the
    pack. Absent from the document entirely for ordinary runs, so old
    readers see an unchanged shape.
    """
    if content is _COMPUTE:
        try:
            content = stamp_dict()
        except Exception:
            logger.warning("content stamp unavailable for run %s; provenance "
                           "written without it", run_id, exc_info=True)
            content = None
    doc = {
        "run_id": run_id,
        "workspace_code": workspace_code,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "content": content,
    }
    if draft:
        doc["draft"] = draft
    try:
        path = run_provenance_path(root, run_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    except Exception:
        logger.warning("could not write %s for run %s", RUN_PROVENANCE_FILE,
                       run_id, exc_info=True)
        return None
    return doc


def read_run_provenance(root: Path, run_id: str) -> dict | None:
    """The provenance document, or ``None`` when absent/unreadable (fail-open)."""
    try:
        path = run_provenance_path(root, run_id)
        if not path.is_file():
            return None
        doc = json.loads(path.read_text(encoding="utf-8-sig"))
        return doc if isinstance(doc, dict) else None
    except Exception:
        logger.debug("unreadable %s for run %s", RUN_PROVENANCE_FILE, run_id,
                     exc_info=True)
        return None


def workflow_snapshot_sha(root: Path, run_id: str) -> str | None:
    """A digest of the run's FROZEN workflow directory
    (``instances/<run_id>/workflow/``): the prompts and the tools this run
    executed. Packs are stamped at creation; the snapshot was not, so two
    runs across a mid-week tool edit read identically in ``explain``
    (novice finding, round 6). Computed from the snapshot at read time -
    it is frozen per run, so the answer cannot drift. None when the run
    has no snapshot (or it is unreadable)."""
    import hashlib
    base = Path(root) / "instances" / run_id / "workflow"
    if not base.is_dir():
        return None
    h = hashlib.sha256()
    try:
        for p in sorted(x for x in base.rglob("*") if x.is_file()):
            h.update(p.relative_to(base).as_posix().encode("utf-8"))
            h.update(b"\0")
            h.update(p.read_bytes())
            h.update(b"\0")
    except OSError:
        return None
    return h.hexdigest()[:12]


def run_content_line(root: Path, run_id: str) -> str:
    """The ``content:`` line for a run — from its provenance.json, or the
    honest not-recorded text when the run predates the file. A draft run's
    line names the author, because "which bytes ran?" has a different answer
    there than the pack stamp alone gives."""
    doc = read_run_provenance(root, run_id)
    if doc is None:
        return CONTENT_NOT_RECORDED
    content = doc.get("content")
    line = content.get("line") if isinstance(content, dict) else None
    line = line if line else CONTENT_STAMP_FAILED
    # the snapshot digest sits with the pack stamps; a draft author stays
    # the LAST thing on the line (readers key on that suffix)
    snap = workflow_snapshot_sha(root, run_id)
    if snap:
        line = f"{line} | workflow snapshot @ {snap}"
    draft = doc.get("draft")
    author = draft.get("author") if isinstance(draft, dict) else None
    if author:
        line = f"{line} + draft by {author}"
    return line
