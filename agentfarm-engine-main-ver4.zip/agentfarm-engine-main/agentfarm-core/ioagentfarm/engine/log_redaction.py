"""Conversation text does not go into the log by default.

THE RUNTIME LOGS BOTH HALVES OF EVERY TURN, AT INFO. ``iobot.agent.loop``
writes ``Processing message from <channel>:<sender>: <the user's message>`` and
``Response to <channel>:<sender>: <the agent's reply>``. So wherever the pod's
stdout goes — a file, a log shipper, a colleague's terminal — every
conversation goes with it, outside the session store and outside every control
that protects it.

Found by an independent validator on the memory walkthrough, and it was the
route by which one caller's secret reached another: the agent grepped the
service's own log file and read a reply it had given somebody else. Redacting
our own ``chat.start`` line, which is what an earlier pass did, covered one
line of three and none of the ones the runtime writes.

The same decision already governs the OTel spans (``wrap_chat`` exports
lengths; ``IOF_OTEL_CONTENT=1`` opts in). This is that rule applied to the log,
with the same switch shape: ``IOF_LOG_CHAT_CONTENT=1`` puts the text back for a
deployment that wants it.

A length and a short digest are kept, so a turn can still be correlated with a
trace or a support report, and two reports of the same turn can be matched,
without reproducing what was said.

The runtime's source is vendored and must not be hand-edited, so this works at
the LOG RECORD, which also catches every other writer of the same lines.

WHAT THIS DELIBERATELY DOES NOT TOUCH, verified end to end on a real run:

* **The agent's deliverables.** ``analyze.md``, ``OUTPUT.md`` and everything
  else under a run's ``project/`` are the work product. Redacting them would
  destroy the thing the run exists to produce.
* **The forensic blobs.** ``forensics/attempts/*/`` — ``http.log``, the
  session JSONL, the stdout tee — are EVIDENCE, written before this runs and
  read by whoever has to explain a failure. The same rule that keeps branding
  out of them keeps redaction out of them.

The line is between what a system SAYS about a conversation (a log, a span, a
console) and what it KEEPS of one (a deliverable, a transcript, an audit
trail). Only the first is reduced here.
"""
from __future__ import annotations

import hashlib
import os
import re

#: The runtime's two conversation lines. Anchored on the literal prefixes it
#: writes, with the channel:sender kept — that is routing, not content.
_PATTERNS = (
    re.compile(r"^(Processing message from [^:]*:[^:]*: )(.+)$", re.S),
    re.compile(r"^(Response to [^:]*:[^:]*: )(.+)$", re.S),
)

#: TOOL CALL ARGUMENTS, which carry conversation text whenever the agent
#: passes any into a tool — a query it composed from what the user said, a
#: file it was asked to write. The TOOL NAME is kept: it is the half a
#: debugger needs, and it is not the user's words.
_TOOL_PATTERNS = (
    re.compile(r"^(Tool call: [\w.-]+\()(.+)(\))$", re.S),
    re.compile(r"^(Provider-hosted tool call: [\w.-]+\()(.+)(\))$", re.S),
)

#: Our own line, whose payload is already a digest when redaction is on. Left
#: alone so it is not digested twice.
_ALREADY_SAFE = re.compile(r"<\d+ chars, sha256:[0-9a-f]{6,}>")


def chat_content_logged() -> bool:
    """True when the deployment has opted into logging conversation text."""
    return (os.environ.get("IOF_LOG_CHAT_CONTENT") or "").strip().lower() in (
        "1", "true", "yes")


def summarize(text: str) -> str:
    """What replaces the text: enough to identify a turn, none of its content."""
    body = text.strip()
    digest = hashlib.sha256(body.encode("utf-8", "replace")).hexdigest()[:8]
    return f"<{len(body)} chars, sha256:{digest}>"


def redact_line(message: str) -> str:
    """Redact a formatted log line, or return it unchanged.

    Never raises: this runs inside a logging patcher, and a logging patcher
    that throws takes the log with it.
    """
    try:
        if not message or chat_content_logged():
            return message
        if _ALREADY_SAFE.search(message):
            return message
        for pattern in _PATTERNS:
            m = pattern.match(message)
            if m:
                return m.group(1) + summarize(m.group(2))
        for pattern in _TOOL_PATTERNS:
            m = pattern.match(message)
            if m:
                return m.group(1) + summarize(m.group(2)) + m.group(3)
        return message
    except Exception:  # noqa: BLE001 - never break logging
        return message


def redact_record(record) -> None:
    """Rewrite a loguru record in place. Used by the shared patcher."""
    try:
        message = record.get("message")
        if isinstance(message, str):
            redacted = redact_line(message)
            if redacted != message:
                record["message"] = redacted
    except Exception:  # noqa: BLE001
        pass
