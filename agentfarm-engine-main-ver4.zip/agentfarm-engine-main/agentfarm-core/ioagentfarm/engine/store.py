from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from ioagentfarm.engine.db import DbAdapter, engine_schema
from ioagentfarm.engine.models import Workflow, StepTemplate
from contextlib import contextmanager

logger = logging.getLogger(__name__)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


#: schema_meta row that records which revision of `Store._init_full` last
#: ran to completion against this database. See `Store.init`.
_INIT_STAMP_KEY = "store_init"
_INIT_STAMP: Optional[str] = None


def _init_stamp() -> str:
    """A digest of `_init_full`'s source - the schema revision, derived
    rather than declared. Falls back to the package version where source is
    unavailable (a bytecode-only install), which still changes on upgrade."""
    global _INIT_STAMP
    if _INIT_STAMP is None:
        import hashlib
        try:
            import inspect
            text = inspect.getsource(Store._init_full)
        except Exception:  # noqa: BLE001
            try:
                from importlib.metadata import version
                text = "version:" + version("agentfarm-core")
            except Exception:  # noqa: BLE001
                text = "version:unknown"
        _INIT_STAMP = hashlib.sha1(text.encode("utf-8")).hexdigest()[:20]
    return _INIT_STAMP


class Store:
    """Pluggable state store (runs, steps, stories, tasks).

    Accepts any DbAdapter implementation — SQLite (default), PostgreSQL,
    or third-party backends via the DbAdapter protocol.
    """

    def __init__(self, adapter: DbAdapter):
        self._db = adapter

    def _conn(self) -> Any:
        return self._db.connect()

    @contextmanager
    def _tx(self):
        """Connection + cursor context manager.  Yields a cursor only."""
        with self._conn() as con:
            self._db.init_connection(con)
            cursor = con.cursor()
            try:
                yield cursor
            finally:
                cursor.close()

    @contextmanager
    def _tx_pair(self):
        """Connection + cursor context manager.  Yields ``(con, cursor)``
        for operations that need explicit transaction control
        (BEGIN IMMEDIATE / COMMIT / ROLLBACK)."""
        with self._conn() as con:
            self._db.init_connection(con)
            cursor = con.cursor()
            try:
                yield con, cursor
            finally:
                cursor.close()

    def _q(self, sql: str) -> str:
        """Rewrite ? placeholders to the adapter's placeholder style."""
        ph = self._db.placeholder()
        if ph == "?":
            return sql
        return sql.replace("?", ph)

    def _now(self) -> str:
        return _utc_now()

    def _columns(self, cursor, table: str) -> set:
        """Column names via the CATALOG, never a failing SELECT — a failed
        statement poisons a PostgreSQL transaction, and ``init`` runs inside
        one."""
        try:
            if self._db.placeholder() == "%s":
                cursor.execute(
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_name = %s AND table_schema = %s",
                    (table, engine_schema()))
                return {(r["column_name"] if isinstance(r, dict)
                         or hasattr(r, "keys") else r[0])
                        for r in cursor.fetchall()}
            cursor.execute(f"PRAGMA table_info({table})")
            return {(r["name"] if isinstance(r, dict) or hasattr(r, "keys")
                     else r[1]) for r in cursor.fetchall()}
        except Exception:
            return set()

    def init(self) -> None:
        """Ensure the engine schema exists - ONE statement when it already does.

        ``_init_full`` is ~40 CREATE statements plus ten column probes, and
        it ran on EVERY ``_store()`` call: every CLI command (the code driver
        polls ``next-step`` in a subprocess every 2s), every web request (32
        call sites in the API), every 2s tick of the cloud SSE poll. On
        SQLite that is milliseconds; against a managed PostgreSQL each
        statement is a round trip, so a poll paid seconds of DDL to read one
        row.

        The full pass records a stamp of ITS OWN SOURCE in ``schema_meta``;
        a later ``init`` reads the stamp and returns when it matches. Any
        edit to ``_init_full`` (a new table, a new ``_ensure_column``)
        changes the stamp, so the next ``init`` against an older database
        replays the whole pass once - nothing to bump by hand, nothing to
        forget. No stamp, no table, no schema: the full pass runs.
        """
        stamp = _init_stamp()
        try:
            with self._tx() as cursor:
                cursor.execute(
                    self._q("SELECT value FROM schema_meta WHERE key=?"),
                    (_INIT_STAMP_KEY,))
                row = cursor.fetchone()
                if row is not None and str(row["value"]) == stamp:
                    return
        except Exception:  # noqa: BLE001 - no table yet, or no schema yet
            pass
        self._init_full()

    def _init_full(self) -> None:
        auto_id = self._db.auto_id()
        with self._tx() as cursor:

            # Create the engine schema on PostgreSQL (no-op on SQLite).
            # Name from IOF_DB_SCHEMA, default "iof" — validated as a bare
            # identifier by engine_schema() before it reaches this DDL.
            if self._db.placeholder() == "%s":
                cursor.execute(
                    f"CREATE SCHEMA IF NOT EXISTS {engine_schema()};")

            # Workspaces (team/group/dept — top-level grouping for workflows and runs)
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS workspaces (
                    id {auto_id},
                    code TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL DEFAULT '',
                    description TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );"""
            )

            # The GLOBAL agent catalog, synced from the installed packs via
            # `aicore sync` / POST /api/agents/sync. `pack` and the three
            # mirror columns below exist for one consumer: the Studio API,
            # which runs in a pod with no packs, no agent home and no state
            # directory, and must still list and render an agent it cannot
            # read from disk. `soul`/`tools_md` are the wheel's text VERBATIM
            # and are refreshed by every sync — a mirror, not tenant content
            # (that is `studio_agent_defs`, which is workspace-keyed, exported
            # to solution repos and is what hydration materialises from).
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS agents (
                    role TEXT PRIMARY KEY,
                    name TEXT NOT NULL DEFAULT '',
                    title TEXT NOT NULL DEFAULT '',
                    avatar TEXT NOT NULL DEFAULT '',
                    color TEXT NOT NULL DEFAULT '',
                    pack TEXT NOT NULL DEFAULT '',
                    soul TEXT NOT NULL DEFAULT '',
                    tools_md TEXT NOT NULL DEFAULT '',
                    skills_json TEXT NOT NULL DEFAULT '[]',
                    seeded_at TEXT NOT NULL
                );"""
            )

            # The GLOBAL skill catalog — the counterpart of agents.pack, and
            # the half that did not exist until 2026-08: skills had only the
            # per-workspace studio_skills, whose pack rows are assignment-only
            # by design, so a studio API pod with no packs listed no SDK skill
            # at all. Written by catalog_sync.sync_pack_skills; nothing
            # materialises from it (hydration resolves an assignment-only row
            # from the WHEEL) and it is never exported.
            #
            # Declared here AND in workspace_sync.ensure_platform_schema
            # because both sides ensure their own schema: the engine reaches
            # it through this function, the API through that one.
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS pack_skills (
                    name      TEXT PRIMARY KEY,
                    pack      TEXT NOT NULL DEFAULT '',
                    shared    INTEGER NOT NULL DEFAULT 0,
                    skill_md  TEXT NOT NULL DEFAULT '',
                    synced_at TEXT NOT NULL DEFAULT ''
                );"""
            )

            # Boot registration — WHAT CONTENT IS RUNNING HERE (One Truth
            # model, docs/one-truth-content-model.md §3.3/§5). One row per
            # installed content distribution per engine boot: pack, dist,
            # version, git sha, dirty flag, host, booted_at. Written by
            # `serve` at startup (engine/registration.register_content),
            # read by `aicore current` and, later, the Studio. The latest
            # rows per (workspace, host) are what is running there.
            #
            # Declared here AND in workspace_sync.ensure_platform_schema —
            # both call ONE DDL function, so the two ensurers cannot drift
            # (see pack_skills above for why both sides need it).
            from ioagentfarm.engine.registration import content_registration_ddl
            for ddl in content_registration_ddl(self._db.placeholder() == "%s"):
                cursor.execute(ddl)

            # Content drafts (One Truth §3.5): one author's unpromoted overlay
            # on one agent/skill/workflow, resolved ONLY inside that author's
            # own Try-it sessions and draft runs. Declared by ONE function,
            # ensured here (engine) and in workspace_sync.ensure_platform_schema
            # (the Studio API) — same anti-drift rule as the two tables above.
            from ioagentfarm.engine.drafts import content_drafts_ddl
            for ddl in content_drafts_ddl(self._db.placeholder() == "%s"):
                cursor.execute(ddl)

            # Workflow metadata (lazily created by orchestrator on first run)
            # Workflow run-metadata registry. `code` is unique PER WORKSPACE,
            # not globally (2026-08, workspace families): two tenants — or two
            # solution families — may each have a `signal_detection`, and a
            # global constraint made the second one silently share the first's
            # row. The Studio catalog (`studio_workflow_defs`) was already
            # keyed this way; this brings the run registry into agreement.
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS workflows (
                    id {auto_id},
                    workspace_code TEXT NOT NULL DEFAULT 'default',
                    code TEXT NOT NULL,
                    name TEXT NOT NULL DEFAULT '',
                    description TEXT NOT NULL DEFAULT '',
                    steps_json TEXT NOT NULL DEFAULT '[]',
                    roles_json TEXT NOT NULL DEFAULT '[]',
                    team_json TEXT NOT NULL DEFAULT '[]',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(workspace_code, code)
                );"""
            )

            cursor.execute(
                """CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY,
                    workspace_id INTEGER,
                    workflow_name TEXT NOT NULL,
                    workflow_id INTEGER,
                    kind TEXT NOT NULL DEFAULT 'workflow',
                    goal TEXT NOT NULL,
                    project_dir TEXT NOT NULL DEFAULT '',
                    parent_run_id TEXT,
                    user_id TEXT,
                    status TEXT NOT NULL,
                    driver_heartbeat_at TEXT,
                    supervisor_resumes INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );"""
            )

            # `status='running'` is what the supervisor, `next-step`'s
            # resolution and every "latest active run" lookup filter on, and
            # `list_runs` scopes by workspace - both were table scans over a
            # table that only ever grows.
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_runs_status_created ON runs(status, created_at);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_runs_workspace_created ON runs(workspace_id, created_at);")

            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS steps (
                    id {auto_id},
                    run_id TEXT NOT NULL,
                    seq INTEGER NOT NULL,
                    step_key TEXT NOT NULL,
                    role TEXT NOT NULL,
                    status TEXT NOT NULL,
                    attempt INTEGER NOT NULL DEFAULT 0,
                    max_attempts INTEGER NOT NULL DEFAULT 2,
                    deps_json TEXT NOT NULL DEFAULT '[]',
                    meta_json TEXT NOT NULL DEFAULT '{{}}',
                    output_text TEXT,
                    heartbeat_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(run_id, step_key)
                );"""
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_steps_run_status_seq ON steps(run_id, status, seq);")

            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS stories (
                    id {auto_id},
                    run_id TEXT NOT NULL,
                    story_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    details TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(run_id, story_id)
                );"""
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_stories_run_status ON stories(run_id, status);")

            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS tasks (
                    id {auto_id},
                    task_id TEXT NOT NULL UNIQUE,
                    run_id TEXT,
                    role TEXT NOT NULL,
                    title TEXT NOT NULL,
                    body TEXT NOT NULL,
                    user_id TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    output_text TEXT,
                    spawned_at TEXT,
                    completed_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );"""
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tasks_run_id_status ON tasks(run_id, status);")

            # Append-only message log for real-time agent output streaming
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS messages (
                    id {auto_id},
                    run_id TEXT,
                    step_key TEXT,
                    task_id TEXT,
                    workspace_id INT,
                    workflow_id INT,
                    session_id TEXT,
                    user_id TEXT,
                    source TEXT NOT NULL DEFAULT 'agent',
                    role TEXT NOT NULL DEFAULT '',
                    agent_name TEXT NOT NULL DEFAULT '',
                    content TEXT NOT NULL,
                    msg_type TEXT NOT NULL DEFAULT 'output',
                    metadata TEXT,
                    created_at TEXT NOT NULL
                );"""
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_run_step ON messages(run_id, step_key);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_run_id ON messages(run_id, id);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_workflow ON messages(workflow_id, id);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, run_id, id);")

            # End-user feedback on ONE CHAT REPLY (thumbs up/down/correction).
            # Distinct from `learning_feedback`, which is a steward's verdict
            # on a SKILL for a run step. `item_id` is a /v1/conversations
            # item (msg_...); `message_id` is a legacy `messages.id`. One of
            # the two is set. `agent` is denormalised so the summary survives
            # a deleted thread. See engine/feedback.py and web/feedback.py.
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS message_feedback (
                    id {auto_id},
                    workspace_id TEXT NOT NULL DEFAULT '',
                    conversation_id TEXT,
                    item_id TEXT,
                    message_id INTEGER,
                    user_id TEXT NOT NULL DEFAULT '',
                    agent TEXT NOT NULL DEFAULT '',
                    signal TEXT NOT NULL,
                    comment TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );"""
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_message_feedback_ws_created "
                           "ON message_feedback(workspace_id, created_at);")

            # Offline eval results: one row per (suite, case, run). Written by
            # `aicore eval run`, read by `aicore eval list|show`. `mode` is
            # 'live' or 'replay'; `output_sha` lets two modes be compared
            # without storing the output. See engine/eval/results.py.
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS eval_results (
                    id {auto_id},
                    suite TEXT NOT NULL,
                    case_id TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    passed INTEGER NOT NULL,
                    reason TEXT NOT NULL DEFAULT '',
                    duration_s REAL,
                    output_sha TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );"""
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_eval_results_suite "
                           "ON eval_results(suite, created_at);")

            # Per-user active run context (replaces global .iof/active_run file)
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS user_context (
                    user_id TEXT PRIMARY KEY,
                    active_run_id TEXT,
                    updated_at TEXT NOT NULL
                );"""
            )

            # ARIA business-rule tables (aria_rules, aria_clause_rules,
            # aria_checklists, negotiation_terms, vendor_fiscal_calendars)
            # are PROCUREMENT-DOMAIN content, not engine metadata - they are
            # no longer created here (2026-08-27). The ARIA feature ensures
            # its OWN schema on use (Store.ensure_aria_schema), the case/play
            # tier's pattern, so a domain table never lands in a generic
            # engine DB, and a DBA-handoff env (env_setup) that never turns
            # ARIA on has no orphan procurement tables in its engine schema.

            # --- Migrations for existing databases ---
            # workflows.code: globally UNIQUE -> unique per workspace.
            # Detection is via the catalog, NOT a failing SELECT — a failed
            # statement poisons a PostgreSQL transaction and this whole init
            # runs inside one.
            if "workspace_code" not in self._columns(cursor, "workflows"):
                if self._db.placeholder() == "%s":
                    for ddl in (
                        "ALTER TABLE workflows ADD COLUMN workspace_code "
                        "TEXT NOT NULL DEFAULT 'default'",
                        "ALTER TABLE workflows DROP CONSTRAINT IF EXISTS "
                        "workflows_code_key",
                        "ALTER TABLE workflows ADD CONSTRAINT "
                        "workflows_workspace_code_code_key "
                        "UNIQUE (workspace_code, code)",
                    ):
                        cursor.execute(ddl)
                else:
                    # sqlite: the inline UNIQUE is an auto-index that cannot
                    # be dropped — rebuild, preserving ids (runs.workflow_id
                    # points at them).
                    cursor.execute(
                        "ALTER TABLE workflows RENAME TO _workflows_legacy")
                    cursor.execute(
                        f"""CREATE TABLE workflows (
                            id {auto_id},
                            workspace_code TEXT NOT NULL DEFAULT 'default',
                            code TEXT NOT NULL,
                            name TEXT NOT NULL DEFAULT '',
                            description TEXT NOT NULL DEFAULT '',
                            steps_json TEXT NOT NULL DEFAULT '[]',
                            roles_json TEXT NOT NULL DEFAULT '[]',
                            team_json TEXT NOT NULL DEFAULT '[]',
                            created_at TEXT NOT NULL,
                            updated_at TEXT NOT NULL,
                            UNIQUE(workspace_code, code)
                        );""")
                    cursor.execute(
                        "INSERT INTO workflows (id, workspace_code, code,"
                        " name, description, steps_json, roles_json,"
                        " team_json, created_at, updated_at) "
                        "SELECT id, 'default', code, name, description,"
                        " steps_json, roles_json, team_json, created_at,"
                        " updated_at FROM _workflows_legacy")
                    cursor.execute("DROP TABLE _workflows_legacy")

            # Add workflow_id column to runs if missing
            try:
                cursor.execute("SELECT workflow_id FROM runs LIMIT 0")
            except Exception:
                try:
                    cursor.execute("ALTER TABLE runs ADD COLUMN workflow_id INTEGER")
                except Exception:
                    pass
            # Add workspace_id column to runs if missing
            try:
                cursor.execute("SELECT workspace_id FROM runs LIMIT 0")
            except Exception:
                try:
                    cursor.execute("ALTER TABLE runs ADD COLUMN workspace_id INTEGER")
                except Exception:
                    pass
            # Add metadata column to messages if missing — JSON-encoded
            # string holding {split: {summary, detail, footer}, ...}.
            # Both sqlite and postgres treat this as TEXT; consumers
            # parse via json.loads. Carries the chat-bubble progressive-
            # disclosure split so SSE/UI consumers don't have to compute
            # it from content client-side.
            #
            # SAVEPOINT-based migration (postgres-safe): a probe SELECT
            # against a missing column fails AND poisons the surrounding
            # transaction in postgres, so the subsequent ALTER also
            # fails ("current transaction is aborted"). Wrap the probe
            # in a savepoint so we can roll back to a clean state and
            # retry ALTER cleanly. SQLite tolerates this too — its
            # savepoints work the same way.
            try:
                cursor.execute("SAVEPOINT msg_metadata_probe")
                try:
                    cursor.execute("SELECT metadata FROM messages LIMIT 0")
                    cursor.execute("RELEASE SAVEPOINT msg_metadata_probe")
                except Exception:
                    # Column missing — roll back the failed probe and
                    # try ALTER in a fresh savepoint.
                    try:
                        cursor.execute("ROLLBACK TO SAVEPOINT msg_metadata_probe")
                        cursor.execute("RELEASE SAVEPOINT msg_metadata_probe")
                    except Exception:
                        pass
                    try:
                        cursor.execute(
                            "ALTER TABLE messages ADD COLUMN metadata TEXT"
                        )
                    except Exception:
                        pass
            except Exception:
                # Backend doesn't support savepoints (very old) — fall
                # back to plain ALTER and swallow if it errors (column
                # already there or unsupported syntax).
                try:
                    cursor.execute(
                        "ALTER TABLE messages ADD COLUMN metadata TEXT"
                    )
                except Exception:
                    pass

            # Run-supervisor columns (heartbeats + bounded driver resumes).
            # Same SAVEPOINT-based probe/ALTER pattern as messages.metadata
            # above — postgres-safe (a failed probe SELECT poisons the tx
            # without a savepoint rollback) and a no-op when the column is
            # already present (fresh DBs get it from CREATE TABLE).
            def _ensure_column(table: str, column: str, ddl: str) -> None:
                sp = f"col_probe_{table}_{column}"
                try:
                    cursor.execute(f"SAVEPOINT {sp}")
                    try:
                        cursor.execute(f"SELECT {column} FROM {table} LIMIT 0")
                        cursor.execute(f"RELEASE SAVEPOINT {sp}")
                    except Exception:
                        try:
                            cursor.execute(f"ROLLBACK TO SAVEPOINT {sp}")
                            cursor.execute(f"RELEASE SAVEPOINT {sp}")
                        except Exception:
                            pass
                        try:
                            cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
                        except Exception:
                            pass
                except Exception:
                    try:
                        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
                    except Exception:
                        pass

            # steps.heartbeat_at — touched ~every 30s by the run-step process
            # while its iobot subprocess is alive (DB-based so it works
            # across pods; PID checks don't).
            _ensure_column("steps", "heartbeat_at", "TEXT")
            # runs.kind — 'workflow' (a declared DAG) or 'swarm' (a compiled
            # goal run). workflow_name is the de-facto identity either way;
            # kind is what keeps a swarm out of workflow-only surfaces.
            _ensure_column("runs", "kind", "TEXT NOT NULL DEFAULT 'workflow'")
            # runs.driver_heartbeat_at — touched by the driver loop (blocking
            # `run` cycles) and by every Alex action point (next-step,
            # step-complete, step finalization).
            _ensure_column("runs", "driver_heartbeat_at", "TEXT")
            # WHO DRIVES THIS RUN. `aicore run --driver code` was honoured only
            # on the blocking path; `--json` spawned project_lead regardless,
            # and so did `resume` and the supervisor - a client who scripted
            # the documented way to detach paid for a model in the control
            # plane they had explicitly turned off, and nothing said so.
            _ensure_column("runs", "driver", "TEXT NOT NULL DEFAULT 'agent'")
            # runs.supervisor_resumes — bounded-convergence counter: how many
            # times the supervisor resurrected this run's driver. Beyond
            # IOF_SUPERVISOR_MAX_RESUMES the run is failed (supervisor_gave_up).
            _ensure_column("runs", "supervisor_resumes", "INTEGER NOT NULL DEFAULT 0")
            # messages.conversation_id — WHICH THREAD a chat row belongs to.
            # `conversation_id` split the thread from the person on the chat
            # surfaces; without this column the split was invisible to
            # history: user_id stopped identifying a thread, and a UI
            # resuming on another pod could not reassemble one conversation
            # from the interleaved rows. NULL = pre-threading rows (and
            # non-chat sources), where the thread WAS the user_id.
            _ensure_column("messages", "conversation_id", "TEXT")
            # agents.pack — which solution pack contributed this agent, written
            # by POST /api/agents/sync (which runs in the ENGINE, where the
            # packs are installed). It exists so consumers that may NOT have
            # the solution packs installed — notably the studio API in a split
            # or clustered deployment — can answer "which solution does this
            # agent belong to?" from the DB instead of importing the registry.
            _ensure_column("agents", "pack", "TEXT NOT NULL DEFAULT ''")
            # agents.soul / .tools_md / .skills_json — the same argument one
            # step further. `pack` let the studio API answer "which solution
            # is this agent from?" without the packs; these let it answer
            # "what does its persona say, and what skills does it carry?",
            # which is what the agent DETAIL screen renders. Without them a
            # correctly deployed API pod can list an agent and cannot open it.
            # Written by catalog_sync.sync_agents from the wheel; a tenant edit
            # lives in studio_agent_defs and wins on read.
            _ensure_column("agents", "soul", "TEXT NOT NULL DEFAULT ''")
            _ensure_column("agents", "tools_md", "TEXT NOT NULL DEFAULT ''")
            _ensure_column("agents", "skills_json", "TEXT NOT NULL DEFAULT '[]'")

            # LAST, in the same transaction: the stamp `init` reads. It is
            # written only after everything above succeeded, so a partial
            # pass (a DDL error, a lost connection) leaves no stamp and the
            # next init replays the whole thing.
            cursor.execute(
                "CREATE TABLE IF NOT EXISTS schema_meta ("
                "key TEXT PRIMARY KEY, value TEXT NOT NULL);")
            cursor.execute(self._q("DELETE FROM schema_meta WHERE key=?"),
                           (_INIT_STAMP_KEY,))
            cursor.execute(
                self._q("INSERT INTO schema_meta(key, value) VALUES(?, ?)"),
                (_INIT_STAMP_KEY, _init_stamp()))

    # -----------------------
    # Workspaces
    # -----------------------
    def workspace_exists(self, code: str) -> bool:
        """Whether a workspace row is present, without creating one.

        `ensure_workspace` is CREATE-OR-GET by design, and on the run path
        that turned a deleted tenant into a resurrected one: an engine still
        serving a workspace the operator had just deleted accepted a single
        `POST /api/run` and wrote the row back - with no members and no
        settings, so it accrued run history and could never be opened in the
        Studio again. The operator had been told the delete succeeded.

        A caller that must not create needs a way to ask.
        """
        try:
            with self._tx() as cursor:
                cursor.execute(self._q("SELECT id FROM workspaces WHERE code=?"),
                               (code,))
                return cursor.fetchone() is not None
        except Exception:  # noqa: BLE001 - a young database has no table yet
            return False

    def ensure_workspace(self, *, code: str, name: str = "",
                         description: str = "", rename: bool = False) -> int:
        """Ensure a workspace record exists and return its id.

        Called lazily by the orchestrator before ``create_run()``.

        EXISTING ROWS ARE LEFT ALONE unless *rename* is set. This used to
        UPDATE name and description unconditionally, and every lazy caller
        passes a name DERIVED from the code (``code.replace("_"," ").title()``)
        purely as an insert-time fallback — so starting a run renamed the
        operator's "Logistics Team" to "Logistics" and blanked its
        description, from a call whose only job was to make sure the row was
        there. Only a caller that means to rename (``workspace create``) says
        so.

        Parameters
        ----------
        code : str
            Unique workspace identifier (e.g. ``edi_team``, ``platform``).
        name : str
            Human-readable display name (e.g. "EDI Team").
            Defaults to *code* if empty. Applied on INSERT always; on an
            existing row only when *rename* is True.
        rename : bool
            Opt in to updating an existing row's name/description.
        """
        display_name = name or code
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(self._q("SELECT id FROM workspaces WHERE code=?"), (code,))
            row = cursor.fetchone()
            if row:
                ws_id = int(row["id"])
                if not rename:
                    return ws_id
                cursor.execute(
                    self._q("UPDATE workspaces SET name=?, description=?, updated_at=? WHERE id=?"),
                    (display_name, description, now, ws_id),
                )
                return ws_id
            else:
                sql = ("INSERT INTO workspaces(code, name, description, created_at, updated_at) "
                       "VALUES(?,?,?,?,?)")
                sql += self._db.returning_clause()
                cursor.execute(self._q(sql),
                               (code, display_name, description, now, now))
                ws_id = self._db.get_last_id(cursor)
                logger.info("Created workspace '%s' (id=%d)", code, ws_id)
                return ws_id

    def get_workspace(self, code: str) -> Optional[Dict[str, Any]]:
        """Get a workspace by code, or None."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id, code, name, description, created_at, updated_at "
                        "FROM workspaces WHERE code=?"),
                (code,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_workspace_by_id(self, workspace_id: int) -> Optional[Dict[str, Any]]:
        """Get a workspace by id, or None."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id, code, name, description, created_at, updated_at "
                        "FROM workspaces WHERE id=?"),
                (workspace_id,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    def list_workspaces(self) -> List[Dict[str, Any]]:
        """List all workspaces."""
        with self._tx() as cursor:
            cursor.execute(
                "SELECT id, code, name, description, created_at, updated_at "
                "FROM workspaces ORDER BY name ASC"
            )
            return [dict(r) for r in cursor.fetchall()]

    # -----------------------
    # Workflows
    # -----------------------
    def ensure_workflow(self, *, code: str, name: str = "",
                        description: str = "",
                        steps_json: str = "[]", roles_json: str = "[]",
                        team_json: str = "[]",
                        workspace_code: str) -> int:
        """Upsert a workflow record and return its id.

        Called lazily by the orchestrator before ``create_run()``.
        If the workflow already exists, updates name/description/steps/roles/team.

        Parameters
        ----------
        code : str
            Workflow identifier (folder name, e.g. ``feature_dev``) — unique
            PER WORKSPACE, not globally: two workspaces may each register a
            ``signal_detection`` without sharing (or clobbering) one row.
        name : str
            Human-readable display name (e.g. "Feature Development").
            Defaults to *code* if empty.
        team_json : str
            JSON array of team members, e.g. ``[{"role":"project_lead"},{"role":"analyst"}]``.
        workspace_code : str
            The owning workspace/tenant. ``default`` for unscoped callers.
        """
        display_name = name or code
        now = self._now()
        with self._tx() as cursor:
            # Check if workflow already exists IN THIS WORKSPACE
            cursor.execute(self._q(
                "SELECT id FROM workflows WHERE workspace_code=? AND code=?"),
                (workspace_code, code))
            row = cursor.fetchone()
            if row:
                wf_id = int(row["id"])
                cursor.execute(
                    self._q("UPDATE workflows SET name=?, description=?, steps_json=?, roles_json=?, team_json=?, updated_at=? WHERE id=?"),
                    (display_name, description, steps_json, roles_json, team_json, now, wf_id),
                )
                return wf_id
            else:
                sql = ("INSERT INTO workflows(workspace_code, code, name, description, steps_json, roles_json, team_json, created_at, updated_at) "
                       "VALUES(?,?,?,?,?,?,?,?,?)")
                sql += self._db.returning_clause()
                cursor.execute(self._q(sql),
                               (workspace_code, code, display_name, description, steps_json, roles_json, team_json, now, now))
                wf_id = self._db.get_last_id(cursor)
                logger.info("Created workflow '%s' (id=%d, workspace=%s)",
                            code, wf_id, workspace_code)
                return wf_id

    def get_workflow(self, code: str,
                     workspace_code: str) -> Optional[Dict[str, Any]]:
        """Get a workflow by (workspace, code), or None."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id, workspace_code, code, name, description, steps_json, roles_json, team_json, created_at, updated_at "
                        "FROM workflows WHERE workspace_code=? AND code=?"),
                (workspace_code, code),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    def list_workflows(self, workspace_code: Optional[str] = None
                       ) -> List[Dict[str, Any]]:
        """Known workflows — one workspace's, or all (None)."""
        with self._tx() as cursor:
            if workspace_code is None:
                cursor.execute(
                    "SELECT id, workspace_code, code, name, description, steps_json, roles_json, created_at, updated_at "
                    "FROM workflows ORDER BY workspace_code ASC, code ASC"
                )
            else:
                cursor.execute(self._q(
                    "SELECT id, workspace_code, code, name, description, steps_json, roles_json, created_at, updated_at "
                    "FROM workflows WHERE workspace_code=? ORDER BY code ASC"),
                    (workspace_code,))
            return [dict(r) for r in cursor.fetchall()]

    # -----------------------
    # Runs
    # -----------------------
    def create_run(self, *, workflow_name: str, goal: str, project_dir: str = "",
                   parent_run_id: str = "", user_id: str = "",
                   workflow_id: Optional[int] = None, workspace_id: Optional[int] = None,
                   kind: str = "workflow") -> str:
        run_id = f"run_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}"
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("INSERT INTO runs(id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, parent_run_id, user_id, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)"),
                (run_id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, parent_run_id or None, user_id or None, "running", now, now),
            )
        logger.info("Created run %s (workspace_id=%s, workflow=%s, workflow_id=%s, kind=%s, user=%s)", run_id, workspace_id, workflow_name, workflow_id, kind, user_id)
        return run_id

    def list_runs(self, *, limit: int = 10, user_id: Optional[str] = None,
                  workspace_code: Optional[str] = None) -> List[Dict[str, Any]]:
        """Runs, SCOPED TO A WORKSPACE when one is given.

        THE LEAK THIS CLOSES. This method had no workspace parameter, so
        `aicore status` returned a byte-identical list for two different
        tenants sharing one database - and every run in it belonged to the
        OTHER tenant. `forensics explain` then read that tenant's goal text,
        its steps, its token usage and its cost.

        It was invisible for nine validation rounds because every one ran on
        local-mode SQLite, where each workspace resolves its own state file
        and an unfiltered SELECT is scoped by accident of file layout. On one
        shared PostgreSQL - the deployment shape this product is built for -
        the accident stops holding.

        The product refuses to act without an explicit workspace selection
        and then ignored it here, which is exactly what makes an operator
        trust the answer.

        `workspace_code=None` keeps the old unscoped behaviour for the one
        caller that legitimately wants every tenant (a platform-wide sweep);
        it must be passed deliberately, never by omission.
        """
        where, params = [], []
        if user_id:
            where.append("user_id=?")
            params.append(user_id)
        if workspace_code:
            where.append("workspace_id = (SELECT id FROM workspaces WHERE code=?)")
            params.append(workspace_code)
        clause = (" WHERE " + " AND ".join(where)) if where else ""
        params.append(limit)
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, parent_run_id, user_id, status, created_at, updated_at FROM runs" + clause + " ORDER BY created_at DESC LIMIT ?"),
                tuple(params),
            )
            return [dict(r) for r in cursor.fetchall()]

    def get_run(self, run_id: str) -> Dict[str, Any]:
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, parent_run_id, user_id, status, driver_heartbeat_at, supervisor_resumes, created_at, updated_at, driver FROM runs WHERE id=?"),
                (run_id,),
            )
            row = cursor.fetchone()
            if not row:
                raise KeyError(run_id)
            return dict(row)

    def list_active_runs(self) -> List[Dict[str, Any]]:
        """All runs with status='running' — the supervisor's sweep scope."""
        with self._tx() as cursor:
            cursor.execute(
                "SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, parent_run_id, user_id, status, driver_heartbeat_at, supervisor_resumes, created_at, updated_at, driver "
                "FROM runs WHERE status='running' ORDER BY created_at ASC"
            )
            return [dict(r) for r in cursor.fetchall()]

    def get_latest_active_run(self, *, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        with self._tx() as cursor:
            if user_id:
                cursor.execute(
                    self._q("SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, parent_run_id, user_id, status, created_at, updated_at FROM runs WHERE status='running' AND user_id=? ORDER BY created_at DESC LIMIT 1"),
                    (user_id,),
                )
            else:
                cursor.execute(
                    "SELECT id, workspace_id, workflow_name, workflow_id, kind, goal, project_dir, parent_run_id, user_id, status, created_at, updated_at FROM runs WHERE status='running' ORDER BY created_at DESC LIMIT 1"
                )
            row = cursor.fetchone()
            return dict(row) if row else None

    def mark_run_done_if_complete(self, run_id: str) -> bool:
        """Flip a run to 'done' iff every step is done AND it is still
        'running'. Returns True ONLY for the caller whose UPDATE actually made
        the running->done transition (rowcount == 1); False otherwise.

        The ``AND status='running'`` guard makes the transition a
        single-winner CLAIM across every process that can observe a run
        completing — the finalizer, plus a supervisor sweep on each pod. A
        caller emits the closing run.completed boundary ONLY when it wins the
        claim. Without it the finalizer and a concurrent sweep each believed
        they had transitioned the run and both emitted the terminal event: 92
        of 292 runs carried a duplicate run.completed in a 3-pod soak. This
        mirrors the already-correct gave_up / deadlock claims in
        supervisor.py, which check ``rowcount`` before emitting.
        """
        with self._tx() as cursor:
            cursor.execute(self._q("SELECT COUNT(*) AS n FROM steps WHERE run_id=? AND status!='done'"), (run_id,))
            n = int(cursor.fetchone()["n"])
            if n != 0:
                return False
            now = self._now()
            cursor.execute(self._q("UPDATE runs SET status='done', updated_at=? WHERE id=? AND status='running'"), (now, run_id))
            won = cursor.rowcount == 1
            if won:
                logger.info("Run %s marked as done (all steps completed)", run_id)
            return won

    def mark_run_failed_if_stuck(self, run_id: str) -> bool:
        """Mark run as 'failed' when: any step is failed AND nothing can run.

        This catches the case where a step exhausts max_attempts — the run
        would otherwise stay 'running' forever with no actionable steps.

        A PENDING step whose dependency chain contains a failed step is NOT
        actionable: with DAG enforcement (2026-08-13) run-step refuses it, so
        it can never run. Before this refinement such steps kept the run
        'running' forever — observed live the moment the DAG guard landed:
        intake failed, its whole downstream stayed pending, and the sweep
        counted them as work-in-waiting. Blocking is computed transitively
        (a step whose dep is itself blocked is blocked).
        """
        with self._tx() as cursor:
            # Check current run status first — only act on running runs
            cursor.execute(self._q("SELECT status FROM runs WHERE id=?"), (run_id,))
            row = cursor.fetchone()
            if not row or row["status"] != "running":
                return False

            cursor.execute(
                self._q("SELECT step_key, status, deps_json FROM steps WHERE run_id=?"),
                (run_id,),
            )
            rows = cursor.fetchall()
            status = {r["step_key"]: r["status"] for r in rows}
            deps = {r["step_key"]: json.loads(r["deps_json"] or "[]") for r in rows}

            running = [k for k, s in status.items() if s == "running"]
            failed = [k for k, s in status.items() if s == "failed"]

            # Transitive blocking: pending steps downstream of a failure.
            blocked: set = set()
            changed = True
            while changed:
                changed = False
                for k, s in status.items():
                    if s != "pending" or k in blocked:
                        continue
                    if any(d in failed or d in blocked for d in deps.get(k, [])):
                        blocked.add(k)
                        changed = True
            actionable = len(running) + sum(
                1 for k, s in status.items()
                if s == "pending" and k not in blocked)
            if actionable > 0:
                return False  # still have work in progress or genuinely waiting

            if failed:
                now = self._now()
                cursor.execute(self._q("UPDATE runs SET status='failed', updated_at=? WHERE id=? AND status='running'"), (now, run_id))
                won = cursor.rowcount == 1
                if won:
                    logger.warning(
                        "Run %s marked as failed (%d step(s) failed, %d downstream "
                        "step(s) permanently blocked, no actionable steps remaining)",
                        run_id, len(failed), len(blocked))
                return won
            return False

    # -----------------------
    # Steps
    # -----------------------
    def materialize_steps(self, run_id: str, workflow: Workflow) -> None:
        now = self._now()
        sql = self._q(self._db.upsert_ignore(
            "INSERT INTO steps(run_id, seq, step_key, role, status, attempt, max_attempts, deps_json, meta_json, created_at, updated_at) "
            "VALUES(?,?,?,?, 'pending', 0, ?, ?, ?, ?, ?)"
        ))
        with self._tx() as cursor:
            for idx, s in enumerate(workflow.steps, start=1):
                cursor.execute(
                    sql,
                    (
                        run_id,
                        idx,
                        s.key,
                        s.role,
                        int(s.max_attempts),
                        json.dumps(s.deps or []),
                        json.dumps({"type": s.type, "fresh_session": s.fresh_session, "title": s.title}),
                        now,
                        now,
                    ),
                )

    def list_steps(self, run_id: str) -> List[Dict[str, Any]]:
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id, seq, step_key, role, status, attempt, max_attempts, deps_json, meta_json, heartbeat_at, created_at, updated_at, COALESCE(output_text,'') AS output_text "
                "FROM steps WHERE run_id=? ORDER BY seq ASC"),
                (run_id,),
            )
            return [dict(r) for r in cursor.fetchall()]

    def get_step_outputs_map(self, run_id: str) -> Dict[str, str]:
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT step_key, COALESCE(output_text,'') AS output_text FROM steps WHERE run_id=?"),
                (run_id,),
            )
            return {str(r["step_key"]): str(r["output_text"] or "") for r in cursor.fetchall()}

    def _deps_done(self, cursor: Any, run_id: str, deps: List[str]) -> bool:
        if not deps:
            return True
        ph = self._db.placeholder()
        q = "SELECT step_key, status FROM steps WHERE run_id={} AND step_key IN ({})".format(
            ph, ",".join([ph] * len(deps))
        )
        cursor.execute(q, [run_id, *deps])
        got = {r["step_key"]: r["status"] for r in cursor.fetchall()}
        return all(got.get(d) == "done" for d in deps)

    def claim_next_runnable_step(self, run_id: str, *, role_filter: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Atomically claim the next runnable step (status pending + deps done)."""
        now = self._now()
        with self._tx_pair() as (con, cursor):
            self._db.begin_immediate(con)
            committed = False
            try:
                if role_filter:
                    cursor.execute(
                        self._q("SELECT id, seq, step_key, role, deps_json, attempt, max_attempts, meta_json FROM steps "
                        "WHERE run_id=? AND status='pending' AND role=? ORDER BY seq ASC"),
                        (run_id, role_filter),
                    )
                else:
                    cursor.execute(
                        self._q("SELECT id, seq, step_key, role, deps_json, attempt, max_attempts, meta_json FROM steps "
                        "WHERE run_id=? AND status='pending' ORDER BY seq ASC"),
                        (run_id,),
                    )

                rows = cursor.fetchall()
                for r in rows:
                    deps = json.loads(r["deps_json"] or "[]")
                    if self._deps_done(cursor, run_id, deps):
                        # `AND status='pending'` + rowcount is the claim on
                        # PostgreSQL. BEGIN IMMEDIATE serialises SQLite
                        # writers, but a plain BEGIN there is READ COMMITTED:
                        # two claimers both read the row pending, the second
                        # UPDATE waits for the first to commit and then
                        # applies too, and both returned the same step.
                        cursor.execute(
                            self._q("UPDATE steps SET status='running', heartbeat_at=?, updated_at=? "
                                    "WHERE id=? AND status='pending'"),
                            (now, now, r["id"]))
                        if cursor.rowcount != 1:
                            continue  # taken between our read and this write
                        cursor.execute("COMMIT;")
                        committed = True
                        return dict(r)

                cursor.execute("COMMIT;")
                committed = True
                return None
            finally:
                if not committed:
                    try:
                        cursor.execute("ROLLBACK;")
                    except Exception:
                        pass
                self._db.end_immediate(con)

    def claim_pending_step(self, run_id: str, step_key: str) -> Optional[int]:
        """pending -> running, attempt+1, in ONE conditional statement.

        `run-step` read the row, decided it was pending, and later wrote
        status='running' unconditionally - two callers arriving together
        (the driver is an LLM and does emit the same run-step twice) both
        passed the read and both spawned. Returns the new attempt number,
        or None when another caller claimed the step first.
        """
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("UPDATE steps SET status='running', attempt=attempt+1, "
                        "heartbeat_at=?, updated_at=? "
                        "WHERE run_id=? AND step_key=? AND status='pending'"),
                (now, now, run_id, step_key))
            if cursor.rowcount != 1:
                return None
            cursor.execute(self._q("SELECT attempt FROM steps WHERE run_id=? AND step_key=?"),
                           (run_id, step_key))
            row = cursor.fetchone()
            return int(row["attempt"]) if row else None

    def claim_stale_running_step(self, run_id: str, step_key: str,
                                 observed_heartbeat: Optional[str]) -> bool:
        """Take over a `running` step whose executor is presumed dead.

        Compare-and-set on the heartbeat the caller judged stale: the beat
        is refreshed only if it still reads exactly that value, so two
        recoverers racing for one abandoned step cannot both win - the
        second sees a fresh beat and is refused as a duplicate.
        """
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("UPDATE steps SET heartbeat_at=?, updated_at=? "
                        "WHERE run_id=? AND step_key=? AND status='running' "
                        "AND COALESCE(heartbeat_at, '') = ?"),
                (now, now, run_id, step_key, observed_heartbeat or ""))
            return cursor.rowcount == 1

    def set_step_meta(self, run_id: str, step_key: str, updates: Dict[str, Any]) -> None:
        """Merge *updates* into the step's meta_json. Small facts about a step
        that are not its status - e.g. which gate sent it back."""
        with self._tx() as cursor:
            cursor.execute(self._q("SELECT meta_json FROM steps WHERE run_id=? AND step_key=?"),
                           (run_id, step_key))
            row = cursor.fetchone()
            if not row:
                return
            try:
                meta = json.loads(row["meta_json"] or "{}")
            except (TypeError, ValueError):
                meta = {}
            meta.update(updates)
            cursor.execute(self._q("UPDATE steps SET meta_json=?, updated_at=? WHERE run_id=? AND step_key=?"),
                           (json.dumps(meta), self._now(), run_id, step_key))

    def set_run_status(self, run_id: str, status: str) -> None:
        """One status write, for the paths that decide a run's fate outside
        the scheduler (a spawn that failed before its driver started)."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("UPDATE runs SET status=?, updated_at=? WHERE id=?"),
                (status, self._now(), run_id))

    def set_run_driver(self, run_id: str, driver: str) -> None:
        """Record who drives this run, so every path that later spawns a
        driver for it (--json, resume, the supervisor) spawns the right one."""
        with self._tx() as cursor:
            cursor.execute(self._q("UPDATE runs SET driver=?, updated_at=? WHERE id=?"),
                           (driver, self._now(), run_id))

    def bump_step_attempt(self, run_id: str, step_key: str) -> int:
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(self._q("SELECT attempt FROM steps WHERE run_id=? AND step_key=?"), (run_id, step_key))
            row = cursor.fetchone()
            if not row:
                raise KeyError(f"{run_id}/{step_key}")
            attempt = int(row["attempt"]) + 1
            cursor.execute(
                self._q("UPDATE steps SET attempt=?, updated_at=? WHERE run_id=? AND step_key=?"),
                (attempt, now, run_id, step_key),
            )
        return attempt

    def touch_step_heartbeat(self, run_id: str, step_key: str) -> None:
        """Record that the run-step process executing this step is alive.

        Called ~every 30s by the run-step path while its iobot subprocess
        lives (same cadence as the inflight forensic snapshot). Guarded to
        status='running' so a late beat from a finishing process never
        touches an already-finalized row. Best-effort — a heartbeat write
        failure must never break step execution.
        """
        try:
            with self._tx() as cursor:
                cursor.execute(
                    self._q("UPDATE steps SET heartbeat_at=? WHERE run_id=? AND step_key=? AND status='running'"),
                    (self._now(), run_id, step_key),
                )
        except Exception:
            logger.debug("touch_step_heartbeat failed (%s/%s)", run_id, step_key, exc_info=True)

    def clear_driver_heartbeat(self, run_id: str) -> None:
        """The driver has STOPPED - on purpose. `resume` and the supervisor
        read a fresh heartbeat as a live driver; a run that failed a second
        ago carried one, so `aicore resume` right after `step-retry` was
        refused for a driver that had already exited (novice finding,
        round 3). A cleared heartbeat is the honest state: nothing drives
        this run until something starts a driver again."""
        try:
            with self._tx() as cursor:
                cursor.execute(
                    self._q("UPDATE runs SET driver_heartbeat_at=NULL WHERE id=?"),
                    (run_id,))
        except Exception:  # noqa: BLE001 - never fail a run's exit over this
            logger.debug("clear_driver_heartbeat failed (%s)", run_id, exc_info=True)

    def touch_driver_heartbeat(self, run_id: str) -> None:
        """Record that a live driver (Alex / `run` loop) is attending this run.

        Touched from the blocking `run` drive-cycle loop and from every
        driver action point (next-step poll, step-complete, step
        finalization). The supervisor resurrects a driver only when this
        goes stale while runnable steps wait. Best-effort — never raises.
        """
        try:
            with self._tx() as cursor:
                cursor.execute(
                    self._q("UPDATE runs SET driver_heartbeat_at=? WHERE id=?"),
                    (self._now(), run_id),
                )
        except Exception:
            logger.debug("touch_driver_heartbeat failed (%s)", run_id, exc_info=True)

    def crash_recover_step(self, run_id: str, step_key: str) -> Dict[str, Any]:
        """Reset a stuck/crashed step to pending WITHOUT bumping attempts.

        The single implementation behind BOTH `step-retry --crash-recovery`
        (human/Alex-invoked) and the run supervisor's automatic reap — the
        transition semantics must stay identical, so neither caller
        duplicates this logic.

        Accepts steps in running/failed/done. A done step WITH output is
        left alone (it completed — e.g. the exec timeout fired but the step
        finished anyway). Otherwise: status -> 'pending', heartbeat cleared,
        attempt counter untouched (the hard attempt cap still bounds total
        spawns), and a run previously marked 'failed' is re-activated.
        """
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT status, COALESCE(output_text,'') AS output_text FROM steps WHERE run_id=? AND step_key=?"),
                (run_id, step_key),
            )
            row = cursor.fetchone()
            if not row:
                return {"error": f"Step '{step_key}' not found in run {run_id}"}
            status = str(row["status"])
            if status not in ("running", "failed", "done"):
                return {"error": f"Step '{step_key}' is '{status}'. Can only reset running, failed, or done steps."}
            if status == "done" and row["output_text"]:
                return {
                    "action": "crash_recovery_skipped",
                    "reason": "step already completed with output",
                    "status": "done",
                }
            now = self._now()
            cursor.execute(
                self._q("UPDATE steps SET status='pending', heartbeat_at=NULL, updated_at=? WHERE run_id=? AND step_key=?"),
                (now, run_id, step_key),
            )
            cursor.execute(
                self._q("UPDATE runs SET status='running', updated_at=? WHERE id=? AND status='failed'"),
                (now, run_id),
            )
            return {
                "action": "crash_recovery",
                "new_status": "pending",
                "previous_status": status,
            }

    def set_step_output(self, run_id: str, step_key: str, status: str, output_text: str) -> None:
        now = self._now()
        with self._tx() as cursor:
            # heartbeat_at is only meaningful while the step is running —
            # clear it on any terminal/pending transition so the supervisor
            # never reads a stale beat from a prior attempt.
            cursor.execute(
                self._q("UPDATE steps SET status=?, output_text=?, heartbeat_at=NULL, updated_at=? WHERE run_id=? AND step_key=?"),
                (status, output_text, now, run_id, step_key),
            )
            cursor.execute(self._q("UPDATE runs SET updated_at=? WHERE id=?"), (now, run_id))

    # -----------------------
    # Stories
    # -----------------------
    def add_stories(self, run_id: str, stories: List[Dict[str, Any]]) -> None:
        now = self._now()
        sql = self._q(self._db.upsert_ignore(
            "INSERT INTO stories(run_id, story_id, title, details, status, created_at, updated_at) "
            "VALUES(?,?,?,?, 'pending', ?, ?)"
        ))
        with self._tx() as cursor:
            for s in stories:
                sid = str(s.get("id") or s.get("story_id") or s.get("key") or "")
                title = str(s.get("title") or sid)
                details = json.dumps(s, ensure_ascii=False)
                cursor.execute(sql, (run_id, sid, title, details, now, now))

    def ensure_story_steps(
        self,
        run_id: str,
        *,
        after_step_key: str,
        per_item_steps: List[StepTemplate],
        next_yaml_step_keys: Optional[List[str]] = None,
    ) -> None:
        """Create per-story step rows after loop step. Deterministic sequence: loop step seq + story order + template order.

        If next_yaml_step_keys is provided, those YAML backbone steps are rewired
        to depend on all story steps (so they wait for story work to finish).
        """
        now = self._now()
        insert_sql = self._q(self._db.upsert_ignore(
            "INSERT INTO steps(run_id, seq, step_key, role, status, attempt, max_attempts, deps_json, meta_json, created_at, updated_at) "
            "VALUES(?,?,?,?, 'pending', 0, ?, ?, ?, ?, ?)"
        ))
        with self._tx() as cursor:
            # loop step seq
            cursor.execute(self._q("SELECT seq FROM steps WHERE run_id=? AND step_key=?"), (run_id, after_step_key))
            row = cursor.fetchone()
            if not row:
                return
            base_seq = int(row["seq"])

            # existing max seq
            cursor.execute(self._q("SELECT MAX(seq) AS m FROM steps WHERE run_id=?"), (run_id,))
            max_seq = int(cursor.fetchone()["m"] or base_seq)

            # story order
            cursor.execute(self._q("SELECT story_id FROM stories WHERE run_id=? ORDER BY id ASC"), (run_id,))
            story_ids = [r["story_id"] for r in cursor.fetchall()]

            all_story_keys: List[str] = []
            seq = max_seq + 1
            for sid in story_ids:
                for tmpl in per_item_steps:
                    step_key = f"story:{sid}:{tmpl.key_suffix}"
                    all_story_keys.append(step_key)
                    deps = [after_step_key]
                    for d in tmpl.deps or []:
                        if d in [t.key_suffix for t in per_item_steps]:
                            deps.append(f"story:{sid}:{d}")
                        else:
                            deps.append(d)
                    cursor.execute(
                        insert_sql,
                        (
                            run_id,
                            seq,
                            step_key,
                            tmpl.role,
                            int(tmpl.max_attempts),
                            json.dumps(deps),
                            json.dumps({"type": "story", "story_id": sid}),
                            now,
                            now,
                        ),
                    )
                    seq += 1

            # Rewire downstream YAML steps to depend on all story steps
            if all_story_keys and next_yaml_step_keys:
                for nk in next_yaml_step_keys:
                    cursor.execute(
                        self._q("SELECT deps_json FROM steps WHERE run_id=? AND step_key=?"),
                        (run_id, nk),
                    )
                    row = cursor.fetchone()
                    if not row:
                        continue
                    existing_deps = json.loads(row["deps_json"] or "[]")
                    merged = list(dict.fromkeys(existing_deps + all_story_keys))
                    cursor.execute(
                        self._q("UPDATE steps SET deps_json=?, updated_at=? WHERE run_id=? AND step_key=?"),
                        (json.dumps(merged), now, run_id, nk),
                    )

    def insert_dynamic_tasks(
        self,
        run_id: str,
        *,
        after_step_key: str,
        tasks: List[Dict[str, Any]],
        next_yaml_step_keys: List[str],
    ) -> int:
        """Insert dynamic tasks emitted by project_lead via TASKS_JSON.

        - Tasks are inserted after `after_step_key` in sequence order.
        - Each task must have: key, role, title. Optional: deps, max_attempts.
        - If a task's deps list is empty, it defaults to [after_step_key].
        - `next_yaml_step_keys` are the YAML-defined steps that come after
          `after_step_key`. Their deps are rewired to depend on ALL dynamic
          tasks (so the backbone waits for dynamic work to finish).

        Returns the number of tasks inserted.
        """
        now = self._now()
        inserted = 0
        insert_sql = self._q(self._db.upsert_ignore(
            "INSERT INTO steps(run_id, seq, step_key, role, status, "
            "attempt, max_attempts, deps_json, meta_json, created_at, updated_at) "
            "VALUES(?,?,?,?, 'pending', 0, ?, ?, ?, ?, ?)"
        ))
        with self._tx() as cursor:
            # Get current max seq
            cursor.execute(self._q("SELECT MAX(seq) AS m FROM steps WHERE run_id=?"), (run_id,))
            max_seq = int(cursor.fetchone()["m"] or 0)

            dynamic_keys = []
            seq = max_seq + 1
            for t in tasks:
                key = str(t.get("key") or "")
                if not key:
                    continue
                role = str(t.get("role") or "developer")
                title = str(t.get("title") or key)
                max_attempts = int(t.get("max_attempts", 2))
                deps = t.get("deps") or [after_step_key]
                prompt_text = str(t.get("prompt") or title)

                cursor.execute(
                    insert_sql,
                    (
                        run_id,
                        seq,
                        key,
                        role,
                        max_attempts,
                        json.dumps(deps),
                        json.dumps({"type": "dynamic", "title": title, "prompt": prompt_text}),
                        now,
                        now,
                    ),
                )
                dynamic_keys.append(key)
                seq += 1
                inserted += 1

            # Rewire downstream YAML steps to depend on all dynamic tasks
            if dynamic_keys and next_yaml_step_keys:
                for nk in next_yaml_step_keys:
                    cursor.execute(
                        self._q("SELECT deps_json FROM steps WHERE run_id=? AND step_key=?"),
                        (run_id, nk),
                    )
                    row = cursor.fetchone()
                    if not row:
                        continue
                    existing_deps = json.loads(row["deps_json"] or "[]")
                    merged = list(dict.fromkeys(existing_deps + dynamic_keys))
                    cursor.execute(
                        self._q("UPDATE steps SET deps_json=?, updated_at=? WHERE run_id=? AND step_key=?"),
                        (json.dumps(merged), now, run_id, nk),
                    )

        return inserted

    def story_counts(self, run_id: str) -> Dict[str, int]:
        with self._tx() as cursor:
            cursor.execute(self._q("SELECT COUNT(*) AS n FROM stories WHERE run_id=?"), (run_id,))
            total = int(cursor.fetchone()["n"])
            cursor.execute(self._q("SELECT COUNT(*) AS n FROM stories WHERE run_id=? AND status='done'"), (run_id,))
            done = int(cursor.fetchone()["n"])
        return {"total": total, "done": done}

    def list_stories(self, run_id: str) -> List[Dict[str, Any]]:
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT story_id, title, status, details, created_at, updated_at "
                "FROM stories WHERE run_id=? ORDER BY id ASC"),
                (run_id,),
            )
            return [dict(r) for r in cursor.fetchall()]

    def role_summary(self, run_id: str) -> List[Dict[str, Any]]:
        """Per-role step summary: how many done/pending/failed/running."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT role, status, COUNT(*) AS cnt FROM steps "
                "WHERE run_id=? GROUP BY role, status ORDER BY role, status"),
                (run_id,),
            )
            rows = cursor.fetchall()

        by_role: Dict[str, Dict[str, int]] = {}
        for r in rows:
            role = r["role"]
            if role not in by_role:
                by_role[role] = {"pending": 0, "running": 0, "done": 0, "failed": 0}
            by_role[role][r["status"]] = r["cnt"]

        result = []
        for role, counts in sorted(by_role.items()):
            result.append({"role": role, **counts, "total": sum(counts.values())})
        return result

    # -----------------------
    # Tasks (ad-hoc spawn tracking)
    # -----------------------
    def create_task(
        self,
        *,
        role: str,
        title: str,
        body: str,
        run_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> str:
        """Create a tracked ad-hoc task. Returns a unique task_id."""
        task_id = f"task_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}"
        now = self._now()
        sql = self._q(
            "INSERT INTO tasks(task_id, run_id, role, title, body, user_id, status, created_at, updated_at) "
            "VALUES(?,?,?,?,?,?,'pending',?,?)"
        )
        with self._tx() as cursor:
            cursor.execute(sql, (task_id, run_id, role, title, body, user_id, now, now))
        return task_id

    def mark_task_spawned(self, task_id: str) -> None:
        """Mark task as spawned (sub-agent is running)."""
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("UPDATE tasks SET status='running', spawned_at=?, updated_at=? WHERE task_id=?"),
                (now, now, task_id),
            )

    def complete_task(self, task_id: str, *, status: str, output_text: str) -> None:
        """Mark task as done/failed and store output."""
        now = self._now()
        status = status if status in ("done", "failed") else "done"
        with self._tx() as cursor:
            cursor.execute(
                self._q("UPDATE tasks SET status=?, output_text=?, completed_at=?, updated_at=? WHERE task_id=?"),
                (status, output_text, now, now, task_id),
            )

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get a single task by task_id."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id, task_id, run_id, role, title, body, user_id, status, "
                "output_text, spawned_at, completed_at, created_at, updated_at "
                "FROM tasks WHERE task_id=?"),
                (task_id,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    def list_tasks(self, *, status: Optional[str] = None, run_id: Optional[str] = None, user_id: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """List tasks, optionally filtered by status, run_id, and/or user_id."""
        q = ("SELECT id, task_id, run_id, role, title, body, user_id, status, "
             "output_text, spawned_at, completed_at, created_at, updated_at FROM tasks")
        where: List[str] = []
        params: List[Any] = []
        if status:
            where.append("status=?")
            params.append(status)
        if run_id:
            where.append("run_id=?")
            params.append(run_id)
        if user_id:
            where.append("user_id=?")
            params.append(user_id)
        if where:
            q += " WHERE " + " AND ".join(where)
        q += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        with self._tx() as cursor:
            cursor.execute(self._q(q), tuple(params))
            return [dict(r) for r in cursor.fetchall()]

    def get_completed_tasks_for_notify(self, *, user_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get tasks that are done/failed but not yet notified to the user.

        Uses notified_at IS NULL to find unnotified tasks — status stays
        done/failed so task-list and other queries still find them.
        """
        with self._tx() as cursor:
            if user_id:
                cursor.execute(
                    self._q("SELECT id, task_id, run_id, role, title, body, user_id, status, "
                    "output_text, spawned_at, completed_at, created_at, updated_at "
                    "FROM tasks WHERE status IN ('done', 'failed') AND notified_at IS NULL AND user_id=? "
                    "ORDER BY completed_at ASC"),
                    (user_id,),
                )
            else:
                cursor.execute(
                    self._q("SELECT id, task_id, run_id, role, title, body, user_id, status, "
                    "output_text, spawned_at, completed_at, created_at, updated_at "
                    "FROM tasks WHERE status IN ('done', 'failed') AND notified_at IS NULL "
                    "ORDER BY completed_at ASC"),
                )
            return [dict(r) for r in cursor.fetchall()]

    def mark_task_notified(self, task_id: str) -> bool:
        """Atomically mark task as notified. Returns True if this call claimed it.

        Sets notified_at timestamp (does NOT change status). Uses
        WHERE notified_at IS NULL so only one pod wins in multi-pod deployments.
        """
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("UPDATE tasks SET notified_at=?, updated_at=? "
                        "WHERE task_id=? AND status IN ('done', 'failed') AND notified_at IS NULL"),
                (now, now, task_id),
            )
            return cursor.rowcount > 0

    # -----------------------
    # User context (per-user active run)
    # -----------------------
    def set_user_active_run(self, user_id: str, run_id: str) -> None:
        """Set the active run for a user (UPSERT)."""
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q(self._db.upsert_ignore(
                    "INSERT INTO user_context(user_id, active_run_id, updated_at) VALUES(?,?,?)"
                )),
                (user_id, run_id, now),
            )
            # upsert_ignore may silently skip on conflict; always UPDATE to be safe
            cursor.execute(
                self._q("UPDATE user_context SET active_run_id=?, updated_at=? WHERE user_id=?"),
                (run_id, now, user_id),
            )

    def get_user_active_run(self, user_id: str) -> Optional[str]:
        """Get the active run_id for a user, or None."""
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT active_run_id FROM user_context WHERE user_id=?"),
                (user_id,),
            )
            row = cursor.fetchone()
            return row["active_run_id"] if row else None

    # -----------------------
    # Messages (unified conversation thread)
    # -----------------------
    def insert_message(
        self,
        *,
        run_id: str = "",
        step_key: str = "",
        task_id: str = "",
        workspace_id: int | None = None,
        workflow_id: int | None = None,
        session_id: str = "",
        user_id: str = "",
        conversation_id: str = "",
        source: str = "agent",
        role: str = "",
        agent_name: str = "",
        content: str,
        msg_type: str = "output",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Insert a message into the unified conversation thread.

        Sources: user, agent, step_output, step_start, task_spawned,
        task_output, system.

        ``metadata`` (optional) is a small dict serialised to JSON. Used
        to carry the chat-bubble progressive-disclosure split:
        ``{split: {summary, detail, footer}}``. Other consumers (SSE
        stream, /messages endpoint) get it for free without re-computing.

        Returns the message id (0 if not retrievable).
        """
        now = self._now()
        metadata_json = json.dumps(metadata) if metadata else None
        with self._tx() as cursor:
            cursor.execute(
                self._q(
                    "INSERT INTO messages(run_id, step_key, task_id, workspace_id, workflow_id, "
                    "session_id, user_id, conversation_id, source, role, agent_name, content, "
                    "msg_type, metadata, created_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (run_id or None, step_key or None, task_id or None,
                 workspace_id, workflow_id, session_id or None,
                 user_id or None, conversation_id or None,
                 source, role, agent_name, content, msg_type,
                 metadata_json, now),
            )
            try:
                return self._db.get_last_id(cursor)
            except Exception:
                return 0

    def get_messages_since(
        self,
        run_id: str,
        *,
        after_id: int = 0,
        step_key: Optional[str] = None,
        conversation_id: Optional[str] = None,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        """Fetch messages for a run after a given message id (for polling/SSE).

        Returns messages ordered by id ASC. The caller tracks the last seen id
        and passes it as *after_id* on the next call. *conversation_id*
        narrows to one chat thread (rows stamped by the chat handlers).
        """
        q = ("SELECT id, run_id, step_key, task_id, user_id, conversation_id, "
             "source, role, agent_name, "
             "content, msg_type, metadata, created_at "
             "FROM messages WHERE run_id=? AND id>?")
        params: List[Any] = [run_id, after_id]
        if step_key:
            q += " AND step_key=?"
            params.append(step_key)
        if conversation_id:
            q += " AND conversation_id=?"
            params.append(conversation_id)
        q += " ORDER BY id ASC LIMIT ?"
        params.append(limit)
        with self._tx() as cursor:
            cursor.execute(self._q(q), tuple(params))
            rows = [dict(r) for r in cursor.fetchall()]
        # Parse metadata JSON -> dict so consumers get structured data.
        # null/missing metadata returns None on the row.
        for r in rows:
            raw = r.get("metadata")
            if raw and isinstance(raw, str):
                try:
                    r["metadata"] = json.loads(raw)
                except (json.JSONDecodeError, ValueError):
                    r["metadata"] = None
        return rows

    def get_chat_messages(
        self,
        workflow_id: int,
        user_id: str,
        *,
        after_id: int = 0,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        """Fetch ad-hoc chat messages (no run) for a workflow."""
        q = ("SELECT id, workflow_id, user_id, source, role, agent_name, "
             "content, msg_type, created_at "
             "FROM messages WHERE workflow_id=? AND run_id IS NULL AND user_id=? AND id>? "
             "ORDER BY id ASC LIMIT ?")
        with self._tx() as cursor:
            cursor.execute(self._q(q), (workflow_id, user_id, after_id, limit))
            return [dict(r) for r in cursor.fetchall()]

    # -----------------------
    # ARIA business rules
    # -----------------------

    def ensure_aria_schema(self) -> None:
        """Create the ARIA business-rule tables on first use.

        ARIA (procurement clause/negotiation rules) is a DOMAIN feature,
        not engine metadata, so its tables are NOT created by ``init()``.
        Every ARIA entry point - the ``/api/aria`` router and each read/
        write method below - calls this first; it runs its DDL once per
        Store instance. Idempotent. The case/play tier keeps its own
        tables out of core the same way.
        """
        if getattr(self, "_aria_ensured", False):
            return
        auto_id = self._db.auto_id()
        with self._tx() as cursor:
            # ARIA: scalar business rules (thresholds, multipliers, day counts)
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS aria_rules (
                    id          {auto_id},
                    domain      TEXT NOT NULL,
                    rule_key    TEXT NOT NULL,
                    rule_name   TEXT NOT NULL,
                    value_type  TEXT NOT NULL,
                    value       TEXT NOT NULL,
                    applies_to  TEXT,
                    description TEXT,
                    is_active   INTEGER NOT NULL DEFAULT 1,
                    created_at  TEXT NOT NULL,
                    updated_at  TEXT NOT NULL,
                    UNIQUE(domain, rule_key)
                );"""
            )

            # ARIA: CRA clause checklist (clause presence → penalty points)
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS aria_clause_rules (
                    id             {auto_id},
                    rule_set       TEXT NOT NULL,
                    clause_field   TEXT NOT NULL,
                    clause_label   TEXT NOT NULL,
                    penalty_points INTEGER NOT NULL,
                    applies_to     TEXT,
                    severity       TEXT,
                    description    TEXT,
                    is_active      INTEGER NOT NULL DEFAULT 1,
                    sort_order     INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(rule_set, clause_field)
                );"""
            )

            # ARIA: ordered intake/exit checklists per domain
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS aria_checklists (
                    id           {auto_id},
                    domain       TEXT NOT NULL,
                    checklist_id TEXT NOT NULL,
                    step_order   INTEGER NOT NULL,
                    step_key     TEXT NOT NULL,
                    step_label   TEXT NOT NULL,
                    step_detail  TEXT,
                    required     INTEGER NOT NULL DEFAULT 1,
                    applies_to   TEXT,
                    is_active    INTEGER NOT NULL DEFAULT 1,
                    UNIQUE(checklist_id, step_key)
                );"""
            )

            # Negotiation terms playbook (from negotiation-rules.xlsx)
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS negotiation_terms (
                    id                       {auto_id},
                    term_name                TEXT NOT NULL,
                    term_slug                TEXT NOT NULL UNIQUE,
                    category                 TEXT NOT NULL,
                    difficulty               TEXT NOT NULL,
                    bd_relevant              TEXT,
                    explanation              TEXT,
                    risk_description         TEXT,
                    moderate_leverage_action TEXT,
                    high_leverage_action     TEXT,
                    applies_to               TEXT,
                    is_active                INTEGER NOT NULL DEFAULT 1,
                    sort_order               INTEGER NOT NULL DEFAULT 0
                );"""
            )

            # Vendor fiscal year / negotiation timing (cross-agent shared config)
            cursor.execute(
                f"""CREATE TABLE IF NOT EXISTS vendor_fiscal_calendars (
                    id                  {auto_id},
                    vendor_name         TEXT NOT NULL,
                    vendor_slug         TEXT NOT NULL UNIQUE,
                    vendor_category     TEXT NOT NULL,
                    fy_end_month        INTEGER NOT NULL,
                    fy_end_label        TEXT NOT NULL,
                    best_window_label   TEXT NOT NULL,
                    discount_uplift_pct TEXT,
                    notes               TEXT,
                    is_active           INTEGER NOT NULL DEFAULT 1
                );"""
            )
        self._aria_ensured = True

    def load_aria_rules(self) -> Dict[str, Any]:
        """Load all active ARIA rules from all 4 tables.

        Returns
        -------
        dict with keys:
          'rules'     → {domain: {rule_key: {value, value_type, applies_to, ...}}}
          'clauses'   → {rule_set: [{clause_field, clause_label, penalty_points, ...}]}
          'checklists'→ {checklist_id: [{step_order, step_key, step_label, required, ...}]}
          'calendars' → [{vendor_name, fy_end_month, fy_end_label, best_window_label, ...}]
          'negotiation_terms' → [{term_name, term_slug, category, difficulty, bd_relevant,
                                   moderate_leverage_action, high_leverage_action}]
        Only is_active=1 rows returned.
        """
        self.ensure_aria_schema()
        result: Dict[str, Any] = {
            "rules": {},
            "clauses": {},
            "checklists": {},
            "calendars": [],
            "negotiation_terms": [],
        }
        with self._tx() as cursor:
            # Scalar rules
            cursor.execute(
                "SELECT domain, rule_key, rule_name, value_type, value, applies_to, description "
                "FROM aria_rules WHERE is_active=1 ORDER BY domain, rule_key"
            )
            for row in cursor.fetchall():
                d = dict(row)
                domain = d.pop("domain")
                key = d.pop("rule_key")
                result["rules"].setdefault(domain, {})[key] = d

            # Clause rules
            cursor.execute(
                "SELECT rule_set, clause_field, clause_label, penalty_points, applies_to, severity, sort_order "
                "FROM aria_clause_rules WHERE is_active=1 ORDER BY rule_set, sort_order, clause_field"
            )
            for row in cursor.fetchall():
                d = dict(row)
                rs = d.pop("rule_set")
                result["clauses"].setdefault(rs, []).append(d)

            # Checklists
            cursor.execute(
                "SELECT checklist_id, step_order, step_key, step_label, step_detail, required, applies_to "
                "FROM aria_checklists WHERE is_active=1 ORDER BY checklist_id, step_order"
            )
            for row in cursor.fetchall():
                d = dict(row)
                cid = d.pop("checklist_id")
                result["checklists"].setdefault(cid, []).append(d)

            # Vendor fiscal calendars
            cursor.execute(
                "SELECT vendor_name, vendor_slug, vendor_category, fy_end_month, "
                "fy_end_label, best_window_label, discount_uplift_pct, notes "
                "FROM vendor_fiscal_calendars WHERE is_active=1 ORDER BY vendor_category, fy_end_month"
            )
            result["calendars"] = [dict(r) for r in cursor.fetchall()]

            # Negotiation terms (bd_relevant only for prompt injection size)
            cursor.execute(
                "SELECT term_name, term_slug, category, difficulty, bd_relevant, "
                "moderate_leverage_action, high_leverage_action, applies_to "
                "FROM negotiation_terms WHERE is_active=1 AND bd_relevant IN ('must','yes') "
                "ORDER BY sort_order, category, term_name"
            )
            result["negotiation_terms"] = [dict(r) for r in cursor.fetchall()]

        return result

    def upsert_aria_rule(
        self, domain: str, rule_key: str, rule_name: str,
        value_type: str, value: str,
        applies_to: Optional[str] = None,
        description: Optional[str] = None,
    ) -> int:
        self.ensure_aria_schema()
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(self._q("SELECT id FROM aria_rules WHERE domain=? AND rule_key=?"), (domain, rule_key))
            row = cursor.fetchone()
            if row:
                rid = int(row["id"])
                cursor.execute(
                    self._q("UPDATE aria_rules SET rule_name=?, value_type=?, value=?, "
                            "applies_to=?, description=?, updated_at=? WHERE id=?"),
                    (rule_name, value_type, value, applies_to, description, now, rid),
                )
                return rid
            sql = ("INSERT INTO aria_rules(domain,rule_key,rule_name,value_type,value,"
                   "applies_to,description,is_active,created_at,updated_at) "
                   "VALUES(?,?,?,?,?,?,?,1,?,?)")
            sql += self._db.returning_clause()
            cursor.execute(self._q(sql), (domain, rule_key, rule_name, value_type, value,
                                          applies_to, description, now, now))
            return int(self._db.get_last_id(cursor))

    def upsert_aria_clause(
        self, rule_set: str, clause_field: str, clause_label: str,
        penalty_points: int,
        applies_to: Optional[str] = None,
        severity: Optional[str] = None,
        description: Optional[str] = None,
        sort_order: int = 0,
    ) -> int:
        self.ensure_aria_schema()
        now = self._now()
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id FROM aria_clause_rules WHERE rule_set=? AND clause_field=?"),
                (rule_set, clause_field),
            )
            row = cursor.fetchone()
            if row:
                rid = int(row["id"])
                cursor.execute(
                    self._q("UPDATE aria_clause_rules SET clause_label=?, penalty_points=?, "
                            "applies_to=?, severity=?, description=?, sort_order=? WHERE id=?"),
                    (clause_label, penalty_points, applies_to, severity, description, sort_order, rid),
                )
                return rid
            sql = ("INSERT INTO aria_clause_rules(rule_set,clause_field,clause_label,penalty_points,"
                   "applies_to,severity,description,is_active,sort_order) "
                   "VALUES(?,?,?,?,?,?,?,1,?)")
            sql += self._db.returning_clause()
            cursor.execute(self._q(sql), (rule_set, clause_field, clause_label, penalty_points,
                                          applies_to, severity, description, sort_order))
            return int(self._db.get_last_id(cursor))

    def upsert_aria_checklist_step(
        self, domain: str, checklist_id: str, step_order: int,
        step_key: str, step_label: str,
        step_detail: Optional[str] = None,
        required: int = 1,
        applies_to: Optional[str] = None,
    ) -> int:
        self.ensure_aria_schema()
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id FROM aria_checklists WHERE checklist_id=? AND step_key=?"),
                (checklist_id, step_key),
            )
            row = cursor.fetchone()
            if row:
                rid = int(row["id"])
                cursor.execute(
                    self._q("UPDATE aria_checklists SET domain=?, step_order=?, step_label=?, "
                            "step_detail=?, required=?, applies_to=? WHERE id=?"),
                    (domain, step_order, step_label, step_detail, required, applies_to, rid),
                )
                return rid
            sql = ("INSERT INTO aria_checklists(domain,checklist_id,step_order,step_key,"
                   "step_label,step_detail,required,applies_to,is_active) "
                   "VALUES(?,?,?,?,?,?,?,?,1)")
            sql += self._db.returning_clause()
            cursor.execute(self._q(sql), (domain, checklist_id, step_order, step_key,
                                          step_label, step_detail, required, applies_to))
            return int(self._db.get_last_id(cursor))

    def upsert_negotiation_term(
        self, term_slug: str, term_name: str, category: str, difficulty: str,
        bd_relevant: Optional[str] = None,
        explanation: Optional[str] = None,
        risk_description: Optional[str] = None,
        moderate_leverage_action: Optional[str] = None,
        high_leverage_action: Optional[str] = None,
        applies_to: Optional[str] = None,
        sort_order: int = 0,
    ) -> int:
        with self._tx() as cursor:
            cursor.execute(self._q("SELECT id FROM negotiation_terms WHERE term_slug=?"), (term_slug,))
            row = cursor.fetchone()
            if row:
                rid = int(row["id"])
                cursor.execute(
                    self._q("UPDATE negotiation_terms SET term_name=?, category=?, difficulty=?, "
                            "bd_relevant=?, explanation=?, risk_description=?, "
                            "moderate_leverage_action=?, high_leverage_action=?, "
                            "applies_to=?, sort_order=? WHERE id=?"),
                    (term_name, category, difficulty, bd_relevant, explanation, risk_description,
                     moderate_leverage_action, high_leverage_action, applies_to, sort_order, rid),
                )
                return rid
            sql = ("INSERT INTO negotiation_terms(term_slug,term_name,category,difficulty,bd_relevant,"
                   "explanation,risk_description,moderate_leverage_action,high_leverage_action,"
                   "applies_to,is_active,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,1,?)")
            sql += self._db.returning_clause()
            cursor.execute(self._q(sql), (term_slug, term_name, category, difficulty, bd_relevant,
                                          explanation, risk_description, moderate_leverage_action,
                                          high_leverage_action, applies_to, sort_order))
            return int(self._db.get_last_id(cursor))

    def upsert_vendor_fiscal_calendar(
        self, vendor_name: str, vendor_slug: str, vendor_category: str,
        fy_end_month: int, fy_end_label: str, best_window_label: str,
        discount_uplift_pct: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> int:
        with self._tx() as cursor:
            cursor.execute(
                self._q("SELECT id FROM vendor_fiscal_calendars WHERE vendor_slug=?"), (vendor_slug,)
            )
            row = cursor.fetchone()
            if row:
                rid = int(row["id"])
                cursor.execute(
                    self._q("UPDATE vendor_fiscal_calendars SET vendor_name=?, vendor_category=?, "
                            "fy_end_month=?, fy_end_label=?, best_window_label=?, "
                            "discount_uplift_pct=?, notes=? WHERE id=?"),
                    (vendor_name, vendor_category, fy_end_month, fy_end_label,
                     best_window_label, discount_uplift_pct, notes, rid),
                )
                return rid
            sql = ("INSERT INTO vendor_fiscal_calendars(vendor_name,vendor_slug,vendor_category,"
                   "fy_end_month,fy_end_label,best_window_label,discount_uplift_pct,notes,is_active) "
                   "VALUES(?,?,?,?,?,?,?,?,1)")
            sql += self._db.returning_clause()
            cursor.execute(self._q(sql), (vendor_name, vendor_slug, vendor_category,
                                          fy_end_month, fy_end_label, best_window_label,
                                          discount_uplift_pct, notes))
            return int(self._db.get_last_id(cursor))

    def load_negotiation_terms(
        self,
        category: Optional[str] = None,
        bd_relevant: bool = False,
    ) -> List[Dict[str, Any]]:
        q = ("SELECT id, term_name, term_slug, category, difficulty, bd_relevant, "
             "explanation, risk_description, moderate_leverage_action, high_leverage_action, "
             "applies_to, sort_order FROM negotiation_terms WHERE is_active=1")
        params: List[Any] = []
        if bd_relevant:
            q += " AND bd_relevant IN ('must','yes')"
        if category:
            q += " AND category=?"
            params.append(category)
        q += " ORDER BY sort_order, category, term_name"
        with self._tx() as cursor:
            cursor.execute(self._q(q), tuple(params))
            return [dict(r) for r in cursor.fetchall()]

    def load_vendor_fiscal_calendars(
        self, category: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        q = ("SELECT id, vendor_name, vendor_slug, vendor_category, fy_end_month, "
             "fy_end_label, best_window_label, discount_uplift_pct, notes "
             "FROM vendor_fiscal_calendars WHERE is_active=1")
        params: List[Any] = []
        if category:
            q += " AND vendor_category=?"
            params.append(category)
        q += " ORDER BY vendor_category, fy_end_month"
        with self._tx() as cursor:
            cursor.execute(self._q(q), tuple(params))
            return [dict(r) for r in cursor.fetchall()]

    def set_aria_entity_active(self, table: str, row_id: int, active: bool) -> None:
        """Soft-delete / restore a row in any ARIA config table."""
        self.ensure_aria_schema()
        allowed = {"aria_rules", "aria_clause_rules", "aria_checklists",
                   "negotiation_terms", "vendor_fiscal_calendars"}
        if table not in allowed:
            raise ValueError(f"Unknown ARIA table: {table!r}")
        with self._tx() as cursor:
            cursor.execute(
                self._q(f"UPDATE {table} SET is_active=? WHERE id=?"),
                (1 if active else 0, row_id),
            )
