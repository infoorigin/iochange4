"""Message-level feedback: what a person thought of ONE chat reply.

WHAT THIS IS, AND WHAT IT IS NOT. ``learning_feedback`` (engine/learning) is
a steward's verdict on a SKILL for a run step - it feeds the learning
lifecycle. This is the other thing every chat product has and this engine
did not: a thumbs up, a thumbs down, or a correction, attached to a reply in
a conversation, from the person who read it. It feeds nothing automatically;
it is a record, read back by ``GET /api/feedback/summary`` and
``aicore feedback list|export`` so a team can see which agent is earning
its keep and pull the corrections into an eval suite.

The table is created by ``Store.init()`` (engine/store.py) beside
``messages``. Every function here takes the engine ``Store`` so the router
and the CLI share one implementation of every query.

Rows are workspace-scoped. ``workspace_id`` carries the workspace CODE - the
column name follows the ``messages`` table's spelling, the value follows the
conversations tables', because a code is what every other tenant-keyed row
on the chat surfaces carries and an integer id is what nothing resolves.
"""
from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

#: The legal signals, in the order an error message lists them.
SIGNALS: tuple[str, ...] = ("up", "down", "correction")

_MAX_COMMENT = 8_000


class FeedbackError(ValueError):
    """A request this module refuses; the message names the fix."""

    def __init__(self, message: str, status: int = 422):
        super().__init__(message)
        self.status = status


def validate_signal(signal: Any) -> str:
    """The signal, normalised - or :class:`FeedbackError` naming the legal set."""
    s = str(signal or "").strip().lower()
    if s not in SIGNALS:
        raise FeedbackError(
            f"signal must be one of: {', '.join(SIGNALS)} (got {signal!r})")
    return s


def clean_comment(comment: Any) -> str:
    text = "" if comment is None else str(comment)
    if len(text) > _MAX_COMMENT:
        raise FeedbackError(
            f"comment is too long ({len(text)} chars; the limit is {_MAX_COMMENT})")
    return text.strip()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def parse_since(since: str | None) -> str | None:
    """A ``since`` argument as an ISO timestamp, or None for "all".

    Accepts an ISO date/datetime, or a window like ``7d``, ``24h``, ``30m``.
    """
    if since is None:
        return None
    text = str(since).strip()
    if not text:
        return None
    unit = text[-1:].lower()
    if unit in ("d", "h", "m") and text[:-1].isdigit():
        n = int(text[:-1])
        delta = {"d": timedelta(days=n), "h": timedelta(hours=n),
                 "m": timedelta(minutes=n)}[unit]
        return (datetime.now(timezone.utc) - delta).isoformat(timespec="seconds")
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        raise FeedbackError(
            f"since must be an ISO date/time or a window like 7d, 24h, 30m "
            f"(got {since!r})")
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def record(store, *, workspace: str, signal: str, user_id: str = "",
           agent: str = "", comment: str = "", conversation_id: str | None = None,
           item_id: str | None = None, message_id: int | None = None) -> dict:
    """Insert one feedback row and return it as a dict."""
    sig = validate_signal(signal)
    text = clean_comment(comment)
    if item_id is None and message_id is None:
        raise FeedbackError("feedback must name an item_id or a message_id")
    created = now_iso()
    with store._tx() as cur:
        cur.execute(store._q(
            "INSERT INTO message_feedback (workspace_id, conversation_id,"
            " item_id, message_id, user_id, agent, signal, comment, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"),
            (workspace, conversation_id, item_id, message_id, user_id or "",
             agent or "", sig, text, created))
        cur.execute(store._q(
            "SELECT id FROM message_feedback WHERE workspace_id=? AND created_at=?"
            " ORDER BY id DESC LIMIT 1"), (workspace, created))
        row = cur.fetchone()
        new_id = int(dict(row)["id"]) if row is not None else 0
    return {
        "id": new_id, "workspace_id": workspace,
        "conversation_id": conversation_id, "item_id": item_id,
        "message_id": message_id, "user_id": user_id or "", "agent": agent or "",
        "signal": sig, "comment": text, "created_at": created,
    }


_COLS = ("id, workspace_id, conversation_id, item_id, message_id, user_id,"
         " agent, signal, comment, created_at")


def list_feedback(store, *, workspace: str | None, since: str | None = None,
                  agent: str | None = None, signal: str | None = None,
                  limit: int = 500) -> list[dict]:
    """Rows newest first. ``workspace=None`` reads every workspace (CLI export)."""
    q = f"SELECT {_COLS} FROM message_feedback WHERE 1=1"
    params: list = []
    if workspace is not None:
        q += " AND workspace_id=?"
        params.append(workspace)
    if since:
        q += " AND created_at>=?"
        params.append(since)
    if agent:
        q += " AND agent=?"
        params.append(agent)
    if signal:
        q += " AND signal=?"
        params.append(validate_signal(signal))
    q += " ORDER BY id DESC LIMIT ?"
    params.append(int(limit))
    with store._tx() as cur:
        cur.execute(store._q(q), tuple(params))
        return [dict(r) for r in cur.fetchall()]


def _empty_counts() -> dict:
    return {s: 0 for s in SIGNALS} | {"total": 0}


def summary(store, *, workspace: str | None, since: str | None = None) -> dict:
    """Counts by signal, per agent and per day. One read, folded in Python -
    the same shape on both backends, and the volumes here are human-sized."""
    rows = list_feedback(store, workspace=workspace, since=since, limit=100_000)
    by_signal = _empty_counts()
    by_agent: dict[str, dict] = defaultdict(_empty_counts)
    by_day: dict[str, dict] = defaultdict(_empty_counts)
    for r in rows:
        sig = r["signal"]
        day = (r["created_at"] or "")[:10]
        for bucket in (by_signal, by_agent[r["agent"] or ""], by_day[day]):
            bucket[sig] = bucket.get(sig, 0) + 1
            bucket["total"] += 1
    return {
        "workspace": workspace,
        "since": since,
        "total": by_signal["total"],
        "by_signal": {s: by_signal[s] for s in SIGNALS},
        "by_agent": [{"agent": a, **c} for a, c in sorted(by_agent.items())],
        "by_day": [{"day": d, **c} for d, c in sorted(by_day.items())],
    }


def export_jsonl(rows: Iterable[dict], path) -> int:
    """Write rows as JSON lines. Returns the count."""
    n = 0
    with open(path, "w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=True, default=str) + "\n")
            n += 1
    return n


def digest(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()
