"""Lint a ``workflow.yaml`` before the loader silently forgives it.

WHY THIS EXISTS. ``WorkflowLoader._load_from_dir`` reads every field with
``data.get(...)``. That is not a validation step — it is the *absence* of one.
A key the loader does not recognise is not rejected, it is **never read**, so
the workflow loads clean and the setting simply does not exist::

    requires_artifact: [report.md]     # missing the 's'

loads without a word of complaint, and the fail-closed artifact gate that was
supposed to stop a step reporting success without writing its handoff is now
off. The run "works". A downstream step then composes its section from a file
that was never written. One character, no error, wrong output.

The same shape of bug hides in ``skilz:`` (the role runs with every skill
loaded instead of the filter you wrote), ``vars_typo:`` (your template
variables render as empty strings) and ``learnings: disabled`` (memory keeps
compounding across runs).

``learning:`` deserves its own note. It is not on the ``Workflow`` model at
all — ``cli_orchestration._finalize_step`` and ``workspaces.create_filtered_workspace``
each re-read the raw snapshot YAML and test
``str(wf_data.get("learning", "")).lower() in ("disabled", "false", "off")``.
So it never passes through the loader, never reaches pydantic, and any value
outside that set means "learning stays ON" — including ``learning: none``,
which reads like it disables it and does the opposite.

WHAT THIS MODULE ADDS that nothing else does:

* **Unknown keys are rejected**, at every level, with a did-you-mean.
* **Facts the loader cannot know**: prompt files that are not on disk, a
  ``type: loop`` with nothing to fan out into, ``stories_from`` on a step type
  that never reads it, two steps both carrying ``per_item_steps`` (the
  scheduler resolves templates from the *first* one it finds and the second
  step's templates are unreachable).
* **``learning:`` validated against the values the two call sites honour.**
* **Every finding at once**, with a line number and a fix, split into errors
  (will not run, or will run wrong) and warnings (legal, suspicious).

The graph checks — deps resolve, roles exist, no cycles — are NOT reimplemented
here. ``workflow_loader.collect_workflow_errors`` is the one implementation and
this calls it against a skeleton ``Workflow`` built from the raw YAML.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import yaml

ERROR = "error"
WARNING = "warning"

# ── The key sets ────────────────────────────────────────────────────────
#
# Derived from BOTH ``engine/models.py`` AND the loader's actual ``data.get``
# calls, because the YAML shape is not the model shape:
#
#   * ``roles``  is a LIST of mappings in YAML, a ``Dict[str, Role]`` on the
#     model (the loader keys it by ``r["name"]``).
#   * ``team``   is a LIST of ``{role: ...}`` in YAML; ``Workflow.team`` is a
#     STRING (the contents of ``team.md``) and the YAML list lands in
#     ``team_roster``. Validating against the model's field types here would
#     be actively wrong.
#   * ``learning`` is on NEITHER — it exists only in raw YAML.

TOP_LEVEL_KEYS = frozenset({
    "name", "description", "protocol", "learning", "vars",
    "team", "sandbox", "roles", "steps",
    # `depends_on_runs` refuses this workflow while a workflow it CONSUMES
    # from still has a run producing (engine/run_deps.py); `coverage` declares
    # the commands that say what a run did NOT cover (engine/coverage.py).
    # Both must be listed here as well as read by the loader - an unknown key
    # is a lint ERROR, so a key wired into the model and not into this set
    # loads correctly and fails the linter, which is the worst of both.
    "depends_on_runs", "single_active_run", "coverage",
})

ROLE_KEYS = frozenset({"name", "prompt", "skills", "model", "allowed_tools"})

STEP_KEYS = frozenset({
    "key", "title", "role", "type", "prompt", "deps", "max_attempts",
    "command", "stories_from", "fresh_session", "loop_source_key",
    "per_item_steps", "requires_artifacts", "mcp_tools", "timeout",
    "routes", "on_fail",
})

TEMPLATE_KEYS = frozenset({"key_suffix", "title", "role", "prompt",
                           "max_attempts", "deps", "mcp_tools"})

SANDBOX_KEYS = frozenset({"policy", "prewarm", "idle_timeout", "pool", "image"})

TEAM_MEMBER_KEYS = frozenset({"role"})

STEP_TYPES = ("normal", "loop", "exec", "route")
#: The types that run `command` with no agent.
_CMD_TYPES = ("exec", "route")
ON_FAIL_KEYS = frozenset({"reset", "feedback"})

#: ``str(value).lower()`` values that the two ``learning:`` call sites treat as
#: "disable learning for this workflow". Note YAML 1.1 folds ``off``/``no``/
#: ``n``/``false`` to the boolean ``False``, whose ``str()`` is ``"false"`` —
#: so all of those spellings do disable it, by accident rather than design.
LEARNING_DISABLES = frozenset({"disabled", "false", "off"})

#: Values that reliably mean "leave learning on". Everything outside the union
#: of these two sets is silently ignored and learning stays ON.
LEARNING_ENABLES = frozenset({"enabled", "true"})

#: ``create_filtered_workspace`` adds this to the required set unconditionally,
#: so a ``skills:`` list cannot drop it. Every OTHER ``always: true`` skill is
#: dropped if the list does not name it. Not policy: an agent without
#: ``output_protocol`` emits no ``STATUS:``/``OUTPUT:``, so every step it runs
#: is marked failed and retried.
ALWAYS_INJECTED_SKILL = "output_protocol"

_STEP_KEY_RE = re.compile(r"^[A-Za-z0-9_.-]+$")

#: Template variables whose value DIFFERS per fan-out item, and which
#: therefore make a `{{output_dir}}/<file>` name unique across items.
#:
#: `story_id` is the obvious one. `step_key_safe` is the one that matters:
#: `render_step_prompt` prescribes it in so many words - "a prompt that needs
#: to name a per-step file ... must use this, not step_key" - because a
#: fan-out key is `story:G01:detect` and Windows cannot create a filename
#: containing a colon. So the checkpoint file every retry-resumable fan-out
#: prompt writes is named with it. Accepting only `story_id` warned about
#: exactly the spelling the scheduler mandates, on the shipped
#: `signal_detection` workflow: two rules for one decision, disagreeing, and
#: a warning that is always wrong is a warning nobody reads.
_PER_ITEM_VARS = ("story_id", "step_key_safe", "step_key")


@dataclass(frozen=True)
class Finding:
    """One problem, with the location and the fix."""

    severity: str          # ERROR | WARNING
    where: str             # dotted path, e.g. "steps[2].requires_artifact"
    message: str           # what is wrong, and what the engine will do about it
    fix: str               # what to write instead
    line: int | None = None

    def format(self, path: str | None = None) -> str:
        loc = path or ""
        if self.line is not None:
            loc = f"{loc}:{self.line}" if loc else f"line {self.line}"
        head = f"{self.severity.upper()}"
        if loc:
            head = f"{loc}: {head}"
        out = f"{head}: {self.where}: {self.message}"
        if self.fix:
            out += f"\n    fix: {self.fix}"
        return out


class LintResult:
    """The findings for one workflow, plus the convenience predicates."""

    def __init__(self, path: Path | str, findings: Sequence[Finding],
                 name: str = "") -> None:
        self.path = str(path)
        self.name = name
        self.findings = list(findings)

    @property
    def errors(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == ERROR]

    @property
    def warnings(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == WARNING]

    @property
    def ok(self) -> bool:
        return not self.errors

    def __bool__(self) -> bool:          # pragma: no cover - convenience
        return self.ok

    def format(self) -> str:
        return "\n".join(f.format(self.path) for f in self.findings)


# ── YAML line numbers ───────────────────────────────────────────────────
#
# ``yaml.safe_load`` gives clean values and no positions; ``yaml.compose``
# gives positions and awkward values. Walk the node tree once to build a
# path -> line index, then keep using the clean values.

def _line_index(node: Any, path: tuple = (), out: dict | None = None) -> dict:
    if out is None:
        out = {}
    if isinstance(node, yaml.MappingNode):
        for key_node, val_node in node.value:
            child = path + (key_node.value,)
            out[child] = key_node.start_mark.line + 1
            _line_index(val_node, child, out)
    elif isinstance(node, yaml.SequenceNode):
        for i, item in enumerate(node.value):
            child = path + (i,)
            out[child] = item.start_mark.line + 1
            _line_index(item, child, out)
    return out


#: Names an author reaches for that are too far from the real key for
#: ``difflib`` to bridge. ``dependencies`` -> ``deps`` scores 0.5 on
#: SequenceMatcher (below the 0.6 cutoff), and it is the single most likely
#: thing someone writes who has used any other pipeline format. A suggestion
#: is only offered when the target is actually valid at that level, so
#: ``name`` -> ``key`` fires inside ``steps[]`` and never inside ``roles[]``,
#: where ``name`` is correct.
ALIASES = {
    "dependencies": "deps", "depends_on": "deps", "depends": "deps",
    "needs": "deps", "after": "deps", "requires": "deps",
    "artifacts": "requires_artifacts",
    "required_artifacts": "requires_artifacts",
    "outputs": "requires_artifacts", "produces": "requires_artifacts",
    "agent": "role", "actor": "role", "assignee": "role",
    "id": "key", "step_key": "key", "step": "key", "name": "key",
    "retries": "max_attempts", "attempts": "max_attempts",
    "max_retries": "max_attempts",
    "cmd": "command", "run": "command", "shell": "command",
    "script": "command", "exec": "command",
    "variables": "vars", "params": "vars", "parameters": "vars", "env": "vars",
    "memory": "learning",
    "tools": "allowed_tools", "allowlist": "allowed_tools",
    "skill": "skills", "capabilities": "skills",
    "llm": "model", "provider": "model",
    "loop_steps": "per_item_steps", "item_steps": "per_item_steps",
    "manifest": "stories_from", "stories": "stories_from",
}


def _suggest(key: str, known: Iterable[str]) -> str | None:
    """Closest known key, or None.

    ``difflib`` alone misses the two cases that matter most here: a key that
    differs only by a trailing 's' (``requires_artifact``), and a key that is
    a different word for the same thing (``dependencies``). Check the exact
    transforms and the alias table before falling back to fuzzy matching.
    """
    known = list(known)
    for cand in (key.rstrip("s"), key + "s", key.replace("_", ""),
                 key.rstrip("_")):
        if cand in known:
            return cand
    alias = ALIASES.get(key.lower())
    if alias in known:
        return alias
    hit = difflib.get_close_matches(key, known, n=1, cutoff=0.6)
    return hit[0] if hit else None


class _Linter:
    def __init__(self, base: Path | None, workspace: str | None = None) -> None:
        self.base = base
        #: The workspace whose ``models.yaml`` the model check reads; None
        #: falls back to the selection in force.
        self.workspace = workspace
        self.findings: list[Finding] = []
        self.lines: dict = {}
        #: `vars:` keys, stashed before checks run, so a prompt's template
        #: names can be resolved against what the workflow declares.
        self._declared_vars: set = set()

    # -- emit helpers ---------------------------------------------------
    def _add(self, severity: str, where: str, message: str, fix: str,
             path: tuple = ()) -> None:
        self.findings.append(
            Finding(severity, where, message, fix, self.lines.get(path))
        )

    def err(self, where: str, message: str, fix: str, path: tuple = ()) -> None:
        self._add(ERROR, where, message, fix, path)

    def warn(self, where: str, message: str, fix: str, path: tuple = ()) -> None:
        self._add(WARNING, where, message, fix, path)

    # -- shared checks --------------------------------------------------
    def _unknown_keys(self, mapping: dict, known: frozenset, where: str,
                      path: tuple, *, elsewhere: dict[str, str] | None = None
                      ) -> None:
        """The whole point of the linter.

        The loader never sees an unrecognised key, so the setting it was
        meant to carry simply does not exist. Say which one, and what the
        engine will do without it.
        """
        for key in mapping:
            if not isinstance(key, str) or key in known:
                continue
            hint = _suggest(key, known)
            if hint:
                fix = f"rename `{key}` to `{hint}`"
            elif elsewhere and key in elsewhere:
                fix = (f"`{key}` is a valid key, but it belongs under "
                       f"{elsewhere[key]}, not here — move it")
            else:
                fix = (f"remove `{key}`; valid keys here are: "
                       f"{', '.join(sorted(known))}")
            self.err(
                f"{where}.{key}",
                "unknown key — the loader reads fields by name and never "
                "reads this one, so whatever it was meant to configure is "
                "silently left at its default",
                fix,
                path + (key,),
            )

    def _require_str(self, mapping: dict, key: str, where: str, path: tuple,
                     *, allow_empty: bool = False) -> str | None:
        val = mapping.get(key)
        if val is None:
            self.err(f"{where}.{key}",
                     f"required key `{key}` is missing",
                     f"add `{key}: <value>`", path)
            return None
        if not isinstance(val, str):
            self.err(f"{where}.{key}",
                     f"`{key}` must be a string, got {type(val).__name__}",
                     f"quote the value: `{key}: \"{val}\"`", path + (key,))
            return None
        if not val.strip() and not allow_empty:
            self.err(f"{where}.{key}", f"`{key}` is empty",
                     f"give `{key}` a value", path + (key,))
            return None
        return val

    def _check_prompt_file(self, where: str, rel: str, path: tuple) -> None:
        """A prompt path the loader will ``read_text`` and blow up on.

        The loader resolves prompts relative to the workflow directory and
        reads them unconditionally. A path that is not there is a
        ``FileNotFoundError`` at run creation, from inside the loader, with
        no indication of which of the twenty prompt paths was wrong.
        """
        if self.base is None or not rel:
            return
        target = self.base / rel
        if not target.exists():
            near = self._nearby_prompts(rel)
            fix = f"create {rel}, or point `prompt:` at a file that exists"
            if near:
                fix += f" (did you mean {near}?)"
            self.err(where,
                     f"prompt file `{rel}` does not exist under {self.base} — "
                     "the loader reads it unconditionally, so this is a "
                     "FileNotFoundError at run creation",
                     fix, path)
        elif target.is_dir():
            self.err(where, f"prompt path `{rel}` is a directory, not a file",
                     "point `prompt:` at the .md file", path)
        elif not target.read_text(encoding="utf-8", errors="replace").strip():
            self.warn(where, f"prompt file `{rel}` is empty — the agent will "
                             "receive only the step wrapper",
                      f"write the step instructions into {rel}", path)
        else:
            self._check_text_before_tool_calls(where, rel, target, path)
            self._check_template_names(where, rel, target, path)

    #: Names the engine's own render context supplies to every step prompt
    #: (engine/scheduler.render_step_prompt). Everything else must come from
    #: `vars:` or a `step_output.` reference, or it renders as "".
    _CTX_NAMES = frozenset({
        "run_id", "workflow", "goal", "project_dir", "output_dir",
        "workflow_dir", "metadata_dir", "step_key", "step_key_safe", "role",
        "attempt", "max_attempts", "feedback", "progress", "story_id",
    })

    _TEMPLATE_NAME_RE = re.compile(r"\{\{\s*([A-Za-z0-9_.:-]+)\s*\}\}")

    def _check_template_names(self, where: str, rel: str,
                              target, path: tuple) -> None:
        """A template name nothing supplies renders as "" - silently.
        The templater's contract is missing -> empty string, which is the
        right runtime behaviour and precisely why the AUTHORING error class
        (`vars_typo` in this module's docstring) needs a checker: a live
        workflow shipped `{{vars.target_brand}}` where the context key was
        the bare `target_brand`, lint reported 0/0, and the running step's
        prompt read "A share-loss alert has arrived for  in ." The dotted
        `vars.<name>` spelling is legal now (the scheduler aliases it), so
        only a name that resolves to NOTHING is flagged - as a warning,
        because a prompt may legitimately show literal `{{x}}` in a code
        example it teaches.
        """
        try:
            text = target.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return
        self._check_template_text(where, f"prompt file `{rel}`", text, path)

    #: placeholders that carry PERSON-supplied text into a command line
    _USER_TEXT = ("goal", "story_id", "feedback")

    def _lint_unquoted_placeholders(self, where: str, command: str, path: tuple) -> None:
        """`--label {{label}}` runs through the system shell with the value
        bare: a value with a space is two arguments, one with `&&` is a
        second command (novice finding, round 5). The engine's own path
        names are safe unquoted; a `vars:` value, the goal, a story id or
        the feedback are a person's text and must be quoted."""
        if not isinstance(command, str):
            return
        watch = set(self._declared_vars) | set(self._USER_TEXT)
        quote = None
        unquoted: list = []
        i = 0
        while i < len(command):
            ch = command[i]
            if quote:
                if ch == quote:
                    quote = None
                i += 1
                continue
            if ch in ("'", '"'):
                quote = ch
                i += 1
                continue
            m = self._TEMPLATE_NAME_RE.match(command, i)
            if m:
                name = m.group(1)
                base = name[5:] if name.startswith("vars.") else name
                if base in watch and base not in unquoted:
                    unquoted.append(base)
                i = m.end()
                continue
            i += 1
        for name in unquoted:
            self.warn(
                f"{where}.command",
                f"`{{{{{name}}}}}` is unquoted in `command:` - the value is a person's text "
                "and the command runs through the system shell, so a space splits it "
                "into arguments and `&&` runs a second command",
                f'quote it: `--x "{{{{{name}}}}}"`',
                path + ("command",))

    def _check_template_text(self, where: str, label: str, text: str,
                             path: tuple) -> None:
        """The same check over any templated TEXT - a `command:` included.

        The first version read prompt FILES only, so `{{output_dirr}}` in a
        command line passed lint and the tool ran with an empty argument
        (novice finding: "lint said clean, the step failed on a path")."""
        seen: set = set()
        for name in self._TEMPLATE_NAME_RE.findall(text):
            if name in seen:
                continue
            seen.add(name)
            if name in self._CTX_NAMES or name in self._declared_vars:
                continue
            if name.startswith("step_output."):
                continue
            if name.startswith("vars.") and name[5:] in self._declared_vars:
                continue
            declared = ", ".join(sorted(self._declared_vars)) or "none"
            self.warn(
                where,
                f"{label} uses `{{{{{name}}}}}`, which nothing "
                "supplies - the templater renders an unknown name as an "
                "EMPTY STRING, so the agent reads a sentence with a hole "
                "in it (or the command loses an argument) and nothing errors",
                f"declare it under `vars:` or use one of the engine's own "
                f"names; this workflow declares: {declared}",
                path,
            )
    #: (``cli_scaffold.step_output_block``). Matched loosely because authors
    #: legitimately reword it; what must survive is the instruction, not the
    #: sentence.
    _TEXT_FIRST = ("before every tool call", "before each tool call",
                   "before any tool call", "before every tool_use",
                   "before any tool_use")

    def _check_text_before_tool_calls(self, where: str, rel: str,
                                      target, path: tuple) -> None:
        """The scaffold generates this rule; an author can silently drop it.

        A turn whose first content block is a tool call is a known cause of
        dropped responses — the failure surfaces as what looks like a network
        error, is retried, and costs a step's attempts while the prompt reads
        perfectly. `requires_artifacts` is checked rather than remembered for
        the same reason; this is the other half of that contract.

        Found by measuring a workflow that an assistant authored over the
        scaffold's own output: it kept the catalog-first and sectioned-
        composition rules and dropped this one, in all three steps.

        STEP prompts only. A ROLE prompt is an identity - it describes who
        the agent is, carries no output contract, and the scaffold does not
        put the rule there. Checking it flagged every correctly-generated
        workflow on the first cut.
        """
        if not where.startswith("steps[") and "per_item_steps" not in where:
            return
        body = target.read_text(encoding="utf-8", errors="replace").lower()
        if any(cue in body for cue in self._TEXT_FIRST):
            return
        # One finding per FILE. Every prompt is visited twice - once as
        # `roles[<name>].prompt` and once as `steps[<key>].prompt` - and a
        # doubled warning reads as two problems.
        seen = self.__dict__.setdefault("_text_first_warned", set())
        if rel in seen:
            return
        seen.add(rel)
        self.warn(
            where,
            f"prompt file `{rel}` does not tell the agent to print a line of "
            "text before every tool call — the scaffold generates that rule, "
            "so it has been edited out; a turn that opens with a tool call is "
            "a known cause of dropped responses",
            "add: `Print at least one line of text immediately BEFORE every "
            "tool call.`",
            path)

    def _nearby_prompts(self, rel: str) -> str:
        if self.base is None:
            return ""
        stem = Path(rel).name
        cands = [str(p.relative_to(self.base)).replace("\\", "/")
                 for p in self.base.rglob("*.md")]
        hit = difflib.get_close_matches(stem, [Path(c).name for c in cands],
                                        n=1, cutoff=0.6)
        if not hit:
            return ""
        return next((c for c in cands if Path(c).name == hit[0]), "")

    # -- top level ------------------------------------------------------
    def lint(self, data: Any) -> None:
        if data is None:
            self.err("<file>", "workflow.yaml is empty",
                     "a workflow needs at least `name:`, `roles:` and `steps:`")
            return
        if not isinstance(data, dict):
            self.err("<file>",
                     f"top level must be a mapping, got {type(data).__name__}",
                     "the file should start with `name: <workflow_name>`")
            return

        self._unknown_keys(
            data, TOP_LEVEL_KEYS, "<top-level>", (),
            elsewhere={k: "`roles[]`" for k in ROLE_KEYS - TOP_LEVEL_KEYS}
            | {k: "`steps[]`" for k in STEP_KEYS - TOP_LEVEL_KEYS}
            | {k: "`sandbox`" for k in SANDBOX_KEYS - TOP_LEVEL_KEYS},
        )

        name = self._require_str(data, "name", "<top-level>", ())
        if name and self.base is not None and name != self.base.name:
            # Everything that ADDRESSES a workflow uses the DIRECTORY name:
            # `list_workflows` scans directories, `load(name)`/`snapshot_workflow`
            # take that name, and `catalog_sync` upserts `code=<dir name>`.
            # `name:` becomes ``Workflow.name`` — and ``scheduler`` re-materialises
            # the snapshot with ``snapshot_workflow(workflow.name, ...)``. When
            # the two disagree, that call raises FileNotFoundError, which the
            # scheduler swallows at debug level, and `{{metadata_dir}}` silently
            # falls back off the workflow's own catalog.
            self.err(
                "name",
                f"`name: {name}` does not match the directory name "
                f"'{self.base.name}'. Everything that addresses a workflow "
                "uses the DIRECTORY name; `name:` only feeds Workflow.name, "
                "which the scheduler passes to snapshot_workflow() when it "
                "re-materialises the frozen snapshot. On a mismatch that lookup "
                "raises FileNotFoundError, the scheduler swallows it at debug "
                "level, and {{metadata_dir}} falls back off this workflow's own "
                "catalog — grounded queries then read the wrong metadata, or none",
                f"rename the key to `name: {self.base.name}`, or rename the "
                f"directory to '{name}'",
                ("name",),
            )
        if "description" in data and not isinstance(data["description"], str):
            self.err("description",
                     f"must be a string, got {type(data['description']).__name__}",
                     "use a `>` folded block or quote the text",
                     ("description",))

        self._lint_learning(data)
        self._lint_vars(data)
        self._lint_protocol(data)
        self._lint_sandbox(data)

        role_names = self._lint_roles(data)
        self._lint_role_models(data)
        self._lint_team(data, role_names)
        self._lint_steps(data, role_names)
        self._lint_registry(data, role_names)

    # -- registry-backed checks (workspace families) --------------------
    def _lint_registry(self, data: dict, role_names: set[str]) -> None:
        """Cross-family dependencies and name collisions — WARNINGS only.

        Backed by the INSTALLED pack registry, so these are environment
        facts, not file facts: the same workflow can lint clean on one
        machine and warn on another, and that is the point — the warning
        describes what THIS deployment will do. Skipped entirely (silently)
        when the registry is unavailable: lint must stay usable offline and
        in CI without installed packs.
        """
        if self.base is None:
            return
        try:
            from ioagentfarm.packs import detect_collisions, load_registry
            from ioagentfarm.engine.catalog_sync import (
                role_pack_map, workflow_pack_map,
            )
            registry = load_registry()
            agent_family = role_pack_map()
            wf_family = workflow_pack_map().get(self.base.name)
            collisions = detect_collisions(registry)
        except Exception:
            return

        # A workflow naming an agent another family ships. It RUNS today —
        # the role namespace is flat — but couples this solution to a pack
        # another team versions. Core agents (cora, project_lead, …) are
        # the platform tier, shared with everyone by design: never warned.
        if wf_family:
            for role in sorted(role_names):
                fam = agent_family.get(role)
                if fam and fam not in (wf_family, "core"):
                    self.warn(
                        f"roles.{role}",
                        f"agent `{role}` is shipped by family `{fam}`, but "
                        f"this workflow belongs to `{wf_family}`. The flat "
                        "role namespace makes this run, but it couples this "
                        "solution to another team's release cycle — and a "
                        "workspace scoped to one family will not pre-seed "
                        "the other family's agent",
                        f"move `{role}` into this workspace's shared pack, "
                        "or accept the cross-family dependency knowingly",
                        ("roles",),
                    )

        # Installed-pack name collisions that involve THIS workflow's roles
        # or skill filters. Global collisions are load_registry()'s log line;
        # here only what this workflow actually touches, so the warning is
        # actionable at the file being linted.
        used_skills: set[str] = set()
        roles_raw = data.get("roles")
        for r in (roles_raw if isinstance(roles_raw, list) else []):
            if isinstance(r, dict) and isinstance(r.get("skills"), list):
                used_skills |= {s for s in r["skills"] if isinstance(s, str)}
        for c in collisions:
            relevant = ((c.kind == "agent" and c.name in role_names)
                        or (c.kind == "skill" and c.name in used_skills))
            if not relevant:
                continue
            winner = c.packs[0]
            self.warn(
                f"{c.kind}.{c.name}",
                f"{c.kind} `{c.name}` is shipped by more than one installed "
                f"pack ({', '.join(c.packs)}) — first in registry order wins, "
                f"so this workflow gets `{winner}`'s copy"
                + (" (two distributions of ONE family both carry it — the "
                   "shared pack should be the only carrier)"
                   if c.same_family else ""),
                "remove the duplicate from all but one pack "
                "(the family's shared pack is the right home)",
                ("roles",),
            )

    # -- learning -------------------------------------------------------
    def _lint_learning(self, data: dict) -> None:
        """The one key that never reaches the loader OR pydantic.

        Both call sites do the same string test, so an unrecognised value is
        not an error anywhere — it just means learning stays on. The two
        worst spellings look deliberate: ``learning: none`` (YAML null ->
        ``"none"``) and ``learning:`` with nothing after it (also null).
        """
        if "learning" not in data:
            return
        raw = data["learning"]
        norm = str(raw).lower()
        if norm in LEARNING_DISABLES or norm in LEARNING_ENABLES:
            return
        shown = "(empty)" if raw is None else repr(raw)
        self.err(
            "learning",
            f"value {shown} is not one the engine honours. `learning:` is read "
            "straight from the raw YAML in cli_orchestration._finalize_step "
            "and workspaces.create_filtered_workspace — it is not on the "
            "Workflow model, so nothing validates it. Anything outside "
            f"{sorted(LEARNING_DISABLES)} leaves learning ON, and MEMORY.md "
            "keeps compounding across runs",
            "write `learning: disabled` to turn it off, or `learning: enabled` "
            "(or omit the key) to leave it on",
            ("learning",),
        )

    # -- vars -----------------------------------------------------------
    def _lint_vars(self, data: dict) -> None:
        if "vars" not in data:
            return
        v = data["vars"]
        if v is None:
            return
        if not isinstance(v, dict):
            self.err("vars", f"must be a mapping, got {type(v).__name__}",
                     "use `vars:\\n  key: \"value\"`", ("vars",))
            return
        for key, val in v.items():
            if isinstance(val, str):
                continue
            # Workflow.vars is Dict[str, str] and pydantic v2 does NOT coerce
            # int/bool/None into str — this is a hard ValidationError at load,
            # not a silent one, but the traceback names pydantic rather than
            # the line you wrote.
            self.err(
                f"vars.{key}",
                f"value must be a quoted string, got {type(val).__name__}. "
                "`Workflow.vars` is `Dict[str, str]` and pydantic will refuse "
                "the whole workflow",
                f'quote it: `{key}: "{val}"`',
                ("vars", key),
            )

    def _lint_protocol(self, data: dict) -> None:
        if "protocol" not in data or data["protocol"] is None:
            return
        if not isinstance(data["protocol"], dict):
            self.err("protocol",
                     f"must be a mapping, got {type(data['protocol']).__name__}",
                     'use `protocol:\\n  required_keys: ["STATUS", "OUTPUT"]`',
                     ("protocol",))

    # -- sandbox --------------------------------------------------------
    def _lint_sandbox(self, data: dict) -> None:
        if "sandbox" not in data or data["sandbox"] is None:
            return
        sb = data["sandbox"]
        if not isinstance(sb, dict):
            self.err("sandbox", f"must be a mapping, got {type(sb).__name__}",
                     "use `sandbox:\\n  policy: default`", ("sandbox",))
            return
        self._unknown_keys(sb, SANDBOX_KEYS, "sandbox", ("sandbox",))
        for key in ("policy", "pool"):
            val = sb.get(key)
            if val is None:
                continue
            if not isinstance(val, str) or not re.match(r"^[a-zA-Z0-9_-]+$", val) \
                    or len(val) > 64:
                self.err(f"sandbox.{key}",
                         f"`{key}` must be alphanumeric/hyphens/underscores, "
                         "max 64 chars — SandboxWorkflowConfig rejects anything "
                         "else to stop path traversal into sandbox_policies/",
                         f"use a plain name, e.g. `{key}: default`",
                         ("sandbox", key))
        if "idle_timeout" in sb:
            it = sb["idle_timeout"]
            if not isinstance(it, int) or isinstance(it, bool) or it < 0:
                self.err("sandbox.idle_timeout",
                         "must be an integer >= 0 (0 means never destroy)",
                         "use `idle_timeout: 300`", ("sandbox", "idle_timeout"))
        if "prewarm" in sb and not isinstance(sb["prewarm"], bool):
            self.err("sandbox.prewarm",
                     f"must be true or false, got {type(sb['prewarm']).__name__}",
                     "use `prewarm: true`", ("sandbox", "prewarm"))

    # -- roles ----------------------------------------------------------
    def _lint_roles(self, data: dict) -> set[str]:
        roles = data.get("roles")
        names: set[str] = set()
        if roles is None:
            self.err("roles", "no `roles:` section — every non-exec step needs "
                              "a role defined here",
                     "add a `roles:` list with at least one `- name: … "
                     "prompt: roles/….md`")
            return names
        if not isinstance(roles, list):
            # A mapping here is the commonest shape error: `roles` is a
            # Dict[str, Role] on the MODEL but a LIST in the YAML.
            self.err("roles",
                     f"must be a LIST of mappings, got {type(roles).__name__}. "
                     "(`Workflow.roles` is a dict on the model, but the loader "
                     "builds that dict by iterating a YAML list and keying on "
                     "`name` — the YAML shape is a list)",
                     "use `roles:\\n  - name: analyst\\n    prompt: roles/analyst.md`",
                     ("roles",))
            return names

        for i, r in enumerate(roles):
            path = ("roles", i)
            where = f"roles[{i}]"
            if not isinstance(r, dict):
                self.err(where, f"must be a mapping, got {type(r).__name__}",
                         "each role is `- name: … / prompt: …`", path)
                continue
            self._unknown_keys(r, ROLE_KEYS, where, path,
                               elsewhere={k: "`steps[]`"
                                          for k in STEP_KEYS - ROLE_KEYS})
            name = self._require_str(r, "name", where, path)
            if name:
                if name in names:
                    self.err(f"{where}.name",
                             f"duplicate role name '{name}' — the loader keys "
                             "roles by name, so this entry silently replaces "
                             "the earlier one",
                             "give each role a distinct name", path + ("name",))
                names.add(name)
                where = f"roles[{name}]"
            prompt = self._require_str(r, "prompt", where, path)
            if prompt:
                self._check_prompt_file(f"{where}.prompt", prompt,
                                        path + ("prompt",))
            self._lint_role_skills(r, where, path)
            if "model" in r and r["model"] is not None \
                    and not isinstance(r["model"], str):
                self.err(f"{where}.model", "must be a string like "
                                           "\"provider/model-name\"",
                         'e.g. `model: "anthropic/claude-opus-4-6"`',
                         path + ("model",))
            at = r.get("allowed_tools")
            if at is not None and not isinstance(at, list):
                self.err(f"{where}.allowed_tools",
                         f"must be a list, got {type(at).__name__}",
                         "use `allowed_tools: [read_file, exec]`",
                         path + ("allowed_tools",))
        return names

    def _lint_role_models(self, data: dict) -> None:
        """A role's ``model:`` against the deployment's MODEL REGISTRY.

        The registry (``engine/model_registry.py``) is ``models.yaml`` in
        the ``IOF_MODELS`` / workspace / pack tiers. When one resolves, a
        model it does not allow — absent from the file, or ``retired`` — is
        an ERROR with a did-you-mean over the allowed names, a model past
        its ``deprecated_after`` is a WARNING, and the registry's own
        ``default:`` must be allowed too. When NO registry resolves this
        emits nothing: a deployment that never wrote one lints exactly as
        before. A registry that exists and cannot be read is an ERROR of
        its own, never silence — that would read as "everything allowed".
        """
        roles = data.get("roles")
        if not isinstance(roles, list):
            return
        from ioagentfarm.engine import model_registry as _mr
        try:
            registry = _mr.load_registry(self.workspace)
        except _mr.RegistryError as exc:
            self.err("<model-registry>", f"the model registry is unreadable: {exc}",
                     "fix models.yaml (status is one of "
                     f"{', '.join(_mr.STATUSES)}) or remove it")
            return
        except Exception:  # noqa: BLE001 - lint stays usable offline
            return
        if registry is None:
            return
        for f in _mr.check_role_models(roles, registry=registry):
            path = ("roles", f.index, "model") if f.index is not None else ()
            emit = self.err if f.severity == _mr.ERROR else self.warn
            emit(f.where, f.message, f.fix, path)

    def _lint_role_skills(self, r: dict, where: str, path: tuple) -> None:
        """The exact-set trap.

        ``skills:`` is not "also load these". It is the EXACT set of skills the
        role runs this job with: ``create_filtered_workspace`` materializes the
        named skills (plus ``output_protocol``, which it adds unconditionally)
        and nothing else. Every other ``always: true`` skill the agent carries
        — ``grounded_analysis``, ``catalog_reader``, a pack's house style — is
        dropped without a word unless it is named here.

        It cuts BOTH ways since skills became open (2026-08): a name is
        resolved from the whole workspace catalog — the agent's workspace, then
        ``studio_skills``, then the pack sources — so this list may also name a
        skill the agent has never carried and get it. There is no eligibility
        rule to lint against; a name that resolves nowhere is a runtime
        warning naming every source it searched.
        """
        if "skills" not in r:
            return
        skills = r["skills"]
        if skills is None:
            return                      # explicit null == omitted == all skills
        if not isinstance(skills, list):
            self.err(f"{where}.skills",
                     f"must be a list, got {type(skills).__name__}. Omit the "
                     "key entirely to load all of the role's skills",
                     "use `skills:\\n  - catalog_reader\\n  - grounded_analysis`",
                     path + ("skills",))
            return
        for j, s in enumerate(skills):
            if not isinstance(s, str) or not s.strip():
                self.err(f"{where}.skills[{j}]",
                         "each entry must be a non-empty skill name",
                         "name the skill directory, e.g. `- grounded_analysis`",
                         path + ("skills", j))
        if not skills:
            self.warn(
                f"{where}.skills",
                "empty list names nothing — the agent runs with ONLY "
                f"`{ALWAYS_INJECTED_SKILL}` (which create_filtered_workspace "
                "adds unconditionally) and every `always: true` skill it "
                "carries is dropped",
                "omit `skills:` entirely to load all of them, or name the ones "
                "this workflow needs",
                path + ("skills",),
            )

    # -- team -----------------------------------------------------------
    def _lint_team(self, data: dict, role_names: set[str]) -> None:
        if "team" not in data or data["team"] is None:
            return
        team = data["team"]
        if not isinstance(team, list):
            # ``Workflow.team`` is a STRING (team.md contents). The YAML key of
            # the same name is a list that becomes ``team_roster``. Same word,
            # two different things.
            self.err("team",
                     f"must be a LIST of `- role: <name>` entries, got "
                     f"{type(team).__name__}. (Confusingly, `Workflow.team` on "
                     "the model is the text of team.md; the YAML `team:` key "
                     "lands in `team_roster`)",
                     "use `team:\\n  - role: analyst`", ("team",))
            return
        for i, m in enumerate(team):
            path = ("team", i)
            if not isinstance(m, dict):
                self.err(f"team[{i}]",
                         f"must be a mapping `- role: <name>`, got "
                         f"{type(m).__name__}",
                         "use `- role: analyst`", path)
                continue
            self._unknown_keys(m, TEAM_MEMBER_KEYS, f"team[{i}]", path)
            role = m.get("role")
            if not isinstance(role, str) or not role.strip():
                # The loader does ``t["role"]`` — a missing key is a KeyError.
                self.err(f"team[{i}].role",
                         "required key `role` is missing or not a string — the "
                         "loader indexes it directly, so this is a KeyError",
                         "use `- role: analyst`", path)
            elif role_names and role not in role_names:
                self.warn(f"team[{i}].role",
                          f"'{role}' is not defined in `roles:` — the roster is "
                          "display-only (it feeds the UI team panel), so this "
                          "will not fail the run, it will just show a member "
                          "no step can use",
                          f"add a `roles:` entry for '{role}', or drop it from "
                          "`team:`", path + ("role",))

    # -- steps ----------------------------------------------------------
    def _lint_steps(self, data: dict, role_names: set[str]) -> None:
        steps = data.get("steps")
        if steps is None:
            self.err("steps", "no `steps:` section — the workflow has nothing "
                              "to run",
                     "add a `steps:` list with at least one step")
            return
        if not isinstance(steps, list):
            self.err("steps",
                     f"must be a list, got {type(steps).__name__}",
                     "use `steps:\\n  - key: analyze\\n    role: analyst\\n"
                     "    prompt: steps/analyze.md`",
                     ("steps",))
            return
        if not steps:
            self.err("steps", "empty — a run created from this workflow has no "
                              "runnable step and completes immediately",
                     "add at least one step", ("steps",))
            return

        keys: list[str] = []
        fanout_steps: list[str] = []
        dependents: dict[str, list[str]] = {}
        parsed: list[dict] = []

        by_key = {x.get("key"): x for x in steps
                  if isinstance(x, dict) and isinstance(x.get("key"), str)}
        for i, s in enumerate(steps):
            path = ("steps", i)
            where = f"steps[{i}]"
            if not isinstance(s, dict):
                self.err(where, f"must be a mapping, got {type(s).__name__}",
                         "each step is `- key: … / role: … / prompt: …`", path)
                continue
            self._unknown_keys(s, STEP_KEYS, where, path,
                               elsewhere={k: "`roles[]`"
                                          for k in ROLE_KEYS - STEP_KEYS}
                               | {k: "`per_item_steps[]`"
                                  for k in TEMPLATE_KEYS - STEP_KEYS})

            key = self._require_str(s, "key", where, path)
            if key:
                where = f"steps[{key}]"
                if key in keys:
                    self.err(f"{where}.key",
                             f"duplicate step key '{key}' — the engine keys "
                             "steps by name and only one of these can ever be "
                             "addressed; deps pointing here are ambiguous",
                             "give each step a distinct key", path + ("key",))
                keys.append(key)
                if key.startswith("story:"):
                    self.err(f"{where}.key",
                             "a step key may not start with `story:` — that "
                             "prefix is reserved for the per-item steps the "
                             "engine materializes, and the scheduler routes on "
                             "it",
                             "rename the step", path + ("key",))
                elif not _STEP_KEY_RE.match(key):
                    self.warn(f"{where}.key",
                              f"'{key}' contains characters outside "
                              "[A-Za-z0-9_.-]; step keys become directory names "
                              "in the run output and forensics trees, and ':' "
                              "collides with the story-key format",
                              "use letters, digits, `_`, `-` or `.`",
                              path + ("key",))

            stype = self._lint_step_type(s, where, path)
            self._lint_step_role(s, stype, where, path, role_names)
            self._lint_step_prompt_and_command(s, stype, where, path)
            self._lint_step_scalars(s, where, path)
            self._lint_step_routing(s, stype, where, path, by_key)
            self._lint_step_fanout(s, stype, where, path, role_names)

            deps = s.get("deps") or []
            if deps and not isinstance(deps, list):
                self.err(f"{where}.deps",
                         f"must be a list of step keys, got "
                         f"{type(deps).__name__}",
                         "use `deps: [analyze]`", path + ("deps",))
                deps = []
            for d in deps if isinstance(deps, list) else []:
                if isinstance(d, str):
                    dependents.setdefault(d, []).append(key or where)

            if s.get("per_item_steps"):
                fanout_steps.append(key or where)

            parsed.append({"raw": s, "path": path, "where": where,
                           "key": key, "type": stype})

        self._lint_single_fanout(fanout_steps, parsed)
        self._lint_artifact_gate(parsed, dependents)
        self._lint_per_item_deps(parsed, keys)
        self._lint_shared_dir_flow(parsed)

    #: `{{output_dir}}/<something>` - a file in the run's ONE shared
    #: artifact directory, referenced from a prompt or a command.
    _SHARED_REF_RE = re.compile(
        r"\{\{\s*output_dir\s*\}\}[/\\]([A-Za-z0-9_.{}\-/\\]+)")

    def _step_texts(self, s: dict) -> list:
        """(label, text) for a step's command and its prompt file."""
        out = []
        cmd = s.get("command")
        if isinstance(cmd, str) and cmd.strip():
            out.append(("`command:`", cmd))
        p = s.get("prompt")
        if isinstance(p, str) and p.strip() and self.base is not None:
            try:
                out.append((f"prompt file `{p}`",
                            (self.base / p).read_text(encoding="utf-8",
                                                      errors="replace")))
            except OSError:
                pass
        return out

    def _lint_shared_dir_flow(self, parsed: list) -> None:
        """Two silent shapes in the ONE shared artifact directory.

        Every step of a run renders the same `{{output_dir}}`; `deps:` is
        the only thing that orders them. So (1) a step that READS a file
        another step is gated on, without depending on that step, can run
        first under a parallel driver - it fails on a missing file, is
        retried, and passes: a run that reads green and was wrong once.
        (2) Every item of a fan-out renders the same directory, so a
        per-item prompt naming a fixed `{{output_dir}}/<file>` with no
        `{{story_id}}` in the path is overwritten by each item. Both found
        by a novice engineer on their first workflow; neither errors at
        runtime.
        """
        by_key = {e["key"]: e for e in parsed if e.get("key")}
        producers: dict = {}
        for e in parsed:
            for a in (e["raw"].get("requires_artifacts") or []):
                if isinstance(a, str) and e.get("key"):
                    producers.setdefault(a, e["key"])

        def _upstream(k: str, seen: set) -> set:
            for d in (by_key.get(k, {}).get("raw", {}).get("deps") or []):
                if isinstance(d, str) and d not in seen:
                    seen.add(d)
                    _upstream(d, seen)
            return seen

        for e in parsed:
            key = e.get("key")
            if not key:
                continue
            ups = _upstream(key, set())
            for label, text in self._step_texts(e["raw"]):
                for ref in dict.fromkeys(self._SHARED_REF_RE.findall(text)):
                    producer = producers.get(ref)
                    if producer is None or producer == key or producer in ups:
                        continue
                    if key in _upstream(producer, set()):
                        continue   # the producer is DOWNSTREAM - not a read
                    self.warn(
                        f"{e['where']}",
                        f"{label} names `{{{{output_dir}}}}/{ref}`, which "
                        f"step `{producer}` produces (its "
                        f"`requires_artifacts`), but this step does not "
                        f"depend on `{producer}` - under a parallel driver "
                        f"it can run first and fail on a missing file",
                        f"add `{producer}` to this step's `deps:`",
                        e["path"] + ("deps",))
            pis = e["raw"].get("per_item_steps")
            if not isinstance(pis, list):
                continue
            for i, t in enumerate(pis):
                if not isinstance(t, dict):
                    continue
                for label, text in self._step_texts(t):
                    for ref in dict.fromkeys(self._SHARED_REF_RE.findall(text)):
                        if any(v in ref for v in _PER_ITEM_VARS) or ref in producers:
                            continue
                        self.warn(
                            f"{e['where']}.per_item_steps[{i}]",
                            f"{label} names `{{{{output_dir}}}}/{ref}` with "
                            f"nothing per-item in the path - every "
                            f"fan-out item renders the same output_dir, so "
                            f"a fixed filename is overwritten by each item "
                            f"and only the last survives",
                            "put `{{story_id}}` or `{{step_key_safe}}` in the "
                            "filename, e.g. `{{output_dir}}/reason_{{story_id}}.md`",
                            e["path"] + ("per_item_steps", i))

    def _lint_step_type(self, s: dict, where: str, path: tuple) -> str:
        stype = s.get("type", "normal")
        if stype is None:
            stype = "normal"
        if not isinstance(stype, str) or stype not in STEP_TYPES:
            self.err(f"{where}.type",
                     f"must be one of {list(STEP_TYPES)}, got {stype!r} — "
                     "`Step.type` is a Literal and pydantic rejects the whole "
                     "workflow",
                     "use `type: exec` for a command, `type: loop` for a "
                     "fan-out, or omit it for a normal agent step",
                     path + ("type",))
            return "normal"
        return stype

    def _lint_step_routing(self, s: dict, stype: str, where: str, path: tuple,
                           by_key: dict) -> None:
        """`type: route` + `routes:` and `on_fail:` - the two fenced turns.

        A route is a switch over DECLARED targets, so every target must exist,
        and each must depend on the route step or it runs before the choice
        is made. `on_fail.reset` names producers to re-run; a target that is
        not upstream of this step is almost certainly a mistake, since
        resetting it changes nothing this step consumes.
        """
        key = s.get("key")
        routes = s.get("routes")
        on_fail = s.get("on_fail")

        if stype == "route":
            if not isinstance(routes, list) or not routes:
                self.err(f"{where}.routes",
                         "`type: route` needs a non-empty `routes:` list - the "
                         "declared targets its ROUTE_JSON may choose from; with "
                         "none, the tool has nothing it is allowed to choose",
                         "add `routes: [<step>, <step>]`", path + ("routes",))
            else:
                for r in routes:
                    if not isinstance(r, str) or r not in by_key:
                        self.err(f"{where}.routes",
                                 f"route target {r!r} is not a step in this "
                                 "workflow - a route chooses among DECLARED "
                                 "steps, it cannot invent one",
                                 "name an existing step key", path + ("routes",))
                        continue
                    if r == key:
                        self.err(f"{where}.routes",
                                 "a route step cannot route to itself",
                                 "remove it from `routes:`", path + ("routes",))
                        continue
                    tdeps = by_key[r].get("deps") or []
                    if key not in tdeps:
                        self.warn(f"{where}.routes",
                                  f"route target '{r}' does not list '{key}' in "
                                  "its `deps:`, so it becomes runnable BEFORE the "
                                  "route decides - the choice cannot close a step "
                                  "that already started",
                                  f"add `{key}` to {r}'s `deps:`", path + ("routes",))
        elif routes:
            self.err(f"{where}.routes",
                     f"`routes:` only means something on a `type: route` step; "
                     f"on `type: {stype}` it is parsed and never read",
                     "set `type: route`, or remove `routes:`", path + ("routes",))

        if on_fail is None:
            return
        if not isinstance(on_fail, dict):
            self.err(f"{where}.on_fail", "must be a mapping",
                     "use `on_fail:\\n  reset: [<step>]\\n  feedback: critique.md`",
                     path + ("on_fail",))
            return
        unknown = sorted(set(on_fail) - ON_FAIL_KEYS)
        if unknown:
            self.err(f"{where}.on_fail",
                     f"unknown key(s) {unknown} - allowed: {sorted(ON_FAIL_KEYS)}",
                     "fix the spelling", path + ("on_fail",))
        reset = on_fail.get("reset")
        if isinstance(reset, str) and reset.strip():
            reset = [reset]          # the loader accepts the bare form too
        if not isinstance(reset, list) or not reset:
            self.err(f"{where}.on_fail.reset",
                     "`on_fail` needs a non-empty `reset:` list - the upstream "
                     "steps to re-run when this step fails",
                     "add `reset: [<producer step>]`", path + ("on_fail",))
        else:
            anc, frontier = set(), list(s.get("deps") or [])
            while frontier:
                d = frontier.pop()
                if d in anc or d not in by_key:
                    continue
                anc.add(d)
                frontier.extend(by_key[d].get("deps") or [])
            for t in reset:
                if not isinstance(t, str) or t not in by_key:
                    self.err(f"{where}.on_fail.reset",
                             f"reset target {t!r} is not a step in this workflow",
                             "name an existing step key", path + ("on_fail",))
                elif t == key:
                    self.err(f"{where}.on_fail.reset",
                             "a step cannot reset itself - a failed attempt "
                             "already retries under `max_attempts`",
                             "name the producer instead", path + ("on_fail",))
                elif t not in anc:
                    self.warn(f"{where}.on_fail.reset",
                              f"'{t}' is not upstream of '{key}', so re-running "
                              "it changes nothing this step consumes",
                              "reset a step this one depends on (directly or "
                              "through others)", path + ("on_fail",))
        fb = on_fail.get("feedback")
        if fb is not None and (not isinstance(fb, str) or not fb.strip()):
            self.err(f"{where}.on_fail.feedback",
                     "`feedback:` must be a filename (in the shared artifact "
                     "dir) or be omitted",
                     "e.g. `feedback: critique.md`", path + ("on_fail",))

    def _lint_step_role(self, s: dict, stype: str, where: str, path: tuple,
                        role_names: set[str]) -> None:
        role = s.get("role")
        if role is None:
            if stype not in _CMD_TYPES:
                # The loader does ``s["role"]`` for non-exec steps — KeyError.
                self.err(f"{where}.role",
                         "required key `role` is missing. Only `type: exec` "
                         "steps may omit it (they run a command, so their role "
                         "defaults to 'system' and is attribution-only)",
                         "add `role: <a name from roles:>`", path)
            return
        if not isinstance(role, str) or not role.strip():
            self.err(f"{where}.role", "must be a non-empty string",
                     "name a role defined under `roles:`", path + ("role",))
            return
        if stype in _CMD_TYPES and role != "system" and role not in role_names:
            self.warn(f"{where}.role",
                      f"exec steps spawn no agent, so '{role}' is attribution "
                      "only — validate_workflow skips exec steps and will not "
                      "tell you this name does not exist",
                      "omit `role:` (it defaults to 'system') or name a defined "
                      "role", path + ("role",))
        # non-exec undefined roles are reported by collect_workflow_errors

    def _lint_step_prompt_and_command(self, s: dict, stype: str, where: str,
                                      path: tuple) -> None:
        prompt = s.get("prompt")
        command = s.get("command")

        if stype in _CMD_TYPES:
            if not isinstance(command, str) or not command.strip():
                self.err(f"{where}.command",
                         "`type: exec` requires a non-empty `command:` — the "
                         "loader raises ValueError without it",
                         'add `command: >-\\n  my-tool --out {{output_dir}}`',
                         path)
            if prompt:
                self.warn(f"{where}.prompt",
                          "an exec step runs `command:` and never sends the "
                          "prompt to a model — this file is loaded and thrown "
                          "away",
                          "delete `prompt:`, or change the step to "
                          "`type: normal` if you meant an agent to do this",
                          path + ("prompt",))
        else:
            if command:
                self.warn(f"{where}.command",
                          f"`command:` is only executed for `type: exec` steps; "
                          f"this step is `type: {stype}` so the command never "
                          "runs",
                          "add `type: exec`, or delete `command:`",
                          path + ("command",))
            if not isinstance(prompt, str) or not prompt.strip():
                self.err(f"{where}.prompt",
                         f"a `type: {stype}` step needs a `prompt:` — without "
                         "one the agent is spawned with only the step wrapper "
                         "and no instructions",
                         "add `prompt: steps/<name>.md`", path)

        if isinstance(prompt, str) and prompt.strip():
            self._check_prompt_file(f"{where}.prompt", prompt,
                                    path + ("prompt",))
        if isinstance(command, str) and command.strip() and stype in _CMD_TYPES:
            self._lint_unquoted_placeholders(where, command, path)
            self._check_template_text(f"{where}.command", "`command:`",
                                      command, path + ("command",))
        if command is not None and not isinstance(command, str):
            self.err(f"{where}.command",
                     f"must be a string, got {type(command).__name__}",
                     "use a `>-` folded block for multi-line commands",
                     path + ("command",))

    def _lint_step_scalars(self, s: dict, where: str, path: tuple) -> None:
        ma = s.get("max_attempts")
        if ma is not None:
            if isinstance(ma, bool) or not isinstance(ma, int):
                self.err(f"{where}.max_attempts",
                         f"must be an integer, got {type(ma).__name__}",
                         "use `max_attempts: 2`", path + ("max_attempts",))
            elif ma < 1:
                self.err(f"{where}.max_attempts",
                         f"must be >= 1, got {ma} — a step that may never be "
                         "attempted can never complete",
                         "use `max_attempts: 2`", path + ("max_attempts",))
        fs = s.get("fresh_session")
        if fs is not None and not isinstance(fs, bool):
            # The loader does bool(...), so "false" (a string) becomes True.
            self.err(f"{where}.fresh_session",
                     f"must be true or false, got {type(fs).__name__}. The "
                     "loader wraps it in bool(), so the string \"false\" "
                     "becomes True and the session is recreated anyway",
                     "use `fresh_session: false` unquoted",
                     path + ("fresh_session",))
        elif fs is False:
            # Parsed onto the model and written into the step's meta_json,
            # then read by nothing. The session key is
            # ``iof:<run_id>:<step_key>`` unconditionally
            # (cli_orchestration.py), so every step already gets its own
            # session and this flag cannot make one persist.
            self.warn(f"{where}.fresh_session",
                      "`fresh_session: false` has no effect today — it is "
                      "recorded in the step's meta_json and never read. The "
                      "session key is `iof:<run_id>:<step_key>` regardless, "
                      "so the step gets a fresh session either way",
                      "delete it, and do not rely on session reuse between "
                      "steps", path + ("fresh_session",))
        ra = s.get("requires_artifacts")
        if ra is not None:
            if not isinstance(ra, list):
                self.err(f"{where}.requires_artifacts",
                         f"must be a list of file names, got "
                         f"{type(ra).__name__}",
                         "use `requires_artifacts: [report.md]`",
                         path + ("requires_artifacts",))
            else:
                for j, a in enumerate(ra):
                    if not isinstance(a, str) or not a.strip():
                        self.err(f"{where}.requires_artifacts[{j}]",
                                 "each entry must be a non-empty file name "
                                 "relative to the step output dir",
                                 "e.g. `- intelligence_report.md`",
                                 path + ("requires_artifacts", j))
        if "loop_source_key" in s and s["loop_source_key"] is not None:
            self.warn(f"{where}.loop_source_key",
                      "`loop_source_key` is parsed onto the model and then "
                      "read by nothing — the fan-out source is the step's own "
                      "STORIES_JSON (or `stories_from` for an exec step). It "
                      "has no effect",
                      "delete it", path + ("loop_source_key",))

    def _lint_step_fanout(self, s: dict, stype: str, where: str, path: tuple,
                          role_names: set[str]) -> None:
        pis = s.get("per_item_steps")
        stories_from = s.get("stories_from")

        if stories_from is not None:
            if not isinstance(stories_from, str) or not stories_from.strip():
                self.err(f"{where}.stories_from",
                         "must be the name of a JSON file the command writes "
                         "into the step output dir",
                         "e.g. `stories_from: batch_manifest.json`",
                         path + ("stories_from",))
            elif stype not in _CMD_TYPES:
                # cli_orchestration only reads stories_from inside the exec
                # branch (`if rc == 0 and step_def.stories_from`), and the
                # fail-closed stories gate only counts it for exec steps.
                self.err(f"{where}.stories_from",
                         f"`stories_from` is only read for `type: exec` steps; "
                         f"this step is `type: {stype}`, so the manifest is "
                         "never opened and no stories are produced",
                         "add `type: exec` with the `command:` that writes the "
                         "manifest, or drop `stories_from` and have the agent "
                         "emit STORIES_JSON with `type: loop`",
                         path + ("stories_from",))
            elif not pis:
                # the manifest's items are recorded and nothing fans out over
                # them: 1,000 stories `pending` under a `done` run (novice,
                # round 6)
                self.warn(f"{where}.stories_from",
                          "`stories_from` without `per_item_steps` fans out over "
                          "nothing - the manifest's items are only recorded, and a "
                          "run that never touches them still reads done",
                          "add `per_item_steps:` (agent steps run once per item), or "
                          "drop `stories_from` when the tool processes its own items",
                          path + ("stories_from",))

        if stype == "loop" and not pis:
            self.err(f"{where}.per_item_steps",
                     "`type: loop` with no `per_item_steps:` — the step will "
                     "be required to emit STORIES_JSON (the fail-closed "
                     "stories gate flips it to failed without one) and then "
                     "materialize nothing from it",
                     "add `per_item_steps:` with at least one "
                     "`- key_suffix: … / role: … / prompt: …`, or use "
                     "`type: normal`", path)

        if pis is None:
            return
        if not isinstance(pis, list):
            self.err(f"{where}.per_item_steps",
                     f"must be a list, got {type(pis).__name__}",
                     "use `per_item_steps:\\n  - key_suffix: process\\n"
                     "    role: analyst\\n    prompt: steps/process.md`",
                     path + ("per_item_steps",))
            return
        if pis and stype not in ("loop", "exec"):
            self.err(f"{where}.per_item_steps",
                     f"a `type: {stype}` step never fans out — the engine "
                     "materializes per-item steps only from a `type: loop` "
                     "step's STORIES_JSON or a `type: exec` step's "
                     "`stories_from` manifest, so these templates are "
                     "unreachable",
                     "set `type: loop` (agent emits STORIES_JSON) or "
                     "`type: exec` with `stories_from:`",
                     path + ("per_item_steps",))
        if pis and stype == "exec" and not stories_from:
            self.err(f"{where}.per_item_steps",
                     "an exec step fans out from the `stories_from:` manifest; "
                     "without it the step produces no STORIES_JSON and these "
                     "templates never materialize",
                     "add `stories_from: <manifest>.json` naming the JSON file "
                     "the command writes", path + ("per_item_steps",))

        suffixes: set[str] = set()
        for j, t in enumerate(pis):
            tpath = path + ("per_item_steps", j)
            twhere = f"{where}.per_item_steps[{j}]"
            if not isinstance(t, dict):
                self.err(twhere, f"must be a mapping, got {type(t).__name__}",
                         "each template is `- key_suffix: … / role: … / "
                         "prompt: …`", tpath)
                continue
            self._unknown_keys(t, TEMPLATE_KEYS, twhere, tpath,
                               elsewhere={k: "`steps[]`"
                                          for k in STEP_KEYS - TEMPLATE_KEYS})
            suffix = self._require_str(t, "key_suffix", twhere, tpath)
            if suffix:
                twhere = f"{where}.per_item_steps[{suffix}]"
                if ":" in suffix:
                    self.err(f"{twhere}.key_suffix",
                             "may not contain ':' — the materialized key is "
                             "`story:<id>:<key_suffix>` and the scheduler "
                             "recovers the suffix with split(':')[-1]",
                             "use letters, digits and underscores",
                             tpath + ("key_suffix",))
                if suffix in suffixes:
                    self.err(f"{twhere}.key_suffix",
                             f"duplicate key_suffix '{suffix}' — both templates "
                             "materialize the same `story:<id>:{suffix}` key "
                             "and the scheduler resolves only the first",
                             "give each template a distinct suffix",
                             tpath + ("key_suffix",))
                suffixes.add(suffix)
            trole = self._require_str(t, "role", twhere, tpath)
            if trole and role_names and trole not in role_names:
                # collect_workflow_errors never sees these — it walks
                # workflow.steps, and per-item templates are not steps yet.
                self.err(f"{twhere}.role",
                         f"role '{trole}' is not defined under `roles:`. "
                         "Nothing else checks this: the graph validator only "
                         "walks `steps`, and these templates do not become "
                         "steps until a run fans them out — so the failure "
                         "lands mid-run, not at load",
                         f"add a `roles:` entry for '{trole}', or use a defined "
                         "role", tpath + ("role",))
            # The loader does ``base / t["prompt"]`` with no ``.get`` — a
            # per-item template WITHOUT a prompt is a KeyError, even though
            # StepTemplate.prompt defaults to "".
            tprompt = self._require_str(t, "prompt", twhere, tpath)
            if tprompt:
                self._check_prompt_file(f"{twhere}.prompt", tprompt,
                                        tpath + ("prompt",))
            tma = t.get("max_attempts")
            if tma is not None and (isinstance(tma, bool)
                                    or not isinstance(tma, int) or tma < 1):
                self.err(f"{twhere}.max_attempts",
                         "must be an integer >= 1",
                         "use `max_attempts: 2`", tpath + ("max_attempts",))
            tdeps = t.get("deps")
            if tdeps is not None and not isinstance(tdeps, list):
                self.err(f"{twhere}.deps",
                         f"must be a list, got {type(tdeps).__name__}",
                         "use `deps: [prepare]`", tpath + ("deps",))

    # -- cross-step -----------------------------------------------------
    def _lint_single_fanout(self, fanout_steps: list[str],
                            parsed: list[dict]) -> None:
        """Two fan-out anchors is a silent mis-wire.

        ``scheduler.render_step_prompt`` resolves a ``story:<id>:<suffix>``
        key with ``next((s for s in workflow.steps if s.per_item_steps), None)``
        — the FIRST step carrying templates, whichever story it belongs to. A
        second anchor's templates are unreachable, and its stories render the
        first anchor's prompts (or fail with "No template found for suffix").
        """
        if len(fanout_steps) < 2:
            return
        for entry in parsed:
            if entry["key"] in fanout_steps[1:]:
                self.err(
                    f"{entry['where']}.per_item_steps",
                    f"this is the {fanout_steps.index(entry['key']) + 1}nd step "
                    f"carrying `per_item_steps:` (the first is "
                    f"'{fanout_steps[0]}'). The scheduler resolves per-item "
                    "prompts from the FIRST such step it finds, so these "
                    "templates are unreachable and this step's stories will "
                    "render the wrong prompt or fail with 'No template found "
                    "for suffix'",
                    "a workflow can have only one fan-out anchor — split the "
                    "second into its own workflow",
                    entry["path"] + ("per_item_steps",),
                )

    def _lint_artifact_gate(self, parsed: list[dict],
                            dependents: dict[str, list[str]]) -> None:
        """The gate that stops a fabricated handoff.

        ``_finalize_step`` flips a step to failed when a declared artifact is
        missing or empty, even on ``STATUS: done``. A step whose output another
        step consumes and which declares nothing has no such protection: the
        agent can report success having written nothing, and the downstream
        step composes its section from a file that does not exist.

        THE PREMISE IS A CLAIM, SO IT APPLIES TO AGENTS (round 9, S3-1). The
        danger is a step SAYING `STATUS: done` without having done it. An exec
        step makes no such claim - round 7 settled that its exit code is the
        only verdict, and shields any protocol line a tool prints inside its
        own stdout - so warning about every exec step with a successor flagged
        a valid all-exec pipeline at every join. It still earns the warning
        when a command exits 0 and silently writes nothing, but only where
        there is a filesystem handoff to break: a downstream step that names
        something under ``{{output_dir}}``. Communicating through a database,
        which is what the pharma pipelines' `prepare` steps do, is not a
        handoff this gate can protect.
        """
        # Which files anyone reads out of the run's shared artifact directory.
        read_refs: set[str] = set()
        for e in parsed:
            for _label, text in self._step_texts(e["raw"]):
                read_refs.update(self._SHARED_REF_RE.findall(text))
            for t in (e["raw"].get("per_item_steps") or []):
                if isinstance(t, dict):
                    for _label, text in self._step_texts(t):
                        read_refs.update(self._SHARED_REF_RE.findall(text))

        for entry in parsed:
            key = entry["key"]
            if not key or not dependents.get(key):
                continue
            if entry["raw"].get("requires_artifacts"):
                continue
            if entry.get("type") in ("exec", "route") and not read_refs:
                # No step names a file in the shared directory, so there is
                # no fabricated handoff available to warn about.
                continue
            consumers = ", ".join(sorted(set(dependents[key])))
            claim = ("On `STATUS: done` with no file"
                     if entry.get("type") not in ("exec", "route")
                     else "On exit 0 with no file")
            self.warn(
                f"{entry['where']}.requires_artifacts",
                f"'{key}' hands off to {consumers} but declares no "
                "`requires_artifacts:` — nothing verifies it wrote anything. "
                f"{claim}, the run advances and the "
                "downstream step composes from a file that was never written",
                "declare the deliverable, e.g. "
                "`requires_artifacts: [findings.md]`",
                entry["path"],
            )

    def _lint_per_item_deps(self, parsed: list[dict],
                            step_keys: list[str]) -> None:
        """A per-item dep is either a sibling suffix or a real step key.

        ``store.ensure_story_steps`` rewrites a dep that matches a sibling
        ``key_suffix`` into ``story:<id>:<dep>`` and otherwise stores it
        verbatim. A dep that is neither leaves the story step waiting on a
        key that will never exist, so it never becomes runnable.
        """
        for entry in parsed:
            pis = entry["raw"].get("per_item_steps")
            if not isinstance(pis, list):
                continue
            suffixes = {t.get("key_suffix") for t in pis if isinstance(t, dict)}
            for j, t in enumerate(pis):
                if not isinstance(t, dict):
                    continue
                deps = t.get("deps")
                if not isinstance(deps, list):
                    continue
                sfx = t.get("key_suffix") or j
                for d in deps:
                    if not isinstance(d, str) or d in suffixes or d in step_keys:
                        continue
                    self.err(
                        f"{entry['where']}.per_item_steps[{sfx}].deps",
                        f"'{d}' is neither a sibling `key_suffix` nor a step "
                        "key. ensure_story_steps rewrites sibling suffixes to "
                        "`story:<id>:<suffix>` and stores anything else "
                        "verbatim — so this story step waits forever on a key "
                        "that is never created",
                        f"use a sibling key_suffix ({sorted(s for s in suffixes if s)}) "
                        f"or a step key ({sorted(step_keys)})",
                        entry["path"] + ("per_item_steps", j, "deps"),
                    )


# ── graph checks (delegated) ────────────────────────────────────────────

def _skeleton_workflow(data: dict):
    """A ``Workflow`` carrying only what the graph checks read.

    ``collect_workflow_errors`` looks at step keys, step roles, step types and
    deps — nothing else. Building a skeleton lets the graph rules stay in
    exactly one place (``workflow_loader``) instead of being reimplemented
    here against raw dicts, and it works even when the prompt files the real
    loader would read are missing.
    """
    from ioagentfarm.engine.models import Role, Step, Workflow

    roles = {}
    for r in data.get("roles") or []:
        if isinstance(r, dict) and isinstance(r.get("name"), str):
            roles[r["name"]] = Role(name=r["name"], prompt="")

    steps = []
    seen: set[str] = set()
    for s in data.get("steps") or []:
        if not isinstance(s, dict) or not isinstance(s.get("key"), str):
            continue
        if s["key"] in seen:
            continue          # duplicate keys are reported by _lint_steps
        seen.add(s["key"])
        stype = s.get("type") or "normal"
        if stype not in STEP_TYPES:
            stype = "normal"
        role = s.get("role")
        if not isinstance(role, str) or not role.strip():
            if stype not in _CMD_TYPES:
                continue                  # already reported as a missing key
            role = "system"
        deps = [d for d in (s.get("deps") or []) if isinstance(d, str)]
        steps.append(Step(key=s["key"], role=role, type=stype, deps=deps))

    name = data.get("name") if isinstance(data.get("name"), str) else "<unnamed>"
    return Workflow(name=name, roles=roles, steps=steps)


def _graph_findings(data: dict, lines: dict) -> list[Finding]:
    from ioagentfarm.engine.workflow_loader import collect_workflow_errors

    try:
        wf = _skeleton_workflow(data)
    except Exception as exc:                       # pragma: no cover - defensive
        return [Finding(ERROR, "<workflow>",
                        f"could not build the step graph: {exc}",
                        "fix the errors above and re-run")]

    out: list[Finding] = []
    key_line = {}
    for i, s in enumerate(data.get("steps") or []):
        if isinstance(s, dict) and isinstance(s.get("key"), str):
            key_line[s["key"]] = lines.get(("steps", i))
    for msg in collect_workflow_errors(wf):
        # Attribute the finding to the step the message is ABOUT — the first
        # quoted name. Scanning for any known key instead matches whichever
        # step happens to appear first in the "Available steps: [...]" tail,
        # which is alphabetical and almost never the offender.
        line = None
        subject = re.search(r"'([^']+)'", msg)
        if subject:
            line = key_line.get(subject.group(1))
        out.append(Finding(
            ERROR, "steps", msg,
            "point `deps:` at a step that exists, define the role under "
            "`roles:`, or break the cycle",
            line,
        ))
    return out


def _unused_role_findings(data: dict, lines: dict) -> list[Finding]:
    used = set()
    for s in data.get("steps") or []:
        if not isinstance(s, dict):
            continue
        if isinstance(s.get("role"), str):
            used.add(s["role"])
        elif s.get("type") in _CMD_TYPES:
            # MIRROR THE LOADER. An exec step that declares no role gets the
            # placeholder `system` (`workflow_loader`: role=s.get("role") or
            # ("system" if type == "exec" ...)). Not mirroring it made every
            # all-exec pipeline warn that its one declared role was unused -
            # a warning on the shape a ported deterministic workflow always
            # has, which teaches authors to ignore the linter.
            used.add("system")
        for t in s.get("per_item_steps") or []:
            if isinstance(t, dict) and isinstance(t.get("role"), str):
                used.add(t["role"])
    out = []
    for i, r in enumerate(data.get("roles") or []):
        if not isinstance(r, dict) or not isinstance(r.get("name"), str):
            continue
        if r["name"] in used:
            continue
        out.append(Finding(
            WARNING, f"roles[{r['name']}]",
            f"role '{r['name']}' is defined but no step uses it — its prompt "
            "file is read at load and then discarded",
            "delete the role, or give it a step",
            lines.get(("roles", i)),
        ))
    return out


# ── public API ──────────────────────────────────────────────────────────

def lint_workflow_text(text: str, base: Path | None = None,
                       path: str = "workflow.yaml",
                       workspace: str | None = None) -> LintResult:
    """Lint YAML source. *base* is the workflow dir, for prompt-file checks;
    *workspace* selects whose ``models.yaml`` the model check reads."""
    try:
        data = yaml.safe_load(text)
        node = yaml.compose(text)
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        return LintResult(path, [Finding(
            ERROR, "<file>", f"YAML syntax error: {exc}",
            "fix the indentation or quoting at the marked position",
            (mark.line + 1) if mark is not None else None,
        )])

    linter = _Linter(base, workspace)
    linter.lines = _line_index(node) if node is not None else {}
    if isinstance(data, dict) and isinstance(data.get("vars"), dict):
        linter._declared_vars = {str(k) for k in data["vars"]}
    linter.lint(data)

    findings = list(linter.findings)
    if isinstance(data, dict):
        findings.extend(_graph_findings(data, linter.lines))
        findings.extend(_unused_role_findings(data, linter.lines))

    name = data.get("name", "") if isinstance(data, dict) else ""
    findings.sort(key=lambda f: (f.line if f.line is not None else 0,
                                 0 if f.severity == ERROR else 1))
    return LintResult(path, findings, name=name if isinstance(name, str) else "")


def lint_workflow_dir(base: Path, workspace: str | None = None) -> LintResult:
    """Lint the ``workflow.yaml`` in *base* (a real workflow directory)."""
    base = Path(base)
    wf_yaml = base / "workflow.yaml"
    if not wf_yaml.is_file():
        return LintResult(str(wf_yaml), [Finding(
            ERROR, "<file>", f"no workflow.yaml in {base}",
            "point the linter at a directory containing workflow.yaml",
        )])
    return lint_workflow_text(
        wf_yaml.read_text(encoding="utf-8"), base=base, path=str(wf_yaml),
        workspace=workspace,
    )


def resolve_workflow_dir(target: str, workspace: str | None = None) -> Path | None:
    """A path or a workflow name -> a real directory to lint.

    Names resolve through the same precedence the loader uses (tenant override
    tree, then the flat one, then pack/bundled sources), so the linter reads
    the tree that would actually run. A pack source that is not a real
    directory — a zipped wheel — is materialized into a temp dir first, since
    the prompt-file checks need a filesystem.
    """
    from ioagentfarm.engine.workflow_loader import WorkflowLoader

    p = Path(target)
    if p.is_dir() and (p / "workflow.yaml").is_file():
        return p
    if p.name == "workflow.yaml" and p.is_file():
        return p.parent
    if p.exists() and p.is_file():
        return None

    loader = WorkflowLoader()
    # SAME PRECEDENCE AS THE RUNTIME: the installed pack first, in every
    # mode; a staged copy only for a name no pack provides (unpromoted,
    # Studio-authored). Resolving a different copy here than `run` does would
    # make the linter answer about a file that never executes - which is how
    # a `requires_artifact` typo once reported "0 error(s)" from a staged
    # copy while the reader's own file, the one that ran, carried it.
    base = loader._workflow_dir(target)
    if base is None:
        inst = loader._unpromoted_dir(target, workspace)
        return inst if inst is not None else None
    real = Path(str(base))
    if real.is_dir() and (real / "workflow.yaml").is_file():
        return real
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix=f"iof-lint-{target}-"))
    loader._copy_traversable(base, tmp)
    return tmp


def lint_workflow(target: str, workspace: str | None = None) -> LintResult:
    """Lint by name or by path."""
    base = resolve_workflow_dir(target, workspace)
    if base is None:
        return LintResult(target, [Finding(
            ERROR, "<file>",
            f"no workflow named '{target}', and no workflow.yaml at that path",
            "run `aicore list-workflows`, or pass a directory containing "
            "workflow.yaml",
        )])
    return lint_workflow_dir(base, workspace)
