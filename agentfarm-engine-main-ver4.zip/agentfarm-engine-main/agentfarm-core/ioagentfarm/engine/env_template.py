"""Where a credential VALUE goes, and how the person is told to put it there.

THE RULE THIS MODULE IMPLEMENTS: a declaration carries a ``${VAR}``
REFERENCE, and the value is typed by a PERSON into a file the assistant never
writes. Nothing here ever accepts, stores or prints a value.

Two files, and the difference matters:

* ``<pack>/.env.example`` - IN the repository, committed, values never
  present. It documents what an operator must supply, so a teammate cloning
  the repo can see what the pack needs without running anything.
* the workspace's own ``.env`` - OUTSIDE the repository
  (``~/.iobot/workspaces/<code>/.env``), never committed, and the only file
  the runtime actually reads. This module appends a COMMENTED stub for each
  variable it does not already mention.

**The stub is commented on purpose, and it is the whole design.** An
uncommented ``VENDORS_TOKEN=`` would make the variable SET-but-empty, and
``effective_mcp_servers`` only checks whether the name is in the environment
- so the server would stop being "dropped, loudly" and would instead connect
with an empty credential and be rejected by the remote end on every call,
which is the silent failure this platform is bad at showing. Left commented,
the variable stays unset until a person fills it, and the loud drop keeps
working. Uncommenting is the act of supplying the value.
"""
from __future__ import annotations

import re
from pathlib import Path

#: `${VAR}` / `${VAR:-default}` - the reference form used in declarations.
ENV_REF = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-[^}]*)?\}")

_BANNER = "# --- required by aicore (add the values, then uncomment) ---"


def refs_in(obj) -> set[str]:
    """Every ``${VAR}`` name referenced anywhere in *obj*, recursively."""
    if isinstance(obj, str):
        return {m.group(1) for m in ENV_REF.finditer(obj)}
    if isinstance(obj, dict):
        out: set[str] = set()
        for v in obj.values():
            out |= refs_in(v)
        return out
    if isinstance(obj, (list, tuple, set)):
        out = set()
        for v in obj:
            out |= refs_in(v)
        return out
    return set()


def _mentions(text: str, name: str) -> bool:
    """Is *name* already spoken for in *text* - set, or already stubbed?

    Deliberately generous: a commented stub counts, so re-running a command
    does not pile up duplicate blocks, and a real assignment obviously counts
    so nothing this module does can disturb a value someone already put in.
    """
    pattern = re.compile(rf"^\s*#?\s*{re.escape(name)}\s*=", re.MULTILINE)
    return bool(pattern.search(text))


def _block(names: list[str], why: str) -> str:
    lines = [_BANNER]
    for name in names:
        lines.append(f"# {name} - {why}")
        lines.append(f"# {name}=")
    return "\n".join(lines) + "\n"


def stub_env_file(path: Path, names, why: str) -> list[str]:
    """Append a commented stub for each of *names* not already in *path*.

    Returns the names actually added. Creates the file when absent. NEVER
    rewrites an existing line, so a value already supplied cannot be touched
    - the file holds credentials, and the only safe edit to it is an append.
    """
    wanted = [n for n in dict.fromkeys(names) if n]
    if not wanted:
        return []
    try:
        text = path.read_text(encoding="utf-8-sig") if path.is_file() else ""
    except OSError:
        return []
    missing = [n for n in wanted if not _mentions(text, n)]
    if not missing:
        return []
    body = _block(missing, why)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        prefix = "" if (not text or text.endswith("\n")) else "\n"
        with path.open("a", encoding="utf-8") as fh:
            fh.write(f"{prefix}\n{body}" if text.strip() else body)
    except OSError:
        return []
    return missing


def pack_env_example(pack_root: Path, names, why: str) -> tuple[Path, list[str]]:
    """Document the requirement in the repository's committed ``.env.example``."""
    path = Path(pack_root) / ".env.example"
    return path, stub_env_file(path, names, why)


def workspace_env_stub(code: str, names, why: str) -> tuple[Path | None, list[str]]:
    """Stub the WORKSPACE's own ``.env`` - the file the runtime reads.

    Returns ``(None, [])`` when no workspace can be resolved: a scaffold
    command legitimately runs without one, and inventing a target for a
    credential file is not a thing to do on someone's behalf.
    """
    if not code:
        return None, []
    try:
        from ioagentfarm.engine.workspace_env import workspace_env_path
        path = workspace_env_path(code)
    except Exception:                      # noqa: BLE001 - never block a scaffold
        return None, []
    return path, stub_env_file(path, names, why)
