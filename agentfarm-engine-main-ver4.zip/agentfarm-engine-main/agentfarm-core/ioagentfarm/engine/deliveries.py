"""Declared deliveries — the tools this deployment sends a case action through.

A rulebook's delivery contract says HOW a case action reaches the world
(``"delivery": "email"``, ``"monitoring_task"``), never WHICH tool does it:
the tool is a deployment fact, and naming it in a rulebook would tie a
business procedure to one MCP server. Before this seam existed the platform
action workflow (``case_action``) carried the pharma tool names in its own
``mcp_tools`` allowlist and prompt, which is why it could not leave the
solution repo and why "every system a playbook reaches" was a slide, not a
check. Now the deployment declares, per delivery kind, the tool that
implements it, and three consumers read ONE resolution:

- the rulebook validator refuses, at put / validate / compile-stage /
  compile-approve, an action whose delivery kind this workspace has no tool
  for, and a ``verification`` contract naming a tool the workspace does not
  declare for verification;
- ``iof-case ctx`` hands the act step the resolved tool
  (``pending_action_meta.tool``), so the prompt names nothing;
- the engine expands the ``@deliveries`` token in a step's ``mcp_tools`` to
  exactly the declared tools, so the narrowing stays physics.

Three tiers, most explicit first: ``IOF_CASE_DELIVERIES`` (a JSON object —
the container's voice, like ``IOF_MCP_SERVERS``), the workspace tier
``~/.iobot/workspaces/<code>/deliveries.yaml`` (beside its ``mcp.yaml``), and
the packs' own ``deliveries.yaml`` (``Pack.deliveries``, merged first-wins).
The tiers do not merge with each other — the first that declares anything
is the declaration, so a deployment can never be half one tier and half
another without knowing.

Shape, in any tier::

    email:            {tool: mcp_pharma_send_field_email}
    monitoring_task:  {tool: mcp_pharma_create_monitoring_task}
    verification:     {tools: [mcp_pharma_get_rep_alignment]}

A bare string is accepted as ``{tool: <string>}``.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

ENV_VAR = "IOF_CASE_DELIVERIES"
#: The token a workflow step writes in ``mcp_tools`` to mean "the tools this
#: deployment declares for deliveries" — expanded by the engine at run time.
TOKEN = "@deliveries"
#: Delivery kinds that reach an external system through ONE declared tool.
#: ``open_play`` and ``workflow`` deliver through ``iof-case`` itself;
#: ``verification`` names its tool in the contract and is checked against the
#: declared list.
#:
#: ``system_of_record`` is the WRITE-BACK: the outcome a case reached, put
#: where the business reads it. Without it a case can tell people and open
#: tasks, but its own decision lives only on the event ledger - a barrier
#: "confirmed into the register" that leaves every register row untouched,
#: which is a playbook reporting an outcome nobody else can see. The tool is
#: the deployment's, exactly like the other two.
TOOL_KINDS = ("email", "monitoring_task", "system_of_record")


def normalize(data, source: str) -> dict[str, dict]:
    """``{kind: {tool: ...} | {tools: [...]}}`` from any accepted spelling."""
    if data is None:
        return {}
    if not isinstance(data, dict):
        logger.warning("deliveries from %s are not a mapping; ignored", source)
        return {}
    out: dict[str, dict] = {}
    for kind, entry in data.items():
        if isinstance(entry, str):
            entry = {"tool": entry}
        if not isinstance(entry, dict):
            logger.warning("deliveries from %s: %r is not a mapping; ignored",
                           source, kind)
            continue
        out[str(kind)] = dict(entry)
    return out


def load_pack_deliveries(package: str) -> dict[str, dict]:
    """A pack's ``deliveries.yaml`` as ``{kind: entry}``; ``{}`` when absent."""
    from importlib import resources
    try:
        f = resources.files(package) / "deliveries.yaml"
        if not f.is_file():
            return {}
        data = yaml.safe_load(f.read_text(encoding="utf-8"))
    except Exception:       # noqa: BLE001 - a broken file is a warning, not a crash
        logger.warning("deliveries.yaml of %s is unreadable; ignored", package,
                       exc_info=True)
        return {}
    return normalize(data, f"pack {package}")


def workspace_deliveries_path(code: str) -> Path:
    """``~/.iobot/workspaces/<code>/deliveries.yaml`` — the workspace tier,
    beside the workspace's ``mcp.yaml``."""
    from ioagentfarm.engine.workspace_env import workspace_home
    return workspace_home(code) / "deliveries.yaml"


def describe_deliveries(workspace: str | None = None) -> tuple[dict, str]:
    """``(deliveries, source)`` — the resolved declaration and where it came
    from (``env``, ``workspace:<path>``, ``packs`` or ``none``). Raises
    ``ValueError`` when the environment variable is set and malformed: a
    deployment that tried to declare and failed must be refused, not read
    as "declares nothing"."""
    raw = (os.environ.get(ENV_VAR) or "").strip()
    if raw:
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            raise ValueError(f"{ENV_VAR} is not valid JSON ({e})") from e
        if not isinstance(data, dict):
            raise ValueError(f"{ENV_VAR} must be a JSON object keyed by "
                             f"delivery kind")
        return normalize(data, ENV_VAR), "env"
    code = workspace
    if not code:
        try:
            from ioagentfarm.engine.workspaces import maybe_workspace_code
            code = maybe_workspace_code()
        except Exception:       # noqa: BLE001 - no selection is not an error here
            code = None
    if code:
        path = workspace_deliveries_path(code)
        if path.is_file():
            try:
                data = yaml.safe_load(path.read_text(encoding="utf-8"))
            except Exception as e:      # noqa: BLE001
                raise ValueError(f"{path} is unreadable ({e})") from e
            return normalize(data, str(path)), f"workspace:{path}"
    from ioagentfarm.packs import load_registry
    packs = load_registry().deliveries()
    return packs, ("packs" if packs else "none")


def declared_deliveries(workspace: str | None = None) -> dict[str, dict]:
    return describe_deliveries(workspace)[0]


def delivery_tools(deliveries: dict) -> list[str]:
    """Every tool name the declaration reaches, in declaration order."""
    tools: list[str] = []
    for kind, entry in (deliveries or {}).items():
        if not isinstance(entry, dict):
            continue
        names = (entry.get("tools") or []) if kind == "verification" \
            else ([entry["tool"]] if entry.get("tool") else [])
        for n in names:
            n = str(n)
            if n and n not in tools:
                tools.append(n)
    return tools


def expand_step_tool_allowlist(allowed, workspace: str | None = None):
    """Replace ``@deliveries`` in a step's ``mcp_tools`` with the declared
    delivery tools. ``None`` (no allowlist) passes through untouched; a
    deployment that declares nothing leaves the step with NO delivery tools
    — the act step then reports the tool unavailable rather than reaching
    for one it was never granted."""
    if allowed is None or TOKEN not in allowed:
        return allowed
    try:
        tools = delivery_tools(declared_deliveries(workspace))
    except ValueError as e:
        logger.warning("%s: %s — the step gets no delivery tools", TOKEN, e)
        tools = []
    if not tools:
        logger.warning("%s: this deployment declares no delivery tools "
                       "(deliveries.yaml / %s) — the step gets none",
                       TOKEN, ENV_VAR)
    out = [str(a) for a in allowed if a != TOKEN]
    out += [t for t in tools if t not in out]
    return out
