"""Forensic event log — structured timeline for post-mortem reconstruction.

Purpose
-------
The messages table captures *what the agent said*. The learning_log captures
*what the agent learned*. Neither captures *what the orchestrator and runtime
actually did* — when subprocesses spawned, what they exited with, when retries
fired, what errors the LLM provider returned, when crash-recovery kicked in.

Without that operator-level event stream, debugging a failed run in production
is reduced to guessing from sparse evidence (overwritten stderr, missing
OUTPUT.md, vague Alex narration). This module fixes that.

Two outputs per event
---------------------
1. **DB row** in ``iof.forensic_events`` (PostgreSQL) / ``forensic_events``
   (SQLite) — small, indexed, queryable. The structured timeline.
2. **Optional blob path** referenced from the row — pointer to a file in
   ``.iof/instances/<run_id>/forensics/`` for large content (rendered prompts,
   raw stdout, env snapshots). Blobs are written by ``cli.py`` (Phases 1-2);
   this module just records the pointer.

The events form an append-only audit log. Never delete, never update from
this module. Retention is ``aicore retention prune`` (``engine/retention.py``):
a completed run's events leave with the run, under the workspace's policy.

Event types
-----------
The schema is intentionally a free-form ``event_type`` string (not an enum)
so we can add new event types without schema migrations. The list below is
the ACTUALLY-EMITTED vocabulary — derived from the emit sites in
``cli_orchestration.py``, ``engine/supervisor.py`` and ``cli.py``, and pinned
by ``tests/test_forensic_event_docs_match_emits.py`` so it can never drift
again (an earlier revision listed eight types nothing emitted, and any LLM
reading them diagnosed against ghosts).

Run boundaries (``cli.py`` / ``_finalize_step``):

  run.created                 — run row created (workflow and swarm runs);
                                payload {kind, workflow, goal, content} where
                                `content` is the installed-content stamp line
                                (engine/content.py) also written to the run's
                                provenance.json
  run.completed               — the run transitioned to done
  run.failed                  — the run transitioned to failed (stuck)
  run.memory_queued           — workspace-memory consolidation of the
                                completed run was queued (payload.mode:
                                detached | inline | skipped | error)
  run.memory_consolidated     — `aicore memory consolidate --run` finished
                                for the run (payload: candidates, posture,
                                result counts, or skipped/error)
  run.coverage                — what the run did NOT cover, from the
                                workflow's declared `coverage:` commands, run
                                at the completion transition. A run's record
                                knows its own steps and nothing about input
                                never queued for it, so a pipeline consuming
                                half its backlog reaches `done` with every
                                gate green and the shortfall appears nowhere.
                                A report, never a gate (engine/coverage.py)

Step lifecycle (``cli_orchestration.py``):

  step.started                — run-step claimed the step
  step.spawn_subprocess       — Popen called for the agent subprocess
  step.subprocess_exited      — proc.wait() returned (exit code, duration)
  step.output_md_written      — _finalize_step found a valid OUTPUT.md
  step.output_md_missing      — _finalize_step did NOT find OUTPUT.md
  step.protocol_parse_failed  — STATUS/OUTPUT header missing or malformed
  step.artifact_missing       — requires_artifacts gate tripped (done->failed)
  step.stories_missing        — loop/exec step reported done without stories
  step.finalized              — final status written to the DB
  step.retry_initiated        — step-retry invoked (incl. --crash-recovery)
  step.skipped                — step-skip invoked
  step.inline_complete_refused — step-complete rejected for a non-lead step
  step.duplicate_refused      — run-step refused a SECOND spawn: a live
                                subprocess already owns the step
  step.dag_bypass_refused     — run-step refused a step with unmet deps (the
                                DAG is enforced; a driver cannot force order)
  step.model_refused          — run-step refused a step whose model the
                                model registry (models.yaml) retires or
                                does not list
  step.deps_overridden        — a human operator (IOF_OPERATOR_OVERRIDE=1 +
                                --ignore-deps) forced a step past unmet deps
  step.skip_refused_gate      — step-skip refused: the step's
                                requires_artifacts gate is unmet
  step.exec_started           — an exec/route step's command is about to run
                                (attempt n); the OTel step span opens here
  step.skip_refused_reset     — step-skip refused: a gate sent this step
                                back (on_fail) and it has not re-run; a
                                skip would resubmit the rejected work
  step.routed                 — a `type: route` step chose its successors;
                                payload: chosen / declared / skipped
  step.route_missing          — route step reported done with no ROUTE_JSON
                                (done->failed, fail-closed)
  run.interrupted             — the foreground driver took Ctrl+C (warn)
  run.artifact_changed_after_gate — a deliverable differs from its gate
                                digest now that the run is done (warn)
  step.artifact_gate_passed   — the gate passed; payload carries each
                                deliverable's size and sha256
  step.route_ambiguous        — a route step printed more than one
                                ROUTE_JSON line; the last decided (warn)
  step.reaped_on_resume       — resume reset a step whose driver was
                                gone and whose heartbeat had stopped (warn)
  run.cancelled               — an operator stopped the run for good
                                (`aicore cancel`; warn)
  step.stories_unconsumed     — a stories_from manifest listed items but
                                the step declares no per_item_steps (warn)
  run.shared_project_dir      — another active run uses this project
                                directory; concurrent writes can be lost
                                (warn)
  step.fanout_empty           — a stories_from manifest held zero items:
                                nothing fans out, downstream runs over
                                nothing (warn)
  run.spawn_failed            — `run --json` could not start the driver;
                                the run is marked failed, its id printed
  run.resumed                 — a person ran `aicore resume` (payload:
                                by, force)
  step.route_target_already_ran — a route closed a branch that had already
                                run: the target did not depend on the
                                route step, so the decision could not
                                apply to it (warn)
  step.route_undeclared       — route step chose a target outside its
                                declared `routes:` (done->failed)
  step.reset_on_fail          — a gate failed and sent its producers back to
                                pending, with feedback; payload: targets /
                                reset / feedback_chars
  step.on_fail_exhausted      — the gate failed on its LAST attempt; nothing
                                reset - the loop's bound
  step.hard_cap_reached       — attempt ceiling hit; step failed fatally
  step.auto_retry_after_stall — Fix 6 retried the attempt in place
  step.retry_not_needed       — a stall reason was a FALSE ALARM: the step's
                                OUTPUT.md is complete, so the step is accepted
                                instead of being re-run. The guard used to look
                                in the project dir while agents write to the STEP
                                output dir, so it never fired and finished work
                                was discarded and redone (cli_orchestration.py)
  step.exec_completed         — type:exec step command succeeded
  step.exec_failed            — type:exec step command failed
  step.tool_usage             — per-attempt tool aggregate derived from the
                                session snapshot at finalize: {by_name,
                                failures, by_target_top, assistant_turns,
                                wrote_output}

LLM stream (``cli_orchestration.py``, parsed from subprocess output):

  llm.request_failed          — provider error mid-stream
  llm.stream_stalled          — 90s token watchdog fired

Swarm (``_finalize_step``, on swarm-run completion):

  swarm.child_result          — one per child in the run's results.json:
                                {child, ok, error}

Driver / supervisor:

  agent.next_step_polled      — the driver asked for the next runnable step
  supervisor.step_reaped      — stale running step reset to pending
  supervisor.deadlock         — runnable steps exist but nothing can claim
  supervisor.driver_resumed   — dead driver resurrected via spawn_run
  supervisor.gave_up          — resume budget exhausted; run failed
  supervisor.work_may_repeat  — a pending step already has artifacts on
                                disk: the signature of a database
                                restored without its write-ahead log,
                                so resuming re-runs work already done
  supervisor.workspace_unresolved — run has no attributable workspace; failed
                                rather than resurrected into a guessed tenant
  run.driver_gave_up          — the blocking driver loop exhausted its
                                respawn budget with no progress (e.g. a
                                total provider outage: the driver cannot
                                make its own LLM calls, so no step ever
                                starts). Without it such a run carried a
                                single run.created event and `explain`
                                could only say "status: running".

Deliberately NOT emitted: per-tool-call events (``tool.call``/``tool.error``)
— per-call detail lives in the session JSONLs (``forensics narrative``);
``step.tool_usage`` carries the queryable aggregate.

Severity
--------
``info``  — happy path / informational
``warn``  — recoverable degradation (vectorfs unavailable, retry fired)
``error`` — step or run-level failure
``fatal`` — orchestrator crashed
"""
from __future__ import annotations

import json
import logging
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from ioagentfarm.engine.db import DbAdapter

logger = logging.getLogger(__name__)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _uuid() -> str:
    return uuid.uuid4().hex[:12]


# Severity constants — keep as plain strings for forward compat with new levels
SEVERITY_INFO = "info"
SEVERITY_WARN = "warn"
SEVERITY_ERROR = "error"
SEVERITY_FATAL = "fatal"


class Forensics:
    """Append-only event store for forensic reconstruction.

    Initialized once per process; cheap to construct (just wraps a DbAdapter).
    All writes are best-effort — a forensics failure must NEVER break the
    actual run. Every public method is wrapped in try/except internally.
    """

    def __init__(self, adapter: DbAdapter):
        self._db = adapter

    # ------------------------------------------------------------------
    # Connection / SQL helpers (mirrors LearningLog pattern)
    # ------------------------------------------------------------------

    def _conn(self) -> Any:
        return self._db.connect()

    @contextmanager
    def _tx(self):
        with self._conn() as con:
            self._db.init_connection(con)
            cursor = con.cursor()
            try:
                yield cursor
            finally:
                cursor.close()

    def _q(self, sql: str) -> str:
        ph = self._db.placeholder()
        if ph == "?":
            return sql
        return sql.replace("?", ph)

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def init(self) -> None:
        """Create the ``forensic_events`` table and indexes (idempotent)."""
        try:
            auto_id = self._db.auto_id()
            with self._tx() as cursor:
                cursor.execute(
                    f"""CREATE TABLE IF NOT EXISTS forensic_events (
                        id {auto_id},
                        event_id TEXT NOT NULL UNIQUE,
                        run_id TEXT NOT NULL,
                        step_key TEXT,
                        attempt INTEGER,
                        role TEXT,
                        ts TEXT NOT NULL,
                        event_type TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        message TEXT,
                        blob_path TEXT,
                        payload_json TEXT
                    );"""
                )
                cursor.execute(
                    "CREATE INDEX IF NOT EXISTS idx_forensic_events_run "
                    "ON forensic_events(run_id);"
                )
                cursor.execute(
                    "CREATE INDEX IF NOT EXISTS idx_forensic_events_run_step "
                    "ON forensic_events(run_id, step_key, attempt);"
                )
                cursor.execute(
                    "CREATE INDEX IF NOT EXISTS idx_forensic_events_severity "
                    "ON forensic_events(severity);"
                )
                cursor.execute(
                    "CREATE INDEX IF NOT EXISTS idx_forensic_events_type "
                    "ON forensic_events(event_type);"
                )
        except Exception:
            logger.debug("Failed to init forensic_events table", exc_info=True)

    # ------------------------------------------------------------------
    # Append (the only mutation API — events are immutable)
    # ------------------------------------------------------------------

    def emit(
        self,
        *,
        run_id: str,
        event_type: str,
        severity: str = SEVERITY_INFO,
        step_key: Optional[str] = None,
        attempt: Optional[int] = None,
        role: Optional[str] = None,
        message: Optional[str] = None,
        blob_path: Optional[Path] = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """Append one event. Returns the event_id, or None on failure.

        Best-effort — never raises. A forensic write failure must not break
        the calling code path. Failures are logged at DEBUG only.
        """
        try:
            event_id = _uuid()
            ts = _utc_now_iso()
            blob_str = str(blob_path) if blob_path is not None else None
            payload_str = (
                json.dumps(payload, ensure_ascii=False, default=str)
                if payload is not None else None
            )
            with self._tx() as cursor:
                cursor.execute(
                    self._q(
                        "INSERT INTO forensic_events "
                        "(event_id, run_id, step_key, attempt, role, ts, "
                        "event_type, severity, message, blob_path, payload_json) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    ),
                    (
                        event_id, run_id, step_key, attempt, role, ts,
                        event_type, severity, message, blob_str, payload_str,
                    ),
                )
            # THE ONE SEAM. Every event of a run passes here, so the OTel
            # export is a listener on this call and nothing else - what
            # forensics knows, the client's observability stack gets, and
            # nothing is emitted twice from two places. Best-effort like the
            # write above: an exporter problem is a DEBUG line, never a
            # failed step.
            try:
                from ioagentfarm.engine import otel_export as _otel
                if _otel.enabled():
                    import os as _os
                    _otel.on_event(
                        root_path=Path(getattr(self, "_root_path", None)
                                       or _os.getenv("IOF_ROOT", ".iof")),
                        run_id=run_id, event_type=event_type, severity=severity,
                        step_key=step_key, attempt=attempt, role=role,
                        message=message, payload=payload, ts_iso=ts)
            except Exception:
                logger.debug("otel listener failed for %s", event_type, exc_info=True)
            return event_id
        except Exception:
            logger.debug(
                "forensic emit failed (run_id=%s type=%s)",
                run_id, event_type, exc_info=True,
            )
            return None

    # ------------------------------------------------------------------
    # Query API (used by Phase 4 CLI and the future post-mortem workflow)
    # ------------------------------------------------------------------

    def get_run_timeline(
        self,
        run_id: str,
        *,
        since_ts: Optional[str] = None,
        severity_min: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Return all events for a run in chronological order.

        ``since_ts`` lets the ``forensics tail`` CLI poll incrementally.
        ``severity_min`` filters out events below a level (e.g. ``"warn"``).
        """
        try:
            sql = "SELECT * FROM forensic_events WHERE run_id=?"
            args: List[Any] = [run_id]
            if since_ts:
                sql += " AND ts > ?"
                args.append(since_ts)
            if severity_min:
                rank = {"info": 0, "warn": 1, "error": 2, "fatal": 3}
                min_rank = rank.get(severity_min, 0)
                allowed = [k for k, v in rank.items() if v >= min_rank]
                placeholders = ",".join(["?"] * len(allowed))
                sql += f" AND severity IN ({placeholders})"
                args.extend(allowed)
            sql += " ORDER BY ts ASC, id ASC"
            with self._tx() as cursor:
                cursor.execute(self._q(sql), args)
                return [dict(r) for r in cursor.fetchall()]
        except Exception:
            logger.debug("forensic get_run_timeline failed", exc_info=True)
            return []

    def get_step_timeline(
        self,
        run_id: str,
        step_key: str,
        attempt: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Return events for a single step (optionally a single attempt)."""
        try:
            sql = "SELECT * FROM forensic_events WHERE run_id=? AND step_key=?"
            args: List[Any] = [run_id, step_key]
            if attempt is not None:
                sql += " AND attempt=?"
                args.append(attempt)
            sql += " ORDER BY ts ASC, id ASC"
            with self._tx() as cursor:
                cursor.execute(self._q(sql), args)
                return [dict(r) for r in cursor.fetchall()]
        except Exception:
            logger.debug("forensic get_step_timeline failed", exc_info=True)
            return []

    def list_runs(
        self,
        *,
        limit: int = 50,
        only_failed: bool = False,
    ) -> List[Dict[str, Any]]:
        """List recent runs that have any forensic events.

        Returns one row per run with summary counters: total events, errors,
        first/last event timestamps. Used by ``forensics list``.
        """
        try:
            severity_filter = ""
            if only_failed:
                severity_filter = " HAVING SUM(CASE WHEN severity IN ('error','fatal') THEN 1 ELSE 0 END) > 0"
            sql = (
                "SELECT run_id, "
                "  COUNT(*) AS event_count, "
                "  SUM(CASE WHEN severity='error' THEN 1 ELSE 0 END) AS error_count, "
                "  SUM(CASE WHEN severity='fatal' THEN 1 ELSE 0 END) AS fatal_count, "
                "  SUM(CASE WHEN severity='warn' THEN 1 ELSE 0 END) AS warn_count, "
                "  MIN(ts) AS first_ts, "
                "  MAX(ts) AS last_ts "
                "FROM forensic_events "
                "GROUP BY run_id"
                f"{severity_filter} "
                "ORDER BY MAX(ts) DESC LIMIT ?"
            )
            with self._tx() as cursor:
                cursor.execute(self._q(sql), [limit])
                return [dict(r) for r in cursor.fetchall()]
        except Exception:
            logger.debug("forensic list_runs failed", exc_info=True)
            return []


# ----------------------------------------------------------------------
# Failure-pattern detection from session JSONL
# ----------------------------------------------------------------------

# Known failure patterns in iobot's session JSONL `assistant` content.
# When the agent loop terminates due to one of these conditions, iobot
# records the error as a final assistant message with no tool_calls. We
# match against the literal substring (case-insensitive) so future iobot
# wording variations need at most a tweak here, not a refactor.
#
# (substring, reason_code) — reason_code is the structured value used in
# event payloads and CLI filters; substring is the literal text to scan for.
#
# IMPORTANT: order matters. Patterns are matched in list order, first hit
# wins. Put MORE SPECIFIC patterns BEFORE the catch-all "Error calling LLM:"
# so a specific reason code is preferred over the generic one.
FAILURE_PATTERNS: List[tuple] = [
    # Specific patterns first
    ("stream stalled for more than", "llm_stream_stalled"),
    ("Model request failed", "llm_request_failed"),
    ("Connection error", "llm_connection_error"),
    ("maxToolIterations", "max_tool_iterations"),
    ("max tool iterations", "max_tool_iterations"),
    ("context window", "context_window_exceeded"),
    ("rate limit", "llm_rate_limited"),
    ("authentication", "llm_auth_failed"),
    ("API key", "llm_auth_failed"),
    # Catch-all for any other "Error calling LLM: ..." variant iobot might
    # emit. This pattern MUST be last so the more specific reasons above win.
    # Without it, novel LLM error messages return reason="unknown" and
    # operators have to grep raw session JSONLs by hand.
    ("Error calling LLM:", "llm_generic_error"),
]


def find_swarm_results(project_dir) -> Optional["Path"]:
    """Locate a swarm run's ``results.json`` across its two real layouts.

    The dispatch artifacts land either at the project root or under
    ``project/metadata/tmp/<hash>/`` — the a2a_consult skill's prescribed
    scratch path, carried into the project dir by artifact collection.
    Latest mtime wins. Shared by the ``swarm.child_result`` emitter and
    ``forensics explain`` so the two can never disagree about where a run's
    children are recorded (they did once: a run whose files sat one
    directory down emitted no child events and rendered an empty table).
    """
    from pathlib import Path
    project = Path(project_dir)
    candidates = [project]
    try:
        candidates += sorted((project / "metadata" / "tmp").iterdir())
    except OSError:
        pass
    best, newest = None, -1.0
    for base in candidates:
        cand = base / "results.json"
        try:
            mtime = cand.stat().st_mtime
        except OSError:
            continue
        if mtime > newest:
            newest, best = mtime, cand
    return best


def parse_session_failure(session_jsonl_path: Path) -> Optional[Dict[str, Any]]:
    """Read a iobot session JSONL and detect why the agent loop ended.

    Handles BOTH session formats iobot uses:

    1. **Post-exit format** (multi-line role-tagged): a sequence of objects
       with ``role: user|assistant|tool`` plus optional metadata. Used by
       ``session-snapshot.jsonl`` after the subprocess exits.

    2. **In-flight checkpoint format** (single-line metadata wrapper): a
       single JSON object with ``_type: metadata`` and the latest assistant
       state nested under ``metadata.runtime_checkpoint.assistant_message``.
       Used by inflight session snapshots taken while the subprocess is
       still running. (Forensic Gap C — was missed before this fix.)

    Detection has two layers:

    - **Substring scan** of the last assistant turn's text against
      ``FAILURE_PATTERNS`` — catches the literal error strings iobot
      writes when its stream consumer / HTTP layer raises (stream stall,
      connection error, etc.).

    - **Structural premature-termination check** — catches the case where
      iobot's agent loop interpreted a text-only or empty/thinking-only
      assistant turn as "agent done" and exited cleanly without the agent
      having written ``STATUS:`` to OUTPUT.md. This is the Analyst failure
      mode: the model emitted a standalone ``[PROGRESS]`` narration turn
      with no ``tool_use``, iobot read it as completion, the loop ended
      after 26s with rc=0 and no work product. Returns the reason
      ``agent_premature_termination`` so Fix 6 can auto-retry.

    Returns a dict with structured failure info if either layer trips.
    Returns None for clean exits.

    Result shape::

        {
          "reason": "llm_stream_stalled" | "agent_premature_termination" | ...,
          "raw_text": "<last assistant text, truncated to 500 chars>",
          "matched_pattern": "stream stalled for more than" | "(structural)" | ...,
          "tool_calls_made": 9,
          "wrote_output": False,
          "format": "post_exit"|"inflight_checkpoint",
        }
    """
    if not session_jsonl_path.exists():
        return None

    try:
        with open(session_jsonl_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return None

    last_assistant_text = ""
    last_assistant_tool_calls = 0
    last_assistant_seen = False
    tool_calls_made = 0
    wrote_output = False
    detected_format = "post_exit"

    # Walk every line. Each line is either a post-exit role object
    # OR an inflight checkpoint metadata object — handle both shapes.
    for ln in lines:
        try:
            obj = json.loads(ln)
        except Exception:
            continue

        # Format 2: in-flight checkpoint metadata wrapper
        if obj.get("_type") == "metadata":
            ckpt = obj.get("metadata", {}).get("runtime_checkpoint")
            if not ckpt:
                continue
            asst = ckpt.get("assistant_message")
            if not asst or asst.get("role") != "assistant":
                continue
            detected_format = "inflight_checkpoint"
            # The assistant_message inside the checkpoint has the same shape
            # as a post-exit assistant turn — fall through to the unified
            # processing below by treating this as the assistant object.
            obj = asst

        # Unified processing — handles both post-exit assistant objects
        # AND the unwrapped inflight assistant_message from above.
        if obj.get("role") != "assistant":
            continue

        last_assistant_seen = True
        text = (obj.get("content") or "").strip()
        turn_tool_calls = obj.get("tool_calls") or []
        # Track the LAST assistant turn (not cumulative). Empty text and
        # zero tool_calls is a valid state for a thinking-only turn that
        # we still want to detect structurally.
        last_assistant_text = text
        last_assistant_tool_calls = len(turn_tool_calls)
        for tc in turn_tool_calls:
            tool_calls_made += 1
            if tc.get("function", {}).get("name") == "write_file":
                wrote_output = True

    if not last_assistant_seen:
        return None

    text_lower = last_assistant_text.lower()
    # Layer 1: substring match against known error messages
    for substring, reason in FAILURE_PATTERNS:
        if substring.lower() in text_lower:
            return {
                "reason": reason,
                "raw_text": last_assistant_text[:500],
                "matched_pattern": substring,
                "tool_calls_made": tool_calls_made,
                "wrote_output": wrote_output,
                "format": detected_format,
            }

    # Layer 2: structural premature-termination detection.
    #
    # If the last assistant turn made no tool calls AND its text doesn't
    # contain the protocol's "STATUS:" marker, iobot's agent loop ended
    # without the agent signaling completion. The model either emitted a
    # standalone narration turn (Analyst class — text without action) or a
    # thinking-only/empty turn (Reviewer class — invisible to the stream
    # consumer). Both are recoverable via session-resume retry.
    #
    # We check for "STATUS:" rather than the full "STATUS: done" because
    # the agent may have written it as part of a longer chat sentence and
    # we want to avoid false positives — if the marker is anywhere in the
    # text, treat the turn as a real (if malformed) completion attempt and
    # let _finalize_step handle the protocol parse.
    if last_assistant_tool_calls == 0 and "status:" not in text_lower:
        return {
            "reason": "agent_premature_termination",
            "raw_text": (last_assistant_text or "(empty/thinking-only turn)")[:500],
            "matched_pattern": "(no tool_calls and no STATUS marker in last assistant turn)",
            "tool_calls_made": tool_calls_made,
            "wrote_output": wrote_output,
            "format": detected_format,
        }

    return None


# ----------------------------------------------------------------------
# Orchestrator session checkpoint snapshot helper
# ----------------------------------------------------------------------


def orchestrate_reasoning(
    root_path: Path,
    run_id: str,
    user_id: str = "",
) -> Optional[tuple[Path, int]]:
    """The best available record of the DRIVER's reasoning: (path, turns).

    WHY A LOCATOR AND NOT JUST THE SNAPSHOT. Making the snapshot land was
    only half of A2. The certification's round 2 measured what landed: 26
    snapshots across two live runs, EVERY one exactly two lines - metadata
    and the driver's own prompt, zero assistant turns - because the runtime
    flushes an agent's session JSONL once, at the END of its turn, while the
    snapshot is taken from a DIFFERENT process (`aicore next-step`) in the
    middle of it. The copy is of a file not yet written. Every existence
    check passed: 3 KB, non-empty, present.

    So the reasoning is looked for where it actually is, in order:

      1. the newest SNAPSHOT that contains at least one assistant record -
         the only thing that survives a driver killed mid-run;
      2. otherwise the LIVE orchestrate session, which after the driver exits
         is flushed and complete.

    Returns None when neither holds a turn, which is a fact worth printing
    rather than an empty section.
    """
    def _turns(p: Path) -> int:
        n = 0
        try:
            with open(p, encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line.startswith("{"):
                        continue
                    try:
                        row = json.loads(line)
                    except Exception:      # noqa: BLE001 - a torn tail is fine
                        continue
                    if isinstance(row, dict) and row.get("role") == "assistant":
                        n += 1
        except OSError:
            return 0
        return n

    # THE RICHEST RECORD WINS, not the newest. A resumed run has several
    # session files and several snapshots: round 4 watched `explain` cite the
    # post-resume session's 2 turns while the 48-turn session carrying the
    # actual failure sat beside it on disk, uncited. Newest is the right rule
    # for the WRITER (preserve the live file); most-turns is the right rule
    # for the READER (that is where the reasoning is). Ties break to newest.
    candidates: list[tuple[int, float, Path]] = []
    snap_dir = Path(root_path) / "instances" / run_id / "forensics" / "orchestrate"
    try:
        snaps = list(snap_dir.glob("*.jsonl"))
    except OSError:
        snaps = []
    # EVERY live session, not the newest one. `_live_orchestrate_session`
    # returns max-by-mtime, and a resumed run has several: certification
    # round 5 re-read a run whose 48-turn session sat beside a 2-turn one and
    # got the 2 - because the rich file was filtered out by that max() BEFORE
    # this max() could see it. The reader wants them all and picks the
    # richest; the writer still wants the newest, which is why they are two
    # functions. (The pinning test for this had put its rich record in the
    # SNAPSHOT directory, so it passed against the broken reader.)
    live_all = _live_orchestrate_sessions(run_id, user_id)
    for p in snaps + live_all:
        try:
            n = _turns(p)
            if n:
                candidates.append((n, p.stat().st_mtime, p))
        except OSError:
            continue
    if not candidates:
        return None
    n, _mtime, path = max(candidates, key=lambda c: (c[0], c[1]))
    return (path, n)


def _live_orchestrate_sessions(run_id: str, user_id: str = "") -> list[Path]:
    """EVERY live session file for *run_id* - a resumed run has several."""
    sessions_dir = _orchestrate_sessions_dir()
    if sessions_dir is None:
        return []

    def _decoded(stem: str) -> str:
        import base64 as _b64
        try:
            pad = -len(stem) % 4
            return _b64.urlsafe_b64decode(stem + "=" * pad).decode("utf-8")
        except Exception:                  # noqa: BLE001
            return stem

    hits = []
    for p in sessions_dir.glob("*.jsonl"):
        key = _decoded(p.stem)
        if run_id in key and "orchestrate" in key:
            hits.append(p)
    return hits


def _orchestrate_sessions_dir() -> Optional[Path]:
    """Where the driver's sessions live, workspace-scoped or classic."""
    sessions_dir = None
    try:
        from ioagentfarm.engine.workspaces import iobot_agent_workspace
        sessions_dir = Path(iobot_agent_workspace("project_lead")) / "sessions"
    except Exception:                      # noqa: BLE001
        sessions_dir = None
    if sessions_dir is None or not sessions_dir.exists():
        try:
            home = Path.home()
        except Exception:                  # noqa: BLE001
            return None
        from ioagentfarm.engine.state_dir import state_dir_name
        sessions_dir = (home / state_dir_name() / "agents" / "project_lead"
                        / "workspace" / "sessions")
    return sessions_dir if sessions_dir.exists() else None


def _live_orchestrate_session(run_id: str, user_id: str = "") -> Optional[Path]:
    """The driver's own session file for *run_id*, wherever the runtime put it.

    Shared with `snapshot_orchestrator_session` so the writer and every
    reader agree on what a session file is called - the capture layer and its
    reader having independent ideas about that is the bug this whole section
    exists to close.
    """
    sessions_dir = None
    try:
        from ioagentfarm.engine.workspaces import iobot_agent_workspace
        sessions_dir = Path(iobot_agent_workspace("project_lead")) / "sessions"
    except Exception:                      # noqa: BLE001
        sessions_dir = None
    if sessions_dir is None or not sessions_dir.exists():
        try:
            home = Path.home()
        except Exception:                  # noqa: BLE001
            return None
        from ioagentfarm.engine.state_dir import state_dir_name
        sessions_dir = (home / state_dir_name() / "agents" / "project_lead"
                        / "workspace" / "sessions")
    if not sessions_dir.exists():
        return None

    def _decoded(stem: str) -> str:
        import base64 as _b64
        try:
            pad = -len(stem) % 4
            return _b64.urlsafe_b64decode(stem + "=" * pad).decode("utf-8")
        except Exception:                  # noqa: BLE001
            return stem

    hits = []
    for p in sessions_dir.glob("*.jsonl"):
        key = _decoded(p.stem)
        if run_id in key and "orchestrate" in key:
            hits.append(p)
    if not hits:
        return None
    return max(hits, key=lambda p: p.stat().st_mtime)


def snapshot_orchestrator_session(
    root_path: Path,
    run_id: str,
    user_id: str,
    *,
    label: str = "checkpoint",
) -> Optional[Path]:
    """Copy the project_lead orchestrate session JSONL to a forensics blob.

    Alex's session is stored at::

        ~/.iobot/agents/project_lead/workspace/sessions/iof_<run_id>_orchestrate_u_<user>_<id>.jsonl

    iobot rewrites it in place on every checkpoint, so to preserve history
    we copy it to::

        <root>/instances/<run_id>/forensics/orchestrate/<ts>.<label>.jsonl

    Best-effort. Returns the destination path on success, None on failure.
    Called from CLI commands Alex invokes (next-step, step-retry, step-complete,
    step-skip) so every Alex action point creates a snapshot.
    """
    try:
        # THE SNAPSHOT NEVER LANDED, AND NOTHING SAID SO (Phase A round 1,
        # 2026-08-28: 0 of 4 agent runs produced an orchestrate blob, while
        # `agent.next_step_polled` kept firing - so the record LOOKED
        # checkpointed and `forensics narrative|stats|blob` all failed with
        # "no attempts dir"). Two independent reasons, both invisible because
        # this function is best-effort and swallows:
        #
        #   1. THE NAME. The runtime stores a session as
        #      `base64url(key).jsonl` (`SessionManager._storage_key`), with two
        #      legacy spellings behind it. The glob below looked for
        #      `iof_<run>_orchestrate*.jsonl`, a FOURTH convention that matches
        #      none of them. So it is matched by DECODING each stem rather than
        #      by guessing the encoding - drift-proof, and it still recognises
        #      both legacy (already-readable) names.
        #   2. THE PLACE. The sessions directory was hand-built from
        #      `~/<state dir>/agents/project_lead/...`, which is not where a
        #      WORKSPACE-SCOPED install keeps agent homes. It now asks the
        #      engine's own resolver, and only falls back to the old path.
        #
        # This is the "validate the CONSUMER, not just that a file was
        # written" lesson from the learning-skill layout bug, in the one place
        # that makes an agent run postmortem-able.
        sanitized_uid = (user_id or "").replace(":", "_").replace("/", "_")
        sessions_dir = None
        try:
            from ioagentfarm.engine.workspaces import iobot_agent_workspace
            sessions_dir = Path(iobot_agent_workspace("project_lead")) / "sessions"
        except Exception:
            sessions_dir = None
        if sessions_dir is None or not sessions_dir.exists():
            try:
                home = Path.home()
            except Exception:
                return None
            from ioagentfarm.engine.state_dir import state_dir_name
            sessions_dir = (home / state_dir_name() / "agents" / "project_lead"
                            / "workspace" / "sessions")
        if not sessions_dir.exists():
            return None

        def _decoded(stem: str) -> str:
            """The session KEY a storage stem encodes, or the stem itself.

            Decoded inline rather than imported: this runs on the CLI's hot
            path (`next-step` on every driver turn) and importing the agent
            runtime to read a filename would cost the startup budget.
            """
            import base64 as _b64
            try:
                pad = -len(stem) % 4
                return _b64.urlsafe_b64decode(stem + "=" * pad).decode("utf-8")
            except Exception:
                return stem

        exact, loose = [], []
        for p in sessions_dir.glob("*.jsonl"):
            key = _decoded(p.stem)
            if run_id not in key or "orchestrate" not in key:
                continue
            (exact if sanitized_uid and sanitized_uid in
             key.replace(":", "_").replace("/", "_") else loose).append(p)
        candidates = exact or loose
        if not candidates:
            return None
        # Newest wins: a run that was resumed has more than one session file,
        # and the live one is the one worth preserving.
        src = max(candidates, key=lambda p: p.stat().st_mtime)
        # Destination
        dst_dir = root_path / "instances" / run_id / "forensics" / "orchestrate"
        dst_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        dst = dst_dir / f"{ts}.{label}.jsonl"
        import shutil
        shutil.copy2(str(src), str(dst))
        return dst
    except Exception:
        logger.debug("snapshot_orchestrator_session failed", exc_info=True)
        return None


# ----------------------------------------------------------------------
# Module-level helper for callers that don't want to instantiate themselves
# ----------------------------------------------------------------------

_forensics_singleton: Optional[Forensics] = None


def get_forensics(root_path: Optional[Path] = None) -> Forensics:
    """Return a process-cached Forensics instance using the same DB as the
    main Store. Cheap to call repeatedly — adapter creation is the only cost
    on first call. Schema is initialized lazily on first ``get_forensics``."""
    import os
    global _forensics_singleton
    if _forensics_singleton is not None:
        return _forensics_singleton
    from ioagentfarm.engine.db import make_adapter
    db_url = os.getenv("IOF_DATABASE_URL", "")
    if not db_url:
        if root_path is None:
            root_path = Path(os.getenv("IOF_ROOT", ".iof"))
        db_url = f"sqlite:///{root_path / 'state.db'}"
    adapter = make_adapter(db_url)
    f = Forensics(adapter)
    f.init()
    # Remembered for the OTel listener, which needs the instance root to
    # find `instances/<run>/otel.json`.
    f._root_path = Path(root_path) if root_path is not None else Path(os.getenv("IOF_ROOT", ".iof"))
    _forensics_singleton = f
    return f
