"""The one seam for "which skill teaches which CLI tool".

A tool is only reachable through a skill that teaches it, so two product
surfaces answer this question: the engine's tools console (tool -> taught_by
skills) and the Studio's per-agent capability view (skill -> "via <tool>").
They derived the answer independently — the console matched only the
``tool:`` frontmatter key that ``new-skill --tool`` writes, while the Studio
also carried a hand map for the incumbent skills that teach by prose — and
the walkthrough caught them disagreeing: the per-agent view correctly showed
``iof-query via data_query`` while the console said "no skill" for every
tool. Both now read THIS module, so they cannot disagree again.

Matching, in order:
1. ``tool:`` in SKILL.md frontmatter — the explicit declaration.
2. :data:`SKILL_TOOL_HINTS` — the incumbent skills known to teach a tool
   without the frontmatter key.
3. Prose: the tool's name or binary appearing as a standalone token in the
   skill body (``iof-query`` in backticks or instructions). Deliberately
   word-bounded so ``vectorfs`` does not match ``vectorfs_query``'s own name
   in passing prose about the skill itself.
"""
from __future__ import annotations

import re

#: Incumbent skills that teach a tool in prose, predating ``new-skill
#: --tool``'s frontmatter declaration. Mirrored from the Studio's former
#: private map — additions belong here, not in either consumer.
SKILL_TOOL_HINTS: dict[str, str] = {
    "data_query": "iof-query",
    "catalog_reader": "iof-query",
    "vectorfs_query": "vectorfs",
}


def frontmatter_tool(skill_text: str) -> str | None:
    """The ``tool:`` frontmatter value, or None."""
    if not skill_text.startswith("---"):
        return None
    parts = skill_text.split("---", 2)
    if len(parts) < 3:
        return None
    m = re.search(r"^tool:\s*[\"']?([A-Za-z0-9_.-]+)[\"']?\s*$",
                  parts[1], re.M)
    return m.group(1) if m else None


def teaches(tool_name: str, bin_name: str, skill_name: str,
            skill_text: str) -> bool:
    """Whether *skill_name*/*skill_text* teaches the given tool."""
    declared = frontmatter_tool(skill_text or "")
    if declared and declared in (tool_name, bin_name):
        return True
    hinted = SKILL_TOOL_HINTS.get(skill_name)
    if hinted and hinted in (tool_name, bin_name):
        return True
    body = skill_text or ""
    for candidate in {tool_name, bin_name} - {None, ""}:
        if re.search(rf"(?<![\w-]){re.escape(candidate)}(?![\w-])", body):
            return True
    return False
