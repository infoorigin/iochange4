"""OpenTelemetry export - a LISTENER on the forensic event stream.

The proprietary forensics stay the deep record (per-attempt blobs, `explain`,
`narrative`). This module is the bridge to whatever observability stack a
client already runs - Langfuse, Arize / Phoenix, AWS AgentCore via ADOT,
Grafana, Datadog - over standard OTLP, with standard semantic conventions.

ONE INTEGRATION POINT. `Forensics.emit` is the single seam every event of a
run passes through, so this module is a subscriber to it and nothing else:
`run.created` opens a run trace context, `step.started` / `step.exec_started`
open a step span, `step.finalized` closes it with its status, every other
step event becomes a span event, and the run span is emitted when a step's
finalization turns out to have finished the run. What forensics knows, OTel
gets; nothing is emitted twice from two places.

THE TRACE, across processes. A run is many processes (driver, one `run-step`
per attempt, agent children, exec tools), so the trace is stitched with W3C
`traceparent`: the run's ids live in `instances/<run>/otel.json` from
`run.created`; a step span is live in the `run-step` process and its
traceparent goes to children in the environment (`TRACEPARENT`); an agent
child parents its `gen_ai` LLM spans to it (`_iobot_patches.otel_llm_spans`),
an exec tool parents its own span through `ioagentfarm.sdk.obs`.

    aicore.run  <run_id>                          (root; emitted at the end)
      aicore.step  plan            [exec]         attempt 1
        aicore.tool  iof-x-plan                   (sdk.obs, if the tool calls it)
      aicore.step  story:h1:reason [agent]        attempt 1
        gen_ai.chat  anthropic/…                  one per LLM call
        gen_ai.chat  …
      aicore.step  verify          [exec]         attempt 2 (status ERROR)

CONVENTIONS. OTel GenAI semantic conventions (`gen_ai.*`) are the primary -
they are what Langfuse's OTLP endpoint and AWS's GenAI observability read.
The OpenInference aliases Arize / Phoenix prefer (`openinference.span.kind`,
`llm.token_count.*`, `input.value`) are emitted beside them; attributes are
cheap and a backend ignores what it does not know. `aicore.*` carries what
is ours: run_id, step_key, attempt, role, workflow, workspace, driver.

CONFIGURATION IS STANDARD OTEL ENV, NOTHING OF OURS:

    OTEL_EXPORTER_OTLP_ENDPOINT   the switch - set it and export is on
    OTEL_EXPORTER_OTLP_HEADERS    e.g. Authorization=Basic … (Langfuse),
                                  api_key=…,arize-space-id=… (Arize)
    OTEL_SERVICE_NAME             default `aicore`
    OTEL_RESOURCE_ATTRIBUTES      deployment.environment=prod,…

plus two of ours for development and tests: `IOF_OTEL_EXPORTER=console`
prints spans to stdout; `=memory` keeps them in-process (tests). With no
endpoint and neither of those, every function here returns at once - the
layer costs one env lookup. The SDK is an optional extra
(`agentfarm-core[otel]`); absent, the same functions are no-ops.

Failures never propagate. This is called from inside `Forensics.emit`'s
own try - an export problem is logged at DEBUG and the run goes on.
"""
from __future__ import annotations

import atexit
import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from loguru import logger


def content_enabled() -> bool:
    """Whether this deployment has opted into exporting message bodies.

    THE SINGLE READER for the whole runtime. It was spelled out at each site
    that needed it, and the site added later - the agent tool spans in
    `_iobot_patches` - did not spell it out at all, so a guarantee stated
    to clients ("message bodies are not exported") was true of three span
    kinds and false of the fourth. An independent validator decoded the wire
    and found 16 of 16 tool spans carrying document text with the flag unset.

    Default OFF, and an unrecognised value is OFF: a disclosure switch fails
    closed.
    """
    return (os.environ.get("IOF_OTEL_CONTENT") or "").strip().lower() in (
        "1", "true", "yes")


# --------------------------------------------------------------------------
# on/off
# --------------------------------------------------------------------------

def exporter_kind() -> str:
    """'otlp' | 'console' | 'memory' | '' (off)."""
    k = (os.environ.get("IOF_OTEL_EXPORTER") or "").strip().lower()
    if k in ("console", "memory", "otlp"):
        return k
    if (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or "").strip():
        return "otlp"
    return ""


def enabled() -> bool:
    return bool(exporter_kind())


#: Signal paths the OTLP/HTTP spec appends to a BASE endpoint.
_SIGNAL_PATHS = {"traces": "/v1/traces", "metrics": "/v1/metrics"}


def resolved_endpoint(signal: str) -> tuple[Optional[str], Optional[str]]:
    """Where this signal will actually be POSTed, and a note if that surprises.

    The spec says ``OTEL_EXPORTER_OTLP_ENDPOINT`` is a BASE and the exporter
    appends ``/v1/traces``. Every observability vendor's copy-paste snippet -
    Phoenix, Arize, Langfuse - shows the FULL collector URL including that
    path, so the natural thing to paste produces
    ``https://host/v1/traces/v1/traces``, a 404 on every export, reported
    nowhere a person is looking. Measured against a real Phoenix endpoint
    before this existed.

    So a base that already ends in the signal's own path is honoured as the
    signal endpoint rather than doubled - and the note says so, because
    silently accepting a wrong-looking value is how the next person is
    confused instead.
    """
    signal_specific = os.environ.get(
        f"OTEL_EXPORTER_OTLP_{signal.upper()}_ENDPOINT") or ""
    if signal_specific.strip():
        return signal_specific.strip(), None

    base = (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or "").strip()
    if not base:
        return None, None

    path = _SIGNAL_PATHS[signal]
    trimmed = base.rstrip("/")

    # A base carrying ANY signal's path is a full collector URL, not a base.
    # Strip whichever it carries, then append the one being asked for - so a
    # traces URL pasted into the base does not produce
    # `.../v1/traces/v1/metrics` for the other signal.
    for other in _SIGNAL_PATHS.values():
        if trimmed.endswith(other):
            root = trimmed[: -len(other)] or "/"
            note = (
                f"OTEL_EXPORTER_OTLP_ENDPOINT ends with {other}, which the OTLP "
                f"spec treats as a base and would append a signal path to again. "
                f"Reading the base as {root} and sending {signal} to {root.rstrip('/')}{path}. "
                f"To silence this, set the base to {root} or set "
                f"OTEL_EXPORTER_OTLP_{signal.upper()}_ENDPOINT explicitly.")
            return root.rstrip("/") + path, note
    return trimmed + path, None


def configured_header_names() -> list[str]:
    """Header NAMES only - a value here is a credential."""
    raw = (os.environ.get("OTEL_EXPORTER_OTLP_HEADERS") or "").strip()
    names = []
    for part in raw.split(","):
        if "=" in part:
            names.append(part.split("=", 1)[0].strip())
    return [n for n in names if n]


def metrics_enabled() -> bool:
    """False when the deployment asked for no metrics.

    `OTEL_METRICS_EXPORTER=none` is the OTel spec's own off-switch and this
    module used to ignore it, so a metric reader was built whenever an
    endpoint was set - including against a TRACES-ONLY backend. Phoenix is
    exactly that (`/v1/metrics` is not a route: a POST there answers 405, the
    same as a path that was never defined), so every process - the driver,
    each `run-step`, each tool - posted a batch that could only fail, every
    five seconds, for its whole life. Traces were unaffected, which is why it
    reads as log noise rather than a fault; it is still a request per process
    per five seconds that nobody can consume.

    Splitting the signals (`OTEL_EXPORTER_OTLP_METRICS_ENDPOINT` at a
    collector that does accept them) is the other answer and needs nothing
    here - that variable is read by the exporter itself."""
    return (os.environ.get("OTEL_METRICS_EXPORTER") or "").strip().lower() != "none"


try:  # the optional extra
    from opentelemetry import trace as _trace, metrics as _metrics
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor
    from opentelemetry.sdk.trace.id_generator import IdGenerator, RandomIdGenerator
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.trace import SpanContext, TraceFlags, NonRecordingSpan, Status, StatusCode
    from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
    _HAVE_OTEL = True
except Exception:  # noqa: BLE001 - not installed: every entry point no-ops
    _HAVE_OTEL = False

    # THE OPTIONAL EXTRA WAS NOT OPTIONAL. `_FixedIds(IdGenerator)` further
    # down is a class STATEMENT at module level, so its base is looked up when
    # this module is imported — not when a span is emitted. Without the SDK it
    # raised `NameError: name 'IdGenerator' is not defined` and the import
    # failed outright, taking with it every command that touches this module:
    # `aicore otel check` died with a traceback where its own documented
    # behaviour is to exit 1 naming the extra to install. The comment above
    # claimed the opposite for as long as the bug existed.
    #
    # A stand-in base is enough: nothing constructs `_FixedIds` unless
    # `_HAVE_OTEL` is true, and every entry point checks that first.
    IdGenerator = object       # type: ignore[assignment,misc]
    RandomIdGenerator = None   # type: ignore[assignment]


def available() -> bool:
    return _HAVE_OTEL


# --------------------------------------------------------------------------
# providers, once per process
# --------------------------------------------------------------------------

_lock = threading.Lock()
_setup_done = False
_tracer = None
_meter = None
_span_exporter = None          # shared by the main provider and the run-span provider
_ROOT_HINT = None              # the state root the last forensic event named (spans-file routing)
_memory_spans = None           # InMemorySpanExporter when IOF_OTEL_EXPORTER=memory
_memory_metrics = None         # InMemoryMetricReader, same
_instruments: Dict[str, Any] = {}
_open_steps: Dict[Tuple[str, str, int], Any] = {}


def _resource() -> "Resource":
    from ioagentfarm import __version__ as _v  # noqa: WPS433
    attrs = {"service.name": os.environ.get("OTEL_SERVICE_NAME") or "aicore",
             "service.version": str(_v)}
    # OTEL_RESOURCE_ATTRIBUTES is merged by the SDK's default resource
    return Resource.create(attrs)


class _JsonlSpanExporter:
    """One JSON line per finished span, appended to ITS run's
    ``instances/<run_id>/otel/spans.jsonl`` - the run is read from the
    ``aicore.run_id`` attribute every span carries. The first cut keyed on
    IOF_RUN_ID, which only a step subprocess has, so the launcher's and the
    driver's spans - the run span among them - were never written and the
    file described by the docs did not exist (novice finding, round 6)."""

    def __init__(self, root_for) -> None:
        self._root_for = root_for

    def export(self, spans):
        from opentelemetry.sdk.trace.export import SpanExportResult
        try:
            root = self._root_for()
            by_run: dict = {}
            for s in spans:
                rid = str((s.attributes or {}).get("aicore.run_id")
                          or os.environ.get("IOF_RUN_ID") or "")
                if rid:
                    by_run.setdefault(rid, []).append(s)
            for rid, group in by_run.items():
                path = run_spans_file(root, rid)
                path.parent.mkdir(parents=True, exist_ok=True)
                with open(path, "a", encoding="utf-8") as fh:
                    for s in group:
                        ctx, par = s.get_span_context(), s.parent
                        fh.write(json.dumps({
                            "name": s.name,
                            "trace_id": f"{ctx.trace_id:032x}", "span_id": f"{ctx.span_id:016x}",
                            "parent_span_id": f"{par.span_id:016x}" if par else None,
                            "start_ns": s.start_time, "end_ns": s.end_time,
                            "status": str(getattr(s.status, "status_code", "")),
                            "attributes": dict(s.attributes or {}),
                            "events": [{"name": e.name, "attributes": dict(e.attributes or {})}
                                       for e in (s.events or [])],
                        }, default=str) + "\n")
            return SpanExportResult.SUCCESS
        except Exception:  # noqa: BLE001
            return SpanExportResult.FAILURE

    def shutdown(self) -> None:
        return None

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


class _TeeSpanExporter:
    """Fan one span out to several exporters."""

    def __init__(self, exporters) -> None:
        self._exporters = [e for e in exporters if e is not None]

    def export(self, spans):
        from opentelemetry.sdk.trace.export import SpanExportResult
        ok = True
        for e in self._exporters:
            try:
                ok = (e.export(spans) == SpanExportResult.SUCCESS) and ok
            except Exception:  # noqa: BLE001
                ok = False
        return SpanExportResult.SUCCESS if ok else SpanExportResult.FAILURE

    def shutdown(self) -> None:
        for e in self._exporters:
            try:
                e.shutdown()
            except Exception:  # noqa: BLE001
                pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return all(getattr(e, "force_flush", lambda *_: True)(timeout_millis) for e in self._exporters)


def run_spans_file(root: Path, run_id: str) -> Path:
    return Path(root) / "instances" / run_id / "otel" / "spans.jsonl"


def _root_for_spans() -> Path:
    return Path(_ROOT_HINT or os.environ.get("IOF_ROOT") or ".iof").resolve()


def _run_file_exporters() -> list:
    """The per-run spans file, from ANY process: the launcher, the driver,
    a step subprocess - each routes its spans by their run id."""
    return [_JsonlSpanExporter(_root_for_spans)]


def _setup() -> bool:
    global _setup_done, _tracer, _meter, _span_exporter, _memory_spans, _memory_metrics
    if _setup_done:
        return _tracer is not None
    with _lock:
        if _setup_done:
            return _tracer is not None
        _setup_done = True
        if not (_HAVE_OTEL and enabled()):
            return False
        try:
            kind = exporter_kind()
            res = _resource()
            if kind == "memory":
                from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
                from opentelemetry.sdk.metrics.export import InMemoryMetricReader
                _memory_spans = InMemorySpanExporter()
                _span_exporter = _memory_spans
                processor = SimpleSpanProcessor(_span_exporter)
                _memory_metrics = InMemoryMetricReader()
                readers = [_memory_metrics] if metrics_enabled() else []
            elif kind == "console":
                from opentelemetry.sdk.trace.export import ConsoleSpanExporter
                from opentelemetry.sdk.metrics.export import ConsoleMetricExporter
                # A code-driven run's steps are subprocesses whose stderr the
                # driver discards, so "prints every span to the terminal"
                # printed nothing for a run (novice finding, round 5). Inside
                # a run the spans are ALSO appended to the run's own
                # otel/spans.jsonl, which survives, and `explain` names it.
                _span_exporter = _TeeSpanExporter(
                    [ConsoleSpanExporter(out=sys.stderr)] + _run_file_exporters())
                processor = SimpleSpanProcessor(_span_exporter)
                readers = [PeriodicExportingMetricReader(
                    ConsoleMetricExporter(out=sys.stderr), export_interval_millis=60_000
                )] if metrics_enabled() else []
            else:
                # OTLP/HTTP protobuf. The exporters read OTEL_EXPORTER_OTLP_*
                # themselves - endpoint, headers, timeout, compression - and
                # append /v1/traces and /v1/metrics to a bare endpoint.
                from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
                from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
                # The endpoint is resolved HERE rather than left to the
                # exporter, so a base that already carries `/v1/traces` is
                # not doubled into a 404 nobody sees. `resolved_endpoint`
                # explains it; the note is logged once so the operator who
                # pasted a collector URL learns what was done with it.
                _t_ep, _t_note = resolved_endpoint("traces")
                if _t_note:
                    logger.warning("otel: {}", _t_note)
                _span_exporter = _CountingSpanExporter(
                    OTLPSpanExporter(endpoint=_t_ep) if _t_ep
                    else OTLPSpanExporter())
                processor = BatchSpanProcessor(_span_exporter, schedule_delay_millis=1000)
                if metrics_enabled():
                    _m_ep, _ = resolved_endpoint("metrics")
                    readers = [PeriodicExportingMetricReader(
                        OTLPMetricExporter(endpoint=_m_ep) if _m_ep else OTLPMetricExporter(),
                        export_interval_millis=5_000)]
                else:
                    readers = []
            tp = TracerProvider(resource=res, shutdown_on_exit=False)
            tp.add_span_processor(processor)
            _trace.set_tracer_provider(tp)
            mp = MeterProvider(resource=res, metric_readers=readers, shutdown_on_exit=False)
            _metrics.set_meter_provider(mp)
            _tracer = tp.get_tracer("ioagentfarm")
            _meter = mp.get_meter("ioagentfarm")
            _make_instruments()
            atexit.register(_shutdown, tp, mp)
            return True
        except Exception as exc:  # noqa: BLE001
            # NOT debug. An operator who set an endpoint is expecting traces;
            # swallowing the reason they will never arrive leaves them
            # debugging their collector. The run still goes on - export is
            # never load-bearing - but the reason is on the console once.
            logger.warning(
                "otel: telemetry export is OFF - setup failed: {}: {}. "
                "`aicore otel check` diagnoses this.",
                type(exc).__name__, exc)
            logger.debug("otel: setup traceback", exc_info=True)
            _tracer = None
            return False


def _fold(step_key: Optional[str]) -> str:
    """`story:h1:reason` -> `story_h1_reason`: the forensics directory name,
    which is the only spelling some callers (the agent spawn) hold."""
    return (step_key or "").replace(":", "_").replace("/", "_")


_shut: set = set()


def _shutdown(tp, mp) -> None:
    # Every CLI process is short-lived; without this a run-step's spans and
    # the last metric points would die with the process. Idempotent: tests
    # reload the module and register again.
    if id(tp) in _shut:
        return
    _shut.add(id(tp))
    for p in (tp, mp):
        try:
            p.force_flush(timeout_millis=5000)
        except Exception:  # noqa: BLE001
            pass
        try:
            p.shutdown()
        except Exception:  # noqa: BLE001
            pass


def _make_instruments() -> None:
    m = _meter
    _instruments.update({
        "step.duration": m.create_histogram("aicore.step.duration", unit="s",
                                            description="wall clock of one step attempt"),
        "run.duration": m.create_histogram("aicore.run.duration", unit="s",
                                           description="wall clock of a run"),
        "step.attempts": m.create_counter("aicore.step.attempts",
                                          description="step attempts started"),
        "step.failures": m.create_counter("aicore.step.failures",
                                          description="step attempts that ended failed, by reason"),
        "route.decisions": m.create_counter("aicore.route.decisions",
                                            description="route steps that chose"),
        "tokens": m.create_histogram("gen_ai.client.token.usage", unit="{token}",
                                     description="tokens per LLM call, by gen_ai.token.type"),
        "chat.duration": m.create_histogram("aicore.chat.duration", unit="s",
                                            description="one always-on agent turn"),
        "chat.errors": m.create_counter("aicore.chat.errors",
                                        description="always-on agent turns that raised"),
        "case.dispatches": m.create_counter("aicore.case.dispatches",
                                            description="case actions the scheduler started a run for"),
    })


class _CountingSpanExporter:
    """Wraps a span exporter and RECORDS whether the export actually worked.

    THE PREDICATE THAT WAS WRONG. The breaker was keyed on
    ``TracerProvider.force_flush()``, which returns ``True`` whether or not
    the batch reached the collector - so `ok` was always true, the failure
    count never left zero, and the breaker never engaged. A validator
    measured eight consecutive flushes at ~9s each with the counter pinned at
    0 and not one warning in seven serve logs: the fix was inert, and the
    walkthrough advertised it.

    Worse, the test that was supposed to pin it used a fake provider whose
    ``force_flush`` returned ``False`` on failure - a contract the real SDK
    does not honour - so it passed against a stub that behaved the way the
    bug assumed. Ask the EXPORTER, which is the only object that knows.
    """

    def __init__(self, inner) -> None:
        self._inner = inner
        self.failures = 0
        self.successes = 0

    def export(self, spans):
        from opentelemetry.sdk.trace.export import SpanExportResult
        try:
            result = self._inner.export(spans)
        except Exception:  # noqa: BLE001 - a failed export is data, not a crash
            self.failures += 1
            raise
        if result is SpanExportResult.SUCCESS:
            self.successes += 1
        else:
            self.failures += 1
        return result

    def shutdown(self):
        return self._inner.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return getattr(self._inner, "force_flush", lambda *_: True)(timeout_millis)


#: Consecutive failed flushes before the breaker opens, and how long it stays
#: open. Deliberately small and short: the cost of being wrong in one
#: direction is a few dropped spans, and in the other it is every turn on the
#: deployment paying the timeout.
_FLUSH_FAIL_LIMIT = 3
_FLUSH_COOLDOWN_S = 60.0

_flush_failures = 0
_flush_blocked_until = 0.0


def _flush_timeout_ms() -> int:
    """How long one flush may block. Override with IOF_OTEL_FLUSH_TIMEOUT_MS."""
    raw = (os.environ.get("IOF_OTEL_FLUSH_TIMEOUT_MS") or "").strip()
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    return 3000


def flush() -> None:
    """Push what is buffered now. Called after a step closes, and by the SDK
    at tool exit - a `run-step` process must not exit with spans unsent.

    **AN UNREACHABLE COLLECTOR MUST NOT SLOW THE DEPLOYMENT DOWN.** Each
    force_flush blocks up to its timeout, twice (traces and metrics), several
    times per turn - so against a dead endpoint an independent validator
    measured turns going from 1.5s to 12-20s, an 8-13x cost, while the
    walkthrough promised telemetry "fails silently by design". It failed
    silently in the sense that nothing raised; it was extremely loud in the
    only currency a user notices.

    So consecutive failures open a breaker: flushing is skipped for a
    cooldown, then retried once. Spans still batch and still export on their
    own schedule when the endpoint returns - what is given up is the
    guarantee that a flush pushed them RIGHT NOW, which is worth nothing when
    nothing is listening.
    """
    global _flush_failures, _flush_blocked_until
    if not _setup():
        return
    now = time.monotonic()
    if now < _flush_blocked_until:
        return
    timeout = _flush_timeout_ms()
    # THE EXPORTER'S OWN TALLY, not force_flush's return value - see
    # _CountingSpanExporter. Read before and after, so a batch that failed
    # DURING this flush is what decides, rather than a boolean that is true
    # either way.
    before = getattr(_span_exporter, "failures", None)
    t0 = time.monotonic()
    ok = True
    try:
        _trace.get_tracer_provider().force_flush(timeout_millis=timeout)
        _metrics.get_meter_provider().force_flush(timeout_millis=timeout)
    except Exception:  # noqa: BLE001
        ok = False
    elapsed = time.monotonic() - t0
    if ok and before is not None:
        ok = getattr(_span_exporter, "failures", 0) <= before
    elif ok:
        # No counting exporter (a file or in-memory sink): fall back to the
        # clock. A flush that ran to its own timeout did not deliver.
        ok = elapsed * 1000.0 < timeout * 0.9
    if ok:
        _flush_failures = 0
        return
    _flush_failures += 1
    if _flush_failures >= _FLUSH_FAIL_LIMIT:
        _flush_blocked_until = now + _FLUSH_COOLDOWN_S
        _flush_failures = 0
        # Loguru formats with {}, not %s. The first version used %-style and
        # printed the template with its placeholders intact - a warning that
        # says nothing is barely better than no warning.
        _ep, _ = resolved_endpoint("traces")
        logger.warning(
            "otel: the collector did not accept a flush {} times; pausing "
            "flushes for {:.0f}s so turns do not pay the export timeout. "
            "Spans still batch and resume when it answers. endpoint={}",
            _FLUSH_FAIL_LIMIT, _FLUSH_COOLDOWN_S, _ep or "?")


def memory_spans() -> list:
    """Finished spans, when IOF_OTEL_EXPORTER=memory (tests)."""
    return list(_memory_spans.get_finished_spans()) if _memory_spans else []


def memory_metrics() -> list:
    """Metric data points, when IOF_OTEL_EXPORTER=memory (tests)."""
    if not _memory_metrics:
        return []
    out = []
    try:
        data = _memory_metrics.get_metrics_data()
        for rm in (data.resource_metrics if data else []):
            for sm in rm.scope_metrics:
                for m in sm.metrics:
                    for pt in m.data.data_points:
                        out.append((m.name, dict(pt.attributes), getattr(pt, "sum", None) or getattr(pt, "value", None)))
    except Exception:  # noqa: BLE001
        pass
    return out


# --------------------------------------------------------------------------
# the run context: ids written once, read by every process of the run
# --------------------------------------------------------------------------

def _ctx_path(root_path: Path, run_id: str) -> Path:
    return Path(root_path) / "instances" / run_id / "otel.json"


def _write_run_context(root_path: Path, run_id: str, ts_iso: str) -> None:
    p = _ctx_path(root_path, run_id)
    if p.exists():
        return
    gen = RandomIdGenerator()
    ctx = {"trace_id": format(gen.generate_trace_id(), "032x"),
           "span_id": format(gen.generate_span_id(), "016x"),
           "start_ns": _ns(ts_iso)}
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(ctx), encoding="utf-8")


def _read_run_context(root_path: Path, run_id: str) -> Optional[dict]:
    p = _ctx_path(root_path, run_id)
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
    except (OSError, ValueError):
        return None


def _run_parent(root_path: Path, run_id: str):
    ctx = _read_run_context(root_path, run_id)
    if not ctx:
        return None
    sc = SpanContext(trace_id=int(ctx["trace_id"], 16), span_id=int(ctx["span_id"], 16),
                     is_remote=True, trace_flags=TraceFlags(TraceFlags.SAMPLED))
    return _trace.set_span_in_context(NonRecordingSpan(sc))


def _ns(ts_iso: Optional[str]) -> int:
    if not ts_iso:
        return time.time_ns()
    try:
        dt = datetime.fromisoformat(ts_iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp() * 1e9)
    except ValueError:
        return time.time_ns()


# --------------------------------------------------------------------------
# traceparent for children
# --------------------------------------------------------------------------

def traceparent(root_path: Path, run_id: str, step_key: Optional[str] = None,
                attempt: Optional[int] = None) -> Optional[str]:
    """`00-<trace>-<span>-01` for a child of the open step span, else of the run."""
    if not _setup():
        return None
    span = _open_steps.get((run_id, _fold(step_key), int(attempt or 0)))
    if span is not None:
        sc = span.get_span_context()
        return f"00-{sc.trace_id:032x}-{sc.span_id:016x}-01"
    ctx = _read_run_context(root_path, run_id)
    if ctx:
        return f"00-{ctx['trace_id']}-{ctx['span_id']}-01"
    return None


def child_env(env: Dict[str, str], root_path: Path, run_id: str,
              step_key: Optional[str] = None, attempt: Optional[int] = None,
              **extra: str) -> Dict[str, str]:
    """Add TRACEPARENT (+ extra IOF_OTEL_* hints) to a child's environment.
    A no-op when export is off, so the env stays byte-identical then."""
    if not enabled():
        return env
    tp = traceparent(root_path, run_id, step_key, attempt)
    if tp:
        env["TRACEPARENT"] = tp
    for k, v in extra.items():
        if v:
            env[k] = str(v)
    return env


# --------------------------------------------------------------------------
# the listener
# --------------------------------------------------------------------------

# THE NOISE POLICY. A span is a unit of work with a duration; an event is a
# fact on one. Chatter that is neither - the driver's 2-second polls, "I am
# about to spawn", "OUTPUT.md exists" - stays in forensics and is not
# exported: a run under the code driver would otherwise ship hundreds of
# point spans that say nothing a client's backend can use. Everything here is
# still in `aicore forensics show`; this is what leaves the building.
_EXPORT_DROP = frozenset({
    "agent.next_step_polled", "step.spawn_subprocess", "step.output_md_written",
    "agent.orchestrate_snapshot", "step.heartbeat",
})
#: Run-level events (no step) become point spans on the root only when they
#: matter - lifecycle and anything at warn or above.
_RUN_POINT_ALLOW = frozenset({
    "run.created", "run.failed", "run.done", "run.completed", "run.coverage",
    "run.driver_gave_up", "run.resumed", "supervisor.driver_resumed",
    "supervisor.step_reaped", "supervisor.gave_up", "supervisor.deadlock",
    "swarm.child_result",
})

_STEP_OPEN = ("step.started", "step.exec_started")
_STEP_CLOSE = "step.finalized"
_STEP_FAIL_EVENTS = ("step.exec_failed", "step.artifact_missing", "step.stories_missing",
                     "step.route_missing", "step.route_undeclared", "step.hard_cap_reached",
                     "step.on_fail_exhausted", "step.subprocess_died")


def on_event(*, root_path: Path, run_id: str, event_type: str, severity: str,
             step_key: Optional[str], attempt: Optional[int], role: Optional[str],
             message: Optional[str], payload: Optional[dict], ts_iso: str) -> None:
    """Called by Forensics.emit after the row is written. Never raises."""
    if not enabled():
        return
    try:
        _on_event(root_path, run_id, event_type, severity, step_key, attempt, role,
                  message, payload or {}, ts_iso)
    except Exception:  # noqa: BLE001
        logger.debug("otel: on_event %s failed", event_type, exc_info=True)


def _on_event(root_path, run_id, event_type, severity, step_key, attempt, role,
              message, payload, ts_iso) -> None:
    global _ROOT_HINT
    if _ROOT_HINT is None and root_path:
        _ROOT_HINT = Path(root_path)
    if event_type == "run.created":
        _write_run_context(root_path, run_id, ts_iso)
        return
    if event_type in _EXPORT_DROP:
        return
    if not _setup():
        return
    key = (run_id, _fold(step_key), int(attempt or 0))

    if event_type in _STEP_OPEN and step_key:
        if key in _open_steps:
            return
        parent = _run_parent(root_path, run_id)
        kind = "TOOL" if event_type == "step.exec_started" else "AGENT"
        span = _tracer.start_span(
            f"aicore.step {step_key}", context=parent, start_time=_ns(ts_iso),
            attributes=_clean({
                "aicore.run_id": run_id, "aicore.step_key": step_key,
                "aicore.step.attempt": int(attempt or 0), "aicore.step.role": role,
                "aicore.step.type": "exec" if kind == "TOOL" else "agent",
                "aicore.workflow": payload.get("workflow"),
                "gen_ai.agent.name": role if kind == "AGENT" else None,
                "gen_ai.operation.name": "invoke_agent" if kind == "AGENT" else None,
                "openinference.span.kind": kind,
                "input.value": ((payload.get("goal") or None)
                                if content_enabled() else None),
            }))
        _open_steps[key] = span
        _instruments["step.attempts"].add(1, {"aicore.step_key": step_key,
                                              "aicore.workflow": payload.get("workflow") or ""})
        return

    span = _open_steps.get(key) or _latest_open_for(run_id, step_key)

    if event_type == _STEP_CLOSE and step_key:
        status = str(payload.get("status") or ("done" if severity == "info" else "failed"))
        if span is not None:
            span.set_attribute("aicore.step.status", status)
            if status != "done":
                span.set_status(Status(StatusCode.ERROR, f"step {status}"))
            out = payload.get("output") or message
            # engine chatter is not the step's output (novice, round 7)
            if out and not str(out).startswith("_finalize_step"):
                # A STEP'S OUTPUT IS CONTENT. This site was ungated - found by
                # the guard written for the tool spans, not by the validator
                # who found those, which is the argument for a guard over an
                # audit: the same omission had happened twice.
                span.set_attribute("aicore.output.chars", len(str(out)))
                if content_enabled():
                    span.set_attribute("output.value", str(out)[:2000])
            end = _ns(ts_iso)
            dur = max(0.0, (end - span.start_time) / 1e9)
            span.end(end_time=end)
            _open_steps.pop(next((k for k, v in _open_steps.items() if v is span), key), None)
            _instruments["step.duration"].record(dur, {"aicore.step_key": step_key,
                                                       "aicore.step.status": status})
            if status != "done":
                _instruments["step.failures"].add(1, {"aicore.step_key": step_key,
                                                      "aicore.reason": "finalized_failed"})
        _maybe_emit_run_span(root_path, run_id, ts_iso)
        flush()
        return

    # everything else: an event on the open step span, or a point span on the run
    attrs = _clean({"aicore.severity": severity, "aicore.step_key": step_key,
                    "aicore.step.attempt": attempt, "aicore.message": ((message or "")[:500] if content_enabled() else None),
                    "aicore.message.chars": len(message or ""),
                    **_payload_attrs(payload)})
    if event_type in _STEP_FAIL_EVENTS and step_key:
        _instruments["step.failures"].add(1, {"aicore.step_key": step_key,
                                              "aicore.reason": event_type.split(".", 1)[1]})
    if event_type == "step.routed":
        _instruments["route.decisions"].add(1, {"aicore.step_key": step_key or ""})
    if span is not None:
        span.add_event(event_type, attributes=attrs, timestamp=_ns(ts_iso))
        if event_type in _STEP_FAIL_EVENTS:
            span.set_status(Status(StatusCode.ERROR, event_type))
    elif event_type in _RUN_POINT_ALLOW or severity in ("warn", "warning", "error", "fatal"):
        parent = _run_parent(root_path, run_id)
        # A RUN THIS PROCESS HAS NO TRACE CONTEXT FOR IS NOT OURS TO NARRATE.
        # `_run_parent` is None only when `instances/<run>/otel.json` is
        # absent - the run began before export was on, or in another state
        # root - so the point span has no trace to join and is exported as a
        # ROOT instead. Marked ERROR for anything at warn or above, it then
        # reads in the backend as a failed TRACE, which is what a person
        # scans for. Measured: a `serve` left running while the test suite
        # wrote its `cli:test` fixture rows had its supervisor sweep them and
        # emit run.failed + supervisor.workspace_unresolved for each, landing
        # 20 error-marked roots in a project where nothing real had failed -
        # and taking "traces with errors" and the latency percentiles with
        # them. The event is still in forensics, which is where a run with no
        # trace belongs.
        if parent is None:
            return
        t = _ns(ts_iso)
        s = _tracer.start_span(f"event {event_type}", context=parent, start_time=t,
                               attributes={"aicore.run_id": run_id, **attrs})
        if severity in ("error", "fatal"):
            s.set_status(Status(StatusCode.ERROR, event_type))
        s.end(end_time=t)
    if event_type in ("run.failed", "run.driver_gave_up", "run.done", "run.completed"):
        _maybe_emit_run_span(root_path, run_id, ts_iso, terminal_event=True)
        flush()


def _latest_open_for(run_id: str, step_key: Optional[str]):
    if not step_key:
        return None
    cands = [(k, v) for k, v in _open_steps.items() if k[0] == run_id and k[1] == _fold(step_key)]
    return max(cands, key=lambda kv: kv[0][2])[1] if cands else None


# --------------------------------------------------------------------------
# the run span, emitted once at the terminal transition
# --------------------------------------------------------------------------

class _FixedIds(IdGenerator):
    """The run span must carry the ids every child already used as parent."""

    def __init__(self, trace_id: int, span_id: int):
        self._t, self._s = trace_id, span_id
        self._rand = RandomIdGenerator()

    def generate_trace_id(self) -> int:
        return self._t

    def generate_span_id(self) -> int:
        s, self._s = self._s, None
        return s if s is not None else self._rand.generate_span_id()


def _emitted_marker(root_path: Path, run_id: str) -> Path:
    """Beside the run context: proof the run span has already gone out.

    ``_run_emitted`` is a set in ONE process, and a run is routinely finalized
    by two - the finalizer, and the supervisor healing it. A validator decoded
    the wire and found `aicore.run` transmitted twice with an identical
    span_id, in separate batches. Most backends upsert on span identity so
    little breaks, but it is a wasted export and it double-counts in any
    span-count metric. The marker is a file for the same reason the trace ids
    are: it is the only thing both processes can see.
    """
    return _ctx_path(root_path, run_id).with_suffix(".emitted")


_run_emitted: set = set()


def _maybe_emit_run_span(root_path: Path, run_id: str, ts_iso: str,
                        terminal_event: bool = False) -> None:
    """The run span is emitted ONCE, so it must not be emitted on a verdict
    that is still being argued.

    A FAILED RUN IS NOT FINAL. `runs.status` goes to 'failed' while a step is
    between attempts, and the harness routinely retries it back to 'done' -
    that is the whole design. This was called after EVERY step finalization
    and read the run row, so one failing attempt emitted the run span with
    `aicore.run.status=failed`, `steps.done=0`, ERROR - and `_run_emitted`
    then blocked the correction. Spans are immutable once ended, so the
    backend kept a failed run that had in fact converged.

    Measured: `brand_share_response` reported `ok_after_retries`, 1/1 steps
    done, "Run converged after 1 auto-retry" - while the trace showed it
    failed. The top-level verdict a client reads in their dashboard was the
    wrong one, and nothing disagreed with it there.

    So 'done' may be emitted from anywhere (it is terminal by construction),
    but 'failed' only from a RUN-LEVEL terminal event - `run.failed`,
    `run.driver_gave_up` - where the driver has actually given up.
    """
    if run_id in _run_emitted:
        return
    marker = None
    try:
        marker = _emitted_marker(Path(root_path), run_id)
        if marker.exists():
            _run_emitted.add(run_id)      # another process already sent it
            return
    except Exception:  # noqa: BLE001 - a marker must never block telemetry
        marker = None
    try:
        from ioagentfarm.cli import _store
        store = _store(Path(root_path))
        run = store.get_run(run_id)
    except Exception:  # noqa: BLE001
        return
    status = (run or {}).get("status")
    if status not in ("done", "failed"):
        return
    if status == "failed" and not terminal_event:
        return
    ctx = _read_run_context(root_path, run_id)
    if not ctx:
        return
    _run_emitted.add(run_id)
    # Durable, so the OTHER process that finalizes this run does not send the
    # root span a second time. Written before the export rather than after:
    # the failure this prevents is a duplicate, and a marker lost to a crash
    # mid-export costs one missing root span, which the backend shows as an
    # orphaned trace rather than as two conflicting ones.
    if marker is not None:
        try:
            marker.parent.mkdir(parents=True, exist_ok=True)
            marker.write_text(ts_iso or "", encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
    try:
        steps = store.list_steps(run_id)
    except Exception:  # noqa: BLE001
        steps = []
    tp = TracerProvider(shutdown_on_exit=False, resource=_resource(),
                        id_generator=_FixedIds(int(ctx["trace_id"], 16), int(ctx["span_id"], 16)))
    tp.add_span_processor(SimpleSpanProcessor(_span_exporter))
    tracer = tp.get_tracer("ioagentfarm")
    start, end = int(ctx["start_ns"]), _ns(ts_iso)
    span = tracer.start_span(
        f"aicore.run {run.get('workflow_name') or ''}", start_time=start,
        attributes=_clean({
            "aicore.run_id": run_id, "aicore.workflow": run.get("workflow_name"),
            "aicore.workspace": os.environ.get("IOF_WORKSPACE"),
            "aicore.run.kind": run.get("kind"), "aicore.run.status": status,
            "aicore.run.user": run.get("user_id"),
            "aicore.steps.total": len(steps),
            "aicore.steps.done": sum(1 for s in steps if s["status"] == "done"),
            "aicore.steps.failed": sum(1 for s in steps if s["status"] == "failed"),
            # a code-driven run is a CHAIN, not an agent invocation; and the
            # goal is where a client types the customer's text - it leaves
            # the machine only under IOF_OTEL_CONTENT (novice finding, round 7)
            "gen_ai.operation.name": ("invoke_agent" if (run.get("driver") or "agent") != "code" else None),
            "openinference.span.kind": ("CHAIN" if (run.get("driver") or "agent") == "code" else "AGENT"),
            "input.value": ((run.get("goal") or "")[:2000]
                            if content_enabled() else None),
            "aicore.goal.length": len(run.get("goal") or ""),
            **_case_attrs(run.get("goal") or ""),
        }))
    # run-level events (no step_key) from the record, so the root carries the
    # driver's story - polls, coverage, gave-up - whatever process emitted them
    try:
        from ioagentfarm.engine.forensics import get_forensics
        for e in get_forensics(Path(root_path)).get_run_timeline(run_id) or []:
            if e.get("step_key"):
                continue
            et = str(e.get("event_type"))
            if et in _EXPORT_DROP or not (et in _RUN_POINT_ALLOW or
                                          str(e.get("severity")) in ("warn", "warning", "error", "fatal")):
                continue
            span.add_event(str(e.get("event_type")), timestamp=_ns(e.get("ts")),
                           attributes=_clean({"aicore.message": (e.get("message") or "")[:300]}))
    except Exception:  # noqa: BLE001
        pass
    if status != "done":
        span.set_status(Status(StatusCode.ERROR, f"run {status}"))
    span.end(end_time=end)
    _instruments["run.duration"].record(max(0.0, (end - start) / 1e9),
                                        {"aicore.workflow": run.get("workflow_name") or "",
                                         "aicore.run.status": status})
    try:
        tp.force_flush(timeout_millis=3000)
    except Exception:  # noqa: BLE001
        pass


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

#: Forensic payload keys whose VALUES are content, not shape. A file path is
#: chosen by the agent and routinely carries a customer's name, an account
#: code or a case number; a message is text. They were exported with the
#: content switch OFF, so "lengths only" was true of message BODIES and not of
#: these - a validator decoded `aicore.payload.by_target_top` and read the
#: absolute path of every file the agent had touched.
_CONTENTY_PAYLOAD_KEYS = frozenset({
    "by_target_top", "target", "targets", "path", "paths", "file", "files",
    "command", "cmd", "args", "argv", "sql", "query", "prompt", "output",
    "goal", "url", "urls",
})


def _payload_attrs(payload: dict) -> dict:
    """Forensic payload as span attributes, minus the contenty values.

    Kept either way: counts, durations, statuses, ids - the shape of what
    happened. Dropped unless IOF_OTEL_CONTENT is on: anything whose value is
    chosen by the agent or typed by a user.
    """
    allow_content = content_enabled()
    out = {}
    for k, v in (payload or {}).items():
        if not allow_content and k in _CONTENTY_PAYLOAD_KEYS:
            # Say that something was there without saying what it was.
            try:
                out[f"aicore.payload.{k}.count"] = (
                    len(v) if isinstance(v, (list, tuple, dict, str)) else 1)
            except Exception:  # noqa: BLE001
                pass
            continue
        out[f"aicore.payload.{k}"] = _scalar(v)
    return out


def _scalar(v: Any) -> Any:
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    try:
        return json.dumps(v, default=str)[:500]
    except Exception:  # noqa: BLE001
        return str(v)[:500]


def _clean(d: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in d.items() if v is not None and v != ""}


def current_span():
    """The active span in THIS process, or None. Used by the SDK."""
    if not (_HAVE_OTEL and _setup()):
        return None
    s = _trace.get_current_span()
    return s if s is not None and s.get_span_context().is_valid else None


def tracer():
    return _tracer if _setup() else None


def instrument(name: str):
    return _instruments.get(name) if _setup() else None


def meter():
    return _meter if _setup() else None


# --------------------------------------------------------------------------
# the other surfaces
# --------------------------------------------------------------------------

_CASE_RE = None


def _case_attrs(goal: str) -> Dict[str, Any]:
    """The case-tier link on a run started by the dispatcher, whose goal reads
    `case:<id> action:<action> - dispatched by the scheduler: <rule> decided
    at <ts>`. Attributes, so a backend can group a case's runs."""
    import re
    global _CASE_RE
    if _CASE_RE is None:
        _CASE_RE = re.compile(r"case:(?P<case>\S+)\s+action:(?P<action>\S+)(?:.*?:\s*(?P<rule>R\d+))?")
    m = _CASE_RE.search(goal or "")
    if not m:
        return {}
    out = {"aicore.case_id": m.group("case"), "aicore.case.action": m.group("action")}
    if m.group("rule"):
        out["aicore.case.rule_id"] = m.group("rule")
    return out


_inbound_tp = None


def set_inbound_traceparent(tp):
    """An inbound W3C `traceparent` (an A2A caller's, a chat client's) becomes
    the parent of the chat turn served in this task - so an agent consulting
    another agent over A2A is ONE trace, not two. A ContextVar: per task,
    never leaking between concurrent requests."""
    global _inbound_tp
    if _inbound_tp is None:
        import contextvars
        _inbound_tp = contextvars.ContextVar("iof_inbound_traceparent", default=None)
    return _inbound_tp.set((tp or "").strip() or None)


def _inbound_context():
    if _inbound_tp is None:
        return None
    tp = _inbound_tp.get()
    if not tp:
        return None
    try:
        from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
        return TraceContextTextMapPropagator().extract({"traceparent": tp})
    except Exception:  # noqa: BLE001
        return None


def wrap_chat(process_direct, role: str):
    """One span per always-on agent TURN - the unit of work behind `/api/chat`,
    A2A `SendMessage`, Teams, the Studio proxy. Applied once in
    `AgentPool.get`, beside the pool ceiling, so every surface inherits it.

    The turn span is the current context for the duration of the call, so
    the LLM hook in the same task parents its `gen_ai.chat` spans to it - the
    in-process form of what TRACEPARENT does for a subprocess.

    Message bodies are NOT exported by default (an always-on agent sees
    customer text; MLR and PII rules apply): lengths only, and
    `IOF_OTEL_CONTENT=1` opts a deployment into `input.value`/`output.value`.
    """
    if not (_HAVE_OTEL and enabled()):
        return process_direct
    import functools
    import inspect

    @functools.wraps(process_direct)
    async def _wrapped(content, *a, **k):
        if not _setup():
            return await process_direct(content, *a, **k)
        session_key = k.get("session_key") or (a[0] if a else "") or ""
        channel = k.get("channel") or (a[1] if len(a) > 1 else "") or ""
        if str(session_key).startswith("warmup_"):
            # the pool's startup cache warm-up: two synthetic turns per
            # always-on agent, not a person's conversation - no trace
            return await process_direct(content, *a, **k)
        want_content = content_enabled()
        attrs = _clean({
            "gen_ai.agent.name": role, "gen_ai.operation.name": "invoke_agent",
            "openinference.span.kind": "AGENT",
            "aicore.session_key": str(session_key)[:200], "aicore.channel": str(channel),
            "aicore.workspace": os.environ.get("IOF_WORKSPACE"),
            "aicore.input.chars": len(str(content or "")),
            "input.value": (str(content)[:2000] if want_content else None),
        })
        t0 = time.monotonic()
        with _tracer.start_as_current_span(f"aicore.chat {role}", attributes=attrs,
                                           context=_inbound_context()) as span:
            try:
                result = await process_direct(content, *a, **k)
            except BaseException as e:  # noqa: BLE001 - record, then re-raise
                span.set_status(Status(StatusCode.ERROR, type(e).__name__))
                span.record_exception(e)
                _instruments["chat.errors"].add(1, {"gen_ai.agent.name": role,
                                                    "aicore.channel": str(channel)})
                raise
            finally:
                _instruments["chat.duration"].record(
                    time.monotonic() - t0, {"gen_ai.agent.name": role, "aicore.channel": str(channel)})
            try:
                text = result if isinstance(result, str) else getattr(result, "content", None)
                if text is not None:
                    span.set_attribute("aicore.output.chars", len(str(text)))
                    if want_content:
                        span.set_attribute("output.value", str(text)[:2000])
            except Exception:  # noqa: BLE001
                pass
            return result

    return _wrapped


def case_dispatched(root_path: Path, *, case_id: str, action: str, play_id: str,
                    workflow: str, run_id: str, attempt: int) -> None:
    """The scheduler started a run for a case action: a point span in the
    dispatcher's process, LINKED to the run's trace (an OTel span link, the
    standard way to join two traces). A backend then answers "which runs did
    this case cause" from the link, and the run root carries the case id as
    an attribute for the other direction."""
    if not (_HAVE_OTEL and enabled()) or not _setup():
        return
    try:
        from opentelemetry.trace import Link
        links = []
        ctx = _read_run_context(root_path, run_id)
        if ctx:
            links.append(Link(SpanContext(
                trace_id=int(ctx["trace_id"], 16), span_id=int(ctx["span_id"], 16),
                is_remote=True, trace_flags=TraceFlags(TraceFlags.SAMPLED))))
        t = time.time_ns()
        sp = _tracer.start_span(
            f"aicore.case.dispatch {action}", start_time=t, links=links,
            attributes=_clean({"aicore.case_id": case_id, "aicore.case.action": action,
                               "aicore.play_id": play_id, "aicore.workflow": workflow,
                               "aicore.run_id": run_id, "aicore.dispatch.attempt": attempt,
                               "openinference.span.kind": "CHAIN"}))
        sp.end(end_time=t)
        _instruments["case.dispatches"].add(1, {"aicore.play_id": play_id or "",
                                                "aicore.case.action": action})
        flush()
    except Exception:  # noqa: BLE001
        logger.debug("otel: case_dispatched failed", exc_info=True)
