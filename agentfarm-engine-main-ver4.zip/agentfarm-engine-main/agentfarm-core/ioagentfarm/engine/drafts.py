"""Content drafts — one author's unpromoted overlay on one content item.

The One Truth model (docs/one-truth-content-model.md §3.5) makes the installed
pack the only content the engine serves, which leaves the low-code author with
nowhere to put an edit. A DRAFT is that place: it is stored per AUTHOR, pinned
to the BASE it was written against, and resolved ONLY inside sessions and runs
that name its author. No other user's chat and no unflagged run ever sees it.

    base (the installed pack's files)  +  overlay (this draft's files)
    ------------------------------------------------------------------
    = what the author's Try-it session and draft run resolve

Four rules, each load-bearing:

* **Never a second content tier.** A draft is not served to anyone but its
  author, so it cannot become the "what is actually running here?" ambiguity
  the model exists to remove. Everything else keeps resolving the pack.
* **Base-pinned, so staleness is detectable.** ``base_stamp`` records the
  content stamp the author edited against and ``base_files_json`` the exact
  bytes of the touched paths. When the environment moves to a new pack the
  draft is STALE and the Studio can show a three-way diff; nothing is rebased
  on the author's behalf.
* **Promotion is a person's act, on a developer desktop.** This platform never
  commits or pushes to git (organisational policy: the engine has no repository
  access). ``aicore drafts apply`` writes the draft's files into a checkout;
  when the change lands in the installed pack the draft reads PROMOTED because
  the base bytes now equal it — detected, never declared.
* **Carriage is content.** An agent's skill assignment travels in the overlay
  under the reserved key :data:`SKILLS_KEY`, so a Studio-side add or removal on
  a pack agent is draft-only until promoted, exactly like a SOUL.md edit.

**This module holds the pure logic and the SQL, and nothing that touches a
filesystem.** That split is not tidiness: the Studio API pod has no filesystem
(CLAUDE.md, "THE STUDIO API HAS NO FILESYSTEM") and imports this module, so a
disk call here would fail there in production while passing every local test.
Everything that materialises a draft on disk lives in
:mod:`ioagentfarm.engine.draft_files`, which the API never imports.

The SQL functions take a raw DBAPI ``con`` plus ``is_pg`` rather than a
``Store``, because the API has no ``Store`` — it yields a plain connection from
``app/database.py``. :class:`DraftStore` is the engine-side convenience that
adapts a ``Store`` onto the same verbs, so both sides run one implementation.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from datetime import datetime, timezone
from difflib import unified_diff as _unified_diff
from typing import Any, Iterable, Sequence

logger = logging.getLogger(__name__)

TABLE = "content_drafts"
INDEX = "idx_content_drafts_ws_author_status"

#: The kinds an item can be. A draft is scoped to one of them plus a name.
KINDS = ("agent", "skill", "workflow")

#: Reserved overlay key: the agent's skill carriage (a list of skill names).
#: It is not a file path, so every file-walking consumer must skip it — that is
#: what :func:`overlay` does and why the key starts with an underscore.
SKILLS_KEY = "_skills"

#: Draft lifecycle. 'draft' is editable; 'applied' means a developer ran
#: ``aicore drafts apply`` into a checkout; 'promoted' is DERIVED (the base
#: caught up) and recorded so the Studio stops nagging; 'discarded' is a
#: tombstone kept for the audit trail rather than a DELETE.
STATUSES = ("draft", "applied", "promoted", "discarded")

#: Default filter for a listing: what a user still has outstanding.
OPEN_STATUSES = ("draft", "applied")

#: A unified diff is shown in a browser and in a terminal; an unbounded one is
#: neither readable nor cheap. Mirrors the runtime's own diff limits.
MAX_DIFF_LINES = 400
MAX_DIFF_CHARS = 40_000

_SLUG_RE = re.compile(r"[^a-z0-9._-]+")

_COLUMNS = (
    "id", "workspace_code", "kind", "name", "author", "files_json",
    "base_files_json", "base_stamp", "base_pack", "base_version",
    "base_git_sha", "content_hash", "status", "note", "created_at",
    "updated_at", "applied_at", "applied_by", "applied_host", "promoted_at",
    "promoted_ref",
)
_SELECT = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# DDL — declared once, ensured by both schema ensurers
# ---------------------------------------------------------------------------

def content_drafts_ddl(is_pg: bool) -> list[str]:
    """The table + its indexes, in the dialect asked for. Idempotent.

    Same four-place contract as ``content_registration``: this function is the
    ONE declaration, called by ``engine/store.py`` ``Store.init`` (engine side)
    and ``workspace_sync.ensure_platform_schema`` (API side); the psql script
    and the API tests' schema carry mirrored copies. A table declared in some
    of those places works in one environment and not another.

    Timestamps are TIMESTAMP columns holding ISO-8601 UTC STRINGS on both
    backends — the same rule (and the same reason) as
    :mod:`ioagentfarm.engine.registration`.
    """
    auto_id = "SERIAL PRIMARY KEY" if is_pg else "INTEGER PRIMARY KEY AUTOINCREMENT"
    return [
        f"""CREATE TABLE IF NOT EXISTS {TABLE} (
            id              {auto_id},
            workspace_code  TEXT NOT NULL,
            kind            TEXT NOT NULL,
            name            TEXT NOT NULL,
            author          TEXT NOT NULL,
            files_json      TEXT NOT NULL DEFAULT '{{}}',
            base_files_json TEXT NOT NULL DEFAULT '{{}}',
            base_stamp      TEXT NOT NULL DEFAULT '',
            base_pack       TEXT NOT NULL DEFAULT '',
            base_version    TEXT NOT NULL DEFAULT '',
            base_git_sha    TEXT NOT NULL DEFAULT '',
            content_hash    TEXT NOT NULL DEFAULT '',
            status          TEXT NOT NULL DEFAULT 'draft',
            note            TEXT NOT NULL DEFAULT '',
            created_at      TIMESTAMP NOT NULL,
            updated_at      TIMESTAMP NOT NULL,
            applied_at      TIMESTAMP,
            applied_by      TEXT NOT NULL DEFAULT '',
            applied_host    TEXT NOT NULL DEFAULT '',
            promoted_at     TIMESTAMP,
            promoted_ref    TEXT NOT NULL DEFAULT ''
        );""",
        # One live draft per (tenant, item, author). A second edit UPDATES;
        # without this an author accumulates drafts and "which one does Try-it
        # resolve?" is exactly the ambiguity this model removes.
        f"CREATE UNIQUE INDEX IF NOT EXISTS idx_{TABLE}_item_author "
        f"ON {TABLE}(workspace_code, kind, name, author);",
        f"CREATE INDEX IF NOT EXISTS {INDEX} "
        f"ON {TABLE}(workspace_code, author, status);",
    ]


def ensure_table(con: Any, *, is_pg: bool) -> None:
    """Create the table on a connection whose schema ensurer has not run."""
    cur = con.cursor()
    try:
        for ddl in content_drafts_ddl(is_pg):
            cur.execute(ddl)
    finally:
        cur.close()


# ---------------------------------------------------------------------------
# pure helpers
# ---------------------------------------------------------------------------

def author_slug(email: str) -> str:
    """A filesystem-safe, stable directory name for an author.

    Lowercased, ``@``/``+`` and every other unsafe character folded to ``-``,
    with a short hash of the ORIGINAL appended so two addresses that fold to
    the same slug (``a.b@x`` and ``a-b@x``) never share a draft home.
    """
    raw = (email or "").strip().lower()
    if not raw:
        raise ValueError("author_slug: an author email is required")
    base = _SLUG_RE.sub("-", raw).strip("-") or "author"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:8]
    return f"{base[:48]}-{digest}"


def normalise_files(files: dict | None) -> dict:
    """Validate an overlay map: ``{posix rel path: text | None}`` + ``_skills``.

    ``None`` means "delete this file from the base". Raises ``ValueError`` on
    an absolute path, a ``..`` segment, a backslash, or a non-string body —
    the same refusal the writer performs, done HERE so a bad overlay is
    rejected at save time rather than at materialisation time on some pod.
    """
    out: dict = {}
    for key, value in (files or {}).items():
        if not isinstance(key, str) or not key.strip():
            raise ValueError("draft overlay: file paths must be non-empty strings")
        if key == SKILLS_KEY:
            if value is None:
                out[key] = None
                continue
            if not isinstance(value, (list, tuple)):
                raise ValueError(f"draft overlay: {SKILLS_KEY} must be a list of skill names")
            names = sorted({str(v).strip() for v in value if str(v).strip()})
            out[key] = names
            continue
        rel = key.replace("\\", "/").strip()
        if rel.startswith("/") or re.match(r"^[A-Za-z]:", rel):
            raise ValueError(f"draft overlay: absolute path refused: {key!r}")
        if any(part in ("..", "") for part in rel.split("/")):
            raise ValueError(f"draft overlay: path escapes the item: {key!r}")
        if value is not None and not isinstance(value, str):
            raise ValueError(f"draft overlay: {key!r} must be text or null (delete)")
        out[rel] = value
    return out


def overlay(base: dict | None, files: dict | None) -> dict:
    """``base`` with the overlay applied — the bytes a draft session resolves.

    Pure: returns a new ``{rel: text}`` map. ``None`` in the overlay deletes;
    :data:`SKILLS_KEY` is carriage, not a file, and is skipped (the agent-home
    builder reads it from the draft record itself).
    """
    out = dict(base or {})
    for rel, value in (files or {}).items():
        if rel == SKILLS_KEY:
            continue
        if value is None:
            out.pop(rel, None)
        else:
            out[rel] = value
    return out


def carried_skills(files: dict | None) -> list[str] | None:
    """The carriage an agent draft declares, or ``None`` when it declares none.

    Sorted and de-duplicated here as well as at save time: this is read by the
    home builder, which may be handed an overlay that never went through
    :func:`normalise_files` (a caller composing one in memory).
    """
    value = (files or {}).get(SKILLS_KEY)
    if value is None:
        return None
    return sorted({str(v).strip() for v in value if str(v).strip()})


def touched_paths(files: dict | None) -> list[str]:
    """Every base path an overlay writes or deletes (carriage excluded)."""
    return sorted(k for k in (files or {}) if k != SKILLS_KEY)


def canonical_hash(files: dict | None) -> str:
    """Stable sha256 of an overlay — the draft's content identity.

    Canonical means sorted keys and a compact separator, so two saves of the
    same content hash identically regardless of dict ordering. This value is
    what the engine's draft pool compares to decide a session's agent home is
    out of date, so a spurious change costs a rebuild and a missed change
    serves stale content.
    """
    payload = json.dumps(normalise_files(files), sort_keys=True,
                         separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def draft_signature(drafts: Sequence[dict] | None) -> str:
    """One value identifying a SET of drafts, for cache invalidation."""
    items = sorted((str(d.get("id")), str(d.get("content_hash") or ""))
                   for d in (drafts or []))
    return hashlib.sha256(
        json.dumps(items, separators=(",", ":")).encode("utf-8")).hexdigest()


def provenance_summary(drafts: Sequence[dict] | None) -> list[dict]:
    """``{id, kind, name, content_hash, base_stamp}`` per draft.

    What a draft session's reply and a draft run's provenance record carry:
    enough to say WHICH drafts shaped an answer, without any content. One
    implementation so the chat and run surfaces cannot drift on the shape.
    """
    return [{"id": d.get("id"), "kind": d.get("kind"), "name": d.get("name"),
             "content_hash": d.get("content_hash"),
             "base_stamp": d.get("base_stamp")}
            for d in (drafts or [])]


def unified_diff(path: str, before: str | None, after: str | None,
                 *, max_lines: int = MAX_DIFF_LINES,
                 max_chars: int = MAX_DIFF_CHARS) -> str:
    """A bounded unified diff for one file. ``''`` when the bytes are equal.

    ``None`` on either side is rendered as an empty file, so an addition and a
    deletion both produce a readable diff instead of a special case.
    """
    a = (before or "").splitlines(keepends=True)
    b = (after or "").splitlines(keepends=True)
    if a == b:
        return ""
    lines = list(_unified_diff(a, b, fromfile=f"a/{path}", tofile=f"b/{path}"))
    truncated = False
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        truncated = True
    text = "".join(lines)
    if len(text) > max_chars:
        text = text[:max_chars]
        truncated = True
    if truncated:
        text = text.rstrip("\n") + "\n... (diff truncated)\n"
    return text


def diff_files(before: dict | None, after: dict | None, **kw) -> list[dict]:
    """Per-file diffs between two ``{rel: text}`` maps.

    ``[{path, change: 'added'|'removed'|'modified', diff}]``, sorted by path.
    Unchanged files are omitted.
    """
    a, b = dict(before or {}), dict(after or {})
    out: list[dict] = []
    for path in sorted(set(a) | set(b)):
        old, new = a.get(path), b.get(path)
        if old == new:
            continue
        change = "added" if old is None else "removed" if new is None else "modified"
        out.append({"path": path, "change": change,
                    "diff": unified_diff(path, old, new, **kw)})
    return out


def staleness(draft: dict, current_stamp: str | None,
              current_base: dict | None) -> dict:
    """Is this draft stale, and has it already landed?

    * ``stale`` — the environment's content stamp is not the one the draft was
      written against. The Studio then offers a three-way diff and a rebase;
      nothing rebases automatically, because only the author knows whether the
      new base changed the meaning of their edit.
    * ``promoted`` — every path the draft touches already reads exactly what
      the draft says in the CURRENT base. That is what promotion looks like
      from here: a developer applied it, it was merged, built and deployed.
      Derived, so a draft cannot claim to be promoted while the pod still runs
      the old bytes.
    * ``conflicts`` — paths whose base bytes moved since the pin AND that the
      draft also rewrites. Those are the ones a rebase has to be looked at for;
      a path only the base changed is not the author's problem.
    """
    pinned = _loads(draft.get("base_files_json"))
    files = _loads(draft.get("files_json"))
    current = dict(current_base or {})
    stale = bool(current_stamp) and (draft.get("base_stamp") or "") != current_stamp

    paths = touched_paths(files)
    promoted = bool(paths) and all(
        current.get(p) == files.get(p) for p in paths)
    # A carriage-only draft (skills added/removed, no file edits) has no bytes
    # to compare, so it can never be auto-detected as promoted.
    if not paths:
        promoted = False

    conflicts = [p for p in paths
                 if p in pinned and pinned.get(p) != current.get(p)
                 and files.get(p) is not None]
    return {"stale": stale, "promoted": promoted, "conflicts": conflicts}


# ---------------------------------------------------------------------------
# row plumbing
# ---------------------------------------------------------------------------

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _loads(raw: Any) -> dict:
    if isinstance(raw, dict):
        return dict(raw)
    if not raw:
        return {}
    try:
        value = json.loads(raw)
    except (TypeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def _dumps(files: dict | None) -> str:
    return json.dumps(normalise_files(files), sort_keys=True,
                      separators=(",", ":"), ensure_ascii=False)


def _iso(value: Any) -> Any:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    return value


def row_to_dict(row: Any) -> dict:
    """A driver row as a plain dict with parsed JSON and ISO timestamps."""
    d = dict(row) if not isinstance(row, dict) else dict(row)
    d["files"] = _loads(d.get("files_json"))
    d["base_files"] = _loads(d.get("base_files_json"))
    for key in ("created_at", "updated_at", "applied_at", "promoted_at"):
        d[key] = _iso(d.get(key))
    return d


def _q(sql: str, is_pg: bool) -> str:
    """Placeholder rewrite — the same rule ``Store._q`` applies."""
    return sql.replace("?", "%s") if is_pg else sql


def _validate(kind: str, name: str, author: str, workspace_code: str) -> None:
    if kind not in KINDS:
        raise ValueError(f"draft kind must be one of {KINDS}, got {kind!r}")
    if not (name or "").strip():
        raise ValueError("draft: an item name is required")
    if not (author or "").strip():
        raise ValueError("draft: an author is required")
    if not (workspace_code or "").strip():
        raise ValueError("draft: a workspace_code is required")


# ---------------------------------------------------------------------------
# SQL — raw connection + is_pg, so the API can call it with its own connection
# ---------------------------------------------------------------------------

def upsert_draft(con: Any, *, is_pg: bool, workspace_code: str, kind: str,
                 name: str, author: str, files: dict,
                 base_files: dict | None = None, base_stamp: str = "",
                 base_pack: str = "", base_version: str = "",
                 base_git_sha: str = "", note: str = "") -> dict:
    """Create or replace this author's draft of one item; return the row.

    A second save REPLACES the overlay rather than merging it — the Studio
    always sends the full item, and a merge would make "what is in my draft?"
    depend on the order of saves. The base pin is refreshed too: an author
    saving again is editing against what they can currently see.

    A draft that was applied, promoted or discarded and is edited again
    returns to ``draft`` — the author is working on it once more.
    """
    _validate(kind, name, author, workspace_code)
    author = author.strip().lower()
    files_json = _dumps(files)
    base_json = _dumps(base_files)
    digest = canonical_hash(files)
    now = _utc_now_iso()
    cur = con.cursor()
    try:
        cur.execute(_q(
            f"SELECT id FROM {TABLE} WHERE workspace_code=? AND kind=? "
            "AND name=? AND author=?", is_pg),
            (workspace_code, kind, name, author))
        hit = cur.fetchone()
        if hit is not None:
            draft_id = hit["id"] if not isinstance(hit, tuple) else hit[0]
            cur.execute(_q(
                f"UPDATE {TABLE} SET files_json=?, base_files_json=?, "
                "base_stamp=?, base_pack=?, base_version=?, base_git_sha=?, "
                "content_hash=?, status='draft', note=?, updated_at=?, "
                "applied_at=NULL, applied_by='', applied_host='', "
                "promoted_at=NULL, promoted_ref='' WHERE id=?", is_pg),
                (files_json, base_json, base_stamp, base_pack, base_version,
                 base_git_sha, digest, note, now, draft_id))
        else:
            cur.execute(_q(
                f"INSERT INTO {TABLE}(workspace_code, kind, name, author, "
                "files_json, base_files_json, base_stamp, base_pack, "
                "base_version, base_git_sha, content_hash, status, note, "
                "created_at, updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,'draft',?,?,?)", is_pg),
                (workspace_code, kind, name, author, files_json, base_json,
                 base_stamp, base_pack, base_version, base_git_sha, digest,
                 note, now, now))
    finally:
        cur.close()
    _commit(con)
    found = find_draft(con, workspace_code, kind, name, author, is_pg=is_pg)
    if found is None:  # pragma: no cover - the row was just written
        raise RuntimeError("draft upsert did not persist")
    return found


def get_draft(con: Any, draft_id: int, *, is_pg: bool) -> dict | None:
    cur = con.cursor()
    try:
        cur.execute(_q(f"SELECT {_SELECT} FROM {TABLE} WHERE id=?", is_pg),
                    (draft_id,))
        row = cur.fetchone()
    finally:
        cur.close()
    return row_to_dict(row) if row is not None else None


def find_draft(con: Any, workspace_code: str, kind: str, name: str,
               author: str, *, is_pg: bool,
               statuses: Iterable[str] | None = OPEN_STATUSES) -> dict | None:
    """This author's draft of one item, or ``None``.

    ``statuses=None`` includes discarded and promoted rows (the audit view);
    the default is what Try-it and the Studio resolve.
    """
    sql = (f"SELECT {_SELECT} FROM {TABLE} WHERE workspace_code=? AND kind=? "
           "AND name=? AND author=?")
    params: list[Any] = [workspace_code, kind, name, (author or "").strip().lower()]
    if statuses:
        statuses = tuple(statuses)
        sql += f" AND status IN ({','.join('?' for _ in statuses)})"
        params.extend(statuses)
    cur = con.cursor()
    try:
        cur.execute(_q(sql, is_pg), tuple(params))
        row = cur.fetchone()
    finally:
        cur.close()
    return row_to_dict(row) if row is not None else None


def list_drafts(con: Any, workspace_code: str, *, is_pg: bool,
                author: str | None = None, kind: str | None = None,
                name: str | None = None,
                statuses: Iterable[str] | None = OPEN_STATUSES) -> list[dict]:
    """Drafts in a workspace, newest first. Filters are ANDed."""
    sql = f"SELECT {_SELECT} FROM {TABLE} WHERE workspace_code=?"
    params: list[Any] = [workspace_code]
    if author:
        sql += " AND author=?"
        params.append(author.strip().lower())
    if kind:
        sql += " AND kind=?"
        params.append(kind)
    if name:
        sql += " AND name=?"
        params.append(name)
    if statuses:
        statuses = tuple(statuses)
        sql += f" AND status IN ({','.join('?' for _ in statuses)})"
        params.extend(statuses)
    sql += " ORDER BY updated_at DESC, id DESC"
    cur = con.cursor()
    try:
        cur.execute(_q(sql, is_pg), tuple(params))
        rows = cur.fetchall()
    finally:
        cur.close()
    return [row_to_dict(r) for r in rows]


def set_status(con: Any, draft_id: int, status: str, *, is_pg: bool,
               applied_by: str = "", applied_host: str = "",
               promoted_ref: str = "") -> dict | None:
    """Move a draft's lifecycle marker; return the row."""
    if status not in STATUSES:
        raise ValueError(f"draft status must be one of {STATUSES}, got {status!r}")
    now = _utc_now_iso()
    sets = ["status=?", "updated_at=?"]
    params: list[Any] = [status, now]
    if status == "applied":
        sets += ["applied_at=?", "applied_by=?", "applied_host=?"]
        params += [now, applied_by, applied_host]
    elif status == "promoted":
        sets += ["promoted_at=?", "promoted_ref=?"]
        params += [now, promoted_ref]
    params.append(draft_id)
    cur = con.cursor()
    try:
        cur.execute(_q(f"UPDATE {TABLE} SET {', '.join(sets)} WHERE id=?", is_pg),
                    tuple(params))
    finally:
        cur.close()
    _commit(con)
    return get_draft(con, draft_id, is_pg=is_pg)


def rebase_draft(con: Any, draft_id: int, *, is_pg: bool,
                 base_files: dict, base_stamp: str, base_pack: str = "",
                 base_version: str = "", base_git_sha: str = "") -> dict | None:
    """Re-pin a stale draft to the CURRENT base, keeping the overlay.

    An explicit act — the author has looked at the three-way diff and decided
    their edit still means what they intended against the new base.
    """
    cur = con.cursor()
    try:
        cur.execute(_q(
            f"UPDATE {TABLE} SET base_files_json=?, base_stamp=?, base_pack=?, "
            "base_version=?, base_git_sha=?, status='draft', updated_at=? "
            "WHERE id=?", is_pg),
            (_dumps(base_files), base_stamp, base_pack, base_version,
             base_git_sha, _utc_now_iso(), draft_id))
    finally:
        cur.close()
    _commit(con)
    return get_draft(con, draft_id, is_pg=is_pg)


def _commit(con: Any) -> None:
    """Commit when the caller's connection is not in autocommit.

    Both callers hand us a live connection they own: the API's ``get_db()``
    context manager and the engine's ``Store``. Committing here keeps a write
    durable for a caller that does not commit, and is harmless for one that
    does — but a connection with no ``commit`` (a mock) must not break.
    """
    commit = getattr(con, "commit", None)
    if callable(commit):
        try:
            commit()
        except Exception:  # noqa: BLE001 - an outer transaction owns the commit
            logger.debug("content_drafts: commit deferred to the caller",
                         exc_info=True)


# ---------------------------------------------------------------------------
# engine-side convenience
# ---------------------------------------------------------------------------

class DraftStore:
    """The same verbs over an engine ``Store``.

    The engine has a ``Store``; the API has a bare connection. Rather than two
    implementations, this adapts one onto the other — ``is_pg`` comes from the
    adapter's placeholder, the connection from the store's own context manager.
    """

    def __init__(self, store: Any):
        self._store = store

    @property
    def is_pg(self) -> bool:
        return self._store._db.placeholder() == "%s"

    def _con(self):
        return self._store._conn()

    def ensure_table(self) -> None:
        with self._con() as con:
            self._store._db.init_connection(con)
            ensure_table(con, is_pg=self.is_pg)

    def upsert(self, **kw) -> dict:
        with self._con() as con:
            self._store._db.init_connection(con)
            return upsert_draft(con, is_pg=self.is_pg, **kw)

    def get(self, draft_id: int) -> dict | None:
        with self._con() as con:
            self._store._db.init_connection(con)
            return get_draft(con, draft_id, is_pg=self.is_pg)

    def find(self, workspace_code: str, kind: str, name: str, author: str,
             **kw) -> dict | None:
        with self._con() as con:
            self._store._db.init_connection(con)
            return find_draft(con, workspace_code, kind, name, author,
                              is_pg=self.is_pg, **kw)

    def list(self, workspace_code: str, **kw) -> list[dict]:
        with self._con() as con:
            self._store._db.init_connection(con)
            return list_drafts(con, workspace_code, is_pg=self.is_pg, **kw)

    def set_status(self, draft_id: int, status: str, **kw) -> dict | None:
        with self._con() as con:
            self._store._db.init_connection(con)
            return set_status(con, draft_id, status, is_pg=self.is_pg, **kw)

    def rebase(self, draft_id: int, **kw) -> dict | None:
        with self._con() as con:
            self._store._db.init_connection(con)
            return rebase_draft(con, draft_id, is_pg=self.is_pg, **kw)


def for_author(store: Any, workspace_code: str, author: str) -> list[dict]:
    """Every open draft one author holds in a workspace — what a draft session
    and a draft run resolve. Returns ``[]`` for no author (the ordinary path),
    so callers need no special case."""
    if not (author or "").strip():
        return []
    return DraftStore(store).list(workspace_code, author=author)
