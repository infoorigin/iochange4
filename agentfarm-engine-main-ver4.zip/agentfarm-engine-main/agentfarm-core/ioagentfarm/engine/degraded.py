"""What the engine knows is wrong, carried to the surface someone reads.

THE SHAPE THIS FIXES. A crash validator ran twenty-five damage experiments
and the dominant failure was not a crash - it was a confident wrong answer.
In almost every case the engine HAD DETECTED the problem:

* a session file with one bad byte: the runtime logged
  ``Repair failed for session ...`` and then answered *"this session has no
  history"* with HTTP 200 and ``error: null`` - and overwrote the file;
* a missing ``SOUL.md``: ``lint-agent`` says *"the agent has no identity at
  all"*, while the serving path answered as a generic assistant with every
  stated guardrail gone, HTTP 200, ``error: null``;
* an uninstalled pack: the CLI correctly said the agent did not exist while
  ``serve`` kept pre-warming and answering as it;
* a corrupt database: ``memory list`` raised, ``memory status`` printed a
  healthy table.

Detection was never the gap. **Propagation was.** Every one of those was a
WARNING in a log nobody was reading, beside an answer that claimed nothing
was wrong.

So this is a per-process register. A site that detects a degradation records
it here; the surfaces a person actually looks at read it back:

* a chat reply carries ``warnings`` beside its content;
* ``/ready`` stops claiming ready while a degradation is active;
* the CLI can print it.

WHAT IT IS NOT. Not an error channel - a degradation is a thing that is wrong
while the engine keeps working, which is exactly the case that was silent.
Not persistent: it describes THIS process's view of THIS host, so it is
rebuilt on restart rather than carried in a database that would then need its
own truth. And not a substitute for the log, which stays the record.

Bounded on purpose: a repeated degradation updates its entry rather than
appending, so a failing session cannot fill memory or bury the others.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Optional

from loguru import logger

#: Severity, in the only two levels that change what a reader does.
WARN = "warn"        # answers are still trustworthy; something needs attention
DEGRADED = "degraded"  # answers may be WRONG, and the caller must be told

_LOCK = threading.Lock()
_ENTRIES: Dict[str, Dict[str, Any]] = {}

#: Above this, the register stops accepting NEW keys - it is a summary, not a
#: queue, and an unbounded one would become the thing nobody reads.
_MAX_ENTRIES = 200


def record(code: str, message: str, *, severity: str = DEGRADED,
           scope: str = "", detail: Optional[Dict[str, Any]] = None,
           quiet: bool = False) -> None:
    """Note that something is wrong and the engine is continuing anyway.

    *code* is a stable slug (``session.repair_failed``); *scope* narrows it to
    one agent, workspace or session so a reader knows what is affected, and
    two scopes of the same code do not overwrite each other.
    """
    key = f"{code}:{scope}" if scope else code
    now = time.time()
    with _LOCK:
        entry = _ENTRIES.get(key)
        if entry is None:
            if len(_ENTRIES) >= _MAX_ENTRIES:
                return
            entry = {"code": code, "scope": scope, "severity": severity,
                     "message": message, "first_seen": now, "count": 0}
            _ENTRIES[key] = entry
        entry["message"] = message
        entry["severity"] = severity
        entry["last_seen"] = now
        entry["count"] += 1
        if detail:
            entry["detail"] = detail
    # The log stays the record; this makes the register's own arrival visible
    # in it, so the two never tell different stories about when.
    #
    # `quiet` exists for ONE caller: the log bridge below. Logging from inside
    # a loguru sink re-enters the handler and loguru refuses it - "Could not
    # acquire internal lock ... deadlock avoided" - printing a traceback per
    # bridged record. The runtime has already logged the underlying line, so
    # there is nothing lost by staying silent here.
    if not quiet:
        logger.warning("degraded [{}]{}: {}", code,
                       f" ({scope})" if scope else "", message)


def clear(code: str, scope: str = "") -> None:
    """Withdraw a degradation that has been resolved."""
    key = f"{code}:{scope}" if scope else code
    with _LOCK:
        _ENTRIES.pop(key, None)


def clear_scope(scope: str) -> int:
    """Withdraw everything recorded against one scope. Returns how many."""
    with _LOCK:
        gone = [k for k, v in _ENTRIES.items() if v.get("scope") == scope]
        for k in gone:
            _ENTRIES.pop(k, None)
    return len(gone)


def active(scope: str = "", severity: str = "") -> List[Dict[str, Any]]:
    """Current degradations, worst first, newest first within a severity."""
    with _LOCK:
        rows = list(_ENTRIES.values())
    if scope:
        rows = [r for r in rows if r.get("scope") in ("", scope)]
    if severity:
        rows = [r for r in rows if r.get("severity") == severity]
    rows.sort(key=lambda r: (r.get("severity") != DEGRADED,
                             -float(r.get("last_seen") or 0)))
    return rows


def warnings_for(scope: str = "") -> List[Dict[str, str]]:
    """The compact form a chat reply carries.

    Deliberately small - code, severity and one sentence. A caller rendering
    this into a UI needs to say WHAT is wrong, not to debug it; the log and
    the CLI carry the rest.
    """
    return [{"code": r["code"], "severity": r["severity"],
             "message": r["message"]}
            for r in active(scope=scope)]


def is_degraded(scope: str = "") -> bool:
    """True when answers from this scope may be wrong."""
    return any(r.get("severity") == DEGRADED for r in active(scope=scope))


def reset() -> None:
    """Empty the register. For tests and for a deliberate re-evaluation."""
    with _LOCK:
        _ENTRIES.clear()


# ---------------------------------------------------------------------------
# The bridge: the runtime already says these things, to a log nobody reads
# ---------------------------------------------------------------------------

#: Runtime log lines that mean "an answer may be wrong", mapped to a code and
#: a sentence a caller can act on.
#:
#: A BRIDGE RATHER THAN A PATCH, deliberately. The session repair that discards
#: a conversation lives in the vendored runtime, which must never be
#: hand-edited - and the general problem is not that one site: it is that the
#: runtime detects things and only says so in a log. Matching its own words
#: catches this class without forking it, and a phrasing change degrades to
#: "not surfaced", never to a crash.
_RUNTIME_SIGNALS = (
    ("Repair failed for session", "session.repair_failed", DEGRADED,
     "this conversation's history could not be read and has been discarded - "
     "the reply was composed without it"),
    ("Skipped", "session.partially_recovered", WARN,
     "part of this conversation's history was unreadable and was skipped"),
    ("Failed to load session", "session.load_failed", DEGRADED,
     "this conversation's history could not be loaded - the reply was "
     "composed without it"),
)

_WATCHING = False


def _session_key_in(text: str) -> str:
    """The session a runtime line is about, so a warning is scoped.

    A session key IS colon-separated (`web:chat:general:cora:u:alice`), so the
    first version - which split on `:` to find a token - returned `web` and
    scoped every conversation's warning to the same bucket. Caught by running
    it: `is_degraded("web:chat:...")` came back False for a session that had
    just failed.
    """
    for token in text.split():
        stripped = token.rstrip(":,.;")
        if stripped.count(":") >= 2 and (
                stripped.startswith("web:") or stripped.startswith("a2a:")
                or stripped.startswith("iof:")):
            return stripped
    return ""


def watch_runtime_logs() -> bool:
    """Record a degradation when the runtime logs one. Idempotent.

    Returns True if the sink was installed by this call.
    """
    global _WATCHING
    if _WATCHING:
        return False
    try:
        def _sink(message) -> None:
            try:
                rec = message.record
                if rec["level"].no < 30:          # WARNING and above only
                    return
                text = str(rec["message"])
                for needle, code, sev, sentence in _RUNTIME_SIGNALS:
                    if needle in text and "session" in text:
                        record(code, sentence, severity=sev,
                               scope=_session_key_in(text),
                               detail={"runtime": text[:300]},
                               quiet=True)
                        return
            except Exception:  # noqa: BLE001 - a sink must never raise
                pass

        logger.add(_sink, level="WARNING", enqueue=False)
        _WATCHING = True
        return True
    except Exception:  # noqa: BLE001
        logger.debug("degraded: could not watch runtime logs", exc_info=True)
        return False
