"""Everything the PLATFORM owns, and one way to create all of it.

`aicore init` used to leave 12 tables behind, then 21. Both numbers were an
accident of which provisioner happened to be reachable from the command
rather than a decision about what a fresh deployment should have. The rest
were created lazily by the feature that owned them, on first use - which is
fine on SQLite and impossible on a locked-down PostgreSQL, where the app user
has no CREATE and "first use" is the moment it fails.

So the provisioners are enumerated HERE, once, and `init` runs all of them.

WHAT COUNTS AS PLATFORM, and the two exclusions are the interesting part:

  * IN - the engine's own run tables, the Studio tier, learning, workspace
    memory, forensics, cross-run recall, and the play/case tier. The last is
    in because `CLAUDE.md` places it in core deliberately: `iof-plays`,
    `iof-case` and the `play_operator` role all ship with the engine.
  * OUT - `aria_*`, `negotiation_terms` and `vendor_fiscal_calendars`, which
    are a procurement DOMAIN feature and are ensured at the `/api/aria`
    mount. `web/app.py` says so in as many words: "a generic engine DB that
    never mounts ARIA carries no orphan procurement tables."
  * OUT - the MS Teams channel and the preferences feature, by decision.
    Both are platform code and neither is on unless configured, so they keep
    creating their own tables when they are.
  * OUT - `plan_cache`, which is not in this database at all. It lives in its
    own `plan_cache.db` under the state root.
  * OUT - the four tables the Studio API owns (`user`, `user_password`,
    `studio_agent_display`, `studio_skill_scripts`, `studio_engine_health`).
    Core cannot import `apps/agentfarm-api`, and that pod self-provisions
    them at startup.

IDEMPOTENT, and it has to be: every provisioner below is `CREATE TABLE IF NOT
EXISTS` and several memoise per connection, so a second `init` is a no-op.

EACH ONE IS ISOLATED. A provisioner that raises must not stop the others -
an app user with rights to some schemas and not others is a real deployment,
and getting eleven of twelve tiers is strictly better than getting none. The
caller reports which failed BY NAME; a partial result that reads as success
is the failure this module exists to remove.
"""
from __future__ import annotations

import logging
from typing import Callable, Iterable

logger = logging.getLogger(__name__)


def _studio(adapter, con) -> None:
    from ioagentfarm import workspace_sync

    is_pg = adapter.placeholder() == "%s"
    workspace_sync.ensure_platform_schema(con, is_pg)
    # A SEPARATE call - `ensure_platform_schema` does not make the members
    # table, which is why it was the one platform table a fresh deployment
    # never had, and why the Studio then refused to open the workspace.
    workspace_sync.ensure_members_table(con, is_pg)


def _forensics(adapter, con) -> None:
    from ioagentfarm.engine.forensics import Forensics

    Forensics(adapter).init()


def _learning_log(adapter, con) -> None:
    from ioagentfarm.engine.learning.log import LearningLog

    LearningLog(adapter).init()


def _learning_store(adapter, con) -> None:
    from ioagentfarm.engine.learning.store import LearningStore

    LearningStore(adapter).init()


def _recall(adapter, con) -> None:
    from ioagentfarm.engine.learning.recall_fts import FtsRecall

    FtsRecall(adapter).init()


def _workspace_memory(adapter, con) -> None:
    from ioagentfarm.engine.memory.store import WorkspaceMemoryStore

    WorkspaceMemoryStore(adapter).init()


def _case_tier(adapter, con) -> None:
    """The case tier's `meta_*` tables.

    `_connect` is what ensures them, and it takes the ADAPTER - so passing
    the one `init` already resolved avoids `session()`, which infers its own
    root and would provision a different database than the command reports.
    That mistake has been made in this codebase before.
    """
    from ioagentfarm.tools.casetier import store as case_store

    case_store._connect(adapter).close()


def _play_tier(adapter, con) -> None:
    from ioagentfarm.tools import playbook_store

    playbook_store._connect(adapter).close()


#: ``(label, provisioner)``, run in this order. The label is what a failure
#: is reported under, so it is the tier's name rather than a function name.
PROVISIONERS: tuple[tuple[str, Callable], ...] = (
    ("studio", _studio),
    ("forensics", _forensics),
    ("learning-log", _learning_log),
    ("learning-store", _learning_store),
    ("recall", _recall),
    ("workspace-memory", _workspace_memory),
    ("case-tier", _case_tier),
    ("play-tier", _play_tier),
)

#: Every table the provisioners above create, plus the engine's own. Read by
#: `init` to report a count and by the suite to prove nothing was missed.
#:
#: ONE list, beside the code that makes them. A second copy anywhere is a
#: second thing to forget - which is how the members table came to be the one
#: table no single call created.
PLATFORM_TABLES: tuple[str, ...] = (
    # the engine's own, from Store.init()
    "agents", "content_drafts", "content_registration", "eval_results",
    "message_feedback", "messages",
    "pack_skills", "runs", "schema_meta", "steps", "stories", "tasks",
    "user_context", "workflows", "workspaces",
    # the Studio tier
    "studio_agent_defs", "studio_conversation_messages", "studio_conversations",
    "studio_skills", "studio_workflow_defs", "studio_workspace_items",
    "studio_workspace_members", "studio_workspace_repos",
    "studio_workspace_settings",
    # forensics
    "forensic_events",
    # learning
    "learning_log", "learnings", "learning_feedback", "learning_history",
    # workspace memory
    "workspace_memory", "workspace_memory_history", "workspace_memory_runs",
    "workspace_memory_settings",
    # the case tier
    "meta_cases", "meta_case_events", "meta_case_runs", "meta_case_timers",
    "meta_rulebooks", "meta_calendars",
    # the play tier
    "meta_playbooks", "meta_compilations", "meta_stagings",
    "meta_capability_requests", "meta_unmatched_requests",
)

#: Cross-run recall, which is NOT one table. `FtsRecall.init()` creates an
#: FTS5 virtual table called `recall_fts` on SQLite and a plain `recall_docs`
#: with a GIN index on PostgreSQL - same tier, different names, because full
#: text search is the one thing the two engines do not spell alike.
#:
#: Kept out of `PLATFORM_TABLES` and added per backend by :func:`present`.
#: A flat list counted 41 of 42 on SQLite and would have been wrong on
#: Postgres for the mirror-image reason - and a count that is quietly short
#: is the number an operator uses to decide the database is fine.
RECALL_TABLE = {False: "recall_fts", True: "recall_docs"}   # keyed by is_pg


class _RecordingCursor:
    """Swallows every statement and keeps it; answers reads emptily.

    Several provisioners probe before they create, so this has to be
    answerable rather than raise - an empty answer makes them take the
    "nothing exists yet" branch, which is the branch whose DDL is wanted.
    """

    def __init__(self, sink: list):
        self.sink = sink
        self.description = None
        self.rowcount = -1

    def execute(self, sql, params=None):
        self.sink.append(str(sql))
        return self

    def executemany(self, sql, seq=()):
        self.sink.append(str(sql))
        return self

    def fetchone(self):
        return None

    def fetchall(self):
        return []

    def close(self):
        pass

    def __iter__(self):
        return iter(())


class _RecordingConnection:
    def __init__(self, sink: list | None = None):
        self.sql: list[str] = sink if sink is not None else []

    def cursor(self):
        return _RecordingCursor(self.sql)

    def execute(self, sql, params=None):
        self.sql.append(str(sql))
        return _RecordingCursor(self.sql)

    def commit(self):
        pass

    def rollback(self):
        pass

    def close(self):
        pass

    # `with self._conn() as con:` is how several stores open a
    # transaction, so this must be a context manager. Without the pair,
    # four tiers raised TypeError during recording and contributed no
    # DDL - and the recorder swallows a failed tier, so the only symptom
    # was tables appearing with ZERO columns.
    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        return False


class _RecordingAdapter:
    """The real adapter, except that `connect()` records instead of running.

    THIS IS THE PIECE THAT MAKES RECORDING WORK, and its absence is why the
    first attempt collected nothing. Every provisioner except the Studio one
    takes an ADAPTER and opens its own connection - `Forensics(adapter).init()`,
    `LearningStore(adapter).init()` - so handing them a recording CONNECTION
    achieved exactly nothing: they never saw it. Everything else is delegated,
    so `placeholder()` still decides the dialect and the DDL recorded is the
    DDL that backend would really run.
    """

    def __init__(self, real, sink: list):
        self._real = real
        self._sink = sink

    def connect(self):
        return _RecordingConnection(self._sink)

    def init_connection(self, con):
        return None

    def __getattr__(self, name):
        return getattr(self._real, name)


def declared_columns(adapter) -> dict:
    """``{table: {column: type_ddl}}`` the provisioners would create.

    Recorded, not listed. Every provisioner runs once against a connection
    that executes nothing, and the CREATE TABLE statements it emits ARE the
    expectation - so it cannot drift from what the code actually does, which
    a hand-maintained list of columns provably does.
    """
    from ioagentfarm.engine import schema_diff

    sink: list = []
    rec_con = _RecordingConnection(sink)
    rec_adapter = _RecordingAdapter(adapter, sink)

    # THE ENGINE'S OWN TABLES TOO. `Store.init()` makes runs/steps/agents and
    # is NOT in PROVISIONERS - `init` has already called it through `_store()`
    # by the time this runs. Recording it here is what puts its columns in the
    # expectation; without it `agents.seeded_at` was neither restored nor
    # reported, which is the worst of the three outcomes.
    try:
        from ioagentfarm.engine.store import Store

        Store(rec_adapter).init()
    except Exception:  # noqa: BLE001
        logger.debug("column reconcile: could not record the engine store",
                     exc_info=True)

    for label, fn in PROVISIONERS:
        try:
            fn(rec_adapter, rec_con)
        except Exception:  # noqa: BLE001 - a tier that will not record
            logger.debug("column reconcile: could not record %s", label,
                         exc_info=True)
    return schema_diff.parse_create_statements(chr(10).join(sink))


def reconcile_columns(adapter, con) -> tuple[list[str], list[str]]:
    """Add columns the code declares and a live table lacks.

    `CREATE TABLE IF NOT EXISTS` is a no-op on an existing table, so this is
    the half that makes an UPGRADE work: nine columns dropped across nine
    tiers and a second `init` restored four of them before this existed.
    """
    from ioagentfarm.engine import schema_diff

    is_pg = adapter.placeholder() == "%s"
    expected = declared_columns(adapter)
    if not expected:
        return [], []
    cur = con.cursor()
    added, refused = schema_diff.reconcile(cur, expected, is_pg=is_pg)
    try:
        con.commit()
    except Exception:  # noqa: BLE001 - autocommit connections
        pass
    return added, refused


def ensure_all(adapter, con) -> tuple[int, list[str]]:
    """Create every platform tier. Returns ``(succeeded, failed_labels)``.

    Never raises. A provisioner that fails is logged with its traceback at
    debug and named in the return, because the caller has to be able to say
    WHICH tier is missing - "the platform tables could not be created" sends
    an operator looking at all of them.
    """
    ok, failed = 0, []
    for label, fn in PROVISIONERS:
        try:
            fn(adapter, con)
            ok += 1
        except Exception as exc:  # noqa: BLE001 - reported, never fatal
            failed.append(label)
            logger.debug("platform schema: %s failed (%s: %s)",
                         label, type(exc).__name__, exc, exc_info=True)
    return ok, failed


def present(cur, is_pg: bool, names: Iterable[str] | None = None) -> int:
    """How many of :data:`PLATFORM_TABLES` exist. For reporting, not gating."""
    wanted = (tuple(names) if names is not None
              else PLATFORM_TABLES + (RECALL_TABLE[bool(is_pg)],))
    listed = ", ".join("'" + t + "'" for t in wanted)
    if is_pg:
        cur.execute("SELECT count(*) FROM information_schema.tables "
                    f"WHERE table_name IN ({listed})")
    else:
        cur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' "
                    f"AND name IN ({listed})")
    row = cur.fetchone()
    if row is None:
        return 0
    return int(row[0] if not isinstance(row, dict) else list(row.values())[0])
