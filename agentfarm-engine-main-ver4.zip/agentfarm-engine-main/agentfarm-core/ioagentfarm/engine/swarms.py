"""Swarms: goal-oriented orchestration as a first-class content kind.

A WORKFLOW is a deterministic DAG — fixed steps, fixed roles, the route drawn
in advance. A SWARM is the complementary paradigm: a META-AGENT given a GOAL
plus a ROSTER of capabilities — external A2A child agents (from the workspace
registry) and MCP servers — deciding at runtime which to call in what order.
A solution is a collection of both; both are goal-oriented.

THE ARCHITECTURE IS A COMPILE, NOT A SECOND ENGINE. ``run-swarm`` compiles
the definition into a synthesized ONE-STEP workflow written directly to
``.iof/instances/<run_id>/workflow/`` — and ``snapshot_workflow`` early-returns
on an existing snapshot dir, so the entire run pipeline (driver loop,
``run-step``, ``_finalize_step``) operates on the compiled definition. That
inheritance is the point: Fix-6 auto-retry, forensics, the fail-closed
``requires_artifacts`` gate, the hard attempt cap, supervisor reaping and
resurrection, S3 recovery, ``--background``, message streaming and the whole
run CLI all apply to swarm runs with zero orchestration-engine changes.

Roster scoping rides the two functions that already re-read the raw snapshot
``workflow.yaml`` (the ``learning:`` precedent): ``create_filtered_workspace``
reads the compiled ``agents:`` list and filters the materialized external-agent
catalog; ``create_instance_config`` reads the compiled ``mcp_servers:`` list
and filters ``tools.mcpServers``. The loader ignores unknown top-level keys,
so those markers (and ``kind: swarm``) travel in the compiled YAML harmlessly.

Definition — ``swarms/<name>/`` in a solution package, sibling of
``workflows/``::

    swarm.yaml          # the definition (see Swarm model)
    meta.md             # optional: overrides the generated goal briefing
    roles/<role>.md     # optional: overrides the generated orchestrator persona
    metadata/           # optional: copied into the snapshot ({{metadata_dir}})
"""
from __future__ import annotations

import logging
import os
import re
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

#: Same shape rule as every other addressable name in the platform — it
#: becomes a directory name, a run's ``workflow_name`` and a CLI argument.
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,48}$")

#: The shared skill that teaches an agent to consult external A2A agents.
CONSULT_SKILL = "a2a_consult"

DEFAULT_DELIVERABLE = "swarm_report.md"

#: The compiled step's key. One step by definition — a swarm's sequencing
#: happens inside the meta-agent's session, not in the DAG.
STEP_KEY = "run"


class SwarmBudget(BaseModel):
    """The rabbit-hole guardrails: how much a swarm run may spend.

    ``tool_calls`` is a HARD cap — it becomes the run's
    ``agents.defaults.maxToolIterations`` in the instance config, so the
    meta-agent's session physically cannot loop past it (floor 20: the run
    DRIVER shares the instance config and needs headroom for its own short
    cycles). ``consults`` is a BRIEFING CONTRACT — the generated briefing
    tells the meta-agent its dispatch allowance; it is judgement-enforced,
    not physics, and documented as such.
    """

    tool_calls: Optional[int] = None
    consults: Optional[int] = None


class Swarm(BaseModel):
    """One swarm definition (the parsed ``swarm.yaml``).

    ``agents`` semantics: ``None`` (key omitted) = every external agent
    registered for the workspace; a LIST = exactly that roster; ``[]`` = no
    external agents (an MCP-only or self-contained swarm). ``mcp_servers``
    mirrors that: ``None`` = whatever the declaration tiers provide, a list =
    filtered to those names.

    A swarm is a collection of tools and agents working under one
    meta-agent's direction toward a goal, with predefined CONTROLS (the
    rosters + the deliverable gate), BUDGET (``budget``) and CHECKPOINTING
    (the generated briefing mandates a ``_run_plan.md`` progress file — the
    exact file Fix-6's smart continuation reads, so a retried attempt resumes
    from the checkpoint instead of starting over).
    """

    name: str
    description: str = ""
    role: str
    agents: Optional[List[str]] = None
    mcp_servers: Optional[List[str]] = None
    skills: List[str] = Field(default_factory=list)
    deliverable: str = DEFAULT_DELIVERABLE
    max_attempts: int = 2
    budget: Optional[SwarmBudget] = None
    vars: Dict[str, str] = Field(default_factory=dict)
    #: Where the definition came from (Path or importlib Traversable) — the
    #: home of the optional override files. Excluded from the YAML schema.
    base_dir: Optional[Any] = None


# ── generated documents ─────────────────────────────────────────────────────

#: The meta-orchestrator persona — the shape proven by the federation
#: pressure tests (examples/mcp-a2a-lab) and by AINF's production meta-agent.
_DEFAULT_PERSONA = """\
# Swarm orchestrator - {name}

You are the orchestrator of the `{name}` swarm. {description}

You are a PURE ORCHESTRATOR: you hold no data of your own. Every figure in
your deliverable comes from a capability in your roster - an external agent
you consulted or a tool you called - and is attributed to its source. You
decide, at runtime, which capability answers which part of the goal and in
what order; that judgement is the reason you exist.

Operating rules:

- Route each part of the goal to the best-fit capability; skip capabilities
  the goal does not need.
- Never fabricate a number, and never guess at data a capability failed to
  return. A failed capability is named in the deliverable, with its data
  reported as unavailable.
- Attribute every externally-sourced figure to the agent or tool it came
  from.
- Parts of the goal no capability covers are answered honestly: say what you
  cannot answer, and why.
"""

_DEFAULT_BRIEFING = """\
# {title}

## Your goal

{{{{goal}}}}

## Your roster

{roster_lines}

External agents are consulted with the `a2a_consult` skill's protocol: read
`metadata/external_agents.yaml` in your workspace (it lists exactly the
agents this swarm may use), route each question to the best-fit agent by
description/tags/examples, dispatch with `iof-consult --batch`, and combine
the results. MCP tools, when present, are registered live in your tool list
as `mcp_<server>_<tool>`.

## Your discipline

{budget_lines}Before your first capability call, write `_{step_key}_plan.md` in your
working directory: the parts of the goal as a checklist. Update it after
every completed part (mark done, note where the result lives). This is your
CHECKPOINT — if your session is interrupted and retried, you resume from
whatever the plan file says is already done rather than starting over. Work
the plan; when every part is done or accounted for, stop and compose. Do not
chase side-questions the goal did not ask.

## Your deliverable

Write `{deliverable}` in your working directory: the goal's answer, organized
for a reader who was not present — findings first, every figure attributed to
its source capability, failed capabilities named with their data reported as
unavailable. The run does not complete until this file exists and is
non-empty.
"""


def _budget_lines(swarm: Swarm) -> str:
    if swarm.budget is None or swarm.budget.consults is None:
        return ""
    return (f"Your dispatch allowance is {swarm.budget.consults} external "
            "consult(s) for this run - batch questions per agent rather than "
            "spending a dispatch per question, and do not re-consult an "
            "agent that already answered.\n\n")


def _roster_lines(swarm: Swarm) -> str:
    lines: List[str] = []
    if swarm.agents is None:
        lines.append("- External A2A agents: every agent registered for this "
                     "workspace (see `metadata/external_agents.yaml`).")
    elif swarm.agents:
        lines.append("- External A2A agents: "
                     + ", ".join(f"`{a}`" for a in swarm.agents) + ".")
    else:
        lines.append("- External A2A agents: none for this swarm.")
    if swarm.mcp_servers is None:
        lines.append("- MCP servers: whatever this deployment declares "
                     "(tools named `mcp_<server>_<tool>` in your tool list).")
    elif swarm.mcp_servers:
        lines.append("- MCP servers: "
                     + ", ".join(f"`{s}`" for s in swarm.mcp_servers)
                     + " (tools named `mcp_<server>_<tool>`).")
    else:
        lines.append("- MCP servers: none for this swarm.")
    return "\n".join(lines)


def _read_optional(base: Any, *rel: str) -> Optional[str]:
    """Read an override file from a Path or Traversable base, if present."""
    if base is None:
        return None
    node = base
    try:
        for part in rel:
            node = node / part
        if node.is_file():
            return node.read_text(encoding="utf-8")
    except (OSError, TypeError, AttributeError):
        return None
    return None


def compiled_skills(swarm: Swarm) -> List[str]:
    """The compiled role's ``skills:`` list — ALWAYS a list, never None.

    A ``skills: None`` role skips ``create_filtered_workspace`` entirely,
    which is also what materializes the scoped external-agent catalog — so
    the compiler must always emit a list (possibly just the consult skill).
    ``a2a_consult`` is ensured whenever the swarm can consult anyone
    (``agents`` omitted = all, or a non-empty roster); an explicit
    ``agents: []`` swarm does not carry it.
    """
    out = list(dict.fromkeys(swarm.skills))
    consults = swarm.agents is None or bool(swarm.agents)
    if consults and CONSULT_SKILL not in out:
        out.append(CONSULT_SKILL)
    return out


def compile_swarm_docs(swarm: Swarm) -> Tuple[Dict[str, Any], str, str]:
    """The compiled artifacts, PURE: (workflow_yaml_dict, role_md, step_md).

    Pure so the linter and the compiler cannot disagree — the linter builds
    the same dict and validates the graph the run would execute.
    """
    if swarm.role == "project_lead":
        raise ValueError(
            "a swarm's role must not be project_lead - that role is the run "
            "DRIVER, and run-step refuses to execute steps as it")

    role_md = (_read_optional(swarm.base_dir, "roles", f"{swarm.role}.md")
               or _DEFAULT_PERSONA.format(name=swarm.name,
                                          description=swarm.description))
    step_md = (_read_optional(swarm.base_dir, "meta.md")
               or _DEFAULT_BRIEFING.format(
                   title=swarm.name.replace("_", " ").capitalize(),
                   roster_lines=_roster_lines(swarm),
                   budget_lines=_budget_lines(swarm),
                   step_key=STEP_KEY,
                   deliverable=swarm.deliverable))

    wf: Dict[str, Any] = {
        "name": swarm.name,
        "description": swarm.description,
        # Markers for the raw-snapshot readers; the workflow loader ignores
        # unknown top-level keys by design.
        "kind": "swarm",
    }
    if swarm.agents is not None:
        wf["agents"] = list(swarm.agents)
    if swarm.mcp_servers is not None:
        wf["mcp_servers"] = list(swarm.mcp_servers)
    if swarm.budget is not None and (swarm.budget.tool_calls is not None
                                     or swarm.budget.consults is not None):
        # Budget markers. tool_calls is the HARD cap create_instance_config
        # applies as the run's maxToolIterations (floor 20: the run driver
        # shares the config). consults is the briefing contract, carried so
        # `forensics explain` can report used-vs-budget.
        budget_marker: Dict[str, Any] = {}
        if swarm.budget.tool_calls is not None:
            budget_marker["tool_calls"] = max(20, int(swarm.budget.tool_calls))
        if swarm.budget.consults is not None:
            budget_marker["consults"] = int(swarm.budget.consults)
        wf["budget"] = budget_marker
    if swarm.vars:
        wf["vars"] = dict(swarm.vars)
    wf["roles"] = [{
        "name": swarm.role,
        "prompt": f"roles/{swarm.role}.md",
        "skills": compiled_skills(swarm),
    }]
    wf["steps"] = [{
        "key": STEP_KEY,
        "title": f"{swarm.name} - goal run",
        "role": swarm.role,
        "max_attempts": swarm.max_attempts,
        "prompt": f"steps/{STEP_KEY}.md",
        "requires_artifacts": [swarm.deliverable],
    }]
    return wf, role_md, step_md


def compile_swarm(swarm: Swarm, run_id: str, root: Path) -> Path:
    """Write the compiled one-step workflow as the run's SNAPSHOT.

    ``snapshot_workflow`` early-returns on an existing snapshot dir, so this
    compile IS the snapshot — everything downstream (driver, run-step,
    finalize) reads the compiled definition and nothing ever consults a
    workflow catalog for it.
    """
    target = Path(root) / "instances" / run_id / "workflow"
    if target.exists():
        raise FileExistsError(
            f"run {run_id} already has a workflow snapshot at {target} - "
            "compile_swarm must run before anything else touches the run")
    wf, role_md, step_md = compile_swarm_docs(swarm)

    (target / "roles").mkdir(parents=True)
    (target / "steps").mkdir(parents=True)
    (target / "workflow.yaml").write_text(
        yaml.safe_dump(wf, sort_keys=False, allow_unicode=True),
        encoding="utf-8")
    (target / "roles" / f"{swarm.role}.md").write_text(role_md,
                                                       encoding="utf-8")
    (target / "steps" / f"{STEP_KEY}.md").write_text(step_md,
                                                     encoding="utf-8")

    # Ship the swarm's metadata/ so {{metadata_dir}} resolves in prompts.
    meta = None
    if swarm.base_dir is not None:
        try:
            candidate = swarm.base_dir / "metadata"
            if candidate.is_dir():
                meta = candidate
        except (OSError, TypeError, AttributeError):
            meta = None
    if meta is not None:
        _copy_tree(meta, target / "metadata")

    logger.info("Compiled swarm %s into %s", swarm.name, target)
    return target


def _copy_tree(src: Any, dst: Path) -> None:
    """Copy a Path or Traversable tree (mirrors the loader's traversable copy)."""
    if isinstance(src, Path):
        shutil.copytree(str(src), str(dst))
        return
    dst.mkdir(parents=True, exist_ok=True)
    for entry in src.iterdir():
        if entry.is_dir():
            _copy_tree(entry, dst / entry.name)
        else:
            (dst / entry.name).write_bytes(entry.read_bytes())


# ── loading ─────────────────────────────────────────────────────────────────

def parse_swarm(text: str, base_dir: Any = None) -> Swarm:
    """Parse swarm.yaml text into a validated ``Swarm``. Raises ValueError."""
    try:
        data = yaml.safe_load(text) or {}
    except yaml.YAMLError as exc:
        raise ValueError(f"swarm.yaml is not valid YAML: {exc}")
    if not isinstance(data, dict):
        raise ValueError("swarm.yaml must be a mapping")
    known = {"name", "description", "role", "agents", "mcp_servers",
             "skills", "deliverable", "max_attempts", "budget", "vars"}
    payload = {k: v for k, v in data.items() if k in known}
    try:
        swarm = Swarm(**payload, base_dir=base_dir)
    except Exception as exc:
        raise ValueError(f"swarm.yaml is invalid: {exc}")
    if not NAME_RE.match(swarm.name or ""):
        raise ValueError(
            f"swarm name {swarm.name!r} must match ^[a-z][a-z0-9_]{{1,48}}$")
    if not swarm.role:
        raise ValueError("swarm.yaml must name a `role:` (the meta-agent)")
    return swarm


class SwarmLoader:
    """Resolve swarms by name: override tree first, then installed packs.

    Mirrors ``WorkflowLoader``'s precedence in miniature. The override tier
    (``<IOF_ROOT>/swarms/<name>/``) exists so an operator can drop a swarm
    onto a machine without a pack release; nothing writes it automatically
    in v1 (workspace push/pull of swarms is a documented follow-up).
    """

    MARKER = "swarm.yaml"

    def _override_dir(self, name: str, root: Optional[Path]) -> Path:
        base = Path(root) if root else Path(os.environ.get("IOF_ROOT", ".iof"))
        return base / "swarms" / name

    def _sources(self):
        from ioagentfarm.packs import load_registry
        try:
            return load_registry().swarm_sources()
        except Exception:  # a broken registry must not block resolution
            logger.warning("pack registry unavailable while resolving swarms",
                           exc_info=True)
            return []

    def load(self, name: str, root: Optional[Path] = None) -> Swarm:
        override = self._override_dir(name, root)
        if (override / self.MARKER).is_file():
            return parse_swarm(
                (override / self.MARKER).read_text(encoding="utf-8"),
                base_dir=override)
        for source in self._sources():
            try:
                candidate = source / name / self.MARKER
                if candidate.is_file():
                    return parse_swarm(candidate.read_text(encoding="utf-8"),
                                       base_dir=source / name)
            except (OSError, TypeError, AttributeError):
                continue
        raise FileNotFoundError(f"no swarm named {name!r}")

    def list_swarms(self, root: Optional[Path] = None) -> Dict[str, Swarm]:
        """Every resolvable swarm, first source wins per name.

        A definition that fails to parse is skipped with a warning naming
        the problem — a broken swarm must not hide the working ones.
        """
        out: Dict[str, Swarm] = {}

        def _scan(entries, origin: str) -> None:
            for entry in entries:
                try:
                    marker = entry / self.MARKER
                    if not marker.is_file() or entry.name in out:
                        continue
                    out[entry.name] = parse_swarm(
                        marker.read_text(encoding="utf-8"), base_dir=entry)
                except (OSError, TypeError, AttributeError):
                    continue
                except ValueError as exc:
                    logger.warning("swarm %s (%s) failed to load: %s",
                                   entry.name, origin, exc)

        override_root = (Path(root) if root
                         else Path(os.environ.get("IOF_ROOT", ".iof"))) / "swarms"
        if override_root.is_dir():
            _scan(sorted(override_root.iterdir()), "override")
        for source in self._sources():
            try:
                _scan(source.iterdir(), "pack")
            except (OSError, TypeError, AttributeError):
                continue
        return out
