"""The model registry — which models a deployment permits a step to run on.

Model SELECTION has three mature seams: the deployment default
(``agents.defaults.model`` in ``~/.iobot/config.json``), a role's ``model:``
in ``workflow.yaml`` (``Role.model`` -> ``create_role_config``), and the
provider swaps in ``_iobot_patches``. None of them asks whether the model
is one this deployment has APPROVED: a role could name any string, the
linter checked only that it was a string, and a retired model kept serving
steps until its endpoint went away. This module is the missing catalog.

A registry is ONE ``models.yaml``, resolved in tiers, most explicit first:

1. ``IOF_MODELS`` — a path to the file (the container's voice);
2. the workspace tier, ``~/.iobot/workspaces/<code>/models.yaml`` (beside
   the workspace's ``mcp.yaml`` and ``deliveries.yaml``);
3. the packs' own ``models.yaml`` (``Pack.models``, merged first-pack-wins).

The tiers do not merge with each other: the first that declares anything is
the registry. **No file in any tier = no registry = every model allowed** —
a deployment that never wrote one behaves exactly as before.

Shape::

    default: anthropic/MiniMax-M2.7-highspeed
    models:
      anthropic/MiniMax-M2.7-highspeed:
        status: approved
        version: "M2.7"
        context_window: 204800
        notes: "production model"
      anthropic/claude-opus-4-6:
        status: approved
        version: "2026-05"
        deprecated_after: "2026-12-31"
      openai/gpt-4o:
        status: retired

``status`` is one of ``approved``, ``trial``, ``retired``; anything else is
a load error that names the legal values. ``approved`` and ``trial`` are
allowed; ``retired`` and ABSENT are refused — a registry is an allowlist,
and an allowlist that admits names it has never heard of is a comment.
``deprecated_after`` is an ISO date; past it the model is reported as
deprecated (a warning at lint and at run) but still allowed, unless its
status retires it.

Three consumers read ONE resolution: the linter (a role's ``model:``, and
the registry's own ``default:``), the run path (``refuse_if_retired`` before
a step's config is written — the deployment default included, because that
is the model most steps actually run on), and ``aicore models list|check|show``.
"""
from __future__ import annotations

import difflib
import logging
import os
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any, Iterable, Optional

import yaml

logger = logging.getLogger(__name__)

ENV_VAR = "IOF_MODELS"
FILE_NAME = "models.yaml"
#: The legal ``status`` values, in the order an error message lists them.
STATUSES = ("approved", "trial", "retired")
#: Statuses a step may run on.
ALLOWED_STATUSES = ("approved", "trial")

ERROR = "ERROR"
WARNING = "WARNING"


class RegistryError(ValueError):
    """A registry file exists and cannot be read as one. Never swallowed
    into "no registry": a deployment that tried to declare and failed must
    be refused, not read as permitting everything."""


class ModelNotAllowed(RuntimeError):
    """A step's model is refused by the resolved registry."""


@dataclass(frozen=True)
class ModelEntry:
    name: str
    status: str
    version: str = ""
    context_window: Optional[int] = None
    deprecated_after: Optional[date] = None
    notes: str = ""

    def deprecated_on(self, today: Optional[date] = None) -> bool:
        if self.deprecated_after is None:
            return False
        return (today or date.today()) > self.deprecated_after

    def as_dict(self) -> dict:
        return {
            "model": self.name,
            "status": self.status,
            "version": self.version,
            "context_window": self.context_window,
            "deprecated_after": (self.deprecated_after.isoformat()
                                 if self.deprecated_after else None),
            "notes": self.notes,
        }


@dataclass(frozen=True)
class Verdict:
    ok: bool
    reason: str
    status: Optional[str] = None       # the entry's status; None when absent
    deprecated: bool = False           # allowed, but past ``deprecated_after``
    suggestion: Optional[str] = None   # did-you-mean over the allowed names


@dataclass(frozen=True)
class Finding:
    """One registry finding about a role, the deployment default, or the
    registry's own ``default:``. ``index`` is the role's position in the
    workflow's ``roles:`` list (``None`` for the non-role findings) so the
    linter can attach a line number."""
    severity: str
    where: str
    model: Optional[str]
    message: str
    fix: str
    index: Optional[int] = None
    role: Optional[str] = None


@dataclass
class Registry:
    models: dict[str, ModelEntry]
    default: Optional[str]
    source: str                 # env | workspace | packs
    path: Optional[str]         # the file, when there is one

    # -- queries ---------------------------------------------------------
    def allowed_names(self) -> list[str]:
        return [n for n, e in self.models.items() if e.status in ALLOWED_STATUSES]

    def approved_names(self) -> list[str]:
        return [n for n, e in self.models.items() if e.status == "approved"]

    def suggest(self, model: str) -> Optional[str]:
        hit = difflib.get_close_matches(model, self.allowed_names(), n=1, cutoff=0.5)
        return hit[0] if hit else None

    def allows(self, model: str, today: Optional[date] = None) -> Verdict:
        entry = self.models.get(model)
        if entry is None:
            hint = self.suggest(model)
            return Verdict(
                False,
                f"'{model}' is not listed in the model registry ({self.location()}); "
                f"allowed: {_join(self.allowed_names())}",
                status=None, suggestion=hint)
        if entry.status == "retired":
            hint = self.suggest(model)
            return Verdict(
                False,
                f"'{model}' is RETIRED in the model registry ({self.location()}); "
                f"allowed: {_join(self.allowed_names())}",
                status="retired", suggestion=hint)
        if entry.deprecated_on(today):
            return Verdict(
                True,
                f"'{model}' is deprecated since {entry.deprecated_after.isoformat()} "
                f"({self.location()}); it still runs, but plan the move to an "
                f"approved model",
                status=entry.status, deprecated=True)
        return Verdict(True, f"'{model}' is {entry.status}", status=entry.status)

    def location(self) -> str:
        return self.path or f"{self.source} tier"

    def describe(self) -> dict:
        return {
            "source": self.source,
            "path": self.path,
            "default": self.default,
            "models": [e.as_dict() for e in self.models.values()],
        }


# ── loading ─────────────────────────────────────────────────────────────

def _join(names: Iterable[str]) -> str:
    names = list(names)
    return ", ".join(names) if names else "(none)"


def _parse_date(value: Any, model: str, source: str) -> Optional[date]:
    if value is None or value == "":
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError as e:
        raise RegistryError(
            f"{source}: models.{model}.deprecated_after must be an ISO date "
            f"(YYYY-MM-DD), got {value!r}") from e


def normalize(data: Any, source: str) -> tuple[Optional[str], dict[str, ModelEntry]]:
    """``(default, {name: ModelEntry})`` from a loaded ``models.yaml``.

    Raises :class:`RegistryError` — naming the legal values — on a shape the
    registry cannot honour. A file with no ``models:`` key at all is an
    error too: an empty allowlist would refuse every step, and that has to
    be written on purpose (``models: {}``), never reached by a typo.
    """
    if data is None:
        raise RegistryError(f"{source}: the file is empty; a registry needs a "
                            f"`models:` mapping")
    if not isinstance(data, dict):
        raise RegistryError(f"{source}: top level must be a mapping with a "
                            f"`models:` key, got {type(data).__name__}")
    unknown = [k for k in data if k not in ("default", "models")]
    if unknown:
        raise RegistryError(f"{source}: unknown top-level key(s) "
                            f"{', '.join(map(str, unknown))}; the legal keys are "
                            f"default, models")
    if "models" not in data:
        raise RegistryError(f"{source}: no `models:` key; the legal top-level "
                            f"keys are default, models")
    raw = data.get("models")
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise RegistryError(f"{source}: `models:` must be a mapping of "
                            f"provider/model-name -> {{status, ...}}, got "
                            f"{type(raw).__name__}")
    default = data.get("default")
    if default is not None and not isinstance(default, str):
        raise RegistryError(f"{source}: `default:` must be a string like "
                            f"\"provider/model-name\", got {type(default).__name__}")

    out: dict[str, ModelEntry] = {}
    for name, entry in raw.items():
        name = str(name)
        if entry is None:
            entry = {}
        if isinstance(entry, str):
            entry = {"status": entry}
        if not isinstance(entry, dict):
            raise RegistryError(f"{source}: models.{name} must be a mapping "
                                f"(status, version, ...), got {type(entry).__name__}")
        status = entry.get("status")
        if status is None:
            raise RegistryError(f"{source}: models.{name} has no `status`; "
                                f"it must be one of: {', '.join(STATUSES)}")
        status = str(status).strip().lower()
        if status not in STATUSES:
            hint = difflib.get_close_matches(status, STATUSES, n=1, cutoff=0.5)
            more = f" (did you mean '{hint[0]}'?)" if hint else ""
            raise RegistryError(f"{source}: models.{name}.status '{status}' is "
                                f"not one of: {', '.join(STATUSES)}{more}")
        bad = [k for k in entry if k not in
               ("status", "version", "context_window", "deprecated_after", "notes")]
        if bad:
            raise RegistryError(f"{source}: models.{name} has unknown key(s) "
                                f"{', '.join(map(str, bad))}; the legal keys are "
                                f"status, version, context_window, "
                                f"deprecated_after, notes")
        cw = entry.get("context_window")
        if cw is not None:
            try:
                cw = int(cw)
            except (TypeError, ValueError) as e:
                raise RegistryError(f"{source}: models.{name}.context_window must "
                                    f"be an integer, got {cw!r}") from e
        out[name] = ModelEntry(
            name=name, status=status,
            version=str(entry.get("version") or ""),
            context_window=cw,
            deprecated_after=_parse_date(entry.get("deprecated_after"), name, source),
            notes=str(entry.get("notes") or ""),
        )
    return default, out


def _read_file(path: Path) -> Any:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as e:
        raise RegistryError(f"{path} is unreadable ({e})") from e


def load_pack_models(package: str) -> dict:
    """A pack's ``models.yaml`` as the RAW ``{default, models}`` mapping;
    ``{}`` when absent. Mirrors ``deliveries.load_pack_deliveries``: a broken
    file in a wheel is a warning, not a crash — the pack tier is the lowest
    and a workspace can always override it."""
    from importlib import resources
    try:
        f = resources.files(package) / FILE_NAME
        if not f.is_file():
            return {}
        data = yaml.safe_load(f.read_text(encoding="utf-8"))
    except Exception:       # noqa: BLE001
        logger.warning("%s of %s is unreadable; ignored", FILE_NAME, package,
                       exc_info=True)
        return {}
    return data if isinstance(data, dict) else {}


def workspace_models_path(code: str) -> Path:
    """``~/.iobot/workspaces/<code>/models.yaml`` — the workspace tier."""
    from ioagentfarm.engine.workspace_env import workspace_home
    return workspace_home(code) / FILE_NAME


def _pack_models() -> dict:
    """The packs' merged ``{default, models}`` (first pack wins by model
    name), or ``{}``. Guarded: the registry must stay usable where no pack
    is installed."""
    try:
        from ioagentfarm.packs import load_registry as _pack_registry
        return _pack_registry().models()
    except Exception:       # noqa: BLE001 - no packs is not an error here
        logger.debug("pack registry unavailable for models.yaml", exc_info=True)
        return {}


def _workspace_code(workspace: Optional[str]) -> Optional[str]:
    if workspace:
        return workspace
    try:
        from ioagentfarm.engine.workspaces import maybe_workspace_code
        return maybe_workspace_code()
    except Exception:       # noqa: BLE001 - no selection is not an error here
        return None


def load_registry(workspace: Optional[str] = None) -> Optional[Registry]:
    """The resolved registry, or ``None`` when no tier declares one.

    Raises :class:`RegistryError` when a tier that exists is malformed —
    ``IOF_MODELS`` naming a file that is missing or unreadable, or a
    workspace file with an illegal status.
    """
    raw_env = (os.environ.get(ENV_VAR) or "").strip()
    if raw_env:
        path = Path(raw_env).expanduser()
        if not path.is_file():
            raise RegistryError(f"{ENV_VAR}={raw_env} names no file")
        default, models = normalize(_read_file(path), str(path))
        return Registry(models, default, "env", str(path))
    code = _workspace_code(workspace)
    if code:
        path = workspace_models_path(code)
        if path.is_file():
            default, models = normalize(_read_file(path), str(path))
            return Registry(models, default, "workspace", str(path))
    packs = _pack_models()
    if packs:
        default, models = normalize(packs, "packs' models.yaml")
        return Registry(models, default, "packs", None)
    return None


# ── the deployment default ───────────────────────────────────────────────

def deployment_default_model() -> Optional[str]:
    """``agents.defaults.model`` from ``~/.iobot/config.json`` — the model a
    step runs on when its role names none. ``None`` when unconfigured."""
    try:
        from ioagentfarm.engine.home_bootstrap import describe_config
        model = describe_config().get("model")
    except Exception:       # noqa: BLE001
        return None
    if not model or str(model).endswith(">"):       # template placeholder
        return None
    return str(model)


def instance_default_model(instance_config: Optional[Path]) -> Optional[str]:
    """``agents.defaults.model`` from a run's instance config — the copy of
    the deployment default this run was created with. Falls back to the
    live ``~/.iobot/config.json`` when the instance config is absent."""
    if instance_config is not None:
        try:
            import json
            data = json.loads(Path(instance_config).read_text(encoding="utf-8"))
            model = ((data.get("agents") or {}).get("defaults") or {}).get("model")
            if model:
                return str(model)
        except Exception:       # noqa: BLE001 - fall through to the home config
            logger.debug("instance config unreadable for model lookup", exc_info=True)
    return deployment_default_model()


def effective_step_model(role_model: Optional[str],
                         instance_config: Optional[Path]) -> Optional[str]:
    """The model a step will actually run on: the role's override when the
    workflow names one, else the deployment default."""
    return role_model or instance_default_model(instance_config)


# ── checks ───────────────────────────────────────────────────────────────

def _role_fields(role: Any) -> tuple[Optional[str], Optional[str]]:
    """``(name, model)`` from a YAML role mapping or a ``Role`` object."""
    if isinstance(role, dict):
        name, model = role.get("name"), role.get("model")
    else:
        name, model = getattr(role, "name", None), getattr(role, "model", None)
    return ((str(name) if name is not None else None),
            (str(model) if isinstance(model, str) and model.strip() else None))


def _finding_for(verdict: Verdict, where: str, model: str, *, index=None,
                 role=None) -> Optional[Finding]:
    if not verdict.ok:
        fix = (f"use `model: \"{verdict.suggestion}\"`"
               if verdict.suggestion else
               "name an allowed model, or omit `model:` to run on the "
               "deployment default")
        return Finding(ERROR, where, model, verdict.reason, fix, index, role)
    if verdict.deprecated:
        return Finding(WARNING, where, model, verdict.reason,
                       "move to an approved model before the date passes "
                       "unnoticed", index, role)
    return None


def check_default(registry: Registry, today: Optional[date] = None) -> list[Finding]:
    """The registry's own ``default:`` must itself be allowed."""
    if not registry.default:
        return []
    v = registry.allows(registry.default, today)
    f = _finding_for(v, "<registry>.default", registry.default)
    if f is None:
        return []
    return [Finding(f.severity, f.where, f.model,
                    f"the registry's own `default:` is not usable - {f.message}",
                    "set `default:` to an allowed model in the same file")]


def check_role_models(workflow_roles: Iterable[Any],
                      workspace: Optional[str] = None,
                      registry: Optional[Registry] = None,
                      today: Optional[date] = None) -> list[Finding]:
    """Findings for every role that names a ``model:``, plus the registry's
    own ``default:``. Empty when no registry resolves (fail-open).

    *workflow_roles* is the ``roles:`` list of a workflow.yaml (dicts) or a
    ``Workflow.roles`` mapping's values (``Role`` objects). Raises
    :class:`RegistryError` for a malformed registry — the linter turns that
    into an ERROR of its own.
    """
    reg = registry if registry is not None else load_registry(workspace)
    if reg is None:
        return []
    out: list[Finding] = list(check_default(reg, today))
    roles = list(workflow_roles.values()) if isinstance(workflow_roles, dict) \
        else list(workflow_roles)
    for i, role in enumerate(roles):
        name, model = _role_fields(role)
        if not model:
            continue
        f = _finding_for(reg.allows(model, today),
                         f"roles[{name or i}].model", model, index=i, role=name)
        if f is not None:
            out.append(f)
    return out


def check_deployment_default(workspace: Optional[str] = None,
                             registry: Optional[Registry] = None,
                             today: Optional[date] = None) -> list[Finding]:
    """The deployment default (``~/.iobot/config.json``) against the
    registry: the model every step without a role override runs on."""
    reg = registry if registry is not None else load_registry(workspace)
    if reg is None:
        return []
    model = deployment_default_model()
    if not model:
        return [Finding(WARNING, "<deployment>.agents.defaults.model", None,
                        "no deployment default model is configured "
                        "(~/.iobot/config.json agents.defaults.model)",
                        "run `aicore init-home` and set the model")]
    f = _finding_for(reg.allows(model, today), "<deployment>.agents.defaults.model",
                     model)
    return [f] if f is not None else []


def refuse_if_retired(model: Optional[str], *, workspace: Optional[str] = None,
                      registry: Optional[Registry] = None,
                      role: Optional[str] = None) -> Optional[Verdict]:
    """The run-time gate. ``None`` when no registry resolves or no model is
    known (fail-open); the verdict otherwise. Raises
    :class:`ModelNotAllowed` — naming the model, the registry file and the
    allowed list — when the registry refuses it. A deprecated model runs
    with a warning in the log.

    A malformed registry is also a refusal: a deployment that tried to
    declare and failed must not run on "anything goes".
    """
    if not model:
        return None
    reg = registry if registry is not None else load_registry(workspace)
    if reg is None:
        return None
    v = reg.allows(model)
    who = f"role '{role}'" if role else "this step"
    if not v.ok:
        hint = f" Did you mean '{v.suggestion}'?" if v.suggestion else ""
        raise ModelNotAllowed(
            f"model '{model}' for {who} is refused by the model registry: "
            f"{v.reason}.{hint} Registry: {reg.location()}. Approved: "
            f"{_join(reg.approved_names())}.")
    if v.deprecated:
        logger.warning("model registry: %s (%s)", v.reason, who)
    return v
