"""Compare declared columns against a live table, and add what is missing.

ONE IMPLEMENTATION, TWO CALLERS. `scripts/schema_doctor.py` has done this for
a while against `scripts/setup_schema.sql`; `aicore init` needs the same
comparison against the DDL the provisioners themselves emit, because a wheel
has no `scripts/` directory. Writing a second parser for that was the
obvious move and the wrong one - this codebase's standing rule is that every
reader and emitter of a capture layer shares its discovery code, and two
column parsers would disagree the first time either was fixed.

So the parsing, the diff and the ALTER live here, and the two callers differ
only in where the EXPECTED columns come from:

    schema_doctor   parse_create_statements(setup_schema.sql text)
    aicore init     parse_create_statements(what the provisioners would run)

WHY IT IS NEEDED AT ALL. `CREATE TABLE IF NOT EXISTS` is a no-op on a table
that already exists, so a column added in a later release never arrives from
it. Measured on a real database: nine columns dropped across nine tiers, a
second `init`, and FOUR came back - the four some provisioner happened to
carry a hand-written `_ensure_column` for. `agents.seeded_at`,
`studio_workspace_settings.updated_at`, `learnings.updated_at`,
`learning_log.created_at` and `forensic_events.payload_json` did not. A
hand-written list is how those five came to be forgotten; adding five more
buys one release.

WHAT IT WILL NOT DO. It never drops, renames, retypes or reorders, and it
never touches data. A column whose TYPE differs is left alone - that is a
migration, and a migration is a decision, not a repair.
"""
from __future__ import annotations

import logging
import re

logger = logging.getLogger(__name__)

#: A line inside a CREATE TABLE body that declares a CONSTRAINT, not a column.
#: Matched on the first word, upper-cased - the same set `schema_doctor` used.
NOT_A_COLUMN = frozenset({
    "PRIMARY", "UNIQUE", "FOREIGN", "CHECK", "CONSTRAINT", "EXCLUDE",
})

_CREATE = re.compile(
    r"CREATE TABLE\s+(?:IF NOT EXISTS\s+)?([^\s(]+)\s*\(", re.I)


def _split_top_level(body: str) -> list[str]:
    """Split a CREATE TABLE body on commas at depth 0.

    Not `body.split(",")`: a `DECIMAL(10, 2)` or a multi-column `UNIQUE(a, b)`
    carries its own commas, and cutting inside one produces a fragment that
    parses as a column named `2`.
    """
    parts, depth, buf = [], 0, []
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    parts.append("".join(buf))
    return parts


def _body_of(text: str, start: int) -> str | None:
    """The parenthesised body of the CREATE TABLE beginning at *start*."""
    depth, out = 0, []
    seen = False
    for ch in text[start:]:
        if ch == "(":
            depth += 1
            seen = True
            if depth == 1:
                continue
        elif ch == ")":
            depth -= 1
            if seen and depth == 0:
                return "".join(out)
        if seen:
            out.append(ch)
    return None


def parse_create_statements(text: str) -> dict[str, dict[str, str]]:
    """``{table: {column: type_ddl}}`` from any text containing CREATE TABLE.

    Deliberately a small parser rather than a SQL library, for the reason
    `schema_doctor` gave: these statements are machine-written in one shape,
    and a dependency only this needed would not survive the next environment
    that runs it.
    """
    out: dict[str, dict[str, str]] = {}
    for m in _CREATE.finditer(text):
        raw = m.group(1).strip().strip('"')
        name = raw.split(".")[-1].strip('"')
        if not re.fullmatch(r"[a-z][a-z0-9_]*", name):
            continue
        body = _body_of(text, m.start())
        if body is None:
            continue
        cols: dict[str, str] = {}
        for piece in _split_top_level(body):
            piece = " ".join(piece.split())
            if not piece:
                continue
            head = piece.split(" ", 1)[0]
            if head.upper().strip('"') in NOT_A_COLUMN:
                continue
            col = head.strip('"')
            if not re.fullmatch(r"[a-z_][a-z0-9_]*", col, re.I):
                continue
            cols.setdefault(col, piece[len(head):].strip())
        if cols:
            out.setdefault(name, cols)
    return out


def live_columns(cur, table: str, is_pg: bool) -> set[str]:
    """The columns a live table has, or an empty set if it has none."""
    try:
        if is_pg:
            cur.execute("SELECT column_name FROM information_schema.columns "
                        "WHERE table_name = %s", (table,))
        else:
            cur.execute("PRAGMA table_info(" + table + ")")
        rows = cur.fetchall()
    except Exception:  # noqa: BLE001 - a missing table is not this job
        return set()
    out = set()
    for r in rows:
        if isinstance(r, dict):
            out.add(r.get("column_name") or r.get("name"))
        else:
            out.add(r[0] if is_pg else r[1])
    return {c for c in out if c}


def add_column_sql(table: str, column: str, ddl: str, *, is_pg: bool,
                   schema: str = "") -> str:
    """One ALTER. PRIMARY KEY / UNIQUE / AUTOINCREMENT are stripped.

    Neither engine can add a primary key or a unique constraint through ADD
    COLUMN, and the plain column is still worth having - a table missing it
    fails on every INSERT, while a table missing its uniqueness fails only on
    a duplicate somebody has yet to write.
    """
    clean = re.sub(r"\b(PRIMARY\s+KEY|UNIQUE|AUTOINCREMENT)\b", "", ddl,
                   flags=re.I)
    clean = " ".join(clean.split())
    qualified = table if (is_pg is False or not schema) else schema + "." + table
    # IF NOT EXISTS keeps the emitted SQL re-runnable by a DBA. SQLite has no
    # such clause on ADD COLUMN, so its form is the plain one - and it is only
    # ever emitted for a column just confirmed absent.
    guard = "IF NOT EXISTS " if is_pg else ""
    return f"ALTER TABLE {qualified} ADD COLUMN {guard}{column} {clean}".strip()


def needs_a_default(ddl: str) -> bool:
    """``NOT NULL`` with no ``DEFAULT``.

    Both engines refuse that on a table that has rows. Reported rather than
    forced: inventing a default is a decision, and a wrong one is worse than
    a gap somebody can see.
    """
    return bool(re.search(r"\bNOT\s+NULL\b", ddl, re.I)) and \
        not re.search(r"\bDEFAULT\b", ddl, re.I)


def reconcile(cur, expected: dict[str, dict[str, str]], *, is_pg: bool,
              schema: str = "") -> tuple[list[str], list[str]]:
    """Add every declared column a live table lacks.

    Returns ``(added, refused)`` as ``"table.column"`` strings. A table that
    does not exist is skipped, not created - that is the provisioners' job,
    and creating one here would make two things responsible for it.
    """
    added: list[str] = []
    refused: list[str] = []
    for table, columns in sorted(expected.items()):
        live = live_columns(cur, table, is_pg)
        if not live:
            continue
        for column, ddl in columns.items():
            if column in live:
                continue
            if needs_a_default(ddl):
                refused.append(f"{table}.{column} (NOT NULL, no DEFAULT)")
                continue
            try:
                cur.execute(add_column_sql(table, column, ddl, is_pg=is_pg,
                                           schema=schema))
                added.append(f"{table}.{column}")
            except Exception as exc:  # noqa: BLE001
                refused.append(f"{table}.{column} ({type(exc).__name__})")
                logger.debug("add column %s.%s failed", table, column,
                             exc_info=True)
    return added, refused
