"""What a run did NOT cover, reported by the harness at run completion.

THE PROBLEM THIS EXISTS FOR. A run's record knows about its own steps: which
ran, which retried, which failed. It knows nothing about what was never queued
for it. So a pipeline that consumes half its input reaches ``done`` with every
gate green, and the shortfall is not a failure anywhere — it is an ABSENCE, and
an absence is invisible to a success check. The deliverable simply rests on
less evidence than the reader believes, and the confidence scores quietly
reflect it.

Found live: a client-simulation session ran a detection pipeline to ``done``,
reported four barriers with a confident narrative, and never mentioned that 100
of the ingested call notes had not been processed — so every barrier rested on
one of the two available detection methods. The agent HAD run the domain's
status command, during orientation, when the hub was empty and the backlog line
read 0. It checked preconditions at the start and never checked postconditions
at the end. The information was available; the timing was wrong.

Telling an agent to look harder is the fix that keeps failing — a rule stated
to a model is a request. This makes the postcondition part of the run RECORD,
produced by the harness at the moment of completion, so it is in front of
whoever reads the run next whether they thought to ask or not.

WHY IT IS DECLARATIVE AND CORE STAYS DOMAIN-FREE. Core cannot know what
"unprocessed" means for a domain — a backlog is signals here, documents
elsewhere, claims somewhere else. So the workflow DECLARES the commands whose
output describes its own coverage, and core runs them and records what they
said. Same seam as ``requires_artifacts``: the domain states the contract, the
harness enforces the reporting.

    # workflow.yaml
    coverage:
      - name: unprocessed backlog
        command: iof-signals status

Nothing here fails a run. Coverage is a REPORT, not a gate: a pipeline that
legitimately leaves a backlog (a nightly batch, a sampled corpus) must not be
marked failed for it. The point is that the number is stated rather than
absent.
"""

from __future__ import annotations

import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any

#: A coverage command is a report, not a build step. It must never be able to
#: hold a run open, so it is capped hard and its failure is recorded rather
#: than raised.
_TIMEOUT_S = int(os.getenv("IOF_COVERAGE_TIMEOUT_S", "60") or 60)

#: Output is stored on the run record and printed in `explain`; a command that
#: dumps a whole table must not push the verdict off the screen.
_MAX_CHARS = 4000


def declared_checks(workflow: Any) -> list[dict]:
    """The ``coverage:`` entries of a workflow, normalised.

    Read from the RAW snapshot the same way ``learning:`` and the swarm markers
    are, so an older loader that has never heard of the key ignores it rather
    than failing to load the workflow.
    """
    raw = None
    if isinstance(workflow, dict):
        raw = workflow.get("coverage")
    else:
        raw = getattr(workflow, "coverage", None)
    if not raw:
        return []
    out: list[dict] = []
    for i, entry in enumerate(raw if isinstance(raw, list) else [raw]):
        if isinstance(entry, str):
            out.append({"name": f"check {i + 1}", "command": entry})
        elif isinstance(entry, dict) and entry.get("command"):
            out.append({"name": str(entry.get("name") or f"check {i + 1}"),
                        "command": str(entry["command"])})
    return out


def run_checks(checks: list[dict], cwd: Path | None = None,
               env: dict | None = None) -> list[dict]:
    """Execute each check and return what it said. Never raises.

    A check that fails is REPORTED as failed rather than swallowed: "the
    coverage command errored" is itself a coverage fact, and silence is what
    let the original defect sit.
    """
    # A COVERAGE CHECK NAMES A CONSOLE SCRIPT, SO IT NEEDS THE SAME PATH AN
    # EXEC STEP GETS. A pack's console scripts are installed beside the
    # interpreter running this orchestrator, and a caller who never activated
    # the venv - invoking `.venv/Scripts/aicore.exe` by path, which is what a
    # scheduled run does - has no such entry on PATH. `_run_exec_step`
    # prepends it for exactly that reason; this did not, so one and the same
    # command resolved as a STEP and failed as a CHECK in the same run.
    # Measured live: the pipeline's first exec step ran its tool fine while
    # the run's own coverage reported "is not recognized as an internal or
    # external command".
    #
    # It degraded exactly where it hurts. The report still appeared, still
    # green-looking at a glance, saying only that a command failed - and this
    # module exists because a run that consumed half its backlog reads
    # perfectly healthy. A guard against silence must not itself go quiet for
    # an environmental reason.
    _env = {**os.environ, **(env or {})}
    _scripts = str(Path(sys.executable).parent)
    _env["PATH"] = _scripts + os.pathsep + _env.get("PATH", "")

    results: list[dict] = []
    for chk in checks:
        cmd = chk["command"]
        entry: dict = {"name": chk["name"], "command": cmd}
        try:
            proc = subprocess.run(
                cmd if os.name == "nt" else shlex.split(cmd),
                shell=os.name == "nt",
                cwd=str(cwd) if cwd else None,
                env=_env,
                capture_output=True, text=True, timeout=_TIMEOUT_S,
            )
            entry["exit_code"] = proc.returncode
            out = (proc.stdout or "") + (
                ("\n" + proc.stderr) if proc.returncode and proc.stderr else "")
            entry["output"] = out.strip()[:_MAX_CHARS]
        except subprocess.TimeoutExpired:
            entry["exit_code"] = -1
            entry["output"] = f"(coverage check exceeded {_TIMEOUT_S}s and was stopped)"
        except Exception as exc:                              # noqa: BLE001
            entry["exit_code"] = -1
            entry["output"] = f"(coverage check could not run: {exc})"
        results.append(entry)
    return results


def render(results: list[dict]) -> str:
    """The block printed under a run's completion, and by ``explain``."""
    if not results:
        return ""
    lines = ["COVERAGE AT COMPLETION",
             "  what this run did NOT cover is as much a result as what it did"]
    for r in results:
        head = f"  - {r['name']}"
        if r.get("exit_code"):
            head += f"   (command failed, exit {r['exit_code']})"
        lines.append(head)
        lines.append(f"    $ {r['command']}")
        for line in (r.get("output") or "(no output)").splitlines():
            lines.append(f"      {line}")
    return "\n".join(lines)
