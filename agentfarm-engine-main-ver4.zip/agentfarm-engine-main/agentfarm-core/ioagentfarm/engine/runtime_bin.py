"""Resolve the agent-runtime console script (``iobot``).

One canonical implementation, because this had drifted into THREE copies —
``cli.py:_iobot_bin``, ``engine/iobot_runner.py:_resolve_iobot_bin`` and
``web/spawn.py:_iobot_bin`` — each hardcoding the binary name. Renaming the
runtime meant editing all three, and missing one would surface only when that
particular spawn path ran: the web spawner is the Studio/UI run path, so a miss
there is invisible until a user starts a run from the browser.

Kept dependency-free (stdlib only) so `web/spawn.py` and `engine/` can import it
without pulling in the CLI.
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

# One name. The runtime ships exactly one console script, `iobot`; a venv that
# resolves anything else is not an install of this product.
RUNTIME_BIN_NAMES = ("iobot",)


def runtime_bin() -> str:
    """Path to the runtime binary, preferring the one beside sys.executable.

    Venv-local wins over PATH so we never pick up a stale system-wide install
    while running inside a project venv.
    """
    venv_dir = Path(sys.executable).parent
    suffix = ".exe" if sys.platform == "win32" else ""
    for name in RUNTIME_BIN_NAMES:
        local = venv_dir / f"{name}{suffix}"
        if local.exists():
            return str(local)
    for name in RUNTIME_BIN_NAMES:
        found = shutil.which(name)
        if found:
            return found
    return RUNTIME_BIN_NAMES[0]  # let subprocess raise a clear error


def runtime_bin_available() -> bool:
    """Whether a runtime binary can actually be resolved."""
    resolved = runtime_bin()
    return Path(resolved).exists() or shutil.which(resolved) is not None
