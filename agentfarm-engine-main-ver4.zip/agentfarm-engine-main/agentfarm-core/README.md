# agentfarm-core

The **AgentFarm SDK core** — the domain-agnostic multi-agent workflow runtime
(DAG scheduler, state store, iobot orchestration + patches, web/session/A2A
APIs, channels, forensics, learning) plus the built-in core pack of shared
agents (Jarvis, Quinn, Alex, analyst, developer, reviewer, …).

Domain solutions plug in **without editing core** via the `aicore.packs`
entry point — see `solutions/procurement` (a real example), `solutions/_template`
(copy-to-start scaffold), and the pack registry in `ioagentfarm/packs.py`.

> The import package is currently `ioagentfarm`; the `ioagentfarm → agentfarm`
> import rename is a tracked follow-up (see `../SDK_REFACTOR_PLAN.md`, decision D3).

Install (editable, dev):

```bash
pip install -e agentfarm-core[iobot]
pip install -e agentfarm-skills --no-deps
pip install -e solutions/procurement --no-deps
```
