# AI Core Harness engine

The engine runs multi-agent workflows: it schedules the step graph, spawns each
agent on the IOBOT runtime, stores runs and steps, and serves the engine web
API. It also supplies the `aicore` CLI and the always-on agents Jarvis, Quinn
and Alex.

Published to your package index as **`ai-core-harness-engine`**.

## Install

```bash
python -m venv .venv
.venv/Scripts/activate            # Linux and macOS: source .venv/bin/activate
pip install ai-core-harness-engine ai-core-harness-skills
aicore --version
```

The agent runtime, the web API and DuckDB are installed with it. There are no
extras to select.

## First run

```bash
aicore init-home                  # lays down the ~/.iobot/ templates to fill in
aicore config-check               # confirms the model provider resolves
aicore init                       # creates the state schema (needs CREATE on the database)
aicore setup-agents --workspace acme
aicore run <workflow> --goal "..." --workspace acme
```

A workspace keeps its settings, including its database URL, in
`~/.iobot/workspaces/<workspace>/.env`. That file is the only one read; a
`.env` beside your repository or in your home directory is not — `aicore
current` lists the ones it ignored, so a setting in the wrong file shows up as
ignored rather than as silence. `aicore init` is only needed
against a shared database: `aicore local on` confines a workspace to your
working directory and a SQLite file under `.iof/`. Run `aicore current` before
any command that writes; it reports the workspace, environment file and
database in force.

## Operating notes

- **`aicore sync` is what makes installed content visible to the Studio.** The
  Studio API pod installs no solution content and reads everything from the
  database. Every sync rewrites what it finds and deletes what it does not, so
  an upgrade lands by re-running it.
- **`aicore serve` has no authentication.** It listens on port 8111 and anything
  that can reach the port can create runs. Keep it on an internal network.
- **`aicore lint-workflow <name>` before you run.** The loader ignores keys it
  does not recognise, so a misspelled `requires_artifacts` or `skills` loads
  cleanly and silently disables the behaviour you wanted.
- **`aicore forensics explain <run_id>` first, for any question about a run.**
  It composes the run record, the step timeline, per-attempt evidence and the
  coverage report into one verdict. Reach for it before reading logs.
- **`aicore supervise --once` on a cron for CLI-only deployments.** Nothing
  else reaps a step whose executor died — `aicore serve` runs this
  automatically, but a deployment without it has no self-healing at all.
- **Upgrade by version bump.** Do not fork or edit this package. Your workspace
  plugs in through its own entry point and needs no changes here.

## Next

[`../aicore_docusaurus/`](../aicore_docusaurus/) is the full track: getting
started, building solutions, running them, improving them, reference and
troubleshooting. The shared craft skills ship as a separate package with its
own CLIENT_README.
