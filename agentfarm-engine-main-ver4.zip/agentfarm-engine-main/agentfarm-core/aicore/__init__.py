"""`aicore` - the name a solution imports the SDK by.

THE SAME ALIAS THE CLI ALREADY HAS. The console script is `aicore` while the
implementation package is named otherwise, and the import surface had no such
alias: a solution author's only way in was the implementation name, which is
not the product's name and is the one thing the client documentation may not
print. So the documentation described the import instead of showing it, and a
reader had to derive one line of code from their own source tree.

This is an ALIAS, not a copy. Every module below is registered in
`sys.modules` as the SAME module object the engine already imported, so
`aicore.sdk.obs` IS the engine's `obs` - one set of module state, no
divergence possible, and nothing to keep in step. The implementation name
keeps working unchanged: existing solution repositories import it, and
breaking them on an SDK upgrade is exactly what "upgrades are version bumps,
not merges" exists to prevent.

    from aicore.packs import Pack        # what a solution's pack() declares
    from aicore.sdk import obs, route    # what a tool records and returns
"""
from __future__ import annotations

import sys as _sys

import ioagentfarm as _engine
from ioagentfarm import packs as _packs
from ioagentfarm import sdk as _sdk
from ioagentfarm.sdk import obs as _obs
from ioagentfarm.sdk import route as _route

#: Registered by NAME so `import aicore.sdk.obs` and `from aicore.packs
#: import Pack` both resolve to the engine's own module objects. Assigning
#: the attributes alone would leave `import aicore.packs` failing, because
#: the import system looks for a submodule on disk that is not there.
for _name, _mod in (("packs", _packs), ("sdk", _sdk),
                    ("sdk.obs", _obs), ("sdk.route", _route)):
    _sys.modules[f"{__name__}.{_name}"] = _mod

packs = _packs
sdk = _sdk

__version__ = _engine.__version__

__all__ = ["packs", "sdk", "__version__"]
