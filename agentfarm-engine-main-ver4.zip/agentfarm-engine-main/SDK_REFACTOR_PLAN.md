# AgentFarm SDK Refactor — Phased Plan

> **Branch:** `refactor/agentfarm-sdk` (off `feature/ppt-decks-main` @ `a0de933`)
> **Goal:** Split the monolithic `ioagentfarm` package into a reusable **`agentfarm-core`** SDK (framework-team owned, published to Artifactory) plus open-ended **`solutions/<domain>`** packs (domain-team owned). Prove the model end-to-end on **procurement**; leave a template + pharma stub for the next domains.
> **Success definition:** A brand-new domain with one trivial workflow registers and runs **without editing a single `agentfarm-core` file**, and the existing procurement solution produces the *same grounded output it does today*.

---

## 1. Target structure (monorepo at project root)

```
io-procurement-insight-engine/            # repo root (unchanged name for now)
├── agentfarm-core/                       # THE SDK LIB → Artifactory (framework team)
│   ├── pyproject.toml                    # name: agentfarm-core ; import pkg: agentfarm
│   ├── agentfarm/
│   │   ├── __init__.py                   # windows env recovery + iobot patch bootstrap
│   │   ├── packs.py                      # ★ NEW: Pack, PackRegistry, load_registry()
│   │   ├── engine/                       # scheduler, store, db, templating, protocol,
│   │   │                                 #   workflow_loader, workspaces (GENERALIZED to registry)
│   │   ├── web/                          # FastAPI, spawn, runner, sse, storage, thought_processor
│   │   │                                 # (session_engine REMOVED — commit 89f05a2, workflow-driven only)
│   │   ├── channels/                     # teams
│   │   ├── vendored/  _iobot_patches.py
│   │   ├── cli.py  cli_orchestration.py  cli_forensics.py
│   │   └── corepack/                     # the built-in "core pack" content
│   │       ├── agents/                   # jarvis, queryngine(Quinn), project_lead(Alex),
│   │       │                             #   analyst, developer, reviewer, data_analyst(Ria),
│   │       │                             #   strategist, domain_consultant(Morgan),
│   │       │                             #   data_architect, platform_engineer, io
│   │       ├── skills/                   # output_protocol ONLY (engine contract);
│   │       │                             #   capability skills live in agentfarm-skills (D2)
│   │       └── workflows/                # generic: bug_fix, feature_dev, story_loop,
│   │                                     #   project_lead, pilot_build, forensic_analysis, deck_build
│   └── tests/
├── agentfarm-skills/                     # SEPARATE dist (D2) — skills-only pack via entry point
│   ├── pyproject.toml                    # name: agentfarm-skills ; entry-point aicore.packs
│   └── agentfarm_skills/
│       ├── __init__.py                   # def pack() -> Pack(skills=files("agentfarm_skills.skills"))
│       └── skills/                       # data_query, dataviz, guardrails, plan_and_checkpoint,
│                                         #   presentation, report_standards, vectorfs_query
├── solutions/
│   ├── _template/                        # ★ scaffold for domain N (copy-to-start)
│   │   ├── pyproject.toml                # entry-point stanza + core dep
│   │   └── agentfarm_template/{__init__.py, workflows/, agents/, skills/, metadata/}
│   ├── procurement/                      # FIRST real solution (proof)
│   │   ├── pyproject.toml                # name: agentfarm-procurement
│   │   ├── agentfarm_procurement/
│   │   │   ├── __init__.py               # def pack() -> Pack(...)
│   │   │   ├── workflows/                # procurement_intelligence, spend_risk_intelligence,
│   │   │   │                             #   doc_ingestion, external_intel_refresh
│   │   │   ├── agents/                   # procurement_analyst(Iris), aria, doc_ingestor
│   │   │   ├── skills/                   # _procurement pack (api_query, contract_analysis,
│   │   │   │                             #   spend_commercial, vendor_risk) + IT-VMO deep skills
│   │   │   │                             #   (it_vendor_management, spend_intelligence,
│   │   │   │                             #   vendor_risk_assessment, contract_intelligence,
│   │   │   │                             #   renewal_pipeline, contract_value_realization,
│   │   │   │                             #   license_compliance, cloud_finops,
│   │   │   │                             #   saas_rationalization, market_benchmark,
│   │   │   │                             #   market_intelligence, vendor_strategy, etc.)
│   │   │   ├── metadata/                 # BD catalog.yaml, databases.yml, synonyms.yaml,
│   │   │   │                             #   vectorfs.yaml, data/*.csv, generate_spend_cube.py
│   │   │   └── tools/                    # seed_qdrant_contracts
│   │   └── tests/
│   └── ainf/                             # ainf-core pharma domain (5 always-on A2A agents)
│       ├── pyproject.toml                # name: agentfarm-pharma
│       ├── ainf_core/                    # the import package (import ainf_core)
│       │   ├── __init__.py               # pack()
│       │   ├── agents/                   # Prism, sia, FeedbackLens, profound, Synthesis
│       │   ├── session/                  # pharma taxonomy.yaml (session_engine removed)
│       │   ├── products/                 # brand YAMLs — imported from upstream later
│       │   └── goals/                    # pharma playbooks — imported from upstream later
│       └── tests/
├── ts-skills/                            # unchanged (separate TS monorepo)
├── docs/  CLAUDE.md  MEMORY.md           # unchanged
└── pyproject.toml (root)                 # dev workspace: editable-installs core + solutions
```

**Notes**
- `ts-skills/` (vectorfs CLI) is untouched — separate build lifecycle.
- Package **import name** becomes `agentfarm`; distribution name `agentfarm-core`. A compat shim `ioagentfarm → agentfarm` re-export ships for one release so the `procurement-insights` consumer doesn't break on day one (decision D3 below).
- **Deep IT-VMO skills' physical home** is confirmed in Phase 1 (they're referenced by the procurement workflow but may live under `agents/procurement_analyst/workspace/skills/` and/or `agents/_procurement/`). Wherever they are, they're procurement-owned and move to `solutions/procurement/.../skills/`.

---

## 2. Classification manifest (what moves where)

### Workflows
| workflow | → destination | note |
|---|---|---|
| bug_fix, feature_dev, story_loop, project_lead, pilot_build, forensic_analysis, deck_build | **core** `corepack/workflows` | domain-neutral |
| procurement_intelligence, spend_risk_intelligence, doc_ingestion, external_intel_refresh | **solutions/procurement** | IT-VMO / contract / vendor |
| test_queryngine | **core** (engine) + dataset → **solutions/procurement** | harness is generic; its bundled spend CSV is procurement sample data |

### Agents
| agent | → destination | note |
|---|---|---|
| jarvis, queryngine(Quinn), project_lead(Alex), analyst, developer, reviewer, data_analyst(Ria), strategist, data_architect(Arjun), platform_engineer(Priya), io | **core** `corepack/agents` | generic identities; domain comes from skills filter |
| domain_consultant(Morgan) | **core** | generic advisor SOUL; reused by deck_build; procurement skills injected per-workflow |
| procurement_analyst(Iris) | **solutions/procurement** (see D1) | procurement-branded; discipline generic |
| aria(ARIA), doc_ingestor | **solutions/procurement** | procurement strategist / contract extraction |
| governance_agent(Gita) | **core (candidate)** | generic "data governance & compliance"; confirm in Phase 1, default to core |
| _common | **core** `corepack/skills` | shared skills pack |
| _procurement | **solutions/procurement** | api_query, contract_analysis, spend_commercial, vendor_risk |

### Skills — THREE tiers by ownership
The registry merges a `skills=` source from **every** pack; the workflow's `skills:` filter (the domain selector) picks which each agent loads. Ownership:

| tier | owner | home | contents |
|---|---|---|---|
| **engine-contract** | framework | `agentfarm-core/corepack/skills` | `output_protocol` only |
| **shared capability** | framework | `agentfarm-skills` (separate dist, D2) | `data_query, dataviz, guardrails, plan_and_checkpoint, presentation, report_standards, vectorfs_query` |
| **domain-specific** | **domain team** | `solutions/<domain>/.../skills` | procurement: `_procurement` pack (api_query, contract_analysis, spend_commercial, vendor_risk) **+** IT-VMO deep modules (it_vendor_management, spend_intelligence, vendor_risk_assessment, contract_intelligence, renewal_pipeline, contract_value_realization, license_compliance, cloud_finops, saas_rationalization, market_benchmark, market_intelligence, vendor_strategy, negotiation_advisory, sourcing_advisory, business_case, transformation_planning, risk_advisory, vendor_governance_compliance, it_benefits_analysis, it_quality_gates) |

A domain team owns its **agent workspaces + domain skills together** in one repo. Grounding skills `catalog_reader`/`grounded_analysis` are shared-capability (any domain reuses them) — confirm their physical home in Phase 1 and route to `agentfarm-skills`.

### Tools
| tool | → destination (tentative — confirm in Phase 1) |
|---|---|
| iof_api, iof_extract, iof_store, iof_validate | **core** (generic API/extract/store/validate) |
| iof_assess, iof_reconcile | **confirm** — pharma/EDI-flavored (`iof-pharma-*` scripts); likely solutions |
| seed_qdrant_contracts | **solutions/procurement** |

### Pharma
- **No workflows/agents/products exist in this repo.** Pharma = the hardcoded leaks in `session_engine/` only. `solutions/ainf` is created as the *home* for those leaks + a future import; it is **not runnable** here until brand YAMLs/goals are imported from the upstream ioagentfarm repo.

---

## 3. Domain leaks to extract from core (config-over-code)

These are the real work — the seam itself is a day; these make core domain-free.

| # | leak (file:line) | fix |
|---|---|---|
| 1 | `cli.py:1920` `_procurement_roles={"aria"}` in `setup-agents` | use the existing generic `domain_skills_dirs` seam (`workspaces.py:188`); packs declare their own skill dirs |
| 2 | `session_engine/loader.py:315` pharma signal→barrier map | move to `taxonomy.yaml` in pharma pack; loader reads `pack.taxonomy` |
| 3 | `session_engine/workspace.py:100` brand-slug prefixes `("tremfya_",…)` | derive from product configs, not a literal tuple |
| 4 | `session_engine/loader.py:214` `revenue_mn`/`persistence_pp` metric | metric name from product.yaml |
| 5 | `web/thought_processor.py:105,119` "Querying procurement data" / "Searching contract documents" | generic labels, or per-tool label supplied by the active pack |
| 6 | `pyproject.toml:32-39` `iof-pharma-*`, `iof-seed-contracts` scripts | move to each domain pack's `[project.scripts]` |

Core is clean afterward: `cli_orchestration.py` and `engine/` runner/scheduler/store already have **zero** domain coupling.

---

## 4. The registration seam (`agentfarm/packs.py`)

```python
@dataclass(frozen=True)
class Pack:
    name: str
    workflows: Traversable | None = None   # files("agentfarm_procurement.workflows")
    agents:    Traversable | None = None
    skills:    Traversable | None = None    # auto-injected into every agent workspace
    products:  Traversable | None = None
    goals:     Traversable | None = None
    taxonomy:  Traversable | None = None    # replaces hardcoded pharma maps
    labels:    dict[str, str] | None = None # tool→UI-label (replaces thought_processor hardcodes)

def load_registry() -> list[Pack]:
    packs = [core_pack()]                              # corepack/* — jarvis/quinn/alex + shared skills
    for ep in entry_points(group="aicore.packs"):  # domain packs self-register
        packs.append(ep.load()())
    return packs                                       # precedence: .iof/ override > pack > core
```

Domain repo registers with one stanza — **no core edit ever**:
```toml
[project.entry-points."aicore.packs"]
procurement = "agentfarm_procurement:pack"
```

Scanners generalized (behavior identical while `ioagentfarm.*` is the only registered source):
- `workflow_loader.py:80` → iterate `registry.workflow_sources()`
- `workspaces.py:12` → iterate `registry.agent_sources()` + `registry.skill_sources()`
- `session_engine/loader.py:17` → iterate `registry.product_sources()`

---

## 5. Phased execution

### Phase 0 — Baseline & freeze (no code moves) ✅ branch done
- [x] Create branch `refactor/agentfarm-sdk`.
- [ ] **Capture GREEN baseline as the regression oracle:** run `procurement_intelligence` end-to-end on the BD catalog (or, if too slow, `--dry-run` + `test_queryngine` smoke + queryngine smoke). Save deliverables (`intelligence_report.md`, grounded figures + SQL) to `docs/baselines/procurement_pre_refactor/`. *This is the "did I break it?" reference.*
- [ ] Finalize inventory: read remaining SOULs/tool docstrings, confirm deep-skill physical locations, resolve governance_agent + iof_assess/iof_reconcile. Freeze the manifest in §2.
- [ ] Resolve decisions D1–D3 (below).

### Phase 1 — Build the seam in-place (no restructure)
- [ ] Add `agentfarm/packs.py` (`Pack`, `PackRegistry`, `load_registry`, `core_pack`).
- [ ] Generalize the 3 scanners to iterate the registry; register `ioagentfarm.{workflows,agents,products}` as the sole source → **identical behavior**.
- [ ] **Gate:** baseline still green. De-risks the seam independently of any file move.

### Phase 2 — De-couple domain leaks from core
- [x] **Leak #1** (setup-agents procurement hardcode) → pack-driven. New generic
  `PackRegistry.domain_skill_injections()` reads a `_<domain>/inject.yaml` manifest
  from each pack's agent source; `cli.py setup-agents` no longer names procurement
  or aria. Manifest ships at `agents/_procurement/inject.yaml`.
- [x] **Leak #5** (thought_processor labels) → domain-neutral defaults + pack override
  (`Pack.labels`, `api:<endpoint>` keys). Core carries no "procurement/contract/spend"
  strings (only an explanatory comment). Procurement re-supplies flavor as pack labels in Phase 3.
- [x] **Leaks #2/#3/#4 (session_engine pharma taxonomy/slugs/metric) — MOOT (session_engine removed).**
  Superseded by deleting `session_engine/` entirely (commit `89f05a2`); the code that carried
  these leaks no longer exists. See §7b. (Original plan was to relocate the config into
  `solutions/ainf`; removal made that unnecessary for the workflow-driven solution.)
- [ ] **Leak #6 (pyproject `iof-pharma-*` / `iof-seed-contracts` scripts) DEFERRED to Phase 3**,
  moves with the tools into each solution's `[project.scripts]`.
- [x] **Gate (Phase 2 scope):** procurement-path core files (`cli.py` setup-agents,
  `web/thought_processor.py`) domain-free; baseline oracle green (48 POs / 16 vendors / $100.45M).

### Phase 3 — Physical restructure (monorepo layout)
- [ ] Create `agentfarm-core/`; `git mv` engine/web/session_engine/channels/cli/vendored into `agentfarm-core/agentfarm/` (preserve history).
- [ ] `git mv` core pack content → `corepack/{agents,skills,workflows}`.
- [ ] Rename import `ioagentfarm` → `agentfarm`; add `ioagentfarm` compat shim (D3).
- [ ] Create `solutions/procurement/`; `git mv` procurement workflows/agents/skills/metadata/tools in; add `pyproject.toml` + `__init__.pack()` + entry point.
- [ ] Create `solutions/ainf/` (stub + session leaks) and `solutions/_template/`.
- [ ] Root dev `pyproject.toml` / install script: `pip install -e agentfarm-core -e solutions/procurement`.

### Phase 4 — Cut over registration
- [ ] Core pack registers only `corepack/*`; drop `ioagentfarm.{workflows,agents,products}` built-in sources.
- [ ] Procurement content resolves **purely** via the installed entry point.
- [ ] **Gate:** `agentfarm list-workflows` shows procurement_intelligence sourced from the pack, not core.

### Phase 5 — Test & validate procurement (ACCEPTANCE)
- [ ] `pip install -e` core + procurement in the venv.
- [ ] `agentfarm setup-agents` provisions Iris/domain_consultant/reviewer with procurement skills via the pack — **no hardcoded `_procurement_roles`**.
- [ ] `agentfarm run procurement_intelligence --dry-run` → DAG validates.
- [ ] **Full run on BD catalog** → assert: grounded figures + SQL cited, `requires_artifacts` gate fires, output **diffs clean vs Phase 0 baseline**.
- [ ] `test_queryngine` + queryngine smoke pass.
- [ ] Re-validate iobot patches (import sentinels; `IOF_DISABLE_STREAMING=true python -c "import agentfarm"`).

### Phase 6 — Prove N-domain generalization + pharma stub
- [x] Scaffolded throwaway `solutions/hello` from `_template` → `pip install -e` → registry
  discovered it via entry point (`[core, hello, pharma, procurement, skills]`), `hello_world`
  workflow loaded + dry-ran, procurement kept working, **`git status ioagentfarm/` = 0**.
  Probe removed after proving. Proof: `docs/baselines/n_domain_proof/`.
- [x] Confirmed `session_engine` imports clean in core and the pharma taxonomy resolves from
  `solutions/ainf` (`_taxonomy_map` → SIG-PF→PERSISTENCE, …). Upstream pharma brand-content
  import documented as follow-on (§7b).

---

## 6. Decisions — RESOLVED (2026-07-08)

- **D1 — Iris ownership → procurement owns Iris.** The whole `procurement_analyst` agent (SOUL + skills) moves to `solutions/procurement`. Core still ships the generic grounding skills (`catalog_reader`, `grounded_analysis`) any domain can reuse. Revisit to a generic `grounded_analyst` base only when a 2nd domain needs one.
- **D2 — Shared skills → SEPARATE `agentfarm-skills` package.** ppt/dataviz/dataquery/vectorfs + guardrails/plan_and_checkpoint/report_standards ship as their own distribution, **registered as a skills-only pack via the `aicore.packs` entry point** (dogfoods the seam — core does not hardcode them). `agentfarm-core` and `solutions/*` both depend on it. Only `output_protocol` (engine contract) stays inside core. Skills iterate independently of core releases.
- **D3 — Rename `ioagentfarm`→`agentfarm` + compat shim.** Import package becomes `agentfarm` (dist `agentfarm-core`); a one-release `ioagentfarm` re-export shim keeps the `procurement-insights` consumer working until it migrates. Rename lands in Phase 3 (not Phase 1).

## 7. Risks & mitigations
- **Windows env-recovery + iobot patch bootstrap** (`__init__.py`) must run before any stdlib call — carry it into `agentfarm/__init__.py` verbatim; verify sentinels in Phase 1 & 5.
- **`git mv` history preservation** — use `git mv`, commit moves separately from edits so blame survives.
- **Entry-point discovery in editable installs** — verify `entry_points(group=...)` resolves for `pip install -e` packs (it does with modern setuptools/pep517; test in Phase 4).
- **`.iof/` snapshot paths** — run snapshots copy the workflow dir; confirm pack-sourced workflows snapshot correctly (Phase 5 full run exercises this).
- **Baseline flakiness** — MiniMax stalls can make a "regression" look like a break; diff on grounded *figures/SQL*, not on incidental prose.

## 7b. Session-engine deep pharma coupling — RESOLVED BY REMOVAL

**Superseded (2026-07, branch `core/ainf-reconciliation`, commit `89f05a2`):**
`session_engine/` was **deleted entirely** — the interactive session mode (Savant
Strategy Lab) is not part of the workflow-driven solution. The deep pharma
coupling this section used to track (hardcoded TREMFYA/RYBREVANT prong vocabulary,
drug-name lists, brand barrier logic, worked examples in `prompts/strategist_base.md`
/ `skills/strategist/opening.md`) went away with the module — there is nothing left
to generalize. Removed in the same change: the `IOF_SESSION_BRANDS` web mount, the
session API router, and the `sync-products` / `upload-datasets` CLI commands. The
pharma domain now ships as the always-on **A2A agent** pack (`solutions/ainf`, 5
agents: Prism/sia/FeedbackLens/profound/Synthesis), not session mode. Leaks #2/#3/#4
below (session taxonomy / brand-slug / metric) are therefore **moot** — the code
that carried them no longer exists.

## 8. Out of scope (explicit)
- Publishing to Artifactory / CI pipeline wiring (follow-on after acceptance).
- Importing real pharma brand/goal content (lives in upstream ioagentfarm repo).
- Splitting `solutions/*` into physically separate git repos (this refactor keeps them in-repo under `solutions/`; separate-repo split is a later, trivial step once the entry-point seam is proven).
```
