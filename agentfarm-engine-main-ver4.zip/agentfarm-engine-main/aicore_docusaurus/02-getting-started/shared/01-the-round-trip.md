---
sidebar_position: 1
title: The round trip
description: Where the two tracks meet. An edit made in AI Core Harness Studio is held as a draft; a developer carries it into the repository, and the deployment makes it the running content.
---

# The round trip

**This is the page where the two tracks meet.** A solution repository is built
in git and delivered to an environment as an installed package. AI Core Harness
Studio edits the same content from a browser. The platform has one rule for how
those two meet:

> **The running solution is the one the repository delivered. Nothing replaces
> it in place.**

An edit made in the Studio is held as a **draft** until a developer carries it
into the repository. A change therefore reaches an environment only through
review, build and deployment, and every run in that environment executes content
that came from a commit.

## Which track are you on?

**Code-first** — content is authored in a repository, installed, and run. The
repository is already the source, and this page describes what happens when a
colleague edits the same item from the Studio.

**Studio** — content was built in the Studio and is now required in git, to be
reviewed, versioned, or deployed elsewhere. `aicore drafts apply` is that path,
and it is the second half of this page. A solution repository is required to
apply into ([scaffold one](../code-first/03-example-workflow-windows.md)), along
with a developer holding a checkout of it.

:::note Why there is no button
The platform has no git authority. Applying a draft writes files into a
developer's checkout; reviewing, committing and opening the pull request happen
under that developer's own git identity. A business user therefore cannot
trigger a repository write, and no change enters a repository without a person
seeing the diff.
:::

## 1. Edit in the Studio

In the UI: **Studio → Workflows → `logistics_report` → edit a step prompt →
save.** Make a change that is identifiable in the applied file. Shortening the
compose step's instruction to *"Keep the answer under 80 words"* is the edit
this page was written against.

The save reports that it created a draft, and the editor shows the draft strip
with the draft's status and its actions. A workflow draft is validated as it is
saved; a definition that does not load is reported with the save, before the
draft is tested or applied.

## 2. The draft changes nothing for anyone else

The draft resolves in its author's own test sessions and draft-flagged runs.
Every other user, every other session and every run in the environment continues
to execute the installed content. **Try it** in the draft strip starts a session
that resolves the installed content with the draft applied on top, and the
response names the draft and the version it was applied to, so a test result is
attributable to the draft rather than to the running solution.

This is the property that makes the rest of the page safe: nothing has to be
protected from the draft, because the draft was never serving anyone.

## 3. See what the draft changes

On the machine holding the checkout, with the workspace selected:

```bash
aicore drafts list
```

Each draft is listed with its id, its item, its author, its status — `draft`,
`applied`, `promoted` or `discarded` — and whether it is stale against the
content installed on this machine. The default listing holds `draft` and
`applied` drafts; `--all` includes the rest. Take the id of the draft to
promote, then compare it against the content installed on this machine:

```bash
aicore drafts diff 4
```

The left side is what this machine's packages contain now — the same content a
run here would resolve — not the content the draft was written against. When
those differ the draft is **stale**, and the difference is called out so the
change is read against the correct base. Rebase or discard a stale draft in the
Studio before applying it; applying a stale draft writes it over a base its
author never saw.

## 4. Apply the draft into the checkout

```bash
cd C:/aicore_project/aicore_sol
aicore drafts apply 4
```

The draft's files are written into the checkout at the item's path within the
solution package, and the draft is marked `applied`. The command never commits
and never pushes.

`apply` refuses when the target has uncommitted changes, so an unrelated edit in
the working tree cannot be overwritten without being seen. `--force` proceeds
anyway, and also covers the case where git cannot confirm the target is clean.
For a new workflow in a repository holding more than one solution, `--solution`
names the solution it belongs to; without it the destination is ambiguous and
the command stops. `--dir` applies into a checkout other than the current
directory.

## 5. Review and commit

```bash
git diff --stat
```

The working tree now holds the Studio author's wording. Review it, reconcile it
with any repository-side change to the same file, and commit under the reviewing
developer's identity:

```bash
git commit -qam "adopt the studio edit to the compose step"
```

The pull request, its review and its merge follow the repository's own process.
The platform is not involved in any of them.

## 6. Deployment makes it the running content

After the change merges, the build produces a new version of the solution
package and the environment deploys it. From that point every run resolves the
new content, and the item's version stamp in the Studio names the version it
came from.

The draft then reads **promoted**. That status is detected rather than declared:
it is set when the installed content matches the draft for every file the draft
touched. A draft cannot report itself promoted while the environment still runs
the previous content.

:::note A draft that changes only skill assignment
Adding or removing a skill on an agent is part of the draft and travels with it.
Such a draft touches no file, so there is nothing to compare and it never
detects promotion; close it by hand once the assignment ships.
:::

## What the round trip does not carry

The round trip moves **content**: agents, skills and workflows. Three things are
outside it, and expecting them to travel is the common mistake.

| Not carried | Why, and how it reaches the other side |
|---|---|
| **Tool code** | A command-line tool is an executable, and its launcher is generated when its package is installed. Promoting content does not deliver it; install the solution package on the machine that runs the agents. See [Tools and capabilities](../studio/04-tools-and-capabilities.md). |
| **Swarm definitions** | A swarm is resolved from the installed package or the local state directory, and is not held as content, so it does not travel with a draft. Carry the definition in the repository and install it. |
| **The platform's shared skills** | These arrive with the platform, not with a solution. Copying them into a repository would freeze a version that no platform upgrade could reach. |

Environment values are also outside it. Credentials and endpoints belong to the
machine, never to the content, and nothing in this page moves them.

## Content imported under an earlier model

`aicore workspace pull` and `aicore workspace diff` operate on content imported
into a workspace before the current model. A deployment that has only ever run
the current model holds none, so `diff` reports each repository item as new and
`pull` writes nothing. Where such content exists, `aicore drafts migrate`
converts it into drafts, which then promote through the procedure above.

`aicore workspace push` and `aicore sync` are deprecated: each is still
accepted, performs no work, and reports that it had nothing to do, so an
existing runbook continues to run unchanged.

`aicore setup-agents` is deprecated in the same way **when called without
flags**. `--force` is the exception and still does real work: it discards the
copy of the content prepared on this machine, so the next run or chat re-reads
it from the installed package. That is the remedy when an edit to an installed
solution does not appear — see
[Troubleshooting](../code-first/08-troubleshooting.md).

## Where to go next

- Code-first → [Overview of the examples](../code-first/00-overview.md), each
  of which ends with its own teardown
- Studio → [Teardown](../studio/08-teardown.md)

## Related pages

- [Drafts and promotion](../../03-building-solutions/12-drafts-and-promotion.md)
