---
sidebar_position: 2
title: Troubleshooting (both tracks)
description: Symptoms that are not specific to either track — machine setup, the database, and running a workflow.
---

# Troubleshooting — both tracks

Symptoms common to both tracks: machine setup, the database and the model
provider. Entries are keyed on the text a search would be run against.

:::note Track-specific symptoms
Each track has its own page for symptoms only it produces —
[Code-first](../code-first/08-troubleshooting.md) ·
[Studio](../studio/09-troubleshooting.md).
:::

## `sqlite3.OperationalError: no such table: user`

Login returns HTTP 500 on a new database.

**Cause:** the authentication tables do not exist in the database the Studio API
is using. They are created when the API starts against that database.

**Fix:** restart the Studio API, which creates the `user` and `user_password`
tables at startup, then create the first account. A correctly configured
installation answers an invalid login with `401 {"detail":"Invalid email or
password"}`, never 500.

## `init` reports a database on an unexpected path

```text
Initialized C:\aicore_project\state\.iof
database: C:\c\aicore_project\state\state.db (sqlite)
```

The two lines disagree, and the database is on a path that was not specified.

**Cause:** POSIX-style path rewriting in Git Bash. A POSIX path that is the
entire value of a variable is rewritten to Windows form, but the same path
inside a URL is left literal, and Windows then resolves a leading `/c/` as
drive-relative. `IOF_ROOT=/c/w/.iof` becomes `C:\w\.iof`, while
`IOF_DATABASE_URL=sqlite:////c/w/db` resolves to `C:\c\w\db`.

**Fix:** write paths in Windows form with forward slashes, `C:/…`, wherever the
value is set — the exported variable or the selected workspace's environment
file, `~/.iobot/workspaces/<code>/.env`. Re-run `init`, confirm the two lines
agree, and delete the incorrect directory tree.

## `IOF_DATABASE_URL is not set`

**Cause:** no database URL was found in the environment or in the environment
file the command consulted.

**Fix:** set it in the selected workspace's environment file,
`~/.iobot/workspaces/<code>/.env`, or export it for the single command. In
local mode (`aicore local on`) no database URL is required. `aicore current`
prints the database in force and a `set by` line naming where the value came
from — read that line to confirm the value took effect.

## `503 IOF_DATABASE_URL is not configured (engine DB unavailable)`

**Cause:** the Studio API has no database URL. It resolves the value from its
own environment at request time, independently of the environment in which
other commands run.

**Fix:** configure the database URL where the Studio API runs. The API returns
an error rather than falling back to a local store, so that data is never
served from an unintended source.

## A command reports a database that was not specified {#wrong-database}

```text
Initialized C:\aicore_project\state\.iof
database: postgresql://…@some-host.example.com:5432/somebody_elses_db
```

**Cause:** an `IOF_DATABASE_URL` exported in the shell, or the selected
workspace's environment file, supplied the value.

**Fix:** print the resolved value and its source, then either unset the exported
variable, select a different workspace, or move the setting:

```bash
aicore current         # the `set by` line names what supplied IOF_DATABASE_URL
```

Precedence, highest first: an exported environment variable, then the selected
workspace's environment file, `~/.iobot/workspaces/<code>/.env`. No other file
is read: an environment file in the working directory, in a directory above it,
or in the home directory is reported by `aicore current` as ignored and is never
loaded.

## `No such file or directory` for a path that exists

```text
bash: C:/…/.venv/Scripts/aicore: No such file or directory
```

**Cause:** an empty variable. A path built from `"$SOMETHING/.venv/…"` with
`SOMETHING` unset resolves to `/.venv/…`, and the resulting message quotes a
path that appears plausible.

**Fix:** print the variable; an empty value confirms the cause. No procedure in
this guide requires a path to be held in a variable — activate the virtual
environment and invoke `aicore` directly.

If the path is spelled out in full and the command still fails, check the file
name on disk. On Windows the virtual environment contains `aicore.exe` and no
extension-less copy; Git Bash appends `.exe` when resolving, so an
extension-less path normally succeeds.

## `bash: !2026: event not found`

**Cause:** an argument contains `!`, which an interactive shell expands as
history before the command runs. The command is never executed. Only
interactive shells apply this expansion, which is why the same line succeeds
inside a script.

Passwords are the most common case, but the rule applies to any argument
containing `!`, including a goal string.

**Fix:** enclose the argument in single quotes, or supply it on standard input:

```bash
printf '%s\n' 'ChangeMe!2026' | some-command
```

`set +H` disables history expansion for the shell.

The error names the argument, which suggests the argument was rejected. It was
not submitted.

## Any password is accepted at the Studio login

**Cause:** development authentication is enabled in the environment that started
the Studio API (`IOF_AUTH_DEV=1`). It accepts any credentials and treats
unauthenticated callers as a development identity.

**Fix:** remove the setting from the environment of the deployed service. It
must not be set on any deployed installation.

## A workspace that was created does not appear in the list or the switcher

**Cause:** the workspace has no membership record. Access requires one. Each
creation path grants membership — the command line to the address in
`IOF_BOOTSTRAP_ADMIN`, the Studio to the signed-in user — so this occurs when
membership was suppressed at creation, or when `IOF_BOOTSTRAP_ADMIN` was unset.
In the latter case the create command reports that no one can open the
workspace.

**Fix:** grant access. `create` updates an existing workspace, so re-running it
adds the member without affecting anything else:

```bash
aicore workspace create <code> --member you@yourcompany.com
aicore workspace show <code>        # the access line lists the members
```

A platform administrator can do the same in **Administration → Workspaces**.

## Model calls are rejected immediately

Read operations succeed and generation calls fail.

**Cause:** `maxTokens` is set above 21333 in the model provider configuration,
on an Anthropic provider. That provider rejects non-streaming requests above
this ceiling, and AI Core Harness issues non-streaming requests, so generation calls
fail while smaller requests continue to succeed.

**Fix:** set `"maxTokens": 21333`. `aicore config-check` reports the condition
before a run is started.

This rule applies only to Anthropic providers. Azure and OpenAI providers have
no such ceiling, and a higher value is valid for them; if the symptom appears
there, the cause is different.

## A step reports a timeout after 300 seconds but the run continues

**Cause:** expected behaviour. The step's subprocess continues running after the
model's own call timeout elapses, and the orchestrator polls until the step
completes.

**Fix:** none required. Do not impose shorter timeouts to suppress the message.
See [Automatic recovery](../../04-running-solutions/03-automatic-recovery.md).

## An agent reports that a run does not exist

**Cause:** `IOF_ROOT` is set to a relative path, or is not reaching agent
subprocesses. An agent subprocess runs with a restricted environment and its own
working directory, so a relative value resolves to a different state directory
and the agent reports accurately on that one.

**Fix:** set `IOF_ROOT` to an absolute path in every environment.

## `UnicodeDecodeError` while an agent workspace is prepared

**Cause:** a version-control or state directory exists inside an agent's
workspace, and the copy step reads every file as text.

**Fix:** delete those directories and re-run the command.

## Previous behaviour persists after reinstalling (Windows)

**Cause:** an interrupted installation leaves partially renamed directories in
the virtual environment's `site-packages`, which remain importable.

**Fix:** remove them and reinstall:

```bash
rm -rf <venv>/Lib/site-packages/~*
```

---

If the symptom is not listed here, ask the assistant to diagnose the run
directly — see [Diagnosing runs](../../06-core-assistant/02-diagnosing-runs.md) — or
consult [Common failures](../../08-troubleshooting/01-common-failures.md).

**Next:** [Common failures](../../08-troubleshooting/01-common-failures.md).
