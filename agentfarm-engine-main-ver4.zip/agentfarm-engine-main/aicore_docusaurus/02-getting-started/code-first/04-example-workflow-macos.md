---
sidebar_position: 5
title: "Example 2 — A workflow solution (macOS)"
description: The macOS variant of Example 2 — the same two-agent workflow solution, built in zsh or bash, in local mode, with no server.
---

# Example 2 — A workflow solution (macOS)

This is the macOS variant of [Example 2 (Windows)](./03-example-workflow-windows.md).
The steps and their meaning are identical; only the shell differs. The Windows
page carries the fuller explanation of each step.

:::note Start in a new, empty folder
Create a new, empty folder for this exercise and work inside it. Teardown is
deleting this one folder and its workspace.
:::

## 1. Create the folder and activate the SDK environment

```bash
mkdir -p ~/work/example2
cd ~/work/example2
source ~/aicore-setup/.venv/bin/activate
aicore --version
```

The SDK and model provider are installed from [Install the SDK](./01-install.md).

## 2. Turn on local mode

```bash
aicore local on
```

Everything now resolves to the current folder: a SQLite database at
`.iof/state.db`, agent homes under `.iof/workspaces/`, and your files as the
source of truth.

## 3. Create the workspace

```bash
aicore workspace create pharma_comm \
  --name "Pharma Commercial" \
  --description "Brand performance and payer access"
aicore workspace show pharma_comm
```

Three zeroes for workflows, agents, and skills are correct. `workspace create`
also selects the workspace.

## 4. Scaffold the solution repository

```bash
aicore new-solution pharma_comm_sol --no-example
```

Scaffolds into the current folder. Do not change into the package folder
afterwards.

## 5. Create the database and install the pack

```bash
aicore init
pip install -e ".[dev]"
pytest -q
aicore list-workflows
```

An empty workflow list is correct.

## 6. Create two agents

```bash
aicore new-agent brand_analyst    --name "Priya"
aicore new-agent medical_reviewer --name "Dr Chen"
```

Each agent gets its own `output_protocol` skill, which is required.

## 7. Attach the repository to the workspace

```bash
aicore workspace attach pharma_comm --url ~/work/example2
aicore workspace show   pharma_comm
```

`attach` binds this repository to the workspace, making it the target for
promoting an edit made in AI Core Harness Studio; a workspace without one cannot
accept a promotion. `show` reports the workspace record and its membership.

Your two agents are resolved from the installed solution whenever something asks
for them, so nothing publishes them into the workspace. Step 11 confirms that by
talking to one. The platform's own agents — `cora`, `cora_build`, `project_lead`,
`queryngine`, `meta_agent` and `play_operator` — are available alongside them, including the orchestrator that
drives the workflow.

## 8. Create the tool

```bash
aicore new-tool nbrx_trend \
  --description "Compute NBRx and TRx trend by territory from a claims extract"
pip install -e .
aicore cli-hub check
```

The reinstall is required — the console script is generated at install time. A
working version of the tool is in [The tool and its data](./05-example-workflow-tool.md).

:::note A `vectorfs` gap here is expected, and nothing in this example needs it
`cli-hub check` reports every declared tool, including ones the SDK declares
but your machine has not built, so you will usually see `vectorfs … gap` and
`Gaps remain`. That is a report, not a failure: `vectorfs` builds from source
only when you opt in with `aicore cli-hub install --allow-build`, and no step
in this example uses it. The line to check is `nbrx_trend`, which must read
`ready`.
:::

## 9. Pair the tool with a skill

```bash
aicore new-skill nbrx_usage --tool nbrx_trend --role brand_analyst
```

## 10. Create a shared skill and assign it

```bash
aicore new-skill promotional_compliance
aicore assign-skill promotional_compliance --role brand_analyst
aicore assign-skill promotional_compliance --role medical_reviewer
```

## 11. Talk to an agent

```bash
aicore agent-chat --role brand_analyst --message "Who are you and what skills do you have?"
```

The command is standalone by default: it talks to the agent's own workspace and
looks up no run, so it needs no server.

## 12. Create, lint, and dry-run the workflow

```bash
aicore new-workflow brand_performance \
  --steps "analyze:brand_analyst,review:medical_reviewer"
aicore lint-workflow brand_performance
aicore run brand_performance \
  --goal "Which territories show NBRx decline against a payer access change this quarter?" \
  --dry-run
```

:::warning A workflow is discoverable only after `pip install -e .`
`lint-workflow` reads your files directly; `run` resolves the workflow through
the installed pack. If `run` reports the workflow does not exist, run
`pip install -e .` and try again.
:::

## 13. Write the content and run it

Fill the tool, the step instructions, and the catalog — see
[The tool and its data](./05-example-workflow-tool.md). The sample extract goes
in `metadata/data/` beside the catalog. Then:

```bash
aicore run brand_performance --goal "Which territories show NBRx decline against a payer access change this quarter?"
```

## 14. Ask the Core Assistant what happened

The run is recorded in full. Rather than reading that record yourself, ask the
assistant that ships with the platform:

```bash
aicore status
aicore agent-chat --role cora \
  --message "Explain the last brand_performance run: did every step complete, what did each one produce, and was anything retried?"
```

`status` lists recent runs with their identifiers and outcomes. The second
command puts the question to `cora`, the Core Assistant, which reads the run's
recorded evidence — the step timeline, the artifact gates, retries and token
usage — and answers from it. It is **evidence first**, saying what it checked
where the record cannot answer, and **read-only**: it never edits your files.

The conversation persists, so follow-ups need no run identifier:

```bash
aicore agent-chat --role cora \
  --message "Why did that step retry, and what would you change in the workflow to avoid it?"
```

:::note Two paths, and the caller picks
`agent-chat` never chooses a context for you. By default it is **standalone**:
it spawns the runtime against the agent's own workspace, resolved from the
installed solution, with no server and no run lookup. The run started at step 13
is irrelevant to it, and so is any run left behind by an earlier example.

`--run-id <id>` is the other path: it posts into that run's session through the
engine, and therefore needs `aicore serve`. An unreachable engine is an error
there, never a silent fall back to a fresh local conversation.
:::

For the raw record instead of a conversation: `aicore forensics explain <run_id>`.

## 15. Review what the environment resolves

```bash
aicore list-workflows --workspace pharma_comm
```

`brand_performance` is listed, because a workflow is resolved from the installed
solution. The tool, the two skills and the workflow added during this example
all reached the run the same way, with no publishing step between the repository
and the environment.

## Teardown

```bash
pip uninstall -y pharma-comm-sol    # the pack registers in the shared environment, not this folder
aicore workspace delete pharma_comm --yes --force
rm -rf ~/work/example2
```

**Next:** [The tool and its data](./05-example-workflow-tool.md), then
[Example 3 — an MCP integration](./06-example-mcp-server.md).
