---
sidebar_position: 3
title: "Example 1 — Your first agent"
description: The smallest possible solution — one agent, one skill, and a direct conversation. Establishes the core loop before the larger examples add tools, workflows and swarms.
---

# Example 1 — Your first agent

The smallest solution AI Core Harness can run is a single agent with a single skill.
This example creates one, gives it one instruction of judgment, and holds a
short conversation with it. It introduces the core loop — an agent, a skill,
and the model connection — with no tool, no workflow and no server. The larger
examples build on it.

Allow about ten minutes.

:::note Start in a new, empty folder
Create a new, empty folder for this exercise and work inside it. Nothing here
conflicts with other work, and teardown is deleting this one folder and its
workspace.
:::

## 1. Create the folder and activate the SDK environment

```bash
mkdir -p ~/work/first-agent           # Windows: mkdir C:\work\first-agent
cd ~/work/first-agent                 # Windows: cd C:\work\first-agent
source ~/aicore-setup/.venv/bin/activate   # Windows: %USERPROFILE%\aicore-setup\.venv\Scripts\activate
```

The SDK and model provider are installed once, as described in
[Install the SDK](./01-install.md). Confirm the CLI resolves:

```bash
aicore --version
```

## 2. Set up a local workspace and solution

```bash
aicore local on
aicore workspace create first_demo --name "First Agent Demo"
aicore new-solution first_demo_sol --no-example
aicore init
pip install -e ".[dev]"
```

`local on` directs everything to the current folder — a database file under
`.iof`, no server. `workspace create` also selects the workspace, so the
commands that follow need no `--workspace` flag. `new-solution` scaffolds the
repository in place; `init` creates the database; the editable install puts the
solution on the path.

## 3. Create the agent

```bash
aicore new-agent assistant --name "Ada"
```

This creates the agent's workspace, including its identity file `SOUL.md` and
its required output-contract skill. The identity file is where the agent's
responsibility is defined; for this example the default is sufficient.

## 4. Give the agent a skill

A skill is the judgment an agent applies, written as markdown. Create one:

```bash
aicore new-skill executive_summary --role assistant
```

`--role assistant` places the skill in that agent's workspace, so the agent
carries it. Open `first_demo_sol/agents/assistant/workspace/skills/executive_summary/SKILL.md`
and replace the scaffold with a short instruction, for example:

```markdown
---
name: executive_summary
description: Summarise a body of text into a three-point executive summary.
always: true
---

When asked to summarise, produce exactly three bullet points. Each point states
one conclusion in one sentence. Lead with the most consequential point. Do not
add a preamble or a closing line.
```

`always: true` is what makes this example work. A skill reaches the agent in
one of two ways:

| Frontmatter | What the agent receives |
|---|---|
| `always: true` | The skill's full text, in every request, before the agent answers. |
| omitted (the default) | Only the name and `description`, plus the file path. The agent must decide the skill applies and read the file before answering. |

A formatting rule must apply to every answer, so it belongs in the first
group. Without `always: true` the agent is told a summarising skill exists,
answers the question directly, and the three-bullet rule never takes effect —
the skill is loaded correctly and never consulted. Leave `always` off
for skills that apply to specific tasks, where loading the text every time
would be wasted context.

:::note If your editor flags the underscore in `name:`
Some editors validate any file called `SKILL.md` against an unrelated skill
format that requires hyphenated names. AI Core Harness applies no such rule — skill
names use underscores, and the directory name is what identifies the skill.
The warning is the editor's and changes nothing about how the skill loads.
See [Skill format](../../07-reference/04-skill-format.md#naming).
:::

The assignment takes effect on next use: the agent is built from the installed
solution the first time something asks for it, which is the next step.

## 5. Talk to the agent

```bash
aicore agent-chat --role assistant \
  --message "Summarise this: the Q3 review found rising demand in two regions, a supplier delay affecting one product line, and stable margins overall."
```

Ada answers as herself, applying the skill: three points, most consequential
first, no preamble. This confirms the agent, its skill and the model connection
in one command — with no workflow and no server.

**`agent-chat` is standalone by default.** It spawns the runtime against the
agent's own workspace — no server, no port, no run lookup — so an engine that is
not listening and any run left behind by earlier work are both irrelevant. To
talk to an agent *inside* a run instead, name the run with `--run-id`; that path
needs `aicore serve`, and an unreachable engine is reported as an error rather
than quietly becoming a fresh local conversation.

## What you have built

A complete, if minimal, solution: one agent whose behaviour you control through
a skill. Everything larger is composition of these same parts —

- [Example 2 — a workflow solution](./03-example-workflow-windows.md) adds a
  second agent, a deterministic tool, and a two-step pipeline;
- [Example 3 — an MCP integration](./06-example-mcp-server.md) connects an
  agent to externally hosted tools;
- [Example 4 — a swarm](./07-example-swarm.md) delegates a goal to a
  meta-agent that decides the route at run time.

## Teardown

```bash
pip uninstall -y first-demo-sol    # the pack registers in the shared environment, not this folder
aicore workspace delete first_demo --yes --force
rm -rf ~/work/first-agent             # Windows: rmdir /s /q C:\work\first-agent
```

**Next:** [Example 2 — a workflow solution (Windows)](./03-example-workflow-windows.md).
