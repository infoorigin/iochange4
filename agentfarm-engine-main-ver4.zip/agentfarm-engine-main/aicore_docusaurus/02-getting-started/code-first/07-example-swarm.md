---
sidebar_position: 8
title: "Example 4 — A swarm"
description: Stand up a local external agent, register it, build a meta-agent, and run a swarm that consults the external agent under a goal.
---

# Example 4 — A swarm

A **swarm** is the goal-oriented counterpart of a workflow. Instead of a fixed
pipeline, a meta-agent is given a goal, a roster of external agents and tools,
and controls; it decides the route at run time. This example stands up a small
external agent, registers it, and runs a swarm whose meta-agent consults it.

:::note Start in a new, empty folder
Create a new, empty folder for this exercise and work inside it. It is
independent of Examples 1, 2 and 3.
:::

## 1. Set up the folder

```bash
mkdir -p ~/work/example4
cd ~/work/example4
source ~/aicore-setup/.venv/bin/activate   # Windows: %USERPROFILE%\aicore-setup\.venv\Scripts\activate
aicore local on
aicore workspace create swarm_demo --name "Swarm Demo"
aicore new-solution swarm_demo_sol --no-example
aicore init
pip install -e ".[dev]"
aicore new-agent market_lead --name "Morgan"
```

`market_lead` is the meta-agent that will drive the swarm.

## 2. Write the external agent

The external agent answers over the Agent2Agent (A2A) protocol — the same
interface AI Core Harness's own agents expose. This minimal version echoes each
question. Install its dependencies and save the file as `echo_agent.py`:

```bash
pip install fastapi uvicorn
```

```python title="echo_agent.py"
import os
from uuid import uuid4
from fastapi import FastAPI, Request

ROLE = "lab-echo"
app = FastAPI()

@app.get(f"/a2a/{ROLE}/.well-known/agent-card.json")
async def card(request: Request):
    base = str(request.base_url).rstrip("/")
    return {
        "protocolVersion": "1.0",
        "name": "Lab Echo Agent",
        "description": "Answers any market question with a stub envelope.",
        "version": "1.0.0",
        "capabilities": {"streaming": False},
        "supportedInterfaces": [
            {"url": f"{base}/a2a/{ROLE}", "protocolBinding": "JSONRPC",
             "protocolVersion": "1.0"}],
        "skills": [{"id": "echo", "name": "Echo",
                    "description": "Echoes a question.",
                    "tags": ["lab"], "examples": ["What is the share of X?"]}],
    }

@app.post(f"/a2a/{ROLE}")
async def jsonrpc(request: Request):
    body = await request.json()
    if body.get("method") != "SendMessage":
        return {"jsonrpc": "2.0", "id": body.get("id"),
                "error": {"code": -32601, "message": "method not supported"}}
    message = (body.get("params") or {}).get("message") or {}
    text = " ".join(p.get("text", "") for p in message.get("parts") or []).strip()
    envelope = {"schema": "lab.echo.v1", "answer": f"echo: {text}"}
    task = {"id": f"task-{uuid4().hex[:12]}",
            "status": {"state": "TASK_STATE_COMPLETED"},
            "artifacts": [{"artifactId": f"art-{uuid4().hex[:8]}",
                           "name": "response", "parts": [{"data": envelope}]}]}
    return {"jsonrpc": "2.0", "id": body.get("id"), "result": {"task": task}}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8909)
```

Run it in a **second terminal** and leave it running:

```bash
python echo_agent.py
```

## 3. Register the external agent

In the first terminal, register the running agent for the workspace. Name the
workspace with `--workspace`: the external-agent registry is workspace-scoped,
and the swarm reads the registry of the workspace it runs in.

```bash
aicore a2a-add lab-echo http://127.0.0.1:8909/a2a/lab-echo \
  --description "Echo agent: answers any market question with a stub" \
  --tag lab \
  --example "What is the market share of X?" \
  --workspace swarm_demo
aicore a2a-list --workspace swarm_demo
```

`a2a-list` prints every registered agent and whether each referenced variable
resolves. The description and examples are what routing matches a question
against, so write them in the terms a question would use. An agent registered in
a different workspace is not visible to this swarm, and the meta-agent reports
that it cannot reach it.

## 4. Create the swarm

```bash
aicore new-swarm market_pulse --role market_lead --agents lab-echo
```

`--role` names the meta-agent; `--agents` is its roster — the external agents it
may consult. Omitting `--agents` grants every registered agent, so state the
roster explicitly.

## 5. Run the swarm

```bash
aicore run-swarm market_pulse \
  --goal "Ask the lab-echo agent what the market share of product X is, and report what it returns."
```

The meta-agent reads the roster, routes the question to `lab-echo`, receives the
echo envelope, and reports it. The external agent's terminal shows the incoming
request.

A swarm compiles to a single-step run, so it inherits the same retry,
forensics, and fail-closed deliverable gate as a workflow. The full model is in
[Swarms](../../03-building-solutions/07-swarms.md).

## Teardown

Stop the external agent in the second terminal, then:

```bash
pip uninstall -y swarm-demo-sol    # the pack registers in the shared environment, not this folder
aicore workspace delete swarm_demo --yes --force
rm -rf ~/work/example4
```

**Next:** [Building solutions](../../03-building-solutions/01-agents-and-skills.md)
for the reference treatment of each building block, or
[Troubleshooting](./08-troubleshooting.md).
