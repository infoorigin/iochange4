---
sidebar_position: 2
title: Install the SDK
description: Install the SDK from your package index, create the AI Core Harness home directory, configure a model provider, and confirm the installation.
---

# Install the SDK

This one-time setup applies to all four examples. It installs the SDK,
configures a model provider, and confirms the installation. It writes nothing
into a solution folder, so it is done once per machine.

## 1. Create an isolated environment

Create a working folder and a Python virtual environment:

```bash
mkdir ~/aicore-setup             # Windows: mkdir %USERPROFILE%\aicore-setup
cd ~/aicore-setup                # Windows: cd %USERPROFILE%\aicore-setup
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
```

:::important This is the only environment you create
The SDK is installed into this one virtual environment, and **every example
activates it** rather than creating its own. A Python environment holds the
installed packages, not the project files, so a second environment created in
an example folder is empty — `aicore` is not on its path, and the example's
first command fails with *command not found*.

Note the path to this folder. Each example begins by activating it:

```bash
source ~/aicore-setup/.venv/bin/activate     # Windows: %USERPROFILE%\aicore-setup\.venv\Scripts\activate
```
:::

## 2. Install from your package index

Point `pip` at the package index — the devops team sets up the index URL — then install the two SDK
distributions:

```bash
pip install --upgrade \
    --index-url https://your-index.example.com/simple \
    ai-core-harness-engine ai-core-harness-skills
aicore --version
```

Use `--upgrade` on every reinstall. Without it, `pip install <name>` performs no
action when any version is already present: it reports *Requirement already
satisfied* and exits successfully.

Both distributions are required. The engine provides the runtime and the CLI;
the skills distribution provides the shared skills that agents carry by default.
The engine does not install the skills distribution on its own.

## 3. Create the AI Core Harness home directory

```bash
aicore init-home
```

This writes the per-user configuration into the AI Core Harness home directory, a
per-user location named `.iobot` in your home directory. It creates
`config.json` (where the model provider is configured), an environment file, and
a `config.README.md`. It never overwrites an existing file, so running it twice
is safe.

## 4. Configure a model provider

Open `config.json` in the AI Core Harness home directory and set your model and API key:

- Windows: `%USERPROFILE%\.iobot\config.json`
- macOS and Linux: `~/.iobot/config.json`

First-time setup is the only place this is done. Nothing that calls a model
works until it is set.

## 5. Confirm the installation

```bash
aicore --version
aicore config-check
```

`config-check` reports the model provider it resolves and the file each setting
came from. When it reports the provider and key you configured, the setup is
complete.

**Next:** [Example 1 — your first agent](./02-example-first-agent.md).
