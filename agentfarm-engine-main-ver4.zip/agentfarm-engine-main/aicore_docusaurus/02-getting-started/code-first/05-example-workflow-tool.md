---
sidebar_position: 6
title: "Example 2 — The tool and its data"
description: Working versions of the tool, catalog, sample extract, and tests that Example 2 leaves as skeletons — with the design rules a deterministic tool follows.
---

# Example 2 — The tool and its data

Example 2 scaffolds three files as skeletons. This page provides working
versions, with the sample extract and tests, and the rules a deterministic tool
follows. Download the four files:

- [`nbrx_trend.py`](./files/nbrx_trend.py) — the tool
- [`catalog.yaml`](./files/catalog.yaml) — the data catalog the agent reads
- [`claims_q3.csv`](./files/claims_q3.csv) — the sample extract
- [`test_nbrx_trend.py`](./files/test_nbrx_trend.py) — the tests

Place them under the repository root created in Example 2:

```text
example2/
├── pyproject.toml
├── tests/
│   └── test_nbrx_trend.py
└── pharma_comm_sol/
    ├── tools/
    │   └── nbrx_trend.py                 # overwrite the scaffold
    └── workflows/
        └── brand_performance/
            └── metadata/
                ├── catalog.yaml          # overwrite the scaffold
                └── data/                 # create this folder
                    └── claims_q3.csv
```

The `metadata/data/` folder is not scaffolded — `new-workflow` writes
`catalog.yaml` and nothing beside it. Create it before copying in the extract.

:::warning The extract belongs under the workflow's `metadata/`, not the repo root
`{{metadata_dir}}` resolves to the workflow's own `metadata/`, so a catalog
`source:` of `data/claims_q3.csv` is read from there. A copy at the repository
root is not found at run time and is not shipped in the package.
:::

No reinstall is needed for these three — the tool's entry point already points
at the script, and an editable install reads the rest from your files.

## Why the computation is a tool, not a skill

An agent asked to compute a percentage change returns an answer that is
plausible and occasionally wrong, with nothing in the output to distinguish the
two. A script returns the same answer every time and is tested without a model.

Anything whose correct behaviour can be written as code should be a script. What
remains for the agent — which territories matter, what a decline means against a
change in payer access, what to recommend — is judgment, and that is what the
paired skill carries.

## What the tool computes

`summarize()` compares the latest month against the one before it, per
territory: NBRx and TRx percent change, and a `declining` flag at a
caller-settable threshold. Three rules keep the output honest, and each is
visible in the result rather than hidden inside it:

- **A territory missing one of the two months is dropped, not interpolated.**
  Half a pair is not a trend.
- **A prior value of zero returns null, not infinite growth.** Undefined is a
  real answer; infinity reads as a finding.
- **The threshold is included in the output**, so a reader knows what
  "declining" meant.

The tool writes machine-readable JSON to standard output and nothing else;
failures go to standard error with a non-zero exit. An agent runs the tool and
parses one stream, reading problems from the other.

## Run it

```bash
iof-pharma_comm_sol-nbrx_trend pharma_comm_sol/workflows/brand_performance/metadata/data/claims_q3.csv
```

```json title="expected (abridged)"
{
  "prior_month": "2026-06",
  "latest_month": "2026-07",
  "decline_threshold_pct": -5.0,
  "territory_count": 6,
  "declining": ["T-102 Mid-Atlantic", "T-104 Great Lakes",
                "T-105 Texas", "T-107 Mountain"]
}
```

The full result also carries a `territories` array, one entry per trendable
territory, with prior and latest values and the percent change.

## The sample data

`claims_q3.csv` holds seven territories across three months, with a payer access
tier per territory-month. It is shaped so the obvious reading is not the correct
one: several territories decline sharply, and each of those also changed access
tier — the analysis the workflow exists to perform.

## The catalog

`catalog.yaml` is the agent's only source of entity and column names; it does
not guess them. Put real figures in each `description` — cardinality, ranges,
totals, distributions. Those are what let an agent choose the right entity
without spending a turn discovering it.

```yaml
    dimensions:
      - {name: territory,         description: "sales territory, `T-1NN Region`; 7 distinct"}
      - {name: month,             description: "YYYY-MM; 2026-05, 2026-06, 2026-07"}
      - {name: nbrx,              description: "new prescriptions that month; 142..544"}
      - {name: trx,               description: "total prescriptions that month; 1301..3971"}
      - {name: payer_access_tier, description: "preferred | non-preferred | step-therapy, as of that month"}
```

Do not add example queries or from-clauses to a catalog. They bias the shape
of every answer the agent gives.

## The incomplete territory is deliberate

One territory in the extract, T-106 Pacific, has no `2026-06` row. The
catalog states the gap rather than leaving it to be discovered:

```yaml
  - name: claims_q3
    source_path: "data/claims_q3.csv"
    description: >
      Monthly prescription counts per sales territory, 2026-05..2026-07,
      20 rows across 7 territories. One row per territory-month. T-106 Pacific
      has NO 2026-06 row - the extract is incomplete there, so it cannot be
      trended and must be reported as a gap rather than interpolated.
```

The tool drops that territory and reports `territory_count: 6`.

This is the check on whether the analysis is grounded. An agent that reports
six trendable territories and names the gap is reading the data. An agent
that reports seven has invented one — caught on a dataset small enough to
verify by eye, which is what a fixture is for.

## The tests

`test_nbrx_trend.py` covers the computation and the three rules above, and needs
no model. Run it with `pytest -q` from the repository root.

**Next:** [Example 3 — an MCP integration](./06-example-mcp-server.md).
