---
sidebar_position: 9
title: Troubleshooting
description: Conditions a developer meets while following the code-first examples, each with the command that resolves it.
---

# Troubleshooting

Each condition below fails without an error that names its cause. They are
ordered by how often they arise.

## The install reported success but nothing changed

Without `--upgrade`, `pip install <name>` does nothing when any version is
already installed. It reports *Requirement already satisfied* and exits
successfully. Reinstall with `--upgrade`:

```bash
pip install --upgrade --index-url https://your-index.example.com/simple \
    ai-core-harness-engine ai-core-harness-skills
```

To see what the index offers against what is installed:

```bash
pip index versions ai-core-harness-engine
```

## `run` reports the workflow does not exist

A workflow is resolved through the installed pack, not from files. After
`new-workflow`, install the pack before running:

```bash
pip install -e .
aicore run <workflow> --goal "..." --dry-run
```

`lint-workflow` reads files directly and works without the install, which is why
lint can pass while `run` cannot find the workflow.

## A new tool is not found

The console script for a tool is generated at install time. After `new-tool`,
reinstall:

```bash
pip install -e .
aicore cli-hub check
```

`cli-hub check` reports a declared tool as ready only when its binary is on the
path. A tool missing from `tools.yaml` is not checked, so the failure surfaces
later as *command not found* inside a step. `new-tool` writes the declaration;
hand-written tools are where this is missed.

## `workspace show` lists no `data_query` or `guardrails`

Two causes, in order:

**The skills distribution is not installed.** It is separate from the engine and
is not pulled in automatically:

```bash
pip show ai-core-harness-skills
```

**A copy prepared earlier on this machine is being used.** A shared skill is
assigned in the agent's `skills.yaml` and resolved from the installed skills
distribution when the agent is built. Where an agent was built before the
distribution was installed, discard that copy so the next run re-reads what is
installed:

```bash
aicore setup-agents --force
```

## `agent-chat` cannot reach the service

`agent-chat` only contacts a service when you name a run with `--run-id`, and an
unreachable engine is reported there rather than silently ignored. Start the
engine, or drop the flag: without it the command is standalone and needs no
service at all.

```bash
aicore agent-chat --role <agent> --message "..."
```

## `Could not find a version that satisfies the requirement upgrade`

`pip install upgrade <name>` makes pip look for a package called `upgrade`.
The option is `--upgrade`, with two hyphens.

## AI Core Harness Studio shows a skill but not the tool it uses

Expected. CLI tools are declared in `tools.yaml` and resolved on `PATH`;
Studio has no filesystem and cannot see either. The skill that teaches an
agent to run the tool does appear. `aicore cli-hub check` is the tool-side
view.

## `cli-hub check` reports a tool ready on a machine that lacks it

Only DECLARED tools are checked. A tool missing from `tools.yaml` is not
absent as far as the check is concerned, so it reports all-clear and the
failure surfaces later, inside a step, as `command not found`. `aicore
new-tool` writes the declaration; a hand-written tool is where this bites.
A typo in a step's `command:` reads the same way at run time;
`aicore forensics explain <run id>` classifies it as `command_not_found` and
says whether to install the tools package or correct the name.

## AI Core Harness Studio lists an agent but cannot open it

A database created by an earlier version is missing columns a later one
reads. Re-running the schema does not add them: the statements create tables
that already exist and change nothing.

In local mode the database holds nothing you authored — your files do — so
the quickest remedy is to discard it and recreate the workspace:

```bash
rm -rf .iof
aicore init
aicore workspace create pharma_comm --name "Pharma Commercial"
aicore workspace attach pharma_comm --url .
```

On a shared database, do not do this. Report the symptom to whoever operates
that database.

## The workspace exists but cannot be opened in AI Core Harness Studio

Access is closed by default; a workspace with no members does not appear in the
Studio's workspace list. Add a member:

```bash
aicore workspace create <code> --member you@yourcompany.com
```

`create` is create-or-update, so re-running it adds the member without changing
anything else.

**Next:** [Building solutions](../../03-building-solutions/01-agents-and-skills.md).
