"""iof-pharma_comm_sol-nbrx_trend — Compute NBRx and TRx trend by territory from a claims extract

A DETERMINISTIC TOOL, not an agent. Everything here runs the same way every
time and can be tested without a model. That is the entire reason it exists: an
agent asked to compute something returns an answer that is plausible and
occasionally wrong, with nothing to tell the two apart.

NOTHING HERE TELLS AN AGENT THIS EXISTS. A console script is on PATH for every
agent and known to none of them; the skill that says WHEN to run it and how to
read what it prints is a separate file, written by
`aicore new-skill nbrx_usage --tool nbrx_trend`. That skill deliberately
does not restate the flags — `--help` is current in a way a hand-copied list
never is.

THE CONTRACT IS WORTH KEEPING: the machine-readable result on stdout, anything
for a human on stderr, non-zero exit on failure. An agent runs this through
`exec` and parses stdout; a friendly sentence printed there is one more thing it
has to guess its way past, and a traceback there reads as data.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys

REQUIRED_COLUMNS = ("territory", "month", "nbrx", "trx")


def load_rows(fh) -> list[dict]:
    """Parse the claims extract, refusing anything that is not one.

    A missing column is raised here rather than defaulted, because a defaulted
    NBRx of zero reads downstream as a real collapse in prescriptions.
    """
    reader = csv.DictReader(fh)
    missing = [c for c in REQUIRED_COLUMNS if c not in (reader.fieldnames or [])]
    if missing:
        raise ValueError(f"missing column(s): {', '.join(missing)}")

    rows = []
    for lineno, raw in enumerate(reader, start=2):
        try:
            rows.append({
                "territory": (raw["territory"] or "").strip(),
                "month": (raw["month"] or "").strip(),
                "nbrx": float(raw["nbrx"]),
                "trx": float(raw["trx"]),
            })
        except (TypeError, ValueError) as exc:
            raise ValueError(f"row {lineno}: {exc}") from exc
    return rows


def summarize(rows: list[dict], decline_threshold: float = -5.0) -> dict:
    """Per-territory NBRx/TRx change, latest month against the one before it.

    Kept out of `main` so it can be tested directly — no argv, no process, no
    stdout. That is most of the value of writing this as a tool at all.

    `decline_threshold` is a percent, negative. A territory at or below it is
    flagged; the caller gets both the flag and the number behind it, so a
    judgement call stays visible instead of collapsing into a boolean.
    """
    months = sorted({r["month"] for r in rows})
    if len(months) < 2:
        return {"months": months, "territories": [], "declining": [],
                "note": "need at least two months to compute a trend"}

    prior, latest = months[-2], months[-1]
    by_territory: dict[str, dict] = {}
    for r in rows:
        if r["month"] not in (prior, latest):
            continue
        slot = by_territory.setdefault(r["territory"], {})
        slot[r["month"]] = r

    def pct(now: float, before: float) -> float | None:
        if before == 0:
            return None                      # undefined, not "infinite growth"
        return round((now - before) / before * 100, 1)

    territories = []
    for name in sorted(by_territory):
        pair = by_territory[name]
        if prior not in pair or latest not in pair:
            continue                         # incomplete pair cannot trend
        nbrx_change = pct(pair[latest]["nbrx"], pair[prior]["nbrx"])
        territories.append({
            "territory": name,
            "nbrx_prior": pair[prior]["nbrx"],
            "nbrx_latest": pair[latest]["nbrx"],
            "nbrx_pct_change": nbrx_change,
            "trx_prior": pair[prior]["trx"],
            "trx_latest": pair[latest]["trx"],
            "trx_pct_change": pct(pair[latest]["trx"], pair[prior]["trx"]),
            "declining": nbrx_change is not None and nbrx_change <= decline_threshold,
        })

    return {
        "prior_month": prior,
        "latest_month": latest,
        "decline_threshold_pct": decline_threshold,
        "territory_count": len(territories),
        "territories": territories,
        "declining": [t["territory"] for t in territories if t["declining"]],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="iof-pharma_comm_sol-nbrx_trend",
        description="Compute NBRx and TRx trend by territory from a claims extract")
    parser.add_argument(
        "input", nargs="?", default="-",
        help="claims CSV with columns territory,month,nbrx,trx — or `-` for stdin")
    parser.add_argument(
        "--decline-threshold", type=float, default=-5.0,
        help="percent NBRx change at or below which a territory is flagged (default -5.0)")
    parser.add_argument(
        "--indent", type=int, default=2,
        help="pretty-print width for the JSON result (0 for one line)")
    args = parser.parse_args(argv)

    try:
        if args.input == "-":
            rows = load_rows(sys.stdin)
        else:
            with open(args.input, encoding="utf-8", newline="") as fh:
                rows = load_rows(fh)
    except (OSError, ValueError) as exc:
        # stderr and a non-zero exit, so the caller sees a FAILURE rather than
        # parsing a traceback off stdout as though it were the result.
        print(f"iof-pharma_comm_sol-nbrx_trend: cannot read {args.input}: {exc}", file=sys.stderr)
        return 1

    json.dump(summarize(rows, args.decline_threshold), sys.stdout, indent=args.indent or None)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":   # runnable before the console script exists
    sys.exit(main())
