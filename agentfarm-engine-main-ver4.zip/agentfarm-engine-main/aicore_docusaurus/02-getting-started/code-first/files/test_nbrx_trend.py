"""The tool computes; these prove what it computes.

No model, no subprocess, no argv — `summarize` takes rows and returns a dict,
so the arithmetic an agent will quote in a board deck is pinned here.
"""
import io

import pytest

from pharma_comm_sol.tools.nbrx_trend import load_rows, summarize

ROWS = [
    {"territory": "T-1", "month": "2026-06", "nbrx": 100.0, "trx": 800.0},
    {"territory": "T-1", "month": "2026-07", "nbrx": 80.0, "trx": 760.0},
    {"territory": "T-2", "month": "2026-06", "nbrx": 200.0, "trx": 900.0},
    {"territory": "T-2", "month": "2026-07", "nbrx": 210.0, "trx": 930.0},
]


def test_declining_territory_is_flagged_with_the_number_behind_it():
    out = summarize(ROWS)
    t1 = next(t for t in out["territories"] if t["territory"] == "T-1")
    assert t1["nbrx_pct_change"] == -20.0
    assert t1["declining"] is True
    assert out["declining"] == ["T-1"]


def test_growth_is_not_flagged():
    t2 = next(t for t in summarize(ROWS)["territories"] if t["territory"] == "T-2")
    assert t2["nbrx_pct_change"] == 5.0
    assert t2["declining"] is False


def test_threshold_is_the_caller_s_judgement_call():
    assert summarize(ROWS, decline_threshold=-25.0)["declining"] == []


def test_latest_two_months_win_when_there_are_more():
    rows = [{"territory": "T-1", "month": m, "nbrx": n, "trx": 0.0}
            for m, n in (("2026-05", 999.0), ("2026-06", 100.0), ("2026-07", 80.0))]
    out = summarize(rows)
    assert (out["prior_month"], out["latest_month"]) == ("2026-06", "2026-07")
    assert out["territories"][0]["nbrx_pct_change"] == -20.0


def test_a_territory_missing_a_month_is_dropped_not_trended():
    """T-106 Pacific in the shipped extract. Half a pair is not a trend."""
    rows = ROWS + [{"territory": "T-3", "month": "2026-07", "nbrx": 50.0, "trx": 100.0}]
    assert "T-3" not in [t["territory"] for t in summarize(rows)["territories"]]


def test_zero_prior_is_undefined_rather_than_infinite_growth():
    rows = [{"territory": "T-4", "month": m, "nbrx": n, "trx": 1.0}
            for m, n in (("2026-06", 0.0), ("2026-07", 40.0))]
    t4 = summarize(rows)["territories"][0]
    assert t4["nbrx_pct_change"] is None
    assert t4["declining"] is False


def test_one_month_cannot_trend():
    out = summarize([ROWS[0]])
    assert out["territories"] == []
    assert "two months" in out["note"]


def test_a_missing_column_is_refused_not_defaulted():
    """A defaulted NBRx of zero reads downstream as a real collapse."""
    with pytest.raises(ValueError, match="missing column"):
        load_rows(io.StringIO("territory,month,trx\nT-1,2026-07,800\n"))


def test_a_junk_value_names_its_row():
    with pytest.raises(ValueError, match="row 2"):
        load_rows(io.StringIO("territory,month,nbrx,trx\nT-1,2026-07,n/a,800\n"))
