---
sidebar_position: 7
title: "Example 3 — An MCP integration"
description: Build a local Model Context Protocol server, declare it to AI Core Harness, pair it with a skill, and have an agent call its tools.
---

# Example 3 — An MCP integration

A Model Context Protocol (MCP) server exposes tools that an agent can call. AI
Core Harness includes a complete MCP client: declare a server, and the runtime connects
it and registers its tools automatically. This example builds a local MCP
server, declares it, pairs it with a skill, and has an agent call its tools.

:::note Start in a new, empty folder
Create a new, empty folder for this exercise and work inside it. It is
independent of Examples 1 and 2.
:::

## 1. Set up the folder

```bash
mkdir -p ~/work/example3
cd ~/work/example3
source ~/aicore-setup/.venv/bin/activate   # Windows: %USERPROFILE%\aicore-setup\.venv\Scripts\activate
aicore local on
aicore workspace create mcp_demo --name "MCP Demo"
aicore new-solution mcp_demo_sol --no-example
aicore init
pip install -e ".[dev]"
aicore new-agent assistant --name "Ada"
```

## 2. Write the MCP server

The server exposes two tools. Install the MCP library and save the file as
`mcp_server.py` in the folder:

```bash
pip install mcp
```

```python title="mcp_server.py"
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("lab")

@mcp.tool()
def add_numbers(a: float, b: float) -> str:
    """Add two numbers and return the sum."""
    return str(a + b)

@mcp.tool()
def word_count(text: str) -> str:
    """Count the words in a text."""
    return str(len(text.split()))

if __name__ == "__main__":
    mcp.run()          # stdio transport
```

The runtime launches this as a subprocess and speaks the protocol over standard
input and output. No network port is involved.

## 3. Declare the server

Declare the server so the runtime launches it. Use the absolute path to
`mcp_server.py`:

```bash
aicore new-mcp-server lab \
  --command python \
  --args "/absolute/path/to/mcp_server.py"
```

On Windows, use the full path with backslashes, for example
`C:\work\example3\mcp_server.py`.

:::tip Give `--command` the full path to your virtual environment's Python
`--command python` is resolved through `PATH` at the moment the run starts, by
whatever process starts it. A terminal where the environment is not activated
resolves a different Python — on Windows often the Microsoft Store stub — which
does not have the `mcp` library installed. The server then fails to start, the
run continues with none of its tools registered, and the agent reports that it
could not find them.

Point at the interpreter directly to remove the ambiguity:

```bash
aicore new-mcp-server lab \
  --command ~/aicore-setup/.venv/bin/python \
  --args "/absolute/path/to/mcp_server.py"
```

On Windows: `--command %USERPROFILE%\aicore-setup\.venv\Scripts\python.exe`.
:::

The command writes one entry to the solution's `mcp.yaml`. The server is
connected when a run starts: the runtime launches it and registers each of its
tools under the name `mcp_<server>_<tool>` — here `mcp_lab_add_numbers` and
`mcp_lab_word_count`.

## 4. Pair the server with a skill

Every declared server connects for every agent in scope. A skill tells the agent
*when* to use its tools:

```bash
aicore new-skill lab_usage --mcp-server lab --role assistant
```

`--mcp-server` is refused if no tier declares the named server, so a skill can
never point at a server that does not exist.

## 5. Call the tools from a run

MCP servers are connected while a run executes, so exercise the tools with a
short workflow. Create a one-step workflow whose agent is the assistant:

```bash
aicore new-workflow lab_check --steps "compute:assistant"
```

Open `mcp_demo_sol/workflows/lab_check/steps/compute.md` and replace the
scaffold with an instruction that uses the tools:

```markdown
# Use the lab tools

Goal: {{goal}}

Print one line of text before every tool call. Call `mcp_lab_add_numbers` with
21 and 21, then `mcp_lab_word_count` on "the quick brown fox". Write
`{{output_dir}}/compute.md` with each tool's return value.

STATUS: done
OUTPUT: the two return values.
```

Install the solution so the workflow is discoverable, then run it:

```bash
pip install -e .
aicore run lab_check --goal "Exercise the lab tools."
```

The run launches the MCP server, registers `mcp_lab_add_numbers` and
`mcp_lab_word_count`, and the agent calls them rather than computing by hand. The
result file records:

```text title="compute.md (abridged)"
mcp_lab_add_numbers(21, 21) returned: 42.0
mcp_lab_word_count("the quick brown fox") returned: 4
```

Declared servers are also connected for `aicore agent-chat`, so the tools can be
exercised in a chat without starting a run:

```bash
aicore agent-chat --role assistant --message "Add 21 and 21 using your tools."
```

The command is standalone by default: it talks to the agent's own workspace and
looks up no run, so it needs no server. Its MCP tools come from the declaration
merged into that workspace's config.

## Declaration tiers

A server can be declared at three tiers; the highest present wins by server
name:

| Tier | Command | Scope |
|---|---|---|
| Solution | `aicore new-mcp-server` | every workspace running the solution |
| Machine | `aicore mcp-add <name> ...` | every workspace on the machine |
| Workspace | `aicore mcp-add <name> ... --workspace <code>` | that workspace only |

Write secrets in headers or environment values as `${VAR}` references. The value
resolves from the environment at load time and never sits in the declaration. A
server whose variable is unset is dropped, with a warning naming the variable.
Declaring one also writes a commented placeholder for each referenced variable
into the pack's `.env.example` and into the workspace's own `.env`, and prints
both paths: see
[MCP tools — where the value goes](../../03-building-solutions/04-mcp-tools.md#where-the-value-goes).

The full model is in [MCP tools](../../03-building-solutions/04-mcp-tools.md).

## Teardown

```bash
pip uninstall -y mcp-demo-sol    # the pack registers in the shared environment, not this folder
aicore workspace delete mcp_demo --yes --force
rm -rf ~/work/example3
```

**Next:** [Example 4 — a swarm](./07-example-swarm.md).
