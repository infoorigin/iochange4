---
sidebar_position: 1
title: Overview
description: The code-first track builds four complete solutions in order of increasing scope — a first agent, a workflow, an MCP integration, and a swarm — each in its own empty folder.
---

# The code-first track

This track builds four complete solutions, in order of increasing scope. Each
is self-contained and runs on a local database with no server.

| Example | What it builds | Introduces |
|---|---|---|
| [1 — Your first agent](./02-example-first-agent.md) | One agent with one skill, answering directly | Agents, skills, the model connection |
| 2 — A workflow solution, for [Windows](./03-example-workflow-windows.md) or [macOS](./04-example-workflow-macos.md), with [its tool and data](./05-example-workflow-tool.md) | Two agents, a deterministic tool, a shared skill and a two-step workflow that analyses a claims extract | Tools, workflows, the tenant catalog |
| [3 — An MCP integration](./06-example-mcp-server.md) | A local Model Context Protocol server whose tools an agent calls | Declaring an MCP server, pairing it with a skill |
| [4 — A swarm](./07-example-swarm.md) | A meta-agent that consults an external agent under a goal | External agents, swarms, goal-oriented routing |

Example 1 takes about ten minutes; the others about thirty each. Begin with
Example 1 even if your target is a workflow or a swarm — it establishes the
agent-and-skill core that the later examples compose.

Work through them in sequence. Each example assumes the SDK is installed and a
model provider is configured, as described in [Install the SDK](./01-install.md).

Every example begins in a **new, empty folder**, and each is removed by deleting
that folder, its workspace, and its installed pack.

:::note One thing does carry between examples: the installed pack
Each example runs `pip install -e .`, which registers its solution in the
shared SDK environment — and a Python environment is not scoped to a folder.
Deleting the folder leaves the registration behind, so everything the pack
declares stays visible: its workflows keep appearing in `list-workflows`, and
an agent or skill name reused by a later example collides:

```text
agent name collision: 'assistant' shipped by packs ['first_demo_sol', 'mcp_demo_sol']
  — first in registry order wins ('first_demo_sol')
```

Read that last clause carefully: the winner is decided by **registry order,
not by which example you are working in**, so the surviving agent may be the
earlier example's — carrying its skills rather than the ones you just
created. Run each example's teardown, which uninstalls the pack, and the
question does not arise.
:::

## Prerequisites

- Python 3.11 or later.
- Access to the package index, from which the SDK installs. The devops team sets up the pip index URL.
- A model provider and its API key.

The [Studio track](../studio/01-create-a-workspace.md) builds equivalent content
in the browser, without a repository or a local environment.

**Next:** [Install the SDK](./01-install.md).
