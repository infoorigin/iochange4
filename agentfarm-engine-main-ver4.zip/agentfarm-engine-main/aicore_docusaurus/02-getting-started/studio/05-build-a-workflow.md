---
sidebar_position: 5
title: Build a workflow
description: A short form — one agent, a few steps — validated by the engine before it is accepted.
---

# Build a workflow

Select **Workflows** in the **BUILD** group of the left rail, then **New workflow**.

An empty workspace reports *"No workflows yet."* The list shows every
workflow this workspace can run. One an installed solution provides carries
the SOURCE value **Built-in**; one saved here carries **Your draft**.

A **Built-in** workflow opens and can be edited — saving does not change the
solution's copy, it creates your own draft on top of it, and the page says so
(*"Saved as your draft"*).

## The form

Titled **New workflow** — *"Describe the work in plain words — the workflow
definition is generated for you and validated by the engine before it is
saved."* Two columns, **Cancel** / **Create & validate** top right.

Left column:

| Section | Field | What it is |
|---|---|---|
| **Basics** | **Workflow name** | the id. *"Lowercase letters, numbers and underscores."* |
| | **What should this workflow accomplish?** | the description |
| | **Which agent does the work?** | a single agent. The dropdown lists every agent in the workspace as `Name (role)`; the ones you built are suffixed **— created in Studio**. Helper: *"This agent does every step unless you hand one to somebody else. Any agent can join — including agents you just built."* |
| **Steps** | **Short title** and **What should the agent do?** per step | each step also carries a **Done by** selector, defaulting to the workflow's agent |

Each step past the first has a **Remove** link. **+ Add a step** sits under
the last one. A submission with an unnamed step is refused with **"Every step
needs a name."** — nothing entered elsewhere on the form is lost, and the form
additionally keeps an unsaved draft in the browser tab: reloading the page
restores it with a *"Restored your unsaved draft from this tab"* notice, and
the draft is cleared on a successful create.

Below the steps, **What each agent can use** scopes capabilities per agent:
*"By default nobody is limited."* The default — everything the agent already
has — is right for this track; narrowing is for workflows that need an agent
to do one job and nothing else.

Right column:

- **How it will run** — *"Each step runs when the steps it waits for are
  finished. You can watch every step live and read the full conversation after
  a run."* Once agents are chosen it previews the plan: `1 Assess carrier
  performance → Freight Analyst`, `2 Write the review → Freight Analyst`.
- **▸ Advanced: workflow definition** — *"The generated definition (saved as the
  workflow's configuration). Edits here take precedence over the form."* It
  shows the generated YAML in an editable box. Touch it and a **Reset to
  generated** link appears next to the helper text.

The generated YAML for a two-step workflow is exactly this:

```yaml
name: carrier_review
description: >
  Produce a short carrier performance review for the weekly logistics meeting.

protocol:
  required_keys: ["STATUS", "OUTPUT"]

team:
  - role: freight_analyst

roles:
  - name: freight_analyst
    prompt: roles/freight_analyst.md

steps:
  - key: assess_carrier_performance
    title: Assess carrier performance
    role: freight_analyst
    prompt: steps/assess_carrier_performance.md
    max_attempts: 2

  - key: write_the_review
    title: Write the review
    role: freight_analyst
    deps: [assess_carrier_performance]
    prompt: steps/write_the_review.md
    max_attempts: 2
```

Step keys are slugified from your titles, and the `deps` chain is built for you.
One prompt file per step is generated alongside; you never have to look at
either.

:::note One agent and up to four steps is the form, not the limit
The form covers the common shape: one specialist working through a few stages in
order. Everything the engine can express — several agents, branching `deps`,
loop steps, `exec` steps that run a script with no model call, and
`requires_artifacts` gates — is available by editing the YAML in the Advanced
panel, or on the
[code-first track](../code-first/03-example-workflow-windows.md), where the
workflow is a file in your repository.
:::

## Saving validates the definition

There is one control — **Create & validate** — and no separate validation step.
The definition is written, materialised, and validated by a dry run. If
validation fails the write is rolled back, so no partially valid definition is
stored. The operation takes a few seconds.

This is the same validation the code-first track performs with `--dry-run`,
applied here as a gate that cannot be skipped.

:::warning A rejected definition returns a detailed report
The report is verbose. **The last line states the fault.** A step that
references a role that does not exist produces approximately forty lines ending
in:

```text
ValueError: Workflow 'carrier_review' validation failed:
  - Step 'write_the_review' references role 'no_such_agent' which is not
defined in workflow roles: ['freight_analyst']
```

Read the report from the bottom upward. The previous version is retained.
:::

## The detail page

The page is headed with the workflow name, its description, and a **Runs of
this workflow** control that opens the run history filtered to it. Sections
follow in reading order: the run summary (agents on the team, step count, and
how steps sequence), **THE TEAM** — one card per agent with what it does and
what it can use here — and **THE STEPS**, one card per step in execution
order, each expandable to the step's full instruction. **Advanced:
definition** presents the YAML in an editable box with the same validate-gate
and rollback as create.

The workflows list shows the columns `WORKFLOW · AGENT · STEPS · SOURCE`, e.g.
`Carrier Review · Freight Analyst · 2 · Your draft`.

The `SOURCE` column reports where the definition comes from: **Built-in** for one
an installed solution provides, and **Your draft** for one saved here and not yet
promoted. A definition saved here runs for its author alone until it is promoted
into the solution repository — see
[the round trip](../shared/01-the-round-trip.md).

:::warning There is no run control and no delete control on this page
Runs begin in the **Sessions** area — [Run it](./06-run-it.md).

Neither the detail page nor the list row provides a delete action. To remove a
workflow definition, delete the workspace ([Teardown](./08-teardown.md)), or ask
your AI Core Harness team to remove the definition.
:::

**Next:** [Run it](./06-run-it.md).
