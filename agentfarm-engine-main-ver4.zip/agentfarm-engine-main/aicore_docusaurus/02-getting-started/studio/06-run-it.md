---
sidebar_position: 6
title: Run it
description: Start a run from the Sessions tab, watch it live in the Run Monitor, and read the platform's own explanation of what happened.
---

# Run it

Runs are started from the **Sessions** tab and watched from the Studio's
**Runs** area. The workflow page displays the definition; it does not start a
run.

## Prerequisites

Two conditions must be met before a run can start:

1. **The workspace runtime is online.** Runs execute on the runtime introduced
   in [Create a workspace](./01-create-a-workspace.md), and the platform
   reports its state rather than failing silently. Where the runtime has not
   yet come online, the dialog replaces **Start Session** with *"Your
   workspace runtime is being set up — starting sessions switches on
   automatically as soon as it comes online. Your goal and settings stay right
   here."* Where a runtime that was previously online stops answering, the
   dialog reports it as temporarily unreachable and offers **Check again**.
   Everything entered is retained in both cases.
2. **A model provider is configured.** Without one, the run is created and
   fails on its first model call.

## Starting a run

Select **Sessions** in the header. The left rail is headed **WORKFLOWS** and
lists **All Sessions** together with each workflow in the workspace and its
session count. A workflow is shown under the name it was given — the one you
typed when creating it, or the one an installed solution declares (often
`snake_case`, such as `signal_brief`). Nothing is re-cased for display.

Select **+ Session** at the top right, or **Start First Session** in the empty
state. Both open the **Start New Session** dialog:

- **Workflow** — scoped to the workspace, with the description shown beneath
  the selection.
- **Workflow Steps** — a collapsible summary of the step sequence.
- **What's your goal for this session?** — required. State the outcome you
  want in specific terms; the goal is passed to every step in the run.

**Start Session** submits the dialog, creates the run, and opens the
conversation view. A failure to create the run is reported in place — the
dialog and everything entered in it remain.

Where the workflow expects input data, the dialog is two steps instead of
one: the button reads **Next**, a second step offers **Upload File** for the
data the run will read, and **Create Session** starts it.

## Three views of a running run

A run can be followed from three connected views, each linked to the others.

**The conversation view** opens first: the team on the left with a status card
per step, the transcript in the middle as agents work, artifacts on the right
as they are produced. The composer sends messages into the run.

**The Run Monitor** — Studio → **Runs** in the **OPERATE** group lists every
run with status, step progress and sortable columns; selecting a run opens its
monitor. The monitor shows the run's status pill, an *updated Ns ago*
freshness marker, one row per step with its attempt count, and **live token
usage** per session with a running total. **Open agent conversation view** and
**Explain this run** link onward.

**The Explain view** is the platform's own account of the run, composed from
its execution record. It carries:

- **A verdict banner** — `converged`, `degraded`, `failed` or `running`. A
  degraded verdict on a finished run reads, for example, *"Run converged: 1/1
  step(s) done after 1 auto-retry"* — the run completed, and the platform
  states plainly that recovery was involved.
- **The step table** — per step: status, attempts (with any stall retries
  called out), duration, tool calls, and the artifact gate. A workflow that
  declares no gate shows an em dash; a destructive `missing:` badge appears
  only when a declared gate actually failed.
- **The timeline** — the run's forensic events, filterable by severity, each
  row expandable to its full payload.
- **Token usage** — per session and in total.

The three views cross-link: Explain ⇄ Monitor ⇄ Conversation.

## Interpreting the result

An agent with no data available to it should report that fact rather than
produce an answer it cannot support. A run that concludes by stating the
required data is not available has behaved correctly:

```text
STATUS: done

OUTPUT: No carrier data is available for last quarter. The project directory
contains no freight or carrier records, and no spend, rate, on-time, or claims
data exists in any accessible data source. A carrier scorecard cannot be
produced without this data. Recommendation: source and load carrier performance
data before the next quarterly review.
```

:::note Transient failures are absorbed automatically
Model stalls, premature terminations and connection interruptions occur in any
system built on model calls. AI Core Harness retries within a step, resumes interrupted
runs, and bounds the total number of attempts, so a run ends either complete or
in a reported failure. A degraded verdict with a completed run is that
machinery working, and the Explain timeline shows exactly where it engaged. Do
not stop a run at the first sign of an error. See
[Automatic recovery](../../04-running-solutions/03-automatic-recovery.md).
:::

**Next:** [Build a swarm](./07-build-a-swarm.md).
