---
sidebar_position: 2
title: Build an agent
description: Describe the agent in your own words and let the platform draft it, or write the persona yourself. No repo, no files.
---

# Build an agent

An **agent** is an identity plus a set of skills. On this track you create one in
the product, and it is held as your own draft until it is promoted into a
solution repository — there is no file to author here and no installation step.

Click **Studio** in the header. The left rail is headed **Agent Studio** and is
organised in three labelled groups:

- **BUILD** — Agents, Skills, Workflows (each with a count), and Capability map
- **OPERATE** — Runs, Swarms, Learning, External agents, Tools & MCP
- **DOMAIN** — solution-specific consoles supplied by installed solutions

The Studio opens on the agent list. In a fresh workspace it holds the platform
agents every workspace receives — **Alex**, the workflow orchestrator, and
**Quinn**, the query engine — and nothing of your own yet. Which platform
agents appear is set by your installation, so the list may also include the
Core Assistant. Press **New agent**, top right.

## Describe it, or fill in the form

The page is titled **New agent**, with **Cancel** and **Create agent** top
right. Inline guidance next to the title states what is still required —
initially *"Add an agent name to continue"* — and **Create agent** stays
disabled until that is satisfied.

The **Describe** card asks *"What should this agent do?"* Write the agent's job
in your own words:

```text
Analyse freight and carrier spend for the logistics team. Every figure must
trace to a query the agent actually ran; when the data cannot answer, it
must say so rather than estimate.
```

**Draft this agent** enables once a description is entered. Pressing it fills
the form: a drafted persona, and a **Suggested for you** panel of skills
matched to the words of your description. A confirmation appears: *"Draft
ready — review and adjust anything below."* The control becomes **Draft
again**.

Skipping the draft is fully supported — *"or skip and fill in the form
manually — it works either way."*

Two things about the suggestions:

- **`output_protocol` is listed first, carrying a 🔒 `required` badge**
  (*"Required by the platform"*). An agent without it emits no status line, so every step it runs
  would be recorded as failed and retried; the platform therefore always
  includes it.
- Suggestions are matched against the description's words across every skill
  in the workspace's catalog. Untick any that do not apply.

Name the agent in the **Identity** card — `Freight Analyst` — and select
**Create agent**. The agent's own page opens.

## The agent's page

The header shows the agent's avatar, name, a **Yours** provenance chip, and a
summary — skill and tool counts. Top right: **Reset draft** and **Save
changes**. Five tabs: **Build**, **Capabilities**, **Workflows**, **Knowledge**
and **Activity**. A collapsible **Test conversation** rail sits on the
right-hand edge — one message proves the persona and skills loaded without
running a workflow.

:::note A save creates a draft
**Save changes** records the edit as your own draft. The running solution is
unchanged, and no other member's session or run resolves it. The draft strip
under the editor carries the draft's state — **Draft**, **Out of date**, **With
a developer** or **Promoted** — and the actions **Try it**, **Diff**,
**Rebase**, **Discard** and **Promote**. The edit becomes running content only
once it is promoted into the solution repository and that change is deployed.
See [Drafts and promotion](../../03-building-solutions/12-drafts-and-promotion.md).
:::

**Build** is a sectioned editor:

- `01 · IDENTITY` — **Name**, **Role** (*"a plain-language job title shown
  across the studio"*) and **What this agent does**. Renaming updates the
  personality heading when you save.
- `02 · PERSONALITY & INSTRUCTIONS` — *"How it should think, sound and
  behave"*, one box per section, with controls to add tone and additional
  instructions. Content that cannot be classified into a section is preserved
  verbatim rather than lost.

**Capabilities** is where the agent's reach is managed:

- `01 · SKILLS` — what it knows how to do. Skills marked **Always active** are
  loaded in every conversation; the others show a remove control.
  **+ Add skill** and **Browse catalog** open the picker. Every skill in the
  catalog can be added to every agent — assignment records which agents hold a
  skill, not which are permitted to.
- `02 · TOOLS` — what it can reach. *"Tools arrive with the skills that teach
  them — add a skill to grant a tool."* Each entry names the tool and the
  skill that grants it, for example `iof-query via data_query`. Tools are not
  added directly; [Tools and capabilities](./04-tools-and-capabilities.md)
  covers the model.
- `03 · A2A EXPOSURE` — publishing this agent to other systems. *"The agent
  card is the switch"*: a card declaring exposure serves the agent at a public
  Agent2Agent endpoint with no deployment change. **Start from template**
  authors the card; a served-card preview shows what external callers will
  read. Saving the card records it in your draft and leaves the running agent
  unchanged — exposure follows the card once the draft is promoted. The panel carries the
  operational caveat: the service port carries no authentication, so exposed
  agents are reachable by anything on the network — keep the service internal
  or place an authenticating proxy in front of it. **Save card** and **Remove
  card** control the exposure; removing the card withdraws the agent.

Expose the Freight Analyst now — **Start from template**, then **Save card**.
The [swarm page](./07-build-a-swarm.md) consults it through this endpoint.

:::warning There is no delete action
AI Core Harness Studio provides no way to remove an agent. An agent created to
evaluate an approach can be discarded from its draft strip while it is still a
draft; nobody else has seen it. Once promoted it belongs to the solution, and it
is removed by removing it from the repository
([Teardown](./08-teardown.md) removes an unpromoted one with the workspace).
:::

**Next:** [Build a skill](./03-build-a-skill.md).
