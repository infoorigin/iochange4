---
sidebar_position: 7
title: Build a swarm
description: Register your exposed agent as an external roster member, then inspect, edit and run a goal-oriented swarm from the Swarms console.
---

# Build a swarm

A **swarm** is the goal-oriented sibling of a workflow: one meta-agent, a
goal, a roster of external agents it may consult, the MCP servers in its
reach, a budget, and a fail-closed deliverable. Where a workflow fixes the
steps in advance, a swarm's meta-agent decides its own route at run time,
within the controls the definition sets.

This page closes the track's loop: the Freight Analyst exposed in
[Build an agent](./02-build-an-agent.md) becomes a roster member another agent
consults.

## Register the exposed agent

A swarm's roster draws from the workspace's **external agent registry** — the
catalog of Agent2Agent endpoints this workspace may consult. The agent
exposed earlier serves exactly such an endpoint, so it can be registered as a
consultable agent in its own workspace.

Select **External agents** in the **OPERATE** group. Two tabs:

- **Exposed** — what this workspace publishes. The Freight Analyst appears
  here with a `card` source badge; rows link back to the agent's Capabilities
  tab.
- **Registry** — what this workspace consults. Select the add control and
  complete the dialog: a name (`freight-analyst`), the endpoint URL — the
  exposed agent's own address, `http://<engine-host>:8111/a2a/freight_analyst`
  — a description written in the terms a question would use, and optional
  tags, examples and authentication headers. Header values may reference
  environment variables as `${VAR}`; the value never leaves the engine host.

Each registry row carries a credentials pill and a **Validate** control.
Validation runs three escalating checks from the engine host and reports each:
credential resolvability (variable names only), endpoint reachability with the
served card's name and skill count, and a protocol handshake. A row that
validates is a roster member a swarm can actually reach.

## The Swarms console

Select **Swarms** in the **OPERATE** group. The list shows every swarm the
workspace can run: name, solution, meta-agent, roster and MCP counts —
`all` when the definition names no explicit set — the deliverable, and whether
the definition comes from an installed solution (`pack`) or a local edit
(`override`).

The console lists, edits and runs swarms. **Creating one is not part of this
track**: `aicore new-swarm` writes into a solution package, and nothing built
so far in the Studio has one — everything to this point has been authored in
the product, with no repository and no installation step.

```bash
aicore new-swarm freight_pulse    # requires a solution repository
```

If your workspace has no installed solution, the swarm console is empty and
stays that way. To author one, follow the
[code-first track](../code-first/07-example-swarm.md), which creates the
package first; the console then lists what it declares.

## The swarm's page

Selecting a swarm opens a two-pane view.

**The compiled shape**, left: the meta-agent; one card per roster member,
cross-checked against the registry — a member the registry does not hold is
marked **not in this workspace's registry**, and a run would leave the
meta-agent unable to consult it; the MCP servers in reach; the budget; and the
deliverable gate.

Two budget lines mean two different things. `tool_calls` is a **hard ceiling
the platform enforces** — the run cannot exceed it. `consults` is a **briefing
contract** — an instruction the meta-agent is told to honour, not a limit the
platform imposes.

**The definition**, right: the YAML in an editable box. **Save** writes it and
returns lint findings in place — errors in destructive tone, warnings beside
them, each with the place and the fix. A definition that lints clean will
load; **Run** stays disabled while lint errors remain.

## Run it

**Run** opens a dialog: the goal, with the budget summarised beneath it.
Starting the swarm creates a standard run — a swarm compiles to a one-step
workflow — so it appears in the **Runs** list and carries the full
[Monitor and Explain](./06-run-it.md) treatment, including per-consult results
in the timeline.

**Next:** [Teardown](./08-teardown.md).
