---
sidebar_position: 9
title: Troubleshooting (Studio)
description: Symptoms specific to building in AI Core Harness Studio — disabled controls, scoping, validation messages, and where runs start.
---

# Troubleshooting — AI Core Harness Studio

:::note Not specific to this track?
Machine setup, sign-in, database and model-provider symptoms are on the
[shared page](../shared/02-troubleshooting.md).
:::

Entries are keyed on what is displayed.

---

## **Create agent** is unavailable

**Cause:** a required field is still empty. The guidance line beside the page
title names what is missing — initially *"Add an agent name to continue"*.

**Fix:** complete the named field. The agent's internal id is derived from the
name on save; it cannot be changed later, and there is no rename or delete
action.

## The agent was saved under a different name

`Freight Analyst` was entered in **Agent name**, and the agent is named
`Analyse Freight Carrier`.

**Cause:** the saved name is taken from the `# SOUL — <name>` heading at the top
of **Personality & instructions**, which takes precedence over the Agent name
field. After **Draft this agent**, that heading holds the drafted name, which is
derived from the first words of the description.

**Fix:** open the agent, select **Build** → `01 · IDENTITY`, correct **Name**,
and select **Save changes**. The page states the relationship: *"Renaming
updates the personality heading when you save."* The internal id is permanent
regardless.

## The internal id was altered on save

`Freight-Analyst!` was entered and the agent's id is `freight_analyst_`.

**Cause:** the id is normalised rather than rejected. Characters outside the
permitted set become underscores.

**Fix:** none after the fact; there is no rename or delete action. Create a
second agent with the required id, or delete the workspace
([Teardown](./08-teardown.md)). Verify the name before selecting **Create
agent**.

## **Draft this agent** is unavailable

**Cause:** the description field above it is empty. The control is enabled on
the first character.

## The draft suggested unrelated skills

A freight agent is offered skills belonging to other solutions.

**Cause:** two conditions together. Drafting matches keywords rather than
interpreting intent, and the pool it matches against is the skills of every
installed solution, because a workspace created in the Studio is unscoped — see
the next entry.

**Fix:** clear the selections before saving. Only `output_protocol` is
compulsory, and it is selected and locked.

## The workspace lists agents and skills that were not created in it

A newly created workspace opens with a populated agent and skill count.

**Cause:** content is resolved from the solution packages installed in the
environment the workspace's runtime runs in, not held per workspace. The agents
and skills of every installed solution are therefore listed, including the
platform's own always-on agents.

**How to distinguish your content:** each agent row shows its owning solution
beneath the job title, and carries one of three labels — **Your draft** for
one you created here, **Yours** for one this workspace owns, **Built-in** for
one an installed solution supplies. In the workflow form's agent list yours
are suffixed **— created in Studio**.

**Fix:** none required. Where a single solution is installed there is nothing to
distinguish; otherwise use the solution label on each row. The list is shortened
only by installing fewer solutions in that environment. Content created in the
Studio is unaffected either way.

## An agent is labelled **Your draft**

**Cause:** the agent was created in AI Core Harness Studio and is held as a
draft. Agents supplied by an installed solution are labelled **Built-in**.

**What the label means:** a draft resolves in its author's own test sessions and
draft-flagged runs, and nowhere else. Other users do not see it, and it does not
execute in the environment's ordinary runs.

**Fix:** promote it. A draft becomes running content when a developer carries it
into the solution repository and that change is built and deployed — see
[Drafts and promotion](../../03-building-solutions/12-drafts-and-promotion.md).

## The agent's Capabilities list changed after a run

An agent given one skill reports several skills and tools after its first run,
and `output_protocol` is no longer listed.

**Cause:** a run materialises the agent's workspace for execution and rewrites
its skill set. The Studio displays that set, so what appears after a run is the
run's set rather than the original selection. An agent that has never run
retains exactly what was assigned to it.

**Fix:** none required; the run completed and the output protocol was applied.
Do not treat the Capabilities list after a run as a record of the original
selection. Re-add any required skill through **+ Add skill**.

## A skill was created and no agent holds it

The skill appears in the list with no usage count, and no agent lists it under
**Capabilities**.

**Cause:** expected behaviour. `03 · SHARING` was left empty. Skills are open:
the sharing section records which agents *hold* the skill, not which agents are
permitted it, and a skill held by nobody is a valid state.

**Fix:** none required if a workflow step names the skill directly. To give it
to an agent, open the agent's **Capabilities** tab and use **+ Add skill**, or
edit the skill's sharing section.

## Only four steps can be added to a workflow

**Cause:** expected behaviour. The form supports one agent and one to four
steps. At four steps the **+ Add a step** control is removed from the page.

**Fix:** open **▸ Advanced: workflow definition** and add steps to the YAML
directly; edits there take precedence over the form, and **Reset to generated**
restores it. Definitions beyond a straight sequence — several agents, non-linear
`deps`, loops, or `exec` steps — are authored in the YAML editor or on the
[code-first track](../code-first/03-example-workflow-windows.md).

## Saving a workflow is rejected with a validation report

**Cause:** expected behaviour. Every create and save is validated before it is
stored, and a definition that does not load is rejected rather than saved.

**Fix:** read the last line of the message, which states the specific fault:

```text
ValueError: Workflow 'carrier_review' validation failed:
  - Step 'write_the_review' references role 'no_such_agent' which is not
defined in workflow roles: ['freight_analyst']
```

The previous version is retained; the rejected write is not applied.

## A new workflow is not counted in the sidebar

The workflow was created and its detail page is open, but the left rail still
reports zero workflows.

**Cause:** the counts in the rail are loaded with the page and are not refreshed
after a create.

**Fix:** navigate to **Workflows**, or reload the page.

## A workflow I did not create is listed

**Cause:** expected. The list shows every workflow the workspace can run.
One an installed solution provides carries the SOURCE value **Built-in**;
only workflows saved here carry **Your draft**. Editing a **Built-in** one is
allowed — the save becomes your own draft on top of the solution's copy,
never a change to it.

## There is no run control on the workflow page

**Cause:** runs are started from the **Sessions** area.

**Fix:** see [Run it](./06-run-it.md).

## The Start New Session dialog shows no **Start Session** control

In its place the dialog states that the workspace runtime is being set up, or
that it is temporarily unreachable.

**Cause:** expected behaviour. Session starts require the workspace runtime.
A runtime that has never come online is reported as being prepared — the normal
state of a newly created workspace — and one that was online and stopped
answering is reported as temporarily unreachable.

**Fix:** for a new workspace, continue building; starting sessions becomes
available on its own once the runtime comes online. For an unreachable runtime,
select **Check again**, and if it persists ask your AI Core Harness team whether the
workspace's runtime service is running. The goal and settings entered are
retained in both cases. See
[Create a workspace](./01-create-a-workspace.md#build-now-run-when-the-runtime-is-online).

## **Start Session** is unavailable

**Cause:** **What's your goal for this session?** is required and empty.

## The Start New Session dialog has no upload control

**Cause:** the dialog offers one only when the workflow expects input data —
then it runs in two steps, with **Upload File** on the second (`.json`,
`.md`, `.csv`, `.py`, `.txt`).

Otherwise upload in the conversation view, in the **Artifacts** panel —
**Input Files** → *Upload Your Files*, accepting `.json`, `.md`, `.csv`,
`.py`, `.txt`, `.html`, `.mhtml` and `.htm`.

## "cannot be a new workspace code (3-31 chars: a lowercase letter, then lowercase letters, digits or '_')"

**Cause:** **Create** on the New workspace card is enabled as soon as the code
field is non-empty; the format is validated on save. `UI Validate`,
`1logistics` and any code containing a hyphen are rejected; for a hyphenated
code the message names the underscore form to use.

**Fix:** use a value such as `logistics` or `field_ops_2026`.

## The workspace confirmation names CLI commands

**Cause:** the confirmation message is written for the code-first track and is
displayed unchanged.

**Fix:** disregard it. On this track the workspace is populated in AI Core Harness
Studio rather than from a repository.

## There is no way to delete an agent or a skill

**Cause:** AI Core Harness Studio provides create and edit operations only.

**Fix:** delete the workspace ([Teardown](./08-teardown.md)).

## Deleting a workspace prompts twice and reports `--force`

**Cause:** the first prompt is the confirmation. The second appears only when
the workspace holds run history, which is not deleted implicitly.

**Fix:** confirming a second time deletes the run history with the workspace.
Stored run artifacts are retained in either case. See
[Teardown](./08-teardown.md).

## A request without a workspace is refused

```json
{"detail":"X-Workspace-Id header is required: name the workspace this request acts on (numeric id or code; a stream that cannot set headers may use the workspace_id query parameter instead). There is no fallback workspace."}
```

**Cause:** expected behaviour. Every request names the workspace it operates
on; the platform never selects one on the caller's behalf.

**Fix:** select a workspace in the switcher. If the session predates workspace
selection, sign out and back in.

## The Administration entry is not present in the user menu

**Cause:** the account is not a platform administrator.

**Fix:** an existing administrator grants the role in **Administration →
Users**.

## A skill has no Edit control

**Cause:** it ships with the platform SDK. The row shows **🔒 Built-in**
where **Edit** would be, and the API refuses the edit as well.

**Fix:** none — this is deliberate. An SDK skill arrives in a wheel and
changes on upgrade, so a workspace copy would freeze a fork that no upgrade
could reach again. Use **New skill** to author your own.

## The workspace name differs between screens

**Cause:** one screen displays the workspace's display name and the other
derives a label from its code. They identify the same workspace.

## The workflow form reports "Every step needs a name."

**Cause:** a step's short title is empty. The definition cannot be generated
without a key for every step.

**Fix:** name the step and select **Create & validate** again. Nothing entered
elsewhere on the form is lost, and an unsaved draft is kept in the browser
tab — reloading the page restores it with a *"Restored your unsaved draft from
this tab"* notice.

## A tool row reads "no skill"

**Cause:** the tool is declared and installed, but no skill teaches it, so no
agent will use it.

**Fix:** create the teaching skill —
[Tools and capabilities](./04-tools-and-capabilities.md) names the pairing
command on the row.

## A swarm's Run control is disabled

**Cause:** the definition has lint errors. A definition that does not lint
clean will not load, so the run is not offered.

**Fix:** correct the findings listed under the editor — each carries the place
and the fix — and save again.

---

If the symptom is not listed here, see the
[shared page](../shared/02-troubleshooting.md) or
[Common failures](../../08-troubleshooting/01-common-failures.md).

**Next:** [The round trip](../shared/01-the-round-trip.md).
