---
sidebar_position: 8
title: Teardown
description: AI Core Harness Studio provides no delete action for agents, skills or workflows. Removing the workspace is how an experiment is undone.
---

# Teardown

:::warning AI Core Harness Studio cannot delete what it creates
No delete action is provided for an agent, a skill or a workflow — not on a list
row, not on a detail page, and not under an Advanced disclosure. Content can be
created and edited only. Teardown on this track therefore means removing the
**workspace** rather than removing items within it.
:::

## Delete the workspace

User menu → **Administration** → **Workspaces**. Each workspace card
provides a **Delete workspace** control.

Two confirmations follow, and the second is the significant one.

**First**, a confirmation:

```text
Delete workspace "logistics"? Any draft authored here and not yet promoted is
lost. Content an installed solution provides is unaffected.
```

**Then**, if the workspace holds run history, the deletion is refused and a
second question is asked:

```text
workspace 'logistics' has 1 run(s) — refusing to delete run history. Re-run with
--force (API: ?force=true) to delete them too; on-disk run artifacts under
<IOF_ROOT>/instances are left alone either way.

Delete the run history too?
```

Confirming deletes the run history with the workspace:

```text
Workspace logistics and its runs deleted.
```

The card is removed from the list and the workspace's own directory is deleted.
Stored run artifacts are retained in either case, as the message states.

:::note The second prompt quotes command-line options
`--force` and `?force=true` are the command-line equivalents of the same
operation. In AI Core Harness Studio the question means only *delete the run history as
well*. Selecting **Cancel** leaves the workspace and its contents unchanged.
:::

The same operation from the command line:

```bash
aicore workspace delete logistics --yes --force
```

```text title="expected (counts will differ)"
deleted workspace 'logistics'
       1  agent
       2  skills
       1  workflow
       3  imported items
       1  member
       1  settings record
       1  workspace record
removed <IOF_ROOT>\workspaces\logistics
```

This removes every record keyed to the workspace: the agents, the skills, the
workflows, and the membership.

:::warning An unpromoted draft is lost with the workspace
Content built here is held as a draft until it is promoted into a solution
repository. Deleting the workspace deletes any draft that was never promoted. To
retain such work, promote it first — see
[the round trip](../shared/01-the-round-trip.md), which documents the path from
content built in AI Core Harness Studio to content held in Git.
:::

Deleting a workspace removes only that workspace's content. The platform's
shared content — the Core Assistant and the shared skills — does not belong
to any workspace and is unaffected by workspace deletion.

## Removing a single item

Individual agents, skills and workflows cannot be removed in AI Core Harness Studio. To
remove one, delete the workspace, or ask your AI Core Harness team to remove the
definition.

**Next:** [Troubleshooting](./09-troubleshooting.md).
