---
sidebar_position: 1
title: Create a workspace
description: The tenant that everything you build belongs to. Created from the Administration area of AI Core Harness Studio.
---

# Create a workspace

A **workspace** is a tenant. It owns the runs made against it, its membership,
and the drafts its members author; the agents, skills and workflows it lists
come from the solutions installed in its runtime's environment. Everything built
on this track belongs to one.
The track builds one coherent example, page by page: a `logistics` workspace, a
freight analyst agent, the skill and tool that ground it, a workflow that runs
it, and a swarm that consults it. Each page builds on the one before.

## Where things are

Two menus in the header control workspace matters:

- The **workspace switcher** — the chip in the top right showing the current
  workspace. Its menu contains a `WORKSPACES` heading, a **Search workspace…**
  field, the list of workspaces you can reach with the current one marked
  `current`, and two entries at the foot: **Workspace settings** and
  **Operational Insights**.
- The **user menu** — your avatar, at the far right. It holds
  **Administration**, above **Logout**. The entry is present only for platform
  administrators; if it is absent, ask an existing administrator to grant the
  role.

On first sign-in the platform selects a workspace you are a member of. Every
request the interface makes is scoped to the selected workspace; the chip
always shows which one that is.

## Creating it

Open the user menu and select **Administration**. The page states: "Workspaces
are private: a user reaches only the workspaces they are a member of. An admin
reaches every workspace." Below it are two sub-tabs, **Users** and
**Workspaces**. Select **Workspaces**.

The first card is **New workspace**. It is the form itself rather than a
control that opens one: two fields side by side, `code (lowercase, e.g.
logistics)` and `display name (optional)`, and a **Create** button. **Create
remains disabled until a code is entered.**

The card states:

> You are added as a member automatically. A new workspace has no content of
> its own — it lists the agents, skills and workflows of whichever solutions
> are installed for it.

:::note On this track nothing is installed yet
The next pages author this workspace's first agent, skill and workflow in the
Studio, where each is held as your own draft until it is promoted.
:::

Enter `logistics`, give it the display name `Logistics Intelligence`, and select
**Create**. The confirmation reads *"Workspace logistics created — This
workspace is empty. It lists the agents, skills and workflows of whichever
solutions are installed for it; anything you build here starts as your own
draft."* A new card appears in the list below, headed
`logistics — 1 member(s)`, with a **Delete workspace** control and your email
address listed as `MEMBER`.

### If the code is rejected

**Create** is enabled as soon as the code field is non-empty; the format is
validated on save. A rejected code produces a message above the card:

```text
workspace code: 'ui validate' cannot be a new workspace code (3-31 chars: a
lowercase letter, then lowercase letters, digits or '_'); it becomes the
package prefix the scaffold generates
```

`UI Validate` and `1logistics` are both rejected, as is a code containing a
hyphen — the message then names the underscore form to use instead. The code
`default` is reserved and refused: a workspace is always named explicitly, and
the platform never supplies one on a caller's behalf.

### Switching to it

Open the workspace switcher and select the new workspace by its display name.
The chip changes, and all subsequent work is scoped to that workspace.

:::tip The two screens identify the workspace differently
The Administration cards are keyed on the **code** (`logistics`). The workspace
switcher lists the **display name** (`Logistics Intelligence`). Both refer to
the same workspace.
:::

### Build now, run when the runtime is online

A workspace has two halves: the content you are about to author, and a
**workspace runtime** — the service that executes runs and hosts the
always-available agents. Every page of this track up to
[Run it](./06-run-it.md) authors content without the runtime.

Until the new workspace's runtime comes online, its run surfaces show
**"Your workspace runtime is being set up"** — an expected state for a new
workspace, not an error. Build the agent, skill and workflow now; running
them switches on automatically as soon as the runtime is available. On a
local installation the runtime is the `aicore serve` service, and pointing it
at the new workspace is restarting it as `aicore serve --workspace logistics`.
In a deployed installation each workspace has its own runtime service; see
[Deploying as a service](../../04-running-solutions/04-deploying-as-a-service.md).

## Membership

Workspace access is closed: without a membership record there is no access.
Creating a workspace adds the creator as a member, so a workspace you create is
one you can open. Additional members are added in **Administration →
Workspaces**.

:::warning A workspace lists every installed solution
Content is resolved from the solution packages installed in the environment the
workspace's runtime runs in, not held per workspace. A workspace therefore lists
**the agents and skills of every installed solution**, including the platform's
own always-on agents — the Core Assistant, the workflow orchestrator and the
query engine.

A newly created workspace containing nothing of your own can therefore open
with a populated agent and skill count. Content you create is always attributed
to the workspace it was created in; it is the additional entries that appear.
See [Troubleshooting](./09-troubleshooting.md).
:::

**Next:** [Build an agent](./02-build-an-agent.md).
