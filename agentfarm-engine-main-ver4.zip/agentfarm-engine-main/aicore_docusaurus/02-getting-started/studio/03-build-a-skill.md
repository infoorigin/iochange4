---
sidebar_position: 3
title: Build a skill
description: Teach an agent something — a method, a house style, or a data tool it may call.
---

# Build a skill

A **skill** is a `SKILL.md` package: instructions an agent loads, and optionally
a command it may run. On this track it is authored in AI Core Harness Studio and stored
in the workspace.

A skill is judgement; a tool is a script. A skill *teaches* an agent when and
how to use a tool — the tool itself is code, installed on the engine host. An
agent's Tools list is derived entirely from the skills it holds, which is why
the agent page states *"Tools arrive with the skills that teach them."* The
[next page](./04-tools-and-capabilities.md) covers where tools come from.

Select **Skills** in the **BUILD** group of the left rail, then **New skill**.

The skills list groups skills by category (`DATA & ANALYSIS · 5`,
`DOMAIN KNOWLEDGE · 10`, …), each row showing its description and usage count.
Any row outside the platform SDK provides an **Edit** control — your own
skills, and the ones your installed solution supplies, which this workspace
is allowed to shadow with its own version. A skill that ships with the SDK
itself shows **🔒 Built-in** in place of Edit and cannot be edited here: it
arrives in a wheel and changes on upgrade, so a workspace copy would freeze a
fork no upgrade could ever reach.

## The form

Titled **New skill**, subtitle *"Teach agents a new capability — no files or
code required."* Four numbered sections, with **Cancel** / **Create skill** top
right.

| Section | Field | What it is |
|---|---|---|
| `01 · BASICS` | **Name** | *"Lowercase letters, numbers and underscores. This becomes the skill's id."* Permanent — the editor later says "internal id is `<name>` — it can't change". |
| | **Category** | dropdown: Data & Analysis · Domain Knowledge · Reasoning & Method · Output & Reporting · System. Defaults to Domain Knowledge. *"Where this skill appears when people browse the library."* Browsing only. |
| | **What this skill teaches the agent** | one line. *"One clear sentence — agents use it to decide when this skill applies."* |
| | **Always active** | *"Loaded in every conversation — use for rules the agent must never forget."* |
| `02 · INSTRUCTIONS` | **Instructions for the agent** | the substance — the markdown body the agent reads |
| `03 · SHARING` | **Give to all agents** + a checkbox per agent | which agents receive it |
| `04 · DATA TOOL` | **Tool** *(optional)* | bind a registered command |

**Create skill** enables once **Name**, **What this skill teaches the agent**
and **Instructions for the agent** are all filled. It does **not** wait for
the sharing section — see below.

## Who receives it

The sharing control drives two different things at once, and the distinction
matters:

- **`install_to`** — the agents that get a copy now.
- **`roles`** — the assignment record: which agents *hold* it. A skill with no
  roles assigned is held by no agent.

It is not a permission. Nothing refuses this skill to an agent outside the
list: the Capabilities picker on the agent side will add it, and a workflow
step can name it for any agent at all. Naming an `install_to` agent outside
`roles` is fine too — the server folds it in rather than refusing, because
installing a skill into an agent *is* assigning it.

Ticking *Give to all agents* sets `roles: all`. Ticking specific agents sets
both, to the same list — the request body for a skill given to one agent is
literally:

```json
{"…", "roles":["freight_analyst"], "install_to":["freight_analyst"]}
```

:::note A skill may be created with no agents at all
Enter the name and instructions, select no agent, and **Create skill**
succeeds: the skill is stored, held by nobody, and its list row shows no
usage. That is a valid state — a workflow step can name the skill directly,
and any agent can be given it later from its **Capabilities** tab or by
editing the skill's sharing section. Creating a second skill with the same
name is refused with *"skill '&lt;name&gt;' already exists"* — the name is the
permanent id.
:::

:::note The equivalent rule on the code-first track
In a repository, a `SKILL.md` whose frontmatter omits `roles:` is initially held
by no agent, and nothing reports it. This form does not save until the question
is answered. The assignment is a starting point only: a workflow step can name
the skill, and it can be assigned to an agent later.
:::

## Binding a data tool

`04 · DATA TOOL` — *"Pick a registered tool and the skill will teach the agent
exactly how to run it."* The **Tool** dropdown offers what is already
registered:

- No tool — instructions only
- Data query — SQL over the governed data catalog
- Run deliverables — read and publish run artifacts
- Document search — vector filesystem reads

To add one, expand **▸ Advanced: register a new tool**, which stores a name, a
description, the command line and usage markdown.

This is the AI Core Harness Studio equivalent of a solution's `tools.yaml`. It is what
takes a skill from guidance alone to guidance plus something the agent can
execute.

## What happens on save

The `SKILL.md` is composed — frontmatter from the form fields, your instructions
as the body, and a tool section if one was bound — then saved as **your own
draft**. Carriage rides the draft too: the agents named in the sharing section
hold it in your own sessions and in draft-flagged runs, not yet for anyone
else. The skills list reopens with the new skill listed under its category and
its usage count, marked **Your draft**.

To make it part of the workspace for everyone, promote it — see
[Drafts and promotion](../../03-building-solutions/12-drafts-and-promotion.md).

## Editing it afterwards

**Edit** on the list row opens the same four sections, with three additions:

- **Sharing becomes three explicit choices**, not one checkbox —
  *Give to all agents* / *Give to selected agents* / *Only where installed*
  (*"Leave the current holders exactly as they are."*).
- A `USED BY · n` section — *"Where it is installed"* — naming the agents, with
  *"Saving updates the skill everywhere it is installed."*
- **▸ View source (SKILL.md)**.

Frontmatter keys the form does not manage are carried through unchanged, so
hand-authored additions survive an edit made here.

:::warning There is no delete action
As with agents, create and edit are provided and remove is not — neither on the
list row nor in the editor. A skill created in error can be discarded from its
draft strip while it is still a draft; nobody else has seen it. Once promoted it
belongs to the solution, and it is removed by removing it from the repository.
:::

**Next:** [Tools and capabilities](./04-tools-and-capabilities.md).
