---
sidebar_position: 2
title: Set up your machine
description: One-time prerequisites for building a solution on the code-first track, and where each track's setup is documented.
---

# Set up your machine

Setup applies to the **code-first** track only. AI Core Harness Studio requires no local
setup — your AI Core Harness team provides the Studio address and an account.

:::tip Working in AI Core Harness Studio only?
Skip this page. Go to [Create a workspace](./studio/01-create-a-workspace.md).
:::

## Prerequisites

The code-first track requires, once per machine:

| Requirement | Purpose |
|---|---|
| Python 3.11 or later | The SDK and its virtual environment |
| Access to the package index | The SDK installs from it. If pip cannot reach it, check with the devops team on the pip index URL setup. |
| A model provider and API key | Running a workflow calls a model |

## Setup and the four examples

The detailed setup — installing the SDK, creating the AI Core Harness home directory,
and configuring a model provider — is the first step of the code-first track:

- [Install the SDK](./code-first/01-install.md)

The track then builds four complete solutions in order of increasing scope,
each in its own empty folder:

1. [Your first agent](./code-first/02-example-first-agent.md) — one agent with
   one skill, answering directly. The core loop, in about ten minutes.
2. [A workflow solution](./code-first/03-example-workflow-windows.md) — two
   agents, a deterministic tool, a shared skill, and a two-step workflow.
3. [An MCP integration](./code-first/06-example-mcp-server.md) — a local
   Model Context Protocol server whose tools an agent calls.
4. [A swarm](./code-first/07-example-swarm.md) — a meta-agent that consults an
   external agent under a goal.

Start at [The code-first track](./code-first/00-overview.md).

## Which database

The examples run in **local mode**: a SQLite database in the working folder, no
server, no privileges. A production deployment points the same commands at a
shared database instead; nothing in the examples changes. Local mode is set per
folder with `aicore local on`.

Every command that opens a database states which one, on standard error: `LOCAL` followed by the file, or `SHARED` followed by the server and schema. Local mode is durable rather than per-command, so this line is what tells you which database the next command will write to.

**Next:** [The code-first track](./code-first/00-overview.md), or the
[Studio track](./studio/01-create-a-workspace.md).
