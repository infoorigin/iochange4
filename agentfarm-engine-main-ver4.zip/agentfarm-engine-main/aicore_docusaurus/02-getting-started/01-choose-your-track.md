---
sidebar_position: 1
title: Choose your track
description: AI Core Harness supports two development tracks. Select one according to where solution content is stored and how it is versioned.
---

# Choose your track

AI Core Harness supports two development tracks. They differ in where solution content
is stored, not in what can be built.

On the **code-first** track the source of truth is a set of files in a
workspace repository: the repository is installed as a package, the engine
resolves content from the installed package, and the repository is the
deliverable, reviewed and versioned in Git like any other code.

On the **Studio** track content is entered in the web interface and held in the
platform database as its author's draft. A draft becomes running content when a
developer applies it into a solution repository and that change is deployed; no
repository is required until then.

Both tracks write to a **workspace**, produce entries in the same catalog, and
execute on the same engine.

## Selection criteria

Select the **code-first** track when the solution is owned by a team and must be
reviewed in pull requests, released under a version, deployed to more than one
environment, and reproducible from a clone.

Select the **Studio** track to build an agent, a skill and a workflow, run
them, and publish the agent to other systems — without creating a repository.
Content created this way is held as a draft and can be carried into Git later.

:::note Content can move between tracks
[The round trip](./shared/01-the-round-trip.md) documents how content is
transferred in both directions, and the conditions under which applying a
draft refuses to overwrite an uncommitted change in the repository.
:::

## Requirements by track

The code-first track is a sequence of CLI commands run against an installed
solution — `workspace create`, `workspace attach`, `workspace show` and `run`.
No sign-in is involved. It needs a one-time host setup: access to your
organisation's package index, a Python virtual environment, and a scaffolded
solution repository. See [Set up your machine](./02-set-up-your-machine.md).

AI Core Harness Studio is a browser client of the platform services. It requires those
services to be running and an account to exist, and needs no local setup at
all; your AI Core Harness team provides the Studio address and your credentials.

Either track needs a model provider configured before a workflow will run.

## What each track supports

Both tracks produce content that runs identically. They differ in the range of
definitions that can be authored directly.

**AI Core Harness Studio** creates and edits content; it provides no delete action for
an agent or a skill. To remove an experiment, delete the workspace — see
[Teardown](./studio/08-teardown.md).

**The Studio workflow form** supports one agent and up to four steps in a
straight sequence. Definitions beyond that shape — several agents, non-linear
`deps`, loops, `exec` steps, or `requires_artifacts` — are authored in the YAML
editor in the **Advanced** panel of the same form, or on the code-first track.

**A workspace lists the content of every solution installed in its runtime's
environment.** Content is resolved from the installed solution packages rather
than held per workspace, so where an environment has several solutions
installed, the agents and skills of all of them are listed. Each entry is
labelled with the solution that supplies it, and content created in the Studio
is labelled *Studio-built*. Where a single solution is installed, this has no
visible effect. See
[Studio troubleshooting](./studio/09-troubleshooting.md).

**Runs start from the Sessions area,** not from the workflow page. See
[Run it](./studio/06-run-it.md).

## Where to start

- **Code-first**: [Start the code-first track](./code-first/00-overview.md)
- **Studio**: [Create a workspace](./studio/01-create-a-workspace.md)
- **Machine setup**: [Set up your machine](./02-set-up-your-machine.md)

:::note Verify against your own environment
Commands, labels and messages quoted in this guide reflect a standard
installation. Where your environment differs, treat the documentation as
incorrect and report it to your AI Core Harness team.
:::

**Next:** [Set up your machine](./02-set-up-your-machine.md).
