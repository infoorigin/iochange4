---
sidebar_position: 7
title: Swarms
description: A swarm delegates a goal to one meta-agent with a granted roster of agents and tools. The route is planned at runtime under a budget, a checkpoint and a fail-closed deliverable gate.
---

# Swarms

A swarm is a goal delegated to one meta-agent. You nominate the meta-agent,
grant it a roster of external agents, connected tools and skills, and state
what the run must achieve. The meta-agent determines which capability to use
and in what order while the run proceeds.

Swarms belong to a solution, as workflows do. Use a swarm when the route
depends on what the agents find; use a [workflow](./06-workflows.md) when the
process is known in advance.

A swarm is not an unconstrained agent. Four controls bound every run: the
roster limits what may be used, the budget limits how far the run may go, the
checkpoint records what has been completed, and the deliverable is verified
before the run is allowed to succeed.

## Create a swarm

```bash
aicore new-swarm portfolio_review --role intel_orchestrator \
    --agents rx-sales,market-voice \
    --mcp lab \
    --description "Cross-domain brand risk review"
```

| Option | Effect |
|---|---|
| `--role` | the meta-agent. Defaults to the solution's agent when it has exactly one. |
| `--agents` | the external-agent roster, by workspace registry name |
| `--mcp` | the MCP server roster, by declared server name |
| `--description` | one line stating what the swarm achieves |
| `--solution` | which solution owns the swarm; required only when the workspace has several |

The command creates `swarms/portfolio_review/` with three files.

| File | Purpose |
|---|---|
| `swarm.yaml` | the definition: meta-agent, rosters, deliverable, budget |
| `meta.md` | the briefing the meta-agent receives. Editable; delete it to use the generated default. |
| `roles/<role>.md` | the orchestrator persona: route, dispatch, attribute, never fabricate |

## The definition

```yaml
name: portfolio_review
description: Cross-domain brand risk review
role: intel_orchestrator

agents: [rx-sales, market-voice]
mcp_servers: [lab]
skills: [a2a_consult, grounded_analysis]

deliverable: swarm_report.md
max_attempts: 2

budget:
  tool_calls: 120
  consults: 6

vars:
  region: EMEA
```

`name` must be lowercase and must match the directory name. `role` may not be a
pipeline-orchestration role: a swarm's meta-agent runs the work itself rather
than driving a step pipeline. The complete key-by-key schema is in the
[swarm.yaml reference](../07-reference/03-swarm-yaml.md).

## Rosters

`agents`, `mcp_servers` and `skills` are rosters, and each is three-valued.

| Declaration | Grant |
|---|---|
| key omitted | everything of that kind available to the workspace |
| explicit list | exactly the named entries |
| empty list | nothing of that kind |

A roster is a control, not a hint. Only granted external agents are placed in
the meta-agent's catalog, and only granted MCP servers appear in the run's
configuration. A capability that is not granted is not reachable, whatever the
meta-agent decides.

State the roster explicitly on any swarm that will run against production data.
An omitted key grants every capability the workspace has now **and every one
added to it later**. The full distinction is in
[roster semantics](../07-reference/03-swarm-yaml.md#roster-semantics).

## The briefing

`meta.md` is the instruction the meta-agent receives at the start of the run.
It is the highest-leverage file in the definition; the roster determines what
is possible, and the briefing determines what is attempted.

State the following in it:

- **The objective**, in the terms the business would use.
- **What the finished deliverable must contain** — its sections, the questions
  it must answer, and the evidence each conclusion requires.
- **Attribution.** Every figure must name the agent or tool it came from.
- **Failure conduct.** A capability that fails is to be named in the
  deliverable, not replaced with an estimate.
- **Any ordering that is genuinely required.** Where one result is a
  precondition for another, state the dependency rather than the sequence.

The briefing also requires the meta-agent to maintain a run plan as a checklist
while it works. That file is the run's checkpoint: an interrupted attempt
resumes from the work already recorded as complete rather than starting again.

## Controls and budget

| Control | Effect |
|---|---|
| `deliverable` | the file the run must produce. Missing or empty, the run fails and retries. Defaults to `swarm_report.md`. |
| `max_attempts` | how many times the run may be attempted. Defaults to 2. |
| `budget.tool_calls` | a hard ceiling on tool activity in the session. Enforced. |
| `budget.consults` | the dispatch allowance stated in the briefing, and reported against afterwards. |

The two budget keys differ in kind, and the difference matters when you set
them.

- **`budget.tool_calls` is enforced.** It becomes the session's tool-iteration
  ceiling. A swarm cannot exceed it, which is what prevents an open-ended
  investigation from consuming an unbounded amount of work. **A value below 20
  is raised to 20**, because the run's driver shares the same ceiling and
  cannot complete the run below it.
- **`budget.consults` is a contract stated in the briefing.** The meta-agent is
  told its allowance and is expected to work within it. Where the allowance is
  exceeded, the run's record reports it, so the definition can be corrected.

Set `tool_calls` from the work the goal genuinely requires. A ceiling set too
low ends the run before the deliverable is complete, and the artifact gate then
records the run as failed.

## Validate, preview, run

```bash
aicore lint-swarm portfolio_review
aicore lint-swarm --all --strict
```

The linter reports unknown keys, rosters naming entries that do not resolve,
and definitions that cannot be compiled into a run. It exits non-zero on error;
`--strict` makes warnings fail as well, and `--json` produces machine-readable
findings.

```bash
aicore run-swarm portfolio_review --dry-run \
    --goal "Assess ORALIA risk for 2026-Q3"
```

`--dry-run` prints the resolved roster and the compiled run shape without
executing anything. Use it to confirm that the capabilities you intended to
grant are the ones the meta-agent will receive.

```bash
aicore run-swarm portfolio_review \
    --goal "Assess ORALIA risk across sales, sentiment and supply for 2026-Q3"
```

| Option | Effect |
|---|---|
| `--goal` | required; the objective for this run |
| `--var KEY=VALUE` | override a `vars:` entry for this run; repeatable |
| `--json` | run in the background and return the run identifier |
| `--workspace` | the workspace the run belongs to |
| `--project-dir` | the directory the run operates on |

`aicore list-swarms` shows every swarm resolvable in the current environment.

## What a swarm inherits

A swarm run is a single-step run. Everything that applies to a workflow run
applies to it without exception: durable state, bounded retries, absorption of
transient failures, the fail-closed artifact gate, the recorded execution, and
follow-up questioning after completion.

The deliverable is written to the run's output directory and read with
`aicore run-output`, exactly as a workflow's deliverables are.

## Grant capabilities to the swarm

A swarm is only as capable as its roster. The three kinds of capability are
declared elsewhere and named here:

| To grant | Declare it as | Name it in |
|---|---|---|
| a connected service's tools | [an MCP server](./04-mcp-tools.md) | `mcp_servers` |
| another team's agent | [an external agent](./05-external-agents.md) | `agents` |
| judgment your workspace owns | [a skill](./01-agents-and-skills.md) | `skills` |

Command-line tools installed in the workspace are available to the meta-agent
without being named in a roster, as they are to any agent.

## Related pages

- [Workflows](./06-workflows.md)
- [swarm.yaml reference](../07-reference/03-swarm-yaml.md)
- [Getting started: swarms](../02-getting-started/code-first/07-example-swarm.md)

**Next:** [Running a solution](../04-running-solutions/01-running-a-solution.md).
