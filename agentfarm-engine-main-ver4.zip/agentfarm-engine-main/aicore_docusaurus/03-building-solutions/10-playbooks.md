---
sidebar_position: 10
title: Playbooks
description: A playbook is a business operating procedure the platform executes as data. It is authored in business language, compiled into a validated executable form, approved by a person, and revised without a release.
---

# Playbooks

A **playbook** is a business operating procedure: the situation that starts it,
the goal, the roles involved, the time windows, the escalation order, and the
policy for every outcome. It is authored by the business, compiled into a
validated executable form, and approved by a person before it can run.

A playbook is data, not code. Creating one, amending one, or taking one out of
service is a catalog change; none of them requires a release.

## Playbook, workflow, skill

These three artifacts are frequently confused. They are owned by different
people and enforced differently.

| Artifact | Answers | Owned by | Enforcement |
|---|---|---|---|
| **Playbook** | What happens, when, for whom | The business, through an approval gate | Compiles into rules the engine refuses to break |
| **Workflow** | How one unit of work executes | Solution engineering | Engine-enforced steps, gates and retries |
| **Skill** | How an agent conducts itself | The team that owns the agent | Advisory |

The placement rule follows from the last column: **a rule that must always hold
does not belong in a skill.** A skill shapes judgement and is followed almost
always, which is the wrong standard for a recipient restriction or a mandatory
pause. Such rules belong in the playbook, where they compile into structure the
engine enforces.

## Two kinds of playbook

| Species | Shape | Executed as |
|---|---|---|
| **Pipeline** | Minutes-scale, sequential, data-driven, ends at a human validation gate | One workflow per stage, split at the gate |
| **Case** | Days-to-weeks, event- and timer-driven, escalation ladders | Durable case records driven by a rulebook — see [Case playbooks](./11-case-playbooks.md) |

`policy.species` in the play document declares which. A case playbook also
names its rulebook family in `policy.template`.

## See what is already in service

Check the catalog before authoring. A new playbook whose trigger phrase
overlaps an existing one produces an ambiguous match, and matching then
refuses to choose rather than running the wrong procedure.

```bash
iof-plays status                       # operational playbooks and pending stagings, as counts
iof-plays list
iof-plays show PLAY-COVERAGE-GAP-001
```

## Author a playbook

Start from the template. It is rendered from what the workspace can deliver —
how it notifies people, the analyses and reports it can run, the records a
step can be verified against — so that what the playbook asks for is
executable when it is approved:

```bash
iof-plays template --out PLAYBOOK-TEMPLATE.md
```

Write the procedure in business language under the template's headings. The
compiler reads what the business wrote, so state each step, each role, each
window, and each closing condition explicitly. Where a step needs something
the template does not list, write it anyway and end the sentence with
`[capability request]`: the step is compiled as a notice to the role who
would perform it by hand, and the request is recorded (see
[Capability requests](#capability-requests)). Two additions materially
improve the result:

- **State any compliance property in one sentence** — for example, "the
  administrator is notified only after the escalation window has expired, never
  earlier". A property stated this way becomes a declared invariant, checked
  against every future revision.
- **Quote any mandated wording** for a communication. Quoted wording is
  delivered verbatim; unquoted wording is composed to meet the intent stated in
  the step.

Anything the prose leaves ambiguous — a window that contradicts an earlier
step, an escalation with no named recipient, a reference to a step that does
not exist — is recorded as an assumption for the reviewer rather than silently
resolved.

## Compile, review, approve

Compilation drafts the executable form and stages it for a person. Nothing
reaches the catalog until that person approves it.

```bash
aicore run playbook_compile --goal "Onboard this business playbook: <the prose>" --json
```

The run produces the source prose, a draft rulebook, a draft play document, and
a notes file listing every assumption. It then validates all of it. A draft
that fails validation is refused with the exact defects named, corrected, and
re-staged within the same run; a run that cannot produce a validated staging
fails rather than delivering an unusable draft.

**Compilation runs in the background and takes several minutes.** The command
returns a run id immediately. Track it, because a compilation still running and
one that failed both leave the review queue empty:

```bash
aicore status --run-id <run-id>
```

Review and decide:

```bash
iof-plays compile-pending --json
iof-plays compile-show CMP-0001
iof-plays compile-approve CMP-0001 --as "<reviewer name>"
iof-plays compile-reject  CMP-0001 --as "<reviewer name>" --reason "<what to change>"
```

`compile-show` renders what a business reviewer needs, beside the original
prose: the rule table, the delivery contract for every action, a simulation of
what happens when nobody responds and only the clock fires, the declared
invariants, the criteria by which a written reply becomes an event, structural
warnings, and the compiler's assumptions.

The review is captured when the compilation is staged, so it shows what the
reviewer decided on rather than a re-rendering of the current catalog.

`compile-history` lists every prior compilation of a playbook with each
rejection's reason. A rejection is binding on the next draft: the compiler
reads the history before drafting and states, for each prior rejection, which
decision in the new draft answers it.

```bash
iof-plays compile-history TPL-BRAND-SHARE-LOSS
```

Approval re-validates both documents at the moment of decision and then writes
the rulebook and the play. A draft that has become unsound since it was staged
is refused; reject it and compile again.

Approving with `--status draft` registers the playbook without making it
matchable. Going live afterwards is a status change, not a new compilation.

## Author without compilation

A play and its rulebook can also be written directly as JSON documents and
installed with the catalog commands. The validation is identical.

```bash
iof-case rulebook validate --file tpl-my-family.json
iof-case rulebook put      --file tpl-my-family.json --as "<reviewer name>"
iof-plays put              --file play-my-play.json --status draft
```

### The play document

The rulebook says how a case advances. The play binds it to a trigger, supplies
the parameter overrides, and carries the business text a reviewer reads.

```jsonc
{
  "play_id": "PLAY-BRAND-SHARE-LOSS-001",
  "name": "Brand Share Loss Response",
  "trigger_type": "Brand Share Loss",
  "goal": "Turn a detected share loss into an owned, time-bound response.",
  "policy": {
    "species": "case",
    "template": "TPL-BRAND-SHARE-LOSS",
    "triage_sla_days": 2,
    "trigger_synonyms": ["losing share", "market share drop"]
  },
  "workflow_generate": "case_action",
  "params_needed": ["brand", "market"],
  "body_md": "# Playbook: Brand Share Loss Response\n\n## Goal\n..."
}
```

| Key | Required | Purpose |
|---|---|---|
| `play_id` | Yes | Catalog identity. Amending reuses it and increments the version |
| `name` · `goal` | Yes | What a reviewer and a requester see |
| `trigger_type` | Yes | The phrase that starts it — see [Triggers and matching](#triggers-and-matching) |
| `policy` | Yes | `species`, and for a case play `template`; parameter overrides; `trigger_synonyms` |
| `params_needed` | Yes | The values a request must supply before a case can open |
| `body_md` | Yes | The procedure in business language. This is the text a reviewer approves |
| `workflow_generate` | Yes | The workflow the play commissions. It must resolve to a workflow the workspace provides. A case play names `case_action` |
| `workflow_deliver` | No | A second workflow for a pipeline play's delivery stage |

Every key in the table above is required except where noted; a document missing
one is refused by `iof-plays put` with the key named. A case play is refused
unless `policy.template` names a rulebook that is already installed.

:::note `workflow_generate` and `policy.workflow_action` are the same field
A case play may name its action workflow either way. Prefer
`workflow_generate`: it is what the catalog stores and what `iof-plays show`
and `match` report back.
:::

A case playbook whose `policy.template` names a rulebook that does not exist is
refused: install the rulebook first. A playbook whose `workflow_generate` or
`workflow_deliver` names a workflow the workspace does not provide is refused
the same way, at `put`, at `compile-stage` and again at `compile-approve`; the
refusal lists the workflows that do resolve and suggests the nearest name.

## Triggers and matching

A playbook declares the phrase that starts it in `trigger_type`, and any number
of alternatives in `policy.trigger_synonyms`. Matching is deterministic over
operational playbooks:

```bash
iof-plays match --trigger "<the requester's message>" --json
```

| Result | Meaning | Required response |
|---|---|---|
| `matched: true` | Exactly one playbook claims the text | Proceed; the response carries the full policy |
| `ambiguous: true` | Several claim it | Ask which applies. Selecting one silently executes the wrong procedure correctly |
| `matched: false` | None claim it. The request is recorded | Restate the request using one of the returned `known_triggers`, or stop |

Declare synonyms for the phrases requesters actually use. A playbook with no
synonyms matches only its exact trigger phrase, and a paraphrased request will
not find it.

### Requests no playbook covers

A request that matches no playbook is recorded with the requester's words, the
triggers known at the time, who asked (`--requester`) and when. Read the list
back, most asked first:

```bash
iof-plays unmatched
iof-plays unmatched --json --limit 20
```

This list is the evidence for which playbook to write next. To check a phrase
without recording it, pass `--no-record` to `match`.

### Capability requests

A step the author marked `[capability request]`, or one the compiler could not
map to anything the workspace provides, is recorded when the draft is staged.
The reviewer sees every request in the compilation review, and the list is
read back with:

```bash
iof-plays capability-requests
iof-plays capability-requests --resolve 3 --as "<name>" --reason "shipped as a workflow"
```

A draft that records fewer requests than the author marked is refused at
staging: a request dropped at compile time is a capability the business never
learns it lacks. Together with the unmatched requests above, this list is
what the workspace builds next.

## Actions that run a workflow

A step of the procedure can be work the platform already performs — an
analysis, a ranking, a report — rather than a message to a person. The
compiler is given the list of workflows the workspace provides and maps such
a step to one of them; it never names a workflow that is not on the list. In
the compiled form the action reads:

```json
"run_share_analysis": {
  "side_effects": true,
  "delivery": "workflow",
  "workflow": "brand_share_response",
  "goal_hint": "Establish whether the share loss for <item> in <group> is real, isolated and explained",
  "completion_event": "analysis_complete"
}
```

When the rule fires, the platform starts the run and records it against the
case. When the run finishes, its result arrives at the case as the declared
event, and the rule for that event decides what happens next. A run that
fails arrives as `system_error`. The reviewer sees every workflow a playbook
is authorised to run before approving it.

Three checks apply at compile and install time: the workflow must exist in
the workspace (the refusal names the ones that do), the outcome events must
be declared, and the state the rule moves to must have a rule for the
completion event — a run may not finish into nothing.

```bash
iof-plays workflows            # the workflows a playbook may name
```

## What the workspace declares

A playbook's actions reach the world through tools the workspace declares,
never through tools named in the playbook. `deliveries.yaml` says which tool
sends an email, which creates a monitoring task, and which tools a
verification may read from. It is resolved from three places, the most
explicit winning: `IOF_CASE_DELIVERIES` as a JSON object in the deployment's
environment; the workspace's own file at
`~/.iobot/workspaces/<code>/deliveries.yaml`; and the `deliveries.yaml` in the
workspace package, which the scaffold writes beside `tools.yaml`:

```yaml
email:
  tool: mcp_crm_send_field_email
  recipients: [Brand Marketer, Brand Lead, Marketing Director]
monitoring_task:
  tool: mcp_crm_create_monitoring_task
verification:
  tools: [mcp_crm_get_rep_alignment]
```

`recipients` lists the roles the workspace can notify. When it is present, a
playbook addressing any other role is refused with the nearest declared name
suggested, and the authoring template lists exactly those roles. When it is
absent, any role is accepted.

A playbook whose action delivers by a kind the workspace declares no tool for
is refused at install, naming the kinds it does declare. `iof-case deliveries`
shows what the workspace resolves.

## Amend a playbook

Amendment is the same path as authoring: compile the revised prose, review, and
approve. Each approval increments the version, records the approver, and takes
effect immediately for every future decision, including on cases already open.

Two properties bound what an amendment can do to work in flight:

- **Structure is live.** A case decides against the current rulebook revision,
  so a new or rewired step applies to open cases at their next event.
- **Parameters are frozen.** Roles and windows are captured when a case opens,
  so amending them never re-targets an escalation already under way.

Every ledger entry records the rulebook revision that decided it.

A value the play already owns — a window, a role, a synonym — can be changed
without compiling:

```bash
iof-plays amend PLAY-BRAND-SHARE-LOSS-001 --set triage_sla_days=3 --as "<name>"
iof-plays amend PLAY-BRAND-SHARE-LOSS-001 --add-synonym "share erosion" --as "<name>"
```

`--set` accepts only a key the play or its rulebook's `default_params` already
holds. A new key, or a structural field — the species, the template, the action
workflow, the parameters a request must supply — is refused; structure changes
go through compilation.

## Retire a playbook

```bash
iof-plays put --file play-my-play.json --status retired
```

A retired playbook stops matching new requests. Cases already open continue
under the rulebook they were opened with; retiring a playbook does not close
them.

**Next:** [Case playbooks](./11-case-playbooks.md) — the rulebook a case playbook runs on.

## Related pages

- [Operating playbooks](../04-running-solutions/08-operating-playbooks.md) — opening cases, relaying events, the scheduler and the ledger
- [Workflows](./06-workflows.md) — the unit of work a playbook step can commission
- [Environment variables](../07-reference/07-environment-variables.md) — delivery, dispatch and timer settings
