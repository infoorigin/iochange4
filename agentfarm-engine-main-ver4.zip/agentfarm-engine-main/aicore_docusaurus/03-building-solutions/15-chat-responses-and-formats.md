---
sidebar_position: 15
title: Chat responses and output formats
description: Talk to an always-available agent over HTTP, keep a conversation on one thread, and control the shape of every reply - the agent's own voice, the built-in response envelope, or an output format you declare yourself.
---

# Chat responses and output formats

An always-available agent answers requests directly, with no run of its own.
This page covers how a caller reaches one, how a conversation stays on one
thread, and how to control the shape of what comes back.

Every route on this page — chat, streaming, history — is served by the
running service. With the service down, a call is refused at the socket:
a connection-refused response means the service is not running, not that
the route or the agent is missing. Starting the service, and exposing an
agent to it, is covered in
[Deploying as a service](../04-running-solutions/04-deploying-as-a-service.md);
the Agent2Agent surface is [Exposing your agents](./08-exposing-your-agents.md).

## Sending a message

```bash
curl -X POST http://127.0.0.1:8111/api/chat/general \
  -H "Content-Type: application/json" \
  -d '{"content": "Which vendors renew this quarter?",
       "agent": "advisor",
       "user_id": "alice"}'
```

| Field | Meaning |
|---|---|
| `content` | The user's message. An empty or whitespace-only value is refused with 400 before any model call. |
| `agent` | The role to address. A role the deployment does not serve is refused with 400 naming the pack that would provide it. Omitted, the request goes to the default assistant. |
| `user_id` | The person. Attribution, message history and user-scoped memory key on it. |
| `conversation_id` | The thread. Requests carrying the same value continue one conversation; omitted, the thread falls back to `user_id`. See below. |
| `format` | The response shape. See [Controlling the shape of a reply](#controlling-the-shape-of-a-reply). |
| `composition_mode` | How much the agent condenses its answer. Omitted, the agent's own instructions govern. |
| `workspace` | The workspace the caller expects. A service serves one workspace; a request naming a different one is refused with 409. |

The path segment (`general` above) is a namespace of the caller's choosing.
It scopes the conversation alongside the agent and the user.

## Multi-turn conversations

**The person and the thread are separate fields.** `user_id` identifies the
person: attribution, message history and user-scoped memory key on it,
whichever conversation is talking. `conversation_id` names the thread:
requests carrying the same `agent`, the same path segment and the same
`conversation_id` continue one conversation — the agent sees the earlier
turns and answers in their context. Nothing else needs to be sent — no
transcript, no history, no session token.

One person holds any number of parallel threads. Each has its own context;
none reads another's turns.

```bash
# Thread "renewals" — establish context
-d '{"content":"I look after the EMEA vendor portfolio.",
     "agent":"advisor","user_id":"alice","conversation_id":"renewals"}'

# Same thread — the agent already knows the region
-d '{"content":"Which of my contracts renew this quarter?",
     "agent":"advisor","user_id":"alice","conversation_id":"renewals"}'

# A second thread for the same person — fresh context, in parallel
-d '{"content":"Assess the pricing exposure on APAC.",
     "agent":"advisor","user_id":"alice","conversation_id":"pricing"}'
```

`conversation_id` omitted, the thread falls back to `user_id` — one
conversation per person, so a caller that sends only `user_id` behaves
exactly as before. Sent empty or whitespace-only, the request is refused
with 400 before any model call: explicit-and-blank is a caller defect, not
a default.

A conversation grows for as long as the caller keeps using the same
thread. There is no turn limit to configure, and a long thread does not
need to be re-established after a pause.

### What carries across turns, and what does not

| Carries | Does not carry |
|---|---|
| Everything said earlier in this thread | The turns of another thread — including the same person's other threads |
| The agent's own instructions and persona | Another agent's conversations |
| A fact stated in turn 1, still available many turns later | A caller's private context, unless stated in this thread |

A conversation survives a restart of the service: the thread is held in the
agent's workspace, not in the process. A caller who continues a thread after a
restart is answered in context.

**The thread is the conversation's memory.** An agent remembers everything in
the thread it is answering. It does not read another caller's conversation.

Durable facts about the workspace are a separate tier: a completed
conversation's turns are read afterwards, and a fact worth keeping can become
part of [workspace memory](./14-workspace-memory.md), which every agent in the
workspace then sees. That is governed and reviewable, and it is scoped to
facts about the workspace's world — not a transcript of the conversation, and
not a substitute for stating a caller's own context in the thread that needs
it.

### Changing the response shape mid-conversation

`format` and `composition_mode` are per request. Changing either does not
start a new thread or discard what came before: a conversation can take a
structured answer in the middle and return to a written reply afterwards.

```bash
# a written reply, then a structured answer, then a written reply - one thread
-d '{"content":"What is my largest exposure?","agent":"advisor","user_id":"alice"}'
-d '{"content":"Give me that as data.","agent":"advisor","user_id":"alice",
     "format":"viz_envelope"}'
-d '{"content":"Why is it the largest?","agent":"advisor","user_id":"alice"}'
```

The third turn answers with the first two in context.

### Concurrency on one thread

Turns on the same thread are processed one at a time, in the order they
arrive, so two requests sent together on one `conversation_id` cannot
interleave or corrupt the conversation. Turns on **different** threads run
concurrently — a person's parallel conversations do not queue behind each
other.

### Streaming a reply

Every chat route has a streaming sibling: `POST /api/chat/<namespace>/stream`
runs the same turn — same body, same thread rules, same formats — delivered
as Server-Sent Events. A caller switches transport without changing anything
else.

| Event | Payload |
|---|---|
| `status` | A tool action as the agent works — the same line a polling client reads back as a thought row. |
| `delta` | Model text as it is produced. |
| `message` | The complete reply — exactly the body the non-streaming endpoint returns. |
| `done` | End of turn. |

Read the stream with a client that does not buffer (`curl -N`; in a browser,
`fetch` with `response.body.getReader()` — `EventSource` only issues GET and
cannot call this route). A refusal raised before the turn starts — empty
content, unknown format, empty `conversation_id` — is an ordinary HTTP
status code, not a stream.

### Reading a conversation back

Every turn is recorded server-side, so a client re-renders a conversation
after a reload or on another instance without keeping its own transcript:

```bash
GET /api/chat/<namespace>/messages?user_id=alice&conversation_id=renewals
```

`conversation_id` narrows the history to one thread; without it, every
thread the person holds is returned interleaved. Rows carry `source`
(`user` or `agent`) and `msg_type` — render `message` rows as the
conversation and `thought` rows as the agent's working trail.

### Multi-turn over the Agent2Agent surface

A caller using [the A2A surface](./08-exposing-your-agents.md) keeps a
conversation by reusing the `contextId` from the previous response. Omitting
it starts a new conversation — no error is raised, so a caller that does not
carry the value forward silently loses continuity.

## Controlling the shape of a reply

Three levels, in order of increasing control.

### The agent's own voice (the default)

With no `format` and no `composition_mode`, the agent answers according to its
own instructions — the persona and rules its author wrote. Nothing is added to
the request. An agent instructed to open with a greeting and sign its replies
does so.

Set `composition_mode` to `"smart"` for terse answers (a scalar question gets
the value and a one-line evidence tag), `"none"` for minimal output, or
`"always"` to leave composition to the agent. Setting any value overrides the
agent's own instructions about verbosity for that turn.

### The response envelope

`format: "viz_envelope"` requests the built-in response envelope: exactly one fenced
JSON block and nothing outside it.

```json
{
  "schema": "v1",
  "answer":   "<one-line answer, or null>",
  "data":     { "type": "scalar|table|list|text", "columns": [], "rows": [] },
  "insight":  "<one-paragraph interpretation, or null>",
  "viz_hint": { "chart": "bar", "category": "<column>", "measure": "<column>" },
  "follow_up_chips": ["<short next question>"],
  "evidence": { "sources": [], "queries": [], "trust": "high|medium|low" }
}
```

Every top-level field is present; unused ones are the literal `null`. Values
are raw — numbers unquoted, no markup inside strings — because the client
renders them. The reply carries the parsed envelope alongside the text.

The message may name the fields it wants — `"fields": ["data", "insight"]` —
and every other field comes back `null`.

Some agents are built to emit the envelope on every reply. Asking such an
agent for a different format is refused with 409: two conflicting format
instructions in one prompt produce unreliable output, so the request is
refused rather than answered unpredictably.

### An output format you declare

A solution can define its own response shape. Declare it in a skill in the
agent's workspace:

```markdown
---
name: brief_card
description: "Brief-card output format: headline, points, confidence."
output_format: brief_card
---

Respond as a brief card: one headline, two to four points, and your
confidence.

```json
{"type": "object",
 "required": ["headline", "points", "confidence"],
 "properties": {"headline": {"type": "string"},
                "points": {"type": "array", "items": {"type": "string"}},
                "confidence": {"enum": ["high", "medium", "low"]}}}
```
```

Three parts, each required for a different reason:

- **`output_format: <name>`** in the frontmatter names the format. This is the
  value a caller passes in `format`.
- **The body** is the instruction the agent receives when a request names this
  format, and only then. The skill governs no other turn.
- **The fenced JSON Schema block** is the contract the reply is checked
  against. A format declared without one is accepted, but replies in it are
  not validated — the guarantees below do not apply.

Request it by name:

```bash
-d '{"content": "Assess this renewal.", "agent": "advisor", "user_id": "alice",
     "format": "brief_card"}'
```

The reply carries `format` and `format_validation` alongside the parsed
payload.

**What the service guarantees for a declared format.** The reply is extracted
from the response, validated against the format's schema, and — when it does
not conform — the agent is asked once to correct it, with the specific
violations named. A correction that is not an improvement is discarded and the
original is returned with the violations reported in `format_validation`, so a
caller always learns whether the payload conformed. Text outside the fenced
block counts as a violation.

An agent may hold several formats. The caller chooses one per request; the
same agent answers in whichever shape was named.

## Errors a caller must handle

| Response | Meaning |
|---|---|
| 400, empty content | The message was empty or whitespace. No model call was made. |
| 400, empty `conversation_id` | The field was sent empty or whitespace-only. Send a stable thread id, or omit the field to thread by `user_id`. No model call was made. |
| 400, unknown format | The named format is not declared for this agent. The message lists the formats that are. A format declared while the service is running is not visible to an already-warmed agent until the service restarts. |
| 400, unknown agent | The deployment does not serve that role. |
| 409, workspace mismatch | The service serves a different workspace than the request named. |
| 409, conflicting format | The agent is built to emit the response envelope; request `viz_envelope`, or address an agent without that contract. |
| 422 | The request body is not valid JSON, or a required field is missing. |

Under a configured concurrency cap, a request that waits longer than the queue
timeout is answered with an `error` field rather than a reply. Check for
`error` before rendering `content`.

## Verify

```bash
# the agent answers in its own voice, as written text
curl -s -X POST http://127.0.0.1:8111/api/chat/general \
  -H "Content-Type: application/json" \
  -d '{"content":"Introduce yourself.","agent":"advisor","user_id":"check"}'

# the same thread remembers
curl -s -X POST http://127.0.0.1:8111/api/chat/general \
  -H "Content-Type: application/json" \
  -d '{"content":"What did I just ask you?","agent":"advisor","user_id":"check"}'

# a declared format conforms
curl -s -X POST http://127.0.0.1:8111/api/chat/general \
  -H "Content-Type: application/json" \
  -d '{"content":"Assess this renewal.","agent":"advisor","user_id":"check",
       "format":"brief_card"}'
```

The first reply is written in the agent's own voice. The second refers to the
first. The third carries `format_validation` reporting a conforming payload.

## Related pages

- [Agents and skills](./01-agents-and-skills.md) — authoring the agent and the
  skills a format skill sits beside.
- [Deploying as a service](../04-running-solutions/04-deploying-as-a-service.md)
  — starting the service and pre-warming always-available agents.
- [Exposing your agents](./08-exposing-your-agents.md) — the Agent2Agent
  surface for external callers.
- [Securing the service](../04-running-solutions/05-securing-the-service.md) —
  authentication on these routes.
