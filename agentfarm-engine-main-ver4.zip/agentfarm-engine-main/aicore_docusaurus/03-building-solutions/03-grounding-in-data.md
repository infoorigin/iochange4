---
sidebar_position: 3
title: Grounding agents in your data
description: A data-driven solution gives its agents catalogued, queryable access to structured data, so that every figure an agent reports traces to a query it ran rather than to an estimate.
---

# Grounding agents in your data

A business solution reasons over data. Left to describe a dataset from its own
knowledge, an agent produces figures that are plausible and occasionally
invented, and the two are indistinguishable in the output. Grounding removes the
guesswork: the agent is given a **catalogue** of what data exists and a **tool**
that runs real queries against it, and its instructions require every figure to
carry the query that produced it.

Three parts work together:

| Part | Role |
|---|---|
| The data catalog (`catalog.yaml`) | declares the entities an agent may query, their columns and measures, described honestly |
| The database declaration (`databases.yml`) | names each data source and how to reach it |
| The `iof-query` tool | executes validated read-only queries and returns grounded rows |

All three are bundled with the workflow that uses them, under its `metadata/`
directory, so the data an agent sees is fixed for the duration of a run.

## The data catalog

`catalog.yaml` is the single source of truth for what an agent may query. It
names each **entity**, its **dimensions** and **measures**, and describes each one
in plain language — cardinality, ranges, totals, the meaning of a code. An agent
reads the catalog before it queries, so a description that is vague or wrong
produces a query that is vague or wrong.

```yaml
entities:
  - name: claims
    database: claims_dw
    table: "finance.claims"
    grain: "One row per submitted claim"
    semantic: >
      ~120,000 rows, Q1–Q3 of the current year.
      status is one of submitted | approved | denied | pending.
    dimensions:
      - {name: claim_id, type: string, description: "unique claim identifier"}
      - {name: region,   type: string, description: "one of EMEA, NA, APAC, LATAM"}
      - {name: status,   type: string, description: "current disposition"}
    measures:
      - {name: amount_usd,   type: number, description: "claim value in USD"}
      - {name: total_amount, sql: "SUM(amount_usd)", description: "claim value, summed"}
```

`database` names an entry in `databases.yml`; `iof-query --db` serves the
entities that name it. The full schema — `databases`, `source_path` for a
bundled file, `type`, `trust` and `freshness` — is in the
[data catalog reference](../07-reference/06-data-catalog.md).

`iof-query` rejects a query that would return more than `--max-rows` rows
(default 50) and suggests a `GROUP BY`, which keeps a large table from being
read row by row into the agent's context; `--max-rows 0` lifts the limit for a
small reference table. `--list-entities` reports each entity's row count and
whether, under that limit, it can be read raw (`raw_ok`) or only aggregated
(`aggregate_only`).

Describe with real facts — counts, ranges, the set a code is drawn from. Do not
add example queries or instructions on how to phrase a query; those bias the
agent toward one shape and go stale. The catalog states what the data **is**;
the agent decides how to ask.

## Declaring the data source

`databases.yml`, beside the catalog, names each database and how to connect to
it. Credentials are referenced, never written in the file.

```yaml
databases:
  claims_warehouse:
    type: duckdb
    path: "${CLAIMS_DB_PATH}"
  reporting:
    type: postgresql
    url: "${REPORTING_DSN}"
```

A value written as `${VAR}` is resolved from the environment at query time;
`${VAR:-default}` supplies a fallback for an unset or empty variable, and a
plain `${VAR}` that is unset fails the query rather than connecting elsewhere.
That failure is raised by the backend that reads the key, so an unset variable
on a key the chosen backend never reads is not an error: one file can declare
`type: ${HUB_TYPE:-postgres}` with a `schema` that Postgres requires and a
SQLite developer hub ignores. `--list-databases` reports an unset variable the
declared backend needs before any query runs.
No other substitution is applied inside the file: a path is written in full or
as a `${VAR}` reference. The file holds the reference; the secret lives in the
workspace environment.

A `postgres` or `redshift` entry takes either a `url` or the discrete `host`,
`port`, `database`, `user` and `password` keys, and an optional `schema` that
is placed first on the search path and is the schema `--list-schemas`
describes. A `redshift` entry connects over TLS (`sslmode=require`) unless the
URL or an `sslmode` key says otherwise, defaults to port 5439, and uses the
engine's PostgreSQL driver; `driver: redshift_connector` selects Amazon's
driver where it is installed.

## Querying the data

`iof-query` executes **validated `SELECT` queries only** against a declared
database. It cannot write, and it rejects a query that is not a read. An agent
runs it the way an engineer would; a workflow may also run it as a deterministic
step.

```bash
# Discover what is available
iof-query --metadata-dir metadata --list-entities     # entities, row counts, query mode
iof-query --metadata-dir metadata --list-schemas --db claims_warehouse

# Run a query
iof-query --metadata-dir metadata --db claims_warehouse \
    --sql "SELECT region, SUM(amount_usd) AS total FROM claims WHERE status='approved' GROUP BY region"
```

| Option | Effect |
|---|---|
| `--metadata-dir` | the directory holding `databases.yml` and the catalog (required) |
| `--db` | the database name from `databases.yml` |
| `--sql`, `--sql-file`, `--sql-stdin` | the query; `--sql-stdin` avoids shell-quoting of identifiers |
| `--list-databases`, `--list-schemas`, `--list-entities` | discovery, then exit |
| `--max-rows` | reject a query returning more than this many rows, with a suggestion to aggregate; keeps a run's context small |
| `--limit` | a default `LIMIT` applied when the query omits one |

A query that names a column or table the catalog does not contain is rejected
with the valid names, so an agent corrects a mistaken query in one step rather
than guessing repeatedly.

## The skills that carry the judgment

The tool executes; the **skills** decide when and how to use it. A grounded
analyst carries two:

- A **catalog-reading** skill: read `catalog.yaml` from the workflow's metadata
  before querying, and take entity and column names only from it — never guess
  a schema.
- A **grounded-analysis** skill: every figure in the deliverable cites the
  entity it came from, the query that produced it, and the row count; recency is
  computed against today's date; a gap is stated as "not available in
  `<entity>`" rather than filled with an estimate.

These are assigned to the agent, or named in a workflow step's `skills:` list.
Because the catalog is supplied by the workflow and read at run time, one
grounded analyst serves many datasets: the same agent analyses a claims
warehouse in one workflow and a sales extract in another, with no change to the
agent.

## Bundling with a workflow

A workflow carries its data context in its own `metadata/` directory:

```
solutions/claims/workflows/claims_triage/
  workflow.yaml
  metadata/
    catalog.yaml
    databases.yml
    data/
      claims.duckdb
  steps/
```

At run creation the platform freezes this directory into the run's snapshot, and
`{{metadata_dir}}` in a step prompt resolves to it. The catalogue an agent reads
and the data it queries are therefore fixed for the run and identical on a
re-run.

## Verify

```bash
iof-query --metadata-dir metadata --list-entities    # the catalog loads and lists its entities
iof-query --metadata-dir metadata --db <name> --sql "SELECT 1"   # the database is reachable
```

If an agent reports a figure with no query behind it, the grounding discipline
has not been applied: confirm the analyst carries the grounded-analysis skill
and that the step prompt requires every figure to cite its source.

## Related pages

- [Agents and skills](./01-agents-and-skills.md) — assigning the grounding skills
- [Command-line tools](./02-command-line-tools.md) — how a tool reaches an agent
- [Workflows](./06-workflows.md) — bundling `metadata/` and reading `{{metadata_dir}}`
- [Data catalog reference](../07-reference/06-data-catalog.md) — the `catalog.yaml` and `databases.yml` schemas

**Next:** [MCP tools](./04-mcp-tools.md).
