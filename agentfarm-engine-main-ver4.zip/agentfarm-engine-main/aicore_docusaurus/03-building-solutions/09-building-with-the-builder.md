---
sidebar_position: 9
title: Cora Build (Solution Builder)
description: Cora Build is the platform's interactive solution builder - a build session in which the builder agent designs content and places it with the scaffold commands, with a live console, enforced plan and review modes, and per-turn undo.
---

# Cora Build — the solution builder

**Cora Build** is the platform's interactive solution builder. `aicore build`
opens a session with `cora_build`, the dedicated builder agent, in the
current repository. Describe what the solution
needs — an agent, a skill, a workflow, a swarm, a CLI tool — and the builder
creates it with the platform scaffold commands, writes the real content into
the files those commands created, lints what changed, and reports
`git status`. The session is local: the agent runs on this machine and no
server is contacted.

```bash
cd <solution-repo>
aicore build
```

Every command available inside a session, and every option of the command
itself, is listed with an example in
[Build session commands](../07-reference/08-build-session-commands.md).
Inside a session, `/help` prints the same list.

A build session runs against one workspace. When none is selected, an
interactive session asks — listing the existing workspaces, or creating one
through the same machinery as `aicore workspace create`. Select it ahead of
time with `--workspace <code>`, `IOF_WORKSPACE`, or `aicore workspace use`.

A new code is checked at the prompt with the rule every later command applies
to it: three to thirty-one characters, a lowercase letter followed by lowercase
letters, digits or `_`. The code becomes the package prefix of the workspace
repository, so a hyphen or a two-letter code is refused here rather than by
`aicore workspace scaffold` one command later; the refusal names the fix. When the
configured database is a shared server, the session then asks where the new
workspace should live — **local** (a SQLite file under this directory's state
directory, nothing shared; the recommended choice for trying things out) or
**shared** (the configured server, named in the prompt, visible to other
people). Choosing local turns local mode on for the directory before the
workspace is created, which is the only order in which that choice can take
effect (`aicore local` has the detail). A SQLite database asks nothing.

The builder observes hard limits. It never uses `--force`, never commits, and
never writes outside the session's repository. Content is placed only into
files a scaffold command created.

## Platforms

A build session runs on Linux, macOS and Windows, with the same commands and
the same behaviour. Three differences are handled by the session rather than
by the reader, and are stated here because they change what a repository may
contain without consequence:

| Condition | Behaviour |
|---|---|
| A file the session must revert is read-only | The permission is widened for the revert and the file keeps every other permission it had. An executable stays executable. |
| A filename carries accents, a space, or a backslash | Checkpoints, `/diff` and `/undo` handle it unchanged. On macOS, where the filesystem stores names decomposed, the composed and decomposed spellings of one name are treated as one file. |
| Two directory paths differ only in capitalisation | Where the filesystem treats them as one directory they share one set of conversations; where it treats them as two they keep separate ones. The session measures the filesystem rather than assuming. |

Paths in this page are written in POSIX form. On Windows, use the platform's
own form — `%USERPROFILE%\solution` for `~/solution`, and
`.venv\Scripts\activate` for `source .venv/bin/activate`.

A command that changes the Python or Node environment is confirmed
separately, whether or not approval mode is on: the session shows the exact
command and waits for a yes. This is how a new CLI tool's console script gets
installed — `pip install -e .` after `new-tool`, because pip generates the
launcher at install time and no file the builder writes can substitute for
it. A one-shot or CI run has nobody to ask, so the install is refused and the
builder reports what needed installing and why.

When you ask the builder to install something, it runs the command and the
session asks you for a yes or no before anything changes; the builder does
not decline an install on your behalf.

To keep the builder out of the environment altogether — a shared machine, or
a policy that only a person installs — set `IOF_BUILD_INSTALLS=never` before
starting the session. Every install is then refused without a prompt, the
refusal names the exact command for you to run, and the builder continues
with what is installed.

## The console

While a turn runs, the console shows the work as it happens. Each element is
produced by the harness from what it observes, not by asking the agent to
report on itself:

```text
· Found the workflow at pharma_intel_sol/. Reading its catalog and the step files.
  ● read_file: pharma_intel_sol\workflows\access_review\workflow.yaml
    ⎿ read_file: 55 line(s) - 1| name: access_review
  ● edit pharma_intel_sol\workflows\claims_watch\steps\watch.md
    - # Watch
    + # Claims Watch
✓ step 2/4 Both files written. Running lint.
38.2k/204.8k context (19%)  ·  12.1k in · 3.4k out · 84% cached · 9 calls
```

| Line | Meaning |
|---|---|
| `·` | The builder's narration: what the last result showed and what follows from it |
| `●` | A tool call, with its argument shown relative to the repository |
| `⎿` | The call's result — every completed call gets one: the first line, prefixed with a line count when there is more than one |
| `-` / `+` | An edit's old and new text, shown as the change is made |
| `…` | A truncation marker: how many further lines or edits were not shown |
| `✗` | A tool call that failed, with the error |
| `✓ step N/M` | Progress against an approved plan, ticked as each step completes |

On a console that cannot encode them, every glyph falls back to an ASCII
equivalent (`·`→`-`, `●`→`*`, `✗`→`x`, `⎿`→`>`, `✓`→`*`, `…`→`...`) rather
than failing the render.

The last line of a turn is the meter: how full the context window is, the
turn's input and output tokens, the share served from cache, and the number
of model calls. The figures are read from the runtime's own per-call usage
records — nothing here estimates them. The context figure also rides the
status line while a long turn runs, so a filling window is visible before the
turn ends rather than only after. It is what tells you when `/compact` is
worth running.

A terminal session additionally shows a status line with the current phase,
elapsed time, the action in progress, and the cancel hint. `Ctrl+C` cancels
the current turn without ending the session; the conversation keeps every
round that completed.

## Plan, execute, review

An instruction given without `/plan` is executed in the same turn. The
builder decides reversible details itself, states each decision, and places
any remaining question at the end of the turn with the work already done;
`/undo` reverts the turn when a decision is wrong. Where the builder returns
a proposal without acting, the console reports that nothing changed and
`/go` executes the proposal — recovery is one command, not a repeated
instruction.

Three commands separate proposing, doing, and judging — and the first and
last are enforced by the harness, not requested of the model:

| Command | Behaviour |
|---|---|
| `/plan <request>` | The builder proposes a numbered plan and changes nothing. The harness enforces it: at the end of the turn the working tree is restored to the checkpoint, so a planning turn cannot leave a file behind. |
| `/go` | Execute the approved plan. Where the builder marks each completed step, the console renders the marks as ticked progress; a turn that narrates without them still executes the plan. |
| `/review` | An adversarial review of the current changes, in a separate session whose history never contains the authoring it judges. Activity streams live; the verdict — `APPROVE` or `FIX` with numbered findings — renders at the end. The tree is restored afterwards, so a review cannot alter what it judges. |

The plan and review reverts restore the whole tree to the checkpoint — they
do not distinguish who wrote a file, as `/undo` does. Neither mode is meant
to change anything, so avoid editing the repository yourself while one runs.

**This enforcement is a git operation.** Outside a git repository there is no
checkpoint to restore to, so a planning turn's writes are kept and a review
has no baseline. The session says so when it happens, and `--json` reports
`"enforced": false` — check that field before relying on plan mode being
inert.

A review finding must quote the evidence it rests on. A reviewer that cannot
run a validation command reports the command's exact output rather than a
conclusion drawn from the failure.

## Checkpoints: `/diff` and `/undo`

When the repository is under git, every acting turn records a checkpoint
before it starts. `/diff` lists the files the last turn added, modified or
deleted. Checkpoints use a throwaway index: the user's staged work is never
touched, and nothing is committed. Without git, both commands are unavailable
— and so is the plan and review enforcement above, which restores to the same
checkpoint. The session says so at startup.

`/undo` reverts the last turn — and asks before touching anything it cannot
attribute to the builder. A checkpoint diff alone cannot say who changed a
file, so the two cases are separated: paths the harness observed the builder
write are reverted without ceremony, and anything else that changed since the
turn began is listed and offered. That second list is real work — your own
edits made while the turn ran, and files a scaffold command produced through
`exec`, which only the snapshot sees. Answering no reverts the builder's
files and leaves the rest. A non-interactive session, having no one to ask,
takes that same narrower path.

Attribution is recorded with the checkpoint, so `/undo` behaves identically
in a session resumed days later in a new terminal.

A revert that cannot complete names the files it could not restore — a file
held open by another program is the usual cause — and keeps the checkpoint,
so `/undo` can be run again once the file is released.

## Conversations per repository

Each repository keeps named, continuing conversations, stored as the agent's
own session record:

| Command | Behaviour |
|---|---|
| `/new [name]` | Start a new conversation (auto-named when no name is given) |
| `/sessions` | List conversations; the active one is marked |
| `/switch <name>` | Continue a different conversation |
| `/rename <new>` | Rename the active conversation; its history is preserved |
| `/compact` | Distill the conversation into a summary and continue in a fresh one that carries it. The full original stays available under `/switch`. |
| `/transcript` | Show the tail of the active conversation as it is stored |
| `/exit` (or `/quit`) | Leave the session; the conversation is kept |

`--session <name>` selects or creates a conversation at launch;
`--new-session` starts a fresh one.

## Context: `@file`, macros, and BUILD.md

- **`@path`** in a message inlines that file's content into the turn — the
  first 8 KB of each, marked `[truncated]` beyond that, so one reference
  cannot flood a turn. The console confirms each resolved reference with its
  line count. At most three files inline per message. A reference is left as
  written, with a warning naming the reason, when the path does not exist,
  when it resolves outside the session's repository, or when the file is
  binary. A build session reads only files under the repository it opened;
  copy a file in if the builder needs it.
- **Repository macros**: a markdown file at `.aicore/commands/<name>.md`
  becomes the command `/<name>`. The file's content is sent as the message,
  with anything typed after the command appended.
- **`/remember <note>`** appends the note to the repository's
  `CORABUILD.md`, which the builder reads at the start of every session.
  Conventions recorded there outrank the builder's defaults. The scaffold
  creates the file with every new workspace and solution.
- **`CORABUILD.md` is maintained, not only appended to.** It holds the
  conventions this repository follows, the decisions already taken and the
  constraint behind each, and anything that must not be done again — not
  status, task lists or transcripts. The builder rewrites an entry that a
  later decision supersedes rather than leaving both, and keeps the file
  short enough to be read in full at the start of every session. Ask it to
  tidy the file directly when it has grown.

## One-shot and CI use

| Invocation | Behaviour |
|---|---|
| `aicore build --message "..."` | One turn, non-interactive |
| `aicore build --message "..." --plan` | One planning turn; any write is reverted |
| `aicore build --review` | Review the working tree against the last checkpoint, or against the last commit when there is none. Files not yet added to version control are included, which is most of what a build session produces. |
| `aicore build --message "/go"` | Run an in-session command non-interactively — any built-in command above, or a repository macro |
| `... --json` | Machine output: the final stdout line is a single JSON object with the reply, files changed, and whether a revert ran |

A slash command sent this way is executed by the harness, not handed to the
model — `--message "/undo"` performs the real checkpoint restore. This is
what makes the plan-then-approve loop usable from a script: `--message "..."
--plan` to propose, then `--message "/go"` to execute. Repository macros work
the same way. A leading `/` that is neither a built-in command nor a macro is
refused with exit `2` rather than sent to the builder as a message, so a
mistyped command in a script fails instead of becoming an instruction. Under
`--json` that refusal is reported as JSON on the final line, like any other
result.

`--message` with an empty value is refused with exit `2`. A caller that
passes the flag has asked for one turn, and an empty turn is not one; omit
`--message` entirely for an interactive session.

With `--json`, parse the last line of stdout; the command's own output and
any startup notices precede it. A run that fails before a turn starts — no
workspace selected, for instance — exits non-zero and prints no JSON at all,
so check the exit code before parsing.

A one-shot needs its workspace selected in advance — `--workspace <code>`,
`IOF_WORKSPACE`, or a previous `aicore workspace use`. Only an interactive
session can ask; a one-shot exits `2` naming the commands that select one
rather than guessing, which is why CI should pass `--workspace` explicitly.
Installs are refused in this mode for the same reason (see above), so
anything a build needs installed should already be in place.

## Approval mode

`aicore build --gated` (or `/gated on` in-session) pauses before every
mutating action — a command, a file write — for a y/n confirmation, showing
the first lines of any content it would write. Answering `a` disables the
gate for the rest of the session. Approval mode requires an interactive
terminal. Environment-changing installs keep their own confirmation either
way, including after `a`.

## Documentation questions

The builder answers questions about the platform documentation inside the
session — "is a swarm's budget a hard limit", "where is the skill format
defined" — by searching the official documentation at query time and citing
the exact page. The documentation set is resolved from the `AICORE_DOCS_DIR`
environment variable, or found automatically in a development checkout.

## What the session safeguards, and what it does not

A build session runs commands with your own account, in your own
environment. Its rules — no commits, no `--force`, no git command that
discards uncommitted work or rewrites history, nothing written outside
the repository through the file tools, no credential value in a file or a
command, and a separate confirmation for anything that changes the Python or
Node environment — are safeguards against mistakes. They are not a security
sandbox, and the session does not claim to contain a determined attempt to
work around them.

Two things follow. Open a build session on repositories you trust, as you
would any tool that runs commands on your behalf. And treat what the builder
reads as data you have vetted: a specification, a returned tool result or a
fetched page can contain text addressed to the assistant rather than to you,
and instructions found in content are still instructions.

Where a deployment needs containment rather than safeguards, run the session
in an isolated environment — a container, or a machine account without access
to credentials the work does not need.

### Git commands a session will not run

Alongside `git commit` and `git push`, a session refuses two further groups of
git command.

| Refused | Why |
|---|---|
| `git checkout`, `git restore`, `git switch`, `git stash` | They discard or hide uncommitted work — yours included, made while the turn ran. `/undo` reverts a turn without touching anything the builder did not write, and changing branch under a session invalidates its checkpoints. |
| `git gc`, `git prune`, `git reflog expire`, `git update-ref`, `git branch -D`, `git filter-branch`, `git worktree prune` | They collect or rewrite git objects. `/undo` and `/diff` restore from objects that no branch points at, so collecting them ends the session's undo history, and both commands then report the checkpoint as no longer present. |

`git reset`, `git clean`, `git rebase` and `git merge` are refused for the same
reasons. Where one of these commands is genuinely the right move, the builder
shows you the command and you run it yourself, which is also the moment to
decide whether the session's checkpoints still matter.

## How the builder validates its own output

The builder lints what it creates with the same validators available to any
operator: `lint-workflow`, `lint-swarm`, `lint-skill` and `lint-agent`, each
run against the content's path. A lint that cannot resolve its target is a
discovery failure, not a pass, and the builder reports it as such. The
command list is supplied to the builder by the session itself, derived from
the installed engine when the conversation starts, so it is current for that
engine and costs no turn to obtain; before using a flag its instructions do
not name, the builder consults `aicore <cmd> --help` once per command.

## Credentials never enter the repository

An MCP server or an external agent that needs a token is declared with a
`${VAR}` reference — `--header 'Authorization=Bearer ${SEARCH_TOKEN}'` — and
the builder tells you which variable to set and where (your workspace `.env`
or the deployment's environment). It does not ask for the value and does not
write that file. The session enforces this at the tool layer, not only in the
builder's instructions: a command or file write that carries a literal
credential (an API key, a JWT, a connection URL with its password, a private
key) is refused with the reference named as the fix, and a command that would
read a credential file (`.env`, keys, credential stores), dump the environment
or print a secret-bearing variable is refused likewise. A pasted token is
therefore never echoed and never lands in a file; put the value in the named
variable yourself.

**The refusal does not depend on what the session is asked.** An instruction
to skip the indirection — for a test box, for one file, for this once — is
refused the same way, and the builder answers with the `${VAR}` reference to
use instead. It holds in a one-shot `--message` run and a CI turn exactly as
it does in an interactive session, so a scripted build cannot place a value
that an interactive one would refuse.

Where a declaration references a variable, `aicore new-mcp-server` and
`aicore mcp-add` write a commented placeholder for it into the pack's
`.env.example` and into the workspace's own `.env`, and print both paths.
Uncommenting the line in the workspace file and typing the value after the `=`
is yours to do; see
[MCP tools — where the value goes](./04-mcp-tools.md#where-the-value-goes).

What the builder declares is a reference, never a value, in either of the two
supported shapes: a credential the runtime sends as a static header, or an
OAuth client-credentials grant the runtime performs and renews itself — for
which it declares the token endpoint and the client identifier and secret as
`${VAR}` references. A server that requires an interactive authorization flow,
where a person authorises the client in a browser, needs a gateway in front of
it to hold that flow; the builder states this when a request describes that
shape, and builds everything else the request asks for. See
[MCP tools](./04-mcp-tools.md) for both shapes of authentication and what to
ask a vendor for.

## MCP servers that will not answer

At the start of a session each declared remote MCP server is contacted once. A
server that does not answer — a rejected credential, a wrong URL, nothing
listening — is named on the console with the status it returned and what to do
about it:

```text
[build] MCP server search will not answer this session - unauthorized: credential refused
      the credential was refused - check the value in the workspace .env, not the declaration
      its mcp_search_* tools are unavailable; `aicore mcp-list --probe` re-checks
```

The builder is told the same thing, so a missing tool is reported rather than
explained away: without that signal an agent asked why its tools are absent
supplies a reason of its own, and that reason is a guess.

`aicore mcp-list --probe` re-checks at any time; `--probe-timeout` sets how
many seconds each server is given. Servers the runtime launches itself are not
contacted — there is nothing to reach until the session starts them.

A build session resolves MCP servers from all three declaration tiers — the
solution's own declaration, the machine configuration and the workspace — so a
server declared during a session is available to that session's agent.

## Related pages

- [MCP tools](./04-mcp-tools.md) — declaring servers, the tiers, authentication
- [Build session commands](../07-reference/08-build-session-commands.md) — every in-session command

**Next:** [Playbooks](./10-playbooks.md) — business procedures the platform executes as data.
