---
sidebar_position: 12
title: Drafts and promotion
description: A Studio edit is saved as a draft — visible only to its author, testable in isolation, and promoted into the running solution through the repository by a developer.
---

# Drafts and promotion

The running solution is the installed solution package: what an environment
executes changes only through the repository, the build and the deployment.
Editing in AI Core Harness Studio therefore never changes the running solution
directly. A save creates a **draft** — the author's private working copy of one
item — and the draft becomes running content only when a developer carries it
into the repository. This page covers what a draft is, how to test and compare
one, what a stale draft means, and the promotion procedure.

## What a draft is

A draft is one author's saved change to one item — an agent, a skill or a
workflow. It records the changed files and the solution version the change was
written against.

- **Per author, per item.** Each author holds at most one draft of an item; a
  second save replaces the first. Two authors editing the same item hold two
  independent drafts.
- **Visible only to its author.** A draft resolves in the author's own test
  sessions and draft-flagged runs, and nowhere else. Every other user, session
  and run continues to execute the installed content unchanged.
- **A new item is also a draft.** An agent, skill or workflow created in the
  Studio exists as a draft and appears only in its author's lists until it is
  promoted. It is not served to other users and it does not run in the
  environment.
- **Skill assignments follow the same rule.** Adding or removing a skill on an
  agent the solution package provides is part of the draft. Other users see the
  installed assignment until the change is promoted.

A draft cannot be created for the run-orchestration role (`project_lead`); a
save against it is refused, because that role always executes as installed.

## Saving

Saving an item in the Studio creates or updates the draft and states that it
did. The editor then shows the draft strip: the draft's state — **Draft**, **Out
of date**, **With a developer** or **Promoted** — and the actions **Try it**,
**Diff**, **Rebase**, **Discard** and **Promote**.

A workflow draft is validated when it is saved; validation findings are
reported with the save, so a definition error is visible before the draft is
tested or promoted.

## Trying a draft

**Try it** starts a conversation or a run that resolves the installed content
with the draft applied on top. The response header names the draft and the
version it was applied to, so a test result is always attributable to the
exact content that produced it.

A draft test session runs in an isolated workspace with its own blank memory.
Nothing the test session writes reaches the agent's accumulated memory, and
discarding the draft leaves nothing behind.

## Comparing a draft

**Diff** shows each changed file as a unified diff between the draft and the
content the environment currently runs. Files the draft adds and files it
deletes appear in the same view.

## Stale drafts and rebase

When the environment moves to a new version of the solution package, every
draft pinned to the previous version is marked **stale**. A stale draft is
still served only to its author — it is never served to anyone else — but the
content it was written against is no longer what runs.

For a stale draft the diff becomes three-way: the version the draft was
written against, the draft, and the current version. Files that changed in
both the draft and the new version are listed as conflicts and must be
reviewed.

**Rebase** re-pins the draft to the current version, keeping the draft's
changes. It is an explicit action; the platform never rebases a draft on the
author's behalf, because only the author can judge whether the new base
changed the meaning of the edit.

## Discarding

**Discard** withdraws the draft. The author's sessions return to the installed
content, and the draft no longer resolves anywhere.

## Promotion

A draft becomes running content through the repository — the same path as
every other change. The platform does not commit, push or open pull requests;
a draft that is never applied to the repository never changes any environment.

1. In the Studio, **Promote** shows the workspace's attached repository and
   the command to run. A patch file of the draft is available for download
   from the same dialog.
2. A developer runs, inside a checkout of the workspace repository:

   ```bash
   aicore drafts apply <id>
   ```

   The command writes the draft's files at the item's path in the package and
   marks the draft `applied`. It refuses a checkout with uncommitted changes
   at the target path unless `--force` is given, and it warns when the
   checkout's origin is not the workspace's attached repository.

   The command must be able to find the solution package — it looks for
   `aicore.solution.yaml` or `pyproject.toml` in the current directory and
   above it. When the package sits inside a larger repository, name it
   explicitly:

   ```bash
   aicore drafts apply <id> --dir path/to/solution
   ```
3. The developer reviews the change with `git diff`, commits, and opens a
   pull request. Review and merge follow the team's normal process.
4. After merge, build and deployment, the environment runs the change. The
   draft is then marked `promoted` automatically: promotion is detected when
   the running content equals the draft, never declared in advance. A draft
   is not marked promoted while the environment still runs the previous
   content.

## Working with drafts from the command line

| Command | Purpose |
|---|---|
| `aicore drafts list` | Drafts in the workspace: item, author, status, base version |
| `aicore drafts show <id>` | One draft's changed files, status and base pin |
| `aicore drafts diff <id>` | The draft against the solution content installed on this machine |
| `aicore drafts apply <id>` | Write the draft's files into the current repository checkout for review, commit and pull request. `--force` overrides the dirty-target refusal |
| `aicore drafts migrate` | Convert content created in the Studio before drafts existed into drafts. Idempotent; `--dry-run` reports what would be converted without writing |

`aicore drafts diff` compares against the content installed where the command
runs. On a machine with a different version installed than the environment,
the diff describes that machine, not the environment.

**Next:** [Command-line interface](../07-reference/01-cli.md).

## Related pages

- [Workflows](./06-workflows.md)
- [Agents and skills](./01-agents-and-skills.md)
- [Managing workspaces](../04-running-solutions/07-managing-workspaces.md)
