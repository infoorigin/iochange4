---
sidebar_position: 4
title: MCP tools
description: Connect agents to Model Context Protocol servers by declaration. The runtime registers each server's tools at session start, at one of three tiers, with no client code.
---

# MCP tools

A command-line tool is a script your workspace installs. An **MCP server** is a
capability something else hosts — an internal service, a vendor endpoint or a
community-maintained server — that speaks the Model Context Protocol.

The runtime speaks the protocol. At session start it connects each declared
server and registers every tool the server offers as `mcp_<server>_<tool>`,
alongside the agent's built-in tools. You write no client code and no wrapper.
The work is one declaration and one skill.

A server that requires a credential is authenticated in one of two ways: a
static credential the runtime sends in a header, or an OAuth 2.0
client-credentials grant the runtime performs itself, renewing the token before
it expires. Both are declared, not coded. Read
[Authentication](#authentication) before committing to a server whose access is
gated by an authorization flow.

## Declare a server

Ship the declaration with your solution:

```bash
# Stdio: the runtime launches the server as a subprocess
aicore new-mcp-server github --command npx \
    --args "-y,@modelcontextprotocol/server-github" \
    --env 'GITHUB_TOKEN=${GITHUB_TOKEN}'

# Remote: the transport is auto-detected from the URL
aicore new-mcp-server search --url https://mcp.example.com/mcp \
    --header 'Authorization=Bearer ${MCP_SEARCH_TOKEN}'
```

| Option | Applies to | Effect |
|---|---|---|
| `--command`, `--args` | stdio | the command the runtime launches |
| `--url` | remote | the server endpoint |
| `--type` | either | `stdio`, `sse` or `streamableHttp`; auto-detected when omitted |
| `--env` | stdio | an environment variable for the subprocess; repeatable |
| `--header` | remote | an HTTP header; repeatable |
| `--auth-type`, `--auth-token-url`, `--auth-client-id`, `--auth-client-secret`, `--auth-scope`, `--auth-audience` | remote | an OAuth client-credentials grant the runtime performs — see [Authentication](#authentication) |
| `--enabled-tools` | either | restrict registration to a named list of tools |
| `--tool-timeout` | either | per-call timeout in seconds |

The command writes one artifact: an entry in the solution's `mcp.yaml`. Unlike
a command-line tool there is no console script and no reinstall, because the
server's tools register themselves at session start.

## The three tiers

A solution ships defaults. Operators override them without modifying your
repository.

| Tier | Declared with | Scope | Precedence |
|---|---|---|---|
| **Solution** | `aicore new-mcp-server` | every workspace running the solution | lowest |
| **Machine** | `aicore mcp-add <name> ...` | every workspace on that machine | middle |
| **Workspace** | `aicore mcp-add <name> ... --workspace <code>` | that workspace only | highest |

Override is **by server name and by whole entry**. Fields are never merged
across tiers: a higher tier's entry replaces the lower tier's entry
completely. Copy the fields you intend to keep.

The three tiers resolve the same way inside a build session. A server declared
during a session — at any tier — is available to that session's agent, so a
declaration and the first call on its tools belong in one sitting. See
[Cora Build](./09-building-with-the-builder.md).

```bash
aicore mcp-list
```

`mcp-list` prints the effective merged view with a provenance column showing
which tier supplied each server, and flags any server that has been dropped.

## Narrowing and suppression

Two adjustments are made from a higher tier without touching the solution.

- **Narrow a server to specific tools** with an `enabledTools` list. Only the
  named tools are registered. Use this where a server offers write operations
  that a given deployment must not expose.
- **Suppress a server entirely** by overriding it with an entry whose
  `enabled` field is `false`. The lower tier's server is not connected.

## Environment references

Secrets are written as `${VAR}` references and **stay unexpanded in every
declaration**. The runtime resolves them from the environment when it loads the
configuration, so a value never travels in a distributed package and never
lands in a run's configuration.

A server whose variable is unset is **dropped from the generated configuration,
with a warning naming the variable**. The remaining servers connect normally.
`mcp-list` reports any server dropped for this reason, which is the first place
to look when an expected tool is not registered.

### Where the value goes

Declaring a server that references `${VAR}` also writes a placeholder for each
referenced variable into two files, and prints both paths:

| File | In the repository | Holds the value |
|---|---|---|
| the pack's `.env.example` | yes, committed | never — it documents what an operator must supply, so whoever clones the repository sees what the pack needs without running anything |
| the workspace's own `.env` | no | yes — this is the file the runtime reads |

The workspace entry is written **commented out**:

```text
# --- required by aicore (add the values, then uncomment) ---
# MCP_SEARCH_TOKEN - MCP server 'search'
# MCP_SEARCH_TOKEN=
```

Supply the value by removing the comment and typing it after the `=`:

```text
MCP_SEARCH_TOKEN=the-token-your-vendor-issued
```

The comment is what keeps the failure loud. A variable that is present but
empty counts as supplied: the server is no longer dropped with a warning, it is
connected with an empty credential, and the far end rejects every call — the
agent then runs on without those tools and nothing on the console says why.
Left commented, the variable stays unset and the drop is reported.

Neither `aicore new-mcp-server` nor `aicore mcp-add` asks for a credential
value, stores one, or prints one. A value already in the file is never
modified, and re-running either command adds no duplicate entry. Where no
workspace is selected, the command names the workspace `.env` as the
destination rather than choosing one; `aicore current` identifies the file for
the selected workspace.

## Authentication

Two shapes are supported. In both, the credential is written into the
declaration as a `${VAR}` reference and its value is typed into the workspace's
own `.env` — see [Where the value goes](#where-the-value-goes).

### A static credential in a header

A server that accepts a long-lived bearer token or API key is connected by
declaring that header:

```bash
aicore new-mcp-server search --url https://mcp.example.com/mcp \
    --header 'Authorization=Bearer ${MCP_SEARCH_TOKEN}'
```

The runtime sends the declared headers on every request, unchanged.

Nothing renews a static credential. A short-lived token — a JWT carrying an
expiry — therefore works until it expires, after which every call to the server
is refused and the agent runs on without those tools. Where the server issues
short-lived tokens, declare a grant instead.

### An OAuth client-credentials grant

Where the server issues tokens from a token endpoint, declare the grant. The
runtime obtains the token itself, presents it on every request, and renews it
before it expires, so the capability does not lapse part-way through a session.

```bash
aicore mcp-add vendors --url https://vendors.example.com/mcp --workspace acme \
    --auth-type oauth2_client_credentials \
    --auth-token-url https://vendors.example.com/token \
    --auth-client-id '${VENDORS_CLIENT_ID}' \
    --auth-client-secret '${VENDORS_CLIENT_SECRET}' \
    --auth-scope 'mcp:tools'
```

`aicore new-mcp-server` takes the same options and writes the same declaration
at the solution tier.

| Option | Required | Value |
|---|---|---|
| `--auth-type` | yes | the grant: `oauth2_client_credentials` |
| `--auth-token-url` | yes | the token endpoint |
| `--auth-client-id` | yes | the client identifier, as a `${VAR}` reference |
| `--auth-client-secret` | yes | the client secret, as a `${VAR}` reference |
| `--auth-scope` | no | the scope requested |
| `--auth-audience` | no | the audience, where the server requires one |

The declaration that results:

```yaml
mcp_servers:
  vendors:
    url: https://vendors.example.com/mcp
    auth:
      type: oauth2_client_credentials
      token_url: https://vendors.example.com/token
      client_id: ${VENDORS_CLIENT_ID}
      client_secret: ${VENDORS_CLIENT_SECRET}
      scope: mcp:tools
```

A partial set of `--auth-*` options is refused, naming the option that is
missing. Declare the grant with the commands rather than by editing the file:
half a grant reaches a deployment intact and fails at connect time as a
rejection that appears to come from the server.

An unresolved `${VAR}` inside an `auth:` block counts exactly as one in a
header: the server is **dropped from the generated configuration, with a
warning naming the variable**, rather than connecting and being refused.

### What is not supported: an interactive authorization-code flow

A server that requires a person to authorise the client in a browser and be
redirected back cannot be connected directly. An agent runtime is headless: it
has nowhere to present a browser and no redirect URI to return to.

Terminate that flow in front of the server. A gateway or reverse proxy holds
the interactive session, obtains and refreshes the access token, and accepts a
credential of your own choosing from the runtime. Declare the gateway's URL and
either supported shape against it.

Where that is not available, the capability belongs behind a
[command-line tool](./02-command-line-tools.md) that performs the flow itself.

### Recognising a refused credential

A credential the far end rejects fails in a way that resembles a working
configuration. The shape of the failure:

- `mcp-list` shows the server as declared, with its variables resolved. On its
  own the listing reads the configuration files and does not connect, so a
  server whose every request is rejected is indistinguishable from a healthy
  one. **`aicore mcp-list --probe` settles it**: it contacts each remote server
  and reports what came back — `ok`, `unauthorized`, `forbidden`, `not-found`,
  `unreachable` or `unset-vars`, each with one line saying what to do.
  `--probe-timeout <seconds>` sets how long each server is given; the default
  is 6.
- The probe presents the same credential the runtime presents, including
  obtaining a token from a declared grant, so a server authenticated by a grant
  reports `ok`. Where the grant itself is rejected, the probe reports
  `unauthorized` and points at the token endpoint, the client identifier and
  secret in the workspace `.env`, and any scope or audience the server
  requires. Where a server answers with an authorization challenge and no grant
  is declared, the probe names that.
- The agent starts normally. Its `mcp_<server>_*` tools are absent, and no step
  fails on their account.
- A build session names the server, the status the server returned and what to
  do about it before the first turn, and tells the builder the same — see
  [Cora Build](./09-building-with-the-builder.md). A run records the failure
  instead of displaying it, so `--probe` is the check to run there.
- Outside a build session the agent is not told that the connection was
  refused. Asked why its tools are missing, it supplies a reason of its own;
  treat that explanation as a guess rather than a diagnosis.
- The connection is attempted again at the start of every session and fails
  identically.

Confirm it away from the console where more evidence is wanted. In a build
session the connection attempt is recorded in the session log under the
state directory's `build_logs/` — `.iof/build_logs/` beneath the directory the
session was opened in, or `$IOF_ROOT/build_logs/` where `IOF_ROOT` is set; the
newest file in that directory covers the current session, and a failed
handshake appears there as a closed connection against the server's URL. Where
the server's own access log is available it is the more direct evidence: the
rejected request appears there, and for a declared grant the token endpoint's
log shows whether a token was issued at all.

### What to do about each verdict

| The probe reports | Act on |
|---|---|
| `unset-vars` | the named variable in the workspace `.env`. The placeholder stays commented out until a value is supplied, and the server is dropped until then |
| `unauthorized`, static header | the value in the workspace `.env`, not the declaration. A short-lived token that has expired is the common cause — declare a grant instead of replacing the token by hand |
| `unauthorized`, declared grant | the token endpoint, the client identifier and secret, and any scope or audience the server requires. The rejection is of the grant, not of the tool call |
| `unauthorized`, authorization challenge, no grant declared | the vendor. Ask for client credentials to declare as a grant, or for a long-lived token to declare as a header; failing both, terminate the flow in a gateway |
| `forbidden` | the permissions attached to the credential. It authenticated; it is not entitled to the operation |
| `not-found` | the URL path. Many servers serve the protocol at `/mcp` |
| `unreachable` | the host, the port and any proxy between them |

## Make the server discoverable

Connection and discoverability are separate concerns.

Every declared server connects for every agent in scope. A skill does not gate
that. What a skill does is tell the agent **when** the server's tools are the
right answer:

```bash
aicore new-skill github_usage --mcp-server github --role brand_analyst
```

The generated skill names the `mcp_<server>_*` tool convention and carries the
judgment: which tool answers which job, how to read what it returns, and when
not to reach for it. It deliberately restates no parameters, because the live
tool definitions the runtime registers are current in a way a file cannot be.

`--mcp-server` is refused if no tier declares the named server.

## Granting servers to a swarm

A swarm's `mcp_servers` roster determines which declared servers reach its
meta-agent. Only granted servers appear in the run's configuration.

```yaml
mcp_servers: [github, search]
```

Omitting the key grants every declared server, including servers added to the
workspace later. State the roster explicitly on any swarm that will run against
production systems. See [Swarms](./07-swarms.md).

## Verify

```bash
aicore mcp-list                        # merged view, provenance, dropped servers
aicore mcp-list --probe                # ... and whether each remote server accepts the credential
aicore run <workflow> --goal "..."     # the step log records each tool registering
```

If a tool is not available to an agent, check in this order:

| Check | Command |
|---|---|
| Is the server declared at any tier? | `aicore mcp-list` |
| Was it dropped for an unresolved variable? | `aicore mcp-list` — the entry is flagged, whether the reference sits in a header, an environment entry or an `auth:` block. The placeholder in the workspace `.env` stays commented out until the value is supplied |
| Is a higher tier suppressing it? | `aicore mcp-list` — the provenance column |
| Is the agent told when to use it? | the paired skill, and the step's `skills:` list |
| Does the server accept the credential? | `aicore mcp-list --probe` — it contacts each remote server with the credential the runtime presents, a token from a declared grant included, and reports what came back. Without `--probe` the listing reads files only, and a server that rejects every request is indistinguishable from a healthy one. [What to do about each verdict](#what-to-do-about-each-verdict) |

## Related pages

- [Command-line tools](./02-command-line-tools.md) — capabilities you host
- [External agents](./05-external-agents.md) — capabilities that are whole agents
- [Swarms](./07-swarms.md) — granting servers to a meta-agent
- [Registry reference](../07-reference/05-registries.md) — the `mcp.yaml` schema
- [Getting started: MCP tools](../02-getting-started/code-first/06-example-mcp-server.md)

**Next:** [External agents](./05-external-agents.md).
