---
sidebar_position: 11
title: Case playbooks
description: A case playbook runs as durable case records driven by a rulebook — a validated document of states, typed events, rules and delivery contracts that the engine refuses to depart from.
---

# Case playbooks

A **case playbook** handles a situation that unfolds over days or weeks: an
escalation ladder driven by inbound events and expiring windows. Each affected
item becomes a **case** with durable state, so a procedure's position never
depends on anything remembering it.

A case playbook is executed by a **rulebook**: a validated document naming the
states a case can hold, the typed events it accepts, the rule that fires for
each combination, and what each resulting action delivers. The engine decides
only what the rulebook says; anything else is refused and surfaced.

## The rulebook document

```jsonc
{
  "template_id": "TPL-COVERAGE-GAP",
  "title": "Coverage Gap Escalation",
  "initial_state": "NEW",
  "open_event": "case_opened",
  "states": ["NEW", "OWNER_NOTIFIED", "ESCALATED", "PAUSED", "CLOSED"],
  "events": ["case_opened", "sla_breach", "assignment_confirmed",
             "system_error", "snooze_expired"],
  "terminal_states": ["CLOSED"],
  "role_params": ["owner_role", "cc_role", "escalation_role"],
  "default_params": {"owner_role": "District Manager", "cc_role": "Regional Director",
                     "escalation_role": "Field Operations",
                     "owner_sla_days": 2, "pause_days": 30},
  "rules": [
    {"from_state": "NEW", "event": "case_opened", "rule_id": "R01",
     "action": "notify_owner", "to_state": "OWNER_NOTIFIED",
     "sla_param": "owner_sla_days"}
  ],
  "wildcard_rules": [
    {"event": "assignment_confirmed", "rule_id": "R09",
     "action": "close", "to_state": "CLOSED", "sla_param": null}
  ],
  "actions": { },
  "event_rubrics": { },
  "invariants": [ ]
}
```

| Key | Purpose | Consequence if wrong |
|---|---|---|
| `states` · `events` | The complete vocabulary | A rule naming anything undeclared is refused at install |
| `terminal_states` | Where a case stops | A rule leaving a terminal state is refused |
| `rules` | One row per `(state, event)` | A duplicated pair is refused: the rulebook must be unambiguous |
| `wildcard_rules` | Applies from any non-terminal state, ahead of `rules` | Use for outcomes that can arrive at any point |
| `default_params` | Roles and windows | A rule naming an undeclared `sla_param` is refused |
| `actions` | The delivery contract per action | An undeclared action is treated as side-effecting |
| `event_rubrics` | How free text becomes a typed event | A rubric for an undeclared event is refused |
| `invariants` | Compliance properties, machine-checked | A revision violating one is refused |
| `business_days` · `calendar` | Windows count business days by default; `calendar` names the holiday region | `business_days: false` counts calendar days. A region with no holiday set loaded treats weekends as the only non-business days |

An event arriving in a state with no matching rule changes nothing: the refusal
is written to the case ledger for a person to review. A case never guesses its
way forward.

## Events: four are the platform's, the rest are yours

`events` is one list, but it holds two different kinds of name, and
confusing them produces a rulebook that validates, reads plausibly, and
does the wrong thing.

**Platform events.** These four are emitted by the platform itself. Their
meanings are fixed; a rule that assumes otherwise never fires.

| Event | Emitted when |
|---|---|
| `case_opened` | A case is opened. Named by `open_event`. |
| `sla_breach` | **Any window expires** — the first notification window, a reminder window, an escalation window. This is the one that drives an escalation ladder. |
| `snooze_expired` | **A pause ends** — only a pause. Not a general window. |
| `system_error` | A delivery or tool failure the platform reports. |

**Domain events** are everything else, and you name them: a reply, a
determination, a confirmation, a resolution. `assignment_confirmed` in the
sample above is one of these, not a platform event.

Which event a window's expiry produces is declared by the action that starts
the window. An action carrying `"expiry_event": "snooze_expired"` is a pause,
and its window ends as `snooze_expired`; every other window ends as
`sla_breach`, or as the rulebook's `breach_event` when it declares one.

:::warning A window expiring is `sla_breach`, never `snooze_expired`
This is the mistake to check for first when reviewing a compiled rulebook.
A draft that used `snooze_expired` for a triage window, combined with a
`wildcard_rules` entry closing the case on `snooze_expired`, produced a
ladder where an untriaged case **closed itself** — the rule table looked
correct and only the simulation exposed it.

Two checks catch it:

* **Read the simulation in the review.** A parked ladder
  (`REFUSED`, `ladder exhausted — case parked`) where you expected an
  escalation means the escalation is keyed to an event nobody emits.
* **Look for a wildcard on the same event.** Wildcard rules are matched
  first, from every state, so any specific rule on an event that also has
  a wildcard **can never fire**. The validator raises this as a warning
  naming the dead rule.
:::

## Delivery contracts

Each action declares what it delivers. This is data, so a change of recipient,
wording or channel is an amendment rather than a code change.

```jsonc
"actions": {
  "notify_owner": {
    "side_effects": true, "delivery": "email",
    "to_param": "owner_role", "cc_param": "cc_role",
    "subject_hint": "Coverage assignment needed — <item>",
    "brief": "request coverage within the window",
    "task_kind": "owner_sla"
  },
  "notify_admin": {
    "side_effects": true, "delivery": "email", "to_param": "admin_role",
    "approved_text": "Automated compliance notice: {item} (case {case_id}) ...",
    "task_kind": "pause"
  },
  "close": {"side_effects": false}
}
```

| Field | Effect |
|---|---|
| `to_param` · `cc_param` | Names the parameters holding the recipient roles, never people. Omitting `cc_param` expresses "directly and exclusively": the contract the action step receives then states `cc_policy: exclusive`, and the step sends no copy recipient |
| `subject_hint` | Subject line; `<item>` is replaced with the case's item |
| `brief` | What a composed message must convey, when no approved wording exists |
| `approved_text` | Delivered **verbatim** with only `{item}`, `{case_id}`, `{sla_days}`, `{prior_sla_days}` and parameter names substituted. Reviewed language is never rephrased |
| `task_kind` | The monitoring task to create |
| `side_effects` | Whether the action reaches an external system. An action with no entry is treated as side-effecting |

### Delivery kinds

`delivery` names how the action reaches the world. Each kind has its own
required fields, and the tool that performs it comes from what the workspace
declares — see
[What the workspace declares](./10-playbooks.md#what-the-workspace-declares).

| `delivery` | Required fields | Performs |
|---|---|---|
| `email` | `to_param`; optionally `cc_param`, `subject_hint`, `brief` or `approved_text` | Sends one message to one role. A parameter holding a list of roles is refused: one delivery addresses one role |
| `monitoring_task` | `task_kind` | Creates a task in the monitoring system |
| `open_play` | `play` | Opens child cases under the named play, linked to this case as their parent. Always side-effecting |
| `workflow` | `workflow`; optionally `goal_hint`, `completion_event` (default `workflow_completed`) and `failure_event` (default `system_error`) | Starts a run; its outcome arrives as the declared event, and both events must be in `events`. Always side-effecting — see [Actions that run a workflow](./10-playbooks.md#actions-that-run-a-workflow) |

Any action may also carry `"verification": {"tool": "<tool name>"}`: the action
step reads the ground truth from exactly that tool before recording the
delivery, and the tool must be one the workspace declares for verification.

### The two window placeholders

`{sla_days}` is the window the action **starts**. `{prior_sla_days}` is the
window that just **expired**. Escalation wording almost always means the
second, and quoting the first states the length of the next window while
claiming it is the one that ended — a false statement inside language
nobody is permitted to rephrase.

```jsonc
// refused: quotes the window being entered, in a sentence about expiry
"approved_text": "The escalation window of {sla_days} days has now expired."
// correct
"approved_text": "The escalation window of {prior_sla_days} days has now expired. A further {sla_days} business days now apply."
```

Validation refuses the first form. `{prior_sla_days}` is absent before a
case's second decision and renders as nothing rather than as zero, so
opening wording must not use it.

A recipient restriction is carried to the delivery step as an instruction,
not enforced at the point the message is sent. Where a copy recipient would
be a regulatory breach rather than an untidiness, audit the delivery record
as well as the contract: `iof-case explain` names the receipt for every
delivered action, and the receiving system's own log states who was
copied.

## Declared invariants

An invariant is a compliance property written as data and checked on every
install. Two kinds are available; a property fitting neither belongs in the
prose for a human reviewer.

```jsonc
"invariants": [
  {"kind": "action_only_from", "action": "notify_admin",
   "states": ["ESCALATION_REMINDED"], "except_events": ["system_error"]},
  {"kind": "event_always_closes", "event": "assignment_confirmed"}
]
```

`action_only_from` refuses any rule that fires the named action from a state
outside the allowed set. `event_always_closes` refuses any rule handling the
named event that does not reach a terminal state. A revision that breaks either
is refused with the offending rule named, so a property approved once survives
every later change.

## Validate and simulate before approving

```bash
iof-case rulebook validate --file tpl-coverage-gap.json
iof-case rulebook put      --file tpl-coverage-gap.json --as "<reviewer name>"
iof-case simulate TPL-COVERAGE-GAP
iof-case simulate TPL-COVERAGE-GAP --events "sla_breach,assignment_confirmed"
```

The two commands read different things, and the order matters. `validate` reads
the **file**. `simulate` takes a `template_id` and reads the **installed**
rulebook, so a rulebook that has only been validated is not yet simulatable:
the command reports `no rulebook '<template_id>'` and exits non-zero.

:::warning Installing writes to the workspace's database
`rulebook put` writes to whatever database the current workspace resolves to,
which on a configured machine may be a production one. Run `aicore current` to
see which database is in force before installing. To rehearse a rulebook
against nothing that matters, point the tools at a scratch store first:

```bash
IOF_DATABASE_URL="sqlite:///./rehearsal.db" iof-case rulebook put --file tpl-coverage-gap.json --as "<reviewer name>"
IOF_DATABASE_URL="sqlite:///./rehearsal.db" iof-case simulate TPL-COVERAGE-GAP
```

Installing a rulebook is not approving a playbook: a rulebook with no play
bound to it matches no request and opens no case.
:::

`simulate` walks the rulebook without touching any case. With no `--events` it
prints the **exhaust trace**: what happens when nobody ever responds and only
the clock fires. It ends at one of three verdicts, and the third is the one to
look for:

| Verdict | Meaning |
|---|---|
| `REFUSED` — `ladder exhausted — case parked` | The ladder ran out of rules. The case waits for a person or a different typed event. Usually correct |
| `REFUSED` — `terminal state accepts nothing` | The ladder reached a terminal state. Correct |
| **`LOOP`** | A rule returns to the state it fired from, so it re-fires on every further breach — an escalation that repeats forever. Never correct |

With `--events`, a step for which the state has no rule reads `REFUSED` with
`no rule — surfaces UNMATCHED`: the live case would record that event as
unmatched and wait for a person.

A `LOOP` verdict is reported structurally, from the rule's `to_state` alone. It
is raised even when the rule sets no new window, because an `sla_breach` from
any other source re-enters the same rule. Give the last rung its own state so
the ladder exhausts:

```jsonc
// loops: notify_director re-fires from ESCALATED on every breach
{"from_state": "ESCALATED", "event": "sla_breach", "rule_id": "R10",
 "action": "notify_director", "to_state": "ESCALATED", "sla_param": null}
// parks: the ladder runs out of rules and the case waits for a person
{"from_state": "ESCALATED", "event": "sla_breach", "rule_id": "R10",
 "action": "notify_director", "to_state": "DIRECTOR_NOTIFIED", "sla_param": null}
```

This is the trace to read before approving a ladder, and it is embedded in
every compilation review.

Validation reports two classes:

- **Errors** refuse the install. Undeclared states or events, duplicate rule
  pairs, rules leaving terminal states, invariant violations, and a rulebook
  whose rules never match its opening event — the last of which would install
  cleanly and then never open a case.
- **Warnings** are printed and do not block: a state no event path can reach;
  a reachable non-terminal state no rule leaves, where the rulebook has no
  wildcard rules — correct when the procedure stops there for a person, a gap
  otherwise; a rule that can never fire because a wildcard on the same event
  is matched first; an action no rule fires; and the same approved wording
  carried by more than one action.

## Revise a rulebook

```bash
iof-case rulebook put --file tpl-coverage-gap.json --as "<reviewer name>"
iof-case rulebook list
iof-case rulebook show TPL-COVERAGE-GAP
```

A new store lists two sample rulebooks, `TPL-OS-VACANCY` and
`TPL-SAMPLE-DISCREPANCY`, as starting content. They bind no playbook and open
no case until a playbook names one of them.

Each install increments the revision and records who made it. Adding a state,
inserting a rung for a new role, rewiring a rule or changing a delivery
contract requires no code and no release. Where a structural change moves an
action that an invariant constrains, update the invariant in the same
revision — otherwise the install is refused, which is the invariant working as
intended.

## One rulebook, many playbooks

A rulebook describes a family of situations; a playbook binds it to a trigger
and supplies parameter overrides.

```jsonc
"policy": {"species": "case", "template": "TPL-COVERAGE-GAP",
           "owner_sla_days": 1,
           "trigger_synonyms": ["vacant territory", "no coverage assigned"]}
```

Two playbooks can share one rulebook and differ only in roles and windows.
Where the ladder itself differs, author a second rulebook.

**Next:** [Operating playbooks](../04-running-solutions/08-operating-playbooks.md) — opening cases, relaying events and the scheduler.

## Related pages

- [Playbooks](./10-playbooks.md) — authoring, compilation, review and approval
- [Workflows](./06-workflows.md) — what a `workflow` delivery commissions
