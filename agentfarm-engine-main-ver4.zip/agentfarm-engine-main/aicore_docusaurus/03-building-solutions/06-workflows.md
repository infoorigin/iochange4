---
sidebar_position: 6
title: Workflows
description: A workflow is a declared pipeline of steps belonging to one solution. Each step names an agent, loads an exact set of skills, and is gated on the artifact it must produce.
---

# Workflows

A workflow is a pipeline of steps, declared in advance, that belongs to one
solution. It defines which agent performs each step, in what order, with what
instructions, and what each step must produce.

Use a workflow when the process is known before the run begins. Where the route
depends on what the agents find, use a [swarm](./07-swarms.md) instead.

## Create a workflow

A workflow belongs to a solution. Create the solution first if it does not
exist, and reinstall the workspace so that the new solution is registered.

```bash
aicore new-solution claims
pip install -e ".[dev]"
```

```bash
aicore new-workflow claims_triage --solution claims \
    --steps analyze:brand_analyst,compose:brand_analyst
```

`--solution` is required only when the workspace contains more than one
solution. `--steps` takes a single comma-separated argument because the steps
form a dependency chain and their order is part of the definition.

The command creates `solutions/claims/workflows/claims_triage/`:

```
workflow.yaml          the pipeline: roles, steps, dependencies and gates
metadata/catalog.yaml  the data catalog this workflow's prompts reference
roles/*.md             per-role framing, applied to every step that role runs
steps/*.md             per-step instructions
```

Generated step prompts contain a `<< REPLACE THIS ... >>` line. Replace it
before running.

## The definition

```yaml
name: claims_triage
description: Triage inbound claims and produce a disposition summary

team:
  - role: brand_analyst

roles:
  - name: brand_analyst
    prompt: roles/brand_analyst.md
    skills: [catalog_reader, grounded_analysis, house_style]
    model: "provider/model-name"

vars:
  region: EMEA

steps:
  - key: analyze
    title: Analyze
    role: brand_analyst
    prompt: steps/analyze.md
    requires_artifacts: [analysis.md]
    max_attempts: 2

  - key: compose
    title: Compose
    role: brand_analyst
    prompt: steps/compose.md
    deps: [analyze]
    requires_artifacts: [triage_summary.md]
```

`name` must match the directory name. The complete key-by-key schema is in the
[workflow.yaml reference](../07-reference/02-workflow-yaml.md).

## Steps and dependencies

`deps` is the entire sequencing mechanism. A step becomes runnable when every
step it names has completed. Steps with no dependency relationship may run
concurrently.

There is no direct messaging between agents. A step reads a prior step's result
by template substitution:

```markdown
The analysis produced by the previous step:

{{step_output.analyze}}
```

This is deliberate. Because every handoff passes through a recorded step
output, the input to any step is inspectable after the run.

## Roles

A role entry declares how one agent behaves in this workflow.

| Key | Effect |
|---|---|
| `name` | the workspace agent that performs the step |
| `prompt` | the role framing file, applied to every step this agent runs. Required. |
| `skills` | the exact set of skills loaded for that agent's steps |
| `model` | the model used for that agent's steps, overriding the default |

A step names its agent with `role:`; the role entry that defines that agent is
keyed `name:`. A role entry without a `prompt` fails to load.

Roles resolve across the workspace. A role name refers to the shared agent
regardless of which solution the workflow belongs to.

Each role must be a separate list item. YAML de-duplicates repeated mapping
keys, so two role entries written under one mapping key silently become one.

### The skills list is an exact set

`skills:` is a whitelist, not an addition. Any skill not named is omitted,
including skills the agent normally loads automatically. The list may also name
a skill the agent does not otherwise carry, because skills resolve across the
workspace catalog.

| Declaration | Result |
|---|---|
| key omitted | the agent's declared carriage loads |
| `skills: [a, b]` | exactly `a`, `b` — plus the output contract |
| `skills: []` | the output contract only |

The output contract is added unconditionally and cannot be excluded. Without
it, an agent emits no status marker and every step it runs is recorded as
failed.

## The artifact gate

Every step should declare `requires_artifacts`.

```yaml
requires_artifacts: [analysis.md]
```

After the step's agent reports its status, the platform verifies that each
named file exists in the run's output directory and is not empty. If any is
missing or empty, the step is recorded as **failed** and retried, even when the
agent reported success.

:::danger The gate is the only guarantee of a complete handoff
A step with no `requires_artifacts` completes on the agent's own report. If the
agent reports success without writing its deliverable, the next step proceeds
with nothing to read and produces a result derived from an absent input.

The key is `requires_artifacts`, plural. Unrecognised keys are ignored rather
than rejected, so a singular spelling loads without error and leaves the step
ungated. Run `aicore lint-workflow` to catch this.
:::

## Template variables

Step prompts are rendered before the agent receives them. Role and identity
files are never templated.

| Variable | Value |
|---|---|
| `{{goal}}` | the goal supplied at run creation |
| `{{step_output.<key>}}` | the recorded output of a completed step |
| `{{run_id}}` | the run identifier |
| `{{step_key}}` | the current step's key |
| `{{role}}` | the agent performing the step |
| `{{attempt}}`, `{{max_attempts}}` | the current attempt and the limit |
| `{{project_dir}}` | the project directory the run operates on |
| `{{output_dir}}` | the directory deliverables are written to |
| `{{workflow_dir}}` | the workflow's directory in the run's snapshot |
| `{{metadata_dir}}` | this workflow's `metadata/` directory |
| `{{progress}}` | the run's progress summary |

Any key defined under `vars:` is available by its own name, so
`vars: { region: EMEA }` makes `{{region}}` available in every step prompt. Use
`vars:` for per-workflow configuration such as collection names, endpoints and
feature flags.

`{{metadata_dir}}` resolves inside the snapshot the platform freezes at run
creation, not in your source tree, so a workflow's data catalog is fixed for
the duration of the run.

## Step types

Most steps run an agent. Two other types exist.

### Deterministic steps

A step that runs a command rather than an agent declares `type: exec`.

```yaml
  - key: prepare_batches
    type: exec
    command: "iof-acme-batcher --input {{metadata_dir}}/source.csv --out {{output_dir}}"
    requires_artifacts: [batches.json]
```

The same template variables apply, the artifact gate applies, and failures
retry within the attempt limit. Command output is recorded with the step.

If a step's correct behaviour can be written as a script, write it as a script.
An agent asked to perform a deterministic computation returns a result that is
plausible and occasionally incorrect, and the two are indistinguishable from
the output.

### Fan-out steps

A step that produces a list of work items and repeats subsequent steps for each
of them declares `type: loop`, with the repeated steps under `per_item_steps`.
A deterministic step may anchor the fan-out by writing the item list to a file
and naming it in `stories_from`, which avoids an agent transcribing the list.

## Sessions and memory

By default each attempt runs in a fresh session, so a retry is not influenced by
the attempt that failed. Set `fresh_session: false` on a step whose agent must
retain the prior attempt's session.

A run is not influenced by what earlier runs concluded. Conclusions are not
carried between runs; what carries is reusable method, and only after a person
approves it — see [How solutions learn](../05-improving-solutions/02-how-solutions-learn.md).
To exclude a workflow from that channel entirely, so its runs neither
contribute learning nor receive it, set `learning: disabled` at the top level
of the definition.

## Validate before running

```bash
aicore lint-workflow claims_triage
```

The loader reads fields by name and ignores keys it does not recognise. A
misspelled key therefore loads without error and silently disables what it was
meant to configure. The linter rejects unknown keys at every level with a
suggested correction, verifies that referenced prompt files exist, checks the
step graph, and reports errors and warnings separately. It exits non-zero on
error.

```bash
aicore lint-workflow --all          # every workflow resolvable in the environment
aicore lint-workflow --strict       # treat warnings as errors
```

A generated workflow passes with no errors and no warnings.

## Run it

```bash
aicore run claims_triage --goal "Triage the Q3 EMEA claims backlog" --dry-run
aicore run claims_triage --goal "Triage the Q3 EMEA claims backlog"
```

`--dry-run` prints the step graph without executing it and reports lint
findings as advisory information; it exits 0 even when lint errors are present.
Use `lint-workflow` to gate a build.

`aicore list-workflows` shows every workflow resolvable in the current
environment. A workflow that is absent from that list is not registered, which
is usually a missing reinstall after the solution was added.

## Related pages

- [Swarms](./07-swarms.md) — the goal-oriented alternative
- [Agents and skills](./01-agents-and-skills.md)
- [workflow.yaml reference](../07-reference/02-workflow-yaml.md)
- [Getting started: workflows](../02-getting-started/code-first/03-example-workflow-windows.md)

**Next:** [Swarms](./07-swarms.md).
