---
sidebar_position: 5
title: External agents
description: Federate with agents other teams operate. Register the endpoint once per workspace, assign the consult skill, and your agents route questions to it over the Agent2Agent protocol.
---

# External agents

The third kind of external capability is a whole agent that another team
operates — a partner's insight service, another department's data agent —
reachable over the Agent2Agent protocol.

Where an MCP server exposes tools, an external agent answers questions. Your
agents consult it and combine what it returns with their own work.

This page covers the outbound direction: consuming an agent someone else
operates. The inbound direction — serving your own agent to external
callers, card and endpoint included — is
[Exposing your agents to other systems](./08-exposing-your-agents.md).

Integration has three parts, each owning one concern.

| Part | Concern |
|---|---|
| The workspace registry | which agents exist, where they are, and how they authenticate |
| The consult transport | dispatch, parallel fan-out and header authentication |
| The `a2a_consult` skill | judgment: which agent to ask, and how to combine answers |

## Register an endpoint

```bash
aicore a2a-add partner-insights https://partner.example.com/a2a/insights \
    --description "Partner market-insights agent: share, growth and competitive queries" \
    --tag market-share --tag partner \
    --example "Which regions grew share last quarter?" \
    --header 'Authorization=Bearer ${PARTNER_A2A_TOKEN}'
```

| Option | Effect |
|---|---|
| `--description` | what the agent answers; the line routing decisions match against |
| `--tag` | a routing tag; repeatable |
| `--example` | an example question this agent answers; repeatable |
| `--header` | an HTTP header, with secrets written as `${VAR}`; repeatable |
| `--workspace` | the workspace whose registry receives the entry |

The entry is written to the workspace's external-agent registry.

:::note Routing quality is a function of the metadata
Routing matches a question against exactly three fields: the description, the
tags and the examples. An agent registered without a description is not
selected for any question, and one described in internal shorthand is selected
for the wrong ones.

Write the description in the terms someone would use to ask for the work.
:::

## Authentication

A header value written as `${VAR}` is stored as that reference. The registry
never holds a secret.

Place the value in the workspace's environment file, alongside the registry,
then confirm that it resolves:

```bash
aicore a2a-list
```

`a2a-list` prints every registered agent and whether each referenced variable
resolves. **Values are never printed.**

At dispatch, header values are expanded from the environment. A header whose
variable is unset is dropped, with a warning naming the variable, rather than
being sent half-formed.

## How your agents reach it

The registry is materialised into each agent's workspace as a catalog of
external agents, refreshed when an always-available agent warms up and when a
run is created. A change therefore takes effect on the next warmup or run, not
in the middle of a session.

An agent uses the catalog through the shared `a2a_consult` skill:

```bash
aicore assign-skill a2a_consult --role brand_analyst
```

The skill may also be named in a workflow step's `skills:` list, which loads it
for that step whether or not the agent otherwise carries it.

The skill's protocol is:

1. Read the catalog of registered agents.
2. Route each question to the best-fit agent, by description, tags and
   examples.
3. Dispatch the questions, in parallel where they are independent.
4. Combine the results, attributing each finding to the agent that supplied it.

**An agent that fails is excluded and named in the output.** It is never
replaced with an estimate, and the absence is reported rather than absorbed.

## Consulting directly

The consult transport can also be invoked directly, which is the fastest way to
confirm that an endpoint and its credentials are correct before any agent
depends on them:

```bash
iof-consult --url https://partner.example.com/a2a/insights \
    --nlq "Which regions grew share last quarter?" \
    --output out.json \
    --header 'Authorization: Bearer ${PARTNER_A2A_TOKEN}'
```

A batch mode dispatches several questions concurrently and returns one result
set, which is the mode the skill uses. Each result carries the agent it came
from, so attribution survives the combination step.

## Granting agents to a swarm

A swarm's `agents` roster determines which registered agents its meta-agent may
consult. Only granted agents are placed in the meta-agent's catalog.

```yaml
agents: [partner-insights, rx-sales]
```

Omitting the key grants every registered agent, including agents registered
later. State the roster explicitly on any swarm that runs against production
systems. See [Swarms](./07-swarms.md).

## Verify

| Check | Command |
|---|---|
| Is the agent registered, and do its variables resolve? | `aicore a2a-list` |
| Does the endpoint answer with these credentials? | `iof-consult --url ... --nlq ...` |
| Does the calling agent hold the consult skill? | its `skills.yaml`, or the step's `skills:` list |
| Is the routing metadata specific enough? | the `--description`, `--tag` and `--example` values |

## Related pages

- [MCP tools](./04-mcp-tools.md) — capabilities exposed as tools rather than agents
- [Swarms](./07-swarms.md) — granting external agents to a meta-agent
- [Agents and skills](./01-agents-and-skills.md) — assigning the consult skill
- [Registry reference](../07-reference/05-registries.md) — the external-agent registry schema
- [Getting started: external agents](../02-getting-started/code-first/07-example-swarm.md)

**Next:** [Workflows](./06-workflows.md).
