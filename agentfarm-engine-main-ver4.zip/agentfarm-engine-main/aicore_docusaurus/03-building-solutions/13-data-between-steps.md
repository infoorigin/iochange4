---
sidebar_position: 13
title: How data moves between steps
description: Every step of a run reads and writes one shared directory. This page states where each step's input comes from, where its output goes, and how to inspect both after a run.
---

# How data moves between steps

A workflow's `deps:` decide **when** a step runs. They carry no data. What a
step reads, and what it leaves for the next one, is decided by paths — and
every step of one run resolves the same path.

## One directory per run

`{{output_dir}}` renders to the run's **shared artifact directory**:
`<state dir>/instances/<run id>/project/`. Every step of the run — sequential,
parallel, and every item of a fan-out — receives the same value. A file one
step writes there is the next step's input by name; nothing copies it.

```yaml
- key: plan
  type: exec
  command: iof-acme-plan --out {{output_dir}}
  requires_artifacts: [plan.json]
- key: compute
  type: exec
  deps: [plan]
  command: iof-acme-compute --plan {{output_dir}}/plan.json --out {{output_dir}}
  requires_artifacts: [results.json]
```

`compute` depends on `plan` **and** reads the file `plan` is gated on. Both
halves matter:

- `deps:` is what guarantees `plan.json` exists when `compute` starts. Under
  a parallel driver, a step that reads a file without depending on the step
  that writes it may run first, fail on a missing file, and succeed on retry
  — a run that reads green and was wrong once. The linter warns about this
  shape.
- `requires_artifacts:` is what guarantees the file is real. Without it, a
  producer that wrote nothing still reports success.

A command runs with the working directory of the process that started the
run (`--project-dir`; by default, where `aicore run` was typed). Write every
output by `{{output_dir}}`, never by a bare relative path — a relative write
lands in that working directory, and the artifact gate, which looks only in
the shared directory, reports the file missing.

Per-step directories also exist — `runs/<run id>/steps/<key>/` holds each
step's `OUTPUT.md`, the recorded prompt, and for a command step its
`_exec_stdout.log` and `_exec_stderr.log`. Those are the step's **record**,
not its hand-off; hand-offs go through the shared directory.

A command step also receives the same facts as environment variables:
`IOF_ARTIFACT_DIR`, `IOF_RUN_ID`, `IOF_STEP_KEY`, `IOF_STEP_DIR`, and
`IOF_STEP_FEEDBACK` when an `on_fail` reset carried a note.

## Fan-out shares the directory too

Every item of a fan-out (`stories_from` + `per_item_steps`, or a `loop` step)
writes into the **same** `{{output_dir}}`. A per-item file therefore needs the
item's identifier in its name, or every item overwrites the last:

```yaml
per_item_steps:
  - key_suffix: reason
    role: reasoner
    prompt: steps/reason.md     # writes {{output_dir}}/reason_{{story_id}}.md
```

The linter warns when a per-item prompt names a fixed `{{output_dir}}/<file>`
with no `{{story_id}}` in the path.

## Agent steps

An agent step's prompt is rendered from the same variables, so it can name
the files it must read and write by path. Its recorded reply — the text after
`OUTPUT:` — is also available to later prompts as `{{step_output.<key>}}`,
which suits a short summary; a deliverable belongs in a file in the shared
directory, gated by `requires_artifacts`.

## Inspecting a run

| Question | Command |
|---|---|
| What did step X produce, and what did its command print? | `aicore status --run-id <id> --step <key>` |
| Why did the run stop, and where do I look next? | `aicore forensics explain <id>` |
| What happened, in order? | `aicore forensics show <id>` |
| The files themselves | `<state dir>/instances/<id>/project/` |

`aicore run` exits non-zero when the pipeline fails, so a script can gate on
it.

## Related pages

- [Workflows](./06-workflows.md)
- [Workflow YAML reference](../07-reference/02-workflow-yaml.md) — `requires_artifacts`, `timeout`, `routes`, `on_fail`
- [Command-line tools](./02-command-line-tools.md)
