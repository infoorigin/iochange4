---
sidebar_position: 1
title: Agents and skills
description: Agents are workspace-level identities with persistent memory. Skills are the judgment they apply, held by name so that one copy of a skill serves every agent that carries it.
---

# Agents and skills

An **agent** is a named identity with a defined responsibility. A **skill** is
judgment the agent applies, written as markdown.

Both are declared at workspace level and are available to every solution in the
workspace. A second solution reuses the first solution's analyst rather than
defining another one.

## Create an agent

```bash
aicore new-agent brand_analyst --name "Ida"
```

The command creates `agents/brand_analyst/workspace/`:

| File | Purpose |
|---|---|
| `SOUL.md` | the agent's identity: what it is responsible for and what it declines |
| `TOOLS.md` | how this agent uses the capabilities available to it |
| `memory/MEMORY.md` | memory retained across runs |
| `skills/output_protocol/` | the output contract |

The role name is how workflows and swarms refer to the agent. `--name` is what
people call it in conversation.

Two rules apply to the role name. It must not be one that an installed pack
already provides (the platform's own `project_lead`, `cora` and `queryngine`,
and any agent another installed pack ships — `aicore list-agents` names every
role a workflow here may use): a run resolves agents by name, and the platform's agent would run in
place of yours, so the command refuses the name and suggests one prefixed with
your package. And when a new agent should start with the skills of an existing
one, pass `--like <role>`: every skill directory that agent carries is copied
into the new one, while its identity file stays yours to write.

```bash
aicore new-agent brand_reviewer --name "Mira" --like brand_analyst
```

### The identity file

Edit `SOUL.md` first. It is loaded on every run and frames everything the agent
does.

State what the agent is responsible for, what evidence its conclusions must
rest on, and — explicitly — what it must decline to do. An agent with no stated
refusals attempts work outside its competence and reports success.

Identity files are never templated. They describe a durable role, not one run's
task; per-run instruction belongs in the step prompt.

### The output contract

`output_protocol` is created inside the agent rather than assigned to it later.
It causes the agent to emit the status and output markers that each step is
parsed for. Without it, every step the agent runs is recorded as failed and
retried.

For that reason it is added to every step unconditionally and cannot be
excluded by a workflow's `skills:` list.

## Create a skill

```bash
aicore new-skill house_style
aicore new-skill claim_review --role brand_analyst
```

Placement determines who holds the skill.

| Command | Placement | Held by |
|---|---|---|
| `new-skill <name>` | `skills/` at workspace level | any agent that declares it, and any workflow step that names it |
| `new-skill <name> --role <role>` | inside that agent | that agent |

Assignment is by location. A skill created inside an agent belongs to that
agent; a skill created at workspace level belongs to nobody until it is
declared or named.

### Writing a skill

A skill is judgment, not a function and not a wrapper around one. Replace the
`<< ... >>` placeholders in the generated file with:

- **When the skill applies**, in the terms a request would be phrased in.
- **How to approach the work** — the sequence, the checks, the evidence
  required.
- **What good output looks like**, with an example where the shape matters.
- **What to refuse**, and what to do instead.

Write the frontmatter `description:` field with care. An agent matches a task
against that line, so a skill described vaguely is not selected for work it
would have handled.

```yaml
---
name: claim_review
description: "Review a triaged claim for completeness, evidence and policy fit before it is escalated."
---
```

Quote the description. An unquoted value containing a colon followed by a space
is parsed as a mapping rather than as text.

A skill marked `always: true` in its frontmatter loads on every step the
carrying agent runs, unless the step's `skills:` list omits it.

## Declaring carriage

An agent carries a skill by **name**, declared in its own workspace file:

```yaml
# agents/brand_analyst/workspace/skills.yaml
carries:
  - house_style
  - a2a_consult
```

```bash
aicore assign-skill house_style --role brand_analyst
aicore assign-skill house_style --role brand_analyst --unassign
```

One copy of each skill exists — at workspace level or supplied with the SDK —
and any number of agents declare its name. Because carriage creates no copies,
an edit to a shared skill applies to every agent that carries it, and an SDK
upgrade reaches all of them.

`--role` is required only when the workspace has more than one agent.

### Skills are open

Nothing refuses a skill to an agent. Carriage sets an agent's **baseline**: the
skills it loads when a step does not say otherwise.

A workflow step declares what the **job** requires. Its `skills:` list is the
exact set for that step, and it may name a skill the agent does not otherwise
carry. Where the same skill exists in more than one place, the agent's own copy
is used before the workspace copy, and the workspace copy before the SDK copy,
so a local edit is never displaced by an upgrade.

## Making an edit take effect

Editing a file or declaring a skill changes your repository. An agent is built
from the installed solution the first time something asks for it, so an edit to
`SOUL.md`, a skill or `skills.yaml` takes effect on the next run against an
installed copy of your repository. **Memory is never overwritten.**

Where the solution is installed in editable mode, the next run reads the edited
files directly. Where a copy has already been prepared on the machine and the
edit does not appear, discard that copy so the next run re-reads the installed
solution:

```bash
aicore setup-agents --force
```

An environment other than your own runs the version its solution package was
built from. An edit reaches it through the repository, the build and the
deployment; there is no command that publishes it directly.

Declaring a skill name that nothing supplies fails when the agent is
materialised rather than silently. An agent that is missing an assigned
capability still runs and still reports success, which is a worse outcome than
a refusal.

## Scripts inside a skill

A skill may include a helper script, such as
`skills/<name>/scripts/check.py`, that the agent runs by path. The script
travels with the skill and requires no packaging.

Two constraints apply:

- **Code that must be on `PATH`, or that more than one skill uses, belongs in a
  tool.** Do not add a console-script entry point to a skill. See
  [Command-line tools](./02-command-line-tools.md).
- **A skill's script may import installed packages only** — the SDK, your
  workspace's own tools package, or the standard library. It cannot import
  files belonging to another skill.

## Choosing between a skill and a tool

| The work is | Implement it as |
|---|---|
| a judgment: what to consider, in what order, and what to refuse | a skill |
| a computation whose correct answer is defined | a tool |
| a computation an agent decides *when* to run | a tool, plus a skill that states when |

An agent asked to compute a result returns an answer that is plausible and
occasionally incorrect, and the two are indistinguishable from the output.
Deterministic behaviour belongs in a script.

## Related pages

- [Command-line tools](./02-command-line-tools.md)
- [Workflows](./06-workflows.md)
- [Skill format reference](../07-reference/04-skill-format.md) — frontmatter keys and resolution order
- [Getting started: agents and skills](../02-getting-started/code-first/03-example-workflow-windows.md)

**Next:** [Command-line tools](./02-command-line-tools.md).
