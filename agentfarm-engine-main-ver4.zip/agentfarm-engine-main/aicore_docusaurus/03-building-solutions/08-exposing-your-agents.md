---
sidebar_position: 8
title: Exposing your agents to other systems
description: Serve an agent to external callers over the Agent2Agent protocol - a public agent card plus a JSON-RPC endpoint - by declaring exposure in the agent's card file.
---

# Exposing your agents to other systems

An agent you build can be called by systems outside AI Core Harness over the
Agent2Agent (A2A) protocol. An exposed agent serves two things:

- **A public agent card** at
  `GET /a2a/<role>/.well-known/agent-card.json` — the machine-readable
  description an external caller reads to decide whether and how to use the
  agent.
- **A JSON-RPC endpoint** at `POST /a2a/<role>` accepting the A2A methods
  `SendMessage`, `GetTask` and `CancelTask`.

This page covers the inbound direction: your agent as the service. The
outbound direction — your solution consuming someone else's A2A agent — is
[External agents](./05-external-agents.md).

## The card file is the exposure switch

Exposure is declared in the agent's card file, `a2a-card.yaml`, in the
agent's workspace. When the file declares `expose: true`, the platform
serves the agent on the A2A surface at startup. No deployment configuration
changes; creating the agent and authoring its card is sufficient.

```bash
aicore new-agent pricing_broker --name "Brie" --a2a
```

The `--a2a` option writes a card template alongside the agent's identity
files:

```yaml title="agents/pricing_broker/workspace/a2a-card.yaml"
expose: true
name: "Brie"
description: >-
  Answers competitor-pricing questions from catalogued market data, with
  every figure traced to a query it ran.
version: "1.0.0"
skills:
  - id: pricing
    name: "Competitor pricing questions"
    description: >-
      Price positions, movements and comparisons across tracked competitors.
    tags: [pricing]
    examples:
      - "How did competitor list prices move this quarter?"
```

Setting `expose: false`, or removing the file, withdraws the agent from the
surface at the next startup.

An agent authored in AI Core Harness Studio is exposed the same way: add
`a2a-card.yaml` to the agent's files with `expose: true`. The declaration
takes effect at the next service startup whether or not the agent has ever
run on that host.

## What the card fields control

| Field | Effect |
|---|---|
| `expose` | `true` serves the agent on the A2A surface; anything else does not |
| `name` | The display name in the served card |
| `description` | What the agent does, for an external caller deciding whether to use it. Routing on the calling side matches against this — write it in the terms a task would use |
| `version` | The card's version string |
| `skills` | The capabilities the card advertises: each with an identifier, name, description, tags and example requests |
| `provider` | The owning organisation. When absent, a minimal provider is synthesised from the agent's name |

A card with only `expose` and `description` is valid: every remaining field
is filled with a specification-compliant value derived from the agent's
identity files.

## Operator control

The environment variable `IOF_ALWAYS_ON_AGENTS` (a comma-separated role
list) also places agents on the surface, independent of any card. The two
mechanisms combine: an operator can expose an agent whose card does not
declare it, and a card declaration needs no operator involvement. Agents on
the operator list are additionally warmed at startup; card-declared agents
initialise on their first call.

## Verifying an exposure

With the service running:

```bash
curl http://<host>:8111/a2a/agents
curl http://<host>:8111/a2a/pricing_broker/.well-known/agent-card.json
```

The first lists every exposed role; the second returns the served card. A
role missing from the list means its card does not declare `expose: true`
in the workspace the service runs in — an agent card in one workspace is
invisible to a service running another.

## Calling an exposed agent

External callers use the standard A2A JSON-RPC methods:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "SendMessage",
  "params": {
    "message": {
      "role": "user",
      "parts": [{"text": "How did competitor list prices move this quarter?"}]
    },
    "contextId": "pricing-session-7"
  }
}
```

Multi-turn continuity flows through `contextId`: requests carrying the same
value share one conversation, so a follow-up question is answered in the
context of the answers before it. Structured agent output is returned as a
data part alongside the narrative text part.

:::warning The service port carries no authentication
Anything that can reach the port can call every exposed agent. Run the
service on an internal network and control reachability at the network
layer. Exposure across a trust boundary requires an authenticating proxy in
front of the service.
:::

## Related pages

- [External agents](./05-external-agents.md) — consuming an external A2A
  agent from your solution
- [Swarms](./07-swarms.md) — external agents as swarm roster members
- [Deploying as a service](../04-running-solutions/04-deploying-as-a-service.md)

**Next:** [Cora Build](./09-building-with-the-builder.md).
