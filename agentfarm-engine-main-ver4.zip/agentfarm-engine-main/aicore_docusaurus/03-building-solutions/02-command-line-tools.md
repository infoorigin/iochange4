---
sidebar_position: 2
title: Command-line tools
description: Implement deterministic behaviour as a script rather than a prompt. A tool consists of three artifacts that must agree, plus a skill that tells agents when to run it.
---

# Command-line tools

A **CLI tool** is a script your workspace installs as a command-line
executable. Agents run it the way an engineer would.

Implement deterministic behaviour as a tool. An agent asked to compute a result
returns an answer that is plausible and occasionally incorrect, and the two are
indistinguishable from the output. A skill supplies judgment; a tool performs a
computation.

Tools are declared at workspace level. Once installed, a tool is on `PATH` for
every agent in the workspace.

## Create a tool

```bash
aicore new-tool window_math \
    --description "Compute delivery-window overruns in whole minutes"
```

The command creates three artifacts. A tool is reachable only when all three
agree.

| Artifact | Location | Purpose |
|---|---|---|
| the script | `tools/window_math.py` | the implementation |
| the console script | the workspace `pyproject.toml` | the only mechanism that places the tool on `PATH` |
| the declaration | `tools/tools.yaml` | the record that presence checks validate |

### The binary name carries a prefix

Console scripts share one namespace with the SDK and every other installed
package, so the generated executable name is prefixed:

```toml
iof-acme-window_math = "acme_tools.window_math:main"
```

The prefixed form appears in three places: the console-script entry, the
`name:` and `bin:` fields of `tools/tools.yaml`, and the command an agent
types. Only the `--tool` option of `new-skill` takes the plain name.

Writing the plain name into `tools/tools.yaml` makes the presence check report
a permanent gap for a tool that is installed and on `PATH`.

:::caution A reinstall is required
A console script is generated during installation. It is not read from your
files, so a new tool is not on `PATH` until the workspace is reinstalled:

```bash
pip install -e ".[dev]"
```

Until then the tool exists and is declared, and every attempt to run it fails.
This distinguishes `new-tool` from `new-agent` and `new-skill`, which take
effect without a reinstall.
:::

If the tool requires a third-party package, add it to the `dependencies` list
in the workspace `pyproject.toml` so that it is installed wherever the
workspace runs.

## Make the tool discoverable

A binary on `PATH` is available to every agent and known to none of them.
Create the paired skill, which states when to run the tool and how to interpret
what it returns:

```bash
aicore new-skill window_math_usage --tool window_math --role brand_analyst
```

`--tool` is rejected if `tools.yaml` does not declare the named tool, and the
refusal names the form it expected. A skill that instructs an agent to run a
binary that is not installed causes each step to consume its retry attempts on
a command that cannot be found.

With `--role`, the skill is written inside that agent. Omit `--role` for a
workspace-level skill that a workflow step names.

The tool and its skill are two separate commands. Creating the tool alone
produces a capability that installs, validates and is never used, because no
agent has been told it exists.

## Verify provisioning

The declaration in `tools.yaml` is what allows an environment to be checked
before it runs work.

```bash
aicore cli-hub list       # every declared tool, with its current presence
aicore cli-hub check      # validate only; no changes
aicore cli-hub install    # install whatever is declared and absent
```

`cli-hub check` exits **0** when every declared tool is present, **3** when one
or more are missing, and **1** on error. Use it as a deployment gate: a
solution whose tools are absent fails at the first step that needs one,
whereas the check reports the gap before any run is started.

`cli-hub install` validates first and installs only what is genuinely absent,
so it is safe to run repeatedly and has no effect in an environment that is
already provisioned.

## Calling a tool from a workflow

An agent runs a tool when its skill indicates that the tool is the right
answer. A workflow may also run one directly, with no agent involved:

```yaml
  - key: prepare_batches
    type: exec
    command: "iof-acme-window_math --input {{metadata_dir}}/windows.csv --out {{output_dir}}/overruns.json"
    requires_artifacts: [overruns.json]
```

A deterministic step is preferable wherever the step's correct behaviour can be
written as a command. It consumes no model calls, produces the same result on
every run, and is gated on its artifact in the same way an agent step is.

## Related pages

- [Agents and skills](./01-agents-and-skills.md) — when to write a skill instead
- [MCP tools](./04-mcp-tools.md) — capabilities another service hosts
- [Workflows](./06-workflows.md) — running a tool as a deterministic step
- [Registry reference](../07-reference/05-registries.md) — the `tools.yaml` schema
- [Getting started: CLI tools](../02-getting-started/code-first/05-example-workflow-tool.md)

**Next:** [Grounding agents in your data](./03-grounding-in-data.md).
