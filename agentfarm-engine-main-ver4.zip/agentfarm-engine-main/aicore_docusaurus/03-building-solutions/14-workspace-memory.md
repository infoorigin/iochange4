---
sidebar_position: 14
title: Workspace memory
description: Durable facts about a workspace — its data, systems, conventions and people — gathered from curated files and completed work, reviewed by a steward, and placed in front of every agent of the workspace on every engine.
---

# Workspace memory

Workspace memory is the set of durable facts every agent of a workspace
should know before it starts — the facts an agent would otherwise rediscover
in every run or be told in every prompt. It is gathered from files a team
curates and from the runs and conversations the workspace completes, it is
reviewed before it is used, and every agent of the workspace receives the
same reviewed set on every engine. This page covers what workspace memory
holds and what it does not, where facts come from, how they are reviewed,
how they reach an agent, how the subsystem is operated, how long a fact is
kept, and what is refused.

## What workspace memory is

A fact is one atomic statement about the workspace's world that stays true
across runs: a schema name, a column a dataset lacks, a naming convention,
who owns a system, when the fiscal year starts, how a person prefers to be
addressed. Each fact carries a **scope** — the whole workspace, one
solution, one agent role, or one user — and a **retention mark** —
`permanent`, `durable` or `ephemeral`.

Workspace memory is not:

- **Analytical results.** A number, percentage, amount, ranking or trend
  computed from data in one run is a result, not context. Results are
  refused at extraction and again at review; a result stored as memory
  would anchor every later run on a stale figure.
- **Methods.** How an agent does its job well is learned and governed
  separately — see [Governing what is learned](../05-improving-solutions/03-governing-what-is-learned.md).
  Memory holds what is true about the workspace, not how to work in it.
- **A document store.** Memory holds short facts and short curated notes
  that fit in an agent's context. Data an agent must query lives in the
  data catalog; documents an agent must read live where its tools reach
  them.

## Where facts come from

Three sources feed one store. Every fact records which source it came from.

### Curated files in the solution repository

A `memory/` directory at the root of the workspace repository — beside
`agents/` and `skills/` — holds Markdown files a team writes and versions
with the solution. The path of a file decides its scope:

| Path | Scope |
|---|---|
| `memory/<name>.md` | the whole workspace |
| `memory/workspace/**.md` | the whole workspace |
| `memory/solution/<code>/**.md` | one solution |
| `memory/role/<role>/**.md` | one agent role |
| `memory/user/<id>/**.md` | one user |

Only Markdown files are read. A file or directory whose name begins with
`.` or `_` is ignored; a `role/`, `user/` or `solution/` directory with no
name beneath it is ignored.

The directory is declared in the workspace package beside its agents and
skills, with `memory=` pointing at it the same way `agents=` points at
`agents/`. A directory that is not declared ships with the package and is
never read.

A curated file is carried whole, as one note, and is active as soon as it
is synced — it was written by a person and is not reviewed again. Editing
the file replaces the note; deleting the file retires it. Nothing is
extracted from a curated file, and nothing extracted is ever written back
into one.

### Curated files in the workspace settings directory

The same layout under the workspace's settings directory holds what this
deployment knows and the repository does not — a host name, a schema, a
contact:

```
~/.iobot/workspaces/<code>/memory/
```

It is synced with the same rules as the repository directory and its notes
carry the same standing.

### Facts extracted from completed runs and conversations

When a run completes, its steps' prompts and outputs are read and the
durable facts in them are proposed as candidates. A conversation turn with
a served agent is read the same way after the reply is sent. Every
candidate passes the same checks before it can be stored (see
[Safety](#safety)), is compared with what memory already holds — a
restatement is dropped, a changed value replaces the old fact in place —
and then becomes either a **draft** awaiting review or an **active** fact,
according to the workspace's posture.

Extraction uses the deployment's own model through the same provider the
agents use. It runs after the run has completed and never delays the run's
result.

## Reviewing facts

The workspace's **posture** decides what extraction produces:

- `review` (the default) — extraction produces drafts; a steward approves
  or rejects each one. A draft is never placed in front of an agent.
- `auto` — extraction activates facts directly. They are still checked,
  still recorded, and can still be retired.

```bash
aicore memory posture            # show
aicore memory posture auto       # set
```

The review queue and the decisions:

| Command | Effect |
|---|---|
| `aicore memory pending` | Drafts awaiting a decision |
| `aicore memory show <id>` | One fact in full, with its history |
| `aicore memory approve <id>` | Draft → active. An active fact that states the same thing with a different value is superseded in place. A draft identical to an active fact is marked superseded and nothing is added |
| `aicore memory reject <id> --reason "..."` | Refuse a draft. It stays in the record as rejected |
| `aicore memory forget <id> --reason "..."` | Retire an active fact. It is never placed in front of an agent again; the record stays |
| `aicore memory add "<fact>"` | Add a fact by hand. Active immediately unless `--draft`. `--scope` (default `workspace`; `role:<r>`, `user:<id>`, `solution:<c>`) and `--mark` (`permanent`, `durable` or `ephemeral`; default `durable`) set its placement and retention |

Every decision records who made it: `--as <name>` names the reviewer,
otherwise the value of `IOF_REVIEWER`, otherwise the operating-system user.
A fact that has already been decided answers `not pending`; a second
approval changes nothing.

`aicore memory add` runs the same checks as extraction. A fact that reads
as a computed result, contains a secret, or would instruct the agent is
refused with the reason, whoever typed it.

## How memory reaches an agent

An agent receives its workspace memory as **one block in its system
context**, present from the first turn of every session and identical from
turn to turn. The block opens by telling the agent that what follows is
background knowledge, that it never overrides the agent's identity,
guardrails or task, and that the data is to be trusted over memory when
they disagree.

The block holds the scopes that apply to the agent, in a fixed order:
the workspace, then the agent's role. Inside a scope, curated notes come
first, then facts by mark — `permanent`, `durable`, `ephemeral` — then by
age. Each scope has its own character budget, so a talkative role scope
cannot crowd out the workspace scope:

| Scope | Budget (characters) | Variable |
|---|---|---|
| workspace | 6000 | `IOF_MEMORY_CAP_WORKSPACE` |
| solution | 2500 | `IOF_MEMORY_CAP_SOLUTION` |
| role | 2500 | `IOF_MEMORY_CAP_ROLE` |
| user | 2000 | `IOF_MEMORY_CAP_USER` |

A scope that exceeds its budget ends with a line stating how many facts
were not shown. Facts about the requesting **user** are added to the turn
in which that user is speaking, labelled as background context, because
they belong to one person and not to every user of the agent.

Consequences of this design:

- **A draft is never used.** Only active facts are rendered. Under the
  `review` posture, a workspace whose drafts nobody reviews places nothing
  new in front of its agents.
- **A rejected or forgotten fact is never used again.** It stays in the
  record for audit and is excluded from every block from that moment.
- **What an agent sees is the same on every engine.** The block is
  rendered from the shared database in a fixed order, so two engines
  serving one workspace render identical bytes for the same agent, and a
  new engine joining the deployment renders the same block on its first
  turn.
- **An agent cannot edit its memory.** A write to the memory file from
  inside a session is refused with a message telling the agent to continue
  with its task. Facts worth keeping are extracted when the run completes
  and reviewed by a steward.

To see the block exactly as an agent receives it:

```bash
aicore memory render --role <role>
aicore memory render --role <role> --user <id>
```

## Operating workspace memory

| Command | Purpose |
|---|---|
| `aicore memory status` | Counts by status, the posture, whether extraction is on, and how many runs have been consolidated, are in progress, or failed |
| `aicore memory list` | Facts of the workspace — active by default; `--status` selects `draft`, `active`, `superseded`, `removed`, `rejected` or `all`; `--scope` narrows to one scope |
| `aicore memory history` | The audit trail, newest first; `--limit` sets how many entries |
| `aicore memory sync` | Re-read both curated directories into the store |
| `aicore memory sweep` | Retire expired facts, re-read the curated directories, and consolidate every completed run that has not been consolidated |
| `aicore memory consolidate --run <id>` | Consolidate one completed run now; `--force` re-runs a run that was already consolidated |
| `aicore memory render` | The block an agent receives; `--role`, `--user` and `--solution` select the scopes |

Every command operates on the selected workspace, or on the one named
with `--workspace`; `--json` returns machine-readable output.

**The schedule.** Consolidation of a completed run starts on the engine
that completed it, as a separate process, so the run's result is never
delayed. The service also runs a sweep for the workspace it serves at a
fixed interval; the sweep takes over any consolidation whose process did
not finish — an engine restarted or replaced mid-way — so a completed run
is consolidated exactly once whichever engine finishes it. A run's event
timeline records `run.memory_queued` when consolidation is queued and
`run.memory_consolidated` when it finishes.

**Environment variables a deployment sets:**

| Variable | Default | Effect |
|---|---|---|
| `IOF_MEMORY` | on | `0` turns workspace memory off: no extraction, no block, no sweep. The commands above keep working |
| `IOF_MEMORY_EXTRACTOR` | the deployment's model | `off` stops extraction. Curated files are still synced and the block is still rendered |
| `IOF_MEMORY_POSTURE` | `review` | The posture of a workspace that has not set one with `aicore memory posture` |
| `IOF_MEMORY_SWEEP_INTERVAL_S` | 300 | Seconds between sweeps on the service |
| `IOF_MEMORY_STALE_CLAIM_S` | 600 | Seconds after which an unfinished consolidation may be taken over by a sweep |
| `IOF_MEMORY_MAX_ATTEMPTS` | 3 | Number of attempts a sweep makes at a consolidation that failed; past it, the run is consolidated only by `aicore memory consolidate --run <id> --force` |
| `IOF_MEMORY_MAX_TOKENS` | 1800 | Output ceiling of each extraction call |
| `IOF_MEMORY_EPHEMERAL_TTL_DAYS` | 14 | Days an `ephemeral` fact stays active |
| `IOF_MEMORY_CAP_WORKSPACE`, `IOF_MEMORY_CAP_SOLUTION`, `IOF_MEMORY_CAP_ROLE`, `IOF_MEMORY_CAP_USER` | 6000, 2500, 2500, 2000 | Character budget of each scope in the block |

Run `aicore memory status` on any engine to confirm the posture and
whether extraction is on for the workspace it serves.

## Retention

A fact's mark states how long it is expected to hold:

| Mark | Meaning | Expiry |
|---|---|---|
| `permanent` | never becomes stale — a convention, an identity, a standing decision | none |
| `durable` | valid for months — a schema, a system, a project fact | none |
| `ephemeral` | active task state, a temporary decision | retired `IOF_MEMORY_EPHEMERAL_TTL_DAYS` days after it was added |

An expired fact is excluded from the block at once and marked removed by
the next sweep.

**A correction replaces in place.** When a new fact changes the value of
something an active fact states, the old fact is marked superseded and
the new one takes its place; memory never holds both versions. The same
rule applies when a steward approves a draft that conflicts with an active
fact, and when a curated file is edited.

**The newer source wins, whatever the processing order.** Every extracted
fact records when its run took place. A fact from an older run that
conflicts with an active fact from a newer run is not stored, and
approving such a draft closes it as superseded without changing the
active fact — runs consolidated out of order cannot roll a correction
back.

Nothing is deleted. A superseded, removed, rejected or expired fact stays
in the record with its history, and `aicore memory history` lists every
change with who or what made it.

## Safety

Every candidate — extracted from a run, extracted from a conversation, or
typed with `aicore memory add` — passes the same checks before it can be
stored, and the checks are rules, not judgements: nothing asks a model
whether a fact is safe.

- **Results computed from data are refused.** A percentage, a monetary
  amount, a trend or ranking beside a number, or a figure measured in the
  session beside the quantity it measures is dropped with the reason. The
  fact that a column is absent is kept; the value computed from it is not.
- **Personal identifiers are masked.** E-mail addresses, phone numbers,
  long numeric identifiers and titled person names are replaced in place
  — an address becomes `[email]`, a name becomes initials — before the
  fact is stored. The masking is recorded on the fact.
- **Content that would instruct the agent is refused.** Every candidate is
  scanned with the same security scan that guards learned methods. A body
  the scan rates dangerous can never be stored, whatever its source and
  whatever the posture; a cautionary finding is recorded on the fact for
  the reviewer.

Curated files pass the security scan as well: a file the scan rates
dangerous is refused with a warning and never carried, in either curated
directory.

`aicore memory consolidate --run <id>` lists every candidate the checks
refused and why, so a reviewer can see what was kept out.

**Next:** [Governing what is learned](../05-improving-solutions/03-governing-what-is-learned.md).

## Related pages

- [Agents and skills](./01-agents-and-skills.md)
- [Managing workspaces](../04-running-solutions/07-managing-workspaces.md)
- [Environment variables](../07-reference/07-environment-variables.md)
- [Command-line interface](../07-reference/01-cli.md)
