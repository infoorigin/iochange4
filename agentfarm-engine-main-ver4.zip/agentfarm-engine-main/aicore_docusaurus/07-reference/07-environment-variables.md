---
sidebar_position: 7
title: Environment variables
description: Every environment variable a solution team sets - what it selects, its default, and the consequence of leaving it unset - grouped by where it is read.
---

# Environment variables

Configuration resolves from the environment and from the selected workspace's
settings file. Where a value appears in more than one place, the environment
wins.

Run `aicore config-check` on any machine to see which values are in force and
which file supplied each. It prints no secret, and it is the fastest way to
answer "why is this command using that database".

:::note Where these belong
Set deployment values in the deployment's own environment, and per-machine
values in the selected workspace's settings file. A value that names an
environment — a database, a runtime address — should never travel with content
that is copied between environments.
:::

## Workspace and state

| Variable | Default | Effect |
|---|---|---|
| `IOF_WORKSPACE` | none | The workspace a process operates in. Required by `aicore serve`, which fails at startup without it. For CLI use, `aicore workspace use` is the equivalent and is remembered |
| `IOF_ROOT` | `.iof` | The state directory holding the run database, run artifacts and per-run configuration |
| `IOF_DATABASE_URL` | a local database file under the state directory | The shared database. Every process that must see the same runs, workspaces and catalog points at the same value |
| `IOF_DB_SCHEMA` | `iof` | The schema the platform's tables live in, for a PostgreSQL database |
| `IOF_LOCAL` | unset | Local mode for a workspace: every command runs against a database file under the state directory, with no server. Written to the workspace settings file by `aicore local on`; `--local` / `--no-local` override it for one command |
| `IOF_NO_MODE_BANNER` | unset | Set to silence the one-line notice each command prints on standard error naming the database it opened. Useful for a tool that invokes the command line in a loop; leave it unset otherwise, because that line is what tells you which database the command you are about to run will write to |

A workspace is always named explicitly. Where none is selected, a
workspace-scoped command refuses rather than choosing one.

## Serving and routing

Read by the service that fronts AI Core Harness Studio. Full topology guidance is in
[Deploying as a service](../04-running-solutions/04-deploying-as-a-service.md).

| Variable | Default | Effect |
|---|---|---|
| `IOF_ENGINE_URLS` | none | A JSON object mapping workspace code to runtime address, for explicit per-workspace routing. Takes precedence over the template. A malformed value fails at startup rather than at the first request |
| `IOF_ENGINE_URL_TEMPLATE` | none | A single address containing `{workspace}`, substituted with the workspace code. One line of configuration covers every current and future workspace whose runtime is named after it. A template without `{workspace}` is rejected |
| `IOF_RUN_API_URL` | `http://127.0.0.1:8111` | The runtime address for a single-runtime deployment, and the fallback where neither of the above matches. Also the address `aicore agent-chat --run-id` reaches |
| `IOF_DEPLOYMENT` | none | An environment name carried on each request. Where it is set on both the service and the runtime and the two disagree, the runtime refuses the request. Where either side leaves it unset, no check applies |
| `IOF_ALWAYS_ON_AGENTS` | `cora` | Which always-available agents are pre-warmed at startup, comma-separated. An agent whose card declares it exposed joins them without being listed |
| `IOF_A2A_ENABLED` | on | Set to `false` to stop serving the Agent2Agent surface |
| `IOF_RUNNER` | local | How run processes are created. `k8s` runs each in its own pod |
| `IOF_STORAGE` | none | Where run artifacts are persisted. `s3` makes them available to every instance, which is required to resume a run on another one |
| `IOF_MCP_SERVERS` | none | For a container deployment: a JSON object of MCP server declarations, keyed by server name, applied to the machine tier when the container starts. A value that is not a JSON object fails the start |
| `IOF_POOL_MAX_CONCURRENCY` | `0` | Maximum concurrent turns across the always-available agents. `0` leaves it unbounded |
| `IOF_POOL_QUEUE_TIMEOUT_S` | `60` | With a concurrency ceiling set, seconds a request waits for a slot before it is refused |
| `IOF_REQUEST_TIMEOUT_S` | `180` | Seconds allowed for one model call before it is abandoned and the step's recovery applies |

## Runtime service authentication

Requiring a credential on the runtime service. Full procedure:
[Securing the service](../04-running-solutions/05-securing-the-service.md).

### On the service

| Variable | Default | Meaning |
|---|---|---|
| `IOF_ENGINE_AUTH` | none | `oidc`, `apikey`, both comma-separated, or `off`. **A service bound to a non-loopback address refuses to start unless this is set**, so an exposed service without a credential cannot be reached by omission |
| `IOF_ENGINE_OIDC_TENANT_ID` | none | The Entra ID directory (tenant) identifier. Sufficient on its own to identify the provider: both issuer identifiers Entra ID uses for one application are accepted, and the directory is checked on each token |
| `IOF_ENGINE_OIDC_ISSUER` | none | The issuer identifier for any other OpenID Connect provider. Comma-separated where a provider uses more than one |
| `IOF_ENGINE_OIDC_AUDIENCE` | none | **Required with `oidc`.** What a token must be issued for. Without it, a token issued for any other application in the same directory would be accepted, so it is refused rather than defaulted |
| `IOF_ENGINE_OIDC_REQUIRED_ROLES` | none | Application roles, any one of which a caller must hold. A token that is valid without one is refused with `403` |
| `IOF_ENGINE_OIDC_REQUIRED_SCOPES` | none | Scopes, all of which a caller must hold |
| `IOF_ENGINE_OIDC_JWKS_URI` | discovered | The provider's signing-key endpoint, where the deployment cannot reach discovery |
| `IOF_ENGINE_OIDC_ALGORITHMS` | the asymmetric set | The accepted signing algorithms. Unsigned tokens and symmetric algorithms are never accepted, whatever this is set to |
| `IOF_ENGINE_OIDC_LEEWAY_S` | 60 | Clock-skew tolerance in seconds when checking expiry. Values above 300 are refused |
| `IOF_ENGINE_OIDC_JWKS_TTL_S` | 600 | Seconds the provider's signing keys are cached. A key the service has not seen triggers one refresh regardless, so a rotation does not wait for this to lapse |
| `IOF_ENGINE_API_KEYS` | none | Shared keys, comma- or newline-separated so several are valid during a rotation and a key file mounted as a secret is read correctly. Keys shorter than 32 characters are refused at startup |
| `IOF_ENGINE_DELEGATION_ROLE` | none | An application role a caller must hold before the end user it declares is recorded against the run. Unset, any authenticated caller may declare one |
| `IOF_ENGINE_AUTH_PUBLIC_AGENT_CARD` | off | Set `1` to serve agent cards without a credential, where peers discover agents before authenticating |

### On each caller

Read by the Studio API, the `aicore` command line, and any client application.

| Variable | Default | Meaning |
|---|---|---|
| `IOF_ENGINE_CRED_MODE` | inferred | `oauth`, `apikey` or `off`. Inferred from whichever of the values below are set |
| `IOF_ENGINE_CRED_TENANT_ID` | none | The Entra ID directory, from which the token endpoint is derived |
| `IOF_ENGINE_CRED_TOKEN_URL` | none | The token endpoint for any other provider |
| `IOF_ENGINE_CRED_CLIENT_ID` | none | The caller's own application identifier |
| `IOF_ENGINE_CRED_CLIENT_SECRET` | none | The caller's secret. Belongs in the workspace environment file, never in a repository |
| `IOF_ENGINE_CRED_SCOPE` | `<audience>/.default` | The scope requested. The default is the only value Entra ID accepts for this grant |
| `IOF_ENGINE_CRED_AUDIENCE` | none | The runtime service's audience |
| `IOF_ENGINE_CRED_API_KEY` | none | One of the service's shared keys |

## Recovery

| Variable | Default | Effect |
|---|---|---|
| `IOF_SUPERVISOR` | on | The sweep that detects and recovers stuck runs. Setting `0` disables it, and a run whose process dies then stays incomplete until someone acts |
| `IOF_SUPERVISOR_INTERVAL_S` | 60 | Seconds between sweeps |
| `IOF_SUPERVISOR_STEP_STALE_S` | 180 | Seconds without a heartbeat before a step marked `running` is treated as dead and reset. Also the default silence threshold of `aicore watch` |
| `IOF_SUPERVISOR_NO_HEARTBEAT_GRACE_S` | 900, or the command-step timeout plus 120 where that is larger | Seconds a step that has recorded no heartbeat at all is given before it is treated as dead |
| `IOF_SUPERVISOR_DRIVER_STALE_S` | 300 | Seconds the run's driver may be silent while steps wait before it is started again |
| `IOF_SUPERVISOR_MAX_RESUMES` | 5 | How many times one run may be resumed before it is failed and reported, rather than resumed again |
| `IOF_HARD_ATTEMPT_CAP_MULTIPLIER` | 2 | The absolute ceiling on attempts for one step is `max_attempts` times this value, plus one. Beyond it the step is not started again and the run fails with the cap recorded |
| `IOF_EXEC_STEP_TIMEOUT_S` | 600 | Seconds a `type: exec` step's command may run before it is failed and retried |
| `IOF_FANOUT_MAX_CHILDREN` | 4 | How many fanned-out agent steps a driver keeps in flight at once |

## Playbooks and cases

| Variable | Default | Effect |
|---|---|---|
| `IOF_CASE_DELIVERIES` | unset | The case delivery tools as a JSON object, outranking the workspace's `deliveries.yaml` and the package's. `iof-case deliveries` shows what resolves |
| `IOF_CASE_DISPATCH_AFTER_S` | 30 | Seconds a decision waits before the scheduler delivers its notice unattended |
| `IOF_CASE_DISPATCH_MAX_ATTEMPTS` | 3 | Delivery runs the scheduler starts for one decision before reporting it as owed and leaving it for a person |
| `IOF_CASE_DISPATCH_MAX_AGE_S` | 259200 | Age in seconds (3 days) beyond which a decision is not delivered unattended; `iof-case dispatch --dry-run` lists it as owed |
| `IOF_CASE_RUN_FAILURE_GRACE_S` | 900 | Seconds a failed commissioned run must stay quiet before its failure is applied to the case, because the platform retries failed runs |
| `IOF_TIMER_TOKEN` | unset | Serves the case-timer listener (`POST /api/case-timers/fire`, `GET /api/case-timers/due`); every request must present the value in the `X-Timer-Token` header. Unset, no listener is served |

## Improvement and governance

Learning is on with no configuration. Every variable here exists to deviate
from that. See
[Governing what is learned](../05-improving-solutions/03-governing-what-is-learned.md).

| Variable | Default | Effect |
|---|---|---|
| `IOF_LEARNING_V2` | on | Setting `0` disables learning for the deployment: nothing is proposed, and approved methods stop being offered |
| `IOF_LEARNING_INBOX_DIR` | a directory under the state directory | Where approved methods are stored. Point it at a version-controlled repository to make each approval a reviewed commit |
| `IOF_LEARNING_REVIEWER` | the platform's reviewer | `off` keeps attribution but authors no drafts, so nothing new reaches the review queue |
| `IOF_REVIEWER` | none | The approver identity recorded in the audit trail. `--as` on the command overrides it |

Set `learning: disabled` in a definition to opt one workflow out, rather than
turning learning off for the deployment.

## Access

| Variable | Default | Effect |
|---|---|---|
| `IOF_BOOTSTRAP_ADMIN` | none | The email granted platform administration on first start, so an installation has an administrator before anyone can sign in to create one |
| `IOF_AUTHZ_ENFORCE` | `1` | `0` keeps identity verified but stops enforcing workspace membership. The narrow rollback; not for a deployment |
| `IOF_AUTH_DEV` | off | Set to `1`: accepts any credential and treats an unidentified caller as a local identity. For local development only. **A deployment that sets it has no access control** |
| `IOF_API_URL` | `http://127.0.0.1:8002` | The Studio API address used by `aicore login`, `whoami` and `token`; `--api-url` on those commands overrides it |

## Authoring and building

| Variable | Default | Effect |
|---|---|---|
| `IOF_LINT_STRICT` | off | Set to `1`: lint errors fail `aicore run --dry-run` instead of being reported as an advisory |
| `IOF_SDK_MANIFEST` | `~/.iobot/sdk.json` | The file that names the SDK distributions and versions `aicore new-solution` writes into a new solution's dependencies. A malformed file is refused, not ignored |
| `IOF_BUILD_STALL_S` | `300` | Seconds a build-session turn may produce nothing before it is abandoned and reported. `0` waits without limit |
| `AGENTFARM_TOOLS_SRC_ROOT` | none | A local checkout used as the source for tools declared with `installer: build`, instead of cloning the declared repository |
| `AGENTFARM_ALLOW_TOOL_BUILD` | off | Set to `1`: `aicore cli-hub install` may run build recipes without `--allow-build`. Build steps execute commands; restrict to trusted sources |

## Related pages

- [Deploying as a service](../04-running-solutions/04-deploying-as-a-service.md) — runtime topology and scaling
- [Managing workspaces](../04-running-solutions/07-managing-workspaces.md) — selecting and moving workspaces
- [Command-line interface](./01-cli.md) — `aicore config-check` and the commands these affect

**Next:** [Troubleshooting](../08-troubleshooting/01-common-failures.md).
