---
sidebar_position: 8
title: Build session commands
description: Every command available inside an `aicore build` session and every option of the command itself, with the behaviour and an example for each.
---

# Build session commands

This page is the complete surface of a build session: the commands typed at
the session prompt, the two input forms that are not commands, and the
options of `aicore build` itself. Each entry states the behaviour and shows
one example.

A command is typed at the `build` prompt. Anything that does not begin with
`/` is a request to the builder. A leading `/` that is neither a command
below nor a repository macro is refused; it is never sent to the builder as
a message, so a mistyped command cannot become an instruction.

See [Cora Build](../03-building-solutions/09-building-with-the-builder.md)
for how the session behaves as a whole.

## Producing and checking work

| Command | Behaviour | Example |
|---|---|---|
| `/plan <request>` | Propose only. The builder returns a numbered plan and changes nothing; the working tree is restored at the end of the turn, so a planning turn cannot leave a file behind. Outside a git repository there is no checkpoint to restore to and the writes are kept — the session says so when it happens. | `/plan add a workflow that reviews payer contracts` |
| `/go` | Execute the plan last proposed. Where the builder marks each completed step, the console renders the marks as ticked progress. | `/go` |
| `/review` | Adversarially review the current changes in a separate conversation whose history does not contain the work it judges. The verdict is `APPROVE` or `FIX` with numbered findings. The tree is restored afterwards, so a review cannot alter what it judges. | `/review` |
| `/diff` | List the files the last turn added, modified or deleted. Requires a git repository; without one the command reports that and does nothing. | `/diff` |
| `/undo` | Revert the last turn. Files the session observed the builder write are reverted directly; anything else that changed since the turn began is listed and offered, because a checkpoint cannot say who wrote a file. Files that cannot be restored are named and the checkpoint is kept, so the command can be run again. | `/undo` |
| `/remember <note>` | Append a note to `CORABUILD.md`, the standing-instructions file read at the start of every session. Conventions recorded there outrank the builder's defaults. | `/remember catalogs live under metadata/` |

## Managing conversations

Each repository keeps named conversations. They continue across
invocations, so work resumed next week starts with the context it ended on.

| Command | Behaviour | Example |
|---|---|---|
| `/new [name]` | Start a conversation. Named when a name is given, auto-named otherwise. A name that already exists is not replaced: the session switches to it, with its history, and says so. | `/new market research` |
| `/sessions` | List the conversations for this repository, marking the active one and its turn count. | `/sessions` |
| `/switch <name>` | Continue a different conversation. | `/switch market-research` |
| `/rename <new>` | Rename the active conversation, or `/rename <old> <new>` to rename another. History is preserved. The command reports failure when the name is already taken. | `/rename contract-review` |
| `/compact` | Distil the conversation into a summary and continue in a fresh one that carries it. The full original remains available under `/switch`. Use it when the context figure on the meter line has grown large. | `/compact` |
| `/transcript` | Show the tail of the active conversation as it is stored. | `/transcript` |
| `/exit`, `/quit` | Leave the session. The conversation is kept. The two are equivalent. | `/exit` |

`exit`, `quit` and `help` are also accepted without the slash, and `/session`
with no argument is the same as `/sessions`.

## Controlling the session

| Command | Behaviour | Example |
|---|---|---|
| `/gated on` &#124; `/gated off` | Approval mode. Every mutating action pauses for a `y`/`n` confirmation and shows the first lines of any content it would write. Answering `a` disables the gate for the rest of the session. Requires an interactive terminal. With no argument the command reports the current state. | `/gated on` |
| `/help` | List the session commands with a one-line meaning each. The same list is given to the builder when a conversation starts, so asking it how to start a new conversation or undo a turn gets the command by name. | `/help` |

Commands that change the Python or Node environment are confirmed
separately whether or not approval mode is on. A session with nobody to
ask — a one-shot or a CI run — refuses the install and reports what needed
installing and why.

## Input forms

These are not commands. They are ways of composing a message.

| Form | Behaviour | Example |
|---|---|---|
| `@path` | Inline a file's content into the message: the first 8 KB, marked `[truncated]` beyond that, at most three files per message. The console confirms each resolved reference with its line count. A reference is left as written, with the reason, when the path does not exist, resolves outside the session's repository, or is binary. | `@skills/contracts_summarise/SKILL.md is the frontmatter valid?` |
| `/<macro>` | A markdown file at `.aicore/commands/<name>.md` becomes the command `/<name>`. Its content is sent as the message, with anything typed after the command appended. Checked into the repository, a macro is available to everyone who clones it. | `/release-notes since 0.4.0` |

## Options of `aicore build`

| Option | Behaviour | Example |
|---|---|---|
| `--message`, `-m` | Run a single turn non-interactively and exit. An empty or whitespace-only value is refused with exit `2`: passing the option asks for one turn, and an empty turn is not one. | `aicore build -m "create a skill for payer eligibility"` |
| `--plan` | With `--message`, a planning turn. The builder proposes and any file change is reverted. | `aicore build -m "add a claims workflow" --plan` |
| `--review` | Review the current changes. Usable without `--message`. Files not yet added to version control are included, which is most of what a build session produces. | `aicore build --review` |
| `--json` | Machine output: a single JSON object as the final line of stdout, carrying the reply, the files changed, and whether a revert ran. Requires `--message`, `--plan` or `--review`. A run that fails before a turn starts exits non-zero and prints no JSON, so check the exit code before parsing. | `aicore build --json -m "lint every workflow"` |
| `--session`, `-s` | Continue or create a named conversation for this repository. | `aicore build -s contract-review` |
| `--new-session` | Start a fresh conversation. The previous one is kept; it is no longer continued. | `aicore build --new-session` |
| `--workspace`, `-w` | The workspace the session runs against. Defaults to `IOF_WORKSPACE`, then to the workspace last selected with `aicore workspace use`. A one-shot with none selected exits `2` naming the commands that select one; only an interactive session asks — and when the code typed there is new, it is validated with the creation rule (3–31 chars, `[a-z][a-z0-9_]*`) and, if the configured database is a shared server, followed by a **local or shared** choice before anything is created. | `aicore build -w acme` |
| `--role`, `-r` | The agent to build with. Defaults to `cora_build`, the dedicated builder. | `aicore build -r cora_build` |
| `--gated` | Start in approval mode. Equivalent to `/gated on` at the prompt. | `aicore build --gated` |

## Commands in a script

A slash command passed through `--message` is executed by the session
itself, not handed to the builder, so it performs the real operation. This
is what makes the propose-then-approve loop usable from a script:

```bash
aicore build -w acme -m "add a workflow that reviews payer contracts" --plan
aicore build -w acme -m "/go"
aicore build -w acme --json --review
```

Repository macros work the same way. An unknown command is refused with
exit `2`, and under `--json` that refusal is reported as JSON on the final
line like any other result.

## Related pages

- [Cora Build](../03-building-solutions/09-building-with-the-builder.md)
- [Command-line interface](./01-cli.md)
- [Environment variables](./07-environment-variables.md) - `IOF_BUILD_STALL_S`

**Next:** [Common failures](../08-troubleshooting/01-common-failures.md).

