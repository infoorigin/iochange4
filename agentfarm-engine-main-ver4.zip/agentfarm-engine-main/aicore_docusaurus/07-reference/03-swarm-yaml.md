---
sidebar_position: 3
title: Swarm definition reference
description: Every key in swarm.yaml - its type, its default, and what happens when it is set incorrectly - together with the optional files that override generated content.
---

# Swarm definition reference

A swarm is a directory containing a definition file and, optionally, files that
override the content the platform generates from it.

```text
swarms/
  portfolio-review/
    swarm.yaml
    meta.md                   # optional: overrides the generated briefing
    roles/
      intel_orchestrator.md   # optional: overrides the generated persona
    metadata/                 # optional: available as {{metadata_dir}}
```

:::danger Unknown keys are errors - run the linter
A misspelled key would carry no setting, so every unrecognised key is reported
as an error with the intended spelling.

```bash
aicore lint-swarm --name <name>
aicore lint-swarm --all --strict
```

The linter's final check builds the exact execution shape the run would use
and validates it, so a definition that lints cleanly will load.
:::

## Shape

```yaml
name: portfolio_review            # must equal the directory name
description: >
  Cross-domain brand risk review across sales, sentiment and supply.

role: intel_orchestrator          # the meta-agent

agents: [rx-sales, market-voice]  # external agent roster
mcp_servers: [lab]                # MCP server roster
skills: [market_framing]          # additional skills for the meta-agent

deliverable: swarm_report.md      # the fail-closed output gate
max_attempts: 2

budget:
  tool_calls: 120                 # hard ceiling
  consults: 6                     # briefing allowance

vars:
  window: "2026-Q3"               # values are strings
```

## Keys

| Key | Type | Default | Meaning |
|---|---|---|---|
| `name` | string | required | Must equal the directory name, and match lower-case letters, digits and underscores, starting with a letter, 2 to 49 characters. Everything that addresses the swarm uses it. |
| `description` | string | empty | One sentence stating what the swarm achieves. Shown when a swarm is selected, and quoted into the meta-agent's persona. Empty produces a lint warning. |
| `role` | string | required | The meta-agent: an existing agent role in the workspace. The role that drives the run pipeline itself cannot be used; the linter names it where it is. |
| `agents` | list, or omitted | omitted | The external agent roster. See [Roster semantics](#roster-semantics). |
| `mcp_servers` | list, or omitted | omitted | The MCP server roster. Same semantics. |
| `skills` | list | empty | Additional skills for the meta-agent, resolved from the workspace catalog. |
| `deliverable` | string | `swarm_report.md` | The file the meta-agent must produce. Enforced as a fail-closed gate: while it is missing or empty the run is failed and retried, never completed. |
| `max_attempts` | integer, at least 1 | 2 | Attempts for the swarm. A platform-level ceiling applies on top. |
| `budget.tool_calls` | integer, at least 1 | none | Hard ceiling on the number of tool calls the meta-agent may make. See [Budgets](#budgets). |
| `budget.consults` | integer, at least 1 | none | The number of consultations the briefing allows per roster member. Advisory. |
| `vars` | mapping | empty | Template variables available in the briefing and any prompt file as `{{key}}`. Override per run with `aicore run-swarm --var KEY=VALUE`. |

## Roster semantics

`agents` and `mcp_servers` are three-valued. The distinction between an
omitted key and an empty list is significant.

| Written | Meaning |
|---|---|
| Key omitted | Every entry registered for the workspace is available |
| `agents: [rx-sales]` | Exactly the named entries. Names that are not registered are reported when the run is prepared |
| `agents: []` | None. The swarm cannot consult any external agent |

Declaring both `agents: []` and `mcp_servers: []` leaves the meta-agent with
no external capability at all; it will answer from its own knowledge. The
linter warns about this combination.

The capability that lets the meta-agent consult external agents is added
automatically whenever the roster is not empty, and the output contract is
always present. Neither needs to be listed under `skills`.

## Budgets

The two budget keys are enforced differently, and the difference determines
which one to rely on.

**`budget.tool_calls` is a hard ceiling.** The meta-agent cannot exceed it.
When the ceiling is reached, the swarm stops. This is the control that bounds
the cost and duration of a swarm, and it is the one to set.

Values below 20 are raised to 20, because the run itself consumes calls from
the same allowance. The linter warns where a lower value is written. Setting
`tool_calls` never raises the ceiling above the deployment's configured
maximum.

**`budget.consults` is an allowance stated in the briefing.** It instructs the
meta-agent to batch its questions and not to re-consult a roster member it has
already used. It is a contract the meta-agent is asked to observe, not a quota
the platform enforces. Use it to shape behaviour; use `tool_calls` to bound
consumption.

## Optional files

| File | Overrides |
|---|---|
| `meta.md` | The generated briefing. Template variables apply, and `{{goal}}` carries the goal the run was started with |
| `roles/<role>.md` | The generated meta-agent persona. The default is a pure-orchestration contract: route, dispatch, combine, attribute every figure to its source, never fabricate, and name any capability that failed |
| `metadata/` | Nothing. Its contents are copied into the run and resolve as `{{metadata_dir}}` in prompts |

Where `meta.md` is overridden, retain the instruction to maintain the run plan
checkpoint (`_run_plan.md`). It is what allows a retried attempt to resume from
where the previous attempt stopped rather than starting again, and removing it
makes every retry a full repetition.

## Execution

A swarm executes on the same run pipeline as a workflow. It inherits retries,
the fail-closed deliverable gate, the attempt ceiling, automatic recovery from
transient conditions, and the full diagnostic surface. Every command that
operates on a run operates on a swarm run.

```bash
aicore run-swarm portfolio_review --goal "Assess Q3 brand risk" --dry-run
aicore run-swarm portfolio_review --goal "Assess Q3 brand risk"
aicore forensics explain <run_id>
```

`--dry-run` prints the roster and the resolved execution shape without
executing.

## Lint findings

| Finding | Severity | Meaning |
|---|---|---|
| Unknown key | Error | The key is never read; whatever it was meant to configure does not take effect |
| `name` missing, or not matching the directory | Error | The swarm would be addressed by a name that does not resolve |
| `role` missing, or naming the run driver | Error | No meta-agent, or a role that cannot execute steps |
| `agents`, `mcp_servers` or `skills` not a list | Error | The roster semantics require a list or an omitted key |
| `deliverable` not a string, `max_attempts` below 1, `vars` not a mapping | Error | Type errors |
| Unknown key under `budget`, or a non-integer value | Error | The recognised keys are `tool_calls` and `consults` |
| `budget.tool_calls` below 20 | Warning | Raised to 20 |
| Empty `description` | Warning | The swarm is unlabelled where one is selected |
| `agents: []` together with `mcp_servers: []` | Warning | The swarm has no external capability |

## Related pages

- [Workflow definition reference](./02-workflow-yaml.md)
- [Registry files](./05-registries.md)
- [Building swarms](../03-building-solutions/07-swarms.md)

**Next:** [Skill format](./04-skill-format.md).
