---
sidebar_position: 1
title: Command-line interface
description: The complete reference for the aicore commands used to create, validate, run, operate and improve solutions, grouped by task.
---

# Command-line interface

Every command is invoked as `aicore <command>`. Options shown as `--flag <value>`
take a value; options shown alone are switches. Run `aicore <command> --help`
for the authoritative signature of any command in the installed version.

Commands that operate on a workspace accept `--workspace <code>`. When it is
omitted, the active workspace is used; set the active workspace with
`aicore workspace use`. A workspace is always named explicitly: where none is
given and none is active, the command refuses rather than choosing one, and
the message states how to select one. A malformed code is an error, never a
different workspace.

This reference covers the commands a solution team uses. Commands reserved for
platform operation are not listed.

## Identity

| Command | Purpose |
|---|---|
| `aicore login` | Authenticate against the platform and store a token for reuse |
| `aicore logout` | Discard the stored token on this machine |
| `aicore whoami` | Report the authenticated identity and the workspaces it can open |
| `aicore token` | Print the stored token for use in a direct API call |

## Machine setup

| Command | Purpose |
|---|---|
| `aicore init-home` | Create the AI Core Harness home directory with a configuration file and an environment file to complete |
| `aicore config-check` | Report how configuration resolves — which values are in force and which file supplied each — without printing any secret |
| `aicore init` | Create the state directory and its database |
| `aicore setup-agents` | **Deprecated**, and accepted for compatibility. Seeding is no longer required: content is read from the installed solution package by the run or chat that needs it, and `aicore serve` prepares the host at start-up. Without flags the command performs no work and reports that it did none. `--force` discards the copy prepared on this machine, so the next run or chat re-reads the installed package |
| `aicore local` | Turn local mode on or off for a workspace, durably. In local mode a solution runs against a database file in the working directory with no server |
| | Every command that opens a database states which one it opened, on standard error: `LOCAL` with the file, or `SHARED` with the server and schema. Standard output is unaffected, so `--json` remains parseable. Silence it with `IOF_NO_MODE_BANNER=1` |
| `aicore sync` | **Deprecated**, and accepted for compatibility; performs no work and reports that it did none. There is no content catalog to refresh — the Studio reads content from the running engine, and a run resolves it from the installed package |

## Creating content

Each command scaffolds a validated artifact into the pack rooted at the current
directory. See [Building solutions](../03-building-solutions/01-agents-and-skills.md).

| Command | Creates |
|---|---|
| `aicore new-solution <slug>` | A solution repository that installs, imports and runs |
| `aicore workspace scaffold <slug>` | A workspace repository holding shared agents, skills and tools plus one or more solutions |
| `aicore new-agent <role>` | An agent workspace with identity and memory files. `--like <role>` starts it with a copy of an existing agent's skills. `--a2a` also authors an agent card declaring the agent exposed on the A2A surface — see [Exposing your agents](../03-building-solutions/08-exposing-your-agents.md) |
| `aicore new-skill <name>` | A skill definition |
| `aicore new-tool <name>` | A command-line tool: script, entry point and declaration |
| `aicore new-mcp-server <name>` | An MCP server declaration in the pack's `mcp.yaml`. `--command`/`--args`/`--env` declare a server the runtime launches; `--url`/`--type`/`--header` a remote one; `--enabled-tools` and `--tool-timeout` apply to both. The `--auth-*` options declare an OAuth grant the runtime performs — see [MCP servers and external agents](#mcp-servers-and-external-agents) |
| `aicore new-workflow <name>` | A workflow definition with roles, steps and prompts |
| `aicore new-swarm <name>` | A swarm definition with a roster and budget |

## Assigning skills

| Command | Purpose |
|---|---|
| `aicore assign-skill <skill> [--role <agent>]` | Record that an agent carries a skill, without copying its content |
| `aicore unassign-skill <skill> [--role <agent>]` | Remove the assignment |

## Validating and listing

| Command | Purpose |
|---|---|
| `aicore lint-workflow <name-or-path>` | Check a workflow definition for the mistakes the loader accepts silently — unknown keys, missing prompts, broken fan-out, a step prompt missing the text-before-tool-call rule — and report each with a line and a fix |
| `aicore lint-swarm <name-or-path>` | Validate a swarm definition: unknown keys, malformed rosters, compile errors |
| `aicore lint-skill <path>` | Validate a skill's `SKILL.md`. An unquoted `description` containing `": "` fails the whole frontmatter, and the skill then loads with no name and no description — it is never matched to a job. Also reports a name that disagrees with its directory, a non-boolean `always:`, and a skill with no body |
| `aicore lint-agent <path>` | Validate an agent directory: identity files, the agent card, every carried skill, and the output contract. An agent with no output contract emits no `STATUS:`/`OUTPUT:`, so every workflow step it runs is marked failed and retried to the attempt cap |
| `aicore context-report <role>` | What reaches an agent's model - identity, skills, memory - and what is present on disk but never loaded. Exit `0` when clean, `3` when there are findings. `--path <dir>` inspects a directory directly; `--all` lists every file |
| `aicore list-workflows` | List the workflows this environment can resolve |
| `aicore list-swarms` | List the swarms this environment can resolve |

## Running

| Command | Purpose |
|---|---|
| `aicore run <workflow> --goal "..."` | Run a workflow end to end |
| `aicore run-swarm <swarm> --goal "..."` | Run a swarm: a meta-agent pursues the goal with its roster, under its budget and controls |
| `aicore run-task --role <role> --goal "..."` | Run a single agent task directly, tracked in the store. `--background` returns immediately |

Common options for `run` and `run-swarm`:

| Option | Effect |
|---|---|
| `--goal "..."` | The objective the run pursues (required) |
| `--workspace <code>` | The workspace to run in |
| `--var key=value` | Set a workflow variable; repeatable |
| `--local` / `--no-local` | Force local mode on or off for this run |
| `--dry-run` | Validate and print the plan without executing |
| `--json` | Create the run and return its identifier without blocking, for background execution |
| `--project-dir <path>` | The working directory for the run (defaults to the current directory) |
| `--allow-concurrent` | `run` only. Start although a workflow named in the definition's `depends_on_runs` still has a run producing; the consumer then works from a partial input set |

## Interacting with a run

| Command | Purpose |
|---|---|
| `aicore status` | Show recent runs, a run's step states, or team activity |
| `aicore current` | Show the active run context and the current mode |
| `aicore use-run <run_id>` | Set the run that subsequent commands default to |
| `aicore follow-up --goal "..."` | Start a new run that continues from a prior run's context. `--from <run_id>` names the prior run (default: the active one); `--workflow <name>` selects the workflow, and is required where the default workflow is not installed |
| `aicore agent-chat --role <role> -m "..."` | Send a message to an agent. Without `--run-id` the conversation is standalone on this machine, resolved from the installed solution, and needs no server; with `--run-id <id>` it continues that run's session through the service (`--url` names a service on another host). An unreachable service is an error, never a silent fallback |
| `aicore build` | **Cora Build**, the solution builder: an interactive build session with `cora_build`, the dedicated builder agent, in the current repository. It creates content with the scaffold commands, writes the files they created, lints, and reports `git status`, while the console shows each action as it happens. Each repository keeps named, continuing conversations: `--session <name>` selects or creates one, `--message` runs one turn, and in the prompt `/new`, `/sessions`, `/switch` and `/rename` manage them. Every turn is checkpointed when the repository is under git: `/diff` shows what the last turn changed and `/undo` reverts it exactly, without touching the state directory or the user's staging area. `/remember <note>` appends to the repository's `CORABUILD.md`, which the builder reads at every session start. Local only. The Core Assistant (`cora`) remains the general-purpose assistant. The commands available inside a session and every option of this command are listed with an example in [Build session commands](./08-build-session-commands.md). |
| `aicore watch [run_id]` | Narrate a detached run as it progresses - step transitions and the agent's own output - and, when a step goes quiet past the recovery threshold, state whether it is recovering or stuck. Reports only; never intervenes. `--replay` streams a finished run's history, `--events-only` omits agent output, `--quiet-after <s>` sets the silence threshold |
| `aicore run-output --run-id <id>` | Read, write or publish a run's deliverables |

## Diagnostics

The `forensics` sub-app inspects the recorded execution of a run. See
[The Core Assistant](../06-core-assistant/01-overview.md) (`cora`), which reads
the same substrate and answers the same questions in conversation. Use the slug
wherever a command takes a role, for example
`aicore agent-chat --role cora -m "..."`.

| Command | Purpose |
|---|---|
| `aicore forensics explain <run_id>` | A one-command postmortem: what happened, why, and where to look next |
| `aicore forensics show <run_id>` | Reconstruct the event timeline for a run |
| `aicore forensics tail <run_id>` | Follow forensic events for a run in flight |
| `aicore forensics narrative <run_id> <step.attempt>` | Reconstruct one step attempt's session as readable dialogue |
| `aicore forensics stats <run_id>` | Per-attempt metrics for a run |
| `aicore forensics tokens <run_id>` | Exact token usage for a run, per step and in total |
| `aicore forensics blob <run_id> <step.attempt> [name]` | Print one recorded artifact from a step attempt — the prompt it was given, its output, or its exit record. Omit the name to list the artifacts recorded for that attempt |
| `aicore forensics is-recovering <run_id> <step_key>` | Whether the step's latest attempt is still in progress or being re-attempted. Exit `0` means it is safe to intervene; exit `10` means recovery is in progress and the step must be left alone |
| `aicore forensics list` | Recent runs that have forensic events |

## Recovery

Use these against a run that has already stopped, never one still executing. See
[Automatic recovery](../04-running-solutions/03-automatic-recovery.md).

| Command | Purpose |
|---|---|
| `aicore step-retry --run-id <id> --step-key <key>` | Reset a failed step to pending and raise its attempt allowance so it runs again. `--crash-recovery` resets a step left `running` by a process that died, without raising the allowance |
| `aicore step-skip --run-id <id> --step-key <key>` | Mark a step done with a skipped result so its dependents can proceed |
| `aicore resume [run_id]` | Continue an interrupted run: steps left `running` by a process that died are reset, then the run's driver is started again against the existing run. Refused for a completed run, and for a run whose driver is still alive unless `--force` is given |

## Workspaces and content distribution

The `workspace` sub-app manages tenant workspaces: creating them, granting
access, binding a repository and selecting the active one. See
[Managing workspaces](../04-running-solutions/07-managing-workspaces.md).

| Command | Purpose |
|---|---|
| `aicore workspace list` | All workspaces and the repository bound to each |
| `aicore workspace create <code>` | Create a workspace and grant access to it. `--member <email>` names who may open it (repeatable); `--no-member` creates the record and grants nobody |
| `aicore workspace show <code>` | What the workspace holds and who may open it |
| `aicore workspace attach <code> --url <url>` | Bind a solution repository to a workspace. `--branch` selects the branch (default `main`); `--credential-ref <VAR>` names the environment variable holding the repository token, which is never stored |
| `aicore workspace diff <code>` | What a pull would change, and what has diverged, for content imported under an earlier model; writes nothing |
| `aicore workspace push <code>` | **Deprecated**, and accepted for compatibility; performs no work and reports that it did none. There is no content tier to publish into — content reaches an environment through the repository, the build and the deployment |
| `aicore workspace pull <code>` | Content imported under an earlier model into the repository working tree. To carry an edit made in the Studio into a repository, use `aicore drafts apply` |
| `aicore workspace use <code>` | Set the active workspace |
| `aicore workspace rename <old> <new>` | Rename a workspace: every stored record, the on-disk content tree and the active selection move together |
| `aicore workspace delete <code>` | Remove a workspace and everything keyed to it. Refused while the workspace holds run history unless `--force` is given, which removes those records with it |

These two are top-level commands rather than part of the `workspace` sub-app:

| Command | Purpose |
|---|---|
| `aicore workflow-install <name>` | Copy a bundled workflow into the state directory so it can be edited locally |
| `aicore workflow-uninstall <name>` | Remove a locally installed workflow |

## Content drafts

The `drafts` sub-app works with Studio drafts — an author's unpromoted edits —
and carries them into a repository checkout for review and pull request. The
platform itself never commits or pushes; promotion is performed by a developer
with these commands. See
[Drafts and promotion](../03-building-solutions/12-drafts-and-promotion.md).

| Command | Purpose |
|---|---|
| `aicore drafts list` | Drafts in the workspace: item, author, status and base version |
| `aicore drafts show <id>` | One draft's changed files, status and base pin |
| `aicore drafts diff <id>` | Compare a draft against the solution content installed on this machine |
| `aicore drafts apply <id>` | Write a draft's files into the current repository checkout for review, commit and pull request; marks the draft applied. Refuses a checkout with uncommitted changes at the target path unless `--force` is given. Add `--dir <path>` when the solution package is not the current directory or one above it (a package inside a larger repository) |
| `aicore drafts migrate` | Convert content created in the Studio before drafts existed into drafts. Idempotent; `--dry-run` reports without writing |

## MCP servers and external agents

See [MCP tools](../03-building-solutions/04-mcp-tools.md) and
[External agents](../03-building-solutions/05-external-agents.md).

| Command | Purpose |
|---|---|
| `aicore mcp-list` | The effective MCP server view a run would get, with the tier that supplied each |
| `aicore mcp-list --probe` | The same view, plus one real request to each remote server and the status it returned. `--probe-timeout` sets the seconds allowed per server |
| `aicore mcp-add <name> ...` | Add or update an MCP server at the machine tier, or at the workspace tier with `--workspace <code>` |
| `aicore mcp-remove <name>` | Remove an MCP server declaration from one tier |

`aicore mcp-add` and `aicore new-mcp-server` take the same authentication
options. A static credential is declared as a header with `--header`. An OAuth
client-credentials grant, which the runtime performs and renews itself, is
declared with the options below; a partial set is refused, naming the option
that is missing.

| Option | Value |
|---|---|
| `--auth-type` | The grant: `oauth2_client_credentials`. An authorization-code flow needs a browser and a redirect URI, which an agent runtime has nowhere to put; terminate that flow in a gateway and declare the gateway's credential instead |
| `--auth-token-url` | The token endpoint |
| `--auth-client-id` | The client identifier, written as a `${VAR}` reference — the value belongs in the workspace `.env` |
| `--auth-client-secret` | The client secret, written as a `${VAR}` reference, never the value itself |
| `--auth-scope` | The scope requested; optional |
| `--auth-audience` | The audience, where the server requires one; optional |
| `aicore a2a-add <name> <url> ...` | Register an external agent for a workspace |
| `aicore a2a-list` | List a workspace's registered external agents and whether their credentials resolve |
| `aicore a2a-remove <name>` | Remove a registered external agent |

## Tool provisioning

The `cli-hub` sub-app validates and installs the CLI tools that solutions
declare. See [Command-line tools](../03-building-solutions/02-command-line-tools.md).

| Command | Purpose |
|---|---|
| `aicore cli-hub list` | The tools every installed pack declares, with current presence |
| `aicore cli-hub check` | Validate-only pass: exit 0 when all present, 3 when there are gaps |
| `aicore cli-hub install` | Validate or install every declared CLI tool |

## Improving solutions

The `learning` sub-app is the steward review workflow for agent-authored
methods. See [Governing what is learned](../05-improving-solutions/03-governing-what-is-learned.md).

| Command | Purpose |
|---|---|
| `aicore learning pending` | List every learning draft awaiting a decision, with its scope, evidence and security verdict |
| `aicore learning show <id>` | Show a draft's full body, why it was authored, and its scan findings |
| `aicore learning approve <id> --as <who>` | Approve a draft so agents in its scope receive it; refused if the security scan is dangerous |
| `aicore learning reject <id> --as <who> --reason "..."` | Reject a draft so it never reaches an agent |
| `aicore learning audit` | The approval and rejection trail |

## Deployment

See [Deploying as a service](../04-running-solutions/04-deploying-as-a-service.md).

| Command | Purpose |
|---|---|
| `aicore serve` | Start the web API server that creates runs, streams output and answers always-available agents. `--workspace <code>` names the one workspace the service serves, and wins over `IOF_WORKSPACE` and the stored selection; `--host`, `--port` (default `8111`) and `--root` set the binding and state directory; `--concurrency <n>` bounds concurrent model requests per agent. The service fails at startup where no workspace is named |
| `aicore supervise` | Run the supervisor that detects and recovers stuck runs. The service performs this sweep itself; run it separately where recovery must continue independently of the API. `--once` performs a single sweep, for a scheduler; `--interval <s>` sets the period; `--run-id <id>` scopes the sweep; `--no-resume` resets stale steps without restarting drivers |
| `aicore configure-agent <role> <metadata_dir>` | Deploy domain metadata into an always-available agent's workspace |
| `aicore start-gateway` | Run the project lead in gateway mode for a long-lived interactive channel |
| `aicore heartbeat-log` | Show the heartbeat ticks recorded in gateway mode |

## Isolated execution

Consulted where the deployment runs solutions in isolated sandboxes. See
[Sandboxed execution](../04-running-solutions/06-sandboxed-execution.md).

| Command | Purpose |
|---|---|
| `aicore sandbox-list` | The sandbox configuration every workflow declares |
| `aicore sandbox-status` | Active sandbox instances and their state |
| `aicore policy-validate` | Validate isolation policy files before a deployment relies on them |

## Tools agents invoke

These console tools are invoked by agents during a run, and can be run directly
to verify behaviour.

| Tool | Purpose |
|---|---|
| `iof-query` | Query catalogued structured data with SQL; results are grounded in the catalog. See [Grounding agents in your data](../03-building-solutions/03-grounding-in-data.md) |
| `iof-consult` | Send a question to an external agent over the Agent2Agent protocol |
| `iof-recall` | Search prior runs' step outputs, scope-isolated, for reuse |
| `iof-run-audit` | Summaries of a run's cost, token usage and bottlenecks |
| `iof-plays` | The playbook catalog: list, show and match playbooks, render the authoring template, review and approve compilations, read unmatched and capability requests. See [Playbooks](../03-building-solutions/10-playbooks.md) |
| `iof-case` | Case records and rulebooks: open cases, relay events, declare and dispatch deliveries, run the scheduler, explain, audit, simulate and report. See [Operating playbooks](../04-running-solutions/08-operating-playbooks.md) |

## Related pages

- [Workflow definition reference](./02-workflow-yaml.md)
- [Build session commands](./08-build-session-commands.md)
- [Environment variables](./07-environment-variables.md)
- [Getting help](../08-troubleshooting/02-getting-help.md)

**Next:** [Workflow definition](./02-workflow-yaml.md).
