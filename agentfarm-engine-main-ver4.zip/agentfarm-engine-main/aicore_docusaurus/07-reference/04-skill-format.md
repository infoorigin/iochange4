---
sidebar_position: 4
title: Skill format
description: "The structure of a skill: its directory, its frontmatter keys, how supporting files are used, and how a skill reaches the agent that needs it."
---

# Skill format

A skill is authored judgement: how to assess something, what to prioritise,
what a good result looks like, and how to use a capability correctly. It is
written once and assigned to the agents that need it.

A skill is a directory containing `SKILL.md` and, optionally, supporting
files.

```text
skills/
  contract_review/
    SKILL.md
    references/
      exception-categories.md
      escalation-thresholds.md
    scripts/
      extract_terms.py
```

## `SKILL.md`

The file begins with YAML frontmatter, followed by the instruction body in
Markdown.

```markdown
---
name: contract_review
description: "Assess supplier contracts for commercial exceptions: pricing deviation, term drift, and unapproved auto-renewal."
---

# Contract review

Assess each contract against the terms recorded for its supplier.

## What to check

1. Unit pricing against the contracted schedule...
```

### Frontmatter keys

| Key | Type | Required | Meaning |
|---|---|---|---|
| `name` | string | Yes | The skill's identifier. Must match the directory name. This is the name used to assign the skill and to reference it in a workflow role's `skills` list. |
| `description` | string | Yes | What the skill is for, in one or two sentences. This is the line an agent matches a task against when deciding whether the skill applies, so it must state the job rather than the mechanism. |
| `always` | bool | No | When `true`, the skill's full text is placed in the agent's context on every request, without being named. Default `false`, which advertises the skill and leaves the agent to read it when it applies. See [How a skill reaches the agent](#how-a-skill-reaches-the-agent). |
| `roles` | list | No | The agents that carry the skill when a workspace is first prepared. It is a starting assignment only: it never restricts which agent may be given the skill, and `aicore lint-skill` reports it as a key that gates nothing. Prefer placement or `aicore assign-skill`. |

Always quote the `description`. An unquoted value containing a colon followed
by a space makes the whole frontmatter unparseable, and the skill then loads
with no name and no description — it is advertised nowhere and never matched
to a job. `aicore lint-skill <path>` reports this and the other frontmatter
mistakes with the line and the fix; run it after every skill edit.

### How a skill reaches the agent

Carrying a skill is not the same as applying it. A skill assigned to an agent
reaches its context in one of two ways, decided by `always`.

| `always` | What is placed in the agent's context | Applies when |
|---|---|---|
| `true` | The skill's **full text**, on every request, before the agent begins. | The judgement governs how the agent works generally — an output contract, a formatting rule, a grounding discipline, a safety boundary. |
| omitted or `false` | The skill's **name, `description` and file path** only. The agent reads the file if it judges the skill relevant. | The judgement applies to a particular kind of task, and loading it every time would spend context on requests that never need it. |

Both tiers are in normal use: roughly half the skills the platform ships are
always-on and half are on demand.

An on-demand skill applies when something points the agent at it — a workflow
step prompt that describes the job in the skill's own terms, or a request that
plainly matches its `description`. It does **not** apply reliably when the
request is a complete, self-contained instruction the model can satisfy
directly: the agent answers, having never opened the file. Nothing fails, and
nothing reports a problem — the skill did not participate.

Consequences for authoring:

- A rule that must hold for **every** answer needs `always: true`. Format
  contracts, refusal boundaries and grounding rules belong here.
- For an on-demand skill, write the `description` as the **situation that
  triggers it**, not the mechanism. "When a delivery window was missed and the
  carrier disputes it" is matchable; "helper for the deliveries table" is not.
- In a workflow, name the skill in the step's `skills` list **and** describe
  the job in the step prompt. The list controls what the agent carries; the
  prompt is what makes an on-demand skill fire.

### Naming

Skill names are lowercase words separated by underscores — `contract_review`,
`output_protocol`, `data_query`. Every skill the platform ships follows this
convention, and `aicore new-skill` writes it.

The **directory name is authoritative**. The runtime resolves a skill as
`skills/<name>/SKILL.md`, and a workflow role's `skills` list names that same
string. The frontmatter `name` is documentation and is kept identical to the
directory so the two never disagree.

:::note An editor may flag the underscore
Some editors validate any file called `SKILL.md` against an unrelated
skill format that requires hyphenated names, and will mark the underscore
as invalid. AI Core applies no such rule. The warning comes from the editor,
not the platform, and has no effect on how the skill loads or runs — hover
the warning to see which extension raised it. Renaming a skill to hyphens to
satisfy it is unnecessary, and breaks the skill unless the directory and
every `skills` list that names it are renamed to match.
:::

Additional optional metadata keys exist for specialised cases. They are not
required for authoring a skill; contact platform support if a requirement
appears to need one.

### `always: true`

Use it for skills that establish a contract the agent must observe on every
step - an output format, a grounding discipline, a compliance rule - rather
than for capabilities that apply to particular tasks.

An `always: true` skill is still subject to a role's `skills` list. Where a
workflow role declares that list, it is the exact set loaded, and an
`always: true` skill not named in it is dropped. Name every skill a role's
steps require.

## Writing the body

The body is instruction to an agent, and it is loaded into context whenever
the skill is active. Two properties follow from that.

- **State the judgement, not the syntax.** An agent knows how to run a command
  and how to write Markdown. Write what to assess, what thresholds matter, what
  to do with an ambiguous case, and what the finished result must contain.
- **Keep the file to what applies every time.** Detail that applies only in
  particular circumstances belongs in a supporting file the agent reads when
  it becomes relevant.

## Supporting files

Files alongside `SKILL.md` are available to the agent but are not loaded into
context until the agent reads them. This keeps the resident cost of a skill
proportional to what it always needs.

| Directory | Contains |
|---|---|
| `references/` | Detailed material consulted for specific cases: category definitions, threshold tables, worked examples, formatting specifications |
| `scripts/` | Helper code with a single consumer, invoked by the skill |

Reference them from the body by path so the agent knows when to open them:

```markdown
For the full exception taxonomy, read `references/exception-categories.md`.
```

A helper script with a single consumer may sit in `scripts/`. Where a script
is needed by more than one skill or agent, build it as a command-line tool
instead so it is installed on the path and declared once. See
[Command-line tools](../03-building-solutions/02-command-line-tools.md).

## Where a skill lives, and who carries it

Placement determines assignment.

| Location | Assignment |
|---|---|
| `agents/<role>/workspace/skills/<name>/` | Assigned to that agent by its location. No further declaration is required |
| A pack-level `skills/` directory | Held by no agent until assigned by name, or named by a workflow role's `skills` list |

Create a skill in either place with the scaffold command:

```bash
aicore new-skill contract_review --role analyst    # in the agent's workspace
aicore new-skill contract_review                   # pack level
```

Assign a pack-level skill to an agent without copying it:

```bash
aicore assign-skill contract_review --role analyst
aicore unassign-skill contract_review --role analyst
```

Assignment records that the agent carries the skill. The skill itself stays in
one place, so assigning it to several agents does not create copies that
diverge.

## How a step resolves a skill

An agent's assigned skills are its baseline. A workflow role's `skills` list
declares what the job requires, and is resolved from the whole workspace
catalog - it may name a skill the agent does not normally carry.

Where a skill named in a `skills` list cannot be found anywhere in the
workspace, the run reports it. A skill that is not found is not silently
substituted.

## Related pages

- [Agents and skills](../03-building-solutions/01-agents-and-skills.md)
- [Workflow definition reference](./02-workflow-yaml.md)
- [Command-line interface](./01-cli.md)

**Next:** [Registry files](./05-registries.md).
