---
sidebar_position: 5
title: Registry files
description: The declaration files that make command-line tools, MCP servers and external agents available to a solution - their schemas, their placement, and how each is provisioned.
---

# Registry files

Three kinds of capability are declared rather than assigned: command-line
tools, MCP servers, and external agents. Each has a declaration file, and each
is provisioned differently.

| Capability | Declared in | Provisioned by |
|---|---|---|
| Command-line tools | `tools.yaml`, at the solution root | `aicore cli-hub install`; `aicore serve` validates them at start-up and refuses to start when one is missing |
| MCP servers | `mcp.yaml`, at the solution root | Run preparation, from the merged declarations |
| External agents | The workspace registry, managed by `aicore a2a-add` | Run preparation, from the workspace registry |

A skill names the capability it uses. The declaration is what puts that
capability in place. Both are required: a skill that instructs an agent to run
a binary nobody installed causes the agent to attempt it and consume the
step's attempts on a command that does not exist.

## `tools.yaml` - command-line tools

Declares the executables a solution's agents invoke. Placed at the solution
root, alongside the package definition.

```yaml
tools:
  - name: contract-extract
    owner: domain
    installer: pip
    package: my-solution
    bin: contract-extract

  - name: term-diff
    owner: domain
    installer: npm-global
    package: "@my-org/term-diff"
    bin: term-diff
    check: "term-diff --version"
```

| Field | Type | Required | Meaning |
|---|---|---|---|
| `name` | string | Yes | The tool's identifier, used by `cli-hub` and referenced when creating a skill for it |
| `owner` | string | Yes | `domain` for a tool this solution owns. Tools the platform provides declare their own tier |
| `installer` | string | For a tool that may need installing | How to install it if absent: `pip`, `npm`, `npm-global`, `brew`, or `build` |
| `bin` | string | Yes | The executable name. Its presence on the path is the validation check |
| `package` | string | For registry installers | The package to install |
| `check` | string | No | A command to run instead of a path lookup. A zero exit means the tool is present |
| `build` | mapping | For `installer: build` | A build recipe. See below |

Provisioning validates first: where the executable is already present, nothing
is installed. Only a genuine gap triggers an install.

```bash
aicore cli-hub list       # what is declared, and what is present
aicore cli-hub check      # validate only: 0 all present, 3 gaps, 1 error
aicore cli-hub install    # install the gaps
aicore cli-hub install --dry-run --only contract-extract
```

`cli-hub check` is the command to run in a deployment pipeline. It performs no
installation and fails when a declared tool is absent.

### `installer: build`

For a tool with no registry artifact, declare how to build it. Build steps run
commands, so building is opt-in: it requires `--allow-build` on the install
command. Restrict build sources to internally controlled repositories.

```yaml
  - name: term-diff
    owner: domain
    installer: build
    bin: term-diff
    build:
      repo: "git+https://git.example.com/my-org/term-tools.git"
      ref: "v1.4.0"
      subdir: "."
      steps:
        - "npm install"
        - "npm run build"
        - "npm link -w term-diff"
```

A build runs only where validation proves the tool absent, so a tool already
provided by the deployment image is never rebuilt.

## `mcp.yaml` - MCP servers

Declares the MCP servers a solution's content requires. Placed at the solution
root. The top-level key is `mcp_servers`, and each entry is named.

```yaml
mcp_servers:
  github:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"

  search:
    url: "https://mcp.example.com/mcp"
    headers:
      Authorization: "Bearer ${MCP_SEARCH_TOKEN}"
    toolTimeout: 60
    enabledTools: ["search", "fetch"]

  vendors:
    url: "https://vendors.example.com/mcp"
    auth:
      type: oauth2_client_credentials
      token_url: "https://vendors.example.com/token"
      client_id: "${VENDORS_CLIENT_ID}"
      client_secret: "${VENDORS_CLIENT_SECRET}"
      scope: "mcp:tools"
```

An entry declares either a local server the platform launches, or a remote
server it connects to.

| Field | Applies to | Meaning |
|---|---|---|
| `command` | Local | The executable to launch |
| `args` | Local | Arguments passed to it |
| `cwd` | Local | Working directory |
| `env` | Local | Environment for the server process |
| `url` | Remote | The server endpoint |
| `type` | Remote | The transport, where it must be stated explicitly |
| `headers` | Remote | Headers sent with each request, including a static credential |
| `auth` | Remote | An OAuth grant the platform performs itself, obtaining the token and renewing it before it expires |
| `toolTimeout` | Both | Seconds before a tool call is abandoned |
| `enabledTools` | Both | Restricts the solution to the named tools. Omitted, every tool the server exposes is available |
| `enabled` | Both | `false` suppresses a declaration of the same name made at a lower tier, without removing it there |

An `auth` block declares one grant, `oauth2_client_credentials`. `token_url`,
`client_id` and `client_secret` are required; `scope` and `audience` are
supplied where the server requires them. Declare the block with the `--auth-*`
options of `aicore new-mcp-server` and `aicore mcp-add` rather than by hand: a
partial block is refused by those commands, and reaches connect time as an
unexplained rejection when it is written directly.

Values of the form `${NAME}` are resolved from the environment at run
preparation, in an `auth` block as in `headers` and `env`. Declare credentials
this way rather than writing them into the file. A server with an unresolved
reference is dropped from the run's configuration and named.

`enabledTools` is worth setting. A server that exposes a broad tool surface
enlarges every prompt in which it is available, and restricts nothing.

The equivalent commands operate on the workspace rather than the solution:

```bash
aicore mcp-list
aicore mcp-add search --url https://mcp.example.com/mcp --tool-timeout 60
aicore mcp-remove search
```

A swarm's `mcp_servers` roster selects from what is declared. See the
[swarm definition reference](./03-swarm-yaml.md#roster-semantics).

## External agents

External agents are registered per workspace, because the endpoints and
credentials belong to the deployment rather than to the solution.

```bash
aicore a2a-add partner-insights https://partner.example.com/a2a/insights \
  --description "Partner market-insights agent: share, growth and competitive queries" \
  --tag market-share --tag partner \
  --example "Which regions grew share last quarter?" \
  --header "Authorization: Bearer \${PARTNER_A2A_TOKEN}"

aicore a2a-list
aicore a2a-remove partner-insights
```

The registry the commands maintain has the following shape:

```yaml
agents:
  - name: partner-insights
    description: "Partner market-insights agent: share, growth and competitive queries"
    a2a_url: "https://partner.example.com/a2a/insights"
    tags: [market-share, partner]
    examples: ["Which regions grew share last quarter?"]
    headers:
      Authorization: "Bearer ${PARTNER_A2A_TOKEN}"
```

| Field | Required | Meaning |
|---|---|---|
| `name` | Yes | The identifier used in a swarm roster |
| `a2a_url` | Yes | The agent's endpoint |
| `description` | In practice | What the agent answers |
| `tags` | In practice | Subject areas it covers |
| `examples` | In practice | Representative questions it handles |
| `headers` | No | Authentication for this endpoint |

**`description`, `tags` and `examples` are what routing decisions match
against.** An entry without them is registered but not routable: a meta-agent
has no basis on which to select it. The registration command reports their
absence.

A swarm's `agents` roster selects from this registry. See the
[swarm definition reference](./03-swarm-yaml.md#roster-semantics).

## `deliveries.yaml` - case delivery tools

A playbook's actions reach the world through tools the workspace declares,
never through tools named in the playbook. `deliveries.yaml` names, per
delivery kind, the tool that performs it.

```yaml
email:
  tool: mcp_crm_send_field_email
  recipients: [Brand Marketer, Brand Lead, Marketing Director]
monitoring_task:
  tool: mcp_crm_create_monitoring_task
verification:
  tools: [mcp_crm_get_rep_alignment]
```

| Key | Purpose |
|---|---|
| `email.tool` | The tool that sends a notice. Tool names are the MCP tool names as the runtime exposes them |
| `email.recipients` | The roles the workspace can notify. When present, a playbook addressing any other role is refused with the nearest declared name; when absent, any role is accepted |
| `monitoring_task.tool` | The tool that creates a monitoring task |
| `verification.tools` | The tools an action's `verification` may read the ground truth from |

Three tiers, the most explicit winning: `IOF_CASE_DELIVERIES` as a JSON object
in the deployment's environment; the workspace's own file at
`~/.iobot/workspaces/<code>/deliveries.yaml`; and the file in the workspace
package, which the scaffold writes beside `tools.yaml`. A rulebook whose
action delivers by a kind no tier declares a tool for is refused at install,
naming the kinds that are declared. `iof-case deliveries` shows what resolves
and where it came from. See [Playbooks](../03-building-solutions/10-playbooks.md#what-the-workspace-declares).

## Related pages

- [MCP tools](../03-building-solutions/04-mcp-tools.md)
- [External agents](../03-building-solutions/05-external-agents.md)
- [Command-line tools](../03-building-solutions/02-command-line-tools.md)
- [Playbooks](../03-building-solutions/10-playbooks.md)
- [Command-line interface](./01-cli.md)

**Next:** [Data catalog](./06-data-catalog.md).
