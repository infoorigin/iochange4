---
sidebar_position: 2
title: Workflow definition reference
description: Every key in workflow.yaml - its type, its default, and what happens when it is set incorrectly - together with the template variables available in prompts.
---

# Workflow definition reference

A workflow is a directory containing a definition file, one prompt file per
role, one prompt file per step, and optionally the metadata the workflow's
agents read.

```text
workflows/
  order-exceptions/
    workflow.yaml
    roles/
      analyst.md
    steps/
      pull.md
      check.md
      report.md
    metadata/
      catalog.yaml
```

:::danger An unrecognised key is not rejected - it is never read
Definition files are read permissively. A key the platform does not recognise
does not raise an error; the setting it was carrying has no effect.

```yaml
requires_artifact: [report.md]     # one missing character
```

That definition loads successfully, and the artifact gate it was meant to
declare is not in effect. The run reports success, and a later step composes
its output from a file that was never written.

Validate before running:

```bash
aicore lint-workflow <name-or-path>
aicore lint-workflow --all --strict
```

The linter reports every problem at once with a line number and a correction,
and exits non-zero on errors.
:::

## Shape

```yaml
name: order_exceptions          # must equal the directory name
description: >
  Reports contract exceptions in yesterday's orders.

learning: disabled

vars:
  window_days: "180"            # values must be quoted strings

team:
  - role: analyst

roles:
  - name: analyst
    prompt: roles/analyst.md
    skills: [catalog_reader, grounded_analysis]

steps:
  - key: pull
    title: Retrieve orders
    role: analyst
    prompt: steps/pull.md
    max_attempts: 2
    requires_artifacts: [orders.json]

  - key: report
    role: analyst
    prompt: steps/report.md
    deps: [pull]
    requires_artifacts: [report.md]
```

## Top-level keys

### `name`

**string, required.** Must equal the directory name.

Everything that addresses a workflow - listing, running, resolving its
metadata - uses the directory name. Where `name` disagrees with it, the
workflow still runs but `{{metadata_dir}}` does not resolve to this workflow's
metadata, so any step that reads a catalog reads the wrong one or none.
Omitting `name` fails at load.

### `description`

**string, optional. Default empty.**

Shown wherever a workflow is presented for selection. A workflow without one
is unlabelled in every list.

### `learning`

**string, optional. Default absent, which means learning is enabled.**

`learning: disabled` gives each step an empty memory file and records no
observations from the run.

Only a fixed set of values is honoured. Any other value leaves learning
enabled.

| Value | Effect |
|---|---|
| `disabled`, `false`, `no`, `off`, `n` | Learning off |
| `enabled`, `true`, `yes`, `on` | Learning on |
| `none`, `disable`, `0`, empty | **Learning on.** These read as instructions and are not honoured |

:::warning Quoting the value changes the outcome
`no`, `off`, `n` and `yes`, `on` are honoured because an unquoted value is
read as a boolean. Quote one and it becomes ordinary text that matches
nothing, so `learning: "no"` leaves learning **on** while `learning: no`
turns it off. `disabled` is the unambiguous spelling and is not affected by
quoting; write that one.
:::

Disable learning on any workflow whose steps produce findings. With learning
enabled, what an agent concluded on one run is carried into the next, and the
later run reasons from figures that belonged to different data. The linter
rejects any value outside the two honoured sets.

### `vars`

**mapping of string to string, optional. Default empty.**

Template variables available in step prompts and in `command` strings as
`{{key}}`. Override at launch with `aicore run <workflow> --var key=value`.

```yaml
vars:
  window_days: "180"
  brand: ""
```

Values must be quoted. An unquoted number fails validation at load. A
misspelled `vars` key is never read, and every `{{key}}` that names it — in a
prompt or in a `command:` — then renders as an **empty string**, not as the
literal text: a command line silently loses an argument. `lint-workflow` warns
about any placeholder nothing supplies; run it after every edit.

### `team`

**list of `{role: <name>}`, optional. Default empty.**

The roster presented in the interface. It is display only - a roster entry
does not make a role available to a step. An entry missing its `role` key
fails at load.

### `sandbox`

**mapping, optional. Default none.**

Isolation settings, consulted where the deployment is configured to run
solutions in isolated sandboxes.

| Field | Type | Default | Meaning |
|---|---|---|---|
| `policy` | string | `default` | The named isolation policy to apply |
| `prewarm` | bool | `false` | Create the sandbox when the service starts |
| `idle_timeout` | int | `300` | Seconds before an idle sandbox is destroyed; `0` never destroys it |
| `pool` | string | none | Share one sandbox across workflows naming the same pool |
| `image` | string | none | Container image to use |

`policy` and `pool` accept letters, digits, underscore and hyphen only, to a
maximum of 64 characters. A misspelled field name is not read, and the default
applies.

### `depends_on_runs`

**list of workflow names, optional. Default empty.**

The workflows this one consumes output from. A run is refused while any of
them still has a run in progress; the refusal names the run in the way. The
platform never waits on the caller's behalf. `aicore run --allow-concurrent`
overrides the refusal for one run, which then works from a partial input set.

### `single_active_run`

**bool, optional. Default `false`.**

When `true`, a second run of this workflow is refused while one is active.
Set it on a workflow that consumes its own queue.

The refusal names the active run. When that run's driver has stopped sending
heartbeats it says so (`driver GONE - no heartbeat for <n>s`) and prints the
`aicore resume <id>` line, because a run whose driver was killed holds the
queue until something restarts it. `--allow-concurrent` overrides the refusal.

### `coverage`

**list, optional. Default empty.**

Commands the platform executes when the run completes, whose output states
what the run did not process. The result is recorded against the run and
shown beside the verdict of `aicore forensics explain`. It is a report, never
a gate: a remaining backlog does not fail the run.

### `roles`

**list, required in practice.** See [Role keys](#role-keys).

### `steps`

**list, required.** See [Step keys](#step-keys).

## Role keys

### `roles[].name`

**string, required.** The identifier steps reference in their `role` key.

### `roles[].prompt`

**string, required.** Path to the role's prompt file, relative to the workflow
directory. This file establishes what the role is responsible for across every
step it runs: it is rendered with the same variables as a step prompt and
placed ahead of the step's instructions on every step the role runs. Keep the
standing brief here — responsibilities, the evidence conclusions must rest on,
what the role declines — and leave each step's task to the step prompt.

### `roles[].skills`

**list of strings, optional. Default omitted, meaning all of the agent's
assigned skills load.**

When present, the list is the **exact** set loaded for this role. Any skill not
named is dropped, including skills the agent normally always loads. Name every
skill the role's steps require.

```yaml
skills: [catalog_reader, grounded_analysis]
```

An omitted list is not the same as an empty one. `skills: []` loads nothing
beyond the output contract.

### `roles[].model`

**string, optional. Default the deployment's configured model.**

Overrides the model for this role, in `provider/model` form.

### `roles[].allowed_tools`

**list of strings, optional. Default empty, meaning no restriction.**

Restricts the tools available to the agent while it runs this role's steps.

## Step keys

### `steps[].key`

**string, required.** Unique within the workflow. Referenced by other steps in
`deps`, and used to address the step in status and diagnostic commands.

### `steps[].title`

**string, optional. Default empty.** Shown in progress output.

### `steps[].role`

**string, required except for `type: exec`.** Must name a declared role.

### `steps[].type`

**`normal`, `loop`, `exec` or `route`. Optional. Default `normal`.**

| Type | What runs | Fan-out source |
|---|---|---|
| `normal` | One agent, one prompt | Not applicable |
| `loop` | One agent that emits a set of items to fan out over | Its own emitted set |
| `exec` | A command, with no agent and no model calls | The `stories_from` manifest |
| `route` | A command that then chooses which of its declared `routes:` run | Not applicable |

An unrecognised value fails at load. See `steps[].routes` and
`steps[].on_fail` below for the two ways a pipeline turns on its own output.

Where a step's correct behaviour can be expressed as a script, use `type: exec`.
It consumes no model calls and produces the same result on every run.

### `steps[].prompt`

**string, required for `normal` and `loop` steps.** Path to the step's prompt
file, relative to the workflow directory.

### `steps[].deps`

**list of step keys, optional. Default empty.**

Declares which steps must complete before this one starts. Dependencies are
the entire sequencing mechanism; a step with no `deps` may start as soon as the
run begins. A step that consumes another step's output must declare it.

### `steps[].max_attempts`

**integer of at least 1, optional. Default 2.**

How many times the step may be attempted before the run fails. Each attempt is
a full re-execution. Raising this on a step whose failure is deterministic
repeats the same failure at greater cost.

### `steps[].requires_artifacts`

**list of filenames relative to the step's output directory, optional. Default
empty.**

The fail-closed gate, and the highest-value line in the file. When a declared
artifact is missing or empty at the end of a step, the step is marked failed
and retried, **even where the agent reported success**.

Without it, a step can report success having written nothing, the run
advances, and a later step composes its output from a file that does not
exist.

```yaml
requires_artifacts: [report.md]
```

Declare it on every step whose output another step consumes. The linter warns
where a handoff is left ungated.

### `steps[].command`

**string, required for `type: exec`, ignored otherwise.**

A command's output is data. Its exit code is the only verdict: non-zero
fails the step, zero passes it to the artifact gate. A `STATUS:` or `OUTPUT:`
line the command prints is recorded as text and never read as the step's
result (it appears in the record prefixed with `| `). `{{step_output.<key>}}`
of a command step is that record: the command line, and the tails of its
stdout and stderr.

The command to run. Templated with the same variables as prompts, then run
through the system shell of the machine the run is on (`cmd.exe` on Windows,
`/bin/sh` elsewhere — so `&&` chains on both, `;` only on Linux). Two
consequences:
quote a `{{var}}` whose value may contain spaces (`--label "{{label}}"`), and
treat a value that reaches a command from outside — a `--var` on the command
line — as text the shell will read. Use a folded block for multi-line
commands. `aicore lint-workflow` warns when a `vars:` placeholder, `{{goal}}`,
`{{story_id}}` or `{{feedback}}` appears unquoted in a `command:`; the engine's
own paths (`{{output_dir}}`, `{{metadata_dir}}`, `{{run_id}}`) are safe bare.

```yaml
- key: prepare_batches
  type: exec
  command: >-
    my-tool batch --size {{batch_size}} --out {{output_dir}}
  stories_from: batch_manifest.json
  requires_artifacts: [batch_manifest.json]
```

An `exec` step with no command fails at load. A `command` on a `normal` step is
never executed; the step runs its agent as usual. A non-zero exit fails the
step, which is then retried under its attempt budget. A command that exits 0
may still fail its step deliberately by printing a line `STATUS: failed` on
its standard output — `aicore forensics explain` reports that as "the tool
itself reported failure"; keep `STATUS:` out of ordinary output otherwise.

The command's own output is kept with the step:
`aicore status --run-id <id> --step <key>` shows its stdout and stderr, and
`aicore forensics explain <id>` names the last line of stderr as the failure
reason. Every step of a run
writes into ONE shared directory, `{{output_dir}}`, so a file one step writes
is the next step's input by path — see
[How data moves between steps](../03-building-solutions/13-data-between-steps.md).

### `steps[].timeout`

**integer seconds, optional. Default none.**

A wall-clock bound on one attempt of an `exec` or `route` step. When it is
reached the command and every process it started are stopped, the attempt
fails with `timed out after <n>s` in its stderr, and the step is retried
under its attempt budget. An agent step has no per-step timeout; the run's
supervisor bounds it.

```yaml
- key: compute
  type: exec
  command: my-tool compute --out {{output_dir}}
  timeout: 900
```

### `steps[].routes`

**list of step keys, required for `type: route`, refused otherwise.**

A route step prints exactly one `ROUTE_JSON:` line on its standard output
(the SDK's `route.next(...)` does this). Standard error is never read for it. If
more than one line is printed the last one decides and the run records
`step.route_ambiguous` as a warning.

The steps a `route` step may choose between. The command runs, then names
which of these run next — by printing one line on its standard output,
`ROUTE_JSON: {"next": ["deep_dive"]}` (a bare list, `ROUTE_JSON:
["deep_dive"]`, is read the same way), or, in a Python tool, through the SDK
helper `route.next("deep_dive")`, which writes that line and accepts either
several names or one list. Every
route it does not choose is closed: marked done with a note, so the steps
behind the closed branch that depend on nothing else never run. Choosing a
key outside `routes:` fails the step (`step.route_undeclared`). Choosing
nothing — `route.next()` with no names, or `ROUTE_JSON: []` — is a valid
decision: every route is closed, a join downstream proceeds, and the run
converges having done no work past the route; `aicore forensics explain`
warns about it, and a later prompt reads a closed step's
`{{step_output.<key>}}` as `(closed - not chosen by route ...)`.

```yaml
- key: triage
  type: route
  command: iof-acme-triage --out {{output_dir}}
  routes: [deep_dive, quick_answer]
- key: deep_dive
  deps: [triage]
  ...
- key: quick_answer
  deps: [triage]
  ...
```

A route target should depend on the route step. A target that has already
run when the decision is made cannot be un-run; the run records
`step.route_target_already_ran` and `forensics explain` reports it.

### `steps[].on_fail`

**mapping `{reset: <step key>, feedback: <file>}`, optional.**

What to do when this step fails: reset an EARLIER step to pending so the
pipeline re-runs from there, with a note for it. The command (or agent)
writes the note to `feedback:` (default `feedback.md`) in the shared
directory — through the SDK, `route.fail("the totals do not reconcile")` —
and the reset step's next attempt receives it as `{{feedback}}` in its prompt
and `IOF_STEP_FEEDBACK` in its environment. **The loop is bounded by this
step's own `max_attempts`** — the gate's, not the reset step's: a reset
step's re-runs are free (`aicore status` shows them as `3/2 (reset by
verify; resets are free)`), and when the gate has failed on its last attempt
the run fails with `step.on_fail_exhausted`. `reset:` takes one step key or
a list of them.

The engine hands the declared file name to the step as `IOF_FEEDBACK_FILE`;
`route.fail(note)` writes the note there, so the SDK and the definition
cannot disagree about the file (`route.fail(note, file=...)` still
overrides). A reset step reads it as `{{feedback}}` and `IOF_STEP_FEEDBACK`.

```yaml
- key: draft
  role: writer
  prompt: steps/draft.md         # may read {{feedback}}
  max_attempts: 3
- key: verify
  type: exec
  deps: [draft]
  command: iof-acme-verify --out {{output_dir}}
  on_fail: {reset: draft, feedback: feedback.md}
```

`reset:` must name a step this one depends on, directly or through others;
the linter refuses a forward or unrelated target.

### `steps[].fresh_session`

**bool, optional. Default `true`.**

Each attempt of the step starts from a fresh agent session. Set `false` to
continue the role's session from the previous step within the same run.

### `steps[].mcp_tools`

**list of tool names, optional. Default omitted.**

The MCP tools the step's agent may use, enforced by the platform rather than
by the prompt. Omitted, every tool of every server in scope is available. A
list makes exactly those tools available, named either as the server exposes
them or as `mcp_<server>_<tool>`. `mcp_tools: []` gives the step no MCP tools.
The same key applies to a per-item template.

### `steps[].stories_from`

**string naming a JSON file in the step's output directory, optional.
`type: exec` only.**

Lets a command anchor a fan-out. The platform reads the file's top-level
`stories` array - or the whole file where it is itself an array - and uses it
as the step's item set, so no agent has to transcribe a manifest a command has
already written.

On a `normal` or `loop` step the key is never read and no items are produced.
On an `exec` step, a missing or malformed file fails the step.

### `steps[].per_item_steps`

**list of templates, optional. Default empty.**

The work performed once per item, materialised as
`story:<item_id>:<key_suffix>`. Meaningful only on a `loop` step, or an `exec`
step with `stories_from`.

:::warning A workflow may declare only one fan-out anchor
Where two steps carry `per_item_steps`, per-item work resolves against the
first of them. The second set of templates is unreachable: its items render
the first anchor's prompts, or fail to resolve a template. This is not
reported at load. Split the second fan-out into its own workflow.
:::

On a `normal` step the templates never materialise. On a `loop` step with none,
the step is still required to emit its item set and then produces nothing from
it.

## Per-item keys

Templates materialised once per item as `story:<item_id>:<key_suffix>`.

A per-item step is an agent step: `role` and `prompt` are required and
`type: exec` is not accepted. A script fan-out belongs inside the tool — a
thread pool over the manifest it wrote — and only agent work becomes per-item
steps. A `stories_from` manifest on a step that declares no `per_item_steps`
fans out over nothing: its items are recorded, the run still reads done, and
`aicore lint-workflow` warns. A passed gate records each deliverable's size
and digest (`step.artifact_gate_passed`); when the run ends, every deliverable
is compared with its digest and a difference is recorded as
`run.artifact_changed_after_gate` — a process the step left behind, or a later
step, wrote to the artifact directory. `aicore forensics explain` also
re-checks each recorded digest against the file every time it is read, so a
deliverable altered after the run completed is reported too — a `done` run is
proof the deliverable is intact only for as long as nothing rewrites it. The
gate is a check at one instant; a step must not leave children behind.

| Key | Type | Required | Default | Meaning |
|---|---|---|---|---|
| `key_suffix` | string | Yes | - | Appended to the item key to form the step key |
| `role` | string | Yes | - | The role that runs this per-item step |
| `prompt` | string | Yes | - | Prompt file path, relative to the workflow directory |
| `title` | string | No | empty | Shown in progress output |
| `max_attempts` | integer | No | 2 | Attempts for each materialised step |
| `deps` | list | No | empty | Dependencies between per-item steps |
| `mcp_tools` | list | No | omitted | The MCP tools available to the step; same semantics as `steps[].mcp_tools` |

## Template variables

Available in every step prompt and in `command` strings.

| Variable | Contains |
|---|---|
| `{{goal}}` | The goal the run was started with |
| `{{progress}}` | What has completed so far in the run |
| `{{step_output.<key>}}` | The recorded output of the named step |
| `{{run_id}}` | The run identifier |
| `{{workflow}}` | The workflow name |
| `{{step_key}}` | The current step's key |
| `{{role}}` | The role running the current step |
| `{{attempt}}` | The current attempt number |
| `{{max_attempts}}` | The step's attempt budget |
| `{{story_id}}` | The item identifier, in per-item steps |
| `{{feedback}}` | The note an `on_fail` reset carried, else empty |
| `{{project_dir}}` | The project directory the run operates in |
| `{{output_dir}}` | The run's shared artifact directory — one directory for every step and every fan-out item, so a per-item file needs `{{story_id}}` in its name |
| `{{workflow_dir}}` | The workflow directory for this run |
| `{{metadata_dir}}` | The workflow's metadata directory |

Every key declared under `vars` is available under its own name. Use
`{{output_dir}}` and `{{metadata_dir}}` rather than writing paths directly;
they resolve correctly on every operating system and in every deployment.

## Related pages

- [Swarm definition reference](./03-swarm-yaml.md)
- [Skill format](./04-skill-format.md)
- [Command-line interface](./01-cli.md)
- [Building workflows](../03-building-solutions/06-workflows.md)

**Next:** [Swarm definition reference](./03-swarm-yaml.md).
