---
sidebar_position: 6
title: Data catalog
description: The catalog.yaml schema a workflow bundles under metadata/ — the databases, entities, dimensions, measures and descriptions that ground an agent's queries.
---

# Data catalog

A data catalog describes the structured data a solution's agents may query. A
workflow bundles it as `catalog.yaml` under the workflow's `metadata/`
directory, and every step that queries data reads the catalog first. The
catalog is the agent's only source of entity and column names; the agent does
not infer them. See
[Grounding agents in your data](../03-building-solutions/03-grounding-in-data.md)
for how agents use it.

## Structure

```yaml
databases:
  claims_dw:
    type: duckdb
    semantic: "Claims extract for the quarterly review"
    trust: high
    freshness: monthly

entities:
  - name: claims_q3
    database: claims_dw
    source_path: "data/claims_q3.csv"
    grain: "One row per territory-month"
    semantic: >
      Monthly prescription counts per sales territory, 2026-05..2026-07,
      20 rows across 7 territories.
    dimensions:
      - {name: territory, type: string,  description: "sales territory; 7 distinct"}
      - {name: month,     type: string,  description: "YYYY-MM; 2026-05, 2026-06, 2026-07"}
    measures:
      - {name: nbrx,      type: integer, description: "new prescriptions that month; 142..544"}
```

## Fields

### `databases`

A map of the stores the entities live in, keyed by the name `iof-query --db`
takes. Connection details are not written here: they live in `databases.yml`
beside the catalog. The catalog describes the data; the other file says how to
reach it.

| Field | Required | Meaning |
|---|---|---|
| `type` | Yes | The kind of store — `duckdb`, `postgres`, `redshift`, `mysql`, `sqlite`, `vectorfs` — so the agent writes the right dialect |
| `semantic` | Yes | What the database is for |
| `trust` · `freshness` | No | How far the agent may rely on it (`high`, `medium`, `low`) and how often it changes (`realtime`, `daily`, `weekly`, `monthly`, `on-ingest`). Stated for the agent; nothing enforces them |

A source is declared by the protocol it speaks, not by the product name in
front of it. An operational data platform served from PostgreSQL or Aurora
PostgreSQL is `type: postgres`; one served from Amazon Redshift is
`type: redshift`, which connects over TLS unless `databases.yml` names an
`sslmode` of its own and describes the schema it is configured with. A KPI is
not a source: a KPI definition is a `measures:` entry on the entity it is
computed from, with its canonical expression in `sql`, so every query that
reports it aggregates the same way.

### `entities`

A list, one entry per queryable dataset.

| Field | Required | Meaning |
|---|---|---|
| `name` | Yes | The name the agent queries. It is the identifier used in a query, so it must be stable |
| `database` | Yes | The `databases` entry the entity lives in. `iof-query --db <name>` serves only the entities that name that database |
| `source_path` | For a bundled file | A CSV under the metadata directory, for example `data/claims_q3.csv`. `iof-query` registers it as a view named after the entity when the database is opened, so a query reads `FROM claims_q3` |
| `table` | For a database table | The schema-qualified table the agent queries |
| `grain` | Yes | What one row represents |
| `semantic` | Yes | What the entity contains and when to query it, stated precisely enough that an agent chooses it without a discovery query |
| `dimensions` | Yes | The columns a query filters and groups by. May be empty |
| `measures` | Yes | The quantities a query aggregates. May be empty |

### `dimensions` and `measures`

Each entry is an object with a `name`, a `type` and a `description`; a measure
may also carry `sql`, the expression that computes it.

| Field | Required | Meaning |
|---|---|---|
| `name` | Yes | The column or measure name as it appears in a query. When a query names a column that does not exist, these names are what the tool suggests |
| `type` | Yes | The value type the agent should expect — for example `string`, `integer`, `number`, `date` |
| `description` | Yes | What it holds, including its range |
| `sql` | No | For a measure, the expression that computes it — for example `SUM(amount_usd)` |

## Descriptions carry the data's shape

A description is not a label. State cardinality, ranges, totals, distinct
values, and known gaps. These are what let an agent select the correct entity
and column without first running a discovery query, and they are what let it
report a gap honestly instead of interpolating over one.

```yaml
description: >
  20 rows across 7 territories, 2026-05..2026-07. Territory T-106 has no
  2026-06 row — the extract is incomplete there, so it cannot be trended
  and must be reported as a gap.
```

Do not add example queries, from-clauses or prohibited-operation lists. They
bias the shape of every answer the agent produces.

## An empty catalog is a valid state

A workflow that does not yet query data still ships a catalog that declares no
entities. A present, honestly empty catalog is a fact an agent can act on; a
missing catalog leaves the agent searching for data that was never catalogued.
State in the step prompt that an empty catalog is expected until the entities
are filled in.

## Related pages

- [Grounding agents in your data](../03-building-solutions/03-grounding-in-data.md) — how agents query the catalog
- [Workflow definition](./02-workflow-yaml.md) — how a workflow bundles its metadata

**Next:** [Environment variables](./07-environment-variables.md).
