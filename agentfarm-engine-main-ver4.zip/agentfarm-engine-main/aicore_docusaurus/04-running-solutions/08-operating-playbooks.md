---
sidebar_position: 8
title: Operating playbooks
description: Open cases from a trigger, relay typed events as they arrive, commission the action each rule names, and answer status, diagnosis and effectiveness questions from the case ledger.
---

# Operating playbooks

A [case playbook](../03-building-solutions/11-case-playbooks.md) in service
produces **cases**: one durable record per affected item, each holding its own
state, window and history. Operating a playbook means opening cases, relaying
events, commissioning the actions the rulebook names, and reporting from the
ledger.

## Where requests arrive

The **Meta Agent** is the platform's front door for playbook execution. A
requester states a situation in plain language; the agent matches it to the
approved playbook, opens the cases, relays events as they arrive, and reports
from the ledger. It is a platform-shared agent, present in every workspace;
no solution ships it.

```bash
aicore agent-chat --role meta_agent --workspace <code> --message "Denver, Phoenix and Los Angeles have no coverage assigned"
```

Run it from the solution's project directory: the case records resolve
through the workspace, as they do for every run. The same agent answers in
the Studio and over the agent-to-agent interface when it is named in the
always-on list (`IOF_ALWAYS_ON_AGENTS`) — see
[Exposing your agents](../03-building-solutions/08-exposing-your-agents.md).

Every command below is what the Meta Agent runs on a requester's behalf, and
what an operator runs directly. Each reads and writes the case record: no
procedure state lives in a conversation, and no answer is given from
recollection.

## Open cases

```bash
iof-plays match --trigger "<the requester's message>" --json
iof-case open --play PLAY-COVERAGE-GAP-001 --group BAR-00006 \
    --items "Denver,Phoenix,Los Angeles"
```

`match` resolves the playbook and returns its policy, including the action
workflow to commission. `open` creates one case per item, applies the opening
rule, and reports the action each case now requires.

A request that matches no playbook is recorded — the requester's words, who
asked and when. `iof-plays unmatched` lists them, most asked first; it is the
evidence for which playbook to write next.

## Runs a case has commissioned

Where a procedure's step runs a workflow, the case starts the run and waits
for it. The scheduler applies the result to the case when the run finishes;
nobody relays it.

```bash
iof-case runs                  # every run cases have commissioned, and its state
iof-case runs --settle         # apply the outcome of every finished run now
```

`commission` is the command the platform uses to start such a run; passing
`--run-id` attaches a run that was started another way.

```bash
iof-case deliveries            # which tool sends an email here, and where that was declared
iof-case dispatch --dry-run    # every notice a decision is owed, and what would deliver it
```

The scheduler delivers as well as decides. On every pass it starts the action
workflow for every decision whose notice has not gone out — once per decision,
after a short delay (`IOF_CASE_DISPATCH_AFTER_S`, default 30 seconds) so that
whoever opened the matter may start the first notice themselves. A decision
made by the clock outside office hours is therefore delivered without anyone
asking. A delivery run that fails is tried again on a later pass, up to
`IOF_CASE_DISPATCH_MAX_ATTEMPTS` (default 3) times; after that the decision is
reported as owed and left for a person. A decision older than
`IOF_CASE_DISPATCH_MAX_AGE_S` (default 3 days) is never delivered unattended:
`dispatch --dry-run` lists it as owed and says why it waits.

A run the platform marks as failed is applied to the case as a failure only
after it has been quiet for a grace period (`IOF_CASE_RUN_FAILURE_GRACE_S`,
default 900 seconds), because the platform retries failed runs. A run that
completes after its failure was applied still delivers its result; the
playbook's rules decide what a late result means.

Where an item enters the procedure differently — an owner is unknown, a record
arrives already escalated — declare the variant opening event:

```bash
iof-case open --play PLAY-COVERAGE-GAP-001 --group BAR-00006 \
    --items "Denver,Boise" --open-event-for "Boise=case_opened_no_owner"
```

A second `open` for an existing case is refused; cases are not re-created.

## Relay events

The monitoring system owns every clock. Deadlines expiring, pauses ending and
external confirmations all arrive as **typed events** that the platform records
and decides against.

```bash
iof-case transition --case CASE-BAR-00006-Denver --event sla_breach \
    --detail "<the source message, verbatim>" --key "<occurrence id>"
```

| Argument | Purpose | Consequence if omitted |
|---|---|---|
| `--event` | One typed event from the rulebook | An event outside the rulebook is refused with the accepted list |
| `--detail` | The source text or system message | The ledger records the transition without its evidence |
| `--key` | Identifies the occurrence — a clock id, notification id or deadline | A retried delivery of the same occurrence fires the next rule and escalates the case early |

**Always pass `--key` where the source provides an identifier.** A second
delivery carrying a key already seen is suppressed, recorded as such, and
changes nothing.

The transition output names the rule that fired and the action now required. A
state and event combination the rulebook does not cover is refused, recorded,
and left for a person: the case does not move.

### Free text becomes a typed event

A reply written by a person is not an event. Classify it against the rulebook's
criteria before relaying it:

```bash
iof-case rulebook show TPL-COVERAGE-GAP        # read event_rubrics
iof-case transition --case CASE-BAR-00006-Denver --event backfill_received \
    --detail "Manager wrote: 'interviewing a candidate this week'"
```

Record the classification and the quoted evidence in `--detail`. Where no
criterion clearly fits, do not transition: a wrong classification executes the
wrong rule correctly.

## Commission the action

Each transition names an action. The scheduler commissions it through the
playbook's action workflow on its next pass. To commission it by hand — before
the delay elapses, or for a decision the dispatcher left for a person —
delegate once per event, with the action named verbatim:

```bash
aicore run case_action --goal "case:CASE-BAR-00006-Denver action:remind_owner - <one line of context>" --json
```

The workflow reads the case, resolves the action's delivery contract, performs
it, and records the delivery against the case. A goal naming an action other
than the case's pending action is refused before any delivery occurs — the same
check refuses a duplicate delegation for an action already delivered.

The action workflow performs real deliveries through the field tools the
deployment configures. Where those tools are unreachable, the step fails and
the case keeps its pending action; it does not record a delivery that did not
happen.

The action `close` requires no workflow: the rulebook has already closed the
case.

## Report and diagnose

| Question | Command |
|---|---|
| Where does this case stand? | `iof-case show <case_id>` |
| What has happened to it? | `iof-case history <case_id>` |
| Why is it stuck, and is a retry safe? | `iof-case explain <case_id>` |
| What needs attention across all cases? | `iof-case audit` |
| Is the playbook working? | `iof-case kpi [--play <play_id>]` |

`explain` is the first command for any case question. It reports the state and
window, every decision with its delivery status, refused events awaiting
review, and explicit retry guidance.

| Decision status | Meaning |
|---|---|
| `DELIVERED` | The action reached its recipient; the receipt is recorded |
| `PENDING` | Decided, not yet delivered — this is the outstanding work |
| `SUPERSEDED` | A later event replaced this decision before it was delivered. Do not deliver it |

`audit` flags each case: `PENDING-UNDELIVERED`, `UNMATCHED` events awaiting
review, `SLA-EXPIRED`. A closed case carries no flags.

## Retry discipline

A failed action run does not mean the action did not happen. An email or a task
that reached an external system before the run failed has been delivered, and
re-commissioning it sends it twice.

1. Run `iof-case explain <case_id>` before any retry.
2. Where the pending action is side-effecting, confirm delivery in the
   receiving system's record. If it was delivered, record it and stop:

   ```bash
   iof-case record-action --case <case_id> --action <action> --receipt "<id>"
   ```

3. Only re-commission an action `explain` reports as free of side effects, or
   one confirmed undelivered.
4. `NO PENDING ACTION` means there is nothing to redispatch.

An action the rulebook does not declare is treated as side-effecting, so an
incomplete rulebook produces caution rather than duplicate deliveries.

## Read the effectiveness report

```bash
iof-case kpi --play PLAY-COVERAGE-GAP-001
```

| Reading | Interpretation |
|---|---|
| Rule heatmap: a late rung fires for most cases | Earlier windows are too short, or the ladder starts too late |
| Cases close mostly by pause expiry rather than resolution | The procedure parks situations instead of resolving them |
| Repeated `UNMATCHED` events of one type | The rulebook is missing a rule the business relies on |
| Time-to-close far below the window total | The windows are longer than the work requires |

Each of these is a reason to revise the playbook, and a revision is an approved
catalog change — see
[Playbooks](../03-building-solutions/10-playbooks.md#amend-a-playbook).
Simulate the revised ladder before approving it.

## Deadlines and who advances them

Every case records the window it is running. Deadlines are computed in
**business days** by default — a one-day window opened Friday afternoon is due
Monday afternoon — using the holiday set loaded for the region the rulebook's
`calendar` names; where no set is loaded for that region, weekends are the only
non-business days. A rulebook declaring `business_days: false` counts calendar
days.

The platform does not decide that a deadline has passed until an **emitter**
tells it. Three are available, and all reach the same place, so the choice is a
deployment decision rather than a change to any playbook.

| Emitter | Use when |
|---|---|
| The supplied scheduler | No authoritative scheduler exists elsewhere |
| An external system polling `GET /api/case-timers/due` | A scheduler already exists and should stay authoritative |
| An external system posting to `POST /api/case-timers/fire` | Timers already exist in the estate and mirroring them would create two truths |

### The supplied scheduler

```bash
iof-case due                                      # what is overdue, and what is blocked
iof-case scheduler --once                         # lease, apply, deliver and record one pass
iof-case scheduler --passes 1440 --interval 60    # one pass a minute, for a day
```

`--passes` is the number of passes to run (default 1) and `--interval` the
seconds between them. For continuous operation, run it under the deployment's
process supervisor, which restarts it. The scheduler holds nothing of its own. Every start rebuilds its working set
from the case records, so restarting it cannot lose a clock. Running more than
one instance is safe but buys nothing: each re-reads the same cases.

To apply a single trigger by hand — testing a ladder, or clearing one case
after resolving a delivery — use the command-line equivalent of the listener.
It reports the same outcome vocabulary:

```bash
iof-case fire --case CASE-BAR-00006-Denver --event sla_breach \
    --key "<occurrence id>" --clock-seq 2
```

### The listener

`POST /api/case-timers/fire` accepts `case_id`, `event`, `idem_key`, an
optional `clock_seq`, and `detail`. It is mounted **only** when
`IOF_TIMER_TOKEN` is set, and every request must present that value in the
`X-Timer-Token` header. A deployment without the variable exposes no timer
endpoint at all.

The response states what happened. **Exactly one outcome may be retried.**

| Outcome | Meaning | Required response |
|---|---|---|
| `fired` | A rule matched; the case advanced | Complete the job |
| `suppressed` | This occurrence was already applied | Complete the job |
| `fenced` | The trigger names a window the case has moved past | Complete the job |
| `unmatched` | The rulebook has no rule for this state and event | Complete, and review the case |
| `skipped` | The window's own notification was never delivered | Complete, and resolve the delivery |
| `error` | The platform did not decide | Retry with backoff |

Retrying any outcome other than `error` repeatedly triggers a case that is
behaving correctly.

### Two properties to rely on

**A trigger cannot escalate a case that has moved on.** Pass the `clock_seq`
the trigger was raised against; a trigger naming a superseded window is
refused. Without it, a job raised before a reply arrived escalates the person
who replied.

**A case whose notification never went out is not escalated.** Where the
current window's own notification is recorded as undelivered, the deadline is
surfaced rather than fired, and `iof-case due` marks the case as blocked.
Resolve the delivery, and the clock proceeds normally.

**Next:** [Improving solutions](../05-improving-solutions/01-overview.md) — what a solution learns from its runs.

## Related pages

- [Playbooks](../03-building-solutions/10-playbooks.md) — authoring, compilation and approval
- [Case playbooks](../03-building-solutions/11-case-playbooks.md) — the rulebook document, delivery contracts and simulation
- [Environment variables](../07-reference/07-environment-variables.md) — dispatch, grace and timer settings
