---
sidebar_position: 1
title: Running a solution
description: Start a workflow or a swarm from the command line or from AI Core Harness Studio, supply a goal, and locate the deliverables a run produces.
---

# Running a solution

A **run** is one execution of a workflow or a swarm against a goal. It is
recorded in the database, produces deliverables in a project directory, and
retains a complete evidence trail. Runs are started from the command line or
from AI Core Harness Studio; both produce the same record and execute on the same
engine.

## Before starting a run

Three conditions must hold:

| Requirement | Verified by |
|---|---|
| A model provider is configured | `aicore config-check` |
| The workspace is selected and holds the definition | `aicore list-workflows` · `aicore list-swarms` |
| The definition is valid | `aicore lint-workflow <name>` · `aicore lint-swarm --name <name>` |

A run started without a model provider is created and fails on its first model
call, so verify the configuration rather than diagnosing the failure.

## Starting a workflow run

```bash
aicore run <workflow> --goal "Produce a carrier scorecard for last quarter"
```

The command blocks and reports progress as each step is claimed, executed and
completed. The goal is passed to every step in the run.

Frequently used options:

| Option | Effect |
|---|---|
| `--dry-run` | Print the step graph and exit. No model calls are made and no run is created. |
| `--project-dir <path>` | The directory agents read from and write deliverables to. Defaults to the current directory. Two active runs pointed at one directory can overwrite each other's files: the second is warned when it starts and its record carries `run.shared_project_dir`. |
| `--var KEY=VALUE` | Override a variable declared in the definition's `vars:` block. Repeatable. |
| `--workspace <code>` | Run against a specific workspace instead of the selected one. |
| `--local` | Run in local mode for this run: state and database in the working directory, no server. Content always resolves from the installed solution. |
| `--json` | Create the run, execute it in the background, and return the run record immediately. |
| `--driver code` | The engine's own scheduler decides the order — no model in the control plane. Independent steps run in parallel; agents still run their own steps. The default, `agent`, lets the project lead decide. |

Validate before spending tokens:

```bash
aicore run <workflow> --goal "..." --dry-run
```

The dry run loads the definition, resolves every role and step, and reports the
dependency graph. Findings from the linter are reported alongside it.

### Choosing the driver

A run has a **driver**: what decides which step runs next. With
`--driver code` the engine's scheduler reads the dependency graph and starts
every step whose inputs are complete, in parallel — deterministic, with no
model call in the control plane; a step that runs an agent still does. With
the default driver the project-lead agent makes that decision and can add
tasks mid-run. The driver is recorded on the run: a detached run
(`--json`), `aicore resume` and the run supervisor all keep it, and
`aicore forensics explain` names it in its header. A pipeline of command
steps and gated agent steps belongs on `--driver code`; a pipeline that needs
judgement about what to do next belongs on the default.

## Starting a swarm run

```bash
aicore run-swarm <swarm> --goal "Assess Q3 exposure across the carrier base"
```

A swarm assigns a roster of tools, skills and external agents to one meta-agent,
which decides the order of work itself. The options above apply unchanged;
`--dry-run` prints the roster and the compiled shape rather than a step graph.

A swarm run is recorded, monitored and recovered exactly as a workflow run is.
For the difference between the two models and how to choose, see
[Workflows and swarms](../01-introduction/03-workflows-and-swarms.md).

## Starting a run in AI Core Harness Studio

Runs begin in the **Sessions** area. Select **+ Session**, choose the workflow,
state the goal, and select **Start Session**. The conversation view opens on the
new run and streams its progress.

The workflow detail page does not start runs. See
[Run it](../02-getting-started/studio/06-run-it.md) for the full procedure.

## What a run produces

| Output | Where |
|---|---|
| Deliverables | The project directory, listed by `aicore run-output --run-id <id> --list` |
| Step results | The run record, shown by `aicore status --run-id <id>` |
| Evidence trail | The forensic record, shown by `aicore forensics show <id>` |

Read a deliverable without leaving the terminal:

```bash
aicore run-output --run-id <id> --list
aicore run-output --run-id <id> --file carrier_scorecard.md
```

In AI Core Harness Studio, deliverables appear in the **Artifacts** panel of the
conversation view as the run produces them.

## The output contract

Every step returns a status and an output block. A step that reports completion
without producing a deliverable it was required to produce is failed and
retried; the requirement is declared on the step as `requires_artifacts`. This
is what prevents an incomplete step from being passed to the step that depends
on it.

A run therefore ends in one of two states: complete, or failed with a recorded
reason. See [Automatic recovery](./03-automatic-recovery.md).

**Next:** [Monitoring a run](./02-monitoring-a-run.md).
