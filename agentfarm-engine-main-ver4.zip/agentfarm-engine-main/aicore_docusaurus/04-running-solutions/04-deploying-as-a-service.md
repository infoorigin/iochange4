---
sidebar_position: 4
title: Deploying as a service
description: Run a solution as a long-lived HTTP service so a client application can create runs, stream output, send follow-ups, and resume — with always-available agents that answer directly.
---

# Deploying as a service

The command line runs a solution one invocation at a time. To make a solution
available to a client application — a web front end, a back-office system, a
scheduled job — run it as a long-lived HTTP service. The service exposes an API
for creating and monitoring runs, and hosts a pool of always-available agents
that answer requests directly.

## Starting the service

The service serves exactly one workspace, and it must be named before
startup: pass `--workspace <code>`, set the `IOF_WORKSPACE` environment
variable in the deployment, or select a workspace with `aicore workspace use`.
The flag wins over the variable and the stored selection. A service started
without a workspace refuses to start, and the startup message names the
variable to set. A request that names a different workspace than the one the
service serves is refused.

```bash
aicore serve --workspace <code> --host 0.0.0.0 --port 8111
```

The service uses a hybrid execution model. A workflow or swarm run is executed
as an independent operating-system process, so runs are fully isolated and a
crash in one never affects another. Follow-up messages and direct requests are
answered by an in-process pool of pre-warmed agents, which respond without the
startup cost of a new process.

| Option | Effect |
|---|---|
| `--workspace` | The workspace this service serves. Wins over `IOF_WORKSPACE` and the stored selection. |
| `--host` | Bind address. Default `0.0.0.0`. |
| `--port` | Listen port. Default `8111`. |
| `--root` | State root directory. Default `.iof`. |
| `--concurrency` | Maximum concurrent model requests per agent. Default `10`; `0` removes the limit. |

## The run API

A client application drives runs over HTTP. The core endpoints:

| Endpoint | Purpose |
|---|---|
| `POST /api/run` | Create a run. The JSON body carries `workflow`, `goal`, and optionally `driver` (`agent` or `code`, exactly as `aicore run --driver`; any other value is refused with 422), `project_dir`, `variables` (the `--var` overrides, as an object) and `workspace`. Returns the run identifier and the driver recorded. |
| `GET /api/run/{id}/status` | The run's current state, step counts and a `driver` object — whether the run's driver is alive and how old its last heartbeat is. A read; it changes nothing. |
| `GET /api/run/{id}/stream` | A server-sent-events stream of the run's output as it is produced. |
| `POST /api/run/{id}/message` | Send a follow-up to an agent in the run: body `{"content": "...", "role": "<agent role>"}` (or an `@Name` mention in the content). The agent answers with the run's context — goal, steps, outputs — so the message does not need to restate it. `user_id` identifies the person and `conversation_id` names the thread; one person holds any number of parallel threads on a run, each starting from the run's working memory. A command-only run has no agent to address and answers 409 — read it with `GET .../status` or `aicore forensics explain` instead; naming a `role` explicitly still routes to that agent. Each reply is a model turn. |
| `POST /api/run/{id}/message/stream` | The same follow-up delivered as Server-Sent Events: `status` events as the agent works, `delta` events carrying model text, then one `message` event with the complete reply. Body and semantics are identical to the non-streaming route. |
| `GET /api/run/{id}/messages` | The run's conversation history — user messages, replies and the agents' working trail. `?conversation_id=` narrows to one thread; `?step_key=` to one step's channel. This is how a client re-renders a conversation after a reload or on another instance. |
| `POST /api/run/{id}/resume` | Resume a run that was interrupted, on any instance of the service. Refused with 409 while the run's driver is still sending heartbeats — the same window the command line honours — unless the body says `{"force": true}`; a run that is done answers 409. |
| `POST /api/run/{id}/cancel` | Stop a run for good: the driver is stopped, running steps are failed with the reason in the body (`{"reason": "..."}`), and the supervisor leaves the run alone. |

An unknown run identifier answers 404 on every route.

```bash
curl -s -X POST http://localhost:8111/api/run \
  -H "X-IOF-Engine-Key: <key>" -H "Content-Type: application/json" \
  -d '{"workflow": "<name>", "goal": "<goal>", "driver": "code",
       "variables": {"window_days": "90"}}'
```

A run created through the API is recorded, monitored, recovered and inspected
exactly as a run started from the command line. The same forensic record and
the same deliverables are produced.

:::warning Require a credential on the service port
Without one, anything that can reach the port creates runs in any workspace the
service serves and consumes model capacity doing it. Set `IOF_ENGINE_AUTH` to
require an OAuth 2.0 bearer token from your identity provider, or a shared key
— see [Securing the service](./05-securing-the-service.md).

A service bound to a routable address refuses to start until this is answered.
Run it on an internal network as well; a credential is the control that holds
when a network rule is wrong, not a replacement for one.

Browsers are not clients of this API. AI Core Harness Studio sends every run
operation to its own API, which routes the request to the workspace's runtime
server-side, so no browser is given a runtime address. Keep it that way: a
runtime reachable from a browser is a runtime reachable from anything.
:::

## Always-available agents

Some agents answer requests directly rather than as part of a run — a
conversational assistant, a query agent that federates data sources. The
service pre-warms the agents named in the `IOF_ALWAYS_ON_AGENTS` environment
variable at startup, so the first request to each reaches a warm agent instead
of paying a cold-start cost.

A pre-warmed agent answers through the same session and workspace mechanics as
any other agent. It holds no run of its own; it responds to each request and
retains conversation continuity per caller.

Callers reach one at `POST /api/chat/<namespace>` with a body carrying
`content`, `agent`, `user_id` and `conversation_id`. `user_id` identifies
the person; `conversation_id` names the thread — reuse it to continue a
conversation, change it to start another, omit it to hold one thread per
person. A streaming sibling (`POST /api/chat/<namespace>/stream`) delivers
the same turn as Server-Sent Events, and
`GET /api/chat/<namespace>/messages` returns the recorded conversation. The
reply shape is the caller's choice per request — the agent's own voice, the
built-in response envelope, or a format the solution declares. See
[Chat responses and output formats](../03-building-solutions/15-chat-responses-and-formats.md).

The pool accepts an unlimited number of concurrent agent turns by default.
`IOF_POOL_MAX_CONCURRENCY` caps the turns one instance handles at once; a
request that waits longer than `IOF_POOL_QUEUE_TIMEOUT_S` seconds (default
`60`) for a slot is refused rather than queued indefinitely. This cap is
separate from `--concurrency`, which bounds model requests per agent.

## Scaling horizontally

The service is designed to run as multiple identical instances behind a load
balancer:

- **Shared state.** Point every instance at the same database
  (`IOF_DATABASE_URL`) and the same object storage (`IOF_STORAGE`). Run and step
  records, deliverables and session state are then visible to every instance.
- **Mostly stateless.** Creating a run, checking status, sending a follow-up and
  resuming a run can be served by any instance, because each reads and writes
  shared state.
- **Sticky only for streaming.** A live output stream
  (`GET /api/run/{id}/stream`) reads from the process executing that run, so a
  streaming connection is served by the instance that owns the run. Every other
  operation is not sticky.

An interrupted run is resumed from shared state on whichever instance receives
the resume request, so the loss of one instance does not lose a run.

## Serving multiple workspaces: one Studio, one runtime per workspace

Each service instance serves exactly one workspace. An organisation with
several workspaces therefore runs several runtime services — one deployment
per workspace, each started with its own `IOF_WORKSPACE` — while a single
AI Core Harness Studio connects to all of them. When a user switches workspace in the
Studio, their requests are routed to that workspace's runtime.

The routing is **configured in the Studio deployment's environment, never
stored as data**. A runtime address kept in a database travels with database
copies — a production address restored into a test environment would silently
route test traffic to production. Environment configuration stays with the
deployment it describes. Three variables, most specific wins:

| Variable | Form | Use |
|---|---|---|
| `IOF_ENGINE_URLS` | JSON map of workspace code to base URL, e.g. `{"logistics": "http://engine-logistics:8111"}` | Explicit per-workspace addresses. Overrides the template for the codes it names. |
| `IOF_ENGINE_URL_TEMPLATE` | A URL containing `{workspace}`, e.g. `http://engine-{workspace}.agents.svc:8111` | The convention: name each runtime deployment after its workspace code and every current and future workspace resolves with one line of configuration. |
| `IOF_RUN_API_URL` | A single base URL | The single-runtime deployment, and the fallback when neither of the above matches. |

**Set at least one of the three in any deployment.** With none of them set,
every workspace resolves to `http://localhost:8111` — the default that keeps a
local development stack working with no configuration. In a deployed Studio
that address reaches nothing, and every run, follow-up and console request
fails with a message naming these three variables.

Two configuration errors are refused at Studio startup rather than at request
time, so they are caught by the deployment and not by the first user: an
`IOF_ENGINE_URLS` value that is not a JSON object of string code to string
URL, and an `IOF_ENGINE_URL_TEMPLATE` that does not contain `{workspace}`.
Each variable's default and the consequence of leaving it unset are in the
[environment variable reference](../07-reference/07-environment-variables.md).

**Deployment identity check.** Where separate environments (development,
production) each carry a workspace of the same code, set `IOF_DEPLOYMENT` to
the same value on the Studio and on every runtime it should reach. Each
request then carries the deployment name, and a runtime refuses a request
from a different deployment — a misconfigured address fails loudly instead of
running work in the wrong environment. When the variable is unset on either
side, the check does not apply.

**Runtime lifecycle.** The Studio observes each workspace's runtime rather
than assuming it, and presents one of three states:

- **Being prepared** — the runtime has never been seen healthy. This is the
  normal state of a newly created workspace whose runtime deployment has not
  come online yet: building agents, skills and workflows proceeds
  immediately, and running them switches on automatically once the runtime
  is up.
- **Connected** — the runtime answered recently; nothing is shown.
- **Temporarily unreachable** — a runtime that has been healthy before is not
  answering now. This is the only state presented as an incident, with the
  time it was last seen.

The distinction is drawn from observed history, not from configuration: a
runtime that has never answered is being prepared, and one that answered
before is unreachable. A runtime address never appears in a member's view of
the Studio. Platform administrators have a read-only topology view in
**Administration** listing every workspace with the host serving it, how that
address was resolved, and its current state; the topology is environment
configuration and cannot be edited from the interface.

## Case playbooks in a deployment

A deployment that runs case playbooks adds two things to the service. The
case scheduler runs as its own process under the deployment's process
supervisor (`iof-case scheduler --passes <n> --interval <seconds>`), and
where an external system fires timers, `IOF_TIMER_TOKEN` is set so that the
service mounts the case-timer listener. Both are described in
[Operating playbooks](./08-operating-playbooks.md#deadlines-and-who-advances-them).

## Sending traces to your observability platform

The service exports every run as an OpenTelemetry trace when
`OTEL_EXPORTER_OTLP_ENDPOINT` is set, and the container image carries the
export already. Set the endpoint beside the other environment variables; leave
it unset and the layer costs nothing.

Where more than one instance serves the same workspace, set `IOF_STORAGE=s3`
as described above. The trace identifiers of a run travel with its artefacts,
so an instance that continues a run started elsewhere reads them and keeps one
trace; without shared storage its work appears as a second, unrelated trace.

See [Observability](./08-observability.md) for the platform-specific settings.

## Verify

```bash
aicore serve --workspace <code> --port 8111      # start the service
curl -H "X-IOF-Engine-Key: <key>" http://localhost:8111/api/run/<id>/status
# a shared key travels in that header; an identity-provider token in
# "Authorization: Bearer <token>" - see Securing the service
```

## Related pages

- [Running a solution](./01-running-a-solution.md) — the command-line equivalent
- [Monitoring a run](./02-monitoring-a-run.md) — the run record the API exposes
- [Automatic recovery](./03-automatic-recovery.md) — what resume relies on
- [Securing the service](./05-securing-the-service.md) — requiring an identity on every call
- [Sandboxed execution](./06-sandboxed-execution.md) — isolating run workloads in production

**Next:** [Securing the service](./05-securing-the-service.md).
