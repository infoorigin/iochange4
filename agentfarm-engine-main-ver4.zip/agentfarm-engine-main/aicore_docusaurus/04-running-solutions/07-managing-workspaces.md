---
sidebar_position: 7
title: Managing workspaces
description: Create and select workspaces, control who can open them, publish a solution repository into one, and remove a workspace and its history.
---

# Managing workspaces

A **workspace** is a tenant. It owns a catalog — agents, skills, workflows and
swarms — and the runs made against it. Every command and every run resolves to
exactly one workspace.

## Selecting the workspace

Resolution order, highest precedence first:

1. `--workspace <code>` on the command
2. the `IOF_WORKSPACE` environment variable
3. the workspace selected by `aicore workspace use`

When none of the three supplies a workspace, the command refuses and names
the fix. The platform never selects a workspace on your behalf.

The code `default` is reserved and cannot be selected or created. An
installation upgraded from a version that used it adopts its data into a
named workspace once — the rename carries every stored record and the
on-disk content tree, so the workspace is not created first:

```bash
aicore workspace rename default <code>
aicore workspace use <code>
```

```bash
aicore workspace use acme     # select for subsequent commands
aicore current                # report what is actually in force
```

`aicore current` reports the selected workspace, the environment file in effect,
the resolved database, and the file that supplied the database URL. Run it
whenever a command's behaviour is unexpected; it reports resolved values rather
than configured ones.

## Creating a workspace

```bash
aicore workspace create acme --member you@yourcompany.com
```

Creation grants access to the address supplied. **Access is closed**: without a
membership record there is no access, and a workspace nobody is a member of
cannot be opened by anyone. If `create` reports that nobody can open the
workspace, no member was granted — re-run it with `--member`.

`create` also updates an existing workspace, so re-running it to add a member
affects nothing else.

In AI Core Harness Studio, the same operation is in **Administration → Workspaces**.

## Inspecting a workspace

```bash
aicore workspace list          # every workspace and its repository binding
aicore workspace show acme     # its contents and who may open it
```

`show` reports the workflows, agents and skills the workspace holds, and its
membership.

## Binding a workspace to a solution repository

For the code-first track, a workspace is bound to the repository that supplies
its content:

```bash
aicore workspace attach acme --url .      # bind the repository
```

The repository is the promotion target. It is where an edit made in AI Core
Harness Studio is applied, and without it a draft cannot become running content.

Content is not published into a workspace. What an environment runs is the
solution package installed in it, so a change reaches a workspace through the
repository, the build and the deployment. See
[The round trip](../02-getting-started/shared/01-the-round-trip.md) for the full
procedure and for how content moves between the two tracks.

A workspace lists the agents and skills of every solution installed in the
environment its runtime runs in. There is no per-workspace scoping record.

:::note Content imported under an earlier model
`aicore workspace diff` and `aicore workspace pull` operate on content imported
into a workspace before the current model, and `pull` replaces the working-tree
copy rather than merging it — commit or stash your own changes to a diverged
item first. A deployment that has only ever run the current model holds no such
content, so `diff` reports each repository item as new and `pull` writes
nothing. `aicore workspace push` is deprecated and performs no work.
:::

## Working from your files

While developing, run against a database in the working directory rather than a
shared one:

```bash
aicore local on                              # this directory, and the workspace you create next
aicore local on --workspace acme             # that workspace only
aicore run <workflow> --goal "..." --local   # for a single run
```

The two forms scope differently, and the difference matters where a directory
is used with more than one workspace. With no flag the switch is recorded
against the DIRECTORY, which is what makes the workspace you create next a
local one; a workspace whose own settings are silent then inherits it. With
`--workspace` the switch is recorded against that workspace alone, and no
other workspace used from the same directory is affected.

Content resolves from the installed solution in either mode. Where the solution
is installed in editable mode, a run reads your working tree, so an edit takes
effect on the next run. The mode in force is reported at the start of every run.

## Deleting a workspace

```bash
aicore workspace delete acme --yes
```

This removes every record keyed to the workspace: its agents, skills, workflows,
membership and settings, together with the workspace's own directory.

Deletion is refused where the workspace holds run history. Confirm explicitly to
remove that as well:

```bash
aicore workspace delete acme --yes --force
```

Stored run artifacts are retained in both cases.

:::warning Content built in AI Core Harness Studio exists only in the database
Deleting a workspace removes it. Content published from a repository can be
re-published; content created in AI Core Harness Studio and never exported cannot be
recovered. Export it first — see
[The round trip](../02-getting-started/shared/01-the-round-trip.md).
:::

## Settings per workspace

Each workspace holds its own settings, including its database URL, in its own
environment file, `~/.iobot/workspaces/<code>/.env` — outside the state
directory, so a copied `.iof` carries no credentials with it. Settings in one
workspace's file do not apply to another, and
no other location on the machine is read. `aicore current` names the file in
effect.

**Next:** [Operating playbooks](./08-operating-playbooks.md) — opening cases, relaying events and the scheduler.
