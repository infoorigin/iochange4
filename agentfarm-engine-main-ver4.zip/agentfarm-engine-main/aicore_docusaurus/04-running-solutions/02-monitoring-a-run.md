---
sidebar_position: 2
title: Monitoring a run
description: Follow a run in progress, inspect step results, read the evidence trail, and account for token usage.
---

# Monitoring a run

A run in progress can be followed live, and a completed run can be reconstructed
in full from its record. Nothing needs to be captured in advance: the evidence
trail is written as the run executes.

## Run and step status

```bash
aicore status                        # recent runs
aicore status --run-id <id>          # the step table for one run
aicore status --run-id <id> --step analyze   # one step's output
```

The step table reports each step's key, role, status and attempt count. A step
is `pending`, `running`, `done` or `failed`; a run is `running`, `done` or
`failed`.

`aicore status --json` returns the same information in machine-readable form,
including stall detection.

To see which step the engine will claim next without claiming it:

```bash
aicore next-step --run-id <id>
```

## Following a run live

```bash
aicore forensics tail <id>
```

This follows the event timeline for a run in flight — step claims, attempts,
retries, artifact-gate outcomes and completions — as they are recorded.

```bash
aicore watch <id>
```

This narrates a detached run — one started with `--json` or from AI Core
Harness Studio — as work rather than as events, streaming the agent's own
output alongside step transitions. When a step goes quiet for longer than the
platform's own staleness threshold, it reports whether the step is recovering
or stuck. It only reports; it never retries or intervenes.

In AI Core Harness Studio, the conversation view streams the same progress: the
orchestrator narrates each handoff, the assigned agent's reasoning appears as it
works, and each step closes with its status and output. Step cards in the left
column advance from `PENDING` to `DONE`.

## The evidence trail

Every attempt of every step records what it was told, what it did and how it
ended.

```bash
aicore forensics show <id>                       # the full timeline
aicore forensics stats <id>                      # per-attempt metrics
aicore forensics narrative <id> <step.attempt>   # the attempt as a readable transcript
aicore forensics blob <id> <step.attempt> <name> # one recorded artifact
```

The recorded artifacts for an attempt include the prompt the agent received, its
output, the transcript of its reasoning and tool calls, the request log for its
model calls, and its exit record. `aicore forensics stats` summarises them —
duration, tool-call count, and the classified outcome of each attempt.

`aicore forensics list` reports recent runs that have a forensic record.

## Postmortem

For any question of the form "what happened to this run", start here:

```bash
aicore forensics explain <id>
```

The command composes the run record, the event timeline, the per-attempt
artifacts, usage totals and — for a swarm — the results of each delegated call
into a single ranked verdict, with the specific evidence to examine next. It
applies to workflow and swarm runs alike.

Add `--json` for the machine-readable form.

## Token usage

```bash
aicore forensics tokens <id>
```

This reports exact token consumption for the run, captured from the model calls
themselves rather than estimated. Use it to compare the cost of two definitions
against the same goal, or to identify the step that dominates a run's cost.

## Asking the assistant instead

Every command above answers one fixed question. The AI Assistant answers the
specific question you have — why a step failed, which step consumed the run's
budget, whether the output is sound — by reading the same record. See
[Diagnosing runs](../06-core-assistant/02-diagnosing-runs.md) and
[Cost and usage](../06-core-assistant/03-cost-and-usage.md).

**Next:** [Automatic recovery](./03-automatic-recovery.md).

## Exit codes

Every `aicore` command exits with one of these, so a script can branch
without parsing prose:

| Code | Meaning |
|---|---|
| `0` | Done — the run converged, or the command did what was asked. `aicore resume` on a run that is already done also exits 0 and says so. |
| `1` | Failed — the run or step ended in failure, or the command could not do what was asked (a failed run cannot be resumed without `--force`; a pending step cannot be retried). |
| `2` | Bad invocation — an unknown option, an undeclared `--var`, a `--var` that is not `KEY=VALUE`, a driver or workspace that does not exist, a service that refuses to start. |
| `3` | Not found — the run (or step) names nothing in this database. `status`, `watch`, `resume`, `cancel`, `step-retry`, `step-skip`, `run-output` and every `forensics` command answer this way; under `--json` the body is `{"error": "run not found", ...}`. A failed run is `1` on every command, `watch` included. |
| `4` | Refused because another run is in the way — `single_active_run` or `depends_on_runs`. The message names the run and, when its driver is gone, the `resume` command. |
| `124` | The `timeout` you wrapped a `watch` or a service in expired. Not the product's code. |
