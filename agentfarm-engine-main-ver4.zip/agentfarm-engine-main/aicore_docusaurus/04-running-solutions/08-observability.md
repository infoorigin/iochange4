---
sidebar_position: 8
title: Observability
description: Export every run as a standard OpenTelemetry trace — steps, model calls, tool calls and metrics — to the observability platform already operated here.
---

# Observability

The evidence trail described in [Monitoring a run](./02-monitoring-a-run.md)
is the deep record: every prompt, session and gate decision, kept per attempt
and read by `aicore forensics explain`. This page is the bridge to the
observability platform a team already runs — Langfuse, Arize or Phoenix, AWS
Bedrock AgentCore, Grafana Tempo, Datadog, Honeycomb, or any other that
accepts the OpenTelemetry protocol. The export uses the standard protocol,
the standard conventions for model calls, and the standard environment
variables; there is nothing of ours to install on the receiving side.

## What a run looks like in a trace viewer

One run is one trace. Its root is the run; each step attempt is a child; a
model call or a tool call inside an agent step is a child of that step.

```
aicore.run forecast_variance                       status, goal, step counts
├─ aicore.step plan                     [TOOL]     the command it ran
├─ aicore.step compute                  [TOOL]     events: step.exec_completed
├─ aicore.step story:fv_nbrx:reason     [AGENT]    attempt 1
│  ├─ gen_ai.chat <model>               [LLM]      tokens in and out, finish reason
│  ├─ aicore.agent_tool read_file       [TOOL]
│  └─ gen_ai.chat <model>               [LLM]
├─ aicore.step verify                   [TOOL]     attempt 1 — error, step.reset_on_fail
├─ aicore.step draft                    [TOOL]     attempt 2 — the loop, visible
└─ aicore.step verify                   [TOOL]     attempt 2
```

A retry is a sibling attempt of the same step. An `on_fail` loop is the same
step recurring. A `route` decision is an event on the route step naming what
it chose and what it closed. Every gate that trips — a missing artifact, the
attempt cap, an undeclared route — is an error-marked event on the step where
it happened.

An always-on agent's conversation turn (the chat endpoint, a run's follow-up
message, the Agent2Agent surface, Microsoft Teams) is its own trace, one per
turn, with the model calls beneath it; the service's own start-up warm-up
turns are not traced. A turn that arrives with a W3C `traceparent` header —
from an agent consulting this one, or from any instrumented client — is
recorded as a child of that trace. A case action started by the playbook dispatcher is linked to the
run it started, so "which runs did this case cause" is one query.

### Metrics

| Metric | Kind | Dimensions |
|---|---|---|
| `aicore.run.duration` | histogram, seconds | workflow, run status |
| `aicore.step.duration` | histogram, seconds | step key, status |
| `aicore.step.attempts` | counter | step key, workflow |
| `aicore.step.failures` | counter | step key, reason |
| `aicore.route.decisions` | counter | step key |
| `gen_ai.client.token.usage` | histogram | token type (input / output), model |

Dimensions are kept to low-cardinality keys — a step key, a model, a channel —
never a run identifier, so dashboards and alerts stay cheap.

### What is exported, and what is not

**`IOF_OTEL_CONTENT` is the switch.** It governs whether traces carry the
text your agents handle, or only its measurements. It is the one setting on
this page with a data-handling consequence, so it is worth deciding
deliberately rather than inheriting.

| | Unset — the default | `IOF_OTEL_CONTENT=1` |
|---|---|---|
| A run's goal | length only | the goal text |
| A chat turn's message and reply | `aicore.input.chars`, `aicore.output.chars` | the message and the reply |
| A tool's arguments and results | character counts | the arguments and what the tool returned |
| A step's output | length only | the output text |
| File and command targets a step touched | how many | the paths themselves |
| Identifiers — run id, step key, workspace code, user id, agent role | always exported | always exported |
| Timings, token counts, status, attempt numbers | always exported | always exported |

The default is off, and an unrecognised value is treated as off. Nothing is
exported that a trace viewer would show as readable text unless the switch is
set.

**Identifiers are always exported**, because a trace without them cannot be
searched. A user id and a workspace code are identifiers rather than text, but
they still say who used the system and when. Where that matters, treat access
to your trace backend as you treat access to the underlying data.

**Confirm which state a deployment is in:**

```bash
aicore otel check
```

Alongside the delivery result, it reports the switch — either that content
export is off and only lengths and digests are sent, or a warning that message
bodies are being exported to the configured endpoint. Use it rather than
inspecting a span.

Set the switch in the workspace's own environment file
(`~/.iobot/workspaces/<code>/.env`) or in the service's environment. A
workspace's file applies to that workspace alone.

### What is never exported

- **Credentials.** Header values are never printed and never logged; only
  header names appear in `aicore otel check` and `aicore otel env`, and values
  are shown as a length and a digest.
- **The engine's own chatter** — the scheduler's polling, "output written",
  "spawning" — stays in the evidence trail. It would be hundreds of empty
  spans per run and would bury the ones that matter.
- **Developer tools** (`aicore build`, local agent chat) and the Studio API
  service are not instrumented. The Studio API is a standard FastAPI
  application; instrument it with the standard FastAPI instrumentation if
  you want its requests.

Attribute values are capped in length and payloads are flattened to scalars.
A code-driven run is a `CHAIN` span; its command steps are `TOOL` spans.

## Turning it on

Nothing to install — the exporter ships with the engine. Set the standard
environment; the endpoint is the switch, so set it and export is on, leave it
unset and the layer costs nothing.

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=https://...      # the switch
export OTEL_EXPORTER_OTLP_HEADERS="..."             # authentication, per platform
export OTEL_SERVICE_NAME=aicore-commercial          # default: aicore
export OTEL_RESOURCE_ATTRIBUTES=deployment.environment=prod,team=commercial
export OTEL_METRICS_EXPORTER=none                   # for a traces-only platform
```

`OTEL_METRICS_EXPORTER=none` turns off the metrics half while leaving traces
untouched. Set it wherever the platform stores traces only, such as Phoenix;
otherwise every process attempts a metrics export every few seconds against
an endpoint that will refuse it. To keep the metrics and send them somewhere
that accepts them, set `OTEL_EXPORTER_OTLP_METRICS_ENDPOINT` to that
collector instead.

In a container these belong beside the other environment variables; an
OpenTelemetry collector sidecar is usually reached at
`http://localhost:4318`. For development, `IOF_OTEL_EXPORTER=console` writes
every span to the run's `otel/spans.jsonl` (below) instead of sending it
anywhere; the two exporters are exclusive.

A code-driven run's steps are subprocesses whose output goes to the run's
forensic record rather than to your terminal, so inside a run the console
exporter also appends every span to `.iof/instances/<run_id>/otel/spans.jsonl`
(one JSON object per line: name, trace and span ids, attributes, events) —
from every process that took part: the launcher, the driver, each step. What
a step's process printed to the terminal is in that step's `stderr.log` in the
forensic record. `aicore forensics explain <run_id>` names the file when it
exists.

### Langfuse

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=https://cloud.langfuse.com/api/public/otel
export OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic <base64 of public-key:secret-key>"
```

Model, tokens and finish reason land on each model-call observation; steps
render as nested observations; the run is the trace.

### Arize and Phoenix

```bash
# Arize
export OTEL_EXPORTER_OTLP_ENDPOINT=https://otlp.arize.com/v1
export OTEL_EXPORTER_OTLP_HEADERS="api_key=<key>,arize-space-id=<space>"

# Phoenix, self-hosted and unauthenticated
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006

# Phoenix behind authentication
export OTEL_EXPORTER_OTLP_ENDPOINT=https://<phoenix-host>
export OTEL_EXPORTER_OTLP_HEADERS="Authorization=Bearer%20<key>"
export OTEL_RESOURCE_ATTRIBUTES=openinference.project.name=<project>
export OTEL_METRICS_EXPORTER=none
```

Both the GenAI conventions and the OpenInference attributes are emitted, so
the same run reads correctly in either family of platform.

Four requirements apply to an authenticated Phoenix deployment:

- **The endpoint is the host, with no signal path.** The exporter appends
  `/v1/traces` itself, so an endpoint that already ends in `/v1/traces` posts
  to a path that does not exist and the platform answers 405. Setting only
  `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` leaves export off altogether, because
  `OTEL_EXPORTER_OTLP_ENDPOINT` is the switch that turns it on.
- **Header values are URL-encoded.** `Authorization=Bearer <key>` with a
  literal space is discarded by the OpenTelemetry header parser, which logs
  one warning at startup and drops the header; every span is then rejected
  with 401. Write `Bearer%20<key>`.
- **Phoenix and Arize authenticate differently.** The `api_key` header Arize
  accepts is refused by Phoenix, which requires `Authorization: Bearer`.
- **The project is a resource attribute.** `openinference.project.name`
  selects the Phoenix project. The `PHOENIX_PROJECT` and `PHOENIX_API_KEY`
  variables belong to the Phoenix client libraries and are not read by this
  export; a deployment that sets only those sends no credential and selects
  no project.

Phoenix stores traces, not metrics. Set `OTEL_METRICS_EXPORTER=none` for a
Phoenix deployment, or send metrics elsewhere with
`OTEL_EXPORTER_OTLP_METRICS_ENDPOINT`. Without one of the two, every process
attempts a metrics export every few seconds against an endpoint that does not
exist and logs the failure each time. Traces are unaffected. Phoenix computes
run volume, error rate and latency percentiles from the spans themselves, so
only the engine-specific counters — step failures by reason, route decisions,
case dispatches — have nowhere to land.

### AWS Bedrock AgentCore

Run the AWS Distro for OpenTelemetry collector and point at it:

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318
export OTEL_RESOURCE_ATTRIBUTES=service.name=aicore,aws.log.group.names=/aws/bedrock-agentcore/aicore
```

## Adding your own signals from a tool

A command-line tool run by a `type: exec` step is already inside the run's
trace: the step passes its trace context to the command, and the SDK opens a
span for the life of the process. The SDK's `obs` module adds to it:

```python
from aicore.sdk import obs

obs.attr("cards.planned", len(cards))              # an attribute on this tool's span
obs.event("registry.validated", unknown=0)         # a timestamped event
obs.metric("fv.rows_fetched", n, unit="{row}")     # a histogram point
obs.metric("fv.warehouse_errors", 1, kind="counter")
with obs.span("warehouse.query", pair=label):      # a child span
    rows = run_query(...)
```

Every call is a no-op when export is off or the extra is not installed, and
none of them raise: a tool written with them runs unchanged on a machine with
no observability. Underneath it is plain OpenTelemetry — the current span is
the standard current span, if you prefer the raw API.

Name your metrics with your solution's own prefix (`fv.rows_fetched`, not
`aicore.` or `gen_ai.`), and keep their dimensions to a handful of values.

**Metrics need a platform that accepts them.** `obs.metric` records through
the same metrics exporter as the engine's own counters, so a deployment that
sets `OTEL_METRICS_EXPORTER=none` — the setting this page recommends for a
traces-only platform such as Phoenix — records your metric points nowhere,
silently. Where a solution's own metrics matter, send them to a collector that
accepts them with `OTEL_EXPORTER_OTLP_METRICS_ENDPOINT` rather than turning
metrics off. Attributes, events and spans are unaffected: they travel with the
trace.

**Attributes and events are exported as written.** `IOF_OTEL_CONTENT` governs
the message bodies the engine itself records — a step's goal, an agent turn's
input and output. It does not apply to what a tool passes to `obs.attr`,
`obs.event` or `obs.span`, which is exported whenever export is on. Record
identifiers, counts and outcomes; do not pass customer text, personal data or
credentials, and treat a value read from your source data as content until you
know otherwise.

**Seeing your own signals while developing.** `IOF_OTEL_EXPORTER=console`
writes every span, with its attributes and events, to the run's
`otel/spans.jsonl` without sending anything to a platform — the quickest way
to confirm a tool's signals are shaped the way you intended.

`obs.span` declares an OpenInference span kind so the platform can classify
it. The default is `CHAIN`, a unit of work; pass `kind="RETRIEVER"`,
`kind="TOOL"` or `kind="LLM"` where one of those is accurate:

```python
with obs.span("warehouse.fetch", kind="RETRIEVER", pair=label):
    rows = run_query(...)
```

## Where a custom tool's signals attach

Everything a tool records becomes a child of the span for the work that
invoked it, so a reader opens the run, opens the step, and finds the tool's
own detail underneath. Which span that is depends on how the tool is
invoked, and in every case the context travels without the tool arranging
it:

| How the tool runs | Its span attaches to | What carries the context |
|---|---|---|
| A `type: exec` step | that step | the trace context in the command's environment |
| A command the agent runs itself, such as `iof-query` | the step the agent is working on | the same context, forwarded through the runtime's environment allowlist |
| An MCP tool, local or remote | the model's tool call | the trace context travels in the tool-call request |

The second row places the tool's span beside the agent's own tool-call span
rather than beneath it, because the context the agent's environment carries
is the step's. Both sit under the same step, and both carry the run
identifier.

### Work done on worker threads

OpenTelemetry's current span is per thread. A span opened on a thread from a
pool therefore has no current span to attach to, and would become a new root
outside the run's trace. `obs.span` attaches such a span to the tool's own
span instead, so a fan-out inside a tool stays in the trace:

```python
with ThreadPoolExecutor(max_workers=8) as pool:
    for pair in pairs:
        pool.submit(fetch, pair)      # each fetch may open obs.span freely
```

### Reaching another service from a tool

A tool that calls a service directly — an internal API, another agent over
the Agent2Agent protocol — extends the trace by sending its context on the
request. `obs.traceparent()` returns the W3C `traceparent` of the work in
progress:

```python
headers = {}
tp = obs.traceparent()
if tp:
    headers["traceparent"] = tp
response = httpx.post(url, json=payload, headers=headers)
```

A service that reads that header records its work inside the same trace,
under the tool that called it. The `iof-consult` command already does this,
so an agent consulting another agent is one trace rather than two.

### A tool that runs on another machine

An MCP server is a service and is often remote. The trace context of the
model's tool call travels in the tool-call request itself, as `traceparent`
in the request's `_meta`, so a server that reads it records its work as a
child of that tool call. Nothing is required of the solution: the context is
sent whenever export is on.

A server joins the trace by reading `_meta.traceparent` from the incoming
request and starting its spans from it. Connection and capability-listing
requests carry no context, because they belong to no tool call.

## Runs that span a restart or several pods

One run is one trace across every process it uses, including a run that is
resumed after an interruption or continued on another instance of the
service. The run's trace identifiers are held with the run's own artefacts,
and every process of the run reads them from there.

A deployment that runs more than one instance of the service must therefore
share those artefacts, by setting `IOF_STORAGE=s3` as described in
[Deploying as a service](./04-deploying-as-a-service.md). Without shared
storage, an instance that picks up a run started elsewhere cannot read the
run's trace identifiers, and the work it does appears as a second, unrelated
trace.

Conversations are traced one turn at a time. Each turn with an always-on
agent is its own trace, and the turns of a conversation are related by the
session recorded on each of them rather than by a single enclosing trace.
This is unaffected by a restart: a conversation resumed after the service
restarts continues to record the same session.

## Related pages

- [Monitoring a run](./02-monitoring-a-run.md) — the evidence trail and the postmortem
- [Deploying as a service](./04-deploying-as-a-service.md) — where the environment variables go
- [Command-line tools](../03-building-solutions/02-command-line-tools.md) — the tools that carry your signals
