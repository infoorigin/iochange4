---
sidebar_position: 5
title: Securing the service
description: Require an identity for every call to the runtime service — an OAuth 2.0 bearer token from your identity provider, or a shared key — so the port is a controlled boundary rather than an open one.
---

# Securing the service

A runtime service started with `aicore serve` creates runs, reads agent memory
and consumes model capacity. Require a credential on it. The service verifies
OAuth 2.0 / OpenID Connect bearer tokens against your identity provider —
Microsoft Entra ID and Okta are both supported from the same configuration — or
a shared key where no provider is reachable.

The service refuses every request that presents no acceptable credential. The
Kubernetes health probes and browser preflight requests are the only
exemptions.

## Choose a mechanism

`IOF_ENGINE_AUTH` selects it. Set `oidc`, `apikey`, both separated by a comma,
or `off`.

| Value | Use when |
|---|---|
| `oidc` | An identity provider is reachable. Tokens are short-lived, centrally revocable, and identify the caller. |
| `apikey` | No provider is reachable — an air-gapped installation, or before an application registration exists. |
| `oidc,apikey` | Migrating. Both are accepted, so a job that still holds a key keeps working while callers move to tokens. |
| `off` | The port is controlled entirely at another layer, such as a service mesh enforcing mutual TLS. |

:::warning A service bound to a routable address will not start without one
`aicore serve` refuses a non-loopback bind when no mechanism is configured. Set
a mechanism, set `IOF_ENGINE_AUTH=off` to state the decision explicitly, or
bind `--host 127.0.0.1`. The refusal names every option.

A service that was previously bound to `0.0.0.0` without a credential will not
start after an upgrade until this is answered.
:::

## Microsoft Entra ID

Register two applications in the directory:

1. **The runtime service.** Expose an Application ID URI, such as
   `api://ai-core-runtime`. Declare an application role — `Engine.Invoke` in
   the example below — with allowed member type **Applications**.
2. **Each caller**, such as the Studio API. Grant it that application role and
   have an administrator consent to it.

Configure the runtime service:

```bash
IOF_ENGINE_AUTH=oidc
IOF_ENGINE_OIDC_TENANT_ID=<directory (tenant) id>
IOF_ENGINE_OIDC_AUDIENCE=api://ai-core-runtime
IOF_ENGINE_OIDC_REQUIRED_ROLES=Engine.Invoke
```

`IOF_ENGINE_OIDC_TENANT_ID` is sufficient on its own to identify the provider.
Entra ID issues tokens under two issuer identifiers for the same application,
and an access token for an `api://` resource frequently carries the older of
the two. Both are accepted when the tenant is named this way. Naming a single
issuer with `IOF_ENGINE_OIDC_ISSUER` instead will reject valid tokens that
carry the other.

## Okta, or any OpenID Connect provider

```bash
IOF_ENGINE_AUTH=oidc
IOF_ENGINE_OIDC_ISSUER=https://<org>.okta.com/oauth2/<authorization-server-id>
IOF_ENGINE_OIDC_AUDIENCE=api://ai-core-runtime
IOF_ENGINE_OIDC_REQUIRED_SCOPES=engine.invoke
```

The provider's signing keys are read from its OpenID Connect discovery
document and cached. A key rotation is picked up without a restart. Where the
deployment cannot reach discovery, name the key endpoint directly with
`IOF_ENGINE_OIDC_JWKS_URI`.

## Shared key

```bash
IOF_ENGINE_AUTH=apikey
IOF_ENGINE_API_KEYS=<key>
```

Generate a key with `python -c "import secrets; print(secrets.token_urlsafe(32))"`.
Keys shorter than 32 characters are refused at startup.

Several keys may be configured at once, separated by commas or newlines, so a
rotation overlaps instead of cutting over. A key file mounted as a Kubernetes
secret is read correctly without reformatting.

A caller presents the key in the `X-IOF-Engine-Key` header — not as a bearer
token, which is the identity-provider scheme:

```bash
curl -s http://<host>:8111/api/whoami -H "X-IOF-Engine-Key: <key>"
```

A request without an acceptable credential is answered `401` with
`{"detail": "Authentication required.", "hint": "present the shared key in the
X-IOF-Engine-Key header"}` — the hint names how to present one, never whether
a credential was sent or was wrong.

## Configure the callers

Every caller of the runtime service reads the same variables — the Studio API,
the `aicore` command line, and any client application of your own.

For an identity provider:

```bash
IOF_ENGINE_CRED_MODE=oauth
IOF_ENGINE_CRED_TENANT_ID=<directory (tenant) id>     # Entra ID
IOF_ENGINE_CRED_CLIENT_ID=<the caller's application id>
IOF_ENGINE_CRED_CLIENT_SECRET=<the caller's secret>
IOF_ENGINE_CRED_AUDIENCE=api://ai-core-runtime
```

Use `IOF_ENGINE_CRED_TOKEN_URL` in place of `IOF_ENGINE_CRED_TENANT_ID` for a
provider other than Entra ID.

For a shared key:

```bash
IOF_ENGINE_CRED_MODE=apikey
IOF_ENGINE_CRED_API_KEY=<one of the service's keys>
```

The caller acquires its token and renews it before expiry. A token configured
as a fixed string would stop working at its expiry with nothing to renew it.

## Attribution

The Studio API calls the runtime service as itself. It also declares the end
user it acts for, and the runtime service records that user as the owner of the
run. The run record therefore names the person who started the run rather than
the calling service.

The declared user is accepted only from a caller that has authenticated. Set
`IOF_ENGINE_DELEGATION_ROLE` to an application role to narrow it further; only
callers holding that role may then declare a user, and a declaration from any
other caller is discarded while the call proceeds.

## Confirm the configuration

The startup banner states the posture on every start:

```
Starting the engine web server
  http://0.0.0.0:8111
  auth: oidc
         issuer https://login.microsoftonline.com/<tenant>/v2.0
         audience api://ai-core-runtime
```

`GET /api/whoami` reports what the service made of a caller. It requires a
credential like every other route, so it is also the shortest confirmation
that the service is guarded.

```bash
curl -s http://<host>:8111/api/whoami
# {"detail":"Authentication required."}

curl -s http://<host>:8111/api/whoami -H "Authorization: Bearer <token>"
curl -s http://<host>:8111/api/whoami -H "X-IOF-Engine-Key: <key>"      # shared key
```

```json
{
  "authenticated": true,
  "policy": { "enabled": true, "mechanisms": ["oidc"] },
  "principal": {
    "kind": "service",
    "client_id": "<the caller's application id>",
    "roles": ["Engine.Invoke"],
    "method": "oidc",
    "actor": "jane@example.com",
    "label": "<the caller's application id> (for jane@example.com)"
  }
}
```

A caller that presents no credential receives `401` with a `WWW-Authenticate`
header. A caller whose token is valid but lacks the required role or scope
receives `403`. The response body states which of the two applies and nothing
further; the service log records the specific reason.

## What is not covered

- **Authorization within the service.** An authenticated caller reaches every
  route. Restrict which workspaces a person may reach in AI Core Harness
  Studio, which enforces membership.
- **Interactive sign-in against the runtime service.** The service accepts
  tokens; it does not conduct a browser sign-in flow. Callers acquire tokens
  from the identity provider.
- **Network reachability.** Keep the port on an internal network. Requiring a
  credential is the control that holds when a network rule is wrong, not a
  replacement for one.

Browsers are not clients of this API. AI Core Harness Studio sends every run
operation to its own API, which reaches the workspace's runtime server-side, so
no browser is given a runtime address or a runtime credential.

## Related pages

- [Deploying as a service](./04-deploying-as-a-service.md) — starting the
  service and the API it exposes
- [Sandboxed execution](./06-sandboxed-execution.md) — isolating run workloads
- [Managing workspaces](./07-managing-workspaces.md) — which tenant a service
  serves

**Next:** [Sandboxed execution](./06-sandboxed-execution.md).
