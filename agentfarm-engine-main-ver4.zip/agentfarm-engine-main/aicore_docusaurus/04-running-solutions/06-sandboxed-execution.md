---
sidebar_position: 6
title: Sandboxed execution
description: Run agent workloads inside isolated sandboxes governed by an explicit policy that constrains the filesystem, the network, and the commands an agent may run.
---

# Sandboxed execution

An agent executes commands and reads and writes files to do its work. In
production, that capability must be bounded: an agent should reach only the data
its task requires and no network endpoint it has no reason to reach. Sandboxed
execution runs each workload inside an isolated environment governed by an
explicit **policy**.

Sandboxing is opt-in. Set the runner to `sandbox` to enable it:

```bash
export IOF_RUNNER=sandbox
```

With the default runner, workloads execute directly and the policy machinery is
inactive.

## What a policy governs

A policy is a YAML file that constrains a workload along three axes:

| Section | Governs |
|---|---|
| `filesystem_policy` | Which paths the workload may read and write. |
| `network_policies` | Which network destinations the workload may reach. |
| `version` | The policy schema version, so a policy is validated against the rules it was written for. |

A policy is deny-by-default: it must end in a catch-all rule that denies
anything not explicitly allowed, and it must not allow access to sensitive
infrastructure endpoints. A policy that omits the catch-all, or that allows a
prohibited endpoint, is rejected before it can be used.

## Validating a policy

Validate a policy before deploying it. A policy that fails validation is never
applied, so validation is the point at which a mistake is caught.

```bash
aicore policy-validate                 # validate every policy
aicore policy-validate developer       # validate one policy by name
```

Validation checks the YAML syntax, the presence of the required sections, the
deny-all catch-all rule, the absence of prohibited endpoints, and the policy
name format. Each failure is reported with the rule it violates.

## Inspecting sandboxes

Two commands report the sandbox configuration and the live state.
`sandbox-list` reports the configuration in any mode; `sandbox-status` requires
`IOF_RUNNER=sandbox` and otherwise reports that sandbox mode is not active.

```bash
aicore sandbox-list                    # each workflow's policy, prewarm status and pool assignment
aicore sandbox-status                  # active sandbox instances and their idle state
```

`sandbox-list` shows how each workflow is configured — which policy governs it,
whether its sandbox is pre-warmed, and which pool it is assigned to.
`sandbox-status` shows the sandboxes that are currently running, the policy each
carries, the workflow each serves, and whether each is idle.

## Deploying with sandboxing

1. Author a policy for each class of workload, scoped to the data and endpoints
   that workload legitimately needs.
2. Validate every policy with `aicore policy-validate`. Resolve every finding —
   an unvalidated policy is not applied.
3. Set `IOF_RUNNER=sandbox` in the deployment environment.
4. Confirm the configuration with `aicore sandbox-list`, and observe live
   sandboxes with `aicore sandbox-status`.

A workload whose policy denies an operation the agent attempts is stopped at
that operation, not part-way through with a side effect already committed.

## Related pages

- [Deploying as a service](./04-deploying-as-a-service.md) — the service that hosts sandboxed runs
- [Automatic recovery](./03-automatic-recovery.md) — how a stopped workload is handled
- [Command-line tools](../03-building-solutions/02-command-line-tools.md) — the tools a policy governs access to

**Next:** [Managing workspaces](./07-managing-workspaces.md).
