---
sidebar_position: 3
title: Automatic recovery
description: What AI Core Harness absorbs without intervention, why a run should not be stopped at the first error, and the small set of conditions that require action.
---

# Automatic recovery

AI Core Harness is built to absorb failure. Transient conditions — model
stalls, interrupted connections, a call that terminates before producing a
result, an infrastructure connection dropped while idle — are expected
conditions in any system built on model calls across a network. They are
absorbed by the platform rather than raised to the operator one at a time.

The consequence for anyone running a solution is a single rule:

:::warning Do not stop a run at the first error
What appears to be a stalled run is usually recovery in progress. Stopping the
run interrupts exactly the mechanism that would have completed it. A run always
converges: it ends `done`, or it ends `failed` with a recorded reason and a
complete evidence trail.
:::

## What is absorbed without intervention

| Condition | Response |
|---|---|
| A model call stalls, is interrupted, or terminates without a result | The step is retried within the same run. The failed attempt's evidence is preserved. |
| A step reports completion without producing a required deliverable | The step is failed and retried. An incomplete result is never passed downstream. |
| A step's own call timeout elapses while its work continues | The work continues and the orchestrator polls until the step completes. |
| A step is left running by a process that stopped | The step is reclaimed and re-executed. |
| A run's driver stops while work remains | The driver is restarted and the run resumes from the last completed step. |
| A run is interrupted entirely | It is resumed from where it stopped, on any host. |

Every retry is bounded. A hard attempt cap applies per step, so a run cannot
retry indefinitely: it reaches `done` or it fails with the cap recorded as the
reason.

## Why a long step is not a stalled step

A step may run for several minutes and report an elapsed call timeout while its
work continues normally. The orchestrator polls until the step completes rather
than treating the elapsed timeout as a failure. This is expected behaviour, not
a fault, and imposing shorter timeouts to suppress the message causes real work
to be discarded.

To distinguish a step that is working from a step that is stuck:

```bash
aicore forensics tail <run_id>
```

Activity in the timeline — attempts, tool calls, artifact writes — is a step
working. Silence across the poll interval, with the run's driver also silent, is
the condition the platform's own supervision detects and acts on. The sweep
interval, the staleness thresholds and the resume limit are set by the
`IOF_SUPERVISOR*` variables in the
[environment variable reference](../07-reference/07-environment-variables.md).

## What requires action

A small set of conditions cannot be recovered automatically, because the cause
is configuration or data rather than transience.

| Condition | Action |
|---|---|
| No model provider configured, or invalid credentials | `aicore config-check`, then correct the provider configuration |
| A model provider rejects every generation call | Check the provider's limits; see [Troubleshooting](../02-getting-started/shared/02-troubleshooting.md) |
| A required data source or tool is unreachable | Restore access; the run's evidence names the failing call |
| A definition names a role, skill or artifact that does not exist | `aicore lint-workflow <name>` or `aicore lint-swarm --name <name>` |
| A step exhausts its attempt cap | Diagnose the underlying cause before retrying |

Diagnose any of these from the run's own record:

```bash
aicore forensics explain <run_id>
```

## Resuming and correcting a run manually

These commands intervene in a run that has already stopped. They are not for use
against a run that is still executing.

```bash
aicore resume <id>
```

Continues an interrupted run: steps left running by a process that stopped are
reset, and the run's driver — the one it was created with, `agent` or `code`
— is started again against the existing record. A completed run is refused,
and a run whose driver is still alive is refused unless `--force` is given.

This is also how a run continues after `step-retry`: the retry resets the
step, and `aicore resume <id>` runs it. A failed run's console names both
commands.

A driver that has simply been killed is detected by silence: a `code`
driver is considered gone after 30 seconds without a heartbeat, the default
driver after five minutes (an agent's turn can legitimately take that
long). Inside that window `resume` refuses, saying how old the last
heartbeat is; `aicore status --run-id <id>`, `aicore forensics explain <id>`
and `aicore watch <id>` say `driver: GONE` once it has passed. When you know
the driver is dead — you killed it — `aicore resume <id> --force` does not
wait. A run that failed before any step completed — its driver killed or
crashed at birth — has no step to point at; `aicore forensics explain` says
exactly that and names `aicore resume <id> --force` as the way to continue
it, so the failure is never a dead end with no cause.

A dead driver also holds any queue its workflow declared with
`single_active_run`: a second `aicore run` of that workflow is refused while
the first is recorded as running. When the first run's driver has stopped
sending heartbeats the refusal says so beside the run
(`driver GONE - no heartbeat for <n>s`) and prints the command to type
(`aicore resume <id>`); under `aicore serve` the supervisor restarts it
without anyone typing anything. The thirty-second rule holds for a `code`
driver killed mid-step as well as between steps: a running step's own
heartbeat does not vouch for it. A run whose driver has not yet sent its
first heartbeat is judged from its creation time, so a run two seconds old
is never declared gone.

`POST /api/run/{id}/resume` applies the same window as the command line and
answers 409 inside it unless the body says `{"force": true}`; a resumed run
records `run.resumed` whichever surface asked.

A resume also resets the steps the dead driver was running — a command step
sends a heartbeat every few seconds while it lives, so one silent for thirty
seconds died with its driver — recording `step.reaped_on_resume` for each,
and the fresh driver starts them again at once rather than waiting for the
supervisor's sweep. A foreground run stopped with Ctrl+C records
`run.interrupted` and prints the `resume` command to continue it.

To stop a run for good — no retry, no resurrection, no further model calls:

```bash
aicore cancel <run_id> --reason "superseded"
```

It stops the run's driver, fails every running step with the reason, records
`run.cancelled`, and the supervisor leaves the run alone; `aicore forensics
explain` reads `Run CANCELLED by ...`. Cancelling a stuck run is immediate;
cancelling a run whose driver is **still alive** asks for confirmation first,
so a mistyped run identifier does not stop a healthy run — pass `--yes` to
skip the prompt, which is required when there is no terminal. Over the service
it is `POST /api/run/{id}/cancel`. `aicore step-retry` re-opens a step if the
cancellation was a mistake.

```bash
aicore step-retry --run-id <id> --step-key <key>
```

Resets a failed step to pending and raises its attempt allowance, so it is
executed again.

```bash
aicore step-retry --run-id <id> --step-key <key> --crash-recovery
```

Resets a step that was left in a running state by a process that stopped,
without consuming an attempt.

```bash
aicore step-skip --run-id <id> --step-key <key>
```

`aicore step-retry` and `aicore step-skip` act on the run named by `--run-id`.
With it omitted they resolve only a run of your own and never another user's,
so an operator on a shared deployment cannot reach a colleague's run by
reflex.

Marks a step as completed with a skipped result, so that the steps depending on
it can proceed. Use this only when the skipped step's deliverable is genuinely
not required; downstream steps will run without it.

## Judging whether a solution is reliable

The measure of a reliable solution is not that no failure occurs during a run.
It is that the run converges without intervention, and that the reason for any
failure is recorded.

Run the pipeline end to end without intervening, and confirm two things: that it
ends `done` or with a bounded, explained failure, and that the evidence trail
accounts for every attempt. A run that completed only because someone watched it
and restarted a step has not demonstrated anything about the solution.

**Next:** [Deploying as a service](./04-deploying-as-a-service.md).
