---
sidebar_position: 1
title: Common failures
description: Symptoms you can observe, their cause, and the corrective action - covering installation, authoring, running, and content distribution.
---

# Common failures

Each entry states a symptom as it presents, its cause, and the action that
corrects it.

## Installation and setup

| Symptom | Cause | Action |
|---|---|---|
| `aicore` is not recognised as a command | The platform is installed in an environment that is not active | Activate the environment, or invoke the executable from within it |
| A newly created command-line tool is not found | Tool executables are generated when the package is installed | Reinstall the package after creating the tool |
| A workflow does not appear in `aicore list-workflows` | Content added to a solution is not visible until the solution is reinstalled | Reinstall the solution, then list again. See [Building workflows](../03-building-solutions/06-workflows.md#run-it) |
| A solution's content does not appear when running or listing | The solution is installed in a different environment from the one the platform runs in | Install the solution into the same environment |
| A configuration value has no effect | Another source is supplying that value | Run `aicore config-check`. It reports the value in force and the file that supplied it |
| An agent reports that a command was not found while running a step | The tool is declared but not provisioned on this machine | Run `aicore cli-hub check` to confirm, then `aicore cli-hub install`. See [Verify provisioning](../03-building-solutions/02-command-line-tools.md#verify-provisioning) |
| A tool is installed, but provisioning still reports a gap | The declaration, the executable and the entry point must agree on the name, and the installed name carries a prefix | Compare the three against [The binary name carries a prefix](../03-building-solutions/02-command-line-tools.md#the-binary-name-carries-a-prefix) |

## Authoring definitions

| Symptom | Cause | Action |
|---|---|---|
| A setting in a definition appears to have no effect | The key is misspelled. Unrecognised keys are not read, and no error is raised | Run `aicore lint-workflow <name>` or `aicore lint-swarm --name <name>`. The linter reports the key with its intended spelling |
| Every `{{variable}}` renders as its own literal text in prompts | The `vars` block key itself is misspelled, so no variables were defined | Correct the key to `vars` |
| The definition fails to load, citing a value type | A variable value is an unquoted number. Variable values must be strings | Quote the value: `window_days: "180"` |
| Steps read the wrong metadata, or metadata is empty | `name` does not equal the workflow's directory name | Set `name` to the directory name |
| A skill fails to load | Its `description` is unquoted and contains a colon followed by a space, which is read as a nested value | Quote the description |
| An agent lacks a capability the step requires | The role's `skills` list is the exact set loaded; anything not named is dropped | Add the skill to the list, or remove the list so the agent's full assignment loads |
| A skill named in a `skills` list is reported as not found | It does not exist under that name anywhere in the workspace | Correct the name, or create and assign the skill |
| Per-item work runs the wrong prompt, or fails to resolve a template | The workflow declares more than one fan-out anchor. Per-item work resolves against the first | Split the second fan-out into its own workflow |

## Running

### A run appears to be doing nothing

This is usually recovery in progress, not a fault. AI Core Harness absorbs transient
conditions by re-attempting the affected step, and re-attempting involves
waiting.

Establish which case applies before acting:

```bash
aicore status --run-id <run_id>
aicore forensics tail <run_id>
```

or ask the assistant:

```text
Is run_20260416_141904_011042 stuck?
```

| State | Action |
|---|---|
| A step is executing | None. Wait |
| A step is being re-attempted | None. Intervening discards the recovery in progress and the run restarts work it had already completed |
| No step is executing and none can start | Diagnose. `aicore forensics explain <run_id>` names the blocking condition |

### Other run failures

| Symptom | Cause | Action |
|---|---|---|
| Every step is marked failed and retried although the agent completed its work | The agent's final report carries no `STATUS:` line, so the platform cannot tell success from failure and treats the attempt as failed. The agent is missing the `output_protocol` skill — most often because the step's `skills:` list does not name it, which drops it | Name `output_protocol` in the step's `skills:` list, or omit `skills:` so the agent's full set loads. `aicore forensics explain <run_id>` confirms the missing marker |
| A run completes successfully but a deliverable is empty or missing | The producing step declares no artifact gate, so it reported success having written nothing | Add the file to that step's `requires_artifacts`. See [The artifact gate](../03-building-solutions/06-workflows.md#the-artifact-gate), which also covers the singular-spelling trap |
| A step exhausts its attempts on the same failure each time | The cause is deterministic, so each attempt reproduces it | Correct the cause. Raising `max_attempts` repeats the failure at greater cost |
| A later step produces conclusions unsupported by the data | An earlier step handed off an artifact that was never verified | Gate the handoff with `requires_artifacts`, and review the run - see [Reviewing output quality](../06-core-assistant/04-reviewing-output-quality.md) |
| Figures disagree between sections of a deliverable | Arithmetic performed in a prompt is not deterministic | Move the computation into a command-line tool and have the step call it |
| A run reasons from figures that belong to an earlier run's data | Learning is enabled, so prior conclusions carry forward | Set `learning: disabled` in the definition |
| `learning: none` did not disable learning | Only a fixed set of values is honoured, and `none` is not among them | Use `learning: disabled` |

### Swarms

| Symptom | Cause | Action |
|---|---|---|
| A swarm stops without producing its deliverable | The tool-call ceiling was reached before the goal was met | Raise `budget.tool_calls`, or narrow the goal to what the roster can complete within the ceiling |
| A swarm answers from general knowledge and consults nothing | Both `agents` and `mcp_servers` are declared as empty lists | Remove the empty lists to make all registered entries available, or name the entries the swarm should use |
| A swarm consults the wrong roster member, or none | Routing matches against each registry entry's description, tags and examples | Add or improve those fields on the registered entry |
| A roster name is reported as unrecognised when the run is prepared | The name is not registered in this workspace | Confirm with `aicore a2a-list` or `aicore mcp-list`, and correct the name or register the entry |
| A swarm retry repeats work the previous attempt had completed | A customised briefing removed the run plan checkpoint | Restore the checkpoint instruction in the briefing |

### External capabilities

| Symptom | Cause | Action |
|---|---|---|
| A tool call to an MCP server abandons before returning | The call exceeded the configured timeout | Raise `toolTimeout` for that server, or reduce the scope of the request |
| An MCP server is declared but its tools are unavailable | The declaration was dropped for an unresolved variable, suppressed by a higher tier, refused by the server itself, or has no skill directing an agent to use it | Work through the diagnostic table in [Verify](../03-building-solutions/04-mcp-tools.md#verify). `aicore mcp-list` confirms the registration; `aicore mcp-list --probe` reports whether the server accepts the credential |
| An MCP server's declared OAuth grant is reported as rejected | The token endpoint refused the client credentials, the scope or the audience. The rejection is of the grant, not of a tool call | `aicore mcp-list --probe` names it. Check the token endpoint in the declaration, the client identifier and secret values in the workspace `.env`, and any scope or audience the server requires — see [What to do about each verdict](../03-building-solutions/04-mcp-tools.md#what-to-do-about-each-verdict) |
| An MCP server that worked stops answering after a period | A static credential expired. Nothing renews one, so a short-lived token works until its expiry and then every call is refused | Replace the value in the workspace `.env`, or declare an OAuth client-credentials grant, which the runtime renews before expiry — see [Authentication](../03-building-solutions/04-mcp-tools.md#authentication) |
| Consulting an external agent fails | The endpoint is unreachable, or the credential was rejected | Confirm the registration with `aicore a2a-list`, then confirm the endpoint and credential with the team that operates it |
| Prompts are unexpectedly large where an MCP server is available | The solution has access to the server's entire tool surface | Restrict it with `enabledTools` |

### Playbooks and cases

| Symptom | Cause | Action |
|---|---|---|
| A request matches no playbook (`matched: false`) | No operational playbook claims the phrase | Restate the request with one of the returned `known_triggers`, or declare the phrase as a synonym on the playbook. `iof-plays unmatched` lists what was asked and not covered |
| `iof-case simulate` reports `no rulebook '<id>'` | `simulate` reads the installed rulebook; the file was only validated | Install it first: `iof-case rulebook put --file <file> --as "<name>"` |
| A rulebook is refused at install naming a delivery kind | The workspace declares no tool for that kind | Declare it in `deliveries.yaml` or `IOF_CASE_DELIVERIES`; `iof-case deliveries` shows what resolves |
| A decision stays `PENDING` and nothing delivers it | It is newer than the dispatch delay, older than the maximum age, or its delivery runs failed the maximum number of times | `iof-case dispatch --dry-run` says which; `iof-case explain <case_id>` names the retry that is safe |
| A timer trigger returns `fenced` or `suppressed` | The case moved to a later window, or the occurrence was already applied | Complete the job; do not retry. Only `error` is retried |
| A commissioned run failed but the case has not moved | A failure is applied only after the run has been quiet for the grace period, because the platform retries failed runs | Wait out `IOF_CASE_RUN_FAILURE_GRACE_S`, or run `iof-case runs --settle` once the run is quiet |

## Workspace selection and runtime availability

| Symptom | Cause | Action |
|---|---|---|
| A command refuses, stating that no workspace is selected | A workspace is always named explicitly; the platform never chooses one on your behalf | Select one with `aicore workspace use <code>`, or name it per command with `--workspace <code>`. `aicore current` reports what is selected |
| A request through AI Core Harness Studio is refused as naming no workspace | The interface sends the selected workspace with every request, and none was selected | Select a workspace in the workspace switcher. Where the selection is not offered, membership is missing — see [Managing workspaces](../04-running-solutions/07-managing-workspaces.md) |
| A new workspace reports that its runtime is being prepared | Expected. A workspace has a catalog and a runtime, and the runtime for a newly created workspace is not online yet | None. Agents, skills and workflows can be built immediately; running them begins working once the runtime is available. Locally, start it with `aicore serve` naming that workspace |
| A workspace that previously ran reports that its runtime is temporarily unreachable | The runtime answered before and is not answering now | Confirm the service is running and reachable from the interface's host. The state names when it was last seen |

## Runtime service authentication

| Symptom | Cause | Action |
|---|---|---|
| `aicore serve` refuses to start, stating it will not serve without authentication | The service binds an address other than loopback and no credential is required on it | Set `IOF_ENGINE_AUTH` to `oidc` or `apikey`, set it to `off` to state the decision explicitly, or bind `--host 127.0.0.1`. See [Securing the service](../04-running-solutions/05-securing-the-service.md) |
| A caller receives `401` from the runtime service | No credential was presented, or the one presented did not verify | Confirm the caller's `IOF_ENGINE_CRED_*` values. `aicore agent-chat` names what it presented in its own error. The service log records the specific reason; the response deliberately does not |
| A caller receives `403` from the runtime service | The token verified but does not carry a required application role or scope | Grant the caller the role named in `IOF_ENGINE_OIDC_REQUIRED_ROLES`, or the scopes in `IOF_ENGINE_OIDC_REQUIRED_SCOPES`, and have an administrator consent to it |
| Every token is refused although the identity provider issues them correctly | The audience or the issuer does not match. With Microsoft Entra ID, naming a single issuer rejects tokens carrying the other identifier it uses for the same application | Set `IOF_ENGINE_OIDC_TENANT_ID` rather than `IOF_ENGINE_OIDC_ISSUER`, and confirm `IOF_ENGINE_OIDC_AUDIENCE` matches the Application ID URI exactly. `GET /api/whoami` reports the configuration in force |
| The token endpoint refuses the caller with an invalid-scope error | Microsoft Entra ID accepts only `<audience>/.default` for this grant; individual scopes are consented in the directory | Leave `IOF_ENGINE_CRED_SCOPE` unset so it is derived, or set it to the audience followed by `/.default` |
| The service refuses to start, naming an authentication value it does not recognise | `IOF_ENGINE_AUTH` names a mechanism the service does not know, or names one with nothing configured behind it (`apikey` with no key) | Correct the value; the message lists the accepted ones — `oidc`, `apikey`, both comma-separated, or `off`. Nothing listens until it is fixed, so the misconfiguration cannot be served |

## Workspaces and content distribution

| Symptom | Cause | Action |
|---|---|---|
| `aicore workspace diff` reports every item as new, or `aicore workspace pull` exports nothing | Expected. Both commands read content imported under an earlier model, and a current deployment does not populate it | Carry a Studio edit into the repository with `aicore drafts apply`. See [Drafts and promotion](../03-building-solutions/12-drafts-and-promotion.md) |
| A swarm built in one place is missing in another | A swarm resolves from installed solutions and the local state directory, and a pull does not move swarm definitions | Distribute the swarm with its solution package, or recreate it where it is needed |
| New content does not appear in AI Core Harness Studio | The engine is not running a solution package that contains it | Install the package into the environment the engine runs in, then restart `aicore serve`. The Studio shows what the engine is running and stamps each item with the package version it came from |
| An upgrade's content does not take effect | The environment still runs the previous package version | Deploy the new version and restart the engine. The version stamp shown against each item states which version is in force |
| An edit made in AI Core Harness Studio does not affect a run | Expected. A save creates a draft, which resolves only for its author | Promote the draft — see [Drafts and promotion](../03-building-solutions/12-drafts-and-promotion.md). Until a promoted change is deployed, every run executes the installed content |
| A workspace cannot be deleted | It has run history | Confirm the history is no longer required, then repeat with `--force`, which removes the run records with it |

## Related pages

- [Getting help](./02-getting-help.md)
- [Diagnosing runs](../06-core-assistant/02-diagnosing-runs.md)
- [Building workflows](../03-building-solutions/06-workflows.md)
- [Command-line tools](../03-building-solutions/02-command-line-tools.md)
- [MCP tools](../03-building-solutions/04-mcp-tools.md)
- [Workflow definition reference](../07-reference/02-workflow-yaml.md)
- [Swarm definition reference](../07-reference/03-swarm-yaml.md)

**Next:** [Getting help](./02-getting-help.md).
