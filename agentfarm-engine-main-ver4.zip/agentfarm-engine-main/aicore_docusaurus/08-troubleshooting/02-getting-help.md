---
sidebar_position: 2
title: Getting help
description: How to establish what happened before escalating, and what to include in a support request so it can be answered without a second exchange.
---

# Getting help

Most questions about a run can be answered from the run's own record. Work
through the sequence below before raising a request; where escalation is still
required, the same sequence produces everything the request needs.

## 1. Ask the assistant

State the question against the run. The Core Assistant answers from the run's
recorded evidence and names the step, attempt and record behind its
conclusion.

```text
What happened in run_20260416_141904_011042?
Why did the compose step fail?
Is that run stuck?
Review the deliverable - can I rely on it?
```

See [Diagnosing runs](../06-core-assistant/02-diagnosing-runs.md).

## 2. Establish the facts directly

Where the assistant is unavailable, or a machine-readable record is required:

```bash
aicore forensics explain <run_id>          # verdict for the run
aicore status --run-id <run_id>            # step states
aicore forensics show <run_id> --step <key> --attempt <n>
aicore forensics narrative <run_id> <step>.<attempt>
aicore forensics tokens <run_id>           # consumption
```

`explain`, `show`, `list` and `tokens` accept `--json`. `show` also narrows to
one attempt with `--step` and `--attempt`, and filters with `--severity`.

## 3. Validate the definition

A large proportion of run failures originate in the definition rather than in
execution. An unrecognised key is never read, so a misspelled setting produces
no error and no effect.

```bash
aicore lint-workflow <name> --strict
aicore lint-swarm --name <name> --strict
```

Both report every finding at once, with a line number and a correction.

## 4. Confirm the environment

```bash
aicore --version       # the installed versions, to state in any request
aicore whoami          # identity, and the workspaces it can open
aicore current         # active run and active workspace
aicore config-check    # each configuration value and the file that supplied it
aicore cli-hub check   # declared command-line tools, and whether each is present
aicore mcp-list        # registered MCP servers
aicore a2a-list        # registered external agents
```

`config-check` resolves the most common class of environment problem: a value
in force that was supplied by a different file from the one being edited.

## What to include in a support request

Provide the following. Each item is obtainable from the sequence above, and
together they allow a request to be answered without a further exchange.

| Include | Obtained from |
|---|---|
| The installed versions | `aicore --version`. State these first: behaviour differs between versions, and every other item is interpreted against them |
| The run identifier | The command that started the run, or `aicore current` |
| What was expected, and what occurred | Your own statement of both |
| The run verdict | `aicore forensics explain <run_id> --json` |
| Step states | `aicore status --run-id <run_id> --json` |
| The definition file, and the linter output for it | The repository, and `aicore lint-workflow <name> --strict` |
| Configuration resolution | `aicore config-check` |
| Whether the failure reproduces | Re-run with the same goal, and state the result |

State whether the run is currently executing. A run that is re-attempting a
step is recovering; leaving it to complete frequently resolves the question,
and intervening discards work already completed.

## Before reporting a defect

Confirm each of the following. Each corresponds to a failure that presents as
a platform fault and is not one.

- The definition lints cleanly with `--strict`.
- Every capability the run uses is registered and present:
  `aicore cli-hub check`, `aicore mcp-list`, `aicore a2a-list`.
- The solution is installed in the same environment the platform runs in.
- The engine runs the package version that contains the change. The version
  stamp shown against the item names the version in force; a change that is
  still a draft, or is merged but not yet deployed, does not reach a run.
- The run was not interrupted while it was re-attempting a step.
- Where a deliverable is empty, the producing step declares it in
  `requires_artifacts`.

## Related pages

- [Common failures](./01-common-failures.md)
- [The Core Assistant](../06-core-assistant/01-overview.md)
- [Command-line interface](../07-reference/01-cli.md)

**Next:** [Command-line interface](../07-reference/01-cli.md).
