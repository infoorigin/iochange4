---
id: home
sidebar_position: 0
title: Home
description: "AI Core Harness documentation: what the platform is, how to build a solution on it, and how to run, operate and improve one."
---

# AI Core Harness

AI Core Harness runs multi-agent solutions. A **solution** is a set of agents, the
skills that give them judgment, the tools that give them reach, and the
workflows or swarms that put them to work — built in your own repository,
installed as a package, and run against a workspace of your own.

## Start here

| If you want to | Go to |
|---|---|
| Understand what the platform is and its vocabulary | [Introduction](./01-introduction/01-what-is-ai-core.md) |
| Install it and build a first solution | [Getting started](./02-getting-started/01-choose-your-track.md) |
| Build agents, skills, tools, workflows, swarms and playbooks | [Building solutions](./03-building-solutions/01-agents-and-skills.md) |
| Run a solution, monitor it, and deploy it as a service | [Running solutions](./04-running-solutions/01-running-a-solution.md) |
| Let solutions improve, under review | [Improving solutions](./05-improving-solutions/01-overview.md) |
| Ask the assistant what a run did and why | [The Core Assistant](./06-core-assistant/01-overview.md) |
| Look up a command, a file format or a variable | [Reference](./07-reference/01-cli.md) |
| Work out why something failed | [Troubleshooting](./08-troubleshooting/01-common-failures.md) |

## Two ways to build

Getting started offers the same destination by two routes. Both produce a real
solution; pick the one that matches how your team works.

**Code-first** builds a solution in a repository with the `aicore` command
line: four worked examples take you from a single agent to a workflow with a
deterministic tool, an integration with externally hosted tools, and a swarm.
The solution is code you own, versioned and reviewed like any other.

**AI Core Harness Studio** builds the same things in the product, writing to the
database rather than to files. No repository and nothing to install.

The two are not alternatives to choose between permanently. Content built in
the Studio is held as a draft and carried into a solution repository with
`aicore drafts apply`; a repository is installed as a package into the
environment a workspace's runtime runs in.

## What a solution is made of

- An **agent** is an identity with a job.
- A **skill** is judgment, written as markdown — what to do and when.
- A **tool** is a program an agent runs when an answer must be computed rather
  than reasoned.
- A **workflow** is a fixed pipeline of steps with declared dependencies.
- A **swarm** gives a goal and a roster to one meta-agent, which decides the
  route at run time.
- A **playbook** is a business procedure the platform executes as data:
  written in business language, compiled, approved by a person, and run as
  durable cases.
- A **workspace** is the tenant everything belongs to.

[Introduction](./01-introduction/01-what-is-ai-core.md) covers each in turn, and
explains when a workflow is the right shape and when a swarm is.

**Next:** [What AI Core Harness is](./01-introduction/01-what-is-ai-core.md).
