---
sidebar_position: 1
title: Overview
description: Agents propose reusable methods from completed work; nothing reaches another agent until a person approves it. Three gates govern what a solution learns.
---

# Improving solutions

:::caution Early beta
The learning system is in early beta. Its behaviour and interfaces may change.
Evaluate it in non-production workspaces before relying on it.
:::

A solution improves when the techniques its agents work out on one run become
available to later runs. AI Core Harness captures that improvement as **methods** —
transferable procedures an agent can reuse — and places every method behind a
human approval gate before another agent ever sees it.

## What is learned, and what is not

A method is a **technique**: how to reconcile two sources, how to structure a
particular kind of brief, which computation a class of question requires. A
method is never a **conclusion** — a figure, a name, or a result from one
dataset. Conclusions go stale and would mislead the next run; the system
classifies them and discards them rather than storing them.

A solution therefore accumulates transferable technique rather than data.

## Scope

Every method is scoped to a **(role, workflow) pair**. A method learned by the
brand-analyst role in one workflow is offered only to that role in that
workflow. No method is available outside the scope that produced it.

## The three gates

Three gates separate a proposed method from an agent that could apply it. A
proposal that fails any one of them never reaches an agent.

| Gate | What it enforces |
|---|---|
| **Recurrence** | A method is proposed only when a genuinely new approach recurs. One-off approaches are not turned into methods. |
| **Security scan** | A proposal whose body contains a dangerous instruction — prompt injection, a destructive command, credential access, an embedded secret — is blocked. |
| **Human approval** | A proposed method is inert until a person approves it. Approval is the only action that releases it to agents. |

## Default state

Learning is active by default and requires no configuration to enable. What it
does unattended is bounded: it proposes drafts. **A draft reaches no agent
until a person approves it.** In its default state the system therefore
accumulates proposals for review; it does not change how any agent behaves.

Two controls disable it. `IOF_LEARNING_V2=0` turns learning off for the
deployment: nothing is proposed and nothing is applied. `learning: disabled`
on a workflow excludes that workflow alone. Both are described in
[Governing what is learned](./03-governing-what-is-learned.md).

**Next:** [How solutions learn](./02-how-solutions-learn.md).

## Related pages

- [How solutions learn](./02-how-solutions-learn.md) — the lifecycle a builder observes
- [Governing what is learned](./03-governing-what-is-learned.md) — the review workflow
- [Cross-run recall](./04-recall.md) — reusing what earlier runs established
