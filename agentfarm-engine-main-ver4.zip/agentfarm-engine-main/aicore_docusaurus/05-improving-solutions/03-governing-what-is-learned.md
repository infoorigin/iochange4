---
sidebar_position: 3
title: Governing what is learned
description: Review, approve and reject proposed methods, at the command line or in AI Core Harness Studio. A dangerous draft cannot be approved. Every decision is audited; a git-versioned store makes each approval a reviewed commit.
---

# Governing what is learned

The learning system is in early beta.

Nothing an agent proposes reaches another agent until a person approves it.
This page is the review workflow a steward performs to exercise that gate.

The same queue is available two ways: the `aicore learning` commands below, and
**AI Core Harness Studio → Learning**, which presents the queue, each draft's evidence
and security findings, the decision controls, and the audit trail. Both act on
one queue and one audit log; a decision made in either is visible in the other.
The commands are shown here because they scale to scripting and run where a
steward has no browser.

## The review loop

```bash
aicore learning pending                  # the queue: scope, evidence, scan verdict
aicore learning show <id>                 # full method + why it was proposed + findings
aicore learning approve <id> --as <you>   # release it to agents in its scope
aicore learning reject  <id> --as <you> --reason "..."
aicore learning audit                     # who decided what, and when
```

`pending` lists every draft with its `(role, workflow)` scope, its measured
evidence — how often applied and the completion rate of work that used it — and
its security verdict. `show` prints the full method, the reason it was proposed,
and each security finding, so a reviewer decides without opening a file.

## A dangerous draft cannot be approved

`approve` re-runs the security scan and refuses any draft the scan marks
dangerous, naming the findings. A dangerous draft is rejected, not released.
This is enforced when the decision is made, not left to reviewer discretion:
the Studio disables its Approve control for such a draft, and the server
refuses the approval even if the request is made directly.

Every decision — approve, reject, and a refused approval — is recorded in an
audit log with the approver, the method, and the timestamp. `aicore learning
audit` prints that trail.

Approval is the only action that moves a method to where an agent loads it. It
takes effect on the agent's next run.

## Git-versioned approval

For a durable, reviewable audit trail, point the approved-method store at a git
repository. Each approval then becomes a commit a team can review as a pull
request.

```bash
export IOF_LEARNING_INBOX_DIR=/path/to/approved-methods-repo   # a git checkout
aicore learning approve <id> --as jane.steward --commit --note "reviewed: sound method"
```

`--commit` writes the approved method into the repository and commits it with
the approver and the security verdict in the message. Push the branch and open
a pull request for peer review before merge. The merged repository is the set
agents read from — nothing reaches an agent that is not a reviewed, committed
file.

## Controlling authoring

Learning is active by default and requires no setting to enable. Unattended, it
proposes drafts and takes no further action: no method reaches an agent without
a human decision. Each setting below narrows that default.

| Setting | Effect |
|---|---|
| `IOF_LEARNING_REVIEWER=off` | Stop proposing new methods, while continuing to measure those already approved. Retains the record without adding to the queue. |
| `IOF_LEARNING_V2=0` | Disable learning for the deployment. Nothing is proposed, nothing is applied, and approved methods stop being offered. |
| `learning: disabled` in a workflow | Exclude that workflow. Its runs propose nothing and apply nothing; other workflows are unaffected. |
| `IOF_LEARNING_INBOX_DIR` | The approved-method store; set it to a git checkout for the reviewed-commit workflow above. |

`IOF_LEARNING_V2=0` is a single-purpose control: it disables learning, and a
deployment that sets it receives no methods.

**Next:** [Cross-run recall](./04-recall.md).

## Related pages

- [Overview](./01-overview.md) — the three gates
- [How solutions learn](./02-how-solutions-learn.md) — the lifecycle
