---
sidebar_position: 2
title: How solutions learn
description: A completed run may yield a draft method; drafts accumulate for review; approved methods load on the next run; each method's real-world effect is measured.
---

# How solutions learn

The learning system is in early beta.

This page describes the lifecycle a builder observes with learning active,
from a completed run to a method an agent applies.

## The lifecycle

1. **A completed run may yield a draft.** When an agent works out a technique
   that recurs, the system proposes it as a **draft method**. Most runs yield
   no draft; a draft appears only when a genuinely new, recurring approach is
   observed.
2. **Drafts accumulate for review.** A draft is inert. It waits in a review
   queue with the scope it applies to, the reason it was proposed, and the
   result of its security scan.
3. **A person approves or rejects it.** Approval is the only action that
   releases a method to agents. See
   [Governing what is learned](./03-governing-what-is-learned.md).
4. **Approved methods load on the next run.** An approved method becomes
   available to its scoped role the next time that role runs. It is presented
   as one of the agent's skills.
5. **Each method's effect is measured.** As approved methods are applied, the
   system records how often each is used and the completion rate of the work
   that used it. A steward reviews that evidence, not the method's prose alone.

## What a method carries

A method carries **technique, not figures**. It states how to approach a class
of problem — the steps, the checks, the structure — in terms that transfer to
new data. It does not carry the numbers, names, or conclusions from the run
that produced it. This is what makes a learned method safe to apply to a
different dataset.

## What runs by default

Learning is active without configuration, and what it does unattended stops at
step 2: drafts accumulate. Steps 3 to 5 require a person, so no agent's
behaviour changes until someone approves a method.

Run representative work in a non-production workspace first and review what the
system proposes there. The queue shows what a solution is proposing to learn
before any of it reaches an agent. The settings that narrow or disable
authoring, and the review workflow itself, are described in
[Governing what is learned](./03-governing-what-is-learned.md).

**Next:** [Governing what is learned](./03-governing-what-is-learned.md).
