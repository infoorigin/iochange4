---
sidebar_position: 4
title: Cross-run recall
description: Search prior runs' outputs, scope-isolated by role and workflow, to reuse what earlier runs established instead of re-deriving it.
---

# Cross-run recall

The learning system is in early beta.

Recall enables an agent, or a person, to locate what earlier runs produced, so
a solution reuses established results instead of re-deriving them. It searches
**run outputs**, not agent memory: the material is the deliverables and step
outputs prior runs wrote, which are durable and attributable to a specific run.

## Searching prior runs

```bash
iof-recall "vendor concentration method" --role brand_analyst --workflow brand_performance
```

The search is **scope-isolated**: results come only from the given role and
workflow, so one agent's history never surfaces in another's answers.

| Option | Effect |
|---|---|
| `--role` | Restrict the search to one agent role. |
| `--workflow` | Restrict the search to one workflow. |
| `--limit` | Maximum number of matches to return. |
| `--json` | Machine-readable output. |
| `--any-scope` | Search across every scope. Intended for diagnostics; scope isolation is the default. |
| `--reindex` | Rebuild the search index from prior runs' recorded outputs. |

An agent uses recall to check whether a question has been answered before
committing effort to it; a person uses it to trace where a result first
appeared.

## What it is not

Recall retrieves prior **outputs** to inform new work. It does not modify an
agent, and it does not carry conclusions into a prompt on its own — a result is
returned to a caller who reads it and decides. It is retrieval, not memory.

**Next:** [The Core Assistant](../06-core-assistant/01-overview.md).

## Related pages

- [How solutions learn](./02-how-solutions-learn.md) — methods, the other half of improvement
- [The Core Assistant](../06-core-assistant/01-overview.md) — questions about what a run did
