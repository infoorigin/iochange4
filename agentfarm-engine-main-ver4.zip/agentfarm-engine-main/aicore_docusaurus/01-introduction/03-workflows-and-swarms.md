---
sidebar_position: 3
title: Workflows and swarms
description: Both execution models are goal-oriented and produce a gated deliverable. A workflow fixes the route at authoring time; a swarm's meta-agent determines it at runtime under budget and checkpoint controls.
---

# Workflows and swarms

A solution is a collection of workflows and swarms. Both are goal-oriented,
both produce a deliverable that is verified before the run is allowed to
complete, and both execute on the same run machinery.

They differ in one respect: **who decides the route**.

- In a **workflow**, you decide. The steps, their order, the agent responsible
  for each, and the artifact each must produce are declared before the run
  begins and are the same on every run.
- In a **swarm**, the meta-agent decides. You state the goal, grant a roster of
  agents and tools, and set the controls. The route is determined during the
  run and varies with the goal and with what the agents find.

## Comparison

| | Workflow | Swarm |
|---|---|---|
| **Route** | declared in the definition | planned by the meta-agent at runtime |
| **Sequencing** | explicit dependencies between steps | the meta-agent's dispatch order |
| **Agent assignment** | one named agent per step | a roster the meta-agent draws from |
| **Reproducibility** | the same steps on every run | varies with the goal and the findings |
| **Deliverable gate** | one per step | one for the run |
| **Cost profile** | predictable; a function of the step count | bounded by the tool-call budget |
| **Failure isolation** | to the failing step, which retries alone | to the run, which retries from its checkpoint |
| **Best suited to** | a process the business can already name | an objective whose route is not known in advance |

## When to choose a workflow

Choose a workflow when any of the following holds.

- **The process is already named by the business.** Assess, analyse, draft,
  review, sign off — where the sequence exists as a procedure, encode it.
- **The output must be identical in shape every time.** Regulated reporting,
  scheduled analysis and anything a downstream system parses require a fixed
  structure that a declared pipeline guarantees.
- **Different stages require different expertise.** A workflow assigns each
  step its own agent, its own skills and its own prompt, so an analyst step and
  a review step do not share one context.
- **A stage must be verified before the next begins.** Per-step artifact gates
  stop an incomplete result from reaching the step that would build on it.
- **Cost must be predictable.** The number of steps is known before the run
  starts.

## When to choose a swarm

Choose a swarm when any of the following holds.

- **The route depends on what is found.** Where the second question is
  determined by the answer to the first, a fixed pipeline either omits work or
  performs work that is not needed.
- **The work is a synthesis across capabilities.** Where the objective is to
  combine several data sources, connected tools and external agents into one
  assessment, a meta-agent selecting among them is a closer fit than a
  pipeline enumerating them.
- **The set of participants is a policy, not a sequence.** Where the
  requirement is "these agents and these tools are permitted, and nothing
  else," a roster expresses it directly.
- **The task is exploratory.** Investigations, cross-domain reviews and
  first-pass assessments are more usefully expressed as a goal with controls
  than as a route no one has yet established.

A swarm is not an unconstrained agent. Its roster limits what it may use, its
budget limits how far it may go, its checkpoint records what it has completed,
and its deliverable is gated in the same way a workflow step's is.

## What is identical between them

Choosing one over the other does not change how the solution is operated.
Both:

- create a run that is recorded durably and survives process restarts;
- retry within bounded attempt limits and absorb transient failures without
  intervention;
- enforce their declared deliverable before completing;
- write output to the run's output directory, read with `aicore run-output`;
- accept follow-up questions after completion, with the run's context intact;
- retain a complete execution record that the Core Assistant can be questioned about;
- appear in the same status, listing and monitoring surfaces.

## Combining both in one solution

A solution frequently contains both, used in sequence.

| Pattern | Description |
|---|---|
| **Explore, then standardise** | A swarm establishes how a new question should be answered. Once the route is stable, it is encoded as a workflow and run on a schedule. |
| **Standard pipeline, delegated stage** | A workflow handles the fixed process, and one step consults external agents or connected tools for the part that varies. |
| **Pipeline output, swarm review** | A workflow produces the deliverable; a swarm reviews it against sources the workflow did not consult. |

There is no requirement to commit to one model for a whole solution. Both are
defined in the same solution, listed together, and run with the same commands.

## Next

| To build | Go to |
|---|---|
| A workflow | [Workflows](../03-building-solutions/06-workflows.md) |
| A swarm | [Swarms](../03-building-solutions/07-swarms.md) |
| The agents both rely on | [Agents and skills](../03-building-solutions/01-agents-and-skills.md) |

**Next:** [Workflows](../03-building-solutions/06-workflows.md).
