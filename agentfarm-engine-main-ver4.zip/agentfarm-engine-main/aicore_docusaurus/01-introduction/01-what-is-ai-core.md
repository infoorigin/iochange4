---
sidebar_position: 1
title: What AI Core Harness is
description: AI Core Harness is an enterprise platform for building, running and operating solutions in which multiple AI agents cooperate to produce a business deliverable.
---

# What AI Core Harness is

AI Core Harness is an enterprise platform for building, running and operating solutions
in which multiple AI agents cooperate to produce a business deliverable.

A solution built on AI Core Harness is a set of **definitions** — agents, skills, tools
and pipelines, expressed as files in a repository and as records in the
platform database — rather than an application your team writes and maintains.
The platform supplies the agent runtime, the orchestration and state layer, the
connections to external capabilities, the recovery behaviour, and the
operational surfaces through which solutions are executed and inspected.

Your team supplies the domain: what the agents know, what judgment they apply,
what data they are permitted to reach, and what the finished work must contain.

## What you build

Work is organised in three levels.

| Level | What it is | Who owns it |
|---|---|---|
| **Workspace** | One team's tenancy. Holds the agents, skills and command-line tools that the team's solutions share. | one engineering team |
| **Solution** | One business capability, delivered as a collection of workflows and swarms. | the team, within its workspace |
| **Workflow or Swarm** | One executable unit of work that produces a named deliverable. | the solution |

A workspace may contain any number of solutions, and a solution any number of
workflows and swarms. Agents, skills and tools are declared once at workspace
level and are available to every solution in it, so a second solution reuses
the first solution's analyst rather than duplicating it.

## The two execution models

Every unit of work in a solution is either a workflow or a swarm. Both are
goal-oriented, both produce a gated deliverable, and both run on the same
execution and recovery machinery.

- A **workflow** is a pipeline you define. You declare the steps, the agent
  responsible for each step, the order in which they run, and the artifact each
  step must produce. The route is fixed at authoring time and is identical on
  every run.
- A **swarm** is a goal you delegate. You nominate one meta-agent, grant it a
  roster of agents and connected tools, and state the objective. The meta-agent
  determines the route at runtime, within controls, a budget and a checkpoint
  that you set.
- A **playbook** is a business operating procedure handed to the platform as
  data. The business writes it in its own language; it is compiled into a
  validated form, approved by a person, and executed as durable cases whose
  every decision is recorded — see
  [Playbooks](../03-building-solutions/10-playbooks.md).

Choosing between them is a design decision covered in
[Workflows and swarms](./03-workflows-and-swarms.md).

## What the platform supplies

| Capability | What it means for a solution |
|---|---|
| **Agent runtime** | Agents hold a persistent identity, memory and skills, and reach tools through a managed session. |
| **Orchestration and state** | Runs and steps are recorded durably. A run survives process restarts and can be resumed. |
| **Capability integration** | Command-line tools, Model Context Protocol servers and external agents are connected by declaration; no client code is written. |
| **Fail-closed deliverables** | A step that does not produce its declared artifact is recorded as failed and retried, even when the agent reports success. |
| **Automatic recovery** | Transient model, network and execution failures are absorbed by the platform and retried within bounded attempt limits. |
| **Execution record** | Every run retains its prompts, dialog, tool activity, timings and outcome for later inspection. |
| **Core Assistant** | An assistant that answers questions about what a run did, what it cost, whether its output is sound, and how to design a solution. |
| **Learning (early beta)** | Agents propose reusable methods from completed work; a method reaches other agents only after a human approves it. |
| **AI Core Harness Studio** | A browser interface for building agents, skills and workflows and for running and reviewing them. |

## How you work with it

Three surfaces address the same platform and the same data.

- **The `aicore` command line and SDK.** The code-first surface. Solutions are
  scaffolded, edited, validated, published and executed from a repository your
  team owns under source control.
- **AI Core Harness Studio.** The browser surface. Agents, skills and workflows are
  authored and run without a local development environment. Studio and the
  command line operate on the same workspace, and content moves between the
  repository and the platform in both directions.
- **The service API.** Solutions are executed and monitored programmatically,
  and agents that are always available answer requests directly.

Content authored in a repository is visible in the Studio once its package is
installed; content authored in the Studio is held as its author's draft until
it is promoted into the repository. A team may use one surface exclusively or
both together.

## What a run produces

Executing a workflow or a swarm creates a **run**. A run proceeds through its
steps, records what each step did, and writes deliverables into the run's
output directory. Every step declares the artifact it must produce; the run
does not advance past a step whose artifact is missing or empty.

Deliverables are read, published and searched with `aicore run-output`. A run's
agents can be questioned after it completes, with the run's own context intact.

## Where to start

| If you want to | Go to |
|---|---|
| Learn the vocabulary this documentation uses | [Core concepts](./02-core-concepts.md) |
| Decide between a workflow and a swarm | [Workflows and swarms](./03-workflows-and-swarms.md) |
| Install AI Core Harness and build a first solution | [Getting started](../02-getting-started/01-choose-your-track.md) |
| Understand the building blocks in detail | [Building solutions](../03-building-solutions/01-agents-and-skills.md) |
| Let solutions improve under review | [Improving solutions](../05-improving-solutions/01-overview.md) |

**Next:** [Core concepts](./02-core-concepts.md).
