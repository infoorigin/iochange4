---
sidebar_position: 2
title: Core concepts
description: The vocabulary AI Core Harness uses — workspace, solution, agent, skill, tool, workflow, swarm, run, step and deliverable — and the scope rule that governs where each one is defined.
---

# Core concepts

This page defines every term used throughout this documentation set and states
the scope at which each artifact is defined.

## The scope rule

**Capabilities are shared at workspace level. Executable work belongs to a
solution.**

Agents, skills and command-line tools are declared once for the whole workspace
and are available to every solution in it. Workflows and swarms belong to an
individual solution.

```
workspace
├── agents/                 identities shared by every solution
├── skills/                 judgment shared by every solution
├── tools/                  command-line tools shared by every solution
└── solutions/
    ├── <solution-a>/
    │   ├── workflows/<name>/
    │   └── swarms/<name>/
    └── <solution-b>/
        └── workflows/<name>/
```

A workflow in one solution may name an agent, a skill or a tool declared
anywhere in the workspace. It may not reach into another solution's workflows.

## Vocabulary

| Term | Definition |
|---|---|
| **Workspace** | One team's tenancy. Contains the team's shared agents, skills and tools, its solutions, its connected capabilities, and its configuration. Content is isolated between workspaces. |
| **Solution** | One business capability, expressed as a collection of workflows and swarms. |
| **Agent** | A named identity with a defined responsibility, a persistent memory and a declared set of skills. Defined at workspace level. |
| **Skill** | Judgment, written as markdown, that an agent loads. A skill states when work applies, how to approach it, and what to refuse. |
| **CLI tool** | A script installed as a command-line executable, invoked by agents for deterministic computation. |
| **MCP server** | An externally hosted capability whose tools the runtime connects to and registers automatically at session start. |
| **External agent** | A whole agent operated by another team, reachable over the Agent2Agent protocol and consulted by your agents. |
| **Workflow** | A pipeline of steps, defined in advance, in which each step is assigned to an agent and gated on an artifact. |
| **Step** | One unit of a workflow: an agent, a prompt, the skills it loads, its dependencies, and the artifact it must produce. |
| **Swarm** | A goal delegated to one meta-agent, which determines the route at runtime from a granted roster of agents and tools. |
| **Meta-agent** | The agent that plans and dispatches within a swarm. |
| **Roster** | The set of agents, tools and skills a swarm's meta-agent is permitted to use. |
| **Run** | One execution of a workflow or a swarm, recorded durably with its steps, outputs and outcome. |
| **Deliverable** | A file a step or a swarm must produce. Named in the definition and enforced. |
| **Artifact gate** | The check that records a step as failed when its declared deliverable is missing or empty, regardless of what the agent reported. |
| **Catalog** | The description of the data a workflow may query, supplied with the workflow rather than embedded in an agent. |
| **Budget** | The limits placed on a swarm: how many tool calls it may make and how many consultations it is allowed. |
| **Playbook** | A business operating procedure executed as data: authored in business language, compiled into a validated form, approved by a person, and revised without a release. |
| **Rulebook** | The validated document a case playbook runs on: the states a case can hold, the typed events it accepts, the rule for each combination, and what each action delivers. |
| **Case** | One durable record per item a case playbook handles, holding its own state, window and ledger. |
| **Meta Agent** | The platform agent that is the front door for playbook execution: it matches a request to the approved playbook, opens cases, relays events and reports from the ledger. Distinct from a swarm's meta-agent. |
| **Learned method** | A reusable technique an agent proposes from completed work. It reaches other agents only after a human approves it. Scoped to a role and workflow. Early beta. |

## Workspace

A workspace is the unit of isolation and of ownership. It holds:

- the team's agents, skills and command-line tools;
- one or more solutions;
- the workspace's connected capabilities — its Model Context Protocol servers
  and its external-agent registry;
- the workspace's configuration and environment values.

A workspace exists both as a repository your team owns and as records in the
platform. Content reaches the platform when the repository's package is
installed into the workspace runtime's environment, and an edit made in the
Studio is carried back into the repository as a draft, so that either surface
can be the place work is done.

An engineer works in one workspace at a time. Commands that operate on
workspace content name their target explicitly.

## Solution

A solution groups the workflows and swarms that deliver one business
capability. It is the packaging boundary: a solution is added to a workspace,
listed, published and executed as a unit.

Adding a solution to a workspace registers it with the platform. In a
repository-based workspace, the registration takes effect when the workspace is
reinstalled; until then the new solution's workflows are not listed.

## Agent

An agent is a named identity, defined once at workspace level and used by any
solution.

An agent holds:

- **an identity** — what it is responsible for and what it must decline;
- **memory** — retained across runs, never overwritten by a rebuild;
- **carried skills** — declared by name, so one copy of a skill serves every
  agent that carries it;
- **an output contract** — the markers each step is parsed for.

Agents are defined in [Agents and skills](../03-building-solutions/01-agents-and-skills.md).

## Skill

A skill is judgment expressed as markdown. It states when the work applies, how
to approach it, what good output looks like, and what to refuse. It is not a
function and it is not a wrapper around one.

Three placements exist, and the placement determines who holds the skill:

| Placement | Held by |
|---|---|
| Inside an agent | that agent only |
| At workspace level | any agent that declares it, and any workflow step that names it |
| Supplied with the SDK | any agent that declares it |

Skills are open: a workflow step may name any skill in the workspace, including
one the agent does not otherwise carry.

## The three kinds of capability

An agent reaches the outside world in three ways. They differ in who hosts the
capability and how it is declared.

| Kind | Hosted by | Declared as | Documented in |
|---|---|---|---|
| **CLI tool** | your workspace | a script, a console-script entry, and a declaration | [Command-line tools](../03-building-solutions/02-command-line-tools.md) |
| **MCP server** | a service, internal or external | a server entry at one of three tiers | [MCP tools](../03-building-solutions/04-mcp-tools.md) |
| **External agent** | another team | an entry in the workspace registry | [External agents](../03-building-solutions/05-external-agents.md) |

In all three cases the capability is connected by declaration. A paired skill
tells agents when the capability is the right answer; the declaration is what
makes it reachable.

## How a solution improves

A solution does not have to be static. From completed work, an agent can
propose a **learned method** — a reusable technique, never a specific dataset's
conclusions. A proposed method is inert until a human approves it, and an
approved method applies only to the role and workflow it was scoped to. This
capability is in early beta and is covered in
[Improving solutions](../05-improving-solutions/01-overview.md).

## Run, step and deliverable

Executing a workflow or a swarm creates a **run**. The run is recorded durably,
so that its state is independent of the process that started it.

A workflow run proceeds through its **steps** in dependency order. Each step:

1. loads its agent, that agent's memory, and the skills the step names;
2. receives its prompt, with the run's goal and prior step outputs substituted
   in;
3. performs its work, reaching tools as required;
4. writes its declared artifact into the run's output directory;
5. reports its status.

A swarm run is a single step whose agent is the meta-agent. Everything that
applies to a workflow step — the artifact gate, retries, the recorded
execution, follow-up questioning — applies to it unchanged.

The **artifact gate** is what makes a step's completion verifiable. A step that
reports success without producing its declared deliverable is recorded as
failed and retried. An incomplete handoff is therefore never presented to the
next step as a successful one.

## Where each artifact is defined

| Artifact | Scope | Created with |
|---|---|---|
| Workspace | — | `aicore workspace scaffold` |
| Solution | workspace | `aicore new-solution` |
| Agent | workspace | `aicore new-agent` |
| Skill | workspace or agent | `aicore new-skill` |
| CLI tool | workspace | `aicore new-tool` |
| MCP server | solution, machine or workspace tier | `aicore new-mcp-server`, `aicore mcp-add` |
| External agent | workspace | `aicore a2a-add` |
| Workflow | solution | `aicore new-workflow` |
| Swarm | solution | `aicore new-swarm` |

The full command surface is in the [CLI reference](../07-reference/01-cli.md).

**Next:** [Workflows and swarms](./03-workflows-and-swarms.md).
