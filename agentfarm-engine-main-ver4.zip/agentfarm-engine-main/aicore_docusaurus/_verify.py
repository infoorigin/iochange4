"""Verification scans for aicore_docusaurus. Four checks, all must report zero.

Run: python verify_docs.py <folder>
"""
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()

def _upstream_runtime_patterns() -> list[str]:
    """The runtime's upstream project is never named in the product. Its name
    is not written anywhere in the repository except the copyright line of
    the runtime licence, so the pattern is derived from there rather than
    spelled here."""
    licence = Path(__file__).resolve().parents[1] / "iobot" / "LICENSE"
    try:
        m = re.search(r"and the (\w+) contributors",
                      licence.read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return []
    return [r"\b" + re.escape(m.group(1)) + r"\b"] if m else []


# Names that spell out a prior product, package or runtime identity.
# Opaque identifiers a user must literally type are NOT banned here:
#   IOF_* env vars, iof-* tool binaries, and the ~/.iobot home directory
#   are real surfaces with no alternative spelling. They are counted
#   separately so their use stays deliberate and small.
BANNED = [
    *_upstream_runtime_patterns(),
    r"\bagentfarm\b",
    r"\bagent[ -]farm\b",
    r"\bioagentfarm\b",
    r"\bantfarm\b",
    r"\bagentfarm[-_](core|skills|api|ui|engine)\b",
    # NOT banned: "AI Core Harness" is the product's real name — it is what
    # the site's own navigation says. Banning it here is why 104 occurrences
    # of the bare "AI Core" accumulated across the corpus and only the home
    # page says the full name. The corpus still needs a deliberate sweep; the
    # ban was actively preventing one.
    r"\bpro-code\b",
    r"\blow-code\b",
    r"\bHKUDS\b",
    # Agents belonging to solutions that are not part of the product.
    # Alex (project_lead) and Quinn (queryngine) ARE shipped and documented,
    # so they are allowed. `Jarvis` is BANNED: it is the assistant's retired
    # name — the slug is `cora` and the display name is the Core Assistant.
    # A page that still says Jarvis sends a reader looking for an agent their
    # workspace does not contain, which reads as a broken install.
    r"\bIris\b|\bDana\b|\bNova\b|\bSam\b|\bChris\b|\bJames\b|\bJarvis\b",
]
COUNTED = [r"IOF_[A-Z_]+", r"\biof-[a-z-]+", r"\.iobot\b"]

# Confidential material that must never appear.
CONFIDENTIAL = [
    r"\bJ&J\b", r"\bjnj\b", r"\bJohnson\b", r"\bTREMFYA\b", r"\bCaplyta\b",
    r"\bvantive\b", r"\bsavant\b", r"\bminimax\b", r"\bMiniMax\b",
    r"\bhardening backlog\b", r"\bPLATFORM_HARDENING\b",
]

fence = re.compile(r"```.*?```", re.S)
span = re.compile(r"`[^`\n]+`")


def strip_code(text):
    """Blank out fenced blocks and code spans, preserving line count."""
    def blank(m):
        return re.sub(r"[^\n]", " ", m.group(0))
    return span.sub(blank, fence.sub(blank, text))


def heading_slugs(text: str) -> set:
    """Every anchor Docusaurus generates for *text*, plus explicit ids.

    THE CHECK THAT WAS MISSING. The link rule below split a target on "#"
    and validated only the FILE, so `page.md#no-such-heading` passed here
    and then failed the Docusaurus build with "broken anchors" - exactly the
    class of error this script exists to catch first. Found by a real build
    warning naming an anchor that had never existed on the target page.

    Docusaurus slugifies a heading by lowercasing it, dropping anything that
    is not a letter, digit, space or hyphen, and joining words with hyphens.
    An explicit `{#custom-id}` suffix overrides that.
    """
    slugs = set()
    for line in strip_code(text).splitlines():
        m = re.match(r"^(#{1,6})\s+(.*?)\s*$", line)
        if not m:
            continue
        title = m.group(2)
        explicit = re.search(r"\{#([A-Za-z0-9_-]+)\}\s*$", title)
        if explicit:
            slugs.add(explicit.group(1).lower())
            title = title[:explicit.start()].strip()
        title = title.replace("`", "")
        slug = re.sub(r"[^a-z0-9\s-]", "", title.lower()).strip()
        slug = re.sub(r"\s+", "-", slug)
        if slug:
            slugs.add(slug)
    return slugs


def scan():
    # Files prefixed with "_" are excluded from Docusaurus routing and are not
    # published. _README.md names the banned terms in order to prohibit them.
    pages = sorted(p for p in ROOT.rglob("*.md") if not p.name.startswith("_"))
    findings = {"naming": [], "confidential": [], "links": [], "mdx": [],
                "docusaurus": []}
    counted = {}

    for page in pages:
        rel = page.relative_to(ROOT).as_posix()
        raw_bytes = page.read_bytes()
        raw = page.read_text(encoding="utf-8", errors="replace")
        prose = strip_code(raw)
        own_slugs = heading_slugs(raw)

        # 0. Docusaurus display-compatibility — a page that will not render is
        #    worse than a stylistic slip. BOM breaks frontmatter parsing; a
        #    missing title/frontmatter breaks the sidebar; an odd number of
        #    code fences leaks raw markup into the page; an unbalanced
        #    admonition renders the ::: literally.
        if raw_bytes.startswith(b"\xef\xbb\xbf"):
            findings["docusaurus"].append(f"{rel}:1  BOM at file start (breaks frontmatter)")
        if not raw.lstrip("﻿").startswith("---"):
            findings["docusaurus"].append(f"{rel}:1  no frontmatter block")
        else:
            fm = raw.lstrip("﻿").split("---", 2)
            if len(fm) < 3:
                findings["docusaurus"].append(f"{rel}:1  frontmatter not closed")
            elif "title:" not in fm[1]:
                findings["docusaurus"].append(f"{rel}:1  frontmatter missing title:")
            else:
                # PARSE IT AS YAML, don't just look for keys. An unquoted
                # scalar containing ": " is a MAPPING, not a string — so a
                # description like `The structure of a skill: its directory`
                # fails to parse and Docusaurus fails the whole build. This
                # scan reported that page clean for weeks because every other
                # check reads the frontmatter as text. Any value that comes
                # back as a dict or list is the same mistake wearing a
                # different key.
                try:
                    import yaml as _yaml
                    meta = _yaml.safe_load(fm[1])
                    if not isinstance(meta, dict):
                        findings["docusaurus"].append(
                            f"{rel}:1  frontmatter does not parse as a mapping")
                    else:
                        for k, v in meta.items():
                            if isinstance(v, (dict, list)):
                                findings["docusaurus"].append(
                                    f"{rel}:1  frontmatter `{k}:` parsed as "
                                    f"{type(v).__name__}, not text — quote the "
                                    f'value (a bare ": " makes it a mapping)')
                except ImportError:      # pragma: no cover - yaml always present
                    pass
                except Exception as exc:
                    findings["docusaurus"].append(
                        f"{rel}:1  frontmatter is not valid YAML, so the build "
                        f"fails: {str(exc).splitlines()[0]}")
        if raw.count("```") % 2 != 0:
            findings["docusaurus"].append(f"{rel}  odd number of ``` fences (unclosed code block)")
        opens = len(re.findall(r"^:::[a-z]", raw, re.M))
        closes = len(re.findall(r"^:::\s*$", raw, re.M))
        if opens != closes:
            findings["docusaurus"].append(
                f"{rel}  unbalanced admonition (:::) — {opens} open, {closes} close")

        # 1. naming — banned names anywhere, including inside code
        for pat in BANNED:
            for m in re.finditer(pat, raw, re.I):
                line = raw[: m.start()].count("\n") + 1
                findings["naming"].append(f"{rel}:{line}  {m.group(0)}")

        for pat in CONFIDENTIAL:
            for m in re.finditer(pat, raw):
                line = raw[: m.start()].count("\n") + 1
                findings["confidential"].append(f"{rel}:{line}  {m.group(0)}")

        for pat in COUNTED:
            for m in re.finditer(pat, raw):
                counted.setdefault(m.group(0), []).append(rel)

        # 2. links — every relative target resolves inside ROOT
        for m in re.finditer(r"\[[^\]]*\]\(([^)]+)\)", raw):
            whole = m.group(1).strip()
            target, _, anchor = whole.partition("#")
            target = target.strip()
            anchor = anchor.strip().lower()
            line = raw[: m.start()].count("\n") + 1
            if not target or whole.startswith(("http://", "https://", "mailto:", "#")):
                if whole.startswith(("http://", "https://")):
                    findings["links"].append(f"{rel}:{line}  external: {whole}")
                elif whole.startswith("#") and anchor and anchor not in own_slugs:
                    findings["links"].append(
                        f"{rel}:{line}  broken anchor on this page: #{anchor}")
                continue
            dest = (page.parent / target).resolve()
            try:
                dest.relative_to(ROOT)
            except ValueError:
                findings["links"].append(f"{rel}:{line}  escapes folder: {target}")
                continue
            if not dest.exists() and not dest.with_suffix(".md").exists():
                findings["links"].append(f"{rel}:{line}  broken: {target}")
                continue
            if anchor:
                # THE FILE EXISTING IS NOT THE LINK WORKING. An anchor naming
                # no heading is a dead link to a reader and a build warning
                # to Docusaurus.
                page_file = dest if dest.suffix == ".md" else dest.with_suffix(".md")
                if page_file.is_file():
                    slugs = heading_slugs(page_file.read_text(
                        encoding="utf-8", errors="replace"))
                    if anchor not in slugs:
                        findings["links"].append(
                            f"{rel}:{line}  broken anchor: {target}#{anchor} "
                            f"- that page has no such heading")

        # 3. MDX safety — bare <...> or {{...}} outside code
        body = prose.split("---", 2)[-1] if prose.startswith("---") else prose
        offset = len(prose) - len(body)
        for m in re.finditer(r"<[A-Za-z_][A-Za-z0-9_.-]*>|\{\{[^}]+\}\}", body):
            line = prose[: offset + m.start()].count("\n") + 1
            findings["mdx"].append(f"{rel}:{line}  {m.group(0)}")

    return pages, findings, counted


pages, findings, counted = scan()
print(f"scanned {len(pages)} pages under {ROOT.name}\n")

failed = False
for name, items in findings.items():
    label = {"naming": "1. NAMING", "confidential": "1b. CONFIDENTIAL",
             "links": "2. LINK INTEGRITY", "mdx": "3. MDX SAFETY",
             "docusaurus": "4. DOCUSAURUS DISPLAY"}[name]
    if items:
        failed = True
        print(f"{label}: {len(items)} finding(s)")
        for i in items[:40]:
            print(f"   {i}")
        if len(items) > 40:
            print(f"   ... and {len(items) - 40} more")
    else:
        print(f"{label}: clean")
    print()

print("Opaque identifiers in use (allowed, but keep deliberate):")
for token, where in sorted(counted.items(), key=lambda kv: -len(kv[1])):
    print(f"   {token:32} {len(where):3}x  {len(set(where))} page(s)")

sys.exit(1 if failed else 0)
