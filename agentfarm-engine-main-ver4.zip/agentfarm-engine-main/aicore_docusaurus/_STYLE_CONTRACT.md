# Style contract — every page in this folder holds to this

Audience: **enterprise engineering teams who build solutions on AI Core Harness.** Not
the team that builds AI Core Harness itself. A reader must be able to design, build,
run, improve and operate a solution without ever learning how the platform is
implemented internally.

## 1. Register — world-class enterprise product documentation

Direct, declarative, precise. State behaviour, procedure and consequence.

- No casual or friendly tone. No `let's`, `you'll`, `we'll`, `simply`, `just`,
  `easy`, `great`, `note that`, exclamation marks, or rhetorical questions.
- No first-person plural ("we decided", "our approach"). The product is the
  subject, or the reader is ("Declare the server", "The run records each step").
- No war stories, no history, no rationale-for-us. State the rule and its
  consequence for the reader.
- Every constraint states what happens when it is not met.

Correct: *"A step that declares no `requires_artifacts` cannot fail closed; the
run continues with an empty deliverable."*
Wrong: *"We learned the hard way that skipping the gate bites you later."*

## 2. Audience boundary — never leak internals

Never appears: platform source paths, module/class/function names, the name of
the underlying agent runtime, internal mechanisms, defect history, backlogs,
test infrastructure, or any indication the product/CLI/runtime ever had a
different name.

- Call the runtime **"the agent runtime"**, never its library name.
- Call the per-user state directory **"the AI Core Harness home directory"** in prose.
  Show the literal `~/.iobot` / `%USERPROFILE%\.iobot` path ONLY where a reader
  must locate or edit a specific file, and only in a code block or inline code.
  Never explain where the name comes from.
- `IOF_*` env vars and `iof-*` tools are real strings a reader types — keep
  them, but do not gloss them as "internal".

## 3. Product naming

| Use | Never |
|---|---|
| AI Core Harness | any prior product name, "AI Core Harness" |
| `aicore` (the CLI) | any prior CLI name |
| AI Core Harness Studio | any prior UI name |
| the agent runtime | the runtime library's name |

## 4. Self-contained (drops into a client's Docusaurus as a subfolder)

- Every markdown link is **relative** and resolves to a file inside this
  folder. No absolute (`/`-rooted) links, no `../` above the folder root, no
  external `http(s)://` links — not even to a protocol spec. Name the standard
  in plain text instead.
- Cross-section links use the CURRENT numbering:
  `../06-core-assistant/`, `../07-reference/`, `../08-troubleshooting/`.

## 5. MDX safety

Docusaurus compiles `.md` as MDX. Every `<placeholder>` and `{{variable}}` in
prose must sit inside a code span or fenced block, or the build fails.

## 6. Commands are real

Every `aicore` command and flag shown must exist and match live `--help`
output. Do not invent flags. Verify before writing.

## 7. Page shape

Frontmatter on every page: `sidebar_position`, `title`, `description` (one
sentence stating what the page is). Open with a one-paragraph statement of what
the page covers. Close with a `**Next:**` link and a short `## Related pages`
list where useful. `_`-prefixed files (this one) are excluded from the site.
