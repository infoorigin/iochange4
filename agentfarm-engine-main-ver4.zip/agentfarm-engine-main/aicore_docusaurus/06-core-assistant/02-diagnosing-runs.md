---
sidebar_position: 2
title: Diagnosing runs
description: Ask the Core Assistant what happened in a run, why a step failed, and what to change. Includes the evidence the Core Assistant draws on and the commands that produce the same material directly.
---

# Diagnosing runs

Diagnosis is the most common use of the Core Assistant. Rather than reading execution
records yourself, state the question and the Core Assistant returns a verdict supported by
the specific evidence behind it.

## Asking

Include the run identifier. Anything phrased as a question about the run is
understood.

```text
What happened in run_20260416_141904_011042?
Why did the compose step fail?
Is that run stuck, or is it still working?
The deliverable is thin - which step is responsible?
Show me what the analyst agent actually did in attempt 2.
```

The Core Assistant answers with the conclusion first, then the evidence. A typical
response identifies the outcome, names the step and attempt where the
determining event occurred, quotes the relevant record, and states what to
change.

## What the Core Assistant can establish

| Question | What the answer contains |
|---|---|
| How did the run end? | Final state, the step that determined it, and the elapsed time |
| Why did a step fail? | The failure as recorded, the attempt it first appeared on, and whether later attempts repeated or changed it |
| Was the failure retried? | Attempt count, what changed between attempts, and whether the retry budget was exhausted |
| Did the artifact gate hold? | Which declared artifacts were produced, which were missing or empty, and which step is responsible |
| Is the run progressing? | Whether it is running, waiting, recovering from a transient condition, or genuinely stalled |
| What did the agent do? | The sequence of reasoning and tool calls for a given step and attempt |
| Where do I look next? | The specific step, attempt and record to examine, or the specific definition change to make |
| What happened inside a swarm? | Which roster members the meta-agent called, in what order, what each returned, and how the budget was consumed |

## Distinguishing a stalled run from a working one

A run that appears to be doing nothing is usually recovering. AI Core Harness absorbs
transient conditions automatically, and recovery involves waiting: a step is
re-attempted, or the platform waits for an in-flight step to report.

Ask directly:

```text
Is run_20260416_141904_011042 stuck?
```

The Core Assistant distinguishes three cases and says which applies:

- **Progressing.** A step is executing. No action.
- **Recovering.** The platform is re-attempting a step within its retry budget.
  No action. Intervening here discards the recovery in progress.
- **Stalled.** No step is executing and none can start. The Core Assistant
  names the blocking condition and the corrective action.

## Diagnosing without the assistant

The same evidence is available two other ways, so a diagnosis never depends on
the assistant being reachable.

**In AI Core Harness Studio.** Open **Runs**, select the run, and open its **Explain**
view. It presents the same verdict, the step table, the forensic timeline and
the artifact gate result as a screen rather than an answer.

**From the command line.** These commands produce the material the Core
Assistant reports on, and are the route to use when scripting.

```bash
aicore forensics explain <run_id>              # postmortem verdict for the run
aicore forensics show <run_id>                 # event timeline
aicore forensics show <run_id> --step compose --attempt 2
aicore forensics narrative <run_id> compose.2  # the agent's dialog for one attempt
aicore forensics stats <run_id> --pretty       # per-step counts and durations
aicore forensics list --failed -n 20           # recent failed runs
aicore forensics tail <run_id>                 # follow a live run
aicore status --run-id <run_id>                # step states
```

`explain`, `show`, `list` and `tokens` accept `--json` for machine-readable
output; `stats` emits machine-readable output unless `--pretty` is given.

## From diagnosis to correction

Where a failure has a definition-level cause, the Core Assistant states the change rather
than only the symptom. Common corrections it identifies:

| Observed | Correction |
|---|---|
| A step produced a deliverable that a later step could not use | Declare the file in `requires_artifacts` on the producing step so the gate holds |
| An agent did not have a capability the step required | Add the skill to the step's `skills` list, or remove the list so the agent's full assignment loads |
| A step exhausted its attempts on the same failure | Address the cause; raising `max_attempts` repeats the failure at greater cost |
| A swarm ended without a deliverable | Raise `budget.tool_calls`, or narrow the goal so the roster can complete it within the ceiling |
| A swarm called the wrong roster member | Improve the `description`, `tags` and `examples` on the roster entries, which are what routing matches against |

Definition changes are covered in
[Design and authoring assistance](./05-design-and-authoring.md).

## Related pages

- [Cost and usage](./03-cost-and-usage.md)
- [Reviewing output quality](./04-reviewing-output-quality.md)
- [Common failures](../08-troubleshooting/01-common-failures.md)
- [CLI reference](../07-reference/01-cli.md)

**Next:** [Cost and usage](./03-cost-and-usage.md).
