---
sidebar_position: 3
title: Cost and usage
description: Ask the Core Assistant what a run consumed, where the consumption occurred, and how two runs compare. Includes how token figures are counted and what is required before a currency amount can be reported.
---

# Cost and usage

Every run records what it consumed. The Core Assistant reports that record,
attributes it to the steps and attempts that produced it, and compares runs.

## Asking

```text
How many tokens did run_20260416_141904_011042 use?
Which step was the most expensive?
What did that run cost?
Why is this run twice the size of yesterday's?
Is caching working on the analysis step?
```

## How consumption is counted

Two figures are recorded for every model call, and their meaning determines
every total derived from them.

| Figure | Contains |
|---|---|
| Input | All tokens sent to the model, **inclusive** of tokens read from cache and tokens written to cache |
| Output | All tokens produced by the model |

The total consumption of a run is input plus output. Cached tokens are already
counted inside the input figure and must not be added again; doing so
overstates a run by the size of its cache traffic, which on a long run is the
majority of it.

Cache behaviour is reported separately so that efficiency can be assessed:
cache reads are input tokens served from cache, and cache writes are input
tokens stored for later reuse. A step that reads a large proportion of its
input from cache is operating efficiently. A step that writes repeatedly and
reads little is not reusing context between attempts.

## What the Core Assistant reports

| Question | What the answer contains |
|---|---|
| What did the run consume? | Input, output and total tokens, and the number of model calls |
| Where did it go? | The same figures broken down per step and per attempt |
| What is the most expensive part? | The steps ranked by consumption, with the share each represents |
| Is caching effective? | Cache read and write volume per step, and the proportion of input served from cache |
| Why is this run larger than that one? | A comparison naming the steps whose consumption differs and by how much |
| What did it cost? | A currency amount, provided a rate card is available - see below |

## Currency amounts require a rate card

The platform records token counts. It does not record prices, because prices
depend on the model, the contract and the region under which your deployment
operates.

The Core Assistant reports a currency amount only when the applicable rates are supplied
to it, and it states which rates it used. Supply them in the question, or ask
your administrator to make the rate card available to the assistant:

```text
Our rate is 0.30 per million input tokens and 1.20 per million output.
What did run_20260416_141904_011042 cost?
```

Where no rate card is available, the Core Assistant reports token counts and states that a
cost figure cannot be produced. It does not substitute published list prices
for your contracted rates.

## Reading consumption directly

```bash
aicore forensics tokens <run_id>            # per-step and total consumption
aicore forensics tokens <run_id> --json     # machine-readable
aicore forensics stats <run_id> --pretty    # counts and durations per step
```

## Controlling consumption

Consumption is a property of the definition, not of the platform. The
following changes reduce it:

- **Bound swarms with `budget.tool_calls`.** A swarm without a ceiling explores
  until it reaches a deliverable or fails. The ceiling is enforced and is the
  primary control on swarm consumption.
- **Name only the skills a step needs.** A role's `skills` list is the exact
  set loaded for that step. Omitting the list loads the agent's full
  assignment, which enlarges every prompt in that step.
- **Set `max_attempts` deliberately.** Each attempt is a full re-execution.
  A step whose failure is deterministic consumes its entire attempt budget
  producing the same failure.
- **Keep step deliverables scoped.** A step that reads a large corpus into
  context on every attempt is more expensive than one that reads it once and
  writes a summary a later step consumes.
- **Prefer a command-line tool where the work is deterministic.** Work that can
  be computed rather than reasoned about consumes no tokens at all. See
  [Command-line tools](../03-building-solutions/02-command-line-tools.md).

## Related pages

- [Diagnosing runs](./02-diagnosing-runs.md)
- [Design and authoring assistance](./05-design-and-authoring.md)
- [Swarm definition reference](../07-reference/03-swarm-yaml.md)

**Next:** [Reviewing output quality](./04-reviewing-output-quality.md).
