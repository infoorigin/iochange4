---
sidebar_position: 4
title: Reviewing output quality
description: Ask the Core Assistant whether a run's deliverable is supported by the evidence that run gathered. Covers the checks applied, the verdicts returned, and the boundary of what a review can establish.
---

# Reviewing output quality

A run can complete successfully and still produce a deliverable that should
not be relied upon. Completion establishes that every step reported success
and every declared artifact was produced. It does not establish that the
conclusions in those artifacts follow from the evidence.

The Core Assistant reviews a deliverable against the evidence the run itself gathered and
returns a verdict.

## Asking

```text
Review the deliverable from run_20260416_141904_011042.
Can I rely on the analysis in that run?
Is the market-share figure in that report supported?
Did the run answer the question I actually asked?
```

## The boundary of a review

**The evidence set is the run under review, and only that run.** The Core
Assistant compares the deliverable against what that run retrieved, computed
and recorded. It does not validate the deliverable against external sources,
industry knowledge or its own judgement of the subject matter.

This boundary is what makes the verdict dependable. A finding of *unsupported*
means the run's own record does not contain the basis for a claim. It does not
mean the claim is false, and a finding of *supported* does not mean the
underlying data is correct - only that the deliverable represents that data
faithfully.

## Checks applied

Five checks are applied to every review.

| Check | Question |
|---|---|
| Traceability | Does every figure, name and date in the deliverable trace to something the run retrieved? |
| Evidence coverage | Was the evidence the run gathered used, or was a material part of it collected and then ignored? |
| Internal consistency | Do figures agree across sections, and do the totals reconcile with their components? |
| Treatment of gaps | Where data was unavailable, is that stated, or has the gap been filled with an assumption presented as a finding? |
| Goal coverage | Does the deliverable answer the goal the run was given, in full? |

Two further checks apply judgement rather than verification, and are reported
separately because they identify weakness rather than error.

| Check | Question |
|---|---|
| Unexamined obvious explanation | Is there a straightforward explanation of the finding that the run neither adopted nor ruled out? |
| Unresolved conflict | Did the run gather evidence that points in two directions, and reach a conclusion without reconciling it? |

## What a review returns

A review returns an overall verdict, then each finding with the location in
the deliverable and the corresponding evidence, or the absence of it.

| Verdict | Meaning | Action |
|---|---|---|
| Supported | Every claim traces to run evidence, and the checks pass | The deliverable may be relied upon within the boundary above |
| Qualified | The substance is supported; specific claims are weak or unreconciled | Address the named claims, or state the qualification when the deliverable is used |
| Unsupported | Material claims have no basis in the run's evidence | Do not rely on the deliverable; correct the definition and re-run |

## Acting on a review

Findings usually indicate a definition change rather than a one-off
correction, because the same definition will produce the same weakness on
every run.

| Finding | Change |
|---|---|
| Figures that trace to nothing | Require the producing step to record its retrieval alongside its conclusion, and gate the record with `requires_artifacts` |
| Evidence gathered and unused | Split the step: one step gathers, a second consumes the gathered artifact, with the dependency declared |
| Gaps filled with assumptions | State in the step prompt that unavailable data is to be reported as unavailable |
| Goal only partly answered | The goal covers more than the step chain does; add the missing step, or narrow the goal |
| Inconsistent totals | Compute the totals in a command-line tool rather than in a prompt, so the arithmetic is deterministic |

## Related pages

- [Diagnosing runs](./02-diagnosing-runs.md)
- [Design and authoring assistance](./05-design-and-authoring.md)
- [Workflow definition reference](../07-reference/02-workflow-yaml.md)

**Next:** [Design and authoring assistance](./05-design-and-authoring.md).
