---
sidebar_position: 5
title: Design and authoring assistance
description: Ask the Core Assistant which building block fits a requirement, how to structure a solution, and for complete definition files to place in your repository.
---

# Design and authoring assistance

The Core Assistant assists with the design of solutions and produces the definition files
that implement them. Two kinds of question are handled: which building block
fits a requirement, and what the definition for it should contain.

## Asking

```text
I need to summarise support tickets every morning and post the result. What should I build?
Should this be a workflow or a swarm?
Write me a workflow that pulls yesterday's orders, checks them against contract terms, and reports exceptions.
Review my swarm definition - is the budget realistic?
This step keeps producing inconsistent numbers. How should it be structured?
```

## Which building block

The choice between the four building blocks follows from the nature of the
work, not from its size.

| The work is | Build | Because |
|---|---|---|
| Deterministic - the same input always yields the same correct output | A command-line tool | A computation must be computed. Reasoning about it produces answers that are plausible and occasionally wrong, with nothing to distinguish the two. |
| A fixed sequence of stages, known before the run starts | A workflow | The route is part of the design, so it belongs in the definition where it can be gated, retried and audited per step. |
| Goal-directed, where the route depends on what is found | A swarm | The route cannot be written in advance. A meta-agent selects from a roster at runtime under an enforced budget. |
| Judgement an agent applies - how to assess, what to prioritise, what good looks like | A skill | Judgement is instruction, not code. It is authored once and assigned to the agents that need it. |

The Core Assistant applies these rules to the requirement as described and states which
block it selected and why. Where a requirement spans more than one - most do -
it decomposes: the deterministic parts become tools, the fixed sequence
becomes a workflow, and the judgement each step applies becomes skills.

## Authoring

The Core Assistant produces complete definition files, not fragments. A workflow request
returns the `workflow.yaml`, the role prompt for each role, and the step
prompt for each step, with dependencies and artifact gates already declared.
A swarm request returns the `swarm.yaml` with the roster and budget set.

Three conditions apply to anything the Core Assistant authors.

- **It is content for you to place.** The Core Assistant does not write into your
  repository. Create the definition with the scaffold command, then replace
  the generated content with what the Core Assistant produced.
- **Lint before running.** A definition file is read permissively: an
  unrecognised key is not rejected, it is never read. A misspelled
  `requires_artifacts` loads cleanly and silently disables the artifact gate.
  Lint reports unknown keys with the intended spelling.
- **Names must match placement.** A definition's `name` must equal its
  directory name, and role names referenced by steps must be declared.

```bash
aicore new-workflow order-exceptions --role analyst --steps pull:analyst,check:analyst,report:analyst
# replace the generated files with the authored content
aicore lint-workflow order-exceptions --strict
aicore run order-exceptions --goal "Report yesterday's contract exceptions" --dry-run
```

The equivalent for a swarm:

```bash
aicore new-swarm pricing-review --role meta
aicore lint-swarm --name pricing-review --strict
aicore run-swarm pricing-review --goal "Review competitor pricing changes this week" --dry-run
```

`--dry-run` validates the definition and prints the plan without executing it.

## Improving an existing definition

Provide the definition and the run that exposed the problem. The Core
Assistant reviews the definition against the recorded behaviour and returns
specific changes.

```text
Here is my workflow. Run run_20260416_141904_011042 produced an empty report.
What is wrong with the definition?
```

Reviews commonly return the following.

| Observation | Change |
|---|---|
| A step's output is consumed by a later step but not gated | Declare it in `requires_artifacts` so the step fails closed rather than passing an empty file forward |
| A `skills` list omits a capability the step requires | Add the skill, or remove the list so the agent's full assignment loads |
| A swarm ends without a deliverable | Raise `budget.tool_calls`, or narrow the goal to what the roster can complete within the ceiling |
| Roster entries carry no description, tags or examples | Add them; routing decisions match against exactly these fields |
| Arithmetic is performed in a prompt | Move it to a command-line tool and have the step call the tool |
| Steps declare no dependencies | Declare `deps`; without them the ordering is not part of the definition |

## Related pages

- [Reviewing output quality](./04-reviewing-output-quality.md)
- [Workflow definition reference](../07-reference/02-workflow-yaml.md)
- [Swarm definition reference](../07-reference/03-swarm-yaml.md)
- [Skill format](../07-reference/04-skill-format.md)

**Next:** [CLI reference](../07-reference/01-cli.md).
