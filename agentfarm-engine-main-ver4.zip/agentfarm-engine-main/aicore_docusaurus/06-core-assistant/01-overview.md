---
sidebar_position: 1
title: Overview
description: The Core Assistant is built into AI Core Harness. It answers questions about your solutions and their runs from recorded execution evidence, and assists with the design and authoring of solution content.
---

# The Core Assistant

The Core Assistant is included with AI Core Harness. It answers questions about
solutions and the runs they produce, and it assists with designing and
authoring solution content.

Its role slug is `cora` — the name to use where a command or a definition
needs the role, such as `--role cora` or a swarm roster.

Its defining characteristic is that answers are derived from recorded
execution evidence rather than from recollection. Every figure, cause and
verdict the Core Assistant reports is taken from the execution record of the run in
question. Where the record does not contain an answer, the Core Assistant states that
rather than inferring one.

This section uses the terms *run*, *step* and *deliverable* throughout. They
are defined in
[Core concepts](../01-introduction/02-core-concepts.md#run-step-and-deliverable).

## What the Core Assistant is for

| Area | Questions it answers |
|---|---|
| Diagnosis | What happened in a run, why a step failed, whether a run is stuck, what an agent actually did |
| Consumption | How many tokens a run used, what it cost, how efficiently it used caching, how two runs compare |
| Output quality | Whether a deliverable is supported by the evidence the run gathered, and whether the reasoning holds |
| Design and authoring | How to structure a workflow or swarm, how to improve an existing definition, and complete definition files ready to place |
| Documentation | How to perform a task in AI Core Harness, what a term means, and which page covers it |

The first four areas have a page each in this section.

Documentation questions need no page of their own: ask in ordinary language —
*"how do I declare an MCP server?"*, *"what does the artifact gate do?"* — and
the answer cites the page it came from. The Core Assistant reads the
documentation at the time of asking rather than reciting it, so its answers
match the documentation set your deployment carries.

## Addressing the Core Assistant

The Core Assistant is available wherever your deployment exposes the assistant: the
AI Core Harness Studio chat surface, the platform web API, and any messaging channel
your administrator has connected. No special syntax is required. State the
question in ordinary language and include the run identifier when the
question concerns a specific run. From the command line, address it directly:

```bash
aicore agent-chat --role cora --message "What went wrong with run_20260416_141904_011042?"
```

```text
What went wrong with run_20260416_141904_011042?
How many tokens did that run use, and what did it cost?
Review the analysis in that run - can I rely on it?
Write me a swarm that reviews competitor pricing weekly.
```

When no run is named, the Core Assistant resolves the most recent matching run and
states which one it used. If the reference is ambiguous, it asks rather
than guessing.

## What the Core Assistant will not do

- **It does not modify your solutions.** Design and authoring answers are
  delivered as content for you to place with the documented commands. The
  Core Assistant does not write into your repository.
- **It does not act on a run without being asked.** Retries, skips and other
  interventions are performed on your instruction, and the Core Assistant confirms what
  it requested.
- **It does not estimate.** A number that was not recorded is reported as
  unavailable.
- **It does not explain what the record cannot show.** Execution evidence
  captures what occurred within the platform. It does not capture why an
  external system was slow or unavailable, and the Core Assistant distinguishes the two.

## Related pages

- [Diagnosing runs](./02-diagnosing-runs.md)
- [Cost and usage](./03-cost-and-usage.md)
- [Reviewing output quality](./04-reviewing-output-quality.md)
- [Design and authoring assistance](./05-design-and-authoring.md)

**Next:** [Diagnosing runs](./02-diagnosing-runs.md).
