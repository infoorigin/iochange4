"""`ioagentfarm workspace` — the tenant/solution-repo bridge CLI.

The ONLY surface where git and the platform DB meet (in the product the DB
is authoritative and git never appears). See workspace_sync.py for the
contract, including the nothing-erases guarantee.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

workspace_app = typer.Typer(no_args_is_help=True,
                            help="Tenant workspaces + solution-repo push/pull")
console = Console()

_ACTION_STYLE = {
    "added": "green",
    "updated": "cyan",
    "unchanged": "dim",
    "reconciled": "green",
    "diverged": "red",
    "diverged-local": "yellow",
    "studio-owned": "magenta",
    "orphaned": "yellow",
}


def _prog() -> str:
    """The command name this CLI was invoked as, so hints are copy-pasteable."""
    from ioagentfarm.cli_scaffold import _prog as _p
    return _p()


def _adopt_local(code: str) -> None:
    """Carry the directory's local mode into *code*'s own settings.

    `aicore local on` runs BEFORE any workspace exists -- that is the whole
    point of it, since it decides whether the workspace created next is local
    -- so it records the switch against the directory. This is the moment the
    workspace becomes real, and therefore the moment its own `.env` should
    record the mode: that file is what `aicore current` reports and what a pod
    reads.
    """
    from ioagentfarm.engine import workspace_env as _we
    try:
        if _we.adopt_directory_local(code):
            console.print("[dim]local mode carried into this workspace's "
                          "settings[/dim]")
    except OSError:                            # pragma: no cover - defensive
        pass


def _activate(code: str) -> None:
    """Apply *code*'s own settings before anything reads a database.

    THESE COMMANDS TAKE THE WORKSPACE POSITIONALLY, and that is exactly how
    they came to skip this. `run`, `setup-agents` and `list-workflows` receive
    it as `--workspace` and go through the CLI's activation path; `workspace
    show|diff|push|pull|delete|attach` take it as an argument and went
    straight to `_store()`, which reads the AMBIENT `IOF_DATABASE_URL`.

    So `aicore current --workspace acme` reported the database from
    `~/.iobot/workspaces/acme/.env`, and `aicore workspace push acme` then
    published to a different one -- with no error, because both are valid
    databases. Point a workspace at PostgreSQL, confirm it with the command
    the docs tell you to trust, push, and the rows land somewhere else.

    Idempotent, and safe before the workspace exists: a missing settings file
    is a no-op, which is what `create` needs.
    """
    from ioagentfarm.engine import workspace_env as _we

    _we.load_workspace_env(code)
    # Local mode is stored in that same file, so it can only be honoured
    # after it has been read. Without this, `local on` followed by
    # `workspace push` published to the ambient database rather than the
    # local SQLite the mode promises.
    #
    # THE SHARED HELPER, not the condition written out again. This was the
    # only place in the CLI that paired "load the workspace's settings" with
    # "apply the mode they declare", and it was right - it just was not
    # reachable from the fifty other places that open a store. Now that the
    # pairing has a name, this calls it: two copies of a rule drift, and this
    # one would have kept its own idea of what counts as truthy.
    _we.adopt_if_declared(code)


def _confirm_if_shared(code: str, yes: bool) -> None:
    """Creating a tenant in a SHARED database is not a local experiment.

    In local mode this is free and reversible: the rows go to a SQLite file in
    the working directory. Against a team's PostgreSQL it is a tenant everyone
    can see, and the command gave no sign of the difference -- same output,
    same exit code, and the database named nowhere.

    So: local mode passes straight through, and anything else states the
    target and asks. `--yes` is the script answer; without a terminal the
    command REFUSES rather than assuming consent, because a CI job that meant
    to write to a shared database can say so.
    """
    from ioagentfarm.engine import workspace_env as _we

    if yes:
        return
    # KEYED ON THE DATABASE, NOT THE MODE FLAG -- and it now MEANS it. This
    # used to return early on a truthy `IOF_LOCAL`, one line above the
    # comment saying it does not do that, and the two disagree in the one
    # case that matters. Local mode does NOT repoint a url supplied by the
    # REAL environment (`workspace_env.localise`: "Values supplied by the
    # REAL environment are not replaced"), so `IOF_LOCAL=1` is not evidence
    # of a local TARGET: a workspace whose own `.env` records local mode,
    # opened in a shell exporting the production url, resolved to
    # production and skipped this prompt on the strength of the flag.
    # Reproduced - `_adopt_local()` set `IOF_LOCAL=1` from the workspace's
    # `.env`, the guard passed straight through, and the next call opened a
    # connection to the production host.
    #
    # Reading the url instead costs nothing in the ordinary case: genuine
    # local mode HAS repointed it at a SQLite file, so it passes through
    # here on the branch below and the local loop is never interrupted.
    #
    # A SQLite file is one developer's, whether or not local mode is
    # switched on, and prompting about it would teach people to hit `y`
    # without reading -- which is exactly how a guard stops working on the
    # day it matters. Only a server is shared, and that is the case worth
    # stopping for.
    # Adopted before the url is read, because this function DECIDES on it.
    # Its own reasoning below is "IOF_LOCAL=1 is not evidence of a local
    # TARGET - read the url instead"; that stays exactly right, and adoption
    # is what makes the url reflect a declared mode by the time it is read.
    _we.adopt_if_declared(code)
    url = (os.getenv("IOF_DATABASE_URL") or "").strip()
    if not url or url.startswith("sqlite:"):
        return
    from ioagentfarm.engine.db import describe_db_target

    target = describe_db_target(_root())
    console.print(f"[yellow]This creates the tenant '{code}' in a database "
                  "other people read:[/yellow]")
    console.print(f"  [bold]{target}[/bold]")
    console.print(f"  [dim]set by {_we.source_of('IOF_DATABASE_URL')}[/dim]")
    console.print(f"[dim]For a local experiment instead: `{_prog()} local on` "
                  "first, which keeps everything in this directory.[/dim]")
    if not sys.stdin.isatty():
        console.print("[red]Refusing without confirmation (no terminal). "
                      "Pass --yes if this is deliberate.[/red]")
        raise typer.Exit(code=1)
    if not typer.confirm(f"create '{code}' there?", default=False):
        raise typer.Abort()


def _code_re() -> str:
    """The EXISTING-code pattern, owned by ``engine.workspaces`` (one source).

    A function, not an import-time binding: ``rename`` checks the OLD code
    with it and that must keep accepting every shape a tenant was ever
    created with.
    """
    from ioagentfarm.engine.workspaces import WORKSPACE_CODE_RE
    return WORKSPACE_CODE_RE.pattern


def _check_code(code: str, *, what: str = "workspace code",
                new: bool = False) -> str:
    """Validate a user-supplied workspace code: shape, then retirement.

    A malformed code is refused rather than reinterpreted — a typo must never
    become a different workspace. ``new=True`` is for a code being CREATED
    (``create``, the target of ``rename``): it must also satisfy the package
    rule the scaffold applies to the same string, so a workspace cannot be
    created that ``new-workspace`` refuses one command later. The retired
    ``default`` is refused with the adoption path: it existed only as a
    silent fallback, and nothing may select, create or delete it as though
    it were a tenant.
    """
    from ioagentfarm.engine.workspaces import (RETIRED_WORKSPACE_CODES,
                                               workspace_code_problem)
    code = (code or "").strip().lower()
    problem = workspace_code_problem(code, new=new)
    if problem and code not in RETIRED_WORKSPACE_CODES:
        console.print(f"[red]invalid {what}[/red] - {problem}")
        raise typer.Exit(code=1)
    if code in RETIRED_WORKSPACE_CODES:
        console.print(
            "[red]the 'default' workspace is retired[/red] - it existed only "
            "as a silent fallback, which made it impossible to tell which "
            "workspace served which answer. Create a named workspace and "
            "adopt any existing data:")
        console.print(f"    {_prog()} workspace create <code>")
        console.print(f"    {_prog()} workspace rename default <code>")
        raise typer.Exit(code=1)
    return code


def _selector_root() -> Path:
    """Where the active-workspace pointer lives - see `workspace_env.selector_root`."""
    from ioagentfarm.engine import workspace_env as _we
    return _we.selector_root()


def _root() -> Path:
    """ONE implementation, in `cli`. Imported here rather than repeated.

    This was a byte-identical copy of `cli._root`, and so was
    `cli_forensics._root` — three copies of the line that decides where state
    lives. When local-mode adoption was added to the resolver, only one copy
    got it, and the other two kept answering from the un-adopted environment:
    every `workspace` and `forensics` command stayed pointed at the shared
    database while the operator had been told the workspace was local.

    Deferred import because `cli` imports this module at load.
    """
    from ioagentfarm.cli import _root as _cli_root

    return _cli_root()


def _store():
    from ioagentfarm.engine import workspace_env as _we
    from ioagentfarm.engine.db import make_adapter
    from ioagentfarm.engine.store import Store

    # Local mode, adopted before the URL is read — and it must be HERE rather
    # than relying on `_root()` below, because the `or` short-circuits: a set
    # IOF_DATABASE_URL (the shared database, from the workspace's own .env)
    # wins before `_root()` is ever called, so the resolver that does adopt
    # would never run. The same shape as `cli._store`; see
    # `workspace_env.adopt_if_declared`.
    _we.adopt_if_declared()
    # And say which database, once per process — see `cli.announce_target_once`.
    from ioagentfarm.cli import announce_target_once

    announce_target_once()
    url = (os.getenv("IOF_DATABASE_URL") or "").strip() \
        or f"sqlite:///{_root() / 'state.db'}"
    store = Store(make_adapter(url))
    store.init()
    return store


def _print_report(report: dict) -> None:
    console.print(f"[bold]workspace[/bold] {report.get('workspace')}"
                  + (f"  [dim]@ {report['sha'][:10]}[/dim]"
                     if report.get("sha") else ""))
    counts = report.get("counts") or {}
    if counts:
        summary = " - ".join(f"{v} {k}" for k, v in sorted(counts.items()))
        console.print(f"  {summary}")
    for item in report.get("items", []):
        style = _ACTION_STYLE.get(item["action"], "")
        console.print(f"  [{style}]{item['action']:>14}[/{style}]  "
                      f"{item['kind']}/{item['name']}")
    if report.get("refused"):
        console.print("[red]REFUSED - diverged items were edited in the "
                      "Studio since their last import:[/red]")
        for name in report["refused"]:
            console.print(f"  [red]! {name}[/red]")
        console.print(f"[yellow]{report.get('resolution', '')}[/yellow]")
    if report.get("backups"):
        console.print(f"[yellow]prior DB content of {report['backups']} "
                      f"snapshotted under {report.get('backup_dir')}[/yellow]")
    if report.get("scoped_to_pack"):
        console.print(f"[dim]workspace scoped to pack "
                      f"'{report['scoped_to_pack']}' - the Studio now lists "
                      "only this solution's agents and skills here[/dim]")
    if report.get("note"):
        console.print(f"[dim]{report['note']}[/dim]")


@workspace_app.command("list")
def list_workspaces():
    """All tenant workspaces + their repo binding."""
    from ioagentfarm import workspace_sync
    from ioagentfarm.engine.workspaces import RETIRED_WORKSPACE_CODES
    store = _store()
    rows = store.list_workspaces()
    # The platform tier's row is NOT a workspace: nothing can select it, and
    # listing it as one is how 'default' kept reading as a place you could
    # work. Its shared rows are re-populated by `sync`; adoption of old data
    # is `workspace rename default <code>`.
    hidden = [ws for ws in rows if ws["code"] in RETIRED_WORKSPACE_CODES]
    rows = [ws for ws in rows if ws["code"] not in RETIRED_WORKSPACE_CODES]
    table = Table(show_header=True, header_style="bold")
    for col in ("code", "name", "repo", "branch", "last import"):
        table.add_column(col)
    for ws in rows:
        repo = workspace_sync.get_repo(ws["code"]) or {}
        table.add_row(ws["code"], ws["name"], repo.get("repo_url", ""),
                      repo.get("branch", ""),
                      (repo.get("last_imported_at") or "")
                      + (f" @ {repo['last_sha'][:10]}"
                         if repo.get("last_sha") else ""))
    console.print(table)
    if hidden:
        console.print(
            "[dim]a retired 'default' row exists in this database (shared "
            f"platform rows live there). Adopt its tenant data with `{_prog()} "
            "workspace rename default <code>`.[/dim]")


def ensure_tenant_workspace(
    code: str, *, name: str = "", description: str = "",
    member: list[str] | None = None, no_member: bool = False,
    yes: bool = False, rename: bool = True,
) -> tuple[int, bool]:
    """Create-or-reuse tenant *code*: select it, seed its scope, grant access.

    THE ONE IMPLEMENTATION, and it has two callers on purpose.
    `workspace create` is the command; `new-workspace` calls it too, so
    scaffolding a workspace REPO and registering the TENANT it pairs with
    stopped being two commands a client has to know are related. They share
    one code by design, and nothing said so - which is how a build session
    reached for `new-workspace ps2` with `ps2` already created and selected.

    IDEMPOTENT, which is what makes the folded command safe to re-run: a
    second call finds the row, reports it, and changes nothing.

    *rename* is the display-name authority. `create` is documented as
    "create (or update)" and keeps it; a scaffold that was given no
    ``--title`` passes False, because a bare re-run must never rename a
    workspace somebody named in the Studio.

    Returns ``(workspace_id, existed_before)``.
    """
    code = _check_code(code, new=True)
    _activate(code)
    _adopt_local(code)
    from ioagentfarm import workspace_sync
    # ASKED BEFORE ANYTHING TOUCHES THE DATABASE, and the order is the whole
    # point. `_store()` calls `Store.init()`, which runs DDL - so asking
    # second would CREATE SCHEMA in the production database the user is
    # about to say "no" to. This guard is a pure environment check (the
    # url, the mode, the file that set them) and needs no connection, so
    # there is never a reason to open one first.
    #
    # It therefore also fires on a re-run against a shared database, before
    # we can know the row already exists. That is the right trade: the
    # alternative is a read - a connection - to avoid a question, and a
    # question is cheaper than an unwanted connection to somebody's
    # production instance. Local mode and any SQLite file pass through
    # silently, so the ordinary local loop is never interrupted.
    _confirm_if_shared(code, yes)
    store = _store()
    existed = store.get_workspace(code) is not None
    ws_id = store.ensure_workspace(
        code=code,
        name=name or code.replace("_", " ").title(),
        description=description, rename=rename and bool(name or not existed))
    if existed:
        console.print(f"[green]workspace '{code}' already exists "
                      f"(id={ws_id})[/green] [dim]- reused, nothing "
                      "recreated[/dim]")
    else:
        console.print(f"[green]workspace '{code}' ready (id={ws_id})[/green]")

    # NAME THE DATABASE. A workspace row is only real in ONE database, and
    # which one is decided by a resolution order the reader cannot see -
    # exported env, then the workspace's own `.env`, then a local SQLite.
    # Ordering mistakes are therefore SILENT: register the tenant first and
    # run `aicore local on` second, and `localise` repoints the URL that
    # came from a FILE, so the workspace just created stops being visible.
    # Reproduced exactly - `workspace list` came back EMPTY one command
    # after "workspace 'psrev' ready (id=2)", with nothing on screen
    # connecting the two. Printing the target is what makes that a fact the
    # reader already has rather than a mystery to debug.
    try:
        from ioagentfarm.engine import workspace_env as _we
        from ioagentfarm.engine.db import describe_db_target
        console.print(f"[dim]  registered in {describe_db_target(_root())}"
                      f" (set by {_we.source_of('IOF_DATABASE_URL')})[/dim]")
    except Exception:                       # noqa: BLE001 - never cost a row
        pass

    # CREATING A WORKSPACE SELECTS IT. Nobody creates a tenant in order to
    # keep working in a different one, and every command that followed had to
    # be told the code again -- so the ordinary path was a flag repeated on
    # each line, and forgetting it silently acted on `default`. Two separate
    # walkthroughs lost work to exactly that.
    #
    # This is the same pointer `workspace use` writes, so switching later is
    # `workspace use <other>` and nothing here is a special case.
    root = _selector_root()
    try:
        root.mkdir(parents=True, exist_ok=True)
        (root / "active_workspace").write_text(code, encoding="utf-8")
        console.print(f"[dim]active workspace: {code} - later commands use it "
                      f"with no flag (`aicore workspace use <other>` to "
                      "switch)[/dim]")
    except OSError as exc:                  # pragma: no cover - defensive
        console.print(f"[yellow]workspace created, but the active-workspace "
                      f"pointer could not be written ({exc}); pass "
                      f"--workspace {code} or run `aicore workspace use "
                      f"{code}`[/yellow]")

    # The Studio's create screen does this; the CLI did not, and the divergence
    # was invisible until you opened the workspace: no scoping row means
    # UNSCOPED, and unscoped means the Studio lists every installed solution's
    # agents in a tenant that has none of its own.
    workspace_sync.seed_empty_scope(code)

    emails = [e.strip().lower() for e in (member or []) if e.strip()]
    if not emails and not no_member:
        bootstrap = (os.getenv("IOF_BOOTSTRAP_ADMIN") or "").strip().lower()
        if bootstrap:
            emails = [bootstrap]

    granted: list[str] = []
    for email in emails:
        try:
            workspace_sync.add_workspace_member(code, email)
        except ValueError as exc:
            console.print(f"[red]{email}: {exc}[/red]")
            raise typer.Exit(code=1)
        granted.append(email)

    if granted:
        console.print("  access granted to " + ", ".join(granted))
        console.print("[dim]anyone else needs `aicore workspace create "
                      f"{code} --member <email>` or the Studio's "
                      "Administration -> Workspaces screen[/dim]")
    elif not existed:
        # Never silent. A workspace with no members is a legitimate thing to
        # create and an illegitimate thing to create by accident, and the two
        # are told apart by whether the operator sees this. Only on CREATE:
        # repeating it on every idempotent re-run would train the reader past
        # it, and a workspace that has been in use for a week is not the case
        # this warning is about.
        console.print("[yellow]  nobody can open this workspace yet - it has "
                      "no members[/yellow]")
        console.print(f"[dim]grant access with: aicore workspace create "
                      f"{code} --member you@yourcompany.com   "
                      "(or set IOF_BOOTSTRAP_ADMIN and re-run)[/dim]")
    return ws_id, existed


@workspace_app.command("create")
def create(code: str = typer.Argument(..., help="workspace code (lowercase)"),
           name: str = typer.Option("", help="display name"),
           description: str = typer.Option("", help="description"),
           member: list[str] = typer.Option(
               None, "--member", "-m",
               help="email to grant access to (repeatable). Defaults to "
                    "$IOF_BOOTSTRAP_ADMIN when that is set."),
           no_member: bool = typer.Option(
               False, "--no-member",
               help="create the registry row and grant nobody - an operator "
                    "shell for a tenant somebody else will be added to"),
           yes: bool = typer.Option(
               False, "--yes", "-y",
               help="Skip the confirmation shown when the target is a shared "
                    "database. Local mode never asks.")):
    """Create a tenant workspace and grant somebody access to it.

    ACCESS IS THE HALF THAT USED TO BE MISSING. Membership is CLOSED - no row,
    no access - so a registry row on its own is a workspace nobody can open,
    including the person who just made it. That is what this command produced
    until now, and the symptom was as far from the cause as it gets: the
    creation succeeded, and the NEXT call, listing workspaces, answered ``[]``.
    Empty. Not "you cannot see this one" - nothing at all, in a shape
    indistinguishable from a broken token or a failed import.

    So `create` now grants access by default, exactly as the Studio's own
    create screen does. `--no-member` keeps the old behaviour for the case
    that genuinely wants it (provisioning a tenant for someone else), and says
    what to run next rather than leaving a dead workspace behind.
    """
    # `create` is the caller that MEANS to set the display name - it is
    # documented as "create (or update)", so it keeps rename authority.
    ensure_tenant_workspace(code, name=name, description=description,
                            member=member, no_member=no_member, yes=yes,
                            rename=True)


@workspace_app.command("show")
def show(code: str = typer.Argument(..., help="workspace code"),
         as_json: bool = typer.Option(False, "--json",
                                      help="machine-readable, for scripts")):
    """What this workspace holds: workflows, agents, skills, who may open it.

    THE POINT IS WHAT IT DOES NOT NEED. No running server, no bearer token, no
    ``X-Workspace-Id`` header to forget. The getting-started walk used to
    verify an import with three authenticated ``curl`` calls, and every one of
    the ways that went wrong - an unset token, a dropped header, a shell that
    ate the password - looked like a failed import rather than a failed
    request. This reads the same database the Studio reads.

    It lists the TENANT's own content. The Studio shows these plus the
    platform-shared agents (Jarvis, Quinn, Alex) and the SDK's shared skills,
    which belong to every workspace and are nobody's import - so a shorter
    list here than on screen is expected, and the footer says so rather than
    leaving it to be discovered.
    """
    _activate(code)
    from ioagentfarm import workspace_sync
    data = workspace_sync.workspace_catalog(code)
    if not data:
        console.print(f"[red]workspace '{code}' does not exist[/red]")
        console.print("[dim]`aicore workspace list` shows the ones that "
                      "do[/dim]")
        raise typer.Exit(code=1)

    if as_json:
        # print(), not console.print_json(): rich syntax-highlights, and the
        # ANSI it emits makes the output unparseable the moment somebody pipes
        # it into jq — which is the only reason --json exists.
        import json as _json
        print(_json.dumps(data, indent=2))
        return

    console.print(f"[bold]{data['code']}[/bold]  {data.get('name') or ''}")
    if data.get("description"):
        console.print(f"[dim]{data['description']}[/dim]")

    # SCOPING FIRST, because it is the field that explains a list nobody
    # expected. A workspace with no settings row is UNSCOPED, and unscoped
    # means the Studio lists every installed pack's agents in it — which reads
    # as a broken import and is not one.
    if not data.get("scoped"):
        console.print("[yellow]  scope     UNSCOPED - the Studio will list "
                      "every installed solution's agents here. "
                      "`workspace attach` sets the scope from the repo's manifest.[/yellow]")
    elif data.get("scope"):
        console.print(f"  scope     {data['scope']}")
    else:
        console.print("[dim]  scope     none yet - an import will claim it"
                      "[/dim]")

    repo = data.get("repo") or {}
    if repo:
        console.print(f"  repo      {repo.get('repo_url')} "
                      f"({repo.get('branch')})"
                      + (f" @ {repo['last_sha'][:10]}"
                         if repo.get("last_sha") else ""))
    if data.get("runs"):
        console.print(f"  runs      {data['runs']}")

    members = data.get("members") or []
    if members:
        console.print("  access    " + ", ".join(
            f"{m['user_email']}" + (f" ({m['role']})" if m.get("role")
                                    and m["role"] != "member" else "")
            for m in members))
    else:
        console.print("[yellow]  access    nobody - this workspace has no "
                      "members, so it cannot be opened in the Studio[/yellow]")
        console.print(f"[dim]            fix: aicore workspace create "
                      f"{data['code']} --member you@yourcompany.com[/dim]")

    for label, values in (("workflows", data["workflows"]),
                          ("agents", data["agents"])):
        console.print(f"\n[bold]{label}[/bold] ({len(values)})")
        for v in values:
            console.print(f"  {v}")
        if not values:
            console.print("[dim]  (none)[/dim]")

    skills = data["skills"]
    console.print(f"\n[bold]skills[/bold] ({len(skills)})")
    for s in skills:
        held = s["held_by"]
        who = "every agent" if held == "all" else \
            (", ".join(held) if isinstance(held, list) and held else "nobody")
        # ORIGIN IS NOT DECORATION. A tenant's rows here are a mix of three
        # things that look identical in a bare list: the skills the solution
        # repo ships, assignment-only records for skills that live in the SDK's
        # wheels, and anything authored in the Studio. Someone verifying "my
        # import landed" counts five and expected two.
        #
        # Only `repo` is unmarked, because that is the reader's own work; the
        # other two answer different questions (an SDK skill must never be
        # forked, a Studio one exists in no repo until it is exported).
        # NAME THE PACK THAT SHIPS IT. `studio_skills.origin` only says whether
        # the CONTENT is stored here, so `origin='pack'` covers the SDK's
        # wheels AND this repo's own skills before they are pushed -- and
        # calling both "(sdk)" told an author that the skill they had just
        # written came from the framework. `pack_skills` answers the real
        # question, so `shared` gets "(sdk)" and anything else is named.
        if s.get("origin") == "studio":
            origin = "  [dim](studio)[/dim]"
        elif s.get("shared"):
            origin = "  [dim](sdk)[/dim]"
        elif s.get("pack"):
            origin = f"  [dim]({s['pack']})[/dim]"
        else:
            origin = ""
        # An unheld skill is the silent failure the skills docs warn about: a
        # SKILL.md with no `roles:` imports perfectly and lands in no agent.
        body = f"  {s['name']:<28} held by {who}"
        console.print((f"[yellow]{body}[/yellow]" if who == "nobody" else body)
                      + origin)
    if not skills:
        console.print("[dim]  (none)[/dim]")

    console.print("\n[dim]tenant content only - the Studio also shows the "
                  "platform's shared agents (cora, project_lead, queryngine) "
                  "and the SDK's shared skills in every workspace[/dim]")


@workspace_app.command("delete")
def delete(code: str = typer.Argument(..., help="workspace code to remove"),
           force: bool = typer.Option(
               False, "--force",
               help="also delete this workspace's run history (rows only - "
                    "on-disk artifacts under <IOF_ROOT>/instances are kept)"),
           keep_files: bool = typer.Option(
               False, "--keep-files",
               help="leave <IOF_ROOT>/workspaces/<code>/ on disk"),
           yes: bool = typer.Option(False, "--yes", "-y",
                                    help="skip the confirmation prompt")):
    """Remove a tenant workspace and every row keyed to it.

    The counterpart to `create`. Pack content is untouched (it lives in the
    installed pack, not in the workspace); anything authored ONLY in the
    Studio is deleted with the workspace - `workspace pull` it into the repo
    first if you want to keep it.
    """
    from ioagentfarm.engine.workspaces import RETIRED_WORKSPACE_CODES
    if (code or "").strip().lower() in RETIRED_WORKSPACE_CODES:
        # Not "protected" — not a WORKSPACE. The platform tier's shared rows
        # (pack skill assignments, platform-shared agents) are keyed there,
        # and deleting them breaks every workspace at once.
        console.print(
            "[red]'default' is not a workspace[/red] - it is the platform "
            "tier, where shared catalog rows live. There is nothing of yours "
            f"to delete there; adopt old tenant data with `{_prog()} "
            "workspace rename default <code>` instead.")
        raise typer.Exit(code=1)
    _activate(code)
    from ioagentfarm import workspace_sync
    if not yes:
        typer.confirm(
            f"delete workspace '{code}' and all its catalog rows?", abort=True)
    try:
        report = workspace_sync.delete_workspace(
            code, force=force, keep_files=keep_files)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1)
    removed = report["removed"]
    console.print(f"[green]deleted workspace '{report['workspace']}'[/green]")
    for table, n in sorted(removed.items()):
        console.print(f"  {n:>6}  {_removal_label(table, n)}")
    if report["state_dir_removed"]:
        console.print(f"[dim]removed {report['state_dir']}[/dim]")
    elif not keep_files and Path(report["state_dir"]).exists():
        # `rmtree(ignore_errors=True)` and a Windows file lock: the tree is
        # half gone and the receipt used to say nothing. A leftover
        # `agents/<role>/workspace/` there is later counted as a bundled
        # agent and fails `serve` at startup.
        console.print(
            f"[yellow]! {report['state_dir']} could not be fully removed "
            "(a file is open there - an engine, an editor, a build session). "
            "Close it and delete the directory by hand before re-creating "
            "this workspace.[/yellow]")
    # THE POINTER. `delete` used to leave `active_workspace` naming the
    # workspace it had just removed; every command then ran against a
    # code with no row, and the failure surfaced as "No agent '<role>'".
    pointer = _selector_root() / "active_workspace"
    try:
        if pointer.is_file() and pointer.read_text(
                encoding="utf-8").strip().lower() == code.strip().lower():
            pointer.unlink()
            console.print("[dim]no workspace is selected now - "
                          f"`{_prog()} workspace create <code>` or "
                          f"`{_prog()} workspace use <code>` next[/dim]")
    except OSError:
        pass
    # NAME WHAT SURVIVED. "settings record" is the platform's row; the
    # workspace's own `.env` -- its credentials and its local-mode flag -- is
    # deliberately kept, since deleting a tenant is not a reason to discard
    # either. Without this line the receipt reads as "settings removed", and a
    # re-created workspace then surprises the reader by still being local.
    from ioagentfarm.engine import workspace_env as _we
    _env = _we.workspace_env_path(report["workspace"])
    if _env.is_file():
        console.print(f"[dim]kept    {_env}  (credentials and local mode)[/dim]")


#: Storage table -> what the operator actually deleted. The CLI is the whole
#: interface for managing a solution, so it must not make someone learn the
#: engine's schema to read a removal receipt: "studio_agent_defs" is a fact
#: about our storage, "agents" is a fact about their workspace. Anything not
#: listed falls back to the raw name rather than being hidden — a new table
#: appearing in the receipt should look odd, not vanish.
_REMOVAL_LABELS = {
    "studio_agent_defs": ("agent", "agents"),
    "studio_skills": ("skill", "skills"),
    "studio_workflow_defs": ("workflow", "workflows"),
    "studio_workspace_items": ("imported item", "imported items"),
    "studio_workspace_members": ("member", "members"),
    "studio_workspace_repos": ("repo binding", "repo bindings"),
    "studio_workspace_settings": ("settings record", "settings records"),
    "studio_agent_display": ("agent display card", "agent display cards"),
    "studio_skill_scripts": ("skill tool binding", "skill tool bindings"),
    "workspaces": ("workspace record", "workspace records"),
    "runs": ("run", "runs"),
    "steps": ("step", "steps"),
    "messages": ("message", "messages"),
    "tasks": ("task", "tasks"),
    "stories": ("story", "stories"),
}


def _removal_label(table: str, n: int) -> str:
    pair = _REMOVAL_LABELS.get(table)
    if pair is None:
        return table
    return pair[0] if n == 1 else pair[1]


@workspace_app.command("attach")
def attach(code: str = typer.Argument(...),
           url: str = typer.Option(..., "--url", help="git URL or local path of the solution repo"),
           branch: str = typer.Option("main", "--branch"),
           credential_ref: str = typer.Option(
               "", "--credential-ref",
               help="ENV VAR NAME holding the git token (resolved at clone "
                    "time; never stored)")):
    """Bind a solution repo to a workspace (no sync happens yet)."""
    _activate(code)
    from ioagentfarm import workspace_sync
    store = _store()
    if not store.get_workspace(code):
        console.print(f"[red]workspace '{code}' does not exist - "
                      f"`aicore workspace create {code}` first[/red]")
        raise typer.Exit(code=1)
    # Refuse a local path that cannot be imported from, HERE, rather than
    # storing it and failing two commands later. `resolve_repo_tree` falls
    # through to a clone when the path is not a directory, so a typo reached
    # git as a REMOTE and came back "does not appear to be a git repository" -
    # an error about the wrong thing, pointing at a missing `git init` when
    # the directory simply was not there.
    problem = workspace_sync.local_repo_problem(url)
    if problem:
        console.print(f"[red]cannot attach:[/red] {problem}")
        console.print("[dim]  --url takes the solution repo's own directory "
                      "(the one holding aicore.solution.yaml), or a git URL.[/dim]")
        console.print(f"[dim]  if you scaffolded elsewhere, point at that "
                      f"directory instead - `{_prog()} current` shows where "
                      "this workspace's state lives.[/dim]")
        raise typer.Exit(code=2)
    row = workspace_sync.attach_repo(code, url, branch, credential_ref)
    console.print(f"[green]attached[/green] {row['repo_url']} "
                  f"(branch {row['branch']}) -> workspace '{code}'")
    console.print(f"[dim]next: aicore workspace diff {code}   "
                  "# review - content runs from the installed pack, "
                  "there is nothing to push[/dim]")


@workspace_app.command("diff")
def diff(code: str = typer.Argument(...),
         keep_tree: bool = typer.Option(False, "--keep-tree",
                                        help="don't fetch; classify against the tree as-is")):
    """What an import would change - and what has diverged. Writes nothing."""
    _activate(code)
    from ioagentfarm import workspace_sync
    from ioagentfarm.solution_manifest import ManifestError
    try:
        report = workspace_sync.diff_workspace(code, keep_tree=keep_tree)
    except ManifestError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=workspace_sync.EXIT_GAPS)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=workspace_sync.EXIT_ERROR)
    _print_report(report)


@workspace_app.command("push")
def push(code: str = typer.Argument(...),
            take_repo: bool = typer.Option(
                False, "--take-repo",
                help="overwrite diverged items with the repo version "
                     "(prior DB content is snapshotted to .backups/ first)"),
            only: str = typer.Option(
                "", "--only",
                help="comma-separated item names --take-repo applies to "
                     "(default: all diverged)"),
            keep_tree: bool = typer.Option(False, "--keep-tree",
                                           help="don't fetch; import from the tree as-is")):
    """Kept for compatibility - a no-op that says so. Exits 0, writes nothing.

    This used to publish YOUR REPO into the DATABASE's tenant content tier.
    That tier is gone: content is read from the installed pack, so there is
    nothing to push into (docs/one-truth-content-model.md section 4.5).
    `workspace pull / diff / attach` are unchanged - they remain the review
    and promotion path. Every option is accepted and ignored so a runbook
    that still calls this keeps working."""
    # Activate as before so the context line names the workspace's own
    # database rather than the ambient one.
    _activate(code)
    from ioagentfarm.cli import context_line
    console.print(context_line(code), soft_wrap=True)
    console.print(PUSH_NOOP, soft_wrap=True)


#: The one sentence `workspace push` prints. ASCII only; a constant so the
#: pinning test and the command cannot drift.
PUSH_NOOP = (
    "workspace push: nothing to do - there is no tenant content tier to push "
    "into; content is read from the installed pack. `workspace pull / diff / "
    "attach` are unchanged.")


@workspace_app.command("pull")
def pull(code: str = typer.Argument(...)):
    """The DATABASE -> your repo working tree (like `git pull`: theirs -> mine).

    Writes files for the owning team to review and commit - the platform
    NEVER commits or pushes to git for you."""
    _activate(code)
    from ioagentfarm import workspace_sync
    from ioagentfarm.solution_manifest import ManifestError
    try:
        exit_code, report = workspace_sync.pull_workspace(code)
    except ManifestError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=workspace_sync.EXIT_GAPS)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=workspace_sync.EXIT_ERROR)
    if report.get("error"):
        console.print(f"[red]{report['error']}[/red]")
        raise typer.Exit(code=exit_code)
    _n = (len(report["exported"]) + len(report.get("exported_agents") or [])
          + len(report.get("exported_skills") or []))
    console.print(f"[green]pulled {_n} item(s)[/green]")
    # EACH ITEM UNDER THE PATH IT WAS ACTUALLY WRITTEN TO. Workflows,
    # agents and skills go to three different roots, and a single header
    # naming the workflows root announced agents under a path that does not
    # exist -- indistinguishable, to a reader, from a pull writing to the
    # wrong place.
    wrote = report.get("wrote_to") or {}
    for kind, names in (("workflow", report["exported"]),
                        ("agent", report.get("exported_agents") or []),
                        ("skill", report.get("exported_skills") or [])):
        for name in names:
            label = name if kind == "workflow" else f"{kind}/{name}"
            where = wrote.get(f"{kind}/{name}")
            console.print(f"  ~ {label}" + (f"  [dim]-> {where}[/dim]"
                                            if where else ""))
    # A regenerated declaration is a real edit the reader will meet in
    # `git status`; reporting "0 item(s)" while writing files is how a pull
    # reads as a no-op that silently changed the tree.
    for name in report.get("assignment_refreshed") or []:
        console.print(f"  ~ agent/{name} skills.yaml [dim](assignment "
                      "regenerated from the database)[/dim]")
    console.print(f"[dim]{report['note']}[/dim]")


#: Every table keyed by a workspace_code column. `workspaces` (keyed by
#: `code`) and `runs`/`steps`/… (keyed by workspace_id, which the rename
#: does not change) are handled separately. Guarded per-table at run time —
#: an older database missing one of these simply has nothing to move.
_CODE_KEYED_TABLES = (
    "studio_workspace_repos",
    "studio_workspace_items",
    "studio_workspace_members",
    "studio_workspace_settings",
    "studio_workflow_defs",
    "studio_agent_defs",
    "studio_skills",
    "studio_agent_display",
    "studio_skill_scripts",
    "content_drafts",
    # A rename is one identity changing name, so its memory travels with it.
    # Kept in step with `_TENANT_TABLES` in workspace_sync: a table that one
    # list knows about and the other does not is a workspace that half moves.
    "workspace_memory",
    "workspace_memory_history",
    "workspace_memory_runs",
    "workspace_memory_settings",
)


@workspace_app.command("rename")
def rename(old: str = typer.Argument(..., help="current workspace code"),
           new: str = typer.Argument(..., help="new workspace code"),
           yes: bool = typer.Option(False, "--yes", "-y",
                                    help="skip the confirmation prompt")):
    """Rename a workspace: every DB row AND its on-disk tree, together.

    Also the ADOPTION path for pre-explicit-workspace data:
    `workspace rename default <code>` moves everything that silently
    accumulated under the retired fallback into a workspace you named —
    catalog rows, run attribution (via the `workspaces` row), the
    `<IOF_ROOT>/workspaces/default/` tree, and any pre-tenancy agent homes
    still under the machine-global location.

    The on-disk tree is MOVED, not copied — deliberately, and unlike the
    copy-never-move agent migrations: those carry content between LOCATIONS
    of one identity, while a rename is one identity changing its name, and
    two live trees under the old and new names would diverge silently from
    the first write.
    """
    import re as _re

    from ioagentfarm.engine.workspaces import (
        RETIRED_WORKSPACE_CODES, migrate_global_agent_home)

    new = _check_code(new, what="new workspace code", new=True)
    old = (old or "").strip().lower()
    adopting = old in RETIRED_WORKSPACE_CODES
    if not adopting and not _re.match(_code_re(), old):
        console.print(f"[red]invalid workspace code {old!r}[/red]")
        raise typer.Exit(code=1)
    if old == new:
        console.print("[red]old and new are the same code[/red]")
        raise typer.Exit(code=1)

    _activate(new if adopting else old)
    store = _store()
    if not adopting and not store.get_workspace(old):
        console.print(f"[red]no workspace '{old}'[/red]")
        raise typer.Exit(code=1)
    if store.get_workspace(new):
        console.print(f"[red]workspace '{new}' already exists[/red] - "
                      "rename cannot merge two workspaces")
        raise typer.Exit(code=1)
    root = _root()
    old_dir = root / "workspaces" / old
    new_dir = root / "workspaces" / new
    if new_dir.exists():
        console.print(f"[red]{new_dir} already exists[/red] - rename cannot "
                      "merge two workspace trees")
        raise typer.Exit(code=1)
    if not yes:
        typer.confirm(
            f"rename workspace '{old}' to '{new}' (all rows + on-disk tree)?",
            abort=True)

    ph = store._db.placeholder()
    # Probe table existence OUTSIDE the rename transaction. A failed statement
    # aborts a PostgreSQL transaction, so probing by UPDATE-and-catch inside
    # it would discard every earlier table's move on the first missing table.
    present: list[str] = []
    for table in _CODE_KEYED_TABLES:
        try:
            with store._tx_pair() as (con, cur):
                cur.execute(f"SELECT 1 FROM {table} LIMIT 1")
                cur.fetchall()
                present.append(table)
        except Exception:
            pass  # an older schema without this table has nothing to move
    moved: dict[str, int] = {}
    with store._tx_pair() as (con, cur):
        try:
            for table in present:
                cur.execute(
                    f"UPDATE {table} SET workspace_code = {ph} "
                    f"WHERE workspace_code = {ph}", (new, old))
                if cur.rowcount:
                    moved[table] = cur.rowcount
            cur.execute(
                f"UPDATE workspaces SET code = {ph}, name = {ph} "
                f"WHERE code = {ph}",
                (new, new.replace("_", " ").title(), old))
            if cur.rowcount:
                moved["workspaces"] = cur.rowcount
            con.commit()
        except Exception as exc:
            con.rollback()
            console.print(f"[red]rename failed, nothing changed: {exc}[/red]")
            raise typer.Exit(code=1)

    if not moved and not old_dir.is_dir():
        console.print(f"[yellow]nothing found under '{old}' - no rows, no "
                      f"directory[/yellow]")
        raise typer.Exit(code=1)

    for table, n in sorted(moved.items()):
        console.print(f"  {n:>6}  {_removal_label(table, n)} -> '{new}'")

    # The workspaces ROW must exist afterwards even when <old> never had one.
    # A pre-explicit-workspace install commonly has NO row at all — 'default'
    # existed implicitly, which is the disease adoption cures — and without
    # this, `workspace use <new>` refuses the workspace that was just adopted
    # (found live on the first real adoption: tree moved, zero rows, unusable).
    if "workspaces" not in moved:
        try:
            store.ensure_workspace(code=new,
                                   name=new.replace("_", " ").title())
            console.print(f"[dim]created the workspace row for '{new}' "
                          f"('{old}' had none - it existed only implicitly)"
                          f"[/dim]")
        except Exception as exc:
            console.print(f"[yellow]could not create the workspace row for "
                          f"'{new}': {exc} - run `{_prog()} workspace create "
                          f"{new}` to finish[/yellow]")

    if old_dir.is_dir():
        old_dir.rename(new_dir)
        console.print(f"[dim]moved {old_dir} -> {new_dir}[/dim]")

    if adopting:
        # Pre-tenancy agent homes (~/.iobot/agents) are carried too - the
        # adoption path is the ONLY caller; copy-never-overwrite.
        migrate_global_agent_home(workspace_code=new, echo=console.print)
        console.print(f"[dim]run `{_prog()} sync` next - the platform tier's "
                      "shared catalog rows are re-populated by sync, not "
                      "carried by adoption[/dim]")

    # Selection follows the name. The pointer and the env var are separate
    # surfaces: the file we can rewrite; the parent shell's env we cannot.
    try:
        pointer = _selector_root() / "active_workspace"
        if pointer.read_text(encoding="utf-8").strip() == old:
            pointer.write_text(new, encoding="utf-8")
            console.print(f"[dim]active workspace pointer -> {new}[/dim]")
    except OSError:
        pass
    if (os.getenv("IOF_WORKSPACE") or "").strip() == old:
        console.print(f"[yellow]IOF_WORKSPACE still says '{old}' in this "
                      f"shell - run: export IOF_WORKSPACE={new}[/yellow]")

    # The workspace's own settings file (credentials, local mode) lives under
    # the state dir keyed by code - carry it so the rename does not silently
    # drop the database URL the workspace was using.
    from ioagentfarm.engine import workspace_env as _we
    old_env = _we.workspace_env_path(old)
    new_env = _we.workspace_env_path(new)
    if old_env.is_file() and not new_env.exists():
        try:
            new_env.parent.mkdir(parents=True, exist_ok=True)
            new_env.write_bytes(old_env.read_bytes())
            console.print(f"[dim]settings carried to {new_env}[/dim]")
        except OSError:
            console.print(f"[yellow]could not carry {old_env} - copy it to "
                          f"{new_env} by hand[/yellow]")

    console.print(f"[green]workspace '{old}' is now '{new}'[/green]")


@workspace_app.command("use")
def use(code: str = typer.Argument(...)):
    """Set the CLI's active workspace (below --workspace and IOF_WORKSPACE)."""
    code = _check_code(code)
    _activate(code)
    store = _store()
    if not store.get_workspace(code):
        # REFUSE A WORKSPACE THAT IS NOT THERE. This selected it anyway and
        # warned that it "will be created on first run" -- so a typo'd code
        # became the selection, every later command acted on a workspace that
        # did not exist, and the reader found out somewhere further down. The
        # docs frame `use` as selecting an EXISTING one, and it should mean it:
        # creating is `create`, which selects what it creates.
        console.print(f"[red]no workspace '{code}'[/red]")
        known = [w["code"] for w in (store.list_workspaces() or [])]
        if known:
            console.print("  [dim]this database has:[/dim] " + ", ".join(known))
        else:
            console.print("  [dim]this database has none yet[/dim]")
        console.print(f"  [dim]create it:[/dim]  {_prog()} workspace create "
                      f"{code}   [dim]# creates it and selects it[/dim]")
        console.print(f"  [dim]list them:[/dim]  {_prog()} workspace list")
        raise typer.Exit(code=2)
    _adopt_local(code)
    # THE POINTER, NOT THE STATE ROOT. `_root()` here is already the root the
    # workspace's own .env declared (its settings were loaded above), and a
    # pointer written there is invisible to the next command, which has
    # nothing selected and so loads no file. See `selector_root`.
    root = _selector_root()
    root.mkdir(parents=True, exist_ok=True)
    (root / "active_workspace").write_text(code, encoding="utf-8")
    console.print(f"[green]active workspace: {code}[/green]")
