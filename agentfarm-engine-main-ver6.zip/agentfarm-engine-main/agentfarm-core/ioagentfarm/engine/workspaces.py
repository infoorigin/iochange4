from __future__ import annotations
import json
import logging
import os
import re
import shutil
from functools import lru_cache
from pathlib import Path
from importlib import resources

logger = logging.getLogger(__name__)

from ioagentfarm.packs import load_registry

AGENT_PKG = "ioagentfarm.agents"

# Regex to extract agent name from SOUL.md: "You are **Name**, the **ROLE**"
#: Display-name extraction from SOUL.md, tried in order. The original pattern
#: required a BOLD SINGLE WORD ("You are **Jarvis**"), which silently fell back
#: to the role slug for two real conventions in the tree: unbolded names
#: ("You are Nora, the data analyst") and bolded multi-word names
#: ("You are **Pharma Intel**", where ``\w+`` cannot cross the space). Agents
#: then showed as `pharma_data_analyst` instead of `Nora` everywhere the DB
#: registry is read.
_SOUL_NAME_PATTERNS = (
    # 1. The H1 title is the most explicit statement of identity when present:
    #    "# SOUL — Nora, Pharma Data Analyst" -> "Nora" (text before the comma).
    #    A bare "# SOUL" carries no name and falls through.
    re.compile(r"^#\s*SOUL\s*[—–-]+\s*([^,\n]+)", re.MULTILINE),
    # 2. Bolded name, one or more words: "You are **Pharma Intel**, the ..."
    re.compile(r"You are \*\*([^*\n]+?)\*\*"),
    # 3. Unbolded capitalised name: "You are Nora, the data analyst ..."
    re.compile(r"You are ([A-Z][\w'-]*)"),
)


def _soul_display_name(text: str) -> str | None:
    """First display name any pattern yields, else None."""
    for pattern in _SOUL_NAME_PATTERNS:
        m = pattern.search(text)
        if m:
            name = m.group(1).strip()
            if name:
                return name
    return None


#: Roles renamed since release, mapping the retired slug to the current one.
#: Kept INDEFINITELY, not for a deprecation window: a client's pod env, Teams
#: wiring and any external A2A caller all name the role as a string, and none
#: of those upgrade when a wheel does. The cost is one dict lookup; the cost of
#: dropping it is somebody's integration returning 404 on upgrade day.
#:
#: ``jarvis`` -> ``cora``: the assistant is the **Core Assistant**, and the
#: previous name carried a pop-culture association that read as unserious in
#: enterprise settings.
_ROLE_ALIASES = {"jarvis": "cora"}

#: Alias uses already reported, so a long-lived process says it once per role
#: rather than on every request.
_ALIAS_WARNED: set[str] = set()


def canonical_role(role: str) -> str:
    """Resolve a role slug through the rename table.

    Every surface that turns a role STRING into an agent goes through this:
    the CLI, the agent pool, the A2A route, the Teams channel. A retired slug
    keeps working and is logged once, so an operator learns the new name from
    their own logs instead of from a failure.
    """
    if not role:
        return role
    current = _ROLE_ALIASES.get(role.strip().lower())
    if current is None:
        return role
    if role not in _ALIAS_WARNED:
        _ALIAS_WARNED.add(role)
        logger.info(
            "role '%s' has been renamed to '%s' (the Core Assistant); the old "
            "name still works. Update IOF_ALWAYS_ON_AGENTS, any A2A caller and "
            "channel configuration when convenient.", role, current)
    return current


def _platform_shared_roles() -> frozenset[str]:
    """Roles that are framework-owned and identical in EVERY workspace.

    Read from ``PLATFORM_SHARED_ROLES`` with the same name and default as the
    studio API's ``get_settings().platform_shared_roles`` — core cannot import
    the API, so the contract is the env var. If the two ever disagree, the
    studio would show a tenant one Jarvis while runs used another.
    """
    # `cora_query` left this list when it moved to the ainf2 pack
    # (solutions/ainf2) - it is family-level pack content now, reaching a
    # workspace through entry-point discovery like every pharma agent,
    # not a framework role stamped into every tenant.
    # `play_operator` joined 2026-08-25 with the play tier's platform
    # workflows (playbook_compile): the agent that runs a governed compile
    # or case action is framework-owned and carries no domain content.
    raw = os.getenv("PLATFORM_SHARED_ROLES",
                    "cora,queryngine,project_lead,cora_build,meta_agent,play_operator")
    return frozenset(r.strip() for r in raw.split(",") if r.strip())


#: Evaluated at import; process-lifetime like the API's cached settings.
PLATFORM_SHARED_ROLES = _platform_shared_roles()


def _tenant_root() -> Path | None:
    """``<IOF_ROOT>/workspaces/<code>`` for the active tenant, else ``None``.

    Resolved at call time, so each subprocess answers for its own tenant.
    Deliberately NOT an ``aicore.packs`` entry point: ``load_registry()`` is
    ``@lru_cache(maxsize=1)`` process-wide with no cache-reset caller, so an
    env-dependent pack would freeze to whatever the long-lived ``serve``
    process saw first — wrong for a concurrent multi-tenant server. Same
    reasoning as WorkflowLoader._installed_dir.

    IT READ ``IOF_WORKSPACE`` AND NOTHING ELSE, which is half of the
    documented resolution order. ``aicore workspace use <code>`` records the
    selection in ``<IOF_ROOT>/active_workspace`` and exports nothing, so on
    the machine every getting-started guide builds this returned ``None``
    and the tenant's own agent home was dropped from ``_agent_roots()``.
    The visible effect: an agent materialised in the workspace — one
    imported from a solution repo, or Studio-built, neither of which has a
    pack template — was missing from ``list-agents`` and from
    ``_agent_names()``, i.e. it existed and appeared nowhere. Measured
    2026-09-04: invisible with the workspace selected, visible with the
    same code exported.

    ``selected_workspace`` is the one order the CLI, the engine and the
    ``iof-*`` tools already share, and it still reads the environment
    first, so a server — which exports the variable — is unchanged.
    """
    code = os.getenv("IOF_WORKSPACE", "").strip()
    if not code:
        try:
            code = (selected_workspace()[0] or "").strip()
        except Exception:                                     # noqa: BLE001
            code = ""
    if not code or code in RETIRED_WORKSPACE_CODES:
        return None
    root = Path(os.getenv("IOF_ROOT", ".iof")).resolve() / "workspaces" / code
    return root


def _agent_roots():
    """All agent-workspace source roots, in registry (pack) order.

    Replaces the old single ``resources.files(AGENT_PKG)`` lookup so
    pack-contributed agent workspaces resolve alongside the bundled ones.
    Each root is what ``resources.files`` yields (a ``Path`` for on-disk
    packages, which the callers below rely on for ``rglob``/``relative_to``).

    The ACTIVE TENANT's agent home is prepended when one is selected: an agent
    imported from a solution repo has no pack template, so without this it is
    invisible to ``list_bundled_agents()`` (spawn_run's seeding loop,
    ``POST /api/agents/sync``) and to ``_agent_names()`` — it would exist in
    the DB and never appear anywhere. First position so a tenant's own copy
    wins over a same-named pack agent, matching the studio's tenant-first
    resolution.
    """
    roots = []
    tenant = _tenant_root()
    if tenant is not None:
        agents = tenant / "agents"
        try:
            if agents.is_dir():
                roots.append(agents)
        except OSError:
            pass
    return roots + load_registry().agent_sources()


def _local_mode_on() -> bool:
    """Whether this process is in local mode, where YOUR FILES are the source.

    Set by `aicore local on`, stored in the workspace's own `.env`, and read
    here so seeding follows the same rule the rest of the CLI reports. The
    engine reads the variable rather than importing the CLI: `cli.py` replaces
    `sys.stdout` at import time, and nothing in the engine should pay that to
    answer a yes/no question.
    """
    import os as _os
    return (_os.getenv("IOF_LOCAL") or "").strip().lower() in {
        "1", "true", "yes", "on"}


def _role_workspace(role: str, exclude: Path | None = None):
    """First agent source holding ``<role>/workspace/SOUL.md``, else ``None``.

    *exclude* DROPS ONE ROOT: the directory being seeded INTO. The first root
    searched is the active tenant's agent home, which is also the seeding
    target, so a re-seed resolved the agent's own live workspace as its own
    template and copied every file onto itself. The visible effect was that
    editing an agent's ``SOUL.md`` or a skill in the repo changed nothing
    after the agent had been materialised once, and ``setup-agents --force``
    -- documented as "overwrites identity and skill files with the latest
    bundled versions" -- reported success having done nothing at all.
    It looked like it worked the first time, because the first run seeds from
    the template before any live copy exists.

    A WORKSPACE WITHOUT A SOUL IS NOT A TEMPLATE. The check used to be
    ``ws.is_dir()``, and the first root is the ACTIVE TENANT's agent home —
    which ``ensure_agent_workspace`` has already created, empty, by the time it
    asks for a source (``target.mkdir(parents=True)`` runs first, and target IS
    ``<tenant>/agents/<role>/workspace``). Every pack agent seeded into a tenant
    home therefore resolved its own empty target as its source, copied nothing,
    and came out a husk: an AGENTS.md, a skills/ tree, and no SOUL.md. Observed
    on a rebuilt tenant — eleven agent directories, `project_lead` among them,
    not one of them with an identity.

    Requiring SOUL.md is the same completeness test the rest of the codebase
    already applies to an agent directory (``_agent_names``, ``reserved_names``,
    ``read_agent_dir``, the studio's ``_visible_agent_dirs``), and it keeps the
    tenant-first ORDER meaningful: a tenant's real copy still wins, an empty one
    cannot shadow the pack that would have filled it.
    """
    try:
        skip = Path(exclude).resolve() if exclude is not None else None
    except OSError:                         # pragma: no cover - defensive
        skip = None
    for root in _agent_roots():
        ws = root / role / "workspace"
        try:
            if skip is not None and Path(str(ws)).resolve() == skip:
                continue
            if (ws / "SOUL.md").is_file():
                return ws
        except (FileNotFoundError, TypeError, NotADirectoryError, OSError):
            continue
    return None


def _shared_skill_dirs():
    """All shared-skill roots auto-injected into every agent workspace.

    Aggregates pack-contributed skill sources (``registry.skill_sources()`` —
    e.g. the ``agentfarm-skills`` pack) plus any legacy ``agents/_common/skills``
    directory. Each root holds ``<skill_name>/`` subdirectories.
    """
    dirs = []
    # The active tenant's staged solution skills — written by
    # `workspace push` from the manifest's `roots: skills:`. First so a
    # tenant's own version of a skill name wins over a pack's.
    #
    # EXCEPT IN LOCAL MODE, where it goes LAST. Once a workspace has been
    # pushed, this staged copy exists, and being first it shadowed the repo's
    # own `skills/<name>` — so editing a workspace-level skill did nothing,
    # `--force` included, and the resolution pointed at a directory under
    # `.iof/` the reader never edited. "Your files win" has to mean the
    # files, not a copy taken from them at push time.
    tenant = _tenant_root()
    tenant_skills = None
    if tenant is not None:
        ts = tenant / "skills"
        try:
            if ts.is_dir():
                tenant_skills = ts
        except OSError:
            tenant_skills = None
    # The tenant's pushed skill tree (if any) is appended LAST, below - a
    # workspace copy never outranks the installed pack, in any mode.
    for src in load_registry().skill_sources():
        try:
            if src.is_dir():
                dirs.append(src)
        except (FileNotFoundError, TypeError, NotADirectoryError):
            continue
    for root in _agent_roots():
        cs = root / "_common" / "skills"
        try:
            if cs.is_dir():
                dirs.append(cs)
        except (FileNotFoundError, TypeError, NotADirectoryError):
            continue
    # Add-only: a skill that exists ONLY as a pushed/Studio row must still
    # resolve to files rather than disappear - but it can never shadow a
    # pack skill of the same name (docs/one-truth-content-model.md).
    if tenant_skills is not None:
        dirs.append(tenant_skills)
    return dirs


def _resolvable_skill_dirs():
    """Every root a skill NAME can be resolved to files from — wider than
    :func:`_shared_skill_dirs`, and deliberately a separate function.

    ``_shared_skill_dirs`` answers "which skills are auto-injected into every
    workspace" — a seeding question, and deliberately narrow.

    :func:`record_skill_assignment` used to read THAT list, and the mismatch
    was destructive rather than merely tidy: it recorded only names the narrow
    set offered, so a skill this function could resolve and place was recorded
    as absent, and the record then propagated to ``studio_skills.roles_json``
    as "this agent carries nothing". It reads this one now, so recognition and
    resolution cannot disagree.

    This one answers: "given an ASSIGNMENT-ONLY row for
    skill X, where does its content live?" Since the Studio API no longer has a
    filesystem, an agent given ANY pack skill gets an assignment-only row —
    including a skill that belongs to one agent's workspace inside a domain
    pack, which is in no shared root. Without these extra roots
    ``carried_skills`` finds nothing and SKIPS the skill: the Studio reports the
    agent holds it and the agent runs without it.

    Appended LAST so precedence is unchanged: a tenant's staged copy and the
    shared wheels still win over a pack's agent-local one.
    """
    dirs = list(_shared_skill_dirs())
    for root in _agent_roots():
        try:
            entries = list(root.iterdir())
        except (FileNotFoundError, TypeError, NotADirectoryError, OSError):
            continue
        for entry in entries:
            try:
                if entry.name.startswith("."):
                    continue
                sk = (entry / "skills" if entry.name.startswith("_")
                      else entry / "workspace" / "skills")
                if sk.is_dir():
                    dirs.append(sk)
            except (FileNotFoundError, TypeError, NotADirectoryError, OSError):
                continue
    return dirs

# ---------------------------------------------------------------------------
# Skill assignment (the record that replaced the `roles:` eligibility gate)
# ---------------------------------------------------------------------------

#: The per-ROLE "baseline already derived" flag, and the no-database fallback
#: copy of this agent's shared-skill assignment. Written at the root of the
#: agent workspace and snapshotted into ``studio_agent_defs.files_json`` like
#: any other identity file.
#:
#: IT IS NOT THE DURABLE RECORD — ``studio_skills`` is (see
#: :func:`ioagentfarm.engine.hydration.record_pack_assignment`). One table
#: answers "which agents have this skill?" with one SELECT for every tier;
#: a per-agent file answers it only by opening and parsing every agent, which
#: is the N-agent walk ``studio_skills`` was created to remove.
#:
#: It still has two jobs the rows cannot do. The rows are keyed by WORKSPACE,
#: so "this workspace has pack rows" becomes true the moment the FIRST agent is
#: seeded — every agent seeded after it would read an empty assignment and be
#: stripped (``_seed_tenant_agents`` seeds every bundled agent in one loop, so
#: that is the common path, not a corner). This file is the per-role answer to
#: "has THIS agent been derived yet?". And with no database at all — local dev,
#: ``IOF_HYDRATION=0`` — it is the only copy there is.
#:
#: WHY THERE IS A RECORD AT ALL. Until 2026-08 a shared skill's ``SKILL.md``
#: frontmatter carried a ``roles:`` key that acted as an ELIGIBILITY GATE:
#: default-closed, and consulted on every single seed. Two consequences, both
#: bad: a workflow could never ask for a skill outside the gate (it could only
#: subtract from what the agent already carried), and because the rule was
#: re-evaluated every time, a removal made in the Studio was undone by the very
#: next ``ensure_agent_workspace``.
#:
#: The gate is gone. Skills are OPEN — any skill in a workspace may be assigned
#: to any agent in it, and a workflow step resolves what the JOB needs from the
#: whole catalog. What remains is this record, derived exactly ONCE from the
#: historical rule (the migration: without it every agent alive on the day this
#: shipped would silently lose the scoped skills it had purely because of
#: ``roles:``) and authoritative afterwards, removals included.
#:
#: A pack skill's ``studio_skills`` row is ASSIGNMENT ONLY (``origin='pack'``,
#: ``files_json='{}'``): pack CONTENT must never be stored per tenant, because
#: a copy freezes a fork no SDK upgrade reaches again — the rule
#: ``reserved_names()`` enforces on the import and export paths, and which
#: ``skill_defs.upsert_skill_def`` now refuses at the writer.
SKILL_ASSIGNMENT_MARKER = ".skills-assigned.json"


def shared_skill_files(name: str) -> dict[str, str] | None:
    """A shared (pack/SDK/tenant-staged) skill's files, or ``None``.

    ``{rel_posix: content}``, binary-safe via the shared file codec — the same
    shape ``studio_skills.files_json`` holds, so a caller can substitute this
    for a row's stored content without knowing the difference.

    This is what lets a pack skill have an ASSIGNMENT row with NO content: the
    row says who holds it, the wheel says what it is. Storing the content would
    freeze a tenant fork at the version that existed the day it was assigned,
    which no SDK upgrade reaches again.
    """
    from ioagentfarm.engine.filecodec import encode_file
    for root in _resolvable_skill_dirs():
        d = root / name
        try:
            if not d.is_dir():
                continue
        except (OSError, TypeError, NotADirectoryError):
            continue
        files: dict[str, str] = {}
        for p in sorted(d.rglob("*")):
            if not p.is_file() or "__pycache__" in p.parts \
                    or p.suffix in (".pyc", ".pyo"):
                continue
            v = encode_file(p)
            if v is not None:
                files[p.relative_to(d).as_posix()] = v
        if "SKILL.md" in files:
            return files
    return None


def read_skill_assignment(target: Path) -> list[str] | None:
    """The recorded shared-skill assignment, or ``None`` when there is none
    yet (an unmigrated or brand-new workspace). Never raises."""
    import json as _json
    try:
        rec = _json.loads((target / SKILL_ASSIGNMENT_MARKER)
                          .read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    names = rec.get("skills") if isinstance(rec, dict) else None
    return sorted(str(n) for n in names) if isinstance(names, list) else None


def record_skill_assignment(target: Path, role: str = "") -> list[str]:
    """Rewrite the record from what the workspace ACTUALLY carries, and return
    it.

    Call this after anything changes an agent's skills outside a seed — the
    Studio's add/remove is the live case — and BEFORE the workspace is
    snapshotted to the DB. Without that the snapshot carries a stale record and
    a fresh pod rebuilds the agent minus the skill that was just added: the
    change appears to work, and evaporates on the next deployment. This is the
    shared-skill twin of ``skill_defs.sync_carried_skills``, which does exactly
    the same reconciliation for the skills that DO have their own rows.

    Only names the shared sources actually offer are recorded; an agent's own
    skills need no record (they live in its template or its ``studio_skills``
    rows, both of which already travel).

    IDEMPOTENT, and that is load-bearing rather than an optimisation. The
    record is part of the agent's DB snapshot, so anything inside it that moves
    on its own moves ``studio_agent_defs.content_hash`` — which is the sync key
    — and every carrier re-materialises for no reason. An earlier version
    stamped the write time and rewrote unconditionally, so a seed of N agents
    dirtied N rows and did 2N filesystem writes every time, whether or not
    anything had changed. Same rule as the hydrator's own "hash equal -> strict
    no-op".
    """
    import json as _json

    # RECOGNITION MUST MATCH RESOLUTION, or the recorder erases what it merely
    # cannot see. This read `_shared_skill_dirs()` (the narrow set: the shared
    # wheels, the tenant's staged skills, legacy `_common/skills`) while
    # `shared_skill_files` — which is what actually supplies an assignment-only
    # row's content — searches `_resolvable_skill_dirs()`, the wider set that
    # also includes a pack AGENT's own `workspace/skills/`. `output_protocol`
    # lives ONLY there, in `agents/cora/...` and `agents/project_lead/...`.
    #
    # So a studio-built agent carrying `output_protocol` had it resolved and
    # placed, then this function looked for the name in a smaller set, did not
    # find it, and rewrote the record to "carries nothing" — which
    # `sync_carried_skills` then propagated into `studio_skills.roles_json`,
    # deleting an assignment the user made in the Studio. Seen on the first run
    # of demo_intake_analyst / demo_brief_reviewer: three pack rows blanked to
    # [], and `output_protocol` never placed again on any later hydration. That
    # is the skill whose absence makes every step of that agent fail the
    # STATUS/OUTPUT parse.
    #
    # This does widen what the marker records, which moves
    # studio_agent_defs.content_hash once for affected agents and
    # re-materialises them. That is a one-time cost against a record that is
    # currently wrong, and the invariant it buys is worth stating: a name is
    # recorded as shared exactly when a shared source can supply it.
    shared: set[str] = set()
    for root in _resolvable_skill_dirs():
        try:
            shared.update(d.name for d in root.iterdir() if d.is_dir())
        except OSError:
            continue
    skills_dir = target / "skills"
    try:
        carried = sorted(
            d.name for d in skills_dir.iterdir()
            if d.is_dir() and d.name in shared)
    except OSError:
        carried = []
    if read_skill_assignment(target) == carried:
        return carried               # unchanged: do not touch the file
    try:
        (target / SKILL_ASSIGNMENT_MARKER).write_text(_json.dumps({
            "role": role,
            "note": "shared-skill assignment for this agent; see "
                    "engine/workspaces.py SKILL_ASSIGNMENT_MARKER",
            "skills": carried,
        }, indent=2) + "\n", encoding="utf-8")
    except OSError:
        logger.debug("could not write %s for role=%s",
                     SKILL_ASSIGNMENT_MARKER, role, exc_info=True)
    return carried


# ---------------------------------------------------------------------------
# Declared carriage — a solution repo assigns a skill by NAME
# ---------------------------------------------------------------------------

#: An agent workspace in a SOLUTION REPO declares the skills it carries here::
#:
#:     # <pkg>/agents/<role>/workspace/skills.yaml
#:     carries:
#:       - dispute_handling
#:
#: In a repo, assignment was previously PHYSICAL LOCATION and nothing else, so
#: giving one skill to three agents meant three copies that drift apart —
#: visible today in ``solutions/pharma``, where ``catalog_reader``,
#: ``grounded_analysis`` and ``output_protocol`` are duplicated across two
#: agents. The runtime already avoided this: the engine records carriage as
#: NAMES and resolves content from the shared source at materialisation. This
#: file makes that authorable.
#:
#: WHY IT IS NOT :data:`SKILL_ASSIGNMENT_MARKER`. Reusing that file was the
#: smaller-looking option and does not work, for three reasons that are all in
#: the code rather than in taste:
#:
#: 1. ``.skills-assigned.json`` is listed in ``workspace_sync._AGENT_GENERATED``,
#:    which drops it from ``agent_content_hash``. An edit to a declaration would
#:    therefore classify as ``unchanged`` at ``workspace push`` — and
#:    ``APPLY_DEFAULT["unchanged"]`` is False, so the new declaration would
#:    never reach the database. Silent, which is the failure class this whole
#:    feature exists to remove.
#: 2. The same tuple drops it from ``exportable_agent_files``, so it cannot
#:    round-trip back to the repo. Taking it out of that tuple is the change the
#:    tuple's own docstring says breaks the import gate, and it would export
#:    THIS host's derived list — the wheel's ``data_query``/``guardrails``/… —
#:    into a domain repo, where on another install those names resolve nowhere.
#: 3. :func:`record_skill_assignment` REWRITES that file from what is on disk.
#:    On any host where a declared skill was not placed, the authored list would
#:    be replaced by the derived one, re-snapshotted into the agent's row, and
#:    the next ``workspace pull`` would delete the author's declaration from
#:    their own source tree.
#:
#: So the two files have one writer and one meaning each: this one is AUTHORED
#: (hashed, compared, exported, never rewritten by the engine), and
#: ``.skills-assigned.json`` stays GENERATED (rewritten from disk every seed,
#: never exported). A declared skill lands in the generated record too, because
#: by then it is genuinely on disk — the record keeps describing reality and
#: nothing had to learn a second concept.
DECLARED_SKILLS_FILE = "skills.yaml"


class SkillDeclarationError(RuntimeError):
    """A ``skills.yaml`` will not parse, or names a skill nothing can supply.

    FAIL LOUD, deliberately. The alternative — place what resolves, skip what
    does not — is the exact shape this area keeps producing: an agent that runs,
    reports success, and was silently missing the capability the author
    assigned it. A named refusal costs one retry; the silent version costs the
    skill, with no signal anywhere.
    """


def parse_declared_skills(text: str, where: str = DECLARED_SKILLS_FILE
                          ) -> list[str]:
    """The ``carries:`` list from a declaration file's TEXT.

    Separate from :func:`read_declared_skills` because the importer and the
    exporter hold the content as a string out of the database, never as a path.
    """
    import yaml
    if not (text or "").strip():
        return []
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise SkillDeclarationError(f"{where} is not valid YAML: {exc}") from exc
    if doc is None:
        return []
    if not isinstance(doc, dict):
        raise SkillDeclarationError(
            f"{where} must be a mapping with a `carries:` list; got "
            f"{type(doc).__name__}")
    names = doc.get("carries")
    if names is None:
        return []
    if not isinstance(names, list) or not all(
            isinstance(n, str) and n.strip() for n in names):
        raise SkillDeclarationError(
            f"{where}: `carries:` must be a list of skill names, one per line")
    return sorted({n.strip() for n in names})


def read_declared_skills(workspace: Path) -> list[str]:
    """Skill names *workspace* declares it carries; ``[]`` when it declares none."""
    f = workspace / DECLARED_SKILLS_FILE
    try:
        text = f.read_text(encoding="utf-8")
    except OSError:
        return []
    return parse_declared_skills(text, where=str(f))


def resolve_declared_skills(workspace: Path, role: str = "",
                            extra_roots=None) -> dict[str, Path]:
    """``{name: source dir}`` for everything *workspace* declares. Loud.

    Resolves against :func:`_resolvable_skill_dirs` — the same wider set
    ``shared_skill_files`` uses, so a declaration can name a pack-level skill,
    a shared wheel skill, or a skill living in another agent's workspace, and
    recognition cannot disagree with resolution.

    *extra_roots* is prepended by the IMPORTER, which resolves against a repo
    CHECKOUT that may not be pip-installed in this environment — its own
    ``skills/`` root is then in no registry and would read as missing.

    Raises :class:`SkillDeclarationError` naming every unresolvable name and
    every root searched.
    """
    names = read_declared_skills(workspace)
    if not names:
        return {}
    roots = [Path(r) for r in (extra_roots or [])] + list(
        _resolvable_skill_dirs())
    out: dict[str, Path] = {}
    missing: list[str] = []
    for name in names:
        for root in roots:
            d = root / name
            try:
                if (d / "SKILL.md").is_file():
                    out[name] = d
                    break
            except (OSError, TypeError, NotADirectoryError):
                continue
        else:
            missing.append(name)
    if missing:
        searched = "\n".join(f"  {d}" for d in roots) or \
            "  (nothing — no pack or SDK skill source is installed here)"
        raise SkillDeclarationError(
            f"{workspace / DECLARED_SKILLS_FILE} declares "
            + ", ".join(f"`{m}`" for m in missing)
            + (f" for role '{role}'" if role else "")
            + ", and no skill source has it. Searched:\n" + searched
            + "\nRefusing rather than carrying nothing: an agent missing an "
              "assigned skill still runs, still reports success, and is "
              "silently worse. Check the spelling, or install the pack that "
              "ships the skill in THIS environment.")
    return out


def _default_assignment(skill_dir, role: str) -> bool:
    """Does *role* start with this skill in a workspace that has no record yet?

    Runs once per agent (see :data:`SKILL_ASSIGNMENT_MARKER`) — the migration
    source for workspaces predating the assignment record, and the opening
    hand for a brand-new one. NOT a gate: a ``False`` here never blocks a
    workflow, a Studio assignment or an import, and once the record exists
    this is never consulted again — change the mapping in the database and it
    cannot be overridden from here.

    The map comes from the PACKS (``PackRegistry.skill_defaults``), never from
    a constant in core. That is what keeps core domain-free: the shared-skills
    wheel declares its universally-useful skills, each domain pack declares
    what its own agents start with, and the registry merges them by union.
    Nothing in ``agentfarm-core`` names a domain role.

    It replaced a ``roles:`` key inside each SKILL.md, which read as a
    permission the skill granted — exactly what the open-skills change
    removed. A leftover ``roles:`` key is inert: this never reads the file.
    """
    name = getattr(skill_dir, "name", "")
    if not name:
        return False
    try:
        assigned = load_registry().skill_defaults().get(name)
    except Exception:
        logger.debug("skill defaults unavailable for %r", name, exc_info=True)
        return False
    if assigned is None:
        return False
    return assigned == "all" or role in assigned


# ---------------------------------------------------------------------------
# Memory size management
# ---------------------------------------------------------------------------

# Hard cap for MEMORY.md — keeps context window safe for any model.
# 8KB ≈ 2K tokens, well within even small context windows.
MAX_MEMORY_BYTES = 8 * 1024

# Observation entry pattern: lines starting with "- [" (step observations)
_OBS_RE = re.compile(r"^- \[", re.MULTILINE)


def enforce_memory_cap(memory_file: Path, max_bytes: int = MAX_MEMORY_BYTES) -> bool:
    """Enforce a size cap on MEMORY.md, keeping the most recent observations.

    Strategy:
    1. If file is under cap, do nothing.
    2. Split content into entries (sections or observation lines).
    3. Keep the most recent entries that fit within the cap.
    4. Prepend a summary of what was trimmed.

    Returns True if the file was trimmed.
    """
    if not memory_file.exists():
        return False

    content = memory_file.read_text(encoding="utf-8")
    if len(content.encode("utf-8")) <= max_bytes:
        return False

    # Split into entries by section headers or observation markers
    # Try section-based split first (## headers)
    sections = re.split(r"(?=^## )", content, flags=re.MULTILINE)
    sections = [s for s in sections if s.strip()]

    if len(sections) <= 1:
        # No section headers — split by observation entries ("- [step_key]")
        entries = re.split(r"(?=^- \[)", content, flags=re.MULTILINE)
        entries = [e for e in entries if e.strip()]
    else:
        entries = sections

    if len(entries) <= 2:
        # One dominant section (e.g. a single "## Learnings" holding many
        # "### Learning: ..." sub-entries) — split at H3 so the cap can trim
        # WITHIN it instead of keeping the whole oversized block via the
        # keep-at-least-one fallback.
        sub = re.split(r"(?=^### )", content, flags=re.MULTILINE)
        sub = [s for s in sub if s.strip()]
        if len(sub) > len(entries):
            entries = sub

    if len(entries) <= 1:
        # Can't split meaningfully — hard truncate to keep the tail
        trimmed = content.encode("utf-8")[-max_bytes:].decode("utf-8", errors="replace")
        # Find first clean line break
        first_nl = trimmed.find("\n")
        if first_nl > 0:
            trimmed = trimmed[first_nl + 1:]
        header = f"<!-- Memory trimmed: kept last {len(trimmed)} bytes -->\n\n"
        memory_file.write_text(header + trimmed, encoding="utf-8")
        logger.info("Memory hard-truncated to %d bytes: %s", max_bytes, memory_file)
        return True

    # Keep most recent entries (from the end) that fit within budget
    budget = max_bytes - 200  # reserve space for trim header
    kept = []
    kept_bytes = 0
    for entry in reversed(entries):
        entry_bytes = len(entry.encode("utf-8"))
        if kept_bytes + entry_bytes > budget:
            break
        kept.insert(0, entry)
        kept_bytes += entry_bytes

    # If we couldn't keep anything, keep at least the last entry
    if not kept:
        kept = [entries[-1]]

    trimmed_count = len(entries) - len(kept)
    if trimmed_count == 0:
        return False  # Everything fits after all

    header = (
        f"<!-- Memory cap enforced: {trimmed_count} older entries trimmed, "
        f"{len(kept)} most recent kept (cap={max_bytes // 1024}KB) -->\n\n"
    )
    memory_file.write_text(header + "".join(kept), encoding="utf-8")
    logger.info(
        "Memory capped: trimmed %d entries, kept %d (%.1fKB): %s",
        trimmed_count, len(kept), kept_bytes / 1024, memory_file,
    )
    return True


def get_agent_name(role: str) -> str:
    """Return the display name for an agent role by reading its SOUL.md.

    Checks (in order):
    1. Live iobot workspace (~/.iobot/agents/<role>/workspace/SOUL.md)
    2. Bundled template (ioagentfarm/agents/<role>/workspace/SOUL.md)

    Falls back to the role string itself if SOUL.md is missing or unparseable.
    """
    return _agent_names().get(role, role)


def list_bundled_agents() -> list[str]:
    """Return all role names that have a bundled workspace template."""
    roles: set[str] = set()
    try:
        for agents_pkg in _agent_roots():
            for entry in agents_pkg.iterdir():
                if not entry.is_dir():
                    continue
                ws = entry / "workspace"
                # an identity file makes an agent; an empty `workspace/` left
                # behind by a refused hydration does not (novice finding)
                if ws.is_dir() and (ws / "SOUL.md").is_file():
                    roles.add(entry.name)
    except Exception:
        logger.debug("Failed to scan bundled agents", exc_info=True)
    return sorted(roles)


@lru_cache(maxsize=1)
def _agent_names() -> dict[str, str]:
    """Build role→name mapping by scanning all bundled agent SOUL.md files."""
    names: dict[str, str] = {}
    try:
        for agents_pkg in _agent_roots():
            for entry in agents_pkg.iterdir():
                if not entry.is_dir():
                    continue
                role = entry.name
                if role in names:
                    continue  # first source (pack order) wins
                soul = entry / "workspace" / "SOUL.md"
                if soul.is_file():
                    name = _soul_display_name(soul.read_text(encoding="utf-8"))
                    if name:
                        names[role] = name
    except Exception:
        logger.debug("Failed to scan bundled agents for names", exc_info=True)
    return names


def _iof_root() -> Path:
    return Path(os.getenv("IOF_ROOT", ".iof")).resolve()


# ---------------------------------------------------------------------------
# Per-agent iobot workspace management
# ---------------------------------------------------------------------------

#: The internal SHARED tier key for workspace-keyed DB rows: platform-shared
#: roles, pack skill-assignment records, and the shared half of the catalog
#: union. The VALUE is the retired literal on purpose — every existing
#: deployment's shared rows are keyed to it, and renaming the value is a data
#: migration this constant makes a one-line change when it happens. The
#: CONCEPT it names is "the platform tier", which is not a workspace: it can
#: never be selected, created, listed or resolved to. Any code comparing a
#: USER-SUPPLIED workspace code against this value is a bug — user input goes
#: through ``resolved_workspace_code`` / the CLI, both of which refuse it.
PLATFORM_TIER = "default"

#: Workspace codes that are RETIRED as selectable workspaces. ``default``
#: existed as a universal silent fallback — anything that never chose a
#: workspace landed there, which made "which workspace answered this?"
#: unanswerable. Existing data keyed to it is adopted into a named workspace
#: with ``aicore workspace rename default <code>``.
RETIRED_WORKSPACE_CODES = frozenset({PLATFORM_TIER})

#: THE ONE SHAPE OF A WORKSPACE CODE - two regexes, one rule each, and every
#: seam that checks a code imports them from here. They used to be five
#: literals: ``^[a-z][a-z0-9_-]{1,40}$`` in the CLI, the engine API and the
#: Studio API, and ``^[a-z][a-z0-9_]{2,30}$`` in the scaffold - whose
#: ``new-workspace <code>`` takes the SAME code, because it becomes the
#: family code and a Python package prefix. A build session accepted ``ab``
#: at its workspace prompt, its preamble then ordered ``aicore new-workspace
#: ab`` "with that exact code", and the scaffold refused it: a break one
#: command after a creation that looked fine. Same for a hyphen, and for a
#: code of 32-41 characters.
#:
#: EXISTING codes keep the wide shape - a tenant named before this rule is
#: still selectable, renameable-from and deletable. Only a code being
#: CREATED must satisfy the package rule.
WORKSPACE_CODE_RE = re.compile(r"^[a-z][a-z0-9_-]{1,40}$")
NEW_WORKSPACE_CODE_RE = re.compile(r"^[a-z][a-z0-9_]{2,30}$")
NEW_WORKSPACE_CODE_RULE = ("3-31 chars: a lowercase letter, then lowercase "
                           "letters, digits or '_'")


def workspace_code_problem(code: str, *, new: bool = False) -> str | None:
    """Why *code* is not a valid workspace code, or ``None`` when it is.

    ``new=True`` applies the stricter shape a code must have to be CREATED
    (it becomes the package prefix ``aicore new-workspace`` scaffolds); the
    default accepts any code that may already exist. Never reinterprets: a
    malformed code is named back, so a typo cannot select a different
    workspace.
    """
    code = (code or "").strip()
    if not code:
        return "workspace code is empty"
    if code in RETIRED_WORKSPACE_CODES:
        return (f"'{code}' is retired: it existed only as a silent fallback, "
                "which made it impossible to tell which workspace served "
                "which answer. Create a named workspace; adopt existing data "
                f"with `aicore workspace rename {code} <code>`")
    if new:
        if NEW_WORKSPACE_CODE_RE.match(code):
            return None
        hint = ""
        dashed = code.replace("-", "_")
        if "-" in code and NEW_WORKSPACE_CODE_RE.match(dashed):
            hint = f" - use '{dashed}'"
        elif len(code) < 3 and WORKSPACE_CODE_RE.match(code):
            hint = " - too short: a name, not initials"
        elif len(code) > 31 and WORKSPACE_CODE_RE.match(code):
            hint = " - too long for a package prefix"
        return (f"'{code}' cannot be a new workspace code "
                f"({NEW_WORKSPACE_CODE_RULE}); it becomes the package prefix "
                f"the scaffold generates{hint}")
    if WORKSPACE_CODE_RE.match(code):
        return None
    return (f"invalid workspace code '{code}': a lowercase letter, then "
            "lowercase letters, digits, '-' or '_' (2-41 chars)")

_SELECT_HINT = (
    "no workspace is selected. Set one first:\n"
    "  aicore workspace create <code>   # creates it and selects it\n"
    "  aicore workspace use <code>      # selects an existing one\n"
    "or set IOF_WORKSPACE=<code> in the environment. `aicore current` "
    "reports what is selected now."
)

_RETIRED_HINT = (
    "the 'default' workspace is retired: it existed only as a silent "
    "fallback, which made it impossible to tell which workspace served "
    "which answer. Adopt its data into a named workspace (one command - "
    "rename refuses an already-existing target, so do not create it first):\n"
    "  aicore workspace rename default <code>\n"
    "then select it:  aicore workspace use <code>"
)


class WorkspaceNotSelected(RuntimeError):
    """An operation needed a workspace and none is selected.

    There is deliberately NO fallback: the platform never supplies a
    workspace code on the caller's behalf.
    """

    def __init__(self, message: str = "") -> None:
        super().__init__(message or _SELECT_HINT)


class WorkspaceRetired(RuntimeError):
    """A retired workspace code (``default``) was supplied as a selection."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(_RETIRED_HINT)


def selected_workspace(explicit: str | None = None):
    """THE resolution order, in one place: ``(code, source, shadowed)``.

    ``--workspace`` > ``IOF_WORKSPACE`` > ``<selector root>/active_workspace``
    (the REAL environment's ``IOF_ROOT``, else the working directory's
    ``.iof`` - never a root a workspace's own ``.env`` declared; see
    :func:`workspace_env.selector_root`).
    ``shadowed`` is the losing persisted value when it DISAGREES with the
    winner — never None silently: a stale selector that quietly redirects
    work to another tenant is the failure this function exists to stop.

    THIS USED TO BE TWO ORDERS, INVERTED. The CLI read the file first and
    the engine read the environment first, and neither wrote its answer
    back — so a single ``aicore run`` resolved TWO tenants at once:
    CLI-threaded paths got the file's, ambient engine paths got the
    environment's. It surfaced as ``FileNotFoundError: No workspace for
    role=...`` naming a workspace the operator had not selected.

    No test could have caught it: every one sets exactly one signal, a pod
    has the variable and no file, and a fresh machine has the file and no
    variable. Only a developer holding both — which the getting-started
    docs instruct — sees them disagree.

    Environment over file, because that is what the engine, the ``iof-*``
    tools, the container entrypoint and the docs already did; only the CLI
    dissented. The earlier reasoning for file-first was sound about its own
    bug (an invisible variable beating a visible ``workspace use``) but the
    failure is symmetric, and the fix for both directions is to make the
    disagreement LOUD rather than to pick a different silent winner.
    """
    explicit = (explicit or "").strip()
    env = (os.getenv("IOF_WORKSPACE") or "").strip()
    try:
        from ioagentfarm.engine.workspace_env import selector_root
        stored = (selector_root() / "active_workspace").read_text(
            encoding="utf-8").strip()
    except Exception:                                     # noqa: BLE001
        stored = ""
    if explicit:
        losing = env or stored
        return explicit, "--workspace", (losing if losing != explicit
                                         else None)
    if env:
        return env, "IOF_WORKSPACE", (stored if stored and stored != env
                                      else None)
    return stored, "active_workspace", None


def maybe_workspace_code() -> str | None:
    """The selected workspace code, or ``None`` when nothing is selected.

    For surfaces that REPORT selection state (``aicore current``,
    ``config-check``) rather than act on it. A retired code counts as no
    selection here — reporting surfaces name the problem instead of raising.
    """
    code = selected_workspace()[0]
    if not code or code in RETIRED_WORKSPACE_CODES:
        return None
    return code


def resolved_workspace_code() -> str:
    """The tenant workspace in force, resolved WITHOUT needing activation.

    Delegates to :func:`selected_workspace` — ONE order, shared with the
    CLI, which adds ``--workspace`` on top. It does NOT write the answer
    back into the environment (that leaked between in-process callers), so
    sharing the resolver is the only thing keeping the two in agreement.

    FAIL-CLOSED: nothing selected raises :class:`WorkspaceNotSelected`, and a
    retired code raises :class:`WorkspaceRetired`. This function used to
    return ``"default"`` — the root of a tree of silent fallbacks under which
    agent homes, skill assignments and run attribution all landed in a
    workspace nobody chose.
    """
    code = selected_workspace()[0]
    if not code:
        raise WorkspaceNotSelected()
    if code in RETIRED_WORKSPACE_CODES:
        raise WorkspaceRetired(code)
    return code


def agent_home_root() -> Path:
    """The directory agent workspaces are seeded under, resolved.

    ALWAYS WORKSPACE-SCOPED: ``<IOF_ROOT>/workspaces/<code>/agents``, with
    ``IOF_AGENT_HOME`` as an explicit override. There is no machine-global
    agent home — that was the pre-tenancy design, and keeping it as the
    default for ``default`` made correctness depend on whether a command
    remembered to call ``_activate_workspace``: `setup-agents` did and seeded
    the tenant home, `agent-chat` did not and read the global one, so an agent
    seeded by one was invisible to the other. The old docstring named the
    symptom itself ("agents from long-finished work keep turning up in
    unrelated catalogs") without naming the cause.

    Resolving the workspace HERE, rather than trusting an env var some caller
    was supposed to set, is the same fix as ``hub_client.inbox_base()`` and
    ``forensics.find_swarm_results()``: one function both sides go through, so
    a reader and a writer cannot disagree.

    Content seeded under the pre-tenancy global home is adopted into a NAMED
    workspace by ``aicore workspace rename default <code>`` (which calls
    :func:`migrate_global_agent_home` explicitly — never automatically).
    """
    home = os.getenv("IOF_AGENT_HOME", "").strip()
    if home:
        return Path(home)
    return _iof_root() / "workspaces" / resolved_workspace_code() / "agents"


def legacy_global_agent_home() -> Path:
    """The pre-tenancy machine-global agent home, ``~/.iobot/agents``.

    Retained ONLY as the migration source. Nothing resolves to it.
    """
    from ioagentfarm.engine.state_dir import state_dir_root
    return state_dir_root() / "agents"


def migrate_global_agent_home(*, workspace_code: str, echo=None) -> dict | None:
    """Carry pre-tenancy agent homes into *workspace_code*, explicitly.

    An install that predates workspace-scoped agent homes has its identities,
    skills AND MEMORY under ``~/.iobot/agents``. This carries them into the
    NAMED workspace — it is called from the adoption path
    (``aicore workspace rename default <code>``), never automatically: an
    automatic version keyed to ambient resolution is how stale agents from
    long-finished work kept turning up in workspaces nobody put them in,
    which is the confusion the explicit-workspace rule exists to end.

    COPIES, never moves, and never overwrites an agent that already exists in
    the destination — the rule the state-directory migration
    established after its first attempt skipped whenever the destination
    directory existed (which is always, because resolving any path creates
    it). Keyed per AGENT, so a destination that holds some agents still
    receives the ones it lacks.

    Returns a summary when something was carried, else ``None``.
    """
    src = legacy_global_agent_home()
    if not src.is_dir():
        return None
    dst = _iof_root() / "workspaces" / workspace_code / "agents"
    carried: list[str] = []
    for agent_dir in sorted(p for p in src.iterdir() if p.is_dir()):
        target = dst / agent_dir.name
        if target.exists():
            continue  # never overwrite what the tenant already has
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(str(agent_dir), str(target))
            carried.append(agent_dir.name)
        except Exception:
            logger.debug("could not carry agent home %s", agent_dir.name,
                         exc_info=True)
    if not carried:
        return None
    summary = {"from": str(src), "to": str(dst), "agents": carried}
    if echo:
        echo(f"carried {len(carried)} agent home(s) from the pre-tenancy "
             f"location into workspace '{workspace_code}': "
             f"{', '.join(carried)}")
    return summary


def iobot_agent_workspace(role: str) -> Path:
    """Return the iobot workspace directory for a specific agent role.

    Default layout: ~/.iobot/agents/<role>/workspace/
    Each agent gets its own workspace with identity (SOUL.md), memory, and skills.
    This is where iobot's ContextBuilder reads MEMORY.md from natively.

    ``IOF_AGENT_HOME`` overrides the agents root (platform multi-workspace
    isolation: each tenant workspace points this at
    ``<IOF_ROOT>/workspaces/<code>/agents`` so identity, skills AND memory are
    per-tenant instead of machine-global). Resolved at call time so every
    subprocess honors its own environment.
    """
    # Canonicalise HERE, the one place a role STRING becomes a PATH. Every
    # surface that resolves an agent — seeding, the pool, the A2A card, the
    # Teams channel, hydration — arrives through this function, so a retired
    # slug reaches the same directory as the current one and cannot end up
    # with a second workspace holding divergent memory.
    role = canonical_role(role)
    _migrate_renamed_agent_home(role)
    return agent_home_root() / role / "workspace"


def _migrate_renamed_agent_home(role: str) -> None:
    """Carry a renamed agent's existing home to its new slug, once.

    An install that predates the rename has the agent's identity, skills and
    MEMORY under the OLD slug. Resolution now points at the new one, so
    without this the agent looks unseeded and its accumulated memory looks
    lost. COPIES, never moves, and never overwrites an existing destination —
    the rule every migration in this codebase follows.
    """
    old = next((o for o, new in _ROLE_ALIASES.items() if new == role), None)
    if old is None:
        return
    root = agent_home_root()
    src, dst = root / old, root / role
    if not src.is_dir() or dst.exists():
        return
    try:
        shutil.copytree(str(src), str(dst))
        logger.info(
            "carried the '%s' agent home to '%s' (identity, skills and memory "
            "preserved; the old directory is left in place)", old, role)
    except Exception:
        logger.debug("could not carry agent home %s -> %s", old, role,
                     exc_info=True)


def ensure_iobot_agent(
    role: str,
    force: bool = False,
    domain_skills_dirs: list[Path] | None = None,
    workspace_code: str | None = None,
) -> None:
    """Seed a iobot agent workspace from bundled templates.

    Creates ~/.iobot/agents/<role>/workspace/ and copies all bundled identity
    files (SOUL.md, AGENTS.md, TOOLS.md, skills/, etc.).

    When *force* is True, overwrites identity and skill files with the latest
    bundled versions.  Memory files (memory/MEMORY.md) are NEVER overwritten
    regardless of *force* — they contain accumulated learnings.
    """
    ws = iobot_agent_workspace(role)
    ensure_agent_workspace(role, ws, force=force,
                           domain_skills_dirs=domain_skills_dirs,
                           workspace_code=workspace_code)
    logger.debug("Ensured iobot agent workspace for role=%s at %s (force=%s)", role, ws, force)


#: ``(database, workspace_code, role)`` triples whose shared-skill assignment
#: this PROCESS has already written. Purely an optimisation, and deliberately
#: process-local: it must not outlive the process, because the row it stands
#: for can be changed by the Studio, by another pod, or by a direct edit.
#: Losing it costs one idempotent write; trusting a stale one costs a tenant
#: its skills.
#:
#: THE DATABASE IS PART OF THE KEY, not decoration. The memo answers "has this
#: row been written", and that question is meaningless without saying where.
#: Keyed on (workspace, role) alone it survived a change of database inside one
#: process and reported yes about a row that did not exist — which is precisely
#: the failure this memo exists to prevent, one level up. Caught by the test
#: suite, where every test gets a fresh sqlite file and the same interpreter;
#: a long-lived process that is repointed at another database would have hit
#: it in production the same way.
_PACK_ASSIGNMENT_RECONCILED: set[tuple[str, str, str]] = set()


def forget_pack_assignments(workspace_code: str) -> int:
    """Drop the memo for a workspace, so a recreated one is written again.

    THE MEMO OUTLIVED THE WORKSPACE. Its key is
    ``(database, workspace_code, role)`` - deliberately, because a memo over a
    workspace-scoped write needs the database in it - but nothing ever removed
    an entry. Delete a workspace and recreate it under the SAME code in one
    long-lived process, and the memo answers "already reconciled" about rows
    that were deleted with the tenant: the new workspace's catalog lists none
    of the SDK's skills, silently, exactly as it did for the second-tenant bug
    this memo was written to fix.

    Called from the delete path. Returns how many entries went, so a caller
    can log it.
    """
    code = (workspace_code or "").strip()
    if not code:
        return 0
    stale = {k for k in _PACK_ASSIGNMENT_RECONCILED if k[1] == code}
    _PACK_ASSIGNMENT_RECONCILED.difference_update(stale)
    return len(stale)


_write_seq = __import__('itertools').count()


def _write_shared(dest: Path, text: str) -> None:
    """Write an identity file two launches may write at once.

    Two `aicore run` in the same second both re-seeded the platform agents
    and both rewrote `AGENTS.md`; on Windows the second open of a file the
    first is writing is PermissionError, and one launch died with a
    traceback (novice finding, round 4). Three rules: nothing is written
    when the bytes already match (the common case, so there is nothing to
    race on); a write goes to a sibling temp file and is renamed into
    place; a rename refused because the other writer holds the file is
    retried briefly and then, if the file exists, left to the other
    writer - both were writing the same bytes.
    """
    import os
    import threading
    import time
    data = text.encode("utf-8")
    try:
        if dest.is_file() and dest.read_bytes() == data:
            return
    except OSError:
        pass
    # PER THREAD, not per process: `serve` seeds two runs' agents from two
    # threads of one pid, and a temp name keyed on the pid alone made both
    # stage into ONE file - the second `write_bytes` hit the first's open
    # handle, the fallback plain write hit a reader, and the PermissionError
    # the round-4 fix had removed came back from inside one process
    # (found by the suite under load, 2026-08-27).
    tmp = dest.with_name(
        f"{dest.name}.{os.getpid()}.{threading.get_ident()}.{next(_write_seq)}.tmp")
    try:
        tmp.write_bytes(data)
    except OSError:
        # cannot even stage it: a plain write, tolerated - the other writer
        # is writing the same bytes
        try:
            dest.write_bytes(data)
        except OSError:
            if not (dest.is_file() and dest.read_bytes() == data):
                raise
        return
    for attempt in range(10):
        try:
            os.replace(tmp, dest)
            return
        except PermissionError:
            # a READER holds it too, on Windows - a concurrent launch's own
            # bytes-match check above is one
            time.sleep(0.05 * (attempt + 1))
        except OSError:
            break
    try:
        tmp.unlink()
    except OSError:
        pass
    if not dest.is_file():
        try:
            dest.write_bytes(data)     # nobody else wrote it after all
        except OSError:
            if not (dest.is_file() and dest.read_bytes() == data):
                raise


def ensure_agent_workspace(
    role: str,
    target: Path,
    force: bool = False,
    domain_skills_dirs: list[Path] | None = None,
    workspace_code: str | None = None,
) -> None:
    """Materialize a Iobot-style agent workspace into `target`.

    Copies SOUL.md, AGENTS.md, TOOLS.md, USER.md, HEARTBEAT.md, skills/,
    and memory/ from the bundled templates.

    When *force* is False (default on first run): only copies files that
    don't already exist.  Safe for memory — never overwrites MEMORY.md.

    When *force* is True (``setup-agents --force``): overwrites identity
    and skill files with the latest bundled versions, but still preserves
    ``memory/`` to protect accumulated learnings.

    *domain_skills_dirs* — optional list of directories containing shared
    domain skill subdirectories to copy into target/skills/. Each directory
    is expected to contain <skill_name>/ subdirectories (same layout as
    agents/_common/skills/). Use this to inject shared procurement skills
    into specific agent workspaces without auto-detecting from SOUL.md.
    Caller decides explicitly which agents receive which domain skills.

    *workspace_code* — which tenant's DB content to hydrate from. Solution
    agents pass the tenant code so a tenant's own edits win; PLATFORM-SHARED
    roles are forced to ``default`` (see :data:`PLATFORM_SHARED_ROLES`), which
    is what keeps one Jarvis identity across every tenant while each tenant
    keeps its own ``memory/`` — hydration preserves those directories.
    """
    target.mkdir(parents=True, exist_ok=True)

    # Platform-shared roles are framework-owned and identical everywhere, so
    # they always hydrate from the canonical platform-tier row even inside a
    # tenant home. Without this a tenant copy would be seeded once from the
    # pack and then never track platform edits (files that already exist are
    # skipped when force=False — see the copy loop below).
    #
    # For everyone else the SOURCE row must match the TARGET home. When no
    # code is passed we resolve the selected workspace — the same signal
    # iobot_agent_workspace() already uses to pick the target. Without
    # this, callers that don't thread a code (run-step's
    # ensure_iobot_agent) would hydrate a TENANT home from another
    # workspace's row and silently overwrite the tenant's own agent content
    # — observed once with the old 'default' fallback: a scoped run rebuilt
    # the tenant SOUL.md from default and stamped it provenance=db. There is
    # no fallback: with nothing selected this raises WorkspaceNotSelected.
    if role in PLATFORM_SHARED_ROLES:
        hydrate_ws = PLATFORM_TIER
    else:
        hydrate_ws = workspace_code or resolved_workspace_code()

    # THE PACK IS THE TRUTH (docs/one-truth-content-model.md s3.4). The
    # installed pack's template for this role is resolved FIRST - excluding
    # the destination itself, so a home can never seed from its own copy -
    # and its identity files (SOUL, TOOLS, skills/) are re-read from it on
    # EVERY call. There is no "existing file wins" gate any more: that gate
    # is why an SDK edit reached a home only under `--force`, and why a
    # workspace here carried July's skills through two weeks of source edits.
    # A checkout is never cached; a wheel is immutable so re-copying it is
    # merely cheap. `memory/` is excluded below and is never touched.
    #
    # Only an agent that NO installed pack provides - Studio-authored, until
    # drafts replace that path - hydrates from the database, and says so.
    _hydrated = False
    _rebuilt = False
    _action = "not-attempted"
    src = _role_workspace(role, exclude=target)
    if src is not None:
        refresh = True
    else:
        try:
            from ioagentfarm.engine.hydration import hydrate_agent
            _action = hydrate_agent(role, target=target, workspace_code=hydrate_ws)
            _hydrated = _action in ("materialized", "noop")
            # "materialized" = the tree was just REPLACED from the DB row.
            # Shared skills are absent afterwards because the DB does not
            # store pack content - the seed below replays the recorded
            # assignment on that signal instead of guessing.
            _rebuilt = _action == "materialized"
        except Exception:
            _action = "raised"
            logger.debug("agent hydration skipped for %s", role, exc_info=True)
        if _hydrated:
            logger.warning(
                "agent %r is UNPROMOTED content (no installed pack provides it; "
                "materialised from the %s workspace's database row) - promote it "
                "into a pack to make it real", role, hydrate_ws)
        # The live copy is the only template an unpromoted agent has.
        refresh = force
        if (target / "SOUL.md").is_file():
            src = target
    if src is None:
        if _hydrated and (target / "SOUL.md").is_file():
            _generate_agents_md(target, role)
            return
        # An agent with no pack template (Studio-created, or imported from a
        # solution repo) exists ONLY as a DB row, so hydration is the whole
        # supply. Saying "template not found" sends the reader looking for a
        # missing directory when the real answer is almost always in the two
        # facts below — which of the two preconditions failed, and what the
        # hydrator actually returned ('no-db' = no row for this workspace_code,
        # 'locked' = another process is mid-hydrate, 'disabled' = IOF_HYDRATION
        # is off, 'error' = the row is unusable or the DB is unreachable).
        # NAME THE FIX, not just the diagnosis. `no-db` on a tenant is
        # overwhelmingly one thing: the workspace was never imported. In the
        # FLAT layout that is not merely how content is shared — it is a
        # PREREQUISITE OF THE FIRST RUN, because the repo packages only its
        # CLI tools, so no agent template ships and the database is the whole
        # supply. The old message named a missing directory, which sent the
        # reader looking for a folder instead of running one command.
        from ioagentfarm.packs import install_hint
        try:   # leave no empty workspace behind for `list-agents` to advertise
            if target.is_dir() and not any(target.iterdir()):
                target.rmdir()
            # AND THE HOME ABOVE IT. Removing only `<role>/workspace/` left
            # `<role>/` standing, so every refused request created a directory
            # that nothing ever cleans up — and the chat endpoint refuses an
            # unknown agent with 400, so an unauthenticated caller sending
            # random role names grew the filesystem one directory per request.
            # Found by an independent validator, who noticed the leftover after
            # a refusal the walkthrough tells the reader to make.
            home = target.parent
            if home.is_dir() and not any(home.iterdir()):
                home.rmdir()
        except OSError:
            pass
        logger.debug("ensure_agent_workspace(%s): hydrate_agent -> %r, SOUL.md present=%s, target=%s",
                     role, _action, (target / 'SOUL.md').is_file(), target)
        # A PACK THAT FAILED TO LOAD LOOKS EXACTLY LIKE A PACK THAT DOES NOT
        # SHIP THIS AGENT, and the two need opposite actions. Consult the
        # record before blaming the install: a client was told to install a
        # pack they had installed correctly, whose own failure message had
        # scrolled off the screen.
        try:
            from ioagentfarm.packs import broken_packs
            _broken = broken_packs()
        except Exception:  # noqa: BLE001 - diagnosis must never mask the error
            _broken = {}
        _lead = ""
        if _broken:
            _names = ", ".join(sorted(repr(n) for n in _broken))
            _why = "; ".join(f"{n}: {r}" for n, r in sorted(_broken.items()))
            _lead = (
                f"{len(_broken)} installed pack(s) FAILED TO LOAD, so nothing "
                f"they ship is available and this agent may well exist - "
                f"{_names}. FIX THAT FIRST: reinstalling on the assumption "
                f"the agent is missing will not help, and `aicore "
                f"list-agents` will not show it either. Reason - {_why}. "
                f"Then, if it is still not found: ")
        # ADDITIVE ONLY. Suppressing the "install the pack" clause when a
        # pack is broken made this message depend on process-global state -
        # one unrelated broken pack rewrote the error for every genuinely
        # misspelled role, and in a test suite whichever file ran first
        # decided what a later file's error said. The lead above already
        # says reinstalling will not help; that is enough, and it costs no
        # coupling.
        raise FileNotFoundError(
            f"{_lead}"
            f"No installed pack provides an agent named {role!r}, and the "
            f"{hydrate_ws!r} workspace has no unpromoted copy of it either. "
            f"Install the pack that ships this agent into THIS environment, "
            f"or check the role name against `aicore list-agents`. "
            f"(Diagnostic: hydration reported {_action!r}.)"
            + install_hint())

    # Collect bundled file paths for stale-file cleanup when force=True.
    bundled_rels: set[str] = set()

    # Paths under memory/ are NEVER overwritten — they contain accumulated
    # learnings that compound across runs.
    for item in src.rglob("*"):
        if item.is_dir():
            continue
        rel = item.relative_to(src)
        # Skip __pycache__ and compiled/binary files
        if "__pycache__" in rel.parts or rel.suffix in (".pyc", ".pyo", ".exe", ".dll", ".so"):
            continue
        bundled_rels.add(str(rel))
        dest = target / rel
        dest.parent.mkdir(parents=True, exist_ok=True)

        # Never overwrite memory files (learnings persist across runs)
        is_memory = rel.parts[0] == "memory" if rel.parts else False
        # ...and ALWAYS refresh the declaration. Every other identity file is
        # copied once and then owned by the workspace, which is right for a
        # SOUL. It is wrong here: `assign-skill` edits the file in the REPO, so
        # a stale copy in the agent home would make the next `setup-agents`
        # do nothing at all and report success — the silent no-op the
        # declaration exists to remove. The template is the author's copy.
        if dest.exists() and str(rel) != DECLARED_SKILLS_FILE \
                and (not refresh or is_memory):
            continue
        _write_shared(dest, item.read_text(encoding="utf-8"))

    # Place the shared skills (pack skill-sources + legacy _common/skills) this
    # agent is ASSIGNED. No eligibility check — see the module note on
    # :data:`SKILL_ASSIGNMENT_MARKER`.
    #
    # THE DURABLE RECORD IS `studio_skills`, one table for every tier: a shared
    # skill gets an assignment-only row (origin='pack', no content — the wheel
    # stays the content). That is what reaches a pod whose only state is the
    # database, and what lets the Studio answer "which agents have this skill?"
    # with one SELECT instead of a walk over every agent.
    #
    # The MARKER is not a second record; it is the per-ROLE "already derived"
    # flag, and the fallback when there is no database at all. It has to be
    # per role: the rows are per WORKSPACE, so "this workspace has pack rows"
    # is true the moment the FIRST agent is seeded, and every agent seeded
    # after it would read an empty assignment and be stripped. (`_seed_tenant_
    # agents` seeds every bundled agent in one loop, so that is the common
    # case, not a corner.)
    #
    #  * NOT DERIVED YET (no marker) -> derive once from the legacy `roles:`
    #    frontmatter. The migration, and the only remaining reader of `roles:`;
    #    without it every agent alive today silently loses the skills it holds
    #    purely because of that rule.
    #  * DERIVED, and the tree was just REBUILT from the DB -> shared skills
    #    are absent by design, not by removal, so place what the RECORD names:
    #    the rows, or the marker if the DB is unreachable. The fresh-pod path.
    #  * DERIVED, workspace genuinely present -> DISK is the truth and a
    #    removal sticks.
    _db_code = hydrate_ws
    record = read_skill_assignment(target)
    assigned = None
    if record is not None and _rebuilt:
        assigned = set(record)
        try:
            from ioagentfarm.engine.hydration import pack_assignment
            from_db = pack_assignment(_db_code, role)
            if from_db is not None:
                assigned = from_db
        except Exception:
            logger.debug("pack assignment lookup failed for %s", role,
                         exc_info=True)
    for common_skills in _shared_skill_dirs():
        for skill_dir in common_skills.iterdir():
            if not skill_dir.is_dir():
                continue
            # AN AGENT-LOCAL SKILL OUTRANKS A SHARED ONE OF THE SAME NAME - the
            # designed override tier inside one pack (see _resolve_skill).
            # Now that identity is refreshed on every call, this loop would
            # otherwise re-copy the wheel's copy OVER the template's agent-
            # local copy just written above (found by the v2 test rework:
            # home and filtered workspace both ended up with the shared
            # version). The template is the truth for that name; skip it.
            if src is not None and src != target and (src / "skills" / skill_dir.name).is_dir():
                continue
            if assigned is not None:
                if skill_dir.name not in assigned:
                    continue
            elif not (target / "skills" / skill_dir.name).is_dir():
                if record is not None:
                    continue      # the record exists and disk says removed
                if not _default_assignment(skill_dir, role):
                    continue
            # NOTE (2026-07-27 fix): this copy block was previously dedented
            # out of the rglob loop — leaked loop vars meant only the LAST
            # file of each shared skill directory was ever copied.
            for item in skill_dir.rglob("*"):
                if item.is_dir():
                    continue
                rel = Path("skills") / skill_dir.name / item.relative_to(skill_dir)
                if "__pycache__" in rel.parts or rel.suffix in (".pyc", ".pyo"):
                    continue
                bundled_rels.add(str(rel))
                dest = target / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                if dest.exists() and not refresh:
                    continue
                dest.write_text(item.read_text(encoding="utf-8"), encoding="utf-8")

    # DECLARED CARRIAGE (see :data:`DECLARED_SKILLS_FILE`). Placed exactly like
    # the template's own `skills/` tree — unconditionally, from the resolved
    # source — because that is precisely what the declaration is a substitute
    # FOR: one copy in the pack, N agents holding its name. So it behaves the
    # way a physically-copied repo skill already behaves, including the part
    # nobody loves: delete the directory from a live workspace and the next
    # seed puts it back, because the repo still says the agent carries it.
    #
    # Runs BEFORE the record is reconciled, so a declared skill is on disk by
    # the time `record_skill_assignment` looks — it then lands in the generated
    # record and in `studio_skills.roles_json` with no extra machinery, which
    # is what carries the declaration to a pod whose only state is the DB.
    # ROLL THE DECLARATION BACK WHEN IT IS THE THING THAT FAILED. By this
    # point the copy loop has already written the author's `skills.yaml` into
    # the seeded workspace, and the seeded copy is what this call reads. A
    # reader who corrects the name and re-runs was reported to hit the SAME
    # error, naming a string their files no longer contain -- so the fix is
    # made unconditional rather than dependent on which source the refresh
    # resolved: remove the copy, and the next seed cannot read a stale one.
    try:
        declared = resolve_declared_skills(target, role)
    except SkillDeclarationError:
        try:
            (target / DECLARED_SKILLS_FILE).unlink(missing_ok=True)
        except OSError:                     # pragma: no cover - defensive
            pass
        raise
    for _dname, _dsrc in declared.items():
        for item in _dsrc.rglob("*"):
            if item.is_dir():
                continue
            rel = Path("skills") / _dname / item.relative_to(_dsrc)
            if "__pycache__" in rel.parts or rel.suffix in (".pyc", ".pyo"):
                continue
            bundled_rels.add(str(rel))
            dest = target / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists() and not refresh:
                continue
            dest.write_text(item.read_text(encoding="utf-8"), encoding="utf-8")

    # UNASSIGNING HAS TO REACH THE WORKSPACE, or it is not a removal — it is a
    # repo edit that nothing acts on. The loop above this one re-places any
    # shared skill ALREADY on disk (disk is truth for it), so a name deleted
    # from the declaration keeps its materialised copy for ever, `--force`
    # included. An agent still carrying a skill its author removed is the same
    # silent divergence the declaration exists to prevent, pointing the other
    # way — and it is worse than the original, because the repo now says one
    # thing and the workspace does another.
    #
    # NARROW ON PURPOSE, and the first condition is what bounds it: only a
    # workspace that HAS a declaration is touched at all, so no agent alive
    # today changes behaviour. Within that, four things keep their skill: the
    # declaration itself, an explicit assignment from the database, the agent's
    # own template, and the pack's opening hand. What is left is exactly "this
    # workspace only has it because a declaration used to say so".
    if (target / DECLARED_SKILLS_FILE).is_file():
        protected = set(declared) | set(assigned or ())
        try:
            present = sorted(d for d in (target / "skills").iterdir()
                             if d.is_dir())
        except OSError:
            present = []
        for stale_dir in present:
            if stale_dir.name in protected \
                    or (src / "skills" / stale_dir.name).is_dir():
                continue
            source = None
            for shared_root in _resolvable_skill_dirs():
                try:
                    if (shared_root / stale_dir.name / "SKILL.md").is_file():
                        source = shared_root / stale_dir.name
                        break
                except (OSError, TypeError, NotADirectoryError):
                    continue
            if source is None or _default_assignment(source, role):
                continue
            shutil.rmtree(stale_dir, ignore_errors=True)
            logger.info("removed %s from role=%s: no longer declared in %s",
                        stale_dir.name, role, DECLARED_SKILLS_FILE)

    # Reconcile both records to what the workspace now actually carries. The
    # DB write is skipped when nothing moved — that keeps the steady state to
    # zero connections per seed, and `_seed_tenant_agents` runs this loop once
    # per bundled agent.
    #
    # THE ROW IS PER-WORKSPACE; `record` IS NOT. `.skills-assigned.json` lives
    # in the agent's workspace under `agent_home_root()`, which is one shared
    # tree unless IOF_AGENT_HOME is set per tenant — so "the disk record did
    # not move" says nothing about whether THIS workspace has the row. Seeding
    # the same agent into a second tenant found the record unchanged and wrote
    # nothing, and the tenant's catalog listed no shared skills at all. The
    # order that produced it is the obvious one:
    #
    #   assign-skill                → repo declares the skill
    #   setup-agents                → materialises it, writes the disk record,
    #                                 row lands under the ACTIVE workspace
    #   workspace push <tenant>   → re-seeds; record already matches,
    #                                 so the tenant's row was never written
    #
    # So the memo is keyed by (workspace, role) as well. Cost is one idempotent
    # write per pair per process rather than zero: a CLI invocation pays it
    # once per agent, a long-lived `serve` pays it once. That is the price of
    # the guard being able to answer the question it is actually asked.
    carried = record_skill_assignment(target, role)
    _memo_key = (os.getenv("IOF_DATABASE_URL", ""), _db_code or "", role)
    if (record is None or set(record) != set(carried)
            or _memo_key not in _PACK_ASSIGNMENT_RECONCILED):
        try:
            from ioagentfarm.engine.hydration import record_pack_assignment
            record_pack_assignment(_db_code, role, carried)
            _PACK_ASSIGNMENT_RECONCILED.add(_memo_key)
        except Exception:
            logger.debug("pack assignment record failed for %s", role,
                         exc_info=True)

    # Copy domain-specific shared skills (explicit caller-supplied dirs)
    # Each dir is expected to contain <skill_name>/SKILL.md subdirectories.
    if domain_skills_dirs:
        for domain_dir in domain_skills_dirs:
            if not domain_dir.is_dir():
                logger.warning("domain_skills_dir not found, skipping: %s", domain_dir)
                continue
            for item in domain_dir.rglob("*"):
                if item.is_dir():
                    continue
                rel = Path("skills") / item.relative_to(domain_dir)
                if "__pycache__" in rel.parts or rel.suffix in (".pyc", ".pyo"):
                    continue
                # Register injected files as bundled: the force=True stale-skill
                # cleanup below rmtree's any skills/<name>/ dir absent from
                # bundled_rels — without this line every `setup-agents --force`
                # copied the pack-injected skills (signal_brief, aria's four)
                # and then immediately deleted them as "stale"; workflows then
                # ran silently without them (create_filtered_workspace skips
                # missing skills without error).
                bundled_rels.add(str(rel))
                dest = target / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                if dest.exists() and not refresh:
                    continue
                dest.write_text(item.read_text(encoding="utf-8"), encoding="utf-8")

    # Generate AGENTS.md dynamically from all bundled agents (always overwrite)
    _generate_agents_md(target, role)

    # RE-APPLY HOST METADATA. `configure-agent` embeds a deployment's catalog
    # into skills/*/SKILL.md; the refresh above just rewrote those files from
    # the pack, so a one-shot embed would be gone by the next session. The
    # metadata/ dir is host state (like memory/) and survives; the embed is
    # re-derived from it here, deterministically. See engine/agent_metadata.
    try:
        from ioagentfarm.engine.agent_metadata import embed_metadata_into_skills
        embed_metadata_into_skills(target)
    except Exception:
        logger.debug("metadata re-embed skipped for %s", role, exc_info=True)

    # Withdraw skills the PLATFORM placed and has since removed.
    #
    # Two failures this replaces. (1) The cleanup ran only under `--force`, so
    # a skill deleted from the wheel stayed installed indefinitely: a role
    # carried `run_forensics` for weeks after it was deleted upstream, and the
    # replacement skill sat unread beside it. An upgrade that removes a skill
    # has to reach the home, or "upgrade" means "add only". (2) It deleted by
    # ABSENCE from `bundled_rels`, which is every skill the templates did not
    # supply — including hub-approved LEARNED skills, which arrive at run time
    # and are governed content, not template residue. Under `--force` those
    # were silently destroyed. The same shape already bit pack-injected skills
    # once (see the domain-skills loop above).
    #
    # So: withdraw by RECORD, not by absence. `_PLATFORM_SKILLS_FILE` lists
    # what the platform placed on the last seed; a name in that record which
    # this seed did not place is one the platform withdrew, and only those are
    # removed. Anything the platform never placed — learned, hub-approved,
    # user-authored, database-hydrated — is invisible to this loop by
    # construction, which is the property the `--force` version lacked.
    placed_now = _placed_skill_names(bundled_rels)
    _withdraw_removed_platform_skills(
        target, placed_now, protected=set(declared) | set(assigned or ()))
    _record_platform_skills(target, placed_now)

    # Stale FLAT skill files (the pre-<name>/SKILL.md layout) are residue of a
    # migration, never authored content, so absence from the templates is a
    # safe signal for them. Kept under --force.
    if force:
        skills_dir = target / "skills"
        if skills_dir.is_dir():
            for stale in skills_dir.iterdir():
                if stale.is_file():
                    rel_str = str(Path("skills") / stale.name)
                    if rel_str not in bundled_rels:
                        stale.unlink()
                        logger.debug("Removed stale skill file: %s", stale)


#: What the PLATFORM placed into an agent's ``skills/`` on the last seed.
#: Generated, not authored — the record that lets a later seed tell "the
#: platform withdrew this" from "something else put this here". Excluded from
#: the divergence hash for the same reason ``.skills-assigned.json`` is.
_PLATFORM_SKILLS_FILE = ".platform-skills.json"


def _placed_skill_names(bundled_rels: set[str]) -> set[str]:
    """Skill directory names this seed placed, from the copied-file record."""
    names: set[str] = set()
    for rel in bundled_rels:
        parts = Path(rel).parts
        if len(parts) >= 3 and parts[0] == "skills":
            names.add(parts[1])
    return names


def _read_platform_skills(target: Path) -> set[str] | None:
    """The previous seed's record, or None when there is none (first seed)."""
    path = target / _PLATFORM_SKILLS_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return set(data) if isinstance(data, list) else None


def _record_platform_skills(target: Path, placed: set[str]) -> None:
    try:
        (target / _PLATFORM_SKILLS_FILE).write_text(
            json.dumps(sorted(placed), indent=2), encoding="utf-8")
    except Exception:
        logger.debug("could not record platform skills for %s", target,
                     exc_info=True)


def _withdraw_removed_platform_skills(
    target: Path, placed_now: set[str], *, protected: set[str],
) -> list[str]:
    """Remove skills the platform placed before and did not place this time.

    Returns the names removed. A first seed (no record) removes nothing: with
    nothing to compare against, every skill would look withdrawn.
    """
    previous = _read_platform_skills(target)
    if previous is None:
        return []
    withdrawn = sorted(previous - placed_now - protected)
    removed: list[str] = []
    for name in withdrawn:
        skill_dir = target / "skills" / name
        if not skill_dir.is_dir():
            continue
        try:
            shutil.rmtree(skill_dir)
            removed.append(name)
            logger.info(
                "withdrew skill '%s' from %s: the platform no longer supplies "
                "it", name, target.name)
        except Exception:
            logger.debug("could not withdraw skill %s", name, exc_info=True)
    return removed


def _generate_agents_md(target: Path, current_role: str) -> None:
    """Generate AGENTS.md dynamically from all bundled agent SOUL.md files.

    Builds a team roster table so each agent knows who else is on the team.
    Overwrites the static AGENTS.md copied from the template.
    """
    names = _agent_names()
    if not names:
        return

    # Role descriptions (extracted from SOUL.md patterns or defaults)
    role_desc = {
        "project_lead": "Orchestrates workflows, drives pipelines, signs off",
        "analyst": "Investigates, analyzes data, detects signals and barriers",
        "strategist": "Master strategist — evaluates options, simulates outcomes, composes playbook strategies",
        "developer": "Implements code changes, pragmatic, minimal diffs",
        "reviewer": "Tests, reviews, validates, enterprise quality gates",
        "data_analyst": "SQL queries, data analysis, database exploration",
        "cora": "Core Assistant — user-facing gateway, delegates to the team",
    }

    lines = [
        "# AGENTS\n",
        "You are part of a multi-agent team. You do not do other agents' work — you delegate.\n",
        "## The team\n",
        "| Name | Role | Strength |",
        "|------|------|----------|",
    ]
    for role in sorted(names.keys()):
        if role == current_role:
            continue  # Don't list yourself
        name = names[role]
        desc = role_desc.get(role, role.replace("_", " ").title())
        lines.append(f"| **{name}** | `{role}` | {desc} |")

    lines.append("")
    agents_md = target / "AGENTS.md"
    agents_md.write_text("\n".join(lines), encoding="utf-8")
    logger.debug("Generated AGENTS.md for role=%s with %d team members", current_role, len(names) - 1)


def _read_agent_memory(role: str) -> str:
    """Read accumulated learnings from an agent's iobot workspace.

    Checks two locations in priority order:
    1. Per-agent iobot workspace: ~/.iobot/agents/<role>/workspace/memory/MEMORY.md
    2. Bundled seed memory: ioagentfarm/agents/<role>/workspace/memory/MEMORY.md

    This is the single source of truth for agent memory.  iobot's ContextBuilder
    also reads from the same workspace path, so memory is shared between the
    orchestrator (for prompt building) and the runtime (for native context).

    Returns empty string if no memory file exists.
    """
    # 1. Per-agent iobot workspace (primary — iobot's ContextBuilder reads this too)
    ws_memory = iobot_agent_workspace(role) / "memory" / "MEMORY.md"
    if ws_memory.exists():
        content = ws_memory.read_text(encoding="utf-8").strip()
        if content:
            return content

    # 2. Bundled seed memory (fallback for first-ever run)
    ws = _role_workspace(role)
    if ws is not None:
        src = ws / "memory" / "MEMORY.md"
        try:
            content = src.read_text(encoding="utf-8").strip()
            if content:
                return content
        except (FileNotFoundError, TypeError):
            pass

    return ""


def persist_agent_memory(
    role: str, step_workspace: Path, *, learning_disabled: bool = False,
) -> bool:
    """Copy agent's memory/MEMORY.md from step workspace to the agent's iobot workspace.

    Called after step completion (both scheduler and CLI step-complete paths).
    Merges new learnings into ~/.iobot/agents/<role>/workspace/memory/MEMORY.md —
    the same path iobot's ContextBuilder reads from.  This ensures learnings
    from every run are available to both the orchestrator and the runtime natively.

    When *learning_disabled* is True (workflow has ``learning: disabled``),
    skip persistence entirely — don't pollute the persistent workspace with
    stale observations that would mislead future runs with different data.

    Returns True if new memory was persisted.
    """
    if learning_disabled:
        logger.info("Learning disabled — skipping memory persist for role=%s", role)
        return False

    step_memory = step_workspace / "memory" / "MEMORY.md"
    if not step_memory.exists():
        return False

    new_content = step_memory.read_text(encoding="utf-8").strip()
    if not new_content:
        return False

    # Persistent memory location: agent's iobot workspace
    persistent_dir = iobot_agent_workspace(role) / "memory"
    persistent_dir.mkdir(parents=True, exist_ok=True)
    persistent_file = persistent_dir / "MEMORY.md"

    if persistent_file.exists():
        existing = persistent_file.read_text(encoding="utf-8").strip()
        if existing == new_content:
            return False  # No change
        # If the new content already contains the existing content, it's a full rewrite.
        # Otherwise, append the new content.
        if existing in new_content:
            persistent_file.write_text(new_content + "\n", encoding="utf-8")
        else:
            merged = existing + "\n\n" + new_content
            persistent_file.write_text(merged + "\n", encoding="utf-8")
    else:
        persistent_file.write_text(new_content + "\n", encoding="utf-8")

    # Enforce size cap — prevent unbounded memory growth
    enforce_memory_cap(persistent_file)

    logger.debug("Persisted memory for role=%s to %s", role, persistent_file)
    return True


def _catalog_workspace_codes() -> list[str]:
    """Workspace codes to search for a DB-catalogued skill, in order.

    The active tenant first, then the platform tier. Both, because a
    platform-shared agent (the Core Assistant) runs inside a tenant home
    while its canonical definition — and anything the platform installed
    alongside it — lives on the platform tier.
    """
    code = os.getenv("IOF_WORKSPACE", "").strip()
    codes = [code] if code and code not in RETIRED_WORKSPACE_CODES else []
    codes.append(PLATFORM_TIER)
    return codes


def _copy_skill_tree(src_dir: Path, dst_dir: Path) -> None:
    """Copy a skill package, leaving anything already present alone.

    ``dirs_exist_ok`` + no overwrite: the first source to provide a file wins,
    which is what makes the resolution order below actually an ORDER rather
    than a last-writer race.
    """
    for item in src_dir.rglob("*"):
        if item.is_dir() or "__pycache__" in item.parts:
            continue
        dest = dst_dir / item.relative_to(src_dir)
        if dest.exists():
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(item), str(dest))


def _resolve_skill(name: str, skills_src: Path, skills_dst: Path) -> str | None:
    """Materialize one named skill into *skills_dst*. Returns WHERE it came
    from (for the log), or ``None`` when no source has it.

    Resolution order (docs/one-truth-content-model.md): the installed pack
    is the truth; the database only ADDS what no pack provides.

    1. **The agent's own workspace.** Refreshed from the pack template on
       every use, so this is the pack's agent-LOCAL copy of a skill - and an
       agent-local skill deliberately outranks a shared skill of the same
       name (the designed override tier inside one pack).
    2. **The pack / SDK skill sources** (``_shared_skill_dirs()``). The
       shared wheel-shipped catalog every agent may draw on.
    3. **The workspace skill catalog** (``studio_skills``) - unpromoted,
       Studio-authored skills, until drafts replace that path. Add-only:
       it is consulted only for a name neither 1 nor 2 has, and logs that
       it did.

    Flat ``<name>.md`` skills are still honoured at step 1 — several agent
    workspaces predate the ``<name>/SKILL.md`` package layout.
    """
    # 1. the agent's own workspace (package dir and/or legacy flat .md)
    found = None
    src_file = skills_src / f"{name}.md"
    if src_file.is_file():
        shutil.copy2(str(src_file), str(skills_dst / f"{name}.md"))
        found = "agent workspace"
    src_dir = skills_src / name
    if src_dir.is_dir():
        _copy_skill_tree(src_dir, skills_dst / name)
        found = "agent workspace"
    if found:
        return found

    # 2. the pack / SDK shared skill sources - THE TRUTH for a shared name
    for shared in _shared_skill_dirs():
        cand = shared / name
        try:
            if not cand.is_dir():
                continue
        except OSError:
            continue
        _copy_skill_tree(cand, skills_dst / name)
        return f"pack source ({shared})"

    # 3. the workspace skill catalog (studio_skills) - ADD-ONLY and loud.
    # Consulted only when neither the agent's own tree nor any installed
    # pack has the name: an unpromoted, Studio-authored skill, until drafts
    # replace that path. It can never shadow a pack skill (steps 1-2 ran).
    try:
        from ioagentfarm.engine.hydration import workspace_skill
        from ioagentfarm.engine.filecodec import write_file
        files = workspace_skill(name, _catalog_workspace_codes())
    except Exception:
        logger.debug("catalog lookup failed for skill %r", name, exc_info=True)
        files = None
    if files:
        for rel, content in files.items():
            rp = Path(rel)
            if rp.is_absolute() or ".." in rp.parts:
                continue
            write_file(skills_dst / name / rp, content)
        logger.warning(
            "skill %r is UNPROMOTED content (no installed pack provides it; "
            "materialised from the workspace catalog) - promote it into a "
            "pack to make it real", name)
        return "workspace catalog (unpromoted)"

    return None


def create_filtered_workspace(
    role: str,
    skills: list[str] | None,
    run_id: str,
    root_path: Path,
) -> Path:
    """Create a workspace with only specified skills for a workflow invocation.

    Copies identity files and memory from the real agent workspace.
    Only includes the named skills plus ``output_protocol`` (always required).
    ``skills=None`` means "every skill dir of the refreshed home" — the
    role's whole baseline, used by DRAFT runs whose role declares no filter
    (an unfiltered role skips this function entirely on an ordinary run, but
    a draft run must always come through here so the author's overlay lands).
    Returns the filtered workspace path.
    """
    real_ws = iobot_agent_workspace(role)
    filtered_ws = root_path / "instances" / run_id / "workspaces" / role

    # EXISTS is not COMPLETE, and the difference is not cosmetic. This used to
    # return on existence alone, which is how a run shipped an agent with no
    # identity at all: the directory gets created here, but if the agent home
    # is not hydrated yet the copy below finds no SOUL.md and copies nothing —
    # and iobot, launched later with --workspace pointing at this directory,
    # silently scaffolds its OWN stock SOUL ("I am iobot, a personal AI
    # assistant") into the gap. Observed in run_20260802_071739_670307: the
    # reviewer executed as that default persona and returned a plausible
    # review, because the step prompt carried the instructions. Correct-looking
    # output from a wrong identity is the worst shape this can fail in, so
    # re-entering must REPAIR rather than skip. Gate on the identity file the
    # scaffolder would otherwise supply.
    if (filtered_ws / "SOUL.md").is_file():
        return filtered_ws  # already complete for this run

    # Materialize-on-use pull point: run/task spawn. Refresh the live
    # workspace from its DB row (no-op when the sync key matches; fail-open).
    # Same source-matches-target rule as ensure_agent_workspace: real_ws is
    # IOF_AGENT_HOME-resolved, so the row must be the tenant's unless the role
    # is platform-shared. Resolved OUTSIDE the try because the fail-closed
    # identity check below names it, and an unbound local there would turn a
    # clear diagnostic into a NameError.
    _ws_code = (PLATFORM_TIER if role in PLATFORM_SHARED_ROLES
                else resolved_workspace_code())
    # Every spawn re-reads the agent's identity from the installed pack (a
    # checkout is never cached - docs/one-truth-content-model.md s3.4), so a
    # SOUL or skill edited between two runs is what the next run gets. Fail
    # open here; the SOUL.md check below is the fail-closed gate and names
    # the failure better than a stack trace from this call would.
    try:
        ensure_agent_workspace(role, real_ws, workspace_code=_ws_code)
    except Exception:
        logger.debug("agent home refresh skipped for %s", role, exc_info=True)

    # A DRAFT run resolves "pack + this author's overlay". The record travels
    # with the instance dir (drafts.json) because this function also runs in
    # a spawned run-step subprocess, where the creating request's fields are
    # long gone. None for every ordinary run — nothing below then changes.
    from ioagentfarm.engine.draft_runs import load_run_drafts
    _run_drafts = load_run_drafts(root_path, run_id)

    filtered_ws.mkdir(parents=True, exist_ok=True)

    # Copy identity files
    for fname in ("SOUL.md", "AGENTS.md", "TOOLS.md", "USER.md", "HEARTBEAT.md", "team.md"):
        src = real_ws / fname
        if src.exists():
            shutil.copy2(str(src), str(filtered_ws / fname))

    # The author's agent draft, BETWEEN the identity copy and the SOUL check
    # on purpose: a role only the draft introduces has nothing to copy above,
    # and the overlay is what supplies its SOUL.md — applied any later, the
    # fail-closed check below would refuse the very run meant to try it.
    if _run_drafts is not None:
        _run_drafts.apply_agent_overlay(filtered_ws, role)

    # Fail CLOSED on a missing identity. Handing iobot a workspace with no
    # SOUL.md is not a degraded run, it is a different agent: the runtime
    # scaffolds its stock persona and the step proceeds looking healthy. A
    # named failure here costs one retry (and the harness is built to absorb
    # that); the silent version costs the persona someone authored, with no
    # signal anywhere that it happened.
    if not (filtered_ws / "SOUL.md").is_file():
        raise FileNotFoundError(
            f"no SOUL.md for role={role} after hydration — refusing to run it "
            f"with the runtime's default persona. The agent home "
            f"({real_ws}) has no identity to copy: check that the role has a "
            f"row for workspace {_ws_code!r}, or that its pack is installed "
            f"in THIS environment.")

    # Copy memory directory — or start blank if learning is disabled.
    # Check for a learning: disabled flag in the workflow snapshot. The same
    # raw read also carries a compiled SWARM's roster markers (`agents:`),
    # consumed further down when the external-agent catalog materializes —
    # the loader ignores those keys, so the raw snapshot is their only
    # carrier.
    _learning_disabled = False
    _roster_agents = None
    _wf_name = None
    try:
        import yaml as _yaml
        wf_yaml = root_path / "instances" / run_id / "workflow" / "workflow.yaml"
        if wf_yaml.exists():
            wf_data = _yaml.safe_load(wf_yaml.read_text(encoding="utf-8")) or {}
            _wf_name = wf_data.get("name") or None
            _learning_disabled = str(wf_data.get("learning", "")).lower() in ("disabled", "false", "off")
            if isinstance(wf_data.get("agents"), list):
                _roster_agents = [str(a) for a in wf_data["agents"]]
    except Exception:
        # Fail CLOSED on the catalog. The roster is a capability CONTROL
        # ("these agents and nothing else"), and a control must narrow on
        # failure, never widen: leaving the roster None here would hand a
        # swarm whose snapshot went unreadable the FULL registry - every
        # registered agent - which is the leak, warned or not. An empty
        # roster is the safe degradation: consults fail loudly ("no agents
        # in catalog") instead of silently reaching agents the swarm was
        # never granted. The cost to a workflow run is nil in practice - a
        # snapshot exists for every run from creation, so an unreadable one
        # fails the run at the scheduler's own read regardless. (A MISSING
        # file takes the normal path above and keeps None - that is the
        # no-marker-carrier case, not a corrupt control.)
        _roster_agents = []
        logger.warning(
            "could not read run %s's snapshot for learning/roster markers - "
            "external-agent catalog fails CLOSED (zero external agents this "
            "run) and learning stays on. Fix the snapshot under "
            "instances/%s/workflow/ and retry the step.",
            run_id, run_id, exc_info=True)

    from ioagentfarm.engine.learning.hooks import memory_paused as _memory_paused
    mem_dst = filtered_ws / "memory"
    if _learning_disabled or _memory_paused():
        # Start with blank memory — no stale observations from prior runs.
        # Under v2 (memory_paused) the runtime-level patch already returns
        # empty memory context, but not copying the stale tree at all is
        # cheaper and keeps the run workspace honest about what the agent
        # actually received. The agent HOME's memory is untouched.
        mem_dst.mkdir(parents=True, exist_ok=True)
        (mem_dst / "MEMORY.md").write_text(
            "# Memory\n\nClean slate — learning disabled for this workflow.\n"
            if _learning_disabled else
            "# Memory\n\nClean slate — learning v2 owns learning; v1 memory "
            "is not loaded.\n",
            encoding="utf-8",
        )
        logger.info("v1 memory not copied (%s) — blank MEMORY.md",
                    "workflow opt-out" if _learning_disabled else "learning v2 active")
    else:
        mem_src = real_ws / "memory"
        if mem_src.exists() and not mem_dst.exists():
            shutil.copytree(str(mem_src), str(mem_dst))

    # WORKSPACE MEMORY — the durable context every agent of this workspace
    # shares (engine/memory/). Materialized as memory/WORKSPACE_MEMORY.md,
    # which the runtime patch renders into the SYSTEM prompt's memory
    # section; the file is a per-run cache of the database. Distinct from
    # the v1 MEMORY.md above: that was one agent's accumulated conclusions,
    # this is the workspace's reviewed context. Best-effort, workspace-keyed.
    try:
        from ioagentfarm.engine.memory import hooks as _memory_hooks
        _memory_hooks.provision_step_workspace(
            root_path, filtered_ws, role=role, workspace_code=maybe_workspace_code(),
            solution=_memory_hooks.solution_for_workflow(_wf_name))
    except Exception:  # noqa: BLE001 - memory must never cost a run its workspace
        logger.debug("workspace memory not materialized for role=%s", role, exc_info=True)

    # Copy the skills this JOB needs, resolved from the whole workspace
    # catalog (always including output_protocol).
    #
    # SKILLS ARE OPEN. `skills:` used only to SUBTRACT: it copied from the
    # agent's own workspace, so a workflow could only ever narrow what the
    # agent already happened to carry, and naming anything else produced a
    # warning and silence. An agent's assigned skills are its BASELINE; the
    # step declares what the job needs, and a job may legitimately need a
    # skill this agent has never had (`presentation` for a reviewer asked to
    # produce a deck). See :func:`_resolve_skill` for the resolution order.
    skills_dst = filtered_ws / "skills"
    skills_dst.mkdir(exist_ok=True)
    skills_src = real_ws / "skills"

    # skills=None: the role declared no filter, so the job gets the agent's
    # whole baseline — every skill dir of the home just refreshed above.
    if skills is None:
        skills = sorted(
            d.name for d in skills_src.iterdir()
            if d.is_dir() and d.name != "reference"
            and (d / "SKILL.md").is_file()) if skills_src.is_dir() else []
    # A draft's carriage REPLACES the set (the overlay's _skills is the full
    # list) — an add-only merge would hide a skill REMOVAL in the very run
    # meant to try it.
    if _run_drafts is not None:
        skills = _run_drafts.skill_names(role, skills)

    required = set(skills)
    required.add("output_protocol")

    resolved: dict[str, str] = {}
    for skill_name in sorted(required):
        where = _resolve_skill(skill_name, skills_src, skills_dst)
        if where:
            resolved[skill_name] = where
        else:
            logger.warning(
                "workflow names skill '%s' for role '%s' but it is in no "
                "catalog source — the agent will run WITHOUT it. Searched: "
                "the agent's own workspace (%s), the workspace skill catalog "
                "(studio_skills for %s), and the pack/SDK skill sources (%s). "
                "Check the spelling, or that the pack providing it is "
                "installed in THIS environment.",
                skill_name, role, skills_src,
                ", ".join(_catalog_workspace_codes()),
                ", ".join(str(d) for d in _shared_skill_dirs()) or "none")

    # Copy shared reference data (e.g. skills/reference/ with CSV datasets)
    ref_src = skills_src / "reference"
    ref_dst = skills_dst / "reference"
    if ref_src.is_dir() and not ref_dst.exists():
        shutil.copytree(str(ref_src), str(ref_dst))

    # The author's skill drafts, AFTER base resolution on purpose:
    # _resolve_skill writes the pack's bytes into skills_dst, so an overlay
    # applied earlier would be clobbered by its own base.
    if _run_drafts is not None:
        _run_drafts.apply_skill_overlays(skills_dst, sorted(required))

    # Copy S3-pulled input_data into the filtered workspace so agents can access it.
    # input_data/ is populated once at run creation time by web/app.py's
    # pull_prefix call (only when IOF_STORAGE=s3). If the dir doesn't exist
    # (CLI runs, or web API without S3), this is a silent no-op and agents
    # fall through to iof-query's metadata_dir resolution against the frozen
    # workflow snapshot's metadata/data/ — which snapshot_workflow already
    # populated from the bundled package.
    input_data_src = root_path / "instances" / run_id / "input_data"
    if input_data_src.is_dir():
        input_data_dst = filtered_ws / "input_data"
        if not input_data_dst.exists():
            shutil.copytree(str(input_data_src), str(input_data_dst))
        logger.info("Copied input_data (%d files) to filtered workspace",
                     len(list(input_data_src.glob("*"))))

    # External A2A agents registered for this workspace (a2a-add) —
    # materialized as metadata/external_agents.yaml so an agent whose skill
    # set includes a2a_consult can route to them. A compiled SWARM's roster
    # (`agents:` in the raw snapshot, read above) SCOPES the catalog — the
    # meta-agent routes only against the agents its definition granted.
    # Fail-open: a broken registry file must not block the run; the skill
    # answers "no external agents configured" when the file is absent.
    try:
        from ioagentfarm.engine.a2a_registry import materialize_external_agents
        materialize_external_agents(filtered_ws, names=_roster_agents)
    except Exception:
        logger.warning("external-agents materialization failed for role=%s "
                       "run=%s", role, run_id, exc_info=True)

    logger.info(
        "Created filtered workspace for role=%s run=%s skills=%s at %s",
        role, run_id,
        ", ".join(f"{n}({resolved.get(n, 'MISSING')})" for n in sorted(required)),
        filtered_ws,
    )
    return filtered_ws


def build_spawn_prompt(
    role: str,
    step_prompt: str,
    output_path: str = "",
) -> str:
    """Build a full prompt with identity and learnings for engine-level spawns.

    Used by ``IobotRunner`` where the agent subprocess may not have
    ``--workspace`` pointing at the correct identity directory.  Prepends
    SOUL.md identity and MEMORY.md learnings directly into the prompt for
    redundancy.

    When *output_path* is empty (stdout mode), the agent prints to stdout
    and the scheduler captures the result.
    """
    # Read identity from bundled workspace
    identity = ""
    ws = _role_workspace(role)
    if ws is not None:
        try:
            identity = (ws / "SOUL.md").read_text(encoding="utf-8").strip()
        except (FileNotFoundError, TypeError):
            pass

    # Read accumulated learnings
    learnings = _read_agent_memory(role)

    sections = []
    if identity:
        sections.append(f"# Identity\n\n{identity}")
    if learnings:
        sections.append(f"# Learnings\n\n{learnings}")
    sections.append(f"# Task\n\n{step_prompt}")

    if output_path:
        sections.append(
            f"# Output requirements\n\n"
            f"Write your complete output to this file: {output_path}\n"
            f"(the only OUTPUT.md the orchestrator reads - if the task names "
            f"another location for it, write it here anyway)\n\n"
            f"Your output MUST follow this exact format:\n"
            f"STATUS: done|failed\n"
            f"OUTPUT: <your detailed result>"
        )
    else:
        sections.append(
            "# Output requirements\n\n"
            "Print your output to stdout. Your output MUST follow this exact format:\n"
            "STATUS: done|failed\n"
            "OUTPUT: <your detailed result>"
        )

    return "\n\n".join(sections)


def build_task_prompt(
    step_prompt: str,
    output_path: str,
    project_dir: str = "",
    output_dir: str = "",
) -> str:
    """Compose a thin task prompt for agent execution.

    Does NOT include agent identity or memory because _invoke_agent() sets
    IOBOT_WORKSPACE, allowing iobot to load SOUL.md, MEMORY.md, and
    skills natively.

    Two directories:
        project_dir — source/input directory (existing code, metadata). Read from here.
        output_dir  — run-scoped output directory. Write all artifacts here.
                      Your cwd is set to this directory.

    If output_dir is not provided, falls back to project_dir for both
    (backward compat for ad-hoc tasks via run_task).

    Args:
        step_prompt: The fully-rendered step prompt from render_step_prompt().
        output_path: Absolute path where the agent must write OUTPUT.txt.
        project_dir: Absolute path to the source project directory (read-only context).
        output_dir: Absolute path to the run-scoped output directory (write here).

    Returns:
        Complete task prompt with instructions and output contract.
    """
    working_dir_section = ""
    if output_dir:
        working_dir_section = (
            f"\n# Working directories\n\n"
            f"**Source directory (READ):** {project_dir}\n"
            f"Existing code and input files are here. Use absolute paths to read from this directory.\n\n"
            f"**Output directory (WRITE):** {output_dir}\n"
            f"Write ALL deliverable artifacts (code, CSV, reports, etc.) to this directory.\n"
            f"Your current working directory is set to the output directory — relative paths write here.\n"
        )
    elif project_dir:
        working_dir_section = (
            f"\n# Working directory\n\n"
            f"Your project directory is: {project_dir}\n"
            f"All input files are in this directory.\n"
            f"Write ALL deliverable artifacts (code, CSV, reports, etc.) to this directory.\n"
            f"Use absolute paths or write relative to the current directory (which is set to the project directory).\n"
        )

    return f"""# Task

{step_prompt}
{working_dir_section}
# Output destination

Write your complete output to this file: {output_path}

This path is the only OUTPUT.md the orchestrator reads. If the task above
names another location for OUTPUT.md, write it HERE anyway: deliverables go
in the artifact directory, OUTPUT.md does not. (Two of 120 fleet-soak runs
failed on exactly this: the agent merged the two locations into a third path
nobody reads.)

The file MUST start with these two lines (the orchestrator parses them):
STATUS: done
OUTPUT: <your detailed result here>

Write the output file BEFORE you finish."""


