"""Orchestration & recovery CLI commands for ioagentfarm.

Extracted from cli.py to keep the main CLI focused on setup, context,
execution, tasks, and status.  These commands deal with the step-level
pipeline: creating runs, claiming steps, recording output, and recovery.

All commands are registered onto the main Typer app via ``register_commands()``.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from ioagentfarm.engine.workspaces import get_agent_name

from ioagentfarm.engine.workflow_loader import WorkflowLoader
from ioagentfarm.engine.scheduler import render_step_prompt
from ioagentfarm.engine.workspaces import (
    build_task_prompt,
    create_filtered_workspace,
    ensure_iobot_agent,
    iobot_agent_workspace,
    persist_agent_memory,
)
from ioagentfarm.engine.protocol import parse_key_value_protocol
from ioagentfarm.engine.progress import build_progress_markdown

logger = logging.getLogger(__name__)
console = Console()
#: For commands whose STDOUT is consumed by another program (`agent-chat`:
#: the reply, read by Jarvis via exec) - context and notes go here. `stderr=True`
#: with no file resolves `sys.stderr` at each write, so a stream swapped in by
#: a test runner or a redirect is honoured.
_stderr_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Noise filter — suppress iobot framework lines from messages table
# ---------------------------------------------------------------------------

# Prefixes that indicate framework noise (not agent content)
_NOISE_PREFIXES = (
    "Using config:",
    "Hint: Detected deprecated",
    "`memoryWindow`",
    "Created memory\\",
    "Created memory/",
    "Exception ignored",
    "Traceback (most recent call last):",
    "File \"",
    "_warn(",
    "info.append(",
)

# Substrings that indicate framework noise anywhere in the line
_NOISE_CONTAINS = (
    "(io) iobot",         # runtime header/footer
    "iobot is thinking",  # v0.1.5 Rich spinner
    "\\config.json",         # config path fragment
    "/config.json",
    "proactor_events.py",   # asyncio noise
    "ResourceWarning",
)

# Lines that are purely decorative (Rich formatting)
_NOISE_CHARS = set("─│┌┐└┘├┤┬┴┼═║╔╗╚╝╠╣╦╩╬ ─")


def _is_noise(line: str) -> bool:
    """Return True if the line is iobot/framework noise, not agent content."""
    if any(line.startswith(p) for p in _NOISE_PREFIXES):
        return True
    if any(s in line for s in _NOISE_CONTAINS):
        return True
    # Pure separator lines (Rich box-drawing characters only)
    if line and all(c in _NOISE_CHARS for c in line):
        return True
    return False


# ---------------------------------------------------------------------------
# Copy deliverable artifacts from agent workspace to project directory
# ---------------------------------------------------------------------------


def _snapshot_workspace(workspace: Path) -> set[str]:
    """Return set of relative paths for all files in workspace."""
    if not workspace or not workspace.is_dir():
        return set()
    return {str(f.relative_to(workspace)) for f in workspace.rglob("*") if f.is_file()}


def _collect_artifacts(
    workspace: Path, project_dir: Path, before_snapshot: set[str],
) -> list[Path]:
    """Copy agent-created deliverables from workspace to project_dir.

    Uses an allowlist approach: only files with recognized deliverable
    extensions are copied.  This avoids a cat-and-mouse game with iobot
    internal files (.git/, .cursor, sessions/, etc.) that changes across
    iobot versions.

    Returns list of copied destination paths.
    """
    copied: list[Path] = []
    if not workspace or not project_dir or not workspace.is_dir():
        return copied

    # Allowlist: only these extensions are deliverable artifacts.
    # Anything else (git objects, cursors, pyc, jsonl, etc.) is ignored.
    _ALLOW_EXTS = {
        # Documents / reports
        ".md", ".txt", ".html", ".htm", ".mhtml", ".pdf", ".docx", ".pptx",
        ".xlsx", ".rtf", ".rst",
        # Code
        ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rs", ".rb",
        ".c", ".cpp", ".h", ".cs", ".sh", ".bat", ".ps1", ".sql",
        # Data / config
        ".json", ".yaml", ".yml", ".xml", ".csv", ".tsv", ".toml", ".ini",
        ".env.example", ".parquet",
        # Web
        ".css", ".scss", ".less", ".svg", ".vue", ".svelte",
        # Images (agent-generated diagrams, screenshots)
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico",
    }

    # Directories that are iobot internals — never contain deliverables.
    # Using the first path component (relative to workspace) is enough
    # because iobot puts all its internal state under dotdirs or
    # well-known names at workspace root level.
    _SKIP_DIRS = {
    "prompts",  # iobot's template sync writes prompts/README.md AFTER the
                # pre-agent snapshot, so it read as a NEW deliverable and a
                # 'Prompt Overrides' README landed in every client's project/

        ".iobot",   # tool-results/, checkpoints, internal state
        ".git",       # git objects (if workspace is a repo)
        ".cursor",    # cursor IDE state
        "sessions",   # session JSONL files (agent conversation history)
        "memory",     # MEMORY.md and memory fragments
        "skills",     # skill .md files (bundled, not deliverables)
    }

    for fpath in workspace.rglob("*"):
        if not fpath.is_file():
            continue
        # Skip iobot internal directories — these contain session state,
        # tool-result spillover files (call_function_*.txt), checkpoints,
        # and other runtime artifacts that are NOT deliverables.
        try:
            rel_parts = fpath.relative_to(workspace).parts
        except ValueError:
            continue
        if rel_parts and rel_parts[0] in _SKIP_DIRS:
            continue
        if any(part.startswith(".") for part in rel_parts[:-1]):
            continue
        rel = str(fpath.relative_to(workspace))
        # Only copy NEW files (not in pre-agent snapshot)
        if rel in before_snapshot:
            continue
        # Only copy recognized deliverable types
        if fpath.suffix.lower() not in _ALLOW_EXTS:
            continue

        # Flatten into project_dir (don't replicate workspace subdirs)
        dest = project_dir / fpath.name
        # Handle name collisions by prefixing with parent dir name
        if dest.exists() and dest.name != fpath.name:
            parent_prefix = fpath.parent.name
            dest = project_dir / f"{parent_prefix}_{fpath.name}"
        shutil.copy2(str(fpath), str(dest))
        copied.append(dest)
        logger.debug("Copied artifact %s -> %s", fpath, dest)

    return copied


# ---------------------------------------------------------------------------
# Shared post-execution helper
# ---------------------------------------------------------------------------



def _failed_steps_if_run_failed(store, run_id: str, steps: list) -> list:
    """The failed step keys, but ONLY when the engine has already ruled the
    run failed. Not a second discovery: `mark_run_failed_if_stuck` is the one
    place that decides a run cannot converge; this reads its verdict."""
    try:
        if (store.get_run(run_id) or {}).get("status") != "failed":
            return []
    except Exception:  # noqa: BLE001
        return []
    return sorted(s["step_key"] for s in steps if s["status"] == "failed")


def reset_pending(row: dict) -> dict | None:
    """The on_fail reset this step is still carrying, or None.

    `_apply_on_fail` stamps a reset target's meta with who sent it back and
    at which of ITS attempts. Until the step has actually re-run (its attempt
    moved on), it is pending BECAUSE a gate rejected the work - and a `skip`
    would hand the rejected work straight back to that gate. Seen live: the
    orchestrator, finding a step pending that it remembered running, skipped
    it; the artifact gate could not refuse because the rejected draft was
    still on disk.
    """
    if (row.get("status") or "") != "pending":
        return None
    try:
        meta = json.loads(row.get("meta_json") or "{}")
    except (TypeError, ValueError):
        return None
    by = meta.get("reset_by")
    if not by:
        return None
    try:
        if int(meta.get("reset_at_attempt", -1)) != int(row.get("attempt") or 0):
            return None
    except (TypeError, ValueError):
        return None
    return {"reset_by": by, "attempt": int(row.get("attempt") or 0),
            "feedback": bool(meta.get("reset_feedback"))}

def _emit_route_event(root_path, run_id, step_key, role, event_type, message,
                      payload) -> None:
    try:
        from ioagentfarm.engine.forensics import (get_forensics, SEVERITY_INFO,
                                                  SEVERITY_ERROR, SEVERITY_WARN)
        sev = SEVERITY_ERROR if event_type in (
            "step.route_missing", "step.route_undeclared",
            "step.on_fail_exhausted") else SEVERITY_INFO
        if event_type == "step.route_target_already_ran":
            sev = SEVERITY_WARN
        get_forensics(root_path).emit(
            run_id=run_id, event_type=event_type, severity=sev,
            step_key=step_key, role=role, message=message, payload=payload)
    except Exception:
        logger.debug("Failed to emit %s", event_type, exc_info=True)


def _apply_route(store, root_path, run_id, step_key, role, wf, chosen) -> list:
    """Close every declared route the step did not choose - and everything
    reachable ONLY through them.

    A closed step is `done` with a note, the convention `step-skip` already
    uses, so every dep check and the run-completion rule work unchanged on
    every driver. A join that ALSO depends on a live branch keeps running:
    "all deps done" is satisfied by the skipped ones and waits for the rest.
    Only a pending step whose every dep is route-skipped has no live path to
    it, and that is what propagates.
    """
    rdef = {s.key: s for s in wf.steps}[step_key]
    unchosen = [r for r in rdef.routes if r not in chosen]
    steps = store.list_steps(run_id)
    status = {s["step_key"]: s["status"] for s in steps}
    deps = {s["step_key"]: json.loads(s["deps_json"] or "[]") for s in steps}
    skipped = {k for k in unchosen if status.get(k) == "pending"}
    # A target that already ran cannot be un-run. The route's decision was
    # not applied to it, and nothing else would say so - the run reads
    # green with a branch that executed against the decision.
    already_ran = [k for k in unchosen if status.get(k) not in (None, "pending")]
    if already_ran:
        _emit_route_event(
            root_path, run_id, step_key, role,
            event_type="step.route_target_already_ran",
            message=(f"route '{step_key}' did not choose {already_ran}, but "
                     f"they had already run - a route target must depend on "
                     f"the route step (`deps: [{step_key}]`)"),
            payload={"targets": already_ran, "chosen": chosen})
    changed = True
    while changed:
        changed = False
        for k, st in status.items():
            if st != "pending" or k in skipped:
                continue
            d = deps.get(k) or []
            if d and all(x in skipped for x in d):
                skipped.add(k)
                changed = True
    for k in sorted(skipped):
        # the text a later prompt sees as {{step_output.<k>}} - the first
        # cut carried a STATUS: line, so a consumer read "STATUS: done" for
        # a step that never ran (novice finding, round 3)
        store.set_step_output(
            run_id, k, "done",
            f"(closed - not chosen by route step '{step_key}'; it chose {chosen})")
    _emit_route_event(
        root_path, run_id, step_key, role, event_type="step.routed",
        message=f"route '{step_key}' chose {chosen}; closed {sorted(skipped)}",
        payload={"chosen": chosen, "declared": rdef.routes,
                 "skipped": sorted(skipped)})
    return sorted(skipped)


def _apply_on_fail(store, root_path, run_id, step_key, role, fdef, attempt) -> list:
    """Send the named producers - and everything downstream of them that
    already ran - back to pending, carrying this step's feedback.

    Downstream too, not just the targets: their inputs are now stale. This
    step itself is already pending (the caller's status write) and depends on
    the targets, so `next-step` holds it until the chain has re-run.
    """
    from collections import defaultdict
    steps = store.list_steps(run_id)
    status = {s["step_key"]: s["status"] for s in steps}
    deps = {s["step_key"]: json.loads(s["deps_json"] or "[]") for s in steps}
    children = defaultdict(list)
    for k, ds in deps.items():
        for d in ds:
            children[d].append(k)
    targets = [t for t in fdef.on_fail.reset if t in status]
    closure, frontier = set(targets), list(targets)
    while frontier:
        k = frontier.pop()
        for c in children.get(k, []):
            if c not in closure:
                closure.add(c)
                frontier.append(c)
    reset = [k for k in sorted(closure)
             if k != step_key and status.get(k) in ("done", "failed")]
    attempts = {s["step_key"]: int(s.get("attempt") or 0) for s in steps}
    for k in reset:
        store.set_step_output(
            run_id, k, "pending",
            f"STATUS: pending\nOUTPUT: reset by '{step_key}' on_fail "
            f"(its attempt {attempt}) - re-run with feedback")
        # The marker step-skip reads (reset_pending): this step is pending
        # because a gate rejected the work, not because it never ran.
        store.set_step_meta(run_id, k, {
            "reset_by": step_key, "reset_at_attempt": attempts.get(k, 0),
            "reset_feedback": bool(fdef.on_fail.feedback)})
    fb_text = ""
    if fdef.on_fail.feedback:
        from ioagentfarm.engine.iobot_config import get_run_output_dir
        fp = get_run_output_dir(root_path, run_id) / fdef.on_fail.feedback
        if fp.is_file():
            fb_text = fp.read_text(encoding="utf-8", errors="replace").strip()
    if fb_text:
        # FEEDBACK.md is what render_step_prompt reads (and consumes) into the
        # "Feedback from previous attempt" section - the reader existed with
        # no writer; this is the writer.
        for t in targets:
            d = root_path / "runs" / run_id / "steps" / safe_step_key(t)
            d.mkdir(parents=True, exist_ok=True)
            (d / "FEEDBACK.md").write_text(fb_text, encoding="utf-8")
    _emit_route_event(
        root_path, run_id, step_key, role, event_type="step.reset_on_fail",
        message=(f"'{step_key}' failed (attempt {attempt}); reset {reset} to "
                 "pending" + (f" with {len(fb_text)} chars of feedback"
                              if fb_text else "")),
        payload={"targets": targets, "reset": reset,
                 "feedback_file": fdef.on_fail.feedback,
                 "feedback_chars": len(fb_text), "feedback": fb_text[:500],
                 "attempt": attempt})
    return reset

def _declared_max_attempts(step_row) -> int:
    """The max_attempts the WORKFLOW declared, whatever has bumped it since.

    THE CAP CHASED THE RETRIES. `_hard_cap` was
    `step_row["max_attempts"] * multiplier + 1`, and `step-retry` sets
    `max_attempts = max_attempts + 1` - so every retry raised the ceiling it
    was supposed to be bounded by. Certification round 5 measured the result
    on a step declaring `max_attempts: 1`: **38 attempts, 108 model calls,
    5.06M input tokens, $3.60 in ten minutes**, still climbing when it was
    stopped by hand. `step.hard_cap_reached` never fired, because it never
    could. CLAUDE.md calls this cap "the only thing bounding runaway
    retries"; it was bounding nothing.

    The declared value is stamped into the step's meta the first time
    anything bumps it, so the cap keeps its original anchor. Steps created
    before this shipped have no stamp and fall back to the current value -
    the old behaviour, not a crash.
    """
    import json as _json
    try:
        meta = step_row["meta_json"]
        meta = _json.loads(meta) if isinstance(meta, str) else (meta or {})
        declared = meta.get("declared_max_attempts")
        if isinstance(declared, int) and declared > 0:
            return declared
    except Exception:                      # noqa: BLE001 - never break a step
        pass
    return int(step_row["max_attempts"])


def _artifact_digests(out_dir, names) -> dict:
    """size + sha256 of each declared artifact, as it is right now."""
    import hashlib
    out = {}
    for n in names:
        p = Path(out_dir) / n
        try:
            data = p.read_bytes()
            out[n] = {"size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        except OSError:
            out[n] = {"size": None, "sha256": None}
    return out


def _recheck_gates_at_run_end(store, root_path, run_id) -> list:
    """Every deliverable a passed gate digested, compared with what is in
    the artifact directory NOW that the run is done. A file deleted or
    torn by a process a step left behind is otherwise invisible - the gate
    is a check at one instant, and the run reads green (novice, round 7).
    Returns the discrepancies; emits one warn event per changed step."""
    gate_dir = Path(root_path) / "instances" / run_id / "gate"
    out_dir = Path(root_path) / "instances" / run_id / "project"
    changed = []
    if not gate_dir.is_dir():
        return changed
    for gf in sorted(gate_dir.glob("*.json")):
        try:
            rec = json.loads(gf.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        then = rec.get("digests") or {}
        now = _artifact_digests(out_dir, list(then))
        diffs = []
        for name, d0 in then.items():
            d1 = now.get(name) or {}
            if d1.get("sha256") != d0.get("sha256"):
                diffs.append({"artifact": name,
                              "at_gate": d0, "now": d1,
                              "what": "missing" if d1.get("sha256") is None else "changed"})
        if diffs:
            changed.append({"step_key": rec.get("step_key"), "diffs": diffs})
            try:
                from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
                _names = ", ".join(f"{d['artifact']} ({d['what']})" for d in diffs)
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="run.artifact_changed_after_gate", severity=SEVERITY_WARN,
                    step_key=rec.get("step_key"), role=None,
                    message=(f"deliverable(s) of '{rec.get('step_key')}' differ from what its "
                             f"artifact gate digested: {_names} - something wrote to the "
                             "artifact directory after the step ended (a child the step left "
                             "behind, or a later step); the gate is a check at one instant"),
                    payload={"diffs": diffs})
            except Exception:  # noqa: BLE001
                pass
    return changed


def _finalize_step(
    *,
    store,
    root_path: Path,
    run_id: str,
    step_key: str,
    raw: str,
    wf,
    role: str = "",
    agent_workspace: Path | None = None,
    tasks_data: list | None = None,
) -> dict:
    """Post-execution: parse output, handle stories/tasks, update DB, write progress, find next step.

    Called by both ``step-complete`` and ``run-step`` after the agent output is
    available.  Returns a dict ready to be printed as JSON.

    Parameters
    ----------
    store : Store
        The state store instance.
    root_path : Path
        IOF_ROOT path (for runs/ directory).
    run_id, step_key : str
        Identifiers for the current step.
    raw : str
        Raw agent output text (will be parsed for STATUS/OUTPUT protocol).
    wf : Workflow
        Loaded workflow object (for step definitions and team roster).
    role : str
        Agent role that executed the step (for memory persistence).
    agent_workspace : Path | None
        Directory containing agent output (for memory persistence).
    tasks_data : list | None
        Pre-parsed TASKS_JSON list (only from step-complete which parses
        protocol separately).  If *None*, tasks are parsed from *raw*.
    """

    # --- Parse protocol ---
    kv, stories_data, tasks_parsed = parse_key_value_protocol(raw)

    # Fallback: if byte-stream parser found no STATUS, try reading OUTPUT.md
    # from disk. The agent may have written it via write_file but the text
    # never appeared in stdout (common with non-streaming providers where
    # the subprocess exits without printing the STATUS line).
    if "STATUS" not in kv:
        try:
            # THERE ARE TWO OUTPUT.md LOCATIONS AND THIS ONLY READ ONE.
            #
            # The step prompt tells the agent to write to its STEP OUTPUT DIR
            # (`runs/<run>/steps/<key>/OUTPUT.md`); this fallback read only
            # `instances/<run>/project/OUTPUT.md`. So on a non-streaming
            # provider - the case the fallback EXISTS for, where the agent
            # writes the file but never prints STATUS to stdout - it looked
            # where the agent had not been told to write, found nothing, and
            # the step was classed a protocol failure.
            #
            # That is the `agent_premature_termination` we have been absorbing
            # with full step retries. The agents were not failing to finish;
            # they were finishing, and being told their work was missing. Their
            # own consoles show them working it out: "the orchestrator is
            # looking for it in the project directory ... but I [wrote it] one
            # level up in the steps directory. I need to move OUTPUT.md to
            # match" - burning turns shuttling a file to satisfy a reader that
            # was pointed at the wrong place.
            #
            # Both are read, step dir FIRST, because both are genuinely in use:
            # agents that have learned to copy into project/ must keep working.
            _step_dir_name = step_key.replace(":", "_").replace("/", "_")
            for output_md in (
                root_path / "runs" / run_id / "steps" / _step_dir_name / "OUTPUT.md",
                root_path / "instances" / run_id / "project" / "OUTPUT.md",
            ):
                if not output_md.exists():
                    continue
                disk_content = output_md.read_text(encoding="utf-8", errors="replace")
                disk_kv, disk_stories, disk_tasks = parse_key_value_protocol(disk_content)
                if "STATUS" in disk_kv:
                    kv.update(disk_kv)
                    if disk_stories:
                        stories_data = disk_stories
                    if disk_tasks:
                        tasks_parsed = disk_tasks
                    logger.info(
                        "OUTPUT.md fallback: found STATUS=%s from disk (step=%s)",
                        disk_kv.get("STATUS"), step_key,
                    )
        except Exception:
            logger.debug("OUTPUT.md fallback failed", exc_info=True)

    step_status = (kv.get("STATUS") or "failed").strip().lower()
    if step_status not in ("done", "failed"):
        step_status = "failed"
    output_text = kv.get("OUTPUT", raw)

    # --- Fail-closed artifact gate ---
    # A step can declare `requires_artifacts` in the workflow YAML. Even when the
    # agent reports STATUS: done, the step is only truly complete when every
    # declared deliverable actually exists on disk and is non-empty. This stops
    # a weak step from claiming success while never producing the handoff a
    # downstream step depends on (e.g. analyst never writes intelligence_report.md,
    # so the strategist read_file fails and fabricates numbers to fill the gap).
    if step_status == "done":
        _step_def = {s.key: s for s in wf.steps}.get(step_key)
        _required = list(getattr(_step_def, "requires_artifacts", []) or []) if _step_def else []
        if _required:
            _out_dir = root_path / "instances" / run_id / "project"
            _missing, _empty = [], []
            for _art in _required:
                try:
                    _p = _out_dir / _art
                    # `..` and a junction/symlink both resolve OUTSIDE the
                    # artifact directory and the gate passed both (novice,
                    # round 6). A deliverable is in the directory or absent.
                    try:
                        _inside = _p.resolve().is_relative_to(_out_dir.resolve())
                    except (OSError, ValueError):
                        _inside = False
                    if not _inside:
                        _missing.append(f"{_art} (resolves outside the artifact directory)")
                    elif not _p.exists():
                        _missing.append(_art)
                    elif _p.stat().st_size == 0:
                        _empty.append(_art)
                except OSError:
                    _missing.append(_art)
            _gate_desc = "; ".join(
                x for x in ((f"missing: {', '.join(_missing)}" if _missing else ""),
                            (f"empty (0 bytes): {', '.join(_empty)}" if _empty else "")) if x)
            if not (_missing or _empty):
                # The gate PASSED: say so on the record, with a digest of
                # each deliverable as it was at that instant. Until now a
                # passed gate left no event (`explain` read `n/a`), and a
                # child the step left behind could delete or tear the file
                # later with the run still green (novice finding, round 7).
                try:
                    _dig = _artifact_digests(_out_dir, _required)
                    _gate_dir = root_path / "instances" / run_id / "gate"
                    _gate_dir.mkdir(parents=True, exist_ok=True)
                    (_gate_dir / f"{safe_step_key(step_key)}.json").write_text(
                        json.dumps({"step_key": step_key, "digests": _dig}, indent=2), encoding="utf-8")
                    from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO
                    get_forensics(root_path).emit(
                        run_id=run_id, event_type="step.artifact_gate_passed", severity=SEVERITY_INFO,
                        step_key=step_key, role=role,
                        message=f"artifact gate passed: {', '.join(_required)}",
                        payload={"declares": list(_required), "digests": _dig})
                except Exception:  # noqa: BLE001
                    logger.debug("gate digest failed", exc_info=True)
            if _missing or _empty:
                step_status = "failed"
                # NO COMPOSITION ADVICE IT CANNOT KNOW. This appended
                # "(assemble the section files)" to EVERY artifact-gate
                # failure - sectioned composition is one workflow's technique,
                # not a fact about the missing file. Phase A round 1 watched
                # the driver read it on a workflow that has no sections, hunt
                # for files that never existed, and report a false root cause
                # ("the workflow expects section files to be assembled"). A
                # retry hint that misexplains is worse than none: it is the
                # harness inventing the diagnosis.
                # NAME THE DIRECTORY. "the output directory" is exactly the
                # ambiguity that cost the certification runs: there are two,
                # and the driver was handed the other one's path under that
                # name. `explain` already prints where it looked - this is
                # the seam the DRIVER reads, so it says it here too.
                output_text = (
                    f"Required artifact(s) {_gate_desc}. "
                    f"The step must write {', '.join(_required)} into "
                    f"{_out_dir} (the run's artifact directory - NOT the "
                    f"per-step directory) BEFORE reporting STATUS: done."
                )
                # The step's own OUTPUT.md said "completed (exit 0)"; make the
                # record on disk agree with the row (novice finding, round 3).
                try:
                    _omd = root_path / "runs" / run_id / "steps" / safe_step_key(step_key) / "OUTPUT.md"
                    if _omd.is_file():
                        with open(_omd, "a", encoding="utf-8") as _fh:
                            _fh.write(f"\n\n[artifact gate] {_gate_desc} - looked in "
                                      f"{_out_dir}; the step is marked FAILED\n")
                except OSError:
                    pass
                _missing = _missing + _empty
                try:
                    from ioagentfarm.engine.forensics import get_forensics, SEVERITY_ERROR
                    get_forensics(root_path).emit(
                        run_id=run_id, event_type="step.artifact_missing",
                        severity=SEVERITY_ERROR, step_key=step_key, role=role,
                        message=(
                            f"Step reported done but required artifact(s) {_gate_desc}. "
                            f"Looked in: {_out_dir}. Flipped to failed for retry."
                        ),
                        payload={"required": _required, "missing": _missing,
                                 "missing_files": [a for a in _missing if a not in _empty],
                                 "empty_files": _empty, "output_dir": str(_out_dir)},
                    )
                except Exception:
                    logger.debug("Failed to emit step.artifact_missing", exc_info=True)

    # --- Fail-closed stories gate (loop steps) ---
    # A `type: loop` step's actual deliverable IS its STORIES_JSON — the
    # engine materializes per-item steps from it. If the agent reports done
    # WITHOUT the key (observed: a Fix-6 mid-step resume whose continuation
    # prompt narrowed the contract to STATUS/OUTPUT, so the resumed agent
    # wrote a minimal OUTPUT.md), accepting the step silently drops the
    # entire fan-out: downstream steps become runnable with no per-item work
    # done. Same philosophy as requires_artifacts: flip to failed for retry.
    # An explicit empty list (`STORIES_JSON: []`) is a legitimate "no items"
    # outcome and passes; only an ABSENT/unparseable key fails.
    if step_status == "done":
        _step_def = {s.key: s for s in wf.steps}.get(step_key)
        # A command step anchors a fan-out only when it DECLARES one: with
        # `stories_from` and no `per_item_steps` the manifest is recorded
        # and nothing fans out (the batch-12 warning), and this gate then
        # failed the step for having no stories - a documented shape that
        # exited 0 read `failed` (novice finding, round 7).
        _anchors_stories = _step_def is not None and (
            _step_def.type == "loop"
            or (_step_def.runs_command and _step_def.stories_from
                and bool(getattr(_step_def, "per_item_steps", None) or []))
        )
        if _anchors_stories and stories_data is None:
            step_status = "failed"
            output_text = (
                "STORIES_JSON missing: this is a loop step — STORIES_JSON is a "
                "REQUIRED deliverable (the engine materializes per-item steps "
                "from it). Re-emit OUTPUT.md with STATUS, OUTPUT, and a "
                "STORIES_JSON array (use `STORIES_JSON: []` only if there is "
                "genuinely nothing to process)."
            )
            try:
                from ioagentfarm.engine.forensics import get_forensics, SEVERITY_ERROR
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="step.stories_missing",
                    severity=SEVERITY_ERROR, step_key=step_key, role=role,
                    message=(
                        "Loop step reported done but no STORIES_JSON was parsed "
                        "from its output. Flipped to failed for retry."
                    ),
                    payload={"parsed_keys": list(kv.keys())},
                )
            except Exception:
                logger.debug("Failed to emit step.stories_missing", exc_info=True)

    # Phase 3: emit a forensic event when the protocol parser couldn't find
    # a STATUS key. This is the silent failure mode where the agent wrote
    # OUTPUT.md but with markdown-emphasized headers (e.g. **STATUS:** done)
    # instead of the literal "STATUS: done" first line. Without this event,
    # the only signal in the messages table is "Step failed during ... will
    # retry" with no clue why.
    try:
        if "STATUS" not in kv:
            from ioagentfarm.engine.forensics import (
                get_forensics, SEVERITY_ERROR,
            )
            preview = (raw or "")[:300].replace("\n", " ")
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.protocol_parse_failed",
                severity=SEVERITY_ERROR,
                step_key=step_key, role=role,
                message=(
                    "OUTPUT.md exists but parser found no STATUS key — "
                    "agent likely used markdown emphasis (**STATUS:**) "
                    "or a heading instead of the literal 'STATUS: done' "
                    "first line. See output_protocol skill."
                ),
                payload={"raw_preview": preview, "parsed_keys": list(kv.keys())},
            )
    except Exception:
        logger.debug("Failed to emit step.protocol_parse_failed", exc_info=True)

    # Use caller-provided tasks_data when available (step-complete parses
    # protocol itself before calling us), otherwise use freshly parsed data.
    effective_tasks = tasks_data if tasks_data is not None else tasks_parsed

    # --- Handle loop stories ---
    # --- Route gate: a `type: route` step must say where to go, and only to a
    # declared target. Absent/unparseable ROUTE_JSON or an undeclared name flips
    # the step to failed - fail-closed like the artifact and stories gates: a
    # route that silently ran every branch, or none, is the worst outcome a bad
    # tool could produce. A `switch` over `routes:`, never a `goto`.
    _route_choice = None
    if step_status == "done":
        _rdef = {s.key: s for s in wf.steps}.get(step_key)
        if _rdef is not None and _rdef.type == "route":
            from ioagentfarm.engine.protocol import _try_parse_json
            _rj = _try_parse_json(kv["ROUTE_JSON"]) if "ROUTE_JSON" in kv else None
            # `{"next": [...]}` is canonical; a bare list or a bare string is
            # what a person writes first, so both are read too.
            if isinstance(_rj, dict):
                _nxt = _rj.get("next")
            elif isinstance(_rj, (list, str)):
                _nxt = _rj
            else:
                _nxt = None
            if isinstance(_nxt, str):
                _nxt = [_nxt]
            if not isinstance(_nxt, list) or not all(isinstance(x, str) for x in _nxt):
                step_status = "failed"
                output_text = (
                    "ROUTE_JSON missing or malformed: a `type: route` step must "
                    "print `ROUTE_JSON: [...]` (or `{\"next\": [...]}`) naming which of its "
                    f"declared routes run (declared: {_rdef.routes}). "
                    "Use ioagentfarm.sdk.route.next(...).")
                _emit_route_event(root_path, run_id, step_key, role,
                                  event_type="step.route_missing",
                                  message=output_text,
                                  payload={"parsed_keys": list(kv.keys()),
                                           "declared": _rdef.routes})
            else:
                _undeclared = sorted(set(_nxt) - set(_rdef.routes))
                if _undeclared:
                    step_status = "failed"
                    output_text = (
                        f"route step chose {_undeclared}, which is not in its "
                        f"declared `routes:` {_rdef.routes}. A route is a switch "
                        "over declared targets, not a goto - add the target to "
                        "`routes:` or fix the tool.")
                    _emit_route_event(root_path, run_id, step_key, role,
                                      event_type="step.route_undeclared",
                                      message=output_text,
                                      payload={"chose": _nxt, "declared": _rdef.routes})
                else:
                    _route_choice = _nxt

    step_by_key = {s.key: s for s in wf.steps}
    if not step_key.startswith("story:") and step_key in step_by_key:
        step_def = step_by_key[step_key]
        if step_def.type in ("loop", "exec") and isinstance(stories_data, list) and stories_data:
            store.add_stories(run_id, stories_data)
            yaml_keys = [s.key for s in wf.steps]
            if step_key in yaml_keys:
                idx = yaml_keys.index(step_key)
                next_yaml = yaml_keys[idx + 1 : idx + 2]
            else:
                next_yaml = []
            store.ensure_story_steps(
                run_id,
                after_step_key=step_key,
                per_item_steps=step_def.per_item_steps,
                next_yaml_step_keys=next_yaml,
            )

    # --- Handle dynamic tasks (TASKS_JSON) — only from project_lead role ---
    tasks_inserted = 0
    if effective_tasks and step_status == "done":
        steps_all = store.list_steps(run_id)
        emitting_step = next((s for s in steps_all if s["step_key"] == step_key), None)
        emitting_role = emitting_step["role"] if emitting_step else ""

        if emitting_role == "project_lead":
            yaml_keys = [s.key for s in wf.steps]
            if step_key in yaml_keys:
                idx = yaml_keys.index(step_key)
                next_yaml = yaml_keys[idx + 1 : idx + 2]
            else:
                next_yaml = []
            tasks_inserted = store.insert_dynamic_tasks(
                run_id,
                after_step_key=step_key,
                tasks=effective_tasks,
                next_yaml_step_keys=next_yaml,
            )
        # Silently ignore TASKS_JSON from non-lead roles — governance rule

    # --- Update step status in DB ---
    steps = store.list_steps(run_id)
    step_row = next((s for s in steps if s["step_key"] == step_key), None)
    max_attempts = int(step_row["max_attempts"]) if step_row else 2
    attempt = int(step_row["attempt"]) if step_row else 0

    if step_status == "done":
        store.set_step_output(run_id, step_key, "done", raw)
    else:
        if attempt >= max_attempts:
            store.set_step_output(run_id, step_key, "failed", raw)
        else:
            store.set_step_output(run_id, step_key, "pending", raw)

    # --- Route: close the turns not taken ---
    if _route_choice is not None:
        _apply_route(store, root_path, run_id, step_key, role, wf, _route_choice)

    # --- on_fail: send the producers back, with feedback ---
    # Only on the attempt that is NOT terminal: the status write above just put
    # this step back to pending, so it re-runs once the reset chain has. When
    # its own attempts are exhausted the failure stands and nothing is reset -
    # that bound is the loop's limit, and it is written in the YAML.
    _fdef = step_by_key.get(step_key)
    if (step_status != "done" and _fdef is not None and _fdef.on_fail
            and _fdef.on_fail.reset):
        if attempt < max_attempts:
            _apply_on_fail(store, root_path, run_id, step_key, role, _fdef, attempt)
        else:
            _emit_route_event(
                root_path, run_id, step_key, role,
                event_type="step.on_fail_exhausted",
                message=(f"'{step_key}' failed on its last attempt ({attempt}/"
                         f"{max_attempts}); on_fail reset of {_fdef.on_fail.reset} "
                         "not applied - the loop is bounded here"),
                payload={"reset": _fdef.on_fail.reset, "attempt": attempt,
                         "max_attempts": max_attempts})

    # --- Capture enrichment: step.tool_usage (derivation layer) ---
    # The session snapshot holds every tool call the attempt made, but a
    # JSONL is not queryable — one aggregate event per finalized attempt is
    # what makes "how often does iof-consult fail" a single SQL query.
    # Derived from the SAME walk `forensics stats` uses, so the CLI and the
    # event can never disagree.
    try:
        from ioagentfarm.cli_forensics import _walk_session_stats
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO
        _sanitized = step_key.replace(":", "_").replace("/", "_")
        _snap = (root_path / "instances" / run_id / "forensics" / "attempts"
                 / f"{_sanitized}.{attempt}" / "session-snapshot.jsonl")
        if _snap.exists():
            _sess = _walk_session_stats(_snap)
            _by_target = dict(sorted(
                (_sess.get("tool_calls_by_target") or {}).items(),
                key=lambda kv: -kv[1])[:10])
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.tool_usage",
                severity=SEVERITY_INFO, step_key=step_key, attempt=attempt,
                role=role,
                message=(f"{_sess.get('tool_calls_total', 0)} tool call(s) "
                         f"across {_sess.get('assistant_turns', 0)} turn(s)"),
                payload={
                    "by_name": _sess.get("tool_calls_by_name", {}),
                    "failures": 1 if step_status != "done" else 0,
                    "by_target_top": _by_target,
                    "assistant_turns": _sess.get("assistant_turns", 0),
                    "wrote_output": _sess.get("wrote_output_md", False),
                },
            )
    except Exception:
        logger.debug("Failed to emit step.tool_usage", exc_info=True)

    # --- Check learning: disabled flag from workflow snapshot ---
    _learning_disabled = False
    try:
        import yaml as _yaml
        wf_yaml = root_path / "instances" / run_id / "workflow" / "workflow.yaml"
        if wf_yaml.exists():
            wf_data = _yaml.safe_load(wf_yaml.read_text(encoding="utf-8")) or {}
            _learning_disabled = str(wf_data.get("learning", "")).lower() in (
                "disabled", "false", "off",
            )
    except Exception:
        pass

    # --- Persist agent memory ---
    # Paused when v2 is on: the persist-back is the v1 accumulation channel
    # (whatever the agent's session appended to memory/MEMORY.md compounds
    # into the agent home forever), and v2 replaces MEMORY.md-based learning
    # with hub-governed skills. Existing MEMORY.md content still LOADS —
    # only the growth stops.
    from ioagentfarm.engine.learning.hooks import (
        finalize_step as _learn_finalize, memory_paused as _memory_paused)
    if role and agent_workspace:
        persist_agent_memory(
            role, agent_workspace,
            learning_disabled=_learning_disabled or _memory_paused())

    # --- Learning (one facade call; v1-vs-v2 dispatch lives in hooks) ---
    #     v2 on: outcome attribution + distillation into hub drafts, and the
    #     v1 observation capture is PAUSED (it is the MEMORY.md pollution
    #     channel v2 replaces). v2 off: v1 observation + feedback card.
    _learn_finalize(root_path, run_id, step_key, role=role, workflow=wf.name,
                    step_status=step_status, output_text=output_text,
                    store=store, learning_disabled=_learning_disabled)

    # --- Check run-level done/failed ---
    # Claim the running->terminal transition. Each returns True ONLY for the
    # caller whose UPDATE actually flipped the run (see
    # Store.mark_run_done_if_complete), so the closing boundary event — and the
    # one-shot gate re-check + coverage keyed to it below — fire exactly once
    # even when a supervisor sweep on another pod converges the same run in the
    # same instant. Emitting on the old read-compare (_prev_run_status ==
    # "running") let BOTH the finalizer and the sweep emit run.completed for a
    # single run (92 of 292 in a 3-pod soak).
    _won_done = bool(store.mark_run_done_if_complete(run_id))
    _won_failed = bool(store.mark_run_failed_if_stuck(run_id))
    _won_terminal = _won_done or _won_failed

    # Driver heartbeat: a step just finalized — the invoker chain is alive.
    # Resets the supervisor's driver-staleness clock at every step boundary
    # so a driver mid-think between steps is never falsely resurrected.
    store.touch_driver_heartbeat(run_id)

    # --- Write progress ---
    run_refreshed = store.get_run(run_id)

    # --- Run boundary events + swarm child enrichment ---
    # The winner of the claim owes the record its closing work. The
    # sequence lives in `close_run_record` because `next_step` can win
    # this same claim, and used to drop the work on the floor.
    if _won_terminal:
        close_run_record(store, root_path, run_id,
                         run_refreshed=run_refreshed)
    steps = store.list_steps(run_id)
    story_counts = store.story_counts(run_id)
    md = build_progress_markdown(
        run=run_refreshed,
        steps=steps,
        stories=story_counts,
        last_event={"event": "step_complete", "step_key": step_key, "status": step_status},
        team_roster=wf.team,
    )
    run_dir = root_path / "runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "progress.txt").write_text(md, encoding="utf-8")

    # --- Sync artifacts to cloud storage (S3, Azure, etc.) ---
    try:
        from ioagentfarm.web.storage import get_storage
        from ioagentfarm.engine.iobot_config import get_run_output_dir
        storage = get_storage()
        # Push instance dir (logs, config, workspaces, project artifacts)
        instance_dir = root_path / "instances" / run_id
        if instance_dir.exists():
            storage.push(run_id, instance_dir, sub_prefix="instances")
        # Push run dir (step outputs, progress) — critical for pod recovery
        if run_dir.exists():
            storage.push(run_id, run_dir, sub_prefix="state")
        # Push step session JSONL — enables follow-up chat after pod crash or
        # on a different pod.  The JSONL has the agent's full reasoning trail.
        if role and step_status == "done":
            try:
                # Resolved through the one module the chat fork also reads
                # (engine/step_sessions.py). This used to build the legacy
                # `_`-spelled name in the ROLE'S HOME - a file the runtime
                # stopped writing, in a directory a step never wrote to - so
                # `exists()` was False and no step session was ever pushed.
                from ioagentfarm.engine.step_sessions import push_step_session
                pushed = push_step_session(storage, root_path, run_id, step_key, role)
                if pushed is not None:
                    logger.info("S3 push session: %s (%s)", step_key, pushed.name)
            except Exception:
                logger.debug("Session S3 push failed (non-critical)", exc_info=True)
    except Exception as exc:
        logger.error("S3 push failed for run_id=%s: %s", run_id, exc)
        # Also print to stdout so it appears in container logs (ArgoCD visible)
        print(f"[IOF:S3:ERROR] push failed run_id={run_id}: {exc}", flush=True)

    # --- Find next step ---
    step_status_map = {s["step_key"]: s["status"] for s in steps}
    next_info = None
    for s in steps:
        if s["status"] != "pending":
            continue
        deps = json.loads(s["deps_json"] or "[]")
        if all(step_status_map.get(d) == "done" for d in deps):
            next_info = {"step_key": s["step_key"], "role": s["role"]}
            break

    # --- Build result JSON ---
    result: dict[str, Any] = {
        "run_id": run_id,
        "step_key": step_key,
        "status": step_status,
        "output_preview": output_text[:200],
    }
    if tasks_inserted:
        result["tasks_created"] = tasks_inserted
    if next_info:
        result["next_step_key"] = next_info["step_key"]
        result["next_role"] = next_info["role"]
    else:
        result["run_status"] = run_refreshed["status"]

    spawned = _fanout_story_siblings(store, root_path, run_id)
    if spawned:
        result["fanned_out"] = spawned

    return result


def _fanout_story_siblings(store, root_path: Path, run_id: str) -> list[str]:
    """Keep the in-flight budget full of a loop step's children, underneath the
    driver.

    WHY THE DRIVER IS NOT ASKED. A loop step's children all depend on the same
    parent and on nothing else, so which of thirty identical detect steps runs
    when carries no judgement - it is data parallelism wearing an orchestration
    costume. The `orchestrate` skill already asks Alex to fan them out with
    `next-step --all` + `run-step --background`, and states the measured cost of
    not doing it ("four groups at ~5 minutes each ran serially for ~35
    minutes"). Measured again on a 20-story run: he called plain `next-step` and
    ran them one at a time, so the stage took the SUM of the children plus a
    ~90s driver round trip before each one.

    That is this repo's own standing lesson - a rule stated to a model is a
    request - landing in the place the lesson was already written down. So the
    fan-out moves here, where it is physics rather than a request, exactly as
    the sleep-poll ban moved into `build_exec_guard`.

    SCOPE IS DELIBERATELY NARROW. Only `story:` steps, which are the ones the
    engine itself materialized from `per_item_steps` and therefore knows to be
    independent siblings. Every other step keeps the existing behaviour, so a
    workflow whose sequencing the driver genuinely decides is untouched.

    The budget is the SAME `_fanout_limit()` the `--all` path uses, counted over
    steps already running, so this cannot exceed a limit the driver was
    observing. Each completing child tops the pool back up, which makes the
    stage self-sustaining without a supervisor: materialize N, start `cap`, and
    every finish starts the next.
    """
    if (os.environ.get("IOF_AUTO_FANOUT") or "1").strip().lower() in {"0", "false", "no"}:
        return []
    try:
        steps = store.list_steps(run_id)
    except Exception:  # noqa: BLE001 - fan-out is an optimisation, never a gate
        logger.debug("auto fan-out: could not list steps", exc_info=True)
        return []

    cap = _fanout_limit()
    running = sum(1 for s in steps if s["status"] == "running")
    room = cap - running
    if room <= 0:
        return []

    ready = [s for s in steps
             if s["status"] == "pending"
             and str(s["step_key"]).startswith("story:")
             and not unmet_deps(steps, s["step_key"])]
    if not ready:
        return []

    spawned: list[str] = []
    for step in ready[:room]:
        key = str(step["step_key"])
        try:
            # Shelling out to `run-step --background` rather than re-implementing
            # it: that path marks the row running, passes --reentrant so the
            # duplicate guard does not refuse the very child it started, and
            # carries IOF_ROOT to the detached process. A second implementation
            # of those three details is a second place for them to drift.
            proc = subprocess.run(
                [sys.executable, "-m", "ioagentfarm.cli", "run-step",
                 "--step-key", key, "--run-id", run_id, "--background",
                 "--root", str(root_path)],
                capture_output=True, text=True, timeout=120,
            )
            if proc.returncode == 0:
                spawned.append(key)
            else:
                logger.debug("auto fan-out: %s refused (rc=%s)", key, proc.returncode)
        except Exception:  # noqa: BLE001
            logger.debug("auto fan-out: %s failed to spawn", key, exc_info=True)
    return spawned



def safe_step_key(step_key: str) -> str:
    """`step_key` folded to a filename-safe form.

    A fan-out step's key is `story:G01:detect` and Windows cannot create a
    file containing ':' at all. The rest of this codebase already knew —
    the same fold appears in seven other places, including the forensics
    directory built for the very same step — so this exists to stop the
    eighth caller reinventing it slightly differently.
    """
    return step_key.replace(":", "_").replace("/", "_")


def plan_manifest_path(output_dir: Path, step_key: str) -> Path:
    """Where the Fix-6 checkpoint for *step_key* lives.

    THE BUG THIS FIXES. The path was built as `f"_{step_key}_plan.md"`, so a
    story step asked for `_story:G01:detect_plan.md` — uncreatable on Windows.
    The agent could never write the checkpoint, so Priority 1 of the recovery
    hierarchy could never fire for ANY fan-out step and every restart fell
    through to the bare file listing. Measured live: a detect step restarted
    three times, re-adjudicating candidates it had already decided (walking
    back from C-00017 to C-00009), 46 minutes for zero output, while its own
    continuation message reported "No plan manifest found
    (_story:G01:detect_plan.md)" — which was structurally guaranteed.

    Returns the first existing candidate, else the preferred (sanitized) name
    so callers can report what they looked for.
    """
    safe = safe_step_key(step_key)
    candidates = [output_dir / f"_{safe}_plan.md"]
    if safe != step_key:
        # A plan written under the raw name on a filesystem that permits ':'
        # must still be found — the fix must not orphan existing plans.
        candidates.append(output_dir / f"_{step_key}_plan.md")
    candidates.append(output_dir / "_plan.md")  # legacy/generic fallback
    return next((c for c in candidates if c.exists()), candidates[0])


# ---------------------------------------------------------------------------
# Orchestration commands
# ---------------------------------------------------------------------------

def _fanout_limit(explicit: int | None = None) -> int:
    """How many step children may be in flight at once.

    The cap lives HERE and not in the orchestrate skill on purpose: the
    driver is an LLM, and a prompt-level "never spawn more than four" is the
    same instruction the hard attempt cap already exists because Alex does
    not reliably follow (see `run_step`). A fan-out of 4 is a bound; a
    fan-out of 50 — one per cluster on a large taxonomy — is a machine with
    50 concurrent model sessions on it.
    """
    if explicit is not None and explicit > 0:
        return explicit
    raw = (os.environ.get("IOF_FANOUT_MAX_CHILDREN") or "").strip()
    try:
        n = int(raw)
        return n if n > 0 else 4
    except ValueError:
        return 4


def next_step(
    run_id: str = typer.Option(None, help="Run ID (omit for latest active run)"),
    role: str = typer.Option(None, help="Filter by role (optional)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    all_runnable: bool = typer.Option(
        False, "--all",
        help="Return EVERY currently-runnable step (bounded by --limit) instead of "
             "just the next one, so independent siblings can be delegated together"),
    limit: int = typer.Option(
        None, "--limit",
        help="Max steps in flight at once for --all (default IOF_FANOUT_MAX_CHILDREN, else 4). "
             "Steps already running count against it"),
):
    """Peek at the next runnable step WITHOUT claiming it. Returns JSON."""
    from ioagentfarm.cli import _root, _store, _default_user_id, _resolve_run_id, _get_run_or_exit, _workspace_code

    # Fail closed on the tenant BEFORE touching the store. The driver spawns
    # this with IOF_WORKSPACE in its env, which satisfies resolution; a human
    # debugging by hand either has a selection or gets the refusal panel —
    # never a silent default persona.
        # NO --workspace on run/step commands, by design. Activation (or the
    # driver's inherited IOF_WORKSPACE) is the ONE way to choose the tenant,
    # and every command prints a context line naming it. A flag that can
    # disagree with the activation is a footgun for a human and worse for an
    # LLM operator, which pattern-matches the flag from one command onto
    # another. Nothing ever passed it; the surface was pure risk.
    _workspace_code(None, required=True)
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    if not run_id:
        run_id = _resolve_run_id(store, root_path, None, user_id=uid)
        if not run_id:
            print(json.dumps({"error": "No active runs"}))
            return
    run = _get_run_or_exit(store, run_id)

    # Driver heartbeat: a next-step poll is proof a live driver is attending
    # this run — the run supervisor only resurrects a driver when these
    # beats go stale while runnable steps wait.
    store.touch_driver_heartbeat(run_id)

    # SWEEP THIS RUN BEFORE ANSWERING. The stale-step reaper otherwise lives
    # only in `serve`'s lifespan, so a CLI-detached run (`aicore run --json`,
    # i.e. every dev, demo and CI run) had NO supervision at all: an executor
    # that died without finalizing left its step 'running' for ever, and the
    # driver — which cannot reap — polled around it indefinitely. Observed
    # 2026-08-16 on run_20260816_014506_119845: `remediate`'s subprocess died
    # mid-response (GeneratorExit on the body read), heartbeat froze 21+
    # minutes against a 180s threshold, and the run sat there until a human
    # ran `step-retry --crash-recovery`.
    #
    # next-step is the right home: every driver polls it for the whole life
    # of its run, whatever launched it, so this makes supervision universal
    # instead of a property of the serving topology. resume_drivers=False
    # because the CALLER is the driver — resurrecting another would
    # double-drive the run (the blocking `run` loop passes the same flag).
    # Never let a sweep failure break the poll.
    try:
        from ioagentfarm.engine.supervisor import supervise_once
        for action in supervise_once(store, root_path, run_id=run_id,
                                     resume_drivers=False):
            logger.info("next_step swept run %s: %s", run_id, action)
    except Exception:
        logger.debug("next_step: supervision sweep failed", exc_info=True)

    # Phase 3 / Fix 2 + Fix 4: snapshot Alex's orchestrate session JSONL on
    # every next-step call (Alex's primary action point), AND emit a
    # `agent.next_step_polled` event so we can see when and how often Alex
    # is polling. This is the visibility hook that fills the gap between
    # successful step.finalized events — every poll is captured.
    if not all_runnable:  # the code driver's poll is not a checkpoint
        try:
            from ioagentfarm.engine.forensics import (
                get_forensics, snapshot_orchestrator_session, SEVERITY_INFO,
            )
            snapshot_orchestrator_session(root_path, run_id, uid, label="next_step")
            get_forensics(root_path).emit(
                run_id=run_id, event_type="agent.next_step_polled",
                # (the code driver polls with --all every ~2s; that is a
                # poll, not Alex, and 130 lines of it hid a 250s step)
                severity=SEVERITY_INFO,
                # not "Alex": an operator types this too, and the record
                # credited every poll to the agent (novice, round 6)
                message=f"next-step polled by {uid or 'the driver'} (forensic checkpoint)",
            )
        except Exception:
            logger.debug("Failed to snapshot orchestrate session in next_step", exc_info=True)

    loader = WorkflowLoader()
    wf = loader.load(run["workflow_name"], run_id=run_id, root=root_path)

    steps = store.list_steps(run_id)

    # Check if all steps done
    pending = [s for s in steps if s["status"] in ("pending", "running")]
    if not pending:
        # THIS CLAIM IS A REAL ONE, so it carries the closing work. It is
        # here so a run whose finalizer died still converges - but it races
        # the finalizer, which sets the last step `done` well before it
        # claims, and under `--driver code` this poll runs every two seconds
        # while that child is still alive. Winning and doing nothing left
        # runs `done` with no `run.completed` and no `run.coverage`.
        if store.mark_run_done_if_complete(run_id):
            close_run_record(store, root_path, run_id)
        # `done` IS NOT `succeeded`. This branch printed {"done": true} and
        # nothing else, so a FAILED run announced itself to the driver as
        # finished-and-fine: measured in Phase A round 1, Alex read it and
        # closed the console with "The run is now done: true ... The workflow
        # is complete" on a run whose status was `failed` and whose artifact
        # gate had refused both attempts. The `done: false` branches below
        # already carry `blocked`/`failed_steps` - this was the one exit that
        # dropped the verdict. Same class as the earlier "BLOCKED IS NOT
        # WAITING" fix: the driver is an LLM reading this JSON, and a field
        # it cannot see is a fact it will invent.
        _failed = [s["step_key"] for s in steps if s["status"] == "failed"]
        try:
            _final = (store.get_run(run_id) or {}).get("status")
        except Exception:                  # noqa: BLE001 - never break the poll
            _final = run.get("status")
        payload = {"done": True, "run_id": run_id,
                   "run_status": _final or "unknown",
                   "succeeded": (_final == "done") and not _failed}
        if _failed:
            payload["failed_steps"] = _failed
        print(json.dumps(payload))
        return

    # Find next runnable (pending + deps met)
    step_status = {s["step_key"]: s["status"] for s in steps}

    def _runnable(s) -> bool:
        if s["status"] != "pending":
            return False
        if role and s["role"] != role:
            return False
        deps = json.loads(s["deps_json"] or "[]")
        return all(step_status.get(d) == "done" for d in deps)

    if all_runnable:
        # BOUNDED fan-out. The budget is TOTAL steps in flight, not per call:
        # counting only this call's batch would let repeated polls stack up
        # arbitrarily many children, which is the failure the cap exists to
        # prevent. A loop over 50 clusters therefore trickles 4 at a time.
        cap = _fanout_limit(limit)
        running = sum(1 for s in steps if s["status"] == "running")
        slots = max(0, cap - running)
        batch = []
        for s in steps:
            if len(batch) >= slots:
                break
            if not _runnable(s):
                continue
            info = render_step_prompt(
                store=store, workflow=wf, root=root_path, run_id=run_id, step_key=s["step_key"],
                consume_feedback=False,   # a PEEK - run-step consumes
            )
            if "error" in info:
                print(json.dumps({"error": info["error"]}))
                return
            batch.append({
                "step_key": s["step_key"],
                "role": info["role"],
                "output_dir": info["output_dir"],
                "artifact_dir": info.get("artifact_dir", ""),
            })
        _blocked = _failed_steps_if_run_failed(store, run_id, steps)
        print(json.dumps({
            "done": False,
            "steps": batch,
            # the driver needs both numbers to tell "wait for capacity" from
            # "wait for dependencies" — otherwise an empty list reads as done.
            "running": running,
            "limit": cap,
            "waiting": not batch,
            # BLOCKED IS NOT WAITING - see the singular branch below.
            "blocked": bool(_blocked),
            "failed_steps": _blocked,
            "run_id": run_id,
            "pending_count": len(pending),
        }, indent=2))
        return

    # THE SAME IN-FLIGHT BUDGET APPLIES HERE. It used to bound only the
    # `--all` branch above, so `next-step` handed out another step no matter
    # how many were already running — and the driver calls THIS form, so the
    # cap governed the path that was not being used. Measured live with
    # IOF_FANOUT_MAX_CHILDREN=1: `--all` correctly answered
    # `running: 2, limit: 1, waiting: true` while the singular call, on the
    # same run in the same second, handed out a third step.
    #
    # `_fanout_limit`'s own docstring calls this "how many step children may
    # be in flight at once" and says it lives in code rather than the
    # orchestrate skill precisely because a prompt-level limit is a request
    # the driver does not reliably follow. That reasoning applies to both
    # branches; only one implemented it.
    cap = _fanout_limit()
    running = sum(1 for s in steps if s["status"] == "running")
    if running >= cap:
        print(json.dumps({
            "done": False, "waiting": True, "run_id": run_id,
            "running": running, "limit": cap,
            # ASCII only: this string reaches a console that may be cp437 or
            # cp1252, where a non-ASCII character raises UnicodeEncodeError in
            # the renderer and kills the process AFTER the work is paid for.
            "reason": f"{running} step(s) in flight, limit {cap} "
                      f"(IOF_FANOUT_MAX_CHILDREN) - poll again when one finishes",
            "pending_count": len(pending),
        }, indent=2))
        return

    for s in steps:
        if _runnable(s):
            # Render prompt info
            info = render_step_prompt(
                store=store, workflow=wf, root=root_path, run_id=run_id, step_key=s["step_key"],
                consume_feedback=False,   # a PEEK - run-step consumes
            )
            if "error" in info:
                print(json.dumps({"error": info["error"]}))
                return
            print(json.dumps({
                "done": False,
                "step_key": s["step_key"],
                "role": info["role"],
                "output_dir": info["output_dir"],
                # WHERE THE DELIVERABLE GOES, said rather than implied. See
                # scheduler.render_step_prompt: `output_dir` is the per-step
                # directory (OUTPUT.md), `artifact_dir` is the shared project
                # directory the artifact gate checks and `{{output_dir}}`
                # renders to. A driver reading only the first name wrote to
                # the wrong place in 4 of 6 certification runs.
                "artifact_dir": info.get("artifact_dir", ""),
                "run_id": run_id,
            }, indent=2))
            return

    # Nothing runnable right now (deps not met, or filtered by role).
    #
    # BLOCKED IS NOT WAITING. The engine decides a run cannot converge
    # (`mark_run_failed_if_stuck`, at every finalization) and sets the run
    # failed; this command then answered `waiting` anyway, because it never
    # looked at run status - and neither did the code driver, which sat on
    # its 600s stall timer for a run the engine had failed at 9s. Relay the
    # verdict, so a driver stops at once and a person can `step-retry`.
    _blocked = _failed_steps_if_run_failed(store, run_id, steps)
    if _blocked:
        print(json.dumps({
            "done": False, "waiting": False, "blocked": True, "run_id": run_id,
            "failed_steps": _blocked, "pending_count": len(pending),
            "reason": (f"step(s) {_blocked} failed on their last attempt and nothing "
                       f"is running - the run cannot advance; `aicore step-retry "
                       f"--step-key <key> --run-id {run_id}` to try again"),
        }, indent=2))
        return
    print(json.dumps({"done": False, "waiting": True, "run_id": run_id, "pending_count": len(pending)}))


def step_complete(
    run_id: str = typer.Option(None, help="Run ID (omit for latest active run)"),
    step_key: str = typer.Option(..., help="Step key (e.g. analyze, implement)"),
    output_file: str = typer.Option(None, help="Path to OUTPUT.md written by sub-agent"),
    output: str = typer.Option(None, help="Inline output text (alternative to --output-file)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
):
    """Parse output file or inline text, update store, write progress. Returns JSON with status and next step info."""
    from ioagentfarm.cli import _root, _store, _default_user_id, _resolve_run_id, _get_run_or_exit

    # Resolve the workspace BEFORE touching the store: that is what loads
    # `~/.iobot/workspaces/<code>/.env`, and therefore IOF_DATABASE_URL.
    # Without it these commands silently read the DEFAULT local sqlite while
    # `run --workspace X` wrote X's database — so an operator reaching for
    # recovery during an incident was told 'Run not found' (2026-08-16).
    from ioagentfarm.cli import _workspace_code
    # NO --workspace on a write, by design (the `aicore drafts apply` precedent):
    # activation is the ONE way to choose the tenant a mutation lands in. A flag
    # that can disagree with it is a footgun — activate ws1, pass --workspace ws2,
    # and 'which workspace did I just write into?' has two answers. Refusing a
    # mismatch is weaker than not being able to express it.
    _workspace_code(None, required=True, write=True)

    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    if not run_id:
        run_id = _resolve_run_id(store, root_path, None, user_id=uid)
        if not run_id:
            print(json.dumps({"error": "No active runs"}))
            raise typer.Exit(code=1)
    run = _get_run_or_exit(store, run_id)

    # Driver heartbeat: step-complete is a driver action point.
    store.touch_driver_heartbeat(run_id)

    # Fix 2: snapshot Alex's orchestrate session at the step-complete checkpoint
    try:
        from ioagentfarm.engine.forensics import snapshot_orchestrator_session
        snapshot_orchestrator_session(root_path, run_id, uid, label="step_complete")
    except Exception:
        logger.debug("Failed to snapshot orchestrate session in step_complete", exc_info=True)

    loader = WorkflowLoader()
    wf = loader.load(run["workflow_name"], run_id=run_id, root=root_path)

    # Delegation guard — symmetric to run-step's project_lead guard (run_step()
    # refuses project_lead steps). `step-complete` performs INLINE completion:
    # the orchestrator (project_lead / Alex) supplies the output itself. That is
    # only correct for project_lead steps. For any OTHER role the work MUST run
    # in that role's own agent via `run-step` — so it executes with the right
    # skills + workspace AND its LLM calls are token-captured in that step's
    # subprocess. Alex is an LLM and has been observed completing sub-agent steps
    # inline (running discover_barriers/review himself in the orchestrate
    # session), which both bypasses the correct agent and leaves those calls
    # attributed to the orchestrator instead of the step. A prose rule
    # ("delegate, never implement") doesn't reliably hold, so we refuse it
    # structurally: the only path to complete a non-project_lead step is
    # run-step. Escape hatch: IOF_ALLOW_INLINE_STEP_COMPLETE=1.
    _steps_now = store.list_steps(run_id)
    _srow = next((s for s in _steps_now if s["step_key"] == step_key), None)
    _srole = (_srow or {}).get("role", "") or ""
    if (
        _srole
        and _srole != "project_lead"
        and os.environ.get("IOF_ALLOW_INLINE_STEP_COMPLETE", "").lower()
        not in ("1", "true", "yes")
    ):
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.inline_complete_refused",
                severity=SEVERITY_WARN, step_key=step_key, role=_srole,
                message=(
                    f"Refused inline step-complete for non-project_lead step "
                    f"'{step_key}' (role={_srole}); orchestrator must delegate via run-step."
                ),
            )
        except Exception:
            logger.debug("Failed to emit inline_complete_refused event", exc_info=True)
        print(json.dumps({
            "error": (
                f"Step '{step_key}' has role '{_srole}', not project_lead - do NOT "
                f"complete it inline. Delegate it to its agent:\n"
                f"  ioagentfarm run-step --step-key {step_key} --run-id {run_id} --user-id {uid}\n"
                f"step-complete is for project_lead (inline) steps only. Running a "
                f"sub-agent step yourself skips its skills/workspace and its token capture."
            ),
            "delegate_via": "run-step",
            "step_key": step_key,
            "role": _srole,
            "run_id": run_id,
        }))
        raise typer.Exit(code=1)

    # THE CAP APPLIES TO THE INLINE PATH TOO. `run-step` refuses to spawn past
    # the ceiling, and a `project_lead` step never goes through `run-step` -
    # `run_step()` sends the caller here instead. So the only path the DRIVER's
    # own steps take had no cap and no attempt guard at all, and every probe in
    # the certification campaign was on it. Round 6 proved it with zero model
    # calls: with the step at attempt 6 and `hard_cap=3`, `step-complete` was
    # ACCEPTED, advanced the attempt to 7, and handed the same step straight
    # back as `next_step_key` - 36 calls and $0.97 in three and a half minutes
    # on a step declaring `max_attempts: 1`, at the same burn rate as the
    # uncapped round-5 run. The fix that "bounded retries" bounded one of two
    # paths.
    #
    # Same formula and the same declared anchor as the other two sites, so a
    # step cannot be retried past the ceiling by any route.
    if _srow is not None:
        try:
            _cap_mult_i = int(os.environ.get(
                "IOF_HARD_ATTEMPT_CAP_MULTIPLIER", "2"))
            _cap_i = _declared_max_attempts(_srow) * _cap_mult_i + 1
            _att_i = int(_srow.get("attempt") or 0)
        except Exception:                  # noqa: BLE001 - never break a step
            _cap_i, _att_i = 0, 0
        if _cap_i and _att_i >= _cap_i:
            try:
                from ioagentfarm.engine.forensics import (SEVERITY_FATAL,
                                                          get_forensics)
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="step.hard_cap_reached",
                    severity=SEVERITY_FATAL, step_key=step_key, role=_srole,
                    message=(
                        f"Hard attempt cap reached inline (current={_att_i}, "
                        f"cap={_cap_i}, declared max_attempts="
                        f"{_declared_max_attempts(_srow)}). Refusing to "
                        "complete this step again."),
                    payload={"current_attempt": _att_i, "hard_cap": _cap_i,
                             "declared_max_attempts":
                                 _declared_max_attempts(_srow),
                             "cap_multiplier": _cap_mult_i, "path": "inline"},
                )
            except Exception:              # noqa: BLE001
                logger.debug("Failed to emit inline hard_cap_reached",
                             exc_info=True)
            try:
                store.set_step_output(
                    run_id, step_key, "failed",
                    f"Hard attempt cap reached ({_att_i} attempts, ceiling "
                    f"{_cap_i}). Not retried again.")
                store.mark_run_failed_if_stuck(run_id)
            except Exception:              # noqa: BLE001
                logger.debug("Failed to fail the capped step", exc_info=True)
            print(json.dumps({
                "error": (
                    f"Step '{step_key}' has reached the hard attempt cap "
                    f"({_att_i} attempts; ceiling {_cap_i} = declared "
                    f"max_attempts x {_cap_mult_i} + 1). It will not be run "
                    "again. Stop retrying this step and report what failed - "
                    "the run is marked failed and the cause is on the record "
                    f"(`aicore forensics explain {run_id}`)."),
                "hard_attempt_cap_reached": True,
                "attempt": _att_i, "hard_cap": _cap_i,
                "step_key": step_key, "run_id": run_id,
            }))
            raise typer.Exit(code=1)

    # Determine raw output text from --output-file or --output
    has_file = False
    if output:
        raw = output
    elif output_file:
        output_path = Path(output_file).resolve()
        if not output_path.exists():
            # Fallback: check IOBOT_WORKSPACE (write_file and exec resolve paths differently)
            ws = os.environ.get("IOBOT_WORKSPACE", "")
            if ws:
                ws_path = Path(ws) / Path(output_file).name
                if ws_path.exists():
                    output_path = ws_path
            # Also check the project directory (agents sometimes write there)
            if not output_path.exists() and run:
                proj = run.get("project_dir", "")
                if proj:
                    proj_path = Path(proj) / Path(output_file).name
                    if proj_path.exists():
                        output_path = proj_path
        if not output_path.exists():
            print(json.dumps({"error": f"Output file not found: {output_file}"}))
            raise typer.Exit(code=1)
        raw = output_path.read_text(encoding="utf-8")
        has_file = True
    else:
        print(json.dumps({"error": "Provide --output-file or --output"}))
        raise typer.Exit(code=1)

    # Bump attempt counter (consistent with run-step behavior)
    store.bump_step_attempt(run_id, step_key)

    # Resolve role and workspace for memory persistence
    steps = store.list_steps(run_id)
    step_row = next((s for s in steps if s["step_key"] == step_key), None)
    step_role = step_row["role"] if step_row else ""
    step_workspace = Path(output_file).resolve().parent if has_file and step_role else None

    result = _finalize_step(
        store=store,
        root_path=root_path,
        run_id=run_id,
        step_key=step_key,
        raw=raw,
        wf=wf,
        role=step_role,
        agent_workspace=step_workspace,
    )
    _emit_finalized(root_path, run_id, step_key,
                    int(step_row["attempt"]) if step_row else None, step_role, result)
    print(json.dumps(result, indent=2))


def _emit_finalized(root_path, run_id, step_key, attempt, role, result) -> None:
    """`step.finalized` for the exec and inline (step-complete) paths.

    The agent path emitted it; these two did not, so an exec step's OTel span
    never closed and never left the process - a routed run exported two roots
    and nothing under them. Same event, same payload, so every reader treats
    the three paths alike.
    """
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_ERROR, SEVERITY_INFO
        final_status = (result or {}).get("status", "unknown")
        get_forensics(root_path).emit(
            run_id=run_id, event_type="step.finalized",
            severity=SEVERITY_ERROR if final_status == "failed" else SEVERITY_INFO,
            step_key=step_key, attempt=attempt, role=role,
            message=f"_finalize_step completed with status={final_status}",
            payload={"status": final_status,
                     "next_step_key": (result or {}).get("next_step_key")})
    except Exception:
        logger.debug("Failed to emit step.finalized", exc_info=True)


def _kill_tree(proc) -> None:
    """Kill *proc* AND everything it started.

    `shell=True` means the child is a shell and the real work is its
    grandchild. Killing the shell alone leaves that grandchild running, still
    holding the inherited pipe handles - which is what made a timeout a
    verdict rather than a bound.
    """
    import signal
    if os.name == "nt":
        # taskkill walks the tree by PID; there is no process-group signal
        # on Windows that reaches a shell's grandchildren reliably.
        try:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           capture_output=True, timeout=20)
            return
        except Exception:  # noqa: BLE001 - fall through to the plain kill
            logger.debug("taskkill failed for pid %s", proc.pid, exc_info=True)
    else:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            return
        except Exception:  # noqa: BLE001
            logger.debug("killpg failed for pid %s", proc.pid, exc_info=True)
    try:
        proc.kill()
    except Exception:  # noqa: BLE001
        logger.debug("kill failed for pid %s", proc.pid, exc_info=True)


def run_bounded(command: str, *, cwd: str, env: dict, timeout_s: int,
                source: str = "IOF_EXEC_STEP_TIMEOUT_S"):
    """Run *command* under a real wall-clock bound. Returns (rc, out, err).

    `subprocess.run(..., shell=True, timeout=N)` does NOT bound wall clock:
    it kills the shell at N and then blocks reading pipes the surviving
    grandchild still holds, so a 2s timeout on a 30s command returned after
    30s - measured. The step was marked failed at the right time while the
    work kept running, which for a pipeline whose timeout classes exist to
    stop runaway queries is the half that mattered.

    *source* names where the number came from, so the log does not send a
    reader to an env var when the step set its own ceiling.
    """
    popen_kwargs = {}
    if os.name != "nt":
        # Own process group, so one signal reaches the whole tree.
        popen_kwargs["start_new_session"] = True

    proc = subprocess.Popen(
        command, shell=True, cwd=cwd, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="replace", **popen_kwargs,
    )
    try:
        stdout, stderr = proc.communicate(timeout=timeout_s)
        return proc.returncode, stdout or "", stderr or ""
    except subprocess.TimeoutExpired:
        _kill_tree(proc)
        try:
            # The tree is dead, so the pipes close and this returns at once.
            # Bounded anyway: a handle we failed to kill must not hang the
            # step for ever in the very path that exists to stop that.
            stdout, stderr = proc.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            stdout, stderr = "", ""
            logger.warning("exec step: process tree survived the kill; "
                           "output discarded (pid %s)", proc.pid)
        note = (f"\n[exec step timed out after {timeout_s}s "
                f"({source}); process tree killed]")
        return -1, stdout or "", (stderr or "") + note


def _artifact_snapshot(d) -> dict:
    """name -> (mtime_ns, size) for every REAL file under the artifact dir.

    Round 9, S6-2: "a self-referential symlink cycle into `.iof` hangs the
    gate's directory walk". Two things had to be true at once and both were:

    * `Path.rglob("*")` expands `**`, which followed directory links until
      Python 3.13 made `recurse_symlinks=False` the default - so the walk
      terminates on 3.13+ and cycles on 3.11/3.12. The container ships 3.12
      and this repo's dev box runs 3.14: reproducible in the pod, invisible
      here.
    * `os.walk(followlinks=False)` is NOT the fix, which is only obvious
      once you run it. On Windows a JUNCTION is a reparse point but not a
      symlink, `DirEntry.is_symlink()` says False, and the walk descends
      it happily - measured here at ~63 levels of `a/b/up/a/b/up/...`,
      stopped by MAX_PATH rather than by any guard.

    So the walk resolves each directory and refuses one it has already
    visited or that leaves the artifact directory. That is the same rule
    the gate already applies to an artifact NAME (round 6: an artifact
    resolving outside the artifact directory is refused), applied to the
    walk that finds them - a link out of the tree is not this directory's
    content whether it cycles or not.
    """
    import os as _os
    base = Path(d)
    try:
        root_real = base.resolve(strict=True)
    except OSError:
        return {}
    out: dict = {}
    seen: set = {root_real}
    stack: list = [(base, root_real)]
    while stack:
        here, here_real = stack.pop()
        try:
            entries = list(_os.scandir(here))
        except OSError:
            continue
        for e in entries:
            try:
                if e.is_dir(follow_symlinks=False) or e.is_junction():
                    child = Path(e.path)
                    try:
                        child_real = child.resolve(strict=True)
                    except OSError:
                        continue
                    if child_real in seen:
                        continue          # a cycle - junction or symlink
                    if not child_real.is_relative_to(root_real):
                        continue          # a link OUT of the artifact dir
                    seen.add(child_real)
                    stack.append((child, child_real))
                elif e.is_file(follow_symlinks=False):
                    st = e.stat()
                    out[str(Path(e.path).relative_to(base)).replace("\\", "/")] = (
                        st.st_mtime_ns, st.st_size)
            except OSError:
                continue
    return out


def _run_exec_step(
    *,
    store,
    root_path: Path,
    run_id: str,
    step_key: str,
    step_def,
    info: dict,
    step_row: dict,
    wf,
    run: dict,
) -> None:
    """Execute a ``type: exec`` step: run its command directly, no agent.

    Mirrors the agent path's contract exactly - hard attempt cap, claim,
    OUTPUT.md protocol artifact, then the shared ``_finalize_step`` (which
    applies requires_artifacts, materializes stories, emits forensics and
    advances the pipeline). STORIES_JSON comes deterministically from the
    ``stories_from`` manifest instead of an LLM transcription, which removes
    the copy-fragility class the loop-stories gate exists to catch.
    """
    import subprocess
    import time as _time

    # Hard attempt cap — same formula as the agent path. Retries are cheap
    # here, but the cap is what guarantees convergence under crash-recovery.
    _cap_multiplier = int(os.environ.get("IOF_HARD_ATTEMPT_CAP_MULTIPLIER", "2"))
    _hard_cap = _declared_max_attempts(step_row) * _cap_multiplier + 1
    if int(step_row["attempt"]) >= _hard_cap:
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_FATAL
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.hard_cap_reached",
                severity=SEVERITY_FATAL, step_key=step_key, role=step_def.role,
                message=f"exec step reached hard attempt cap ({_hard_cap}); refusing to run.",
                payload={"attempt": int(step_row["attempt"]), "hard_cap": _hard_cap},
            )
        except Exception:
            logger.debug("Failed to emit step.hard_cap_reached", exc_info=True)
        with store._tx() as cursor:
            cursor.execute(
                store._q("UPDATE steps SET status='failed', updated_at=? WHERE run_id=? AND step_key=?"),
                (store._now(), run_id, step_key),
            )
        print(json.dumps({
            "run_id": run_id, "step_key": step_key, "status": "failed",
            "reason": "hard_attempt_cap_reached", "hard_cap": _hard_cap,
        }, indent=2))
        # NON-ZERO, LIKE THE OTHER TWO CAP REFUSALS. This printed
        # `status: failed, reason: hard_attempt_cap_reached` and then exited
        # 0, so a wrapper checking `$?` read a capped step as a success
        # (certification round 7) - and `run-step` already exits 1 for a
        # wrong-state step, so 0 did not mean "ran fine" here either. All
        # three refusals now agree.
        raise typer.Exit(code=1)

    # Claim: bump attempt + mark running (skip if already running)
    if step_row["status"] != "running":
        store.bump_step_attempt(run_id, step_key)
        with store._tx() as cursor:
            _claim_now = store._now()
            cursor.execute(
                store._q("UPDATE steps SET status='running', heartbeat_at=?, updated_at=? WHERE run_id=? AND step_key=?"),
                (_claim_now, _claim_now, run_id, step_key),
            )

    # The attempt this execution IS - read back after the claim, so the span
    # the listener opens here and closes at finalization share one number.
    _att = next((int(r["attempt"]) for r in store.list_steps(run_id)
                 if r["step_key"] == step_key), int(step_row["attempt"]))
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO
        get_forensics(root_path).emit(
            run_id=run_id, event_type="step.exec_started", severity=SEVERITY_INFO,
            step_key=step_key, attempt=_att, role=step_def.role,
            message=f"exec step starting (attempt {_att})",
            payload={"workflow": wf.name, "command": (info.get("command") or "")[:300]})
    except Exception:
        logger.debug("Failed to emit step.exec_started", exc_info=True)

    step_dir = Path(info["output_dir"])
    step_dir.mkdir(parents=True, exist_ok=True)
    command = (info.get("command") or "").strip()
    # The step's own `timeout:` wins; the env var is the deployment default.
    # A ported pipeline states its per-activity timeout classes on the steps,
    # and reading them from one global would silently apply the wrong one.
    timeout_s = int(getattr(step_def, "timeout", None)
                    or os.environ.get("IOF_EXEC_STEP_TIMEOUT_S", "600"))
    cwd = run.get("project_dir") or str(root_path)
    # Console scripts (iof-signal-prep, iof-query, ...) live next to the
    # interpreter running this orchestrator; the caller's PATH may not
    # include that dir (observed: exec from a shell that never activated
    # the venv). Prepend it so pack tools resolve exactly as they do for
    # agent exec calls.
    env = os.environ.copy()
    env["PATH"] = str(Path(sys.executable).parent) + os.pathsep + env.get("PATH", "")
    # THE TOOL-SIDE CONTRACT (ioagentfarm.sdk). Where artifacts go - the SHARED
    # dir, where requires_artifacts is checked and where `route.fail()` has to
    # put a feedback file for the engine to find it - which run and step this
    # is, and whatever a previous attempt left as feedback. Env rather than
    # flags so a tool needs no new arguments to take part.
    from ioagentfarm.engine.iobot_config import get_run_output_dir as _grod
    env["IOF_ARTIFACT_DIR"] = str(_grod(root_path, run_id))
    env["IOF_RUN_ID"] = run_id
    env["IOF_STEP_KEY"] = step_key
    env["IOF_STEP_DIR"] = str(step_dir)
    # The step span's traceparent, so a tool that uses ioagentfarm.sdk.obs
    # joins this run's trace. No-op (env untouched) when export is off.
    try:
        from ioagentfarm.engine import otel_export as _otel
        _otel.child_env(env, root_path, run_id, step_key, _att)
    except Exception:
        logger.debug("otel child env failed", exc_info=True)
    _fb = str(info.get("feedback") or "")
    if _fb.strip():
        env["IOF_STEP_FEEDBACK"] = _fb
    # The file `route.fail()` writes must be the one `on_fail.feedback`
    # declares. The SDK defaulted to feedback.md whatever the YAML said,
    # so the note was lost and the run went green (novice, round 6).
    try:
        _of = getattr(step_def, "on_fail", None)
        if _of is not None and getattr(_of, "feedback", None):
            env["IOF_FEEDBACK_FILE"] = str(_of.feedback)
    except Exception:  # noqa: BLE001
        pass

    # Run-supervisor heartbeat: tick steps.heartbeat_at every ~30s while the
    # exec command runs so a long-running (but alive) exec step is never
    # mistaken for a dead one. If this orchestrator process dies mid-exec,
    # beats stop and the supervisor reaps the step.
    import threading as _threading
    _hb_stop = _threading.Event()

    def _exec_heartbeat_loop() -> None:
        while not _hb_stop.wait(10.0):   # under any sane step-stale threshold
            store.touch_step_heartbeat(run_id, step_key)

    _threading.Thread(
        target=_exec_heartbeat_loop, name=f"iof-exec-heartbeat-{step_key[:24]}",
        daemon=True,
    ).start()

    # What this attempt WRITES into the shared artifact directory - the one
    # data-flow fact a command step can record about itself. Two steps
    # naming one file is then a warning explain can raise (novice finding).
    _art = _grod(root_path, run_id)
    _before = _artifact_snapshot(_art)
    started = _time.time()
    rc, stdout, stderr = 1, "", ""
    try:
        if not command:
            stderr = "exec step rendered an empty command"
        else:
            try:
                rc, stdout, stderr = run_bounded(
                    command, cwd=cwd, env=env, timeout_s=timeout_s,
                    source=("the step's `timeout:`"
                            if getattr(step_def, "timeout", None)
                            else "IOF_EXEC_STEP_TIMEOUT_S"),
                )
            except OSError as e:
                rc = -2
                stderr = f"failed to launch command: {e}"
    finally:
        _hb_stop.set()
    duration = _time.time() - started
    _after = _artifact_snapshot(_art)
    _wrote = sorted(k for k, v in _after.items() if _before.get(k) != v)

    # Forensics-lite: the full stdout/stderr always land next to OUTPUT.md.
    try:
        (step_dir / "_exec_stdout.log").write_text(stdout, encoding="utf-8")
        (step_dir / "_exec_stderr.log").write_text(stderr, encoding="utf-8")
    except OSError:
        logger.debug("Failed to write exec logs", exc_info=True)
    # Per-attempt forensics, the bundle shape the agent path keeps, so
    # `forensics blob/explain` read a command step too and an earlier
    # attempt SURVIVES the next one - the retry used to overwrite the only
    # record of why the first attempt failed (novice finding).
    try:
        _fdir = (Path(root_path) / "instances" / run_id / "forensics"
                 / "attempts"
                 / f"{step_key.replace(':', '_').replace('/', '_')}.{_att}")
        _fdir.mkdir(parents=True, exist_ok=True)
        (_fdir / "stdout.log").write_text(stdout, encoding="utf-8")
        (_fdir / "stderr.log").write_text(stderr, encoding="utf-8")
        (_fdir / "command.txt").write_text(command or "", encoding="utf-8")
        (_fdir / "exit.json").write_text(json.dumps({
            "kind": "exec", "rc": rc, "duration_s": round(duration, 3),
            "timeout_s": timeout_s, "attempt": _att, "step_key": step_key,
            "timed_out": "timed out after" in (stderr or ""),
            "wrote": _wrote[:100],
            # `forensics stats` read null for every command attempt while
            # exit.json held the answer (novice, round 6): the same keys an
            # agent attempt records, so one reader serves both.
            "exit_code": rc,
            "ended_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
            "started_at": (__import__("datetime").datetime.now(__import__("datetime").timezone.utc)
                           - __import__("datetime").timedelta(seconds=float(duration or 0))).isoformat(),
        }, indent=2), encoding="utf-8")
    except OSError:
        logger.debug("Failed to write exec forensics", exc_info=True)

    # Deterministic stories: read the manifest the tool wrote. Missing or
    # malformed manifest => failed (fail-closed, same spirit as the gate).
    stories_line = ""
    stories_err = ""
    if rc == 0 and step_def.stories_from:
        from ioagentfarm.engine.iobot_config import get_run_output_dir
        manifest_path = Path(get_run_output_dir(root_path, run_id)) / step_def.stories_from
        try:
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            stories = data.get("stories", []) if isinstance(data, dict) else data
            if not isinstance(stories, list):
                raise ValueError(f"'stories' in {step_def.stories_from} is not a list")
            stories_line = "STORIES_JSON: " + json.dumps(stories)
            if stories and not (getattr(step_def, "per_item_steps", None) or []):
                # 1,000 story rows sat `pending` under a `done` run - the
                # step declared no per_item_steps, so nothing was ever going
                # to fan out and a dashboard read 0 % (novice, round 6).
                # Record the count; materialise nothing.
                try:
                    from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
                    get_forensics(root_path).emit(
                        run_id=run_id, event_type="step.stories_unconsumed", severity=SEVERITY_WARN,
                        step_key=step_key, role=step_def.role,
                        message=(f"'{step_key}' listed {len(stories)} item(s) in {step_def.stories_from} "
                                 "but declares no per_item_steps - nothing fans out over them; "
                                 "the tool is expected to have processed them itself (drop "
                                 "`stories_from`, or add `per_item_steps:`)"),
                        payload={"manifest": step_def.stories_from, "items": len(stories)})
                except Exception:  # noqa: BLE001
                    pass
                stories_line = ""
            if not stories:
                # a zero-item fan-out converged green in silence; the same
                # empty list from a route step warns (novice finding)
                try:
                    from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
                    get_forensics(root_path).emit(
                        run_id=run_id, event_type="step.fanout_empty", severity=SEVERITY_WARN,
                        step_key=step_key, role=step_def.role,
                        message=(f"'{step_key}' produced ZERO items in {step_def.stories_from} - "
                                 "no per-item step will run and every step downstream runs "
                                 "over nothing"),
                        payload={"manifest": step_def.stories_from})
                except Exception:  # noqa: BLE001
                    pass
        except (OSError, ValueError, json.JSONDecodeError) as e:
            stories_err = f"stories_from '{step_def.stories_from}': {e}"

    ok = rc == 0 and not stories_err
    tail = stdout.strip()[-1500:]
    _timed_out = "timed out after" in (stderr or "")
    # Each stream under its own marker: a JSON-on-stdout plus warnings-on-
    # stderr step used to yield an OUTPUT block where nothing said which
    # line came from where (novice finding).
    # A COMMAND'S OUTPUT IS DATA, NOT PROTOCOL. A tool that printed
    # `STATUS: done` and exited 1 went green: the tails are part of the
    # record, the record is parsed as KEY: value, and the tool's line came
    # last (novice finding, round 7). Every protocol key line inside the
    # tails is shielded with a visible `| ` before the record is composed,
    # so the exit code is the only verdict. ROUTE_JSON is the one line a
    # tool IS meant to print - it is read from the FULL stdout below, never
    # from stderr, and appended clean for route steps.
    from ioagentfarm.engine.protocol import _KNOWN_KEYS as _PKEYS

    def _shield(text: str) -> str:
        out = []
        for _ln in (text or "").splitlines():
            _k = _ln.split(":", 1)[0].strip() if ":" in _ln else ""
            out.append(("| " + _ln) if _k in _PKEYS else _ln)
        return "\n".join(out)

    _route_lines = [ln.split(":", 1)[1].strip() for ln in (stdout or "").splitlines()
                    if ln.split(":", 1)[0].strip() == "ROUTE_JSON" and ":" in ln]
    _route_value = _route_lines[-1] if _route_lines else None
    if len(_route_lines) > 1:
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.route_ambiguous", severity=SEVERITY_WARN,
                step_key=step_key, role=step_def.role,
                message=(f"'{step_key}' printed {len(_route_lines)} ROUTE_JSON lines - the LAST "
                         f"one decides ({_route_value}); a route step must print exactly one"),
                payload={"choices": _route_lines[:10]})
        except Exception:  # noqa: BLE001
            pass
    tail = _shield(tail)
    _err_tail = _shield(stderr.strip()[-800:])
    if ok:
        summary = f"exec step completed in {duration:.1f}s (exit 0): {command}"
        if tail:
            summary += "\n\n--- stdout (tail) ---\n" + tail
        if _err_tail:
            summary += "\n\n--- stderr (tail) ---\n" + _err_tail
        raw = "STATUS: done\nOUTPUT: " + summary
        if stories_line:
            raw += "\n" + stories_line
        if getattr(step_def, "type", "") == "route" and _route_value is not None:
            raw += "\nROUTE_JSON: " + _route_value
    else:
        err_tail = _shield((stderr.strip() or tail or "(no output)")[-1500:])
        reason = stories_err or f"exit code {rc}"
        raw = (
            "STATUS: failed\nOUTPUT: "
            + f"exec step failed ({reason}) after {duration:.1f}s: {command}"
            + ("\n\n--- stderr (tail) ---\n" if stderr.strip()
               else "\n\n--- stdout (tail) ---\n")
            + err_tail
        )

    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO, SEVERITY_ERROR
        get_forensics(root_path).emit(
            run_id=run_id,
            event_type="step.exec_completed" if ok else "step.exec_failed",
            severity=SEVERITY_INFO if ok else SEVERITY_ERROR,
            step_key=step_key, role=step_def.role,
            message=(f"exec step {'completed' if ok else 'FAILED'} in "
                     f"{duration:.1f}s (rc={rc})"
                     + (f" - timed out after {timeout_s}s" if _timed_out else "")),
            payload={"command": command, "rc": rc, "duration_s": round(duration, 2),
                     "stories_error": stories_err or None, "wrote": _wrote[:100],
                     "declares": list(getattr(step_def, "requires_artifacts", None) or [])},
        )
    except Exception:
        logger.debug("Failed to emit exec forensic event", exc_info=True)

    # Same protocol artifact an agent would leave behind (resume/debug parity).
    try:
        (step_dir / "OUTPUT.md").write_text(raw, encoding="utf-8")
    except OSError:
        logger.debug("Failed to write exec OUTPUT.md", exc_info=True)

    result = _finalize_step(
        store=store, root_path=root_path, run_id=run_id, step_key=step_key,
        raw=raw, wf=wf, role=step_def.role,
    )
    _emit_finalized(root_path, run_id, step_key, _att, step_def.role, result)
    # A parallel branch's span was missing on the wire while spans.jsonl
    # had it: the batch exporter's atexit flush lost the race at process
    # exit (novice finding, round 7). Flush explicitly, before printing
    # the result the driver waits for.
    try:
        from ioagentfarm.engine import otel_export as _otel
        _otel.flush()
    except Exception:  # noqa: BLE001
        pass
    print(json.dumps(result, indent=2))



def unmet_deps(steps: list, step_key: str) -> list:
    """Dependencies of ``step_key`` that are not 'done' — [] when runnable.

    The DAG is the run's contract; this is the check `run-step` enforces so a
    driver cannot force a step past a failed dependency (observed live: after
    a fail-closed no-data stop, the driver ran every downstream step by key
    and a data-less deliverable reached the staging store).
    """
    row = next((s for s in steps if s["step_key"] == step_key), None)
    if not row:
        return []
    deps = json.loads(row.get("deps_json") or "[]")
    status = {s["step_key"]: s["status"] for s in steps}
    return [d for d in deps if status.get(d) != "done"]


def missing_required_artifacts(required: list, out_dir: Path) -> list:
    """Declared artifacts that are absent or empty in the step output dir."""
    missing = []
    for art in required or []:
        try:
            p = out_dir / art
            if (not p.exists()) or p.stat().st_size == 0:
                missing.append(art)
        except OSError:
            missing.append(art)
    return missing


def _refuse_duplicate_claim(root_path, run_id: str, step_key: str,
                            step_row: dict, why: str) -> None:
    """The second of two run-step calls for one step: say so and exit 1."""
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
        get_forensics(root_path).emit(
            run_id=run_id, event_type="step.duplicate_refused",
            severity=SEVERITY_WARN, step_key=step_key,
            role=step_row.get("role"),
            message=f"Refused a second run-step: {why}.",
            payload={"attempt": step_row.get("attempt"), "reason": "lost_claim"},
        )
    except Exception:
        logger.debug("could not emit step.duplicate_refused", exc_info=True)
    print(json.dumps({
        "error": f"Step '{step_key}' was claimed by another run-step: {why}. "
                 "Refusing to start a second one.",
        "hint": "Wait for it, or use `next-step` to find what is actually runnable.",
        "step_key": step_key,
    }, indent=2))
    raise typer.Exit(code=1)


def _heartbeat_age_s(stamp) -> float | None:
    """Seconds since `stamp`, or None if it cannot be read.

    None means "cannot tell", and every caller treats that as NOT-alive: a guard
    that refuses work because it failed to parse a timestamp would turn a
    clock-format change into a stalled pipeline.
    """
    if not stamp:
        return None
    import datetime as _dt
    try:
        s = str(stamp).strip().replace("Z", "+00:00")
        ts = _dt.datetime.fromisoformat(s)
        now = _dt.datetime.now(_dt.timezone.utc) if ts.tzinfo else _dt.datetime.now()
        return max(0.0, (now - ts).total_seconds())
    except Exception:
        return None


def _place_output_md(found: Path, expected: Path) -> Path:
    """An OUTPUT.md accepted at a path other than the one the finalizer reads
    is copied into place; returns the path the finalizer will read. A file
    already there is left alone - it was accepted first."""
    found, expected = Path(found), Path(expected)
    if found.resolve() == expected.resolve():
        return expected
    if not expected.exists():
        expected.parent.mkdir(parents=True, exist_ok=True)
        expected.write_bytes(found.read_bytes())
    return expected


def _build_smart_continuation(step_key: str, output_dir: Path, failure: dict,
                              output_md: Path | None = None) -> str:
    """Build a targeted continuation using the agent's own plan manifest.

    Recovery hierarchy (checked in order):
      1. _{step_key}_plan.md - the agent's plan manifest listing every
         intended file by name. Written once at step start (replacing
         the old outline), never updated during normal execution
         because file existence IS the checkpoint. Survives any restart
         mode (Fix 6, crash-recovery, pod migration, manual retry).
      2. File listing fallback - if no plan exists (old workflow or
         agent skipped Phase 0), list files on disk so the agent can
         infer what's done without re-reading.

    Workflow-agnostic: no assumptions about section naming, deliverable
    names, or file structure. The plan is in the agent's own words.

    Module-level (not nested in run_step) so the message can be tested:
    tests/test_stall_resume_names_the_output_path.py.
    """
    reason = failure.get("reason", "transient provider error")
    tool_calls = failure.get("tool_calls_made", "?")
    # THE PATH, SPELLED OUT - and the one run_step READS (`output_md`, the
    # step directory), not the project directory this lists deliverables
    # from. The step prompt that named it is behind the stall; asked only
    # for "OUTPUT.md", an agent reconstructed a directory from memory (one
    # segment off), wrote there, verified there, and the step failed twice
    # with every deliverable done. Named as the project's OUTPUT.md instead,
    # the agent wrote THERE - and the step failed a third time.
    output_md_path = Path(output_md) if output_md is not None else output_dir / "OUTPUT.md"
    output_md = output_md_path.as_posix()
    output_md_exists = output_md_path.exists()

    # --- Priority 1: agent's step-prefixed plan manifest ---
    plan_path = plan_manifest_path(output_dir, step_key)
    plan_content = None
    if plan_path.exists():
        try:
            plan_content = plan_path.read_text(encoding="utf-8").strip()
        except Exception:
            pass

    if plan_content:
        msg = (
            f"Your prior attempt was interrupted ({reason}) after {tool_calls} tool calls. "
            f"Your session context is preserved.\n\n"
            f"Here is your plan manifest from before the interruption:\n\n"
            f"```markdown\n{plan_content}\n```\n\n"
            f"Files on disk: {', '.join(f.name for f in sorted(output_dir.iterdir()) if f.is_file()) if output_dir.exists() else '(empty)'}\n\n"
            f"Compare your plan against the file listing. Files on disk = done. "
            f"Missing files = your remaining work. Resume from the first missing file. "
        )
        if output_md_exists:
            msg += (
                "OUTPUT.md already exists — verify it satisfies the step's FULL "
                "output format from the original instructions: STATUS and OUTPUT, "
                "plus every other key the step requires (e.g. STORIES_JSON for a "
                "story-producing step). STATUS/OUTPUT alone is NOT sufficient "
                "for such steps."
            )
        else:
            msg += (
                f"OUTPUT.md is still MISSING — that is the last file the "
                f"orchestrator needs. Write it to {output_md} per the step's "
                f"ORIGINAL output format: STATUS, OUTPUT, plus every other key "
                f"the instructions require (e.g. STORIES_JSON).\n\n"
                "DO NOT re-read files that already exist on disk. "
                "Every assistant turn MUST contain a tool_use block."
            )
        return msg

    # --- Priority 2: file listing fallback (no _plan.md found) ---
    file_list = []
    try:
        for f in sorted(output_dir.iterdir()):
            if f.is_file():
                sz = f.stat().st_size
                file_list.append(f"  {f.name}  ({sz:,} bytes)")
    except Exception:
        file_list.append("  (could not list output directory)")
    inv_text = "\n".join(file_list) if file_list else "  (empty directory)"

    msg = (
        f"Your prior attempt was interrupted ({reason}) after {tool_calls} tool calls. "
        f"Your session context is preserved.\n\n"
        f"No plan manifest found (_{step_key}_plan.md). Files currently on disk:\n\n{inv_text}\n\n"
    )
    if output_md_exists:
        msg += (
            "OUTPUT.md exists — verify it satisfies the step's FULL output format "
            "(STATUS, OUTPUT, plus every other key the step instructions require, "
            "e.g. STORIES_JSON) and finish any remaining work."
        )
    else:
        msg += (
            f"OUTPUT.md is MISSING — the orchestrator needs it to mark the step "
            f"done, and it reads it at exactly {output_md}.\n\n"
            "DO NOT re-read files already in your context. DO NOT glob or list_dir to "
            "'re-discover' the project — the listing above shows everything.\n"
            "Resume your remaining work, then write OUTPUT.md following the step's "
            "ORIGINAL output format instructions — STATUS: done, OUTPUT: <summary>, "
            "plus every other key the step requires (e.g. STORIES_JSON for a "
            "story-producing step).\n\n"
            "Every assistant turn MUST contain a tool_use block."
        )
    return msg


def run_step(
    step_key: str = typer.Option(..., help="Step key to execute (e.g. analyze, implement)"),
    run_id: str = typer.Option(None, help="Run ID (omit for latest active run)"),
    extra_context: str = typer.Option("", help="Ad-hoc guidance from Project Lead"),
    background: bool = typer.Option(False, "--background", help="Run in background (fire-and-forget for gateway mode)"),
    reentrant: bool = typer.Option(
        False, "--reentrant", hidden=True,
        help="Internal: this process IS the detached child of a --background "
             "spawn, and is expected to find its own step already 'running'."),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    ignore_deps: bool = typer.Option(False, "--ignore-deps", hidden=True, help="OPERATOR OVERRIDE (requires IOF_OPERATOR_OVERRIDE=1 in the operator's shell): run the step even though a dependency is not done. Forensically recorded."),
):
    """Execute a sub-agent step end-to-end: render prompt, invoke agent, record result.

    Single CLI call for step execution. Used by Alex in both sync and
    gateway modes (with --background for fire-and-forget).

    In sync mode (default): blocks until the agent finishes, returns JSON with result.
    In background mode (--background): launches a detached process and returns immediately.
    The detached process runs the same sync logic - gateway mode polls via next-step.

    Examples:
      ioagentfarm run-step --step-key analyze --run-id <id> --user-id cli:user
      ioagentfarm run-step --step-key implement --run-id <id>
      ioagentfarm run-step --step-key analyze --run-id <id> --background  # gateway mode
    """
    from ioagentfarm.cli import (
        _root, _store, _default_user_id, _resolve_run_id, _get_run_or_exit,
        _invoke_agent, _launch_detached, _workspace_code,
    )

    # Fail closed on the tenant BEFORE seeding or spawning anything. The
    # driver's env (IOF_WORKSPACE, stamped at spawn) satisfies resolution;
    # with nothing anywhere this refuses instead of running the step under a
    # silently-chosen persona in a workspace nobody named.
        # NO --workspace on run/step commands, by design. Activation (or the
    # driver's inherited IOF_WORKSPACE) is the ONE way to choose the tenant,
    # and every command prints a context line naming it. A flag that can
    # disagree with the activation is a footgun for a human and worse for an
    # LLM operator, which pattern-matches the flag from one command onto
    # another. Nothing ever passed it; the surface was pure risk.
    _workspace_code(None, required=True)

    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    if not run_id:
        run_id = _resolve_run_id(store, root_path, None, user_id=uid)
        if not run_id:
            print(json.dumps({"error": "No active runs"}))
            raise typer.Exit(code=1)
    run = _get_run_or_exit(store, run_id)

    loader = WorkflowLoader()
    wf = loader.load(run["workflow_name"], run_id=run_id, root=root_path)

    # Render the step prompt
    info = render_step_prompt(
        store=store, workflow=wf, root=root_path, run_id=run_id, step_key=step_key,
    )
    if "error" in info:
        print(json.dumps({"error": info["error"]}))
        raise typer.Exit(code=1)

    # Guard: project_lead steps should be done inline
    if info["role"] == "project_lead":
        print(json.dumps({
            "error": f"Step '{step_key}' is assigned to project_lead. "
                     "Use step-complete --output for inline steps instead."
        }))
        raise typer.Exit(code=1)

    # Check step is pending (or running for background re-entry)
    steps = store.list_steps(run_id)
    step_row = next((s for s in steps if s["step_key"] == step_key), None)
    if not step_row:
        print(json.dumps({"error": f"Step '{step_key}' not found in run {run_id}"}))
        raise typer.Exit(code=1)
    if step_row["status"] not in ("pending", "running"):
        print(json.dumps({"error": f"Step '{step_key}' is '{step_row['status']}', expected 'pending' or 'running'"}))
        raise typer.Exit(code=1)

    # A step that is already `running` has at most one legitimate second caller:
    # the detached child of a `--background` spawn, which the parent marked
    # running before launching it. That child carries --reentrant. Anything else
    # arriving here is a DUPLICATE, and the driver is an LLM that does emit one:
    # observed in run_20260820_072935_532816, two `run-step` calls four seconds
    # apart on story:G02, two subprocesses, two finalizes three minutes apart,
    # the second overlapping the next step and competing with it for the model.
    #
    # Timing cannot separate the two - the background child also arrives seconds
    # after its parent set the heartbeat - which is why the legitimate caller is
    # marked explicitly rather than inferred.
    #
    # A STALE heartbeat is the third case and it is recovery, not duplication:
    # the owning subprocess is gone and the step needs picking up. The staleness
    # measure is the supervisor's own, so the two components cannot disagree
    # about whether a step is still alive.
    if step_row["status"] == "running" and not reentrant:
        _stale_s = float(os.environ.get("IOF_SUPERVISOR_STEP_STALE_S", "180"))
        _beat = step_row.get("heartbeat_at") or step_row.get("updated_at")
        _age = _heartbeat_age_s(_beat)
        _operator_dup = (os.environ.get("IOF_OPERATOR_OVERRIDE", "").strip().lower()
                         in ("1", "true", "yes", "on"))
        if _age is not None and _age < _stale_s and not _operator_dup:
            try:
                from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="step.duplicate_refused",
                    severity=SEVERITY_WARN, step_key=step_key,
                    role=step_row.get("role"),
                    message=(f"Refused a second run-step: a live subprocess owns "
                             f"this step (heartbeat {_age:.0f}s old, stale at "
                             f"{_stale_s:.0f}s)."),
                    payload={"heartbeat_age_s": round(_age, 1),
                             "stale_after_s": _stale_s,
                             "attempt": step_row.get("attempt")},
                )
            except Exception:
                logger.debug("could not emit step.duplicate_refused", exc_info=True)
            print(json.dumps({
                "error": (f"Step '{step_key}' is already running and its subprocess is "
                          f"alive (heartbeat {_age:.0f}s old). Refusing to start a "
                          f"second one."),
                "hint": ("Wait for it, or use `next-step` to find what is actually "
                         "runnable. If the subprocess is genuinely gone, this "
                         "clears itself once the heartbeat passes "
                         f"IOF_SUPERVISOR_STEP_STALE_S ({_stale_s:.0f}s)."),
                "step_key": step_key,
                "heartbeat_age_s": round(_age, 1),
            }, indent=2))
            raise typer.Exit(code=1)
        # Stale: this is recovery, and it is CLAIMED, not assumed. The beat
        # is refreshed only if it still reads the value judged stale above,
        # so two recoverers arriving together cannot both take the step -
        # the second finds a fresh beat and is refused like any duplicate.
        if not _operator_dup and not store.claim_stale_running_step(
                run_id, step_key, step_row.get("heartbeat_at")):
            _refuse_duplicate_claim(
                root_path, run_id, step_key, step_row,
                "another executor took over this stale step first")

    # --- DAG enforcement (2026-08-13) ---
    # run-step is the driver's execution primitive, and the driver is an LLM:
    # observed live, after a fail-closed stop it forced every downstream step
    # by key and a data-less deliverable reached the staging store. The DAG is
    # the run's contract — a step whose dependency is not 'done' does not run.
    _unmet = unmet_deps(steps, step_key)
    _operator = (os.environ.get("IOF_OPERATOR_OVERRIDE", "").strip().lower()
                 in ("1", "true", "yes", "on"))
    if _unmet:
        if not (ignore_deps and _operator):
            try:
                from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
                get_forensics(root_path).emit(
                    run_id=run_id, event_type="step.dag_bypass_refused",
                    severity=SEVERITY_WARN, step_key=step_key,
                    message=(f"run-step refused '{step_key}': unmet "
                             f"dependencies {', '.join(_unmet)}"),
                )
            except Exception:
                logger.debug("Failed to emit step.dag_bypass_refused", exc_info=True)
            print(json.dumps({
                "error": (f"Step '{step_key}' has unmet dependencies: "
                          f"{', '.join(_unmet)}. A failed dependency is a "
                          "verdict, not an obstacle - recover it with "
                          "step-retry, or accept the run's failure and "
                          "report it honestly.")}))
            raise typer.Exit(code=1)
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.deps_overridden",
                severity=SEVERITY_WARN, step_key=step_key,
                message=(f"OPERATOR OVERRIDE: '{step_key}' run with unmet "
                         f"dependencies {', '.join(_unmet)} (--ignore-deps)"),
            )
        except Exception:
            logger.debug("Failed to emit step.deps_overridden", exc_info=True)

    # --- exec steps: deterministic command, no agent -----------------------
    # A step whose correct behaviour is fully a script should not spend an
    # agent session (or risk an LLM mis-transcribing its manifest). Runs the
    # rendered command directly and finalizes through the exact same
    # _finalize_step path as agent steps, so requires_artifacts, stories
    # materialization, forensics and progress all behave identically.
    # Runs synchronously even with --background: the command is seconds-fast
    # and the immediate result is strictly more useful to the caller.
    _exec_def = {s.key: s for s in wf.steps}.get(step_key)
    if _exec_def is not None and _exec_def.runs_command:
        _run_exec_step(
            store=store, root_path=root_path, run_id=run_id, step_key=step_key,
            step_def=_exec_def, info=info, step_row=step_row, wf=wf, run=run,
        )
        return

    # Prepare output directory and path
    output_dir = Path(info["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file_path = output_dir / "OUTPUT.md"

    # Ensure agent workspace exists
    from ioagentfarm.engine.draft_runs import run_has_drafts
    _draft_run = run_has_drafts(root_path, run_id)
    try:
        ensure_iobot_agent(info["role"])
    except Exception:
        # A DRAFT run may introduce a role no installed pack provides; its
        # identity arrives via the overlay create_filtered_workspace applies,
        # and the fail-closed SOUL check THERE still decides. An ordinary
        # run keeps the loud failure — swallowing it would hand iobot an
        # identity-less workspace and its stock persona.
        if not _draft_run:
            raise

    # Create filtered workspace if workflow specifies skill filtering for this role
    role_def = wf.roles.get(info["role"])
    filtered_ws = None
    if _draft_run:
        # A draft run ALWAYS builds the per-run workspace: it is the only
        # place the author's overlay is applied, so a filter-less role that
        # skipped it would execute on the SHARED home — pack bytes, with
        # every stamp on the run still claiming the draft ran.
        filtered_ws = create_filtered_workspace(
            role=info["role"],
            skills=role_def.skills if role_def else None,
            run_id=run_id,
            root_path=root_path,
        )
    elif role_def and role_def.skills is not None:
        filtered_ws = create_filtered_workspace(
            role=info["role"],
            skills=role_def.skills,
            run_id=run_id,
            root_path=root_path,
        )

    # Compile learned skills into workspace (from DB, any pod can do this)
    workspace_for_skills = filtered_ws or iobot_agent_workspace(info["role"])
    # Workspace memory for a role with NO skills filter: such a step runs in
    # the shared agent home, which create_filtered_workspace never touched,
    # so the block is materialized into the home here (version-gated; the
    # file is a cache of the database). The filtered path did this inside
    # create_filtered_workspace.
    if filtered_ws is None:
        try:
            from ioagentfarm.engine.memory import hooks as _memory_hooks
            from ioagentfarm.engine.workspaces import maybe_workspace_code as _mwc
            _memory_hooks.refresh_served_workspace(
                root_path, workspace_for_skills, role=info["role"],
                workspace_code=_mwc() or "",
                solution=_memory_hooks.solution_for_workflow(wf.name))
        except Exception:  # noqa: BLE001
            logger.debug("workspace memory not materialized for role=%s", info["role"], exc_info=True)
    # Provision learned skills into the workspace. Façade: v1 default (compile DB
    # skills + observations into MEMORY.md, identical to the old inline block);
    # v2 (IOF_LEARNING_V2) ingests approved hub skills instead. Best-effort.
    from ioagentfarm.engine.learning.hooks import provision_workspace
    provision_workspace(root_path, run_id, step_key, role=info["role"], workflow=wf.name, dest=workspace_for_skills)

    # Resolve per-run instance config for iobot --config (may be recreated below)
    from ioagentfarm.engine.iobot_config import get_instance_config_path, create_role_config
    instance_config = get_instance_config_path(root_path, run_id)

    # Per-role model override: if the workflow YAML specifies a model for this role,
    # create a role-specific config variant. Falls back to config.json default if not set.
    role_model = wf.roles.get(info["role"], None)

    # Model registry gate (engine/model_registry.py). The model this step
    # will run on - the role's override, else the deployment default the
    # instance config carries - must be one the resolved models.yaml
    # allows. No registry anywhere = no check; a retired or unlisted model
    # does not start, and the refusal names the file and the approved list.
    from ioagentfarm.engine import model_registry as _model_registry
    _step_model = _model_registry.effective_step_model(
        role_model.model if role_model else None, instance_config)
    try:
        _model_registry.refuse_if_retired(_step_model, role=info["role"])
    except (_model_registry.ModelNotAllowed, _model_registry.RegistryError) as _exc:
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_ERROR
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.model_refused",
                severity=SEVERITY_ERROR, step_key=step_key,
                message=str(_exc), payload={"model": _step_model},
            )
        except Exception:
            logger.debug("Failed to emit step.model_refused", exc_info=True)
        # A REFUSAL IS FINAL, SO THE RUN MUST CONCLUDE. Exiting before the
        # step was claimed left it `pending`: the code driver re-spawned it
        # to the hard cap ("exited before claiming the step"), printed
        # `finished with status: running`, and the run sat there with no
        # driver until someone cancelled it - and retention never touches a
        # running run (walked 2026-09-02). The step and the run are failed
        # here, in the pattern the hard-cap path uses, with the reason in
        # the row a status read shows.
        try:
            with store._tx() as cursor:
                cursor.execute(
                    store._q("UPDATE steps SET status='failed', updated_at=? "
                             "WHERE run_id=? AND step_key=?"),
                    (store._now(), run_id, step_key))
                cursor.execute(
                    store._q("UPDATE runs SET status='failed', updated_at=? "
                             "WHERE id=?"),
                    (store._now(), run_id))
        except Exception:
            logger.debug("Failed to mark the refused step failed", exc_info=True)
        print(json.dumps({
            "run_id": run_id, "step_key": step_key, "status": "failed",
            "reason": "model_refused",
            "error": str(_exc),
            "hint": ("Edit the role's `model:` in workflow.yaml, or the "
                     "deployment default in ~/.iobot/config.json, to an "
                     "approved model; `aicore models list` shows the registry."),
        }, indent=2))
        raise typer.Exit(code=1)

    if role_model and role_model.model and instance_config:
        instance_config = create_role_config(instance_config, info["role"], role_model.model)

    # Per-STEP MCP tool allowlist (engine-level least privilege). A step (or a
    # per-item template, for story:* steps) that declares `mcp_tools` gets a
    # derived config whose servers enable ONLY those tools — the step's agent
    # never sees a delivery/publish tool it must not call.
    _step_allow = None
    _own_def = {s.key: s for s in wf.steps}.get(step_key)
    if _own_def is not None:
        _step_allow = _own_def.mcp_tools
    elif step_key.startswith("story:") and ":" in step_key:
        _suffix = step_key.rsplit(":", 1)[-1]
        for _s in wf.steps:
            for _tpl in (_s.per_item_steps or []):
                if _tpl.key_suffix == _suffix and _tpl.mcp_tools is not None:
                    _step_allow = _tpl.mcp_tools
                    break
    if _step_allow is not None and instance_config:
        from ioagentfarm.engine.deliveries import expand_step_tool_allowlist
        from ioagentfarm.engine.iobot_config import create_step_tools_config
        # `@deliveries` -> the tools this deployment declares for case
        # deliveries, so a platform workflow can narrow to "exactly what
        # sends email here" without naming any deployment's tool.
        _step_allow = expand_step_tool_allowlist(_step_allow)
        instance_config = create_step_tools_config(instance_config, step_key, _step_allow)
    # NOTE: instance_config may be None here if local files were lost (pod death).
    # The recovery block after the S3 pull (below) will recreate it.

    # Hard attempt cap (Fix #5).
    #
    # Alex's orchestrate skill says "Never retry more than once. Never use
    # crash-recovery." But Alex is an LLM and doesn't reliably follow that
    # rule under pressure — observed empirically in
    # run_20260411_170752_186480 where Alex burned 4 attempts on the review
    # step via crash-recovery violations before finally giving up.
    #
    # crash-recovery resets the step to `pending` WITHOUT bumping
    # max_attempts, so the normal `attempt >= max_attempts` check in
    # _finalize_step (which would mark the step `failed` and stop retries)
    # never fires. The attempt counter still increments via bump_step_attempt
    # below, but max_attempts stays put. So step.attempt can grow unbounded
    # while max_attempts holds at 2.
    #
    # The hard cap enforces a ceiling at the orchestrator level: refuse to
    # even spawn the subprocess once attempt has reached `max_attempts * 2 + 1`
    # (so for the default max_attempts=2, the absolute ceiling is 5 attempts).
    # This guarantees that no matter how many times Alex calls crash-recovery,
    # we'll never burn more than ceiling attempts of compute on a single step.
    #
    # Override via env: IOF_HARD_ATTEMPT_CAP_MULTIPLIER (default 2).
    _cap_multiplier = int(os.environ.get("IOF_HARD_ATTEMPT_CAP_MULTIPLIER", "2"))
    _hard_cap = _declared_max_attempts(step_row) * _cap_multiplier + 1
    _current_attempt = int(step_row["attempt"])
    if _current_attempt >= _hard_cap:
        # Refuse to start. Mark step failed (final), emit forensic event,
        # return so the run continues to the next step or fails gracefully.
        try:
            from ioagentfarm.engine.forensics import (
                get_forensics, SEVERITY_FATAL,
            )
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.hard_cap_reached",
                severity=SEVERITY_FATAL,
                step_key=step_key, attempt=_current_attempt,
                role=info["role"],
                message=(
                    f"Hard attempt cap reached (current={_current_attempt}, "
                    f"cap={_hard_cap}, max_attempts={step_row['max_attempts']}). "
                    f"Refusing to spawn agent. Likely cause: orchestrator "
                    f"keeps invoking crash-recovery on a permanently failing step."
                ),
                payload={
                    "current_attempt": _current_attempt,
                    "hard_cap": _hard_cap,
                    "max_attempts": int(step_row["max_attempts"]),
                    "cap_multiplier": _cap_multiplier,
                },
            )
        except Exception:
            logger.debug("Failed to emit step.hard_cap_reached", exc_info=True)
        store.set_step_output(
            run_id, step_key, "failed",
            f"STATUS: failed\nOUTPUT: Hard attempt cap reached "
            f"({_current_attempt}/{_hard_cap}). Step refused further retries.",
        )
        store.insert_message(
            run_id=run_id, step_key=step_key, role="project_lead",
            agent_name="Alex", source="orchestrator",
            content=(
                f"Hard attempt cap reached for step '{step_key}' "
                f"({_current_attempt}/{_hard_cap}). No further retries will "
                f"be attempted — orchestrator must escalate or skip."
            ),
            msg_type="delegation",
        )
        print(json.dumps({
            "run_id": run_id,
            "step_key": step_key,
            "status": "failed",
            "reason": "hard_attempt_cap_reached",
            "current_attempt": _current_attempt,
            "hard_cap": _hard_cap,
        }, indent=2))
        # NON-ZERO, LIKE THE OTHER TWO CAP REFUSALS. This printed
        # `status: failed, reason: hard_attempt_cap_reached` and then exited
        # 0, so a wrapper checking `$?` read a capped step as a success
        # (certification round 7) - and `run-step` already exits 1 for a
        # wrong-state step, so 0 did not mean "ran fine" here either. All
        # three refusals now agree.
        raise typer.Exit(code=1)

    # Claim: pending -> running + attempt in ONE conditional write (skip if
    # already running - background re-entry, or the stale takeover above).
    # The read at the top of this command and this write used to be two
    # steps with an unconditional UPDATE between them, so two run-step calls
    # arriving together for one pending step both spawned.
    already_running = step_row["status"] == "running"
    if not already_running:
        if store.claim_pending_step(run_id, step_key) is None:
            _refuse_duplicate_claim(
                root_path, run_id, step_key, step_row,
                "another run-step claimed this pending step first")

    # --- Background mode: launch detached process, return immediately ---
    if background:
        cmd = [
            sys.executable, "-m", "ioagentfarm.cli", "run-step",
            "--step-key", step_key,
            "--run-id", run_id,
            "--user-id", uid,
            # This child is EXPECTED to find its own step already 'running' -
            # the line above marked it so. Without this flag the duplicate
            # guard would refuse the very process the spawn exists to start.
            "--reentrant",
        ]
        if extra_context:
            cmd += ["--extra-context", extra_context]
        if root:
            cmd += ["--root", root]
        # Pass IOF_ROOT so the detached process finds the correct state directory
        env = os.environ.copy()
        env["IOF_ROOT"] = str(root_path)
        _launch_detached(cmd, env=env)

        print(json.dumps({
            "spawned": True,
            "step_key": step_key,
            "role": info["role"],
            "run_id": run_id,
        }, indent=2))
        return

    # --- Sync mode: invoke agent, wait, record result ---

    # --- Pod recovery: restore local state from S3 + recreate anything missing ---

    # Step 1: Pull from S3 if instance dir or run dir is missing (cross-pod recovery)
    instance_dir = root_path / "instances" / run_id
    run_dir = root_path / "runs" / run_id
    try:
        from ioagentfarm.web.storage import get_storage
        cloud = get_storage()
        if not instance_dir.exists():
            logger.info("Instance dir missing for run_id=%s — attempting S3 pull for pod recovery", run_id)
            print(f"[IOF:S3:INFO] pull starting run_id={run_id}", flush=True)
            cloud.pull(run_id, instance_dir, sub_prefix="instances")
            if instance_dir.exists():
                logger.info("S3 pull restored instance dir for run_id=%s", run_id)
                print(f"[IOF:S3:INFO] pull restored run_id={run_id}", flush=True)
            else:
                logger.warning("S3 pull did not restore instance dir for run_id=%s — "
                               "check IOF_STORAGE, AWS credentials, and S3 bucket contents", run_id)
                print(f"[IOF:S3:WARN] pull empty run_id={run_id} - check IOF_STORAGE, AWS creds, bucket", flush=True)
        # Also restore run dir (step outputs, progress) for mid-run recovery
        if not run_dir.exists():
            logger.info("Run dir missing for run_id=%s — pulling step outputs from S3", run_id)
            cloud.pull(run_id, run_dir, sub_prefix="state")
    except Exception as exc:
        logger.error("S3 pull failed for run_id=%s: %s", run_id, exc)
        print(f"[IOF:S3:ERROR] pull failed run_id={run_id}: {exc}", flush=True)

    # Step 2: Recreate instance config if still missing (S3 disabled or pull failed)
    if not instance_config:
        instance_config = get_instance_config_path(root_path, run_id)
    if not instance_config:
        logger.info("Recreating instance config for run_id=%s (pod recovery)", run_id)
        from ioagentfarm.engine.iobot_config import create_instance_config
        project_dir_val = run.get("project_dir", "")
        instance_config = create_instance_config(root_path, run_id, project_dir_val)

    # Step 3: Ensure agent workspace exists on this pod
    ensure_iobot_agent(info["role"])

    # Step 4: Run-scoped output directory — agents write artifacts here
    from ioagentfarm.engine.iobot_config import get_run_output_dir
    run_output_dir = get_run_output_dir(root_path, run_id)
    run_output_dir.mkdir(parents=True, exist_ok=True)

    # Build thin task prompt (identity loaded natively via IOBOT_WORKSPACE)
    message = build_task_prompt(
        step_prompt=info["prompt"],
        output_path=str(output_file_path),
        project_dir=run.get("project_dir", ""),
        output_dir=str(run_output_dir),
    )

    # Write step-start marker to progress file (for parent tailer to detect)
    progress_file = os.environ.get("IOF_PROGRESS_FILE")
    if progress_file:
        with open(progress_file, "a", encoding="utf-8") as pf:
            pf.write(f"IOF_STEP_START:{step_key}:{info['role']}\n")
            pf.flush()

    # Snapshot workspace before agent runs (for artifact detection after)
    agent_ws = filtered_ws or output_dir
    ws_before = _snapshot_workspace(agent_ws) if run_output_dir else set()

    # Resolve agent display name
    agent_name = get_agent_name(info["role"])

    # Build per-line output callback to stream messages into the store.
    #
    # The hard work is done in `_invoke_agent`: it reads iobot's stdout
    # as raw bytes, interprets the stream as a terminal (handling \r
    # carriage returns, CSI cursor-up / clear-line sequences, and ANSI
    # escape codes), and delivers exactly one emit per visual line. No
    # progressive-growth duplicates, no full-buffer re-emits.
    #
    # We still keep a small bounded sliding-window exact-match dedup here
    # as cheap defense-in-depth: if the terminal interpreter ever misses
    # an edge case, identical consecutive lines will still be squashed.
    from collections import deque
    _DEDUP_WINDOW_SIZE = 200
    _recent_lines: "deque[str]" = deque(maxlen=_DEDUP_WINDOW_SIZE)
    _recent_set: set[str] = set()

    # Forensic Gaps B + D: detect LLM-related transient failures and stalls
    # in the streamed text and emit structured events for them. The patterns
    # come from iobot's own LLM client error messages, which appear inline
    # in the assistant content (often after a Rich `↳` continuation prefix).
    #
    # Pattern B: HTTP-level retry — recoverable, iobot retries internally
    #   "Model request failed, retry in 1s (attempt 1)."
    #   "Model request failed, retry in 4s (attempt 3)."
    #
    # Pattern D: stream stall — fatal for the agent loop, watchdog fired
    #   "Error calling LLM: stream stalled for more than 90 seconds"
    #
    # Both events let `forensics show` and the future meta-workflow find
    # transient provider issues by event type instead of grepping the
    # messages table by hand. Each detection only fires ONCE per unique
    # line (the dedup_set above guarantees no duplicates).
    import re as _re_lib
    _LLM_RETRY_RE = _re_lib.compile(
        r"Model request failed, retry in (\d+)s \(attempt (\d+)\)"
    )
    _LLM_STALL_RE = _re_lib.compile(
        r"Error calling LLM: stream stalled for more than (\d+) seconds"
    )

    def _on_agent_output(line: str) -> None:
        text = line.rstrip("\n").strip()
        if not text or _is_noise(text):
            return
        if text in _recent_set:
            return
        if len(_recent_lines) == _DEDUP_WINDOW_SIZE:
            _recent_set.discard(_recent_lines[0])
        _recent_lines.append(text)
        _recent_set.add(text)
        store.insert_message(
            run_id=run_id,
            step_key=step_key,
            role=info["role"],
            agent_name=agent_name,
            source="step_output",
            content=text,
        )

        # Forensic Gap B: structured event for iobot's HTTP retry
        m = _LLM_RETRY_RE.search(text)
        if m:
            try:
                forensics.emit(
                    run_id=run_id, event_type="llm.request_failed",
                    severity=SEVERITY_WARN,
                    step_key=step_key, attempt=attempt, role=info["role"],
                    message=(
                        f"iobot LLM client retrying: attempt {m.group(2)}, "
                        f"backoff {m.group(1)}s"
                    ),
                    payload={
                        "retry_seconds": int(m.group(1)),
                        "attempt_n": int(m.group(2)),
                        "raw_line": text[:300],
                    },
                )
            except Exception:
                logger.debug("Failed to emit llm.request_failed", exc_info=True)

        # Forensic Gap D: structured event for stream stall (real-time)
        m = _LLM_STALL_RE.search(text)
        if m:
            try:
                forensics.emit(
                    run_id=run_id, event_type="llm.stream_stalled",
                    severity=SEVERITY_ERROR,
                    step_key=step_key, attempt=attempt, role=info["role"],
                    message=(
                        f"LLM stream stalled for >{m.group(1)}s — iobot watchdog "
                        f"fired, agent loop will terminate. Fix 6 will auto-retry "
                        f"if budget remains."
                    ),
                    payload={
                        "stall_threshold_s": int(m.group(1)),
                        "raw_line": text[:300],
                    },
                )
            except Exception:
                logger.debug("Failed to emit llm.stream_stalled", exc_info=True)

    # Emit delegation message from Alex — distinguish first run vs retry
    step_rows = store.list_steps(run_id)
    current_step = next((s for s in step_rows if s["step_key"] == step_key), {})
    attempt = int(current_step.get("attempt", 1))

    # Phase 3: structured forensic event log. Best-effort — never raises.
    from ioagentfarm.engine.forensics import (
        get_forensics, SEVERITY_INFO, SEVERITY_WARN, SEVERITY_ERROR,
    )
    forensics = get_forensics(root_path)
    forensics.emit(
        run_id=run_id, event_type="step.started", severity=SEVERITY_INFO,
        step_key=step_key, attempt=attempt, role=info["role"],
        message=f"run-step subprocess starting (attempt {attempt})",
        payload={"workflow": wf.name, "agent_name": agent_name},
    )
    if attempt <= 1:
        delegation_msg = f"Delegating step '{step_key}' to {agent_name} ({info['role']})."
    else:
        delegation_msg = f"Retrying step '{step_key}' - attempt {attempt} by {agent_name} ({info['role']})."
    store.insert_message(
        run_id=run_id, step_key=step_key, role="project_lead",
        agent_name="Alex", source="orchestrator",
        content=delegation_msg,
        msg_type="delegation",
    )

    # Emit speaker-start marker
    store.insert_message(
        run_id=run_id, step_key=step_key, role=info["role"],
        agent_name=agent_name, source="step_start", content="", msg_type="start",
    )

    # Invoke the sub-agent (blocking)
    session_key = f"iof:{run_id}:{step_key}"
    # Per-attempt forensics directory — see _invoke_agent for what gets
    # written here. Layout: .iof/instances/<run_id>/forensics/attempts/<step>.<attempt>/
    # Each attempt gets its own dir so retries don't clobber the prior
    # attempt's blobs (the bug that left us guessing why Analyst failed).
    sanitized_step = step_key.replace(":", "_").replace("/", "_")
    forensics_dir = (
        root_path / "instances" / run_id / "forensics"
        / "attempts" / f"{sanitized_step}.{attempt}"
    )
    forensics.emit(
        run_id=run_id, event_type="step.spawn_subprocess",
        severity=SEVERITY_INFO,
        step_key=step_key, attempt=attempt, role=info["role"],
        message=f"spawning iobot agent for {info['role']}",
        blob_path=forensics_dir,
        payload={"session_key": session_key},
    )

    # Fix 6: auto-retry on stream stall.
    #
    # iobot has a 90-second LLM stream watchdog. When MiniMax (or any
    # provider) accepts a request and starts streaming a response but then
    # stops sending tokens for >90s, iobot raises an exception, the agent
    # loop catches it and writes "Error calling LLM: stream stalled for more
    # than 90 seconds" as the final assistant turn, then exits cleanly with
    # rc=0. The subprocess looks healthy from the OS perspective but produced
    # no work. Same pattern fires for transient HTTP errors that exhaust
    # iobot's internal connection retries ("Model request failed").
    #
    # We can't fix this in iobot. But we CAN detect it from the
    # session-snapshot.jsonl after the subprocess exits, and re-run the
    # whole subprocess up to N times. Each retry preserves the previous
    # attempt's forensic blobs by moving them into a `stall_attempt_<n>`
    # sub-dir before starting fresh, so the forensic timeline shows every
    # attempt and the final blobs at top level are from whichever attempt
    # actually produced (or didn't produce) OUTPUT.md.
    #
    # We do NOT retry on other failure modes (the agent legitimately failed,
    # protocol parse error, etc.) — only on the two transient provider
    # patterns above.
    from ioagentfarm.engine.forensics import (
        parse_session_failure as _parse_session_failure,
    )
    _STALL_MAX_RETRIES = int(os.environ.get("IOF_STALL_MAX_RETRIES", "4"))
    # Reasons Fix 6 will auto-retry on. All five are transient iobot+provider
    # failure modes that have empirically been observed to recover on retry:
    #   llm_stream_stalled  — iobot's 90s SSE watchdog fired (Analyst/Strategist class)
    #   llm_request_failed  — HTTP-level "Model request failed" (catch-all)
    #   llm_connection_error — generic "Connection error", often a thinking-only
    #                          response from a reasoning model that iobot's
    #                          stream consumer can't handle (Reviewer class)
    #   llm_generic_error   — any other "Error calling LLM: ..." variant
    #   agent_premature_termination — last assistant turn had no tool_calls AND
    #                          no STATUS marker, so iobot's agent loop
    #                          interpreted "no action" as "agent done" and
    #                          exited cleanly with rc=0 before the agent
    #                          finished its work. Session-resume retry nudges
    #                          the model to continue from where it left off.
    _STALL_REASONS = (
        "llm_stream_stalled",
        "llm_request_failed",
        "llm_connection_error",
        "llm_generic_error",
        "agent_premature_termination",
    )
    _stall_retry_count = 0

    def _move_attempt_blobs_aside(target_idx: int) -> None:
        """Move the current forensics_dir contents into stall_attempt_<idx>/.

        Keeps prompt.txt and env-snapshot.json at top level (they're
        invariant across retries - the agent gets the same prompt). Moves
        stdout.log, stderr.log, exit.json, session-snapshot.jsonl, and the
        inflight/ subdir aside to preserve the failed-attempt evidence."""
        try:
            stall_dir = forensics_dir / f"stall_attempt_{target_idx}"
            stall_dir.mkdir(parents=True, exist_ok=True)
            _PRESERVE_AT_TOP = {"prompt.txt", "env-snapshot.json"}
            for item in list(forensics_dir.iterdir()):
                if item.name in _PRESERVE_AT_TOP:
                    continue
                if item.name.startswith("stall_attempt_"):
                    continue
                if item.is_file():
                    item.rename(stall_dir / item.name)
                elif item.is_dir() and item.name == "inflight":
                    item.rename(stall_dir / item.name)
        except Exception:
            logger.debug("Failed to move attempt blobs aside", exc_info=True)

    # On retry we don't re-send the original prompt — iobot's session
    # resume already has it (along with everything the agent has done so
    # far). Re-sending the giant step prompt risks the model restarting
    # the work from scratch instead of continuing.
    #
    # CRITICAL: the continuation must be SPECIFIC about what's on disk,
    # not a vague "continue where you left off." A vague nudge triggers
    # a 40+ call re-read spiral where the agent re-explores the entire
    # filesystem and bloats the session context beyond MiniMax's streaming
    # capacity. Empirically observed in run_20260412_044021_154201:
    # strategize.1 stall_1 had 23 calls + wire error; Fix 6 retry added
    # 43 PURE OVERHEAD calls (28 read_file + 9 glob + 4 list_dir + 2 grep)
    # producing zero new work, bloating session to 66 calls, causing a
    # context-size-induced 90s stall that exhausted all retries.
    #
    # Fix: scan the output dir for existing deliverables and tell the
    # agent EXACTLY what's done and what's missing. One targeted tool call
    # instead of a rediscovery expedition.

    # The builder is module-level: _build_smart_continuation (tested).

    # Fallback for the initial _retry_message (before first retry, or if
    # _build_smart_continuation fails for any reason).
    _retry_message = (
        "Your previous attempt did not complete. Write OUTPUT.md following the "
        "step's ORIGINAL output format instructions:\n\n"
        "    STATUS: done\n"
        "    OUTPUT: <one-line summary>\n"
        "    <plus every other key the step requires — e.g. STORIES_JSON for a "
        "story-producing step>\n\n"
        "DO NOT re-read files already in your context. One tool call."
    )

    # Run-supervisor heartbeat: this closure is ticked every ~30s inside
    # _invoke_agent for as long as the iobot subprocess is being awaited —
    # INCLUDING across Fix-6 in-step auto-retries, because every retry loops
    # back through _invoke_agent (which beats immediately on entry). If this
    # run-step process dies (kill, pod eviction), beats stop and the
    # supervisor reaps the step after IOF_SUPERVISOR_STEP_STALE_S.
    def _step_heartbeat() -> None:
        store.touch_step_heartbeat(run_id, step_key)

    while True:
        _invoke_agent(
            role=info["role"],
            session_key=session_key,
            message=(
                _build_smart_continuation(step_key, run_output_dir, _failure,
                                          output_md=output_file_path)
                if _stall_retry_count > 0 and _failure
                else (_retry_message if _stall_retry_count > 0 else message)
            ),
            user_id=uid,
            root_path=root_path,
            config_path=instance_config,
            workspace_override=filtered_ws,
            project_dir=run_output_dir,
            on_output=_on_agent_output,
            forensics_dir=forensics_dir,
            heartbeat=_step_heartbeat,
        )

        # Did this attempt hit a stream stall? If so, retry.
        if _stall_retry_count >= _STALL_MAX_RETRIES:
            break  # exhausted retries, accept whatever happened
        _accepted_without_retry = False
        _failure = _parse_session_failure(forensics_dir / "session-snapshot.jsonl")
        if not _failure or _failure.get("reason") not in _STALL_REASONS:
            break  # no stall or different failure type — don't retry
        # False-alarm guard (do NOT retry a step that already finished). The
        # session-level premature-termination heuristic only inspects the LAST
        # assistant turn: if the agent wrote OUTPUT.md (STATUS: done) and then
        # ended on a trailing narration turn (0 tool_calls, no "STATUS:" text),
        # it is misclassified as agent_premature_termination — even though the
        # deliverable is complete. Re-running a finished step wastes minutes
        # (strategize was re-composed 2-3x this way). So before retrying, check
        # the actual on-disk deliverable produced THIS attempt; if it's a
        # complete OUTPUT.md, accept the step instead of retrying.
        try:
            from ioagentfarm.engine.protocol import parse_key_value_protocol as _pkv
            # THE GUARD WAS LOOKING IN THE WRONG PLACE, so it never once fired.
            #
            # It checked `instances/<run>/project/OUTPUT.md`. The agent is told
            # to write to its STEP OUTPUT DIR - `runs/<run>/steps/<key>/
            # OUTPUT.md`, which is `output_file_path` - and that is where every
            # step's deliverable actually lands. The project path holds nothing.
            #
            # So the very case this guard exists to prevent happened every
            # time: an agent finished its work, wrote a complete OUTPUT.md,
            # ended on a trailing narration turn with no STATUS marker, was
            # classified `agent_premature_termination`, and had the WHOLE step
            # re-run. Measured 2026-08-16: every step of a signal_detection run
            # burned two full retries this way - the agent's own console shows
            # it writing OUTPUT.md, verifying its arithmetic, saying "All done"
            # and then being restarted. Roughly thirty of the run's
            # thirty-eight minutes was correct work being discarded and redone.
            #
            # The step dir is checked FIRST and the project path kept as a
            # fallback, since a step that writes there is still finished.
            _prompt = forensics_dir / "prompt.txt"  # written at this attempt's start
            _candidates = [output_file_path,
                           root_path / "instances" / run_id / "project" / "OUTPUT.md"]
            for _omd in _candidates:
                _fresh = _omd.exists() and (
                    not _prompt.exists()
                    or _omd.stat().st_mtime >= _prompt.stat().st_mtime
                )
                if not _fresh:
                    continue
                _okv, _, _ = _pkv(_omd.read_text(encoding="utf-8", errors="replace"))
                if (_okv.get("STATUS") or "").strip().lower() == "done":
                    # ACCEPTED HERE, READ THERE. The finalizer reads
                    # `output_file_path` and nothing else, so accepting the
                    # project-path copy without moving it declared the step
                    # finished and then failed it for a missing file - seen
                    # live, attempt 4 of a generate_insights step. Put the
                    # accepted file where it is read.
                    _omd = _place_output_md(_omd, output_file_path)
                    logger.info(
                        "Step %s: session signalled %s, but OUTPUT.md at %s is "
                        "complete (STATUS: done) — accepting without retry.",
                        step_key, _failure.get("reason"), _omd,
                    )
                    forensics.emit(
                        run_id=run_id, event_type="step.retry_not_needed",
                        severity=SEVERITY_INFO, step_key=step_key,
                        attempt=attempt, role=info["role"],
                        message=(f"{_failure.get('reason')} was a false alarm - "
                                 f"the deliverable is complete; accepted without "
                                 f"re-running the step"),
                        payload={"reason": _failure.get("reason"),
                                 "output_md": str(_omd)},
                    )
                    _accepted_without_retry = True
                    break
            if _accepted_without_retry:
                break
        except Exception:
            logger.debug("stall false-alarm completeness check failed", exc_info=True)
        # We have a transient stall and budget remaining. Move blobs aside,
        # emit a forensic event, and re-run.
        _stall_retry_count += 1
        _move_attempt_blobs_aside(_stall_retry_count)
        forensics.emit(
            run_id=run_id, event_type="step.auto_retry_after_stall",
            severity=SEVERITY_WARN,
            step_key=step_key, attempt=attempt, role=info["role"],
            message=(
                f"Auto-retry {_stall_retry_count}/{_STALL_MAX_RETRIES} after "
                f"{_failure['reason']} (made {_failure['tool_calls_made']} tool calls). "
                f"Prior attempt blobs preserved in stall_attempt_{_stall_retry_count}/"
            ),
            blob_path=forensics_dir,
            payload={
                "reason": _failure["reason"],
                "matched_pattern": _failure["matched_pattern"],
                "tool_calls_made": _failure["tool_calls_made"],
                "wrote_output": _failure["wrote_output"],
                "stall_retry_count": _stall_retry_count,
                "stall_max_retries": _STALL_MAX_RETRIES,
            },
        )
        # Also write a delegation message so the user-visible messages
        # table reflects what's happening.
        store.insert_message(
            run_id=run_id, step_key=step_key, role="project_lead",
            agent_name="Alex", source="orchestrator",
            content=(
                f"Auto-retrying step '{step_key}' (LLM provider {_failure['reason']}, "
                f"attempt {_stall_retry_count}/{_STALL_MAX_RETRIES} of in-step retries)."
            ),
            msg_type="delegation",
        )
        # Jittered exponential backoff before re-invoking. During a provider
        # brown-out, back-to-back retries from many concurrent steps form a
        # synchronized retry storm that prolongs the outage; a short growing
        # delay with jitter de-correlates them at negligible cost to the
        # common single-retry case. Bounded: retries are already capped by
        # IOF_STALL_MAX_RETRIES, so total added latency is a few seconds.
        import random as _random
        import time as _btime
        _backoff = min(30.0, float(2 ** _stall_retry_count) + _random.uniform(0.0, 2.0))
        _btime.sleep(_backoff)
        # Loop back and re-call _invoke_agent

    # Phase 3: emit subprocess.exited with exit code/duration from exit.json
    # (written by _invoke_agent before this point). Severity is warn if the
    # process didn't exit cleanly (non-zero rc) since downstream may still
    # recover via _finalize_step's missing-OUTPUT handling.
    try:
        exit_path = forensics_dir / "exit.json"
        if exit_path.exists():
            exit_info = json.loads(exit_path.read_text(encoding="utf-8"))
            sev = SEVERITY_WARN if exit_info.get("exit_code") != 0 else SEVERITY_INFO
            forensics.emit(
                run_id=run_id, event_type="step.subprocess_exited",
                severity=sev, step_key=step_key, attempt=attempt,
                role=info["role"],
                message=(
                    f"iobot exited rc={exit_info.get('exit_code')} after "
                    f"{exit_info.get('duration_s')}s"
                    # Only when it is worth a reader's attention. A lag of a
                    # second or two is reaping; a minute is the subprocess
                    # holding its stdout open long after it stopped writing,
                    # and that time is invisible in every other figure the
                    # timeline reports.
                    + (f" ({exit_info['reap_lag_s']}s of that waiting for the "
                       f"process to exit after stdout closed)"
                       if (exit_info.get("reap_lag_s") or 0) >= 10 else "")),
                blob_path=forensics_dir,
                payload=exit_info,
            )
    except Exception:
        logger.debug("Failed to emit step.subprocess_exited", exc_info=True)

    # Emit speaker-end marker
    store.insert_message(
        run_id=run_id, step_key=step_key, role=info["role"],
        agent_name=agent_name, source="step_output", content="", msg_type="end",
    )

    # Write step-end marker to progress file
    if progress_file:
        with open(progress_file, "a", encoding="utf-8") as pf:
            pf.write(f"IOF_STEP_END:{step_key}:{info['role']}\n")
            pf.flush()

    # Copy deliverable artifacts from agent workspace to run output directory.
    # iobot's --workspace controls file tool path resolution, so agents
    # write artifacts relative to their workspace.  We diff against the
    # pre-agent snapshot to find new files and copy them flat to the output dir.
    if run_output_dir and agent_ws:
        copied = _collect_artifacts(agent_ws, run_output_dir, ws_before)
        if copied:
            logger.info(
                "Copied %d artifact(s) from %s to %s",
                len(copied), agent_ws, run_output_dir,
            )

    # Phase 2: snapshot OUTPUT.md as it stands at this exact moment, AFTER
    # _collect_artifacts has copied any agent-workspace writes into the run
    # output dir, but BEFORE _finalize_step parses it. Lets a post-mortem
    # distinguish "agent wrote bad protocol" (file present, parser fails)
    # from "agent wrote nothing" (file missing — usually subprocess died
    # early or hit a tool-iteration limit).
    try:
        snapshot_path = forensics_dir / "output-md-snapshot.txt"
        if output_file_path.exists():
            snapshot_path.write_text(
                output_file_path.read_text(encoding="utf-8", errors="replace"),
                encoding="utf-8",
            )
        else:
            snapshot_path.write_text("(missing)\n", encoding="utf-8")
    except Exception:
        logger.debug("Failed to snapshot OUTPUT.md to forensics", exc_info=True)

    # Read output file (or synthesize failure if missing)
    if output_file_path.exists():
        raw = output_file_path.read_text(encoding="utf-8")
        forensics.emit(
            run_id=run_id, event_type="step.output_md_written",
            severity=SEVERITY_INFO,
            step_key=step_key, attempt=attempt, role=info["role"],
            message=f"OUTPUT.md present at {output_file_path} ({len(raw)} chars)",
            payload={"path": str(output_file_path), "length": len(raw)},
        )
    else:
        raw = "STATUS: failed\nOUTPUT: Agent completed without writing output file."
        # Phase 3 enhancement (Fix 1): parse the session-snapshot.jsonl to find
        # the *actual* reason the agent loop terminated without writing OUTPUT.md.
        # iobot records LLM stream stalls, request errors, etc. as a final
        # assistant message — see engine/forensics.parse_session_failure.
        from ioagentfarm.engine.forensics import parse_session_failure
        failure_info = parse_session_failure(forensics_dir / "session-snapshot.jsonl")
        if failure_info:
            reason_msg = (
                f"OUTPUT.md missing - agent terminated due to {failure_info['reason']} "
                f"after {failure_info['tool_calls_made']} tool calls. "
                f"Last assistant message: {failure_info['raw_text'][:160]}"
            )
            payload = {
                "expected_path": str(output_file_path),
                "reason": failure_info["reason"],
                "matched_pattern": failure_info["matched_pattern"],
                "tool_calls_made": failure_info["tool_calls_made"],
                "wrote_output": failure_info["wrote_output"],
                "last_assistant_text": failure_info["raw_text"],
            }
        else:
            reason_msg = (
                "OUTPUT.md missing — agent exited without producing output, "
                "no recognized failure pattern in session. "
                "Check forensics dir for stderr/stdout/session-snapshot.jsonl."
            )
            payload = {
                "expected_path": str(output_file_path),
                "reason": "unknown",
            }
        forensics.emit(
            run_id=run_id, event_type="step.output_md_missing",
            severity=SEVERITY_ERROR,
            step_key=step_key, attempt=attempt, role=info["role"],
            message=reason_msg,
            blob_path=forensics_dir,
            payload=payload,
        )
        # Write error to progress file so parent tailer shows it
        if progress_file:
            with open(progress_file, "a", encoding="utf-8") as pf:
                pf.write(
                    f"[!] Agent ({info['role']}) exited without producing output. "
                    f"Likely hit maxToolIterations or exec timeout limit.\n"
                )
                pf.flush()

    result = _finalize_step(
        store=store,
        root_path=root_path,
        run_id=run_id,
        step_key=step_key,
        raw=raw,
        wf=wf,
        role=info["role"],
        agent_workspace=filtered_ws or output_dir,
    )

    # Phase 3: emit step.finalized with the final parsed status. error
    # severity if the step ended in failed; info otherwise.
    final_status = (result or {}).get("status", "unknown")
    forensics.emit(
        run_id=run_id, event_type="step.finalized",
        severity=SEVERITY_ERROR if final_status == "failed" else SEVERITY_INFO,
        step_key=step_key, attempt=attempt, role=info["role"],
        message=f"_finalize_step completed with status={final_status}",
        payload={"status": final_status, "next_step_key": (result or {}).get("next_step_key")},
    )

    # Emit the status-aware summary message from project_lead AFTER _finalize_step
    # has determined the real outcome. Emitting "completed by X" before we know
    # the actual status produces a misleading "completed then retrying" sequence
    # in the messages table whenever a step fails and gets retried.
    step_status = (result or {}).get("status", "unknown")
    if step_status == "done":
        summary_msg = f"Step '{step_key}' completed by {agent_name} ({info['role']})."
    elif step_status == "failed":
        summary_msg = (
            f"Step '{step_key}' failed during {agent_name} ({info['role']}) — "
            f"will retry or escalate per workflow policy."
        )
    else:
        summary_msg = f"Step '{step_key}' returned status '{step_status}' from {agent_name} ({info['role']})."
    store.insert_message(
        run_id=run_id, step_key=step_key, role="project_lead",
        agent_name="Alex", source="orchestrator",
        content=summary_msg,
        msg_type="delegation",
    )

    print(json.dumps(result, indent=2))


# ---------------------------------------------------------------------------
# Implicit feedback helper
# ---------------------------------------------------------------------------

def _record_implicit_feedback(store, root_path, run_id: str, step_key: str, role: str, signal: str):
    """Record implicit feedback on learned skills when user retries/skips a step.

    Best-effort - failures are logged but never block the CLI command.
    """
    try:
        from ioagentfarm.cli import _learning_lifecycle
        ll = _learning_lifecycle(root_path)
        run = store.get_run(run_id)
        if not run:
            return
        workflow = run["workflow_name"]
        skills = ll.get_skills(role=role, workflow=workflow)
        for skill in skills:
            ll.record_feedback(
                skill["learning_id"],
                signal=signal,
                content=f"implicit:{signal} (step {step_key})",
                run_id=run_id,
                step_key=step_key,
                source_channel="cli",
            )
        if skills:
            logger.info(
                "Implicit %s feedback on %d learned skills for step %s (role=%s, workflow=%s)",
                signal, len(skills), step_key, role, workflow,
            )
    except Exception:
        logger.debug("Failed to record implicit feedback", exc_info=True)


# ---------------------------------------------------------------------------
# Step recovery commands
# ---------------------------------------------------------------------------

def step_retry(
    step_key: str = typer.Option(..., help="Step key to retry (e.g. implement, test)"),
    run_id: str = typer.Option(None, help="Run ID (omit for latest active run)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    crash_recovery: bool = typer.Option(False, "--crash-recovery", help="Reset a stuck/crashed step without bumping attempts or recording feedback. Accepts running/failed/done steps."),
):
    """Reset a step to pending so it can be re-executed.

    Default: retry a failed step - bumps max_attempts and records negative feedback.
    With --crash-recovery: reset a stuck/crashed step (running, failed, or done) without
    bumping attempts or recording feedback. Use for pod failures and crash recovery.
    """
    from ioagentfarm.cli import _root, _store, _default_user_id, _resolve_run_id, _resolve_own_run_id

    # Resolve the workspace BEFORE touching the store: that is what loads
    # `~/.iobot/workspaces/<code>/.env`, and therefore IOF_DATABASE_URL.
    # Without it these commands silently read the DEFAULT local sqlite while
    # `run --workspace X` wrote X's database — so an operator reaching for
    # recovery during an incident was told 'Run not found' (2026-08-16).
    from ioagentfarm.cli import _workspace_code
    # NO --workspace on a write, by design (the `aicore drafts apply` precedent):
    # activation is the ONE way to choose the tenant a mutation lands in. A flag
    # that can disagree with it is a footgun — activate ws1, pass --workspace ws2,
    # and 'which workspace did I just write into?' has two answers. Refusing a
    # mismatch is weaker than not being able to express it.
    _workspace_code(None, required=True, write=True)

    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    # SCOPED to the caller (novice finding, round 8): an omitted --run-id
    # resolves ONLY to this user's own active run, never the global
    # active_run file or another user's latest, so a step-retry/step-skip
    # cannot reach a stranger's live run on a shared database.
    run_id, _why = _resolve_own_run_id(store, run_id, uid)
    if not run_id:
        print(json.dumps({"error": _why}))
        raise typer.Exit(code=2)

    # Validate BEFORE recording (novice, round 6): a refused retry wrote
    # `step.retry_initiated` into the timeline of a step that was never
    # retried - and into the timeline of a run that did not exist, which
    # then appeared in `forensics list` as a ghost.
    try:
        store.get_run(run_id)
    except KeyError:
        print(json.dumps({"error": f"run not found: {run_id}"}))
        raise typer.Exit(code=3)
    _pre_steps = {s["step_key"]: s for s in store.list_steps(run_id)}
    if step_key not in _pre_steps:
        print(json.dumps({"error": f"Step '{step_key}' not found in run {run_id}",
                          "steps": sorted(_pre_steps)}))
        raise typer.Exit(code=3)
    if crash_recovery and _pre_steps[step_key]["status"] == "pending":
        print(json.dumps({"error": (f"Step '{step_key}' is 'pending'. Can only reset running, "
                                    "failed, or done steps.")}))
        raise typer.Exit(code=1)
    if not crash_recovery and _pre_steps[step_key]["status"] != "failed":
        print(json.dumps({"error": (f"Step '{step_key}' is '{_pre_steps[step_key]['status']}', not "
                                    "'failed'. Can only retry failed steps. Use --crash-recovery "
                                    "for stuck/crashed steps.")}))
        raise typer.Exit(code=1)

    # Fix 2 + Fix 3: snapshot Alex's orchestrate session AND emit a forensic
    # event marking the retry decision. Without this, retry attempts are
    # invisible in the forensic timeline (the gap between strategize.1 fail
    # and strategize.2 start that left us blind for 57 minutes).
    try:
        from ioagentfarm.engine.forensics import (
            get_forensics, snapshot_orchestrator_session, SEVERITY_WARN,
        )
        snapshot_orchestrator_session(
            root_path, run_id, uid,
            label=("crash_recovery" if crash_recovery else "step_retry"),
        )
        get_forensics(root_path).emit(
            run_id=run_id, event_type="step.retry_initiated",
            severity=SEVERITY_WARN,
            step_key=step_key,
            message=(
                f"{'crash-recovery' if crash_recovery else 'step-retry'} invoked "
                f"on step '{step_key}' by {os.environ.get('IOF_USER_ID') or 'the operator'}"
            ),
            payload={"crash_recovery": crash_recovery},
        )
    except Exception:
        logger.debug("Failed to emit step.retry_initiated", exc_info=True)

    steps = store.list_steps(run_id)
    step_row = next((s for s in steps if s["step_key"] == step_key), None)
    if not step_row:
        print(json.dumps({"error": f"Step '{step_key}' not found in run {run_id}"}))
        raise typer.Exit(code=1)

    if crash_recovery:
        # Crash recovery: accept running/failed/done, no bump, no feedback.
        # The transition itself lives in Store.crash_recover_step — the ONE
        # implementation shared with the run supervisor's automatic reap
        # (engine/supervisor.py). Do not reimplement it here.
        result = store.crash_recover_step(run_id, step_key)
        if "error" in result:
            print(json.dumps({"error": result["error"]}))
            raise typer.Exit(code=1)
        result = {"run_id": run_id, "step_key": step_key, **result}
        print(json.dumps(result))
    else:
        # Normal retry: failed only, bump max_attempts, record negative feedback
        if step_row["status"] != "failed":
            print(json.dumps({"error": f"Step '{step_key}' is '{step_row['status']}', not 'failed'. Can only retry failed steps. Use --crash-recovery for stuck/crashed steps."}))
            raise typer.Exit(code=1)

        with store._tx() as cursor:
            new_max = int(step_row["max_attempts"]) + 1
            now = store._now()
            # STAMP THE DECLARED VALUE BEFORE THE FIRST BUMP MOVES IT. The
            # hard cap is a multiple of max_attempts, and this bump is what
            # made the cap chase the retries - 38 attempts on a step
            # declaring 1, and `step.hard_cap_reached` unable to fire. The
            # stamp is written once, so the cap keeps its original anchor
            # however many times a driver retries.
            import json as _json_m
            try:
                _meta_raw = step_row["meta_json"]
                _meta = (_json_m.loads(_meta_raw) if isinstance(_meta_raw, str)
                         else (_meta_raw or {}))
            except Exception:              # noqa: BLE001
                _meta = {}
            if not isinstance(_meta, dict):
                _meta = {}
            if "declared_max_attempts" not in _meta:
                _meta["declared_max_attempts"] = int(step_row["max_attempts"])
                cursor.execute(
                    store._q("UPDATE steps SET meta_json=? WHERE run_id=? "
                             "AND step_key=?"),
                    (_json_m.dumps(_meta), run_id, step_key),
                )
            cursor.execute(
                store._q("UPDATE steps SET status='pending', max_attempts=?, updated_at=? WHERE run_id=? AND step_key=?"),
                (new_max, now, run_id, step_key),
            )
            cursor.execute(
                store._q("UPDATE runs SET status='running', updated_at=? WHERE id=? AND status='failed'"),
                (now, run_id),
            )

        _record_implicit_feedback(store, root_path, run_id, step_key, step_row["role"], "negative")

        print(json.dumps({
            "run_id": run_id,
            "step_key": step_key,
            "action": "retry",
            "new_status": "pending",
            "max_attempts": new_max,
        }))


def step_skip(
    step_key: str = typer.Option(..., help="Step key to skip"),
    run_id: str = typer.Option(None, help="Run ID (omit for latest active run)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (e.g. telegram:12345)"),
    accept_missing_artifacts: bool = typer.Option(
        False, "--accept-missing-artifacts", hidden=True,
        help="OPERATOR OVERRIDE (requires IOF_OPERATOR_OVERRIDE=1 in the "
             "operator's shell): skip a step whose fail-closed artifact gate "
             "is unmet. Forensically recorded."),
):
    """Mark a step as done with 'SKIPPED' output to unblock downstream steps."""
    from ioagentfarm.cli import _root, _store, _default_user_id, _resolve_run_id, _resolve_own_run_id

    # Resolve the workspace BEFORE touching the store: that is what loads
    # `~/.iobot/workspaces/<code>/.env`, and therefore IOF_DATABASE_URL.
    # Without it these commands silently read the DEFAULT local sqlite while
    # `run --workspace X` wrote X's database — so an operator reaching for
    # recovery during an incident was told 'Run not found' (2026-08-16).
    from ioagentfarm.cli import _workspace_code
    # NO --workspace on a write, by design (the `aicore drafts apply` precedent):
    # activation is the ONE way to choose the tenant a mutation lands in. A flag
    # that can disagree with it is a footgun — activate ws1, pass --workspace ws2,
    # and 'which workspace did I just write into?' has two answers. Refusing a
    # mismatch is weaker than not being able to express it.
    _workspace_code(None, required=True, write=True)

    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    # SCOPED to the caller (novice finding, round 8): an omitted --run-id
    # resolves ONLY to this user's own active run, never the global
    # active_run file or another user's latest, so a step-retry/step-skip
    # cannot reach a stranger's live run on a shared database.
    run_id, _why = _resolve_own_run_id(store, run_id, uid)
    if not run_id:
        print(json.dumps({"error": _why}))
        raise typer.Exit(code=2)

    try:
        store.get_run(run_id)
    except KeyError:
        print(json.dumps({"error": f"run not found: {run_id}"}))
        raise typer.Exit(code=3)
    steps = store.list_steps(run_id)
    step_row = next((s for s in steps if s["step_key"] == step_key), None)
    if not step_row:
        print(json.dumps({"error": f"Step '{step_key}' not found in run {run_id}",
                          "steps": sorted(s["step_key"] for s in steps)}))
        raise typer.Exit(code=3)

    if step_row["status"] == "done":
        print(json.dumps({"error": f"Step '{step_key}' is already done."}))
        raise typer.Exit(code=1)

    # --- Gate enforcement (2026-08-13) ---
    # Skipping a step that declares requires_artifacts marks it done while its
    # deliverable does not exist — the run reads as converged with the
    # deliverable silently missing (observed live: the driver skipped a stage
    # step whose fail-closed tool had correctly refused, and the run reported
    # done with nothing staged). A skip must not forge a gate.
    _missing = []
    try:
        run = store.get_run(run_id)
        loader = WorkflowLoader()
        wf = loader.load(run["workflow_name"], run_id=run_id, root=root_path)
        _def = {s.key: s for s in wf.steps}.get(step_key)
        _required = list(getattr(_def, "requires_artifacts", []) or []) if _def else []
        if _required:
            _missing = missing_required_artifacts(
                _required, root_path / "instances" / run_id / "project")
    except Exception:
        logger.debug("step-skip gate check failed open", exc_info=True)
    _operator = (os.environ.get("IOF_OPERATOR_OVERRIDE", "").strip().lower()
                 in ("1", "true", "yes", "on"))
    # A STEP A GATE SENT BACK IS NOT SKIPPABLE. It is pending because its
    # output was rejected; skipping it hands the same output to the same gate
    # and burns one of the gate's bounded attempts on nothing. The artifact
    # gate below cannot catch this - the rejected file is still on disk.
    _reset = reset_pending(step_row) if step_row else None
    if _reset and not _operator:
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_ERROR
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.skip_refused_reset",
                severity=SEVERITY_ERROR, step_key=step_key,
                message=(f"step-skip refused '{step_key}': it was sent back by "
                         f"'{_reset['reset_by']}' (on_fail) with feedback and has "
                         "not re-run - skipping would resubmit rejected work"),
                payload=_reset)
        except Exception:
            logger.debug("Failed to emit step.skip_refused_reset", exc_info=True)
        print(json.dumps({
            "error": (f"refused: '{step_key}' was reset by '{_reset['reset_by']}' "
                      "(on_fail) with feedback and has not re-run yet. Run it "
                      f"again: `run-step --step-key {step_key} --run-id {run_id}`. "
                      "Skipping it would hand the rejected work straight back to "
                      "the gate."),
            "reset_by": _reset["reset_by"], "step_key": step_key,
        }, indent=2))
        return
    if _missing and not (accept_missing_artifacts and _operator):
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
            get_forensics(root_path).emit(
                run_id=run_id, event_type="step.skip_refused_gate",
                severity=SEVERITY_WARN, step_key=step_key,
                message=(f"step-skip refused '{step_key}': required artifact(s) "
                         f"missing ({', '.join(_missing)}) — a skip must not "
                         "forge a fail-closed gate"),
            )
        except Exception:
            logger.debug("Failed to emit step.skip_refused_gate", exc_info=True)
        print(json.dumps({
            "error": (f"Step '{step_key}' declares required artifact(s) that do "
                      f"not exist: {', '.join(_missing)}. Skipping would mark "
                      "the run done with its deliverable missing. Recover the "
                      "step (step-retry) or accept the run's failure and "
                      "report it honestly.")}))
        raise typer.Exit(code=1)

    # Fix 2: snapshot at step-skip checkpoint + emit event
    try:
        from ioagentfarm.engine.forensics import (
            get_forensics, snapshot_orchestrator_session, SEVERITY_WARN,
        )
        snapshot_orchestrator_session(root_path, run_id, uid, label="step_skip")
        _note = (f" WITHOUT required artifact(s): {', '.join(_missing)} "
                 "(--accept-missing-artifacts)") if _missing else ""
        get_forensics(root_path).emit(
            run_id=run_id, event_type="step.skipped",
            severity=SEVERITY_WARN,
            step_key=step_key,
            message=f"Alex skipped step '{step_key}' (manual skip){_note}",
        )
    except Exception:
        logger.debug("Failed to emit step.skipped", exc_info=True)

    _skip_out = "STATUS: done\nOUTPUT: SKIPPED by operator"
    if _missing:
        _skip_out += (" — required artifact(s) accepted as missing: "
                      + ", ".join(_missing))
    store.set_step_output(run_id, step_key, "done", _skip_out)

    # Re-activate the run if it was marked failed
    with store._tx() as cursor:
        now = store._now()
        cursor.execute(
            store._q("UPDATE runs SET status='running', updated_at=? WHERE id=? AND status='failed'"),
            (now, run_id),
        )

    # Implicit negative feedback: user skipping means the step was unhelpful
    _record_implicit_feedback(store, root_path, run_id, step_key, step_row["role"], "negative")

    print(json.dumps({
        "run_id": run_id,
        "step_key": step_key,
        "action": "skip",
        "new_status": "done",
    }))


# ---------------------------------------------------------------------------
# Learning system CLI — single command with action argument
# ---------------------------------------------------------------------------

_LEARNINGS_ACTIONS = ["list", "log", "capture", "feedback", "rationalize", "summary", "analytics"]


def learnings(
    action: str = typer.Argument(..., help="Action: list, log, capture, feedback, rationalize, summary, analytics"),
    role: str = typer.Option(None, help="Agent role"),
    workflow: str = typer.Option(None, help="Workflow name"),
    name: str = typer.Option(None, help="Skill name (capture)"),
    content: str = typer.Option(None, help="Skill content (capture) or feedback text (feedback)"),
    learning_id: str = typer.Option(None, "--learning-id", help="Learning/skill ID (feedback)"),
    signal: str = typer.Option(None, help="positive|negative|correction (feedback)"),
    run_id: str = typer.Option(None, "--run-id", help="Run ID filter"),
    step_key: str = typer.Option(None, "--step-key", help="Step context (feedback)"),
    lines: int = typer.Option(20, "--lines", "-n", help="Number of entries (log)"),
    threshold: float = typer.Option(0.6, "--threshold", help="Similarity threshold (rationalize)"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier (feedback)"),
    root: str = typer.Option(None, help="State root directory"),
):
    """Manage the agent learning system.

    \b
    Actions:
      list         List learned skills with health scores
      log          Show raw observation log from step executions
      capture      Manually capture a learned skill (requires --role, --workflow, --name, --content)
      feedback     Record feedback on a skill (requires --learning-id, --signal)
      rationalize  Deduplicate similar skills (requires --role, --workflow)
      summary      Summary stats for the learning system
      analytics    Effectiveness metrics with feedback loop closure
    """
    from ioagentfarm.cli import _root, _learning_lifecycle

    if action not in _LEARNINGS_ACTIONS:
        print(json.dumps({"error": f"Unknown action '{action}'. Choose from: {', '.join(_LEARNINGS_ACTIONS)}"}))
        raise typer.Exit(code=1)

    root_path = Path(root).resolve() if root else _root()
    ll = _learning_lifecycle(root_path)

    if action == "list":
        from ioagentfarm.engine.learning import LearningStore
        skills = ll._store.list_learnings(role=role, workflow=workflow)
        for s in skills:
            s["health"] = round(LearningStore.learning_health(s), 2)
        print(json.dumps({"learned_skills": skills, "total": len(skills)}, indent=2))

    elif action == "log":
        if run_id:
            obs = ll.get_run_observations(run_id)
        elif role and workflow:
            obs = ll.get_observations(role=role, workflow=workflow, limit=lines)
        else:
            with ll._log._tx() as cursor:
                clauses: list[str] = []
                params: list = []
                if role:
                    clauses.append("role=?")
                    params.append(role)
                if workflow:
                    clauses.append("workflow=?")
                    params.append(workflow)
                where = " AND ".join(clauses) if clauses else "1=1"
                cursor.execute(
                    ll._log._q(f"SELECT * FROM learning_log WHERE {where} ORDER BY created_at DESC LIMIT ?"),
                    (*params, lines),
                )
                obs = [dict(r) for r in cursor.fetchall()]
        print(json.dumps({"observations": obs, "total": len(obs)}, indent=2))

    elif action == "capture":
        if not all([role, workflow, name, content]):
            print(json.dumps({"error": "capture requires --role, --workflow, --name, --content"}))
            raise typer.Exit(code=1)
        sid = ll.capture_skill(role=role, workflow=workflow, name=name, content=content, run_id=run_id)
        print(json.dumps({"learning_id": sid, "name": name, "role": role, "workflow": workflow}))

    elif action == "feedback":
        if not learning_id or not signal:
            print(json.dumps({"error": "feedback requires --learning-id and --signal"}))
            raise typer.Exit(code=1)
        from ioagentfarm.cli import _default_user_id
        uid = user_id or _default_user_id()
        ll.record_feedback(
            learning_id, signal=signal, content=content or "",
            user_id=uid, run_id=run_id or "", step_key=step_key or "",
            source_channel="cli",
        )
        print(json.dumps({"status": "ok", "learning_id": learning_id, "signal": signal}))

    elif action == "rationalize":
        if not role or not workflow:
            print(json.dumps({"error": "rationalize requires --role and --workflow"}))
            raise typer.Exit(code=1)
        result = ll.rationalize(role=role, workflow=workflow, similarity_threshold=threshold)
        print(json.dumps(result, indent=2))

    elif action == "summary":
        summary = ll.summary(role=role, workflow=workflow)
        print(json.dumps(summary, indent=2))

    elif action == "analytics":
        result = ll.analytics(role=role, workflow=workflow)
        print(json.dumps(result, indent=2))


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def run_output(
    run_id: str = typer.Option(..., help="Run ID"),
    file: str = typer.Option(None, help="File name to read (e.g. strategy_plan.md)"),
    list_files: bool = typer.Option(False, "--list", help="List available deliverable files"),
    write: str = typer.Option(None, help="File name to write (reads content from stdin)"),
    publish: str = typer.Option(None, help="Publish a file from agent workspace to run project directory"),
    role: str = typer.Option(None, help="Agent role (for --publish, e.g. strategist)"),
    grep: str = typer.Option(None, help="Search pattern - only return matching sections"),
    step_key: str = typer.Option(None, "--step-key", help="Read raw step output_text from DB instead of file"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
):
    """Read, write, or publish run deliverables.

    Checks local files first, pulls from S3 if not found (pod recovery).
    Used by agents during interactive chat to access run context without
    changing IOBOT_WORKSPACE.

    Examples:
      aicore run-output --run-id <id> --list
      aicore run-output --run-id <id> --file strategy_plan.md
      aicore run-output --run-id <id> --file strategy_plan.md --grep "Play J"
      aicore run-output --run-id <id> --step-key strategize
      echo "content" | aicore run-output --run-id <id> --write strategy_plan_v2.md
    """
    from ioagentfarm.cli import _root, _store

    # Resolve the workspace BEFORE touching the store: that is what loads
    # `~/.iobot/workspaces/<code>/.env`, and therefore IOF_DATABASE_URL.
    # Without it these commands silently read the DEFAULT local sqlite while
    # `run --workspace X` wrote X's database — so an operator reaching for
    # recovery during an incident was told 'Run not found' (2026-08-16).
    from ioagentfarm.cli import _workspace_code
        # NO --workspace on run/step commands, by design. Activation (or the
    # driver's inherited IOF_WORKSPACE) is the ONE way to choose the tenant,
    # and every command prints a context line naming it. A flag that can
    # disagree with the activation is a footgun for a human and worse for an
    # LLM operator, which pattern-matches the flag from one command onto
    # another. Nothing ever passed it; the surface was pure risk.
    _workspace_code(None, required=True)
    from ioagentfarm.engine.iobot_config import get_run_output_dir

    root_path = Path(root).resolve() if root else _root()

    try:  # a ghost run answers a well-formed empty listing otherwise (novice, round 7)

        _store(root_path).get_run(run_id)

    except KeyError:

        print(json.dumps({"error": "run not found", "run_id": run_id}))

        raise typer.Exit(code=3)
    run_output_dir = get_run_output_dir(root_path, run_id)

    # --- List mode ---
    if list_files:
        files = []
        if run_output_dir.exists():
            for f in sorted(run_output_dir.iterdir()):
                if f.is_file() and f.suffix in (".md", ".txt", ".json", ".csv"):
                    files.append({"name": f.name, "size": f.stat().st_size})
        # Also check for step outputs
        steps_dir = root_path / "runs" / run_id / "steps"
        step_outputs = []
        if steps_dir.exists():
            for sd in sorted(steps_dir.iterdir()):
                if sd.is_dir():
                    out = sd / "OUTPUT.md"
                    if not out.exists():
                        out = sd / "OUTPUT.txt"
                    if out.exists():
                        step_outputs.append({"step": sd.name, "size": out.stat().st_size})
        print(json.dumps({"run_id": run_id, "deliverables": files, "step_outputs": step_outputs}, indent=2))
        return

    # --- Step output from DB ---
    if step_key:
        store = _store(root_path)
        outputs = store.get_step_outputs_map(run_id)
        text = outputs.get(step_key, "")
        if text:
            print(text)
        else:
            print(json.dumps({"error": f"No output for step '{step_key}' in run {run_id}"}))
            raise typer.Exit(code=1)
        return

    # --- Write mode ---
    if write:
        import sys as _sys
        run_output_dir.mkdir(parents=True, exist_ok=True)
        content = _sys.stdin.read()
        dest = run_output_dir / write
        dest.write_text(content, encoding="utf-8")
        print(json.dumps({"written": str(dest), "size": len(content)}))
        return

    # --- Publish mode ---
    if publish:
        if not role:
            print(json.dumps({"error": "--publish requires --role (e.g. --role strategist)"}))
            raise typer.Exit(code=1)
        from ioagentfarm.engine.workspaces import iobot_agent_workspace
        import shutil
        ws = iobot_agent_workspace(role)
        source = ws / publish
        if not source.exists():
            print(json.dumps({"error": f"File '{publish}' not found in {role} workspace at {source}"}))
            raise typer.Exit(code=1)
        run_output_dir.mkdir(parents=True, exist_ok=True)
        dest = run_output_dir / publish
        shutil.copy2(str(source), str(dest))
        size = dest.stat().st_size
        # Cleanup temp file from workspace
        source.unlink()
        # Push to S3 so artifacts are available on any pod
        try:
            from ioagentfarm.web.storage import get_storage
            instance_dir = root_path / "instances" / run_id
            if instance_dir.exists():
                get_storage().push_file(run_id, dest, sub_prefix="instances/project")
        except Exception:
            pass  # Best-effort — don't fail publish if S3 is unavailable
        print(json.dumps({"published": str(dest), "size": size, "source_cleaned": True}))
        return

    # --- Read mode ---
    if not file:
        print(json.dumps({"error": "Specify --file, --list, --step-key, --write, or --publish"}))
        raise typer.Exit(code=1)

    fpath = run_output_dir / file
    # Local file check
    if not fpath.exists():
        # Try S3 recovery
        try:
            from ioagentfarm.web.storage import get_storage
            storage = get_storage()
            instance_dir = root_path / "instances" / run_id
            if not instance_dir.exists():
                storage.pull(run_id, instance_dir, sub_prefix="instances")
            # Re-check after pull
            fpath = run_output_dir / file
        except Exception:
            pass

    if not fpath.exists():
        print(json.dumps({"error": f"File '{file}' not found for run {run_id}"}))
        raise typer.Exit(code=1)

    text = fpath.read_text(encoding="utf-8")

    # Grep mode — return only matching sections
    if grep:
        lines = text.split("\n")
        matched = []
        context = 3  # lines around match
        for i, line in enumerate(lines):
            if grep.lower() in line.lower():
                start = max(0, i - context)
                end = min(len(lines), i + context + 1)
                matched.extend(lines[start:end])
                matched.append("---")
        if matched:
            print("\n".join(matched))
        else:
            print(json.dumps({"error": f"No matches for '{grep}' in {file}"}))
            raise typer.Exit(code=1)
        return

    print(text)


#: Session key for the no-run path, before ``_invoke_agent`` appends
#: ``:u:<user_id>``. Stable per (role, user) ON PURPOSE: the runtime persists
#: one JSONL per session under ``<workspace>/sessions/``, so two consecutive
#: ``agent-chat`` calls to the same agent continue one conversation instead of
#: introducing themselves twice. Distinct from ``iof:<run_id>:<step_key>`` and
#: ``iof:task:<id>``, so an ad-hoc chat never lands in a step's transcript.
_ADHOC_SESSION_PREFIX = "iof:chat"


def _chat_without_a_run(*, role: str, message: str, uid: str) -> None:
    """Talk to *role* by spawning the runtime locally. No server, no run.

    This is the "I just made this agent - does it work?" path, and it has the
    same dependencies as ``ioagentfarm run``: an agent workspace and a model
    provider in ``~/.iobot/config.json``. Requiring ``ioagentfarm serve`` for
    it would be an accident of history - chat was built for the always-on
    surface, where a warm pooled AgentLoop and an HTTP endpoint are the point.
    Neither is the point of one question.

    ``ensure_iobot_agent`` first, exactly as ``AgentPool.get`` does, so an
    agent that has never run is seeded here rather than answering as a
    default persona out of an empty directory.

    The spawn is ``cli._invoke_agent`` - the same one every step goes through.
    Not for brevity: it owns the byte-level CR/LF stdout reader that keeps
    Windows output from duplicating every visual line, the iobot rebrand, and
    the venv-first PATH. A second reader here would inherit none of that, and
    would silently stop inheriting the next fix too.
    """
    from ioagentfarm.cli import _invoke_agent, _root

    try:
        ensure_iobot_agent(role)
    except FileNotFoundError as exc:
        # Almost always a typo or a pack that was never installed into THIS
        # environment. The exception already names both preconditions.
        print(json.dumps({"error": f"No agent '{role}': {exc}"}))
        raise typer.Exit(code=1)

    # Workspace memory into the agent's home, version-gated — the standalone
    # chat is the path a developer uses to ask "does my agent work?", and an
    # agent that answers without the workspace's reviewed context here would
    # behave differently from the same agent in a run or on the served path.
    try:
        from ioagentfarm.engine.memory import hooks as _memory_hooks
        from ioagentfarm.engine.workspaces import maybe_workspace_code as _mwc
        _memory_hooks.refresh_served_workspace(
            _root(), iobot_agent_workspace(role), role=role, workspace_code=_mwc() or "")
    except Exception:  # noqa: BLE001
        logger.debug("workspace memory not materialized for agent-chat role=%s", role, exc_info=True)

    # AN INSTANCE CONFIG, OR THE AGENT'S OWN TOOLS RUN BLIND.
    #
    # The runtime strips an exec'd subprocess's environment to HOME/LANG/TERM
    # unless the config lists `tools.exec.allowedEnvKeys`. Without a config
    # this path passed none — so every command the agent itself runs
    # (`forensics explain`, `iof-query`, `iof-run-audit`) started with no
    # IOF_ROOT and no IOF_DATABASE_URL, could not find the state directory or
    # the database, and answered from whatever it could see on disk.
    #
    # The symptom was the Core Assistant contradicting the CLI about the same
    # run: `aicore status` read `done` from the database while the assistant
    # reported "db: unavailable (filesystem-only view)" and a status of
    # unknown — in LOCAL MODE, which is the mode both getting-started guides
    # use. The assistant was not wrong; it genuinely could not see the run.
    #
    # Keyed on the role rather than a run: this session persists across calls,
    # so its config should too, and rebuilding it each time would discard the
    # runtime state iobot derives from the config's directory.
    try:
        from ioagentfarm.engine.iobot_config import create_instance_config
        cfg_path = create_instance_config(_root(), f"adhoc-{role}", os.getcwd())
    except Exception:                      # noqa: BLE001 - never block a chat
        logger.debug("ad-hoc instance config unavailable for %r", role,
                     exc_info=True)
        cfg_path = None

    # root_path gives the subprocess IOF_ROOT and sends its stderr to a file
    # instead of /dev/null — the difference between a diagnosable failure and
    # a silent one when the model provider is misconfigured.
    _invoke_agent(
        role=role,
        session_key=f"{_ADHOC_SESSION_PREFIX}:{role}",
        user_id=uid,
        root_path=_root(),
        message=message,
        config_path=cfg_path,
        # Selects the streaming branch of _invoke_agent, which is the one that
        # interprets the byte stream and rebrands it. Without a callback the
        # subprocess writes to the terminal raw.
        on_output=lambda _line: None,
    )


def agent_chat(
    role: str = typer.Option(..., "--role", "-r", help="Agent role to message (e.g. analyst, strategist)"),
    message: str = typer.Option(..., "--message", "-m", help="Message to send to the agent"),
    run_id: str = typer.Option("", "--run-id", help="Continue THIS run's session via the engine. Without it the chat is standalone on this box - no run is looked up."),
    user_id: str = typer.Option("", "--user-id", help="User ID for session scoping"),
    port: int = typer.Option(0, "--port", help="Gateway port on localhost (default: GATEWAY_PORT env or 8111). --run-id path only - without a run there is no server to reach."),
    url: str = typer.Option("", "--url", help="Engine base URL, e.g. http://engine:8111 (default: IOF_RUN_API_URL env). Use this when the engine is not on this machine. --run-id path only."),
    local: bool = typer.Option(False, "--local/--no-local", help="Accepted and ignored: standalone-local is the default now. Kept so existing scripts keep working; --run-id is what selects the run path."),
    workspace: str = typer.Option(
        "", "--workspace", "-w",
        help="Tenant workspace. Defaults to IOF_WORKSPACE, then the one set "
             "by `workspace use` - the same order as every other "
             "workspace-scoped command."),
):
    """Send a message to an agent - standalone on this box, or inside a run.

    Two paths, and the caller picks: the command never chooses a context on
    your behalf (docs/one-truth-content-model.md section 4.1). It names the
    path it took on stderr, because "continue where the run left off" and
    "fresh conversation" are different answers to the same words.

    DEFAULT - STANDALONE: spawns the runtime locally against the agent's own
    workspace, resolved from the installed pack - no server, no port, no
    database, same requirements as `ioagentfarm run`. This is the check to
    make right after creating or editing an agent: one LLM call to prove the
    persona and its skills loaded, instead of a whole run. The conversation
    continues across calls to the same agent. No run is looked up: old runs
    in the database and an engine that is not listening are both irrelevant.

    --run-id <id>: posts to the engine's /api/run/<id>/message, which has full
    session recovery, so it works after a pod crash or on a different pod.
    Needs `ioagentfarm serve`. An unreachable engine is an error, never a
    silent fallback to a fresh local conversation.

    `--local` is accepted and ignored - it used to force the standalone path,
    which is now the default. There is no "newest active run" fallback.

    Examples:

      aicore agent-chat --role iris -m "Who are you and what can you do?"
      aicore agent-chat --role strategist -m "Why did you choose Play J?" --run-id run_xxx
      aicore agent-chat --role analyst -m "Dig deeper" --run-id run_xxx --url http://engine:8111
    """
    import urllib.request
    import urllib.error

    # RESOLVE AND ACTIVATE THE WORKSPACE FIRST. Without this the command had
    # no `--workspace` at all, so it ran against `default` whatever the rest
    # of the session was doing -- and the standalone path, which promises
    # "the agent's own workspace, nothing shared", materialised the agent
    # into the MACHINE-GLOBAL `~/.iobot/agents/` instead of the tenant's. A
    # walkthrough found the directory still there after both `workspace
    # delete` and the documented teardown, carrying one attempt's memory into
    # the next.
    #
    # `_activate_workspace` is what the run path uses: it resolves
    # --workspace > IOF_WORKSPACE > `workspace use`, loads that workspace's
    # settings, and points IOF_AGENT_HOME at its agent home.
    from ioagentfarm.cli import (_activate_workspace, _default_user_id,
                                 _root, _workspace_code, context_line)
    ws_code = _workspace_code(workspace, required=True)  # resolves AND loads its .env
    _activate_workspace(ws_code, _root())     # points IOF_AGENT_HOME at it
    uid = user_id or _default_user_id()

    # THE CONTEXT LINE, ON STDERR. Every workspace-scoped command opens with
    # workspace / db / installed content; here it goes to stderr because this
    # command's stdout is the agent's reply and nothing else (Jarvis reads it
    # via exec).
    _stderr_console.print(context_line(ws_code), soft_wrap=True)

    if local:
        # Kept so a script written against the old contract still runs.
        # Announced, not silent: an operator who typed it should learn it no
        # longer changes anything.
        _stderr_console.print("[dim]note: --local is the default now and is "
                              "ignored[/dim]", soft_wrap=True)

    # NO RUN LOOKUP. `--run-id` is the ONLY thing that selects the run path.
    # The old contract fell back to "the newest active run for this user",
    # which turned "does my new agent work?" into a call to an engine that
    # may not be listening on any deployment with a run left in it, and
    # needed a database for a question that needs none. Scenario 15 of the
    # content model: standalone works with old runs in the database and no
    # engine listening.
    if not run_id:
        print(f"[agent-chat] no --run-id - talking to {role} locally, no server "
              f"(its own workspace; the conversation continues across calls)",
              file=sys.stderr)
        _chat_without_a_run(role=role, message=message, uid=uid)
        return

    # Resolve WHERE the engine is, not just which port.
    #
    # This used to be `http://localhost:{port}` with no way to say
    # otherwise, so the CLI could only ever talk to an engine on the
    # same machine — while the studio API, reaching the same service
    # for the same reason, has always resolved a full URL from
    # IOF_RUN_API_URL (app/routers/run_proxy.py). In the split
    # deployment the engine is a different pod, so the API could reach
    # it and `agent-chat` could not, with no flag or variable to fix it.
    #
    # Same variable as the API on purpose: one answer to "where is the
    # engine?" in a .env both sides read. --url wins for a one-off;
    # --port/GATEWAY_PORT still work and still mean localhost, so every
    # existing invocation behaves exactly as before.
    base = (url or os.environ.get("IOF_RUN_API_URL", "")).rstrip("/")
    if not base:
        gw_port = port or int(os.environ.get("GATEWAY_PORT", "8111"))
        base = f"http://localhost:{gw_port}"
    url = f"{base}/api/run/{run_id}/message"

    # stderr, not stdout: this command's stdout is consumed by Jarvis via exec
    # and is the agent's reply and nothing else.
    print(f"[agent-chat] run {run_id} - continuing {role}'s session via {base}",
          file=sys.stderr)

    payload = json.dumps({
        "content": message,
        "role": role,
        "sender_id": user_id or "agent:cora",
    }).encode("utf-8")

    # The engine authenticates now (IOF_ENGINE_AUTH), so this caller has to
    # present a credential like every other one. Resolved from the SAME
    # IOF_ENGINE_CRED_* variables the API pod reads — a rail the Studio can
    # use and the terminal cannot is a rail nobody can debug from the
    # terminal. Empty against an engine with auth off, so every existing
    # invocation is unchanged.
    from ioagentfarm.security.rail import engine_auth_headers

    headers = {"Content-Type": "application/json"}
    headers.update(engine_auth_headers())

    req = urllib.request.Request(
        url,
        data=payload,
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            # Print just the agent's response for Jarvis to consume
            print(data.get("content", ""))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        error = f"HTTP {exc.code}: {body}"
        if exc.code in (401, 403):
            # Name the variables rather than leaving the reader to find them.
            # "HTTP 401" against an engine that answered fine last week reads
            # as an outage; it is almost always an unconfigured caller.
            from ioagentfarm.security.rail import describe_credential
            error += (f" | this engine requires authentication and this "
                      f"caller presented: {describe_credential()}. Set "
                      f"IOF_ENGINE_CRED_MODE (apikey|oauth) and its "
                      f"credentials in the workspace .env.")
        print(json.dumps({"error": error}))
        raise typer.Exit(code=1)
    except urllib.error.URLError as exc:
        print(json.dumps({"error": f"Cannot reach gateway at {url}: {exc.reason}"}))
        raise typer.Exit(code=1)


def resume(
    run_id: str = typer.Argument(None, help="Run ID to resume (omit for the latest active run)"),
    root: str = typer.Option(None, help="State root directory; default .iof"),
    user_id: str = typer.Option(None, "--user-id", help="User identifier"),
    force: bool = typer.Option(False, "--force",
                               help="Resume even though the driver heartbeat looks live"),
):
    """Continue an interrupted run: reap what died, then re-spawn its driver.

    The CLI face of what already exists everywhere else - the supervisor's
    driver resurrection and ``POST /api/run/{id}/resume`` both spawn a fresh
    driver against the EXISTING run, because drivers are stateless and the
    database is the only memory that matters. Until this command, an operator
    who Ctrl+C'd a foreground ``run`` had no verb for the same act and was
    left choosing between ``run-step`` per pending step (absurd past one) or
    a brand-new run (correct only for ledger-idempotent workflows).

    Refuses a DONE run (nothing to resume), refuses a live driver unless
    --force (two drivers double-spawn work), and reaps crash-orphaned
    'running' steps first so the fresh driver sees retryable state, not
    ghosts.
    """
    from datetime import datetime as _dt, timezone as _tz

    from ioagentfarm.cli import (_default_user_id, _resolve_run_id, _root,
                                 _store, _workspace_code)
    from ioagentfarm.engine import supervisor as _sup

    # Workspace BEFORE store - same 2026-08-16 lesson step-retry carries: this
    # is what loads the workspace .env and therefore IOF_DATABASE_URL, and
    # without it recovery reads an empty default sqlite and says 'not found'.
    workspace = _workspace_code(None, required=True)
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()
    # (store, root_path, explicit_run_id, user_id) - the first cut passed
    # (store, run_id, uid), so the USER ID landed in the run-id slot and
    # every `aicore resume` answered "run not found: cli:<user>" (novice
    # finding, round 3). Nothing had ever invoked it.
    # Bare `resume` means "the run that needs resuming": the newest RUNNING
    # run of this user, not the pointer the last command left (which was
    # the run that had just finished - novice finding, round 4).
    if not run_id:
        try:
            _cand = store.get_latest_active_run(user_id=uid)
        except Exception:  # noqa: BLE001
            _cand = None
        run_id = (_cand or {}).get("id") or run_id
    rid = _resolve_run_id(store, root_path, run_id, uid)
    try:
        run = store.get_run(rid)
    except KeyError:
        run = None
    if not run:
        typer.echo(f"No run '{rid}' in this database. `aicore status` lists recent runs.", err=True)
        raise typer.Exit(3)

    status = run.get("status")
    if status == "done":
        typer.echo(f"{rid} is done - nothing to resume.")
        raise typer.Exit(0)
    if status == "failed" and not force:
        # A failed run is a decision, not a crash: the hard cap or the
        # supervisor concluded it cannot converge as-is. Resuming it without
        # changing anything re-runs the same convergence to the same wall, so
        # the operator states the intent explicitly.
        typer.echo(
            f"{rid} is FAILED - it was concluded, not interrupted. Fix what "
            f"stopped it (step-retry bumps a capped step, step-skip unblocks "
            f"a dead one), then resume with --force.", err=True)
        raise typer.Exit(1)

    # A LIVE driver means this run does not need resuming - and a second
    # driver would double-spawn steps up to the fan-out cap. Same staleness
    # basis as the supervisor: driver heartbeat, else the run's updated_at.
    # A driver that STOPS clears its heartbeat (Store.clear_driver_heartbeat),
    # so a NULL heartbeat means "nothing drives this run" - the first cut
    # fell back to the run's updated_at, which `step-retry` had just
    # touched, and refused a resume for a driver that had exited (novice
    # finding, round 3: "aicore resume is dead").
    _ds = _sup.driver_state(run, store.list_steps(rid))
    age = _ds.get("heartbeat_age_s")
    if age is not None and not _ds["stale"] and not force:
        typer.echo(
            f"driver heartbeat is {int(age)}s old (stale after "
            f"{int(_ds['threshold_s'])}s for a {run.get('driver') or 'agent'} driver) - "
            f"a driver appears to be running. If you know it is dead, wait for the "
            f"threshold or re-run with --force.", err=True)
        raise typer.Exit(1)

    # Reap first, resume second. A Ctrl+C leaves steps 'running' with no
    # process behind them; a fresh driver polling next-step would count those
    # ghosts against the in-flight cap and wait on work nobody is doing. The
    # supervisor's own sweep flips them to retryable state - scoped to this
    # run, drivers OFF because spawning one is the next line's job.
    actions = _sup.supervise_once(store, root_path, run_id=rid,
                                  resume_drivers=False)
    for line in actions or []:
        if isinstance(line, dict):
            line = (f"{line.get('step_key') or line.get('run_id') or '?'} - "
                    f"{line.get('action') or ''}"
                    + (f": {line.get('reason')}" if line.get("reason") else ""))
        typer.echo(f"  reaped: {line}")

    # The steps the dead driver was running are dead with it. The sweep
    # above reaps a step only past its own staleness window (180 s), so a
    # resume seconds after a kill spawned a driver that idled until a
    # supervisor - or nothing, on a CLI-only deployment - reaped the step
    # three minutes later (novice finding, round 7). A command step
    # heartbeats every ~10 s while it lives: silent for 30 s, it is gone.
    _reaped_now = []
    for _s in store.list_steps(rid):
        if _s.get("status") != "running":
            continue
        _hb = _sup._age_s(__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
                          _sup._parse_ts(_s.get("heartbeat_at")))
        if force or _hb is None or _hb > 30:
            try:
                store.crash_recover_step(rid, _s["step_key"])
                _reaped_now.append((_s["step_key"], _hb))
            except Exception:  # noqa: BLE001
                continue
    for _k, _hb in _reaped_now:
        typer.echo(f"  reaped: {_k} - its process died with the driver "
                   f"(heartbeat {'never' if _hb is None else f'{_hb:.0f}s old'}); it will run again")
        try:
            from ioagentfarm.engine.forensics import get_forensics, SEVERITY_WARN
            get_forensics(root_path).emit(
                run_id=rid, event_type="step.reaped_on_resume", severity=SEVERITY_WARN,
                step_key=_k, role=None,
                message=f"step '{_k}' reset by resume - heartbeat "
                        f"{'never' if _hb is None else f'{_hb:.0f}s old'}; the driver it ran under is gone",
                payload={"heartbeat_age_s": _hb, "force": bool(force)})
        except Exception:  # noqa: BLE001
            pass

    # A `cancel` that landed a second ago wins: re-read before spawning.
    # Two operators did this in the same second and the record read
    # CANCELLED and RECOVERED at once (novice finding, round 7).
    _now_row = store.get_run(rid)
    if _now_row.get("status") == "failed" and status != "failed":
        typer.echo(f"{rid} was failed while this resume ran (a cancel or a verdict landed) - "
                   f"nothing spawned. `aicore forensics explain {rid}` says which.", err=True)
        raise typer.Exit(1)

    if status == "failed":
        # The same raw write the supervisor uses for the opposite transition
        # (its deadlock-fail); Store has no general status setter and this is
        # not the commit that should grow one.
        with store._tx() as cursor:
            cursor.execute(
                store._q("UPDATE runs SET status='running', updated_at=? "
                         "WHERE id=?"),
                (store._now(), rid))
        typer.echo(f"  {rid}: failed -> running (--force)")

    _sup._spawn_driver(store.get_run(rid), root_path, workspace)
    try:
        from ioagentfarm.engine.forensics import get_forensics, SEVERITY_INFO
        get_forensics(root_path).emit(
            run_id=rid, event_type="run.resumed", severity=SEVERITY_INFO,
            step_key=None, role=None,
            message=f"resumed by {uid}" + (" (--force)" if force else ""),
            payload={"by": uid, "force": bool(force)})
    except Exception:  # noqa: BLE001
        pass
    typer.echo(f"resumed {rid}: fresh driver spawned against existing state "
               f"(workspace {workspace}).")
    typer.echo(f"watch: aicore watch {rid}")


def cancel(
    run_id: str = typer.Argument(..., help="The run to stop"),
    reason: str = typer.Option("", "--reason", help="Why - recorded on the run"),
    yes: bool = typer.Option(False, "--yes", "-y",
                             help="Skip the confirmation shown when the run's driver is still alive"),
    root: str = typer.Option(None, "--root", help="Root directory (default: IOF_ROOT or .iof)"),
    user_id: str = typer.Option("", "--user-id", help="Who is cancelling (default: cli:<os user>)"),
):
    """Stop a run for good: no retry, no resurrection, no further model calls.

    Kills the run's detached driver when its pid is on record, fails every
    running step with the reason, fails the run and writes `run.cancelled`;
    the supervisor leaves a failed run alone. `aicore step-retry` re-opens
    a step if this was a mistake. Exit 0 stopped, 0 already concluded
    (says so), 3 unknown run.

    Cancelling a STUCK run (its driver is gone) is friction-free. Cancelling a
    HEALTHY run - one whose driver is still sending heartbeats - is the
    surprising case a tired operator reaches for by reflex, so it asks first
    (novice finding, round 8 N4); `--yes` skips, and with no terminal it
    refuses rather than assume consent.
    """
    from ioagentfarm.cli import _root, _store, _default_user_id
    from ioagentfarm.engine import supervisor as _sup
    root_path = Path(root).resolve() if root else _root()
    store = _store(root_path)
    uid = user_id or _default_user_id()

    # Confirm ONLY when the run's driver is alive - the case where cancel stops
    # work that is actually moving. A gone/failed/done run skips straight through.
    if not yes:
        try:
            _run = store.get_run(run_id)
            _ds = _sup.driver_state(_run, store.list_steps(run_id))
            if _run.get("status") == "running" and not _ds["stale"]:
                _age = _ds.get("heartbeat_age_s")
                _msg = (f"{run_id} has a LIVE driver (heartbeat "
                        f"{'just now' if _age is None else f'{_age:.0f}s ago'}) - cancelling "
                        "stops a run that is still moving and marks it failed.")
                if not sys.stdin.isatty():
                    typer.echo(_msg + " Refusing without --yes (no terminal). Pass --yes if "
                               "this is deliberate.", err=True)
                    raise typer.Exit(code=1)
                if not typer.confirm(f"{_msg}\nCancel it anyway?", default=False):
                    typer.echo("left running.")
                    raise typer.Exit(code=0)
        except KeyError:
            pass  # unknown run: cancel_run below reports it as a 3

    try:
        out = _sup.cancel_run(store, root_path, run_id, by=uid, reason=reason)
    except KeyError:
        typer.echo(f"No run '{run_id}' in this database. `aicore status` lists recent runs.", err=True)
        raise typer.Exit(code=3)
    if out.get("already"):
        typer.echo(f"{run_id} is {out['already']} - nothing to cancel.")
        raise typer.Exit(code=0)
    typer.echo(f"cancelled {run_id}: driver {'killed (pid ' + ', '.join(str(p) for p in out['killed_pids']) + ')' if out['killed_pids'] else 'not running here (no pid on record; a foreground driver notices on its next poll)'}; "
               f"{len(out['stopped_steps'])} running step(s) failed with the reason"
               + (f" ({', '.join(out['stopped_steps'])})" if out['stopped_steps'] else "")
               + "; the run is failed and will not be resumed by the supervisor.")
    # THE UNDO MUST FIT THE STATE CANCEL JUST CREATED. This printed
    # `step-retry --step-key <key>` unconditionally - and when cancel had
    # stopped a run whose step was still PENDING (its own line says "0 running
    # step(s) failed"), that command correctly refuses: step-retry only takes
    # a FAILED step. So the product handed the operator an undo for a state it
    # had not produced (certification round 8). Now it names the steps that
    # can actually be retried, and otherwise says what continuing looks like.
    if out["stopped_steps"]:
        for _k in out["stopped_steps"]:
            typer.echo(f"undo that step: aicore step-retry --run-id {run_id} "
                       f"--step-key {_k}")
    else:
        typer.echo("no step was mid-flight, so there is nothing to retry; "
                   f"continue this run with: aicore resume {run_id} --force")


def register_commands(app: typer.Typer) -> None:
    """Register orchestration and recovery commands onto the main CLI app."""
    app.command("cancel")(cancel)
    app.command("next-step")(next_step)
    app.command("step-complete")(step_complete)
    app.command("run-step")(run_step)
    app.command("agent-chat")(agent_chat)
    app.command("step-retry")(step_retry)
    app.command("resume")(resume)
    app.command("step-skip")(step_skip)
    app.command("run-output")(run_output)
    # Learning system (single command with action argument)
    app.command("learnings")(learnings)


def close_run_record(store, root_path: Path, run_id: str, *,
                     run_refreshed: dict | None = None) -> None:
    """The closing work a run gets EXACTLY ONCE: boundary event, end-of-run
    gate re-check, `coverage:`, the memory queue, swarm child results.

    THE CALLER MUST HAVE WON THE TERMINAL CLAIM.
    `mark_run_done_if_complete` / `mark_run_failed_if_stuck` each return
    True for one caller only, and this is what that winner owes the record.

    IT LIVES HERE BECAUSE THERE ARE TWO WINNERS, NOT ONE. `_finalize_step`
    is the obvious one. The other is `next_step`, which claims the same
    transition whenever it finds nothing pending or running - it exists so a
    run whose finalizer died still converges. But the finalizer sets the
    LAST step to `done` about a hundred lines before it claims, and under
    `--driver code` a poll lands every two seconds WHILE the child is still
    alive. A poll inside that window won the claim and then did none of this
    work, so the finalizer's `_won_done` came back False and the run reached
    `done` with no `run.completed`, no end-of-run gate re-check, no memory
    queue and - the one that matters most for the pharma pipelines - **no
    `run.coverage`**, which is the entire mechanism by which a run that
    consumed half its backlog says so. An absence is invisible to a success
    check; `coverage:` exists to fix exactly that, and a driver's poll
    cadence was quietly undoing it.

    So: whoever wins the claim does the work. Not "the finalizer does the
    work and hopes it wins".
    """
    if run_refreshed is None:
        run_refreshed = store.get_run(run_id)
    # --- Run boundary events + swarm child enrichment ---
    # Emitted only on the actual transition (running -> done|failed), so the
    # timeline gets exactly one closing anchor per run. For swarm runs the
    # same moment derives one swarm.child_result per entry of the run's
    # results.json — the A2A fan-out itself emits nothing, and this is what
    # makes child reliability queryable across runs.
    try:
        from ioagentfarm.engine.forensics import (get_forensics,
                                                  SEVERITY_ERROR,
                                                  SEVERITY_INFO)
        _new_status = run_refreshed.get("status")
        if _new_status in ("done", "failed"):
            if _new_status == "done":
                # every deliverable a passed gate digested, compared with
                # what is in the artifact directory now (novice, round 7)
                try:
                    _recheck_gates_at_run_end(store, root_path, run_id)
                except Exception:  # noqa: BLE001
                    logger.debug("gate re-check failed", exc_info=True)
            _f = get_forensics(root_path)
            _f.emit(
                run_id=run_id,
                event_type=("run.completed" if _new_status == "done"
                            else "run.failed"),
                severity=(SEVERITY_INFO if _new_status == "done"
                          else SEVERITY_ERROR),
                message=f"run transitioned to {_new_status}",
                payload={"kind": run_refreshed.get("kind", "workflow")},
            )
            # WHAT THE RUN DID NOT COVER. A run's record knows its own steps
            # and nothing about input that was never queued for it, so a
            # pipeline consuming half its backlog reaches `done` with every
            # gate green and the shortfall shows up nowhere. The workflow
            # declares the commands that describe its own coverage; this runs
            # them at the transition and puts the answer in the record, so it
            # reaches whoever reads the run next without their having to know
            # to ask. Report, never a gate — a legitimate backlog must not
            # fail a run. Wrapped separately from the boundary event above so
            # a broken coverage command cannot cost the run its closing
            # anchor.
            try:
                from ioagentfarm.engine import coverage as _cov
                import yaml as _yaml
                _wf_path = (root_path / "instances" / run_id
                            / "workflow" / "workflow.yaml")
                # The RAW snapshot, like the `learning:` and swarm markers:
                # the loader ignores keys it does not model, so reading the
                # file directly is what lets `coverage:` exist without a
                # loader change - and an older engine simply never sees it.
                _snapshot = (_yaml.safe_load(_wf_path.read_text(encoding="utf-8")) or {}
                             if _wf_path.exists() else {})
                _checks = _cov.declared_checks(_snapshot)
                if _checks:
                    _results = _cov.run_checks(
                        _checks, cwd=root_path / "instances" / run_id / "project")
                    _f.emit(
                        run_id=run_id,
                        event_type="run.coverage",
                        severity=SEVERITY_INFO,
                        message="coverage at completion",
                        payload={"checks": _results},
                    )
                    logger.info("run %s coverage:\n%s", run_id, _cov.render(_results))
            except Exception:
                logger.debug("coverage checks failed", exc_info=True)
            # WORKSPACE MEMORY. A completed run is EXTRACTED into candidate
            # facts and consolidated against what the workspace already
            # holds (engine/memory/). Keyed to the won transition, so one
            # run is queued once however many pods converge on it; the
            # consolidation itself runs detached (two model calls the
            # finalizer must not wait on) and the claim table makes it
            # exactly-once across pods and re-runnable after a crash. Wrapped
            # separately so it can never cost the run its closing anchor.
            if _new_status == "done":
                try:
                    from ioagentfarm.engine.memory import hooks as _memory_hooks
                    _mrep = _memory_hooks.on_run_completed(root_path, store, run_id)
                    if _mrep.get("mode") != "off":
                        _f.emit(
                            run_id=run_id,
                            event_type="run.memory_queued",
                            severity=SEVERITY_INFO,
                            message=f"workspace memory consolidation {_mrep.get('mode')}",
                            payload={k: v for k, v in _mrep.items()
                                     if k != "dropped_at_extraction"},
                        )
                except Exception:
                    logger.debug("memory consolidation hook failed", exc_info=True)
            if run_refreshed.get("kind") == "swarm":
                from ioagentfarm.engine.forensics import find_swarm_results
                _results_path = find_swarm_results(
                    root_path / "instances" / run_id / "project")
                if _results_path is not None and _results_path.exists():
                    _doc = json.loads(_results_path.read_text(
                        encoding="utf-8-sig"))
                    for _r in (_doc.get("results") or []):
                        if not isinstance(_r, dict):
                            continue
                        _ok = bool(_r.get("ok"))
                        _f.emit(
                            run_id=run_id, event_type="swarm.child_result",
                            severity=(SEVERITY_INFO if _ok
                                      else SEVERITY_ERROR),
                            message=(f"child {_r.get('id')} "
                                     + ("ok" if _ok
                                        else f"failed: {_r.get('error')}")),
                            payload={"child": _r.get("id"), "ok": _ok,
                                     "error": _r.get("error")},
                        )
    except Exception:
        logger.debug("Failed to emit run boundary events", exc_info=True)
