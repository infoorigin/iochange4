"""Signals — read-only explorer over the hub's detected-signals register.

Read-only router over the barrier_signal hub Postgres schema (connection
from ``BARRIER_SIGNAL_DB_URL``, schema from ``BARRIER_SIGNAL_DB_SCHEMA``,
pooled by ``app/hub_db.py``). Powers the Operational Insights "Signals" page
— the middle of the story the sidebar tells: sources → signals → barriers.

  /summary                — counts by method / category / status, freshness,
                            filter definitions (distinct values for dropdowns)
  /                       — paginated signals; server-side filtering
                            (whitelisted exact-match params, AND-combined) +
                            free-text search; limit ≤ 100; each row carries
                            derived barrier_count / evidence_count
  /{signal_id}/evidence   — verbatim evidence snippets + the masked call note
                            behind each quote
  /{signal_id}/links      — upward links: barriers it supports, insights it
                            evidences, correlations it belongs to

CUTOVER. The first version read the retired ``savant_data_hub`` (v1) schema
— ``last_seen_at``, ``barrier_type_hint``, ``region`` — none of which exist in
``savant_data_hub_v2``, where a signal is ONE standardized business condition
at ONE scope carrying every source row that evidenced it (``mention_count``
counts rows; ``distinct_evidence_count`` counts genuinely different
statements). Everything below is v2-only.

NEVER writes to the hub — every statement is a parameterized SELECT; column
identifiers come from the whitelists below, never from the request. PII:
``hcp_name`` is SELECTed only to be masked to "Dr. X. Y." and renamed ``hcp``;
``content_hash`` (plumbing) is never exposed.
"""

from __future__ import annotations

import logging
import re
from contextlib import contextmanager

from fastapi import APIRouter, HTTPException, Request

from app import hub_db
from app.routers.barrier_insights import (
    CORRELATION_SELECT, EVIDENCE_SELECT, NOTE_TRACE_SELECT, TRANSCRIPT_EXCERPT,
    _json_safe, _mask_person, mask_note, mask_scope,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/signals", tags=["signals"])

MAX_LIMIT = 100
DEFAULT_LIMIT = 25
#: query-string keys that are paging/search controls, not column filters
RESERVED_PARAMS = {"limit", "offset", "search"}

#: SELECT list — explicit whitelist. ``hcp_name`` is here ONLY so the row
#: can mask it (see ``mask_row``); ``content_hash`` never is.
COLUMNS: tuple[str, ...] = (
    "signal_id", "signal_type", "signal_category", "scope", "scope_kind",
    "scope_value", "scope_parent", "observed_period", "brand",
    "account_name", "hcp_name",
    "statement", "detection_method", "rule_name", "evidence_strength",
    "mention_count", "distinct_evidence_count", "source_count",
    "corroboration", "status", "run_id", "detected_at",
)

#: filterable low-cardinality columns: column → UI label
FILTERS: dict[str, str] = {
    "signal_type": "Signal type",
    "signal_category": "Category",
    "detection_method": "Detection",
    "scope_kind": "Scope",
    "evidence_strength": "Evidence strength",
    "corroboration": "Corroboration",
    "status": "Status",
    "brand": "Brand",
    "account_name": "Account",
}

#: free-text search columns (ILIKE, OR-combined)
SEARCH_COLS: tuple[str, ...] = ("statement", "signal_id", "signal_type", "account_name")

ORDER_BY = "detected_at DESC, signal_id DESC"

_SIGNAL_ID_RE = re.compile(r"^SIG-\d{1,10}$")


@contextmanager
def _hub():
    """Read-only hub cursor — POOLED, shared with the other hub routers."""
    with hub_db.hub_cursor() as cur:
        yield cur


def _rows(cur) -> list[dict]:
    """The shared mask, not a second copy of it.

    This was `[dict(r) for r in cur.fetchall()]`, which was correct while
    `scope_value` always held an account. At prescriber grain it holds a
    person's name, and this reader would have gone on returning it verbatim
    after the sibling router was fixed.
    """
    return [mask_scope(dict(r)) for r in cur.fetchall()]


def build_signals_query(filters: dict[str, str], search: str,
                        limit: int, offset: int) -> tuple[str, str, list]:
    """(rows_sql, count_sql, params) — pure, parameterized; raises 400 on a
    filter key outside the whitelist. Count uses params minus LIMIT/OFFSET."""
    where, params = [], []
    for col, val in filters.items():
        if col not in FILTERS:
            raise HTTPException(
                status_code=400,
                detail=f"'{col}' is not filterable "
                       f"(filterable: {', '.join(FILTERS)})")
        where.append(f"{col} = %s")
        params.append(val)
    if search:
        like = " OR ".join(f"{c} ILIKE %s" for c in SEARCH_COLS)
        where.append(f"({like})")
        params.extend([f"%{search}%"] * len(SEARCH_COLS))
    where_sql = f" WHERE {' AND '.join(where)}" if where else ""
    cols = ", ".join(COLUMNS)
    rows_sql = (f"SELECT {cols} FROM signals{where_sql} "
                f"ORDER BY {ORDER_BY} LIMIT %s OFFSET %s")
    count_sql = f"SELECT COUNT(*) AS n FROM signals{where_sql}"
    return rows_sql, count_sql, params + [limit, offset]


def _signal_id_or_400(signal_id: str) -> str:
    if not _SIGNAL_ID_RE.match(signal_id):
        raise HTTPException(status_code=400,
                            detail="signal_id must look like SIG-00042")
    return signal_id


def mask_row(row: dict) -> dict:
    """A signals row for the wire: ``hcp_name`` → masked ``hcp``; Decimal /
    datetime made JSON-safe."""
    out = _json_safe(dict(row))
    out["hcp"] = _mask_person(out.pop("hcp_name", None), honorific="Dr. ")
    return out


def merge_page_derivations(rows: list[dict], barrier_counts: list[dict],
                           evidence_counts: list[dict],
                           type_polarity: list[dict] | None = None) -> list[dict]:
    """Pure: page rows ⊕ (signal_id, n) GROUP BY results ⊕ (signal_type,
    polarity) from the KB → SignalRow rows. A signal absent from a
    derivation has zero of it; a type the KB does not carry has no polarity.

    POLARITY IS THE TYPE'S, NOT THE ROW'S. The signals table has no polarity
    column - SIG-9's positive / negative / neutral lives on
    ``signal_type_meta`` - and the page rendered a dash in every row because
    nothing here joined it (the barrier drill did). One statement per page.
    """
    bc = {r["signal_id"]: int(r["n"] or 0) for r in barrier_counts}
    ec = {r["signal_id"]: int(r["n"] or 0) for r in evidence_counts}
    pol = {r["signal_type"]: r.get("polarity") for r in (type_polarity or [])}
    out = []
    for r in rows:
        row = mask_row(r)
        row["barrier_count"] = bc.get(r["signal_id"], 0)
        row["evidence_count"] = ec.get(r["signal_id"], 0)
        row["polarity"] = pol.get(r.get("signal_type"))
        out.append(row)
    return out


# ── endpoints (order matters: /summary before the catch-all pieces) ──

FILTER_VALUES_LIMIT = 80
#: the three breakdowns the page draws, as (name, column)
BREAKDOWNS: tuple[tuple[str, str], ...] = (
    ("method", "detection_method"), ("category", "signal_category"), ("status", "status"))


def summary_sql() -> tuple[str, str]:
    """(head_sql, breakdown_sql) — TWO statements for the whole summary.

    The first cut was thirteen: one per breakdown and one `SELECT DISTINCT`
    per filter column — 3.2 s against RDS from a laptop, paid by the sidebar
    on every navigation. The filter values now ride the head statement as
    correlated array subselects; the three breakdowns are one UNION ALL keyed
    by a literal tag. Column names come from the whitelists above, never
    from a request.
    """
    head = ("SELECT COUNT(*) AS n, MAX(detected_at) AS fresh" + "".join(
        f", (SELECT array_agg(v ORDER BY v) FROM (SELECT DISTINCT {col} AS v "
        f"FROM signals WHERE {col} IS NOT NULL ORDER BY 1 "
        f"LIMIT {FILTER_VALUES_LIMIT}) s) AS f_{i}"
        for i, col in enumerate(FILTERS)) + " FROM signals")
    groups = " UNION ALL ".join(
        f"SELECT '{name}' AS g, {col} AS k, COUNT(*) AS n FROM signals GROUP BY 2"
        for name, col in BREAKDOWNS)
    return head, groups


@router.get("/summary")
def summary():
    """Counts by method / category / status, freshness, and filter
    definitions with distinct values — one call powers the sidebar badge AND
    the dropdowns."""
    head_sql, groups_sql = summary_sql()
    with _hub() as cur:
        cur.execute(head_sql)
        head = cur.fetchone()
        cur.execute(groups_sql)
        rows = cur.fetchall()
    breakdown = {name: {} for name, _ in BREAKDOWNS}
    for r in sorted(rows, key=lambda r: (r["g"], str(r["k"]))):
        breakdown[r["g"]][r["k"] or "unknown"] = r["n"]
    by_method, by_category, by_status = (
        breakdown["method"], breakdown["category"], breakdown["status"])
    filter_defs = []
    for i, (col, label) in enumerate(FILTERS.items()):
        values = list(head.get(f"f_{i}") or [])
        if values:  # empty column → no useless dropdown
            filter_defs.append({"key": col, "label": label, "values": values})
    return {
        "count": head["n"],
        "by_method": by_method,
        "by_category": by_category,
        "by_status": by_status,
        "freshness": head["fresh"].isoformat() if head["fresh"] else None,
        "filters": filter_defs,
        "search_columns": list(SEARCH_COLS),
        "description": ("Standardized business conditions detected from the "
                        "ingested sources — by deterministic rules over "
                        "structured data and by AI / NLP detection over call "
                        "notes. Each signal states WHAT was observed at one "
                        "scope and carries every source row that evidenced "
                        "it; barriers explain why."),
    }


@router.get("/{signal_id}/evidence")
def evidence(signal_id: str):
    """Verbatim evidence snippets proving one signal, each with the masked
    call note it quotes (``source`` is null when the note no longer resolves)."""
    sid = _signal_id_or_400(signal_id)
    with _hub() as cur:
        cur.execute(f"SELECT {EVIDENCE_SELECT} FROM signal_evidence "
                    "WHERE signal_id = %s ORDER BY evidence_id LIMIT 20", (sid,))
        rows = _rows(cur)
        refs = sorted({r["source_ref"] for r in rows
                       if r.get("source_table") == "call_notes" and r.get("source_ref")})
        notes: dict[str, dict] = {}
        if refs:
            cur.execute(f"SELECT {NOTE_TRACE_SELECT} FROM call_notes WHERE note_id = ANY(%s)",
                        (TRANSCRIPT_EXCERPT, refs))
            notes = {n["note_id"]: mask_note(dict(n)) for n in cur.fetchall()}
    out = []
    for r in rows:
        item = _json_safe(r)
        item["source"] = notes.get(r.get("source_ref"))
        out.append(item)
    return {"signal_id": sid, "evidence": out}


@router.get("/{signal_id}/links")
def links(signal_id: str):
    """Upward links: barriers (with stance / tier), insights, correlations."""
    sid = _signal_id_or_400(signal_id)
    with _hub() as cur:
        # `b.scope_kind` and `b.scope_parent` are selected so the mask can tell
        # whether `scope_value` is a person - without the kind it cannot, and
        # a prescriber's name would ride out of here verbatim.
        cur.execute("SELECT b.barrier_id, b.barrier_type, b.barrier_category, b.statement, "
                    "b.severity, b.status, b.scope_kind, b.scope_value, "
                    "b.scope_parent, bs.stance, bs.support_tier "
                    "FROM barrier_signals bs JOIN barriers b ON b.barrier_id = bs.barrier_id "
                    "WHERE bs.signal_id = %s ORDER BY b.priority DESC NULLS LAST, b.barrier_id",
                    (sid,))
        barriers = [_json_safe(r) for r in _rows(cur)]
        cur.execute("SELECT i.insight_id, i.title, i.insight_type "
                    "FROM insight_signals isg JOIN insights i ON i.insight_id = isg.insight_id "
                    "WHERE isg.signal_id = %s ORDER BY i.insight_id", (sid,))
        insights = _rows(cur)
        cur.execute(f"SELECT cs.stance, {CORRELATION_SELECT} FROM correlation_signals cs "
                    "JOIN signal_correlations c ON c.correlation_id = cs.correlation_id "
                    "WHERE cs.signal_id = %s ORDER BY c.correlation_id", (sid,))
        correlations = [_json_safe(r) for r in _rows(cur)]
    return {"signal_id": sid, "barriers": barriers, "insights": insights,
            "correlations": correlations}


@router.get("")
def rows(request: Request, limit: int = DEFAULT_LIMIT,
         offset: int = 0, search: str = ""):
    limit = max(1, min(int(limit), MAX_LIMIT))
    offset = max(0, int(offset))
    filters = {k: v for k, v in request.query_params.items()
               if k not in RESERVED_PARAMS and v != ""}
    rows_sql, count_sql, params = build_signals_query(
        filters, search.strip(), limit, offset)
    count_params = params[:-2]  # everything except the LIMIT/OFFSET pair
    with _hub() as cur:
        cur.execute(count_sql, count_params or None)
        total = cur.fetchone()["n"]
        cur.execute(rows_sql, params)
        page = _rows(cur)
        ids = [r["signal_id"] for r in page]
        barrier_counts: list[dict] = []
        evidence_counts: list[dict] = []
        type_polarity: list[dict] = []
        if ids:
            cur.execute("SELECT signal_id, COUNT(*) AS n FROM barrier_signals "
                        "WHERE signal_id = ANY(%s) GROUP BY 1", (ids,))
            barrier_counts = _rows(cur)
            cur.execute("SELECT signal_id, COUNT(*) AS n FROM signal_evidence "
                        "WHERE signal_id = ANY(%s) GROUP BY 1", (ids,))
            evidence_counts = _rows(cur)
            types = sorted({r["signal_type"] for r in page if r.get("signal_type")})
            cur.execute("SELECT signal_type, polarity FROM signal_type_meta "
                        "WHERE signal_type = ANY(%s)", (types,))
            type_polarity = _rows(cur)
    return {"count": total, "limit": limit, "offset": offset,
            "filters_applied": filters, "search": search.strip(),
            "rows": merge_page_derivations(page, barrier_counts, evidence_counts,
                                           type_polarity)}
