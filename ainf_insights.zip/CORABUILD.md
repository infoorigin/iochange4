# CORABUILD

Standing instructions for the Ainf Insights workspace, read at the start of
every build session.

What belongs here:

- conventions this repository follows that a newcomer would not guess
- decisions already taken, with the constraint that forced each one
- anything that must not be done again, and why

What does not: transcripts, status, task lists, or anything true only today.
Keep it short enough to be read in full at the start of every session.

`aicore build` maintains this file. `/remember <note>` appends to **Notes**
below; the builder also rewrites entries here when one is superseded, rather
than leaving two that disagree.

## Notes
