"""Validate, on THIS deployment, the fixes raised in client feedback.

Run it against a serving engine. Every check is a question the client
team asked, answered by the deployment itself rather than by a document.

    python setup_ainf/validate_fixes.py --engine http://127.0.0.1:8111

Because each check exercises a route or a boundary that changed, a clean
run is also an indirect regression test of the whole set of fixes: the
conversation tables exist (schema-ensure fix), the streaming routes are
mounted, threads are per-person (session-key fix), impersonation is
refused on both chat surfaces, and the agent answers across runs.

Checks that need a verified identity (the RBAC set) are SKIPPED with an
explanation when the engine runs without authentication - they cannot be
answered honestly on an anonymous engine, and pretending otherwise is
the failure mode this exercise exists to avoid.

Exit code 0 when nothing failed, 1 otherwise. Skips do not fail the run.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.error
import urllib.request

PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"
_results: list[tuple[str, str, str]] = []


def record(status: str, ref: str, label: str, detail: str = "") -> None:
    _results.append((status, ref, label))
    line = f"{status:4}  {ref:4} {label}"
    print(line if not detail else f"{line}\n        {detail}")


class Engine:
    def __init__(self, base: str, token: str = ""):
        self.base = base.rstrip("/")
        self.token = token

    def call(self, method, path, actor=None, body=None, timeout=600):
        req = urllib.request.Request(self.base + path, method=method)
        req.add_header("Content-Type", "application/json")
        if self.token:
            req.add_header("Authorization", "Bearer " + self.token)
        if actor:
            req.add_header("X-IOF-Actor", actor)
        data = json.dumps(body).encode() if body is not None else None
        try:
            with urllib.request.urlopen(req, data, timeout=timeout) as r:
                raw = r.read().decode()
                return r.status, (json.loads(raw) if raw.strip() else {})
        except urllib.error.HTTPError as e:
            try:
                return e.code, json.loads(e.read().decode() or "{}")
            except Exception:
                return e.code, {}
        except Exception as exc:                       # noqa: BLE001
            return 0, {"detail": str(exc)}


def _text(payload) -> str:
    """The reply text, whichever surface produced it."""
    if not isinstance(payload, dict):
        return ""
    c = payload.get("content")
    if isinstance(c, str):
        return c
    if isinstance(c, list) and c and isinstance(c[0], dict):
        return c[0].get("text", "") or ""
    return ""


def preflight(eng: Engine) -> dict:
    s, _ = eng.call("GET", "/health", timeout=30)
    if s != 200:
        record(FAIL, "P1", "engine reachable", f"GET /health -> {s}")
        print("\nNothing else can run. Start the service first.")
        sys.exit(1)
    record(PASS, "P1", "engine reachable")

    s, who = eng.call("GET", "/api/whoami", timeout=30)
    auth_on = (s == 401) or bool((who or {}).get("authenticated"))
    record(PASS, "P2", f"authentication is {'ON' if auth_on else 'OFF'} "
                       f"(/api/whoami -> {s})")

    s, spec = eng.call("GET", "/openapi.json", timeout=60)
    paths = set((spec or {}).get("paths", {}))
    if s != 200:
        record(SKIP, "P3", "route inventory unavailable "
                           f"(/openapi.json -> {s}; pass --token)")
    else:
        need = {
            "/v1/conversations": "durable conversation threads",
            "/api/run/{run_id}/message/stream": "run chat streaming",
            "/api/chat/{ns}/stream": "ad-hoc chat streaming",
        }
        for p, what in need.items():
            ok = p in paths
            record(PASS if ok else FAIL, "P3", f"build serves {what}",
                   "" if ok else f"{p} absent - this build predates the fix")
    return {"auth_on": auth_on, "paths": paths}


def conversations(eng: Engine, agent: str, actor) -> None:
    """F3/F4 - where chats live, and how a returning user reattaches."""
    # Under principal binding the caller IS the actor, and asserting a
    # different user_id is refused - correctly. So the validator sends its
    # own identity rather than a label of its own choosing.
    who = actor or "validation@client"
    s, conv = eng.call("POST", "/v1/conversations", actor,
                       {"agent": agent, "title": "Client validation",
                        "user_id": who})
    if s != 200:
        record(FAIL, "F3", "open a durable thread",
               f"POST /v1/conversations -> {s}: {str(conv)[:200]}")
        return
    cid = conv.get("id", "")
    record(PASS, "F3", f"open a durable thread ({cid[:20]}...)")

    s, ans = eng.call("POST", f"/v1/conversations/{cid}/responses", actor,
                      {"user_id": who,
                       "input": "Reply with exactly: VALIDATION-OK"})
    t1 = _text(ans)
    record(PASS if s == 200 and t1 else FAIL, "F3", "the thread answers",
           "" if t1 else f"-> {s}: {str(ans)[:200]}")

    s, lst = eng.call("GET", f"/v1/conversations?user_id={who}", actor)
    found = any(c.get("id") == cid for c in (lst or {}).get("data", []))
    record(PASS if found else FAIL, "F4",
           "the user's own threads are listable")

    s, items = eng.call("GET",
                        f"/v1/conversations/{cid}/items?user_id={who}", actor)
    n = len((items or {}).get("data", []))
    record(PASS if n >= 2 else FAIL, "F3",
           f"history re-renders from the server ({n} items)")

    s, again = eng.call("POST", f"/v1/conversations/{cid}/responses", actor,
                        {"user_id": who,
                         "input": "What did I ask you first in this thread?"})
    t2 = _text(again)
    ok = "VALIDATION-OK" in t2
    record(PASS if ok else FAIL, "F3",
           "a returning user resumes with context",
           "" if ok else f"reply: {t2[:140]}")


def cross_run(eng: Engine, agent: str, actor) -> None:
    """F5 - one question spanning every persisted run."""
    s, ans = eng.call("POST", f"/api/chat/{agent}", actor,
                      {"agent": agent, "user_id": actor or "validation@client",
                       "conversation_id": "validation-crossrun",
                       "content": "List every persisted run id in this "
                                  "workspace with its generated date. "
                                  "Ids only, one per line."})
    text = _text(ans)
    ids = set(re.findall(r"run_\d{8}_\d{6}_\d+", text))
    ok = s == 200 and len(ids) >= 2
    record(PASS if ok else FAIL, "F5",
           f"one answer spans multiple runs ({len(ids)} run ids cited)",
           "" if ok else f"-> {s}: {text[:200]}")


def rbac(eng: Engine, agent: str, run_id) -> None:
    """F6 plus hardening H5/H7 - the boundaries between two people."""
    A, B = "alice@validation", "bruno@validation"
    thread = "validation-shared-name"

    s, _ = eng.call("POST", f"/api/chat/{agent}", B,
                    {"agent": agent, "user_id": A,
                     "conversation_id": "validation-imp", "content": "hello"})
    record(PASS if s == 403 else FAIL, "F6",
           "asserting another person's user_id is refused (chat)",
           "" if s == 403 else f"-> {s}, expected 403. Is "
                               "IOF_CHAT_BIND_PRINCIPAL=1 set?")

    s, _ = eng.call("GET", f"/api/chat/{agent}/messages?user_id={A}", B)
    record(PASS if s == 403 else FAIL, "F6",
           "reading another person's history by name is refused",
           "" if s == 403 else f"-> {s}, expected 403")

    eng.call("POST", f"/api/chat/{agent}", A,
             {"agent": agent, "conversation_id": thread,
              "content": "Remember this token: ALICE-TOKEN-9. Reply OK."})
    s, b2 = eng.call("POST", f"/api/chat/{agent}", B,
                     {"agent": agent, "conversation_id": thread,
                      "content": "What token were you just asked to remember? "
                                 "If none, say NOTHING-YET."})
    leaked = "ALICE-TOKEN-9" in _text(b2)
    record(FAIL if leaked else PASS, "H5",
           "one thread NAME is not one shared session",
           "LEAK: another person's session was resumed" if leaked else "")

    if not run_id:
        record(SKIP, "H7", "run-surface checks (pass --run-id <id>)")
        return
    s, _ = eng.call("POST", f"/api/run/{run_id}/message", B,
                    {"role": agent, "user_id": A,
                     "conversation_id": "validation-run-imp",
                     "content": "hello"})
    record(PASS if s == 403 else FAIL, "H7",
           "run conversations refuse impersonation",
           "" if s == 403 else f"-> {s}, expected 403")

    s, _ = eng.call("POST", f"/api/run/{run_id}/message", B,
                    {"role": agent, "conversation_id": "validation-run-own",
                     "content": "In one line: what was this run about?"})
    record(PASS if s == 200 else FAIL, "H7",
           "the run itself stays team-visible (as yourself)",
           "" if s == 200 else f"-> {s}, expected 200")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--engine", default="http://127.0.0.1:8111")
    ap.add_argument("--agent", default="insights_meta",
                    help="the always-on agent to talk to")
    ap.add_argument("--token", default="",
                    help="bearer token (required when the engine is guarded)")
    ap.add_argument("--run-id", default="",
                    help="a persisted run id, for the run-surface checks")
    ap.add_argument("--skip-rbac", action="store_true")
    args = ap.parse_args()

    eng = Engine(args.engine, args.token)
    print(f"validating {eng.base}\n")
    info = preflight(eng)
    print()

    actor = "alice@validation" if info["auth_on"] else None
    conversations(eng, args.agent, actor)
    print()
    cross_run(eng, args.agent, actor)
    print()

    if args.skip_rbac:
        record(SKIP, "F6", "RBAC checks (--skip-rbac)")
    elif not info["auth_on"]:
        record(SKIP, "F6", "RBAC checks need a verified identity",
               "Start the engine with IOF_ENGINE_AUTH=oidc (or apikey) and "
               "IOF_CHAT_BIND_PRINCIPAL=1, then re-run with --token. On an "
               "anonymous engine every caller resolves to one identity, so "
               "these questions have no honest answer.")
    else:
        rbac(eng, args.agent, args.run_id or None)

    print("\n" + "-" * 68)
    n_fail = sum(1 for s, _, _ in _results if s == FAIL)
    n_skip = sum(1 for s, _, _ in _results if s == SKIP)
    n_pass = sum(1 for s, _, _ in _results if s == PASS)
    print(f"{n_pass} passed, {n_fail} failed, {n_skip} skipped")
    if n_fail:
        print("\nfailed:")
        for s, ref, label in _results:
            if s == FAIL:
                print(f"  {ref}  {label}")
    return 1 if n_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
