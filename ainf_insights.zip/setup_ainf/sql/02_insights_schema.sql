-- The INSIGHTS store — persisted, run-linked, NLQ-queryable output of the
-- brand_insights pipeline. Written ONLY by iof-ainf_insights-insights-store
-- (a validating tool); agents never INSERT here directly.
--
-- DESIGN (full rationale: docs/insights-data-model.md)
--
--   insight_runs      1 ── * insights          1 ── * insight_evidence
--                              │ (self-FK: a driver/action/comparison row
--                              │  nests under its opportunity, exactly as
--                              │  the workbench nests cards)
--                              └─────── * insight_accounts
--
-- HYBRID relational + JSONB, on purpose. The columns are the QUERYABLE
-- SPINE - what a freehand NLQ actually filters and ranks on (brand, kind,
-- confidence, rank, headline, run) - so those never hide inside JSON. The
-- `payload` keeps FULL rendering fidelity so the dashboard can rebuild a
-- card without a second source, and so new card fields ship without DDL.
--
-- Everything is IF NOT EXISTS and the loader NEVER drops these: they hold
-- run history. Re-persisting a run is transactional replace-by-run_id
-- (the tool deletes the run's rows and re-inserts; FKs cascade).

CREATE SCHEMA IF NOT EXISTS ainf_data;

CREATE TABLE IF NOT EXISTS ainf_data.insight_runs (
    run_id       text PRIMARY KEY,           -- the platform run id: the dig-deeper anchor
    workflow     text NOT NULL,
    brand        text NOT NULL,               -- runtime brand from the goal (e.g. DARZALEX)
    goal         text NOT NULL,
    period_start date,
    period_end   date,
    latest_month date,
    diagnosis    text,                        -- lost_share | lost_volume | ...
    status       text NOT NULL DEFAULT 'published',
    generated_at timestamptz NOT NULL DEFAULT now(),
    payload      jsonb NOT NULL               -- the reviewed dashboard_insights.json, verbatim
);
CREATE INDEX IF NOT EXISTS idx_iruns_brand ON ainf_data.insight_runs (brand, generated_at DESC);

CREATE TABLE IF NOT EXISTS ainf_data.insights (
    insight_id        bigserial PRIMARY KEY,
    run_id            text NOT NULL REFERENCES ainf_data.insight_runs(run_id) ON DELETE CASCADE,
    brand             text NOT NULL,          -- denormalized from the run: the #1 NLQ filter
    kind              text NOT NULL CHECK (kind IN
                        ('kpi','opportunity','driver','comparison',
                         'priority_account_set','action','not_recommended','diagnosis')),
    parent_insight_id bigint REFERENCES ainf_data.insights(insight_id) ON DELETE CASCADE,
    rank              integer,                -- order within the parent (driver 1..n, action 1..n)
    ref               text,                   -- stable in-payload id (e.g. 'opp-1', 'market_share')
    headline          text NOT NULL,          -- the card's one-line claim: what NLQ searches
    confidence_pct    numeric(5,1),
    verdict           text,                   -- likely_cause | not_a_cause | needs_attention | on_track | over_pacing ...
    payload           jsonb NOT NULL,         -- the card, verbatim (trend arrays, summaries, deltas)
    created_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_insights_run    ON ainf_data.insights (run_id);
CREATE INDEX IF NOT EXISTS idx_insights_brand  ON ainf_data.insights (brand, kind);
CREATE INDEX IF NOT EXISTS idx_insights_conf   ON ainf_data.insights (kind, confidence_pct DESC);
CREATE INDEX IF NOT EXISTS idx_insights_parent ON ainf_data.insights (parent_insight_id);

CREATE TABLE IF NOT EXISTS ainf_data.insight_evidence (
    evidence_id   bigserial PRIMARY KEY,
    insight_id    bigint NOT NULL REFERENCES ainf_data.insights(insight_id) ON DELETE CASCADE,
    source        text NOT NULL,              -- entity, 'creative_intel MCP', 'computed_metrics:<id>'
    finding       text NOT NULL,
    query_sql     text,                       -- the exact SQL when the source is a table/metric
    n             integer,                    -- 'N of M' numerator, when the finding counts
    of_total      integer
);
CREATE INDEX IF NOT EXISTS idx_evidence_insight ON ainf_data.insight_evidence (insight_id);

CREATE TABLE IF NOT EXISTS ainf_data.insight_accounts (
    insight_id       bigint NOT NULL REFERENCES ainf_data.insights(insight_id) ON DELETE CASCADE,
    account_id       text,
    account_name     text NOT NULL,
    rank             integer,
    score            numeric(6,1),
    share_change_pts numeric(6,2),
    signals          jsonb,                   -- ["campaign_exposure","prescribing_shift",...]
    PRIMARY KEY (insight_id, account_name)
);

-- ── THE COMPUTED-METRICS TIER (added with the comprehensive model) ────
-- Every run's configured metrics persist as ROWS, not only as the
-- computed_metrics.json artifact: scalar values in run_metrics, series
-- (chart data) in run_metric_points, and each hypothesis's verdict in
-- run_hypotheses. Written by the SAME store tool, in the SAME transaction
-- as the insights - so "persisted" always means "the whole run, reviewed".
-- This is what makes every dashboard chart SQL-renderable and every metric
-- a cross-run time series ("how has the share gap moved run over run?").

CREATE TABLE IF NOT EXISTS ainf_data.run_metrics (
    run_id      text NOT NULL REFERENCES ainf_data.insight_runs(run_id) ON DELETE CASCADE,
    metric_id   text NOT NULL,               -- rules.yaml id (share_latest, region_gap, ...)
    title       text NOT NULL,
    unit        text,
    shape       text NOT NULL,               -- 'row' (scalar record) | 'rows' (series)
    value       jsonb,                       -- the scalar record, verbatim (NULL for series)
    query_sql   text NOT NULL,               -- the exact SQL that produced it
    row_count   integer,
    rules_version text,
    computed_at timestamptz,
    PRIMARY KEY (run_id, metric_id)
);
CREATE INDEX IF NOT EXISTS idx_rmetrics_metric ON ainf_data.run_metrics (metric_id, run_id);

CREATE TABLE IF NOT EXISTS ainf_data.run_metric_points (
    run_id       text NOT NULL,
    metric_id    text NOT NULL,
    ord          integer NOT NULL,           -- series order, as computed
    -- PROMOTED DIMENSIONS: the four axes this domain actually filters on,
    -- lifted out of jsonb so series SQL stays plain. A metric populates
    -- whichever apply; anything else stays in dims.
    month        date,
    region       text,
    account_name text,
    segment      text,
    dims         jsonb,                      -- any further dimensions, verbatim
    vals         jsonb NOT NULL,             -- the measures of this point, verbatim
    PRIMARY KEY (run_id, metric_id, ord),
    FOREIGN KEY (run_id, metric_id)
        REFERENCES ainf_data.run_metrics(run_id, metric_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_rpoints_month   ON ainf_data.run_metric_points (metric_id, month);
CREATE INDEX IF NOT EXISTS idx_rpoints_region  ON ainf_data.run_metric_points (metric_id, region);
CREATE INDEX IF NOT EXISTS idx_rpoints_account ON ainf_data.run_metric_points (metric_id, account_name);

CREATE TABLE IF NOT EXISTS ainf_data.run_hypotheses (
    run_id           text NOT NULL REFERENCES ainf_data.insight_runs(run_id) ON DELETE CASCADE,
    hypothesis_id    text NOT NULL,          -- rules.yaml id (H1_..., H5_...)
    driver           text NOT NULL,
    armed            boolean,                -- NULL = external evaluation / errored
    evaluate         text NOT NULL DEFAULT 'sql',   -- 'sql' | 'external'
    source           text,                   -- the external source, when evaluate='external'
    arm_when_sql     text,
    evidence_metrics jsonb,
    confidence_basis text,
    PRIMARY KEY (run_id, hypothesis_id)
);
CREATE INDEX IF NOT EXISTS idx_rhypo_id ON ainf_data.run_hypotheses (hypothesis_id, run_id);
