-- ainf_data — the source-data schema for the ainf_insights workspace.
-- Executed by demo/load_to_db.py; hand this file to a DBA where the app
-- user has no CREATE rights. SOURCE tables are dropped and reloaded by the
-- loader; the INSIGHTS tables live in sql/insights_schema.sql and are NEVER
-- dropped (they hold run history).
--
-- creative_performance_monthly is deliberately ABSENT: that dataset is
-- served by the creative_intel MCP server, to demonstrate multi-source
-- analysis (database + MCP) in one run.

CREATE SCHEMA IF NOT EXISTS ainf_data;

DROP TABLE IF EXISTS ainf_data.brand_performance_monthly;
CREATE TABLE ainf_data.brand_performance_monthly (
    month                 date        NOT NULL,
    region                text        NOT NULL,
    brand_trx             bigint      NOT NULL,
    market_trx            bigint      NOT NULL,
    plan_share_pct        numeric(6,2) NOT NULL,
    prior_year_share_pct  numeric(6,2) NOT NULL,
    plan_brand_trx        bigint      NOT NULL,
    PRIMARY KEY (month, region)
);

DROP TABLE IF EXISTS ainf_data.account_performance_monthly;
CREATE TABLE ainf_data.account_performance_monthly (
    month        date   NOT NULL,
    account_id   text   NOT NULL,
    account_name text   NOT NULL,
    metro        text   NOT NULL,
    region       text   NOT NULL,
    brand_trx    bigint NOT NULL,
    market_trx   bigint NOT NULL,
    PRIMARY KEY (month, account_id)
);
CREATE INDEX idx_acct_perf_account ON ainf_data.account_performance_monthly (account_id, month);
CREATE INDEX idx_acct_perf_metro   ON ainf_data.account_performance_monthly (metro);

DROP TABLE IF EXISTS ainf_data.competitor_activity_monthly;
CREATE TABLE ainf_data.competitor_activity_monthly (
    month                         date    NOT NULL,
    account_id                    text    NOT NULL,
    competitor_sov_pct            numeric(6,2) NOT NULL,
    exposed_earlier_line_campaign smallint NOT NULL,
    competitor_field_calls        integer NOT NULL,
    competitor_speaker_programs   integer NOT NULL,
    our_field_calls               integer NOT NULL,
    PRIMARY KEY (month, account_id)
);

DROP TABLE IF EXISTS ainf_data.new_patient_starts_monthly;
CREATE TABLE ainf_data.new_patient_starts_monthly (
    month             date    NOT NULL,
    account_id        text    NOT NULL,
    segment           text    NOT NULL,
    brand_starts      integer NOT NULL,
    competitor_starts integer NOT NULL,
    PRIMARY KEY (month, account_id, segment)
);

DROP TABLE IF EXISTS ainf_data.field_notes;
CREATE TABLE ainf_data.field_notes (
    note_id                   text NOT NULL PRIMARY KEY,
    note_date                 date NOT NULL,
    account_id                text NOT NULL,
    hcp_specialty             text NOT NULL,
    prescriber_line_focus     text NOT NULL,
    note_text                 text NOT NULL,
    treatment_choice_question smallint NOT NULL,
    competitor_claim_mention  smallint NOT NULL
);
CREATE INDEX idx_notes_account ON ainf_data.field_notes (account_id);
CREATE INDEX idx_notes_flags   ON ainf_data.field_notes (treatment_choice_question, competitor_claim_mention);

DROP TABLE IF EXISTS ainf_data.promo_spend_monthly;
CREATE TABLE ainf_data.promo_spend_monthly (
    month     date   NOT NULL,
    channel   text   NOT NULL,
    spend_usd bigint NOT NULL,
    plan_usd  bigint NOT NULL,
    PRIMARY KEY (month, channel)
);
