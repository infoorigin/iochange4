# Validating the client-raised fixes — a manual walkthrough

For a colleague to run **on the client environment**, against the
`ainf_insights` workspace and its `ainf_data` schema. Every step is a
question the client team asked, answered by their own deployment rather
than by a document.

Nine questions were raised. This walkthrough validates the seven that can
be shown on a running system (the two design questions — deployment shape
and why-this-structure — are answered by
[deployment-topology.md](../docs/deployment-topology.md) and
[bring-your-own-code.md](../docs/bring-your-own-code.md)).

**It is also an indirect regression test of the whole batch.** Each step
exercises a route or a boundary that changed, so a clean walkthrough
means the conversation tables exist, the streaming routes are mounted,
threads are per-person, impersonation is refused on both chat surfaces,
and the agent reasons across runs.

Every command below was rehearsed end to end before this guide was
written; the "you should see" lines are real observed output.

---

## 0 · Before you start

| You need | How to check |
|---|---|
| The engine build carrying these fixes | Step 1.2 checks by capability, not by version number |
| `ai-core-harness-engine` + `ai-core-harness-skills` installed | `pip show ai-core-harness-engine ai-core-harness-skills` |
| The `ainf_insights` workspace with its `.env` | `aicore current` names the workspace and its database |
| `ainf_data` loaded, with at least two completed runs | Step 1.3 |
| The engine serving | `aicore serve --workspace ainf_insights --host 127.0.0.1 --port 8111` |

Set once, for every command below:

```bash
export ENGINE=http://127.0.0.1:8111       # the client's engine address
export AGENT=insights_meta                # Pulse
```

> **If the engine is guarded** (the production posture, and required for
> section 5), every `curl` below also needs
> `-H "Authorization: Bearer $TOKEN"`. The examples in sections 1-4 omit
> it for readability; section 5 shows it in full. A `401` on any step
> means exactly this header is missing.

> **On the client environment the distributions are republished**:
> `ai-core-harness-engine` and `ai-core-harness-skills` rather than the
> upstream names. The CLI is still `aicore`, and everything below is
> unaffected — only `pip show` and the run header's `content:` line name
> the distributions.

---

## 1 · Preflight — is this the right build, on the right data?

### 1.1 The engine answers

```bash
curl -s -o /dev/null -w "%{http_code}\n" $ENGINE/health
```

**You should see** `200`. Anything else: the service is not running, and
nothing below can be validated.

### 1.2 The build carries the fixes (capability, not version)

```bash
curl -s $ENGINE/openapi.json | python -c "import json,sys; p=set(json.load(sys.stdin)['paths']); [print(('YES' if r in p else 'NO '), r) for r in ['/v1/conversations','/api/run/{run_id}/message/stream','/api/chat/{ns}/stream']]"
```

**You should see** `YES` on all three. A `NO` means the deployment is
running an older `ai-core-harness-engine` wheel — upgrade before
continuing, or the results below are about the wrong build.

*(If the engine is guarded, add `-H "Authorization: Bearer $TOKEN"`.)*

### 1.3 The platform schema is complete, and the data is there

```bash
aicore init                     # idempotent; ensures every platform table
aicore status | head -20        # runs in this workspace
```

**You should see** `init` naming the client's database and reporting the
platform table count, and `status` listing completed runs. `init` is the
step that provisions the conversation tables — on a schema created before
this fix they were missing, and the chat surface answered
`UndefinedTable`.

Confirm the data plane too:

```bash
python setup_ainf/setup_db.py --verify
```

**You should see** `ALL CHECKS PASSED` and a line reporting how many
`insight_runs` rows it left alone.

---

## 2 · Where chats are stored, and how a returning user reattaches

*Client questions 3 and 4.*

### 2.1 Open a named thread

```bash
CID=$(curl -s -X POST $ENGINE/v1/conversations -H "Content-Type: application/json" \
  -d '{"agent":"insights_meta","user_id":"colleague@client","title":"August review"}' \
  | python -c "import json,sys; print(json.load(sys.stdin)['id'])")
echo $CID
```

**You should see** an id like `conv_55109c5211334e4…`.

### 2.2 Ask something real

```bash
curl -s -X POST $ENGINE/v1/conversations/$CID/responses -H "Content-Type: application/json" \
  -d '{"user_id":"colleague@client","input":"What is the DARZALEX share gap vs plan in the latest run?"}' \
  | python -c "import json,sys; print(json.load(sys.stdin)['content'][0]['text'][:200])"
```

**You should see** a grounded answer citing the gap (on the reference
data: 18.3% actual vs 19.2% plan, −0.9 pts) and the run it came from.

### 2.3 Walk away, come back — list your threads

```bash
curl -s "$ENGINE/v1/conversations?user_id=colleague@client" \
  | python -c "import json,sys; [print(c['id'][:24], '|', c.get('x_title',''), '|', c.get('x_agent','')) for c in json.load(sys.stdin)['data'][:5]]"
```

**You should see** the thread from 2.1 with its title and agent, most
recent first. *This is the answer to "can we ask the harness for a
user's conversations".* (`x_title` and `x_agent` carry the `x_` prefix
deliberately: the wire shape follows the OpenAI conversations standard,
and our additions are prefixed so a stock client ignores them.)

### 2.4 Re-render the history

```bash
curl -s "$ENGINE/v1/conversations/$CID/items?user_id=colleague@client" \
  | python -c "import json,sys; [print(i['role'],'|',i['content'][0]['text'][:70]) for i in json.load(sys.stdin)['data']]"
```

**You should see** the user question and the assistant answer in order —
served from the database, so any instance can render it and a browser
close loses nothing.

### 2.5 Resume with context

```bash
curl -s -X POST $ENGINE/v1/conversations/$CID/responses -H "Content-Type: application/json" \
  -d '{"user_id":"colleague@client","input":"What did I ask you first in this thread?"}' \
  | python -c "import json,sys; print(json.load(sys.stdin)['content'][0]['text'][:200])"
```

**You should see** the agent recount the 2.2 question. Continuity is
server-side; the client stored nothing but `$CID`.

---

## 3 · Conversing across runs

*Client question 5.*

```bash
curl -s -X POST $ENGINE/api/chat/$AGENT -H "Content-Type: application/json" \
  -d '{"agent":"insights_meta","user_id":"colleague@client","conversation_id":"crossrun",
       "content":"List every persisted run in this workspace with its date and its share gap. Then say whether the gap or the top driver changed run over run."}' \
  | python -c "import json,sys; print(json.load(sys.stdin)['content'][:1200])"
```

**You should see** a table of every run in `ainf_data.insight_runs` —
ids, dates, per-run gap, per-run top driver — in one answer. On the
reference deployment this returned all ten runs. *That is "converse over
all run history": the runs are rows, so the question is a query.*

---

## 4 · What memory stores, and who put it there

*Client questions 7 and 8.*

```bash
aicore memory status
aicore memory pending | head -20
```

**You should see** `posture=review`, a count of **draft** rows and
**0 active** — nothing has entered any agent's context. On the reference
deployment: 145 drafts after ten runs, zero active.

Inspect and decide on one:

```bash
aicore memory show <id>          # the candidate, its scope, its origin run
aicore memory reject <id>        # refuse it, on the record
aicore memory history | head     # the audit trail: who decided what, when
```

**What this proves for "name and address yes, account balance no":**
nothing is stored-and-visible without a person approving it, every
candidate names the run or chat that produced it, and every decision is
recorded. Deterministic rails already drop session figures and redact
PII before a candidate is ever queued. Full detail:
[memory-governance.md](../docs/memory-governance.md).

---

## 5 · RBAC on history — two people, one engine

*Client question 7 (the leak question). **This section needs
authentication on**; on an anonymous engine every caller resolves to one
identity, so these questions have no honest answer.*

Start the engine with the client's IdP and the binding flag:

```bash
export IOF_ENGINE_AUTH=oidc
export IOF_ENGINE_OIDC_ISSUER=<the client IdP issuer>
export IOF_ENGINE_OIDC_AUDIENCE=<the engine's audience>
export IOF_CHAT_BIND_PRINCIPAL=1
aicore serve --workspace ainf_insights --host 127.0.0.1 --port 8111
```

Get a token from the IdP, then set two identities — the header names the
person a service is acting for:

```bash
export TOKEN=<bearer token>
A='-H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: alice@client"'
B='-H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: bruno@client"'
```

### 5.1 One person cannot speak as another

```bash
curl -s -o /dev/null -w "%{http_code}\n" -X POST $ENGINE/api/chat/$AGENT \
  -H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: bruno@client" \
  -H "Content-Type: application/json" \
  -d '{"agent":"insights_meta","user_id":"alice@client","content":"hello"}'
```

**You should see** `403` — Bruno asserting Alice's `user_id` is refused
before any model call.

### 5.2 One person cannot read another's history

```bash
curl -s -o /dev/null -w "%{http_code}\n" \
  "$ENGINE/api/chat/$AGENT/messages?user_id=alice@client" \
  -H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: bruno@client"
```

**You should see** `403`. Without the actor header (his own history) he
gets `200` and only his own rows.

### 5.3 One thread NAME is not one shared session

Alice tells the agent something in an ordinarily-named thread:

```bash
curl -s -X POST $ENGINE/api/chat/$AGENT \
  -H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: alice@client" \
  -H "Content-Type: application/json" \
  -d '{"agent":"insights_meta","conversation_id":"q3-review",
       "content":"Remember this token: ALICE-TOKEN-9. Reply OK."}' > /dev/null
```

Bruno names the **same** thread:

```bash
curl -s -X POST $ENGINE/api/chat/$AGENT \
  -H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: bruno@client" \
  -H "Content-Type: application/json" \
  -d '{"agent":"insights_meta","conversation_id":"q3-review",
       "content":"What token were you just asked to remember? If none, say NOTHING-YET."}' \
  | python -c "import json,sys; print(json.load(sys.stdin)['content'][:160])"
```

**You should see** `NOTHING-YET` — a fresh session. **If you see
`ALICE-TOKEN-9`, stop: the deployment predates this fix** (it was found
and closed on 2026-09-01; before it, two people who chose the same
ordinary thread name shared one agent memory).

### 5.4 The same rule on the run surface

```bash
RUN=$(aicore status --json | python -c "import json,sys; print(json.load(sys.stdin)['run_id'])")

# Bruno asserting Alice on a run conversation
curl -s -o /dev/null -w "%{http_code}\n" -X POST $ENGINE/api/run/$RUN/message \
  -H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: bruno@client" \
  -H "Content-Type: application/json" \
  -d '{"role":"insights_meta","user_id":"alice@client","content":"hello"}'

# Bruno asking about the same run AS HIMSELF
curl -s -o /dev/null -w "%{http_code}\n" -X POST $ENGINE/api/run/$RUN/message \
  -H "Authorization: Bearer $TOKEN" -H "X-IOF-Actor: bruno@client" \
  -H "Content-Type: application/json" \
  -d '{"role":"insights_meta","content":"In one line: what was this run about?"}'
```

**You should see** `403` then `200`. Impersonation is refused; the run
itself stays team-visible, which is the documented model — see
[security-posture.md](../docs/security-posture.md) for what is
deliberately shared and what is not.

---

## 6 · Everything at once (optional)

The same checks as an automated pass, useful for a re-run after any
upgrade:

```bash
# anonymous engine: RBAC section is skipped, with an explanation
python setup_ainf/validate_fixes.py --engine $ENGINE --run-id <run_id>

# guarded engine: the full set
python setup_ainf/validate_fixes.py --engine $ENGINE --token $TOKEN --run-id <run_id>
```

Reference results from the rehearsal: **11 passed / 1 skipped**
unauthenticated, **16 passed / 0 failed** with authentication on.

---

## 7 · Record the outcome

| # | Client question | Step | Result |
|---|---|---|---|
| 1 | Deployment shape, where we write code | doc | ☐ |
| 2 | Why this structure with existing code | doc | ☐ |
| 3 | Where chats are stored; returning user | 2.1–2.5 | ☐ |
| 4 | Ask the harness for a user's conversations | 2.3 | ☐ |
| 5 | Converse across all run history | 3 | ☐ |
| 6 | RBAC on history | 5.1–5.4 | ☐ |
| 7 | Control what memory stores | 4 | ☐ |
| 8 | Who writes memory, where stored | 4 | ☐ |

**If a step fails**, capture: the command, the HTTP status, and
`pip show ai-core-harness-engine` — the most common cause is a
deployment running a wheel from before the fix, which step 1.2 is
designed to catch first.
