"""Idempotent database setup for the ainf_insights workspace.

Applies, in order, each file as ONE statement batch in ONE transaction:

  sql/01_source_schema.sql    schema + the six SOURCE tables (replace
                              semantics: DROP + CREATE, safe to re-run)
  sql/02_insights_schema.sql  insights + computed-metrics tables
                              (IF NOT EXISTS ONLY - run history is never
                              dropped, by this script or any other)
  sql/03_source_data.sql      generated source rows (TRUNCATE + INSERT in
                              one transaction - replace semantics)

Every part converges on the same state however many times it runs; the
only rows that survive independently are the insight/metric tables' run
history, which is exactly the intent. ``--verify`` (alone, or after
setup) checks row counts against the generated file's manifest, the
generator's pinned headline aggregates, and the presence of every
insights-tier table - and prints the run-history count it left alone.

Connection: --db-url > AINF_DB_URL env > AINF_DB_URL in
~/.iobot/workspaces/ainf_insights/.env (read from the file, never sourced
through a shell - the password may contain `$`).
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent
SQL = KIT / "sql"
ENV_FILE = Path.home() / ".iobot" / "workspaces" / "ainf_insights" / ".env"

INSIGHT_TABLES = ("insight_runs", "insights", "insight_evidence",
                  "insight_accounts", "run_metrics", "run_metric_points",
                  "run_hypotheses")


def _db_url(arg: str | None) -> str:
    if arg:
        return arg
    if os.environ.get("AINF_DB_URL"):
        return os.environ["AINF_DB_URL"]
    if ENV_FILE.is_file():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            if line.startswith("AINF_DB_URL="):
                return line.split("=", 1)[1].strip()
    sys.exit("no connection: pass --db-url, set AINF_DB_URL, or put it in "
             f"{ENV_FILE}")


def _expected_counts() -> dict[str, int]:
    """The generated data file carries its own manifest (-- rows: t=N)."""
    text = (SQL / "03_source_data.sql").read_text(encoding="utf-8")
    return {m.group(1): int(m.group(2))
            for m in re.finditer(r"^-- rows: (\w+)=(\d+)$", text, re.M)}


def verify(cur) -> int:
    fails = 0

    def check(label, sql, want, tol=0.0):
        nonlocal fails
        cur.execute(sql)
        got = cur.fetchone()[0]
        ok = (abs(float(got) - want) <= tol) if tol else (got == want)
        print(f"{'PASS' if ok else 'FAIL'}  {label:46s} -> {got}")
        fails += 0 if ok else 1

    for table, want in _expected_counts().items():
        check(f"count {table}",
              f"SELECT count(*) FROM ainf_data.{table}", want)
    check("national share Aug = 18.26",
          "SELECT round(100.0*SUM(brand_trx)/SUM(market_trx), 2) "
          "FROM ainf_data.brand_performance_monthly "
          "WHERE month='2026-08-01'", 18.26, tol=0.02)
    check("spend YTD = 126,000,000",
          "SELECT SUM(spend_usd) FROM ainf_data.promo_spend_monthly",
          126_000_000)
    check("creative stays OUT of the database (MCP-served)",
          "SELECT count(*) FROM information_schema.tables WHERE "
          "table_schema='ainf_data' AND "
          "table_name='creative_performance_monthly'", 0)
    check("insights-tier tables present (incl. metrics tier)",
          "SELECT count(*) FROM information_schema.tables WHERE "
          "table_schema='ainf_data' AND table_name IN "
          + "(" + ",".join(f"'{t}'" for t in INSIGHT_TABLES) + ")",
          len(INSIGHT_TABLES))
    cur.execute("SELECT count(*) FROM ainf_data.insight_runs")
    print(f"info  run history preserved: {cur.fetchone()[0]} insight_runs "
          "rows (this script never writes or deletes them)")
    print(f"--- {'ALL CHECKS PASSED' if not fails else f'{fails} FAILED'} ---")
    return fails


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--db-url", default=None)
    p.add_argument("--verify", action="store_true",
                   help="verify only - apply nothing")
    p.add_argument("--skip-data", action="store_true",
                   help="apply DDL only (01+02), leave table contents alone")
    args = p.parse_args()

    import psycopg2
    con = psycopg2.connect(_db_url(args.db_url))
    con.autocommit = False
    cur = con.cursor()

    if not args.verify:
        files = ["01_source_schema.sql", "02_insights_schema.sql"]
        if not args.skip_data:
            files.append("03_source_data.sql")
        for name in files:
            # One execute per file: psycopg2 sends the whole batch, so no
            # client-side statement splitting can corrupt a literal that
            # happens to contain a semicolon (field-note verbatims do).
            cur.execute((SQL / name).read_text(encoding="utf-8"))
            con.commit()
            print(f"applied sql/{name}")

    fails = verify(cur)
    cur.close()
    con.close()
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
