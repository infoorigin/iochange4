# ainf_data — data model

One Postgres schema, two planes with opposite lifecycles:

| Plane | Tables | Lifecycle | Writer |
|---|---|---|---|
| **Source** | 6 | replace — the kit reloads them at will | `setup_db.py` (or the client's own feed) |
| **Insights + metrics** | 7 | append per run, replace-by-`run_id` — **never dropped** (run history) | `iof-ainf_insights-insights_store` only; agents never INSERT |

Column-level detail: **[data_dictionary.html](data_dictionary.html)**.
Design rationale: `docs/insights-data-model.md` in the repo.

## Relationships

```mermaid
erDiagram
    insight_runs ||--o{ insights : "run_id"
    insight_runs ||--o{ run_metrics : "run_id"
    insight_runs ||--o{ run_hypotheses : "run_id"
    insights ||--o{ insight_evidence : "insight_id"
    insights ||--o{ insight_accounts : "insight_id"
    insights ||--o{ insights : "parent_insight_id (card nesting)"
    run_metrics ||--o{ run_metric_points : "(run_id, metric_id)"

    insight_runs {
        text run_id PK
        text brand
        text workflow
        text diagnosis
        timestamptz generated_at
        jsonb payload
    }
    insights {
        bigserial insight_id PK
        text run_id FK
        text kind "CHECK: 8 card kinds"
        bigint parent_insight_id FK
        text headline
        numeric confidence_pct
        jsonb payload
    }
    insight_evidence {
        bigserial evidence_id PK
        bigint insight_id FK
        text source
        text finding
        text query_sql "the exact SQL behind the claim"
    }
    insight_accounts {
        bigint insight_id PK_FK
        text account_name PK
        numeric score
        jsonb signals
    }
    run_metrics {
        text run_id PK_FK
        text metric_id PK
        text shape "row | rows"
        jsonb value
        text query_sql
    }
    run_metric_points {
        text run_id PK_FK
        text metric_id PK_FK
        integer ord PK
        date month "promoted dim"
        text region "promoted dim"
        text account_name "promoted dim"
        text segment "promoted dim"
        jsonb vals
    }
    run_hypotheses {
        text run_id PK_FK
        text hypothesis_id PK
        boolean armed "NULL = external/errored"
        text arm_when_sql
    }
```

The six **source tables** are flat facts with composite time-grain keys and
no FKs between them — `account_id` is the shared join key by convention:

```
brand_performance_monthly    (month, region)              national/regional TRx vs plan
account_performance_monthly  (month, account_id)          account-level TRx
competitor_activity_monthly  (month, account_id)          SOV, campaign exposure, call counts
new_patient_starts_monthly   (month, account_id, segment) starts by treatment segment
field_notes                  (note_id)                    CRM call notes + signal flags
promo_spend_monthly          (month, channel)             spend vs plan by channel
```

`creative_performance_monthly` is deliberately **absent** — that dataset is
served by the `creative_intel` MCP server (multi-source analysis by design).

## The conventions that make it queryable

- **`run_id` is the lineage key.** Every insights-plane row carries it; the
  same id opens the run's artifacts and its agent sessions. Anchor every
  consumer on a run_id — latest per brand:
  `SELECT run_id FROM ainf_data.insight_runs WHERE brand=:b ORDER BY generated_at DESC LIMIT 1`.
- **Runs are versioned snapshots, never merged.** A re-run appends its own
  run_id-keyed set; re-persisting ONE run is transactional replace-by-run.
  Cross-run trends ("how has the gap moved?") are a two-table join.
- **`brand` lives on `insight_runs`**, denormalized only onto `insights`
  (the #1 NLQ filter). Metrics reach it via the run_id join.
- **Hybrid spine + JSONB.** Columns carry what queries filter and rank on;
  `payload`/`vals` keep verbatim rendering fidelity, so a new card or
  measure field ships with zero DDL.
- **Promoted dimensions.** `run_metric_points` lifts the four axes this
  domain filters on (`month`, `region`, `account_name`, `segment`) into
  real columns; anything further stays in `dims`. A genuinely new axis is
  one nullable column of DDL.
- **Every number is auditable.** `run_metrics.query_sql` and
  `insight_evidence.query_sql` store the exact SQL that produced the value
  or claim — any figure on a dashboard can be re-executed and reproduced.
- **`insights.kind`** is CHECK-constrained to the card vocabulary:
  `kpi · opportunity · driver · comparison · priority_account_set · action
  · not_recommended · diagnosis` — the exculpatory finding
  (`not_recommended`) is first-class and queryable.
- **`run_hypotheses.armed`** is three-valued: `true` = armed by its
  `arm_when_sql`, `false` = cleared, `NULL` = evaluated externally
  (`evaluate='external'`, e.g. via the creative MCP) or errored.
