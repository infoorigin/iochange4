# setup_ainf — client deployment kit

Everything needed to stand up the `ainf_insights` database from nothing:
schema, table DDL, and the source data as SQL. **Every script and every
SQL file here is idempotent** — run any of them any number of times and
the database converges on the same state. The one thing no run ever
touches is the insights tables' existing rows: they are run history.

```
setup_ainf/
  sql/01_source_schema.sql     schema + six SOURCE tables (replace semantics)
  sql/02_insights_schema.sql   insights + computed-metrics tables (IF NOT
                               EXISTS only — never drops, preserves history)
  sql/03_source_data.sql       GENERATED source rows (one transaction:
                               TRUNCATE + INSERT — replace semantics)
  setup_db.py                  applies 01 → 02 → 03, then verifies
  gen_source_inserts.py        regenerates 03 from the workflow CSVs
  templates/mcp.workspace.yaml URL-mode override for the MCP server
  .env.template                every variable a deployment sets
```

## 1. Database

```bash
pip install psycopg2-binary            # already present with the platform SDK
python setup_ainf/setup_db.py          # AINF_DB_URL from env or workspace .env
python setup_ainf/setup_db.py --verify # check without touching anything
```

Connection resolution: `--db-url` > `AINF_DB_URL` env >
`~/.iobot/workspaces/ainf_insights/.env`. Where the app user has no DDL
rights, hand the three `sql/` files to a DBA in order — they are plain
psql-executable SQL.

What a run does, and why re-running is always safe:

| File | Semantics | Re-run effect |
|---|---|---|
| 01_source_schema.sql | `CREATE SCHEMA IF NOT EXISTS` + DROP/CREATE source tables | identical tables, empty |
| 02_insights_schema.sql | `CREATE TABLE IF NOT EXISTS` only | no-op; **history preserved** |
| 03_source_data.sql | one transaction: TRUNCATE six source tables + INSERT | identical rows |

`--verify` checks row counts against the data file's own manifest, the
generator's pinned headline aggregates (national share, spend YTD), that
the creative dataset is NOT in the database (it is MCP-served — see
below), that all seven insights-tier tables exist, and prints the
run-history row count it left alone.

`--skip-data` applies DDL only, for a deployment that wants the schema
but loads its own source extract.

## 2. The creative_intel MCP server

One dataset — creative performance — deliberately does not live in the
database: it is served by an MCP server so a single analysis run
demonstrably works multi-source. The server lives in its **own
repository** (`creative-intel-mcp` — own `pyproject.toml`, own data) and
is accessed like any external MCP server.

- **stdio**: install it into the platform venv —
  `pip install -e ../creative-intel-mcp` (or from your index) — and the
  pack's `tools/mcp.yaml` spawns `creative-intel-mcp` per run.
- **URL mode (recommended)** — the server as its own process, address
  from the env file:

  ```bash
  # wherever the server should live:
  creative-intel-mcp --transport streamable-http --host 0.0.0.0 --port 8765

  # on the platform side:
  cp setup_ainf/templates/mcp.workspace.yaml ~/.iobot/workspaces/<code>/mcp.yaml
  echo 'CREATIVE_MCP_URL=http://<host>:8765/mcp' >> ~/.iobot/workspaces/<code>/.env
  aicore mcp-list --probe        # must show creative_intel healthy
  ```

  The yaml carries only `${CREATIVE_MCP_URL}`; the address lives in the
  env file and nowhere else. The workspace tier replaces the pack's stdio
  entry whole; unset the variable and the server is dropped loudly at
  merge rather than failing runs.

## 3. Refreshing the data

The dataset is generator-pinned (`demo/generate_data.py` self-verifies
19 dashboard facts). After regenerating:

```bash
python setup_ainf/gen_source_inserts.py    # rewrites sql/03_source_data.sql
cp solutions/brand_marketing/workflows/brand_insights/metadata/data/creative_performance_monthly.csv ../creative-intel-mcp/creative_intel/data/
python setup_ainf/setup_db.py              # reload + verify
```

`gen_source_inserts.py` is deterministic — same CSVs, byte-identical
SQL — so a clean `git diff` after running it proves nothing drifted.

## 4. Validating the client-raised fixes

`CLIENT_VALIDATION_WALKTHROUGH.md` walks a colleague through proving, on
their own deployment, each fix the client team asked about - chat
storage and returning users, cross-run questions, memory governance and
the RBAC boundaries. `validate_fixes.py` runs the same checks
automatically (`--token` for the guarded set).

## 5. What this kit does NOT cover

Platform installation (SDK wheels, `aicore workspace create`, agent
seeding, `aicore serve`) is the platform's own setup, documented in the
engine's client docs — this kit is the workspace's DATA plane: the
schema the agents query and the MCP source they consult.
