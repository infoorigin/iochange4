STATUS: done
OUTPUT: Aug 2026 DARZALEX brand review: share -0.9 pts vs plan (18.3% vs 19.2%), TRx +6% vs plan, spend +3% vs plan; diagnosis = lost share in a growing market; Texas carries 138% of national gap; 9 of 22 panel accounts declining, all DFW and all XELVORA campaign-exposed since March; 2L segment is the battleground.

# DARZALEX Brand Review — January–August 2026
## Monthly Business Review | August 2026

---

## 1. Headline KPIs

### Share (August 2026 — national, volume-weighted)
| | Actual | Plan | Gap |
|---|---|---|---|
| Market share | 18.3% | 19.2% | **-0.9 pts** |

Source: `brand_performance_monthly`; SQL: `100.0*SUM(brand_trx)/SUM(market_trx)` for actual;
`SUM(plan_share_pct*market_trx)/SUM(market_trx)` for plan; aggregated national across all 6 regions.
Row count: 6 regional rows for August (1 row per region).

### TRx Volume (YTD, January–August 2026 — national)
| | Actual | Plan | % vs Plan |
|---|---|---|---|
| Brand TRx YTD | 38,400,000 | 36,226,424 | **+6.0%** |

Source: `brand_performance_monthly`; SQL: `SUM(brand_trx)` YTD vs `SUM(plan_brand_trx)` YTD.
Row count: 48 regional-month rows (8 months × 6 regions).

### Promotional Spend (YTD, January–August 2026)
| | Actual | Plan | % vs Plan | Pacing |
|---|---|---|---|---|
| Total spend | $126,000,000 | $122,100,000 | **+3.0%** | Over |

Source: `promo_spend_monthly`; SQL: `SUM(spend_usd)` and `SUM(plan_usd)` across all channels.
Row count: 40 channel-month rows (8 months × 5 channels).

By channel, all five channels are within ±3.1% of plan (field force +3.0%, HCP media +3.0%,
speaker programs +3.0%, digital & CRM +3.0%, congress & events +3.0%). Spend is evenly over plan
across all channels — not a targeted overspend.

---

## 2. Share Trend

National actual share vs plan share and prior-year share, January–August 2026:

| Month | Actual Share | Plan Share | Prior-Year Share | vs Plan (pts) |
|---|---|---|---|---|
| Jan | 19.9% | 19.2% | 18.9% | +0.7 |
| Feb | 19.7% | 19.2% | 18.9% | +0.5 |
| Mar | 19.4% | 19.2% | 19.0% | +0.3 |
| Apr | 19.2% | 19.2% | 19.0% | +0.1 |
| **May** | **18.9%** | **19.2%** | **19.1%** | **-0.3** |
| Jun | 18.7% | 19.2% | 19.2% | -0.5 |
| Jul | 18.5% | 19.2% | 19.2% | -0.7 |
| **Aug** | **18.3%** | **19.2%** | **19.3%** | **-0.9** |

Source: `brand_performance_monthly`; SQL: `100.0*SUM(brand_trx)/SUM(market_trx)` (actual);
`SUM(plan_share_pct*market_trx)/SUM(market_trx)` (plan); `AVG(prior_year_share_pct)` (prior year).
Row count: 8 monthly aggregates (each aggregates 6 regional rows).

**Key inflection point:** Actual share crossed below plan in May 2026 and has widened every month since.
Prior-year share held above actual share from May onward, confirming this is not a seasonal artifact.

---

## 3. Volume-vs-Share Diagnosis

| | January | August | Change |
|---|---|---|---|
| Brand TRx | 4,801,218 | 4,793,676 | **Flat (−0.2%)** |
| Market TRx | 24,134,000 | 26,257,791 | **+8.8%** |

**Verdict: LOST SHARE in a growing market.**

Source: `brand_performance_monthly`; SQL: `SUM(brand_trx)` and `SUM(market_trx)` at month='2026-01-01' and month='2026-08-01'.
Row count: 6 regional rows per month.

The brand held volume essentially flat (down 0.2%) while the market grew 8.8%. The national gap of -192,600 TRx is entirely a share problem: the market expanded and DARZALEX did not capture its proportional share. The prior-year comparison reinforces this — August 2025 share (19.3%) was above August 2026 actual (18.3%), even as the market was larger in 2026.

---

## 4. Region Contribution to National Gap

National YTD gap: -192,600 TRx (actual YTD 38,400,000 vs implied TRx at plan share 38,592,600).

| Region | Gap vs Plan (TRx) | Contribution to National Gap |
|---|---|---|
| **Texas** | **-266,332** | **138.3%** |
| Southeast | -125,836 | 65.3% |
| West | -26,163 | 13.6% |
| Midwest | +103,523 | −53.8% |
| Mountain | +83,225 | −43.2% |
| Northeast | +38,982 | −20.2% |

Source: `brand_performance_monthly`; SQL: `SUM(brand_trx) - SUM(plan_share_pct*market_trx/100.0)` per region YTD;
contribution = regional gap / total national gap.
Row count: 6 regional YTD aggregates.

**Texas alone carries 138% of the national gap.** The Texas gap exceeds the total national gap because
the other five regions are collectively ahead of plan (offsetting +117% combined), masking the true
magnitude of the Texas deterioration. Southeast is the second-worst region but is partially masked
by the Texas over-weight.

---

## 5. Key-Account Panel (DFW Focus)

22 accounts total: 12 DFW (ACC-001..ACC-012), 10 non-DFW comparators.

**Share change Jan→Aug, status classification:**
- Declining (<−0.5 pts): **9 accounts**
- Stable (−0.5 to +0.5 pts): **12 accounts**
- Growing (>+0.5 pts): **1 account** (Boston Cancer Specialists, +0.5 pts)

**All 9 declining accounts are in DFW (Texas). Not a single non-DFW account declined.**

Source: `account_performance_monthly`; SQL: share change = `100.0*SUM(CASE WHEN month='2026-08-01' THEN brand_trx END)/SUM(CASE WHEN month='2026-08-01' THEN market_trx END) - 100.0*SUM(CASE WHEN month='2026-01-01' THEN brand_trx END)/SUM(CASE WHEN month='2026-01-01' THEN market_trx END)` per account.
Row count: 22 accounts (2 months × 22 accounts = 44 rows).

**Decliners ranked by share points lost:**

| Account | Metro | Share Change (pts) | Market TRx Aug | Region |
|---|---|---|---|---|
| Lakeside Oncology Partners | Dallas-Fort Worth | **-7.2** | 2,850 | Texas |
| North Texas Cancer Care | Dallas-Fort Worth | **-6.4** | 2,430 | Texas |
| Grapevine Hematology | Dallas-Fort Worth | **-5.9** | 1,980 | Texas |
| Trinity Valley Oncology | Dallas-Fort Worth | **-5.1** | 1,760 | Texas |
| Denton Community Cancer | Dallas-Fort Worth | **-4.6** | 1,540 | Texas |
| Plano Hematology Associates | Dallas-Fort Worth | **-4.1** | 1,350 | Texas |
| Fort Worth Cancer Specialists | Dallas-Fort Worth | **-2.8** | 1,120 | Texas |
| Arlington Oncology Group | Dallas-Fort Worth | **-2.3** | 960 | Texas |
| Irving Hematology Center | Dallas-Fort Worth | **-1.7** | 870 | Texas |

Top decliner by volume: Lakeside Oncology Partners (market TRx 2,850 in August) — the highest-volume account in the panel and the steepest share decline.

---

## 6. Competitor Signals — XELVORA

### Share of Voice (SOV) Change, Jan→Aug
National panel average SOV: **+2.1 pts** (rising from ~baseline to ~24%).

Source: `competitor_activity_monthly`; SQL: `AVG(CASE WHEN month='2026-08-01' THEN competitor_sov_pct END) - AVG(CASE WHEN month='2026-01-01' THEN competitor_sov_pct END)`.
Row count: 22 accounts × 2 months = 44 rows.

### Earlier-Line Campaign Exposure
The XELVORA earlier-line campaign launched March 2026. Campaign exposure by account:

| Account | Metro | Campaign-Exposed? | Since |
|---|---|---|---|
| Lakeside Oncology Partners | DFW | **Yes** | March 2026 |
| North Texas Cancer Care | DFW | **Yes** | March 2026 |
| Grapevine Hematology | DFW | **Yes** | March 2026 |
| Trinity Valley Oncology | DFW | **Yes** | March 2026 |
| Denton Community Cancer | DFW | **Yes** | March 2026 |
| Plano Hematology Associates | DFW | **Yes** | March 2026 |
| Fort Worth Cancer Specialists | DFW | **Yes** | March 2026 |
| Arlington Oncology Group | DFW | **Yes** | March 2026 |
| Irving Hematology Center | DFW | **Yes** | March 2026 |
| Southlake Cancer Center | DFW | No | — |
| McKinney Oncology Associates | DFW | No | — |
| Rockwall Oncology | DFW | No | — |

**All 9 declining accounts (100%) are campaign-exposed since March 2026.**
Source: `competitor_activity_monthly`; SQL: `MAX(exposed_earlier_line_campaign)` and `MIN(CASE WHEN exposed_earlier_line_campaign=1 THEN month END)` per account.
Row count: 22 accounts.

### Prescribing Shift by Segment

| Segment | Comp Starts Jan | Comp Starts Aug | Change | Brand Starts Jan | Brand Starts Aug |
|---|---|---|---|---|---|
| **2L relapsed** | **209** | **243** | **+34 (+16.3%)** | 229 | 212 |
| 3L+ relapsed | 122 | 136 | +14 (+11.5%) | 136 | 126 |

Source: `new_patient_starts_monthly`; SQL: `SUM(CASE WHEN month='...' THEN competitor_starts END)` per segment.
Row count: 2 segments × 2 months = 4 rows.

**Fastest-growing segment: 2L relapsed (+16.3% competitor starts Jan→Aug).** This is precisely the segment XELVORA is targeting with its earlier-line campaign, and the only segment where brand starts are declining (brand down 7.4% in 2L, even as the segment itself is growing).

**Accounts with rising competitor starts:** 15 of 22 panel accounts (68%) show rising XELVORA starts from January to August.
Source: `new_patient_starts_monthly`; SQL: per-account competitor starts Aug > Jan.
Row count: 22 accounts.

---

## 7. Field-Note Themes

### Treatment-Choice Questions from 2L/3L Prescribers
- Accounts with ≥1 treatment-choice-question flag: **11 of 22 panel accounts**
- Accounts with ≥1 XELVORA competitor claim mention: **5 of 22 panel accounts**
- Treatment-choice accounts are predominantly DFW (8 of the 12 DFW accounts); the 3 non-DFW accounts flagged are Austin, Charlotte, and Chicago.

Source: `field_notes`; SQL: `COUNT(DISTINCT CASE WHEN treatment_choice_question=1 THEN account_id END)`.
Row count: 97 call notes (field_notes grain: 1 row per note, Mar–Aug 2026).

### Verbatim Quotes

**Quote 1 — Treatment choice uncertainty, 2L focus**
> "2L-focused prescriber raised treatment-choice questions: unsure whether to keep DARZALEX frontline of the relapsed setting or trial the newer regimen first."
— Lakeside Oncology Partners (ACC-001), note dated 2026-03-02

**Quote 2 — Competitor claim, "earlier is better" messaging**
> "Office quoted the XELVORA 'earlier is better' leave-behind; requested our response deck on relapsed 2L outcomes."
— Denton Community Cancer (ACC-005), note dated 2026-03-26

**Quote 3 — Sequencing question in 3L+ context**
> "Discussion centered on 3L+ patients; prescriber asked which sequence preserves later-line options and how DARZALEX fits if XELVORA is used earlier."
— North Texas Cancer Care (ACC-002), note dated 2026-03-07

These quotes confirm the narrative from the prescribing data: XELVORA's "earlier is better" framing is generating genuine prescribing uncertainty in both 2L and 3L+ settings, and offices are actively requesting our counter-messaging materials.

---

## 8. Creative Performance

| Variant | Total Impressions | Total Engagements | Engagement Rate |
|---|---|---|---|
| **CEPHEUS Now Approved** | 9,335,852 | 447,372 | **4.79%** |
| Base efficacy | 14,936,394 | 503,163 | 3.37% |

**CEPHEUS lift over base: +42%** (4.79% vs 3.37%).

CEPHEUS launched April 2026 (no January–March data by design). Month-to-month engagement rates are stable for both variants across their respective active windows.

Source: `creative_performance_monthly`; SQL: `100.0*SUM(hcp_engagements)/SUM(impressions)` by creative_variant.
Row count: 13 rows (creative × month combinations).

CEPHEUS is performing well but has received only 38% of total impressions (9.3M of 24.3M). The
higher-performing creative has less weight in market — an allocation opportunity.

---

## 9. Hypotheses for the Strategist

These are candidate drivers grounded in the data above, labeled as hypotheses for prioritization testing. No recommendations are made here — those belong to the strategize step.

**H1 — XELVORA earlier-line campaign in DFW is the primary driver of the share gap.**
Evidence: All 9 declining accounts are in DFW and are campaign-exposed since March 2026 (q06b). XELVORA SOV rose +2.1 pts nationally and is concentrated in DFW. Competitor starts grew +16.3% in the 2L relapsed segment, the campaign's target. Field notes show competitor claim mentions in 5 accounts, all DFW. Texas alone carries 138% of the national share gap.

**H2 — Prescriber uncertainty about sequencing, not brand preference, is the mechanism.**
Evidence: 11 of 22 panel accounts show treatment-choice-question field notes (q08a), and the verbatim quotes repeatedly reference "which sequence preserves later-line options" and uncertainty about where DARZALEX fits relative to XELVORA. This is a clinical-question problem, not a promotional-awareness problem — reps may need medical science liaison support, not more calls.

**H3 — The volume plan was set against a market that has grown faster than planned, masking the share problem.**
Evidence: Market TRx grew 8.8% Jan→Aug while brand TRx was flat, so the brand is growing less than the market (q03). The YTD TRx actual (+6.0%) exceeds plan because the plan volume was calibrated to a slower-growing market; however, share is eroding because the brand is not capturing its proportional share of the expanded market.

**H4 — CEPHEUS creative outperformance is not being fully leveraged.**
Evidence: CEPHEUS engagement rate is 42% above base (q10), but CEPHEUS has only 38% of total impressions. The high-performing creative is underweighted in the media plan.

**H5 — The non-DFW cohort is a stable comparison baseline — the problem is DFW-specific, not national.**
Evidence: 12 of 22 panel accounts are non-DFW; only 1 declined (Boston Cancer Specialists, +0.5 pts). All 9 declining accounts are DFW. The Northeast, Midwest, and Mountain regions are all ahead of plan (q04). The gap is geographically concentrated and not a general brand problem.
