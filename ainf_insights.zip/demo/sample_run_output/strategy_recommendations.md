STATUS: done
OUTPUT: 3 validated drivers confirmed (XELVORA campaign in DFW, prescriber sequencing uncertainty, CEPHEUS under-weighted); top account: Lakeside Oncology Partners (score 100); top action: MSL deployment to 6 TCQ-flagged accounts.

# DARZALEX Brand Strategy — August 2026 Monthly Review
**Role:** Brand Marketing Strategist | **Date:** August 2026 | **Authored from:** steps/analyze findings + self-run cohort queries

---

## 1. Validated Drivers

### Driver 1 (Rank 1): XELVORA Earlier-Line Campaign in DFW is the Primary Driver
**Confidence: 90%**

All evidence converges independently on one conclusion: the share gap is a DFW-specific, campaign-driven event.

**Evidence stream 1 — Competitor SOV differential (cohort contrast).**
Declining DFW accounts (n=9) averaged +3.34 pts SOV change Jan→Aug vs +1.51 pts for stable non-DFW accounts (n=10) — 2.2x the competitive pressure.
Source: `competitor_activity_monthly` via `cohort_competitor_v2.sql`; 9 declining DFW + 10 stable non-DFW accounts.

**Evidence stream 2 — High-intensity competitor targeting.**
7 of 9 declining DFW accounts (77.8%) show SOV increase >2 pts vs 3 of 10 stable non-DFW accounts (30.0%).
Source: same query as above.

**Evidence stream 3 — Competitor field call intensity.**
Declining DFW accounts averaged 86.6 competitor field calls YTD vs 67.5 for stable non-DFW — 22% more competitor rep activity in the affected cohort.
Source: same query as above.

**Evidence stream 4 — All 9 decliners campaign-exposed, top 6 most heavily targeted.**
All 9 declining accounts are campaign-exposed since March 2026. The top 6 accounts (Lakeside through Plano) each show SOV change of +4.2 pts — the highest SOV tier in the panel.
Source: `account_performance_monthly` + `competitor_activity_monthly` via `account_scoring.sql`; 9 accounts.

**Evidence stream 5 — Geographic concentration.**
Texas carries 138.3% of the national share gap — the other five regions are collectively ahead of plan and overcompensate. The gap is not a national brand problem.
Source: `brand_performance_monthly` via analyst's q04; 6 regions.

### Driver 2 (Rank 2): Prescriber Sequencing Uncertainty — Not Brand Preference — is the Mechanism
**Confidence: 82%**

The mechanism of share loss is clinical-question uncertainty, not brand rejection.

**Evidence stream 1 — TCQ field notes by cohort.**
7 of 9 declining DFW accounts (77.8%) carry treatment-choice-question field notes vs 3 of 10 stable non-DFW accounts (30.0%).
Source: `field_notes` via `cohort_field_notes_v2.sql`; 9 declining DFW + 10 stable non-DFW accounts.

**Evidence stream 2 — Competitor claim mentions in field notes.**
5 of 9 declining DFW accounts (55.6%) show competitor-claim mentions vs 0 of 10 stable non-DFW accounts (0.0%).
Source: same query as above.

**Evidence stream 3 — Verbatim field intelligence.**
Three verbatim quotes (March 2026) from declining accounts confirm offices are actively engaging with XELVORA's "earlier is better" framing and requesting our response materials.
Source: `field_notes`; NOTE-0003 (Lakeside), NOTE-0015 (Denton), NOTE-0008 (North Texas).

**Evidence stream 4 — 2L relapsed prescribing shift.**
Competitor starts in the 2L relapsed segment grew +16.3% (Jan→Aug) while brand starts in the same segment declined -7.4%. This is the campaign's target segment and the only segment with brand start decline.
Source: `new_patient_starts_monthly` via analyst's q07.

### Driver 3 (Rank 3): CEPHEUS Creative is Outperforming but Under-Weighted
**Confidence: 78%**

**Evidence stream 1 — Engagement rate differential.**
CEPHEUS Now Approved: 4.79% engagement rate vs Base efficacy: 3.37% — CEPHEUS +42%.
Source: `creative_performance_monthly` via analyst's q10.

**Evidence stream 2 — Impression allocation gap.**
CEPHEUS holds 9.3M of 24.3M total impressions (38%) despite +42% engagement. The high-performing creative is under-weighted. This is a pure allocation decision requiring no new creative development.
Source: same query as above.

---

## 2. Rejected Hypotheses

| Hypothesis | Reason for Rejection |
|---|---|
| Broad undifferentiated field-force increase across the panel | Cohort contrast shows our field-call rate is essentially equal between declining DFW (avg 9.6/month) and stable non-DFW (avg 10.1/month). The gap is not under-contacting. |
| National awareness / brand equity campaign | Non-DFW regions are stable or ahead of plan. Gap is DFW-specific and campaign-specific. National broadcast would dilute spend that should be concentrated in DFW. |

---

## 3. Cohort Contrast Table

**Cohort definition:** Declining DFW = 9 accounts (share change < -0.5 pts, all in Dallas-Fort Worth); Stable non-DFW = 10 accounts (all non-DFW metros, share change -0.5 to +0.5 pts).

| Factor | Declining DFW (n=9) | Stable non-DFW (n=10) | Verdict |
|---|---|---|---|
| Competitor SOV change (avg pts, Jan→Aug) | **+3.34** | +1.51 | **Likely a cause** — 2.2x the competitive pressure |
| Accounts with high SOV (>2 pts increase) | **77.8% (7/9)** | 30.0% (3/10) | **Likely a cause** |
| Competitor field calls (avg YTD) | **86.6** | 67.5 | **Likely a cause** — 22% more competitor rep activity |
| Accounts with treatment-choice-question notes | **77.8% (7/9)** | 30.0% (3/10) | **Likely a cause** — sequencing uncertainty concentrated in declining cohort |
| Accounts with competitor claim mentions | **55.6% (5/9)** | 0.0% (0/10) | **Likely a cause** |
| Our field calls (avg per month) | 9.6 | **10.1** | **Not a cause** — essentially equal; field contact is not the gap |

Sources: `competitor_activity_monthly` via `cohort_competitor_v2.sql`; `field_notes` via `cohort_field_notes_v2.sql`. Row counts: 9 declining DFW accounts, 10 stable non-DFW accounts.

---

## 4. Priority Accounts — Scoring

### Scoring Formula

```
score = (share_decline_percentile × 0.40
       + market_trx_percentile × 0.35
       + driver_strength × 0.25) × 100
```

Normalized to 0–100 scale.

- **share_decline_percentile** = |share_change_pts| / max(|share_change_pts|) across the 9 declining accounts
- **market_trx_percentile** = market_trx_aug / max(market_trx_aug) across the 9 declining accounts
- **driver_strength** = 1.0 if campaign_exposed AND sov_change_pts >= 4.0 (top 6 accounts); 0.65 if campaign_exposed AND sov_change_pts < 4.0 (Arlington, Irving); 0.5 if campaign_exposed AND has_tcq=0
- **Action threshold: 55** — accounts scoring below 55 have either lower volume, lower share decline, or weaker driver signal (lower SOV tier and no TCQ flag)

Anchored to Lakeside Oncology Partners (share -7.2 pts, TRx 2,850, sov +4.2, campaign_exposed, has_tcq=1) = score 100.

### Priority Accounts Above Action Threshold (score >= 55)

| Rank | Account | Score | Share Change (pts) | Market TRx (Aug) | Driver Signals |
|---|---|---|---|---|---|
| 1 | Lakeside Oncology Partners | **100.0** | -7.2 | 2,850 | Campaign-exposed, SOV +4.2, TCQ flagged |
| 2 | North Texas Cancer Care | **96.4** | -6.4 | 2,430 | Campaign-exposed, SOV +4.2, TCQ flagged |
| 3 | Grapevine Hematology | **86.3** | -5.9 | 1,980 | Campaign-exposed, SOV +4.2, TCQ flagged |
| 4 | Trinity Valley Oncology | **80.8** | -5.1 | 1,760 | Campaign-exposed, SOV +4.2, TCQ flagged |
| 5 | Denton Community Cancer | **74.7** | -4.6 | 1,540 | Campaign-exposed, SOV +4.2, TCQ flagged |
| 6 | Plano Hematology Associates | **67.4** | -4.1 | 1,350 | Campaign-exposed, SOV +4.2, TCQ flagged |

### Accounts Below Action Threshold

| Rank | Account | Score | Share Change (pts) | Market TRx (Aug) | Why Below Threshold |
|---|---|---|---|---|---|
| 7 | Fort Worth Cancer Specialists | 51.7 | -2.8 | 1,120 | Smaller decline, mid-volume, but still campaign-exposed; no TCQ flag; borderline |
| 8 | Arlington Oncology Group | 35.0 | -2.3 | 960 | Lower decline, lower volume, SOV +0.35 (low tier), no TCQ flag |
| 9 | Irving Hematology Center | 32.1 | -1.7 | 870 | Smallest decline, lowest volume among decliners, SOV +0.35 (low tier), no TCQ flag |

Source: `account_performance_monthly` + `competitor_activity_monthly` + `field_notes` via `account_scoring.sql`; 9 declining DFW accounts.

---

## 5. Recommended Actions

### Action 1 (Highest Impact)
**Deploy Medical Science Liaisons to the top 6 priority accounts**

Target the prescribing uncertainty that is driving the 2L relapsed segment shift, not the campaign presence.

**Rationale:** 7 of 9 declining DFW accounts (77.8%) carry treatment-choice-question field notes vs 30.0% of stable non-DFW accounts. The verbatim quotes confirm offices are requesting our response deck on relapsed 2L outcomes. The demand signal is already there — this is not a promotional-awareness problem, it is a clinical-question problem. MSL-mediated medical education on DARZALEX regimen sequencing and outcomes in 2L relapsed is the correct lever. Fort Worth Cancer Specialists (score 51.7) is borderline and should receive MSL support at the rep level with a sequencing message before escalation. Arlington and Irving are not TCQ-flagged; their decline appears to be indirect competitive ecosystem pressure, not prescriber uncertainty — MSL investment here has lower expected return.

**Confidence: 82%** — the cohort contrast on TCQ (77.8% vs 30.0%) is a large and specific gap; the verbatim demand signal is independently reported.

**Applies to:** Lakeside Oncology Partners, North Texas Cancer Care, Grapevine Hematology, Trinity Valley Oncology, Denton Community Cancer, Plano Hematology Associates — all DFW, all TCQ-flagged, all campaign-exposed with high SOV.

---

### Action 2 (High Impact)
**Shift HCP media allocation to CEPHEUS Now Approved — 55–60% impression share, prioritize DFW**

Shift existing impressions from under-performing Base efficacy creative to the +42% higher-engagement CEPHEUS variant. DFW is the priority reallocation geography.

**Rationale:** CEPHEUS holds only 38% of impressions despite +42% engagement. This is a pure allocation decision executable within existing spend levels — no new creative, no agency lead time. DFW HCPs are active on treatment-choice questions; CEPHEUS messaging on approved indications and clinical data is directly responsive to the "earlier is better" competitor framing. The analyst's finding that the gap is Texas-specific makes the DFW priority straightforward.

**Confidence: 78%** — the engagement rate differential is measured and large; the allocation gap is straightforward arithmetic; the DFW concentration is confirmed by the analyst.

**Applies to:** HCP media channel, national with DFW priority. The 9 declining DFW accounts specifically, and the broader Texas region.

---

### Action 3 (High Impact)
**Activate key account managers at the top 4 accounts with account-specific competitive battlecards**

Provide field reps at the highest-value accounts with approved materials directly countering XELVORA's "earlier is better" messaging — the materials the accounts have already requested.

**Rationale:** Denton Community Cancer's field note (2026-03-26) records the office explicitly requesting our response deck after encountering XELVORA leave-behind material. The demand is present; the supply is not keeping pace. This action is specifically for the top 4 accounts (Lakeside, North Texas, Grapevine, Trinity Valley) where the combination of high volume, steep share decline, and TCQ flags makes a competitive counter the highest-ROI field investment. Fort Worth, Arlington, and Irving do not carry TCQ flags — at those accounts, the competitive message is less differentiated by prescriber uncertainty and the account-specific battlecard is less likely to convert.

**Confidence: 75%** — the verbatim demand signal is specific to Denton; the account-specific targeting is grounded in the scoring model; execution risk is low (battlecard development and rep briefing are known field operations).

**Applies to:** Lakeside Oncology Partners, North Texas Cancer Care, Grapevine Hematology, Trinity Valley Oncology.

---

## 6. What Not to Do

### Do Not: Broad Undifferentiated Field Force Increase Across the Panel
The cohort contrast is definitive on this point. Our field-call rate is essentially equal between the declining cohort (avg 9.6/month) and the stable cohort (avg 10.1/month) — a 0.5 call/month difference that is within noise. The gap is not our presence; it is the competitor's outsized SOV investment (+3.34 pts vs +1.51 pts in stable markets). Adding rep calls where the problem is the competitor's message — not our frequency — would misallocate field effort and not address the root cause.

**Contrast percentages:** Declining DFW: 9.6 avg monthly calls; Stable non-DFW: 10.1 avg monthly calls. Source: `competitor_activity_monthly` via `cohort_competitor_v2.sql`; row counts: 9 and 10 respectively.

### Do Not: National Awareness or Brand Equity Campaign
The share gap is DFW-specific and campaign-specific. Five regions are ahead of plan. A national broadcast campaign would dilute spend and messaging that should be concentrated in the affected geography. XELVORA's "earlier is better" framing is a clinical claim — the correct answers are MSL-mediated medical education (addressing the sequencing uncertainty) and account-specific competitive materials, not a brand-equity campaign.
