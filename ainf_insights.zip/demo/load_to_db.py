"""Load the synthetic source extract into the `ainf_data` Postgres schema.

- Executes sql/ainf_data_schema.sql   (SOURCE tables: dropped + reloaded)
- Executes sql/insights_schema.sql    (INSIGHTS tables: IF NOT EXISTS, never dropped)
- Loads six CSVs from the workflow's metadata/data/ into their tables.
  creative_performance_monthly is deliberately NOT loaded - that dataset is
  served by the creative_intel MCP server (multi-source demo).
- Verifies row counts and two headline aggregates against the generator's
  known values, and exits non-zero on any mismatch.

Connection comes from AINF_DB_URL in the workspace .env
(~/.iobot/workspaces/ainf_insights/.env) - read directly from the file, never
sourced through a shell (the password contains `$`).
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

import psycopg2

REPO = Path(__file__).resolve().parents[1]
DATA = REPO / "solutions/brand_marketing/workflows/brand_insights/metadata/data"
ENV_FILE = Path.home() / ".iobot" / "workspaces" / "ainf_insights" / ".env"

TABLES = {  # table -> csv (column order in the CSV matches the DDL)
    "brand_performance_monthly": "brand_performance_monthly.csv",
    "account_performance_monthly": "account_performance_monthly.csv",
    "competitor_activity_monthly": "competitor_activity_monthly.csv",
    "new_patient_starts_monthly": "new_patient_starts_monthly.csv",
    "field_notes": "field_notes.csv",
    "promo_spend_monthly": "promo_spend_monthly.csv",
}


def env_url() -> str:
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        if line.startswith("AINF_DB_URL="):
            return line.split("=", 1)[1].strip()
    sys.exit(f"AINF_DB_URL not found in {ENV_FILE}")


def main() -> int:
    con = psycopg2.connect(env_url())
    con.autocommit = False
    cur = con.cursor()

    for ddl in ("ainf_data_schema.sql", "insights_schema.sql"):
        cur.execute((REPO / "sql" / ddl).read_text(encoding="utf-8"))
        print(f"executed sql/{ddl}")

    for table, fname in TABLES.items():
        with open(DATA / fname, newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            cols = next(reader)
            rows = list(reader)
        ph = ",".join(["%s"] * len(cols))
        cur.executemany(
            f"INSERT INTO ainf_data.{table} ({','.join(cols)}) VALUES ({ph})",
            rows)
        print(f"loaded {table:32s} {len(rows):5d} rows")

    con.commit()

    # ── verify: counts + two headline aggregates the generator pinned ──
    fails = 0

    def check(label, sql, want, tol=0.0):
        nonlocal fails
        cur.execute(sql)
        got = cur.fetchone()[0]
        ok = (abs(float(got) - want) <= tol) if tol else (got == want)
        print(f"{'PASS' if ok else 'FAIL'}  {label:44s} -> {got}")
        fails += 0 if ok else 1

    for table, fname in TABLES.items():
        with open(DATA / fname, newline="", encoding="utf-8") as f:
            want = sum(1 for _ in f) - 1
        check(f"count {table}", f"SELECT count(*) FROM ainf_data.{table}", want)

    check("national share Aug = 18.26",
          "SELECT round(100.0*SUM(brand_trx)/SUM(market_trx), 2) "
          "FROM ainf_data.brand_performance_monthly WHERE month='2026-08-01'",
          18.26, tol=0.02)
    check("spend YTD = 126,000,000",
          "SELECT SUM(spend_usd) FROM ainf_data.promo_spend_monthly",
          126_000_000)
    check("creative stays OUT of the database (MCP-served)",
          "SELECT count(*) FROM information_schema.tables WHERE "
          "table_schema='ainf_data' AND table_name='creative_performance_monthly'",
          0)
    check("insights tables present",
          "SELECT count(*) FROM information_schema.tables WHERE "
          "table_schema='ainf_data' AND table_name IN "
          "('insight_runs','insights','insight_evidence','insight_accounts')",
          4)

    cur.close()
    con.close()
    print(f"--- {'ALL CHECKS PASSED' if not fails else f'{fails} FAILED'} ---")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
