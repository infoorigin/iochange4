"""Deterministic synthetic source data for the brand_insights workflow.

Engineers the monthly commercial extract so that grounded analysis reproduces
the demo dashboard's story for the DARZALEX brand (synthetic; no real data):

  - national share 18.2% in Aug'26, -0.9 pts vs plan, above plan in Jan
  - brand TRx YTD 38.4M, +6% vs volume plan (flat TRx: lost share, not volume)
  - promo spend YTD $126.0M, +3% vs plan (over-pacing)
  - Texas region ~61% of the national gap, West ~24%, Southeast the third
  - 12-account DFW panel: 9 declining (named, -7.2 .. -1.7 pts), 3 stable
  - competitor SOV +2.1 pts (panel average, Jan -> Aug)
  - all 9 decliners exposed to the competitor earlier-line campaign (Mar+)
  - 6 of 9 exposed decliners show competitor 2L-relapsed starts up >25%
  - treatment-choice-question notes in 8 of 12 DFW accounts; ~58% of losing
    cohort notes flagged vs ~24% in the steady cohort
  - competitor-claim mentions in 5 accounts
  - CEPHEUS "Now Approved" creative outperforming base (~+40% engagement)

Writes CSVs into solutions/brand_marketing/workflows/brand_insights/metadata/data/
and verifies every headline with DuckDB before exiting (non-zero on failure).
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / (
    "solutions/brand_marketing/workflows/brand_insights/metadata/data"
)

MONTHS = [f"2026-{m:02d}-01" for m in range(1, 9)]
N = len(MONTHS)


def lin(a: float, b: float, i: int) -> float:
    """Linear path from a (i=0) to b (i=N-1)."""
    return a + (b - a) * i / (N - 1)


def jit(key: str, i: int, amp: float) -> float:
    """Tiny deterministic wobble that is exactly 0 at both endpoints."""
    if i == 0 or i == N - 1:
        return 0.0
    h = (hash((key, i)) % 1000) / 1000.0 - 0.5
    return h * amp


# ---------------------------------------------------------------------------
# 1. Region-level share + volume (brand_performance_monthly)
# ---------------------------------------------------------------------------
# region: (market weight, actual share Jan, actual share Aug, plan share,
#          prior-year share Jan, prior-year share Aug)
REGIONS = {
    "Northeast":  (0.20, 19.5, 19.30, 19.3, 18.9, 19.3),
    "Southeast":  (0.18, 19.4, 17.74, 18.9, 18.7, 19.1),
    "Midwest":    (0.17, 19.6, 19.40, 19.2, 19.0, 19.4),
    "Texas":      (0.15, 21.0, 15.34, 19.0, 19.3, 19.6),
    "West":       (0.20, 20.5, 18.42, 19.5, 18.8, 19.2),
    "Mountain":   (0.10, 19.2, 19.20, 18.8, 18.6, 19.0),
}

TARGET_TRX_YTD = 38_400_000        # brand TRx Jan-Aug
TARGET_TRX_VS_PLAN = 1.06          # +6% vs volume plan
MARKET_GROWTH_TOTAL = 0.088        # actual market grows ~8.8% Jan->Aug

# Solve the market level so brand TRx YTD lands exactly on target.
share_by = {
    r: [lin(a, b, i) + jit(r, i, 0.06) for i in range(N)]
    for r, (_, a, b, _, _, _) in REGIONS.items()
}
base = 1.0
market_path = [base * (1 + MARKET_GROWTH_TOTAL) ** (i / (N - 1)) for i in range(N)]
unit_brand = sum(
    REGIONS[r][0] * market_path[i] * share_by[r][i] / 100.0
    for r in REGIONS for i in range(N)
)
MARKET_JAN = TARGET_TRX_YTD / unit_brand          # national market TRx in Jan

rows_perf = []
for i, m in enumerate(MONTHS):
    for r, (w, _, _, plan, py_a, py_b) in REGIONS.items():
        market = MARKET_JAN * market_path[i] * w
        share = share_by[r][i]
        brand = market * share / 100.0
        plan_market = MARKET_JAN * 0.988 * w      # plan assumed a flatter market
        plan_brand = plan_market * plan / 100.0
        rows_perf.append({
            "month": m, "region": r,
            "brand_trx": round(brand), "market_trx": round(market),
            "plan_share_pct": round(plan, 2),
            "prior_year_share_pct": round(lin(py_a, py_b, i) + jit("py" + r, i, 0.05), 2),
            "plan_brand_trx": round(plan_brand),
        })

# Scale plan volume so YTD actual / YTD plan = +6.0% exactly.
tot_actual = sum(r["brand_trx"] for r in rows_perf)
tot_plan = sum(r["plan_brand_trx"] for r in rows_perf)
k = (tot_actual / TARGET_TRX_VS_PLAN) / tot_plan
for r in rows_perf:
    r["plan_brand_trx"] = round(r["plan_brand_trx"] * k)

# ---------------------------------------------------------------------------
# 2. Key-account panel (account_performance_monthly)
# ---------------------------------------------------------------------------
# name: (metro, region, share Jan, share change pts Jan->Aug, market TRx Aug,
#        exposed_campaign, prescribing_shift, competitor_claim_note,
#        treatment_choice_notes, competitor_engaged)
ACCOUNTS = {
    "ACC-001": ("Lakeside Oncology Partners",   "Dallas-Fort Worth", "Texas", 22.4, -7.2, 2850, 1, 1, 0, 1, 1),
    "ACC-002": ("North Texas Cancer Care",      "Dallas-Fort Worth", "Texas", 21.8, -6.4, 2430, 1, 1, 1, 1, 1),
    "ACC-003": ("Grapevine Hematology",         "Dallas-Fort Worth", "Texas", 20.9, -5.9, 1980, 1, 1, 0, 1, 1),
    "ACC-004": ("Trinity Valley Oncology",      "Dallas-Fort Worth", "Texas", 21.2, -5.1, 1760, 1, 1, 1, 1, 1),
    "ACC-005": ("Denton Community Cancer",      "Dallas-Fort Worth", "Texas", 20.4, -4.6, 1540, 1, 0, 1, 1, 1),
    "ACC-006": ("Plano Hematology Associates",  "Dallas-Fort Worth", "Texas", 20.7, -4.1, 1350, 1, 1, 0, 1, 1),
    "ACC-007": ("Fort Worth Cancer Specialists","Dallas-Fort Worth", "Texas", 19.8, -2.8, 1120, 1, 1, 1, 1, 1),
    "ACC-008": ("Arlington Oncology Group",     "Dallas-Fort Worth", "Texas", 19.5, -2.2,  960, 1, 0, 1, 0, 0),
    "ACC-009": ("Irving Hematology Center",     "Dallas-Fort Worth", "Texas", 19.9, -1.7,  870, 1, 0, 0, 0, 0),
    "ACC-010": ("Southlake Cancer Center",      "Dallas-Fort Worth", "Texas", 20.1,  0.3, 1210, 0, 0, 0, 1, 0),
    "ACC-011": ("McKinney Oncology Associates", "Dallas-Fort Worth", "Texas", 19.6, -0.2, 1040, 0, 0, 0, 0, 0),
    "ACC-012": ("Rockwall Oncology",            "Dallas-Fort Worth", "Texas", 19.3,  0.4,  680, 0, 0, 0, 0, 0),
    "ACC-013": ("Houston Oncology Consultants", "Houston",   "Texas",     20.2,  0.2, 2610, 1, 0, 0, 0, 1),
    "ACC-014": ("Austin Hematology Partners",   "Austin",    "Texas",     19.7, -0.3, 1490, 0, 0, 0, 1, 0),
    "ACC-015": ("Atlanta Cancer Institute",     "Atlanta",   "Southeast", 19.9,  0.1, 2280, 1, 0, 0, 0, 1),
    "ACC-016": ("Chicago Oncology Partners",    "Chicago",   "Midwest",   19.8, -0.1, 2340, 0, 0, 0, 1, 0),
    "ACC-017": ("Phoenix Hematology",           "Phoenix",   "Mountain",  19.4,  0.3, 1180, 0, 0, 0, 0, 0),
    "ACC-018": ("Boston Cancer Specialists",    "Boston",    "Northeast", 20.0,  0.5, 1930, 0, 0, 0, 0, 0),
    "ACC-019": ("Nashville Oncology Group",     "Nashville", "Southeast", 19.5, -0.2, 1370, 1, 0, 0, 0, 1),
    "ACC-020": ("Denver Cancer Care",           "Denver",    "Mountain",  19.6,  0.2, 1150, 0, 0, 0, 0, 0),
    "ACC-021": ("Sacramento Oncology Associates","Sacramento","West",     19.8,  0.1, 1260, 1, 0, 0, 0, 0),
    "ACC-022": ("Charlotte Cancer Center",      "Charlotte", "Southeast", 19.7,  0.3, 1090, 0, 0, 0, 1, 0),
}
DECLINING = [a for a, v in ACCOUNTS.items() if v[4] <= -0.5]           # 9
STEADY = [a for a, v in ACCOUNTS.items() if v[4] > -0.5]               # 13

rows_acct = []
for i, m in enumerate(MONTHS):
    for acc, (name, metro, region, s0, dpts, mkt_aug, *_rest) in ACCOUNTS.items():
        share = lin(s0, s0 + dpts, i) + jit(acc, i, 0.15)
        market = round(mkt_aug * (0.97 + 0.03 * i / (N - 1)) + jit("m" + acc, i, 8))
        rows_acct.append({
            "month": m, "account_id": acc, "account_name": name,
            "metro": metro, "region": region,
            "brand_trx": round(market * share / 100.0),
            "market_trx": market,
        })

# ---------------------------------------------------------------------------
# 3. Competitor activity (competitor_activity_monthly)
# ---------------------------------------------------------------------------
rows_comp = []
for i, m in enumerate(MONTHS):
    for acc, (name, metro, region, s0, dpts, mkt, exposed, shift, claim, tcq, engaged) in ACCOUNTS.items():
        if engaged:
            sov = lin(20.6, 20.6 + 4.9, i)         # heavy push in engaged accounts
        else:
            sov = lin(20.4, 20.4 + 0.35, i)        # background drift elsewhere
        sov += jit("sov" + acc, i, 0.2)
        campaign_on = 1 if (exposed and i >= 2) else 0   # campaign starts Mar'26
        comp_calls = (6 + (3 if engaged else 0) + (2 if campaign_on else 0)
                      + (hash(("cc", acc, i)) % 3))
        our_calls = 8 + (hash(("oc", acc, i)) % 5)       # similar in BOTH cohorts
        rows_comp.append({
            "month": m, "account_id": acc,
            "competitor_sov_pct": round(sov, 2),
            "exposed_earlier_line_campaign": campaign_on,
            "competitor_field_calls": comp_calls,
            "competitor_speaker_programs": (1 if (engaged and i % 2 == 0) else 0),
            "our_field_calls": our_calls,
        })

# Calibrate panel-average SOV rise to +2.1 pts exactly: solve the engaged-path
# endpoint. n_eng/22*x + (22-n_eng)/22*0.35 = 2.1
_n_eng = sum(1 for v in ACCOUNTS.values() if v[10])
_x = (2.1 * len(ACCOUNTS) - (len(ACCOUNTS) - _n_eng) * 0.35) / _n_eng
for r in rows_comp:
    acc = r["account_id"]
    engaged = ACCOUNTS[acc][10]
    i = MONTHS.index(r["month"])
    base_sov = 20.6 if engaged else 20.4
    rise = _x if engaged else 0.35
    r["competitor_sov_pct"] = round(lin(base_sov, base_sov + rise, i) + jit("sov" + acc, i, 0.2), 2)

# ---------------------------------------------------------------------------
# 4. New patient starts by segment (new_patient_starts_monthly)
# ---------------------------------------------------------------------------
SEGMENTS = ["2L relapsed", "3L+ relapsed"]
rows_starts = []
for i, m in enumerate(MONTHS):
    for acc, (name, metro, region, s0, dpts, mkt, exposed, shift, *_r) in ACCOUNTS.items():
        scale = mkt / 1500.0
        for seg in SEGMENTS:
            seg_k = 1.0 if seg == "2L relapsed" else 0.6
            brand = 10 * scale * seg_k * (1 - (0.18 if dpts <= -0.5 else 0.0) * i / (N - 1))
            comp = 9 * scale * seg_k
            if shift:                     # prescribing-shift accounts: comp starts surge
                growth = 0.45 if seg == "2L relapsed" else 0.18
                comp *= 1 + growth * max(0, i - 1) / (N - 2)
            else:
                comp *= 1 + 0.04 * i / (N - 1)
            rows_starts.append({
                "month": m, "account_id": acc, "segment": seg,
                "brand_starts": max(0, round(brand + jit("bs" + acc + seg, i, 0.8))),
                "competitor_starts": max(0, round(comp + jit("cs" + acc + seg, i, 0.8))),
            })

# ---------------------------------------------------------------------------
# 5. Field notes (field_notes)
# ---------------------------------------------------------------------------
TCQ_TEXTS = [
    "Lead hematologist asked how to sequence {b} for a relapsed 2L patient already exposed to a proteasome inhibitor; wanted comparative PFS data before committing.",
    "2L-focused prescriber raised treatment-choice questions: unsure whether to keep {b} frontline of the relapsed setting or trial the newer regimen first.",
    "Discussion centered on 3L+ patients; prescriber asked which sequence preserves later-line options and how {b} fits if {c} is used earlier.",
    "Prescriber asked for guidance choosing between {b}-based triplet and competing regimen for transplant-ineligible relapsed patients.",
]
CLAIM_TEXTS = [
    "Prescriber repeated {c} rep claims about earlier-line data and convenience dosing; asked whether our label supports the same setting.",
    "Office quoted the {c} 'earlier is better' leave-behind; requested our response deck on relapsed 2L outcomes.",
]
ROUTINE_TEXTS = [
    "Routine access review with practice manager; prior-auth turnaround stable, no clinical objections raised.",
    "Dropped updated dosing materials; brief exchange with infusion lead, no new questions.",
    "Reviewed patient-support program enrollment with staff; positive feedback on copay support.",
    "Quarterly business review with pharmacy director; formulary position unchanged.",
]
# flagged-note plan, tuned so the cohort note shares land ~58% (losing) vs
# ~24% (steady): flagged decliners get 4 of 5 TCQ notes (first five) or 3 of 5;
# flagged steady accounts get 3 of 4; others 0 flagged.
rows_notes = []
nid = 0
for acc, (name, metro, region, s0, dpts, mkt, exposed, shift, claim, tcq, engaged) in ACCOUNTS.items():
    losing = dpts <= -0.5
    n_notes = 5 if losing else 4
    if tcq and losing:
        n_tcq = 4 if acc <= "ACC-005" else 3
    elif tcq:
        n_tcq = 3
    else:
        n_tcq = 0
    n_claim = 1 if claim else 0
    for j in range(n_notes):
        nid += 1
        i = (j * 2 + (1 if losing else 3)) % N
        if j < n_tcq:
            text = TCQ_TEXTS[(nid + j) % len(TCQ_TEXTS)]
            is_tcq, is_claim = 1, 0
        elif j < n_tcq + n_claim and losing:
            text = CLAIM_TEXTS[nid % len(CLAIM_TEXTS)]
            is_tcq, is_claim = 0, 1
        else:
            text = ROUTINE_TEXTS[(nid + j) % len(ROUTINE_TEXTS)]
            is_tcq, is_claim = 0, 0
        rows_notes.append({
            "note_id": f"NOTE-{nid:04d}",
            "note_date": MONTHS[max(2, i)][:8] + f"{(nid % 27) + 1:02d}",
            "account_id": acc,
            "hcp_specialty": "Hematology/Oncology",
            "prescriber_line_focus": "2L" if (nid % 3) else "3L+",
            "note_text": text.format(b="DARZALEX", c="XELVORA"),
            "treatment_choice_question": is_tcq,
            "competitor_claim_mention": is_claim,
        })

# ---------------------------------------------------------------------------
# 6. Promotional spend (promo_spend_monthly)
# ---------------------------------------------------------------------------
CHANNELS = {  # plan YTD by channel (USD), actual = plan * overspend ramp
    "Field force":        46_500_000,
    "HCP media":          29_000_000,
    "Speaker programs":   17_500_000,
    "Congress & events":  11_800_000,
    "Digital & CRM":      17_500_000,
}
PLAN_YTD = sum(CHANNELS.values())            # 122.3M
TARGET_SPEND = 126_000_000                   # +3.0% vs plan
rows_spend = []
for i, m in enumerate(MONTHS):
    for ch, plan_ytd in CHANNELS.items():
        plan_m = plan_ytd / N
        ramp = 1.0 + (TARGET_SPEND / PLAN_YTD - 1.0) * (0.6 + 0.8 * i / (N - 1))
        rows_spend.append({
            "month": m, "channel": ch,
            "spend_usd": round(plan_m * ramp),
            "plan_usd": round(plan_m),
        })
# exact-total correction on the last month, spread across channels
_delta = TARGET_SPEND - sum(r["spend_usd"] for r in rows_spend)
for j, ch in enumerate(CHANNELS):
    for r in rows_spend:
        if r["month"] == MONTHS[-1] and r["channel"] == ch:
            r["spend_usd"] += _delta // len(CHANNELS) + (1 if j < _delta % len(CHANNELS) else 0)

# ---------------------------------------------------------------------------
# 7. Creative performance (creative_performance_monthly)
# ---------------------------------------------------------------------------
rows_creative = []
for i, m in enumerate(MONTHS):
    for variant, rate in (("CEPHEUS Now Approved", 4.8), ("Base efficacy", 3.4)):
        if variant.startswith("CEPHEUS") and i < 3:
            continue                          # new creative launched Apr'26
        imps = 1_800_000 + (hash(("imp", variant, i)) % 120_000)
        r = rate + jit("cr" + variant, i, 0.15)
        rows_creative.append({
            "month": m, "campaign": "DARZALEX HCP 2026",
            "creative_variant": variant,
            "impressions": imps,
            "hcp_engagements": round(imps * r / 100.0),
        })

# ---------------------------------------------------------------------------
# Write CSVs
# ---------------------------------------------------------------------------
FILES = {
    "brand_performance_monthly.csv": rows_perf,
    "account_performance_monthly.csv": rows_acct,
    "competitor_activity_monthly.csv": rows_comp,
    "new_patient_starts_monthly.csv": rows_starts,
    "field_notes.csv": rows_notes,
    "promo_spend_monthly.csv": rows_spend,
    "creative_performance_monthly.csv": rows_creative,
}
OUT.mkdir(parents=True, exist_ok=True)
for fname, rows in FILES.items():
    with open(OUT / fname, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {fname:38s} {len(rows):5d} rows")

# ---------------------------------------------------------------------------
# Verify the headlines with DuckDB (the same engine the agents use)
# ---------------------------------------------------------------------------
import duckdb  # noqa: E402

con = duckdb.connect(":memory:")
for fname in FILES:
    con.execute(
        f"CREATE VIEW {fname[:-4]} AS SELECT * FROM read_csv_auto('{(OUT / fname).as_posix()}')"
    )

def one(sql):
    return con.execute(sql).fetchone()

checks = []

share_aug, plan_aug = one("""
    SELECT 100.0*SUM(brand_trx)/SUM(market_trx),
           SUM(plan_share_pct*market_trx)/SUM(market_trx)
    FROM brand_performance_monthly WHERE month='2026-08-01'""")
checks.append(("national share Aug = 18.2", abs(share_aug - 18.2) < 0.06, f"{share_aug:.2f}"))
checks.append(("gap vs plan = -0.9 pts", abs((share_aug - plan_aug) + 0.9) < 0.07, f"{share_aug - plan_aug:+.2f}"))

share_jan, plan_jan = one("""
    SELECT 100.0*SUM(brand_trx)/SUM(market_trx),
           SUM(plan_share_pct*market_trx)/SUM(market_trx)
    FROM brand_performance_monthly WHERE month='2026-01-01'""")
checks.append(("Jan actual above plan", share_jan > plan_jan, f"{share_jan:.2f} vs {plan_jan:.2f}"))

trx, plan_trx = one("SELECT SUM(brand_trx), SUM(plan_brand_trx) FROM brand_performance_monthly")
checks.append(("brand TRx YTD = 38.4M", abs(trx - 38_400_000) < 60_000, f"{trx/1e6:.2f}M"))
checks.append(("TRx +6% vs plan", abs(trx / plan_trx - 1.06) < 0.004, f"{100*(trx/plan_trx-1):+.1f}%"))

tx_contrib, w_contrib, gap = one("""
    WITH g AS (SELECT region,
                 SUM(brand_trx) - SUM(plan_share_pct*market_trx/100.0) AS gap_trx
               FROM brand_performance_monthly WHERE month='2026-08-01' GROUP BY region),
         n AS (SELECT SUM(gap_trx) AS total FROM g)
    SELECT 100.0*(SELECT gap_trx FROM g WHERE region='Texas')/n.total,
           100.0*(SELECT gap_trx FROM g WHERE region='West')/n.total,
           n.total FROM n""")
checks.append(("Texas ~61% of gap", 58 <= tx_contrib <= 64, f"{tx_contrib:.1f}%"))
checks.append(("West ~24% of gap", 20 <= w_contrib <= 28, f"{w_contrib:.1f}%"))
checks.append(("national gap negative", gap < 0, f"{gap:,.0f} TRx"))

n_decl, n_panel = one("""
    WITH s AS (SELECT account_id,
        100.0*SUM(CASE WHEN month='2026-08-01' THEN brand_trx END)/SUM(CASE WHEN month='2026-08-01' THEN market_trx END)
      - 100.0*SUM(CASE WHEN month='2026-01-01' THEN brand_trx END)/SUM(CASE WHEN month='2026-01-01' THEN market_trx END) AS chg
      FROM account_performance_monthly
      WHERE account_id IN (SELECT account_id FROM account_performance_monthly WHERE metro='Dallas-Fort Worth')
      GROUP BY account_id)
    SELECT COUNT(*) FILTER (chg < -0.5), COUNT(*) FROM s
    WHERE account_id LIKE 'ACC-0%' AND account_id <= 'ACC-012'""")
checks.append(("9 of 12 DFW declining", (n_decl, n_panel) == (9, 12), f"{n_decl} of {n_panel}"))

lake = one("""
    SELECT 100.0*SUM(CASE WHEN month='2026-08-01' THEN brand_trx END)/SUM(CASE WHEN month='2026-08-01' THEN market_trx END)
         - 100.0*SUM(CASE WHEN month='2026-01-01' THEN brand_trx END)/SUM(CASE WHEN month='2026-01-01' THEN market_trx END)
    FROM account_performance_monthly WHERE account_name='Lakeside Oncology Partners'""")[0]
checks.append(("Lakeside -7.2 pts", abs(lake + 7.2) < 0.15, f"{lake:+.2f}"))

sov = one("""
    SELECT AVG(CASE WHEN month='2026-08-01' THEN competitor_sov_pct END)
         - AVG(CASE WHEN month='2026-01-01' THEN competitor_sov_pct END)
    FROM competitor_activity_monthly""")[0]
checks.append(("SOV +2.1 pts", abs(sov - 2.1) < 0.12, f"{sov:+.2f}"))

exp = one(f"""
    SELECT COUNT(DISTINCT account_id) FROM competitor_activity_monthly
    WHERE exposed_earlier_line_campaign=1 AND account_id IN ({','.join(repr(a) for a in DECLINING)})""")[0]
checks.append(("all 9 decliners campaign-exposed", exp == 9, f"{exp}"))

shift = one(f"""
    WITH g AS (SELECT account_id,
        SUM(CASE WHEN month='2026-08-01' THEN competitor_starts END)*1.0
      / NULLIF(SUM(CASE WHEN month='2026-01-01' THEN competitor_starts END),0) AS ratio
      FROM new_patient_starts_monthly WHERE segment='2L relapsed'
        AND account_id IN ({','.join(repr(a) for a in DECLINING)})
      GROUP BY account_id)
    SELECT COUNT(*) FILTER (ratio > 1.25) FROM g""")[0]
checks.append(("6 of 9 show competitor-start surge", shift == 6, f"{shift}"))

tcq_acc = one("""
    SELECT COUNT(DISTINCT account_id) FROM field_notes
    WHERE treatment_choice_question=1 AND account_id <= 'ACC-012'""")[0]
checks.append(("TCQ notes in 8 of 12 DFW accounts", tcq_acc == 8, f"{tcq_acc}"))

lose_pct, steady_pct = one(f"""
    SELECT 100.0*SUM(CASE WHEN account_id IN ({','.join(repr(a) for a in DECLINING)}) THEN treatment_choice_question END)
              / COUNT(CASE WHEN account_id IN ({','.join(repr(a) for a in DECLINING)}) THEN 1 END),
           100.0*SUM(CASE WHEN account_id NOT IN ({','.join(repr(a) for a in DECLINING)}) THEN treatment_choice_question END)
              / COUNT(CASE WHEN account_id NOT IN ({','.join(repr(a) for a in DECLINING)}) THEN 1 END)
    FROM field_notes""")
checks.append(("TCQ note share ~58% vs ~24%", abs(lose_pct - 58) < 10 and abs(steady_pct - 24) < 10,
               f"{lose_pct:.0f}% vs {steady_pct:.0f}%"))

claims = one("SELECT COUNT(DISTINCT account_id) FROM field_notes WHERE competitor_claim_mention=1")[0]
checks.append(("competitor claims in 5 accounts", claims == 5, f"{claims}"))

spend, plan_spend = one("SELECT SUM(spend_usd), SUM(plan_usd) FROM promo_spend_monthly")
checks.append(("spend YTD = $126.0M", spend == 126_000_000, f"${spend/1e6:.1f}M"))
checks.append(("spend +3% vs plan", abs(spend / plan_spend - 1.03) < 0.004, f"{100*(spend/plan_spend-1):+.1f}%"))

lift = one("""
    SELECT (SUM(CASE WHEN creative_variant LIKE 'CEPHEUS%' THEN hcp_engagements END)*1.0
          / SUM(CASE WHEN creative_variant LIKE 'CEPHEUS%' THEN impressions END))
         / (SUM(CASE WHEN creative_variant='Base efficacy' THEN hcp_engagements END)*1.0
          / SUM(CASE WHEN creative_variant='Base efficacy' THEN impressions END))
    FROM creative_performance_monthly""")[0]
checks.append(("CEPHEUS creative ~+40% lift", 1.30 < lift < 1.55, f"{100*(lift-1):+.0f}%"))

fails = 0
print("\n--- verification ---")
for label, ok, got in checks:
    print(f"{'PASS' if ok else 'FAIL'}  {label:42s} -> {got}")
    fails += 0 if ok else 1
print(f"--- {len(checks) - fails}/{len(checks)} checks passed ---")
sys.exit(1 if fails else 0)
