# Compile demo

Business prose in, an executable rulebook and play out, staged for a
person to approve. **Start here: [WALKTHROUGH.md](WALKTHROUGH.md)** —
seven steps, one file of setup, one command to run.

| File | Use |
|---|---|
| `WALKTHROUGH.md` | The guide: check, set up, compile, read the result |
| `deliveries.yaml` | The one setup file — declares how actions reach the world |
| `sample.playbook.txt` | The business prose to compile |
| `../compile_catalogs/*.json` | A captured catalog set, to show on screen while explaining what the compiler is handed |

One command, once the workspace is selected:

```cmd
aicore run playbook_compile --goal-file demo\compile_only\sample.playbook.txt --driver code --follow
```

## The engine's own guide supersedes this kit

The engine now ships a from-scratch compile-only walkthrough at
`docs/examples/compile-only/01-compile-walkthrough.md` (in the
`ai-core-harness-engine` repository), together with a `workflows.yaml`
that DECLARES the workflows the compiler may name on a machine that
cannot install the workspace repo - the capability this kit had to work
around. Prefer that guide; this folder keeps the brand-marketing prose,
the deliveries file and the captured catalogs for the demo narrative.
