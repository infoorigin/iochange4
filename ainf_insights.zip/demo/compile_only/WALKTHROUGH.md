# Compile walkthrough — business prose to an executable playbook

Ten minutes, seven steps. A playbook written in plain business language
goes in; a rulebook, a play and a list of assumptions come out, staged
for a named person to approve. Nothing runs before that approval.

Commands are `cmd`; they work unchanged in PowerShell and bash. Every
"expected" block below is real output from a rehearsal.

---

## 1. Point at the workspace

```cmd
set IOF_WORKSPACE=<code>
aicore current
```

```text title="expected"
workspace: <code>  -  db: postgresql@<host>/<db> (<schema>)
```

The workspace's `.env` supplies the database and the state directory. If
`aicore current` cannot name a workspace, select one first
(`aicore workspace use <code>`).

## 2. Check what the compiler will be able to name

```cmd
aicore list-workflows
```

```text title="expected (an extract)"
│ brand_share_response   │ The analysis half of the brand share-loss ...
│ barrier_detection      │ Barrier Detection and Insight Generation ...
```

The workflow your playbook needs must be listed. This list comes from
the packs installed **in this engine's virtual environment** — not from
the workspace name — and the compiler is given exactly this list.

## 3. Check how an action can reach the world

```cmd
iof-case deliveries
```

If this prints `source: none`, do step 4. If it already lists delivery
kinds, skip to step 5.

## 4. Declare the delivery capabilities (the only setup)

```cmd
copy demo\compile_only\deliveries.yaml %USERPROFILE%\.iobot\workspaces\%IOF_WORKSPACE%\deliveries.yaml
iof-case deliveries
```

```text title="expected"
source: workspace:...\workspaces\<code>\deliveries.yaml
  email              mcp_pharma_send_field_email
  monitoring_task    mcp_pharma_create_monitoring_task
  verification       mcp_pharma_get_rep_alignment
  system_of_record   mcp_hub_record_decision
@deliveries expands to: mcp_pharma_send_field_email, ...
```

Edit the file to name your deployment's own tools and the roles an email
may address. The file **is** the `{kind: entry}` mapping — there is no
`deliveries:` key above it.

## 5. Read the business text (optional, 1 minute)

```cmd
type demo\compile_only\sample.playbook.txt
```

Plain language, written by a brand team: no states, no events, no rules.
Worth showing on screen — the contrast with step 7 is the whole point of
the demo.

## 6. Compile it

```cmd
aicore run playbook_compile --goal-file demo\compile_only\sample.playbook.txt --driver code --follow
```

Use `--goal-file`. A playbook is longer than a command line, and pasting
one inline fails differently in every shell.

```text title="expected, while it runs"
Run run_20260901_235633_983688  status=running  workflow=playbook_compile
┌─────┬──────────┬───────────────┬─────────┬─────────┐
│ seq │ step_key │ role          │ status  │ attempt │
├─────┼──────────┼───────────────┼─────────┼─────────┤
│ 1   │ catalog  │ system        │ done    │ 1/2     │
│ 2   │ match    │ play_operator │ done    │ 1/2     │
│ 3   │ compile  │ play_operator │ running │ 1/3     │
└─────┴──────────┴───────────────┴─────────┴─────────┘
```

Five to eight minutes. `--follow` streams each step's reasoning to the
console; `catalog` is deterministic (no model), `match` decides which
capability serves each requirement, `compile` drafts and validates.

## 7. Read the result

Everything is in `<IOF_ROOT>\instances\<run_id>\project\`.

**What the compiler was allowed to name:**

```cmd
type <run_dir>\project\workflow_catalog.json
```

**How it mapped the prose to those capabilities:**

```cmd
type <run_dir>\project\capability_map.json
```

```text title="expected shape"
requirement: "Run the share analysis to establish whether the loss ..."
capability : {"type": "workflow", "name": "brand_share_response"}
why        : "the workflow's description says it establishes whether a
              share loss is real, isolated and material"
```

A good result on a configured workspace: **17 requirements mapped** —
1 workflow, 6 email, 5 flow, 2 system-of-record, 1 open-play — and
**zero** capability requests.

**The executable form, and the receipt:**

```cmd
type <run_dir>\project\draft_rulebook.json
type <run_dir>\project\compile_receipt.json
```

```text title="expected"
compile_id: CMP-0002   status: hitl_pending
template_id: TPL-BRAND-SHARE-LOSS   play_id: PLAY-BRAND-SHARE-LOSS-001
rulebook: 9 states, 17 rules, 8 actions
```

`hitl_pending` is the point: the compiler stages, a person approves.

**What it refused to invent:**

```cmd
type <run_dir>\project\capability_requests.json
type <run_dir>\project\compile_notes.md
```

Empty requests means the workspace could serve every requirement. Any
entry names something the deployment cannot do — recorded for a human,
never drafted as a step that would fail at run time.

---

## What to say, in four lines

1. *"Before it reads a word, the compiler is told what this workspace can
   do."* → `workflow_catalog.json`
2. *"It may only name what is on that list — and the validator enforces
   the same list."* → `capability_map.json`
3. *"It matches on what a capability does, not on shared words."* → read
   a description beside a sentence of the playbook.
4. *"What the workspace cannot do is recorded, not improvised."* →
   `capability_requests.json`

## If something looks wrong

| Symptom | Cause |
|---|---|
| Every requirement becomes a capability request | Deliveries not declared (step 4), or the workflow is not installed in this venv (step 2) |
| `@deliveries expands to: (nothing)` | The yaml is wrapped in a `deliveries:` key — the file **is** the mapping |
| Few or unfamiliar workflows in the catalog | The catalog follows the engine venv's installed packs, not the workspace name |
| `Got unexpected extra argument(s)` | The goal was passed inline instead of with `--goal-file` |
| A step retries | Normal. The harness absorbs transient failures; let it converge |
