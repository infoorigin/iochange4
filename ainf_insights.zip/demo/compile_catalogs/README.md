# Compile-demo catalogs — what the compiler is handed

Four files, captured from a configured workspace, so a demo can open them
on screen and go straight to the compile step without waiting for a run.

| File | What it shows |
|---|---|
| `workflow_catalog.json` | 9 workflows this workspace can commission — including `barrier_detection` and `brand_share_response` — each with the description the compiler matches against |
| `deliveries_catalog.json` | The four delivery kinds available here (`email`, `monitoring_task`, `verification`, `system_of_record`), their tools and addressable roles |
| `plays_catalog.json` | The 16 operational plays already installed |
| `compile_history.json` | Previous compilations and the reason each rejection was refused |

## How to use them in the demo

**They are for showing, not for feeding.** The compile workflow's first
step regenerates all four from the live deployment every run — that is
the point of it, and it cannot be skipped or pre-seeded. Open these while
you explain what the compiler was allowed to name, then start the compile
and let its own `catalog` step produce the real ones.

The narrative they support, in one line each:

1. *"Before the compiler reads a word, it is told what this workspace can
   do."* → `workflow_catalog.json`
2. *"It can only name capabilities on that list."* → point at
   `barrier_detection` and its description.
3. *"Matching is on what a capability does, not on shared words."* → read
   one description aloud beside a sentence from the business playbook.
4. *"What the workspace cannot do is recorded, not invented."* →
   `capability_requests.json` in the finished run.

## Minimum setup for a good compile demo

The catalogs are a function of **the engine venv's installed packs** and
**the workspace's declared deliveries** — not of the workspace name. Two
things must be true, and nothing else:

```bash
# 1. the solution pack is installed in the engine's venv
aicore list-workflows          # the workflows you intend to demo appear here

# 2. deliveries resolve for the workspace
iof-case deliveries            # kinds listed, and "source" is not "none"
```

If `list-workflows` is short, the pack is not installed **in that venv** —
the most common cause, because the catalog uses the same resolver a run
does. If `iof-case deliveries` reports `source: none`, every action in the
compiled draft becomes a capability request instead of a delivery, and the
demo shows the compiler correctly refusing to invent one.

## Regenerating them

From any machine, against the workspace you intend to demo:

```bash
export IOF_WORKSPACE=<workspace>
iof-plays workflows       --out workflow_catalog.json
iof-case  deliveries      --out deliveries_catalog.json
iof-plays list            --out plays_catalog.json
iof-plays compile-history --out compile_history.json
```

Those are the four commands the compile workflow's `catalog` step runs.
Captured 2026-09-01 from workspace `ainf2demo`.
