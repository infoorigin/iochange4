# Memory governance — who writes it, what gets stored, and how you control it

The two client questions this answers: *who and how are values added to
memory, and where are they stored?* and *how do I control WHAT is stored
— keep a user's name and address, never an account balance?*

The one-sentence answer, demonstrated live on this deployment: **nothing
enters memory without a human approving it.** After ten pipeline runs
and every chat session, this workspace holds **118 draft candidates and
0 active memories** — the agents have seen none of them, because the
default posture (`review`) makes every candidate a proposal, not a fact.

## Who writes memory, and how (the pipeline)

No agent writes memory directly — an agent's own "remember this" has no
path to storage. Candidates are produced by a governed pipeline that
runs AFTER work completes:

```
run reaches done / chat session ends
  → extraction (what durable facts did this surface?)
  → deterministic rails, in code not judgement:
      - conclusions/findings dropped (memory stores context, not results)
      - PII redaction (emails, phone numbers, long identifiers)
      - security scan (an injected instruction cannot ride a memory)
  → DRAFT rows, awaiting review          ← everything stops here
  → a person approves → ACTIVE (agents now see it)
```

A curated tier also exists: facts your team writes deliberately
(`aicore memory add`, or files in the repo's `memory/` directory) —
same review flow, same storage.

## Where it is stored, and the audit trail

Postgres, in the workspace's platform schema:

| Table | Holds |
|---|---|
| `workspace_memory` | every row with status (`draft/active/superseded/removed/rejected`), scope (workspace / role / user / solution), kind, ORIGIN (which run or chat produced it), and `source_at` (when its source happened) |
| `workspace_memory_history` | every transition — who approved, rejected, or removed what, when |
| `workspace_memory_runs` | the consolidation ledger (exactly-once per run, across pods) |

Every value is traceable to the run or conversation that produced it,
and every acceptance to the person who made it.

## The controls, as commands

```bash
aicore memory status              # posture + counts (the 118/0 above)
aicore memory pending             # review queue: id, scope, origin, the fact
aicore memory show <id>           # one candidate in full
aicore memory approve <id>        # a person promotes it - only now do agents see it
aicore memory reject <id>         # refuse, on the record
aicore memory forget <id>         # retire an ACTIVE memory, on the record
aicore memory history             # the audit trail
aicore memory posture             # review (default) vs auto
```

Scopes narrow exposure: a `user/<id>` memory reaches only that user's
sessions; a `solution/<code>` row reaches only that solution's runs — so
even an approved fact is visible only where it belongs.

## "Name and address yes, account balance no" — the policy answer

Today, three layers deliver that control:

1. **The review gate** (default): a balance can be *proposed* but never
   *stored-and-seen* — the reviewer rejects it, on the record. This is
   the operative control, and it is absolute.
2. **The built-in rails** already drop whole classes before review:
   session-specific figures and conclusions are dropped in code
   (memory stores durable context, never results), and PII patterns are
   redacted.
3. **Curation**: for the strictest posture, disable extraction
   (`IOF_MEMORY_EXTRACTOR=off`) and populate memory only through the
   curated tier — memory then contains exactly what your team wrote.

What does NOT exist yet: a per-workspace **declarative deny-pattern**
("anything matching a currency amount is dropped before it ever reaches
the review queue"). That is filed as a platform change
(`CLIENT_FEEDBACK_BACKLOG.md`, F7-MR): a workspace-tier policy file
applied inside the deterministic rails, with each drop recorded in the
audit trail. Until it lands, the review gate is the enforcement point —
and with 0-active-until-approved semantics, it is a complete one.
