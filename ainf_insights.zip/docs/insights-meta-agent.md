# Pulse — the insights meta agent (`insights_meta`)

The single face the front end talks to. Every user question about brand
performance goes to one endpoint; the front end never routes to workflow
agents or knows where an answer lives.

## Surface — the platform's generic chat route, nothing added

**No new endpoint exists for this agent, and no platform code carries any
domain.** The front end uses the engine's standard ad-hoc chat route,
`POST /api/chat/{namespace}` — the path segment is only a chat-history
namespace (`GET /api/chat/{namespace}/messages` reads it back), and the
agent is selected by the `agent` field in the body. Platform convention is
namespace = the agent role:

```
POST /api/chat/insights_meta
{ "agent": "insights_meta", "content": "<question>", "user_id": "web:<user>",
  "format": "viz_envelope" | null }
```

Everything domain-specific lives in this workspace pack. Exposure is
declared there too: `agents/insights_meta/workspace/a2a-card.yaml` has
`expose: true`, so `aicore serve` mounts Pulse into the always-on pool at
startup — no env var, no deployment change, no route registration. The
platform's generic A2A surface then serves the card-declared agent at
`GET /a2a/insights_meta/.well-known/agent-card.json` and
`POST /a2a/insights_meta` (a parameterized route over pool roles, not a
per-agent registration).

## Three answer tiers (the `insights_navigator` skill)

| Tier | Source | Mechanism | When |
|---|---|---|---|
| 1 | Persisted run insights | `aicore run-output --run-id <id> --root <state_root> --file dashboard_insights.json` (also the reports, `--grep` for narrow questions) | Default — the reviewed payload answers most questions and outranks recomputation |
| 2 | The commercial catalog | `iof-query --db commercial --metadata-dir metadata` against the catalog configured into its workspace | A cut the run did not publish (other month/region/account) |
| 3 | The workflow agents | `aicore agent-chat --role <role> --run-id <id> --workspace <ws> --url <engine_url> -m "..."` | Reasoning/depth questions ("why did the strategist rank this first?") — expensive, one per turn |

Run resolution: the front end passes a run id in the message; with none,
Pulse uses the latest directory under `<state_root>/instances` (run ids sort
by timestamp) and says which run it answered from. Every answer names its
tier and source.

## Response formats (per request, not per agent)

- **Default — markdown**: chat-panel prose, answer first, source line last
  (the `response_style` skill is the agent's one output contract; this agent
  never runs workflow steps, so it carries no `output_protocol`).
- **`format: "viz_envelope"`** — the platform's built-in structured envelope, engine-
  injected, schema-validated with bounded retry, and extracted server-side:
  `{schema:"v1", answer, data, insight, viz_hint, follow_up_chips, evidence}`
  — answer + data + viz hint + summary insight for programmatic rendering.
- Further named formats can be added later as `output_format:` skills
  (always:false) with a JSON-Schema block — the K6 registry resolves them per
  request from the agent's workspace.

## Deployment wiring (per environment, not in skills)

1. `aicore configure-agent insights_meta <workflow>/metadata --force` with the
   workspace env (IOF_ROOT / IOF_AGENT_HOME) supplied — copies
   catalog/databases/data into the agent home; the identity refresh re-embeds
   the catalog into `catalog_reader` on every use.
   (Its validator warns `source_path ... not found` for the
   `data/<file>.csv` convention — it checks against the workspace root while
   iof-query resolves against the metadata dir; the queries work, verified.)
2. Write `<home>/workspace/metadata/deployment.yaml` with `workspace`,
   `state_root`, `engine_url` — the navigator reads deployment facts from
   there, so pack skills stay portable.

## Known limits

- Tier 3 posts to the engine's own `/api/run/{id}/message`; a multi-pod
  deployment should point `engine_url` at the service address.
- Tier 1 needs the run's artifacts on this pod's state root (or S3 recovery
  configured).
