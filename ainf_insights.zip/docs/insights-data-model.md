# The insights data model (`ainf_data`)

The persisted, run-linked, NLQ-queryable output of the `brand_insights`
pipeline. Written ONLY by `iof-ainf_insights-insights_store` (a validating
tool at the end of every run); read by the workbench, by Pulse's NLQ tier,
and by anyone with SQL.

```
insight_runs 1 ──── * insights 1 ──── * insight_evidence
                        │  (self-FK: parent_insight_id)
                        └──────────── * insight_accounts
```

## Design decisions, and why

**1. Hybrid relational + JSONB.** Every card persists twice, deliberately:
a **queryable spine** in columns and the **verbatim card** in `payload`
jsonb. The spine carries exactly what a freehand NLQ filters, joins and
ranks on — `brand`, `kind`, `confidence_pct`, `verdict`, `rank`,
`headline`, `run_id` — so no natural-language question has to reach into
JSON. The payload keeps full rendering fidelity (trend arrays, summaries,
deltas), so the dashboard rebuilds a card from one row and a new card field
ships with zero DDL.

**2. `run_id` is the lineage key, and the dig-deeper anchor.**
`insight_runs.run_id` IS the platform's run id. Every child row carries it,
so "use this run as context" is a WHERE clause, and the same id still opens
the run's artifacts (`aicore run-output`) and its live agent session
(`agent-chat --run-id`) — one identifier, three depths of digging.

**3. The hierarchy is a self-FK, because the dashboard's is.** Drivers,
comparisons, actions and the priority-account set nest under their
opportunity exactly as the workbench nests cards — `parent_insight_id`
models that directly, `rank` preserves display order, and one recursive (or
two-level) join re-assembles a card tree.

**4. `kind` is a CHECK-constrained enum of the card vocabulary**
(`kpi | opportunity | driver | comparison | priority_account_set | action |
not_recommended | diagnosis`). `not_recommended` is first-class: the
exculpatory finding is queryable, not a footnote — "what have we ruled
out?" is a one-liner.

**5. Evidence is normalized out.** `insight_evidence` holds source +
finding + the exact `query_sql` per claim, so "show me the SQL behind
driver X" is a row lookup, and evidence density per insight is measurable
(a governance signal). Sources are typed by convention: a table name, a
`computed_metrics:<id>` reference, or `creative_intel MCP`.

**6. `brand` is denormalized onto `insights`.** It is the first filter of
almost every NLQ; paying one redundant column beats joining `insight_runs`
on every question. The store writes both from one value, so they cannot
drift within a run.

**7. Idempotency is replace-by-run, transactionally.** Re-persisting a run
deletes its row (children cascade) and re-inserts in one transaction: no
partial mixes of two versions, and re-running `persist` is safe.

**8. The insights tables are never dropped.** The source-data loader
recreates the SOURCE tables at will; the insights DDL is `IF NOT EXISTS`
only, because these rows are run history.

## Indexes

`(brand, generated_at DESC)` on runs — "latest run for brand".
`(run_id)`, `(brand, kind)`, `(kind, confidence_pct DESC)`,
`(parent_insight_id)` on insights — the four NLQ access paths.

## The queries the model was designed for

```sql
-- what did a run conclude?
SELECT kind, rank, headline, confidence_pct, verdict
FROM ainf_data.insights WHERE run_id = :run ORDER BY kind, rank;

-- top drivers for a brand, latest first
SELECT r.run_id, i.headline, i.confidence_pct
FROM ainf_data.insights i JOIN ainf_data.insight_runs r USING (run_id)
WHERE i.brand='DARZALEX' AND i.kind='driver' AND i.confidence_pct >= 80
ORDER BY r.generated_at DESC, i.rank;

-- the evidence (and its SQL) behind one driver
SELECT e.source, e.finding, e.query_sql, e.n, e.of_total
FROM ainf_data.insight_evidence e WHERE e.insight_id = :id;

-- has the field-contact verdict ever changed?
SELECT r.run_id, r.generated_at, i.verdict
FROM ainf_data.insights i JOIN ainf_data.insight_runs r USING (run_id)
WHERE i.kind='comparison' AND i.headline ILIKE '%field%'
ORDER BY r.generated_at;
```

DDL: `sql/insights_schema.sql`. Writer: `tools/insights_store.py`.
Catalog entries (for NLQ): the four `insight_*` entities in the workflow's
`metadata/catalog.yaml`.

## The computed-metrics tier (comprehensive extension)

Three tables close the gap between "the run computed it" and "you can
query it": every dashboard chart becomes SQL-renderable rows, and every
metric a cross-run time series.

```
insight_runs 1 ──ALSO── * run_metrics 1 ── * run_metric_points
             1 ──────── * run_hypotheses
```

- **`run_metrics`** — one row per (run, metric): title, unit, shape, the
  scalar record in `value` jsonb, and the EXACT `query_sql`. "How has the
  share gap moved run over run?" is a two-table join.
- **`run_metric_points`** — series metrics as ordered points, with the
  four domain dimensions PROMOTED to real columns (`month`, `region`,
  `account_name`, `segment`) and the measures in `vals` jsonb. The
  workbench's share/TRx/spend trend charts, the region-contribution bars
  and the ranked-account list all read straight from here — one WHERE
  clause per chart.
- **`run_hypotheses`** — the configured-hypothesis audit: armed / cleared /
  external per run, with the `arm_when` SQL on record. "When did the
  field-contact hypothesis first arm?" is a cross-run one-liner.

Written by the SAME store tool, in the SAME transaction, from the compute
step's artifact (`--metrics computed_metrics.json` on the persist command)
— so a persisted run is always whole: cards, evidence, accounts, metrics,
points and verdicts together, replace-by-run. A metric that ERRORED in the
compute step is deliberately not persisted (a failed computation is not a
fact); the run fails at compute anyway.

Design note on the points table: promoted dimensions + jsonb measures is
the flexibility trade made explicit — new MEASURES on a series need
nothing, a new series METRIC is a rules.yaml entry, and only a genuinely
new DIMENSION (a fifth axis) would touch DDL, by adding one nullable
column.

```sql
-- a dashboard chart, straight from SQL
SELECT month, vals->>'actual_pct' actual, vals->>'plan_pct' plan
FROM ainf_data.run_metric_points
WHERE run_id=:run AND metric_id='share_trend' ORDER BY ord;

-- the gap as a cross-run series
SELECT r.generated_at::date, m.value->>'gap_pts'
FROM ainf_data.run_metrics m JOIN ainf_data.insight_runs r USING (run_id)
WHERE m.metric_id='share_latest' ORDER BY r.generated_at;

-- hypothesis verdict history
SELECT r.generated_at::date, h.armed
FROM ainf_data.run_hypotheses h JOIN ainf_data.insight_runs r USING (run_id)
WHERE h.hypothesis_id='H3_field_contact_deficit' ORDER BY r.generated_at;
```
