# Bring your own code — what the structure asks of you, and what it does not

The short answer to *"we already have code — why write it this specific
way?"*: **you don't rewrite your code. You mount it.** The workspace
structure is not a coding style for your logic; it is the declaration
layer that makes your existing logic reachable, governed and upgradeable
inside an agent system. Your code stays yours, in the language and repos
it already lives in.

## The three mounting points

**1. A console-script tool — your code behind a command line.**
Anything deterministic — a calculation, a validator, a loader, an
existing Python/Java/anything module — mounts as a CLI the agents run.
This workspace's own examples are exactly that:
`iof-ainf_insights-metrics` (the whole configured analysis),
`iof-ainf_insights-insights_store` (a validating DB writer),
`iof-ainf_insights-kb` (a file resolver). Each is a thin `main()` over
ordinary code. If your logic already exists, the wrapper is typically a
page: parse arguments, call your function, print. The platform then
gives it presence-validation on every host (`cli-hub check`) for one
`tools.yaml` entry.

**2. An MCP server — your service behind a standard protocol.**
A system agents should *consult* — an internal API, a data platform, a
vendor system — mounts as an MCP server in its own repository, deployed
where that system lives, addressed by a URL from the env.
`creative-intel-mcp` is the worked template: ~150 lines wrapping a
dataset, and every agent in the workspace can call its three tools with
zero changes to any agent. Your existing REST service keeps its code;
the MCP layer is an adapter beside it.

**3. An `exec` step — any command as a pipeline stage.**
A workflow step of `type: exec` runs a command — *any* command, in any
language — under the same gates as an agent step: declared artifacts
checked fail-closed, retries bounded, stdout captured, failures
diagnosable. The rule this workspace runs on: **if a step's correct
behaviour can be written as a script, it is a script.** Two of the five
pipeline steps here (compute, persist) are exec steps precisely because
determinism was available.

## What the structure itself is for

The parts you DO write in the workspace shape — `workflow.yaml`, role
casts, skills, the pack manifest — are not your business logic. They are
the things an agent system needs that plain code cannot provide:

- **Resolution**: the engine finds your agents, workflows, tools and
  assets because the package declares them — no registration scripts, no
  content database, no sync step to forget (One-Truth: the installed
  package IS the source).
- **Gates**: `requires_artifacts` fails a step whose deliverable is
  missing even when a model claims success — the difference between an
  agent pipeline and a hope pipeline.
- **Judgement vs. computation, kept separate**: skills teach agents WHEN
  to use your tools; your tools stay the only place numbers come from.
  This workspace's anti-hallucination record rests on that split.
- **Upgrades as version bumps**: because your content is a package and
  the platform is a dependency, both sides upgrade with pip. A bespoke
  integration would make every platform upgrade a merge.

## The test of the claim

Count what this workspace actually rewrote to adopt the shape: the
metrics engine is plain SQL in a YAML file, the store is plain psycopg2,
the MCP server is a plain dataset wrapper, the KBs are Markdown. The
*platform-shaped* code — pack declaration, workflow YAML, skill files —
totals a few hundred lines, and none of it is business logic. That ratio
is the design goal: your code, one thin declaration layer, and the
harness's governance underneath it.

Where the mounting points live and how to add one:
[`deployment-topology.md`](deployment-topology.md) ·
scaffolds: `aicore new-tool`, `aicore new-skill --tool`,
`aicore new-workflow`.
