# Client feedback — plan and backlog (2026-09-01)

Nine questions from the client team, triaged against what the platform
and this workspace already do (each claim below was verified in code
before it was written). Three kinds of work come out: **Docs** (the
capability exists and needs a client-facing answer), **Demo** (exists and
needs proof), **Platform MR** (a real gap). Items execute top to bottom;
each records its acceptance test.

| # | Client question | What exists today | Gap | Work | Size |
|---|---|---|---|---|---|
| F1 | How do we deploy, and where do we write code? | Engine-per-workspace pods, wheels from your index, MCP servers as sidecars, one Postgres; all client code lives in the workspace repo | No single client-facing page | **Docs**: `docs/deployment-topology.md` | S |
| F2 | We already have code — why code this specific way? | Existing code mounts as-is: console-script tools, MCP servers, `exec` steps running any binary; the structure buys resolution, gates, upgrade-as-pip | No page making that argument | **Docs**: `docs/bring-your-own-code.md` | S |
| F3 | Where are chats stored; how does a returning user reattach? | Messages table (any pod, thread-stamped); per-thread agent sessions (S3-synced); **`/v1/conversations`** — durable threads, create/list/get/items, owner-bound | Client docs don't mention the Conversations API | **Docs+Demo**: extend `docs/chat-api.md`; live returning-user walk | M |
| F4 | Can we ask the harness for a user's conversations? | Yes: `GET /v1/conversations` lists the caller's threads (owner = verified principal under auth) | Same as F3 | folded into F3 | — |
| F5 | Can it converse ACROSS runs, on all run history? | By design: every run persists into `ainf_data` keyed by `run_id`; Pulse's NLQ tier queries across them; `iof-recall` FTS over step outputs | Needs proof + a doc line | **Demo+Docs**: cross-run Pulse Q&A over the 8 persisted runs | S |
| F6 | RBAC on history — an agent could leak what a user must not see | Engine authN (OIDC/api-key); Conversations owner-binding under auth; Studio membership | **Real gaps**: legacy `GET /api/chat/{ns}/messages?user_id=` returns any user's rows to any verified caller; run history has no per-user ownership; auth-off degrades to trusted `user_id` | **Docs** (honest posture page) + **Platform MR**: bind legacy chat routes to the verified principal when auth is on; run-level ownership recorded as platform backlog | L |
| F7 | Control WHAT memory stores (name/address yes, balance no) | Review posture by default (nothing active without approval), deterministic rails (PII redaction, finding-drop, security scan), `aicore memory forget` | No per-workspace configurable deny-patterns ("never store amounts") | **Docs** now; **Platform MR** (workspace-tier memory policy: deny/redact patterns in the rails) as P2 | M |
| F8 | Who writes memory values, how, where stored? | Fully governed: consolidation pipeline → rails → drafts; `workspace_memory` + `_history` (audit) + `_runs` (claims); CLI `status/pending/approve/reject/history` | Client-facing explanation | **Docs+Demo**: `docs/memory-governance.md` (workspace view) with live commands | S |

## Execution order and why

1. **F1, F2** — mental-model docs first; every later answer lands on them.
2. **F3/F4** — the Conversations API demo + doc (returning-user recipe).
3. **F5** — cross-run Q&A demo (uses the runs already persisted).
4. **F8** — memory provenance doc + live commands.
5. **F7** — memory-policy doc; the deny-pattern MR follows as P2.
6. **F6** — security posture doc + the principal-binding MR (largest;
   last so the docs it needs already exist).

## Findings logged while executing

- **F3 (done)**: the returning-user walk is live and documented in
  `docs/chat-api.md`. Executing it surfaced a platform defect: on a
  FRESH Postgres schema, `ensure_platform_schema`'s migration tail can
  fail and its `rollback()` silently discards every CREATE before it —
  the function reports success having created nothing (this workspace's
  schema was missing both conversation tables). The fix is the
  platform's own established pattern: each additive statement in its own
  SAVEPOINT. Filed for the F6 platform-MR batch.

- **F5 (done)**: Pulse enumerated all ten persisted runs — ids,
  timestamps, per-run gap, per-run top driver — in one answer; doc line
  added to `docs/chat-api.md`.
- **F7-doc + F8 (done)**: `docs/memory-governance.md`, anchored on the
  live state (118 drafts, 0 active after 10 runs — review posture
  holding). Open: the F7 deny-pattern platform MR (P2).
- **Second platform finding**: several CLI commands still resolve their
  store WITHOUT adopting the workspace env (`aicore init` ensured tables
  in the wrong target; `aicore memory status` read an empty default
  SQLite while the real state sat in Postgres). Same family as the
  2026-08-27 adoption campaign — the sweep missed `cli_memory`'s and
  init's resolvers. Filed for the F6 platform-MR batch.

- **F6 (done)**: `docs/security-posture.md` states every boundary
  honestly, and engine MR !113 delivers the platform half -
  IOF_CHAT_BIND_PRINCIPAL binds the legacy chat routes to the verified
  principal (403 on an asserted mismatch, history reads scoped to the
  caller), plus the two findings from this pass: ensure_platform_schema
  now survives its own failures (per-statement SAVEPOINTs; a fake with
  pg abort semantics pins it), and init/memory adopt the workspace env.
  Still open by design: per-user ownership of RUNS - an authorization
  model, filed as a platform design item and named in the posture doc.

## Hardening round (2026-09-01, after the F1-F6 pass)

Four checks against real infrastructure, not fakes. Two found defects.

| Check | Result |
|---|---|
| **H1** ensure_platform_schema on a real shared PostgreSQL: fresh scratch schema, re-run, poisoned pre-state | **PASS after 2 fixes** — fresh schema now gets the full table set; re-run identical; with a statement deliberately failing, 9 of 9 other tables survive |
| **H2** the adoption fixes from a bare environment (temp cwd, only `IOF_WORKSPACE`) | **PASS** — `init` reached the workspace RDS (126 tables), `memory status` read the real queue, no stray `.iof` |
| **H3** RBAC matrix under a real OIDC issuer, two principals | **PASS 11/11** — asserting another's `user_id` 403s; cross-user history reads 403; a person's history carries zero rows and zero secret text from the other; thread lists omit and thread opens 404 across principals; each still reads their own |
| **H4** Conversations reconnect | **PASS** — a re-issued turn replayed the same item id and text; no second model call |

**What H1 found that unit tests could not**, both fixed and pinned
(engine `c80356de`): `_table_columns` probed `information_schema`
without a schema filter, so a NEW workspace on a shared database was
told a table already existed and skipped creating it — the deeper cause
of the live missing-tables case; and a guarded SELECT fetched outside
its guard, which raises `no results to fetch` on real psycopg2 after a
compensated failure while an in-memory fake returns `[]`.

## Hardening round 2 - adversarial, on live data (2026-09-01)

Round 1 proved the happy paths and the obvious refusals. Round 2 asked
what an actual attacker or a careless client would do. **Two more real
leaks found and closed**, both on features shipped the same day.

| Check | Result |
|---|---|
| **H5** two verified principals name the SAME `conversation_id` | **FAIL -> fixed -> PASS.** bob named amy's ordinary thread ("q3-review") and the agent replayed her question and her live figures (Lakeside Oncology Partners, -7.2 pts) back to him: the session key carried the CLIENT-CHOSEN thread name and nothing about who asked. Sessions are now namespaced by the person; the stored thread name is unchanged so history filters still work. Re-probed: bob gets a fresh session. |
| **H6** does namespacing cost a person their own thread? | **PASS** - amy's follow-up still recalls her figure (-0.9); her parallel thread starts clean. |
| **H7** impersonation on the RUN surface | **FAIL -> fixed -> PASS.** Round 1 left it unbound ("runs are team artifacts") - but team-visible run DATA is not an impersonable CONVERSATION: bob asserted amy's `user_id`, landed in her thread, and wrote rows under her name. Now 403 before any model work; bob still chats about the same run as himself. |
| **H8** `--follow` filter false positives | **PASS 8/8** - agent prose containing or starting with a date survives, tool lines and tables survive, plain and colorized log records are dropped, date+time without millis is not treated as a record. |
| **H10** KB miss must not fabricate | **PASS** - asked for a brand with no KB, the agent refused, named the brands that have one, and cited the failed tool call plus the SQL showing zero runs. |

**The pattern in both leaks:** a control was applied at the layer where
identity is *reported* (attribution, history reads) but not at the layer
where identity *decides what the agent remembers* (the session key). A
binding that stops at the audit trail is not a boundary.

## Acceptance

- F1/F2/F8/F7-doc: page exists, claims verified against code, linked from
  README/runbook.
- F3: a two-session curl walk — create thread, chat, "come back", list
  conversations, resume by id — captured in the doc.
- F5: one Pulse answer citing figures from ≥2 different run_ids.
- F6: posture doc states every boundary honestly; MR: with auth ON, a
  caller cannot read another principal's chat history (test pinned).
- F7-MR (P2): a workspace-declared deny pattern provably blocks a fact
  from being stored, with the drop recorded in the audit trail.
