# Security posture — who can see what, stated honestly

The client question behind this page: *agents have access to history —
where is the RBAC that stops one user's information reaching another?*
The answer, layer by layer, including what is NOT enforced yet. Every
claim here is the platform's actual behavior, not its aspiration.

## The layers, outermost first

**1. The engine door — verified identity (`IOF_ENGINE_AUTH`).**
OIDC against your IdP (Entra/Okta) or a rotatable shared key, fail-closed
on every route; a service bound to a routable address refuses to start
without it. Production posture: always on. Everything below assumes it.

**2. The workspace wall — hard tenancy.**
One engine serves one workspace. A request naming another workspace is
refused. An agent cannot read across workspaces because nothing in its
process resolves another workspace's content, data or history.

**3. Conversation threads — owner-bound (enforced today).**
On `/v1/conversations`, a thread's owner is the **verified person**
(actor claim first, so a UI proxying through a service account binds to
the human). Another principal listing or opening the thread gets 404.

**4. Legacy chat routes — bound under a flag (engine ≥ 0.6.8).**
The older `POST /api/chat/{ns}` + `GET /api/chat/{ns}/messages` routes
historically trusted the `user_id` the client sent. With
`IOF_CHAT_BIND_PRINCIPAL=1`, they act as the verified caller: an
asserted mismatched `user_id` is refused with 403, and history reads
return the caller's own rows. Opt-in today (existing proxies must send
the actor claim first); treat it as mandatory in any deployment where
users must not read each other's chats.

**4b. Run conversations — the person is not impersonable.**
The run surface is bound by the same flag: anyone in the workspace may
chat about a run (that is the team-artifact model, unchanged), but a
caller asserting another person's `user_id` is refused with 403 rather
than landing in their thread. A hardening probe found exactly that leak
before it was closed: one principal named another's ordinary thread name
and the agent replayed her question and her figures back to him.

**5. Memory — scope-limited and human-gated.**
A `user/<id>` memory row reaches only that user's sessions; nothing
becomes active without steward approval
([memory-governance.md](memory-governance.md)).

**6. Source data — your database's grants are the RBAC.**
Agents read through the `iof-query` credential. That credential should be
granted exactly the views agents may reveal — the platform deliberately
does not duplicate your data platform's row/column security, because a
second copy of grants is a second place for them to be wrong.

**7. Sessions are per-person, not per-thread-name.**
`conversation_id` is chosen by the client, so the agent session it opens
is namespaced by the caller: two people who pick the same ordinary name
("q3-review") get two separate conversations with separate memories.
History still stores the caller's own thread name, so a UI filtering by
it is unaffected.

## What is deliberately team-visible

**Runs are team artifacts.** Within one workspace, run history, run
artifacts and run-scoped chat are visible to the workspace's verified
callers — like build logs in a CI system. There is no per-user ownership
of runs today. If a deployment needs "analyst A may not open analyst
B's runs", that is an authorization model over runs (roles, not routes)
— filed as a platform design item, and this page will say so until it
ships. Do not put per-user secrets in a run goal or artifact.

## The auth-off degradation, named

With `IOF_ENGINE_AUTH=off` (development only): ownership everywhere
degrades to the unverified `user_id` a client sends — separation without
proof. The engine logs a warning saying exactly that. Nothing about the
development posture carries to production, where the service refuses a
routable bind without auth.

## Deployment checklist

```
IOF_ENGINE_AUTH=oidc            # or apikey - never off on a routable bind
IOF_CHAT_BIND_PRINCIPAL=1       # chat + history act as the verified person
# iof-query DB credential: grant only what agents may reveal
# per-user run visibility needed? -> raise it; it is a filed design item
```
