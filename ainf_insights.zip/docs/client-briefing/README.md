# Client engineering briefing

Two deliverables for the client's engineering team:

| File | What it is |
|---|---|
| `OUTLINE.md` | The written outline — the argument, in full, with the diagrams |
| `client-briefing.pptx` | The deck: 17 slides, native editable PowerPoint shapes |
| `client-briefing.pdf` | The same deck for reading and circulation |

Covers **(1)** how the git repo is organised — workspace → solutions →
workflows and swarms, and what is shared across them — and **(2)** the insights
design pattern: three generic pharma-commercial agents that each workflow casts
into a contextual role, behind one meta agent that serves the front end.

## Rebuilding the deck

`deck.src.html` is the authored source; `deck.html` is generated (the Johnson
brand fonts and the presentation design system are inlined into it, which is why
it is ~1 MB and gitignored).

```bash
python build_deck.py                       # deck.src.html -> deck.html
node <skills>/presentation/slides_export.js --input deck.html --output client-briefing.pptx
node <skills>/presentation/slides_export.js --input deck.html --output client-briefing.pdf
```

`<skills>` is the `agentfarm-skills` package's `skills/` directory. The export
needs `playwright`, `dom-to-pptx` and `pptxgenjs` on Node, plus
`npx playwright install chromium`.

## Design notes

- **Brand:** primary `#D71600`, light grey `#F2F2F1` as the secondary, white
  ground. Only the `:root` tokens in `deck.src.html` carry the brand — the
  design system underneath is unchanged.
- **Type:** Johnson Display for headings and figures, Johnson Text for body,
  embedded as base64 so the HTML and PDF render identically anywhere.
  PowerPoint uses the font *name*, so the PPTX picks up the client's installed
  Johnson fonts.
- **Layout is static on purpose** — fixed 1920×1080 slides, top-anchored flow,
  fixed-px type, no animation. That contract is what makes the PPTX export a
  clean coordinate scrape rather than a screenshot.

## Scope

Swarms (goal-directed runs) are deliberately **out of scope** for this
briefing — the insights reference implementation does not use them, so the
repository model is presented as workspace → solutions → workflows.

## Verified before shipping

- 17 slides in the PPTX, 403 native shapes, 1 real (editable) table.
- 0 shapes off-canvas, 0 overlapping text boxes.
- Fonts and brand palette confirmed in rendered output.

If the export fails with `EBUSY`, the target file is open in PowerPoint —
close it and re-run. (A locked target makes the exporter fall back to a
screenshot deck instead of native shapes, so check the output says
"native editable".)
