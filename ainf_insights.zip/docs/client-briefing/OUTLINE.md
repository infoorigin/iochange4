# Client Engineering Briefing — Outline

Two topics for the client's engineering team:

1. **How the git repo is organised** — the workspace / solution / workflow
   model and what is shared across it.
2. **The insights solution design pattern** — generic domain agents that wear a
   contextual role per workflow, with a meta agent as the single front door for
   the front end.

This file is the outline. The deck (`client-briefing.pptx`) presents it.

---

# PART 1 — How the git repo looks

## 1.1 The one-sentence model

> A **workspace** is the team's repo. It holds one or more **solutions** — each
> a module or capability of the project. A solution runs its work as
> **workflows**: declared pipelines of steps. All of them draw on **agents,
> skills and tools** that live once at workspace level and are shared.

## 1.2 The three levels

```
WORKSPACE  ── the repo, the deployable unit, the tenant
   │            shared: agents/  skills/  tools/  memory/
   │
   ├── SOLUTION A  ── one module / capability of the project
   │        └── workflows/                      (owned by this solution)
   │
   └── SOLUTION B  ── another module
            └── workflows/
```

Talking points:

- **Workspace = family code = tenant code.** One repo, one installable
  distribution, one workspace registered in the platform.
- **Solution = a module of the project**, not a separate deployment. The split
  exists so the catalog can attribute work, not to ship separately.
- **Shared content is deliberate, not accidental.** Agents/skills/tools are
  workspace-level because two solutions routinely need the same analyst. If
  two solutions need one agent, it belongs at workspace level.

## 1.3 What the repo actually contains

```
<workspace>/
  agents/<role>/workspace/        SOUL.md · skills/ · memory/     ← shared
  skills/<name>/SKILL.md          shared craft/method skills      ← shared
  tools/                          deterministic CLI tools         ← shared
  memory/                         curated workspace context       ← shared
  solutions/<solution>/
      workflows/<name>/           workflow.yaml · roles/ · steps/ · metadata/
  pyproject.toml                  entry point + package mapping
  aicore.solution.yaml            manifest for the importer
```

Real example — the `ainf_insights` workspace in this briefing:

```
ainf_insights/
  agents/     analyst · strategist · reviewer · insights_meta
  skills/     catalog_reader · grounded_analysis
  solutions/brand_marketing/workflows/brand_insights/
```

## 1.4 How a repo plugs into the platform

```
Framework team                     Business/IT team
──────────────                     ────────────────
publishes SDK wheels        →      installs SDK as a dependency
(engine + shared skills)           owns THIS repo
                                   declares an entry point
                                        │
                                        ▼
                             engine discovers the pack
                             (no core edits, ever)
```

- The seam is a Python **entry point** (`aicore.packs`). Zero core edits.
- **Upgrades are version bumps, not merges.** The team never forks the engine.
- The **files are the source of truth**: an editable install means an edit is
  live on the next run. There is no publish or sync step to forget.

## 1.5 Growing the repo — scaffold, don't hand-write

```bash
aicore workspace scaffold <code>          # the repo + the tenant
aicore new-solution   <name>              # a module
aicore new-agent      <role>              # shared agent
aicore new-skill      <name>              # shared skill (or --role for one agent)
aicore new-tool       <name>              # deterministic CLI tool
aicore new-workflow   <name> --solution <s>
```

Why it matters: several things must line up (entry point, package data, the
manifest, `__init__.py` in every mapped directory) and each **fails silently**
when hand-written — the pack installs and is simply invisible. The scaffold
gets all of them right and ships tests that fail if they drift.

Linting is symmetric and part of the workflow:
`lint-workflow` · `lint-skill` · `lint-agent`.

## 1.6 Part 1 takeaways

1. One repo per team; solutions are modules inside it, not separate repos.
2. Agents/skills/tools are shared; workflows belong to a solution.
3. The engine is a dependency, never a fork — upgrades are version bumps.
4. Scaffold and lint; the failure mode of hand-writing is silence.

---

# PART 2 — The insights solution design pattern

## 2.1 The problem this pattern solves

A brand team asks: *where are we off plan, why, which accounts, what next?*
The naive build is one bespoke agent per brand. That does not scale: N brands
× M questions = N×M agents to write, review and keep consistent.

## 2.2 The pattern

> **Build generic agents with domain expertise. Let each workflow cast them
> into a contextual role.**

```
THREE GENERIC AGENTS                     CAST PER WORKFLOW
(pharma commercial domain)               (context, not identity)

  analyst                                 brand marketing data analyst,
  measures what happened, and       ──►   Darzalex
  where it is concentrated

  strategist                              brand marketing strategist,
  works out why it is happening,    ──►   Darzalex (deep myeloma-market
  and what to do about it                 expertise)

  reviewer                                brand marketing insights reviewer,
  checks it survives scrutiny       ──►   Darzalex
  before it reaches anyone
```

Add a second brand → **add one workflow with three role files**, not three
agents. Add a therapeutic area → same three agents, new dataset and roles.

## 2.3 The four layers — what lives where

| Layer | File | Templated? | Carries |
|---|---|---|---|
| **Identity** | `agents/<role>/workspace/SOUL.md` | No | Who the agent is; domain expertise; discipline |
| **Method** | `skills/*/SKILL.md` | No | How the work is done (reusable technique) |
| **Context** | `workflows/<wf>/roles/<role>.md` | Yes | The role it wears **for this workflow** |
| **Job** | `workflows/<wf>/steps/<step>.md` | Yes | What to produce **this step**, and the output contract |

The rule of thumb: *identity and method are durable and shared; context and job
are per-workflow.* Nothing brand-specific is ever written into an agent.

## 2.4 The insights pipeline

```
  analyze              strategize                review
 (analyst)            (strategist)             (reviewer)
     │                     │                       │
 grounded              validated                audited
 figures      ──►      drivers +      ──►      + corrected
 + findings            actions                 + assembled
     │                     │                       │
     └───── every step gated: no artifact = failed, retry ─────┘
                                                     │
                                                     ▼
                                        dashboard_insights.json
                                    (KPIs · drivers · evidence ·
                                     accounts · actions · not-recommended)
```

Design choices worth explaining to engineers:

- **Grounding is a contract, not a hope.** Two always-on skills: the catalog is
  read (never guessed) and every figure cites entity + query + row count.
- **The dataset comes from the workflow**, not the agent — one analyst serves
  many datasets.
- **Gates are fail-closed.** A step that claims success without its file is
  failed and retried; a broken handoff cannot become a fabricated section.
- **The reviewer re-runs the numbers** rather than trusting them, and may lower
  a confidence but never raise it. Exculpatory findings ("not a cause", "not
  recommended") ship as first-class fields.

## 2.5 The front door — the `insights_meta` agent

The front end talks to **one agent**, not to the pipeline.

```
                    FRONT END
                        │  one agent, standard endpoints
                        ▼
                 ┌──────────────┐
                 │ insights_meta│   "answer from the cheapest
                 │   (Pulse)    │    sufficient source, and say
                 └──────┬───────┘    which one it was"
          ┌─────────────┼─────────────┐
          ▼             ▼             ▼
    ① persisted    ② the data    ③ the workflow
       insights       catalog        agents
    (the reviewed  (figures the   (their reasoning,
     run payload)   run didn't     inside the run
                    publish)       session)
```

- **Tier 1 is the default** — the reviewed payload answers most questions and
  outranks recomputation.
- **Tier 2** computes a cut the run never published, and labels it as freshly
  computed.
- **Tier 3** is a real model call into the run's own session; used for
  reasoning questions, never for a figure tiers 1–2 can give.
- The agent is exposed **declaratively** (a card in the pack), and rides the
  platform's **standard role-based endpoints** — no domain endpoints were added.

## 2.6 One agent, several response formats

The caller picks the shape **per request**:

| Request | Reply |
|---|---|
| *(none)* | Markdown for a chat panel |
| `format: "viz_envelope"` | Structured envelope: answer · data · viz hint · insight · evidence |
| `format: "kpi_tiles"` | A workspace-declared custom format (KPI tile strip) |

**The extensibility point for the client's team:** a new format is a skill in
*their* pack — frontmatter name plus a JSON Schema — resolved per request and
schema-validated by the engine, with a bounded corrective retry. No platform
change is needed to add one.

## 2.7 What was proven, end to end

- The pipeline converged 3/3 steps on the code driver; every gate passed.
- The reviewed payload reproduces the target dashboard: KPIs, the
  lost-share-not-lost-volume diagnosis, the region concentration, the ranked
  accounts, the actions, and the explicit not-recommended lever.
- Q&A answered live from all three tiers, and both structured formats
  validated on the wire.
- The source data is synthetic and **self-verifying**: the generator asserts 19
  headline facts before the data is usable.

## 2.8 Part 2 takeaways

1. Generic agents + per-workflow role casting: brands scale by configuration.
2. Identity/method are shared; context/job are per-workflow.
3. Grounding and gates are enforced by the engine, not by good intentions.
4. One meta agent is the front door; formats are a per-request choice and
   extensible by the client's own team.

---

# Deck plan (slide order)

Headings are descriptive rather than assertive — this is a reference briefing
for an engineering audience, not a pitch. The kicker carries the context, the
heading names the topic, and the argument lives in the body and the seam.

| # | Kicker | Heading | Device |
|---|---|---|---|
| 1 | Engineering briefing | *(title)* | Hero |
| 2 | Agenda | What this briefing covers | Two blocks |
| 3 | — | The repository model | Section divider |
| 4 | Structure | The three levels | Containment diagram |
| 5 | Layout | Repository structure on disk | Annotated tree |
| 6 | Ownership | Shared and solution-owned content | Two columns |
| 7 | Integration | How a workspace plugs into the platform | Flow |
| 8 | Tooling | Scaffolding and validation | Command block |
| 9 | — | The insights design pattern | Section divider |
| 10 | Motivation | Why not one agent per brand | Contrast |
| 11 | The pattern | Generic agents with contextual roles | Casting rows |
| 12 | Composition | Where each layer lives | Layer stack |
| 13 | Execution | The insights workflow | Flow + blocks |
| 14 | Interface | The front-end entry point | Hub and tiers |
| 15 | Output | Response formats | Table |
| 16 | Status | Implementation status | KPI blocks |
| 17 | In summary | Key points | Numbered list |
