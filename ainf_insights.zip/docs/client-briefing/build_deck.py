"""Build the client briefing deck: resolve includes in deck.src.html -> deck.html.

Two includes, both kept OUT of the authored source so it stays readable:
  <!--INLINE:fonts-->          the Johnson OTF faces as base64 @font-face rules
  <!--INLINE:viewport-base-->  the presentation skill's viewport-base.css, verbatim

The static-layout contract lives in that CSS (fixed 1920x1080, top-anchored
block flow, fixed-px type, opacity-only reveals) and is what makes the PPTX
export scrape cleanly. Inline it whole; never edit it here.
"""
from __future__ import annotations

import base64
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FONT_DIR = Path(r"C:\Users\SudhirBisane\Downloads\Assets 2025-12-03 1")
VIEWPORT_CSS = Path(
    r"C:\sb\products\procurement-insights\io-procurement-insight-engine"
    r"\agentfarm-skills\agentfarm_skills\skills\presentation\viewport-base.css"
)

# (file stem, css family, weight or weight-range, style)
FACES = [
    ("JohnsonDisplay-Light",   "JohnsonDisplay", "300",     "normal"),
    ("JohnsonDisplay-Regular", "JohnsonDisplay", "400",     "normal"),
    ("JohnsonDisplay-Medium",  "JohnsonDisplay", "500",     "normal"),
    ("JohnsonDisplay-Bold",    "JohnsonDisplay", "600 900", "normal"),
    ("JohnsonText-Regular",    "JohnsonText",    "300 400", "normal"),
    ("JohnsonText-Medium",     "JohnsonText",    "500 600", "normal"),
    ("JohnsonText-Bold",       "JohnsonText",    "700 900", "normal"),
]


def font_css() -> str:
    out = ["/* Johnson brand faces, embedded so the HTML and PDF render",
           "   identically off any machine. PowerPoint uses the family NAME,",
           "   so the client's installed Johnson fonts drive the PPTX. */"]
    for stem, family, weight, style in FACES:
        p = FONT_DIR / f"{stem}.otf"
        if not p.is_file():
            print(f"  ! missing font {p.name} - skipped", file=sys.stderr)
            continue
        b64 = base64.b64encode(p.read_bytes()).decode("ascii")
        out.append(
            f"@font-face{{font-family:'{family}';font-style:{style};"
            f"font-weight:{weight};font-display:block;"
            f"src:url(data:font/otf;base64,{b64}) format('opentype');}}"
        )
    return "\n".join(out)


def main() -> int:
    src = HERE / "deck.src.html"
    if not src.is_file():
        print(f"error: {src} not found", file=sys.stderr)
        return 1
    html = src.read_text(encoding="utf-8")

    if not VIEWPORT_CSS.is_file():
        print(f"error: {VIEWPORT_CSS} not found", file=sys.stderr)
        return 1

    html = html.replace("<!--INLINE:fonts-->", font_css())
    html = html.replace("<!--INLINE:viewport-base-->",
                        VIEWPORT_CSS.read_text(encoding="utf-8"))

    for marker in ("<!--INLINE:fonts-->", "<!--INLINE:viewport-base-->"):
        if marker in html:
            print(f"error: unresolved include {marker}", file=sys.stderr)
            return 1

    out = HERE / "deck.html"
    out.write_text(html, encoding="utf-8")
    slides = html.count('<section class="slide')
    print(f"wrote {out.name}  {len(html)/1024:.0f} KB  {slides} slides")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
