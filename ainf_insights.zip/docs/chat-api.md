# The chat surfaces — one shape, two anchors

How a UI (or any caller) talks to this workspace's agents. There are
exactly two chat families, deliberately identical in body, events and
history semantics — what differs is what ANCHORS the conversation.
Everything here is the platform's standard role-based surface; nothing is
domain-specific, and no custom endpoints exist.

```
Agent-level (no run)                     Run-level
POST /api/chat/{ns}                      POST /api/run/{run_id}/message
POST /api/chat/{ns}/stream               POST /api/run/{run_id}/message/stream
GET  /api/chat/{ns}/messages             GET  /api/run/{run_id}/messages
       ?user_id=&conversation_id=               ?conversation_id=&step_key=
```

`ns` is the role being addressed (`insights_meta` = Pulse). The run-level
surface addresses the run's own agents via `role` in the body — including
`insights_meta`, which then answers WITH the run as its session anchor.

**Prerequisite: the service must be running.** Every route above — chat,
streaming, history — is served by `aicore serve` (the workspace service on
port 8111 here). Without it nothing answers: every call fails at the
socket with connection refused, streaming included. Running a workflow via
the CLI does not require serve; talking to anything about it does.

## The one request body

```json
{
  "content":         "the message",
  "user_id":         "web:amy",        // the PERSON - attribution, memory, preferences
  "conversation_id": "perf",           // the THREAD - names the conversation
  "role":            "insights_meta",  // run-level only: which agent answers
  "format":          "viz_envelope"    // optional named output format; default markdown
}
```

**`user_id` and `conversation_id` are deliberately separate.** The person
and the thread used to be one field, so parallel conversations meant
minting fake users — losing memory and fragmenting history.  Now one
person holds any number of parallel threads; each thread has its own
session (its own agent memory of the dialogue), while attribution,
user-scope memory and preferences stay on the person. Omit
`conversation_id` and the thread falls back to the person — the classic
one-thread-per-user behaviour, so simple callers change nothing.

## Which anchor when — the run-id rule

- **Run id as SESSION → run-level.** The turn is about *this run*: the
  prompt is auto-augmented with the run's context (goal, steps, outputs),
  and a new thread forks the step's session, so the agent starts with the
  run's full working memory. You never need to name the run in the
  message.
- **Run id as DATA → agent-level.** Pulse answers from the persisted
  tables; a run id mentioned in the content is just a WHERE clause
  (`insight_runs`, `run_metrics`, …). No run id parameter exists on this
  surface on purpose.
- **Across runs is the same surface.** Every run persists into the same
  run-keyed tables, so a question spanning history needs no special mode:
  *"list every DARZALEX run with its share gap and top driver"* returned
  all ten persisted runs in one answer, run ids and confidences cited —
  proven live. Cross-run metric history is plain SQL
  (`setup_ainf/DATA_MODEL.md`).

## Streaming (both levels)

The `/stream` sibling runs the SAME turn as Server-Sent Events — read it
with a client that does not buffer (`curl -N`; in a browser, `fetch` +
`response.body.getReader()` — `EventSource` cannot POST):

| Event | Payload |
|---|---|
| `status` | a tool line as the agent works — the same text a polling client reads back as a thought row |
| `delta` | raw model text as it arrives |
| `message` | exactly the body the non-streaming endpoint returns |
| `done` | end of turn |

Refusals raised before the turn starts (unknown run, empty
`conversation_id`, unknown format) stay ordinary HTTP status codes.

## History — how a UI re-renders after a pod switch or reload

History is served from the **messages table** (shared Postgres), never
from session files — any pod answers, a browser close loses nothing.
Every chat row is stamped with its thread, so one conversation
re-assembles with one query:

```
GET /api/run/{run_id}/messages?conversation_id=dig
GET /api/chat/insights_meta/messages?user_id=web:amy&conversation_id=perf
```

Rows carry `source` (user | agent | …) and `msg_type`
(message | thought | preview): render `message` rows as bubbles and
`thought` rows as the progressive activity trail (concatenate consecutive
fragments, or show only tool lines). Unfiltered reads return every thread
interleaved — thread filtering is the UI's job to request.

Session files (the agent's own memory of a thread) are a separate
mechanism: per-thread JSONL, S3-synced around every turn when
`IOF_STORAGE=s3`, so the *agent* also survives a pod switch. Rendering
never reads them.

## Returning users — the Conversations API

`conversation_id` threading answers "keep my parallel chats apart";
the **Conversations API** answers the next question: *a user comes back
tomorrow — how do they find and resume their threads?* The engine keeps
durable, named threads on an OpenAI-shaped surface:

```
POST   /v1/conversations                     open a thread {agent, title, user_id}
GET    /v1/conversations?user_id=...         the user's threads, latest first
POST   /v1/conversations/{id}/responses      run a turn {input, user_id} (stream: true for SSE)
GET    /v1/conversations/{id}/items          the full history, ordered
DELETE /v1/conversations/{id}                remove a thread
```

The returning-user flow, proven live on this deployment: create
("Monthly performance review", agent `insights_meta`) → ask → leave →
`GET /v1/conversations?user_id=web:amy` lists the thread → resume by id
— the agent answered *"you asked me what the DARZALEX share gap vs plan
was … that was the only question in this conversation"*, with the run id
it had cited a session earlier. History re-renders from `/items`;
continuity is server-side (one engine session per conversation) — the
client stores nothing but the id.

**Ownership.** A thread belongs to its owner. With engine authentication
ON, the owner is the **verified principal** (the person, not the calling
service) and another caller cannot list or open it. With authentication
off, ownership degrades to the unverified `user_id` the client sends —
the engine logs a warning saying exactly that. Production posture:
`IOF_ENGINE_AUTH` on, and ownership is enforced identity.

A turn already answered **replays** instead of running again, so a
client reconnecting after a long turn is safe and costs nothing.

## Worked examples (proven live)

Parallel threads, one person:

```bash
# thread "perf"
curl -X POST http://127.0.0.1:8111/api/chat/insights_meta -H "Content-Type: application/json" \
  -d '{"agent":"insights_meta","user_id":"web:amy","conversation_id":"perf","content":"Where are we off plan? (run <run_id>)"}'

# thread "drivers", same person, independent context
curl -X POST http://127.0.0.1:8111/api/chat/insights_meta -H "Content-Type: application/json" \
  -d '{"agent":"insights_meta","user_id":"web:amy","conversation_id":"drivers","content":"Why is competitor activity a likely driver? Show the evidence. (run <run_id>)"}'
```

Run-anchored dig-deeper, streamed — note the message never names the run:

```bash
curl -N -X POST http://127.0.0.1:8111/api/run/<run_id>/message/stream -H "Content-Type: application/json" \
  -d '{"role":"insights_meta","user_id":"web:amy","conversation_id":"dig","content":"Dig deeper into the top driver - show the evidence and its SQL."}'
```

Engine-side reference: `docs/web-api.md` in the engine repo ("Which chat
surface do I use?").
