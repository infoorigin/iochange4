# Deployment topology — and where your code lives

The answer to two questions at once: what runs where in production, and
which repositories your team writes code in.

## The moving parts

```
                        your index (Artifactory/Nexus)
                          platform wheels, republished
                          under YOUR distribution names
                                     │ pip install
                                     ▼
┌──────────────┐   HTTPS   ┌──────────────────────────┐
│ Client app / │──────────►│ ENGINE SERVICE           │      ┌─────────────┐
│ workbench UI │           │ aicore serve             │◄────►│ PostgreSQL  │
└──────────────┘           │ one service = one        │      │ platform    │
                           │ workspace                │      │ schema  +   │
┌──────────────┐  routes   │  - run API               │      │ ainf_data   │
│ Studio       │──────────►│  - chat + conversations  │      └─────────────┘
│ (optional)   │  per-ws   │  - A2A cards             │
└──────────────┘           └───────────┬──────────────┘
                                       │ ${CREATIVE_MCP_URL}
                                       ▼
                           ┌──────────────────────────┐
                           │ creative-intel-mcp       │
                           │ its own repo + deployment│
                           │ (the media platform seam)│
                           └──────────────────────────┘
```

- **One engine service per workspace.** It serves the run API, both chat
  surfaces, `/v1/conversations` and the A2A cards for exactly one
  workspace; a second workspace is a second deployment of the same image
  with its own `IOF_WORKSPACE`. Several instances of one workspace scale
  behind a load balancer (shared Postgres + `IOF_STORAGE=s3`; only live
  SSE streaming is sticky).
- **One PostgreSQL** carries two separated concerns: the platform schema
  (`iof_ainf_insights` — runs, steps, messages, conversations, memory)
  and the data plane (`ainf_data` — source tables + persisted insights).
  Same instance, different schemas, different DDL owners.
- **MCP servers are their own deployments.** `creative-intel-mcp` runs
  wherever the media platform should live and is addressed purely by
  `CREATIVE_MCP_URL` in the workspace env — the standard pattern for any
  external MCP system you add later.
- **The Studio is optional.** Nothing in this workspace requires it; the
  engine's own HTTP surface is the product contract.

## Configuration surface (per deployment)

Everything a deployment sets lives in ONE env file per workspace
(`~/.iobot/workspaces/<code>/.env`; in a container, injected env — see
[`setup_ainf/.env.template`](../setup_ainf/.env.template)): the two
database URLs, optional state-root overrides, `CREATIVE_MCP_URL`, and —
on any routable bind — `IOF_ENGINE_AUTH` (OIDC against your IdP, or a
shared key). A service bound to a routable address **refuses to start**
until authentication is answered.

## Where you write code — three places, and only three

| You write | Repository | Reaches production by |
|---|---|---|
| Agents, skills, workflows, role prompts, brand KBs, rules.yaml, CLI tools | **this workspace repo** | `pip install` of the workspace package into the engine venv |
| Services agents consult (media platform, CRM, any API) | **their own repos**, as MCP servers (`creative-intel-mcp` is the template) | deployed independently; addressed by URL from the env |
| Nothing | the platform | platform upgrades arrive as **version bumps from your index** — never merges, never forks |

The engine reads this workspace's content **directly from the installed
package** (the platform's One-Truth model): there is no publish step, no
sync step, no content database to load. On a dev box with an editable
install, an edit is live on the next run; on a pod, shipping a new
workspace wheel IS the deployment.

## The deployment sequence

Machine-level, in order, each step idempotent:
[`setup_readme.md`](../setup_readme.md). In one line: install wheels →
`workspace create` + env file → `setup_ainf/setup_db.py` → connect the
MCP server → validate (`list-workflows`, `cli-hub check`,
`mcp-list --probe`) → `configure-agent` for Pulse → run → serve.

## What this buys you operationally

- **Upgrades are pip, both directions.** A platform fix is a new wheel
  version from your index; your release is a new workspace wheel. No
  branch of the platform exists with your name on it.
- **Reproducible runs.** Every run stamps the exact content versions that
  produced it (`content: <dist> <version> @ <sha>` in the run header and
  the forensic record).
- **Crash and pod-loss recovery are built in** — runs resume from shared
  state on any instance; chat sessions sync through object storage; the
  run supervisor reaps and resumes stuck work.
