---
name: crm_field_notes_mining
description: "When CRM call notes are evidence: count themes with flags and denominators, quote verbatim with attribution, and correct for the biases of rep-written text before letting notes carry a conclusion."
---

# CRM Field-Notes Mining

Notes are the richest and most biased dataset in the stack. Method:

## Counting

- Count with the TAGGED FLAGS (they were applied consistently); free-text
  matching is a fallback, and its pattern is reported when used.
- Two grains, both with denominators: accounts with ≥1 flagged note
  ("N of M accounts") and flagged share of a cohort's notes ("58% of
  losing-cohort notes"). They answer different questions — breadth vs
  intensity.

## Quoting

- Verbatim substrings of returned rows only, with account + date; one or
  two quotes that typify a counted theme, never a quote in place of a
  count.
- People appear as roles ("lead hematologist"), never named.

## The biases to correct for

- **Selection**: reps write what was notable, not what was typical — a
  theme's absence from notes is weak evidence of absence.
- **Coverage**: note volume follows call volume; normalize theme rates by
  notes, not by accounts with different call loads.
- **Framing**: a rep's summary of a prescriber's view is secondhand; the
  quote is evidence of the CONVERSATION, not of the prescriber's chart
  behaviour — pair it with starts data before concluding behaviour.

## Signal taxonomy worth counting

Clinical/sequencing questions · competitor claims repeated back · access
and coverage friction · workflow/capacity objections · advocacy (unprompted
positive proof points). Each maps to a different owner (medical, field,
access, ops, none).
