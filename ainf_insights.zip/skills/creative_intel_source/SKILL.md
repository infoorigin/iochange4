---
name: creative_intel_source
description: "When creative, campaign or media-engagement figures are needed: source them from the creative_intel MCP tools - that dataset lives behind the media platform's API, not in the database."
---

# Creative Intel (MCP source)

Creative performance is the ONE dataset of this workspace that does not
live in `ainf_data`. It arrives from the media platform, served to you as
MCP tools:

- `mcp_creative_intel_creative_variants` — the variants and their live
  months.
- `mcp_creative_intel_campaign_summary` — whole-window totals per variant:
  impressions, engagement rate, share of impressions. Start here for any
  lift or mix question.
- `mcp_creative_intel_creative_performance` — monthly rows (CSV with a
  header), optionally bounded by `month_from`/`month_to`. Use it to check
  whether a lift is stable month to month.

## Rules

1. Do NOT look for creative data in SQL: there is no such table, and a
   failed hunt costs a round. The catalog says the same.
2. Cite the source as `creative_intel MCP` (with the tool name) wherever a
   table-sourced figure would cite entity + SQL.
3. The tools return small result sets — read them whole; never estimate a
   month you did not fetch.
4. One source, so cap any conclusion built ONLY on this data at moderate
   confidence and say it is single-source.
