---
name: oncology_market_dynamics
description: "When interpreting oncology prescribing data: reason in lines of therapy and sequencing economics - where a patient decision actually sits, how duration links starts to volume, and why earlier-line moves compound."
---

# Oncology Market Dynamics

The market model behind the numbers, generic to oncology brands.

## Lines of therapy are the map

Every prescribing decision sits at a LINE (1L, 2L, 3L+): a brand competes
line by line, not in one pool. Read share and starts within line; a total
blends decisions that have different competitors and different logic.

## Sequencing is the battleground

In relapsed settings the question is rarely "which drug" but "which ORDER".
The brand that wins the earlier slot compounds: it takes the patient now
AND shapes what remains feasible later. This is why an "earlier-line"
competitor move is the most damaging pattern — and why sequencing
QUESTIONS in field notes are an early warning, not noise.

## Duration links starts to volume

Volume ≈ active patients × duration. A starts shift moves volume only as
patients accrue, delayed by the therapy duration — so starts lead, TRx
lags, and a flat TRx with shifting starts is decline in the pipeline.
Conversely a volume dip with stable starts points at duration/persistence,
a different problem with different owners.

## Practice structure amplifies moves

Community oncology concentrates decisions in a few lead physicians per
group; one convinced lead moves an account's pattern. Account-level share
swings that look implausibly fast are usually one decision-maker, not many
— which is exactly why account-level targeting works.

## Anti-patterns

- Cross-line share math (2L brand vs whole-market denominator).
- Reading duration-driven volume softness as a competitive loss.
- Expecting an earlier-line countermove to show in TRx within a month.
