---
name: omnichannel_engagement
description: "When media, creative or channel-mix performance must be judged: compare variants on the same metric and window, weigh spend pacing against engagement, and recommend reallocation only with both the lift and the current mix in evidence."
---

# Omnichannel Engagement

Method for the promotional side: creative, channels, pacing.

## 1. Like-for-like or not at all

Variants compare on the SAME metric (engagement rate = engagements /
impressions) over the SAME window. A variant live for fewer months compares
on the overlap, with the shorter window stated.

## 2. Lift AND weight

A better-performing creative matters in proportion to what it carries:
report the lift (ratio and points) NEXT TO each variant's share of
impressions. High lift on low weight is an allocation opportunity; high
lift on high weight is a win already banked.

## 3. Stability before reallocation

One strong month is noise. Show the lift month by month; recommend a mix
shift only when the lift holds across the window.

## 4. Pacing is a constraint, not a KPI

Spend vs plan (by channel) bounds what a reallocation can do this year.
Over-pacing plus an under-weighted winner means SHIFT, not add.

## 5. Attribution honesty

Engagement is a media metric, not a prescription. Tie creative performance
to commercial outcomes only through the account/prescriber path, and label
the linkage strength.

## Anti-patterns

- Averaging engagement across variants with different live windows.
- Recommending budget on lift alone with the mix unexamined.
- Treating impressions as reach without frequency context.
