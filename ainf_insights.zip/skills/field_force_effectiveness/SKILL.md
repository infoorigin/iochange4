---
name: field_force_effectiveness
description: "When field activity is proposed as a cause or a remedy: test whether contact levels actually discriminate outcomes before recommending more of them, and design account-level activation instead of blanket frequency."
---

# Field Force Effectiveness

Field effort is the most expensive lever and the first one reached for.
This skill exists to make that reach earn its evidence.

## 1. The discriminating test

Before "call more" enters any recommendation: compare our calls per
account-month across the outcome cohorts (declining vs steady). Similar
levels in both cohorts mean contact does NOT discriminate — more of it is
more of the wrong thing, and saying so is a deliverable, not a footnote.

## 2. Content beats frequency

When notes show clinical questions the rep cannot answer, the gap is the
MESSAGE or the MESSENGER (medical education, MSL), not the visit count.
Route the recommendation to the role that answers the question.

## 3. Activation is account-level

A defensible field recommendation names: the accounts (ranked), what the
rep says there (tied to the claims and questions found in THOSE accounts),
the role that delivers it, and the sequencing with medical touches. "Brief
the field" without an account list is not a plan.

## 4. Measure the lever you pulled

Every field recommendation states what would show it worked (starts,
share change, note themes in the named accounts) and on what horizon.

## Anti-patterns

- Recommending frequency because it is the visible lever.
- Reading call counts as effort quality.
- National field guidance for a metro-concentrated problem.
