---
name: competitive_intelligence
description: "When competitor pressure must be assessed or countered: read share-of-voice moves, campaign exposure and field-sourced claims as one evidence chain, and separate presence from persuasion before crediting a competitor with the damage."
---

# Competitive Intelligence

Method for reading competitor activity in pharma commercial data.

## The evidence chain, in causal order

1. **Presence** — SOV level and change, competitor calls, speaker programs.
   Presence alone proves attention, not effect.
2. **Message penetration** — the competitor's CLAIMS surfacing in our own
   field notes (offices repeating them back). This is the leading indicator
   that presence is landing.
3. **Behaviour shift** — new-patient starts moving to competing regimens,
   segment by segment. Only here is damage real.

A competitor is credited with a share loss when all three link in the SAME
accounts. Presence without penetration is noise; penetration without a
starts shift is a warning, not a driver.

## Discipline

- Measure exposure as "N of M declining accounts exposed since <month>",
  with the same figure for the stable cohort beside it — exposure that does
  not discriminate cohorts is not a driver.
- Name the campaign mechanic (earlier-line positioning, convenience claim)
  from the KB or the notes, not from assumption.
- Counter-messaging recommendations must name the claim being countered and
  the accounts where it penetrated; "respond to the competitor" without an
  account list is not actionable.

## Anti-patterns

- Crediting a rival for softness that volume-vs-share diagnosis attributes
  to the market.
- Averaging SOV across the panel when the story is concentration in a few
  accounts — report distribution, not just the mean.
