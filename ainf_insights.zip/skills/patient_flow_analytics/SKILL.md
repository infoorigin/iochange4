---
name: patient_flow_analytics
description: "When prescribing behaviour must be explained beneath the TRx line: analyze new-patient starts by segment and line of therapy - where growth concentrates, whose starts are shifting, and what that implies for the brands competing at each decision point."
---

# Patient Flow Analytics

TRx is the lagging total; NEW STARTS are where prescribing decisions show
first. Method:

## 1. Segment before you sum

Starts by segment ('2L relapsed', '3L+ relapsed', ...) move for different
reasons. A competitor winning 2L while flat in 3L+ names the decision point
under attack; a total hides it.

## 2. Growth, then concentration

For each segment: brand vs competitor start growth over the window; then
WHICH accounts carry the competitor's growth (ratio latest/window-start per
account). Growth concentrated in the same accounts that are losing share is
the prescribing-shift evidence chain closing.

## 3. Starts lead, share lags

A starts shift precedes the share move by the therapy duration. Flat share
with shifting starts is not stability — it is the queue forming. Say which
one the data shows.

## 4. Denominators, always

"6 of 9 exposed declining accounts show competitor 2L starts up >25%" — the
segment, the cohort, the threshold and both counts. A bare "starts are up"
carries no decision weight.

## Anti-patterns

- Reading seasonality or a single month as a shift; require the window.
- Comparing brand starts to competitor TRx (mixed units, mixed lags).
- Treating a small-denominator account ratio as a trend without the count
  beside it.
