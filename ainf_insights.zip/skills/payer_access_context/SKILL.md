---
name: payer_access_context
description: "When access, coverage or affordability could explain a commercial signal: frame the access hypothesis correctly, name the data that would confirm it, and keep access claims out of conclusions the current dataset cannot support."
---

# Payer Access Context

Access is the third classic explanation for a share move (after competitor
pressure and prescriber preference) — and the easiest to assert without
evidence. This skill keeps it honest.

## The access hypothesis, framed properly

An access-driven loss shows up as: abandonment between decision and fill,
step-through to a preferred alternative, prior-auth friction concentrated
by PAYER (not by metro), and field notes about coverage rather than
clinical choice. Its signature is payer-shaped, not geography-shaped: a
loss concentrated in one metro across many payers argues AGAINST access as
the driver.

## What confirms it

Claims-level approval/rejection, PA turnaround, formulary position by plan,
copay exposure. When the working dataset carries none of these, an access
claim may appear ONLY as a labelled hypothesis with the data request that
would test it — never in the driver list.

## Reading the signals we do have

- Field notes: "prior auth", "coverage", "copay" themes = access signal;
  sequencing and efficacy questions = clinical, not access.
- A loss that survives the cohort contrast on promotional factors but shows
  no payer-shaped pattern still is not access by elimination — say
  "unexplained", not "access".

## Anti-patterns

- Access as the default filler for any unexplained residual.
- National access conclusions from one region's anecdotes.
- Mixing affordability (patient) with coverage (payer) in one claim.
