---
name: message_pull_through
description: "When messaging is the lever - a claim to counter, a story to land, or field talking points to design: work the chain from message platform to field execution and measure penetration in the field's own notes."
---

# Message Pull-Through

From message platform to a changed conversation in the account.

## The chain

Platform (the brand's claims) → assets (the decks and leave-behinds that
carry them) → field delivery (who says it, in which call) → penetration
(the account repeating it back) → behaviour (starts). A messaging
recommendation names WHERE in this chain the break is; "improve messaging"
names nothing.

## Countering a competitor claim

1. Quote the claim as the field actually hears it (verbatim notes, not the
   competitor's brochure).
2. Map it to the response asset that answers it; if none exists, the
   recommendation is to BUILD one, and says so.
3. Deliver account-specifically: the accounts where THAT claim penetrated,
   the objection pattern seen THERE.

## Measuring penetration

The field's notes are the sensor: claims repeated back = competitor
penetration; our proof points appearing unprompted = our penetration;
question themes shifting = the frame moving. Count themes with
denominators; quote sparingly and verbatim.

## Anti-patterns

- Message recommendations with no named claim and no named accounts.
- Answering a sequencing question with an efficacy message (wrong
  question class - route to medical education).
- Measuring pull-through by assets shipped rather than conversations
  changed.
