---
name: launch_analytics
description: "When the brand in scope is in launch phase: lead with uptake KPIs - breadth, depth and starts trajectory - instead of share-vs-plan, and rank accounts by adoption potential rather than by decline."
---

# Launch Analytics

A launch brand is measured on a different axis than a defence brand. When
the brand KB says launch phase, this method replaces the defence framing.

## The launch KPI set, in reading order

1. **Starts trajectory** — new-patient starts by month; slope beats level.
2. **Breadth** — accounts with ≥1 start ("N of M target accounts"); the
   adoption frontier.
3. **Depth** — accounts with repeat prescribing (≥2 distinct months with
   starts); the difference between trial and adoption.
4. **Time-to-first-start** — from first field contact to first start, per
   account; the funnel's speed.
5. **Spend pacing against the launch curve** — early over-pacing is often
   correct; judge against the uptake plan, not a flat monthly plan.

## Account prioritization at launch

Rank by ADOPTION POTENTIAL: eligible-patient volume, group size, early
adopter behaviour — not by share decline (there is no base to decline
from). A launch "priority account" is one to win, not one to save.

## Barrier reading

Launch-phase field notes are mined for CAPABILITY barriers (workflow,
scheduling, handling, reimbursement setup) as much as clinical ones — for
a procedure-adjacent product these gate adoption harder than conviction.

## Honesty rule

Where the working dataset was built for another brand's defence question,
state the coverage gap first and confine launch conclusions to what the
data genuinely covers.
