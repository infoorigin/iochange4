---
name: catalog_reader
description: "Interpret the data catalog. In a workflow step read it from the metadata dir named in your task prompt; in a chat read it from metadata/ in your own workspace. Pick entities by their semantic description, and query each one in a single iof-query call."
always: true
---

# Catalog Reader

The catalog is **provided to you, not baked into you**. Before any query, find
it — in this order, stopping at the first that exists:

1. **The metadata dir named in your task prompt** (usually `{{metadata_dir}}`).
   A workflow step always provides one.
2. **`metadata/` in your own workspace.** A chat turn has no task prompt and
   names no metadata dir; your metadata was deployed there by `configure-agent`.
   `read_file metadata/catalog.yaml`, and pass `--metadata-dir metadata` to
   `iof-query` — `metadata/databases.yml` beside it names the connection.
3. **Neither exists: say so and stop.** Never invent entities or columns.

**Do not search for a catalog.** No `find_files` or `list_dir` sweeps across the
workspace or the state directory, and never copy `catalog.yaml` or
`databases.yml` out of a run's snapshot (`instances/run_*/workflow/metadata/`).
That is another run's schema, possibly stale, and a query against it is a wrong
answer that looks right. If step 2 is empty, the deployment has not run
`configure-agent` for you — that is the finding to report, in one sentence.

## Routing

1. **Pick entities by their `semantic:` description**, never by name alone.
2. **Query in ONE tool call** — pass the SQL inline, never write it to a file
   first (the file is a second model round on every question):
   `iof-query --db <database> --sql "SELECT ..." --metadata-dir <path>`.
   Double quotes around the SQL, single quotes inside it; every column in this
   catalog is snake_case, so no identifier needs quoting. When the turn names a
   scratch workspace directory, add `--scratch <that dir>` so the per-session
   tool budget applies. Only SQL too long for one line goes through
   `--sql-file <scratch dir>/query.sql`. Catalog entities are registered as
   views named after the entity, so query them directly:
   `SELECT ... FROM <entity_name> ...` — no `read_csv()` needed.
3. **Use the `measures:` SQL verbatim** where the catalog supplies it, rather
   than re-deriving a definition each turn.

## Rules

- Never query an entity not listed in the catalog.
- Use column names exactly as the catalog spells them.
- When sources disagree, show both values — never silently pick one.
- Read the entity's `grain:` before aggregating — summing a column across the
  wrong grain double-counts.
