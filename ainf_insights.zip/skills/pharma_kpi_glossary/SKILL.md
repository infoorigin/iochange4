---
name: pharma_kpi_glossary
description: "When commercial KPIs are computed, compared or explained: use the standard pharma definitions and avoid the classic measurement pitfalls - share math, TRx vs NRx vs starts, SOV, plan variance and pacing."
---

# Pharma KPI Glossary (and the pitfalls that go with it)

Definitions the whole team computes the same way — so a review never argues
about arithmetic.

## Volume

- **TRx** — total prescriptions dispensed (new + refill). The lagging
  outcome.
- **NRx / new-patient starts** — new prescriptions / new patients begun.
  The leading indicator; decisions show here first.
- Pitfall: TRx flat + starts falling = decline already queued. Never read
  TRx stability as safety without the starts line.

## Share

- **Share of market** = brand volume / market volume, SAME metric, SAME
  window. Recompute from volumes at every grain — NEVER average share
  percentages across rows (mix shift corrupts the mean).
- **Gap vs plan** in POINTS (actual − plan), one decimal, dated.
- Pitfall: a growing market hides share loss inside flat volume. Always
  run volume-vs-share before attributing anything.

## Promotion

- **SOV (share of voice)** — the competitor's share of promotional
  presence among priority HCPs. A perception input, not an outcome.
- **Pacing** — cumulative spend vs cumulative plan; "over" is a statement
  about the CURVE, not a verdict (launches over-pace by design).

## Plan variance discipline

- Volume plan and share plan are DIFFERENT commitments; beating one while
  missing the other is a diagnosis (market grew faster than planned), not
  a contradiction.
- Every variance carries: the figure, the plan, the delta, the window.

## Counting rules

- Percentages carry denominators ("9 of 12, 75%").
- Patients count DISTINCT; claims and calls count rows. Never mix.
- Rates compare over identical windows; a variant live 5 months compares
  on the overlap, said aloud.
