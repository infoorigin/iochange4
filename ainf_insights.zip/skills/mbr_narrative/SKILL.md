---
name: mbr_narrative
description: "When composing a monthly business review or leadership read-out: structure it the way a brand director reads it - variance first, diagnosis second, drivers with evidence, then actions - with every section answering its one question."
---

# MBR Narrative

How a monthly business review reads when it works. Structure, not style.

## The reading order (each section answers ONE question)

1. **Where do we stand?** The KPI strip vs plan — three numbers, three
   deltas, three statuses. No prose before it.
2. **What kind of problem is it?** The diagnosis: lost volume vs lost
   share vs on-plan. One verdict, with the two series that prove it.
3. **Where is it concentrated?** Geography then accounts — contribution
   percentages, named accounts, "N of M" counts. Concentration is what
   makes a problem actionable.
4. **Why?** Drivers, each with its evidence chain and confidence — and
   what was RULED OUT, stated as firmly as what was ruled in. A review
   that only accuses never earns trust.
5. **So what?** Actions ranked by impact with owners implied by lever
   (field / medical / media), plus the explicit do-not.

## Composition rules

- Every claim's evidence is adjacent to it, not appendixed.
- A number appears once as the headline and never mutates downstream —
  later sections reference, not restate.
- Hypotheticals and forward-looks are labelled as such and quarantined
  from findings.
- The one-line summary at the top is written LAST and contains the gap,
  the diagnosis, the top driver and the top action.

## Anti-patterns

- Opening with methodology.
- Ten KPIs where three carry the meeting.
- Actions unlinked from drivers ("increase engagement").
- Burying the exculpatory finding that would stop a bad spend.
