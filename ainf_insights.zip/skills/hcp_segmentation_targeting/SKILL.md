---
name: hcp_segmentation_targeting
description: "When accounts or prescribers must be prioritized, segmented or targeted: rank by value x movability, respect adopter behaviour, and size every list to the capacity that will actually work it."
---

# HCP Segmentation & Targeting

Prioritization method for accounts and prescribers.

## The two axes, always both

- **Value** — the size of the prize: market volume, eligible patients,
  group influence (a lead hematologist's pattern moves the practice).
- **Movability** — evidence the position can change: recent share
  movement, competitive pressure present, open clinical questions in the
  notes. High value + immovable = maintain; low value + movable = ignore;
  the plan lives in the high/high cell.

## Adopter behaviour

Early-adopter accounts move first on ANY message — theirs is the earliest
signal of a competitor landing, and the first ground to defend. Laggard
accounts are expensive to move and cheap to lose late; sequence them
accordingly.

## Scoring discipline

- Publish the formula with the scores; a rank without its math cannot be
  challenged, so it cannot be trusted.
- Set an ACTION THRESHOLD and name what falls below it — a target list is
  as much about who is off it.
- Size the list to capacity: ten accounts a team can work beats forty it
  cannot. State the assumed capacity.

## Anti-patterns

- Ranking by decline alone (risk without value or movability).
- One national list for a metro-concentrated problem.
- Re-scoring every month so targets churn faster than field work lands.
