# Brand knowledge base — DARZALEX (synthetic demo content)

Read when the run goal names DARZALEX. This is brand CONTEXT for
interpretation; every figure still comes from the data.

## Brand and market

- Anti-CD38 backbone therapy in **multiple myeloma**, contested hardest in
  the **2L+ relapsed/refractory** setting; established standard with deep
  prescriber familiarity.
- Plan posture 2026: **defend share in 2L+** while the market grows; volume
  growth alone is not success if share slips (a growing market hides share
  loss inside flat TRx — always run the volume-vs-share diagnosis).

## Competitive set

- **XELVORA** is the priority threat: launched an **earlier-line campaign in
  spring 2026** anchored on "earlier is better" claims and convenience
  dosing. Its playbook: win the 2L-relapsed sequencing decision before the
  patient ever reaches 3L.
- Watch the SEQUENCE question, not brand rejection: when prescribers ask
  "which order", the brand is losing the frame, not the argument.

## Field and account structure

- Six sales regions; the **Dallas–Fort Worth key-account panel (12
  accounts)** is the bellwether metro — community-heavy, fast adopters,
  historically the earliest to move on competitor messaging.
- Key account archetype: community oncology practices where 2-3 lead
  hematologists set the regimen pattern for the group.

## Message platform and channels

- Core message: durable outcomes across relapse lines; sequencing
  flexibility preserves later options.
- HCP media campaign "**DARZALEX HCP 2026**"; the "**CEPHEUS Now
  Approved**" variant (live since April) carries the newest data story.
- The counter-messaging asset for XELVORA claims is the **relapsed-2L
  response deck** — field notes asking for "our response" mean this.

## What leadership reads first

Share vs plan (points, national then region), TRx vs plan, spend pacing,
and the DFW panel. A driver is only credited when it survives the
losing-vs-steady contrast.

## Terminology

- "2L relapsed" / "3L+ relapsed" are the segment names in the data.
- "Priority HCPs" = the prescribers behind competitor_sov_pct.
- Panel = the 22-account key-account set; DFW panel = ACC-001..ACC-012.
