# Brand knowledge base — INLEXZO (synthetic demo content)

Read when the run goal names INLEXZO. This is brand CONTEXT for
interpretation; every figure still comes from the data.

## Brand and market

- Intravesical therapy in **non-muscle-invasive bladder cancer (NMIBC)**,
  **launch phase**: the 2026 story is uptake, not defence.
- Launch KPIs outrank share KPIs: **breadth** (accounts with ≥1 start),
  **depth** (repeat-prescribing accounts), time-to-first-start after first
  call, and new-patient starts trajectory. Share vs plan matters less than
  slope.

## Competitive set

- Competition is the **entrenched standard of care** (BCG-era practice
  patterns) more than a single branded rival; the barrier is habit and
  logistics, not a rival campaign.
- Watch for capacity objections in field notes (instillation scheduling,
  in-office handling) — for a launch these are the "treatment-choice
  questions" equivalent.

## Field and account structure

- Urology-led accounts, NOT the hematology/oncology panel: where a dataset
  covers only hem/onc accounts, say so — do not force launch conclusions
  out of another brand's panel.

## Message platform

- Core message: durable complete responses without the supply and tolerance
  constraints of the old standard; emphasis on in-office workflow fit.

## What leadership reads first

Starts trajectory and account breadth/depth; then spend pacing against the
launch curve. Priority accounts rank by ADOPTION potential (volume of
eligible patients, urology group size), not by share decline.

## Interpretation rule for this dataset

The current ainf_data extract is a DARZALEX commercial panel. An INLEXZO
run against it must state that coverage gap first, answer only what the
data can support, and route everything brand-specific through this KB
rather than myeloma assumptions.
