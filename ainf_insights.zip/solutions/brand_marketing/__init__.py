"""brand_marketing — a solution of the ainf_insights workspace (workflows only).

Agents, skills and tools come from the workspace's shared pack; this package
exists so the engine can READ THESE WORKFLOW FILES directly. Never grow
agents or skills here — they are workspace-level, shared by every solution.
"""

from importlib.resources import files

__version__ = "0.1.0"


def pack():
    from ioagentfarm.packs import Pack
    return Pack(
        workspace="ainf_insights",       # the WORKSPACE code — same for every pack
        solution="brand_marketing", # what the catalog attributes these to
        workflows=files("brand_marketing_sol") / "workflows",
        swarms=files("brand_marketing_sol") / "swarms",
    )
