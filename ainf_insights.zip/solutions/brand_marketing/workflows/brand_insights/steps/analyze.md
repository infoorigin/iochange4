# Analyze — brand performance, {{window}}

Goal: {{goal}}

## Orient (in this order)

1. **Brand + KB.** Identify the brand from the goal; read
   `iof-ainf_insights-kb <BRAND>` (brand_kb_context skill). The KB decides
   which KPIs lead and how to read everything below. No matching KB = say
   so and proceed on the data alone.
2. **The computed metrics.** Read `{{output_dir}}/computed_metrics.json` —
   the configured analysis, already executed: every aggregate with the SQL
   that produced it, and each HYPOTHESIS with `armed: true/false` (or
   `evaluate: external`). This file is your primary source of figures.
3. **The catalog.** `{{metadata_dir}}/catalog.yaml` for anything you must
   query yourself.

## Sources, and how to cite each

- **computed_metrics.json** — cite as `metric <id>` and quote its recorded
  `sql` when evidence needs the query. NEVER re-derive or re-add what a
  metric already computed.
- **Your own queries** (only for cuts the metrics file does not carry, e.g.
  verbatim field-note quotes):
  `iof-query --db commercial --sql-file query.sql --metadata-dir {{metadata_dir}}`
  — Postgres; fully qualify `ainf_data.<table>`; aggregate in SQL; cite
  entity + SQL + row count.
- **Creative/media** — the `mcp_creative_intel_*` tools, never SQL (the
  creative_intel_source skill). Cite as `creative_intel MCP (<tool>)`.

## What to produce

1. **Headline KPIs** — share vs plan (latest month + gap), TRx YTD vs plan,
   spend YTD vs plan: all from metrics `share_latest`, `trx_ytd`,
   `spend_ytd`, statuses read per the KB's priorities.
2. **Share trend and diagnosis** — metrics `share_trend` and
   `volume_vs_market`: lost volume or lost share in a growing market? Note
   where actual crosses below plan.
3. **Where the gap concentrates** — metric `region_gap` (name the top
   region's contribution) and the panel picture from
   `account_share_change` + `panel_counts`: decliners ranked and named
   verbatim, "N of M" counts.
4. **The armed hypotheses, investigated.** For each hypothesis with
   `armed: true`: walk its `evidence_metrics`, lay the evidence chain out
   (per competitive_intelligence / patient_flow_analytics), and add the
   colour only YOU can add — one or two VERBATIM field-note quotes
   (queried, with account + date). For each `armed: false`: report it as
   ruled out, with the metric values that cleared it — the exculpatory
   findings ship. For `evaluate: external` (creative): pull the MCP figures
   its guidance names and state whether the condition holds.
5. **Hypotheses for the strategist** — the armed set (plus anything the
   external evaluation supports), each with its evidence pointers. Label
   them hypotheses; no recommendations here.

## Deliverables (both required — the step fails without them)

Write section by section, then assemble:

1. `{{output_dir}}/intelligence_report.md` — the readable report in the
   order above; every figure carries its source per the citation rules.
2. `{{output_dir}}/analysis_findings.json` — valid JSON:

```json
{
  "brand": "<UPPERCASE brand from the goal>",
  "kb_loaded": "<kb file read, or null>",
  "period": {"window": "{{window}}", "latest_month": "{{latest_month}}"},
  "kpis": {
    "share_latest": {"actual_pct": 0, "plan_pct": 0, "gap_pts": 0},
    "trx_ytd": {"actual": 0, "plan": 0, "vs_plan_pct": 0},
    "spend_ytd": {"actual_usd": 0, "plan_usd": 0, "vs_plan_pct": 0}
  },
  "share_trend": [{"month": "", "actual_pct": 0, "plan_pct": 0, "prior_year_pct": 0}],
  "diagnosis": {"verdict": "lost_share|lost_volume", "brand_trx_change_pct": 0, "market_growth_pct": 0, "note": ""},
  "region_gap": [{"region": "", "gap_trx": 0, "contribution_pct": 0}],
  "account_panel": {
    "total": 0, "declining": 0, "stable": 0, "growing": 0,
    "decliners": [{"account": "", "metro": "", "share_change_pts": 0, "market_trx_latest": 0}]
  },
  "hypotheses": [{"id": "", "driver": "", "armed": true,
    "evidence": [{"source": "metric <id> | creative_intel MCP | ainf_data.<table>", "finding": ""}],
    "quotes": [{"account": "", "date": "", "text": ""}]}],
  "creative": {"evaluated": true, "finding": "", "source": "creative_intel MCP"}
}
```

Numbers identical to the report; one decimal for percentages and points.

## Output

Print at least one line of text immediately BEFORE every tool call. The
orchestrator's stream consumer requires every assistant turn to contain a
text block before any tool_use block; turns that open with a tool call are
a known cause of dropped responses.

Write your protocol file to the path named under **Output destination** in
this prompt (NOT the deliverables directory above), starting with exactly
these two lines:

```
STATUS: done
OUTPUT: <one-line summary: brand, gap, diagnosis, armed hypotheses>
```
