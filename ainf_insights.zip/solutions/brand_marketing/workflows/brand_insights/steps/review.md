# Review — audit the evidence, assemble the payload that will be persisted

Goal: {{goal}}

What `strategize` reported:

{{step_output.strategize}}

Read first (shared artifacts directory `{{output_dir}}`):
`computed_metrics.json`, `intelligence_report.md`, `analysis_findings.json`,
`strategy_recommendations.md`, `strategy.json` — and the brand KB
(`iof-ainf_insights-kb <BRAND>`).

The step AFTER you persists your payload into the `ainf_data` insights
tables keyed by this run's id. What you approve becomes queryable rows.

## The review (per the `insight_review` skill)

1. **Evidence audit** — every figure names its source: a metric id, an
   `ainf_data` entity + SQL, or the creative_intel MCP. List anything that
   does not.
2. **Spot-recompute at least five material figures.** The metrics file
   records the SQL beside every value: re-run a sample verbatim
   (`iof-query --db commercial --sql-file query.sql --metadata-dir {{metadata_dir}}`)
   and compare — the headline share + gap, one region contribution, one
   account's share change, one cohort percentage — plus ONE fresh
   `mcp_creative_intel_campaign_summary` call against the creative claims.
   Report each: claimed, recomputed, verdict.
3. **Confidence calibration** — check each stated confidence against
   evidence breadth and the hypothesis's `confidence_basis` ceiling; lower
   any overreach, never raise.
4. **Coverage census** — panel accounts sum to the panel; all months in the
   trend; every driver has evidence rows; every ARMED hypothesis was either
   promoted or explicitly rejected; every UNARMED one is reported as ruled
   out. (KB coverage honesty: if the KB flagged a dataset/brand mismatch,
   the payload must carry it in `unverified`.)
5. **Fair-comparison check** — denominators stated; "not a cause" and "not
   recommended" preserved.

A mismatch is reported and CORRECTED IN THE PAYLOAD with your recomputed
value.

## Deliverables (both required — the step fails without them)

1. `{{output_dir}}/review_notes.md` — what you audited, recomputed
   (claimed vs recomputed, verdict), changed and why, the census counts,
   your overall verdict.
2. `{{output_dir}}/dashboard_insights.json` — VALID JSON, exactly this
   shape (write it section by section, then validate it parses):

```json
{
  "schema": "brand-insights/v1",
  "brand": "<UPPERCASE brand from the goal>",
  "goal": "{{goal}}",
  "period": {"window": "{{window}}", "latest_month": "{{latest_month}}"},
  "generated_by": "brand_insights workflow run {{run_id}}",
  "kpis": [
    {"id": "market_share", "label": "Market Share", "value": 0, "unit": "pct",
     "delta_vs_plan": "", "status": "needs_attention|on_track|over_pacing",
     "trend": [{"month": "", "actual": 0, "plan": 0, "prior_year": 0}]},
    {"id": "trx", "label": "TRx", "value": 0, "unit": "count", "delta_vs_plan": "", "status": "",
     "trend": [{"month": "", "actual": 0}]},
    {"id": "spend", "label": "Budget / Spend", "value": 0, "unit": "usd", "delta_vs_plan": "", "status": "",
     "trend": [{"month": "", "actual": 0, "plan": 0}]}
  ],
  "opportunities": [
    {"id": "opp-1", "headline": "", "category": "Brand performance",
     "confidence_pct": 0, "summary": "", "region_of_focus": "",
     "key_drivers": [
       {"rank": 1, "driver": "", "confidence_pct": 0,
        "accounts_affected": {"n": 0, "of": 0},
        "evidence": [{"source": "", "finding": "", "query": ""}]}
     ],
     "comparison": [{"factor": "", "verdict": "likely_cause|not_a_cause",
       "losing_pct": 0, "steady_pct": 0}],
     "priority_accounts": [{"rank": 1, "account": "", "score": 0,
       "share_change_pts": 0, "signals": [""]}],
     "recommended_actions": [{"rank": 1, "action": "", "impact": "",
       "confidence_pct": 0, "rationale": ""}],
     "not_recommended": [{"action": "", "reason": ""}]}
  ],
  "diagnosis": {"verdict": "", "note": ""},
  "unverified": [{"item": "", "reason": ""}],
  "qa_suggestions": ["Where are we off plan?", "Why is the top driver credible?",
    "Which accounts should we prioritize first?", "What should we do next?"]
}
```

`brand` and `goal` are REQUIRED — the persistence step keys on them.
Populate `opportunities` with everything validated (further opportunities —
competitor SOV, creative — when the evidence supports them). Evidence
`query` carries the SQL where the source is a metric or table. Unverified
content goes in `unverified`, never in the cards.

## Output

Print at least one line of text immediately BEFORE every tool call. The
orchestrator's stream consumer requires every assistant turn to contain a
text block before any tool_use block; turns that open with a tool call are
a known cause of dropped responses.

Write your protocol file to the path named under **Output destination** in
this prompt (NOT the deliverables directory above), starting with exactly
these two lines:

```
STATUS: done
OUTPUT: <one-line summary: verdict, corrections, payload ready to persist>
```
