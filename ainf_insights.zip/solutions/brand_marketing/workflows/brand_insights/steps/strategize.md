# Strategize — validate drivers, prioritize accounts, recommend actions

Goal: {{goal}}

What `analyze` reported:

{{step_output.analyze}}

Read first (all steps share one artifacts directory):
- `{{output_dir}}/computed_metrics.json` — the configured metrics AND the
  armed/cleared hypotheses; the cohort contrasts you need are already here
  (`sov_contrast`, `tcq_contrast`, `field_contact_contrast`,
  `campaign_exposure`).
- `{{output_dir}}/intelligence_report.md` and
  `{{output_dir}}/analysis_findings.json`
- The brand KB (`iof-ainf_insights-kb <BRAND>`) — your levers and framing
  come from it.

You may run your own queries
(`iof-query --db commercial --sql-file query.sql --metadata-dir {{metadata_dir}}`,
Postgres, fully qualify `ainf_data.<table>`) and the
`mcp_creative_intel_*` tools for anything not already computed — but the
arithmetic that IS computed is consumed, not repeated.

## What to produce

1. **Validated drivers** — at most three, promoted from the ARMED
   hypotheses (an unarmed hypothesis may only appear as explicitly
   rejected, with the metric values that cleared it). For each driver: the
   claim with accounts/regions named, every INDEPENDENT evidence stream
   (metric id or source + finding + counts with denominators), and a
   confidence calibrated per `brand_strategy` — use each hypothesis's
   `confidence_basis` from the metrics file as the ceiling rationale.
2. **The cohort contrast, judged** — the numbers are in the metrics; your
   work is the verdicts: "likely a cause" vs "happens in both — not a
   cause", each with both cohort figures and denominators. The
   field-contact verdict is mandatory (field_force_effectiveness skill).
3. **Priority accounts** — score every declining account:
   `score = risk x driver strength x account value`, normalized to 0-100
   (document the exact normalization). Inputs: `account_share_change`
   (risk, value) and which validated drivers show per account (query for
   per-account exposure/shift/notes as needed). Rank, set the action
   threshold, name what falls below it.
4. **Recommended actions** — three, ranked by impact, each with
   confidence, rationale, and the accounts/segments it applies to; levers
   chosen from the brand KB. If the creative evaluation held, a media-mix
   action belongs here with its MCP-sourced figures. Plus at least one
   **"do not do"** with the contrast that clears it.

## Deliverables (both required — the step fails without them)

1. `{{output_dir}}/strategy_recommendations.md` — drivers with evidence,
   the contrast verdicts, the scored account table with the formula, the
   actions and the do-not. Every figure carries its source.
2. `{{output_dir}}/strategy.json` — valid JSON:

```json
{
  "brand": "<UPPERCASE brand>",
  "drivers": [{"rank": 1, "driver": "", "hypothesis_id": "", "confidence_pct": 0,
    "evidence": [{"source": "", "finding": "", "n": 0, "of": 0}],
    "accounts_affected": {"n": 0, "of": 0}}],
  "rejected_hypotheses": [{"id": "", "driver": "", "reason": ""}],
  "comparison": [{"factor": "", "verdict": "likely_cause|not_a_cause",
    "losing_pct": 0, "steady_pct": 0}],
  "scoring": {"formula": "", "action_threshold": 0},
  "priority_accounts": [{"rank": 1, "account": "", "score": 0,
    "share_change_pts": 0, "signals": [""]}],
  "below_threshold": [{"account": "", "score": 0}],
  "recommended_actions": [{"rank": 1, "action": "", "impact": "highest|high|medium",
    "confidence_pct": 0, "rationale": "", "applies_to": ""}],
  "not_recommended": [{"action": "", "reason": ""}]
}
```

## Output

Print at least one line of text immediately BEFORE every tool call. The
orchestrator's stream consumer requires every assistant turn to contain a
text block before any tool_use block; turns that open with a tool call are
a known cause of dropped responses.

Write your protocol file to the path named under **Output destination** in
this prompt (NOT the deliverables directory above), starting with exactly
these two lines:

```
STATUS: done
OUTPUT: <one-line summary: drivers validated, top account, top action>
```
