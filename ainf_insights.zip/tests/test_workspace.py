"""The FLAT workspace contract.

Content at the root on the import path; solutions are workflow folders; the
tools package is the only pip-delivered thing. Every assertion corresponds
to a failure that is silent in dev: a manifest that stops loading refuses
`workspace diff`, an unregistered entry point hides tools.yaml from the
resolver, a solutions entry pointing at nothing resolves as nothing.
"""
from __future__ import annotations

import pathlib
import tomllib
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
_DATA = tomllib.loads((REPO / "pyproject.toml").read_text(encoding="utf-8"))


def test_manifest_loads():
    from ioagentfarm.solution_manifest import load_manifest
    m = load_manifest(REPO)
    assert m.agents_roots and m.skills_roots


def test_solutions_map_matches_the_directories():
    from ioagentfarm.solution_manifest import load_manifest
    m = load_manifest(REPO)
    for code, roots in m.solutions.items():
        for r in roots:
            assert r.is_dir(), f"solutions.{code} points at nothing: {r}"


def test_every_content_dir_is_mapped():
    """FLAT ON DISK, MAPPED FOR THE ENGINE. The engine resolves agents,
    skills and workflows from pack sources, so every content dir needs an
    import name — otherwise nothing here is readable from files and no run
    or chat can resolve it. The DIRECTORIES stay flat; only pyproject knows
    the prefixed names."""
    st = _DATA["tool"]["setuptools"]
    mapping = st["package-dir"]
    assert set(st["packages"]) == set(mapping), (
        "every declared package must be mapped to a flat directory")
    dirs = set(mapping.values())
    assert {"tools", "agents", "skills"} <= dirs, (
        f"content dirs missing from package-dir: {dirs}")
    for pkg, d in mapping.items():
        assert (REPO / d).is_dir(), f"{pkg} maps to {d}, which does not exist"


def _declared_packs() -> dict:
    """Every pack this repo declares.

    THERE IS MORE THAN ONE as soon as a solution exists: the workspace pack
    carries agents/skills/tools, and each solution adds its own workflows
    entry point. Nothing here may assume a single entry point -- a test that
    unpacked one was red on every workspace scaffolded with a solution.
    """
    return _DATA["project"]["entry-points"]["aicore.packs"]


def test_the_workspace_is_readable_from_files():
    """The property the flat layout exists for: an editable install lets the
    engine read THIS TREE, so an edit is live without a build step. If this
    fails, the engine has silently stopped reading your files."""
    import importlib
    roots = []
    for slug, target in _declared_packs().items():
        pack = importlib.import_module(target.split(":")[0]).pack()
        if pack.agents is not None:
            roots.append((slug, pathlib.Path(str(pack.agents)).resolve()))
    assert roots, (
        "no declared pack exposes an agents root, so the engine cannot read "
        "this repo's agents from files at all")
    for slug, root in roots:
        assert root == (REPO / "agents").resolve(), (
            f"{slug}'s agents root is {root}, not this repo's agents/ -- is "
            "the install editable? (pip install -e .)")


def test_every_declared_pack_is_importable_and_registered():
    """Declared in pyproject AND visible to the engine are two different
    facts. Entry points are read from installed metadata, so adding a
    solution to pyproject changes nothing until the repo is reinstalled --
    the pack is then invisible with no error anywhere."""
    import importlib
    from importlib.metadata import entry_points

    from ioagentfarm.packs import Pack

    declared = _declared_packs()
    assert declared, "this workspace declares no packs"
    installed = {e.name for e in entry_points(group="aicore.packs")}
    for slug, target in declared.items():
        mod = importlib.import_module(target.split(":")[0])
        assert isinstance(mod.pack(), Pack), (
            f"{slug}: {target} did not return a Pack")
        assert slug in installed, (
            f"entry point {slug!r} is declared in pyproject.toml but not "
            "registered in this venv -- run `pip install -e .` here. (A new "
            "solution or tool adds an entry point, and pip only sees it on "
            "reinstall.)")
