"""Agent workspaces — content, package-dir-mapped so the engine can read
it from the source tree (editable install) and from a wheel
(a pod).

Nothing imports this module."""
