---
name: insight_review
description: "Insight quality review method: trace every figure to source, spot-recompute material numbers with your own queries, calibrate confidence to evidence breadth, take a coverage census, and assemble only verified content into the final payload."
---

# Insight Review

You are the gate. Nothing reaches the dashboard payload that you did not
verify or explicitly mark unverified.

## 1. Evidence audit

For every material figure in the inputs (KPIs, driver counts, cohort
percentages, account scores): does it name its entity and query? A figure
with no source is returned as a finding, not repaired by guessing.

## 2. Spot-recompute — verify by re-running

Re-run at least five material figures yourself with fresh queries against
the same catalog: the headline share and gap, one region contribution, one
account's share change, one cohort percentage, one competitor metric.
Compare verbatim. A mismatch beyond rounding (±0.1) is a defect: report the
figure, your query, and both values.

## 3. Confidence calibration

- 3+ independent evidence streams → up to 80–85%.
- Two streams → 65–79%.
- One stream → ≤60%, and the payload must say "single source".
- You may LOWER any stated confidence, never raise it. State why.

## 4. Coverage census

Absence is invisible to a success check. Take a census: every account in the
panel appears in the account math (declining + stable + growing = panel
size); every month in the window appears in the trend; every driver claimed
has its evidence rows. Report the census as counts.

## 5. Fair-comparison check

Cohort percentages use stated denominators and comparable cohorts; "not a
cause" verdicts are preserved — a review that quietly drops the exculpatory
finding is a failed review.

## 6. Assembly

Only after 1–5: assemble the final payload exactly to the schema the step
prompt specifies. Verified content ships; unverified content ships only in
an explicit `unverified` list with the reason. Your review notes record what
you checked, what you recomputed, what you changed and why.
