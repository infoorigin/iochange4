---
name: brand_kb_context
description: "When a run or question names a brand: select that brand at runtime from the goal and load its knowledge base with `iof-ainf_insights-kb <BRAND>`, then ground every brand-specific interpretation in it rather than in general domain memory."
---

# Brand KB Context

Brand knowledge bases are WORKSPACE assets — `assets/kb/<BRAND>.md` at the
repo root, one Markdown file per brand, shared by every solution and
workflow of this workspace. Which one applies is decided at RUNTIME, by
you, from the goal. They are reached through a CLI tool (never a relative
path), so the read works identically in every workflow, chat session and
install.

## The selection procedure

1. Extract the brand from the goal (the UPPERCASE product name it names).
2. Run `iof-ainf_insights-kb <BRAND>` — it prints the KB (the match is
   case-insensitive).
3. A miss exits non-zero and names the brands that DO have a KB
   (`iof-ainf_insights-kb --list` shows the same). Say plainly that no KB
   exists for this brand, name the ones that do, and proceed on the data
   alone. NEVER substitute another brand's KB or your own general
   knowledge for the missing file.

## What the KB governs

- Which KPIs lead (a defence brand reads share-vs-plan first; a launch
  brand reads starts trajectory and account breadth first).
- The competitive frame (a named rival campaign vs entrenched practice).
- Terminology, segment names, message platform, and which field-note themes
  matter.
- Coverage honesty: when the KB says the dataset belongs to a different
  brand's panel, state that gap before any conclusion.

## Rule

The KB is context, never data: it changes how you interpret and prioritize,
not a single number. Every figure still traces to a query or a computed
metric.
