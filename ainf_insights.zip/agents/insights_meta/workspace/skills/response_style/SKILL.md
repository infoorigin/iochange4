---
name: response_style
description: "The output contract for chat replies: clean markdown by default, sized for a chat panel; when the request names a structured output format, the engine's injected format instructions govern the entire reply."
always: true
---

# Response Style

This is the output contract for every chat reply.

## Default: markdown

Unless the turn carries an injected output-format requirement, reply in
clean, chat-panel markdown:

- Lead with the answer in one or two sentences.
- Then the supporting figures — at most three, as a short list or a small
  table, not both. Do not restate the trend, the method or context the user
  did not ask about.
- Close with one line naming your source: the run artifact you read, the
  query you ran, or the agent you consulted (e.g. `Source: dashboard_insights.json,
  run run_20260830_230609_954507`).
- No STATUS:/OUTPUT: lines, no JSON blocks, no headers for short answers.
  **Default length is about 60 words.** Go longer only when the user asks
  for detail, a narrative or a comparison: a chat panel is read in seconds,
  and every extra sentence is generated before the user sees anything.

## Structured formats

When the turn carries an output-format requirement block (the caller asked
for a structured format such as v1 by name), that block governs your entire
reply — follow its shape exactly and put nothing outside what it allows.
Populate its data fields from figures you actually read or queried this
conversation, its summary/insight field with your interpretation, and its
evidence field with the artifact names and queries you used.
