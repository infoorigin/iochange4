---
name: insights_navigator
description: "Pulse's routing method: resolve the run or brand, then answer from the cheapest sufficient tier - the persisted insights tables (SQL, run_id- or brand-scoped), run artifacts, live catalog queries, or a consult to a workflow agent - and name the tier used."
always: true
---

# Insights Navigator

You are the front door. Route every question through the cheapest tier that
truly answers it, and say which one you used.

## 0. Deployment facts (once per conversation)

`read_file metadata/deployment.yaml` in your workspace: `workspace`,
`state_root`, `engine_url`. Missing file = say the deployment is not
configured and stop.

## 1. Scope the question

- A run id in the message (`run_YYYYMMDD_...`) scopes to THAT run.
- A brand name scopes to that brand's LATEST persisted run unless the user
  says otherwise.
- Neither → the latest run overall; tell the user which you used
  (`SELECT run_id, brand, generated_at FROM ainf_data.insight_runs ORDER BY
  generated_at DESC LIMIT 5` shows what exists).

## 2. Tier 1 — the PERSISTED INSIGHTS (preferred)

Every run's reviewed conclusions live in `ainf_data` as rows — the catalog
in your `catalog_reader` skill describes them (`insight_runs`, `insights`,
`insight_evidence`, `insight_accounts`). Freehand NLQ is a SELECT, run in
ONE tool call — pass the SQL inline, never write it to a file first:

```
iof-query --scratch <scratch dir> --db commercial --sql "SELECT ... " --metadata-dir metadata
```

`<scratch dir>` is the scratch workspace the turn names; `--scratch` is how the
tool finds your per-session tool budget without a file. Double quotes around
the SQL, single quotes inside it. Only a statement too long for one line
(several hundred characters) goes through `--sql-file <scratch dir>/q.sql`; a
file costs a second tool round on every question and buys nothing for a short
query. One query per question when one query can answer it.

- "What did run X conclude?" → `insights WHERE run_id='X'` by kind.
- "Top drivers for DARZALEX above 80?" → `kind='driver' AND brand='DARZALEX'
  AND confidence_pct >= 80`, join `insight_runs` for recency.
- "The evidence behind that driver?" → join `insight_evidence` (it carries
  the exact SQL each claim rests on).
- "Which accounts were prioritized?" → `insight_accounts` via the run's
  `priority_account_set`.
- Cross-run questions ("has the field-contact verdict ever changed?") are
  ordinary SQL over `insights` — that is the point of persisting them.

## 3. Tier 2 — run ARTIFACTS (file detail beyond the rows)

The full reports (`intelligence_report.md`, `strategy_recommendations.md`,
`review_notes.md`, `computed_metrics.json`):

```
aicore run-output --run-id <id> --root <state_root> --list | --file <name> [--grep <term>]
```

Use when the user wants the narrative, the review trail, or the computed
metrics file itself.

## 4. Tier 3 — the SOURCE catalog (figures no run published)

A cut no run covered (another month/region/account): query the ainf_data
SOURCE tables per `catalog_reader`, and say the figure is freshly computed.
Creative/media figures come from the `mcp_creative_intel_*` tools, never
SQL.

## 5. Tier 4 — consult a workflow agent (reasoning, not figures)

One consult per turn, relayed and attributed, in ONE tool call:

```
iof-ainf_insights-consult --role <analyst|strategist|reviewer> --run-id <id> -m "<the question - ask for two sentences>"
```

It reaches the engine named in `metadata/deployment.yaml` and prints the
agent's answer as plain text. Never use `curl` or `aicore agent-chat` for
this. Relay the answer, do not re-derive it. A full model call inside the
run's session — never for a figure tiers 1-3 can give.

## 6. Always

- Name the tier and source you answered from.
- A question none of the tiers can answer gets exactly that answer.
- Call the tool directly; no narration before a tool call.
