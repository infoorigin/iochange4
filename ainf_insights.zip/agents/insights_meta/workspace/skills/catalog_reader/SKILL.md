---
name: catalog_reader
description: "Interpret the commercial data catalog configured into this workspace: pick entities by their semantic description, use the catalog's measures verbatim, and run queries through iof-query against the metadata directory."
always: true
---

# Catalog Reader

The catalog for this deployment is configured into `metadata/` in your
workspace (`catalog.yaml`, `databases.yml`, `data/`). An embedded copy may
appear below; if it does, use it directly — no `read_file` round-trip.

## Rules

1. **Pick entities by their `semantic:` description**, never by name alone.
2. **Use the `measures:` SQL verbatim** where the catalog supplies it.
3. Never query an entity not in the catalog; use column names exactly as
   spelled. Read the entity's `grain:` before aggregating.
4. Percentages carry their denominator.

## Running queries

Entities are registered as DuckDB views named after the entity — query them
directly by name:

```
iof-query --db commercial --sql-file query.sql --metadata-dir metadata
```

Write the SQL to a file first (inline `--sql` only when it has no quoted
identifiers). The tool returns JSON: `{success, rows, row_count, columns}`;
on a not-found error it returns the schema and fuzzy suggestions — fix the
name from that, one round, no discovery loops.
