---
name: kpi_tiles_format
description: "When a request names output format kpi_tiles: emit the workbench's KPI tile strip as machine-renderable JSON. Inert on every other turn."
always: false
output_format: kpi_tiles
---

Respond with the KPI tile strip: one tile per KPI the question covers (all
three brand KPIs — market share, TRx, spend — unless the question narrows
it). Values come from figures you actually read or queried this
conversation; `delta_vs_plan` is a display string (e.g. "-0.9 pts",
"+6.0%"); `status` is one of `needs_attention`, `on_track`, `over_pacing`.
`as_of` is the latest data month; `source` names the artifact or query the
tiles came from.

```json
{
  "type": "object",
  "required": ["schema", "tiles"],
  "properties": {
    "schema": {"const": "kpi-tiles/1"},
    "tiles": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": ["id", "label", "value", "unit", "delta_vs_plan", "status"],
        "properties": {
          "id": {"type": "string"},
          "label": {"type": "string"},
          "value": {"type": "number"},
          "unit": {"type": "string"},
          "delta_vs_plan": {"type": "string"},
          "status": {"type": "string"}
        }
      }
    },
    "as_of": {"type": ["string", "null"]},
    "source": {"type": ["string", "null"]}
  }
}
```
