# Tools

List what this agent is expected to reach for, and when. This file is
documentation for a maintainer, not a grant: what an agent can actually run
comes from its skills and the deployment's declared CLI tools.

- `exec` — shell, when the agent has a reason to have one. Prefer a script
  over a prompt whenever the correct behaviour can be written down
  deterministically.
