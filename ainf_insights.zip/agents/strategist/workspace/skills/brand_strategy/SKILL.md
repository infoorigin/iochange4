---
name: brand_strategy
description: "Pharma brand strategy method: validate drivers with converging independent evidence and a cohort contrast, score priority accounts (risk x driver strength x account value), recommend actions with impact and confidence, and always state what NOT to do."
---

# Brand Strategy

You turn a grounded analysis into decisions. Judgment is welcome here —
labelled as judgment — but every input fact traces to the analysis you were
handed or a query you ran yourself.

## 1. Driver validation — converging, independent evidence

A candidate driver is VALIDATED only when at least two INDEPENDENT evidence
streams point at it (e.g., campaign exposure data + prescribing shift +
field-note mentions are three; the same fact restated is one). For each
driver record:

- the claim, in one sentence naming the affected accounts/regions;
- each evidence stream: source entity, the finding, the count with
  denominator;
- a confidence: ≥80% only with 3+ independent streams, 65–79% with two,
  ≤60% with one. Never above 85% on observational data.

## 2. The cohort contrast — what separates losing from steady

Compare the declining cohort against a comparable stable cohort on each
candidate factor: `% of losing accounts with the factor` vs `% of steady
accounts with the factor`, denominators stated.

- A factor markedly higher in the losing cohort → **likely a cause**.
- A factor present at similar rates in both → **happens in both — not a
  cause**. Saying this out loud is mandatory: it is what stops the team
  spending on a lever that does not discriminate.

## 3. Priority account scoring

`score = risk × driver strength × account value`, normalized to 0–100:

- **risk** — share points lost over the window (more lost = higher);
- **driver strength** — how many validated drivers show in this account
  (campaign exposure, prescribing shift, field-note mentions);
- **account value** — the account's market TRx (size of the prize).

Publish the formula with the scores, rank the accounts, and state the action
threshold: accounts below it are named but not actioned.

## 4. Recommended actions

Three or fewer, ranked by expected impact. Each carries:

- the action, concrete enough to brief a field team from;
- impact tier (highest / high / medium) and the reasoning;
- confidence (calibrated as in §1 — an action inherits the confidence of the
  weakest evidence it rests on);
- which accounts or segments it applies to.

**Always include at least one "do NOT do" recommendation** — a plausible
lever the evidence argues against (typically the factor the cohort contrast
cleared), with the contrast that clears it.

## 5. What a strategist never does

- Recommend on a driver the contrast did not support.
- Let a confidence exceed the evidence (three restatements ≠ three sources).
- Leave "what would change this recommendation" unstated when the evidence
  is thin.
