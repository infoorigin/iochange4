---
name: commercial_analytics
description: "Pharma commercial analysis method: share-vs-plan decomposition, volume-vs-share diagnosis, geography contribution to a national gap, account panel drill-down, competitor share of voice, field-note theme counting, creative performance comparison."
---

# Commercial Analytics

The standard decompositions for a brand performance question. Formulas here
are the method; every number still comes from a query (`grounded_analysis`).

## 1. Share vs plan — the headline

- `share_pct = 100.0 * SUM(brand_trx) / SUM(market_trx)` at whatever grain
  the question asks (month, region, account). Never average pre-computed
  share percentages across rows — recompute from volumes.
- Gap vs plan is stated in **points** (actual share − plan share), one
  decimal, with the month it is measured at.
- Always show the trend, not just the endpoint: month by month, actual vs
  plan vs prior year.

## 2. Volume vs share — lost volume, or lost share?

The single most valuable diagnosis. Compare the brand's TRx trend with its
share trend over the same window:

- Brand TRx flat/growing while share falls → **the market grew and someone
  else took the growth**. This points at competitor dynamics, not at brand
  erosion.
- Brand TRx falling with share → lost volume; look at demand, access, supply.

State which case the data shows, with both series.

## 3. Geography contribution to a national gap

For each region: `gap_trx = actual_brand_trx − plan_share * market_trx`
(plan share applied to the ACTUAL market). A region's contribution is its
share of the national gap: `region_gap / national_gap`. Name the regions that
carry the gap and the percentage each contributes; a region can contribute
negatively (running above plan).

## 4. Account panel drill-down

- Share change per account = share in the latest month − share in the first
  month of the window, in points.
- Count declining (< −0.5 pts), stable (within ±0.5), growing (> +0.5) — and
  say "N of M accounts", never a bare percentage.
- Rank the decliners by points lost; keep account names exactly as the data
  spells them.

## 5. Competitor signals

- Share of voice moves are measured Jan→latest in points, at the grain the
  data offers (priority-HCP weighted if the entity says so).
- Campaign exposure, competitor calls and speaker programs are counted per
  account per month — report exposure as "N of M accounts exposed since
  <month>".
- Prescribing shift: compare competitor new-patient starts by segment
  (latest vs window start); name the segment growing fastest.

## 6. Field notes — count themes, don't quote impressions

Notes are evidence when counted: accounts with ≥1 note matching a theme,
and share of notes matching a theme, both with denominators. A quoted
sentence is a verbatim substring of a returned row, attributed to its
account and date. Never summarize notes you did not retrieve.

## 7. Creative / campaign performance

Compare variants on the same metric and window: engagement rate, reach.
State the lift as a ratio and in points, and whether it is stable across
months — a one-month spike is noted as such.
