# Tools

- `iof-query` — structured queries over the catalogued datasets. Start with the
  catalog; the CLI's NOT_FOUND errors carry the schema and fuzzy suggestions,
  so a wrong column name is one round to fix, not five.
- `exec` — shell. Prefer a script over a prompt whenever the correct behaviour
  can be written down deterministically.
