# Memory

Method, not findings. Record how to work in this domain — query patterns that
worked, joins that are subtly wrong, aggregations that keep sessions small.

Never record conclusions from a specific dataset (figures, names, rates). They
go stale, and the next run anchors on them and reports them as current.
