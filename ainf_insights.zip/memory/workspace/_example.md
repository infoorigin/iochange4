# Curated workspace memory

Markdown files in this directory are carried WHOLE into the workspace's
memory and injected into every agent of the workspace as background
context. Route a file by its path:

    memory/<anything>.md              -> every agent (workspace scope)
    memory/workspace/**.md            -> every agent (workspace scope)
    memory/solution/<code>/**.md      -> agents running that solution's workflows
    memory/role/<role>/**.md          -> one agent role
    memory/user/<id>/**.md            -> one user (chat turns only)

Write what stays true across runs: how the data is organised and what it
lacks, systems and their quirks, conventions, owners, deadlines. Never
results computed from data - those belong in a run's deliverable.

A file whose name starts with `_` or `.` (this one) is never injected.
Verify with `aicore memory sync` then `aicore memory render --role <role>`.
