"""iof-ainf_insights-consult — ask a workflow agent, inside its run, in ONE call.

Pulse's tier-4 consult ("what did the strategist mean by ...") is a message to
the engine's run-context chat, ``POST /api/run/<id>/message`` with the role
named. Two ways of making that call from an agent's exec tool were measured
and rejected:

* ``aicore agent-chat --run-id`` — correct, but a CLI start-up that opens the
  database and stamps every pack: 3.0s before the request is even sent.
* ``curl`` — on Windows the exec tool runs through PowerShell, where ``curl``
  is an alias of Invoke-WebRequest with different flags, and a JSON body has
  to survive two layers of quoting. Measured: five attempts and 111 seconds
  for one consult, four of them spent on quoting.

This script is the third way: arguments, not JSON; httpx, not a shell; no
engine import, so it starts in well under a second. It prints the agent's
answer as plain text and nothing else, exits non-zero with the engine's
detail on any failure, and sends the deployment's engine credential when
one is configured (``IOF_ENGINE_CRED_*``, read the way every caller does).

    iof-ainf_insights-consult --role strategist --run-id run_... -m "Why ...?"

The engine URL comes from ``--url``, else ``IOF_RUN_API_URL``, else
``metadata/deployment.yaml`` beside the calling agent (what configure-agent
wrote), else the local default.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

DEFAULT_URL = "http://127.0.0.1:8111"


def _engine_url(explicit: str | None) -> str:
    if explicit:
        return explicit.rstrip("/")
    env = os.environ.get("IOF_RUN_API_URL")
    if env:
        return env.rstrip("/")
    for base in (Path.cwd(), Path.cwd().parent):
        facts = base / "metadata" / "deployment.yaml"
        if facts.is_file():
            for line in facts.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.strip().startswith("engine_url:"):
                    return line.split(":", 1)[1].strip().strip("'\"").rstrip("/")
    return DEFAULT_URL


def _auth_headers() -> dict[str, str]:
    try:
        from ioagentfarm.security.rail import engine_auth_headers
        return dict(engine_auth_headers())
    except Exception:  # noqa: BLE001 - no engine install, or auth off
        return {}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--role", required=True, help="analyst | strategist | reviewer")
    ap.add_argument("--run-id", required=True)
    ap.add_argument("-m", "--message", required=True)
    ap.add_argument("--url", default=None, help="engine base URL")
    ap.add_argument("--conversation-id", default=None,
                    help="thread to continue (default: one thread per run and role)")
    ap.add_argument("--user-id", default="pulse")
    ap.add_argument("--timeout", type=float, default=150.0)
    ap.add_argument("--json", action="store_true", help="print the engine's whole reply")
    a = ap.parse_args(argv)

    import httpx

    url = f"{_engine_url(a.url)}/api/run/{a.run_id}/message"
    body = {
        "content": a.message,
        "role": a.role,
        "user_id": a.user_id,
        "conversation_id": a.conversation_id or f"consult:{a.run_id}:{a.role}",
    }
    try:
        r = httpx.post(url, json=body, headers=_auth_headers(), timeout=a.timeout)
    except httpx.HTTPError as exc:
        print(f"consult failed: {url}: {exc}", file=sys.stderr)
        return 2
    if r.status_code != 200:
        print(f"consult failed: HTTP {r.status_code}: {r.text[:400]}", file=sys.stderr)
        return 3
    try:
        data = r.json()
    except ValueError:
        print(r.text)
        return 0
    if a.json:
        print(json.dumps(data, indent=1, ensure_ascii=False))
        return 0
    answer = data.get("content") or data.get("response") or ""
    if not answer:
        print(f"consult returned no answer: {json.dumps(data)[:400]}", file=sys.stderr)
        return 4
    name = data.get("agent_name") or data.get("agent") or a.role
    print(f"{name} ({a.role}, run {a.run_id}):")
    print(answer)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
