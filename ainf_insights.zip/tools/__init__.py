"""Ainf Insights workspace — the shared pack (agents, skills, CLI tools).

YOUR FILES ARE THE SOURCE OF TRUTH. The engine resolves agents and skills
from the installed pack, and in an editable install (`pip install -e .`)
`files()` points at THIS SOURCE TREE — so an edit to a SOUL.md or a SKILL.md
is live on the next run or chat, with no build step and nothing to push.

`workspace diff` / `pull` are the review path (what the Studio holds against
this repo), not a prerequisite of testing your own work.

On disk the directories are `agents/`, `skills/`, `tools/`; they install
under unique import names via the pyproject package-dir mapping — the
workspace prefix lives there and nowhere else.
"""

from importlib.resources import files

__version__ = "0.1.0"


def pack():
    from aicore.packs import (Pack, content_root, load_deliveries, load_mcp_servers,
                              load_skill_defaults)
    return Pack(
        # The WORKSPACE code — every pack in this repo declares the same one.
        workspace="ainf_insights",
        agents=files("ainf_insights_agents"),
        skills=files("ainf_insights_skills"),
        # Curated workspace memory: Markdown under memory/, routed by path,
        # injected into every agent of this workspace as background context.
        # WITHOUT THIS LINE the directory the scaffold creates - and the
        # instructions in memory/workspace/_example.md - do nothing: `memory
        # sync` reports 0 added and says nothing is wrong.
        #
        # `content_root`, not `files()`: memory is OPTIONAL, and `files()`
        # RAISES for a mapped directory that is absent from disk. Every root
        # here is resolved in this one call, so that exception took the
        # agents, skills and tools with it - a client saw
        # "NotADirectoryError: MultiplexedPath only supports directories"
        # and then, further down, "No installed pack provides an agent named
        # 'chat_advisor'". Both from a deleted `memory/`.
        memory=content_root("ainf_insights_memory"),
        tools=_cli_tools(),
        # `mcp.yaml` sits beside `tools.yaml` in the packaged tools package.
        # Without this it ships and is never read: the run reports success
        # with no servers attached.
        mcp_servers=load_mcp_servers("ainf_insights_tools"),
        # The tools case actions go through HERE - `deliveries.yaml`, beside
        # tools.yaml and mcp.yaml. See `iof-case deliveries`.
        deliveries=load_deliveries("ainf_insights_tools"),
        # The opening hand for a new agent home - `skill_defaults.yaml`,
        # beside tools.yaml. Without it a chat turn on a consulted agent
        # has no catalog_reader (a step gets it from the workflow filter;
        # the home does not).
        skill_defaults=load_skill_defaults("ainf_insights_tools"),
    )


def _cli_tools() -> list[dict]:
    import yaml

    f = files("ainf_insights_tools") / "tools.yaml"
    try:
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    except (FileNotFoundError, OSError, yaml.YAMLError):
        return []
    return [t for t in (data.get("tools") or []) if isinstance(t, dict)]
