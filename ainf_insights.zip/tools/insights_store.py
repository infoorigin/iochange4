"""iof-ainf_insights-insights_store — persist a run's reviewed insights.

Validates ``dashboard_insights.json`` (schema ``brand-insights/v1``) and maps
it into the four ``ainf_data`` insight tables:

    insight_runs (the run anchor)  ->  insights (typed, nested cards)
                                          ├─ insight_evidence
                                          └─ insight_accounts

This is the ONLY writer of those tables: agents produce the payload, the
review step verifies it, and this tool persists it — a validating boundary,
never a model INSERT. Transactional REPLACE-BY-RUN: the run's old rows are
deleted (FKs cascade) and the new set inserted in one transaction, so a
re-persisted run can never hold a mix of two versions.

Writes ``persist_receipt.json`` (per-table counts + run/brand) — the artifact
the workflow's fail-closed gate checks. Exits non-zero on any validation or
database error; nothing is committed in that case.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import psycopg2
import yaml


REQUIRED_TOP = ("schema", "brand", "period", "kpis", "opportunities")


def _db_url(metadata_dir: Path) -> str:
    try:
        from dotenv import load_dotenv
        raw = yaml.safe_load((metadata_dir / "databases.yml").read_text(encoding="utf-8"))
        if isinstance(raw, dict) and raw.get("env_file"):
            load_dotenv(str(Path(str(raw["env_file"])).expanduser()), override=False)
    except Exception:  # noqa: BLE001
        pass
    from ioagentfarm.tools.query_executor import load_database_configs
    cfg = load_database_configs(str(metadata_dir)).get("commercial") or {}
    if cfg.get("type") != "postgres":
        sys.exit("databases.yml: 'commercial' must be a postgres entry")
    return cfg["url"]


def _month(v):
    if not v:
        return None
    s = str(v)
    return s + "-01" if len(s) == 7 else s


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--payload", required=True, help="dashboard_insights.json")
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--workflow", default="brand_insights")
    ap.add_argument("--goal", default="")
    ap.add_argument("--metadata-dir", required=True)
    ap.add_argument("--metrics", default="",
                    help="computed_metrics.json - persisted as rows "
                         "(run_metrics / run_metric_points / run_hypotheses) "
                         "in the same transaction")
    ap.add_argument("--out", required=True, help="persist_receipt.json")
    args = ap.parse_args()

    try:
        d = json.loads(Path(args.payload).read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        print(f"payload is not valid JSON: {exc}", file=sys.stderr)
        return 2

    missing = [k for k in REQUIRED_TOP if k not in d]
    if missing:
        print(f"payload missing required keys: {missing}", file=sys.stderr)
        return 2
    if d.get("schema") != "brand-insights/v1":
        print(f"unexpected payload schema {d.get('schema')!r}", file=sys.stderr)
        return 2
    brand = str(d.get("brand") or "").strip().upper()
    if not brand:
        print("payload.brand is empty", file=sys.stderr)
        return 2
    # The goal rides in the payload (the review step writes it there) so the
    # exec command line never has to carry free text through shell quoting.
    goal = args.goal or str(d.get("goal") or "")

    metrics_doc = None
    if args.metrics:
        try:
            metrics_doc = json.loads(Path(args.metrics).read_text(encoding="utf-8"))
        except FileNotFoundError:
            print(f"metrics artifact not found: {args.metrics}", file=sys.stderr)
            return 2
        except Exception as exc:  # noqa: BLE001
            print(f"metrics artifact is not valid JSON: {exc}", file=sys.stderr)
            return 2

    con = psycopg2.connect(_db_url(Path(args.metadata_dir)))
    con.autocommit = False
    cur = con.cursor()
    counts = {"insight_runs": 0, "insights": 0,
              "insight_evidence": 0, "insight_accounts": 0,
              "run_metrics": 0, "run_metric_points": 0, "run_hypotheses": 0}

    def ins(run_id, kind, headline, *, parent=None, rank=None, ref=None,
            confidence=None, verdict=None, payload=None) -> int:
        cur.execute(
            "INSERT INTO ainf_data.insights (run_id, brand, kind, "
            "parent_insight_id, rank, ref, headline, confidence_pct, verdict, "
            "payload) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
            "RETURNING insight_id",
            (run_id, brand, kind, parent, rank, ref, headline, confidence,
             verdict, json.dumps(payload or {})))
        counts["insights"] += 1
        return cur.fetchone()[0]

    def evid(insight_id, source, finding, sql=None, n=None, of=None):
        cur.execute(
            "INSERT INTO ainf_data.insight_evidence (insight_id, source, "
            "finding, query_sql, n, of_total) VALUES (%s,%s,%s,%s,%s,%s)",
            (insight_id, source, finding, sql, n, of))
        counts["insight_evidence"] += 1

    try:
        # replace-by-run: cascade clears children
        cur.execute("DELETE FROM ainf_data.insight_runs WHERE run_id=%s",
                    (args.run_id,))

        period = d.get("period") or {}
        cur.execute(
            "INSERT INTO ainf_data.insight_runs (run_id, workflow, brand, "
            "goal, latest_month, diagnosis, payload) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (args.run_id, args.workflow, brand, goal,
             _month(period.get("latest_month")),
             (d.get("diagnosis") or {}).get("verdict"), json.dumps(d)))
        counts["insight_runs"] = 1

        for k in d.get("kpis") or []:
            head = f"{k.get('label', k.get('id'))}: {k.get('value')} " \
                   f"{k.get('unit','')} ({k.get('delta_vs_plan','')})".strip()
            ins(args.run_id, "kpi", head, ref=k.get("id"),
                verdict=k.get("status"), payload=k)

        diag = d.get("diagnosis") or {}
        if diag:
            ins(args.run_id, "diagnosis",
                f"{diag.get('verdict','')}: {str(diag.get('note',''))[:400]}",
                payload=diag)

        for o in d.get("opportunities") or []:
            oid = ins(args.run_id, "opportunity", o.get("headline", ""),
                      ref=o.get("id"), confidence=o.get("confidence_pct"),
                      payload={k: v for k, v in o.items()
                               if k not in ("key_drivers", "comparison",
                                            "priority_accounts",
                                            "recommended_actions",
                                            "not_recommended")})
            for drv in o.get("key_drivers") or []:
                did = ins(args.run_id, "driver", drv.get("driver", ""),
                          parent=oid, rank=drv.get("rank"),
                          confidence=drv.get("confidence_pct"), payload=drv)
                aa = drv.get("accounts_affected") or {}
                for e in drv.get("evidence") or []:
                    evid(did, e.get("source", ""), e.get("finding", ""),
                         e.get("query"), aa.get("n"), aa.get("of"))
            for c in o.get("comparison") or []:
                ins(args.run_id, "comparison", c.get("factor", ""),
                    parent=oid, verdict=c.get("verdict"), payload=c)
            pa = o.get("priority_accounts") or []
            if pa:
                sid = ins(args.run_id, "priority_account_set",
                          f"Priority accounts ({len(pa)})", parent=oid,
                          payload={"count": len(pa)})
                for a in pa:
                    cur.execute(
                        "INSERT INTO ainf_data.insight_accounts (insight_id, "
                        "account_name, rank, score, share_change_pts, signals)"
                        " VALUES (%s,%s,%s,%s,%s,%s)",
                        (sid, a.get("account", ""), a.get("rank"),
                         a.get("score"), a.get("share_change_pts"),
                         json.dumps(a.get("signals") or [])))
                    counts["insight_accounts"] += 1
            for act in o.get("recommended_actions") or []:
                ins(args.run_id, "action", act.get("action", ""), parent=oid,
                    rank=act.get("rank"), confidence=act.get("confidence_pct"),
                    verdict=act.get("impact"), payload=act)
            for nr in o.get("not_recommended") or []:
                ins(args.run_id, "not_recommended", nr.get("action", ""),
                    parent=oid, payload=nr)

        # ── the computed-metrics tier: same transaction, same replace ──
        if metrics_doc is not None:
            PROMOTED = ("month", "region", "account_name", "segment")
            for mid, m in (metrics_doc.get("metrics") or {}).items():
                if "error" in m:
                    continue                  # a failed metric is not a fact
                rows = m.get("rows")
                cur.execute(
                    "INSERT INTO ainf_data.run_metrics (run_id, metric_id, "
                    "title, unit, shape, value, query_sql, row_count, "
                    "rules_version, computed_at) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                    (args.run_id, mid, m.get("title", mid), m.get("unit"),
                     "rows" if rows is not None else "row",
                     None if rows is not None else json.dumps(m.get("value")),
                     m.get("sql", ""), m.get("row_count"),
                     str(metrics_doc.get("rules_version", "")),
                     metrics_doc.get("generated_at")))
                counts["run_metrics"] += 1
                for ord_, r in enumerate(rows or []):
                    r = dict(r)
                    promoted = {k: r.pop(k) for k in PROMOTED if k in r}
                    mo = promoted.get("month")
                    cur.execute(
                        "INSERT INTO ainf_data.run_metric_points (run_id, "
                        "metric_id, ord, month, region, account_name, "
                        "segment, dims, vals) "
                        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                        (args.run_id, mid, ord_, _month(mo),
                         promoted.get("region"), promoted.get("account_name"),
                         promoted.get("segment"), json.dumps({}),
                         json.dumps(r)))
                    counts["run_metric_points"] += 1
            for h in metrics_doc.get("hypotheses") or []:
                cur.execute(
                    "INSERT INTO ainf_data.run_hypotheses (run_id, "
                    "hypothesis_id, driver, armed, evaluate, source, "
                    "arm_when_sql, evidence_metrics, confidence_basis) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                    (args.run_id, h["id"], h.get("driver", ""),
                     h.get("armed"),
                     h.get("evaluate", "sql"), h.get("source"),
                     h.get("arm_when_sql"),
                     json.dumps(h.get("evidence_metrics") or []),
                     h.get("confidence_basis", "")))
                counts["run_hypotheses"] += 1

        con.commit()
    except Exception as exc:  # noqa: BLE001
        con.rollback()
        print(f"persist failed, nothing committed: {exc}", file=sys.stderr)
        return 1
    finally:
        cur.close()
        con.close()

    receipt = {"run_id": args.run_id, "brand": brand, "tables": counts,
               "schema": "ainf_data"}
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(receipt, indent=1), encoding="utf-8")
    print(json.dumps(receipt))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
