"""iof-ainf_insights-kb — print a brand's knowledge base.

Brand KBs are WORKSPACE assets (`assets/kb/<BRAND>.md`), shared by every
solution and workflow, not shipped inside any one workflow's metadata. A
run snapshot carries only the workflow directory, so a root-level asset
cannot be reached through `{{metadata_dir}}` — this tool is the seam: it
resolves the KB through the installed package (editable install = the
repo tree; wheel = the packaged copy), so the same command works on a dev
box and in a pod, from any cwd.

    iof-ainf_insights-kb DARZALEX     # print that brand's KB
    iof-ainf_insights-kb --list       # the brands that have one

Selection stays the AGENT's job (the brand arrives in the run goal); this
tool only makes the read location-independent. A miss names the brands
that exist — never guess, never substitute.
"""
from __future__ import annotations

import argparse
import sys
from importlib.resources import files


def _kb_dir():
    return files("ainf_insights_assets") / "kb"


def _brands() -> list[str]:
    try:
        return sorted(p.name[:-3] for p in _kb_dir().iterdir()
                      if p.name.endswith(".md"))
    except Exception:  # noqa: BLE001 - an empty store is "no brands", not a crash
        return []


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Print a brand's knowledge base from assets/kb/")
    ap.add_argument("brand", nargs="?", help="brand code, e.g. DARZALEX "
                    "(case-insensitive)")
    ap.add_argument("--list", action="store_true",
                    help="list the brands that have a KB")
    args = ap.parse_args()

    brands = _brands()
    if args.list or not args.brand:
        print("\n".join(brands) if brands else "(no brand KBs installed)")
        return 0

    match = next((b for b in brands
                  if b.lower() == args.brand.strip().lower()), None)
    if match is None:
        print(f"no KB for '{args.brand}'. Brands that have one: "
              + (", ".join(brands) or "(none)"), file=sys.stderr)
        return 3
    sys.stdout.write((_kb_dir() / f"{match}.md").read_text(encoding="utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
