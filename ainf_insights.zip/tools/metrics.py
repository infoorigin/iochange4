"""iof-ainf_insights-metrics — execute the CONFIGURED analysis.

Reads ``metadata/rules.yaml`` (metrics + hypotheses), runs every metric's SQL
and every hypothesis's ``arm_when`` condition against the database that
``metadata/databases.yml`` declares, and writes ``computed_metrics.json``:

    {"metrics": {id: {title, unit, value|rows, sql, row_count}},
     "hypotheses": [{id, driver, armed, evidence_metrics, ...}]}

This is the workflow's ``compute`` step. The analyst CONSUMES this artifact —
cites each value with the SQL recorded beside it — and never performs
aggregation arithmetic. Change a threshold or add a hypothesis in rules.yaml;
nothing here or in any prompt changes.

A DETERMINISTIC TOOL, not an agent: same rules + same data => same artifact
(``generated_at`` aside), testable without a model. Exits non-zero when any
metric errors — a partial metrics file would push the analyst back into doing
arithmetic silently.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import decimal
import json
import sys
from pathlib import Path

import psycopg2
import psycopg2.extras
import yaml

# ONE connection convention: the same loader iof-query uses (env_file +
# ${VAR} resolution), so the two tools cannot disagree about credentials.
from ioagentfarm.tools.query_executor import load_database_configs


def _sub(sql: str, variables: dict) -> str:
    for k, v in (variables or {}).items():
        sql = sql.replace("{{%s}}" % k, str(v))
    return sql


def _plain(v):
    if isinstance(v, decimal.Decimal):
        f = float(v)
        return int(f) if f.is_integer() else f
    if isinstance(v, (_dt.date, _dt.datetime)):
        return v.isoformat()
    return v


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--metadata-dir", required=True,
                    help="workflow metadata dir holding rules.yaml + databases.yml")
    ap.add_argument("--out", required=True, help="computed_metrics.json path")
    args = ap.parse_args()

    md = Path(args.metadata_dir)
    rules = yaml.safe_load((md / "rules.yaml").read_text(encoding="utf-8"))
    variables = rules.get("vars") or {}

    # The runtime strips an exec'd subprocess's environment, so credentials
    # come from the env_file databases.yml names — loaded HERE, before the
    # config loader resolves ${VAR} refs (the same order iof-query uses).
    try:
        from dotenv import load_dotenv
        raw = yaml.safe_load((md / "databases.yml").read_text(encoding="utf-8"))
        if isinstance(raw, dict) and raw.get("env_file"):
            load_dotenv(str(Path(str(raw["env_file"])).expanduser()),
                        override=False)
    except Exception:  # noqa: BLE001 - a missing file fails loudly below
        pass

    dbs = load_database_configs(str(md))
    cfg = dbs.get(rules.get("database", "commercial"))
    if not cfg or cfg.get("type") != "postgres":
        print(f"rules.yaml database {rules.get('database')!r} is not a "
              f"postgres entry in databases.yml", file=sys.stderr)
        return 2

    con = psycopg2.connect(cfg["url"])
    con.autocommit = True
    cur = con.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    out = {
        "generated_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "rules_version": rules.get("version"),
        "database": rules.get("database", "commercial"),
        "vars": variables,
        "metrics": {},
        "hypotheses": [],
    }
    failed = 0

    for m in rules.get("metrics") or []:
        sql = _sub(m["sql"], variables).strip()
        entry = {"title": m.get("title", m["id"]), "unit": m.get("unit"),
                 "sql": sql}
        try:
            cur.execute(sql)
            rows = [{k: _plain(v) for k, v in r.items()} for r in cur.fetchall()]
            entry["row_count"] = len(rows)
            if m.get("shape") == "rows":
                entry["rows"] = rows
            else:
                entry["value"] = rows[0] if rows else None
        except Exception as exc:  # noqa: BLE001 - recorded, and the run fails
            entry["error"] = str(exc).strip()
            failed += 1
            print(f"metric {m['id']}: {entry['error']}", file=sys.stderr)
        out["metrics"][m["id"]] = entry

    for h in rules.get("hypotheses") or []:
        rec = {"id": h["id"], "driver": h["driver"],
               "evidence_metrics": h.get("evidence_metrics") or [],
               "confidence_basis": h.get("confidence_basis", "")}
        if h.get("evaluate") == "external":
            rec.update(armed=None, evaluate="external",
                       source=h.get("source", ""), guidance=h.get("guidance", ""))
        else:
            sql = _sub(h["arm_when"], variables).strip()
            rec["arm_when_sql"] = sql
            try:
                cur.execute(sql)
                row = cur.fetchone()
                rec["armed"] = bool(list(row.values())[0]) if row else False
            except Exception as exc:  # noqa: BLE001
                rec["armed"] = None
                rec["error"] = str(exc).strip()
                failed += 1
                print(f"hypothesis {h['id']}: {rec['error']}", file=sys.stderr)
        out["hypotheses"].append(rec)

    cur.close()
    con.close()

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(out, indent=1), encoding="utf-8")
    armed = [h["id"] for h in out["hypotheses"] if h.get("armed")]
    ext = [h["id"] for h in out["hypotheses"] if h.get("armed") is None
           and h.get("evaluate") == "external"]
    print(f"computed {len(out['metrics'])} metrics; armed hypotheses: "
          f"{armed or 'none'}; external evaluation: {ext or 'none'}; "
          f"wrote {args.out}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
