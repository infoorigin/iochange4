# Streaming chat through a BFF

A FastAPI service that relays the engine's chat API to a browser. The browser
calls this service on the same paths with the same bodies; the engine URL and
its credentials stay server-side.

```
browser  ──POST /api/chat/general/stream──▶  BFF  ──▶  engine :8131
         ◀──────── text/event-stream ───────┘
```

| Route | Relays to |
|---|---|
| `POST /api/chat/{ns}/stream` | the engine's SSE stream, chunk by chunk |
| `POST /api/chat/{ns}` | the same turn, one JSON reply |
| `GET /api/chat/{ns}/messages` | thread history |

## Run

An engine must be serving an agent — see
[walkthrough 3](../../docs/examples/feature-walkthroughs/03-multi-turn.md).

```bash
pip install -r requirements.txt
IOF_ENGINE_URL=http://127.0.0.1:8131 uvicorn bff:app --port 8090
```

Open <http://127.0.0.1:8090>. `index.html` is a 90-line chat page: it posts a
message, reads the stream, and renders it as it arrives.

| Variable | Default | |
|---|---|---|
| `IOF_ENGINE_URL` | `http://127.0.0.1:8131` | where the engine is |
| `IOF_ENGINE_CRED_API_KEY` | unset | sent as `X-API-Key` when the engine runs with `IOF_ENGINE_AUTH=apikey` |

The sample sends `agent`, `user_id` and `conversation_id` from the page so it
runs with no login. In a real BFF, take `user_id` from the authenticated
principal and `conversation_id` from the session — a browser that can name its
own `user_id` can read another person's thread.

