"""BFF that relays the engine's chat API to the browser. Same paths, same bodies."""
from __future__ import annotations

import json
import os
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse

ENGINE = os.environ.get("IOF_ENGINE_URL", "http://127.0.0.1:8131").rstrip("/")
API_KEY = os.environ.get("IOF_ENGINE_CRED_API_KEY", "")

app = FastAPI(title="Chat BFF")
HERE = Path(__file__).parent


def headers(request: Request) -> dict[str, str]:
    """Engine credentials are added here. The browser never holds them."""
    h = {"Content-Type": request.headers.get("content-type", "application/json")}
    if API_KEY:
        h["X-API-Key"] = API_KEY
    return h


@app.get("/")
def index() -> FileResponse:
    return FileResponse(HERE / "index.html")


@app.post("/api/chat/{ns}/stream")
async def chat_stream(ns: str, request: Request) -> StreamingResponse:
    body = await request.body()
    client = httpx.AsyncClient(timeout=None)          # a turn can take minutes
    try:
        upstream = await client.send(
            client.build_request("POST", f"{ENGINE}/api/chat/{ns}/stream",
                                 content=body, headers=headers(request)),
            stream=True)                              # do not read the body
    except httpx.HTTPError as exc:
        await client.aclose()
        raise HTTPException(502, f"engine unreachable: {exc}")

    if upstream.status_code >= 400:
        # The engine refuses before the stream starts; keep it an HTTP status.
        raw = (await upstream.aread()).decode("utf-8", "replace")
        await upstream.aclose()
        await client.aclose()
        try:
            detail = json.loads(raw).get("detail", raw)
        except ValueError:
            detail = raw[:500]
        raise HTTPException(upstream.status_code, detail)

    async def relay():
        try:
            async for chunk in upstream.aiter_raw():
                yield chunk
        finally:
            await upstream.aclose()
            await client.aclose()

    return StreamingResponse(relay(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",                    # nginx buffers SSE otherwise
    })


@app.post("/api/chat/{ns}")
async def chat(ns: str, request: Request) -> JSONResponse:
    return await _forward(request, f"/api/chat/{ns}", body=await request.body())


@app.get("/api/chat/{ns}/messages")
async def messages(ns: str, request: Request) -> JSONResponse:
    return await _forward(request, f"/api/chat/{ns}/messages", method="GET",
                          query=request.url.query)


async def _forward(request: Request, path: str, *, method: str = "POST",
                   body: bytes | None = None, query: str = "") -> JSONResponse:
    url = f"{ENGINE}{path}" + (f"?{query}" if query else "")
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.request(method, url, content=body,
                                     headers=headers(request))
    except httpx.HTTPError as exc:
        raise HTTPException(502, f"engine unreachable: {exc}")
    is_json = "json" in r.headers.get("content-type", "")
    return JSONResponse(status_code=r.status_code,
                        content=r.json() if is_json else {"detail": r.text})
